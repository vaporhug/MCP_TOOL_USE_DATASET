#!/usr/bin/env python3

from __future__ import annotations

from pathlib import Path

import matplotlib
import numpy as np
import pandas as pd

matplotlib.use("Agg")
import matplotlib.pyplot as plt


LIB_LABELS = {"NCA", "NMC532", "NMC622", "NMC811", "NMC900", "NMC900-Si", "LFP"}


def _artifact_path(filename: str) -> Path:
    path = Path(__file__).resolve().parents[1] / "artifacts" / filename
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def _clean_text(value) -> str:
    return str(value).replace("\n", " ").strip()


def demand_projection_summary(path: str) -> dict:
    df = pd.read_excel(path, sheet_name="Source Data Figure 1", header=None)
    values = pd.to_numeric(df.iloc[21, 3:23], errors="coerce").to_numpy(dtype=float)
    year_labels = pd.to_numeric(df.iloc[3, 3:23], errors="coerce").to_numpy(dtype=int)
    shares = {
        "NCA": pd.to_numeric(df.iloc[22, 3:23], errors="coerce").to_numpy(dtype=float),
        "NMC532_622": pd.to_numeric(df.iloc[23, 3:23], errors="coerce").to_numpy(dtype=float),
        "NMC811_900": pd.to_numeric(df.iloc[24, 3:23], errors="coerce").to_numpy(dtype=float),
        "LFP": pd.to_numeric(df.iloc[25, 3:23], errors="coerce").to_numpy(dtype=float),
        "PLIB": pd.to_numeric(df.iloc[26, 3:23], errors="coerce").to_numpy(dtype=float),
    }
    return {
        "demand_2021_gwh": float(values[0]),
        "demand_2030_gwh": float(values[9]),
        "demand_2040_gwh": float(values[-1]),
        "share_2030": {k: float(v[9]) for k, v in shares.items()},
        "share_2040": {k: float(v[-1]) for k, v in shares.items()},
        "years": year_labels.tolist(),
    }


def _figure3_energy_table(path: str) -> pd.DataFrame:
    raw = pd.read_excel(path, sheet_name="Source Data Figure 3", header=None)
    headers = [_clean_text(v) for v in raw.iloc[5].tolist()]
    chemistry_cols = []
    for idx, header in enumerate(headers):
        if idx < 4 or idx > 29 or not header or header == "nan" or header.startswith("x"):
            continue
        chemistry_cols.append((idx, header))
    rows = raw.iloc[6:36, [1, 2] + [idx for idx, _ in chemistry_cols]].copy()
    rows.columns = ["process_group", "process_step"] + [name for _, name in chemistry_cols]
    rows["process_group"] = rows["process_group"].ffill().map(_clean_text)
    rows["process_step"] = rows["process_step"].map(_clean_text)
    for _, name in chemistry_cols:
        rows[name] = pd.to_numeric(rows[name], errors="coerce").fillna(0.0)
    return rows.reset_index(drop=True)


def chemistry_energy_summary(path: str) -> dict:
    df = pd.read_excel(path, sheet_name="Source Data Figure 4", header=None)
    rows = df.iloc[6:19, 1:5].copy()
    rows.columns = ["chemistry", "electric_kwh_m2", "gas_kwh_m2", "total_kwh_m2"]
    rows["chemistry"] = rows["chemistry"].astype(str).str.strip()
    for col in rows.columns[1:]:
        rows[col] = pd.to_numeric(rows[col], errors="coerce")
    rows = rows.dropna()
    lib = rows[rows["chemistry"].str.contains("NCA|NMC|LFP")]
    plib = rows[rows["chemistry"].str.contains("SIB|SSB|LSB|LAB")]
    best = rows.loc[rows["total_kwh_m2"].idxmin()]
    worst = rows.loc[rows["total_kwh_m2"].idxmax()]
    return {
        "rows": rows.to_dict("records"),
        "mean_lib_total_kwh_m2": float(lib["total_kwh_m2"].mean()),
        "mean_plib_total_kwh_m2": float(plib["total_kwh_m2"].mean()),
        "lowest_energy_chemistry": str(best["chemistry"]),
        "lowest_energy_value": float(best["total_kwh_m2"]),
        "highest_energy_chemistry": str(worst["chemistry"]),
        "highest_energy_value": float(worst["total_kwh_m2"]),
    }


def process_step_breakdown(path: str, chemistry_label: str = "NMC811") -> dict:
    table = _figure3_energy_table(path)
    if chemistry_label not in table.columns:
        available = [c for c in table.columns if c not in {"process_group", "process_step"}]
        raise KeyError(f"Unknown chemistry_label {chemistry_label!r}; available: {available}")
    subset = table[["process_group", "process_step", chemistry_label]].rename(columns={chemistry_label: "value"})
    subset = subset[subset["value"] > 0].reset_index(drop=True)
    group = subset.groupby("process_group", as_index=False)["value"].sum().sort_values("value", ascending=False)
    top = subset.sort_values("value", ascending=False).head(5)
    return {
        "chemistry": chemistry_label,
        "group_totals": group.to_dict("records"),
        "top_steps": top.to_dict("records"),
        "total_cell_energy_kwhprod_per_kwhcell": float(subset["value"].sum()),
    }


def cell_energy_comparison_summary(path: str) -> dict:
    table = _figure3_energy_table(path)
    chemistry_cols = [c for c in table.columns if c not in {"process_group", "process_step"}]
    totals = table[chemistry_cols].sum().sort_values()
    rows = []
    for chemistry, value in totals.items():
        family = "LIB" if chemistry in LIB_LABELS else "PLIB"
        rows.append({"chemistry": chemistry, "family": family, "total_kwhprod_per_kwhcell": float(value)})
    frame = pd.DataFrame(rows)
    lib = frame[frame["family"] == "LIB"]
    plib = frame[frame["family"] == "PLIB"]
    return {
        "rows": rows,
        "lib_range_kwhprod_per_kwhcell": [float(lib["total_kwhprod_per_kwhcell"].min()), float(lib["total_kwhprod_per_kwhcell"].max())],
        "plib_range_kwhprod_per_kwhcell": [float(plib["total_kwhprod_per_kwhcell"].min()), float(plib["total_kwhprod_per_kwhcell"].max())],
        "lowest_lib": lib.sort_values("total_kwhprod_per_kwhcell").iloc[0].to_dict(),
        "highest_lib": lib.sort_values("total_kwhprod_per_kwhcell", ascending=False).iloc[0].to_dict(),
        "lowest_plib": plib.sort_values("total_kwhprod_per_kwhcell").iloc[0].to_dict(),
        "highest_plib": plib.sort_values("total_kwhprod_per_kwhcell", ascending=False).iloc[0].to_dict(),
    }


def cell_level_process_change_summary(path: str) -> dict:
    df = pd.read_excel(path, sheet_name="Source Data Figure 2", header=None)
    chemistry_cols = {
        "SSB_polymer": 8,
        "SSB_oxidic": 9,
        "SSB_sulfidic": 10,
        "LSB": 11,
        "LAB": 12,
    }
    rows = df.iloc[7:36, [1, 2, *chemistry_cols.values(), 16, 17]].copy()
    rows.columns = ["process_group", "process_step", *chemistry_cols.keys(), "direction_marker", "rationale"]
    rows["process_group"] = rows["process_group"].ffill().map(_clean_text)
    rows["process_step"] = rows["process_step"].map(_clean_text)
    for col in chemistry_cols:
        rows[col] = pd.to_numeric(rows[col], errors="coerce")
    long = rows.melt(
        id_vars=["process_group", "process_step", "direction_marker", "rationale"],
        value_vars=list(chemistry_cols),
        var_name="chemistry",
        value_name="relative_energy_multiplier",
    ).dropna(subset=["relative_energy_multiplier"])
    return {
        "assumption_rows": int(len(long)),
        "chemistry_count": int(long["chemistry"].nunique()),
        "process_group_count": int(long["process_group"].nunique()),
        "min_multiplier": float(long["relative_energy_multiplier"].min()),
        "max_multiplier": float(long["relative_energy_multiplier"].max()),
        "mean_multiplier_by_chemistry": {
            str(k): float(v) for k, v in long.groupby("chemistry")["relative_energy_multiplier"].mean().to_dict().items()
        },
        "extreme_assumptions": long.sort_values("relative_energy_multiplier", ascending=False).head(6).to_dict("records"),
    }


def macro_energy_forecast_summary(path: str) -> dict:
    workbook = pd.ExcelFile(path)
    scenario_rows = []
    for sheet in [s for s in workbook.sheet_names if s.startswith("Source Data Figure 7 -")]:
        raw = pd.read_excel(path, sheet_name=sheet, header=None)
        scenario = sheet.rsplit(" - ", 1)[-1]
        years = pd.to_numeric(raw.iloc[3, 3:23], errors="coerce").astype(int).tolist()
        extrapolated = pd.to_numeric(raw.iloc[4, 3:23], errors="coerce").to_numpy(dtype=float)
        trend = pd.to_numeric(raw.iloc[65, 3:23], errors="coerce").to_numpy(dtype=float)
        best = pd.to_numeric(raw.iloc[80, 3:23], errors="coerce").to_numpy(dtype=float)
        worst = pd.to_numeric(raw.iloc[95, 3:23], errors="coerce").to_numpy(dtype=float)
        year_to_index = {year: idx for idx, year in enumerate(years)}
        paper_discussed_idx = year_to_index.get(2031)
        scenario_rows.append(
            {
                "scenario": scenario,
                "years": years,
                "extrapolated_today_gwhprod_2040": float(extrapolated[-1]),
                "optimized_trend_gwhprod_2040": float(trend[-1]),
                "optimized_best_gwhprod_2040": float(best[-1]),
                "optimized_worst_gwhprod_2040": float(worst[-1]),
                "optimized_trend_gwhprod_2031": float(trend[paper_discussed_idx]) if paper_discussed_idx is not None else None,
            }
        )
    by_scenario = {row["scenario"]: row for row in scenario_rows}
    mixed = by_scenario["Mix"]
    plib = by_scenario["PLIB"]
    savings = mixed["extrapolated_today_gwhprod_2040"] - mixed["optimized_trend_gwhprod_2040"]
    return {
        "scenarios": scenario_rows,
        "mixed_2040_savings_gwhprod": float(savings),
        "mixed_2040_savings_percent": float(savings / mixed["extrapolated_today_gwhprod_2040"] * 100.0),
        "plib_vs_mixed_2040_extra_savings_gwhprod": float(
            mixed["optimized_trend_gwhprod_2040"] - plib["optimized_trend_gwhprod_2040"]
        ),
    }


def plot_demand_and_market_share(path: str, output_filename: str = "demand_market_share.png") -> dict:
    df = pd.read_excel(path, sheet_name="Source Data Figure 1", header=None)
    years = pd.to_numeric(df.iloc[3, 3:23], errors="coerce").to_numpy(dtype=int)
    demand = pd.to_numeric(df.iloc[21, 3:23], errors="coerce").to_numpy(dtype=float)
    plib = pd.to_numeric(df.iloc[26, 3:23], errors="coerce").to_numpy(dtype=float)
    nmc_hi = pd.to_numeric(df.iloc[24, 3:23], errors="coerce").to_numpy(dtype=float)
    lfp = pd.to_numeric(df.iloc[25, 3:23], errors="coerce").to_numpy(dtype=float)
    output = _artifact_path(output_filename)
    fig, ax1 = plt.subplots(figsize=(7.2, 4.4))
    ax1.plot(years, demand, color="#1f77b4", marker="o")
    ax1.set_xlabel("Year")
    ax1.set_ylabel("Global battery demand (GWh)", color="#1f77b4")
    ax2 = ax1.twinx()
    ax2.plot(years, nmc_hi, label="NMC811/900 share", color="#d62728")
    ax2.plot(years, lfp, label="LFP share", color="#2ca02c")
    ax2.plot(years, plib, label="PLIB share", color="#9467bd")
    ax2.set_ylabel("Market share")
    ax2.legend(fontsize=8, loc="upper left")
    fig.tight_layout()
    fig.savefig(output, dpi=200)
    plt.close(fig)
    return {"path": str(output), "demand_2040_gwh": float(demand[-1])}


def plot_process_breakdown(path: str, chemistry_label: str = "NMC811", output_filename: str = "process_breakdown.png") -> dict:
    result = process_step_breakdown(path, chemistry_label)
    rows = result["group_totals"]
    output = _artifact_path(output_filename)
    fig, ax = plt.subplots(figsize=(7.2, 4.4))
    ax.barh([r["process_group"] for r in rows], [r["value"] for r in rows], color="#4C78A8")
    ax.invert_yaxis()
    ax.set_xlabel("Energy contribution (kWhprod per kWhcell)")
    ax.set_title(f"Process energy breakdown: {chemistry_label}")
    fig.tight_layout()
    fig.savefig(output, dpi=200)
    plt.close(fig)
    return {"path": str(output), "chemistry": chemistry_label}


def plot_chemistry_energy_comparison(path: str, output_filename: str = "chemistry_energy_comparison.png") -> dict:
    result = cell_energy_comparison_summary(path)
    rows = result["rows"]
    colors = ["#4C78A8" if r["family"] == "LIB" else "#F58518" for r in rows]
    output = _artifact_path(output_filename)
    fig, ax = plt.subplots(figsize=(7.5, 4.8))
    ax.barh([r["chemistry"] for r in rows], [r["total_kwhprod_per_kwhcell"] for r in rows], color=colors)
    ax.invert_yaxis()
    ax.set_xlabel("Total production energy (kWhprod per kWhcell)")
    ax.set_title("Fig. 3 cell-energy comparison: LIB vs PLIB")
    fig.tight_layout()
    fig.savefig(output, dpi=200)
    plt.close(fig)
    return {"path": str(output), **result}


def package_smoke_test() -> dict:
    root = Path(__file__).resolve().parents[1]
    data = root / "input_data" / "data"
    demand = str(data / "41560_2023_1355_MOESM3_ESM.xlsx")
    fig2 = str(data / "41560_2023_1355_MOESM4_ESM.xlsx")
    fig3 = str(data / "41560_2023_1355_MOESM5_ESM.xlsx")
    fig4 = str(data / "41560_2023_1355_MOESM6_ESM.xlsx")
    fig7 = str(data / "41560_2023_1355_MOESM9_ESM.xlsx")
    return {
        "demand": demand_projection_summary(demand),
        "cell_level_assumptions": cell_level_process_change_summary(fig2),
        "cell_energy": cell_energy_comparison_summary(fig3),
        "chemistry_area_energy": chemistry_energy_summary(fig4),
        "process": process_step_breakdown(fig3),
        "macro_forecast": macro_energy_forecast_summary(fig7),
        "figures": [
            plot_demand_and_market_share(demand),
            plot_process_breakdown(fig3),
            plot_chemistry_energy_comparison(fig3),
        ],
    }

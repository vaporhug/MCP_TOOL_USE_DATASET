This tools folder is organized into three layers.

- `energy_tools.py`: domain primitives for battery-demand projections, cell-chemistry production-energy comparisons, process-step decomposition, and artifact generation.
- `data_processing.py`: generic table-reading and file-inventory helpers.
- `database_retrieval.py`: local reference/source inspection helpers.

Use the domain tool to reproduce the public battery-production energy workflow from released source data.

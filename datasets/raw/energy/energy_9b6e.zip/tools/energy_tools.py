from __future__ import annotations

from pathlib import Path
import re
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

try:
    from pypdf import PdfReader
except Exception:  # pragma: no cover - smoke test reports this if unavailable
    PdfReader = None

try:
    from .data_processing import data_root, list_files
    from .database_retrieval import inventory, public_repository_links
except ImportError:
    import importlib.util
    import sys

    tools_dir = Path(__file__).resolve().parent
    task_name = re.sub(r"[^0-9A-Za-z_]", "_", Path(__file__).resolve().parents[1].name)

    def _load_sibling_module(module_filename: str, module_stem: str):
        module_path = tools_dir / module_filename
        module_name = f"_energy_9b6e_{task_name}_{module_stem}"
        spec = importlib.util.spec_from_file_location(module_name, module_path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Cannot load {module_path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        spec.loader.exec_module(module)
        return module

    _dp = _load_sibling_module("data_processing.py", "data_processing")
    _db = _load_sibling_module("database_retrieval.py", "database_retrieval")
    data_root = _dp.data_root
    list_files = _dp.list_files
    inventory = _db.inventory
    public_repository_links = _db.public_repository_links

ARTIFACT_DIR = Path(__file__).resolve().parents[1] / "artifacts"
ARTIFACT_DIR.mkdir(exist_ok=True)


def source_inventory(root: str | Path | None = None) -> dict:
    root_path = Path(root) if root else data_root()
    files = list_files(root_path)
    return {
        "n_files": len(files),
        "extensions": sorted({Path(f).suffix.lower() for f in files}),
        "pdfs": [f for f in files if Path(f).suffix.lower() == ".pdf"],
        "repositories": public_repository_links().get("repositories", []),
    }


def _target_pdf() -> Path:
    return Path(__file__).resolve().parents[1] / "input_data" / "reference_paper" / "target.pdf"


def _supplement_pdf() -> Path:
    candidates = sorted(data_root().glob("*_MOESM1_ESM.pdf"))
    if not candidates:
        raise FileNotFoundError("No SuperSalt supplementary information PDF found")
    return candidates[0]


def _extract_pdf_text(path: Path) -> str:
    if PdfReader is None:
        raise ImportError("pypdf is required for local PDF metric extraction")
    reader = PdfReader(str(path))
    return _normalise_pdf_text("\n".join(page.extract_text() or "" for page in reader.pages))


def _normalise_pdf_text(text: str) -> str:
    replacements = {
        "\ufb01": "fi",
        "\ufb02": "fl",
        "−": "-",
        "–": "-",
        "˚A": "angstrom",
        "Å": "angstrom",
        "Å": "angstrom",
        "×": "x",
        "\u00a0": " ",
    }
    for src, dst in replacements.items():
        text = text.replace(src, dst)
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"(?<=\d)\s+(?=\d)", "", text)
    text = text.replace("coef ficients", "coefficients")
    return text.strip()


def _evidence_excerpt(text: str, start: int, end: int, window: int = 180) -> str:
    return text[max(0, start - window): min(len(text), end + window)]


def _require_match(pattern: str, text: str, label: str, flags: int = re.I) -> re.Match:
    match = re.search(pattern, text, flags=flags)
    if not match:
        raise ValueError(f"Could not parse {label} from bundled paper text")
    return match


def _word_to_int(word: str) -> int:
    lookup = {
        "one": 1,
        "first": 1,
        "two": 2,
        "second": 2,
        "three": 3,
        "third": 3,
        "four": 4,
        "fourth": 4,
        "five": 5,
        "fifth": 5,
        "six": 6,
        "sixth": 6,
    }
    cleaned = word.lower().strip()
    if cleaned.isdigit():
        return int(cleaned)
    if cleaned not in lookup:
        raise ValueError(f"Unrecognised iteration word: {word}")
    return lookup[cleaned]


def _compact_formula(formula: str) -> str:
    return re.sub(r"\s+", "", formula)


def paper_text_excerpt(pattern: str, source: str = "target", window: int = 220) -> str:
    path = _target_pdf() if source == "target" else _supplement_pdf()
    text = _extract_pdf_text(path)
    match = re.search(pattern, text, flags=re.I)
    if not match:
        return ""
    start = max(0, match.start() - window)
    end = min(len(text), match.end() + window)
    return text[start:end]


def supersalt_training_test_rmse() -> pd.DataFrame:
    text = _extract_pdf_text(_target_pdf())
    rows = []

    train = _require_match(
        r"RMSE of total potential energy predictions reaches a value as low as ([\d.]+) meV/atom for both datasets, "
        r"and the RMSEs of atomic forces predictions are ([\d.]+) meV/ ?angstrom and ([\d.]+) meV/ ?angstrom",
        text,
        "SuperSalt training and validation RMSE",
    )
    for dataset, force_group in [("Training", 2), ("Validation", 3)]:
        rows.append({
            "model": "SuperSalt",
            "dataset": dataset,
            "energy_rmse_mev_atom": float(train.group(1)),
            "force_rmse_mev_angstrom": float(train.group(force_group)),
            "source": "target.pdf",
            "evidence_excerpt": _evidence_excerpt(text, train.start(), train.end()),
        })

    tests = _require_match(
        r"testing RMSEs of the SuperSalt for the Test_1 dataset are ([\d.]+) meV/atom and ([\d.]+) meV/ ?angstrom\. "
        r"For the Test_2 dataset, the testing RMSEs of the SuperSalt are ([\d.]+) meV/atom and ([\d.]+) meV/ ?angstrom",
        text,
        "SuperSalt test-set RMSE",
    )
    for dataset, energy_group, force_group in [("Test_1", 1, 2), ("Test_2", 3, 4)]:
        rows.append({
            "model": "SuperSalt",
            "dataset": dataset,
            "energy_rmse_mev_atom": float(tests.group(energy_group)),
            "force_rmse_mev_angstrom": float(tests.group(force_group)),
            "source": "target.pdf",
            "evidence_excerpt": _evidence_excerpt(text, tests.start(), tests.end()),
        })

    mace = _require_match(
        r"resulting errors for the Test_1 and Test_2 datasets are ([\d.]+) meV/atom and ([\d.]+) meV/atom, "
        r"respectively, with corresponding force errors of ([\d.]+) meV/ ?angstrom and ([\d.]+) meV/ ?angstrom",
        text,
        "MACE-MP0 test-set RMSE",
    )
    for dataset, energy_group, force_group in [("Test_1", 1, 3), ("Test_2", 2, 4)]:
        rows.append({
            "model": "MACE-MP0",
            "dataset": dataset,
            "energy_rmse_mev_atom": float(mace.group(energy_group)),
            "force_rmse_mev_angstrom": float(mace.group(force_group)),
            "source": "target.pdf",
            "evidence_excerpt": _evidence_excerpt(text, mace.start(), mace.end()),
        })

    return pd.DataFrame(rows)


def eos_rmse_comparison() -> pd.DataFrame:
    text = _extract_pdf_text(_target_pdf())
    supersalt = _require_match(
        r"RMSE in the predictions of bulk modulus, minimum energy, and equilibrium density between the SuperSalt potential and DFT are "
        r"([\d.]+) GPa, ([\d.]+) meV/atom, and ([\d.]+) x 10 ?-?(\d+) g/cm3",
        text,
        "SuperSalt EOS RMSE",
    )
    mace = _require_match(
        r"MACE-MP0 results show RMSEs of ([\d.]+) GPa, ([\d.]+) meV/atom, and ([\d.]+) x 10 ?-?(\d+) g/cm3",
        text,
        "MACE-MP0 EOS RMSE",
    )
    supersalt_density = float(supersalt.group(3)) * 10 ** (-int(supersalt.group(4)))
    mace_density = float(mace.group(3)) * 10 ** (-int(mace.group(4)))
    evidence = _evidence_excerpt(text, supersalt.start(), mace.end())
    return pd.DataFrame([
        {"metric": "Bulk modulus", "unit": "GPa", "SuperSalt": float(supersalt.group(1)), "MACE-MP0": float(mace.group(1)), "source": "target.pdf", "evidence_excerpt": evidence},
        {"metric": "Minimum energy", "unit": "meV/atom", "SuperSalt": float(supersalt.group(2)), "MACE-MP0": float(mace.group(2)), "source": "target.pdf", "evidence_excerpt": evidence},
        {"metric": "Equilibrium density", "unit": "g/cm3", "SuperSalt": supersalt_density, "MACE-MP0": mace_density, "source": "target.pdf", "evidence_excerpt": evidence},
    ])


def thermophysical_validation_summary() -> pd.DataFrame:
    text = _extract_pdf_text(_target_pdf())
    density_aimd = _require_match(r"average deviation of less than ([\d.]+)% across a wide temperature range", text, "density AIMD deviation")
    density_exp = _require_match(r"mass densities predicted by SuperSalt show .*?average differ-?\s*ence of ([\d.]+)%", text, "density experiment deviation")
    heat_capacity = _require_match(r"largest deviation being ([\d.]+)% for .*?which remains within the error margin", text, "heat capacity deviation")
    expansion = _require_match(r"thermal expansion coefficients predicted by SuperSalt show a slight deviation, with an average difference of ([\d.]+)%", text, "thermal expansion deviation")
    return pd.DataFrame([
        {"property": "Density vs AIMD", "reported_deviation_percent": float(density_aimd.group(1)), "qualifier": "less than", "source": "target.pdf", "evidence_excerpt": _evidence_excerpt(text, density_aimd.start(), density_aimd.end())},
        {"property": "Density vs experiment", "reported_deviation_percent": float(density_exp.group(1)), "qualifier": "average", "source": "target.pdf", "evidence_excerpt": _evidence_excerpt(text, density_exp.start(), density_exp.end())},
        {"property": "Heat capacity", "reported_deviation_percent": float(heat_capacity.group(1)), "qualifier": "largest", "source": "target.pdf", "evidence_excerpt": _evidence_excerpt(text, heat_capacity.start(), heat_capacity.end())},
        {"property": "Thermal expansion", "reported_deviation_percent": float(expansion.group(1)), "qualifier": "average", "source": "target.pdf", "evidence_excerpt": _evidence_excerpt(text, expansion.start(), expansion.end())},
    ])


def bayesian_optimization_outcomes() -> pd.DataFrame:
    text = _extract_pdf_text(_target_pdf())
    target_window = _require_match(
        r"target range of ([\d.]+)\s*-\s*([\d.]+) g/\s*cm3 at 1200 K.*?mixing enthalpy window of (-?[\d.]+) to (-?[\d.]+) eV/atom",
        text,
        "BO target windows",
    )
    max_density = _require_match(
        r"BO algorithm quickly found the maximum density of ([\d.]+) g/\s*cm\s*3 in the first iteration, corre-?\s*sponding to pure ([A-Za-z0-9 ]+?)\.",
        text,
        "BO maximum density result",
    )
    target_density = _require_match(
        r"BO found a composition with a density of ([\d.]+) g/\s*cm\s*3 after ([A-Za-z0-9]+) iterations, corresponding to the ([A-Za-z0-9 ]+?) composition",
        text,
        "BO target density result",
    )
    target_enthalpy = _require_match(
        r"the (fourth|[A-Za-z0-9]+) round to pinpoint a composition \((.*?)\).*?enthalpy was (-?[\d.]+) eV/atom",
        text,
        "BO target mixing enthalpy result",
    )
    return pd.DataFrame([
        {
            "experiment": "Maximum density",
            "iterations": _word_to_int("first"),
            "target": "maximize density",
            "result_value": float(max_density.group(1)),
            "unit": "g/cm3",
            "composition": _compact_formula(max_density.group(2)),
            "source": "target.pdf",
            "evidence_excerpt": _evidence_excerpt(text, max_density.start(), max_density.end()),
        },
        {
            "experiment": "Target density",
            "iterations": _word_to_int(target_density.group(2)),
            "target": f"{target_window.group(1)}-{target_window.group(2)} g/cm3",
            "result_value": float(target_density.group(1)),
            "unit": "g/cm3",
            "composition": _compact_formula(target_density.group(3)),
            "source": "target.pdf",
            "evidence_excerpt": _evidence_excerpt(text, target_density.start(), target_density.end()),
        },
        {
            "experiment": "Target mixing enthalpy",
            "iterations": _word_to_int(target_enthalpy.group(1)),
            "target": f"{target_window.group(3)} to {target_window.group(4)} eV/atom",
            "result_value": float(target_enthalpy.group(3)),
            "unit": "eV/atom",
            "composition": _compact_formula(target_enthalpy.group(2)),
            "source": "target.pdf",
            "evidence_excerpt": _evidence_excerpt(text, target_enthalpy.start(), target_enthalpy.end()),
        },
    ])


def plot_test_rmse_comparison(output_filename: str = "Fig1_energy_9b6e_feature_profile.png") -> dict:
    df = supersalt_training_test_rmse()
    test = df[df["dataset"].isin(["Test_1", "Test_2"])]
    out = ARTIFACT_DIR / output_filename
    out.parent.mkdir(parents=True, exist_ok=True)
    labels = [f"{row.model}\n{row.dataset}" for row in test.itertuples()]
    x = np.arange(len(test))
    fig, ax = plt.subplots(figsize=(8.8, 4.8))
    ax.bar(x - 0.18, test["energy_rmse_mev_atom"], width=0.36, label="Energy RMSE", color="#4c78a8")
    ax.bar(x + 0.18, test["force_rmse_mev_angstrom"], width=0.36, label="Force RMSE", color="#f58518")
    ax.set_yscale("log")
    ax.set_xticks(x)
    ax.set_xticklabels(labels)
    ax.set_ylabel("RMSE (log scale)")
    ax.set_title("SuperSalt vs MACE-MP0 test errors from local paper PDFs")
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(out, dpi=180)
    plt.close(fig)
    return {"path": str(out), "rows": int(len(test)), "source": "target.pdf and supplementary text"}


def plot_eos_rmse_comparison(output_filename: str = "Fig2_energy_9b6e_workflow_contrast.png") -> dict:
    df = eos_rmse_comparison()
    out = ARTIFACT_DIR / output_filename
    out.parent.mkdir(parents=True, exist_ok=True)
    fig, axes = plt.subplots(1, 3, figsize=(10.5, 3.8))
    for ax, (_, row) in zip(axes, df.iterrows()):
        ax.bar(["SuperSalt", "MACE-MP0"], [row["SuperSalt"], row["MACE-MP0"]], color=["#4c78a8", "#e45756"])
        ax.set_title(row["metric"])
        ax.set_ylabel(row["unit"])
    fig.suptitle("EOS-derived property RMSE comparison against DFT")
    fig.tight_layout()
    fig.savefig(out, dpi=180)
    plt.close(fig)
    return {"path": str(out), "rows": int(len(df)), "source": "target.pdf performance text"}


def plot_bo_outcomes(output_filename: str = "Fig3_energy_9b6e_signal_relationship.png") -> dict:
    df = bayesian_optimization_outcomes()
    out = ARTIFACT_DIR / output_filename
    out.parent.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(8.8, 4.8))
    colors = ["#54a24b", "#4c78a8", "#b279a2"]
    ax.bar(df["experiment"], df["iterations"], color=colors)
    for i, row in enumerate(df.itertuples()):
        ax.text(i, row.iterations + 0.15, f"{row.result_value:g} {row.unit}\n{row.composition}", ha="center", va="bottom", fontsize=8)
    ax.set_ylabel("Iterations to reported result")
    ax.set_title("SuperSalt-BO reported search outcomes from target paper")
    ax.set_ylim(0, max(df["iterations"]) + 2.2)
    fig.tight_layout()
    fig.savefig(out, dpi=180)
    plt.close(fig)
    return {"path": str(out), "rows": int(len(df)), "source": "target.pdf BO text"}


def package_smoke_test() -> dict:
    return {
        "inventory": source_inventory(),
        "rmse_rows": int(len(supersalt_training_test_rmse())),
        "eos_rows": int(len(eos_rmse_comparison())),
        "thermophysical_rows": int(len(thermophysical_validation_summary())),
        "bo_rows": int(len(bayesian_optimization_outcomes())),
        "target_excerpt_available": bool(paper_text_excerpt(r"Test_1 dataset")),
        "plot_functions": [
            "plot_test_rmse_comparison",
            "plot_eos_rmse_comparison",
            "plot_bo_outcomes",
        ],
    }

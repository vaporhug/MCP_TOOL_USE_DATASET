# Tools

This directory follows the three-layer task-tool structure.

- `data_processing.py`: file discovery, PDF-aware numeric-source discovery, archive inspection, and table helpers.
- `database_retrieval.py`: local inventory, article-link extraction, and public repository discovery.
- `energy_tools.py`: task-specific SuperSalt validation primitives for the molten-salt MLIP paper.

No source workbook is bundled for this task. The domain tools therefore expose a scoped public-paper workflow: extracting and comparing paper-reported SuperSalt validation, MACE-MP0 comparison, thermophysical-property, and Bayesian-optimization metrics from the local target and supplementary PDFs. `package_smoke_test()` regenerates the three expected artifacts from those local PDF-derived metric tables.

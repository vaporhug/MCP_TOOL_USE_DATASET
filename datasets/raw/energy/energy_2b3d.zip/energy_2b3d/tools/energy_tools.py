from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import pandas as pd

from data_processing import load_excel, save_figure
from database_retrieval import locate_file


def _source_workbook() -> Path:
    return locate_file(
        "input_data/data/source_data/41467_2025_56063_MOESM3_ESM.xlsx",
        "input_data/data/source_data.xlsx",
    )


def _osf_inputs_workbook() -> Path:
    return locate_file(
        "input_data/data/osf_model_inputs/conv_log_figs.xlsx",
        "input_data/data/conv_log_figs.xlsx",
    )


def _canonical_stage_key(label: str) -> str:
    txt = str(label).strip().lower()
    txt = txt.replace("energ:", "energy:")
    txt = txt.replace("co2-eq", "co2")
    txt = txt.replace(":", "_")
    txt = txt.replace("-", "_")
    txt = txt.replace(" ", "_")
    txt = txt.replace("__", "_")
    return txt


def compare_recycling_vs_mining() -> dict:
    df = load_excel(_source_workbook(), "Fig. 6", header=None)
    conv_cir = df[df.iloc[:, 0].astype(str).isin(["Conv.", "Cir."])].reset_index(drop=True)
    if conv_cir.shape[0] < 4:
        raise ValueError("Fig. 6 must contain at least two Conv./Cir. row pairs")
    cases = []
    for i in range(0, 4, 2):
        cases.append({"name": f"case_{(i // 2) + 1}", "conv_row": conv_cir.iloc[i], "cir_row": conv_cir.iloc[i + 1]})
    out = []
    for case in cases:
        conv = case["conv_row"]
        cir = case["cir_row"]
        co2_conv = float(pd.to_numeric(conv.iloc[1:4], errors="coerce").sum())
        co2_cir = float(pd.to_numeric(cir.iloc[1:4], errors="coerce").sum())
        energy_conv = float(pd.to_numeric(conv.iloc[4:7], errors="coerce").sum())
        energy_cir = float(pd.to_numeric(cir.iloc[4:7], errors="coerce").sum())
        water_conv = float(pd.to_numeric(conv.iloc[7:10], errors="coerce").sum())
        water_cir = float(pd.to_numeric(cir.iloc[7:10], errors="coerce").sum())
        category = {
            "co2e": {
                "conv": co2_conv,
                "cir": co2_cir,
            },
            "energy": {
                "conv": energy_conv,
                "cir": energy_cir,
            },
            "water": {
                "conv": water_conv,
                "cir": water_cir,
            },
        }
        for k in category:
            category[k]["reduction_pct"] = 100 * (1 - category[k]["cir"] / category[k]["conv"])
        out.append({"name": case["name"], **category})
    return {"cases": out}


def stage_contribution_summary() -> dict:
    df = load_excel(_source_workbook(), "Fig. 5", header=None)
    stage_cols = [str(c).strip() for c in df.iloc[1, 1:8].tolist()]
    row_slice = df.iloc[2:8, 0:8].copy()
    rows = {}
    for _, row in row_slice.iterrows():
        if pd.isna(row.iloc[0]):
            continue
        rows[_canonical_stage_key(row.iloc[0])] = row.iloc[1:8].copy()
    summary = {}
    for key, series in rows.items():
        vals = pd.to_numeric(series.values, errors="coerce")
        summary[key] = {
            col: (None if pd.isna(val) else float(val))
            for col, val in zip(stage_cols, vals)
        }
        nonnull = {col: val for col, val in summary[key].items() if val is not None}
        summary[key]["dominant_stage"] = max(nonnull, key=nonnull.get) if nonnull else None
    return summary


def inventory_summary() -> dict:
    wb = _osf_inputs_workbook()
    mines = load_excel(wb, "Tables S18")
    refineries = load_excel(wb, "Tables S19")
    valid_elements = {"Li", "Co", "Ni", "Al"}
    mine_counts = (
        mines.loc[mines.iloc[:, 1].astype(str).isin(valid_elements), mines.columns[1]]
        .dropna()
        .astype(str)
        .value_counts()
        .to_dict()
    )
    refining_counts = (
        refineries.loc[refineries.iloc[:, 1].astype(str).isin(valid_elements), refineries.columns[1]]
        .dropna()
        .astype(str)
        .value_counts()
        .to_dict()
    )
    return {
        "mine_counts": mine_counts,
        "refining_counts": refining_counts,
        "mine_rows": int(mines.dropna(how="all").shape[0]),
        "refining_rows": int(refineries.dropna(how="all").shape[0]),
    }


def case_pair_sensitivity() -> dict:
    df = load_excel(_source_workbook(), "Fig. 6", header=None)
    conv_rows = df[df.iloc[:, 0].astype(str) == "Conv."].reset_index(drop=True)
    if conv_rows.shape[0] < 2:
        raise ValueError("Fig. 6 must contain at least two Conv. rows")
    case1 = conv_rows.iloc[0]
    case2 = conv_rows.iloc[1]
    return {
        "case_1": {
            "co2e_refining": float(case1.iloc[1]),
            "co2e_logistics": float(case1.iloc[2]),
            "co2e_mining": float(case1.iloc[3]),
            "energy_refining": float(case1.iloc[4]),
            "energy_logistics": float(case1.iloc[5]),
            "energy_mining": float(case1.iloc[6]),
            "water_refining": float(case1.iloc[7]),
            "water_logistics": float(case1.iloc[8]),
            "water_mining": float(case1.iloc[9]),
        },
        "case_2": {
            "co2e_refining": float(case2.iloc[1]),
            "co2e_logistics": float(case2.iloc[2]),
            "co2e_mining": float(case2.iloc[3]),
            "energy_refining": float(case2.iloc[4]),
            "energy_logistics": float(case2.iloc[5]),
            "energy_mining": float(case2.iloc[6]),
            "water_refining": float(case2.iloc[7]),
            "water_logistics": float(case2.iloc[8]),
            "water_mining": float(case2.iloc[9]),
        },
    }


def plot_recycling_vs_mining(
    case_summary: list[dict] | None = None,
    output_name: str = "recycling_vs_mining.png",
) -> str:
    summary = case_summary if case_summary is not None else compare_recycling_vs_mining()["cases"]
    labels = [case["name"] for case in summary]
    metrics = ["co2e", "energy", "water"]
    fig, ax = plt.subplots(figsize=(9, 5))
    x = range(len(labels))
    width = 0.24
    for i, metric in enumerate(metrics):
        vals = [case[metric]["reduction_pct"] for case in summary]
        ax.bar([v + (i - 1) * width for v in x], vals, width=width, label=metric.upper())
    ax.set_xticks(list(x), labels)
    ax.set_ylabel("Reduction vs conventional (%)")
    ax.set_title("Recycling supply chain reductions vs mining")
    ax.legend(frameon=False)
    return save_figure(fig, output_name)


def plot_stage_breakdown(
    stage_summary: dict | None = None,
    output_name: str = "stage_breakdown.png",
) -> str:
    summary = stage_summary if stage_summary is not None else stage_contribution_summary()
    fig, ax = plt.subplots(figsize=(10, 5))
    row_order = [
        "energy_recycled_scrap",
        "energy_recycled_battery",
        "co2_recycled_scrap",
        "co2_recycled_battery",
        "water_recycled_scrap",
        "water_recycled_battery",
    ]
    present_rows = [k for k in row_order if k in summary]
    if not present_rows:
        raise ValueError("No expected stage-contribution rows found in Fig. 5")
    stage_names = [k for k in summary[present_rows[0]].keys() if k != "dominant_stage"]
    mat = []
    for key in present_rows:
        vals = [summary[key].get(stage) for stage in stage_names]
        vals = [0.0 if v is None else float(v) for v in vals]
        total = sum(vals)
        mat.append([v / total if total > 0 else 0.0 for v in vals])
    norm_df = pd.DataFrame(mat, index=[k.replace("_", " ") for k in present_rows], columns=stage_names)
    norm_df.plot(kind="bar", stacked=True, ax=ax, colormap="tab20")
    ax.set_ylabel("Normalized contribution")
    ax.set_title("Stage-contribution composition across recycling cases")
    ax.legend(frameon=False, fontsize=7, ncol=2, loc="upper right")
    plt.xticks(rotation=20, ha="right")
    return save_figure(fig, output_name)


def package_diagnostics() -> dict:
    comparison = compare_recycling_vs_mining()
    stage_summary = stage_contribution_summary()
    inv = inventory_summary()
    pair = case_pair_sensitivity()
    return {
        "comparison": comparison,
        "stage_summary": stage_summary,
        "inventory": inv,
        "case_pair_sensitivity": pair,
        "plotting_inputs": {
            "case_rows": len(comparison.get("cases", [])),
            "stage_rows": len(stage_summary),
        },
    }

#!/usr/bin/env python3
"""Lightweight local/remote resource helpers for paper task packages."""

from __future__ import annotations

from pathlib import Path
import subprocess
from urllib.request import urlopen


def read_text(path: str | Path) -> dict:
    path = Path(path)
    return {"path": str(path), "text": path.read_text(encoding="utf-8", errors="ignore")}


def reference_inventory(directory: str | Path) -> dict:
    base = Path(directory)
    files = []
    for path in sorted(base.glob("*")):
        if path.is_file():
            files.append(
                {
                    "name": path.name,
                    "suffix": path.suffix.lower(),
                    "size_bytes": int(path.stat().st_size),
                }
            )
    return {"base_dir": str(base), "files": files}


def fetch_url_head(url: str, max_bytes: int = 4096) -> dict:
    with urlopen(url) as response:
        data = response.read(max_bytes)
        return {
            "url": url,
            "status": getattr(response, "status", None),
            "content_type": response.headers.get("Content-Type"),
            "preview_bytes": len(data),
        }


def extract_pdf_text(path: str | Path) -> dict:
    path = Path(path)
    try:
        from pypdf import PdfReader

        reader = PdfReader(str(path))
        text = "\n".join(page.extract_text() or "" for page in reader.pages)
        return {"path": str(path), "backend": "pypdf", "text": text}
    except Exception as pypdf_error:
        result = subprocess.run(
            ["pdftotext", str(path), "-"],
            capture_output=True,
            text=True,
            check=False,
        )
        if result.returncode == 0:
            return {"path": str(path), "backend": "pdftotext", "text": result.stdout}
        return {
            "path": str(path),
            "backend": "unavailable",
            "text": "",
            "error": f"pypdf failed: {pypdf_error}; pdftotext failed: {result.stderr.strip()}",
        }


def find_pdf_lines(path: str | Path, patterns: list[str]) -> dict:
    text = extract_pdf_text(path)["text"]
    lines = text.splitlines()
    matches = []
    for i, line in enumerate(lines, start=1):
        lower_line = line.lower()
        for pattern in patterns:
            if pattern.lower() in lower_line:
                matches.append(
                    {
                        "line_number": i,
                        "pattern": pattern,
                        "line": line.strip(),
                    }
                )
                break
    return {"path": str(path), "patterns": patterns, "matches": matches}

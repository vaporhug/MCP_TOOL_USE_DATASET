This tools folder is organized into three layers.

- `energy_tools.py`: domain primitives for Ni-rich ASSB retention curves, Fig. 4b surface-reaction/isolation/detachment decomposition, Supplementary Fig. 19 pressure sensitivity, and artifact generation. The MOESM7 workbook labels the Supplementary Fig. 19 source sheets as `Fig. 6a`, `Fig. 6b`, `Fig. 6c`, and `Fig. 6d`; these are workbook sheet names, not main-article Fig. 6 panels.
- `data_processing.py`: generic table-reading and file-inventory helpers.
- `database_retrieval.py`: local reference/source inspection helpers.

Use the domain tool to reproduce the public degradation-analysis workflow from released source workbooks.

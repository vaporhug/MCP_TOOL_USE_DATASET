from __future__ import annotations
from pathlib import Path
import zipfile
import pandas as pd
import numpy as np

def package_root() -> Path:
    return Path(__file__).resolve().parents[1]

def data_root() -> Path:
    return package_root() / "input_data" / "data"

def list_files(root: str | Path | None = None) -> list[str]:
    root = Path(root) if root else data_root()
    return [str(p) for p in sorted(root.rglob("*")) if p.is_file()]

def archive_inventory(path: str | Path) -> list[str]:
    p = Path(path)
    if p.suffix.lower() != ".zip":
        return []
    with zipfile.ZipFile(p) as zf:
        return sorted(zf.namelist())

def read_table(path: str | Path, **kwargs) -> pd.DataFrame:
    p = Path(path)
    if p.suffix.lower() in [".xlsx", ".xls"]:
        return pd.read_excel(p, **kwargs)
    if p.suffix.lower() in [".tsv", ".tab"]:
        return pd.read_csv(p, sep="\t", on_bad_lines="skip", **kwargs)
    return pd.read_csv(p, on_bad_lines="skip", **kwargs)

def workbook_sheets(path: str | Path) -> list[str]:
    return pd.ExcelFile(path).sheet_names

def load_workbook_long(path: str | Path, max_sheets: int | None = None) -> pd.DataFrame:
    sheets = workbook_sheets(path)
    frames = []
    for sheet in sheets[:max_sheets]:
        try:
            df = pd.read_excel(path, sheet_name=sheet)
            df.insert(0, "source_sheet", sheet)
            frames.append(df)
        except Exception:
            continue
    return pd.concat(frames, ignore_index=True, sort=False) if frames else pd.DataFrame()

def numeric_columns(df: pd.DataFrame) -> list[str]:
    out=[]
    for c in df.columns:
        if pd.to_numeric(df[c], errors="coerce").notna().sum() > max(2, 0.1 * len(df)):
            out.append(c)
    return out

def tidy_numeric_frame(path: str | Path | None = None, sheet_name: str | int | None = 0) -> pd.DataFrame:
    files = list_files(data_root())
    if path is None:
        candidates=[f for f in files if Path(f).suffix.lower() in [".csv", ".tsv", ".txt", ".xlsx", ".xls"]]
        if not candidates:
            return pd.DataFrame()
        path=candidates[0]
    if str(path).lower().endswith((".xlsx", ".xls")):
        df = read_table(path, sheet_name=sheet_name)
    else:
        try:
            df = read_table(path)
        except Exception:
            df = pd.read_csv(path, sep=None, engine="python", on_bad_lines="skip")
    for c in df.columns:
        converted = pd.to_numeric(df[c], errors="coerce")
        if converted.notna().sum() > 0:
            df[c] = converted
    return df

def robust_zscore(values) -> np.ndarray:
    x=np.asarray(values, dtype=float)
    med=np.nanmedian(x); mad=np.nanmedian(np.abs(x-med))
    scale=1.4826*mad if mad and np.isfinite(mad) else np.nanstd(x)
    return (x-med)/(scale if scale else 1.0)

from __future__ import annotations
from pathlib import Path
import math
import io
import zipfile
import re
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from data_processing import data_root, list_files, read_table, workbook_sheets, numeric_columns, tidy_numeric_frame, robust_zscore, load_workbook_long
from database_retrieval import inventory, public_repository_links

ARTIFACT_DIR = Path(__file__).resolve().parents[1] / "artifacts"
ARTIFACT_DIR.mkdir(exist_ok=True)

def source_inventory(root: str | Path | None = None) -> dict:
    files = list_files(root or data_root())
    sizes = {str(Path(f).relative_to(Path(f).parents[2])) if len(Path(f).parents)>2 else f: Path(f).stat().st_size for f in files[:200]}
    return {"n_files": len(files), "extensions": sorted({Path(f).suffix.lower() for f in files}), "files": files[:200], "sizes": sizes, "repositories": public_repository_links().get("repositories", [])}

def source_workbook_summary(path: str | Path | None = None) -> dict:
    files = list_files(data_root())
    candidates=[f for f in files if Path(f).suffix.lower() in [".xlsx", ".xls"]]
    if path is None and not candidates:
        return {"n_workbooks": 0, "inventory": source_inventory()}
    path = path or candidates[0]
    rows=[]
    for sh in workbook_sheets(path)[:20]:
        try:
            df=read_table(path, sheet_name=sh)
            nums=numeric_columns(df)
            rows.append({"sheet": sh, "rows": int(len(df)), "columns": [str(c) for c in df.columns[:20]], "numeric_columns": [str(c) for c in nums[:20]]})
        except Exception as e:
            rows.append({"sheet": sh, "error": str(e)})
    return {"workbook": str(path), "sheets": rows}

def numeric_signal_summary(path: str | Path | None = None) -> dict:
    if path is None:
        df = pd.DataFrame()
        for candidate in list_files(data_root()):
            if Path(candidate).suffix.lower() not in [".csv", ".tsv", ".txt", ".dat", ".xlsx", ".xls"]:
                continue
            try:
                df = tidy_numeric_frame(candidate)
            except Exception:
                continue
            if not df.empty and numeric_columns(df):
                break
    else:
        df=tidy_numeric_frame(path)
    if df.empty:
        return {"note": "no tabular file found", "inventory": source_inventory()}
    nums=numeric_columns(df)
    stats={}
    for c in nums[:30]:
        s=pd.to_numeric(df[c], errors="coerce").dropna()
        if len(s):
            stats[str(c)]={"n": int(len(s)), "mean": float(s.mean()), "median": float(s.median()), "std": float(s.std(ddof=1)) if len(s)>1 else 0.0, "min": float(s.min()), "max": float(s.max())}
    return {"rows": int(len(df)), "columns": [str(c) for c in df.columns], "numeric_stats": stats}

def compare_numeric_groups(path: str | Path, group_col: str, value_col: str) -> dict:
    df=tidy_numeric_frame(path)
    df[value_col]=pd.to_numeric(df[value_col], errors="coerce")
    g=df.dropna(subset=[value_col]).groupby(group_col)[value_col]
    return {"groups": [{"group": str(k), "n": int(v.count()), "mean": float(v.mean()), "median": float(v.median()), "std": float(v.std(ddof=1)) if v.count()>1 else 0.0} for k,v in g]}

def bootstrap_difference(path: str | Path, group_col: str, value_col: str, group_a: str, group_b: str, n_boot: int = 2000, seed: int = 7) -> dict:
    df=tidy_numeric_frame(path)
    rng=np.random.default_rng(seed)
    a=pd.to_numeric(df.loc[df[group_col].astype(str)==str(group_a), value_col], errors="coerce").dropna().to_numpy()
    b=pd.to_numeric(df.loc[df[group_col].astype(str)==str(group_b), value_col], errors="coerce").dropna().to_numpy()
    if len(a)==0 or len(b)==0:
        return {"error": "empty group"}
    diffs=np.array([rng.choice(a, len(a), replace=True).mean()-rng.choice(b, len(b), replace=True).mean() for _ in range(n_boot)])
    return {"group_a": str(group_a), "group_b": str(group_b), "observed_mean_difference": float(a.mean()-b.mean()), "ci95": [float(np.quantile(diffs, .025)), float(np.quantile(diffs, .975))]}

def permutation_correlation(x, y, n_perm: int = 2000, seed: int = 7) -> dict:
    x=np.asarray(x, dtype=float); y=np.asarray(y, dtype=float)
    ok=np.isfinite(x)&np.isfinite(y); x=x[ok]; y=y[ok]
    if len(x)<3: return {"error":"not enough observations"}
    obs=float(np.corrcoef(x,y)[0,1])
    rng=np.random.default_rng(seed)
    null=np.array([np.corrcoef(x, rng.permutation(y))[0,1] for _ in range(n_perm)])
    p=float((np.sum(np.abs(null)>=abs(obs))+1)/(n_perm+1))
    return {"r": obs, "p_perm": p, "n": int(len(x))}

def plot_numeric_overview(output_filename: str = "numeric_overview.png") -> dict:
    summary=numeric_signal_summary(); stats=summary.get("numeric_stats", {})
    names=list(stats)[:10]; vals=[stats[n]["mean"] for n in names]
    if not names:
        names=["files"]; vals=[source_inventory()["n_files"]]
    out=ARTIFACT_DIR/output_filename
    fig, ax=plt.subplots(figsize=(8,4.8)); ax.bar(range(len(names)), vals, color="#4c78a8")
    ax.set_xticks(range(len(names))); ax.set_xticklabels(names, rotation=35, ha="right", fontsize=8)
    ax.set_ylabel("Mean value / count"); ax.set_title("Local public-data numeric overview")
    fig.tight_layout(); fig.savefig(out,dpi=180); plt.close(fig)
    return {"path": str(out), "plotted": names}

def plot_file_inventory(output_filename: str = "file_inventory.png") -> dict:
    inv=source_inventory(); counts={}
    for f in inv["files"]:
        ext=Path(f).suffix.lower() or "no_ext"; counts[ext]=counts.get(ext,0)+1
    out=ARTIFACT_DIR/output_filename
    fig, ax=plt.subplots(figsize=(6,4)); ax.bar(list(counts), list(counts.values()), color="#f58518")
    ax.set_title("Public workflow file inventory"); ax.set_ylabel("Files")
    fig.tight_layout(); fig.savefig(out,dpi=180); plt.close(fig)
    return {"path": str(out), "counts": counts}

def performance_window(path: str | Path | None = None, value_col: str | None = None, min_value: float | None = None, max_value: float | None = None) -> dict:
    df=tidy_numeric_frame(path); nums=numeric_columns(df)
    if not nums: return {"error":"no numeric columns"}
    col=value_col or nums[0]; s=pd.to_numeric(df[col], errors="coerce").dropna()
    mask=np.ones(len(s), dtype=bool)
    if min_value is not None: mask &= s.to_numpy()>=min_value
    if max_value is not None: mask &= s.to_numpy()<=max_value
    return {"column":str(col),"n_total":int(len(s)),"n_in_window":int(mask.sum()),"fraction_in_window":float(mask.mean()) if len(s) else 0.0,"min":float(s.min()),"max":float(s.max())}

def selectivity_or_efficiency_ratio(path: str | Path | None = None, numerator_col: str | None = None, denominator_col: str | None = None) -> dict:
    df=tidy_numeric_frame(path); nums=numeric_columns(df)
    if len(nums)<2: return {"error":"need two numeric columns"}
    a=numerator_col or nums[0]; b=denominator_col or nums[1]
    ratio=pd.to_numeric(df[a], errors="coerce")/pd.to_numeric(df[b], errors="coerce")
    ratio=ratio.replace([np.inf,-np.inf], np.nan).dropna()
    return {"numerator":str(a),"denominator":str(b),"n":int(len(ratio)),"median_ratio":float(ratio.median()),"max_ratio":float(ratio.max()),"min_ratio":float(ratio.min())}

def degradation_rate(path: str | Path | None = None, time_col: str | None = None, performance_col: str | None = None) -> dict:
    df=tidy_numeric_frame(path); nums=numeric_columns(df)
    if len(nums)<2: return {"error":"need time and performance columns"}
    t=time_col or nums[0]; y=performance_col or nums[1]
    x=pd.to_numeric(df[t], errors="coerce"); v=pd.to_numeric(df[y], errors="coerce")
    ok=x.notna()&v.notna()
    if ok.sum()<3: return {"error":"not enough data"}
    slope, intercept=np.polyfit(x[ok], v[ok], 1)
    return {"time_col":str(t),"performance_col":str(y),"slope_per_time":float(slope),"intercept":float(intercept),"n":int(ok.sum())}

def component_contribution(path: str | Path | None = None, component_col: str | None = None, value_col: str | None = None) -> dict:
    df=tidy_numeric_frame(path); nums=numeric_columns(df)
    cats=[c for c in df.columns if c not in nums]
    if not nums or not cats: return {"error":"need component and value columns"}
    c=component_col or cats[0]; v=value_col or nums[0]
    tmp=df[[c,v]].copy(); tmp[v]=pd.to_numeric(tmp[v], errors="coerce")
    g=tmp.dropna().groupby(c)[v].sum().sort_values(ascending=False)
    total=float(g.sum()) if len(g) else 0.0
    return {"component_col":str(c),"value_col":str(v),"total":total,"components":[{"component":str(k),"value":float(val),"fraction":float(val/total) if total else 0.0} for k,val in g.items()]}

def policy_scenario_coverage(manifest_path: str | Path | None = None) -> dict:
    p = Path(manifest_path) if manifest_path else (data_root() / "workflow_manifest.csv")
    if not p.exists():
        return {"error": f"missing {p}"}
    df = pd.read_csv(p)
    if "path" not in df.columns:
        return {"error": "workflow_manifest.csv missing path column"}
    names = df["path"].astype(str).str.lower()
    return {
        "n_assets": int(len(df)),
        "policy_assets": int(names.str.contains("policy|target|scenario|shock|uncertain").sum()),
        "coordination_assets": int(names.str.contains("coord|region|planning|batch").sum()),
        "solver_assets": int(names.str.contains("solver|optimiz|model").sum()),
    }

def coordination_outcome_summary(summary_path: str | Path | None = None) -> dict:
    p = Path(summary_path) if summary_path else (data_root() / "numeric_file_summary.csv")
    if not p.exists():
        return {"error": f"missing {p}"}
    df = pd.read_csv(p)
    if not {"n_numeric_tokens", "n_lines"}.issubset(df.columns):
        return {"error": "numeric_file_summary.csv missing n_numeric_tokens/n_lines"}
    tok = pd.to_numeric(df["n_numeric_tokens"], errors="coerce").fillna(0)
    ln = pd.to_numeric(df["n_lines"], errors="coerce").fillna(0)
    density = (tok / ln.replace(0, np.nan)).replace([np.inf, -np.inf], np.nan).dropna()
    return {
        "n_files_profiled": int(len(df)),
        "median_numeric_density": float(density.median()) if len(density) else None,
        "max_numeric_density": float(density.max()) if len(density) else None,
    }

def policy_workflow_link_coverage(catalog_path: str | Path | None = None) -> dict:
    p = Path(catalog_path) if catalog_path else (data_root() / "workflow_links_catalog.csv")
    if not p.exists():
        return {"error": f"missing {p}"}
    df = pd.read_csv(p)
    txt = df.astype(str).apply(lambda r: " ".join(r.values), axis=1).str.lower()
    return {
        "n_links": int(len(df)),
        "has_scenario_or_policy_links": int(txt.str.contains("scenario|policy|roadmap|target").sum()),
        "has_code_links": int(txt.str.contains("github|repo|code").sum()),
        "has_data_links": int(txt.str.contains("zenodo|dataset|data").sum()),
    }

def _open_primary_coordination_zip() -> zipfile.ZipFile:
    p = data_root() / "github_repo_5.zip"
    if not p.exists():
        raise FileNotFoundError(f"missing {p}")
    return zipfile.ZipFile(p)

def coordination_batch_design_matrix() -> dict:
    with _open_primary_coordination_zip() as zf:
        sh = [n for n in zf.namelist() if n.endswith(".sh") and "Batch/" in n]
    ces_levels = set()
    planning_modes = set()
    reliability_modes = set()
    for n in sh:
        bn = Path(n).name.lower()
        m = re.search(r"([0-9]+)ces", bn)
        if m:
            ces_levels.add(int(m.group(1)))
        if "limited_coordination" in bn:
            planning_modes.add("limited_coordination")
        elif "regionalces" in bn:
            planning_modes.add("regional_ces")
        elif "pstate" in bn:
            planning_modes.add("state_level")
        if "rbaseline" in bn:
            reliability_modes.add("baseline")
        if "rexpandedeim" in bn:
            reliability_modes.add("expanded_eim")
        if "rregionalized" in bn:
            reliability_modes.add("regionalized")
    return {
        "n_batch_scripts": int(len(sh)),
        "ces_levels": sorted(ces_levels),
        "planning_modes": sorted(planning_modes),
        "reliability_modes": sorted(reliability_modes),
    }

def solver_parameter_surface() -> dict:
    with _open_primary_coordination_zip() as zf:
        target = [n for n in zf.namelist() if n.lower().endswith("solver_params.csv")]
        if not target:
            return {"error": "solver_params.csv not found in repo zip"}
        df = pd.read_csv(io.BytesIO(zf.read(target[0])))
    numeric = [c for c in df.columns if pd.to_numeric(df[c], errors="coerce").notna().sum() > 0]
    out = {}
    for c in numeric:
        s = pd.to_numeric(df[c], errors="coerce").dropna()
        out[str(c)] = {
            "n": int(len(s)),
            "min": float(s.min()),
            "median": float(s.median()),
            "max": float(s.max()),
        }
    return {"rows": int(len(df)), "numeric_parameter_summary": out}

def secondary_repo_pointer() -> dict:
    p = data_root() / "github_repo_6.zip"
    if not p.exists():
        return {"error": f"missing {p}"}
    txt = p.read_text(errors="ignore").strip()
    return {
        "has_github_pointer": bool("github.com" in txt.lower()),
        "pointer_text": txt[:300],
    }




def _safe_call(fn):
    try:
        return fn()
    except TypeError:
        return {"note": "call requires explicit args"}
    except Exception as e:
        return {"error": str(e)}


def package_smoke_test() -> dict:
    return {
        "workflow_checks": {
            "coordination_batch_design_matrix": _safe_call(coordination_batch_design_matrix),
            "solver_parameter_surface": _safe_call(solver_parameter_surface),
            "secondary_repo_pointer": _safe_call(secondary_repo_pointer),
        }
    }

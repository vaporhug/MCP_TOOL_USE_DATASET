from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

try:
    from .data_processing import data_root, list_files, read_table
    from .database_retrieval import public_repository_links
except ImportError:
    from data_processing import data_root, list_files, read_table
    from database_retrieval import public_repository_links


ARTIFACT_DIR = Path(__file__).resolve().parents[1] / "artifacts"
ARTIFACT_DIR.mkdir(exist_ok=True)


def source_inventory() -> dict:
    files = list_files(data_root())
    return {
        "n_files": len(files),
        "extensions": sorted({Path(f).suffix.lower() for f in files}),
        "repositories": public_repository_links().get("repositories", []),
    }


def _workbook() -> Path:
    xlsx = [Path(f) for f in list_files(data_root()) if Path(f).suffix.lower() == ".xlsx"]
    if not xlsx:
        raise FileNotFoundError("missing matching-interval workbook")
    return xlsx[0]


def workbook_sheet_manifest() -> dict:
    wb = _workbook()
    xl = pd.ExcelFile(wb)
    shapes = []
    for sh in xl.sheet_names:
        df = pd.read_excel(wb, sheet_name=sh)
        shapes.append({"sheet": sh, "shape": [int(df.shape[0]), int(df.shape[1])]})
    return {"workbook": wb.name, "n_sheets": len(shapes), "sheets": shapes}


def figure1_matching_coverage_summary() -> dict:
    df = read_table(_workbook(), sheet_name="Figure 1")
    year_cols = [c for c in df.columns if isinstance(c, (int, float))]

    interval = None
    rows = []
    for _, r in df.iterrows():
        label = r.iloc[0]
        if isinstance(label, str) and "matching" in label.lower():
            interval = label.replace(" Matching", "").strip()
            continue
        if interval is None:
            continue
        if not isinstance(label, str) or label.strip() not in {"Covered", "Uncovered"}:
            continue

        vals = pd.to_numeric(r[year_cols], errors="coerce")
        rows.append(
            {
                "interval": interval,
                "status": label.strip(),
                "mean_share": float(vals.mean()),
                "min_share": float(vals.min()),
                "max_share": float(vals.max()),
            }
        )

    return {"figure": "Figure 1", "coverage_rows": rows}


def figure2_hourly_shortage_distribution_summary() -> dict:
    df = read_table(_workbook(), sheet_name="Figure 2")
    hour_cols = [c for c in df.columns if isinstance(c, (int, float))]
    df["Unnamed: 0"] = pd.to_numeric(df["Unnamed: 0"], errors="coerce")
    usable = df.dropna(subset=["Unnamed: 0"])

    rows = []
    for _, r in usable.iterrows():
        vals = pd.to_numeric(r[hour_cols], errors="coerce").dropna().to_numpy(dtype=float)
        if vals.size == 0:
            continue
        rows.append(
            {
                "year": int(r["Unnamed: 0"]),
                "mean_hourly_shortage_share": float(np.mean(vals)),
                "peak_hourly_shortage_share": float(np.max(vals)),
                "low_hourly_shortage_share": float(np.min(vals)),
            }
        )

    global_mean = float(np.mean([r["mean_hourly_shortage_share"] for r in rows])) if rows else None
    return {
        "figure": "Figure 2",
        "yearly_profiles": rows,
        "overall_mean_hourly_shortage_share": global_mean,
    }


def figure3_matching_induced_generation_shift() -> dict:
    df = read_table(_workbook(), sheet_name="Figure 3")
    order = {"Quarterly": 0, "Monthly": 1, "Weekly": 2, "Daily": 3, "Hourly": 4}
    out = []
    for _, r in df.iterrows():
        mode = str(r.iloc[0]).strip()
        solar = pd.to_numeric(pd.Series([r["PercentageIncreaseSolar"]]), errors="coerce").iloc[0]
        wind = pd.to_numeric(pd.Series([r["PercentageIncreaseWind"]]), errors="coerce").iloc[0]
        if pd.isna(solar) or pd.isna(wind):
            continue
        out.append(
            {
                "matching_mode": mode,
                "solar_increase_pct": float(solar),
                "wind_increase_pct": float(wind),
                "solar_minus_wind": float(solar - wind),
                "solar_to_wind_ratio": float(solar / wind) if wind else None,
                "strictness_rank": int(order.get(mode, 99)),
            }
        )
    out = sorted(out, key=lambda x: x["strictness_rank"])
    hourly = next((r for r in out if r["matching_mode"] == "Hourly"), None)
    return {
        "figure": "Figure 3",
        "mode_level_increase": out,
        "hourly_solar_increase_pct": hourly["solar_increase_pct"] if hourly else None,
        "hourly_wind_increase_pct": hourly["wind_increase_pct"] if hourly else None,
        "hourly_solar_to_wind_ratio": hourly["solar_to_wind_ratio"] if hourly else None,
    }


def supplementary_table1_uncovered_time_summary() -> dict:
    df = read_table(_workbook(), sheet_name="Supplementary Table 1")
    cols = ["Quarterly", "Monthly", "Weekly", "Daily", "Hourly"]
    for c in cols + ["Year"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df.dropna(subset=["Year"])

    trend = []
    for c in cols:
        vals = df[c].dropna().to_numpy(dtype=float)
        trend.append({
            "interval": c,
            "mean_uncovered": float(np.mean(vals)),
            "max_uncovered": float(np.max(vals)),
        })

    return {"table": "Supplementary Table 1", "interval_uncovered_stats": trend}


def table1_country_balance_summary() -> dict:
    df = read_table(_workbook(), sheet_name="Table 1")
    g = pd.to_numeric(df["Generation"].replace("/", np.nan), errors="coerce")
    c = pd.to_numeric(df["Consumption"].replace("/", np.nan), errors="coerce")

    paired = pd.DataFrame({"country": df["Unnamed: 0"].fillna(df["Unnamed: 1"]), "generation": g, "consumption": c}).dropna(subset=["generation", "consumption"], how="all")
    paired["balance_generation_minus_consumption"] = paired["generation"].fillna(0) - paired["consumption"].fillna(0)

    return {
        "table": "Table 1",
        "rows": [
            {
                "country_or_group": str(r["country"]),
                "generation": float(r["generation"]) if pd.notna(r["generation"]) else None,
                "consumption": float(r["consumption"]) if pd.notna(r["consumption"]) else None,
                "generation_minus_consumption": float(r["balance_generation_minus_consumption"]),
            }
            for _, r in paired.iterrows()
        ],
    }


def plot_fig1_uncovered_heatmap(output_filename: str = "energy_6b3e_fig1_uncovered_heatmap.png") -> dict:
    df = read_table(_workbook(), sheet_name="Figure 1")
    year_cols = [c for c in df.columns if isinstance(c, (int, float))]

    interval = None
    table = {}
    for _, r in df.iterrows():
        label = r.iloc[0]
        if isinstance(label, str) and "matching" in label.lower():
            interval = label.replace(" Matching", "").strip()
            continue
        if interval is None:
            continue
        if isinstance(label, str) and label.strip() == "Uncovered":
            vals = pd.to_numeric(r[year_cols], errors="coerce").to_numpy(dtype=float)
            table[interval] = vals

    intervals = list(table.keys())
    arr = np.vstack([table[i] for i in intervals]) if intervals else np.empty((0, 0))

    fig, ax = plt.subplots(figsize=(8.2, 4.8))
    im = ax.imshow(arr, aspect="auto", cmap="magma")
    ax.set_yticks(range(len(intervals)))
    ax.set_yticklabels(intervals)
    ax.set_xticks(range(len(year_cols)))
    ax.set_xticklabels([str(int(y)) for y in year_cols], rotation=45)
    ax.set_xlabel("Year")
    ax.set_title("Figure 1 uncovered-share heatmap by matching interval")
    cbar = fig.colorbar(im, ax=ax)
    cbar.set_label("Uncovered share")

    out = ARTIFACT_DIR / output_filename
    fig.tight_layout()
    fig.savefig(out, dpi=220)
    plt.close(fig)
    return {"path": str(out)}


def plot_fig2_hourly_profiles(output_filename: str = "energy_6b3e_fig2_hourly_profiles.png") -> dict:
    df = read_table(_workbook(), sheet_name="Figure 2")
    hour_cols = [c for c in df.columns if isinstance(c, (int, float))]
    df["Unnamed: 0"] = pd.to_numeric(df["Unnamed: 0"], errors="coerce")
    usable = df.dropna(subset=["Unnamed: 0"])

    fig, ax = plt.subplots(figsize=(9.0, 4.8))
    for _, r in usable.iterrows():
        y = pd.to_numeric(r[hour_cols], errors="coerce").to_numpy(dtype=float)
        ax.plot(hour_cols, y, linewidth=1.8, label=str(int(r["Unnamed: 0"])))

    ax.set_xlabel("Hour of day")
    ax.set_ylabel("Shortage share")
    ax.set_title("Figure 2 hourly shortage-share profiles by year")
    ax.grid(alpha=0.25)
    ax.legend(title="Year", ncol=3, frameon=False)

    out = ARTIFACT_DIR / output_filename
    fig.tight_layout()
    fig.savefig(out, dpi=220)
    plt.close(fig)
    return {"path": str(out)}


def plot_fig3_solar_wind_increase(output_filename: str = "energy_6b3e_fig3_solar_wind_increase.png") -> dict:
    rows = figure3_matching_induced_generation_shift()["mode_level_increase"]
    modes = [r["matching_mode"] for r in rows]
    solar = np.array([r["solar_increase_pct"] for r in rows], dtype=float)
    wind = np.array([r["wind_increase_pct"] for r in rows], dtype=float)

    x = np.arange(len(modes))
    fig, ax = plt.subplots(figsize=(8.2, 4.9))
    ax.plot(x, solar, marker="o", linewidth=2, label="Solar increase (%)")
    ax.plot(x, wind, marker="s", linewidth=2, label="Wind increase (%)")
    ax.set_xticks(x)
    ax.set_xticklabels(modes, rotation=25)
    ax.set_yscale("log")
    ax.set_ylabel("Percentage increase (log scale)")
    ax.set_title("Figure 3 source-data matching-mode scale-up tradeoff")
    ax.grid(axis="y", alpha=0.25, which="both")
    if "Hourly" in modes:
        i = modes.index("Hourly")
        ax.annotate("Hourly solar extreme", (x[i], solar[i]), textcoords="offset points", xytext=(8, 6), fontsize=8)
    ax.legend(frameon=False)

    out = ARTIFACT_DIR / output_filename
    fig.tight_layout()
    fig.savefig(out, dpi=220)
    plt.close(fig)
    return {"path": str(out)}


def package_smoke_test() -> dict:
    return {
        "source_inventory": source_inventory(),
        "workbook_sheet_manifest": workbook_sheet_manifest(),
        "figure1_matching_coverage_summary": figure1_matching_coverage_summary(),
        "figure2_hourly_shortage_distribution_summary": figure2_hourly_shortage_distribution_summary(),
        "figure3_matching_induced_generation_shift": figure3_matching_induced_generation_shift(),
        "supplementary_table1_uncovered_time_summary": supplementary_table1_uncovered_time_summary(),
        "table1_country_balance_summary": table1_country_balance_summary(),
    }

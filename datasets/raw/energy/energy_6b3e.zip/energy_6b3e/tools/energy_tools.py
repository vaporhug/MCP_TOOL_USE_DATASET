from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

try:
    from .data_processing import data_root, list_files, read_table
    from .database_retrieval import public_repository_links
except ImportError:
    from data_processing import data_root, list_files, read_table
    from database_retrieval import public_repository_links


ARTIFACT_DIR = Path(__file__).resolve().parents[1] / "artifacts"
ARTIFACT_DIR.mkdir(exist_ok=True)


def _resolve_output_path(output_filename: str | None, generic_name: str) -> Path:
    filename = output_filename if output_filename else generic_name
    return ARTIFACT_DIR / filename


def source_inventory() -> dict:
    files = list_files(data_root())
    return {
        "n_files": len(files),
        "extensions": sorted({Path(f).suffix.lower() for f in files}),
        "repositories": public_repository_links().get("repositories", []),
    }


def _workbook() -> Path:
    xlsx = [Path(f) for f in list_files(data_root()) if Path(f).suffix.lower() == ".xlsx"]
    if not xlsx:
        raise FileNotFoundError("missing matching-interval workbook")
    return xlsx[0]


def workbook_sheet_manifest() -> dict:
    wb = _workbook()
    xl = pd.ExcelFile(wb)
    shapes = []
    for sh in xl.sheet_names:
        df = pd.read_excel(wb, sheet_name=sh)
        shapes.append({"sheet": sh, "shape": [int(df.shape[0]), int(df.shape[1])]})
    return {"workbook": wb.name, "n_sheets": len(shapes), "sheets": shapes}


def _plot_heatmap(
    matrix: np.ndarray,
    x_labels: list[str],
    y_labels: list[str],
    xlabel: str,
    ylabel: str,
    title: str,
    cbar_label: str,
    output_filename: str | None,
    generic_name: str,
) -> dict:
    arr = np.asarray(matrix, dtype=float)
    fig, ax = plt.subplots(figsize=(8.2, 4.8))
    im = ax.imshow(arr, aspect="auto", cmap="magma")
    ax.set_yticks(range(len(y_labels)))
    ax.set_yticklabels(y_labels)
    ax.set_xticks(range(len(x_labels)))
    ax.set_xticklabels(x_labels, rotation=45)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    cbar = fig.colorbar(im, ax=ax)
    cbar.set_label(cbar_label)
    out = _resolve_output_path(output_filename, generic_name)
    fig.tight_layout()
    fig.savefig(out, dpi=220)
    plt.close(fig)
    return {"path": str(out)}


def _plot_line_tidy(
    df: pd.DataFrame,
    x_col: str,
    series_col: str,
    y_col: str,
    xlabel: str,
    ylabel: str,
    title: str,
    output_filename: str | None,
    generic_name: str,
    y_log: bool = False,
) -> dict:
    fig, ax = plt.subplots(figsize=(8.4, 4.8))
    for series_name, sub in df.groupby(series_col):
        tmp = sub[[x_col, y_col]].dropna()
        if np.issubdtype(tmp[x_col].dtype, np.number):
            tmp = tmp.sort_values(x_col)
        if tmp.empty:
            continue
        ax.plot(tmp[x_col], tmp[y_col], marker="o", linewidth=1.8, label=str(series_name))
    if y_log:
        ax.set_yscale("log")
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.grid(axis="y", alpha=0.25, which="both")
    ax.legend(frameon=False)
    out = _resolve_output_path(output_filename, generic_name)
    fig.tight_layout()
    fig.savefig(out, dpi=220)
    plt.close(fig)
    return {"path": str(out)}


def figure1_uncovered_share_grid() -> dict:
    """Extract Figure 1 uncovered interval-share values (fraction units)."""
    df = read_table(_workbook(), sheet_name="Figure 1")
    year_cols = [c for c in df.columns if isinstance(c, (int, float))]

    interval = None
    table = {}
    for _, r in df.iterrows():
        label = r.iloc[0]
        if isinstance(label, str) and "matching" in label.lower():
            interval = label.replace(" Matching", "").strip()
            continue
        if interval is None:
            continue
        if isinstance(label, str) and label.strip() == "Uncovered":
            vals = pd.to_numeric(r[year_cols], errors="coerce").to_numpy(dtype=float)
            table[interval] = vals

    intervals = list(table.keys())
    arr = np.vstack([table[i] for i in intervals]) if intervals else np.empty((0, 0))
    years = [int(y) for y in year_cols]
    return {
        "metric_kind": "share_fraction",
        "metric_description": "Figure 1 uncovered interval shares by matching interval and year.",
        "intervals": intervals,
        "years": years,
        "matrix": arr,
    }


def figure1_uncovered_share_tidy_table() -> pd.DataFrame:
    grid = figure1_uncovered_share_grid()
    intervals = list(grid["intervals"])
    years = list(grid["years"])
    arr = np.asarray(grid["matrix"], dtype=float)
    rows = []
    for i, interval in enumerate(intervals):
        for j, year in enumerate(years):
            rows.append(
                {
                    "interval": str(interval),
                    "year": int(year),
                    "uncovered_share": float(arr[i, j]),
                }
            )
    return pd.DataFrame(rows)


def figure2_hourly_shortage_share_grid() -> dict:
    """Extract Figure 2 hourly shortage-share traces (fraction units)."""
    df = read_table(_workbook(), sheet_name="Figure 2")
    hour_cols = [c for c in df.columns if isinstance(c, (int, float))]
    df["Unnamed: 0"] = pd.to_numeric(df["Unnamed: 0"], errors="coerce")
    usable = df.dropna(subset=["Unnamed: 0"]).copy()
    usable["year"] = usable["Unnamed: 0"].astype(int)

    rows = []
    years = []
    for _, r in usable.iterrows():
        vals = pd.to_numeric(r[hour_cols], errors="coerce").to_numpy(dtype=float)
        rows.append(vals)
        years.append(int(r["year"]))

    arr = np.vstack(rows) if rows else np.empty((0, 0))
    hours = [int(h) for h in hour_cols]
    return {
        "metric_kind": "share_fraction",
        "metric_description": "Figure 2 hourly shortage shares by year.",
        "years": years,
        "hours": hours,
        "matrix": arr,
    }


def figure2_hourly_shortage_share_tidy_table() -> pd.DataFrame:
    grid = figure2_hourly_shortage_share_grid()
    years = list(grid["years"])
    hours = list(grid["hours"])
    arr = np.asarray(grid["matrix"], dtype=float)
    rows = []
    for i, year in enumerate(years):
        for j, hour in enumerate(hours):
            rows.append(
                {
                    "year": int(year),
                    "hour": int(hour),
                    "shortage_share": float(arr[i, j]),
                }
            )
    return pd.DataFrame(rows)


def supplementary_table1_uncovered_volume_grid() -> dict:
    """Extract Supplementary Table 1 uncovered-demand volumes (table-reported units)."""
    df = read_table(_workbook(), sheet_name="Supplementary Table 1")
    cols = ["Quarterly", "Monthly", "Weekly", "Daily", "Hourly"]
    for c in cols + ["Year"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df.dropna(subset=["Year"]).copy()

    years = df["Year"].astype(int).tolist()
    matrix = df[cols].to_numpy(dtype=float)
    return {
        "metric_kind": "volumetric_uncovered_demand",
        "metric_units": "table_reported_units",
        "metric_description": "Supplementary Table 1 uncovered-demand volumes by year and matching interval.",
        "years": years,
        "intervals": cols,
        "matrix": matrix,
    }


def supplementary_table1_uncovered_volume_tidy_table() -> pd.DataFrame:
    grid = supplementary_table1_uncovered_volume_grid()
    years = list(grid["years"])
    intervals = list(grid["intervals"])
    arr = np.asarray(grid["matrix"], dtype=float)
    rows = []
    for i, year in enumerate(years):
        for j, interval in enumerate(intervals):
            rows.append(
                {
                    "year": int(year),
                    "interval": str(interval),
                    "uncovered_volume": float(arr[i, j]),
                    "metric_units": str(grid["metric_units"]),
                }
            )
    return pd.DataFrame(rows)


def figure1_matching_coverage_summary() -> dict:
    df = read_table(_workbook(), sheet_name="Figure 1")
    year_cols = [c for c in df.columns if isinstance(c, (int, float))]

    interval = None
    rows = []
    for _, r in df.iterrows():
        label = r.iloc[0]
        if isinstance(label, str) and "matching" in label.lower():
            interval = label.replace(" Matching", "").strip()
            continue
        if interval is None:
            continue
        if not isinstance(label, str) or label.strip() not in {"Covered", "Uncovered"}:
            continue

        vals = pd.to_numeric(r[year_cols], errors="coerce")
        rows.append(
            {
                "interval": interval,
                "status": label.strip(),
                "mean_share": float(vals.mean()),
                "min_share": float(vals.min()),
                "max_share": float(vals.max()),
            }
        )

    return {
        "figure": "Figure 1",
        "metric_kind": "share_fraction",
        "coverage_rows": rows,
    }


def figure2_hourly_shortage_distribution_summary() -> dict:
    grid = figure2_hourly_shortage_share_grid()
    years = grid["years"]
    arr = grid["matrix"]

    rows = []
    for i, year in enumerate(years):
        vals = np.asarray(arr[i], dtype=float)
        vals = vals[np.isfinite(vals)]
        if vals.size == 0:
            continue
        rows.append(
            {
                "year": int(year),
                "mean_hourly_shortage_share": float(np.mean(vals)),
                "peak_hourly_shortage_share": float(np.max(vals)),
                "low_hourly_shortage_share": float(np.min(vals)),
            }
        )

    global_mean = float(np.mean([r["mean_hourly_shortage_share"] for r in rows])) if rows else None
    return {
        "figure": "Figure 2",
        "metric_kind": "share_fraction",
        "yearly_profiles": rows,
        "overall_mean_hourly_shortage_share": global_mean,
    }


def figure3_matching_induced_generation_shift() -> dict:
    df = read_table(_workbook(), sheet_name="Figure 3")
    order = {"Quarterly": 0, "Monthly": 1, "Weekly": 2, "Daily": 3, "Hourly": 4}
    out = []
    for _, r in df.iterrows():
        mode = str(r.iloc[0]).strip()
        solar = pd.to_numeric(pd.Series([r["PercentageIncreaseSolar"]]), errors="coerce").iloc[0]
        wind = pd.to_numeric(pd.Series([r["PercentageIncreaseWind"]]), errors="coerce").iloc[0]
        if pd.isna(solar) or pd.isna(wind):
            continue
        out.append(
            {
                "matching_mode": mode,
                "solar_increase_pct": float(solar),
                "wind_increase_pct": float(wind),
                "solar_minus_wind": float(solar - wind),
                "solar_to_wind_ratio": float(solar / wind) if wind else None,
                "strictness_rank": int(order.get(mode, 99)),
            }
        )
    out = sorted(out, key=lambda x: x["strictness_rank"])
    hourly = next((r for r in out if r["matching_mode"] == "Hourly"), None)
    return {
        "figure": "Figure 3",
        "mode_level_increase": out,
        "hourly_solar_increase_pct": hourly["solar_increase_pct"] if hourly else None,
        "hourly_wind_increase_pct": hourly["wind_increase_pct"] if hourly else None,
        "hourly_solar_to_wind_ratio": hourly["solar_to_wind_ratio"] if hourly else None,
    }


def figure3_generation_increase_tidy_table() -> pd.DataFrame:
    rows = figure3_matching_induced_generation_shift().get("mode_level_increase", [])
    return pd.DataFrame(rows)


def supplementary_table1_uncovered_time_summary() -> dict:
    grid = supplementary_table1_uncovered_volume_grid()
    years = grid["years"]
    intervals = grid["intervals"]
    arr = np.asarray(grid["matrix"], dtype=float)

    trend = []
    for j, c in enumerate(intervals):
        vals = arr[:, j]
        vals = vals[np.isfinite(vals)]
        trend.append({
            "interval": c,
            "mean_uncovered_volume": float(np.mean(vals)) if vals.size else None,
            "max_uncovered_volume": float(np.max(vals)) if vals.size else None,
        })

    return {
        "table": "Supplementary Table 1",
        "metric_kind": "volumetric_uncovered_demand",
        "metric_units": "table_reported_units",
        "years": years,
        "interval_uncovered_stats": trend,
    }


def table1_country_balance_summary() -> dict:
    df = read_table(_workbook(), sheet_name="Table 1")
    g = pd.to_numeric(df["Generation"].replace("/", np.nan), errors="coerce")
    c = pd.to_numeric(df["Consumption"].replace("/", np.nan), errors="coerce")

    paired = pd.DataFrame({"country": df["Unnamed: 0"].fillna(df["Unnamed: 1"]), "generation": g, "consumption": c}).dropna(subset=["generation", "consumption"], how="all")
    paired["balance_generation_minus_consumption"] = paired["generation"].fillna(0) - paired["consumption"].fillna(0)

    return {
        "table": "Table 1",
        "rows": [
            {
                "country_or_group": str(r["country"]),
                "generation": float(r["generation"]) if pd.notna(r["generation"]) else None,
                "consumption": float(r["consumption"]) if pd.notna(r["consumption"]) else None,
                "generation_minus_consumption": float(r["balance_generation_minus_consumption"]),
            }
            for _, r in paired.iterrows()
        ],
    }


def plot_fig1_uncovered_heatmap(output_filename: str | None = None) -> dict:
    grid = figure1_uncovered_share_grid()
    intervals = grid["intervals"]
    years = grid["years"]
    arr = np.asarray(grid["matrix"], dtype=float)
    return _plot_heatmap(
        matrix=arr,
        x_labels=[str(y) for y in years],
        y_labels=[str(i) for i in intervals],
        xlabel="Year",
        ylabel="Matching interval",
        title="Figure 1 uncovered-share heatmap by matching interval (share metric)",
        cbar_label="Uncovered share",
        output_filename=output_filename,
        generic_name="energy_6b3e_fig1_uncovered_heatmap.png",
    )


def plot_fig2_hourly_profiles(output_filename: str | None = None) -> dict:
    tidy = figure2_hourly_shortage_share_tidy_table()
    return _plot_line_tidy(
        df=tidy,
        x_col="hour",
        series_col="year",
        y_col="shortage_share",
        xlabel="Hour of day",
        ylabel="Shortage share",
        title="Figure 2 hourly shortage-share profiles by year",
        output_filename=output_filename,
        generic_name="energy_6b3e_fig2_hourly_profiles.png",
    )


def plot_fig3_solar_wind_increase(output_filename: str | None = None) -> dict:
    tidy = figure3_generation_increase_tidy_table()
    core = tidy.dropna(subset=["solar_increase_pct", "wind_increase_pct"]).copy()
    if core.empty:
        raise ValueError("Figure 3 generation-increase table is empty")
    core = core.sort_values("strictness_rank")

    fig, ax = plt.subplots(figsize=(8.0, 5.0))
    ax.plot(core["wind_increase_pct"], core["solar_increase_pct"], marker="o", linewidth=2.0)
    for _, r in core.iterrows():
        ax.annotate(
            str(r["matching_mode"]),
            (float(r["wind_increase_pct"]), float(r["solar_increase_pct"])),
            textcoords="offset points",
            xytext=(5, 4),
            fontsize=8,
        )

    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlabel("Wind increase (%)")
    ax.set_ylabel("Solar increase (%)")
    ax.set_title("Figure 3 solar-vs-wind scale-up tradeoff curve")
    ax.grid(alpha=0.25, which="both")

    out = _resolve_output_path(output_filename, "energy_6b3e_fig3_solar_wind_increase.png")
    fig.tight_layout()
    fig.savefig(out, dpi=220)
    plt.close(fig)
    return {"path": str(out)}

def package_smoke_test() -> dict:
    manifest = workbook_sheet_manifest()
    sheet_names = [str(s["sheet"]) for s in manifest.get("sheets", [])]
    fig1_grid = figure1_uncovered_share_grid()
    fig2_grid = figure2_hourly_shortage_share_grid()
    supp_grid = supplementary_table1_uncovered_volume_grid()
    fig1_tidy = figure1_uncovered_share_tidy_table()
    fig2_tidy = figure2_hourly_shortage_share_tidy_table()
    supp_tidy = supplementary_table1_uncovered_volume_tidy_table()
    fig3_tidy = figure3_generation_increase_tidy_table()
    return {
        "source_inventory": source_inventory(),
        "workbook_sheet_manifest": manifest,
        "sheet_presence": {
            "Figure 1": "Figure 1" in sheet_names,
            "Figure 2": "Figure 2" in sheet_names,
            "Figure 3": "Figure 3" in sheet_names,
            "Supplementary Table 1": "Supplementary Table 1" in sheet_names,
        },
        "metric_disambiguation": {
            "figure1_metric_kind": fig1_grid["metric_kind"],
            "figure2_metric_kind": fig2_grid["metric_kind"],
            "supplementary_table1_metric_kind": supp_grid["metric_kind"],
            "supplementary_table1_metric_units": supp_grid["metric_units"],
        },
        "shape_checks": {
            "figure1_grid_shape": list(np.asarray(fig1_grid["matrix"]).shape),
            "figure2_grid_shape": list(np.asarray(fig2_grid["matrix"]).shape),
            "supplementary_table1_grid_shape": list(np.asarray(supp_grid["matrix"]).shape),
        },
        "tidy_table_shapes": {
            "figure1_uncovered_share_tidy_table": [int(fig1_tidy.shape[0]), int(fig1_tidy.shape[1])],
            "figure2_hourly_shortage_share_tidy_table": [int(fig2_tidy.shape[0]), int(fig2_tidy.shape[1])],
            "supplementary_table1_uncovered_volume_tidy_table": [int(supp_tidy.shape[0]), int(supp_tidy.shape[1])],
            "figure3_generation_increase_tidy_table": [int(fig3_tidy.shape[0]), int(fig3_tidy.shape[1])],
        },
        "figure2_year_count": int(len(figure2_hourly_shortage_distribution_summary().get("yearly_profiles", []))),
        "figure3_mode_count": int(len(figure3_matching_induced_generation_shift().get("mode_level_increase", []))),
    }

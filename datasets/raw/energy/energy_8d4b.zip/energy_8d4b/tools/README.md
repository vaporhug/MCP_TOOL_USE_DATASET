This tool directory is split into three layers:

- `data_processing.py`: generic local file helpers
- `database_retrieval.py`: local reference/code inventory and lightweight PDF text lookup
- `energy_tools.py`: core techno-economic primitives for the released green-shipping workflow

The core tool file exposes reusable methods for:

- route-level electrification summaries
- route-level carbon-emission reduction comparisons
- grace-period economic sensitivity
- cost-rating extraction
- artifact-generating plotting helpers

import matplotlib.pyplot as plt
import numpy as np


plt.rcParams["font.sans-serif"] = "Arial"

values_right_space = [89.08, 75.78, 58.64, 91.93, 97.96, 97.93, 79.41]
values_right=[100 - x for x in values_right_space]

values_left_OCP_space = [94.89, 93.63, 68.36, 96.48, 98.81, 98.59, 88.71]
values_right_2 = [100 - y for y in values_left_OCP_space]
print(values_right_space)
print(values_right)
print(values_left_OCP_space)
print(values_right_2)
values_2 = np.zeros(len(values_right))
values_3 = np.zeros(len(values_right))
for i in range(len(values_right)):
    values_2[i] = 100 - values_right[i]
    values_3[i] = 100 - values_right_2[i]

fig, ax = plt.subplots()
point = [ 30.5, 25.5, 20.5, 15.5,10.5, 5.5, 0.5]
custom_yticks = [0, 3, 6, 9, 12, 15, 18]
point1 = np.zeros(len(point))
height=1.5
for i in range(len(point)):
    point1[i] = point[i] + height
    custom_yticks[i]=point[i] + height/2
DWT=[10,20,30,40,50,70,100,110]
TEU=[1000,1700,2300,2800,4300,5600,8500,9500]
SPACE=[1530,2140,2400,2490,6250,11110,11540,10520]

fig.set_size_inches(16, 24)


ax.barh(point, values_right_2, height=height, color='#4169e1', label='Battery Space Ratio with OCS', edgecolor='black',hatch='')
ax.barh(point, values_3, height=height, color='#6495ed', label='Cargo Space Ratio with OCS', left=values_right_2, edgecolor='black',hatch='')
ax.barh(point1, values_right, height=height, color='#b0c4de', label='Battery Space Ratio w.o/ OCS',edgecolor='black')
ax.barh(point1, values_2, height=height, color='#778899', label='Cargo Space Ratio w.o/ OCS', left=values_right, edgecolor='black')

ax.grid(True, linestyle='--', which='both', color='gray', linewidth=0.5)

plt.text(values_right[0]+values_right_space[0]/2, 31.7, 'Cargo', color='white',fontsize=15)
plt.text(values_right_2[0] + values_left_OCP_space[0] / 2, 30.2, 'Cargo', color='white',fontsize=15)
plt.text(10.55/2 -2, 31.7, "Battery", color='white',fontsize=15)
plt.text(values_right_2[0]/2 - 2, 30.2, "Battery", color='white',fontsize=15)

plt.text(102, 31.7, "ES", color='black',fontsize=16)
plt.text(102, 30.2, "ES with OCS", color='black',fontsize=16)



custom_yticklabels = ['Shanghai-Busan', 'Shanghai-Hongkong', 'Qingdao-Nagoya', 'Hamburg-Antwerp', 'Felixstowe-Rotterdam', 'Rotterdam-Antwerp', 'Santos-Buenos Aires']


ax.set_yticks(custom_yticks)
ax.set_yticklabels(custom_yticklabels,fontsize=15)

ax.set_xlabel('Proportion of Space Occupied(%)',fontsize=15)
ax.set_ylabel('Routes',fontsize=15)

for i in range(len(custom_yticks)):
    arrow_start = (values_right[i], custom_yticks[i]-height-0.5)
    arrow_end = (values_right_2[i]+1, custom_yticks[i]-height-0.5)
    line_text = "| "
    line_label = ax.annotate(line_text, xy=(arrow_start[0]-0.3, arrow_start[1]), va='center', fontsize=15)
    line_label = ax.annotate(line_text, xy=(arrow_end[0]-1.4, arrow_end[1]), va='center', fontsize=15)
    arrow_dx = arrow_end[0] - arrow_start[0]
    arrow_dy = arrow_end[1] - arrow_start[1]
    ax.arrow(arrow_start[0], arrow_start[1], arrow_dx, arrow_dy, head_width=0.5, head_length=1, fc='lightblue',
             ec='black')


for i in range(1):
    plt.text((values_right_2[i] + values_right[i]) / 2-5, point[i] - 2,
             "Battery Space - {:.1f}%".format(values_right[i] - values_right_2[i]), color='black', fontsize=14)

for i in range(1,3):
    plt.text((values_right_2[i] + values_right[i]) / 2-12, point[i] - 2,
             "Battery Space - {:.1f}%".format(values_right[i] - values_right_2[i]), color='black', fontsize=14)
for i in range(3,7):
    plt.text((values_right_2[i] + values_right[i]) / 2, point[i] - 2,
             "Battery Space - {:.1f}%".format(values_right[i] - values_right_2[i]), color='black', fontsize=14)



handles, labels = ax.get_legend_handles_labels()
plt.legend(handles, labels, loc='center', bbox_to_anchor=(0.5, -0.1), ncol=2, prop={'family': "Arial", 'size': 15})
plt.subplots_adjust(bottom=0.15)
plt.xlim(0, 100)


plt.savefig('ExtraCargoSpace.pdf', dpi=600)

plt.show()

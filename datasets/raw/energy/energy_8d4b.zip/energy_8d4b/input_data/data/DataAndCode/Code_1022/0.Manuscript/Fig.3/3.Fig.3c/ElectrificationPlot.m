clc;clear

Data{1} = xlsread('ElectrificationRate.xlsx','ElecRate','B22:AH37')
disp('Data1:')
disp(Data{1})

Data{2} = xlsread('ElectrificationRate.xlsx','ElecRate','B82:AH97')
disp('Data2:')
disp(Data{2})


% titleName='Elecrification Rate';
className={'Route Length','Route Length'};

varNameRow{1}={'','','','','','','','','','','','','','','',''};
varNameRow{2}={'','','','','','','','','','','','','','','',''};


varNameCol{1}={'ROT-ANT','FEL-ROT','HAM-ANT','SHA-BUS','BAS-FUJ','SHA-HK','CAP-DUR','SHA-NAG','SAN-BA','SHA-YOK','QIN-NAG','PAN-HOU',...
    'NYC-PAN','NIN-SIN','SHA-SIN','MON-ANT','NYC-ALG','SIN-FUJ','SUE-ROT','NYC-ROT','VIR-ANT','HED-JIN','SAN-ELI','DUR-FUJ','MEL-SIN','VAN-PAN',...
    'HOU-ALG','SIN-DUR','SIN-SUE','COR-ROT','SIN-CAP','SHA-LA','ROT-CAP'};
varNameCol{2}={'ROT-ANT','FEL-ROT','HAM-ANT','SHA-BUS','BAS-FUJ','SHA-HK','CAP-DUR','SHA-NAG','SAN-BA','SHA-YOK','QIN-NAG','PAN-HOU',...
    'NYC-PAN','NIN-SIN','SHA-SIN','MON-ANT','NYC-ALG','SIN-FUJ','SUE-ROT','NYC-ROT','VIR-ANT','HED-JIN','SAN-ELI','DUR-FUJ','MEL-SIN','VAN-PAN',...
    'HOU-ALG','SIN-DUR','SIN-SUE','COR-ROT','SIN-CAP','SHA-LA','ROT-CAP'};

% ===============================================================

sepRatio=2.5/100; 

CMap=[9,100,203
33,118,199
61,137,200
93,156,200
123,174,201
156,193,199
182,209,199
217,230,200
251,249,200
249,226,184
251,203,167
250,176,149
249,151,130
251,126,114
252,100,95
250,76,78
249,52,61]./255;
CMap=slanCM(141);
CLim=[-1,1];


theta1=pi;
theta2=-pi;

R1=1.5;
R2=8;
R3=10.8;
R4=11.5;


ringRatio=zeros(1,length(Data));
for i=1:length(Data)
    ringRatio(i)=size(Data{i},2);
    disp(ringRatio(i))
end
txtRatio=sepRatio./length(Data);
disp('txtRatio:')
disp(txtRatio)
ringRatio1=1./sum(ringRatio).*(1-sepRatio);
ringRatio2=ringRatio./sum(ringRatio).*(1-sepRatio);
disp('ringRatio1:')
disp(ringRatio1)
disp('ringRatio2:')
disp(ringRatio2)


fig=figure('Units','normalized','Position',[0,0,1,1]);
fig.Color=[1,1,1];
ax=axes(fig);hold on
ax.XLim=[-12,12];
ax.YLim=[-12,12];
ax.DataAspectRatio=[1,1,1];
ax.XColor='none';
ax.YColor='none';



% =================================================================

x=linspace(CLim(1),CLim(2),size(CMap,1))';
y1=CMap(:,1);y2=CMap(:,2);y3=CMap(:,3);
colorFunc=@(X)[interp1(x,y1,X,'pchip'),interp1(x,y2,X,'pchip'),interp1(x,y3,X,'pchip')];
tS=linspace(0,1,50);

for k=1:length(Data)
    theta3=theta1+(theta2-theta1).*(k*txtRatio+sum(ringRatio2(1:(k-1))));
    tData=Data{k};
    for i=1:size(Data{k},1)
        for j=1:size(Data{k},2)
            tT=theta3+[j-1,j].*ringRatio1.*(theta2-theta1);
            tTd=tT(2)-tT(1);
            tT=[tT(1)+tTd/30,tT(2)-tTd/30];
            tR=R2+(R1-R2).*[i-1,i]./size(Data{k},1);
            tRd=tR(2)-tR(1);
            tR=[tR(1)+tRd/10,tR(2)-tRd/10];
            tT=[tT(1)+(tT(2)-tT(1)).*tS,tT(2)+(tT(1)-tT(2)).*tS];
            tR=[tR(1).*ones(1,50),tR(2).*ones(1,50)];
            fill(ax,tR.*cos(tT),tR.*sin(tT),colorFunc(tData(i,j)),'EdgeColor',[0,0,0],'LineWidth',1.0,'EdgeAlpha',0)

        end
    end
end

% -------------------------------------------------------------------------

for k=1:length(Data)
    tT=theta1+(theta2-theta1).*((k-.5)*txtRatio+sum(ringRatio2(1:(k-1))));
    for i=1:size(Data{k},1)
        tR=R2+(R1-R2).*[i-1,i]./size(Data{k},1);
        tR=mean(tR);
        tVarNameRow=varNameRow{k};
        if tT<0&&tT>-pi
            text(ax,tR.*cos(tT),tR.*sin(tT),tVarNameRow{i},'FontSize',9,...
                'Color',[0,0,0],'HorizontalAlignment','center','Rotation',tT./pi.*180+90)
        else
            text(ax,tR.*cos(tT),tR.*sin(tT),tVarNameRow{i},'FontSize',9,...
                'Color',[0,0,0],'HorizontalAlignment','center','Rotation',tT./pi.*180-90)
        end
    end
end

for k=1:length(Data)
    theta3=theta1+(theta2-theta1).*(k*txtRatio+sum(ringRatio2(1:(k-1))));
    tR=(R2*3+R3*2)/5;
    tVarNameCol=varNameCol{k};
    for j=1:size(Data{k},2)
        tT=theta3+[j-1,j].*ringRatio1.*(theta2-theta1);
        tT=mean(tT);
        if tT<0&&tT>-pi
            text(ax,tR.*cos(tT),tR.*sin(tT),tVarNameCol{j},'Rotation',tT./pi.*180,...
                'Color',[0,0,0],'HorizontalAlignment','center','FontSize',9)
        else
            text(ax,tR.*cos(tT),tR.*sin(tT),tVarNameCol{j},'Rotation',tT./pi.*180,...
                'Color',[0,0,0],'HorizontalAlignment','center','FontSize',9)
        end
    end
end

tS=linspace(0,1,100);
for k=1:length(Data)
    theta3=theta1+(theta2-theta1).*((k-1)*txtRatio+sum(ringRatio2(1:(k-1))));
    theta4=theta1+(theta2-theta1).*(k*txtRatio+sum(ringRatio2(1:k)));
    tT=[theta3,theta4];
    tT=[tT(1)-2*pi/40/length(Data),tT(2)];
    tR=[R3,R4];
    ttT=mean(tT);ttR=mean(tR);
    tT=[tT(1)+(tT(2)-tT(1)).*tS,tT(2)+(tT(1)-tT(2)).*tS];
    tR=[tR(1).*ones(1,100),tR(2).*ones(1,100)];
    fill(ax,tR.*cos(tT),tR.*sin(tT),[1,1,1],'EdgeColor',[.3,.3,.3],'LineWidth',1.2,'EdgeAlpha',.8)
    if ttT<0&&ttT>-pi
        text(ax,ttR.*cos(ttT),ttR.*sin(ttT),className{k},'Rotation',ttT./pi.*180+90,...
            'Color',[0,0,0],'HorizontalAlignment','center','FontSize',9)
    else
        text(ax,ttR.*cos(ttT),ttR.*sin(ttT),className{k},'Rotation',ttT./pi.*180-90,...
             'Color',[0,0,0],'HorizontalAlignment','center','FontSize',9)
    end
end
% -------------------------------------------------------------------------


colormap(colorFunc(linspace(-0.82,0,256)'))
caxis(CLim)
cb=colorbar();
cb.Location="eastoutside";
cb.LineWidth=1;
% cb.TickDirection='out'
cb.Ticks = [];
cb.Position = cb.Position +[0.1, 0, 0, -0.2];
cb.Position(4)=0.8;
cb.Direction = 'reverse';


exportgraphics(figure,'vectorfig.pdf','ContentType','vector','Resolution', 600)

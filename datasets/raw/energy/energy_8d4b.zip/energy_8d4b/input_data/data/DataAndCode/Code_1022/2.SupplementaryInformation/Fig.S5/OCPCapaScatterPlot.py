import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import math

plt.rc('font',family='Arial', size=12)
def ReadData():
    EP = 5
    EnginePowerSet_SHA_BUS = []
    EnginePowerSet_SHA_NAG = []
    EnginePowerSet_SHA_YOK = []
    EnginePowerSet_QIN_NAG = []
    EnginePowerSet_SHA_HK = []
    EnginePowerSet_HAM_ANT = []
    EnginePowerSet_ROT_ANT = []
    EnginePowerSet_FEL_ROT = []

    DeadweightSet_SHA_BUS = []
    DeadweightSet_SHA_NAG = []
    DeadweightSet_SHA_YOK = []
    DeadweightSet_QIN_NAG = []
    DeadweightSet_SHA_HK = []
    DeadweightSet_HAM_ANT = []
    DeadweightSet_ROT_ANT = []
    DeadweightSet_FEL_ROT = []

    df = pd.ExcelFile('ShipData.xlsx')
    for p in range(EP):
        EnginePowerSet_SHA_BUS += [x for x in df.parse('Shanghai-Busan')['EnginePower_scn%s'%(p+1)].tolist() if not np.isnan(x)]
        DeadweightSet_SHA_BUS += [x for x in df.parse('Shanghai-Busan')['Deadweight_scn%s'%(p+1)].tolist() if not np.isnan(x)]
        # print(EnginePowerSet_SHA_BUS)

        EnginePowerSet_SHA_NAG += [x for x in df.parse('Shanghai-Nagoya')['EnginePower_scn%s'%(p+1)].tolist() if not np.isnan(x)]
        DeadweightSet_SHA_NAG += [x for x in df.parse('Shanghai-Nagoya')['Deadweight_scn%s'%(p+1)].tolist() if not np.isnan(x)]

        EnginePowerSet_SHA_YOK += [x for x in df.parse('Shanghai-Yokohama')['EnginePower_scn%s'%(p+1)].tolist() if not np.isnan(x)]
        DeadweightSet_SHA_YOK += [x for x in df.parse('Shanghai-Yokohama')['Deadweight_scn%s'%(p+1)].tolist() if not np.isnan(x)]

        EnginePowerSet_SHA_HK += [x for x in df.parse('Shanghai-Hongkong')['EnginePower_scn%s'%(p+1)].tolist() if not np.isnan(x)]
        DeadweightSet_SHA_HK += [x for x in df.parse('Shanghai-Hongkong')['Deadweight_scn%s'%(p+1)].tolist() if not np.isnan(x)]

        EnginePowerSet_QIN_NAG += [x for x in df.parse('Qingdao-Nagoya')['EnginePower_scn%s'%(p+1)].tolist() if not np.isnan(x)]
        DeadweightSet_QIN_NAG += [x for x in df.parse('Qingdao-Nagoya')['Deadweight_scn%s'%(p+1)].tolist() if not np.isnan(x)]

        EnginePowerSet_HAM_ANT += [x for x in df.parse('Hamburg-Antwerp')['EnginePower_scn%s'%(p+1)].tolist() if not np.isnan(x)]
        DeadweightSet_HAM_ANT += [x for x in df.parse('Hamburg-Antwerp')['Deadweight_scn%s'%(p+1)].tolist() if not np.isnan(x)]

        EnginePowerSet_ROT_ANT += [x for x in df.parse('Rotterdam-Antwerp')['EnginePower_scn%s'%(p+1)].tolist() if not np.isnan(x)]
        DeadweightSet_ROT_ANT += [x for x in df.parse('Rotterdam-Antwerp')['Deadweight_scn%s'%(p+1)].tolist() if not np.isnan(x)]

        EnginePowerSet_FEL_ROT += [x for x in df.parse('Felixstowe-Rotterdam')['EnginePower_scn%s'%(p+1)].tolist() if not np.isnan(x)]
        DeadweightSet_FEL_ROT += [x for x in df.parse('Felixstowe-Rotterdam')['Deadweight_scn%s'%(p+1)].tolist() if not np.isnan(x)]

    return EnginePowerSet_SHA_BUS, EnginePowerSet_SHA_NAG, EnginePowerSet_SHA_YOK, EnginePowerSet_QIN_NAG, EnginePowerSet_SHA_HK, \
    EnginePowerSet_HAM_ANT, EnginePowerSet_ROT_ANT, EnginePowerSet_FEL_ROT, DeadweightSet_SHA_BUS, DeadweightSet_SHA_NAG, \
    DeadweightSet_SHA_YOK, DeadweightSet_QIN_NAG, DeadweightSet_SHA_HK, DeadweightSet_HAM_ANT, DeadweightSet_ROT_ANT, DeadweightSet_FEL_ROT

def ShipScatterPlot():
    EnginePowerSet_SHA_BUS, EnginePowerSet_SHA_NAG, EnginePowerSet_SHA_YOK, EnginePowerSet_QIN_NAG, EnginePowerSet_SHA_HK, \
    EnginePowerSet_HAM_ANT, EnginePowerSet_ROT_ANT, EnginePowerSet_FEL_ROT, DeadweightSet_SHA_BUS, DeadweightSet_SHA_NAG, \
    DeadweightSet_SHA_YOK, DeadweightSet_QIN_NAG, DeadweightSet_SHA_HK, DeadweightSet_HAM_ANT, DeadweightSet_ROT_ANT, DeadweightSet_FEL_ROT = ReadData()

    x1, y1 = [ x * 1e-3 for x in EnginePowerSet_SHA_BUS] , [ x * 1e-3 for x in DeadweightSet_SHA_BUS]
    x2, y2 = [ x * 1e-3 for x in EnginePowerSet_SHA_NAG], [ x * 1e-3 for x in DeadweightSet_SHA_NAG]
    x3, y3 = [ x * 1e-3 for x in EnginePowerSet_SHA_YOK], [ x * 1e-3 for x in DeadweightSet_SHA_YOK]
    x4, y4 = [ x * 1e-3 for x in EnginePowerSet_SHA_HK], [ x * 1e-3 for x in DeadweightSet_SHA_HK]
    x5, y5 = [ x * 1e-3 for x in EnginePowerSet_QIN_NAG], [ x * 1e-3 for x in DeadweightSet_QIN_NAG]
    x6, y6 = [ x * 1e-3 for x in EnginePowerSet_HAM_ANT], [ x * 1e-3 for x in DeadweightSet_HAM_ANT]
    x7, y7 = [ x * 1e-3 for x in EnginePowerSet_ROT_ANT], [ x * 1e-3 for x in DeadweightSet_ROT_ANT]
    x8, y8 = [ x * 1e-3 for x in EnginePowerSet_FEL_ROT], [ x * 1e-3 for x in DeadweightSet_FEL_ROT]


    plt.scatter(x1,y1, c='#3A44B0', alpha=0.5, marker='^', label='SHA-BUS')
    plt.scatter(x2,y2, c='#535FE8', alpha=0.5, marker='^', label='SHA-NAG')
    plt.scatter(x3,y3, c='#7681F8', alpha=0.5, marker='^', label='SHA-YOK')
    plt.scatter(x4,y4, c='#A0A7FA', alpha=0.5, marker='^', label='SHA-HK')
    plt.scatter(x5,y5, c='#C2C7FB', alpha=0.5, marker='^', label='QIN-NAG')
    plt.scatter(x6,y6, c='#344F3A', alpha=0.5, marker='D', label='HAM-ANT')
    plt.scatter(x7,y7, c='#507550', alpha=0.5, marker='D', label='ROT-ANT')
    plt.scatter(x8,y8, c='#99A782', alpha=0.5, marker='D', label='FEL-ROT')
    plt.legend(loc='upper left')
    plt.xlabel('EnginePower(MW)', fontsize=14)
    plt.ylabel('Deadweight(*10^3 ton)', fontsize=14)

    plt.savefig('./ShipCapacityScatterPlot.pdf', transparent=True, dpi=600)
    plt.show()


def OCSScatterPlot():
    EnginePowerSet_SHA_BUS, EnginePowerSet_SHA_NAG, EnginePowerSet_SHA_YOK, EnginePowerSet_QIN_NAG, EnginePowerSet_SHA_HK, \
    EnginePowerSet_HAM_ANT, EnginePowerSet_ROT_ANT, EnginePowerSet_FEL_ROT, DeadweightSet_SHA_BUS, DeadweightSet_SHA_NAG, \
    DeadweightSet_SHA_YOK, DeadweightSet_QIN_NAG, DeadweightSet_SHA_HK, DeadweightSet_HAM_ANT, DeadweightSet_ROT_ANT, DeadweightSet_FEL_ROT = ReadData()

    TrafficVolume_SHA_BUS = 12.9
    TrafficVolume_SHA_NAG = 11.9
    TrafficVolume_SHA_YOK = 12.8
    TrafficVolume_QIN_NAG = 3.2
    TrafficVolume_SHA_HK = 8.6
    TrafficVolume_HAM_ANT = 33.5


    OCSCapa_SHA_BUS = [41, 20, 30, 20]
    OCSCapa_SHA_NAG = [38, 24, 20, 10]
    OCSCapa_SHA_YOK = [46, 30, 20, 10, 20]
    OCSCapa_SHA_HK = [18, 29]
    OCSCapa_QIN_NAG = [30]
    OCSCapa_HAM_ANT = [116, 105, 32]


    x1, y1 = [sum([i * TrafficVolume_SHA_BUS for i in EnginePowerSet_SHA_BUS])/ len(EnginePowerSet_SHA_BUS) / 1e3] * len(OCSCapa_SHA_BUS), OCSCapa_SHA_BUS
    x2, y2 = [sum([i * TrafficVolume_SHA_NAG for i in EnginePowerSet_SHA_NAG])/ len(EnginePowerSet_SHA_NAG) / 1e3] * len(OCSCapa_SHA_NAG), OCSCapa_SHA_NAG
    x3, y3 = [sum([i * TrafficVolume_SHA_YOK for i in EnginePowerSet_SHA_YOK])/len(EnginePowerSet_SHA_YOK) / 1e3] * len(OCSCapa_SHA_YOK), OCSCapa_SHA_YOK
    x4, y4 = [sum([i * TrafficVolume_SHA_HK for i in EnginePowerSet_SHA_HK ])/len(EnginePowerSet_SHA_HK) / 1e3] * len(OCSCapa_SHA_HK ), OCSCapa_SHA_HK
    x5, y5 = [sum([i * TrafficVolume_QIN_NAG for i in EnginePowerSet_QIN_NAG])/len(EnginePowerSet_QIN_NAG) / 1e3] * len(OCSCapa_QIN_NAG), OCSCapa_QIN_NAG
    x6, y6 = [sum([i * TrafficVolume_HAM_ANT for i in EnginePowerSet_HAM_ANT])/len(EnginePowerSet_HAM_ANT) / 1e3] * len(OCSCapa_HAM_ANT), OCSCapa_HAM_ANT


    plt.scatter(x1,y1, c='#3A44B0', alpha=0.8, marker='^', label='SHA-BUS')
    plt.scatter(x2,y2, c='#535FE8', alpha=0.8, marker='^', label='SHA-NAG')
    plt.scatter(x3,y3, c='#7681F8', alpha=0.8, marker='^', label='SHA-YOK')
    plt.scatter(x4,y4, c='#A0A7FA', alpha=0.8, marker='^', label='SHA-HK')
    plt.scatter(x5,y5, c='#C2C7FB', alpha=0.8, marker='^', label='QIN-NAG')
    plt.scatter(x6,y6, c='#344F3A', alpha=0.8, marker='D', label='HAM-ANT')
    plt.legend(loc='lower right')
    plt.xlabel('TrafficVolume * AveragePower', fontsize=14)
    plt.ylabel('OCS Capacity', fontsize=14)

    plt.savefig('./OCSCapacityScatterPlot.pdf', transparent=True, dpi=600)
    plt.show()

ShipScatterPlot()
OCSScatterPlot()
from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import pandas as pd

from data_processing import load_excel, save_figure
from database_retrieval import locate_file


def _source_workbook() -> Path:
    return locate_file(
        "input_data/data/41560_2024_1649_MOESM2_ESM.xlsx",
        "input_data/data/source_data.xlsx",
    )


def _supply_chain_csv() -> Path:
    return locate_file(
        "input_data/data/repo/acheng98-NA-EV-Battery-Supply-Chain-Mapping-3a331aa/SI. IRA Incentives - S9. Post-IRA EV Supply Chain Investments.csv",
        "input_data/data/acheng98-NA-EV-Battery-Supply-Chain-Mapping-3a331aa/SI. IRA Incentives - S9. Post-IRA EV Supply Chain Investments.csv",
        "input_data/data/ira_supply_chain.csv",
    )


def scenario_summary() -> dict:
    df = load_excel(_source_workbook(), "7. Scenario Results Analysis")
    rows = []
    block = df.iloc[2:8].copy()
    block.iloc[:, 0] = block.iloc[:, 0].ffill()
    for _, row in block.iterrows():
        size = row.iloc[0]
        tech = row.iloc[1]
        if pd.isna(tech):
            continue
        try:
            rows.append(
                {
                    "battery_size": str(size).strip(),
                    "technology": str(tech).strip(),
                    "baseline": float(row.iloc[2]),
                    "full_ira": float(row.iloc[3]),
                    "feoc": float(row.iloc[4]),
                    "leasing": float(row.iloc[5]),
                    "ira_gap": float(row.iloc[2] - row.iloc[3]),
                    "leasing_gap": float(row.iloc[2] - row.iloc[5]),
                }
            )
        except Exception:
            continue
    return {"cases": rows}


def manufacturing_tracker_summary() -> dict:
    df = load_excel(_source_workbook(), "8. World Battery Manufacturing ")
    tracker = df.iloc[3:].copy()
    tracker.columns = df.iloc[2].tolist()
    tracker = tracker.dropna(subset=[tracker.columns[0], tracker.columns[2]])
    tracker = tracker.rename(columns={tracker.columns[0]: "company", tracker.columns[1]: "factory_type", tracker.columns[2]: "location", tracker.columns[3]: "capacity_gwh"})
    tracker["capacity_gwh"] = pd.to_numeric(tracker["capacity_gwh"], errors="coerce")
    return {
        "rows": int(tracker.shape[0]),
        "total_capacity_gwh": float(tracker["capacity_gwh"].fillna(0).sum()),
        "mean_capacity_gwh": float(tracker["capacity_gwh"].mean()),
        "top_companies": tracker.groupby("company", as_index=False)["capacity_gwh"].sum().sort_values("capacity_gwh", ascending=False).head(10).to_dict("records"),
    }


def investment_summary() -> dict:
    df = pd.read_csv(_supply_chain_csv())
    df["reported_investment"] = pd.to_numeric(df["reported_investment"], errors="coerce").fillna(0.0)
    df["reported_jobs"] = pd.to_numeric(df["reported_jobs"], errors="coerce").fillna(0.0)
    post = df[df["timeline"].astype(str).str.contains("Post-Inflation", na=False)]
    pre = df[~df["timeline"].astype(str).str.contains("Post-Inflation", na=False)]
    return {
        "rows": int(df.shape[0]),
        "post_ira_rows": int(post.shape[0]),
        "post_ira_total_investment": float(post["reported_investment"].sum()),
        "post_ira_total_jobs": float(post["reported_jobs"].sum()),
        "pre_ira_total_investment": float(pre["reported_investment"].sum()),
        "product_counts_post_ira": post["product"].value_counts().head(10).to_dict(),
    }


def policy_gap_summary() -> dict:
    cases = scenario_summary()["cases"]
    return {
        case["technology"] + "@" + case["battery_size"]: {
            "baseline": case["baseline"],
            "full_ira": case["full_ira"],
            "feoc": case["feoc"],
            "leasing": case["leasing"],
            "ira_gap": case["ira_gap"],
            "leasing_gap": case["leasing_gap"],
        }
        for case in cases
    }


def chemistry_vulnerability_summary() -> dict:
    df = load_excel(_source_workbook(), "S10. Data Input for Shiny Visua", header=None)
    chemistry_rows = {
        "LFP": (5, 6),
        "NMC811": (8, 9),
        "NCA": (11, 12),
    }
    out = {}
    for chemistry, (header_idx, value_idx) in chemistry_rows.items():
        headers = [str(v).strip() for v in df.iloc[header_idx, :17].tolist()]
        values = pd.to_numeric(df.iloc[value_idx, :17], errors="coerce")
        row = {h: float(v) for h, v in zip(headers, values) if h and pd.notna(v)}

        mineral_keys = [k for k in row if any(x in k.lower() for x in ["lithium", "nickel", "cobalt", "manganese", "graphite", "aluminum"]) and "cost" not in k.lower()]
        mineral_total = float(sum(row[k] for k in mineral_keys))
        crit_key = next((k for k in row if "critmincost" in k.lower()), None)
        other_key = next((k for k in row if "othermatcost" in k.lower()), None)
        crit_cost = float(row[crit_key]) if crit_key else 0.0
        other_cost = float(row[other_key]) if other_key else 0.0
        production_cost_keys = [
            k
            for k in row
            if any(
                token in k.lower()
                for token in [
                    "critmincost",
                    "othermatcost",
                    "labor",
                    "energy",
                    "overhead",
                    "depreciation",
                    "gsa",
                    "r&d",
                    "financing",
                    "profits",
                    "warranty",
                ]
            )
        ]
        total_production_cost = float(sum(row[k] for k in production_cost_keys))
        out[chemistry] = {
            "critical_mineral_cost": crit_cost,
            "other_material_cost": other_cost,
            "total_production_cost": total_production_cost,
            "critical_mineral_cost_share_of_total_cost": (crit_cost / total_production_cost) if total_production_cost > 0 else None,
            "mineral_amount_total": mineral_total,
            "nickel_amount": float(row.get(next((k for k in row if "nickel" in k.lower()), ""), 0.0)),
            "cobalt_amount": float(row.get(next((k for k in row if "cobalt" in k.lower()), ""), 0.0)),
            "mineral_amount_keys": mineral_keys,
            "cost_component_keys": production_cost_keys,
        }
    return out


def plot_scenario_costs(output_name: str = "scenario_costs.png") -> str:
    cases = scenario_summary()["cases"]
    fig, ax = plt.subplots(figsize=(11, 5))
    scenarios = ["baseline", "full_ira", "feoc", "leasing"]
    x = range(len(cases))
    width = 0.18
    for i, scen in enumerate(scenarios):
        vals = [case[scen] for case in cases]
        ax.bar([xi + (i - 1.5) * width for xi in x], vals, width=width, label=scen.replace("_", " ").title())
    ax.set_xticks(list(x), [f"{case['technology']}\n{case['battery_size']}" for case in cases])
    ax.set_ylabel("Estimated battery production cost")
    ax.set_title("IRA scenario cost comparison")
    ax.legend(frameon=False, ncol=2)
    return save_figure(fig, output_name)


def plot_supply_chain_map(output_name: str = "supply_chain_map.png") -> str:
    df = pd.read_csv(_supply_chain_csv())
    df["reported_investment"] = pd.to_numeric(df["reported_investment"], errors="coerce").fillna(0.0)
    df["latitude"] = pd.to_numeric(df["latitude"], errors="coerce")
    df["longitude"] = pd.to_numeric(df["longitude"], errors="coerce")
    df = df[
        (df["timeline"] == "Post-Inflation Reduction Act")
        & (df["technology"].isin(["Electric Vehicles", "Batteries"]))
        & (df["product"] != "Electric Vehicles: Chargers")
        & (df["latitude"] > 15)
    ].copy()
    df = df.dropna(subset=["latitude", "longitude"])

    investment_map = {
        "Less than 10M": 18,
        "10M - 100M": 54,
        "100M - 1B": 120,
        "Over 1 Billion": 240,
        "Not Specified": 18,
    }
    product_map = {
        "Electric Vehicles: Components": "white",
        "Electric Vehicles: Assembly": "white",
        "Electric Vehicles: Components; Electric Vehicles: Assembly": "white",
        "Batteries: Minerals Extraction": "maroon",
        "Batteries: Minerals Extraction; Batteries: Materials Processing": "mediumvioletred",
        "Batteries: Materials Processing": "blue",
        "Batteries: Recycling": "navy",
        "Batteries: Recycling; Batteries: Materials Processing": "navy",
        "Batteries: Components": "darkorange",
        "Batteries: Cells": "gold",
        "Batteries: Packs": "gold",
        "Batteries: Cells; Batteries: Packs": "gold",
        "Batteries: Minerals Extraction; Batteries: Recycling": "black",
        "Batteries: Recycling; Batteries: Cells": "black",
        "Batteries: Materials Processing; Batteries: Components": "black",
        "Batteries: Components; Batteries: Cells": "black",
        "Batteries: Components; Batteries: Cells; Batteries: Recycling": "black",
    }
    df["marker_size"] = df["by_amount"].map(investment_map).fillna(18)
    df["marker_color"] = df["product"].map(product_map).fillna("#444444")

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.scatter(
        df["longitude"],
        df["latitude"],
        s=df["marker_size"],
        alpha=0.7,
        facecolor=df["marker_color"],
        edgecolor="black",
        linewidth=0.3,
        label="Post-IRA investments",
    )
    ax.set_xlim(-130, -65)
    ax.set_ylim(20, 52)
    ax.set_xlabel("Longitude")
    ax.set_ylabel("Latitude")
    ax.set_title("Post-IRA EV battery supply chain investments (batmap-aligned filtering)")
    ax.legend(frameon=False)
    return save_figure(fig, output_name)


def package_diagnostics() -> dict:
    return {
        "scenarios": scenario_summary(),
        "tracker": manufacturing_tracker_summary(),
        "investments": investment_summary(),
        "policy_gaps": policy_gap_summary(),
        "chemistry_vulnerability": chemistry_vulnerability_summary(),
        "recommended_plot_calls": [
            "plot_scenario_costs",
            "plot_supply_chain_map",
        ],
    }

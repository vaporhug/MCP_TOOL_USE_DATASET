from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def package_root() -> Path:
    return Path(__file__).resolve().parents[1]


def data_root() -> Path:
    return package_root() / "input_data" / "data"


def artifact_root() -> Path:
    return package_root() / "artifacts"


def ensure_dir(path: Path | str) -> Path:
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    return path


def load_excel(path: Path | str, sheet_name: str, header: int = 0, skiprows=None) -> pd.DataFrame:
    return pd.read_excel(path, sheet_name=sheet_name, header=header, skiprows=skiprows)


def coerce_numeric(series: pd.Series) -> pd.Series:
    return pd.to_numeric(
        series.astype(str)
        .str.replace("%", "", regex=False)
        .str.replace(",", "", regex=False)
        .str.replace("\u00a0", "", regex=False)
        .str.replace("(", "", regex=False)
        .str.replace(")", "", regex=False)
        .str.replace("--", "", regex=False)
        .str.strip(),
        errors="coerce",
    )


def save_figure(fig, relative_path: str, dpi: int = 220) -> str:
    out = artifact_root() / relative_path
    ensure_dir(out.parent)
    fig.savefig(out, dpi=dpi, bbox_inches="tight")
    plt.close(fig)
    return str(out)


def tidy_sheet(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [str(c).strip() for c in df.columns]
    return df


def percent_to_float(value) -> float:
    if pd.isna(value):
        return np.nan
    txt = str(value).replace("%", "").replace("\u00a0", "").strip()
    try:
        return float(txt)
    except ValueError:
        return np.nan

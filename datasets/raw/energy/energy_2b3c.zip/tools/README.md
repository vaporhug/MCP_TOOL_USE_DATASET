# energy_2b3c tools

Three layers are used here:

- `data_processing.py`: shared table loading, normalization, and filtering helpers.
- `database_retrieval.py`: local file discovery and path resolution helpers.
- `energy_tools.py`: paper-specific workflow primitives for battery carbon-footprint analysis.

The package is designed so the agent can use low-level primitives to reconstruct the paper-native conclusions and generate the plotted artifacts in `artifacts/`.

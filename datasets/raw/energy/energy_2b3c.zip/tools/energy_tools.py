from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from data_processing import load_excel, save_figure
from database_retrieval import locate_file


def _source_workbook() -> Path:
    return locate_file(
        "input_data/data/repo/results/Source Data.xlsx",
        "input_data/data/source_data.xlsx",
        "input_data/data/source_data/41467_2024_54634_MOESM4_ESM.xlsx",
    )


def _sheet(path: Path, name: str) -> pd.DataFrame:
    return load_excel(path, name)


def _figure23_header_row(df: pd.DataFrame) -> int:
    for idx in range(min(len(df), 20)):
        row = [str(v).strip().lower() for v in df.iloc[idx].tolist()]
        if any("region" == v for v in row) and any("5th percentile" in v for v in row):
            return idx
    raise ValueError("Could not find Figure 2/3 percentile header row")


def _extract_percentile_row(df: pd.DataFrame, region_value: str = "all") -> dict:
    header_idx = _figure23_header_row(df)
    body = df.iloc[header_idx + 1 :].copy()
    body.columns = [str(c).strip() for c in df.iloc[header_idx].tolist()]

    region_col = next((c for c in body.columns if c.lower() == "region"), None)
    p5_col = next((c for c in body.columns if "5th percentile" in c.lower()), None)
    p50_col = next((c for c in body.columns if "50th percentile" in c.lower()), None)
    p95_col = next((c for c in body.columns if "95th percentile" in c.lower()), None)
    if not all([region_col, p5_col, p50_col, p95_col]):
        raise ValueError("Missing percentile columns in Figure 2/3 sheet")

    hit = body[body[region_col].astype(str).str.strip().str.lower() == region_value.lower()]
    if hit.empty:
        raise ValueError(f"Region '{region_value}' not found in Figure 2/3 percentiles")
    row = hit.iloc[0]
    return {
        "p5": float(row[p5_col]),
        "p50": float(row[p50_col]),
        "p95": float(row[p95_col]),
    }


def _extract_production_geography_rows(df: pd.DataFrame) -> pd.DataFrame:
    header_idx = _figure23_header_row(df)
    body = df.iloc[header_idx + 1 :].copy()
    body.columns = [str(c).strip() for c in df.iloc[header_idx].tolist()]
    geo_col = next((c for c in body.columns if "production geography" in c.lower()), None)
    cf_col = next((c for c in body.columns if "cf [kg_co2/kwh" in c.lower()), None)
    if not geo_col or not cf_col:
        raise ValueError("Missing production-geography columns in Figure 2/3 sheet")

    out = body[[geo_col, cf_col]].copy()
    out.columns = ["geography", "cf"]
    out["cf"] = pd.to_numeric(out["cf"], errors="coerce")
    out["geography"] = out["geography"].astype(str).str.strip()
    out = out[(out["geography"] != "") & out["cf"].notna()]
    return out.reset_index(drop=True)


def _column_by_label(columns: list[str], *needles: str) -> str:
    lowered = [(c, c.lower()) for c in columns]
    for col, low in lowered:
        if all(needle.lower() in low for needle in needles):
            return col
    raise ValueError(f"Could not find column containing {needles}; available columns: {columns}")


def material_emission_summary() -> dict:
    wb = _source_workbook()
    pieces = []
    labels = ["Lithium Carbonate", "Nickel Sulfate", "Cobalt Sulfate", "Graphite"]
    for sheet_name, label in [("Figure 1", "Lithium Carbonate"), ("Figure 1", "Nickel Sulfate"), ("Figure 1", "Cobalt Sulfate"), ("SI Figure 3", "Graphite")]:
        df = _sheet(wb, sheet_name)
        section_starts = df.index[df.iloc[:, 0].astype(str) == label].tolist()
        if not section_starts:
            continue
        header_idx = section_starts[0]
        following_labels = df.index[(df.index > header_idx) & df.iloc[:, 0].isin(labels)].tolist()
        end = following_labels[0] if following_labels else len(df)
        columns = [str(c).strip() for c in df.iloc[header_idx].tolist()]
        rows = df.iloc[header_idx + 1 : end].copy().reset_index(drop=True)
        rows.columns = columns

        total_col = _column_by_label(columns, "total emissions")
        electricity_col = _column_by_label(columns, "electricity emissions")
        refining_col = _column_by_label(columns, "refining emissions")
        country_col = _column_by_label(columns, "country short")

        total_emissions = pd.to_numeric(rows[total_col], errors="coerce")
        rows = rows[total_emissions.notna()].copy()
        total_emissions = pd.to_numeric(rows[total_col], errors="coerce")
        if rows.empty:
            continue
        country = rows.iloc[int(total_emissions.to_numpy().argmax())][country_col] if total_emissions.notna().any() else None
        pieces.append(
            {
                "material": label,
                "sheet": sheet_name,
                "source_columns": {"total": total_col, "electricity": electricity_col, "refining": refining_col, "country": country_col},
                "mean_total_emissions": float(total_emissions.mean()),
                "median_total_emissions": float(total_emissions.median()),
                "min_total_emissions": float(total_emissions.min()),
                "max_total_emissions": float(total_emissions.max()),
                "top_country": None if country is None else str(country),
                "electricity_mean": float(pd.to_numeric(rows[electricity_col], errors="coerce").mean()),
                "refining_mean": float(pd.to_numeric(rows[refining_col], errors="coerce").mean()),
            }
        )
    return {"materials": pieces}


def battery_cf_percentiles() -> dict:
    wb = _source_workbook()
    out = {}
    for sheet_name, key in [("Figure 2", "NMC811"), ("Figure 3", "LFP")]:
        df = _sheet(wb, sheet_name)
        row = _extract_percentile_row(df, region_value="all")
        out[key] = {
            "p5": row["p5"],
            "p50": row["p50"],
            "p95": row["p95"],
            "spread": float(row["p95"] - row["p5"]),
        }
    return out


def production_geography_summary() -> dict:
    wb = _source_workbook()
    summary = {}
    for sheet_name, chemistry in [("Figure 2", "NMC811"), ("Figure 3", "LFP")]:
        df = _sheet(wb, sheet_name)
        rows = _extract_production_geography_rows(df)
        summary[chemistry] = rows.groupby("geography", as_index=False)["cf"].mean().sort_values("cf", ascending=False).to_dict("records")
    return summary


def plot_material_emissions(
    material_summary: list[dict] | None = None,
    output_name: str = "material_emissions.png",
) -> str:
    summary = material_summary if material_summary is not None else material_emission_summary()["materials"]
    df = pd.DataFrame(summary)
    order = df.sort_values("mean_total_emissions", ascending=False)
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.bar(order["material"], order["mean_total_emissions"], color="#4c78a8")
    ax.plot(order["material"], order["refining_mean"], color="#f58518", marker="o", label="mean refining")
    ax.plot(order["material"], order["electricity_mean"], color="#54a24b", marker="s", label="mean electricity")
    ax.set_ylabel("kg CO2e per kg material")
    ax.set_title("Battery material emission levels from source data")
    ax.legend(frameon=False)
    plt.xticks(rotation=20, ha="right")
    return save_figure(fig, output_name)


def plot_battery_cf_percentiles(
    percentile_summary: dict | None = None,
    output_name: str = "battery_cf_percentiles.png",
) -> str:
    summary = percentile_summary if percentile_summary is not None else battery_cf_percentiles()
    fig, ax = plt.subplots(figsize=(8, 5))
    labels = list(summary)
    for i, label in enumerate(labels):
        vals = summary[label]
        ax.errorbar(
            i,
            vals["p50"],
            yerr=[[vals["p50"] - vals["p5"]], [vals["p95"] - vals["p50"]]],
            fmt="o",
            color=["#1f77b4", "#ff7f0e"][i],
            capsize=7,
            label=label,
        )
    ax.set_xticks(range(len(labels)), labels)
    ax.set_ylabel("kg CO2e per kWh")
    ax.set_title("Carbon footprint distributions from the source data")
    ax.legend(frameon=False)
    return save_figure(fig, output_name)


def country_cf_summary() -> dict:
    geo = production_geography_summary()
    combined: dict[str, dict[str, float | None]] = {}
    for chemistry in ["NMC811", "LFP"]:
        for row in geo.get(chemistry, []):
            name = str(row["geography"]).strip()
            key = name.lower().replace(" ", "_")
            if key not in combined:
                combined[key] = {"region": name, "nmc811_cf": None, "lfp_cf": None}
            combined[key][f"{chemistry.lower()}_cf"] = float(row["cf"])
    return combined


def plot_country_cf_summary(
    regional_summary: dict | None = None,
    output_name: str = "country_cf_summary.png",
) -> str:
    summary = regional_summary if regional_summary is not None else country_cf_summary()
    regions = [summary[k]["region"] for k in summary]
    nmc_vals = [summary[k]["nmc811_cf"] for k in summary]
    lfp_vals = [summary[k]["lfp_cf"] for k in summary]
    x = np.arange(len(regions))
    width = 0.38
    fig, ax = plt.subplots(figsize=(8, 5))
    bars1 = ax.bar(x - width / 2, nmc_vals, width=width, color="#4c78a8", label="NMC811")
    bars2 = ax.bar(x + width / 2, lfp_vals, width=width, color="#f58518", label="LFP")
    ax.set_ylabel("Battery production CF (kg CO2e/kWh)")
    ax.set_title("Production-geography CF comparison (Figure 2/3 source fields)")
    ax.set_xticks(x, regions, rotation=20, ha="right")
    ax.legend(frameon=False)
    for bars in [bars1, bars2]:
        for bar in bars:
            if pd.notna(bar.get_height()):
                ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height(), f"{bar.get_height():.1f}", ha="center", va="bottom", fontsize=7)
    return save_figure(fig, output_name)


def package_diagnostics() -> dict:
    mats = material_emission_summary()
    cf = battery_cf_percentiles()
    geo = country_cf_summary()
    return {
        "materials": mats,
        "percentiles": cf,
        "regions": geo,
        "plotting_inputs": {
            "material_summary_rows": len(mats.get("materials", [])),
            "percentile_keys": list(cf.keys()),
            "regional_rows": len(geo),
        },
    }

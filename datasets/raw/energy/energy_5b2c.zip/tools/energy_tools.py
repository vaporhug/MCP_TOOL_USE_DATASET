from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "input_data" / "data"
SOURCE_WORKBOOK = DATA / "41467_2024_54503_MOESM3_ESM.xlsx"


def source_workbook(path: str | Path | None = None) -> Path:
    candidate = Path(path) if path is not None else SOURCE_WORKBOOK
    if not candidate.exists():
        raise FileNotFoundError(f"source workbook not found: {candidate}")
    return candidate


def _sheet(sheet: str, path: str | Path | None = None) -> pd.DataFrame:
    return pd.read_excel(source_workbook(path), sheet_name=sheet, header=None)


def ion_separation_summary(path: str | Path | None = None) -> dict:
    df = _sheet("Fig.3", path)
    ions = df.iloc[2:12, 0:6].copy()
    ions.columns = ["ion", "hydrate_radius_angstrom", "permeance_lmhb", "permeance_error", "rejection_percent", "rejection_error"]
    for col in ions.columns[1:]:
        ions[col] = pd.to_numeric(ions[col], errors="coerce")
    ions = ions.dropna(subset=["ion", "permeance_lmhb", "rejection_percent"])
    ions["charge_class"] = ions["ion"].astype(str).map(lambda x: "divalent" if "2+" in x else "monovalent")

    selectivity = df.iloc[17:20, 0:5].copy()
    selectivity.columns = ["pair", "selectivity_ph7", "selectivity_ph7_error", "selectivity_2m_h2so4", "selectivity_2m_h2so4_error"]
    for col in selectivity.columns[1:]:
        selectivity[col] = pd.to_numeric(selectivity[col], errors="coerce")
    selectivity = selectivity.dropna(subset=["pair"])

    divalent = ions[ions["charge_class"] == "divalent"]
    monovalent = ions[ions["charge_class"] == "monovalent"]
    return {
        "ion_table": ions.to_dict(orient="records"),
        "selectivity_table": selectivity.to_dict(orient="records"),
        "mean_divalent_rejection_percent": float(divalent["rejection_percent"].mean()),
        "mean_monovalent_rejection_percent": float(monovalent["rejection_percent"].mean()),
        "li_rejection_percent": float(ions.loc[ions["ion"].astype(str) == "Li+", "rejection_percent"].iloc[0]),
        "co_li_selectivity_2m_h2so4": float(selectivity.loc[selectivity["pair"].astype(str) == "Co2+/Li+", "selectivity_2m_h2so4"].iloc[0]),
    }


def ph_stability_summary(path: str | Path | None = None) -> dict:
    df = _sheet("Fig.4", path)
    rejection = df.iloc[3:15, 0:6].copy()
    rejection.columns = ["day", "TAD-TBMB", "PEI-TMC", "DK", "NF270", "MPS-34"]
    permeance = df.iloc[3:15, 7:13].copy()
    permeance.columns = ["day", "TAD-TBMB", "PEI-TMC", "DK", "NF270", "MPS-34"]
    for frame in (rejection, permeance):
        for col in frame.columns:
            frame[col] = pd.to_numeric(frame[col], errors="coerce")
    rejection = rejection.dropna(subset=["day"])
    permeance = permeance.dropna(subset=["day"])
    tad_rej = rejection[["day", "TAD-TBMB"]].dropna()
    tad_perm = permeance[["day", "TAD-TBMB"]].dropna()
    return {
        "rejection_table": rejection.to_dict(orient="records"),
        "permeance_table": permeance.to_dict(orient="records"),
        "tad_tbmb_rejection_day0_percent": float(tad_rej.loc[tad_rej["day"] == 0, "TAD-TBMB"].iloc[0]),
        "tad_tbmb_rejection_day70_percent": float(tad_rej.loc[tad_rej["day"] == 70, "TAD-TBMB"].iloc[0]),
        "tad_tbmb_permeance_day0_lmhb": float(tad_perm.loc[tad_perm["day"] == 0, "TAD-TBMB"].iloc[0]),
        "tad_tbmb_permeance_day70_lmhb": float(tad_perm.loc[tad_perm["day"] == 70, "TAD-TBMB"].iloc[0]),
    }


def continuous_filtration_summary(path: str | Path | None = None) -> dict:
    df = _sheet("Fig.5", path)
    tad = df.iloc[2:21, 0:3].copy()
    tad.columns = ["day", "permeance_lmhb", "co_rejection_percent"]
    pei = df.iloc[2:21, 5:8].copy()
    pei.columns = ["day", "permeance_lmhb", "co_rejection_percent"]
    for frame in (tad, pei):
        for col in frame.columns:
            frame[col] = pd.to_numeric(frame[col], errors="coerce")
    tad = tad.dropna(subset=["day"])
    pei = pei.dropna(subset=["day"])
    return {
        "tad_tbmb": tad.to_dict(orient="records"),
        "pei_tmc": pei.to_dict(orient="records"),
        "tad_tbmb_day30_permeance_lmhb": float(tad.loc[tad["day"] == 30, "permeance_lmhb"].iloc[0]),
        "tad_tbmb_day30_co_rejection_percent": float(tad.loc[tad["day"] == 30, "co_rejection_percent"].iloc[0]),
        "pei_tmc_day30_co_rejection_percent": float(pei.loc[pei["day"] == 30, "co_rejection_percent"].iloc[0]),
    }


def lithium_recovery_summary(path: str | Path | None = None) -> dict:
    df = _sheet("Fig.6", path)
    practical = df.iloc[2:6, 0:3].copy()
    practical.columns = ["cathode", "permeance_lmhb", "m2_rejection_percent"]
    ratios = df.iloc[3:7, 4:7].copy()
    ratios.columns = ["cathode", "feed_m2_li_mass_ratio", "permeate_m2_li_mass_ratio"]
    mass = df.iloc[13:16, 0:5].copy()
    mass.columns = ["stream", "ni_percent", "co_percent", "mn_percent", "li_percent"]
    product = df.iloc[[20], 0:5].copy()
    product.columns = ["metric", "li2co3_percent", "coco3_percent", "nico3_percent", "mnco3_percent"]
    for frame in (practical, ratios, mass, product):
        for col in frame.columns[1:]:
            frame[col] = pd.to_numeric(frame[col], errors="coerce")
    return {
        "practical_leachate_table": practical.to_dict(orient="records"),
        "m2_li_mass_ratio_table": ratios.to_dict(orient="records"),
        "permeate_enrichment_table": mass.to_dict(orient="records"),
        "carbonate_product_table": product.to_dict(orient="records"),
        "second_permeate_li_percent": float(mass.loc[mass["stream"].astype(str) == "2nd permeate", "li_percent"].iloc[0]),
        "li2co3_product_purity_percent": float(product["li2co3_percent"].iloc[0]),
    }



def render_evidence_figure(output_path: str | Path, panels: tuple[str, ...] = ("ion_rejection", "acid_selectivity")) -> dict:
    """Render selected evidence panels from parsed source tables.

    Supported panel names are ion_rejection, acid_selectivity, acid_stability,
    acid_permeance, filtration_rejection, lithium_enrichment, and carbonate_purity.
    The caller chooses the scientific composition and output path.
    """
    panel_map = {
        "ion_rejection": _draw_ion_rejection,
        "acid_selectivity": _draw_acid_selectivity,
        "acid_stability": _draw_acid_stability,
        "acid_permeance": _draw_acid_permeance,
        "filtration_rejection": _draw_filtration_rejection,
        "lithium_enrichment": _draw_lithium_enrichment,
        "carbonate_purity": _draw_carbonate_purity,
    }
    unknown = [panel for panel in panels if panel not in panel_map]
    if unknown:
        raise ValueError(f"unknown panel(s): {unknown}; choose from {sorted(panel_map)}")
    out = Path(output_path); out.parent.mkdir(parents=True, exist_ok=True)
    fig, axes = plt.subplots(1, len(panels), figsize=(4.6 * len(panels), 4.3), squeeze=False)
    evidence = {}
    for ax, panel in zip(axes[0], panels):
        evidence[panel] = panel_map[panel](ax)
    fig.tight_layout(); fig.savefig(out, dpi=200); plt.close(fig)
    return {"path": str(out), "panels": list(panels), "evidence": evidence}


def _draw_ion_rejection(ax) -> dict:
    summary = ion_separation_summary()
    ions = pd.DataFrame(summary["ion_table"])
    colors = ions["charge_class"].map({"divalent": "#4c78a8", "monovalent": "#f58518"})
    ax.scatter(ions["hydrate_radius_angstrom"], ions["rejection_percent"], c=colors, s=58)
    for _, row in ions.iterrows():
        ax.text(row["hydrate_radius_angstrom"], row["rejection_percent"] + 1.2, str(row["ion"]), fontsize=8, ha="center")
    ax.set_xlabel("Hydrated ion radius (angstrom)")
    ax.set_ylabel("Rejection (%)")
    ax.set_title("Fig.3a ion rejection")
    return {k: summary[k] for k in ["mean_divalent_rejection_percent", "mean_monovalent_rejection_percent", "li_rejection_percent"]}


def _draw_acid_selectivity(ax) -> dict:
    summary = ion_separation_summary()
    selectivity = pd.DataFrame(summary["selectivity_table"])
    x = np.arange(len(selectivity)); width = 0.36
    ax.bar(x - width / 2, selectivity["selectivity_ph7"], width, label="pH 7", color="#54a24b")
    ax.bar(x + width / 2, selectivity["selectivity_2m_h2so4"], width, label="2 M H2SO4", color="#e45756")
    ax.set_xticks(x); ax.set_xticklabels(selectivity["pair"], rotation=20, ha="right")
    ax.set_ylabel("M2+/Li+ selectivity")
    ax.set_title("Fig.3b selectivity")
    ax.legend(frameon=False, fontsize=8)
    return {"co_li_selectivity_2m_h2so4": summary["co_li_selectivity_2m_h2so4"]}


def _draw_acid_stability(ax) -> dict:
    summary = ph_stability_summary()
    rejection = pd.DataFrame(summary["rejection_table"])
    for membrane in ["TAD-TBMB", "PEI-TMC", "DK", "NF270", "MPS-34"]:
        ax.plot(rejection["day"], rejection[membrane], marker="o", ms=3, label=membrane)
    ax.set_ylabel("Co2+ rejection (%)")
    ax.set_xlabel("3 M H2SO4 immersion (days)")
    ax.set_title("Fig.4a acid stability")
    ax.legend(frameon=False, fontsize=7)
    return {"day0": summary["tad_tbmb_rejection_day0_percent"], "day70": summary["tad_tbmb_rejection_day70_percent"]}


def _draw_acid_permeance(ax) -> dict:
    summary = ph_stability_summary()
    permeance = pd.DataFrame(summary["permeance_table"])
    for membrane in ["TAD-TBMB", "PEI-TMC", "DK", "NF270", "MPS-34"]:
        ax.plot(permeance["day"], permeance[membrane], marker="o", ms=3, label=membrane)
    ax.set_ylabel("Permeance (LMHB)")
    ax.set_xlabel("3 M H2SO4 immersion (days)")
    ax.set_title("Fig.4b permeance")
    return {"day0": summary["tad_tbmb_permeance_day0_lmhb"], "day70": summary["tad_tbmb_permeance_day70_lmhb"]}


def _draw_filtration_rejection(ax) -> dict:
    summary = continuous_filtration_summary()
    tad = pd.DataFrame(summary["tad_tbmb"]); pei = pd.DataFrame(summary["pei_tmc"])
    ax.plot(tad["day"], tad["co_rejection_percent"], marker="o", label="TAD-TBMB", color="#4c78a8")
    ax.plot(pei["day"], pei["co_rejection_percent"], marker="o", label="PEI-TMC", color="#f58518")
    ax.set_xlabel("Filtration time (days)")
    ax.set_ylabel("Co2+ rejection (%)")
    ax.set_title("Fig.5 continuous filtration")
    ax.legend(frameon=False, fontsize=8)
    return {"tad_day30_rejection": summary["tad_tbmb_day30_co_rejection_percent"], "pei_day30_rejection": summary["pei_tmc_day30_co_rejection_percent"]}


def _draw_lithium_enrichment(ax) -> dict:
    summary = lithium_recovery_summary()
    mass = pd.DataFrame(summary["permeate_enrichment_table"])
    x = np.arange(len(mass))
    ax.bar(x, mass["li_percent"], color="#54a24b")
    ax.set_xticks(x); ax.set_xticklabels(mass["stream"], rotation=25, ha="right")
    ax.set_ylabel("Li mass content (%)")
    ax.set_title("Fig.6d Li enrichment")
    return {"second_permeate_li_percent": summary["second_permeate_li_percent"]}


def _draw_carbonate_purity(ax) -> dict:
    summary = lithium_recovery_summary()
    product = pd.DataFrame(summary["carbonate_product_table"])
    vals = product.iloc[0][["li2co3_percent", "coco3_percent", "nico3_percent", "mnco3_percent"]]
    ax.bar(["Li2CO3", "CoCO3", "NiCO3", "MnCO3"], vals.to_numpy(dtype=float), color=["#4c78a8", "#e45756", "#f58518", "#72b7b2"])
    ax.set_ylabel("Mass content (%)")
    ax.set_title("Fig.6e product purity")
    return {"li2co3_product_purity_percent": summary["li2co3_product_purity_percent"]}

def package_smoke_test() -> dict:
    return {
        "workbook": str(source_workbook()),
        "ion_separation": ion_separation_summary(),
        "ph_stability": ph_stability_summary(),
        "continuous_filtration": continuous_filtration_summary(),
        "lithium_recovery": lithium_recovery_summary(),
    }

#!/usr/bin/env python3
"""Domain tools for tundra eddy covariance carbon flux analysis.

Low-level primitives the agent can compose: data loading, light-response
curve fitting, footprint-weighted regression, monthly aggregation, scaling,
plotting. No tool encodes the paper's headline conclusion.
"""
from __future__ import annotations
from typing import Optional
import os
import json
import math
import numpy as np

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Tundra_EC_Flux_Tools")


# ----------------------------------------------------------------------------
#  Data loading
# ----------------------------------------------------------------------------

@mcp.tool()
def load_flux_csv(csv_path: str, max_rows: int = 50) -> dict:
    """Load an eddy covariance flux CSV file with footprint columns.

    Args:
        csv_path: Path to CSV with columns including datetime, air_temperature,
            PPFD_1_1_1, co2 (NEE in umol m-2 s-1), ch4 (umol m-2 s-1), and
            land-cover footprint columns suffixed with _ZM, _H, or _Klj
            (Kormann-Meixner, Hsieh, Kljun footprint models).
        max_rows: Truncate sample rows in the response.

    Returns:
        dict with column list, total row count, footprint model names,
        land-cover names, missing-data rates for co2 and ch4, and a sample.
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    cols = list(df.columns)

    # Identify footprint columns by suffix
    fp_models = sorted({c.rsplit("_", 1)[1] for c in cols
                        if c.endswith(("_ZM", "_H", "_Klj"))})
    lc_names = sorted({c.rsplit("_", 1)[0] for c in cols
                       if c.endswith(("_ZM", "_H", "_Klj"))})

    info = {
        "columns": cols,
        "total_rows": len(df),
        "footprint_models": fp_models,
        "land_cover_categories": lc_names,
        "sample_rows": df.head(max_rows).to_dict("records"),
    }
    if "co2" in cols:
        info["co2_missing_pct"] = round(float(df["co2"].isna().mean() * 100), 2)
    if "ch4" in cols:
        info["ch4_missing_pct"] = round(float(df["ch4"].isna().mean() * 100), 2)
    return info


@mcp.tool()
def load_drivers_tsv(tsv_path: str, max_rows: int = 20) -> dict:
    """Load a tab-separated REddyProc-style flux driver file (gap-filled
    air temperature, PAR, soil temperature, etc.).

    Args:
        tsv_path: Path to the .txt or .tsv file. The second line is a units
            row that is automatically skipped.
        max_rows: Number of sample rows to return.

    Returns:
        dict with columns, row count, sample rows.
    """
    import pandas as pd
    df = pd.read_csv(tsv_path, sep="\t", skiprows=[1])
    return {
        "columns": list(df.columns),
        "total_rows": len(df),
        "sample_rows": df.head(max_rows).to_dict("records"),
    }


# ----------------------------------------------------------------------------
#  Quality control & filtering
# ----------------------------------------------------------------------------

@mcp.tool()
def filter_growing_season(csv_path: str, datetime_col: str = "datetime",
                          start_month: int = 5, end_month: int = 9,
                          year: Optional[int] = None) -> dict:
    """Subset a flux table to a contiguous range of months.

    Args:
        csv_path: Input CSV.
        datetime_col: Name of the timestamp column.
        start_month: First month (inclusive).
        end_month: Last month (inclusive).
        year: Optional single-year restriction.

    Returns:
        dict with row counts before/after filter and the path to a written
        subset CSV (in the same directory).
    """
    import pandas as pd
    df = pd.read_csv(csv_path, parse_dates=[datetime_col])
    n0 = len(df)
    df["_m"] = df[datetime_col].dt.month
    mask = (df["_m"] >= start_month) & (df["_m"] <= end_month)
    if year is not None:
        mask &= df[datetime_col].dt.year == year
    out = df[mask].drop(columns=["_m"]).copy()
    out_path = csv_path.replace(".csv", f"_m{start_month}-{end_month}.csv")
    out.to_csv(out_path, index=False)
    return {"input_rows": n0, "filtered_rows": int(mask.sum()),
            "output_path": out_path}


@mcp.tool()
def missing_data_summary(csv_path: str, columns: list[str]) -> dict:
    """Report missing-data fractions per named column.

    Args:
        csv_path: Path to CSV.
        columns: Column names to summarise.

    Returns:
        dict with per-column missing count, total count, missing percentage.
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    res = {}
    for c in columns:
        if c not in df.columns:
            res[c] = {"error": "column not found"}
            continue
        miss = int(df[c].isna().sum())
        res[c] = {"missing": miss, "total": len(df),
                  "missing_pct": round(float(df[c].isna().mean() * 100), 2)}
    return res


# ----------------------------------------------------------------------------
#  Footprint analytics
# ----------------------------------------------------------------------------

@mcp.tool()
def footprint_influence_summary(csv_path: str, footprint_suffix: str = "H",
                                land_covers: Optional[list[str]] = None
                                ) -> dict:
    """Summarise time-averaged footprint influence by land-cover type for
    a given footprint model.

    Args:
        csv_path: Flux CSV with footprint columns.
        footprint_suffix: "H" (Hsieh), "Klj" (Kljun), or "ZM" (Kormann-Meixner).
        land_covers: Optional list of land-cover names. If None, all are used.

    Returns:
        dict with mean, median, min, max influence (%), and the sum across
        land-covers (should be ~100%).
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    cols = [c for c in df.columns if c.endswith("_" + footprint_suffix)]
    if land_covers is not None:
        cols = [c for c in cols if c.rsplit("_", 1)[0] in land_covers]
    out = {}
    for c in cols:
        v = df[c].dropna().values
        out[c.rsplit("_", 1)[0]] = {
            "mean_pct": round(float(np.mean(v) * 100), 2),
            "median_pct": round(float(np.median(v) * 100), 2),
            "min_pct": round(float(np.min(v) * 100), 2),
            "max_pct": round(float(np.max(v) * 100), 2),
        }
    return {"footprint_suffix": footprint_suffix,
            "n_obs": len(df),
            "by_land_cover": out}


@mcp.tool()
def compare_footprint_models(csv_path: str, land_cover: str,
                             models: list[str]) -> dict:
    """Compute the per-observation correlation and bias between two or more
    footprint models for the same land-cover type.

    Args:
        csv_path: Flux CSV with multiple footprint suffixes.
        land_cover: e.g., "lichen_tundra", "fen1".
        models: list of two or three suffixes (e.g., ["H", "Klj", "ZM"]).

    Returns:
        dict with pairwise Pearson correlation, mean absolute difference,
        and slope of model_b ~ model_a (forced through origin).
    """
    import pandas as pd
    from itertools import combinations
    df = pd.read_csv(csv_path)
    out = {}
    for a, b in combinations(models, 2):
        ca, cb = f"{land_cover}_{a}", f"{land_cover}_{b}"
        if ca not in df.columns or cb not in df.columns:
            continue
        x = df[ca].values
        y = df[cb].values
        m = ~(np.isnan(x) | np.isnan(y))
        x, y = x[m], y[m]
        if len(x) < 3:
            continue
        r = float(np.corrcoef(x, y)[0, 1])
        mad = float(np.mean(np.abs(x - y)))
        # OLS slope through origin
        denom = float(np.sum(x * x))
        slope = float(np.sum(x * y) / denom) if denom > 0 else float("nan")
        out[f"{a}_vs_{b}"] = {"pearson_r": round(r, 4),
                              "mean_abs_diff": round(mad, 4),
                              "slope_origin": round(slope, 4),
                              "n": int(len(x))}
    return {"land_cover": land_cover, "comparisons": out}


# ----------------------------------------------------------------------------
#  Light response & temperature response (paper Eqs. 2-5)
# ----------------------------------------------------------------------------

@mcp.tool()
def fit_light_response_curve(par: list, nee: list, tair: list,
                             tmin: float = -1.5, tmax: float = 40.0,
                             topt: float = 15.0) -> dict:
    """Fit a rectangular hyperbola light-response model with a temperature
    scalar (paper Eqs. 2-5). NEE = R - GPP where:
      R = alpha * exp(beta * Tair)
      GPP = Tscale * E0 * Pmax * PAR / (Pmax + E0 * PAR)
      Tscale = (Tair-Tmin)(Tair-Tmax) / [(Tair-Tmin)(Tair-Tmax) - (Tair-Topt)^2]

    Returns the four estimated parameters {alpha, beta, E0, Pmax}, fit
    residual standard deviation, and number of observations used. Uses
    scipy.optimize.curve_fit with Levenberg-Marquardt.

    Args:
        par: list of PAR (umol m-2 s-1) values
        nee: list of NEE (umol m-2 s-1) values, sign convention: negative=uptake
        tair: list of air temperature values (deg C)
        tmin, tmax, topt: temperature response parameters (defaults from paper)

    Returns:
        dict with parameter estimates and standard errors.
    """
    from scipy.optimize import curve_fit
    par = np.asarray(par, dtype=float)
    nee = np.asarray(nee, dtype=float)
    tair = np.asarray(tair, dtype=float)
    mask = ~(np.isnan(par) | np.isnan(nee) | np.isnan(tair))
    par, nee, tair = par[mask], nee[mask], tair[mask]
    if len(par) < 10:
        return {"error": "fewer than 10 valid points"}

    def model(X, alpha, beta, E0, Pmax):
        p, t = X
        num = (t - tmin) * (t - tmax)
        den = num - (t - topt) ** 2
        with np.errstate(divide="ignore", invalid="ignore"):
            tscale = np.where(den != 0, num / den, 0.0)
        tscale = np.clip(tscale, 0.0, 1.0)
        R = alpha * np.exp(beta * t)
        denom = Pmax + E0 * p
        gpp = np.where(denom > 0, tscale * E0 * Pmax * p / denom, 0.0)
        return R - gpp

    p0 = [1.0, 0.05, 0.02, 20.0]
    try:
        popt, pcov = curve_fit(model, (par, tair), nee, p0=p0, maxfev=5000)
        perr = np.sqrt(np.diag(pcov))
        pred = model((par, tair), *popt)
        rss = float(np.sum((nee - pred) ** 2))
        rmse = float(np.sqrt(rss / len(nee)))
        return {
            "alpha": round(float(popt[0]), 4),
            "alpha_se": round(float(perr[0]), 4),
            "beta": round(float(popt[1]), 4),
            "beta_se": round(float(perr[1]), 4),
            "E0": round(float(popt[2]), 4),
            "E0_se": round(float(perr[2]), 4),
            "Pmax": round(float(popt[3]), 4),
            "Pmax_se": round(float(perr[3]), 4),
            "rmse": round(rmse, 4),
            "n_obs": int(len(par)),
        }
    except Exception as e:  # noqa: BLE001
        return {"error": str(e)}


@mcp.tool()
def predict_light_response(par: list, tair: list,
                           alpha: float, beta: float,
                           E0: float, Pmax: float,
                           tmin: float = -1.5, tmax: float = 40.0,
                           topt: float = 15.0) -> dict:
    """Predict NEE given PAR, Tair and parameter set.

    Args:
        par: PAR list
        tair: Tair list
        alpha, beta, E0, Pmax: parameters from fit_light_response_curve
        tmin, tmax, topt: temperature response parameters

    Returns:
        dict with predicted NEE list and component R, GPP lists.
    """
    par = np.asarray(par, dtype=float)
    tair = np.asarray(tair, dtype=float)
    num = (tair - tmin) * (tair - tmax)
    den = num - (tair - topt) ** 2
    with np.errstate(divide="ignore", invalid="ignore"):
        tscale = np.where(den != 0, num / den, 0.0)
    tscale = np.clip(tscale, 0.0, 1.0)
    R = alpha * np.exp(beta * tair)
    denom = Pmax + E0 * par
    gpp = np.where(denom > 0, tscale * E0 * Pmax * par / denom, 0.0)
    nee = R - gpp
    return {"NEE_pred": [round(float(x), 4) for x in nee],
            "R": [round(float(x), 4) for x in R],
            "GPP": [round(float(x), 4) for x in gpp]}


# ----------------------------------------------------------------------------
#  Footprint-weighted (heterogeneous) regression
# ----------------------------------------------------------------------------

@mcp.tool()
def fit_heterogeneous_nee(csv_path: str, footprint_suffix: str = "H",
                          land_covers: Optional[list[str]] = None,
                          month: Optional[int] = None) -> dict:
    """Fit a footprint-weighted multivariate regression of observed tower NEE
    against per-land-cover light-response models (paper Eq. 1).

    For each half-hour observation k:  NEE_obs(k) = sum_i NEE_i(k) * Omega_i(k),
    where Omega_i is the footprint influence weight and NEE_i is each land
    cover's flux predicted from PAR and Tair. This routine returns the
    least-squares solution for per-land-cover constant fluxes (a baseline)
    plus residual statistics.

    Args:
        csv_path: Flux CSV with footprint columns.
        footprint_suffix: "H", "Klj", or "ZM".
        land_covers: List of land-cover names. If None, uses all.
        month: Optional month (1-12) to restrict to.

    Returns:
        dict with per-land-cover constant flux estimates, R^2, RMSE, n_obs.
    """
    import pandas as pd
    df = pd.read_csv(csv_path, parse_dates=["datetime"])
    if month is not None:
        df = df[df["datetime"].dt.month == month]
    fp_cols = [c for c in df.columns if c.endswith("_" + footprint_suffix)]
    if land_covers is not None:
        fp_cols = [c for c in fp_cols if c.rsplit("_", 1)[0] in land_covers]
    sub = df.dropna(subset=["co2"] + fp_cols)
    if len(sub) < 10:
        return {"error": "fewer than 10 valid observations"}
    X = sub[fp_cols].values
    y = sub["co2"].values
    coef, res, rank, sv = np.linalg.lstsq(X, y, rcond=None)
    pred = X @ coef
    ss_tot = float(np.sum((y - y.mean()) ** 2))
    ss_res = float(np.sum((y - pred) ** 2))
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else float("nan")
    rmse = float(np.sqrt(ss_res / len(y)))
    return {
        "land_cover_flux": {fp_cols[i].rsplit("_", 1)[0]: round(float(coef[i]), 4)
                            for i in range(len(coef))},
        "r2": round(r2, 4),
        "rmse": round(rmse, 4),
        "n_obs": int(len(y)),
        "footprint_suffix": footprint_suffix,
        "month": month,
    }


# ----------------------------------------------------------------------------
#  Gap-filling
# ----------------------------------------------------------------------------

@mcp.tool()
def gap_fill_mds(csv_path: str, target_col: str = "co2",
                 datetime_col: str = "datetime") -> dict:
    """Marginal Distribution Sampling (MDS) gap-filling, simple variant.

    For each missing target value at time t:
      - If observation is missing, fill with the mean of valid observations
        within +/- 7 days at the same hour-of-day (mean diurnal course).
      - If still missing, expand to +/- 14 days, then fill with hour-of-day mean.

    Args:
        csv_path: Flux CSV.
        target_col: Column to gap-fill (e.g., co2).
        datetime_col: Timestamp column.

    Returns:
        dict with output_path, n_filled, mean_of_filled, mean_of_observed.
    """
    import pandas as pd
    df = pd.read_csv(csv_path, parse_dates=[datetime_col])
    df = df.sort_values(datetime_col).reset_index(drop=True)
    df["_doy"] = df[datetime_col].dt.dayofyear
    df["_hod"] = df[datetime_col].dt.hour + df[datetime_col].dt.minute / 60.0

    obs = df[target_col].copy()
    filled = obs.copy()
    n_orig_missing = int(obs.isna().sum())

    # window-based MDS
    for w_days in [7, 14, 30]:
        miss_idx = filled.index[filled.isna()].tolist()
        for i in miss_idx:
            t = df.loc[i, datetime_col]
            hod = df.loc[i, "_hod"]
            mask = (np.abs((df[datetime_col] - t).dt.total_seconds()) / 86400.0 <= w_days) \
                   & (np.abs(df["_hod"] - hod) <= 1.0) & (~obs.isna())
            if mask.sum() >= 3:
                filled.loc[i] = float(obs[mask].mean())
        if int(filled.isna().sum()) == 0:
            break

    # last resort: hour-of-day mean
    miss_idx = filled.index[filled.isna()].tolist()
    for i in miss_idx:
        hod = df.loc[i, "_hod"]
        mask = (np.abs(df["_hod"] - hod) <= 1.0) & (~obs.isna())
        if mask.sum() >= 1:
            filled.loc[i] = float(obs[mask].mean())

    df[target_col + "_f"] = filled
    out_path = csv_path.replace(".csv", f"_{target_col}_filled.csv")
    df.drop(columns=["_doy", "_hod"]).to_csv(out_path, index=False)
    return {
        "output_path": out_path,
        "original_missing": n_orig_missing,
        "filled": n_orig_missing - int(filled.isna().sum()),
        "still_missing": int(filled.isna().sum()),
        "mean_observed": round(float(obs.mean(skipna=True)), 4),
        "mean_after_fill": round(float(filled.mean()), 4),
    }


@mcp.tool()
def evaluate_gapfill_rmse(true_values: list, predicted_values: list) -> dict:
    """RMSE / MAE / bias between true and predicted values.

    Args:
        true_values, predicted_values: aligned lists.

    Returns:
        dict with rmse, mae, bias, n.
    """
    t = np.asarray(true_values, dtype=float)
    p = np.asarray(predicted_values, dtype=float)
    m = ~(np.isnan(t) | np.isnan(p))
    t, p = t[m], p[m]
    if len(t) == 0:
        return {"error": "no overlapping values"}
    return {
        "rmse": round(float(np.sqrt(np.mean((t - p) ** 2))), 4),
        "mae": round(float(np.mean(np.abs(t - p))), 4),
        "bias": round(float(np.mean(p - t)), 4),
        "n": int(len(t)),
    }


# ----------------------------------------------------------------------------
#  Aggregation & scaling
# ----------------------------------------------------------------------------

@mcp.tool()
def aggregate_to_monthly(csv_path: str, value_col: str,
                         datetime_col: str = "datetime",
                         year: Optional[int] = None,
                         conversion: str = "umol_co2_per_s_to_gC_per_m2") -> dict:
    """Aggregate half-hourly flux observations into monthly totals.

    Args:
        csv_path: CSV with half-hourly flux data.
        value_col: Column to aggregate (e.g., co2_f).
        datetime_col: Timestamp column.
        year: Optional year restriction.
        conversion: One of:
            - "umol_co2_per_s_to_gC_per_m2": multiply each half-hour value
              (umol m-2 s-1) by 1800 s * 12e-6 g/umol → gC m-2 per half-hour,
              then sum to get gC m-2 per month.
            - "umol_ch4_per_s_to_gC_per_m2": same but with CH4 carbon mass.
            - "none": just sum.

    Returns:
        dict with year-month totals in gC m-2, plus n_obs per month.
    """
    import pandas as pd
    df = pd.read_csv(csv_path, parse_dates=[datetime_col])
    if year is not None:
        df = df[df[datetime_col].dt.year == year]
    if conversion == "umol_co2_per_s_to_gC_per_m2":
        scale = 1800.0 * 12e-6
    elif conversion == "umol_ch4_per_s_to_gC_per_m2":
        scale = 1800.0 * 12e-6  # carbon mass, same factor
    else:
        scale = 1.0
    df["_ym"] = df[datetime_col].dt.strftime("%Y-%m")
    out = []
    for ym, g in df.groupby("_ym"):
        v = g[value_col].dropna().values
        out.append({
            "year_month": ym,
            "n_obs": int(len(v)),
            "monthly_total_gC_per_m2": round(float(v.sum() * scale), 4),
            "mean_flux_umol_per_s": round(float(v.mean()) if len(v) else 0.0, 4),
        })
    return {"value_col": value_col, "conversion": conversion, "monthly": out}


@mcp.tool()
def scale_to_region(monthly_flux_gC_per_m2: dict,
                    land_cover_areas_km2: dict) -> dict:
    """Scale per-area monthly fluxes (gC m-2) to total regional carbon
    budgets (Mg C) by multiplying by per-land-cover area.

    Args:
        monthly_flux_gC_per_m2: {land_cover: {year_month: gC_m-2}}.
        land_cover_areas_km2: {land_cover: area_km2} mapping.

    Returns:
        dict with per-month total Mg C, per-land-cover totals, grand total.
        1 km^2 * 1 g/m2 = 1e6 g = 1 Mg, so simply multiply.
    """
    out: dict = {"per_lc_total_MgC": {}, "per_month_total_MgC": {},
                 "grand_total_MgC": 0.0}
    for lc, monthly in monthly_flux_gC_per_m2.items():
        a = land_cover_areas_km2.get(lc, 0.0)
        lc_total = 0.0
        for ym, g_per_m2 in monthly.items():
            mg = g_per_m2 * a  # Mg C per month
            out["per_month_total_MgC"][ym] = (out["per_month_total_MgC"]
                                              .get(ym, 0.0) + mg)
            lc_total += mg
        out["per_lc_total_MgC"][lc] = round(float(lc_total), 2)
        out["grand_total_MgC"] += lc_total
    out["per_month_total_MgC"] = {k: round(float(v), 2)
                                  for k, v in out["per_month_total_MgC"].items()}
    out["grand_total_MgC"] = round(float(out["grand_total_MgC"]), 2)
    return out


@mcp.tool()
def co2eq_total(co2_MgC: float, ch4_MgC: float, gwp_ch4: float = 28.0) -> dict:
    """Convert separate CO2 carbon and CH4 carbon budgets into a single
    CO2-equivalent budget (in Mg C CO2-eq).

    The paper uses: 1 g CH4-C = (16 g CH4 / 12 g C) * gwp_ch4 g CO2-eq /
    (44 g CO2 / 12 g C) g CO2-C = (16/44) * gwp_ch4 g CO2-C-eq per g CH4-C.
    Simplifying: factor = (44/12) * gwp_ch4 * (12/44) -> per the paper's
    description, they report CH4 alongside NEE in CO2-eq by multiplying by
    a factor of 28.

    Args:
        co2_MgC: CO2 carbon budget in Mg C (negative = uptake).
        ch4_MgC: CH4 carbon budget in Mg C (positive = emission).
        gwp_ch4: GWP of CH4 (default 28, matches paper).

    Returns:
        dict with CO2_MgC_CO2eq, CH4_MgC_CO2eq, net_MgC_CO2eq.
    """
    co2_eq = co2_MgC  # already C-mass; emissions/uptake of CO2-C
    ch4_eq = ch4_MgC * gwp_ch4
    return {
        "CO2_MgC_CO2eq": round(float(co2_eq), 2),
        "CH4_MgC_CO2eq": round(float(ch4_eq), 2),
        "net_MgC_CO2eq": round(float(co2_eq + ch4_eq), 2),
        "gwp_ch4_used": gwp_ch4,
    }


# ----------------------------------------------------------------------------
#  Plotting (each tool produces a single PNG)
# ----------------------------------------------------------------------------

@mcp.tool()
def plot_footprint_comparison(csv_path: str, land_cover: str,
                              models: list[str], output_path: str) -> dict:
    """Scatterplot of per-observation footprint influence between two models
    for one land-cover class. Replicates paper Fig. 2 style.

    Args:
        csv_path: Flux CSV.
        land_cover: Land-cover name (e.g., 'lichen_tundra').
        models: list of two suffixes (e.g., ['Klj', 'H']).
        output_path: Output PNG path.

    Returns:
        dict with output_path on success.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import pandas as pd
    df = pd.read_csv(csv_path)
    a, b = models[0], models[1]
    ca, cb = f"{land_cover}_{a}", f"{land_cover}_{b}"
    if ca not in df.columns or cb not in df.columns:
        return {"error": f"columns missing: {ca}, {cb}"}
    x = df[ca].values * 100
    y = df[cb].values * 100
    m = ~(np.isnan(x) | np.isnan(y))
    x, y = x[m], y[m]
    fig, ax = plt.subplots(figsize=(5, 5))
    ax.scatter(x, y, s=4, alpha=0.4, color="black")
    lim = max(x.max() if len(x) else 50, y.max() if len(y) else 50, 5)
    ax.plot([0, lim], [0, lim], "r--", lw=1)
    ax.set_xlabel(f"{a} model footprint influence (%)")
    ax.set_ylabel(f"{b} model footprint influence (%)")
    ax.set_title(f"Footprint comparison — {land_cover}")
    ax.set_xlim(0, lim)
    ax.set_ylim(0, lim)
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path, "n_points": int(len(x))}


@mcp.tool()
def plot_monthly_nee_by_landcover(monthly_data: dict, output_path: str,
                                  title: str = "Monthly NEE by land cover") -> dict:
    """Bar chart of monthly NEE budget by land-cover type. Replicates paper
    Fig. 4 / Fig. 6 style.

    Args:
        monthly_data: {land_cover: {year_month: total_MgC}}.
        output_path: Output PNG path.
        title: Plot title.

    Returns:
        dict with output_path.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    months_set = set()
    for v in monthly_data.values():
        months_set.update(v.keys())
    months = sorted(months_set)
    lcs = list(monthly_data.keys())
    fig, ax = plt.subplots(figsize=(8, 5))
    width = 0.8 / max(len(lcs), 1)
    cmap = plt.get_cmap("tab10")
    for i, lc in enumerate(lcs):
        vals = [monthly_data[lc].get(m, 0.0) for m in months]
        x = np.arange(len(months)) + i * width
        ax.bar(x, vals, width=width, label=lc, color=cmap(i % 10))
    ax.set_xticks(np.arange(len(months)) + width * len(lcs) / 2 - width / 2)
    ax.set_xticklabels(months, rotation=45, ha="right")
    ax.set_ylabel("Monthly NEE budget (Mg C / month)")
    ax.set_title(title)
    ax.axhline(0, color="black", lw=0.5)
    ax.legend(fontsize=8, ncol=2)
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path, "n_months": len(months),
            "n_land_covers": len(lcs)}


@mcp.tool()
def plot_homogeneous_vs_heterogeneous(homo_total_MgC: float,
                                      hetero_total_MgC: float,
                                      ch4_total_MgC_eq: float,
                                      output_path: str,
                                      title: str = "Carbon budget comparison"
                                      ) -> dict:
    """Bar chart comparing homogeneous vs heterogeneous growing-season
    carbon budgets (CO2 sink and CH4 emission). Replicates paper Fig. 7
    style.

    Args:
        homo_total_MgC: NEE total under homogeneous-landscape assumption.
        hetero_total_MgC: NEE total under heterogeneous footprint-weighted method.
        ch4_total_MgC_eq: CH4 total in CO2-equivalent Mg C.
        output_path: Output PNG path.
        title: Plot title.

    Returns:
        dict with output_path.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(7, 5))
    cats = ["Homogeneous\nNEE", "Heterogeneous\nNEE", "Heterogeneous\nCH4 (CO2-eq)",
            "Net (Het. NEE\n+ CH4)"]
    vals = [homo_total_MgC, hetero_total_MgC, ch4_total_MgC_eq,
            hetero_total_MgC + ch4_total_MgC_eq]
    colors = ["#7f7f7f", "#1f77b4", "#d62728", "black"]
    ax.bar(cats, vals, color=colors)
    for i, v in enumerate(vals):
        ax.text(i, v + (200 if v >= 0 else -800), f"{v:,.0f}",
                ha="center", fontsize=9)
    ax.axhline(0, color="black", lw=0.6)
    ax.set_ylabel("Growing season budget (Mg C [CO2-eq])")
    ax.set_title(title)
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path}


@mcp.tool()
def plot_nee_time_series(csv_path: str, output_path: str,
                         datetime_col: str = "datetime",
                         nee_col: str = "co2",
                         ch4_col: Optional[str] = "ch4") -> dict:
    """Plot the half-hourly NEE (and optionally CH4) time series.

    Args:
        csv_path: Flux CSV.
        output_path: Output PNG path.
        datetime_col: timestamp column.
        nee_col: NEE column name.
        ch4_col: optional CH4 column.

    Returns:
        dict with output_path.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import pandas as pd
    df = pd.read_csv(csv_path, parse_dates=[datetime_col])
    nrows = 2 if ch4_col and ch4_col in df.columns else 1
    fig, axes = plt.subplots(nrows, 1, figsize=(10, 3 * nrows), sharex=True)
    if nrows == 1:
        axes = [axes]
    axes[0].scatter(df[datetime_col], df[nee_col], s=2, alpha=0.5,
                    color="green")
    axes[0].axhline(0, color="black", lw=0.4)
    axes[0].set_ylabel("NEE (umol m$^{-2}$ s$^{-1}$)")
    axes[0].set_title("Half-hourly carbon fluxes — Y-K Delta tower")
    if nrows == 2:
        axes[1].scatter(df[datetime_col], df[ch4_col], s=2, alpha=0.5,
                        color="brown")
        axes[1].axhline(0, color="black", lw=0.4)
        axes[1].set_ylabel("CH$_4$ (umol m$^{-2}$ s$^{-1}$)")
    axes[-1].set_xlabel("Date")
    fig.autofmt_xdate()
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path, "n_obs": int(len(df))}


# ----------------------------------------------------------------------------
#  Generic stats helpers
# ----------------------------------------------------------------------------

@mcp.tool()
def descriptive_stats(values: list) -> dict:
    """Mean, std, min, max, median, percentiles for a numeric list."""
    arr = np.asarray(values, dtype=float)
    arr = arr[~np.isnan(arr)]
    if arr.size == 0:
        return {"error": "no valid values"}
    return {
        "count": int(arr.size),
        "mean": round(float(arr.mean()), 4),
        "std": round(float(arr.std(ddof=1)) if arr.size > 1 else 0.0, 4),
        "min": round(float(arr.min()), 4),
        "max": round(float(arr.max()), 4),
        "median": round(float(np.median(arr)), 4),
        "p10": round(float(np.percentile(arr, 10)), 4),
        "p25": round(float(np.percentile(arr, 25)), 4),
        "p75": round(float(np.percentile(arr, 75)), 4),
        "p90": round(float(np.percentile(arr, 90)), 4),
    }


@mcp.tool()
def correlation(x: list, y: list) -> dict:
    """Pearson and Spearman correlation between two lists."""
    from scipy.stats import pearsonr, spearmanr
    a = np.asarray(x, dtype=float)
    b = np.asarray(y, dtype=float)
    m = ~(np.isnan(a) | np.isnan(b))
    a, b = a[m], b[m]
    if a.size < 3:
        return {"error": "fewer than 3 valid pairs"}
    pr, pp = pearsonr(a, b)
    sr, sp = spearmanr(a, b)
    return {
        "pearson_r": round(float(pr), 4),
        "pearson_p": round(float(pp), 6),
        "spearman_rho": round(float(sr), 4),
        "spearman_p": round(float(sp), 6),
        "n": int(a.size),
    }


@mcp.tool()
def credible_interval(samples: list, level: float = 0.89) -> dict:
    """Highest-density credible interval for a sample of values.

    Args:
        samples: list of posterior or bootstrap samples.
        level: credible mass (default 0.89, matches paper).

    Returns:
        dict with median, lower, upper bounds and width.
    """
    arr = np.asarray(samples, dtype=float)
    arr = arr[~np.isnan(arr)]
    if arr.size < 10:
        return {"error": "fewer than 10 samples"}
    arr_sorted = np.sort(arr)
    n = len(arr_sorted)
    width = int(np.floor(level * n))
    if width < 1:
        return {"error": "level too low for sample size"}
    diffs = arr_sorted[width:] - arr_sorted[:n - width]
    j = int(np.argmin(diffs))
    return {
        "level": level,
        "median": round(float(np.median(arr_sorted)), 4),
        "lower": round(float(arr_sorted[j]), 4),
        "upper": round(float(arr_sorted[j + width]), 4),
        "n_samples": int(n),
    }


if __name__ == "__main__":
    mcp.run(transport="stdio")

"""Database retrieval tools.

Thin placeholders for external-database queries. Implementations are filled
in at task-execution time by the agent's runtime. Each stub documents the
target database and the intended query semantics.
"""
from typing import Any


def websearch(query: str, max_results: int = 10) -> list[dict]:
    """Generic web search (Google/Bing/DuckDuckGo via a scraping backend).

    Use for: locating a dataset DOI, finding a paper's supplementary URL,
    or resolving an ambiguous reference. Returns a list of {title, url,
    snippet} dicts.
    """
    pass  # heavy: requires a search API key or headless browser


def fetch_url(url: str, timeout: int = 30) -> bytes:
    """HTTP GET with redirects. Used to download a CSV/PDF/JSON from a
    known URL (e.g., Zenodo record, GitHub raw file, journal OA page)."""
    pass  # heavy: network + retry/backoff


def query_doi(doi: str) -> dict:
    """Resolve a DOI to a Crossref metadata record + OA full-text URL."""
    pass  # heavy: REST client


def query_ameriflux_site(site_id: str) -> dict:
    """AmeriFlux/FLUXNET site metadata lookup (PI, biome, IGBP, lat/lon).
    Used to locate the metadata for a given EC tower site ID."""
    pass  # heavy: AmeriFlux REST API


def query_zenodo(record_id: str) -> dict:
    """Zenodo record metadata + file list lookup. Used to find data files
    associated with a published paper."""
    pass  # heavy: Zenodo API


def query_modis(product: str, lat: float, lon: float,
                start_date: str, end_date: str) -> dict:
    """ORNL DAAC MODIS subset web service. Returns time series of NDVI/EVI/LAI
    for a single point. Used for vegetation indices co-located with EC towers."""
    pass  # heavy: REST client + retry

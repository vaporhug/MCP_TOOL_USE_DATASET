#!/usr/bin/env python3
"""Bayesian unmixing tools for tundra EC flux analysis.

Implements the Ludwig 2024 BG footprint-weighted unmixing model. The
three functions in this file use DIFFERENT inference paths; please
read the per-function docstrings before interpreting reported
intervals:

1. ``bayesian_unmixing_mcmc``: linear Eq. 1 footprint unmixing with
   PyMC NUTS MCMC when PyMC is available (falls back to a NumPy
   Metropolis-within-Gibbs sampler otherwise). Reports posterior mean
   and 89% HDI from MCMC draws plus R-hat / ESS diagnostics.
2. ``heterogeneous_nee_bayesian``: per-land-cover paper-Eqs.-2-5
   light-response fit using **two-stage MAP optimisation + bootstrap**
   (scipy.optimize.minimize + 120 bootstrap resamples), regardless of
   PyMC availability. Reports posterior mean and 89% **bootstrap
   percentile** interval (NOT posterior HDI). The ``_meta.backend``
   field labels which backend was used.
3. ``joint_heterogeneous_nee_unmixing``: paper-Eq. 1 joint NEE
   unmixing across all land covers simultaneously. Default backend is
   ``"map_bootstrap"`` (lightweight two-stage MAP + bootstrap, 89%
   percentile CI); the heavy PyMC NUTS path matching paper JAGS
   settings is opt-in via ``backend="pymc_nuts"``.

All three report 89% intervals (Ludwig 2024 BG convention); the
interval TYPE (HDI vs percentile) is recorded in ``_meta.interval_type``
or implied by ``_meta.backend``.
"""
from __future__ import annotations

from typing import Optional
import math

import numpy as np
import pandas as pd

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Tundra_Bayesian_Unmixing")


# ---------------------------------------------------------------------------
#  Backend detection
# ---------------------------------------------------------------------------

def _has_pymc() -> bool:
    try:  # pragma: no cover - import probe
        import pymc  # noqa: F401
        return True
    except Exception:  # noqa: BLE001
        return False


# ---------------------------------------------------------------------------
#  Helpers
# ---------------------------------------------------------------------------

def _hdi(samples: np.ndarray, ci: float) -> tuple[float, float]:
    """Highest-density interval at the requested credible mass."""
    s = np.sort(np.asarray(samples, dtype=float).ravel())
    n = s.size
    if n < 2:
        return float("nan"), float("nan")
    k = int(np.floor(ci * n))
    if k < 1:
        return float("nan"), float("nan")
    widths = s[k:] - s[: n - k]
    j = int(np.argmin(widths))
    return float(s[j]), float(s[j + k])


def _effective_sample_size(x: np.ndarray) -> float:
    """Crude single-chain ESS via initial positive-sequence autocorrelation."""
    x = np.asarray(x, dtype=float).ravel()
    n = x.size
    if n < 4:
        return float(n)
    x = x - x.mean()
    var = float(np.dot(x, x) / n)
    if var <= 0:
        return float(n)
    # autocovariance via FFT for speed
    f = np.fft.fft(x, n=2 * n)
    acov = np.real(np.fft.ifft(f * np.conj(f)))[:n] / n
    rho = acov / acov[0]
    # initial positive sequence
    tau = 1.0
    for k in range(1, n):
        if rho[k] <= 0:
            break
        tau += 2.0 * rho[k]
    return float(max(1.0, n / tau))


def _split_rhat(chains: np.ndarray) -> float:
    """Split-chain R-hat over an (n_chains, n_draws) array."""
    chains = np.asarray(chains, dtype=float)
    if chains.ndim != 2 or chains.shape[1] < 4:
        return float("nan")
    m, n = chains.shape
    half = n // 2
    split = np.concatenate([chains[:, :half], chains[:, half:2 * half]], axis=0)
    M, N = split.shape
    chain_means = split.mean(axis=1)
    chain_vars = split.var(axis=1, ddof=1)
    B = N * chain_means.var(ddof=1)
    W = chain_vars.mean()
    if W <= 0:
        return float("nan")
    var_hat = (N - 1) / N * W + B / N
    return float(math.sqrt(var_hat / W))


def _load_unmixing_design(csv_path: str, flux_col: str,
                          footprint_suffix: str,
                          land_covers: Optional[list[str]] = None,
                          month: Optional[int] = None
                          ) -> tuple[np.ndarray, np.ndarray, list[str]]:
    """Return (X, y, lc_names) for the unmixing regression.

    X is the per-observation footprint-weight matrix (rows sum to ~1),
    y is the observed flux, and lc_names is the column ordering.
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    suffix = "_" + footprint_suffix
    fp_cols = [c for c in df.columns if c.endswith(suffix)]
    if land_covers is not None:
        fp_cols = [c for c in fp_cols if c.rsplit("_", 1)[0] in land_covers]
    if not fp_cols:
        raise ValueError(f"no footprint columns with suffix {suffix}")
    if month is not None and "datetime" in df.columns:
        dt = pd.to_datetime(df["datetime"], errors="coerce")
        df = df[dt.dt.month == month]
    sub = df.dropna(subset=[flux_col] + fp_cols)
    X = sub[fp_cols].to_numpy(dtype=float)
    y = sub[flux_col].to_numpy(dtype=float)
    # Renormalise weights so each row sums to 1 (keeps interpretation as
    # per-land-cover flux). Falls back to raw weights if the row sum is 0.
    rsum = X.sum(axis=1, keepdims=True)
    safe = np.where(rsum > 0, rsum, 1.0)
    X = X / safe
    lc_names = [c.rsplit("_", 1)[0] for c in fp_cols]
    return X, y, lc_names


# ---------------------------------------------------------------------------
#  NumPy fallback samplers
# ---------------------------------------------------------------------------

def _gibbs_unmixing(X: np.ndarray, y: np.ndarray,
                    draws: int, tune: int,
                    prior_sd: float, n_chains: int = 2,
                    seed: int = 0) -> np.ndarray:
    """Conjugate Gibbs sampler for y = X beta + Normal(0, sigma) with
    independent Normal(0, prior_sd) priors on beta and Half-Cauchy(2.5)
    on sigma. Returns array of shape (n_chains, draws, k).
    """
    rng = np.random.default_rng(seed)
    n, k = X.shape
    XtX = X.T @ X
    prior_prec = np.eye(k) / (prior_sd ** 2)
    out = np.empty((n_chains, draws, k), dtype=float)
    for c in range(n_chains):
        # initial beta via OLS, sigma via residuals
        beta, *_ = np.linalg.lstsq(X, y, rcond=None)
        resid = y - X @ beta
        sigma2 = float(max(np.var(resid), 1e-6))
        total = tune + draws
        store = 0
        for t in range(total):
            prec = XtX / sigma2 + prior_prec
            cov = np.linalg.inv(prec)
            mean = cov @ (X.T @ y / sigma2)
            # cholesky sample
            L = np.linalg.cholesky(cov + 1e-12 * np.eye(k))
            beta = mean + L @ rng.standard_normal(k)
            resid = y - X @ beta
            # half-cauchy prior on sigma -> sample sigma2 via slice on log
            # posterior. Use a simple Metropolis step instead.
            ss = float(resid @ resid)
            shape = n / 2.0
            scale = ss / 2.0
            sigma2_new = 1.0 / rng.gamma(shape=shape, scale=1.0 / max(scale, 1e-12))
            # half-cauchy(2.5) prior factor
            log_ratio = (
                -0.5 * math.log(1 + sigma2_new / (2.5 ** 2))
                + 0.5 * math.log(1 + sigma2 / (2.5 ** 2))
            )
            if math.log(rng.random()) < log_ratio:
                sigma2 = sigma2_new
            if t >= tune:
                out[c, store] = beta
                store += 1
    return out


def _mh_light_response(par: np.ndarray, nee: np.ndarray,
                       draws: int, tune: int,
                       seed: int = 0, n_chains: int = 2
                       ) -> tuple[np.ndarray, list[str]]:
    """Random-walk Metropolis for the rectangular hyperbola
    NEE = (alpha * PAR * GPP_max) / (alpha * PAR + GPP_max) + Reco + noise.
    Returns (n_chains, draws, 4) for [alpha, GPP_max, Reco, sigma].
    """
    rng = np.random.default_rng(seed)
    par = np.asarray(par, dtype=float)
    nee = np.asarray(nee, dtype=float)

    def loglik(theta: np.ndarray) -> float:
        alpha, gpp_max, reco, sigma = theta
        if alpha <= 0 or gpp_max <= 0 or sigma <= 0:
            return -np.inf
        denom = alpha * par + gpp_max
        # NEE convention (paper): negative = uptake; (-GPP + Reco)
        gpp = (alpha * par * gpp_max) / np.where(denom > 0, denom, 1.0)
        mu = -gpp + reco
        resid = nee - mu
        ll = -0.5 * np.sum((resid / sigma) ** 2) - len(resid) * math.log(sigma)
        # priors: half-normal on positives, normal(0, 5) on reco
        ll += -0.5 * (alpha / 1.0) ** 2
        ll += -0.5 * (gpp_max / 30.0) ** 2
        ll += -0.5 * (reco / 5.0) ** 2
        ll += -0.5 * math.log(1 + (sigma / 2.5) ** 2)
        return float(ll)

    out = np.empty((n_chains, draws, 4))
    names = ["alpha", "GPP_max", "Reco", "sigma"]
    for c in range(n_chains):
        theta = np.array([0.05, 20.0, 1.0, max(float(np.std(nee)), 0.5)])
        step = np.array([0.01, 2.0, 0.2, 0.2])
        cur_ll = loglik(theta)
        store = 0
        accepts = 0
        for t in range(tune + draws):
            proposal = theta + step * rng.standard_normal(4)
            new_ll = loglik(proposal)
            if math.log(rng.random()) < new_ll - cur_ll:
                theta = proposal
                cur_ll = new_ll
                accepts += 1
            # adapt step during tune
            if t < tune and (t + 1) % 50 == 0:
                rate = accepts / 50.0
                step *= 1.0 + 0.3 * (rate - 0.30)
                step = np.clip(step, 1e-5, None)
                accepts = 0
            if t >= tune:
                out[c, store] = theta
                store += 1
    return out, names


# ---------------------------------------------------------------------------
#  Public MCP tools
# ---------------------------------------------------------------------------

@mcp.tool()
def bayesian_unmixing_mcmc(csv_path: str, flux_col: str,
                           footprint_suffix: str = "H",
                           draws: int = 1000, tune: int = 500,
                           ci: float = 0.89,
                           prior_sd: float = 20.0,
                           land_covers: Optional[list[str]] = None,
                           month: Optional[int] = None,
                           non_negative_classes: Optional[list[str]] = None,
                           seed: int = 0,
                           return_samples: bool = False) -> dict:
    """Bayesian linear unmixing of EC tower flux into per-land-cover
    components via PyMC NUTS, with 89% credible intervals.

    Model (Ludwig 2024 BG, Eq. 1, Bayesian form):

        flux_obs(k) = sum_i Omega_i(k) * flux_i + epsilon(k)
        flux_i      ~ Normal(0, prior_sd)             (vegetated classes)
        flux_i      ~ HalfNormal(0, prior_sd)         (classes listed in
                                                       ``non_negative_classes``,
                                                       i.e. paper's CH4 emitter
                                                       constraint per Sect. 2.4.2:
                                                       degraded, edge_degraded,
                                                       fen1/fen2/wetland, water)
        epsilon(k)  ~ Normal(0, sigma),  sigma ~ HalfCauchy(2.5)

    Omega_i(k) is the per-observation footprint influence (rows are
    re-normalised to sum to one). Posterior 89% HDI matches the
    convention used in the Ludwig 2024 BG paper.

    Args:
        csv_path: EC flux CSV with footprint columns suffixed _ZM/_H/_Klj.
        flux_col: Observed flux column (e.g., "co2" or "ch4").
        footprint_suffix: "H", "Klj", or "ZM".
        draws: posterior draws per chain.
        tune: warmup / adaptation steps.
        ci: credible interval mass (default 0.89, paper convention).
        prior_sd: Normal prior SD on per-land-cover flux.
        land_covers: optional restriction to a subset of land-cover names.
        month: optional month restriction (1-12).
        non_negative_classes: optional list of land-cover names whose flux
            posterior is constrained non-negative (HalfNormal prior) — used
            to encode the paper Sect. 2.4.2 "no CH4 uptake" constraint on
            degraded, edge_degraded, fen1/fen2/wetland, water when fitting
            CH4. If None, all classes get the symmetric Normal prior.
        seed: RNG seed.
        return_samples: Include flattened posterior draws per land-cover so
            tools/tundra_flux.py::scale_posterior_flux_draws_to_region can
            propagate the posterior into regional budget intervals.

    Returns:
        dict mapping each land-cover name to
        {mean, ci_low, ci_high, n_eff, r_hat}, plus a top-level
        `_meta` block with backend, n_obs, sigma posterior summary,
        ci level, and footprint suffix.
    """
    X, y, lc_names = _load_unmixing_design(
        csv_path, flux_col, footprint_suffix,
        land_covers=land_covers, month=month,
    )
    if len(y) < 10:
        return {"error": "fewer than 10 valid observations"}

    backend = "pymc" if _has_pymc() else "numpy_gibbs"
    sigma_summary: dict = {}

    if backend == "pymc":
        import pymc as pm
        import pytensor.tensor as pt
        import arviz as az
        nn_set = set(non_negative_classes or [])
        nn_mask = np.array([name in nn_set for name in lc_names])
        with pm.Model() as model:  # noqa: F841 - context manager
            if not nn_mask.any():
                beta = pm.Normal("beta", mu=0.0, sigma=prior_sd,
                                 shape=X.shape[1])
            else:
                # Construct per-class prior: HalfNormal for non-negative
                # classes (paper CH4 no-uptake constraint), Normal for the
                # rest. We stack two RVs and gather by class index.
                beta_pos_raw = pm.HalfNormal("beta_pos", sigma=prior_sd,
                                             shape=int(nn_mask.sum()))
                beta_free    = pm.Normal("beta_free", mu=0.0, sigma=prior_sd,
                                         shape=int((~nn_mask).sum()))
                # Map back into the original order
                pos_idx = np.where(nn_mask)[0]
                free_idx = np.where(~nn_mask)[0]
                beta_full = pt.zeros(X.shape[1])
                beta_full = pt.set_subtensor(beta_full[pos_idx], beta_pos_raw)
                beta_full = pt.set_subtensor(beta_full[free_idx], beta_free)
                beta = pm.Deterministic("beta", beta_full)
            sigma = pm.HalfCauchy("sigma", beta=2.5)
            mu = pm.math.dot(X, beta)
            pm.Normal("obs", mu=mu, sigma=sigma, observed=y)
            idata = pm.sample(
                draws=draws, tune=tune, chains=2, cores=1,
                random_seed=seed, target_accept=0.9,
                progressbar=False, return_inferencedata=True,
            )
        beta_post = idata.posterior["beta"].values  # (chains, draws, k)
        sigma_post = idata.posterior["sigma"].values
        ess = az.ess(idata).beta.values
        rhat = az.rhat(idata).beta.values
        sigma_summary = {
            "mean": round(float(sigma_post.mean()), 4),
            "ci_low": round(float(_hdi(sigma_post, ci)[0]), 4),
            "ci_high": round(float(_hdi(sigma_post, ci)[1]), 4),
        }
    else:
        # NumPy Gibbs fallback (no PyMC available). The conjugate Gibbs
        # sampler used here does NOT support the HalfNormal non_negative
        # prior — we apply a hard post-sample clamp to >= 0 for those
        # classes and record this in _meta.non_negative_classes_enforced
        # so callers cannot silently get unconstrained CH4 emissions.
        post = _gibbs_unmixing(X, y, draws=draws, tune=tune,
                               prior_sd=prior_sd, seed=seed)
        beta_post = post  # (chains, draws, k)
        nn_set = set(non_negative_classes or [])
        if nn_set:
            for i, name in enumerate(lc_names):
                if name in nn_set:
                    beta_post[:, :, i] = np.maximum(beta_post[:, :, i], 0.0)
        ess = np.array([
            _effective_sample_size(beta_post[:, :, i].ravel())
            for i in range(beta_post.shape[2])
        ])
        rhat = np.array([
            _split_rhat(beta_post[:, :, i]) for i in range(beta_post.shape[2])
        ])

    results: dict = {}
    for i, name in enumerate(lc_names):
        flat = beta_post[:, :, i].ravel()
        lo, hi = _hdi(flat, ci)
        results[name] = {
            "mean": round(float(np.mean(flat)), 4),
            "ci_low": round(float(lo), 4),
            "ci_high": round(float(hi), 4),
            "n_eff": round(float(ess[i]), 1),
            "r_hat": round(float(rhat[i]), 4),
        }

    results["_meta"] = {
        "backend": backend,
        "n_obs": int(len(y)),
        "n_land_covers": len(lc_names),
        "footprint_suffix": footprint_suffix,
        "flux_col": flux_col,
        "ci_level": ci,
        "interval_type": ("posterior_hdi" if backend == "pymc"
                          else "posterior_hdi_numpy_gibbs"),
        "non_negative_classes_enforced": (
            list(non_negative_classes or []) if backend == "pymc"
            else ("post_hoc_clamp:" + ",".join(non_negative_classes or [])
                  if non_negative_classes else "none")
        ),
        "draws_per_chain": draws,
        "tune": tune,
        "chains": 2,
        "prior_sd": prior_sd,
        "sigma_posterior": sigma_summary,
        "land_cover_order": lc_names,
    }
    if return_samples:
        results["_posterior_samples"] = {
            name: [round(float(x), 8) for x in beta_post[:, :, i].ravel()]
            for i, name in enumerate(lc_names)
        }
    return results


@mcp.tool()
def light_response_bayesian(par: list, nee: list, tair: list,
                            draws: int = 1000, tune: int = 500,
                            ci: float = 0.89, seed: int = 0) -> dict:
    """Bayesian fit of the rectangular-hyperbola light-response model:

        NEE = -(alpha * PAR * GPP_max) / (alpha * PAR + GPP_max) + Reco + eps

    Returns posterior mean and 89% HDI for alpha, GPP_max and Reco
    (and residual sigma). Diagnostics (R-hat, ESS) are included. The
    `tair` argument is accepted for API symmetry with the deterministic
    light-response tool but is not used inside this minimal model; the
    full temperature scalar can be added as a future extension.

    Args:
        par: PAR (umol photons m-2 s-1).
        nee: observed NEE (umol m-2 s-1, negative = uptake).
        tair: air temperature (deg C) -- currently unused (placeholder).
        draws: posterior draws per chain.
        tune: warmup steps.
        ci: credible mass (default 0.89).
        seed: RNG seed.

    Returns:
        dict {param: {mean, ci_low, ci_high, n_eff, r_hat}} plus _meta.
    """
    par_a = np.asarray(par, dtype=float)
    nee_a = np.asarray(nee, dtype=float)
    tair_a = np.asarray(tair, dtype=float) if tair is not None else None
    mask = ~(np.isnan(par_a) | np.isnan(nee_a))
    if tair_a is not None and len(tair_a) == len(par_a):
        mask &= ~np.isnan(tair_a)
    par_a, nee_a = par_a[mask], nee_a[mask]
    if len(par_a) < 10:
        return {"error": "fewer than 10 valid points"}

    backend = "pymc" if _has_pymc() else "numpy_mh"

    if backend == "pymc":
        import pymc as pm
        import arviz as az
        with pm.Model():
            alpha = pm.HalfNormal("alpha", sigma=1.0)
            gpp_max = pm.HalfNormal("GPP_max", sigma=30.0)
            reco = pm.Normal("Reco", mu=0.0, sigma=5.0)
            sigma = pm.HalfCauchy("sigma", beta=2.5)
            gpp = (alpha * par_a * gpp_max) / (alpha * par_a + gpp_max)
            mu = -gpp + reco
            pm.Normal("obs", mu=mu, sigma=sigma, observed=nee_a)
            idata = pm.sample(
                draws=draws, tune=tune, chains=2, cores=1,
                random_seed=seed, target_accept=0.9,
                progressbar=False, return_inferencedata=True,
            )
        out = {}
        for name in ["alpha", "GPP_max", "Reco", "sigma"]:
            arr = idata.posterior[name].values
            flat = arr.ravel()
            lo, hi = _hdi(flat, ci)
            out[name] = {
                "mean": round(float(flat.mean()), 4),
                "ci_low": round(float(lo), 4),
                "ci_high": round(float(hi), 4),
                "n_eff": round(float(az.ess(idata)[name].values), 1),
                "r_hat": round(float(az.rhat(idata)[name].values), 4),
            }
    else:
        post, names = _mh_light_response(par_a, nee_a, draws=draws,
                                         tune=tune, seed=seed)
        out = {}
        for i, name in enumerate(names):
            flat = post[:, :, i].ravel()
            lo, hi = _hdi(flat, ci)
            out[name] = {
                "mean": round(float(flat.mean()), 4),
                "ci_low": round(float(lo), 4),
                "ci_high": round(float(hi), 4),
                "n_eff": round(float(_effective_sample_size(flat)), 1),
                "r_hat": round(float(_split_rhat(post[:, :, i])), 4),
            }

    out["_meta"] = {
        "backend": backend,
        "n_obs": int(len(par_a)),
        "ci_level": ci,
        "interval_type": ("posterior_hdi" if backend == "pymc"
                          else "posterior_hdi_numpy_mh"),
        "draws_per_chain": draws,
        "tune": tune,
        "chains": 2,
        "model": ("NEE = -(alpha*PAR*GPP_max)/(alpha*PAR+GPP_max) "
                  "+ Reco + Normal(0, sigma)"),
    }
    return out


@mcp.tool()
def heterogeneous_nee_bayesian(csv_path: str,
                                land_cover: str,
                                footprint_suffix: str = "H",
                                month: Optional[int] = None,
                                par_col: str = "PAR",
                                tair_col: str = "Tair",
                                nee_col: str = "co2",
                                dark_par_threshold: float = 50.0,
                                draws: int = 1000,
                                tune: int = 500,
                                ci: float = 0.89,
                                seed: int = 0) -> dict:
    """Per-land-cover Bayesian NEE model implementing paper Eqs. 2-5
    verbatim plus the paper's two-stage dark-then-full parameter fit.

    SCOPE NOTE — paper Eq. 1 joint vs. per-LC simplification: The paper
    fits ALL land-cover classes JOINTLY each month via NEE_obs,k =
    sum_i Ω_i,k · NEE_i,k with NEE_i,k from Eqs. 2-5 per land-cover.
    This bundled tool instead fits ONE land-cover at a time on its
    footprint-DOMINATED observations (rows where the chosen LC has
    the maximum Ω among all LCs). The result is a paper-Eqs.-2-5-aligned
    per-LC parameter set, but NOT the joint Bayesian unmixing of Eq. 1.
    Combine it with bayesian_unmixing_mcmc (linear Eq. 1 unmixing on
    half-hourly aggregated fluxes) or run heterogeneous_nee_bayesian
    sequentially across land covers for the per-LC parameter set.

        Reco = alpha * exp(beta * Tair)                                   (Eq. 3)
        Tscale = (Tair-Tmin)(Tair-Tmax) / [(Tair-Tmin)(Tair-Tmax) - (Tair-Topt)^2]
                                                                          (Eq. 5)
        GPP  = Tscale * E0 * Pmax * PAR / (Pmax + E0 * PAR)               (Eq. 4)
        NEE  = Reco - GPP + eps,  eps ~ Normal(0, sigma)                  (Eq. 2)

    with FIXED Tmin = -1.5 °C, Tmax = 40 °C, Topt = 15 °C (paper Sect. 2.4.2,
    citing Luus & Lin 2015; Luus et al. 2017; Schiferl et al. 2022).

    The paper's two-stage parameter estimation (Sect. 2.4.2) is followed:
      Stage 1: filter dark data (PAR < 50 umol m-2 s-1); fit alpha, beta
               (Eq. 3) under uninformative priors using NEE_obs ≈ Reco
               (GPP ≈ 0 in the dark).
      Stage 2: using the full dataset, fit E0, Pmax (Eq. 4) with
               uninformative GPP priors and using the posterior
               distributions of alpha, beta from Stage 1 as strict
               (informative) priors for Reco. Implements the JAGS
               two-stage pipeline that the paper used.

    Fitted parameters (paper notation; Tair in °C):
      alpha  ~ uninformative Half-Normal(sigma=10)  baseline Reco (umol m-2 s-1)
      beta   ~ uninformative Normal(0, 0.5)         temperature sensitivity of Reco
      E0     ~ uninformative HalfNormal(sigma=0.2)  light-use efficiency
      Pmax   ~ uninformative HalfNormal(sigma=30)   maximum photosynthetic capacity
      sigma  ~ HalfCauchy(2.5)                       observational noise

    Observations are footprint-weighted: rows where the chosen
    ``land_cover``'s footprint weight is the largest contributor are
    retained for the per-LC fit (paper-aligned "dominant-footprint"
    partitioning). The dark-period (PAR < dark_par_threshold) subset
    constrains Reco / Q10 first, then the full set fits GPP parameters.

    Args:
        csv_path: EC flux CSV with PAR, Tair, footprint columns + nee.
        land_cover: one of lichen_tundra, green_tundra, ..., water.
        footprint_suffix: "H" (Hsieh), "ZM" (Kormann-Meixner), or "Klj" (Kljun).
        month: optional month (1-12) for monthly per-LC fits.
        par_col, tair_col, nee_col: column names.
        dark_par_threshold: PAR threshold below which an observation is
            classified as dark (used for Reco partitioning).
        draws, tune: bootstrap-iteration controls when the implementation
            falls back to MAP+bootstrap (the actual code path for this
            function — see SCOPE NOTE above; "draws" here is the number
            of bootstrap resamples, "tune" is currently ignored).
        ci: credible-interval mass for percentile CI (default 0.89 per
            paper convention).
        seed: RNG seed for the bootstrap.

    Returns:
        dict mapping each parameter name to {mean, ci_low, ci_high,
        n_eff, r_hat}, plus _meta with n_obs, n_dark_obs, backend,
        land_cover, footprint_suffix, month.
    """
    df = pd.read_csv(csv_path)
    # Column-name alias resolution to match Ameriflux/REddyProc naming used
    # in the bundled CSV (PPFD_1_1_1 / air_temperature) — same alias logic
    # as joint_heterogeneous_nee_unmixing.
    par_aliases  = (par_col, "PAR", "PPFD_1_1_1", "PPFD_IN", "ppfd_in", "ppfd")
    tair_aliases = (tair_col, "Tair", "air_temperature", "TA", "TA_1_1_1", "T_air")
    if par_col not in df.columns:
        for a in par_aliases:
            if a in df.columns: par_col = a; break
    if tair_col not in df.columns:
        for a in tair_aliases:
            if a in df.columns: tair_col = a; break
    fp_col = f"{land_cover}_{footprint_suffix}"
    needed = {par_col, tair_col, nee_col, fp_col}
    if not needed.issubset(df.columns):
        missing = needed - set(df.columns)
        return {"error": f"missing columns {sorted(missing)}"}
    df = df.copy()
    if month is not None and "month" in df.columns:
        df = df[df["month"] == int(month)]
    # Per-LC partition: keep rows whose dominant footprint matches
    # the requested land_cover (paper's heterogeneous-landscape approach
    # uses footprint dominance to attribute observations).
    fp_cols = [c for c in df.columns if c.endswith(f"_{footprint_suffix}") and not c.startswith("dominant")]
    if len(fp_cols) < 2:
        return {"error": f"no footprint columns with suffix _{footprint_suffix}"}
    fp_mat = df[fp_cols].values.astype(float)
    # Drop rows where all footprint weights are NaN (no usable attribution)
    valid_fp = ~np.all(np.isnan(fp_mat), axis=1)
    df = df.loc[valid_fp].reset_index(drop=True)
    fp_mat = fp_mat[valid_fp]
    fp_mat = np.where(np.isnan(fp_mat), -1.0, fp_mat)
    dom_idx = np.argmax(fp_mat, axis=1)
    dom_names = [c[:-len(f"_{footprint_suffix}")] for c in fp_cols]
    keep = np.array([dom_names[i] == land_cover for i in dom_idx])
    sub = df[keep].copy()
    par = sub[par_col].values.astype(float)
    tair = sub[tair_col].values.astype(float)
    nee = sub[nee_col].values.astype(float)
    mask = ~(np.isnan(par) | np.isnan(tair) | np.isnan(nee))
    par, tair, nee = par[mask], tair[mask], nee[mask]
    n_obs = int(len(nee))
    dark = par < float(dark_par_threshold)
    n_dark = int(dark.sum())
    if n_obs < 30 or n_dark < 5:
        return {"error": f"insufficient observations (n={n_obs}, n_dark={n_dark})"}
    rng = np.random.default_rng(seed)
    backend = "pymc" if _has_pymc() else "numpy_mh"

    # Paper-fixed Tscale constants (Sect. 2.4.2, Luus & Lin 2015 etc.):
    T_MIN = -1.5
    T_MAX = 40.0
    T_OPT = 15.0

    def t_scale(tair_arr: np.ndarray) -> np.ndarray:
        a = (tair_arr - T_MIN) * (tair_arr - T_MAX)
        d = a - (tair_arr - T_OPT) ** 2
        out = np.where(np.abs(d) < 1e-9, 0.0, a / d)
        return np.clip(out, 0.0, 1.5)

    def predict_dark(alpha, beta, tair_arr):
        # In dark periods (PAR<50), GPP≈0 → NEE = Reco
        return alpha * np.exp(np.clip(beta * tair_arr, -20.0, 20.0))

    def predict_full(alpha, beta, E0, Pmax, tair_arr, par_arr):
        reco = alpha * np.exp(np.clip(beta * tair_arr, -20.0, 20.0))
        ts = t_scale(tair_arr)
        denom = np.maximum(Pmax + E0 * par_arr, 1e-9)
        gpp = ts * E0 * Pmax * par_arr / denom
        return reco - gpp

    def neg_log_post_stage1(theta, tair_d, nee_d):
        """Stage 1 (dark fit, paper Sect. 2.4.2 uninformative prior on α, β)."""
        alpha, beta, log_sigma = theta
        if alpha <= 0: return 1e12
        sigma = float(np.exp(log_sigma))
        if sigma <= 0: return 1e12
        pred = predict_dark(alpha, beta, tair_d)
        if not np.all(np.isfinite(pred)): return 1e12
        resid = nee_d - pred
        nll = 0.5 * np.sum((resid / sigma) ** 2) + len(nee_d) * np.log(sigma)
        # Uninformative (broad) priors per paper
        lp = 0.5 * (alpha / 10.0) ** 2
        lp += 0.5 * (beta / 0.5) ** 2
        lp += 0.5 * np.log(1 + (sigma / 2.5) ** 2)
        return float(nll + lp)

    def neg_log_post_stage2(theta, alpha_post_mu, alpha_post_sd,
                            beta_post_mu, beta_post_sd, tair_a, par_a, nee_a):
        """Stage 2 (full fit) with STRICT informative priors from Stage 1
        on α, β (paper Sect. 2.4.2 'posterior distributions of the
        respiration parameters as strict prior information')."""
        alpha, beta, E0, Pmax, log_sigma = theta
        if alpha <= 0 or E0 <= 0 or Pmax <= 0: return 1e12
        sigma = float(np.exp(log_sigma))
        if sigma <= 0: return 1e12
        pred = predict_full(alpha, beta, E0, Pmax, tair_a, par_a)
        if not np.all(np.isfinite(pred)): return 1e12
        resid = nee_a - pred
        nll = 0.5 * np.sum((resid / sigma) ** 2) + len(nee_a) * np.log(sigma)
        # Strict prior from stage 1
        lp = 0.5 * ((alpha - alpha_post_mu) / alpha_post_sd) ** 2
        lp += 0.5 * ((beta - beta_post_mu) / beta_post_sd) ** 2
        # Uninformative for GPP params
        lp += 0.5 * (E0 / 0.2) ** 2
        lp += 0.5 * (Pmax / 30.0) ** 2
        lp += 0.5 * np.log(1 + (sigma / 2.5) ** 2)
        return float(nll + lp)

    # Paper two-stage: Stage 1 (dark fit α, β), Stage 2 (full fit E0, Pmax
    # with α, β as strict informative priors from Stage 1).
    from scipy.optimize import minimize
    tair_dark = tair[dark]
    nee_dark = nee[dark]
    # Stage 1: dark fit α, β
    x0_s1 = np.array([2.0, 0.07, np.log(2.0)])
    s1_res = minimize(neg_log_post_stage1, x0_s1, args=(tair_dark, nee_dark),
                      method="Nelder-Mead",
                      options={"maxiter": 6000, "xatol": 1e-5, "fatol": 1e-6})
    s1_boots = {"alpha": [], "beta": []}
    for _ in range(60):
        idx = rng.integers(0, len(nee_dark), size=len(nee_dark))
        rb = minimize(neg_log_post_stage1, s1_res.x,
                      args=(tair_dark[idx], nee_dark[idx]),
                      method="Nelder-Mead", options={"maxiter": 2000})
        s1_boots["alpha"].append(float(rb.x[0]))
        s1_boots["beta"].append(float(rb.x[1]))
    alpha_post_mu = float(np.mean(s1_boots["alpha"]))
    alpha_post_sd = float(max(np.std(s1_boots["alpha"]), 0.05))
    beta_post_mu = float(np.mean(s1_boots["beta"]))
    beta_post_sd = float(max(np.std(s1_boots["beta"]), 0.005))

    # Stage 2: full fit
    x0_s2 = np.array([alpha_post_mu, beta_post_mu, 0.05, 15.0, np.log(2.0)])
    s2_res = minimize(neg_log_post_stage2, x0_s2,
                      args=(alpha_post_mu, alpha_post_sd,
                            beta_post_mu, beta_post_sd, tair, par, nee),
                      method="Nelder-Mead",
                      options={"maxiter": 8000, "xatol": 1e-5, "fatol": 1e-6})
    boots = {k: [] for k in ("alpha", "beta", "E0", "Pmax", "sigma")}
    for _ in range(120):
        idx = rng.integers(0, n_obs, size=n_obs)
        rb = minimize(neg_log_post_stage2, s2_res.x,
                      args=(alpha_post_mu, alpha_post_sd,
                            beta_post_mu, beta_post_sd,
                            tair[idx], par[idx], nee[idx]),
                      method="Nelder-Mead", options={"maxiter": 3000})
        boots["alpha"].append(float(rb.x[0]))
        boots["beta"].append(float(rb.x[1]))
        boots["E0"].append(float(rb.x[2]))
        boots["Pmax"].append(float(rb.x[3]))
        boots["sigma"].append(float(np.exp(rb.x[4])))
    out = {}
    for k, vals in boots.items():
        arr = np.asarray(vals, dtype=float)
        lo, hi = _hdi(arr, ci)
        out[k] = {"mean": float(np.mean(arr)),
                  "ci_low": float(lo), "ci_high": float(hi),
                  "n_eff": float(len(arr)),
                  "r_hat": float("nan")}
    out["_stage1_summary"] = {
        "alpha_dark_mean": alpha_post_mu, "alpha_dark_sd": alpha_post_sd,
        "beta_dark_mean": beta_post_mu, "beta_dark_sd": beta_post_sd,
        "n_dark_obs": n_dark,
    }
    backend = "two_stage_map_bootstrap"
    out["_meta"] = {
        "n_obs": n_obs,
        "n_dark_obs": n_dark,
        "land_cover": land_cover,
        "footprint_suffix": footprint_suffix,
        "month": month,
        "backend": backend,
        "ci_level": ci,
        "interval_type": "bootstrap_percentile",
        "model": "Reco = alpha*exp(beta*Tair) [Eq.3]; Tscale = (Tair-Tmin)(Tair-Tmax)/[(Tair-Tmin)(Tair-Tmax) - (Tair-Topt)^2] with Tmin=-1.5, Tmax=40, Topt=15 [Eq.5]; GPP = Tscale*E0*Pmax*PAR/(Pmax+E0*PAR) [Eq.4]; NEE = Reco - GPP + Normal(0, sigma) [Eq.2]; two-stage fit per paper Sect 2.4.2 (MAP+bootstrap; PyMC unused in this function despite _has_pymc check elsewhere)",
    }
    return out


@mcp.tool()
def joint_heterogeneous_nee_unmixing(csv_path: str,
                                      footprint_suffix: str = "H",
                                      month: Optional[int] = None,
                                      par_col: str = "PAR",
                                      tair_col: str = "Tair",
                                      nee_col: str = "co2",
                                      dark_par_threshold: float = 50.0,
                                      land_covers: Optional[list] = None,
                                      n_bootstrap: int = 60,
                                      ci: float = 0.89,
                                      seed: int = 0,
                                      backend: str = "map_bootstrap",
                                      merge_fens: bool = True) -> dict:
    """Paper Eq. 1 JOINT Bayesian footprint-weighted NEE unmixing across
    ALL land covers simultaneously (Ludwig et al. 2024 BG, Sect. 2.4.1-2).

    Observation model (paper Eq. 1):
        NEE_obs,k = sum_i Omega_i,k * NEE_i,k + eps
    with per-land-cover NEE_i,k from paper Eqs. 2-5 (verbatim):
        Reco_i,k  = alpha_i * exp(beta_i * Tair_k)              (Eq. 3)
        Tscale_k  = (Tair_k - Tmin)(Tair_k - Tmax) /
                    [(Tair_k - Tmin)(Tair_k - Tmax) - (Tair_k - Topt)^2]  (Eq. 5)
        GPP_i,k   = Tscale_k * E0_i * Pmax_i * PAR_k /
                    (Pmax_i + E0_i * PAR_k)                     (Eq. 4)
        NEE_i,k   = Reco_i,k - GPP_i,k                          (Eq. 2)
    with FIXED Tmin = -1.5 °C, Tmax = 40 °C, Topt = 15 °C (Luus & Lin 2015).

    Two-stage parameter estimation (paper Sect. 2.4.2):
      Stage 1 (DARK, PAR < dark_par_threshold): joint MAP fit of
        {alpha_i, beta_i} across all land-covers using NEE_obs,k ~
        sum_i Omega_i,k * Reco_i,k. Uninformative priors:
          alpha_i ~ HalfNormal(sigma=10)
          beta_i  ~ Normal(0, 0.5)
      Stage 2 (FULL): joint MAP fit of {E0_i, Pmax_i} with alpha, beta
        from Stage 1 used as strict informative priors:
          alpha_i ~ Normal(mu=stage1_alpha_mean_i, sigma=stage1_alpha_sd_i)
          beta_i  ~ Normal(mu=stage1_beta_mean_i,  sigma=stage1_beta_sd_i)
          E0_i    ~ HalfNormal(sigma=0.2)
          Pmax_i  ~ HalfNormal(sigma=30)
          sigma_obs ~ HalfCauchy(2.5)

    Bootstrap (n_bootstrap resamples) provides 89% percentile CIs on all
    parameters. NOTE: this function is MAP-optimisation + bootstrap, NOT
    MCMC; the returned ``ci_low`` / ``ci_high`` are bootstrap percentile
    intervals (not posterior HDI) and there is no draws/tune/chains
    knob — control compute budget via ``n_bootstrap`` instead. For the
    MCMC-based path use ``bayesian_unmixing_mcmc`` (per-month linear
    Eq. 1 unmixing with PyMC NUTS), which exposes the standard
    draws/tune/chains parameters.

    Args:
        csv_path: EC flux CSV with footprint columns (e.g. lichen_tundra_H).
        footprint_suffix: "H" / "ZM" / "Klj".
        month: optional month restriction (1-12) for monthly per-LC fits.
        par_col, tair_col, nee_col: column names.
        dark_par_threshold: PAR < this is treated as dark (paper: 50).
        land_covers: optional restriction to a subset; default = all
            land-cover columns with the suffix.
        n_bootstrap: number of bootstrap resamples for CI.
        ci: credible-interval mass.
        seed: RNG seed.

    Returns:
        dict {land_cover_i: {alpha, beta, E0, Pmax: {mean, ci_low, ci_high},
        per_obs_NEE_summary: {...}}} plus a top-level _meta block. This
        is the full paper Eq. 1 joint unmixing, NOT the per-LC
        dominant-footprint simplification provided by heterogeneous_nee_bayesian.
    """
    from scipy.optimize import minimize
    df = pd.read_csv(csv_path)
    # Column-name alias resolution: if the user-supplied par/tair columns
    # are missing, try common Ameriflux/REddyProc aliases (paper Methods
    # cites the FLUXNET2015 names).
    par_aliases  = (par_col, "PAR", "PPFD_1_1_1", "PPFD_IN", "ppfd_in", "ppfd")
    tair_aliases = (tair_col, "Tair", "air_temperature", "TA", "TA_1_1_1", "T_air")
    if par_col not in df.columns:
        for a in par_aliases:
            if a in df.columns: par_col = a; break
    if tair_col not in df.columns:
        for a in tair_aliases:
            if a in df.columns: tair_col = a; break
    needed = {par_col, tair_col, nee_col}
    if not needed.issubset(df.columns):
        missing = needed - set(df.columns)
        return {"error": f"missing columns {sorted(missing)}"}
    if month is not None and "month" in df.columns:
        df = df[df["month"] == int(month)].copy()
    fp_cols = [c for c in df.columns
               if c.endswith(f"_{footprint_suffix}") and not c.startswith("dominant")]
    if not fp_cols:
        return {"error": f"no footprint columns with suffix _{footprint_suffix}"}
    lc_names_all = [c[:-len(f"_{footprint_suffix}")] for c in fp_cols]
    if land_covers is None:
        land_covers = list(lc_names_all)
        keep_cols = list(fp_cols)
    else:
        keep_cols = [f"{lc}_{footprint_suffix}" for lc in land_covers
                     if f"{lc}_{footprint_suffix}" in df.columns]
        land_covers = [c[:-len(f"_{footprint_suffix}")] for c in keep_cols]
    # Optionally merge fen1 + fen2 footprint columns into a single
    # "wetland" column per paper Sect. 2.4.2 (the paper's joint Bayesian
    # model would not converge with the two fen subclasses kept
    # separate). Default: True (paper-aligned).
    if merge_fens and ('fen1' in land_covers and 'fen2' in land_covers):
        f1_col = f"fen1_{footprint_suffix}"
        f2_col = f"fen2_{footprint_suffix}"
        wet_col = f"wetland_{footprint_suffix}"
        if f1_col in df.columns and f2_col in df.columns:
            df[wet_col] = df[f1_col].astype(float) + df[f2_col].astype(float)
            keep_cols = [c for c in keep_cols if c not in (f1_col, f2_col)] + [wet_col]
            land_covers = [c[:-len(f"_{footprint_suffix}")] for c in keep_cols]
    n_lc = len(land_covers)
    if n_lc < 2:
        return {"error": f"need at least 2 land-cover columns (got {n_lc})"}
    par = df[par_col].values.astype(float)
    tair = df[tair_col].values.astype(float)
    nee = df[nee_col].values.astype(float)
    omega = df[keep_cols].values.astype(float)
    # Drop rows with any NaN in driver / nee / omega
    valid = ~(np.isnan(par) | np.isnan(tair) | np.isnan(nee) |
              np.any(np.isnan(omega), axis=1))
    par, tair, nee, omega = par[valid], tair[valid], nee[valid], omega[valid]
    # Renormalise footprints to sum to 1 per row
    row_sum = omega.sum(axis=1, keepdims=True)
    row_sum = np.where(row_sum < 1e-6, 1.0, row_sum)
    omega = omega / row_sum
    n_obs = len(nee)
    if n_obs < 60:
        return {"error": f"insufficient observations after filtering (n={n_obs})"}
    # Paper-fixed Tscale constants
    T_MIN, T_MAX, T_OPT = -1.5, 40.0, 15.0
    def tscale_arr(t):
        a = (t - T_MIN) * (t - T_MAX)
        d = a - (t - T_OPT) ** 2
        out = np.where(np.abs(d) < 1e-9, 0.0, a / d)
        return np.clip(out, 0.0, 1.5)
    dark = par < float(dark_par_threshold)
    n_dark = int(dark.sum())
    if n_dark < n_lc * 5:
        return {"error": f"insufficient dark observations (n_dark={n_dark}, need >= {n_lc*5})"}
    rng = np.random.default_rng(seed)

    # =================================================================
    # BACKEND DISPATCH
    # =================================================================
    # default = "map_bootstrap" (lightweight, ~seconds); only enter
    # PyMC NUTS path when caller explicitly passes backend="pymc_nuts".
    # The PyMC path matches paper Ludwig 2024 Sect 2.4.2 JAGS settings
    # (3 chains × 5000+5000 burn-in × 3000 retained draws) but costs
    # hours of compute on a single CPU and is NOT the default.
    if backend not in {"map_bootstrap", "pymc_nuts"}:
        return {"error": f"unknown backend {backend!r}; use 'map_bootstrap' or 'pymc_nuts'"}
    try:
        if backend != "pymc_nuts":
            raise ImportError("backend != 'pymc_nuts'; skipping NUTS path")
        import pymc as pm
        import pytensor.tensor as pt
        T_MIN_pm, T_MAX_pm, T_OPT_pm = -1.5, 40.0, 15.0
        dark = par < float(dark_par_threshold)
        n_dark_pm = int(dark.sum())
        par_d, tair_d, nee_d, omega_d = par[dark], tair[dark], nee[dark], omega[dark]
        # Identify water/aquatic land covers from the column names so we can
        # apply the paper's constant-flux treatment for water (Ludwig 2024:
        # water CO2 is fit as a constant; vegetated/degraded LCs follow
        # Eqs. 2-5). Tundra/lichen/sedge/dry/wet/edge/degraded all use the
        # standard Reco/GPP model.
        water_mask = np.array([("water" in lc.lower() or "aquatic" in lc.lower())
                                for lc in land_covers])
        # ---- Stage 1: dark MCMC fit of alpha_i, beta_i across vegetated LCs ----
        # Water LCs get a constant dark-respiration term (no Tair dependence).
        with pm.Model() as model_s1:
            alpha = pm.HalfNormal("alpha", sigma=10.0, shape=n_lc)
            beta_raw = pm.Normal("beta", mu=0.0, sigma=0.5, shape=n_lc)
            # Force beta_water = 0 (constant flux) by masking
            beta_mask = pt.as_tensor_variable((~water_mask).astype(float))
            beta = beta_raw * beta_mask
            sigma_obs = pm.HalfCauchy("sigma_obs", beta=2.5)
            reco_lc = alpha[None, :] * pt.exp(
                pt.clip(beta[None, :] * tair_d[:, None], -20.0, 20.0))
            pred = (omega_d * reco_lc).sum(axis=1)
            pm.Normal("nee_obs", mu=pred, sigma=sigma_obs, observed=nee_d)
            # Paper JAGS settings: 3 chains, 5000 burn-in + 5000 adaptation,
            # 3000 retained draws per chain (Ludwig 2024 Sect. 2.4.2). PyMC's
            # tune phase combines adaptation and burn-in.
            trace_s1 = pm.sample(
                draws=3000, tune=10000, chains=3, cores=1,
                target_accept=0.92, random_seed=seed,
                progressbar=False, return_inferencedata=True,
            )
        s1_post = trace_s1.posterior
        alpha_post_s1 = s1_post["alpha"].values.reshape(-1, n_lc)
        beta_post_s1  = s1_post["beta"].values.reshape(-1, n_lc)
        a_mean = alpha_post_s1.mean(axis=0)
        a_sd   = np.maximum(alpha_post_s1.std(axis=0), 0.05)
        b_mean = beta_post_s1.mean(axis=0)
        b_sd   = np.maximum(beta_post_s1.std(axis=0), 0.005)
        # ---- Stage 2: full MCMC fit of E0_i, Pmax_i with strict Stage1 priors ----
        T_MIN_v, T_MAX_v, T_OPT_v = -1.5, 40.0, 15.0
        a_num = (tair - T_MIN_v) * (tair - T_MAX_v)
        a_den = a_num - (tair - T_OPT_v) ** 2
        ts_full_np = np.where(np.abs(a_den) < 1e-9, 0.0, a_num / a_den)
        ts_full_np = np.clip(ts_full_np, 0.0, 1.5)
        with pm.Model() as model_s2:
            alpha2 = pm.Normal("alpha", mu=a_mean, sigma=a_sd, shape=n_lc)
            beta2  = pm.Normal("beta",  mu=b_mean, sigma=b_sd, shape=n_lc)
            # Water LCs: paper Sect. 2.4.2 specifies water CO2 as a single
            # constant flux. We zero out the GPP terms (E0, Pmax) for water
            # so that NEE_water = alpha_water * exp(beta_water * Tair). With
            # beta_water forced to zero in Stage 1, this collapses to
            # NEE_water = alpha_water = constant.
            gpp_mask = pt.as_tensor_variable((~water_mask).astype(float))
            E0_raw   = pm.HalfNormal("E0",   sigma=0.2, shape=n_lc)
            Pmax_raw = pm.HalfNormal("Pmax", sigma=30.0, shape=n_lc)
            E0   = E0_raw   * gpp_mask
            Pmax = Pmax_raw * gpp_mask + 1e-6  # avoid division-by-zero
            sigma_obs2 = pm.HalfCauchy("sigma_obs", beta=2.5)
            reco_lc2 = alpha2[None, :] * pt.exp(
                pt.clip(beta2[None, :] * tair[:, None], -20.0, 20.0))
            denom = pt.maximum(Pmax[None, :] + E0[None, :] * par[:, None], 1e-9)
            gpp_lc2 = (ts_full_np[:, None] * E0[None, :] *
                       Pmax[None, :] * par[:, None] / denom)
            nee_lc2 = reco_lc2 - gpp_lc2
            pred2 = (omega * nee_lc2).sum(axis=1)
            pm.Normal("nee_obs2", mu=pred2, sigma=sigma_obs2, observed=nee)
            trace_s2 = pm.sample(
                draws=3000, tune=10000, chains=3, cores=1,
                target_accept=0.92, random_seed=seed,
                progressbar=False, return_inferencedata=True,
            )
        s2_post = trace_s2.posterior
        post_arrs = {
            "alpha": s2_post["alpha"].values.reshape(-1, n_lc),
            "beta":  s2_post["beta"].values.reshape(-1, n_lc),
            "E0":    s2_post["E0"].values.reshape(-1, n_lc),
            "Pmax":  s2_post["Pmax"].values.reshape(-1, n_lc),
        }
        sigma_post = s2_post["sigma_obs"].values.flatten()
        out: dict = {}
        for i, lc in enumerate(land_covers):
            lc_summary = {}
            for k, arr in post_arrs.items():
                a = arr[:, i]
                lo, hi = _hdi(a, ci)
                lc_summary[k] = {
                    "mean": float(np.mean(a)),
                    "ci_low": float(lo),
                    "ci_high": float(hi),
                    "n_eff": float(len(a)),
                }
            out[lc] = lc_summary
        lo, hi = _hdi(sigma_post, ci)
        out["_sigma_obs"] = {"mean": float(np.mean(sigma_post)),
                             "ci_low": float(lo), "ci_high": float(hi)}
        # Convergence diagnostics
        try:
            import arviz as az
            rhat = az.rhat(trace_s2)
            ess  = az.ess(trace_s2)
            diagn = {}
            for k in ("alpha", "beta", "E0", "Pmax", "sigma_obs"):
                if k in rhat:
                    rh = float(np.nanmax(rhat[k].values))
                    es = float(np.nanmin(ess[k].values))
                    diagn[k] = {"max_rhat": rh, "min_ess": es}
            out["_convergence"] = diagn
        except Exception:
            pass
        out["_meta"] = {
            "n_obs": int(n_obs),
            "n_dark_obs": int(n_dark_pm),
            "n_land_covers": int(n_lc),
            "land_covers": list(land_covers),
            "footprint_suffix": footprint_suffix,
            "month": month,
            "backend": "pymc_nuts_two_stage",
            "ci_level": ci,
            "interval_type": "posterior_hdi",
            "n_chains": 3,
            "draws_per_chain": 3000,
            "tune_per_chain": 10000,
            "paper_jags_equivalent": "3 chains x (5000 burn-in + 5000 adaptation + 3000 draws) per Ludwig 2024 Sect 2.4.2; PyMC's tune phase folds adaptation and burn-in",
            "model": (
                "NEE_obs,k = sum_i Omega_i,k * (alpha_i*exp(beta_i*Tair_k) "
                "- Tscale_k*E0_i*Pmax_i*PAR_k/(Pmax_i+E0_i*PAR_k)) + Normal(0,sigma); "
                "Tscale_k = (T-Tmin)(T-Tmax)/[(T-Tmin)(T-Tmax)-(T-Topt)^2] with "
                "Tmin=-1.5, Tmax=40, Topt=15; paper Ludwig 2024 BG Eqs. 1-5; "
                "two-stage dark->full PyMC NUTS per Sect 2.4.2"
            ),
        }
        return out
    except Exception as _pymc_err:
        _pymc_fail = repr(_pymc_err)

    # === Stage 1: dark fit alpha_i, beta_i (joint across all LCs) ===
    # Paper Sect. 2.4.2 water/aquatic constant-flux rule: beta_water = 0
    # is enforced IN THE FIT (not post-hoc) by zeroing beta entries for
    # water/aquatic LCs inside neg_log_post_*; the optimizer's
    # corresponding components become inactive and any value they take
    # has no effect on the cost.
    water_mask = np.array([("water" in lc.lower() or "aquatic" in lc.lower())
                            for lc in land_covers])
    veg_mask = ~water_mask
    par_d, tair_d, nee_d, omega_d = par[dark], tair[dark], nee[dark], omega[dark]

    def _zero_water(vec: np.ndarray) -> np.ndarray:
        # Return a copy of vec with water-class indices zeroed; preserves shape.
        out = np.asarray(vec, dtype=float).copy()
        out[water_mask] = 0.0
        return out

    def neg_log_post_stage1(theta, tair_arr, nee_arr, omega_arr):
        # theta layout: [alpha_1..alpha_N, beta_1..beta_N, log_sigma]
        alpha_vec = theta[:n_lc]
        beta_vec_raw  = theta[n_lc:2*n_lc]
        log_sigma = theta[2*n_lc]
        if np.any(alpha_vec <= 0): return 1e12
        sigma = float(np.exp(log_sigma))
        if sigma <= 0: return 1e12
        # Paper Sect. 2.4.2: beta=0 for water/aquatic (constant flux)
        beta_vec = _zero_water(beta_vec_raw)
        reco_lc = alpha_vec[None, :] * np.exp(
            np.clip(beta_vec[None, :] * tair_arr[:, None], -20.0, 20.0))
        pred = (omega_arr * reco_lc).sum(axis=1)
        if not np.all(np.isfinite(pred)): return 1e12
        resid = nee_arr - pred
        nll = 0.5 * np.sum((resid / sigma) ** 2) + len(nee_arr) * np.log(sigma)
        lp = 0.5 * np.sum((alpha_vec / 10.0) ** 2)
        lp += 0.5 * np.sum((beta_vec / 0.5) ** 2)
        lp += 0.5 * np.log(1 + (sigma / 2.5) ** 2)
        return float(nll + lp)

    x0_s1 = np.concatenate([
        np.full(n_lc, 2.0),     # alpha init
        np.full(n_lc, 0.07),    # beta init
        [np.log(2.0)],          # log_sigma
    ])
    s1_res = minimize(neg_log_post_stage1, x0_s1,
                      args=(tair_d, nee_d, omega_d),
                      method="Nelder-Mead",
                      options={"maxiter": 12000, "xatol": 1e-5, "fatol": 1e-6,
                               "adaptive": True})
    # Bootstrap Stage 1
    s1_alpha_boots = np.zeros((min(n_bootstrap, 40), n_lc))
    s1_beta_boots  = np.zeros((min(n_bootstrap, 40), n_lc))
    for b in range(s1_alpha_boots.shape[0]):
        idx = rng.integers(0, n_dark, size=n_dark)
        rb = minimize(neg_log_post_stage1, s1_res.x,
                      args=(tair_d[idx], nee_d[idx], omega_d[idx]),
                      method="Nelder-Mead",
                      options={"maxiter": 4000, "adaptive": True})
        s1_alpha_boots[b] = rb.x[:n_lc]
        s1_beta_boots[b]  = rb.x[n_lc:2*n_lc]
    alpha_mean = s1_alpha_boots.mean(axis=0)
    alpha_sd = np.maximum(s1_alpha_boots.std(axis=0), 0.05)
    beta_mean = s1_beta_boots.mean(axis=0)
    beta_sd = np.maximum(s1_beta_boots.std(axis=0), 0.005)

    # === Stage 2: full fit E0_i, Pmax_i (joint) with strict priors on α, β ===
    # Water/aquatic LCs: paper Sect. 2.4.2 specifies CO2 as a single
    # constant flux, so beta_water = E0_water = Pmax_water = 0 are
    # enforced IN THE FIT (not post-hoc) via _zero_water on the
    # corresponding theta slices inside neg_log_post_stage2.
    def neg_log_post_stage2(theta, tair_arr, par_arr, nee_arr, omega_arr,
                            tscale_arr_obs):
        # theta: [alpha_1..N, beta_1..N, E0_1..N, Pmax_1..N, log_sigma]
        alpha_vec = theta[:n_lc]
        beta_vec  = _zero_water(theta[n_lc:2*n_lc])
        E0_vec    = _zero_water(theta[2*n_lc:3*n_lc])
        Pmax_vec_raw = theta[3*n_lc:4*n_lc]
        # Keep Pmax > 0 for vegetated LCs; allow zero (water constant flux) for water
        Pmax_vec = Pmax_vec_raw.copy().astype(float)
        Pmax_vec[water_mask] = 0.0
        log_sigma = theta[4*n_lc]
        if np.any(alpha_vec <= 0) or np.any(E0_vec[veg_mask] <= 0) or np.any(Pmax_vec_raw[veg_mask] <= 0):
            return 1e12
        sigma = float(np.exp(log_sigma))
        if sigma <= 0: return 1e12
        reco_lc = alpha_vec[None, :] * np.exp(
            np.clip(beta_vec[None, :] * tair_arr[:, None], -20.0, 20.0))
        # GPP_lc per obs per LC. For water (E0=Pmax=0), this evaluates to 0.
        denom = np.maximum(Pmax_vec[None, :] + E0_vec[None, :] * par_arr[:, None],
                           1e-9)
        gpp_lc = (tscale_arr_obs[:, None] * E0_vec[None, :] *
                  Pmax_vec[None, :] * par_arr[:, None] / denom)
        nee_lc = reco_lc - gpp_lc
        pred = (omega_arr * nee_lc).sum(axis=1)
        if not np.all(np.isfinite(pred)): return 1e12
        resid = nee_arr - pred
        nll = 0.5 * np.sum((resid / sigma) ** 2) + len(nee_arr) * np.log(sigma)
        lp = 0.5 * np.sum(((alpha_vec - alpha_mean) / alpha_sd) ** 2)
        lp += 0.5 * np.sum(((beta_vec - beta_mean) / beta_sd) ** 2)
        # Penalise only the vegetated (active) GPP params; water slots are clamped to 0
        lp += 0.5 * np.sum((E0_vec[veg_mask] / 0.2) ** 2)
        lp += 0.5 * np.sum((Pmax_vec[veg_mask] / 30.0) ** 2)
        lp += 0.5 * np.log(1 + (sigma / 2.5) ** 2)
        return float(nll + lp)

    ts_full = tscale_arr(tair)
    x0_s2 = np.concatenate([alpha_mean, beta_mean,
                            np.full(n_lc, 0.05),    # E0 init
                            np.full(n_lc, 15.0),    # Pmax init
                            [np.log(2.0)]])
    s2_res = minimize(neg_log_post_stage2, x0_s2,
                      args=(tair, par, nee, omega, ts_full),
                      method="Nelder-Mead",
                      options={"maxiter": 25000, "xatol": 1e-5, "fatol": 1e-6,
                               "adaptive": True})
    # Bootstrap Stage 2
    n_boot = int(n_bootstrap)
    boots = {k: np.zeros((n_boot, n_lc)) for k in ("alpha", "beta", "E0", "Pmax")}
    boots["sigma"] = np.zeros(n_boot)
    for b in range(n_boot):
        idx = rng.integers(0, n_obs, size=n_obs)
        ts_b = ts_full[idx]
        rb = minimize(neg_log_post_stage2, s2_res.x,
                      args=(tair[idx], par[idx], nee[idx], omega[idx], ts_b),
                      method="Nelder-Mead",
                      options={"maxiter": 6000, "adaptive": True})
        boots["alpha"][b] = rb.x[:n_lc]
        boots["beta"][b]  = rb.x[n_lc:2*n_lc]
        boots["E0"][b]    = rb.x[2*n_lc:3*n_lc]
        boots["Pmax"][b]  = rb.x[3*n_lc:4*n_lc]
        boots["sigma"][b] = float(np.exp(rb.x[4*n_lc]))
    # Pack per-LC summaries
    out: dict = {}
    for i, lc in enumerate(land_covers):
        lc_summary = {}
        for k in ("alpha", "beta", "E0", "Pmax"):
            arr = boots[k][:, i]
            lo, hi = _hdi(arr, ci)
            lc_summary[k] = {
                "mean": float(np.mean(arr)),
                "ci_low": float(lo),
                "ci_high": float(hi),
                "n_eff": float(len(arr)),
            }
        out[lc] = lc_summary
    sigma_arr = boots["sigma"]
    lo, hi = _hdi(sigma_arr, ci)
    out["_sigma_obs"] = {"mean": float(np.mean(sigma_arr)),
                        "ci_low": float(lo), "ci_high": float(hi)}
    # Apply paper's water/aquatic-class constant-flux rule (Ludwig 2024
    # Sect. 2.4.2): water CO2 is a single constant with no Tair / PAR
    # dependence. After the joint fit, force beta_water / E0_water /
    # Pmax_water to zero in the reported per-LC summary so the bundled
    # interpretation matches the paper convention (even though the MAP
    # path fits them numerically). Documented here as a post-hoc
    # zero-clamp rather than an in-fit prior because Nelder-Mead does
    # not accept inequality constraints; the resulting alpha_water
    # value IS the water constant-flux estimate.
    for i, lc in enumerate(land_covers):
        if "water" in lc.lower() or "aquatic" in lc.lower():
            if lc in out:
                for kk in ("beta", "E0", "Pmax"):
                    out[lc][kk] = {"mean": 0.0, "ci_low": 0.0, "ci_high": 0.0,
                                   "n_eff": float(n_boot),
                                   "constrained": "paper Sect. 2.4.2 water constant-flux rule"}
    requested_backend_explicit = (backend == "pymc_nuts")
    out["_meta"] = {
        "n_obs": int(n_obs),
        "n_dark_obs": int(n_dark),
        "n_land_covers": int(n_lc),
        "land_covers": list(land_covers),
        "footprint_suffix": footprint_suffix,
        "month": month,
        "backend": ("joint_two_stage_map_bootstrap"
                    if not requested_backend_explicit
                    else "joint_two_stage_map_bootstrap_FALLBACK_pymc_unavailable"),
        "requested_backend": backend,
        "merge_fens_applied": bool(merge_fens),
        "water_constant_flux_constrained": True,
        "pymc_import_error": (_pymc_fail if (requested_backend_explicit and "_pymc_fail" in locals())
                              else None),
        "ci_level": ci,
        "interval_type": "bootstrap_percentile",
        "n_bootstrap": int(n_boot),
        "model": (
            "NEE_obs,k = sum_i Omega_i,k * (alpha_i*exp(beta_i*Tair_k) "
            "- Tscale_k*E0_i*Pmax_i*PAR_k/(Pmax_i+E0_i*PAR_k)) + Normal(0, sigma); "
            "Tscale_k = (T-Tmin)(T-Tmax)/[(T-Tmin)(T-Tmax)-(T-Topt)^2] with "
            "Tmin=-1.5, Tmax=40, Topt=15; paper Ludwig 2024 BG Eqs. 1-5; "
            "two-stage dark->full fit per Sect 2.4.2"
        ),
    }
    return out


if __name__ == "__main__":
    mcp.run(transport="stdio")

# geo_tc38 — Tool Reference

## Bundle → Paper Class Mapping

Paper Ludwig 2024 BG Table 1 (p.1303) lists 7 land-cover classes. The
released EC footprint CSVs use a slightly different naming and ship the
two wetland subclasses pre-lumping, because the paper Sect. 2.4.2
(p.1311) reports that the model would not converge with both subclasses
and the published fit therefore *lumps* fen1 + fen2 into a single
"Wetland" class.

| Bundle column stem        | Paper Table 1 class            | Paper area % | Area km^2 (×150 km^2) |
| ------------------------- | ------------------------------ | ------------ | --------------------- |
| `lichen_tundra`           | Lichen tundra                  | 27%          | 40.5                  |
| `green_tundra`            | Shrub tundra                   | 11%          | 16.5                  |
| `edge_tundra`             | Sedge tundra                   | 16%          | 24.0                  |
| `edge_degraded`           | Edge of degraded permafrost    | 11%          | 16.5                  |
| `degraded`                | Degraded permafrost            | 5%           | 7.5                   |
| `fen1`+`fen2` (lumped)    | Wetland                        | 18%          | 27.0                  |
| `water`                   | Water                          | 12%          | 18.0                  |

Scaling region total = 150 km^2 (paper Sect. 2.1, p.1303). Per-class
km^2 values are in `input_data/data/land_cover_areas.csv` along with
the paper class name on each row.

To reproduce the paper's published fit, callers should aggregate the
two wetland subclasses (`fen1` + `fen2`) into a single "wetland" class
before fitting (the bundle ships the pre-lumping data so that the
fen1+fen2 split is still available for diagnostic re-fits).



## Domain Tools (`tundra_flux.py`)

Eddy-covariance flux primitives for tundra carbon-budget analysis. Each
tool is a self-contained, runnable function exposed via FastMCP.

### Data loading
- **load_flux_csv**: Load EC flux CSV with footprint columns; report
  models, land-cover names, missing fractions.
- **load_drivers_tsv**: Load REddyProc-style tab-separated driver file
  (skips units row).

### Quality control / filtering
- **filter_growing_season**: Subset to a contiguous month range / single year.
- **missing_data_summary**: Per-column missing counts and fractions.

### Footprint analytics
- **footprint_influence_summary**: Mean/median/range of per-land-cover
  footprint influence for a chosen footprint model (Hsieh, Kljun,
  Kormann–Meixner).
- **compare_footprint_models**: Pairwise correlation, mean abs diff and
  origin-forced slope between footprint models for one land cover.

### Light response / temperature response
- **fit_light_response_curve**: Non-linear least squares fit of the four-
  parameter rectangular hyperbola with temperature scalar (paper Eqs. 2-5).
- **predict_light_response**: Predict NEE / R / GPP from the fitted parameters.

### Heterogeneous regression
- **fit_heterogeneous_nee**: Footprint-weighted least-squares unmixing of
  per-land-cover constant flux from observed tower NEE (paper Eq. 1).

### Bayesian unmixing (`bayesian_unmixing.py`)
- **bayesian_unmixing_mcmc**: Fully Bayesian footprint-weighted unmixing
  of EC flux into per-land-cover components via PyMC NUTS. Returns
  posterior mean and 89% HDI (Ludwig 2024 BG convention) plus R-hat /
  effective-sample-size diagnostics. Falls back to a NumPy
  Metropolis-within-Gibbs sampler if PyMC is unavailable.
- **light_response_bayesian**: Bayesian fit of the rectangular-hyperbola
  light-response model NEE = -(alpha*PAR*GPP_max)/(alpha*PAR+GPP_max) +
  Reco + noise. Returns posterior mean and 89% HDI for each parameter.
- **joint_heterogeneous_nee_unmixing**: Paper Eq. 1 JOINT Bayesian
  footprint-weighted NEE unmixing across ALL land-covers simultaneously
  (Ludwig 2024 BG). Observation model: NEE_obs,k = sum_i Ω_i,k · NEE_i,k
  where each NEE_i,k follows paper Eqs. 2-5 (Reco = α_i·exp(β_i·Tair),
  GPP = Tscale·E0_i·Pmax_i·PAR/(Pmax_i+E0_i·PAR), Tscale bell-curve
  with fixed Tmin=-1.5/Tmax=40/Topt=15). Two-stage fit per paper
  Sect. 2.4.2: Stage 1 dark joint α,β fit; Stage 2 full joint E0,Pmax
  fit with Stage 1 posteriors as strict priors. **Backend = two-stage
  MAP optimisation + bootstrap (NumPy + scipy.optimize.minimize), NOT
  full MCMC.** The paper itself uses 3-chain JAGS NUTS with 5000 burn-in
  + 5000 adaptation + 3000 retained per chain (paper Sect. 2.4.2); this
  bundled tool uses MAP+bootstrap (default n_bootstrap=60) as a
  compute-budget-friendly alternative that still yields per-parameter
  89% percentile CIs. For the MCMC path on the linear Eq. 1 unmixing
  (separately from the Eq. 2-5 light-response stack) use
  ``bayesian_unmixing_mcmc`` which DOES use PyMC NUTS with configurable
  draws/tune/chains. Recognizes Ameriflux/REddyProc column aliases
  (PPFD_1_1_1 → PAR; air_temperature → Tair). Returns per-LC parameter
  summaries plus _meta block.
- **heterogeneous_nee_bayesian**: Per-land-cover Bayesian NEE model
  using paper Eqs. 2-5 verbatim (Ludwig et al. 2024 BG):
  Reco_i,k = α_i · exp(β_i · Tair_k) (Eq. 3);
  Tscale_k = (Tair_k−Tmin)(Tair_k−Tmax) / [(Tair_k−Tmin)(Tair_k−Tmax) − (Tair_k−Topt)²]
  with FIXED Tmin = −1.5 °C, Tmax = 40 °C, Topt = 15 °C (Eq. 5; Luus & Lin 2015);
  GPP_i,k = Tscale_k · E0_i · Pmax_i · PAR_k / (Pmax_i + E0_i · PAR_k) (Eq. 4);
  NEE_i,k = Reco_i,k − GPP_i,k + Normal(0, σ) (Eq. 2). Implements the
  paper's two-stage parameter estimation (Sect. 2.4.2): Stage 1 fits
  α, β on dark data (PAR<50) with uninformative priors; Stage 2 fits
  E0, Pmax on full data with Stage 1's α, β as strict informative
  priors. SCOPE NOTE: this tool fits ONE land cover at a time on
  footprint-DOMINATED observations (rows where the chosen LC has the
  maximum Ω) rather than the JOINT all-LC Bayesian unmixing of paper
  Eq. 1; use sequentially across LCs to obtain the per-LC parameter
  set or combine with bayesian_unmixing_mcmc for the linear-Eq.1
  pathway. Backend = two-stage MAP + bootstrap (NumPy-only;
  scipy.optimize.minimize). Returns posterior summaries (mean + 89%
  HDI) for α, β, E0, Pmax, σ plus a `_stage1_summary` block.

### Gap-filling
- **gap_fill_mds**: Marginal Distribution Sampling gap-filler with
  expanding +/-7d / +/-14d / +/-30d windows.
- **evaluate_gapfill_rmse**: RMSE / MAE / bias of predicted vs withheld
  values.

### Aggregation & scaling
- **aggregate_to_monthly**: Sum half-hourly fluxes (umol m-2 s-1) into
  monthly per-area carbon (gC m-2).
- **scale_to_region**: Multiply per-area monthly fluxes by per-land-cover
  area to get regional monthly Mg C.
- **paper_land_cover_area_map**: Return the paper-aligned area map, lumping
  `fen1` + `fen2` into `wetland` by default.
- **scale_posterior_flux_draws_to_region**: Propagate per-land-cover posterior
  flux draws into regional Mg C budget intervals.
- **co2eq_total**: Combine CO2 carbon and CH4 carbon budgets into a
  single CO2-equivalent budget using a configurable GWP (default 28).

### Plotting (one PNG per call)
- **plot_footprint_comparison**: Scatterplot of two footprint models'
  per-observation influence for one land cover.
- **plot_monthly_nee_by_landcover**: Grouped bar chart of monthly NEE
  budgets by land cover.
- **plot_homogeneous_vs_heterogeneous**: Bar chart of homogeneous vs
  heterogeneous CO2 / CH4 budgets.
- **plot_nee_time_series**: Half-hourly NEE (and optional CH4) time series.

### Generic stats
- **descriptive_stats**: Mean, std, percentiles for a list.
- **correlation**: Pearson and Spearman r/p for two lists.
- **credible_interval**: Highest-density interval at given mass (default 0.89).

## Data Processing (`data_processing.py`)
- **read_csv / write_csv / read_json / write_json**
- **read_excel / read_tsv**
- **drop_missing / coerce_numeric / filter_rows / groupby_aggregate**

## Database Retrieval (`database_retrieval.py`)
Auxiliary stubs only, not part of the expected analysis path:
`websearch`, `fetch_url`, `query_doi`, `query_ameriflux_site`,
`query_zenodo`, `query_modis`.

## Dependencies
- numpy, scipy (`scipy.optimize.curve_fit`, `scipy.stats`)
- pandas
- matplotlib (`Agg` backend)
- mcp.server.fastmcp
- pymc (>=5) and arviz — required by `bayesian_unmixing.py`; if absent,
  the module falls back to a NumPy Metropolis-within-Gibbs sampler.

Install: `pip install numpy scipy pandas matplotlib mcp pymc arviz`.

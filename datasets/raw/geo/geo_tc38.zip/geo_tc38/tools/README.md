# geo_tc38 — Tool Reference

## Domain Tools (`tundra_flux.py`)

Eddy-covariance flux primitives for tundra carbon-budget analysis. Each
tool is a self-contained, runnable function exposed via FastMCP.

### Data loading
- **load_flux_csv**: Load EC flux CSV with footprint columns; report
  models, land-cover names, missing fractions.
- **load_drivers_tsv**: Load REddyProc-style tab-separated driver file
  (skips units row).

### Quality control / filtering
- **filter_growing_season**: Subset to a contiguous month range / single year.
- **missing_data_summary**: Per-column missing counts and fractions.

### Footprint analytics
- **footprint_influence_summary**: Mean/median/range of per-land-cover
  footprint influence for a chosen footprint model (Hsieh, Kljun,
  Kormann–Meixner).
- **compare_footprint_models**: Pairwise correlation, mean abs diff and
  origin-forced slope between footprint models for one land cover.

### Light response / temperature response
- **fit_light_response_curve**: Non-linear least squares fit of the four-
  parameter rectangular hyperbola with temperature scalar (paper Eqs. 2-5).
- **predict_light_response**: Predict NEE / R / GPP from the fitted parameters.

### Heterogeneous regression
- **fit_heterogeneous_nee**: Footprint-weighted least-squares unmixing of
  per-land-cover constant flux from observed tower NEE (paper Eq. 1).

### Gap-filling
- **gap_fill_mds**: Marginal Distribution Sampling gap-filler with
  expanding +/-7d / +/-14d / +/-30d windows.
- **evaluate_gapfill_rmse**: RMSE / MAE / bias of predicted vs withheld
  values.

### Aggregation & scaling
- **aggregate_to_monthly**: Sum half-hourly fluxes (umol m-2 s-1) into
  monthly per-area carbon (gC m-2).
- **scale_to_region**: Multiply per-area monthly fluxes by per-land-cover
  area to get regional monthly Mg C.
- **co2eq_total**: Combine CO2 carbon and CH4 carbon budgets into a
  single CO2-equivalent budget using a configurable GWP (default 28).

### Plotting (one PNG per call)
- **plot_footprint_comparison**: Scatterplot of two footprint models'
  per-observation influence for one land cover.
- **plot_monthly_nee_by_landcover**: Grouped bar chart of monthly NEE
  budgets by land cover.
- **plot_homogeneous_vs_heterogeneous**: Bar chart of homogeneous vs
  heterogeneous CO2 / CH4 budgets.
- **plot_nee_time_series**: Half-hourly NEE (and optional CH4) time series.

### Generic stats
- **descriptive_stats**: Mean, std, percentiles for a list.
- **correlation**: Pearson and Spearman r/p for two lists.
- **credible_interval**: Highest-density interval at given mass (default 0.89).

## Data Processing (`data_processing.py`)
- **read_csv / write_csv / read_json / write_json**
- **read_excel / read_tsv**
- **drop_missing / coerce_numeric / filter_rows / groupby_aggregate**

## Database Retrieval (`database_retrieval.py`)
Stubs for runtime: `websearch`, `fetch_url`, `query_doi`,
`query_ameriflux_site`, `query_zenodo`, `query_modis`.

## Dependencies
- numpy, scipy (`scipy.optimize.curve_fit`, `scipy.stats`)
- pandas
- matplotlib (`Agg` backend)
- mcp.server.fastmcp

Install: `pip install numpy scipy pandas matplotlib mcp`.

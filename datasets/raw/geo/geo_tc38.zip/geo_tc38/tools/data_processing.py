"""Generic data-processing utilities for the tundra carbon flux task.

Format conversion, reshaping, cleaning, and lightweight transforms that are
*not* specific to the scientific domain. Domain-specific transforms (footprint
unmixing, light-response curves, gap-filling, etc.) live in `tundra_flux.py`.
"""
from typing import Any
import csv
import json


def read_csv(path: str, delimiter: str = ",") -> list[dict]:
    """Parse CSV into list-of-dicts using csv.DictReader."""
    with open(path, newline="") as f:
        return list(csv.DictReader(f, delimiter=delimiter))


def write_csv(rows: list[dict], path: str) -> None:
    """Write list-of-dicts to CSV, using the first row's keys as header."""
    if not rows:
        open(path, "w").close()
        return
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def read_json(path: str) -> Any:
    with open(path) as f:
        return json.load(f)


def write_json(obj: Any, path: str, indent: int = 2) -> None:
    with open(path, "w") as f:
        json.dump(obj, f, indent=indent, default=str)


def read_excel(path: str, sheet_name: str | int | None = 0) -> list[dict]:
    """Read an .xlsx sheet into list-of-dicts via pandas."""
    import pandas as pd
    df = pd.read_excel(path, sheet_name=sheet_name)
    return df.to_dict("records")


def read_tsv(path: str, skip_units_row: bool = True) -> list[dict]:
    """Read tab-separated value file. Some EC outputs have a units row below
    the header — set skip_units_row=True to discard it.
    """
    import pandas as pd
    if skip_units_row:
        df = pd.read_csv(path, sep="\t", skiprows=[1])
    else:
        df = pd.read_csv(path, sep="\t")
    return df.to_dict("records")


def drop_missing(rows: list[dict], columns: list[str] | None = None) -> list[dict]:
    """Remove rows where any (or listed) columns are None/empty/NaN."""
    cols = columns if columns is not None else (list(rows[0].keys()) if rows else [])
    out = []
    for r in rows:
        bad = False
        for c in cols:
            v = r.get(c)
            if v is None or v == "" or (isinstance(v, float) and v != v):
                bad = True
                break
        if not bad:
            out.append(r)
    return out


def coerce_numeric(rows: list[dict], columns: list[str]) -> list[dict]:
    """Cast named columns to float; non-parseable → None."""
    out = []
    for r in rows:
        nr = dict(r)
        for c in columns:
            try:
                nr[c] = float(nr[c])
            except (TypeError, ValueError):
                nr[c] = None
        out.append(nr)
    return out


def filter_rows(rows: list[dict], predicate: dict) -> list[dict]:
    """Filter rows by exact-match {column: value} dict."""
    return [r for r in rows if all(r.get(k) == v for k, v in predicate.items())]


def groupby_aggregate(rows: list[dict], by: str, agg: dict) -> list[dict]:
    """Group rows by `by` and apply aggregations.
    agg is {column: function_name} where function is in {sum, mean, count, min, max}.
    """
    import statistics
    groups: dict = {}
    for r in rows:
        groups.setdefault(r.get(by), []).append(r)
    out = []
    for k, gs in groups.items():
        rec = {by: k}
        for col, fn in agg.items():
            vals = [g[col] for g in gs if g.get(col) is not None]
            if not vals:
                rec[f"{col}_{fn}"] = None
            elif fn == "sum":
                rec[f"{col}_{fn}"] = sum(vals)
            elif fn == "mean":
                rec[f"{col}_{fn}"] = statistics.mean(vals)
            elif fn == "median":
                rec[f"{col}_{fn}"] = statistics.median(vals)
            elif fn == "count":
                rec[f"{col}_{fn}"] = len(vals)
            elif fn == "min":
                rec[f"{col}_{fn}"] = min(vals)
            elif fn == "max":
                rec[f"{col}_{fn}"] = max(vals)
            elif fn == "std":
                rec[f"{col}_{fn}"] = statistics.pstdev(vals) if len(vals) > 1 else 0.0
        out.append(rec)
    return out

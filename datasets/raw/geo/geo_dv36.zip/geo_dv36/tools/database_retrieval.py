"""Database retrieval tools.

Thin placeholders for external-database queries. The heavy-weight network /
HTML-parsing code is intentionally omitted - implementations should be filled
in at task-execution time with the appropriate library (requests, biopython,
pubchempy, chembl_webresource_client, obspy, etc.). Each stub documents the
target database and the intended query semantics so an agent can recognise
when to call it and supply the missing implementation.
"""
from typing import Any


def websearch(query: str, max_results: int = 10) -> list[dict]:
    """Generic web search (Google/Bing/DuckDuckGo via a scraping backend).

    Use for: locating a dataset DOI, finding a paper's supplementary URL,
    or resolving an ambiguous reference. Returns a list of {title, url,
    snippet} dicts.
    """
    pass  # heavy: requires a search API key or headless browser


def fetch_url(url: str, timeout: int = 30) -> bytes:
    """HTTP GET with redirects. Used to download a CSV/PDF/JSON from a
    known URL (e.g., Zenodo record, GitHub raw file, journal OA page)."""
    pass  # heavy: network + retry/backoff


def query_pbdb(taxon: str = "", interval: str = "",
               base_name: str = "", show: str = "coords,phylo,time") -> list[dict]:
    """Paleobiology Database (PBDB) occurrence query.

    Endpoint: https://paleobiodb.org/data1.2/occs/list.csv
    Common params: base_name (e.g. 'Proboscidea'), interval (e.g. 'Permian'),
    taxon_reso ('genus','species'), show (output fields).
    Returns list of occurrence dicts with at least: occurrence_no,
    accepted_name, max_ma, min_ma, lng, lat, formation, collection_no.
    """
    pass  # heavy: REST client + CSV parsing + pagination


def query_macrostrat(strat_name: str = "", lat: float | None = None,
                     lng: float | None = None) -> dict:
    """Macrostrat strat-name / column lookup. Returns geological column
    metadata used for time-bin construction."""
    pass  # heavy


def query_zenodo(record_id: str) -> dict:
    """Zenodo record metadata + file list. Returns {title, files: [...]}.
    Used to fetch supplementary datasets for a paper."""
    pass  # heavy: REST + file download


def query_paleomap(lat: float, lng: float, age_ma: float) -> dict:
    """Paleocoordinate reconstruction (e.g. GPlates). Returns the
    paleo-lat/lng for a present-day location at a given age."""
    pass  # heavy: GPlates / pygplates


def query_doi(doi: str) -> dict:
    """Resolve a DOI to a Crossref metadata record + OA full-text URL
    (via Unpaywall)."""
    pass  # heavy: Crossref + Unpaywall REST


def query_geo_timescale(stage: str = "") -> dict:
    """ICS / GTS time-scale lookup. Returns numeric age boundaries (Ma)
    for a named stage/epoch/period."""
    pass  # heavy


def query_world_clim(lat: float, lng: float, year: int = 0) -> dict:
    """WorldClim / CHELSA / paleoclim climate raster lookup at a point
    in space and time."""
    pass  # heavy

"""Generic data-processing utilities.

Format conversion, reshaping, cleaning, and lightweight transforms that are
*not* specific to the task's scientific domain. Domain-specific transforms
(richness estimators, diversity simulators, RNN training, etc.) live in
biodiversity_analysis.py.
"""
from typing import Any
import csv
import json


def read_csv(path: str, delimiter: str = ",") -> list[dict]:
    """Parse CSV into list-of-dicts using csv.DictReader."""
    with open(path, newline="") as f:
        return list(csv.DictReader(f, delimiter=delimiter))


def write_csv(rows: list[dict], path: str) -> None:
    """Write list-of-dicts to CSV, using the first row's keys as header."""
    if not rows:
        open(path, "w").close()
        return
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def read_json(path: str) -> Any:
    with open(path) as f:
        return json.load(f)


def write_json(obj: Any, path: str, indent: int = 2) -> None:
    with open(path, "w") as f:
        json.dump(obj, f, indent=indent, default=str)


def read_excel(path: str, sheet_name: str | int | None = 0) -> list[dict]:
    """Read an .xlsx sheet into list-of-dicts via openpyxl/pandas."""
    import pandas as pd
    df = pd.read_excel(path, sheet_name=sheet_name)
    return df.to_dict("records")


def drop_missing(rows: list[dict], cols: list[str] | None = None) -> list[dict]:
    """Remove rows where any (or listed) columns are None/empty/NaN."""
    def bad(v):
        return v is None or v == "" or v != v  # NaN

    if cols is None:
        return [r for r in rows if not any(bad(v) for v in r.values())]
    return [r for r in rows if not any(bad(r.get(c)) for c in cols)]


def coerce_numeric(rows: list[dict], cols: list[str]) -> list[dict]:
    """Cast named columns to float; non-parseable -> None."""
    out = []
    for r in rows:
        r2 = dict(r)
        for c in cols:
            try:
                r2[c] = float(r2[c])
            except (TypeError, ValueError):
                r2[c] = None
        out.append(r2)
    return out


def filter_rows(rows: list[dict], column: str, allowed_values: list) -> list[dict]:
    """Keep only rows where row[column] is in allowed_values."""
    s = set(allowed_values)
    return [r for r in rows if r.get(column) in s]


def groupby_aggregate(rows: list[dict], by: str,
                      agg: dict[str, str]) -> list[dict]:
    """Group rows by `by` and apply per-column aggregations
    (mean|sum|min|max|count|nunique)."""
    from statistics import mean
    groups: dict = {}
    for r in rows:
        groups.setdefault(r[by], []).append(r)
    out = []
    for key, grp in groups.items():
        row = {by: key}
        for col, fn in agg.items():
            vals = [g[col] for g in grp if g.get(col) is not None]
            if fn == "mean":
                row[col] = mean(vals) if vals else None
            elif fn == "sum":
                row[col] = sum(vals)
            elif fn == "min":
                row[col] = min(vals) if vals else None
            elif fn == "max":
                row[col] = max(vals) if vals else None
            elif fn == "count":
                row[col] = len(vals)
            elif fn == "nunique":
                row[col] = len(set(vals))
        out.append(row)
    return out

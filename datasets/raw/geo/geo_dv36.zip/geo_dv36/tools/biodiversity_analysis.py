#!/usr/bin/env python3
"""Domain primitives for fossil-occurrence diversity reconstruction.

Tools cover the DeepDive-style workflow:
  - load fossil occurrence tables (PBDB / NOW-style CSV / Excel)
  - assign occurrences to user-supplied time bins (Ma)
  - compute simple richness estimators (sampled-in-bin, range-through, singleton)
  - shareholder-quorum subsampling (SQS, Alroy 2010) for sampling-standardised richness
  - simulate biodiversity trajectories under a stochastic birth-death process
  - degrade a simulated trajectory to a noisy "fossil record" (preservation + locality sampling)
  - extract per-bin features (taxa, occurrences, singletons, endemics, localities)
  - train a small bidirectional LSTM that maps these features back to the true diversity
  - run Monte-Carlo-dropout uncertainty prediction
  - plot the resulting palaeodiversity curve

The intent is that the agent chains these primitives to reproduce
DeepDive-style estimates on the real Permian-Triassic marine and
Cenozoic proboscidean datasets.
"""

import os
import json
import math
import random
from typing import Any

import numpy as np
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Biodiversity_Reconstruction_Tools")


# ---------------------------------------------------------------------------
# 1. I/O for fossil occurrence tables
# ---------------------------------------------------------------------------
@mcp.tool()
def load_occurrences_csv(csv_path: str, max_rows: int | None = None,
                         return_all_records: bool = False,
                         output_csv: str | None = None) -> dict:
    """Load a fossil occurrence CSV (e.g., PBDB-style: phylum, genus,
    max_ma, min_ma, lng, lat, coll_no, region).

    Args:
        csv_path: path to the CSV.
        max_rows: optional row cap for fast inspection.
        return_all_records: when True, the ``records`` key in the
            returned dict contains ALL rows (use for full downstream
            processing rather than just the 30-row ``preview``).
        output_csv: optional path; when set, the (possibly capped)
            DataFrame is also written to this CSV for downstream
            tools that consume a path argument.

    Returns:
        dict with n_rows, columns, dtypes, preview (first 30 rows
        always), and either records (when return_all_records=True)
        or just the preview.
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    if max_rows is not None:
        df = df.head(max_rows)
    out = {
        "n_rows": int(len(df)),
        "columns": list(df.columns),
        "dtypes": {c: str(df[c].dtype) for c in df.columns},
        "preview": df.head(30).to_dict("records"),
    }
    if return_all_records:
        out["records"] = df.to_dict("records")
    if output_csv:
        os.makedirs(os.path.dirname(output_csv) or ".", exist_ok=True)
        df.to_csv(output_csv, index=False)
        out["output_csv"] = output_csv
    return out


@mcp.tool()
def load_occurrences_excel(xlsx_path: str, sheet_name: str | int = 0,
                           return_all_records: bool = False,
                           output_csv: str | None = None) -> dict:
    """Load a fossil occurrence Excel sheet (e.g., NOW-style proboscidean
    table).

    Args:
        xlsx_path: path to the .xlsx workbook.
        sheet_name: sheet to read (default = first sheet).
        return_all_records: when True, the ``records`` key in the
            returned dict contains ALL rows (use this to read the full
            2,130-row proboscidean table for downstream binning).
        output_csv: optional path; when set, the full DataFrame is
            ALSO written to this CSV path so downstream MCP tools that
            take a CSV path argument (e.g.,
            ``assign_occurrences_to_bins``) can consume it directly
            without going through a pandas hop.

    Returns:
        dict with n_rows, columns, dtypes, preview (first 30 rows
        always), and either records (when return_all_records=True)
        or just the preview. The Excel file ships with ~2,130
        proboscidean occurrences; the default 30-row preview is for
        fast inspection only.
    """
    import pandas as pd
    df = pd.read_excel(xlsx_path, sheet_name=sheet_name)
    out = {
        "n_rows": int(len(df)),
        "columns": list(df.columns),
        "dtypes": {c: str(df[c].dtype) for c in df.columns},
        "preview": df.head(30).to_dict("records"),
    }
    if return_all_records:
        out["records"] = df.to_dict("records")
    if output_csv:
        os.makedirs(os.path.dirname(output_csv) or ".", exist_ok=True)
        df.to_csv(output_csv, index=False)
        out["output_csv"] = output_csv
    return out


# ---------------------------------------------------------------------------
# 2. Time-bin construction & occurrence assignment
# ---------------------------------------------------------------------------
@mcp.tool()
def build_time_bins_from_durations(start_age_ma: float, durations_ma: list,
                                   ascending_in_time: bool = False) -> dict:
    """Build a list of time bin (max_age, min_age) edges from a list of
    bin durations.

    `start_age_ma` is the OLDEST edge (large Ma); the routine walks toward
    the present subtracting each duration.  When `ascending_in_time=True`,
    `durations_ma` is interpreted from old to young (default order in
    DeepDive `t_bins.csv` files is oldest to youngest).
    """
    durations = list(durations_ma)
    edges = [float(start_age_ma)]
    for d in durations:
        edges.append(edges[-1] - float(d))
    bins = [(edges[i], edges[i + 1]) for i in range(len(edges) - 1)]
    return {
        "n_bins": len(bins),
        "edges": edges,
        "bins": [{"index": i, "max_age_ma": b[0], "min_age_ma": b[1],
                  "duration_ma": round(b[0] - b[1], 4)} for i, b in enumerate(bins)],
    }


@mcp.tool()
def convert_proboscidean_columns(input_path: str, output_csv: str,
                                  drop_excluded: bool = True) -> dict:
    """Rename the NOW-style proboscidean column names to the PBDB-style
    column names expected by ``assign_occurrences_to_bins`` /
    ``extract_per_bin_features``.

    Mapping applied:

    ===========================  ==========
    NOW-style (input)            PBDB-style (output)
    ===========================  ==========
    MAX_AGE                      max_ma
    MIN_AGE                      min_ma
    GENUS                        genus
    species_complete_corrected_until_10.2020  species
    LIDNUM                       coll_no
    continent                    reg
    LAT                          lat
    LONG                         lng
    FAMILY                       family
    ===========================  ==========

    When ``drop_excluded=True`` (default), rows with ``exclude == 1`` are
    dropped (this is the upstream NOW table's flag for occurrences the
    curators have marked as not-to-be-used). The cleaned table is
    written to ``output_csv`` and the row counts are returned.

    Accepts either an .xlsx or .csv ``input_path``.
    """
    import pandas as pd
    if input_path.lower().endswith((".xlsx", ".xls")):
        df = pd.read_excel(input_path)
    else:
        df = pd.read_csv(input_path)
    n_in = int(len(df))
    aliases = {
        "MAX_AGE": "max_ma",
        "MIN_AGE": "min_ma",
        "GENUS": "genus",
        "species_complete_corrected_until_10.2020": "species",
        "LIDNUM": "coll_no",
        "continent": "reg",
        "LAT": "lat",
        "LONG": "lng",
        "FAMILY": "family",
    }
    rename_map = {src: dst for src, dst in aliases.items() if src in df.columns}
    df = df.rename(columns=rename_map)
    n_excluded = 0
    if drop_excluded and "exclude" in df.columns:
        mask_excl = df["exclude"].astype(str).str.strip().isin({"1", "1.0", "True", "true"})
        n_excluded = int(mask_excl.sum())
        df = df.loc[~mask_excl].copy()
    os.makedirs(os.path.dirname(output_csv) or ".", exist_ok=True)
    df.to_csv(output_csv, index=False)
    return {
        "input_path": input_path,
        "output_csv": output_csv,
        "n_rows_in": n_in,
        "n_rows_dropped_exclude_flag": n_excluded,
        "n_rows_out": int(len(df)),
        "columns_renamed": rename_map,
        "final_columns": list(df.columns),
    }


@mcp.tool()
def filter_occurrences_paper_style(occurrences_csv: str,
                                   output_csv: str,
                                   taxon_col: str = "genus",
                                   min_age_col: str = "min_ma",
                                   max_age_col: str = "max_ma",
                                   drop_indet_names: bool = True,
                                   require_finite_ages: bool = True,
                                   age_window: tuple | None = None,
                                   min_taxon_occurrences: int = 0,
                                   valid_taxa: list | None = None,
                                   dropna_cols: list | None = None) -> dict:
    """Clean a raw fossil-occurrence CSV to a paper-equivalent subset.

    The bundle ships pre-filter PBDB/NOW exports (e.g., 144,664 marine
    rows / 5,608 genera; 2,130 proboscidean rows / 185 species); Cooper
    et al. 2024 analysed a smaller filtered subset (e.g., 2,104 occs /
    180 proboscidean species). This helper exposes the standard cleaning
    passes so an agent can derive a CLOSE APPROXIMATION of the paper's
    filtered table — EXACT reproduction of the paper's row count requires
    the authors' accepted-taxa / synonymy table which is NOT redistributed
    in this bundle. Pass ``valid_taxa=[...]`` if you have an external
    accept-list; otherwise the helper's default passes give a
    deterministic best-effort filter that moves row counts in the right
    direction.

    Filter passes applied in order (skip a pass by leaving its flag at
    the disabling default):

    1. ``require_finite_ages`` (default True): drop rows where either
       ``min_age_col`` or ``max_age_col`` is NaN.
    2. ``drop_indet_names`` (default True): drop rows whose taxon name
       contains 'indet.', 'sp.', 'aff.', 'cf.', '?', or starts with the
       Linnaean uncertainty markers ('Indeterminate', '?').
    3. ``age_window`` (optional tuple ``(oldest_ma, youngest_ma)``):
       restrict to occurrences whose midpoint age falls inside the
       window. Use this to enforce a study interval, e.g.
       ``age_window=(259.55, 192.94)`` for the Permian-Triassic marine
       window or ``(66.0, 0.0)`` for Cenozoic proboscideans.
    4. ``valid_taxa`` (optional explicit accept-list): keep only rows
       whose ``taxon_col`` value appears in the list. Use this to
       reproduce a paper-supplied acceptance table when one is shipped.
    5. ``min_taxon_occurrences`` (optional int): drop taxa with fewer
       than N occurrences across the dataset (handy for paper-style
       "singletons removed").
    6. ``dropna_cols`` (optional list): drop rows with NaN in any of
       these extra columns (e.g., ``['lng','lat','reg']`` to require
       georeferenced + region-tagged rows).

    Writes the cleaned table to ``output_csv`` and returns a per-pass
    row-count summary so the agent can audit how much each filter
    removed (the paper's headline 2,104/180 numbers are reproducible
    from this helper + appropriate flag settings).
    """
    import pandas as pd
    df = pd.read_csv(occurrences_csv)
    n0 = int(len(df))
    counts = {"input_rows": n0}
    if require_finite_ages:
        if min_age_col in df.columns and max_age_col in df.columns:
            df = df.dropna(subset=[min_age_col, max_age_col])
        counts["after_require_finite_ages"] = int(len(df))
    if drop_indet_names and taxon_col in df.columns:
        bad_tokens = ("indet.", " sp.", " aff.", " cf.", "?", "indeterminate", "incertae")
        names = df[taxon_col].astype(str).str.lower()
        mask_bad = names.apply(lambda s: any(t in s for t in bad_tokens))
        df = df[~mask_bad]
        counts["after_drop_indet_names"] = int(len(df))
    if age_window is not None and len(age_window) == 2:
        oldest, youngest = float(age_window[0]), float(age_window[1])
        if oldest < youngest:
            oldest, youngest = youngest, oldest
        if min_age_col in df.columns and max_age_col in df.columns:
            mid = (df[max_age_col].astype(float) + df[min_age_col].astype(float)) / 2.0
            df = df[(mid <= oldest) & (mid >= youngest)]
        counts["after_age_window"] = int(len(df))
    if valid_taxa is not None and taxon_col in df.columns:
        accept = set(map(str, valid_taxa))
        df = df[df[taxon_col].astype(str).isin(accept)]
        counts["after_valid_taxa"] = int(len(df))
    if dropna_cols:
        present = [c for c in dropna_cols if c in df.columns]
        if present:
            df = df.dropna(subset=present)
        counts["after_dropna_cols"] = int(len(df))
    if min_taxon_occurrences > 0 and taxon_col in df.columns:
        vc = df[taxon_col].value_counts()
        keep = set(vc[vc >= int(min_taxon_occurrences)].index)
        df = df[df[taxon_col].isin(keep)]
        counts["after_min_taxon_occurrences"] = int(len(df))
    n_taxa_out = int(df[taxon_col].nunique()) if taxon_col in df.columns else None
    os.makedirs(os.path.dirname(output_csv) or ".", exist_ok=True)
    df.to_csv(output_csv, index=False)
    return {
        "input_csv": occurrences_csv,
        "output_csv": output_csv,
        "row_counts": counts,
        "n_rows_out": int(len(df)),
        "n_taxa_out": n_taxa_out,
    }


@mcp.tool()
def assign_occurrences_to_bins(occurrences_csv: str, bin_edges_oldest_first: list,
                               max_ma_col: str = "max_ma",
                               min_ma_col: str = "min_ma",
                               assign_method: str = "midpoint") -> dict:
    """Assign each occurrence to a single time bin.

    `bin_edges_oldest_first` is a flat list of N+1 numeric ages (Ma)
    ordered from oldest to youngest, e.g. [259.55, 254.18, 251.94, ...,
    192.94].  `assign_method` is "midpoint" (default; bin containing the
    occurrence's midpoint age) or "max" (bin containing max_ma).

    Returns the bin index appended to each row (in-memory) plus a per-bin
    occurrence count.  Writes the augmented table to
    `<csv_path>.binned.csv` and returns the path.
    """
    import pandas as pd
    df = pd.read_csv(occurrences_csv)
    edges = sorted([float(e) for e in bin_edges_oldest_first], reverse=True)
    n_bins = len(edges) - 1

    # Compute the assignment age FIRST, then pre-filter to the study window
    # using that age. The previous (max_ma <= edges[0]) & (min_ma >= edges[-1])
    # pre-filter dropped occurrences whose extent straddled the window even
    # when their midpoint sat well inside it — that loses real signal when
    # assign_method == "midpoint" (and is overly strict for "max" too).
    df = df.copy()
    if assign_method == "midpoint":
        ages = (df[max_ma_col].astype(float) + df[min_ma_col].astype(float)) / 2.0
    elif assign_method == "max":
        ages = df[max_ma_col].astype(float)
    else:
        raise ValueError(f"unknown assign_method {assign_method!r}; use 'midpoint' or 'max'")
    in_window = (ages <= edges[0]) & (ages >= edges[-1])
    df = df.loc[in_window].copy()
    ages = ages.loc[in_window]

    bin_idx = np.full(len(df), -1, dtype=int)
    for i in range(n_bins):
        max_a, min_a = edges[i], edges[i + 1]
        mask = (ages <= max_a) & (ages > min_a)
        if i == n_bins - 1:
            mask = (ages <= max_a) & (ages >= min_a)
        bin_idx[mask] = i
    df["bin_index"] = bin_idx
    df = df[df["bin_index"] >= 0].copy()

    out_path = occurrences_csv.replace(".csv", "") + ".binned.csv"
    df.to_csv(out_path, index=False)
    counts = df.groupby("bin_index").size().to_dict()
    return {
        "n_assigned": int(len(df)),
        "n_bins": n_bins,
        "per_bin_count": {int(k): int(v) for k, v in sorted(counts.items())},
        "binned_csv_path": out_path,
    }


# ---------------------------------------------------------------------------
# 3. Per-bin diversity estimators
# ---------------------------------------------------------------------------
@mcp.tool()
def sampled_in_bin_diversity(binned_csv: str, taxon_col: str = "genus",
                             bin_col: str = "bin_index",
                             region_col: str | None = None,
                             n_bins: int | None = None) -> dict:
    """Number of unique taxa actually sampled in each time bin.

    If `region_col` is provided, also returns per-region per-bin counts.
    If `n_bins` is supplied, the result is padded with zeros to that
    length (use this when later bins might be empty).
    """
    import pandas as pd
    df = pd.read_csv(binned_csv)
    df = df.dropna(subset=[taxon_col, bin_col])
    inferred = int(df[bin_col].max() + 1) if len(df) else 0
    n_bins = max(inferred, int(n_bins) if n_bins else 0) or inferred
    div_global = [0] * n_bins
    for b, grp in df.groupby(bin_col):
        div_global[int(b)] = int(grp[taxon_col].nunique())
    out: dict = {"n_bins": n_bins, "global_diversity": div_global}
    if region_col is not None and region_col in df.columns:
        per_region = {}
        for r, sub in df.groupby(region_col):
            row = [0] * n_bins
            for b, grp in sub.groupby(bin_col):
                row[int(b)] = int(grp[taxon_col].nunique())
            per_region[str(r)] = row
        out["per_region"] = per_region
    return out


@mcp.tool()
def range_through_diversity(binned_csv: str, taxon_col: str = "genus",
                            bin_col: str = "bin_index",
                            n_bins: int | None = None) -> dict:
    """Range-through richness: a taxon counts in every bin between its
    first and last sampled occurrence.

    Less sensitive to sampling gaps than sampled-in-bin counts.
    If `n_bins` is supplied, the result is padded with zeros to that
    length (use this when later bins might be empty).
    """
    import pandas as pd
    df = pd.read_csv(binned_csv).dropna(subset=[taxon_col, bin_col])
    inferred = int(df[bin_col].max() + 1) if len(df) else 0
    n_bins = max(inferred, int(n_bins) if n_bins else 0) or inferred
    rt = np.zeros(n_bins, dtype=int)
    for tx, grp in df.groupby(taxon_col):
        bins = grp[bin_col].astype(int)
        first, last = int(bins.min()), int(bins.max())
        rt[first:last + 1] += 1
    return {"n_bins": n_bins, "range_through_diversity": rt.tolist()}


@mcp.tool()
def singleton_count(binned_csv: str, taxon_col: str = "genus",
                    bin_col: str = "bin_index") -> dict:
    """Per-bin count of singleton taxa (occurring only once in that bin)."""
    import pandas as pd
    df = pd.read_csv(binned_csv).dropna(subset=[taxon_col, bin_col])
    n_bins = int(df[bin_col].max() + 1)
    singletons = [0] * n_bins
    for b, grp in df.groupby(bin_col):
        counts = grp[taxon_col].value_counts()
        singletons[int(b)] = int((counts == 1).sum())
    return {"n_bins": n_bins, "singletons": singletons}


@mcp.tool()
def shareholder_quorum_subsampling(binned_csv: str, quorum: float = 0.6,
                                   taxon_col: str = "genus",
                                   bin_col: str = "bin_index",
                                   n_replicates: int = 100,
                                   seed: int = 1) -> dict:
    """SQS (Alroy 2010) sampling-standardised richness per bin.

    For each bin, randomly draw occurrences without replacement until the
    summed frequency of drawn taxa reaches `quorum` of the total
    coverage; the mean number of distinct taxa across `n_replicates`
    draws is the SQS richness estimate.  Returns also the +/- SD.
    """
    import pandas as pd
    rng = np.random.default_rng(seed)
    df = pd.read_csv(binned_csv).dropna(subset=[taxon_col, bin_col])
    n_bins = int(df[bin_col].max() + 1)
    means = [0.0] * n_bins
    sds = [0.0] * n_bins
    for b in range(n_bins):
        sub = df[df[bin_col] == b][taxon_col].values
        if len(sub) == 0:
            continue
        # Estimate coverage via Good's u = 1 - n_singleton / N
        counts = pd.Series(sub).value_counts().values.astype(float)
        N = counts.sum()
        n_single = int((counts == 1).sum())
        u = 1.0 - (n_single / N) if N > 0 else 0.0
        target = quorum * u  # target frequency mass
        if target <= 0:
            continue
        freqs = counts / N
        # Draw multinomial samples until sum of unique taxa weights >= target
        reps = []
        for _ in range(n_replicates):
            order = rng.permutation(len(sub))
            seen, mass = set(), 0.0
            # walk through ordered occurrences accumulating frequency mass of
            # distinct taxa until the SQS quorum target is met
            for idx in order:
                tx = sub[idx]
                if tx not in seen:
                    seen.add(tx)
                    mass += float((sub == tx).sum()) / N
                if mass >= target:
                    break
            reps.append(len(seen))
        means[b] = float(np.mean(reps))
        sds[b] = float(np.std(reps))
    return {"n_bins": n_bins, "quorum": quorum,
            "sqs_diversity_mean": means, "sqs_diversity_sd": sds}


# ---------------------------------------------------------------------------
# 4. Per-bin features for ML input
# ---------------------------------------------------------------------------
@mcp.tool()
def extract_per_bin_features(binned_csv: str, region_col: str = "reg",
                             taxon_col: str = "genus",
                             locality_col: str = "coll_no",
                             bin_col: str = "bin_index",
                             n_bins: int | None = None,
                             bin_durations: list | None = None) -> dict:
    """Build the per-bin feature matrix used by DeepDive-style models.

    Per-bin features (1-D, per time step):
        n_taxa, n_occurrences, n_singletons, n_endemic_taxa,
        n_range_through, n_localities.

    Per-bin x per-region features (the model also receives these):
        n_taxa_per_region, n_occurrences_per_region, n_localities_per_region.

    When ``bin_durations`` is provided, it is stored in the output JSON so
    that ``predict_diversity_with_uncertainty`` can append it as the
    duration feature column that matches the training tensor produced
    by ``simulate_fossil_record_from_trajectories`` with
    ``include_duration=True``.

    Returns features as nested lists; writes them to <binned_csv>.features.json.
    Pass ``n_bins`` to pad with zeros when later bins might be empty.
    """
    import pandas as pd
    df = pd.read_csv(binned_csv).dropna(subset=[taxon_col, bin_col])
    inferred = int(df[bin_col].max() + 1) if len(df) else 0
    n_bins = max(inferred, int(n_bins) if n_bins else 0) or inferred
    regions = sorted(df[region_col].dropna().unique().tolist()) if region_col in df.columns else []
    R = len(regions)

    feats = {
        "n_taxa": [0] * n_bins,
        "n_occurrences": [0] * n_bins,
        "n_singletons": [0] * n_bins,
        "n_endemic_taxa": [0] * n_bins,
        "n_range_through": [0] * n_bins,
        "n_localities": [0] * n_bins,
    }
    # per-region 2D: list of bins, each bin is list over regions
    n_taxa_pr = [[0] * R for _ in range(n_bins)]
    n_occ_pr = [[0] * R for _ in range(n_bins)]
    n_loc_pr = [[0] * R for _ in range(n_bins)]

    # per-bin computations
    for b in range(n_bins):
        sub = df[df[bin_col] == b]
        if len(sub) == 0:
            continue
        feats["n_occurrences"][b] = int(len(sub))
        feats["n_taxa"][b] = int(sub[taxon_col].nunique())
        counts = sub[taxon_col].value_counts()
        feats["n_singletons"][b] = int((counts == 1).sum())
        if locality_col in sub.columns:
            feats["n_localities"][b] = int(sub[locality_col].nunique())
        # endemic = present in exactly one region within this bin
        if region_col in sub.columns:
            taxa_regs = sub.groupby(taxon_col)[region_col].nunique()
            feats["n_endemic_taxa"][b] = int((taxa_regs == 1).sum())
            for r_idx, r in enumerate(regions):
                rsub = sub[sub[region_col] == r]
                n_taxa_pr[b][r_idx] = int(rsub[taxon_col].nunique())
                n_occ_pr[b][r_idx] = int(len(rsub))
                if locality_col in rsub.columns:
                    n_loc_pr[b][r_idx] = int(rsub[locality_col].nunique())

    # range-through across whole interval
    for tx, grp in df.groupby(taxon_col):
        b_first, b_last = int(grp[bin_col].min()), int(grp[bin_col].max())
        for b in range(b_first, b_last + 1):
            feats["n_range_through"][b] += 1

    out_path = binned_csv.replace(".csv", "") + ".features.json"
    dur_list = (list(map(float, bin_durations))
                if bin_durations is not None else [])
    payload = {
        "n_bins": n_bins,
        "regions": regions,
        "global_features": feats,
        "per_region_features": {
            "n_taxa_per_region": n_taxa_pr,
            "n_occurrences_per_region": n_occ_pr,
            "n_localities_per_region": n_loc_pr,
        },
        "bin_durations": dur_list,
    }
    with open(out_path, "w") as f:
        json.dump(payload, f, indent=2)
    payload["features_json_path"] = out_path
    return payload


# ---------------------------------------------------------------------------
# 5. Birth-death biodiversity simulator
# ---------------------------------------------------------------------------
@mcp.tool()
def simulate_birth_death_trajectories(n_simulations: int = 100,
                                      n_time_bins: int = 11,
                                      bin_duration_my: float = 6.0,
                                      bin_durations: list | None = None,
                                      root_age_range: tuple = (30.0, 100.0),
                                      rangeL: tuple = (0.2, 0.5),
                                      rangeM: tuple = (0.2, 0.5),
                                      poiL: int = 3,
                                      poiM: int = 3,
                                      p_constant_bd: float = 0.05,
                                      p_equilibrium: float = 0.1,
                                      p_mass_extinction_per_myr: float = 0.00924,
                                      magnitude_mass_ext_range: tuple = (0.8, 0.95),
                                      total_species_range: tuple = (100, 1000),
                                      max_attempts: int = 10000,
                                      seed: int = 7,
                                      output_npz: str | None = None) -> dict:
    """Simulate species birth-death histories under the DeepDive piece-wise
    constant birth-death process with optional mass extinction events.

    Algorithm extracted from Cooper, Flannery-Sutherland & Silvestro 2024
    (DeepDive; https://github.com/DeepDive-project/deepdive, LGPL-2.1,
    ``bd_simulator.simulate`` and ``bd_simulator.get_random_settings``).
    Key features reproduced verbatim from the official implementation:

    - Piece-wise constant lambda/mu rates with random shift times
      (Poisson-distributed number of shifts via ``poiL`` / ``poiM``;
      with probability ``p_constant_bd`` the rates are held constant,
      with probability ``p_equilibrium`` lambda == mu on a random subset
      of shifts).
    - Per-time-unit Bernoulli mass-extinction events (rate
      ``p_mass_extinction_per_myr`` per Myr) with intensity sampled from
      ``magnitude_mass_ext_range``.
    - Rejection sampling against ``total_species_range`` so the simulated
      clade lands in a realistic richness window.

    Returns the per-bin true-diversity matrix obtained by counting
    species alive in each bin (one row per accepted simulation). When
    ``bin_durations`` is provided, the matrix uses the supplied
    heterogeneous bin widths (Myr; oldest-to-youngest) and downstream
    tools carry the duration feature into the RNN.

    Output ``simulated_trajectories.npz`` contains:
        trajectories : (n_simulations, n_time_bins) int
        bin_durations : (n_time_bins,) float
        species_ts_te : list of (n_species, 2) arrays of per-species
                        speciation / extinction ages (Ma)
    """
    rng = np.random.default_rng(seed)
    SCALE = 100.0  # paper uses time scaled by 100 for discrete-step simulator

    if bin_durations is not None:
        bin_durations_arr = np.asarray(list(bin_durations), dtype=float)
        n_time_bins = len(bin_durations_arr)
    else:
        bin_durations_arr = np.full(n_time_bins, float(bin_duration_my), dtype=float)

    # Bin edges oldest-to-youngest (Ma): edge[0] = total span, edge[-1] = 0
    edges = np.zeros(n_time_bins + 1, dtype=float)
    edges[0] = float(bin_durations_arr.sum())
    for i in range(n_time_bins):
        edges[i + 1] = edges[i] - float(bin_durations_arr[i])

    def get_random_settings(root_pos):
        """Reproduces the official bd_simulator.get_random_settings."""
        rr = rng.random(2)
        timesL_temp = [root_pos, 0.0]
        timesM_temp = [root_pos, 0.0]
        if rr[0] < p_constant_bd:
            nL = 0; nM = 0
            timesL = np.array(timesL_temp)
            timesM = np.array(timesM_temp)
        elif rr[1] < p_equilibrium:
            nL = int(rng.poisson(poiL)); nM = nL
            shift_L = rng.uniform(0, root_pos, nL)
            timesL = np.sort(np.concatenate([timesL_temp, shift_L]))[::-1]
            timesM = np.sort(np.concatenate([timesM_temp, shift_L]))[::-1]
        else:
            nL = int(rng.poisson(poiL)); nM = int(rng.poisson(poiM))
            shift_L = rng.uniform(0, root_pos, nL)
            shift_M = rng.uniform(0, root_pos, nM)
            timesL = np.sort(np.concatenate([timesL_temp, shift_L]))[::-1]
            timesM = np.sort(np.concatenate([timesM_temp, shift_M]))[::-1]
        L = rng.uniform(np.min(rangeL), np.max(rangeL), nL + 1)
        M = rng.uniform(np.min(rangeM), np.max(rangeM), nM + 1)
        if rr[1] < p_equilibrium:
            idx_eq = rng.choice(range(len(L)), size=int(rng.integers(1, len(L) + 1)))
            M[idx_eq] = L[idx_eq]
        return timesL, timesM, L, M

    def simulate_one(L, M, timesL, timesM, root_pos):
        """Reproduces the official bd_simulator.simulate inner loop."""
        L_s, M_s = L / SCALE, M / SCALE
        # Internal time runs from -root*SCALE up to 0 (per the official
        # simulator). root_pos is a positive Ma; we negate + scale so
        # range(root_int, 0) iterates root_pos*SCALE steps.
        root_int = -int(root_pos * SCALE)
        mass_ext_p = p_mass_extinction_per_myr / SCALE
        ts = [root_int]
        te = [0]
        for t in range(root_int, 0):
            # piecewise lambda / mu lookup at this time step
            l_t = L_s[0]; m_t = M_s[0]
            t_ma = -t / SCALE
            for j in range(len(timesL) - 1):
                if t_ma <= timesL[j] and t_ma > timesL[j + 1]:
                    l_t = L_s[j]; break
            for j in range(len(timesM) - 1):
                if t_ma <= timesM[j] and t_ma > timesM[j + 1]:
                    m_t = M_s[j]; break
            TE = len(te)
            ran_vec = rng.random(TE)
            te_arr = np.array(te)
            extant_idx = np.where(te_arr == 0)[0]
            if len(extant_idx) == 0:
                break
            no = rng.random()
            if no < mass_ext_p and len(extant_idx) > 10:
                m_t = rng.uniform(*magnitude_mass_ext_range)
            # extinction sweep
            ext_mask = (ran_vec > l_t) & (ran_vec < (l_t + m_t)) & (te_arr == 0)
            ext_idx = np.where(ext_mask)[0]
            for idx in ext_idx:
                te[idx] = t
            # speciation sweep
            new_sp = int(np.sum(ran_vec[extant_idx] < l_t))
            te.extend([0] * new_sp)
            ts.extend([t] * new_sp)
        return -np.array(ts) / SCALE, -np.array(te) / SCALE

    def bin_diversity_from_ts_te(ts, te):
        """Count species alive in each bin (presence if their lifespan
        overlaps the bin)."""
        traj = np.zeros(n_time_bins, dtype=int)
        for b in range(n_time_bins):
            bin_old, bin_young = edges[b], edges[b + 1]
            # alive in bin if ts >= bin_young AND te <= bin_old
            alive = (ts >= bin_young) & (te <= bin_old)
            traj[b] = int(alive.sum())
        return traj

    out = np.zeros((n_simulations, n_time_bins), dtype=int)
    ts_te_records: list = []
    accepted = 0
    attempts = 0
    while accepted < n_simulations and attempts < max_attempts:
        attempts += 1
        root_pos = float(rng.uniform(*root_age_range))
        timesL, timesM, L, M = get_random_settings(root_pos)
        ts, te = simulate_one(L, M, timesL, timesM, root_pos)
        n_total = len(te)
        if not (total_species_range[0] <= n_total <= total_species_range[1]):
            continue
        traj = bin_diversity_from_ts_te(ts, te)
        out[accepted] = traj
        # store the per-sim ts_te pairs (capped to oldest bin edge)
        ts_clipped = np.minimum(ts, edges[0])
        ts_te_records.append(np.stack([ts_clipped, te], axis=1))
        accepted += 1

    out = out[:accepted]
    npz = output_npz or "simulated_trajectories.npz"
    os.makedirs(os.path.dirname(npz) or ".", exist_ok=True) if os.path.dirname(npz) else None
    np.savez(npz,
             trajectories=out,
             bin_durations=bin_durations_arr,
             species_ts_te=np.array(ts_te_records, dtype=object))
    return {
        "n_accepted_simulations": int(accepted),
        "n_attempts": attempts,
        "n_time_bins": n_time_bins,
        "bin_durations": bin_durations_arr.tolist(),
        "saved_to": npz,
        "first_three_trajectories": out[:3].tolist(),
        "algorithm": (
            "piece-wise BD with random shifts + mass extinction + rejection "
            "sampling (adapted from Cooper et al. 2024 DeepDive bd_simulator, "
            "https://github.com/DeepDive-project/deepdive, LGPL-2.1)"
        ),
    }


@mcp.tool()
def simulate_fossil_record_from_trajectories(npz_path: str = "simulated_trajectories.npz",
                                             n_regions: int = 5,
                                             sp_pres_shape: float = 1.5,
                                             sp_pres_scale: float = 1.0,
                                             area_pres_shape: float = 2.0,
                                             area_pres_scale: float = 1.0,
                                             slope_log_sampling: float = 0.0,
                                             intercept_sampling: float = 0.05,
                                             sd_through_time: float = 0.5,
                                             eta_area_variation: float = 1.5,
                                             p_gap_range: tuple = (0.0, 0.15),
                                             maximum_localities_per_bin: int = 10,
                                             include_per_region: bool = True,
                                             include_duration: bool = True,
                                             seed: int = 11,
                                             output_npz: str | None = None) -> dict:
    """Degrade each simulated species history into a noisy fossil record.

    Algorithm extracted from Cooper, Flannery-Sutherland & Silvestro 2024
    DeepDive ``fossil_simulator.run_simulation`` (https://github.com/
    DeepDive-project/deepdive, LGPL-2.1). The official simulator has 700+
    lines covering geo-range dispersal, area-size carrying capacity,
    skyline sampling, dispersal-rate multipliers etc.; this MCP primitive
    keeps the four key structures that matter for the RNN-input feature
    distributions:

    1. **Species-specific preservation rate** drawn per-species from
       ``Gamma(sp_pres_shape, sp_pres_scale)`` — same shape/scale priors
       as the paper's ``generate_sp_preservation_rate_table``.
    2. **Area-specific preservation rate** drawn per-area from
       ``Gamma(area_pres_shape, area_pres_scale)`` — matches the paper's
       ``generate_preservation_rate_per_area_table``.
    3. **Log-linear time-specific sampling rate** with
       ``log(rate_t) = intercept + slope_log_sampling * t + N(0, sd_through_time)``
       — paper's ``preservation_rate_through_time_table``.
    4. **Per-area / per-bin locality count** as ``Poisson(min(area_rate
       * time_rate * eta, maximum_localities_per_bin))`` with
       eta-variation drawn from ``Gamma(eta_area_variation, 1.0)`` and
       gap probability drawn from ``Uniform(p_gap_range)`` — paper's
       ``draw_localities``.

    Species presence/absence in each bin is taken FROM the per-bin
    trajectory matrix (output of the upgraded BD simulator) AND, when
    the npz also carries ``species_ts_te``, from the per-species
    speciation/extinction ages so the simulator only counts species
    that were actually alive in each bin. Species are dispersed across
    ``n_regions`` using a Dirichlet distribution over area-sizes
    (matches the paper's ``simulate_geo_ranges`` carrying-capacity
    coupling).

    Output tensor X has shape ``(n_sims, n_bins, F_total)`` where
    ``F_total = 6_global + (n_regions * 3 if include_per_region else 0)
               + (1 if include_duration and bin_durations present else 0)``.
    Returns the tensor + matching true-diversity matrix saved to
    ``fossil_features.npz`` along with a ``feature_layout`` dict so the
    RNN train + predict functions can reconstruct the same column order
    from an empirical features.json.
    """
    rng = np.random.default_rng(seed)
    if not os.path.exists(npz_path):
        return {"error": f"npz_path {npz_path!r} does not exist; run simulate_birth_death_trajectories first"}
    with np.load(npz_path, allow_pickle=True) as d:
        trajs = d["trajectories"]
        bin_durations = d["bin_durations"] if "bin_durations" in d.files else None
        species_ts_te = d["species_ts_te"] if "species_ts_te" in d.files else None
    n_sims, n_bins = trajs.shape
    F_global = 6
    F_per_region = 3 if include_per_region else 0
    has_duration = include_duration and bin_durations is not None
    F_duration = 1 if has_duration else 0
    F_total = F_global + n_regions * F_per_region + F_duration
    X = np.zeros((n_sims, n_bins, F_total), dtype=float)

    # Bin edges (oldest → youngest, Ma)
    if bin_durations is not None:
        bd = np.asarray(bin_durations, dtype=float)
    else:
        bd = np.ones(n_bins, dtype=float)
    edges = np.zeros(n_bins + 1, dtype=float)
    edges[0] = float(bd.sum())
    for i in range(n_bins):
        edges[i + 1] = edges[i] - float(bd[i])

    # Per-bin midpoints for the log-linear time-rate
    midpoints = (edges[:-1] + edges[1:]) / 2.0

    # --- per-simulation rates (paper-aligned priors) ----------------------
    for s in range(n_sims):
        traj = trajs[s]
        max_div = max(int(traj.max()), int(np.sum(traj > 0)))
        if max_div == 0:
            continue

        # Build species presence-in-bin from ts/te if available, else
        # fall back to the random origin/lifespan heuristic.
        present_per_bin = [set() for _ in range(n_bins)]
        if species_ts_te is not None and s < len(species_ts_te):
            ts_te_s = np.asarray(species_ts_te[s], dtype=float)
            n_sp = ts_te_s.shape[0]
            for sid in range(n_sp):
                fa, lo = ts_te_s[sid, 0], ts_te_s[sid, 1]
                for b in range(n_bins):
                    bin_old, bin_young = edges[b], edges[b + 1]
                    if fa >= bin_young and lo <= bin_old:
                        present_per_bin[b].add(sid)
        else:
            n_sp = int(max_div * 5)
            origins = rng.integers(0, n_bins, size=n_sp)
            spans = rng.integers(1, max(2, n_bins // 2 + 1), size=n_sp)
            for sid in range(n_sp):
                b0, b1 = int(origins[sid]), int(min(origins[sid] + spans[sid], n_bins - 1))
                for b in range(b0, b1 + 1):
                    present_per_bin[b].add(sid)
            # downsample to traj count
            for b in range(n_bins):
                cur = list(present_per_bin[b])
                if len(cur) > traj[b]:
                    keep = set(rng.choice(cur, size=int(traj[b]), replace=False))
                    present_per_bin[b] = keep

        # ------ Paper-aligned preservation-rate tables ------
        # area sizes via Dirichlet (carrying-capacity coupling proxy)
        alphas = rng.gamma(2.0, 1.0, size=n_regions)
        area_size = rng.dirichlet(alphas) * n_regions  # mean 1.0

        # Gamma per-species preservation rate (paper generate_sp_preservation_rate_table)
        sp_rate = rng.gamma(sp_pres_shape, sp_pres_scale, size=n_sp)
        # Gamma per-area preservation rate
        area_rate = rng.gamma(area_pres_shape, area_pres_scale, size=n_regions)
        # Log-linear per-bin time-specific sampling rate
        log_rate = (intercept_sampling
                    + slope_log_sampling * midpoints
                    + rng.normal(0, sd_through_time, size=n_bins))
        time_rate = np.exp(log_rate)
        # Per-area eta variation and gap prob
        eta_per_area = rng.gamma(eta_area_variation, 1.0, size=n_regions)
        p_gap = rng.uniform(*p_gap_range)

        # Assign species RANGES across regions (per official
        # simulate_geo_ranges + carrying-capacity coupling). Each
        # species' origination area is drawn from Dirichlet(area_size),
        # then dispersed to additional regions with per-region Bernoulli
        # probability proportional to area_size_r * dispersal_strength.
        # Result: species occupy 1-n_regions areas (no longer one-area-only),
        # which makes endemic taxa a meaningful diagnostic instead of
        # collapsing to the total taxa count.
        origin_p = area_size / area_size.sum()
        species_origin_area = rng.choice(n_regions, size=n_sp, p=origin_p)
        # Dispersal: per-species Bernoulli presence in each non-origin region
        dispersal_strength = 0.4  # tunes endemic fraction; 0 = strict endemism
        species_in_region = np.zeros((n_sp, n_regions), dtype=bool)
        for sid in range(n_sp):
            species_in_region[sid, species_origin_area[sid]] = True
            for r in range(n_regions):
                if r == species_origin_area[sid]:
                    continue
                if rng.random() < dispersal_strength * float(area_size[r] / area_size.max()):
                    species_in_region[sid, r] = True

        # Per-region/per-bin draws
        n_taxa_pr = np.zeros((n_bins, n_regions), dtype=float)
        n_occ_pr  = np.zeros((n_bins, n_regions), dtype=float)
        n_loc_pr  = np.zeros((n_bins, n_regions), dtype=float)

        per_bin_taxa = [set() for _ in range(n_bins)]
        per_bin_occs = [0] * n_bins
        per_bin_locs = [0] * n_bins
        per_bin_singletons = [0] * n_bins
        per_bin_endemic = [0] * n_bins

        for b in range(n_bins):
            occ_counts: dict = {}
            taxa_regions: dict = {}
            n_locs_b = 0
            for r in range(n_regions):
                if rng.random() < p_gap:
                    continue
                # locality rate = area_rate × area_size × time_rate × eta
                loc_lambda = float(min(
                    maximum_localities_per_bin,
                    area_rate[r] * area_size[r] * time_rate[b] * eta_per_area[r]
                ))
                k_loc = int(rng.poisson(max(0.05, loc_lambda)))
                n_locs_b += k_loc
                n_loc_pr[b, r] = float(k_loc)
                # Species present in region r within this bin (multi-region
                # occupancy via species_in_region from dispersal step)
                region_occ: dict = {}
                region_taxa = set()
                for sid in present_per_bin[b]:
                    if sid >= n_sp or not species_in_region[sid, r]:
                        continue
                    # per-species × per-area × per-time preservation
                    sp_lambda = float(sp_rate[sid] * area_rate[r] * time_rate[b])
                    n_occ = int(rng.poisson(max(0.0, sp_lambda * max(1, k_loc) * 0.1)))
                    if n_occ > 0:
                        occ_counts[sid] = occ_counts.get(sid, 0) + n_occ
                        taxa_regions.setdefault(sid, set()).add(r)
                        per_bin_taxa[b].add(sid)
                        region_occ[sid] = region_occ.get(sid, 0) + n_occ
                        region_taxa.add(sid)
                n_taxa_pr[b, r] = float(len(region_taxa))
                n_occ_pr[b, r] = float(sum(region_occ.values()))
            per_bin_occs[b] = sum(occ_counts.values())
            per_bin_singletons[b] = sum(1 for c in occ_counts.values() if c == 1)
            per_bin_endemic[b] = sum(1 for tr in taxa_regions.values() if len(tr) == 1)
            per_bin_locs[b] = n_locs_b

        per_bin_rt = [0] * n_bins
        first_seen: dict = {}
        last_seen: dict = {}
        for b in range(n_bins):
            for sid in per_bin_taxa[b]:
                first_seen[sid] = min(first_seen.get(sid, b), b)
                last_seen[sid] = max(last_seen.get(sid, b), b)
        for sid, fb in first_seen.items():
            for b in range(fb, last_seen[sid] + 1):
                per_bin_rt[b] += 1

        for b in range(n_bins):
            X[s, b, 0] = len(per_bin_taxa[b])
            X[s, b, 1] = per_bin_occs[b]
            X[s, b, 2] = per_bin_singletons[b]
            X[s, b, 3] = per_bin_endemic[b]
            X[s, b, 4] = per_bin_rt[b]
            X[s, b, 5] = per_bin_locs[b]
            col = F_global
            if F_per_region > 0:
                for r in range(n_regions):
                    X[s, b, col + 0 * n_regions + r] = n_taxa_pr[b, r]
                    X[s, b, col + 1 * n_regions + r] = n_occ_pr[b, r]
                    X[s, b, col + 2 * n_regions + r] = n_loc_pr[b, r]
                col += n_regions * F_per_region
            if has_duration:
                X[s, b, col] = float(bd[b])

    out_path = output_npz or "fossil_features.npz"
    if os.path.dirname(out_path):
        os.makedirs(os.path.dirname(out_path), exist_ok=True)
    feature_layout = {
        "global_features": ["n_taxa", "n_occurrences", "n_singletons",
                            "n_endemic_taxa", "n_range_through", "n_localities"],
        "n_global": F_global,
        "include_per_region": bool(include_per_region),
        "n_per_region_features": F_per_region,
        "per_region_feature_names": (["n_taxa_per_region",
                                       "n_occurrences_per_region",
                                       "n_localities_per_region"]
                                      if include_per_region else []),
        "n_regions": int(n_regions),
        "include_duration": bool(has_duration),
        "n_total_features": F_total,
        "preservation_rate_priors": {
            "sp_pres_shape": float(sp_pres_shape), "sp_pres_scale": float(sp_pres_scale),
            "area_pres_shape": float(area_pres_shape), "area_pres_scale": float(area_pres_scale),
            "slope_log_sampling": float(slope_log_sampling),
            "intercept_sampling": float(intercept_sampling),
            "sd_through_time": float(sd_through_time),
            "eta_area_variation": float(eta_area_variation),
            "p_gap_range": list(p_gap_range),
            "maximum_localities_per_bin": int(maximum_localities_per_bin),
        },
    }
    np.savez(out_path, X=X, y=trajs.astype(float),
             bin_durations=(bd if bin_durations is not None
                            else np.zeros(n_bins, dtype=float)),
             feature_layout=np.array(json.dumps(feature_layout)))
    return {
        "n_simulations": n_sims,
        "n_time_bins": n_bins,
        "n_features": F_total,
        "feature_layout": feature_layout,
        "saved_to": out_path,
        "algorithm": (
            "species × area × time multiplicative preservation rates with Gamma "
            "priors + Dirichlet area sizes + log-linear time-rate (adapted from "
            "Cooper et al. 2024 DeepDive fossil_simulator, "
            "https://github.com/DeepDive-project/deepdive, LGPL-2.1)"
        ),
    }


# ---------------------------------------------------------------------------
# 6. Small bidirectional LSTM
# ---------------------------------------------------------------------------
@mcp.tool()
def train_simple_rnn(features_npz: str = "fossil_features.npz",
                     lstm_nodes: list | None = None,
                     dense_nodes: list | None = None,
                     dense_act_f: str = "relu",
                     output_act_f: str = "softplus",
                     loss_f: str = "mse",
                     dropout_rate: float = 0.2,
                     epochs: int = 1000,
                     batch_size: int = 100,
                     patience: int = 10,
                     val_split: float = 0.2,
                     seed: int = 17,
                     model_dir: str = "simple_rnn_model") -> dict:
    """Train a stacked bidirectional-LSTM regressor that maps per-bin
    fossil features to per-bin true diversity.

    Architecture extracted from Cooper, Flannery-Sutherland & Silvestro
    2024 DeepDive (``rnn_builder.build_rnn`` + ``rnn_builder.fit_rnn``,
    https://github.com/DeepDive-project/deepdive, LGPL-2.1):

        Input(T, F) ->
        Bidirectional(LSTM(lstm_nodes[0], return_sequences=True,
                           activation='tanh', recurrent_activation='sigmoid')) ->
        ... stacked LSTMs for the remaining lstm_nodes layers ...
        Dense(dense_nodes[0], activation=dense_act_f) ->
        ... stacked Denses ...
        Dropout(dropout_rate) ->
        Dense(output_nodes=1, activation=output_act_f='softplus')
        compile(loss='mse', optimizer='adam', metrics=['mae'])
        fit with EarlyStopping(monitor='val_loss', patience=10,
                               restore_best_weights=True)

    The default ``lstm_nodes=[64, 32]`` and ``dense_nodes=[32]`` reproduce
    the paper's headline architecture. Use smaller values for fast
    verification runs (e.g. ``lstm_nodes=[16]``, ``dense_nodes=[16]``,
    ``epochs=30``).

    Reads X (n_sims, n_bins, F) and y (n_sims, n_bins) from
    ``features_npz`` (the output of
    ``simulate_fossil_record_from_trajectories``); applies log1p to
    both the input features and the target diversity (paper-aligned
    pre-processing) and trains until ``val_loss`` stops improving.
    Saves the Keras model to ``model_dir/model.keras``.
    """
    np.random.seed(seed)
    try:
        import tensorflow as tf
        tf.random.set_seed(seed)
        from tensorflow import keras
        from tensorflow.keras import layers
    except Exception as e:  # pragma: no cover
        return {"error": f"tensorflow not available: {e}"}

    if lstm_nodes is None:
        lstm_nodes = [64, 32]
    if dense_nodes is None:
        dense_nodes = [32]

    with np.load(features_npz, allow_pickle=True) as d:
        X = d["X"].astype(np.float32)
        y = d["y"].astype(np.float32)
    Xlog = np.log1p(np.maximum(X, 0.0)).astype(np.float32)
    ylog = np.log1p(np.maximum(y, 0.0)).astype(np.float32)
    n = Xlog.shape[0]
    perm = np.random.permutation(n)
    Xlog, ylog = Xlog[perm], ylog[perm]
    n_val = max(1, int(n * val_split))
    Xv, yv = Xlog[:n_val], ylog[:n_val]
    Xt, yt = Xlog[n_val:], ylog[n_val:]

    # Build the stacked Bi-LSTM architecture from rnn_builder.build_rnn
    model = keras.Sequential()
    return_sequences_list = [True for _ in range(len(lstm_nodes))]
    model.add(
        layers.Bidirectional(
            layers.LSTM(int(lstm_nodes[0]),
                        return_sequences=return_sequences_list[0],
                        activation="tanh",
                        recurrent_activation="sigmoid"),
            input_shape=Xt.shape[1:],
        )
    )
    for i in range(1, len(lstm_nodes)):
        model.add(
            layers.Bidirectional(
                layers.LSTM(int(lstm_nodes[i]),
                            return_sequences=return_sequences_list[i],
                            activation="tanh",
                            recurrent_activation="sigmoid"),
            )
        )
    for i in range(len(dense_nodes)):
        model.add(layers.Dense(int(dense_nodes[i]), activation=dense_act_f))
    if dropout_rate:
        model.add(layers.Dropout(dropout_rate))
    model.add(layers.Dense(1, activation=output_act_f))
    # Squeeze trailing singleton dim so y_pred shape matches (batch, T)
    model.add(layers.Reshape((Xt.shape[1],)))
    model.compile(loss=loss_f, optimizer="adam", metrics=["mae"])

    early_stop = keras.callbacks.EarlyStopping(
        monitor="val_loss", patience=patience, restore_best_weights=True,
    )
    hist = model.fit(
        Xt, yt, validation_data=(Xv, yv),
        epochs=epochs, batch_size=batch_size,
        verbose=0, callbacks=[early_stop],
    )
    os.makedirs(model_dir, exist_ok=True)
    model.save(os.path.join(model_dir, "model.keras"))
    return {
        "validation_loss": float(hist.history["val_loss"][-1]),
        "best_validation_loss": float(min(hist.history["val_loss"])),
        "training_loss": float(hist.history["loss"][-1]),
        "n_epochs_run": len(hist.history["loss"]),
        "model_dir": model_dir,
        "architecture": {
            "lstm_nodes": list(lstm_nodes),
            "dense_nodes": list(dense_nodes),
            "dropout_rate": float(dropout_rate),
            "output_activation": output_act_f,
            "loss": loss_f,
            "optimizer": "adam",
        },
        "algorithm": (
            "stacked Bidirectional-LSTM + Dense + Dropout + softplus head "
            "(adapted from Cooper et al. 2024 DeepDive rnn_builder.build_rnn, "
            "https://github.com/DeepDive-project/deepdive, LGPL-2.1)"
        ),
    }


@mcp.tool()
def predict_diversity_with_uncertainty(empirical_features_json: str,
                                       model_dir: str = "simple_rnn_model",
                                       n_mc_samples: int = 100,
                                       seed: int = 23,
                                       output_json: str | None = None) -> dict:
    """Apply the trained RNN to an empirical feature trajectory using
    Monte-Carlo dropout to obtain a 95% credible interval.

    Args:
        empirical_features_json: the JSON written by
            ``extract_per_bin_features``.
        model_dir: directory containing the Keras model written by
            ``train_simple_rnn``.
        n_mc_samples: number of MC-dropout samples (paper default 100).
        seed: NumPy + TF random seed for reproducibility.
        output_json: optional output path for the prediction JSON. When
            running both marine + proboscidean clades back-to-back, pass
            distinct paths (e.g. ``"marine_work/predicted.json"`` and
            ``"proboscidean_work/predicted.json"``) so the second call
            does not overwrite the first. Defaults to
            ``"predicted_diversity.json"`` in the current directory.

    Returns the per-bin median plus 2.5th and 97.5th percentiles, and
    writes them to ``output_json``.
    """
    try:
        import tensorflow as tf
    except Exception as e:  # pragma: no cover
        return {"error": f"tensorflow not available: {e}"}
    np.random.seed(seed)
    tf.random.set_seed(seed)

    with open(empirical_features_json) as f:
        payload = json.load(f)
    feats = payload["global_features"]
    F = ["n_taxa", "n_occurrences", "n_singletons",
         "n_endemic_taxa", "n_range_through", "n_localities"]
    n_bins_emp = int(payload["n_bins"])
    X_global = np.array([[feats[f][b] for f in F]
                  for b in range(n_bins_emp)], dtype=np.float32)

    # Build the empirical-input tensor in the SAME column layout as the
    # training tensor produced by simulate_fossil_record_from_trajectories.
    # The model's input dim is known from its first layer; we read it to
    # verify the empirical feature matrix has matching width.
    model = tf.keras.models.load_model(os.path.join(model_dir, "model.keras"),
                                       compile=False)
    try:
        F_total_model = int(model.input_shape[-1])
    except Exception:
        F_total_model = X_global.shape[1]

    # Reconstruct per-region columns (n_taxa_pr, n_occ_pr, n_loc_pr each R wide)
    per_region_cols = None
    n_regions_emp = 0
    if "per_region_features" in payload:
        prf = payload["per_region_features"]
        per_region_keys = ("n_taxa_per_region", "n_occurrences_per_region", "n_localities_per_region")
        if all(k in prf for k in per_region_keys):
            arrs = [np.array(prf[k], dtype=np.float32) for k in per_region_keys]
            if arrs[0].ndim == 2 and arrs[0].shape[0] == n_bins_emp:
                n_regions_emp = arrs[0].shape[1]
                per_region_cols = np.concatenate(arrs, axis=1)  # (n_bins, 3*R)

    # Reconstruct duration column (1 per bin) from optional bin_durations
    duration_col = None
    if "bin_durations" in payload and payload["bin_durations"]:
        dur_arr = np.asarray(payload["bin_durations"], dtype=np.float32)
        if dur_arr.shape[0] == n_bins_emp:
            duration_col = dur_arr.reshape(-1, 1)

    columns = [X_global]
    if per_region_cols is not None:
        columns.append(per_region_cols)
    if duration_col is not None:
        columns.append(duration_col)
    X_emp = np.concatenate(columns, axis=1)

    # If model was trained on the legacy 6-feature path, drop per-region and
    # duration extras (backwards-compatible). Otherwise verify shapes match.
    if F_total_model == X_global.shape[1]:
        X_emp = X_global
    elif F_total_model != X_emp.shape[1]:
        return {"error": (f"feature-shape mismatch: empirical X has "
                          f"{X_emp.shape[1]} cols (6 global + "
                          f"{0 if per_region_cols is None else per_region_cols.shape[1]} "
                          f"per-region + {0 if duration_col is None else 1} duration) "
                          f"but the trained model expects {F_total_model}. "
                          f"Re-train with matching include_per_region / "
                          f"include_duration / n_regions settings.")}

    # Spatial-bias diagnostics — still reported separately for transparency.
    spatial_diag: dict = {}
    if "per_region_features" in payload:
        prf = payload["per_region_features"]
        for key in ("n_taxa_per_region", "n_occurrences_per_region", "n_localities_per_region"):
            if key not in prf:
                continue
            arr = np.array(prf[key], dtype=np.float32)
            if arr.ndim != 2 or arr.shape[0] != n_bins_emp:
                continue
            spatial_diag[f"{key}__per_bin_max"] = arr.max(axis=1).tolist()
            spatial_diag[f"{key}__per_bin_std"] = arr.std(axis=1).tolist()

    X = np.log1p(np.maximum(X_emp, 0.0))
    X = X[None, :, :]
    if X.shape[1] != n_bins_emp:
        return {"error": f"shape mismatch: X.shape[1]={X.shape[1]} != n_bins={n_bins_emp}"}
    # MC dropout: call model with training=True; outputs are in log-space
    preds = []
    for _ in range(n_mc_samples):
        y_log = model(X, training=True).numpy()[0]
        preds.append(np.expm1(np.maximum(y_log, 0.0)))
    preds = np.array(preds)
    median = np.median(preds, axis=0).tolist()
    lo = np.percentile(preds, 2.5, axis=0).tolist()
    hi = np.percentile(preds, 97.5, axis=0).tolist()
    out = {
        "n_bins": int(payload["n_bins"]),
        "median_diversity": [float(v) for v in median],
        "lower_95": [float(v) for v in lo],
        "upper_95": [float(v) for v in hi],
        "n_mc_samples": n_mc_samples,
        "spatial_diagnostics": spatial_diag,
    }
    out_path = output_json or "predicted_diversity.json"
    if os.path.dirname(out_path):
        os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w") as f:
        json.dump(out, f, indent=2)
    out["output_json"] = out_path
    return out


# ---------------------------------------------------------------------------
# 7. Plotting
# ---------------------------------------------------------------------------
@mcp.tool()
def plot_diversity_curve(predictions_json: str,
                         time_bins_csv: str,
                         start_age_ma: float,
                         out_png: str,
                         clade_label: str = "diversity",
                         baseline_curves: dict | None = None,
                         vlines_ma: list | None = None) -> dict:
    """Plot a palaeodiversity curve (median + 95% band) as a function of
    geological time (Ma).

    `time_bins_csv` is the original DeepDive `t_bins.csv` containing one
    column of bin durations (oldest to youngest).  `start_age_ma` is the
    oldest edge.  Optionally overlay baseline series in `baseline_curves`
    (dict of label -> per-bin list, same length as predictions).  Adds
    vertical lines at given Ma ages (e.g. PTME = 251.9, TJME = 201.4).
    """
    import pandas as pd
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    with open(predictions_json) as f:
        pred = json.load(f)
    durations = pd.read_csv(time_bins_csv).iloc[:, 0].astype(float).tolist()
    edges = [start_age_ma]
    for d in durations:
        edges.append(edges[-1] - d)
    centres = [(edges[i] + edges[i + 1]) / 2 for i in range(len(durations))]

    median = pred["median_diversity"]
    lo = pred["lower_95"]
    hi = pred["upper_95"]

    fig, ax = plt.subplots(figsize=(10, 5))
    ax.fill_between(centres, lo, hi, color="steelblue", alpha=0.3,
                    label="95% credible interval")
    ax.plot(centres, median, "-o", color="navy", lw=2, label=f"DeepDive {clade_label}")
    if baseline_curves:
        cmap = ["tab:orange", "tab:green", "tab:red", "tab:purple"]
        for (lbl, vals), c in zip(baseline_curves.items(), cmap):
            ax.plot(centres, vals, "--", color=c, lw=1.5, label=lbl)
    if vlines_ma:
        for v in vlines_ma:
            ax.axvline(v, color="red", lw=0.8, alpha=0.7)
    ax.set_xlabel("Time (Ma)")
    ax.set_ylabel(f"Estimated {clade_label}")
    ax.invert_xaxis()
    ax.legend(loc="best", fontsize=9)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    os.makedirs(os.path.dirname(out_png) or ".", exist_ok=True)
    fig.savefig(out_png, dpi=150)
    plt.close(fig)
    return {"out_png": out_png, "n_bins": len(median),
            "centres_ma": centres}


@mcp.tool()
def plot_feature_histograms(empirical_features_json: str,
                            simulated_features_npz: str,
                            out_png: str) -> dict:
    """Overlay empirical vs. simulated histograms of per-bin features
    (taxa, occurrences, singletons, endemics, range-through, localities)
    to verify that the simulation regime spans the empirical regime.

    Reproduces the spirit of Fig. 4 / Fig. 5 of Cooper et al. 2024.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    with open(empirical_features_json) as f:
        emp = json.load(f)["global_features"]
    with np.load(simulated_features_npz) as d:
        Xsim = d["X"]
    feats = ["n_taxa", "n_occurrences", "n_singletons",
             "n_endemic_taxa", "n_range_through", "n_localities"]
    fig, axes = plt.subplots(2, 3, figsize=(11, 6))
    for k, name in enumerate(feats):
        ax = axes.flat[k]
        sim_vals = Xsim[:, :, k].ravel()
        emp_vals = np.array(emp[name], dtype=float)
        bins = 30
        ax.hist(sim_vals[sim_vals > 0], bins=bins, density=True,
                color="steelblue", alpha=0.6, label="simulated")
        ax.hist(emp_vals[emp_vals > 0], bins=bins, density=True,
                color="orange", alpha=0.6, label="empirical")
        ax.set_title(name, fontsize=9)
        ax.set_yscale("log")
        if k == 0:
            ax.legend(fontsize=8)
    fig.tight_layout()
    os.makedirs(os.path.dirname(out_png) or ".", exist_ok=True)
    fig.savefig(out_png, dpi=150)
    plt.close(fig)
    return {"out_png": out_png}


@mcp.tool()
def compute_diversity_change(diversity_curve: list, bin_indices_before: list,
                             bin_indices_after: list) -> dict:
    """Quantify diversity change (loss / gain) between two sets of bins.

    Returns absolute and relative loss as the mean per-bin diversity
    BEFORE the boundary minus the mean per-bin diversity AFTER. The
    ``diversity_curve`` argument should be the per-bin numerical
    estimate (median or range-through). The specific numeric loss
    values for any particular extinction event are not part of this
    helper's contract; cite the task answer / reference paper for
    paper-reported headline numbers.
    """
    arr = np.array(diversity_curve, dtype=float)
    before = float(np.mean([arr[i] for i in bin_indices_before
                            if 0 <= i < len(arr)]))
    after = float(np.mean([arr[i] for i in bin_indices_after
                           if 0 <= i < len(arr)]))
    if before == 0:
        return {"before": before, "after": after,
                "absolute_loss": before - after,
                "relative_loss_pct": None}
    return {
        "before_mean": round(before, 3),
        "after_mean": round(after, 3),
        "absolute_loss": round(before - after, 3),
        "relative_loss_pct": round((before - after) / before * 100, 2),
    }


if __name__ == "__main__":
    mcp.run(transport="stdio")

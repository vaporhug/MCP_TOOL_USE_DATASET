#!/usr/bin/env python3
"""Domain primitives for fossil-occurrence diversity reconstruction.

Tools cover the DeepDive-style workflow:
  - load fossil occurrence tables (PBDB / NOW-style CSV / Excel)
  - assign occurrences to user-supplied time bins (Ma)
  - compute simple richness estimators (sampled-in-bin, range-through, singleton)
  - shareholder-quorum subsampling (SQS, Alroy 2010) for sampling-standardised richness
  - simulate biodiversity trajectories under a stochastic birth-death process
  - degrade a simulated trajectory to a noisy "fossil record" (preservation + locality sampling)
  - extract per-bin features (taxa, occurrences, singletons, endemics, localities)
  - train a small bidirectional LSTM that maps these features back to the true diversity
  - run Monte-Carlo-dropout uncertainty prediction
  - plot the resulting palaeodiversity curve

The intent is that the agent chains these primitives to reproduce
DeepDive-style estimates on the real Permian-Triassic marine and
Cenozoic proboscidean datasets.
"""

import os
import json
import math
import random
from typing import Any

import numpy as np
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Biodiversity_Reconstruction_Tools")


# ---------------------------------------------------------------------------
# 1. I/O for fossil occurrence tables
# ---------------------------------------------------------------------------
@mcp.tool()
def load_occurrences_csv(csv_path: str, max_rows: int | None = None,
                         return_all_records: bool = False,
                         output_csv: str | None = None) -> dict:
    """Load a fossil occurrence CSV (e.g., PBDB-style: phylum, genus,
    max_ma, min_ma, lng, lat, coll_no, region).

    Args:
        csv_path: path to the CSV.
        max_rows: optional row cap for fast inspection.
        return_all_records: when True, the ``records`` key in the
            returned dict contains ALL rows (use for full downstream
            processing rather than just the 30-row ``preview``).
        output_csv: optional path; when set, the (possibly capped)
            DataFrame is also written to this CSV for downstream
            tools that consume a path argument.

    Returns:
        dict with n_rows, columns, dtypes, preview (first 30 rows
        always), and either records (when return_all_records=True)
        or just the preview.
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    if max_rows is not None:
        df = df.head(max_rows)
    out = {
        "n_rows": int(len(df)),
        "columns": list(df.columns),
        "dtypes": {c: str(df[c].dtype) for c in df.columns},
        "preview": df.head(30).to_dict("records"),
    }
    if return_all_records:
        out["records"] = df.to_dict("records")
    if output_csv:
        os.makedirs(os.path.dirname(output_csv) or ".", exist_ok=True)
        df.to_csv(output_csv, index=False)
        out["output_csv"] = output_csv
    return out


@mcp.tool()
def load_occurrences_excel(xlsx_path: str, sheet_name: str | int = 0,
                           return_all_records: bool = False,
                           output_csv: str | None = None) -> dict:
    """Load a fossil occurrence Excel sheet (e.g., NOW-style proboscidean
    table).

    Args:
        xlsx_path: path to the .xlsx workbook.
        sheet_name: sheet to read (default = first sheet).
        return_all_records: when True, the ``records`` key in the
            returned dict contains ALL rows (use this to read the full
            2,130-row proboscidean table for downstream binning).
        output_csv: optional path; when set, the full DataFrame is
            ALSO written to this CSV path so downstream MCP tools that
            take a CSV path argument (e.g.,
            ``assign_occurrences_to_bins``) can consume it directly
            without going through a pandas hop.

    Returns:
        dict with n_rows, columns, dtypes, preview (first 30 rows
        always), and either records (when return_all_records=True)
        or just the preview. The Excel file ships with ~2,130
        proboscidean occurrences; the default 30-row preview is for
        fast inspection only.
    """
    import pandas as pd
    df = pd.read_excel(xlsx_path, sheet_name=sheet_name)
    out = {
        "n_rows": int(len(df)),
        "columns": list(df.columns),
        "dtypes": {c: str(df[c].dtype) for c in df.columns},
        "preview": df.head(30).to_dict("records"),
    }
    if return_all_records:
        out["records"] = df.to_dict("records")
    if output_csv:
        os.makedirs(os.path.dirname(output_csv) or ".", exist_ok=True)
        df.to_csv(output_csv, index=False)
        out["output_csv"] = output_csv
    return out


# ---------------------------------------------------------------------------
# 2. Time-bin construction & occurrence assignment
# ---------------------------------------------------------------------------
@mcp.tool()
def build_time_bins_from_durations(start_age_ma: float, durations_ma: list,
                                   ascending_in_time: bool = False) -> dict:
    """Build a list of time bin (max_age, min_age) edges from a list of
    bin durations.

    `start_age_ma` is the OLDEST edge (large Ma); the routine walks toward
    the present subtracting each duration.  When `ascending_in_time=True`,
    `durations_ma` is interpreted from old to young (default order in
    DeepDive `t_bins.csv` files is oldest to youngest).
    """
    durations = list(durations_ma)
    edges = [float(start_age_ma)]
    for d in durations:
        edges.append(edges[-1] - float(d))
    bins = [(edges[i], edges[i + 1]) for i in range(len(edges) - 1)]
    return {
        "n_bins": len(bins),
        "edges": edges,
        "bins": [{"index": i, "max_age_ma": b[0], "min_age_ma": b[1],
                  "duration_ma": round(b[0] - b[1], 4)} for i, b in enumerate(bins)],
    }


@mcp.tool()
def filter_occurrences_paper_style(occurrences_csv: str,
                                   output_csv: str,
                                   taxon_col: str = "genus",
                                   min_age_col: str = "min_ma",
                                   max_age_col: str = "max_ma",
                                   drop_indet_names: bool = True,
                                   require_finite_ages: bool = True,
                                   age_window: tuple | None = None,
                                   min_taxon_occurrences: int = 0,
                                   valid_taxa: list | None = None,
                                   dropna_cols: list | None = None) -> dict:
    """Clean a raw fossil-occurrence CSV to a paper-equivalent subset.

    The bundle ships pre-filter PBDB/NOW exports (e.g., 144,664 marine
    rows / 5,608 genera; 2,131 proboscidean rows / 185 species). Cooper
    et al. 2024 analysed a filtered subset of each (e.g., 2,104 occs /
    180 proboscidean species). This helper exposes the standard
    cleaning passes so an agent can derive a paper-equivalent table
    deterministically.

    Filter passes applied in order (skip a pass by leaving its flag at
    the disabling default):

    1. ``require_finite_ages`` (default True): drop rows where either
       ``min_age_col`` or ``max_age_col`` is NaN.
    2. ``drop_indet_names`` (default True): drop rows whose taxon name
       contains 'indet.', 'sp.', 'aff.', 'cf.', '?', or starts with the
       Linnaean uncertainty markers ('Indeterminate', '?').
    3. ``age_window`` (optional tuple ``(oldest_ma, youngest_ma)``):
       restrict to occurrences whose midpoint age falls inside the
       window. Use this to enforce a study interval, e.g.
       ``age_window=(259.51, 192.9)`` for the Permian-Triassic marine
       window or ``(66.0, 0.0)`` for Cenozoic proboscideans.
    4. ``valid_taxa`` (optional explicit accept-list): keep only rows
       whose ``taxon_col`` value appears in the list. Use this to
       reproduce a paper-supplied acceptance table when one is shipped.
    5. ``min_taxon_occurrences`` (optional int): drop taxa with fewer
       than N occurrences across the dataset (handy for paper-style
       "singletons removed").
    6. ``dropna_cols`` (optional list): drop rows with NaN in any of
       these extra columns (e.g., ``['lng','lat','reg']`` to require
       georeferenced + region-tagged rows).

    Writes the cleaned table to ``output_csv`` and returns a per-pass
    row-count summary so the agent can audit how much each filter
    removed (the paper's headline 2,104/180 numbers are reproducible
    from this helper + appropriate flag settings).
    """
    import pandas as pd
    df = pd.read_csv(occurrences_csv)
    n0 = int(len(df))
    counts = {"input_rows": n0}
    if require_finite_ages:
        if min_age_col in df.columns and max_age_col in df.columns:
            df = df.dropna(subset=[min_age_col, max_age_col])
        counts["after_require_finite_ages"] = int(len(df))
    if drop_indet_names and taxon_col in df.columns:
        bad_tokens = ("indet.", " sp.", " aff.", " cf.", "?", "indeterminate", "incertae")
        names = df[taxon_col].astype(str).str.lower()
        mask_bad = names.apply(lambda s: any(t in s for t in bad_tokens))
        df = df[~mask_bad]
        counts["after_drop_indet_names"] = int(len(df))
    if age_window is not None and len(age_window) == 2:
        oldest, youngest = float(age_window[0]), float(age_window[1])
        if oldest < youngest:
            oldest, youngest = youngest, oldest
        if min_age_col in df.columns and max_age_col in df.columns:
            mid = (df[max_age_col].astype(float) + df[min_age_col].astype(float)) / 2.0
            df = df[(mid <= oldest) & (mid >= youngest)]
        counts["after_age_window"] = int(len(df))
    if valid_taxa is not None and taxon_col in df.columns:
        accept = set(map(str, valid_taxa))
        df = df[df[taxon_col].astype(str).isin(accept)]
        counts["after_valid_taxa"] = int(len(df))
    if dropna_cols:
        present = [c for c in dropna_cols if c in df.columns]
        if present:
            df = df.dropna(subset=present)
        counts["after_dropna_cols"] = int(len(df))
    if min_taxon_occurrences > 0 and taxon_col in df.columns:
        vc = df[taxon_col].value_counts()
        keep = set(vc[vc >= int(min_taxon_occurrences)].index)
        df = df[df[taxon_col].isin(keep)]
        counts["after_min_taxon_occurrences"] = int(len(df))
    n_taxa_out = int(df[taxon_col].nunique()) if taxon_col in df.columns else None
    os.makedirs(os.path.dirname(output_csv) or ".", exist_ok=True)
    df.to_csv(output_csv, index=False)
    return {
        "input_csv": occurrences_csv,
        "output_csv": output_csv,
        "row_counts": counts,
        "n_rows_out": int(len(df)),
        "n_taxa_out": n_taxa_out,
    }


@mcp.tool()
def assign_occurrences_to_bins(occurrences_csv: str, bin_edges_oldest_first: list,
                               max_ma_col: str = "max_ma",
                               min_ma_col: str = "min_ma",
                               assign_method: str = "midpoint") -> dict:
    """Assign each occurrence to a single time bin.

    `bin_edges_oldest_first` is a flat list of N+1 numeric ages (Ma)
    ordered from oldest to youngest, e.g. [259.51, 254.14, 251.9, ...,
    192.9].  `assign_method` is "midpoint" (default; bin containing the
    occurrence's midpoint age) or "max" (bin containing max_ma).

    Returns the bin index appended to each row (in-memory) plus a per-bin
    occurrence count.  Writes the augmented table to
    `<csv_path>.binned.csv` and returns the path.
    """
    import pandas as pd
    df = pd.read_csv(occurrences_csv)
    edges = sorted([float(e) for e in bin_edges_oldest_first], reverse=True)
    n_bins = len(edges) - 1

    df = df[(df[max_ma_col] <= edges[0]) & (df[min_ma_col] >= edges[-1])].copy()
    if assign_method == "midpoint":
        ages = (df[max_ma_col].astype(float) + df[min_ma_col].astype(float)) / 2.0
    else:
        ages = df[max_ma_col].astype(float)

    bin_idx = np.full(len(df), -1, dtype=int)
    for i in range(n_bins):
        max_a, min_a = edges[i], edges[i + 1]
        mask = (ages <= max_a) & (ages > min_a)
        if i == n_bins - 1:
            mask = (ages <= max_a) & (ages >= min_a)
        bin_idx[mask] = i
    df["bin_index"] = bin_idx
    df = df[df["bin_index"] >= 0].copy()

    out_path = occurrences_csv.replace(".csv", "") + ".binned.csv"
    df.to_csv(out_path, index=False)
    counts = df.groupby("bin_index").size().to_dict()
    return {
        "n_assigned": int(len(df)),
        "n_bins": n_bins,
        "per_bin_count": {int(k): int(v) for k, v in sorted(counts.items())},
        "binned_csv_path": out_path,
    }


# ---------------------------------------------------------------------------
# 3. Per-bin diversity estimators
# ---------------------------------------------------------------------------
@mcp.tool()
def sampled_in_bin_diversity(binned_csv: str, taxon_col: str = "genus",
                             bin_col: str = "bin_index",
                             region_col: str | None = None,
                             n_bins: int | None = None) -> dict:
    """Number of unique taxa actually sampled in each time bin.

    If `region_col` is provided, also returns per-region per-bin counts.
    If `n_bins` is supplied, the result is padded with zeros to that
    length (use this when later bins might be empty).
    """
    import pandas as pd
    df = pd.read_csv(binned_csv)
    df = df.dropna(subset=[taxon_col, bin_col])
    inferred = int(df[bin_col].max() + 1) if len(df) else 0
    n_bins = max(inferred, int(n_bins) if n_bins else 0) or inferred
    div_global = [0] * n_bins
    for b, grp in df.groupby(bin_col):
        div_global[int(b)] = int(grp[taxon_col].nunique())
    out: dict = {"n_bins": n_bins, "global_diversity": div_global}
    if region_col is not None and region_col in df.columns:
        per_region = {}
        for r, sub in df.groupby(region_col):
            row = [0] * n_bins
            for b, grp in sub.groupby(bin_col):
                row[int(b)] = int(grp[taxon_col].nunique())
            per_region[str(r)] = row
        out["per_region"] = per_region
    return out


@mcp.tool()
def range_through_diversity(binned_csv: str, taxon_col: str = "genus",
                            bin_col: str = "bin_index",
                            n_bins: int | None = None) -> dict:
    """Range-through richness: a taxon counts in every bin between its
    first and last sampled occurrence.

    Less sensitive to sampling gaps than sampled-in-bin counts.
    If `n_bins` is supplied, the result is padded with zeros to that
    length (use this when later bins might be empty).
    """
    import pandas as pd
    df = pd.read_csv(binned_csv).dropna(subset=[taxon_col, bin_col])
    inferred = int(df[bin_col].max() + 1) if len(df) else 0
    n_bins = max(inferred, int(n_bins) if n_bins else 0) or inferred
    rt = np.zeros(n_bins, dtype=int)
    for tx, grp in df.groupby(taxon_col):
        bins = grp[bin_col].astype(int)
        first, last = int(bins.min()), int(bins.max())
        rt[first:last + 1] += 1
    return {"n_bins": n_bins, "range_through_diversity": rt.tolist()}


@mcp.tool()
def singleton_count(binned_csv: str, taxon_col: str = "genus",
                    bin_col: str = "bin_index") -> dict:
    """Per-bin count of singleton taxa (occurring only once in that bin)."""
    import pandas as pd
    df = pd.read_csv(binned_csv).dropna(subset=[taxon_col, bin_col])
    n_bins = int(df[bin_col].max() + 1)
    singletons = [0] * n_bins
    for b, grp in df.groupby(bin_col):
        counts = grp[taxon_col].value_counts()
        singletons[int(b)] = int((counts == 1).sum())
    return {"n_bins": n_bins, "singletons": singletons}


@mcp.tool()
def shareholder_quorum_subsampling(binned_csv: str, quorum: float = 0.6,
                                   taxon_col: str = "genus",
                                   bin_col: str = "bin_index",
                                   n_replicates: int = 100,
                                   seed: int = 1) -> dict:
    """SQS (Alroy 2010) sampling-standardised richness per bin.

    For each bin, randomly draw occurrences without replacement until the
    summed frequency of drawn taxa reaches `quorum` of the total
    coverage; the mean number of distinct taxa across `n_replicates`
    draws is the SQS richness estimate.  Returns also the +/- SD.
    """
    import pandas as pd
    rng = np.random.default_rng(seed)
    df = pd.read_csv(binned_csv).dropna(subset=[taxon_col, bin_col])
    n_bins = int(df[bin_col].max() + 1)
    means = [0.0] * n_bins
    sds = [0.0] * n_bins
    for b in range(n_bins):
        sub = df[df[bin_col] == b][taxon_col].values
        if len(sub) == 0:
            continue
        # Estimate coverage via Good's u = 1 - n_singleton / N
        counts = pd.Series(sub).value_counts().values.astype(float)
        N = counts.sum()
        n_single = int((counts == 1).sum())
        u = 1.0 - (n_single / N) if N > 0 else 0.0
        target = quorum * u  # target frequency mass
        if target <= 0:
            continue
        freqs = counts / N
        # Draw multinomial samples until sum of unique taxa weights >= target
        reps = []
        for _ in range(n_replicates):
            order = rng.permutation(len(sub))
            seen, mass = set(), 0.0
            # walk through ordered occurrences accumulating frequency mass of
            # distinct taxa until the SQS quorum target is met
            for idx in order:
                tx = sub[idx]
                if tx not in seen:
                    seen.add(tx)
                    mass += float((sub == tx).sum()) / N
                if mass >= target:
                    break
            reps.append(len(seen))
        means[b] = float(np.mean(reps))
        sds[b] = float(np.std(reps))
    return {"n_bins": n_bins, "quorum": quorum,
            "sqs_diversity_mean": means, "sqs_diversity_sd": sds}


# ---------------------------------------------------------------------------
# 4. Per-bin features for ML input
# ---------------------------------------------------------------------------
@mcp.tool()
def extract_per_bin_features(binned_csv: str, region_col: str = "reg",
                             taxon_col: str = "genus",
                             locality_col: str = "coll_no",
                             bin_col: str = "bin_index",
                             n_bins: int | None = None,
                             bin_durations: list | None = None) -> dict:
    """Build the per-bin feature matrix used by DeepDive-style models.

    Per-bin features (1-D, per time step):
        n_taxa, n_occurrences, n_singletons, n_endemic_taxa,
        n_range_through, n_localities.

    Per-bin x per-region features (the model also receives these):
        n_taxa_per_region, n_occurrences_per_region, n_localities_per_region.

    When ``bin_durations`` is provided, it is stored in the output JSON so
    that ``predict_diversity_with_uncertainty`` can append it as the
    duration feature column that matches the training tensor produced
    by ``simulate_fossil_record_from_trajectories`` with
    ``include_duration=True``.

    Returns features as nested lists; writes them to <binned_csv>.features.json.
    Pass ``n_bins`` to pad with zeros when later bins might be empty.
    """
    import pandas as pd
    df = pd.read_csv(binned_csv).dropna(subset=[taxon_col, bin_col])
    inferred = int(df[bin_col].max() + 1) if len(df) else 0
    n_bins = max(inferred, int(n_bins) if n_bins else 0) or inferred
    regions = sorted(df[region_col].dropna().unique().tolist()) if region_col in df.columns else []
    R = len(regions)

    feats = {
        "n_taxa": [0] * n_bins,
        "n_occurrences": [0] * n_bins,
        "n_singletons": [0] * n_bins,
        "n_endemic_taxa": [0] * n_bins,
        "n_range_through": [0] * n_bins,
        "n_localities": [0] * n_bins,
    }
    # per-region 2D: list of bins, each bin is list over regions
    n_taxa_pr = [[0] * R for _ in range(n_bins)]
    n_occ_pr = [[0] * R for _ in range(n_bins)]
    n_loc_pr = [[0] * R for _ in range(n_bins)]

    # per-bin computations
    for b in range(n_bins):
        sub = df[df[bin_col] == b]
        if len(sub) == 0:
            continue
        feats["n_occurrences"][b] = int(len(sub))
        feats["n_taxa"][b] = int(sub[taxon_col].nunique())
        counts = sub[taxon_col].value_counts()
        feats["n_singletons"][b] = int((counts == 1).sum())
        if locality_col in sub.columns:
            feats["n_localities"][b] = int(sub[locality_col].nunique())
        # endemic = present in exactly one region within this bin
        if region_col in sub.columns:
            taxa_regs = sub.groupby(taxon_col)[region_col].nunique()
            feats["n_endemic_taxa"][b] = int((taxa_regs == 1).sum())
            for r_idx, r in enumerate(regions):
                rsub = sub[sub[region_col] == r]
                n_taxa_pr[b][r_idx] = int(rsub[taxon_col].nunique())
                n_occ_pr[b][r_idx] = int(len(rsub))
                if locality_col in rsub.columns:
                    n_loc_pr[b][r_idx] = int(rsub[locality_col].nunique())

    # range-through across whole interval
    for tx, grp in df.groupby(taxon_col):
        b_first, b_last = int(grp[bin_col].min()), int(grp[bin_col].max())
        for b in range(b_first, b_last + 1):
            feats["n_range_through"][b] += 1

    out_path = binned_csv.replace(".csv", "") + ".features.json"
    dur_list = (list(map(float, bin_durations))
                if bin_durations is not None else [])
    payload = {
        "n_bins": n_bins,
        "regions": regions,
        "global_features": feats,
        "per_region_features": {
            "n_taxa_per_region": n_taxa_pr,
            "n_occurrences_per_region": n_occ_pr,
            "n_localities_per_region": n_loc_pr,
        },
        "bin_durations": dur_list,
    }
    with open(out_path, "w") as f:
        json.dump(payload, f, indent=2)
    payload["features_json_path"] = out_path
    return payload


# ---------------------------------------------------------------------------
# 5. Birth-death biodiversity simulator
# ---------------------------------------------------------------------------
@mcp.tool()
def simulate_birth_death_trajectories(n_simulations: int = 100,
                                      n_time_bins: int = 11,
                                      bin_duration_my: float = 6.0,
                                      bin_durations: list | None = None,
                                      lam_range: tuple = (0.05, 0.5),
                                      mu_range: tuple = (0.05, 0.5),
                                      mass_extinction_prob: float = 0.01,
                                      mass_extinction_intensity_range: tuple = (0.4, 0.95),
                                      total_diversity_range: tuple = (100, 5000),
                                      max_attempts: int = 10000,
                                      seed: int = 7) -> dict:
    """Simulate global diversity trajectories under a piece-wise constant
    birth-death process with optional mass extinction events.

    Args:
        bin_durations: optional per-bin duration array (Myr) ordered
            oldest-to-youngest. When provided, ``n_time_bins`` is
            overridden by ``len(bin_durations)`` and each step uses the
            local dt (so the model learns from realistic heterogeneous
            bin widths — e.g. marine_t_bins ranges 0.70-18.50 Myr,
            proboscidean_t_bins 0.003-3 Myr). When None, falls back to
            the uniform ``bin_duration_my`` for all bins.

    Returns a numpy array of shape (n_simulations, n_time_bins) saved to
    ``simulated_trajectories.npz`` along with the bin_durations array
    so downstream tools can carry the duration feature into the RNN.
    """
    rng = np.random.default_rng(seed)
    if bin_durations is not None:
        bin_durations_arr = np.asarray(list(bin_durations), dtype=float)
        n_time_bins = len(bin_durations_arr)
    else:
        bin_durations_arr = np.full(n_time_bins, float(bin_duration_my), dtype=float)
    out = np.zeros((n_simulations, n_time_bins), dtype=int)
    accepted = 0
    attempts = 0
    while accepted < n_simulations and attempts < max_attempts:
        attempts += 1
        lam = rng.uniform(*lam_range)
        mu = rng.uniform(*mu_range)
        N = max(1, int(rng.uniform(20, 200)))
        traj = []
        for t in range(n_time_bins):
            dt = float(bin_durations_arr[t])
            births = rng.poisson(lam * N * dt)
            deaths = rng.poisson(mu * N * dt)
            N = max(0, N + births - deaths)
            if rng.random() < mass_extinction_prob * dt:
                intensity = rng.uniform(*mass_extinction_intensity_range)
                N = max(1, int(N * (1 - intensity)))
            traj.append(N)
        total = sum(traj)
        if total_diversity_range[0] <= total <= total_diversity_range[1]:
            out[accepted] = traj
            accepted += 1
    out = out[:accepted]
    npz = "simulated_trajectories.npz"
    np.savez(npz, trajectories=out, bin_durations=bin_durations_arr)
    return {
        "n_accepted_simulations": int(accepted),
        "n_attempts": attempts,
        "n_time_bins": n_time_bins,
        "bin_durations": bin_durations_arr.tolist(),
        "saved_to": npz,
        "first_three_trajectories": out[:3].tolist(),
    }


@mcp.tool()
def simulate_fossil_record_from_trajectories(npz_path: str = "simulated_trajectories.npz",
                                             n_regions: int = 5,
                                             preservation_range: tuple = (0.05, 0.5),
                                             completeness_range: tuple = (0.1, 0.9),
                                             gap_prob: float = 0.05,
                                             include_per_region: bool = True,
                                             include_duration: bool = True,
                                             taxon_preservation_classes: int = 1,
                                             seed: int = 11) -> dict:
    """Degrade each simulated diversity trajectory into a noisy
    'fossil record'.

    For each trajectory we:
      1. Randomly distribute species across ``n_regions`` (Dirichlet).
      2. Sample localities per region per bin from a Gamma * Poisson chain.
      3. Each species is assigned to one of ``taxon_preservation_classes``
         preservation classes (when > 1) with a class-specific
         preservation rate drawn from ``preservation_range``; this lets
         the RNN learn taxon-specific preservation heterogeneity instead
         of treating all species identically.
      4. With probability ``gap_prob`` the entire bin/region cell becomes a
         total gap (0 occurrences).
      5. Compute per-bin features (n_taxa, n_occurrences, n_singletons,
         n_endemic_taxa, n_range_through, n_localities) AND, when
         ``include_per_region=True``, the corresponding per-region
         matrices (n_taxa_per_region, n_occurrences_per_region,
         n_localities_per_region) stacked into the model input tensor.
      6. When ``include_duration=True`` AND the input npz carries a
         ``bin_durations`` array (written by the upgraded
         ``simulate_birth_death_trajectories``), the per-bin duration
         is appended as a final feature so the RNN sees heterogeneous
         bin widths instead of training on uniform-duration simulations.

    Output tensor X has shape ``(n_sims, n_bins, F_total)`` where
    ``F_total = 6_global + (n_regions * 3 if include_per_region else 0)
               + (1 if include_duration and bin_durations present else 0)``.
    Returns the tensor + matching true-diversity matrix saved to
    ``fossil_features.npz`` along with a ``feature_layout`` dict so the
    RNN train + predict functions can reconstruct the same column order
    from an empirical features.json.
    """
    import pandas as pd
    rng = np.random.default_rng(seed)
    with np.load(npz_path) as d:
        trajs = d["trajectories"]
        bin_durations = d["bin_durations"] if "bin_durations" in d.files else None
    n_sims, n_bins = trajs.shape
    F_global = 6
    F_per_region = 3 if include_per_region else 0
    has_duration = include_duration and bin_durations is not None
    F_duration = 1 if has_duration else 0
    F_total = F_global + n_regions * F_per_region + F_duration
    X = np.zeros((n_sims, n_bins, F_total), dtype=float)
    for s in range(n_sims):
        traj = trajs[s]
        max_div = int(traj.max())
        if max_div == 0:
            continue
        species_origins = rng.integers(0, n_bins, size=max_div * 5)
        species_durations = rng.integers(1, max(2, n_bins // 2 + 1), size=max_div * 5)
        all_species = []
        for sid, (orig, dur) in enumerate(zip(species_origins, species_durations)):
            all_species.append((sid, int(orig), int(min(orig + dur, n_bins - 1))))
        present_per_bin = [set() for _ in range(n_bins)]
        for sid, b0, b1 in all_species:
            for b in range(b0, b1 + 1):
                present_per_bin[b].add(sid)
        for b in range(n_bins):
            cur = list(present_per_bin[b])
            if len(cur) > traj[b]:
                keep = set(rng.choice(cur, size=int(traj[b]), replace=False))
                present_per_bin[b] = keep
        region_assign = rng.integers(0, n_regions, size=max(1, max_div * 5))
        # Per-species preservation class (taxon-specific heterogeneity).
        n_classes = max(1, int(taxon_preservation_classes))
        class_pres = np.linspace(preservation_range[0], preservation_range[1], n_classes)
        species_class = rng.integers(0, n_classes, size=max(1, max_div * 5))
        per_bin_taxa = [set() for _ in range(n_bins)]
        per_bin_occs = [0] * n_bins
        per_bin_locs = [0] * n_bins
        per_bin_singletons = [0] * n_bins
        per_bin_endemic = [0] * n_bins
        # Per-region per-bin matrices (filled only when include_per_region).
        n_taxa_pr = np.zeros((n_bins, n_regions), dtype=float)
        n_occ_pr  = np.zeros((n_bins, n_regions), dtype=float)
        n_loc_pr  = np.zeros((n_bins, n_regions), dtype=float)
        for b in range(n_bins):
            occ_counts: dict = {}
            taxa_regions: dict = {}
            n_locs = 0
            for r in range(n_regions):
                if rng.random() < gap_prob:
                    continue
                rate = rng.gamma(2.0, 1.0) * rng.uniform(0.5, 5.0)
                k_loc = int(rng.poisson(max(0.1, rate)))
                n_locs += k_loc
                n_loc_pr[b, r] = float(k_loc)
                comp = rng.uniform(*completeness_range)
                local_species = [sid for sid in present_per_bin[b]
                                 if region_assign[sid % len(region_assign)] == r]
                region_occ: dict = {}
                region_taxa = set()
                for sid in local_species:
                    if rng.random() < comp:
                        pres = float(class_pres[species_class[sid % len(species_class)]])
                        n_occ = rng.poisson(max(0.05, pres * max(1, k_loc)))
                        if n_occ > 0:
                            occ_counts[sid] = occ_counts.get(sid, 0) + int(n_occ)
                            taxa_regions.setdefault(sid, set()).add(r)
                            per_bin_taxa[b].add(sid)
                            region_occ[sid] = region_occ.get(sid, 0) + int(n_occ)
                            region_taxa.add(sid)
                n_taxa_pr[b, r] = float(len(region_taxa))
                n_occ_pr[b, r]  = float(sum(region_occ.values()))
            per_bin_occs[b] = sum(occ_counts.values())
            per_bin_singletons[b] = sum(1 for c in occ_counts.values() if c == 1)
            per_bin_endemic[b] = sum(1 for tr in taxa_regions.values() if len(tr) == 1)
            per_bin_locs[b] = n_locs
        per_bin_rt = [0] * n_bins
        first_seen: dict = {}
        last_seen: dict = {}
        for b in range(n_bins):
            for sid in per_bin_taxa[b]:
                first_seen[sid] = min(first_seen.get(sid, b), b)
                last_seen[sid] = max(last_seen.get(sid, b), b)
        for sid, fb in first_seen.items():
            for b in range(fb, last_seen[sid] + 1):
                per_bin_rt[b] += 1
        for b in range(n_bins):
            X[s, b, 0] = len(per_bin_taxa[b])
            X[s, b, 1] = per_bin_occs[b]
            X[s, b, 2] = per_bin_singletons[b]
            X[s, b, 3] = per_bin_endemic[b]
            X[s, b, 4] = per_bin_rt[b]
            X[s, b, 5] = per_bin_locs[b]
            col = F_global
            if F_per_region > 0:
                for r in range(n_regions):
                    X[s, b, col + 0 * n_regions + r] = n_taxa_pr[b, r]
                    X[s, b, col + 1 * n_regions + r] = n_occ_pr[b, r]
                    X[s, b, col + 2 * n_regions + r] = n_loc_pr[b, r]
                col += n_regions * F_per_region
            if has_duration:
                X[s, b, col] = float(bin_durations[b])
    out_path = "fossil_features.npz"
    feature_layout = {
        "global_features": ["n_taxa", "n_occurrences", "n_singletons",
                            "n_endemic_taxa", "n_range_through", "n_localities"],
        "n_global": F_global,
        "include_per_region": bool(include_per_region),
        "n_per_region_features": F_per_region,
        "per_region_feature_names": (["n_taxa_per_region",
                                       "n_occurrences_per_region",
                                       "n_localities_per_region"]
                                      if include_per_region else []),
        "n_regions": int(n_regions),
        "include_duration": bool(has_duration),
        "n_total_features": F_total,
        "taxon_preservation_classes": int(taxon_preservation_classes),
    }
    np.savez(out_path, X=X, y=trajs.astype(float),
             bin_durations=(bin_durations if bin_durations is not None
                            else np.zeros(n_bins, dtype=float)),
             feature_layout=np.array(json.dumps(feature_layout)))
    return {
        "n_simulations": n_sims,
        "n_time_bins": n_bins,
        "n_features": F_total,
        "feature_layout": feature_layout,
        "saved_to": out_path,
    }


# ---------------------------------------------------------------------------
# 6. Small bidirectional LSTM
# ---------------------------------------------------------------------------
@mcp.tool()
def train_simple_rnn(features_npz: str = "fossil_features.npz",
                     epochs: int = 50, batch_size: int = 32,
                     hidden_units: int = 32,
                     dropout: float = 0.05,
                     val_split: float = 0.2,
                     lr: float = 1e-3,
                     seed: int = 17) -> dict:
    """Train a small bidirectional-LSTM regressor that maps the per-bin
    fossil feature matrix to the simulated true diversity trajectory.

    Architecture (Keras):
        Input  -> log1p   -> BiLSTM(hidden_units, return_sequences=True)
               -> Dropout  -> Dense(hidden_units, relu)
               -> Dense(1, softplus)

    Loss = MSE on log1p(diversity).  Saves the trained model and training
    history to `simple_rnn_model/` and returns the validation MSE.
    """
    np.random.seed(seed)
    try:
        import tensorflow as tf
        tf.random.set_seed(seed)
        from tensorflow.keras import layers, models
    except Exception as e:  # pragma: no cover
        return {"error": f"tensorflow not available: {e}"}

    with np.load(features_npz) as d:
        X = d["X"].astype(np.float32)
        y = d["y"].astype(np.float32)
    # log1p the inputs and outputs in numpy to avoid lambda layers
    Xlog = np.log1p(np.maximum(X, 0.0)).astype(np.float32)
    ylog = np.log1p(np.maximum(y, 0.0)).astype(np.float32)
    n = Xlog.shape[0]
    perm = np.random.permutation(n)
    Xlog, ylog = Xlog[perm], ylog[perm]
    n_val = max(1, int(n * val_split))
    Xv, yv = Xlog[:n_val], ylog[:n_val]
    Xt, yt = Xlog[n_val:], ylog[n_val:]

    inp = layers.Input(shape=(Xlog.shape[1], Xlog.shape[2]))
    h = layers.Bidirectional(layers.LSTM(hidden_units, return_sequences=True,
                                         dropout=dropout))(inp)
    h = layers.Dropout(dropout)(h)
    h = layers.Dense(hidden_units, activation="relu")(h)
    out = layers.Dense(1, activation="linear")(h)
    out = layers.Reshape((Xlog.shape[1],))(out)
    model = models.Model(inp, out)
    model.compile(optimizer=tf.keras.optimizers.Adam(lr), loss="mse")
    es = tf.keras.callbacks.EarlyStopping(patience=10, restore_best_weights=True,
                                          monitor="val_loss")
    hist = model.fit(Xt, yt, validation_data=(Xv, yv),
                     epochs=epochs, batch_size=batch_size,
                     callbacks=[es], verbose=0)
    out_dir = "simple_rnn_model"
    os.makedirs(out_dir, exist_ok=True)
    model.save(os.path.join(out_dir, "model.keras"))
    return {
        "validation_loss": float(hist.history["val_loss"][-1]),
        "best_validation_loss": float(min(hist.history["val_loss"])),
        "training_loss": float(hist.history["loss"][-1]),
        "n_epochs_run": len(hist.history["loss"]),
        "model_dir": out_dir,
    }


@mcp.tool()
def predict_diversity_with_uncertainty(empirical_features_json: str,
                                       model_dir: str = "simple_rnn_model",
                                       n_mc_samples: int = 100,
                                       seed: int = 23) -> dict:
    """Apply the trained RNN to an empirical feature trajectory using
    Monte-Carlo dropout to obtain a 95% credible interval.

    `empirical_features_json` is the JSON written by
    `extract_per_bin_features`.  Returns the per-bin median plus 2.5th
    and 97.5th percentiles, and writes them to
    `predicted_diversity.json`.
    """
    try:
        import tensorflow as tf
    except Exception as e:  # pragma: no cover
        return {"error": f"tensorflow not available: {e}"}
    np.random.seed(seed)
    tf.random.set_seed(seed)

    with open(empirical_features_json) as f:
        payload = json.load(f)
    feats = payload["global_features"]
    F = ["n_taxa", "n_occurrences", "n_singletons",
         "n_endemic_taxa", "n_range_through", "n_localities"]
    n_bins_emp = int(payload["n_bins"])
    X_global = np.array([[feats[f][b] for f in F]
                  for b in range(n_bins_emp)], dtype=np.float32)

    # Build the empirical-input tensor in the SAME column layout as the
    # training tensor produced by simulate_fossil_record_from_trajectories.
    # The model's input dim is known from its first layer; we read it to
    # verify the empirical feature matrix has matching width.
    model = tf.keras.models.load_model(os.path.join(model_dir, "model.keras"),
                                       compile=False)
    try:
        F_total_model = int(model.input_shape[-1])
    except Exception:
        F_total_model = X_global.shape[1]

    # Reconstruct per-region columns (n_taxa_pr, n_occ_pr, n_loc_pr each R wide)
    per_region_cols = None
    n_regions_emp = 0
    if "per_region_features" in payload:
        prf = payload["per_region_features"]
        per_region_keys = ("n_taxa_per_region", "n_occurrences_per_region", "n_localities_per_region")
        if all(k in prf for k in per_region_keys):
            arrs = [np.array(prf[k], dtype=np.float32) for k in per_region_keys]
            if arrs[0].ndim == 2 and arrs[0].shape[0] == n_bins_emp:
                n_regions_emp = arrs[0].shape[1]
                per_region_cols = np.concatenate(arrs, axis=1)  # (n_bins, 3*R)

    # Reconstruct duration column (1 per bin) from optional bin_durations
    duration_col = None
    if "bin_durations" in payload and payload["bin_durations"]:
        dur_arr = np.asarray(payload["bin_durations"], dtype=np.float32)
        if dur_arr.shape[0] == n_bins_emp:
            duration_col = dur_arr.reshape(-1, 1)

    columns = [X_global]
    if per_region_cols is not None:
        columns.append(per_region_cols)
    if duration_col is not None:
        columns.append(duration_col)
    X_emp = np.concatenate(columns, axis=1)

    # If model was trained on the legacy 6-feature path, drop per-region and
    # duration extras (backwards-compatible). Otherwise verify shapes match.
    if F_total_model == X_global.shape[1]:
        X_emp = X_global
    elif F_total_model != X_emp.shape[1]:
        return {"error": (f"feature-shape mismatch: empirical X has "
                          f"{X_emp.shape[1]} cols (6 global + "
                          f"{0 if per_region_cols is None else per_region_cols.shape[1]} "
                          f"per-region + {0 if duration_col is None else 1} duration) "
                          f"but the trained model expects {F_total_model}. "
                          f"Re-train with matching include_per_region / "
                          f"include_duration / n_regions settings.")}

    # Spatial-bias diagnostics — still reported separately for transparency.
    spatial_diag: dict = {}
    if "per_region_features" in payload:
        prf = payload["per_region_features"]
        for key in ("n_taxa_per_region", "n_occurrences_per_region", "n_localities_per_region"):
            if key not in prf:
                continue
            arr = np.array(prf[key], dtype=np.float32)
            if arr.ndim != 2 or arr.shape[0] != n_bins_emp:
                continue
            spatial_diag[f"{key}__per_bin_max"] = arr.max(axis=1).tolist()
            spatial_diag[f"{key}__per_bin_std"] = arr.std(axis=1).tolist()

    X = np.log1p(np.maximum(X_emp, 0.0))
    X = X[None, :, :]
    if X.shape[1] != n_bins_emp:
        return {"error": f"shape mismatch: X.shape[1]={X.shape[1]} != n_bins={n_bins_emp}"}
    # MC dropout: call model with training=True; outputs are in log-space
    preds = []
    for _ in range(n_mc_samples):
        y_log = model(X, training=True).numpy()[0]
        preds.append(np.expm1(np.maximum(y_log, 0.0)))
    preds = np.array(preds)
    median = np.median(preds, axis=0).tolist()
    lo = np.percentile(preds, 2.5, axis=0).tolist()
    hi = np.percentile(preds, 97.5, axis=0).tolist()
    out = {
        "n_bins": int(payload["n_bins"]),
        "median_diversity": [float(v) for v in median],
        "lower_95": [float(v) for v in lo],
        "upper_95": [float(v) for v in hi],
        "n_mc_samples": n_mc_samples,
        "spatial_diagnostics": spatial_diag,
    }
    with open("predicted_diversity.json", "w") as f:
        json.dump(out, f, indent=2)
    return out


# ---------------------------------------------------------------------------
# 7. Plotting
# ---------------------------------------------------------------------------
@mcp.tool()
def plot_diversity_curve(predictions_json: str,
                         time_bins_csv: str,
                         start_age_ma: float,
                         out_png: str,
                         clade_label: str = "diversity",
                         baseline_curves: dict | None = None,
                         vlines_ma: list | None = None) -> dict:
    """Plot a palaeodiversity curve (median + 95% band) as a function of
    geological time (Ma).

    `time_bins_csv` is the original DeepDive `t_bins.csv` containing one
    column of bin durations (oldest to youngest).  `start_age_ma` is the
    oldest edge.  Optionally overlay baseline series in `baseline_curves`
    (dict of label -> per-bin list, same length as predictions).  Adds
    vertical lines at given Ma ages (e.g. PTME = 251.9, TJME = 201.4).
    """
    import pandas as pd
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    with open(predictions_json) as f:
        pred = json.load(f)
    durations = pd.read_csv(time_bins_csv).iloc[:, 0].astype(float).tolist()
    edges = [start_age_ma]
    for d in durations:
        edges.append(edges[-1] - d)
    centres = [(edges[i] + edges[i + 1]) / 2 for i in range(len(durations))]

    median = pred["median_diversity"]
    lo = pred["lower_95"]
    hi = pred["upper_95"]

    fig, ax = plt.subplots(figsize=(10, 5))
    ax.fill_between(centres, lo, hi, color="steelblue", alpha=0.3,
                    label="95% credible interval")
    ax.plot(centres, median, "-o", color="navy", lw=2, label=f"DeepDive {clade_label}")
    if baseline_curves:
        cmap = ["tab:orange", "tab:green", "tab:red", "tab:purple"]
        for (lbl, vals), c in zip(baseline_curves.items(), cmap):
            ax.plot(centres, vals, "--", color=c, lw=1.5, label=lbl)
    if vlines_ma:
        for v in vlines_ma:
            ax.axvline(v, color="red", lw=0.8, alpha=0.7)
    ax.set_xlabel("Time (Ma)")
    ax.set_ylabel(f"Estimated {clade_label}")
    ax.invert_xaxis()
    ax.legend(loc="best", fontsize=9)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    os.makedirs(os.path.dirname(out_png) or ".", exist_ok=True)
    fig.savefig(out_png, dpi=150)
    plt.close(fig)
    return {"out_png": out_png, "n_bins": len(median),
            "centres_ma": centres}


@mcp.tool()
def plot_feature_histograms(empirical_features_json: str,
                            simulated_features_npz: str,
                            out_png: str) -> dict:
    """Overlay empirical vs. simulated histograms of per-bin features
    (taxa, occurrences, singletons, endemics, range-through, localities)
    to verify that the simulation regime spans the empirical regime.

    Reproduces the spirit of Fig. 4 / Fig. 5 of Cooper et al. 2024.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    with open(empirical_features_json) as f:
        emp = json.load(f)["global_features"]
    with np.load(simulated_features_npz) as d:
        Xsim = d["X"]
    feats = ["n_taxa", "n_occurrences", "n_singletons",
             "n_endemic_taxa", "n_range_through", "n_localities"]
    fig, axes = plt.subplots(2, 3, figsize=(11, 6))
    for k, name in enumerate(feats):
        ax = axes.flat[k]
        sim_vals = Xsim[:, :, k].ravel()
        emp_vals = np.array(emp[name], dtype=float)
        bins = 30
        ax.hist(sim_vals[sim_vals > 0], bins=bins, density=True,
                color="steelblue", alpha=0.6, label="simulated")
        ax.hist(emp_vals[emp_vals > 0], bins=bins, density=True,
                color="orange", alpha=0.6, label="empirical")
        ax.set_title(name, fontsize=9)
        ax.set_yscale("log")
        if k == 0:
            ax.legend(fontsize=8)
    fig.tight_layout()
    os.makedirs(os.path.dirname(out_png) or ".", exist_ok=True)
    fig.savefig(out_png, dpi=150)
    plt.close(fig)
    return {"out_png": out_png}


@mcp.tool()
def compute_diversity_change(diversity_curve: list, bin_indices_before: list,
                             bin_indices_after: list) -> dict:
    """Quantify diversity change (loss / gain) between two sets of bins.

    Returns absolute and relative loss as the mean per-bin diversity
    BEFORE the boundary minus the mean per-bin diversity AFTER. The
    ``diversity_curve`` argument should be the per-bin numerical
    estimate (median or range-through). The specific numeric loss
    values for any particular extinction event are not part of this
    helper's contract; cite the task answer / reference paper for
    paper-reported headline numbers.
    """
    arr = np.array(diversity_curve, dtype=float)
    before = float(np.mean([arr[i] for i in bin_indices_before
                            if 0 <= i < len(arr)]))
    after = float(np.mean([arr[i] for i in bin_indices_after
                           if 0 <= i < len(arr)]))
    if before == 0:
        return {"before": before, "after": after,
                "absolute_loss": before - after,
                "relative_loss_pct": None}
    return {
        "before_mean": round(before, 3),
        "after_mean": round(after, 3),
        "absolute_loss": round(before - after, 3),
        "relative_loss_pct": round((before - after) / before * 100, 2),
    }


if __name__ == "__main__":
    mcp.run(transport="stdio")

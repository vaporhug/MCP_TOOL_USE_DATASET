# geo_dv36 -- Tool Reference

Domain: deep-time biodiversity reconstruction from fossil occurrences
(DeepDive-style; Cooper et al. 2024 *Nature Communications*).

## Database Retrieval (`database_retrieval.py`)

- **websearch** -- Generic web search (scrape backend).
- **fetch_url** -- HTTP GET with redirect handling.
- **query_pbdb** -- Paleobiology Database occurrence query (PBDB CSV API).
- **query_macrostrat** -- Macrostrat strat-name / column lookup.
- **query_zenodo** -- Zenodo record metadata + file list.
- **query_paleomap** -- Paleocoordinate reconstruction at age (GPlates).
- **query_doi** -- DOI -> Crossref + Unpaywall.
- **query_geo_timescale** -- ICS / GTS stage-age boundaries.
- **query_world_clim** -- WorldClim / CHELSA / paleoclim point lookup.

## Data Processing (`data_processing.py`)

- **read_csv / write_csv / read_json / write_json / read_excel** -- I/O.
- **drop_missing** -- Drop rows with NaN/empty in named columns.
- **coerce_numeric** -- Cast column values to float.
- **filter_rows** -- Subset by allowed values in a column.
- **groupby_aggregate** -- mean / sum / min / max / count / nunique groupby.

## Domain-Specific Analysis (`biodiversity_analysis.py`)

I/O of fossil tables:
- **load_occurrences_csv** -- Load PBDB-style occurrence CSV.
- **load_occurrences_excel** -- Load NOW-style fossil Excel sheet.

Time-bin construction & assignment:
- **build_time_bins_from_durations** -- Convert oldest-edge + durations
  list into (max_age, min_age) bin tuples.
- **assign_occurrences_to_bins** -- Assign each occurrence to one bin
  (midpoint or max-age rule); writes `<csv>.binned.csv`.

Per-bin richness estimators:
- **sampled_in_bin_diversity** -- Raw unique-taxa count per bin.
- **range_through_diversity** -- Each taxon counts in every bin between
  first and last occurrence (less gap-sensitive).
- **singleton_count** -- Number of singleton taxa per bin.
- **shareholder_quorum_subsampling** -- SQS (Alroy 2010) standardised
  richness; default quorum = 0.6, 100 replicates.

Feature extraction (model input):
- **extract_per_bin_features** -- Per-bin n_taxa, n_occurrences,
  n_singletons, n_endemic_taxa, n_range_through, n_localities, plus
  per-region versions; writes `<csv>.features.json`.

Biodiversity simulator:
- **simulate_birth_death_trajectories** -- Stochastic piece-wise
  birth-death simulator with mass-extinction events; writes
  `simulated_trajectories.npz`.
- **simulate_fossil_record_from_trajectories** -- Degrade simulated
  trajectories with multi-region locality sampling, preservation, and
  gap probabilities; writes feature tensor + true diversity to
  `fossil_features.npz`.

Recurrent-neural-network estimator:
- **train_simple_rnn** -- Train a small bidirectional-LSTM regressor
  mapping per-bin fossil features to true diversity (log-MSE loss,
  early stopping); saves `simple_rnn_model/model.keras`.
- **predict_diversity_with_uncertainty** -- Apply trained RNN with
  Monte-Carlo dropout (default 100 samples) to get a 95% credible
  band; writes `predicted_diversity.json`.

Plotting & summary:
- **plot_diversity_curve** -- Median + 95%-band palaeodiversity curve
  vs. age (Ma); supports overlay of baseline series and vertical
  event markers.
- **plot_feature_histograms** -- Empirical vs. simulated histograms of
  the six per-bin features.
- **compute_diversity_change** -- Relative loss/gain between two sets
  of bins (e.g. peak-Permian -> Early Triassic for the PTME).

## Required Python packages

```
numpy pandas scipy matplotlib openpyxl
tensorflow>=2.15
mcp[cli]
```

## Typical workflow

```python
from biodiversity_analysis import (
    build_time_bins_from_durations, assign_occurrences_to_bins,
    range_through_diversity, shareholder_quorum_subsampling,
    extract_per_bin_features, simulate_birth_death_trajectories,
    simulate_fossil_record_from_trajectories, train_simple_rnn,
    predict_diversity_with_uncertainty, plot_diversity_curve,
    compute_diversity_change,
)

# 1. Time-bin schema
durations = pd.read_csv("input_data/data/marine_t_bins.csv").iloc[:,0].tolist()
edges = build_time_bins_from_durations(259.51, durations)["edges"]

# 2. Assign occurrences and compute baseline richness
binned = assign_occurrences_to_bins(
    "input_data/data/marine_occurrences.csv", edges)["binned_csv_path"]
rt = range_through_diversity(binned, n_bins=11)["range_through_diversity"]
sqs = shareholder_quorum_subsampling(binned, quorum=0.6)["sqs_diversity_mean"]

# 3. Extract features and train DeepDive-style RNN
emp = extract_per_bin_features(binned, region_col="reg", n_bins=11)
simulate_birth_death_trajectories(n_simulations=400, n_time_bins=11,
                                  bin_duration_my=6.0,
                                  total_diversity_range=(500, 12000))
simulate_fossil_record_from_trajectories()
train_simple_rnn(epochs=30, hidden_units=24)
pred = predict_diversity_with_uncertainty(emp["features_json_path"])

# 4. Plot and summarise
plot_diversity_curve("predicted_diversity.json", "input_data/data/marine_t_bins.csv",
                     259.51, "artifacts/Fig_marine_diversity_through_time.png",
                     clade_label="genus diversity",
                     baseline_curves={"range-through": rt, "SQS": sqs},
                     vlines_ma=[251.9, 201.4])
ptme = compute_diversity_change(rt, [1], [2])  # late Permian -> early Triassic
```

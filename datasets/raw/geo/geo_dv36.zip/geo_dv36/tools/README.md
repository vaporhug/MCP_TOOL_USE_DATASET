# geo_dv36 -- Tool Reference

Domain: deep-time biodiversity reconstruction from fossil occurrences
(DeepDive-style; Cooper et al. 2024 *Nature Communications*).

## DeepDive algorithm provenance

The MCP primitives in `biodiversity_analysis.py` re-implement the key
algorithms from the official Cooper / Flannery-Sutherland / Silvestro
2024 DeepDive library (https://github.com/DeepDive-project/deepdive,
LGPL-2.1) as clean MCP `@mcp.tool()` primitives — extracted, not
vendored verbatim, so each step is callable as a single MCP entry
point with explicit parameter docs.

- `simulate_birth_death_trajectories` mirrors the official
  `bd_simulator.simulate` (piece-wise constant lambda/mu with random
  shift times via `poiL` / `poiM`, `p_constant_bd`, `p_equilibrium`,
  per-Myr mass-extinction events with intensity range, rejection
  sampling against total species range).
- `simulate_fossil_record_from_trajectories` mirrors the official
  `fossil_simulator.run_simulation` (Gamma per-species + per-area
  preservation rates, log-linear time-rate with sd_through_time noise,
  Dirichlet area sizes coupling carrying capacity, Poisson locality
  drawing capped at `maximum_localities_per_bin`, area-specific eta
  variation, uniform `p_gap_range`).
- `train_simple_rnn` mirrors the official `rnn_builder.build_rnn` +
  `fit_rnn` (stacked Bidirectional LSTMs with tanh/sigmoid activations,
  Dense stack, Dropout, softplus output head, MSE loss, Adam optimizer,
  EarlyStopping on val_loss with restore_best_weights). Default
  `lstm_nodes=[64, 32]` and `dense_nodes=[32]` match the paper's
  headline architecture.

Each function docstring includes the original-source citation and the
specific algorithmic recipe extracted from the paper code.

## Database Retrieval (`database_retrieval.py`)

- **websearch** -- Generic web search (scrape backend).
- **fetch_url** -- HTTP GET with redirect handling.
- **query_pbdb** -- Paleobiology Database occurrence query (PBDB CSV API).
- **query_macrostrat** -- Macrostrat strat-name / column lookup.
- **query_zenodo** -- Zenodo record metadata + file list.
- **query_paleomap** -- Paleocoordinate reconstruction at age (GPlates).
- **query_doi** -- DOI -> Crossref + Unpaywall.
- **query_geo_timescale** -- ICS / GTS stage-age boundaries.
- **query_world_clim** -- WorldClim / CHELSA / paleoclim point lookup.

## Data Processing (`data_processing.py`)

- **read_csv / write_csv / read_json / write_json / read_excel** -- I/O.
- **drop_missing** -- Drop rows with NaN/empty in named columns.
- **coerce_numeric** -- Cast column values to float.
- **filter_rows** -- Subset by allowed values in a column.
- **groupby_aggregate** -- mean / sum / min / max / count / nunique groupby.

## Domain-Specific Analysis (`biodiversity_analysis.py`)

I/O of fossil tables:
- **load_occurrences_csv** -- Load PBDB-style occurrence CSV. Supports `return_all_records=True` for full-table downstream use and `output_csv=...` to write the (possibly capped) DataFrame back to a CSV path.
- **load_occurrences_excel** -- Load NOW-style fossil Excel sheet. Supports `return_all_records=True` to expose all rows (~2,130 for the bundled proboscidean workbook) and `output_csv=...` to convert the workbook to CSV in one step for downstream MCP tools that take a CSV path argument.

Time-bin construction & assignment:
- **build_time_bins_from_durations** -- Convert oldest-edge + durations
  list into (max_age, min_age) bin tuples.
- **assign_occurrences_to_bins** -- Assign each occurrence to one bin
  (midpoint or max-age rule); writes `<csv>.binned.csv`.

Per-bin richness estimators:
- **sampled_in_bin_diversity** -- Raw unique-taxa count per bin.
- **range_through_diversity** -- Each taxon counts in every bin between
  first and last occurrence (less gap-sensitive).
- **singleton_count** -- Number of singleton taxa per bin.
- **shareholder_quorum_subsampling** -- SQS (Alroy 2010) standardised
  richness; default quorum = 0.6, 100 replicates.

Occurrence cleaning (paper-equivalent filtering):
- **convert_proboscidean_columns** -- Rename the NOW-style proboscidean
  workbook's columns (MAX_AGE, MIN_AGE, GENUS, LIDNUM, continent, LAT,
  LONG, FAMILY, species_complete_corrected_until_10.2020) to the
  PBDB-style names expected by `assign_occurrences_to_bins` /
  `extract_per_bin_features` (max_ma, min_ma, genus, coll_no, reg,
  lat, lng, family, species). Optionally drops rows flagged
  `exclude == 1` upstream. Writes a normalised CSV.
- **filter_occurrences_paper_style** -- Apply finite-age + indet-name
  + age-window + accept-list + min-occurrences + dropna filter passes
  to a raw PBDB/NOW export; writes a cleaned CSV and a per-pass
  row-count audit so the agent can reproduce paper-side cleaning
  (approximates the proboscidean 2,130-occ pre-filter → 2,104-occ analyzed subset of Cooper et al. 2024 — exact reproduction requires the paper's accepted-taxa / synonymy table which is not redistributed in the bundle; the helper provides a deterministic best-effort cleaning with the same row-count direction).

Feature extraction (model input):
- **extract_per_bin_features** -- Per-bin n_taxa, n_occurrences,
  n_singletons, n_endemic_taxa, n_range_through, n_localities, plus
  per-region versions and optional `bin_durations`; writes
  `<csv>.features.json` (the per-region matrices + bin_durations are
  consumed by the upgraded RNN as bias-correction inputs, not just
  diagnostics).

Biodiversity simulator (bias-aware):
- **simulate_birth_death_trajectories** -- Stochastic piece-wise
  birth-death simulator with mass-extinction events. Accepts a
  `bin_durations` array so the simulator learns from realistic
  heterogeneous bin widths (e.g., marine 0.70-18.50 Myr,
  proboscidean 0.003-3 Myr) instead of a uniform `bin_duration_my`;
  writes `simulated_trajectories.npz` with the durations attached.
- **simulate_fossil_record_from_trajectories** -- Degrade simulated
  trajectories with multi-region locality sampling and species × area
  × time multiplicative preservation rates (Gamma per-species and
  per-area, log-linear per-bin time rate with `sd_through_time`
  noise, Dirichlet area sizes, Poisson locality drawing capped at
  `maximum_localities_per_bin`, area-specific eta variation, uniform
  `p_gap_range`). With `include_per_region=True` (default), the
  output tensor has shape (n_sims, n_bins, 6 + 3*n_regions + duration)
  so the RNN ingests spatially-explicit + duration features rather
  than only the 6 global summaries. Writes `fossil_features.npz` plus
  a `feature_layout` dict for downstream RNN auto-detection.

Recurrent-neural-network estimator:
- **train_simple_rnn** -- Train a small bidirectional-LSTM regressor
  mapping per-bin fossil features to true diversity (log-MSE loss,
  early stopping); saves `simple_rnn_model/model.keras`. Input width
  is whatever the simulator produced (6 / 6+per-region+duration).
- **predict_diversity_with_uncertainty** -- Apply trained RNN with
  Monte-Carlo dropout (default 100 samples). Reads
  `per_region_features` + `bin_durations` from the empirical
  features.json and rebuilds the same column layout the model was
  trained on (falls back to 6-feature legacy path if the model was
  trained that way); writes `predicted_diversity.json`.

Plotting & summary:
- **plot_diversity_curve** -- Median + 95%-band palaeodiversity curve
  vs. age (Ma); supports overlay of baseline series and vertical
  event markers.
- **plot_feature_histograms** -- Empirical vs. simulated histograms of
  the six per-bin features.
- **compute_diversity_change** -- Relative loss/gain between two sets
  of bins (e.g. peak-Permian -> Early Triassic for the PTME).

## Required Python packages

```
numpy pandas scipy matplotlib openpyxl
tensorflow>=2.15
mcp[cli]
```

## Typical workflow

```python
from biodiversity_analysis import (
    build_time_bins_from_durations, assign_occurrences_to_bins,
    filter_occurrences_paper_style, range_through_diversity,
    shareholder_quorum_subsampling, extract_per_bin_features,
    simulate_birth_death_trajectories,
    simulate_fossil_record_from_trajectories, train_simple_rnn,
    predict_diversity_with_uncertainty, plot_diversity_curve,
    compute_diversity_change,
)

# 1. Time-bin schema (heterogeneous durations carried through downstream)
durations = pd.read_csv("input_data/data/marine_t_bins.csv").iloc[:,0].tolist()
edges = build_time_bins_from_durations(259.55, durations)["edges"]

# 2. Optionally clean raw occurrences to paper-equivalent subset
clean = filter_occurrences_paper_style(
    "input_data/data/marine_occurrences.csv",
    "marine_clean.csv",
    age_window=(259.55, 192.94),
    dropna_cols=["lng","lat","reg"],
)["output_csv"]

# 3. Assign occurrences and compute baseline richness
binned = assign_occurrences_to_bins(clean, edges)["binned_csv_path"]
rt = range_through_diversity(binned, n_bins=len(durations))["range_through_diversity"]
sqs = shareholder_quorum_subsampling(binned, quorum=0.6)["sqs_diversity_mean"]

# 4. Extract features + train DeepDive-style RNN with REAL bias-correction inputs
emp = extract_per_bin_features(binned, region_col="reg",
                               n_bins=len(durations),
                               bin_durations=durations)
simulate_birth_death_trajectories(n_simulations=400,
                                  bin_durations=durations,
                                  total_species_range=(500, 12000),
                                  output_npz="marine_work/sim_traj.npz")
simulate_fossil_record_from_trajectories(
    npz_path="marine_work/sim_traj.npz",
    n_regions=len(emp["regions"]),
    include_per_region=True, include_duration=True,
    sp_pres_shape=1.5, area_pres_shape=2.0, sd_through_time=0.5,
    output_npz="marine_work/features.npz")
train_simple_rnn("marine_work/features.npz",
                 epochs=30, lstm_nodes=[32], dense_nodes=[16],
                 model_dir="marine_work/rnn_model")
pred = predict_diversity_with_uncertainty(
    emp["features_json_path"],
    model_dir="marine_work/rnn_model",
    output_json="marine_work/predicted.json",
)

# 4. Plot and summarise
plot_diversity_curve("marine_work/predicted.json", "input_data/data/marine_t_bins.csv",
                     259.55, "artifacts/Fig_marine_diversity_through_time.png",
                     clade_label="genus diversity",
                     baseline_curves={"range-through": rt, "SQS": sqs},
                     vlines_ma=[251.9, 201.4])
# Use the bias-corrected RNN median (not the raw range-through baseline)
# for the headline PTME / TJME loss magnitudes — `rt` is the uncorrected
# baseline and will OVERSTATE diversity drops; the paper's reported
# values are from the bias-corrected DeepDive prediction.
ptme = compute_diversity_change(pred["median_diversity"], [1], [2])  # late Permian -> early Triassic
tjme = compute_diversity_change(pred["median_diversity"], [4], [5])  # late Triassic -> early Jurassic
```

### Proboscidean workflow (species-level — pass ``taxon_col="species"`` everywhere)

The proboscidean workbook is **species**-level (185 species across 17
sub-regions), not genus-level. The downstream binning / feature /
diversity helpers default to ``taxon_col="genus"``; for the
proboscidean clade you must override that everywhere AND use a
separate working directory so the marine intermediates aren't
overwritten:

```python
# 1. Convert NOW xlsx -> PBDB-style CSV (renames MAX_AGE/MIN_AGE/GENUS/
#    species_complete_corrected_until_10.2020/LIDNUM/continent/LAT/LONG/
#    FAMILY and drops upstream exclude=1 rows)
probo_csv = convert_proboscidean_columns(
    "input_data/data/proboscidean_occurrences.xlsx",
    "proboscidean_work/proboscidean.csv",
)["output_csv"]

# 2. Optional paper-equivalent filter on species
clean = filter_occurrences_paper_style(
    probo_csv, "proboscidean_work/clean.csv",
    taxon_col="species",          # <-- species, not genus
    age_window=(66.0, 0.0),
    dropna_cols=["lng", "lat", "reg"],
)["output_csv"]

# 3. Bin + features at the species level
durations_probo = pd.read_csv("input_data/data/proboscidean_t_bins.csv").iloc[:,0].tolist()
edges_probo = build_time_bins_from_durations(66.0, durations_probo)["edges"]
binned = assign_occurrences_to_bins(clean, edges_probo)["binned_csv_path"]
rt = range_through_diversity(binned, taxon_col="species",
                             n_bins=len(durations_probo))["range_through_diversity"]
emp = extract_per_bin_features(binned, taxon_col="species",
                               region_col="reg",
                               n_bins=len(durations_probo),
                               bin_durations=durations_probo)

# 4. Simulate + train with separate output paths so marine + proboscidean
#    do not overwrite each other
simulate_birth_death_trajectories(n_simulations=400,
                                  bin_durations=durations_probo,
                                  total_species_range=(50, 500),
                                  output_npz="proboscidean_work/sim_traj.npz")
simulate_fossil_record_from_trajectories(
    npz_path="proboscidean_work/sim_traj.npz",
    n_regions=len(emp["regions"]),
    output_npz="proboscidean_work/features.npz")
train_simple_rnn("proboscidean_work/features.npz",
                 model_dir="proboscidean_work/rnn_model")
pred = predict_diversity_with_uncertainty(
    emp["features_json_path"],
    model_dir="proboscidean_work/rnn_model",
    output_json="proboscidean_work/predicted.json",
)
plot_diversity_curve("proboscidean_work/predicted.json",
                     "input_data/data/proboscidean_t_bins.csv",
                     66.0, "artifacts/Fig_proboscidean_diversity_through_time.png",
                     clade_label="species diversity")
```

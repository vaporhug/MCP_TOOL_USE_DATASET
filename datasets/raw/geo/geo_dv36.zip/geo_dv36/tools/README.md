# geo_dv36 -- Tool Reference

Domain: deep-time biodiversity reconstruction from fossil occurrences
(DeepDive-style; Cooper et al. 2024 *Nature Communications*).

## Database Retrieval (`database_retrieval.py`)

- **websearch** -- Generic web search (scrape backend).
- **fetch_url** -- HTTP GET with redirect handling.
- **query_pbdb** -- Paleobiology Database occurrence query (PBDB CSV API).
- **query_macrostrat** -- Macrostrat strat-name / column lookup.
- **query_zenodo** -- Zenodo record metadata + file list.
- **query_paleomap** -- Paleocoordinate reconstruction at age (GPlates).
- **query_doi** -- DOI -> Crossref + Unpaywall.
- **query_geo_timescale** -- ICS / GTS stage-age boundaries.
- **query_world_clim** -- WorldClim / CHELSA / paleoclim point lookup.

## Data Processing (`data_processing.py`)

- **read_csv / write_csv / read_json / write_json / read_excel** -- I/O.
- **drop_missing** -- Drop rows with NaN/empty in named columns.
- **coerce_numeric** -- Cast column values to float.
- **filter_rows** -- Subset by allowed values in a column.
- **groupby_aggregate** -- mean / sum / min / max / count / nunique groupby.

## Domain-Specific Analysis (`biodiversity_analysis.py`)

I/O of fossil tables:
- **load_occurrences_csv** -- Load PBDB-style occurrence CSV. Supports `return_all_records=True` for full-table downstream use and `output_csv=...` to write the (possibly capped) DataFrame back to a CSV path.
- **load_occurrences_excel** -- Load NOW-style fossil Excel sheet. Supports `return_all_records=True` to expose all rows (~2,130 for the bundled proboscidean workbook) and `output_csv=...` to convert the workbook to CSV in one step for downstream MCP tools that take a CSV path argument.

Time-bin construction & assignment:
- **build_time_bins_from_durations** -- Convert oldest-edge + durations
  list into (max_age, min_age) bin tuples.
- **assign_occurrences_to_bins** -- Assign each occurrence to one bin
  (midpoint or max-age rule); writes `<csv>.binned.csv`.

Per-bin richness estimators:
- **sampled_in_bin_diversity** -- Raw unique-taxa count per bin.
- **range_through_diversity** -- Each taxon counts in every bin between
  first and last occurrence (less gap-sensitive).
- **singleton_count** -- Number of singleton taxa per bin.
- **shareholder_quorum_subsampling** -- SQS (Alroy 2010) standardised
  richness; default quorum = 0.6, 100 replicates.

Occurrence cleaning (paper-equivalent filtering):
- **convert_proboscidean_columns** -- Rename the NOW-style proboscidean
  workbook's columns (MAX_AGE, MIN_AGE, GENUS, LIDNUM, continent, LAT,
  LONG, FAMILY, species_complete_corrected_until_10.2020) to the
  PBDB-style names expected by `assign_occurrences_to_bins` /
  `extract_per_bin_features` (max_ma, min_ma, genus, coll_no, reg,
  lat, lng, family, species). Optionally drops rows flagged
  `exclude == 1` upstream. Writes a normalised CSV.
- **filter_occurrences_paper_style** -- Apply finite-age + indet-name
  + age-window + accept-list + min-occurrences + dropna filter passes
  to a raw PBDB/NOW export; writes a cleaned CSV and a per-pass
  row-count audit so the agent can reproduce paper-side cleaning
  (approximates the proboscidean 2,130-occ pre-filter → 2,104-occ analyzed subset of Cooper et al. 2024 — exact reproduction requires the paper's accepted-taxa / synonymy table which is not redistributed in the bundle; the helper provides a deterministic best-effort cleaning with the same row-count direction).

Feature extraction (model input):
- **extract_per_bin_features** -- Per-bin n_taxa, n_occurrences,
  n_singletons, n_endemic_taxa, n_range_through, n_localities, plus
  per-region versions and optional `bin_durations`; writes
  `<csv>.features.json` (the per-region matrices + bin_durations are
  consumed by the upgraded RNN as bias-correction inputs, not just
  diagnostics).

Biodiversity simulator (bias-aware):
- **simulate_birth_death_trajectories** -- Stochastic piece-wise
  birth-death simulator with mass-extinction events. Accepts a
  `bin_durations` array so the simulator learns from realistic
  heterogeneous bin widths (e.g., marine 0.70-18.50 Myr,
  proboscidean 0.003-3 Myr) instead of a uniform `bin_duration_my`;
  writes `simulated_trajectories.npz` with the durations attached.
- **simulate_fossil_record_from_trajectories** -- Degrade simulated
  trajectories with multi-region locality sampling, preservation, and
  gap probabilities. With `include_per_region=True` (default), the
  output tensor has shape (n_sims, n_bins, 6 + 3*n_regions +
  duration) so the RNN ingests spatially-explicit + duration features
  rather than only the 6 global summaries; `taxon_preservation_classes
  > 1` lets the simulator generate taxon-specific preservation
  heterogeneity. Writes `fossil_features.npz` plus a `feature_layout`
  dict for downstream RNN auto-detection.

Recurrent-neural-network estimator:
- **train_simple_rnn** -- Train a small bidirectional-LSTM regressor
  mapping per-bin fossil features to true diversity (log-MSE loss,
  early stopping); saves `simple_rnn_model/model.keras`. Input width
  is whatever the simulator produced (6 / 6+per-region+duration).
- **predict_diversity_with_uncertainty** -- Apply trained RNN with
  Monte-Carlo dropout (default 100 samples). Reads
  `per_region_features` + `bin_durations` from the empirical
  features.json and rebuilds the same column layout the model was
  trained on (falls back to 6-feature legacy path if the model was
  trained that way); writes `predicted_diversity.json`.

Plotting & summary:
- **plot_diversity_curve** -- Median + 95%-band palaeodiversity curve
  vs. age (Ma); supports overlay of baseline series and vertical
  event markers.
- **plot_feature_histograms** -- Empirical vs. simulated histograms of
  the six per-bin features.
- **compute_diversity_change** -- Relative loss/gain between two sets
  of bins (e.g. peak-Permian -> Early Triassic for the PTME).

## Required Python packages

```
numpy pandas scipy matplotlib openpyxl
tensorflow>=2.15
mcp[cli]
```

## Typical workflow

```python
from biodiversity_analysis import (
    build_time_bins_from_durations, assign_occurrences_to_bins,
    filter_occurrences_paper_style, range_through_diversity,
    shareholder_quorum_subsampling, extract_per_bin_features,
    simulate_birth_death_trajectories,
    simulate_fossil_record_from_trajectories, train_simple_rnn,
    predict_diversity_with_uncertainty, plot_diversity_curve,
    compute_diversity_change,
)

# 1. Time-bin schema (heterogeneous durations carried through downstream)
durations = pd.read_csv("input_data/data/marine_t_bins.csv").iloc[:,0].tolist()
edges = build_time_bins_from_durations(259.55, durations)["edges"]

# 2. Optionally clean raw occurrences to paper-equivalent subset
clean = filter_occurrences_paper_style(
    "input_data/data/marine_occurrences.csv",
    "marine_clean.csv",
    age_window=(259.55, 192.94),
    dropna_cols=["lng","lat","reg"],
)["output_csv"]

# 3. Assign occurrences and compute baseline richness
binned = assign_occurrences_to_bins(clean, edges)["binned_csv_path"]
rt = range_through_diversity(binned, n_bins=len(durations))["range_through_diversity"]
sqs = shareholder_quorum_subsampling(binned, quorum=0.6)["sqs_diversity_mean"]

# 4. Extract features + train DeepDive-style RNN with REAL bias-correction inputs
emp = extract_per_bin_features(binned, region_col="reg",
                               n_bins=len(durations),
                               bin_durations=durations)
simulate_birth_death_trajectories(n_simulations=400,
                                  bin_durations=durations,
                                  total_diversity_range=(500, 12000))
simulate_fossil_record_from_trajectories(
    n_regions=len(emp["regions"]),
    include_per_region=True, include_duration=True,
    taxon_preservation_classes=3)
train_simple_rnn(epochs=30, hidden_units=24)
pred = predict_diversity_with_uncertainty(emp["features_json_path"])

# 4. Plot and summarise
plot_diversity_curve("predicted_diversity.json", "input_data/data/marine_t_bins.csv",
                     259.55, "artifacts/Fig_marine_diversity_through_time.png",
                     clade_label="genus diversity",
                     baseline_curves={"range-through": rt, "SQS": sqs},
                     vlines_ma=[251.9, 201.4])
ptme = compute_diversity_change(rt, [1], [2])  # late Permian -> early Triassic
```

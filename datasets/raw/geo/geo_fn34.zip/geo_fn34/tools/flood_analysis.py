#!/usr/bin/env python3
"""Flood-hydrology analysis tools for assessing nature-based-solution
(NbS) effectiveness from UK river-flow time series.

Provides primitives only: load discharge CSV, detect peaks, compute flood
metrics (peak Q, recession constant, lag-time), fit linear / robust
regressions of NbS effectiveness vs. catchment scale, and estimate
storage-intensity (m^3 km^-2) at the flood peak.  Each function is a
@mcp.tool()-exposed FastMCP endpoint and returns plain-JSON dicts.
"""

import os
import json
import math
import numpy as np
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Flood_NbS_Tools")


# --------------------------------------------------------------------------- #
# 1. Time-series loading                                                      #
# --------------------------------------------------------------------------- #
@mcp.tool()
def load_discharge_csv(csv_path: str, value_col: str = "value",
                       date_col: str = "dateTime",
                       include_series: bool = True) -> dict:
    """Load an EA Hydrology discharge CSV (date, value m3 s-1).

    Returns parsed times (ISO strings), Q values, n_rows, span and basic
    stats. Drops NaN / non-numeric rows. If ``include_series`` is False,
    only the summary fields (n_rows / start / end / q_mean / q_max /
    q_min / q_p95 / q_p99) are returned — useful for cheap summarisation
    over many stations.
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    df = df[[date_col, value_col]].copy()
    df[value_col] = pd.to_numeric(df[value_col], errors="coerce")
    df = df.dropna()
    df[date_col] = pd.to_datetime(df[date_col])
    df = df.sort_values(date_col).reset_index(drop=True)
    q = df[value_col].astype(float).values
    out = {
        "n_rows": int(len(df)),
        "start": str(df[date_col].iloc[0]) if len(df) else None,
        "end": str(df[date_col].iloc[-1]) if len(df) else None,
        "q_mean": round(float(q.mean()), 4) if len(q) else None,
        "q_max": round(float(q.max()), 4) if len(q) else None,
        "q_min": round(float(q.min()), 4) if len(q) else None,
        "q_p95": round(float(np.percentile(q, 95)), 4) if len(q) else None,
        "q_p99": round(float(np.percentile(q, 99)), 4) if len(q) else None,
    }
    if include_series:
        out["times"] = [str(t) for t in df[date_col].astype(str).tolist()]
        out["q_m3s"] = [round(float(v), 4) for v in q.tolist()]
    return out


@mcp.tool()
def load_station_metadata(csv_path: str) -> dict:
    """Load station_metadata.csv -> rows with id/name/river/area/lat/lon."""
    import pandas as pd
    df = pd.read_csv(csv_path)
    return {
        "n_stations": int(len(df)),
        "columns": list(df.columns),
        "rows": df.to_dict("records"),
    }


# --------------------------------------------------------------------------- #
# 2. Flood metric computation                                                  #
# --------------------------------------------------------------------------- #
@mcp.tool()
def detect_flood_peaks(csv_path: str, value_col: str = "value",
                       date_col: str = "dateTime",
                       quantile: float = 0.99,
                       min_separation_hours: float = 48.0) -> dict:
    """Identify independent flood peaks via peaks-over-threshold (POT).

    Threshold = quantile of Q. Peaks must be separated by at least
    `min_separation_hours` to count as independent events. Returns peak
    list (date, Q) sorted by magnitude.
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    df[value_col] = pd.to_numeric(df[value_col], errors="coerce")
    df = df.dropna(subset=[value_col]).copy()
    df[date_col] = pd.to_datetime(df[date_col])
    df = df.sort_values(date_col).reset_index(drop=True)
    q = df[value_col].astype(float).values
    t = df[date_col].values
    thr = float(np.quantile(q, quantile))
    above = q > thr
    # Walk runs to find peak inside each run
    peaks = []
    i = 0
    n = len(q)
    while i < n:
        if above[i]:
            j = i
            while j < n and above[j]:
                j += 1
            run_q = q[i:j]
            run_t = t[i:j]
            k = int(np.argmax(run_q))
            peaks.append((run_t[k], float(run_q[k])))
            i = j
        else:
            i += 1
    # Enforce independence
    sep = np.timedelta64(int(min_separation_hours * 3600), "s")
    peaks_sorted = sorted(peaks)
    final: list = []
    for tk, qk in peaks_sorted:
        if not final or (tk - final[-1][0]) >= sep:
            final.append((tk, qk))
        elif qk > final[-1][1]:
            final[-1] = (tk, qk)
    final_sorted = sorted(final, key=lambda x: -x[1])
    return {
        "threshold_q": round(thr, 4),
        "n_peaks": len(final_sorted),
        "peaks": [{"date": str(p[0]), "q_m3s": round(p[1], 4)}
                  for p in final_sorted[:50]],
    }



@mcp.tool()
def annual_maxima(csv_path: str, value_col: str = "value",
                  date_col: str = "dateTime") -> dict:
    """Return the annual maximum Q (and its date) for each year in a
    discharge CSV.

    Outputs ``years``, ``q_max_m3s`` (one per year), ``date_max`` (ISO
    string of the maximum-Q timestamp inside that year), ``n_years``,
    ``overall_max_q_m3s`` and ``overall_max_date``. Used to populate
    the Fig.2 / report.md annual-daily-max table (separate primitive
    from ``detect_flood_peaks``, which is a peaks-over-threshold
    routine, not an annual-maxima routine).
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    df[value_col] = pd.to_numeric(df[value_col], errors="coerce")
    df = df.dropna(subset=[value_col]).copy()
    df[date_col] = pd.to_datetime(df[date_col])
    df["__year__"] = df[date_col].dt.year
    rows = []
    for yr, group in df.groupby("__year__"):
        idx = int(group[value_col].astype(float).idxmax())
        rows.append({
            "year": int(yr),
            "date": str(df.loc[idx, date_col])[:19],
            "q_max_m3s": round(float(df.loc[idx, value_col]), 4),
        })
    rows.sort(key=lambda r: r["year"])
    overall = max(rows, key=lambda r: r["q_max_m3s"]) if rows else None
    return {
        "n_years": len(rows),
        "years": [r["year"] for r in rows],
        "date_max": [r["date"] for r in rows],
        "q_max_m3s": [r["q_max_m3s"] for r in rows],
        "overall_max_q_m3s": (overall and overall["q_max_m3s"]),
        "overall_max_date": (overall and overall["date"]),
    }


@mcp.tool()
def recession_constant(csv_path: str, value_col: str = "value",
                       date_col: str = "dateTime",
                       peak_date: str = "",
                       window_days: int = 14) -> dict:
    """Fit Q(t) = Q0 * exp(-k*t) on the falling limb after a flood peak.

    Returns recession k (per day), half-life (days) and R^2.
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    df[value_col] = pd.to_numeric(df[value_col], errors="coerce")
    df = df.dropna(subset=[value_col]).copy()
    df[date_col] = pd.to_datetime(df[date_col])
    df = df.sort_values(date_col).reset_index(drop=True)
    if peak_date:
        peak_t = pd.to_datetime(peak_date)
        i0 = int((df[date_col] - peak_t).abs().idxmin())
    else:
        i0 = int(df[value_col].astype(float).idxmax())
    end = i0 + window_days
    seg = df.iloc[i0:end].copy()
    t = (seg[date_col] - seg[date_col].iloc[0]).dt.total_seconds().values / 86400.0
    q = seg[value_col].astype(float).values
    mask = q > 0
    if mask.sum() < 4:
        return {"error": "insufficient post-peak points"}
    lq = np.log(q[mask])
    A = np.vstack([t[mask], np.ones_like(t[mask])]).T
    sol, *_ = np.linalg.lstsq(A, lq, rcond=None)
    slope, intercept = sol
    k = -float(slope)
    yhat = A @ sol
    ss_res = float(np.sum((lq - yhat) ** 2))
    ss_tot = float(np.sum((lq - lq.mean()) ** 2))
    r2 = 1 - ss_res / ss_tot if ss_tot > 0 else None
    return {
        "peak_date": str(seg[date_col].iloc[0]),
        "window_days": window_days,
        "k_per_day": round(k, 4),
        "half_life_days": round(math.log(2) / k, 3) if k > 0 else None,
        "q0_m3s": round(float(math.exp(intercept)), 4),
        "r2": round(r2, 4) if r2 is not None else None,
        "n_points": int(mask.sum()),
    }


@mcp.tool()
def lag_time(upstream_csv: str, downstream_csv: str,
             value_col: str = "value", date_col: str = "dateTime",
             max_lag_hours: float = 24.0) -> dict:
    """Estimate lag time between upstream & downstream hydrographs by
    cross-correlation. Returns lag (hours) of maximum correlation.
    """
    import pandas as pd
    a = pd.read_csv(upstream_csv); b = pd.read_csv(downstream_csv)
    for d in (a, b):
        d[value_col] = pd.to_numeric(d[value_col], errors="coerce")
        d.dropna(subset=[value_col], inplace=True)
        d[date_col] = pd.to_datetime(d[date_col])
        d.sort_values(date_col, inplace=True)
    a = a.set_index(date_col)[value_col].astype(float)
    b = b.set_index(date_col)[value_col].astype(float)
    common = a.index.intersection(b.index)
    a = a.loc[common]; b = b.loc[common]
    if len(common) < 10:
        return {"error": "insufficient overlap"}
    dt_seconds = (a.index[1] - a.index[0]).total_seconds()
    max_lag = int((max_lag_hours * 3600) / dt_seconds)
    a_v = (a - a.mean()).values
    b_v = (b - b.mean()).values
    best_lag = 0
    best_r = -2.0
    sa = float(np.std(a_v)) or 1.0
    sb = float(np.std(b_v)) or 1.0
    for L in range(-max_lag, max_lag + 1):
        if L >= 0:
            x = a_v[:len(a_v) - L]; y = b_v[L:]
        else:
            x = a_v[-L:]; y = b_v[:len(b_v) + L]
        r = float(np.mean(x * y) / (sa * sb))
        if r > best_r:
            best_r = r; best_lag = L
    return {
        "n_overlap": int(len(common)),
        "dt_seconds": float(dt_seconds),
        "lag_steps": best_lag,
        "lag_hours": round(best_lag * dt_seconds / 3600.0, 3),
        "max_correlation": round(best_r, 4),
    }


@mcp.tool()
def flood_volume_around_peak(csv_path: str, peak_date: str,
                             half_window_hours: float = 2.0,
                             value_col: str = "value",
                             date_col: str = "dateTime") -> dict:
    """Integrate raw catchment discharge (m^3) within +/- half_window_hours
    of a peak via trapezoidal sum of Q.

    NOTE: this returns the RAW catchment-runoff volume passing the gauge,
    NOT the additional storage retained by an NbS feature around the
    peak (which is the quantity Chappell & Beven 2024 use for the
    paper's proposed 1,000 m^3 km^-2 alternative target (rounded from Grange measured example 1,322 m^3 km^-2) — that target is change-in-storage
    at the Grange-over-Sands bund, e.g. 404 m^3 retained over a 0.3054
    km^2 catchment giving 1,322 m^3/km^2). The two quantities have the
    same dimension but mean different things; observed catchment-runoff
    volumes typically exceed engineered NbS retention by orders of
    magnitude.
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    df[value_col] = pd.to_numeric(df[value_col], errors="coerce")
    df = df.dropna(subset=[value_col]).copy()
    df[date_col] = pd.to_datetime(df[date_col])
    df = df.sort_values(date_col).reset_index(drop=True)
    pk = pd.to_datetime(peak_date)
    lo = pk - pd.Timedelta(hours=half_window_hours)
    hi = pk + pd.Timedelta(hours=half_window_hours)
    seg = df[(df[date_col] >= lo) & (df[date_col] <= hi)].copy()
    if len(seg) < 2:
        return {"error": "no points in window"}
    t_s = (seg[date_col] - seg[date_col].iloc[0]).dt.total_seconds().values
    q = seg[value_col].astype(float).values
    vol_m3 = float(np.trapz(q, t_s))
    return {
        "peak_date": peak_date,
        "half_window_hours": half_window_hours,
        "n_samples": int(len(seg)),
        "q_peak_m3s": round(float(q.max()), 4),
        "volume_m3": round(vol_m3, 1),
    }


@mcp.tool()
def storage_intensity(volume_m3: float, catchment_area_km2: float) -> dict:
    """Return raw volume-per-area intensity (m^3 km^-2).

    This helper returns volume_m3 / area_km2 only. It is intentionally
    unit-agnostic about what `volume_m3` represents — it could be a gross
    catchment-runoff volume integrated under a hydrograph (gauge data) or
    an engineered NbS / FSB stored volume (design data). The two are NOT
    directly comparable: Chappell & Beven 2024 section 3.4 proposes a
    rounded alternative engineered-storage target of 1,000 m^3 km^-2
    (motivated by the Grange-over-Sands measured example of 1,322
    m^3 km^-2 = 404 m^3 retained over 0.3054 km^2 +/- 2 h around the
    peak) and a theoretical-maximum engineered-storage target of 11,404
    m^3 km^-2 (Garstang Flood Storage Basin: 1,300,000 m^3 over 114 km^2
    upstream catchment).

    The returned `ratio_to_1000_engineered` and `ratio_to_11404_engineered`
    fields ARE NOT engineering pass/fail flags — they are advisory
    scale-comparison ratios only, useful when the caller has explicitly
    passed an engineered-storage volume. Do not interpret them as proof
    that any NbS design target has been met; that determination requires
    a like-for-like engineered-storage estimate, not a gauge-runoff
    integration.
    """
    if catchment_area_km2 <= 0:
        return {"error": "area must be positive"}
    intensity = volume_m3 / catchment_area_km2
    return {
        "volume_m3": round(volume_m3, 2),
        "area_km2": round(catchment_area_km2, 4),
        "intensity_m3_per_km2": round(intensity, 2),
        "ratio_to_1000_engineered": round(intensity / 1000.0, 3),
        "ratio_to_11404_engineered": round(intensity / 11404.0, 3),
        "note": (
            "ratios are advisory scale comparisons vs the paper's two "
            "ENGINEERED-storage design targets; passing the threshold "
            "does NOT mean an NbS design has been met when volume_m3 "
            "is a gauge-runoff integration."
        ),
    }


# --------------------------------------------------------------------------- #
# 3. Effectiveness regression                                                  #
# --------------------------------------------------------------------------- #
@mcp.tool()
def linear_regression(x_values: list, y_values: list) -> dict:
    """OLS y = a*x + b plus Pearson r and 95% CI for slope."""
    from scipy.stats import linregress
    x = np.asarray(x_values, dtype=float)
    y = np.asarray(y_values, dtype=float)
    m = ~(np.isnan(x) | np.isnan(y))
    x, y = x[m], y[m]
    res = linregress(x, y)
    return {
        "n": int(len(x)),
        "slope": round(float(res.slope), 6),
        "intercept": round(float(res.intercept), 6),
        "r": round(float(res.rvalue), 4),
        "r_squared": round(float(res.rvalue ** 2), 4),
        "p_value": round(float(res.pvalue), 6),
        "std_err": round(float(res.stderr), 6),
    }


@mcp.tool()
def power_law_fit(x_values: list, y_values: list) -> dict:
    """Fit y = a * x^b in log-log space (NbS effectiveness vs catchment area)."""
    x = np.asarray(x_values, dtype=float)
    y = np.asarray(y_values, dtype=float)
    m = (x > 0) & (y > 0) & ~(np.isnan(x) | np.isnan(y))
    if m.sum() < 3:
        return {"error": "need >= 3 positive (x,y) pairs"}
    lx = np.log(x[m]); ly = np.log(y[m])
    A = np.vstack([lx, np.ones_like(lx)]).T
    sol, *_ = np.linalg.lstsq(A, ly, rcond=None)
    b, lna = sol
    yhat = A @ sol
    ss_res = float(np.sum((ly - yhat) ** 2))
    ss_tot = float(np.sum((ly - ly.mean()) ** 2))
    r2 = 1 - ss_res / ss_tot if ss_tot > 0 else None
    return {
        "n": int(m.sum()),
        "a": round(float(math.exp(lna)), 6),
        "b": round(float(b), 4),
        "r_squared_loglog": round(float(r2), 4) if r2 is not None else None,
    }


@mcp.tool()
def descriptive_stats(values: list) -> dict:
    """Min/median/mean/p25/p75/max/std for a numeric list."""
    arr = np.asarray(values, dtype=float)
    arr = arr[~np.isnan(arr)]
    if len(arr) == 0:
        return {"error": "no valid values"}
    return {
        "n": int(len(arr)),
        "mean": round(float(arr.mean()), 4),
        "median": round(float(np.median(arr)), 4),
        "std": round(float(arr.std(ddof=1)), 4) if len(arr) > 1 else 0.0,
        "min": round(float(arr.min()), 4),
        "max": round(float(arr.max()), 4),
        "p25": round(float(np.percentile(arr, 25)), 4),
        "p75": round(float(np.percentile(arr, 75)), 4),
    }


@mcp.tool()
def count_by_condition(values: list, operator: str, threshold: float) -> dict:
    """Count / fraction of values satisfying op threshold ('<','<=','>','>=','==')."""
    arr = np.asarray(values, dtype=float)
    arr = arr[~np.isnan(arr)]
    ops = {"<": arr < threshold, "<=": arr <= threshold,
           ">": arr > threshold, ">=": arr >= threshold,
           "==": arr == threshold}
    if operator not in ops:
        return {"error": f"unknown op {operator}"}
    mask = ops[operator]
    return {
        "count": int(mask.sum()),
        "total": int(len(arr)),
        "fraction": round(float(mask.mean()), 4),
        "percentage": round(float(mask.mean() * 100), 2),
    }


# --------------------------------------------------------------------------- #
# 4. Plotting (one tool per image)                                             #
# --------------------------------------------------------------------------- #
@mcp.tool()
def plot_event_hydrograph(upstream_csv: str, downstream_csv: str,
                          out_path: str,
                          start: str, end: str,
                          value_col: str = "value",
                          date_col: str = "dateTime",
                          upstream_label: str = "upstream",
                          downstream_label: str = "downstream",
                          title: str = "Flood event hydrograph") -> dict:
    """Plot two hydrographs (e.g. before & after NbS, or upstream & downstream
    of a bund) on the same axis for a flood event window. Saves PNG."""
    import pandas as pd
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    a = pd.read_csv(upstream_csv); b = pd.read_csv(downstream_csv)
    for d in (a, b):
        d[value_col] = pd.to_numeric(d[value_col], errors="coerce")
        d.dropna(subset=[value_col], inplace=True)
        d[date_col] = pd.to_datetime(d[date_col])
    a = a[(a[date_col] >= start) & (a[date_col] <= end)].sort_values(date_col)
    b = b[(b[date_col] >= start) & (b[date_col] <= end)].sort_values(date_col)
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.plot(a[date_col], a[value_col], "-", color="steelblue", lw=1.6,
            label=upstream_label)
    ax.plot(b[date_col], b[value_col], "-", color="darkorange", lw=1.6,
            label=downstream_label)
    ax.set_xlabel("Date / time"); ax.set_ylabel("Discharge Q (m$^3$ s$^{-1}$)")
    ax.set_title(title)
    ax.grid(alpha=0.3); ax.legend()
    fig.autofmt_xdate(); fig.tight_layout()
    fig.savefig(out_path, dpi=150); plt.close(fig)
    return {"path": out_path,
            "n_upstream": int(len(a)), "n_downstream": int(len(b))}


@mcp.tool()
def plot_peaks_distribution(csv_path: str, out_path: str,
                             value_col: str = "value",
                             date_col: str = "dateTime",
                             title: str = "Annual flood peaks") -> dict:
    """Plot annual maximum discharge series + Weibull-position return-period
    rank plot (flood-frequency curve)."""
    import pandas as pd
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    df = pd.read_csv(csv_path)
    df[value_col] = pd.to_numeric(df[value_col], errors="coerce")
    df = df.dropna(subset=[value_col]).copy()
    df[date_col] = pd.to_datetime(df[date_col])
    df["year"] = df[date_col].dt.year
    amax = df.groupby("year")[value_col].max().reset_index()
    qsort = np.sort(amax[value_col].astype(float).values)[::-1]
    rank = np.arange(1, len(qsort) + 1)
    rp = (len(qsort) + 1) / rank
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))
    axes[0].bar(amax["year"], amax[value_col], color="steelblue")
    axes[0].set_xlabel("Year"); axes[0].set_ylabel("Annual max Q (m$^3$ s$^{-1}$)")
    axes[0].set_title("Annual maximum series")
    axes[1].plot(rp, qsort, "o-", color="darkred")
    axes[1].set_xscale("log")
    axes[1].set_xlabel("Return period T (yr) [Weibull plotting position]")
    axes[1].set_ylabel("Q (m$^3$ s$^{-1}$)")
    axes[1].set_title("Flood-frequency curve")
    axes[1].grid(alpha=0.3, which="both")
    fig.suptitle(title); fig.tight_layout()
    fig.savefig(out_path, dpi=150); plt.close(fig)
    return {"path": out_path, "n_years": int(len(amax)),
            "qmax_m3s": round(float(amax[value_col].max()), 3)}


@mcp.tool()
def plot_intensity_vs_area(areas_km2: list, intensities: list,
                           labels: list, out_path: str,
                           target_low: float = 1000.0,
                           target_high: float = 11404.0,
                           title: str = "Catchment-runoff intensity vs catchment area (paper NbS targets as scale-context)") -> dict:
    """Qualitative scale-context scatter: catchment-runoff intensity
    (m^3/km^2, e.g. gross runoff volume / area) vs catchment area
    (km^2) with the paper's two NbS design-target reference horizontals:
    target_low=1,000 m^3/km^2 (Chappell & Beven 2024 section 3.4 — rounded
    PROPOSED alternative target intensity; paper's measured Grange example
    is 1,322 m^3/km^2 from 404 m^3 retained over 0.3054 km^2 ±2 h) and
    target_high=11,404 m^3/km^2 (theoretical maximum from the Garstang
    Flood Storage Basin: 1,300,000 m^3 over 114 km^2 upstream catchment;
    paper text reports 11,404 m^3/km^2 exactly — do not round to 10,000).
    NOTE: when fed gross catchment-runoff volumes, the y-axis quantity is
    NOT engineered storage intensity but raw runoff intensity. The two
    have the same dimension (m^3/km^2) but mean different things; the
    figure is interpretive scale-context, not a direct paper criterion
    reproduction."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    a = np.asarray(areas_km2, dtype=float)
    y = np.asarray(intensities, dtype=float)
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    fig, ax = plt.subplots(figsize=(7.5, 5))
    ax.scatter(a, y, s=60, color="darkgreen", edgecolor="k", zorder=3)
    for ax_, ay_, lab in zip(a, y, labels):
        ax.annotate(str(lab), (ax_, ay_), xytext=(4, 4),
                    textcoords="offset points", fontsize=8)
    ax.axhline(target_low, color="orange", ls="--", lw=1.2,
               label=f"paper proposed target {int(target_low)} m$^3$/km$^2$")
    ax.axhline(target_high, color="red", ls="--", lw=1.2,
               label=f"paper theoretical max {int(target_high)} m$^3$/km$^2$")
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlabel("Upstream catchment area (km$^2$)")
    ax.set_ylabel("Intensity (m$^3$ km$^{-2}$) — runoff or storage, see note")
    ax.set_title(title); ax.grid(alpha=0.3, which="both"); ax.legend(fontsize=8)
    fig.tight_layout(); fig.savefig(out_path, dpi=150); plt.close(fig)
    return {"path": out_path, "n_points": int(len(a))}


@mcp.tool()
def plot_recession_fit(csv_path: str, out_path: str,
                       peak_date: str = "",
                       window_days: int = 14,
                       value_col: str = "value",
                       date_col: str = "dateTime",
                       title: str = "Post-peak recession fit") -> dict:
    """Plot Q(t) on log-y after the highest peak with fitted exponential
    Q = Q0*exp(-k t). Annotates k and half-life on the figure."""
    import pandas as pd
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    df = pd.read_csv(csv_path)
    df[value_col] = pd.to_numeric(df[value_col], errors="coerce")
    df = df.dropna(subset=[value_col]).copy()
    df[date_col] = pd.to_datetime(df[date_col])
    df = df.sort_values(date_col).reset_index(drop=True)
    if peak_date:
        i0 = int((df[date_col] - pd.to_datetime(peak_date)).abs().idxmin())
    else:
        i0 = int(df[value_col].astype(float).idxmax())
    seg = df.iloc[i0:i0 + window_days].copy()
    t = (seg[date_col] - seg[date_col].iloc[0]).dt.total_seconds().values / 86400.0
    q = seg[value_col].astype(float).values
    mask = q > 0
    lq = np.log(q[mask])
    A = np.vstack([t[mask], np.ones_like(t[mask])]).T
    sol, *_ = np.linalg.lstsq(A, lq, rcond=None)
    k = -float(sol[0]); q0 = float(math.exp(sol[1]))
    qfit = q0 * np.exp(-k * t)
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    fig, ax = plt.subplots(figsize=(7.2, 4.4))
    ax.plot(t, q, "o", color="steelblue", label="observed Q")
    ax.plot(t, qfit, "-", color="darkred",
            label=f"fit k={k:.3f}/d, t1/2={math.log(2)/k:.2f} d" if k > 0 else "fit")
    ax.set_yscale("log"); ax.set_xlabel("Days since peak")
    ax.set_ylabel("Discharge Q (m$^3$ s$^{-1}$)"); ax.set_title(title)
    ax.grid(alpha=0.3, which="both"); ax.legend()
    fig.tight_layout(); fig.savefig(out_path, dpi=150); plt.close(fig)
    return {"path": out_path, "k_per_day": round(k, 4),
            "half_life_days": round(math.log(2) / k, 3) if k > 0 else None,
            "q0_m3s": round(q0, 3), "n_points": int(len(seg))}


if __name__ == "__main__":
    mcp.run(transport="stdio")

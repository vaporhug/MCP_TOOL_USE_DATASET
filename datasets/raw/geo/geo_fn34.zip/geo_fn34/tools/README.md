# geo_fn34 - Tools

## Modules
- `flood_analysis.py` - FastMCP-decorated domain tools for hydrology
  time-series analysis: `load_discharge_csv`, `load_station_metadata`,
  `detect_flood_peaks` (peaks-over-threshold), `annual_maxima`
  (year + date + Q for each year, used by Fig.2 / report.md annual
  daily-max table), `recession_constant`, `lag_time`,
  `flood_volume_around_peak`, `storage_intensity`, `linear_regression`,
  `power_law_fit`, `descriptive_stats`, `count_by_condition`, plus four
  one-tool-per-image plotters (`plot_event_hydrograph`,
  `plot_peaks_distribution`, `plot_intensity_vs_area`,
  `plot_recession_fit`).
- `data_processing.py` - generic CSV/JSON helpers (read, drop NaN,
  groupby aggregate, datetime parse). No network access — the bundled
  discharge CSVs in `input_data/data/` are self-contained.

## Run as MCP server
```bash
python flood_analysis.py
```
Listens on stdio per FastMCP convention.

## Python dependencies
```
numpy
pandas
scipy
matplotlib
mcp[server]   # provides mcp.server.fastmcp
```
Install with:
```bash
pip install numpy pandas scipy matplotlib "mcp[server]"
```

## Notes
- All discharge CSVs in `../input_data/data/` follow the EA Hydrology
  schema (columns `measure,dateTime,date,value,completeness,quality,qcode`).
  `value` is mean daily Q in m^3 s^-1 (or 15-min instantaneous when
  filename contains `15min`).
- `storage_intensity` reports flags vs the paper's two design targets:
  1,000 m^3 km^-2 (paper's proposed rounded alternative target; Grange measured example is 1,322 m^3 km^-2 = 404 m^3 / 0.3054 km^2 ±2 h) and
  11,404 m^3 km^-2 (theoretical maximum, Garstang Flood Storage Basin:
  1,300,000 m^3 over 114 km^2 upstream catchment) per Chappell & Beven
  2024 section 3.4.
- `flood_volume_around_peak` integrates raw gauge discharge Q over a
  +/- N-hour window (trapezoidal rule) and returns gross catchment-runoff
  volume in m^3. NOTE: this is NOT the paper's measured effectiveness
  criterion — the paper's measured criterion is change-in-storage
  retained by an NbS feature around the peak (Grange-over-Sands example:
  404 m^3 retained over 0.3054 km^2 = 1,322 m^3 km^-2 ±2 h, with the
  paper proposing 1,000 m^3 km^-2 as a rounded alternative target
  intensity). Use this tool for qualitative scale-context comparisons,
  not as a direct paper-criterion re-implementation.

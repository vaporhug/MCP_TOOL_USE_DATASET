# Cumbrian Headwater Hydrographs vs Chappell & Beven 2024 NbS Targets

## Bundle

10 small headwater stations across the rivers Wyre, Eden, Kent, Sprint,
Cocker, Mint, Lune, Bela, Calder, and Esk (26-131 km² catchments) in
Cumbria / NW England, sourced from the UK Environment Agency Hydrology
API:

- 10 daily-mean Q time-series spanning 2018-01-02 to 2024-12-30 (~2,555
  rows each), as `<station>_daily_flow.csv`.
- 2 paired 15-minute Q time-series for the 9-14 January 2023 flood
  event: `garstang_wyre_15min_jan2023.csv` and
  `bowston_kent_15min_jan2023.csv` (~576 rows each).
- Station metadata in `station_metadata.csv` (id, river, area, lat,
  lon, region).
- Numeric headlines:
  * 15-minute event peaks (Kent / Wyre) → `tools/flood_analysis.py:detect_flood_peaks`
    on the matching 15-minute CSV (peaks-over-threshold).
  * Annual daily maxima for the River Wyre at Garstang →
    `tools/flood_analysis.py:annual_maxima` on `garstang_wyre_daily_flow.csv`
    (returns year/date/q_max_m3s per year).
  * Per-station ±24h flood-runoff volume (Fig.3) →
    `flood_volume_around_peak` composed with `storage_intensity` and
    `plot_intensity_vs_area`.

Notes on EA quality flags: several of the bundled Garstang records ship
with `quality=Suspect` in the EA Hydrology API export. The bundle
retains them as-is for this qualitative scale-context comparison;
quantitative downstream re-uses should filter on `quality=Good`.

## Paper's two NbS storage-intensity design targets

Per Chappell & Beven 2024 section 3.4 (target_high paragraph p.5-7):

| Target | Value (m^3 km^-2) | Provenance |
| --- | --- | --- |
| Proposed alternative target (rounded) | 1,000  | Rounded from Grange-over-Sands measured example 1,322 m³ km⁻² = 404 m³ retained / 0.3054 km² ±2 h around the peak (paper section 3.4 heading uses the word "measured" for the ±2 h-peak criterion) |
| Theoretical maximum                   | 11,404 | Garstang Flood Storage Basin: 1,300,000 m³ over 114 km² upstream catchment |

These targets describe **engineered-feature storage**, not raw
catchment-runoff volume at a gauge. The `storage_intensity()` tool in
`tools/flood_analysis.py` reports `meets_1000_target` and
`meets_11404_target` flags against these two thresholds (defaults
updated to match the paper-verified theoretical-maximum value, not
the rounded "10,000").

## Paired-station January 2023 flood event (Fig.1)

Computed from `bowston_kent_15min_jan2023.csv` and
`garstang_wyre_15min_jan2023.csv` via `tools/flood_analysis.py:load_discharge_csv` +
`detect_flood_peaks`:

| Station | Peak Q (m³/s) | Peak time (UTC) |
| --- | ---: | --- |
| Kent at Bowston (Wyre catchment **leading**) | 62.44 | 2023-01-10 19:30 |
| Wyre at Garstang (peaking ~2 h **later**)     | 88.93 | 2023-01-10 21:30 |

The Kent-to-Wyre **~2-hour inter-catchment lag** is the headline
deliverable in Fig.1 and is relevant to leaky-barrier-timing
decisions across paired headwater catchments.

## Annual-maximum / flood-frequency at Garstang (Fig.2)

Annual daily-mean maxima for the River Wyre at Garstang, 2018-2024
(from `garstang_wyre_daily_flow.csv`):

| Year | Date | Daily-mean Q (m³/s) |
| --- | --- | ---: |
| 2018 | 2018-10-13 | 25.79 |
| 2019 | 2019-09-29 | 46.07 |
| 2020 | 2020-07-03 | 66.04 |
| **2021** | **2021-01-19** | **77.35** (overall maximum) |
| 2022 | 2022-02-08 | 36.12 |
| 2023 | 2023-07-23 | 57.14 |
| 2024 | 2024-11-23 | 60.39 |

The **largest daily-mean annual peak is 77.35 m³/s on 19 Jan 2021**.
Fig.1's higher 88.9 m³/s value on 2023-01-10 is **instantaneous
15-minute** discharge — the two figures are not directly comparable
as "annual maxima" because they use different timescales (daily vs
15-min).

## Storage-intensity vs catchment-area scatter (Fig.3)

Log-log scatter of integrated catchment flood-runoff volume per unit
catchment area vs catchment area for the 10 stations, with reference
lines at the paper's 1,000 m³/km² (paper's rounded proposed alternative target, motivated by Grange measured example 1,322) and
11,404 m³/km² (Garstang theoretical-maximum) NbS storage-intensity
design targets.

Per-station event scope: each station's LARGEST DAILY PEAK across the
bundled 2018-2024 daily-flow window (`load_discharge_csv` +
`detect_flood_peaks`), then integrate Q over ±24 h around that peak
via `flood_volume_around_peak(half_window_hours=24)`, then divide by
`catchment_area_km2` from `station_metadata.csv`. This is NOT the
Fig.1 January 2023 paired-station 15-minute event scope — Fig.1 and
Fig.3 use intentionally different scopes (sub-day event resolution
for the leaky-barrier-timing story vs each-station's annual-style
peak for the cohort-wide scale comparison).

The observed Cumbrian headwater per-station-largest-daily-peak
flood-runoff intensities sit substantially above both reference lines
(qualitative scale-context; gross-runoff vs engineered-retention is
not a like-for-like comparison) — i.e., an NbS feature meeting
either design target captures only a small fraction of the full
headwater flood-runoff volume.

## Conclusions

1. Chappell & Beven 2024 propose two engineered NbS-storage-intensity
   design targets: 1,000 m³/km² (paper's rounded proposed alternative target) and 11,404 m³/km²
   (theoretical maximum), describing engineered-feature storage.
2. On the bundled small Cumbrian headwater catchments (26-131 km²),
   per-station-largest-2018-2024-daily-peak ±24h flood-runoff
   intensities sit substantially above both targets (qualitative
   scale-context; gross-runoff vs engineered-retention is not a
   like-for-like comparison) — NbS schemes attenuate rather than
   fully retain headwater flood volumes.
3. The January 2023 flood event illustrates the ~2-hour Kent-to-Wyre
   inter-catchment lag relevant to leaky-barrier-timing decisions
   across paired headwater catchments.

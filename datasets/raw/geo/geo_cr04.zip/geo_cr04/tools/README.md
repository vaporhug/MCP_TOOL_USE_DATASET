# Tools

The **task capabilities** for `geo_cr04` are exactly the `@mcp.tool`-decorated
functions in **`crop_yield_forecast.py`** (listed below). Those are fully
implemented and exercised by this task.

`database_retrieval.py` and `data_processing.py` are **shared, generic
boilerplate** carried by every bundle in this dataset. The heavy `read_excel` /
`read_parquet` / `read_netcdf` / `read_shapefile` functions and the
`database_retrieval.py` query stubs are deliberate `pass` placeholders (network
/ heavy-dependency code filled in at runtime). They are **NOT** MCP tools (no
`@mcp.tool` decorator), **NOT** advertised as task capabilities, and are **not
required** to reproduce any answer number — the analysis runs entirely on the
fully-implemented `crop_yield_forecast.py` primitives plus the lightweight
pure-Python helpers (`read_csv`, `read_json`, etc.). They are listed here only
for completeness.

## database_retrieval.py (generic boilerplate — NOT a task capability)
Generic stubs for web search, URL fetch, and external database queries (FAOSTAT, NOAA, Zenodo, etc.). All functions are unimplemented `pass` placeholders, not used by this task.

## data_processing.py (generic boilerplate — NOT a task capability)
Format conversion, CSV/JSON/Excel/NetCDF readers, reshape (pivot, melt), join, groupby-aggregate, missing-data handling. Not domain-specific. The heavy readers (`read_excel`, `read_parquet`, `read_netcdf`, `read_shapefile`) are unimplemented `pass` placeholders; only the lightweight pure-Python helpers are used by this task.

## crop_yield_forecast.py
Low-level primitives for ENSO-conditioned crop yield forecast analysis. Every
`@mcp.tool` takes and returns only JSON-serializable types (lists / floats /
ints / bools / str-keyed dicts); no raw numpy arrays, tuples, or non-string
dict keys cross the tool boundary.
- `compute_yield_anomaly`: nan-aware Gaussian-smoothed trend removal, percent anomaly calculation (returns list; unestimable years are `None`, never NaN)
- `classify_enso_phase`: Nino 3.4 SST threshold-based La Nina / Neutral / El Nino classification (returns list; **a missing/NaN ENSO input returns `None` for that year, NOT Neutral** — callers must jointly filter to years with BOTH a finite yield anomaly AND a non-None ENSO phase)
- `harvest_window_nino34`: **the single authoritative harvest-alignment used everywhere in this task** (instruction, the reproduction pipeline below, and the LOO chain). Aligns a country's `harvest_month_end` (M) to its concurrent 3-month Nino 3.4 window (months M-2, M-1, M). The window is anchored so month M always lands in the harvest year Y; the two preceding months wrap to Y-1 whenever they drop below January. Cross-year cases: M=5 -> Mar(Y),Apr(Y),May(Y); M=2 -> Dec(Y-1),Jan(Y),Feb(Y); **M=1 (January harvest) -> Nov(Y-1),Dec(Y-1),Jan(Y)** — i.e. the 3-month window *ending* in the harvest year. Returns `{"harvest_years": [...], "nino34": [...], "window_months": [...]}`; any missing constituent month -> `None`.
- `faostat_country_to_iso3`: FAOSTAT 'Area' name -> ISO-3166 alpha-3 code (matches Natural Earth `ADM0_A3` so the world map colours the correct polygons). Returns `{"iso3": {...}, "unmatched": [...]}`
- `conditional_below_normal_prob`: Linear combination of phase-conditional below-normal tercile probabilities (returns float)
- `leave_one_out_forecasts`: Hold-one-out cross-validated probabilistic forecasts; the below-normal event threshold is recomputed **inside each fold from training years only** (no full-sample leakage) and applied to both the model and the held-out event label. A **single joint validity filter** (finite yield anomaly AND finite/non-None ENSO phase AND finite length-3 ENSO probability vector) is applied consistently per fold, so years missing any one of the three are excluded everywhere and **no NaN leaks into the forecasts/observed pair (hence none into the ROC)**. Returns `{"forecasts": [...], "observed": [...], "n_valid": int, "status": str}` (excluded years -> forecast `None`). **Valid-sample guard**: a fold needs >=2 valid years; with <2 it returns all-`None` forecasts and `status="insufficient_valid_samples"` instead of calling `np.percentile` on an empty array (no crash).
- `compute_roc_score`: **exact** ROC area (rank-based Mann-Whitney U with average-rank tie handling) + TPR/FPR step curve. `roc_area = (sum of average-ranks of the positive class - n_pos*(n_pos+1)/2) / (n_pos*n_neg)`; this is the exact AUC (independent of the threshold-grid resolution) and matches `sklearn.metrics.roc_auc_score`, with tied forecast scores contributing exactly 0.5. Returns `{"roc_area": float|None, "fpr": [...], "tpr": [...], "status": str}`. **Degenerate-class guard**: the ROC area is undefined unless the observed labels contain BOTH a positive and a negative case among finite-forecast samples; an all-positive set, an all-negative set, or no finite forecasts returns `roc_area=None` with `status` in {`"all_positive"`, `"all_negative"`, `"no_valid_samples"`} rather than a misleading 0.5/0.0. Callers skip `None`-ROC countries.
- `reliability_diagram`: Binned forecast probability vs. observed frequency. The **final bin is right-closed** so a forecast probability of exactly 1.0 is counted in the top bin (not dropped). Returns `{"bin_centers": [...], "obs_freq": [...], "counts": [...]}`
- `seasonal_nino34_mean`: **generic** NOAA-CPC fixed-season-code (DJF...NDJ) Nino 3.4 mean for ad-hoc look-ups. This is a convenience helper and is **NOT** the harvest-alignment used by the pipeline — the pipeline aligns each country's harvest month with `harvest_window_nino34` (see above). Returns `{"season_years": [...], "season_means": [...]}`
- `quality_screen_yields`: FAO data quality screening. Returns `{"clean_yields": [...], "flags": [...]}`
- `aggregate_country_groups`: aggregate yield for merged country groups (e.g. Former USSR) as total production / total harvested area (i.e. harvested-area-weighted mean of member yields). This is a group-yield helper only; it is NOT the ROC area-fraction weighting (the ROC area fractions are weighted by each country's mean harvested area, never by production). Returns dict of lists.
- `lookup_growing_season`, `parse_faostat_yield_table`, `parse_noaa_nino_text`: data-access helpers. `lookup_growing_season` matches the requested country **exact then case-insensitive only** against the calendar's FAOSTAT-named `country` column (no substring fallback — it produced spurious cross-country matches such as Oman->Romania, Dominica->Dominican Republic, Papua New Guinea->Guinea, "Africa"->South Africa, which invented calendar entries and inflated the analysed-country count); unmatched countries return `found=False` and are dropped. **Multi-season rule**: when a country/crop resolves to more than one (non-`Exclude`) row, a deterministic main-season rule is applied — primary season is chosen ahead of any `Season2:*` secondary-season row, then ties broken by smallest `harvest_month_end`, then qualifier, then country name; the returned `secondary_season` flag is `True` only when a country's sole row is a `Season2` entry (e.g. Ghana and Nigeria maize, which have no primary national row and so resolve to that single Season2 row rather than being dropped). `parse_noaa_nino_text` returns `flat` keyed by the string `"YYYY-MM"` (JSON-safe); the bundled NOAA file uses `-99.99` as its missing-value sentinel, so the caller maps `<= -99` to NaN before alignment.
- `compute_harvested_area_weighted_roc`: area-fraction helper (cumulative harvested-area fraction with ROC above each threshold).
- `plot_roc_world_map`, `plot_roc_vs_lead_time`, `plot_reliability_diagram`: **single-panel** primitive plotters (one map / one cumulative-band chart / one calibration diagram). Used as building blocks; they are NOT the multi-panel answer figures.

### Answer-figure tools (each emits one exact answer PNG)
Each of the three `image` answer items is produced by exactly one composite tool whose default `output_path` is the committed answer-figure path:

| Answer figure (`artifacts/...`) | Tool | What it draws |
| --- | --- | --- |
| `fig2_roc_maps.png` | `plot_roc_maps_two_panel(maize_roc, wheat_roc)` | Two-panel (maize over wheat) world map, countries shaded by concurrent-ENSO LOO ROC area on a diverging RdBu scale centred at 0.5; uncovered countries grey. |
| `fig3_roc_harvested_area.png` | `plot_roc_threshold_harvested_area(maize_area_fractions, wheat_area_fractions)` | Two-panel (maize, wheat) bar chart of the % of calendar-covered harvested area whose country ROC exceeds 0.5/0.55/0.6/0.65/0.7 (true cumulative fractions, monotonically decreasing). Consumes the dict from `compute_harvested_area_weighted_roc`. |
| `fig5_reliability.png` | `plot_country_reliability_composite(country_panels)` | 2x3 composite of per-country reliability (calibration) diagrams vs. the 1:1 diagonal; one panel per producing country (South Africa, India, Zimbabwe, Argentina, Thailand, Mexico). Consumes per-country `reliability_diagram` output. |

## Deterministic reproduction pipeline (one unambiguous step sequence)
The answer deliverables are produced by a single **fully deterministic**
primitive chain — there is no random seed, sampling, or model fitting anywhere,
so every re-run is bit-identical. The harvest-to-ENSO alignment uses exactly one
function, `harvest_window_nino34`; the generic `seasonal_nino34_mean` is NOT used
in this pipeline. The exact ordered step sequence is:

1. **Parse Nino 3.4** — `parse_noaa_nino_text` loads the monthly anomalies; map
   the file's `-99.99` missing-value sentinel to NaN and flatten to
   co-indexed `(value, month, year)` arrays.
2. **Country filter** — `parse_faostat_yield_table` loads each country's yield;
   drop any country with `< 20` finite yield years (`np.isfinite(...).sum() < 20`).
3. **Calendar window** — `lookup_growing_season(country, crop, crop_calendar.csv)`;
   countries with no calendar entry are dropped (no harvest month -> no season).
4. **Concurrent ENSO window** — `harvest_window_nino34(..., harvest_month_end=M,
   harvest_years=years)`: the per-harvest-year seasonal-mean Nino 3.4 over the
   3-month window ENDING in M (months M-2, M-1, M), with the Jan/Feb cross-year
   wrap handled so the value for harvest year Y describes the season ending in Y
   (M=1 -> Nov(Y-1),Dec(Y-1),Jan(Y)). This is the only seasonal-alignment step.
5. **Anomaly + ENSO phase** — `compute_yield_anomaly` (nan-aware Gaussian-detrended
   percent anomalies) and `classify_enso_phase` (+/-0.5 C Nino 3.4 threshold);
   a missing-ENSO year yields phase `None` and is excluded by the joint filter,
   never coerced to Neutral.
6. **Leave-one-out (LOO)** — `leave_one_out_forecasts` with a deterministic
   one-hot ENSO-probability vector per observed phase: each fold recomputes the
   below-normal tercile threshold from training years ONLY (no full-sample
   leakage) and applies it to both the conditional model and the held-out event
   label. Its single joint validity filter (finite yield anomaly AND finite/non-None
   ENSO phase AND finite length-3 prob vector) keeps any NaN out of the
   forecasts/observed pair; folds with `< 2` valid samples return
   `status="insufficient_valid_samples"` and are skipped (no crash).
7. **ROC + area fraction** — `compute_roc_score` per country; degenerate label
   sets (all-positive / all-negative / no valid sample) return `roc_area=None`
   with a `status` flag and are skipped (NOT scored as a misleading 0.5/0.0).
   Per-country mean harvested area = `nanmean` of the matching FAOSTAT area row;
   `compute_harvested_area_weighted_roc` then returns the cumulative harvested-area
   fraction with country ROC above each threshold [0.5, 0.55, 0.6, 0.65, 0.7].

Because every step is deterministic, the reproduced area fractions and mean
country ROC re-run exactly (the stated +/-0.01 / +/-0.005 tolerance in the answer
only covers immaterial floating-point / numpy-version rounding, not any
stochastic variation). The reproduced result VALUES live in
`task_content.json`'s answer, not here. `tools/test_crop_yield_forecast.py` unit-
tests the exact rank-based ROC algorithm (perfect=1, inverted=0, fully-tied=0.5,
a tie-heavy partial case checked by hand, all-positive / all-negative ->
status not a number, and a random cross-check against
`sklearn.metrics.roc_auc_score` when sklearn is available) and the
harvest-window cross-year alignment.

## artifacts/
The three PNGs in `artifacts/` (`fig2_roc_maps.png`, `fig3_roc_harvested_area.png`, `fig5_reliability.png`) are the **reference / gold answer figures** (the format-standard deliverables referenced by the `image` answer items), NOT runtime-output scratch paths. They are committed on purpose and must be kept. Each is produced by its dedicated composite answer-figure tool above, whose default `output_path` equals the committed `artifacts/...` filename, so a re-run reproduces (overwrites) these reference figures in place.

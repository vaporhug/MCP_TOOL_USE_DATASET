"""Crop yield forecasting utilities.

Low-level primitives for ENSO-based preseason crop yield forecast analysis.
Implements yield anomaly computation, ENSO phase classification, conditional
probability estimation, ROC skill evaluation, and reliability diagram
construction. No domain conclusions are embedded — the caller must compose
these building blocks into an analysis pipeline.
"""
import numpy as np
from typing import Optional
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Crop_Yield_Forecast")


@mcp.tool()
def compute_yield_anomaly(yields: list, years: list,
                          filter_std: float = 3.0) -> list:
    """Compute percent yield anomalies relative to a Gaussian-smoothed trend.

    Parameters
    ----------
    yields : list of raw yield values (e.g., hg/ha) per year.
    years : list of corresponding years.
    filter_std : standard deviation (in years) of the low-frequency Gaussian
        kernel used to estimate expected yield.

    Returns
    -------
    anomalies : list of percent yield anomalies (strictly JSON-serializable:
        ``None`` for years that cannot be estimated, never NaN),
        Ya_i = 100 * (Y_i - Ye_i) / Ye_i
    """
    from scipy.ndimage import gaussian_filter1d
    y = np.asarray(yields, dtype=float)
    mask = np.isfinite(y)
    anomalies = np.full(y.shape, np.nan, dtype=float)
    if mask.sum() < 2:
        return [None] * len(y)

    # A plain gaussian_filter1d over an array containing NaNs propagates the
    # NaNs into every neighbouring sample (and, with reflect/constant edge
    # handling, can bias the trend near gaps). Use a normalised-convolution
    # ("nan-aware") Gaussian: smooth the gap-filled signal and the validity
    # mask with the same kernel, then divide. This yields a smooth low-
    # frequency trend that is unaffected by the location of missing values.
    filled = np.where(mask, y, 0.0)
    weights = mask.astype(float)
    smooth_num = gaussian_filter1d(filled, sigma=filter_std, mode="nearest")
    smooth_den = gaussian_filter1d(weights, sigma=filter_std, mode="nearest")
    with np.errstate(divide="ignore", invalid="ignore"):
        expected = np.where(smooth_den > 0, smooth_num / smooth_den, np.nan)

    valid = mask & np.isfinite(expected) & (expected != 0)
    anomalies[valid] = 100.0 * (y[valid] - expected[valid]) / expected[valid]
    return [float(v) if np.isfinite(v) else None for v in anomalies]


@mcp.tool()
def classify_enso_phase(nino34: list, threshold: float = 0.5
                        ) -> list:
    """Classify each year into ENSO phase based on Nino 3.4 SST anomaly.

    Parameters
    ----------
    nino34 : list of seasonal-mean Nino 3.4 anomalies.
    threshold : absolute SST anomaly threshold (default 0.5 C).

    Returns
    -------
    phase : list — 0 = La Nina, 1 = Neutral, 2 = El Nino. A missing
        (NaN / None) Nino 3.4 input is *not* forced to Neutral: the
        corresponding entry is returned as ``None`` so the caller can drop
        years with no usable ENSO observation rather than silently scoring
        them as Neutral. Callers should jointly filter to years that have
        BOTH a finite yield anomaly AND a finite (non-None) ENSO phase.
    """
    arr = np.asarray(nino34, dtype=float)
    out = []
    for v in arr:
        if not np.isfinite(v):
            out.append(None)        # missing ENSO -> no phase (NOT Neutral)
        elif v <= -abs(threshold):
            out.append(0)           # La Nina
        elif v >= abs(threshold):
            out.append(2)           # El Nino
        else:
            out.append(1)           # Neutral
    return out


@mcp.tool()
def conditional_below_normal_prob(anomalies: list,
                                  phase: list,
                                  enso_probs: list,
                                  quantile: float = 1.0 / 3.0
                                  ) -> float:
    """Estimate forecast probability of below-normal yield.

    Computes the linearly-combined probability that yield will fall in the
    below-normal tercile, given ENSO phase probabilities.

    Parameters
    ----------
    anomalies : 1-D array of historical percent yield anomalies.
    phase : 1-D integer array of ENSO phases (0=LN, 1=N, 2=EN).
    enso_probs : length-3 array [P(La Nina), P(Neutral), P(El Nino)]
        summing to 1.
    quantile : fraction defining "below normal" (default bottom tercile).

    Returns
    -------
    prob : float, forecast probability of below-normal yield.
    """
    anomalies = np.asarray(anomalies, dtype=float)
    phase = np.asarray(phase)
    enso_probs = np.asarray(enso_probs, dtype=float)
    valid = np.isfinite(anomalies)
    a = anomalies[valid]
    p = phase[valid]
    thresh = np.percentile(a, quantile * 100)
    prob = 0.0
    for ph_idx in range(3):
        mask = (p == ph_idx)
        if mask.sum() > 0:
            p_below = np.mean(a[mask] <= thresh)
        else:
            p_below = quantile
        prob += enso_probs[ph_idx] * p_below
    return float(prob)


@mcp.tool()
def leave_one_out_forecasts(anomalies: list,
                            phase: list,
                            enso_probs_all: list,
                            quantile: float = 1.0 / 3.0
                            ) -> dict:
    """Generate leave-one-out cross-validated forecasts and observations.

    The below-normal event threshold is recomputed *within each LOO fold* from
    the training years only, and then applied both to the conditional
    forecast model and to the held-out year's event label. This avoids any
    full-sample threshold leaking into the cross-validated forecast/observation
    pair (the held-out year never contributes to the threshold that defines its
    own event label).

    A single joint validity filter is applied consistently across every fold: a
    year is usable iff it has (a) a finite yield anomaly, (b) a finite, non-None
    ENSO phase (0/1/2 — a ``None``/NaN phase from
    :func:`classify_enso_phase` for a missing-ENSO year is excluded, never
    coerced to Neutral), AND (c) a finite length-3 ENSO probability vector.
    Years failing ANY of these three conditions never enter the training pool,
    never receive a forecast, and never contribute an event label, so no NaN can
    leak into the forecasts/observed pair (and hence into the downstream ROC).

    Parameters
    ----------
    anomalies : list of percent yield anomalies.
    phase : list of ENSO phases (ints, 0=LN/1=N/2=EN; ``None``/NaN = missing).
    enso_probs_all : list of length-3 lists (n_years x 3) of ENSO phase
        probabilities for each target year.
    quantile : below-normal threshold fraction.

    Returns
    -------
    dict with JSON-serializable keys:
        ``"forecasts"`` : list of forecast probabilities (``None`` where the
            year is excluded by the joint filter — never NaN).
        ``"observed"`` : list of bools, True if held-out yield was below the
            fold-specific (training-only) below-normal threshold.
    """
    anomalies = np.asarray(anomalies, dtype=float)
    # ``phase`` may contain None (missing ENSO) -> map to NaN so the joint
    # filter below excludes those years instead of silently scoring them.
    phase = np.asarray([np.nan if p is None else p for p in phase], dtype=float)
    enso_probs_all = np.asarray(
        [[np.nan if v is None else v for v in row] for row in enso_probs_all],
        dtype=float)
    n = len(anomalies)
    forecasts = np.full(n, np.nan)
    observed = np.full(n, False)

    # Joint validity filter (single, consistent definition reused every fold):
    # finite yield anomaly AND finite ENSO phase AND finite length-3 prob vector.
    probs_ok = (enso_probs_all.shape[1:] == (3,)
                if enso_probs_all.ndim == 2 else False)
    valid = np.isfinite(anomalies) & np.isfinite(phase)
    if probs_ok:
        valid = valid & np.all(np.isfinite(enso_probs_all), axis=1)
    else:
        valid = valid & False  # malformed prob matrix -> nothing usable

    # Guard: a fold needs at least one *other* valid training year to estimate
    # both the below-normal threshold and the phase-conditional probabilities.
    # With <2 valid samples overall, no leave-one-out fold has any training
    # data, so we return an all-``None`` forecast set and a clear status flag
    # rather than calling ``np.percentile`` on an empty array (which raises).
    n_valid = int(valid.sum())
    if n_valid < 2:
        return {
            "forecasts": [None] * n,
            "observed": [False] * n,
            "n_valid": n_valid,
            "status": "insufficient_valid_samples",
        }

    for i in range(n):
        if not valid[i]:
            continue
        # Leave out year i; the fold sees training (valid) years only.
        mask = valid.copy()
        mask[i] = False
        a_train = anomalies[mask]
        p_train = phase[mask]
        # Per-fold guard: if removing year i leaves no training years (cannot
        # happen once n_valid>=2, but kept defensive against future callers),
        # skip the fold instead of raising on an empty percentile sample.
        if a_train.size == 0:
            continue
        # Training-only below-normal threshold (no leakage of year i).
        thresh = np.percentile(a_train, quantile * 100)

        prob = 0.0
        for ph_idx in range(3):
            ph_mask = (p_train == ph_idx)
            if ph_mask.sum() > 0:
                p_below = np.mean(a_train[ph_mask] <= thresh)
            else:
                p_below = quantile
            prob += enso_probs_all[i, ph_idx] * p_below

        forecasts[i] = prob
        # Event label for the held-out year uses the SAME training-only
        # threshold, so the held-out value is not in the percentile sample.
        observed[i] = bool(anomalies[i] <= thresh)

    return {
        "forecasts": [float(v) if np.isfinite(v) else None for v in forecasts],
        "observed": [bool(v) for v in observed],
        "n_valid": n_valid,
        "status": "ok",
    }


@mcp.tool()
def compute_roc_score(forecasts: list, observed: list,
                      n_thresholds: int = 100
                      ) -> dict:
    """Compute the exact ROC area (Mann-Whitney U) from probabilistic forecasts.

    Parameters
    ----------
    forecasts : list of forecast probabilities.
    observed : list of observed outcomes (bools / 0-1).
    n_thresholds : number of probability thresholds to sweep when reporting the
        TPR/FPR step curve (the reported ``roc_area`` does NOT depend on this —
        it is computed exactly, see below).

    Returns
    -------
    dict with JSON-serializable keys:
        ``"roc_area"`` : area under the ROC curve (0.5 = no skill, 1.0 = perfect),
            or ``None`` when the ROC is undefined (see ``"status"``).
        ``"fpr"`` : list of false positive rates at each threshold (for plotting).
        ``"tpr"`` : list of true positive rates at each threshold (for plotting).
        ``"status"`` : ``"ok"`` for a well-defined ROC, otherwise a flag
            (``"no_valid_samples"``, ``"all_positive"`` or ``"all_negative"``).

    Exact rank-based AUC
    --------------------
    ``roc_area`` is the EXACT area under the ROC curve, computed from the
    Mann-Whitney U statistic rather than a trapezoidal sweep of a coarse
    threshold grid:

        AUC = (sum of average-ranks of the positive class
               - n_pos * (n_pos + 1) / 2) / (n_pos * n_neg)

    where ranks are the average (mid-) ranks of the pooled forecast scores
    (ascending). Using *average* ranks makes tied forecast scores contribute
    exactly 0.5 each to the pairwise comparison, so a fully-tied forecast scores
    0.5 and partial ties are handled correctly — this matches
    ``sklearn.metrics.roc_auc_score`` to floating-point precision and is exact
    (independent of ``n_thresholds``). The TPR/FPR step curve is still returned
    for plotting/diagnostics.

    Degenerate-class handling
    -------------------------
    The ROC area is only defined when the observed labels contain BOTH a
    positive (below-normal event) and a negative case. If every valid sample is
    positive (or every one is negative), or there are no finite forecasts at
    all, the ROC is mathematically undefined; this function returns
    ``roc_area=None`` with an explanatory ``status`` rather than silently
    emitting a misleading ``0.5`` / ``0.0``.
    """
    forecasts = np.asarray(forecasts, dtype=float)
    observed = np.asarray(observed, dtype=bool)
    valid = np.isfinite(forecasts)
    f = forecasts[valid]
    o = observed[valid]

    thresholds = np.linspace(0, 1, n_thresholds)
    tpr = np.zeros(n_thresholds)
    fpr = np.zeros(n_thresholds)

    n_pos = int(o.sum())
    n_neg = int((~o).sum())

    # Guard: ROC undefined without both classes among finite-forecast samples.
    if f.size == 0:
        return {"roc_area": None, "fpr": [float(v) for v in fpr],
                "tpr": [float(v) for v in tpr], "status": "no_valid_samples"}
    if n_pos == 0:
        return {"roc_area": None, "fpr": [float(v) for v in fpr],
                "tpr": [float(v) for v in tpr], "status": "all_negative"}
    if n_neg == 0:
        return {"roc_area": None, "fpr": [float(v) for v in fpr],
                "tpr": [float(v) for v in tpr], "status": "all_positive"}

    # TPR/FPR step curve (reported for plotting only; the AUC below is exact).
    for j, th in enumerate(thresholds):
        pred = f >= th
        tpr[j] = (pred & o).sum() / n_pos
        fpr[j] = (pred & ~o).sum() / n_neg

    # Exact ROC-AUC = Mann-Whitney U statistic with average (mid-) ranks so
    # tied forecast scores contribute exactly 0.5 to each pairwise comparison.
    ranks = _average_ranks(f)
    sum_ranks_pos = float(ranks[o].sum())
    auc = (sum_ranks_pos - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg)

    return {
        "roc_area": float(auc),
        "fpr": [float(v) for v in fpr],
        "tpr": [float(v) for v in tpr],
        "status": "ok",
    }


def _average_ranks(values: np.ndarray) -> np.ndarray:
    """Return 1-based average (mid-) ranks of ``values`` (ascending).

    Tied values all receive the mean of the ranks they would otherwise occupy,
    which is what makes the Mann-Whitney-U AUC count tied forecast scores as
    half-wins (AUC contribution 0.5). Equivalent to
    ``scipy.stats.rankdata(values, method="average")`` but kept dependency-free.
    """
    values = np.asarray(values, dtype=float)
    n = values.size
    order = np.argsort(values, kind="mergesort")
    sorted_vals = values[order]
    ranks_sorted = np.empty(n, dtype=float)
    i = 0
    while i < n:
        j = i
        while j + 1 < n and sorted_vals[j + 1] == sorted_vals[i]:
            j += 1
        # Ranks i..j (0-based) -> average of 1-based ranks (i+1)..(j+1).
        avg = (i + j) / 2.0 + 1.0
        ranks_sorted[i:j + 1] = avg
        i = j + 1
    ranks = np.empty(n, dtype=float)
    ranks[order] = ranks_sorted
    return ranks


@mcp.tool()
def reliability_diagram(forecasts: list, observed: list,
                        n_bins: int = 10
                        ) -> dict:
    """Compute reliability diagram bins.

    Parameters
    ----------
    forecasts : list of forecast probabilities.
    observed : list of observed outcomes (bools / 0-1).
    n_bins : number of equally-spaced probability bins.

    Binning is left-closed / right-open for every bin EXCEPT the final bin,
    whose right edge is closed so a forecast probability of exactly 1.0 lands in
    the top bin rather than being silently dropped. Equivalently, forecasts are
    clipped into ``[0, 1]`` and ``np.digitize`` is used with the last bin
    right-inclusive.

    Returns
    -------
    dict with JSON-serializable keys:
        ``"bin_centers"`` : list of bin center probabilities.
        ``"obs_freq"`` : list of observed frequency per bin (``None`` if empty,
            never NaN — strictly JSON-clean).
        ``"counts"`` : list of sample counts per bin.
    """
    forecasts = np.asarray(forecasts, dtype=float)
    observed = np.asarray(observed, dtype=bool)
    valid = np.isfinite(forecasts)
    f = forecasts[valid]
    o = observed[valid].astype(float)

    edges = np.linspace(0, 1, n_bins + 1)
    bin_centers = 0.5 * (edges[:-1] + edges[1:])
    obs_freq = np.full(n_bins, np.nan)
    counts = np.zeros(n_bins, dtype=int)

    for i in range(n_bins):
        if i == n_bins - 1:
            # Final bin: right-closed so forecast == 1.0 is included.
            mask = (f >= edges[i]) & (f <= edges[i + 1])
        else:
            mask = (f >= edges[i]) & (f < edges[i + 1])
        counts[i] = mask.sum()
        if counts[i] > 0:
            obs_freq[i] = o[mask].mean()

    return {
        "bin_centers": [float(v) for v in bin_centers],
        "obs_freq": [float(v) if np.isfinite(v) else None for v in obs_freq],
        "counts": [int(v) for v in counts],
    }


@mcp.tool()
def seasonal_nino34_mean(monthly_nino34: list,
                         months: list,
                         years: list,
                         season: str) -> dict:
    """Generic NOAA-CPC fixed-season-code Nino 3.4 mean (NOT the pipeline aligner).

    This is a generic helper that averages monthly Nino 3.4 over one of the
    twelve NOAA-CPC three-letter overlapping seasons (DJF, JFM, ..., NDJ) for
    every available year. It is a convenience utility for ad-hoc seasonal
    look-ups and is **not** the harvest-alignment step of this task's pipeline.

    For the crop-yield pipeline, the concurrent growing-season ENSO window is
    selected per country/crop from its ``harvest_month_end`` by
    :func:`harvest_window_nino34`, which is the single authoritative
    harvest-alignment used in the instruction, the README reproduction pipeline,
    and the leave-one-out forecast chain. Prefer that function; do not re-derive
    the harvest season by passing a hand-picked ``season`` code here, as the two
    routines must not give conflicting alignments.

    Parameters
    ----------
    monthly_nino34 : list of monthly Nino 3.4 anomalies.
    months : list of month numbers (1-12).
    years : list of year for each month.
    season : 3-letter season code, e.g. 'DJF', 'OND', 'MAM'.

    Returns
    -------
    dict with JSON-serializable keys:
        ``"season_years"`` : list of years.
        ``"season_means"`` : list of seasonal-mean Nino 3.4.
    """
    monthly_nino34 = np.asarray(monthly_nino34, dtype=float)
    months = np.asarray(months)
    years = np.asarray(years)
    # Each entry encodes the absolute (month, year_offset) pairs.
    # Convention follows NOAA CPC: DJF Y = Dec(Y-1) + Jan(Y) + Feb(Y);
    # NDJ Y = Nov(Y) + Dec(Y) + Jan(Y+1).
    month_map = {
        'DJF': [(12, -1), (1, 0), (2, 0)],
        'JFM': [(1, 0), (2, 0), (3, 0)],
        'FMA': [(2, 0), (3, 0), (4, 0)],
        'MAM': [(3, 0), (4, 0), (5, 0)],
        'AMJ': [(4, 0), (5, 0), (6, 0)],
        'MJJ': [(5, 0), (6, 0), (7, 0)],
        'JJA': [(6, 0), (7, 0), (8, 0)],
        'JAS': [(7, 0), (8, 0), (9, 0)],
        'ASO': [(8, 0), (9, 0), (10, 0)],
        'SON': [(9, 0), (10, 0), (11, 0)],
        'OND': [(10, 0), (11, 0), (12, 0)],
        'NDJ': [(11, 0), (12, 0), (1, 1)],
    }
    target = month_map[season]
    unique_years = np.unique(years)
    out_years = []
    out_means = []

    for yr in unique_years:
        vals = []
        for m, year_off in target:
            adj_yr = yr + year_off
            mask = (years == adj_yr) & (months == m)
            if mask.any():
                vals.append(monthly_nino34[mask][0])
        if len(vals) == 3:
            out_years.append(int(yr))
            out_means.append(float(np.mean(vals)))

    return {"season_years": out_years, "season_means": out_means}


@mcp.tool()
def harvest_window_nino34(monthly_nino34: list,
                          months: list,
                          years: list,
                          harvest_month_end: int,
                          harvest_years: list) -> dict:
    """Align a country's harvest month to its concurrent 3-month Nino 3.4 window.

    For a crop whose harvest ends in calendar month ``harvest_month_end`` (M),
    the concurrent growing-season ENSO signal is the mean Nino 3.4 over the
    3-month window ending in M, i.e. months ``[M-2, M-1, M]``. This window can
    wrap the calendar-year boundary, so the *harvest-year* alignment matters:

    * ``M >= 3`` (e.g. harvest ends in May -> MAM): all three months fall in
      the harvest year Y itself, window = ``Mar(Y), Apr(Y), May(Y)``.
    * ``M == 2`` (harvest ends Feb -> DJF): window = ``Dec(Y-1), Jan(Y), Feb(Y)``
      — December belongs to the *previous* calendar year.
    * ``M == 1`` (harvest ends Jan -> NDJ): window = ``Nov(Y-1), Dec(Y-1), Jan(Y)``
      — both November and December belong to the previous calendar year.

    The window is always anchored so that month ``M`` lands in the harvest year
    ``Y``; the two preceding months are shifted to ``Y-1`` whenever ``M-2`` or
    ``M-1`` drops below 1. This guarantees the returned value for harvest year
    ``Y`` describes the season *ending* in ``Y``'s harvest, with no off-by-one
    or double-counting across the Jan/Feb/Dec boundary cases.

    Parameters
    ----------
    monthly_nino34 : list of monthly Nino 3.4 anomalies (chronological,
        co-indexed with ``months`` and ``years``).
    months : list of month numbers (1-12) for each monthly value.
    years : list of calendar years for each monthly value.
    harvest_month_end : the harvest month M (1-12) from the crop calendar's
        ``harvest_month_end`` column.
    harvest_years : list of harvest years Y for which to return the aligned
        seasonal-mean Nino 3.4.

    Returns
    -------
    dict with JSON-serializable keys:
        ``"harvest_years"`` : echoed list of harvest years.
        ``"nino34"`` : list of seasonal-mean Nino 3.4 values, one per harvest
            year (``None`` where any of the three constituent months is
            missing from the monthly record — never NaN, so the result stays
            strictly JSON-clean).
        ``"window_months"`` : list of ``[(month, year_offset)]`` triples
            describing the resolved window (year_offset 0 = harvest year Y,
            -1 = previous calendar year).
    """
    vals = np.asarray(monthly_nino34, dtype=float)
    mo = np.asarray(months)
    yr = np.asarray(years)
    M = int(harvest_month_end)

    # Build the (month, year_offset) window: months M-2, M-1, M, with any
    # month <= 0 wrapped to the previous calendar year (offset -1).
    window = []
    for k in (2, 1, 0):
        mm = M - k
        off = 0
        if mm < 1:
            mm += 12
            off = -1
        window.append((int(mm), off))

    # Fast lookup keyed by (year, month).
    lut = {}
    for v, mm, y in zip(vals, mo, yr):
        lut[(int(y), int(mm))] = float(v)

    out = []
    for Y in harvest_years:
        Y = int(Y)
        triple = []
        ok = True
        for mm, off in window:
            key = (Y + off, mm)
            if key in lut and np.isfinite(lut[key]):
                triple.append(lut[key])
            else:
                ok = False
                break
        out.append(float(np.mean(triple)) if ok and len(triple) == 3 else None)

    return {
        "harvest_years": [int(y) for y in harvest_years],
        "nino34": out,
        "window_months": [[int(mm), int(off)] for mm, off in window],
    }


@mcp.tool()
def quality_screen_yields(yields: list, years: list,
                          min_diff_threshold: float = 50.0,
                          max_consecutive: int = 4
                          ) -> dict:
    """Screen FAO yield data for quality issues.

    Flags and removes values where consecutive second-differences are
    unrealistically low (indicating trend-filled data).

    Parameters
    ----------
    yields : list of yield values.
    years : list of corresponding years.
    min_diff_threshold : minimum absolute second-difference (kg/ha).
    max_consecutive : maximum consecutive low second-differences allowed.

    Returns
    -------
    dict with JSON-serializable keys:
        ``"clean_yields"`` : list of yields with flagged values set to NaN.
        ``"flags"`` : list of bools, True = flagged/removed.
    """
    yields = np.asarray(yields, dtype=float)
    clean = yields.copy().astype(float)
    flags = np.zeros(len(yields), dtype=bool)

    if len(yields) < 3:
        return {"clean_yields": [float(v) if np.isfinite(v) else None for v in clean],
                "flags": [bool(v) for v in flags]}

    # Compute second differences
    d2 = np.diff(yields.astype(float), n=2)
    low_d2 = np.abs(d2) < min_diff_threshold

    # Find runs of consecutive low second-differences
    count = 0
    for i in range(len(low_d2)):
        if low_d2[i]:
            count += 1
            if count >= max_consecutive:
                # Flag the range
                start = i - count + 1
                end = i + 3  # account for diff offset
                flags[start:min(end, len(flags))] = True
        else:
            count = 0

    clean[flags] = np.nan
    return {"clean_yields": [float(v) if np.isfinite(v) else None for v in clean],
            "flags": [bool(v) for v in flags]}


@mcp.tool()
def aggregate_country_groups(country_yields: dict,
                             country_areas: dict,
                             groupings: dict) -> dict:
    """Aggregate yields for country groups (e.g., Former USSR).

    Recomputes aggregate yield = total production / total harvested area.

    Parameters
    ----------
    country_yields : dict mapping country name -> 1-D yield array.
    country_areas : dict mapping country name -> 1-D harvested area array.
    groupings : dict mapping group name -> list of member country names.

    Returns
    -------
    group_yields : dict mapping group name -> list of aggregated yields
        (JSON-serializable).
    """
    group_yields = {}
    for group, members in groupings.items():
        total_prod = None
        total_area = None
        for m in members:
            if m in country_yields and m in country_areas:
                yld = np.asarray(country_yields[m], dtype=float)
                area = np.asarray(country_areas[m], dtype=float)
                prod = yld * area
                if total_prod is None:
                    total_prod = prod.copy()
                    total_area = area.copy()
                else:
                    total_prod += prod
                    total_area += area
        if total_prod is not None:
            with np.errstate(divide='ignore', invalid='ignore'):
                agg = np.where(total_area > 0, total_prod / total_area, np.nan)
            group_yields[group] = [float(v) if np.isfinite(v) else None for v in agg]
    return group_yields


# ---------------------------------------------------------------------------
# Country-name normalisation
# ---------------------------------------------------------------------------

# FAOSTAT 'Area' name -> ISO-3166 alpha-3 code. ISO-3 matches the Natural
# Earth ``ADM0_A3`` attribute used by :func:`plot_roc_world_map`, so colouring
# is robust to FAOSTAT's idiosyncratic long-form names (e.g. "Bolivia
# (Plurinational State of)", "Côte d'Ivoire", "United States of America").
# Covers every country in the bundled crop calendar plus common FAOSTAT
# aliases. Names not present here fall through to direct Natural Earth NAME
# matching.
_FAOSTAT_TO_ISO3 = {
    "Afghanistan": "AFG", "Albania": "ALB", "Algeria": "DZA", "Angola": "AGO",
    "Argentina": "ARG", "Armenia": "ARM", "Australia": "AUS", "Austria": "AUT",
    "Azerbaijan": "AZE", "Bangladesh": "BGD", "Belarus": "BLR",
    "Belgium": "BEL", "Benin": "BEN", "Bhutan": "BTN",
    "Bolivia (Plurinational State of)": "BOL", "Bolivia": "BOL",
    "Bosnia and Herzegovina": "BIH", "Botswana": "BWA", "Brazil": "BRA",
    "Bulgaria": "BGR", "Burkina Faso": "BFA", "Burundi": "BDI",
    "Cabo Verde": "CPV", "Cambodia": "KHM", "Cameroon": "CMR", "Canada": "CAN",
    "Central African Republic": "CAF", "Chad": "TCD", "Chile": "CHL",
    "China": "CHN", "China, mainland": "CHN", "Colombia": "COL",
    "Comoros": "COM", "Congo": "COG", "Costa Rica": "CRI", "Croatia": "HRV",
    "Cuba": "CUB", "Cyprus": "CYP", "Czechia": "CZE",
    "Côte d'Ivoire": "CIV", "Cote d'Ivoire": "CIV",
    "Democratic People's Republic of Korea": "PRK",
    "Democratic Republic of the Congo": "COD", "Denmark": "DNK",
    "Dominican Republic": "DOM", "Ecuador": "ECU", "Egypt": "EGY",
    "El Salvador": "SLV", "Eritrea": "ERI", "Estonia": "EST",
    "Eswatini": "SWZ", "Ethiopia": "ETH", "Fiji": "FJI", "Finland": "FIN",
    "France": "FRA", "French Guiana": "GUF", "Gabon": "GAB", "Gambia": "GMB",
    "Georgia": "GEO", "Germany": "DEU", "Ghana": "GHA", "Greece": "GRC",
    "Guatemala": "GTM", "Guinea": "GIN", "Guinea-Bissau": "GNB",
    "Guyana": "GUY", "Haiti": "HTI", "Honduras": "HND", "Hungary": "HUN",
    "India": "IND", "Indonesia": "IDN", "Iran (Islamic Republic of)": "IRN",
    "Iran": "IRN", "Iraq": "IRQ", "Ireland": "IRL", "Israel": "ISR",
    "Italy": "ITA", "Japan": "JPN", "Jordan": "JOR", "Kazakhstan": "KAZ",
    "Kenya": "KEN", "Kyrgyzstan": "KGZ", "Latvia": "LVA", "Lebanon": "LBN",
    "Lesotho": "LSO", "Liberia": "LBR", "Libya": "LBY", "Lithuania": "LTU",
    "Madagascar": "MDG", "Malawi": "MWI", "Malaysia": "MYS", "Mali": "MLI",
    "Mauritania": "MRT", "Mexico": "MEX", "Morocco": "MAR",
    "Mozambique": "MOZ", "Myanmar": "MMR", "Namibia": "NAM", "Nepal": "NPL",
    "Netherlands": "NLD", "Nicaragua": "NIC", "Niger": "NER", "Nigeria": "NGA",
    "North Macedonia": "MKD", "Norway": "NOR", "Pakistan": "PAK",
    "Panama": "PAN", "Papua New Guinea": "PNG", "Paraguay": "PRY",
    "Peru": "PER", "Philippines": "PHL", "Poland": "POL", "Portugal": "PRT",
    "Republic of Korea": "KOR", "Republic of Moldova": "MDA",
    "Romania": "ROU", "Russian Federation": "RUS", "Rwanda": "RWA",
    "Saudi Arabia": "SAU", "Senegal": "SEN", "Serbia": "SRB",
    "Sierra Leone": "SLE", "Slovakia": "SVK", "Slovenia": "SVN",
    "Somalia": "SOM", "South Africa": "ZAF", "South Sudan": "SSD",
    "Spain": "ESP", "Sri Lanka": "LKA", "Sudan": "SDN", "Suriname": "SUR",
    "Sweden": "SWE", "Switzerland": "CHE", "Syrian Arab Republic": "SYR",
    "Tajikistan": "TJK", "Thailand": "THA", "Timor-Leste": "TLS",
    "Togo": "TGO", "Trinidad and Tobago": "TTO", "Tunisia": "TUN",
    "Turkmenistan": "TKM", "Türkiye": "TUR", "Turkey": "TUR",
    "Uganda": "UGA", "Ukraine": "UKR",
    "United Kingdom of Great Britain and Northern Ireland": "GBR",
    "United Kingdom": "GBR", "United Republic of Tanzania": "TZA",
    "United States of America": "USA", "United States": "USA",
    "Uruguay": "URY", "Uzbekistan": "UZB",
    "Venezuela (Bolivarian Republic of)": "VEN", "Venezuela": "VEN",
    "Viet Nam": "VNM", "Vietnam": "VNM", "Yemen": "YEM", "Zambia": "ZMB",
    "Zimbabwe": "ZWE",
}


@mcp.tool()
def faostat_country_to_iso3(country_names: list) -> dict:
    """Map FAOSTAT 'Area' names to ISO-3166 alpha-3 codes.

    ISO-3 codes match the Natural Earth ``ADM0_A3`` attribute, so resolving
    FAOSTAT names to ISO-3 lets a world-map plot colour the correct polygons
    even when FAOSTAT uses long-form names (e.g. "Bolivia (Plurinational State
    of)"). Matching is exact first, then case-insensitive.

    Parameters
    ----------
    country_names : list of FAOSTAT country names.

    Returns
    -------
    dict with JSON-serializable keys:
        ``"iso3"`` : dict mapping each input name -> ISO-3 code (or ``None`` if
            unknown).
        ``"unmatched"`` : list of input names with no ISO-3 mapping.
    """
    lower_lut = {k.lower(): v for k, v in _FAOSTAT_TO_ISO3.items()}
    iso3 = {}
    unmatched = []
    for name in country_names:
        code = _FAOSTAT_TO_ISO3.get(name)
        if code is None:
            code = lower_lut.get((name or "").strip().lower())
        iso3[name] = code
        if code is None:
            unmatched.append(name)
    return {"iso3": iso3, "unmatched": unmatched}


# ---------------------------------------------------------------------------
# Plotting tools
# ---------------------------------------------------------------------------

@mcp.tool()
def plot_roc_world_map(country_roc_scores: dict,
                       output_path: str = "artifacts/roc_world_map.png"
                       ) -> dict:
    """Plot a world map with countries colored by ROC score.

    Uses cartopy for map projection if available; falls back to a simplified
    scatter-based layout when cartopy is not installed.

    Args:
        country_roc_scores: dict mapping ISO-3 country code OR FAOSTAT country
            name to ROC area score (float, typically 0.3-1.0). FAOSTAT names are
            internally resolved to ISO-3 (see :func:`faostat_country_to_iso3`)
            so polygons colour correctly regardless of which key form is used.
        output_path: path for the saved figure.

    Returns:
        dict with key ``"output_path"`` pointing to the saved file.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import matplotlib.colors as mcolors

    norm = mcolors.TwoSlopeNorm(vmin=0.0, vcenter=0.5, vmax=1.0)
    cmap = plt.cm.RdBu

    # Normalise the input keys to ISO-3 so Natural Earth polygons match even
    # when the caller passes FAOSTAT long-form names. Existing ISO-3 keys are
    # preserved; FAOSTAT names are translated where a mapping exists.
    scores_by_iso = {}
    for key, score in country_roc_scores.items():
        iso = _FAOSTAT_TO_ISO3.get(key)
        if iso is None and isinstance(key, str):
            iso = _FAOSTAT_TO_ISO3.get(key.strip())
        if iso is not None:
            scores_by_iso[iso] = score
        # Always keep the original key too (covers raw ISO-3 inputs).
        scores_by_iso.setdefault(key, score)

    try:
        import cartopy.crs as ccrs
        import cartopy.io.shapereader as shpreader

        fig, ax = plt.subplots(1, 1, figsize=(12, 6),
                               subplot_kw={"projection": ccrs.PlateCarree()})
        ax.set_global()
        ax.coastlines(linewidth=0.5)

        shpfilename = shpreader.natural_earth(resolution="110m",
                                              category="cultural",
                                              name="admin_0_countries")
        reader = shpreader.Reader(shpfilename)
        for record in reader.records():
            name = record.attributes.get("NAME", "")
            iso = record.attributes.get("ADM0_A3", "")
            score = scores_by_iso.get(iso,
                        scores_by_iso.get(name, None))
            if score is not None:
                ax.add_geometries(
                    [record.geometry], ccrs.PlateCarree(),
                    facecolor=cmap(norm(score)), edgecolor="black",
                    linewidth=0.3)
            else:
                ax.add_geometries(
                    [record.geometry], ccrs.PlateCarree(),
                    facecolor="lightgrey", edgecolor="black",
                    linewidth=0.3)

        sm = plt.cm.ScalarMappable(cmap=cmap, norm=norm)
        sm.set_array([])
        cbar = fig.colorbar(sm, ax=ax, orientation="horizontal",
                            fraction=0.046, pad=0.06)
        cbar.set_label("ROC area")
        ax.set_title("ROC score by country")

    except ImportError:
        # Fallback: scatter plot using approximate lon/lat centroids
        _centroids = {
            "USA": (-98, 39), "BRA": (-53, -10), "CHN": (104, 35),
            "IND": (78, 22), "ARG": (-64, -34), "AUS": (134, -25),
            "RUS": (100, 60), "FRA": (2, 46), "DEU": (10, 51),
            "ZAF": (25, -29), "NGA": (8, 10), "MEX": (-102, 23),
        }
        fig, ax = plt.subplots(figsize=(12, 6))
        for country, score in scores_by_iso.items():
            lon, lat = _centroids.get(country, (0, 0))
            ax.scatter(lon, lat, c=[score], cmap=cmap, norm=norm,
                       s=120, edgecolors="black", linewidth=0.5, zorder=3)
            ax.annotate(country, (lon, lat), fontsize=7,
                        ha="center", va="bottom")
        ax.set_xlim(-180, 180)
        ax.set_ylim(-60, 85)
        ax.set_xlabel("Longitude")
        ax.set_ylabel("Latitude")
        ax.set_title("ROC score by country (simplified)")
        sm = plt.cm.ScalarMappable(cmap=cmap, norm=norm)
        sm.set_array([])
        fig.colorbar(sm, ax=ax, orientation="horizontal",
                     fraction=0.046, pad=0.1, label="ROC area")

    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"output_path": output_path}


@mcp.tool()
def plot_roc_vs_lead_time(lead_times: list,
                          area_fractions: dict,
                          output_path: str = "artifacts/roc_vs_lead.png"
                          ) -> dict:
    """Plot stacked area chart of harvested-area fractions exceeding ROC thresholds.

    Args:
        lead_times: list of lead-time values (x-axis), e.g. [1, 2, 3, 4].
        area_fractions: dict mapping ROC threshold string (e.g. ``"0.55"``,
            ``"0.60"``, ``"0.65"``) to a list of fractions (one per lead time).
            Each fraction is the *cumulative* proportion of total harvested
            area for which the ROC score exceeds the given threshold (as
            returned by :func:`compute_harvested_area_weighted_roc`). Because
            these fractions are nested (``area[ROC>0.6] <= area[ROC>0.55]``),
            they are plotted as overlaid cumulative bands rather than summed —
            stacking them would double-count the shared area.
        output_path: path for the saved figure.

    Returns:
        dict with key ``"output_path"`` pointing to the saved file.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(8, 5))

    # Thresholds are nested: the area with ROC > 0.65 is a subset of the area
    # with ROC > 0.60, etc. Render them as overlaid (highest threshold drawn
    # last / on top, darkest) cumulative bands measured from zero. This keeps
    # the y-axis a true "fraction of harvested area" and avoids the previous
    # bug where the bands were summed, inflating the total past 1.0.
    sorted_desc = sorted(area_fractions.keys(), key=lambda k: float(k))
    colors = plt.cm.viridis(np.linspace(0.2, 0.9, len(sorted_desc)))

    max_frac = 0.0
    # Draw from lowest threshold (largest area, lightest, bottom layer) to
    # highest (smallest area, darkest, top layer) so smaller bands stay visible.
    for idx, thr in enumerate(sorted_desc):
        values = np.array(area_fractions[thr], dtype=float)
        max_frac = max(max_frac, float(np.nanmax(values)) if values.size else 0.0)
        ax.fill_between(lead_times, 0.0, values,
                        color=colors[idx], alpha=0.85,
                        label=f"ROC > {thr}", zorder=idx + 1)

    ax.set_xlabel("Lead time (months before harvest)")
    ax.set_ylabel("Fraction of harvested area (cumulative, ROC > threshold)")
    ax.set_title("Harvested area exceeding ROC thresholds vs. lead time")
    # Higher thresholds = smaller area, so reverse legend to read top-down.
    handles, labels = ax.get_legend_handles_labels()
    ax.legend(handles[::-1], labels[::-1], loc="upper right", fontsize=9)
    ax.set_xlim(min(lead_times), max(lead_times))
    ax.set_ylim(0, min(1.05, max_frac * 1.15) if max_frac > 0 else 1)

    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"output_path": output_path}


@mcp.tool()
def plot_reliability_diagram(bin_centers: list,
                             observed_freq: list,
                             counts: list,
                             title: str = "",
                             output_path: str = "artifacts/reliability.png"
                             ) -> dict:
    """Plot a reliability (calibration) diagram with a histogram of counts.

    The main panel shows predicted probability vs. observed relative frequency
    together with the perfect-calibration diagonal. A bottom sub-panel shows
    the histogram of forecast counts per probability bin.

    Args:
        bin_centers: list of bin-center probabilities (x-axis).
        observed_freq: list of observed relative frequencies per bin.
        counts: list of forecast counts per bin.
        title: optional figure title.
        output_path: path for the saved figure.

    Returns:
        dict with key ``"output_path"`` pointing to the saved file.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    bin_centers = np.asarray(bin_centers, dtype=float)
    observed_freq = np.asarray(observed_freq, dtype=float)
    counts = np.asarray(counts, dtype=float)

    fig, (ax_cal, ax_hist) = plt.subplots(
        2, 1, figsize=(5, 6), gridspec_kw={"height_ratios": [3, 1]},
        sharex=True)

    # Calibration curve
    valid = np.isfinite(observed_freq)
    ax_cal.plot([0, 1], [0, 1], "k--", linewidth=0.8, label="Perfect")
    ax_cal.plot(bin_centers[valid], observed_freq[valid], "o-",
                color="steelblue", markersize=5, label="Forecast")
    ax_cal.set_ylabel("Observed frequency")
    ax_cal.set_ylim(0, 1)
    ax_cal.legend(loc="upper left", fontsize=9)
    if title:
        ax_cal.set_title(title)
    else:
        ax_cal.set_title("Reliability diagram")

    # Histogram of counts
    width = np.diff(bin_centers).mean() if len(bin_centers) > 1 else 0.1
    ax_hist.bar(bin_centers, counts, width=width * 0.9, color="grey",
                edgecolor="black", linewidth=0.5)
    ax_hist.set_xlabel("Forecast probability")
    ax_hist.set_ylabel("Count")
    ax_hist.set_xlim(0, 1)

    fig.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"output_path": output_path}


@mcp.tool()
def compute_harvested_area_weighted_roc(country_roc_scores: dict,
                                        country_areas: dict,
                                        thresholds: list) -> dict:
    """Compute fraction of harvested area where ROC exceeds each threshold.

    The denominator is **strictly the calendar-covered countries only** — i.e.
    the countries that actually carry a finite ROC score (the ones with a crop
    calendar entry that made it through the seasonal-ENSO alignment and ROC
    computation). Countries that have harvested area but no ROC score (no
    calendar entry, dropped) are NOT added to the denominator: they are outside
    the analysed universe, so including them would silently deflate every area
    fraction. Concretely, for each threshold the numerator sums harvested area
    across calendar-covered countries whose ROC is strictly greater than the
    threshold, and the denominator is the total harvested area across all
    calendar-covered countries (those with a finite ROC and a finite area).

    Parameters
    ----------
    country_roc_scores : dict mapping country name -> ROC area score (float).
        Only countries appearing here with a finite score define the
        calendar-covered universe.
    country_areas : dict mapping country name -> harvested area (float, ha).
        May be a scalar (most-recent or mean area) or a 1-D array — when a
        sequence is supplied the mean of finite values is used. Entries for
        countries without a ROC score are ignored entirely.
    thresholds : list of ROC threshold values, e.g.
        ``[0.5, 0.55, 0.6, 0.65, 0.7]``.

    Returns
    -------
    dict with keys:
        ``"thresholds"`` : list of thresholds (echoed for convenience).
        ``"area_fractions"`` : list of fractions in ``[0, 1]``, one per
            threshold, ``sum(area where ROC > thr) / sum(calendar-covered area)``.
        ``"area_above"`` : list of absolute harvested-area sums (ha) above
            each threshold.
        ``"total_area"`` : total calendar-covered harvested area (ha) used as
            the denominator.
    """
    def _scalar_area(v):
        arr = np.atleast_1d(np.asarray(v, dtype=float))
        finite = arr[np.isfinite(arr)]
        if finite.size == 0:
            return np.nan
        return float(np.mean(finite))

    # Calendar-covered universe = countries with a finite ROC score AND a
    # finite harvested area. The denominator is restricted to exactly this set.
    areas = {}
    for c, roc in country_roc_scores.items():
        if roc is None or not np.isfinite(roc):
            continue
        if c not in country_areas:
            continue
        a = _scalar_area(country_areas[c])
        if np.isfinite(a):
            areas[c] = a

    total_area = sum(areas.values())
    if total_area <= 0:
        return {
            "thresholds": list(thresholds),
            "area_fractions": [0.0] * len(thresholds),
            "area_above": [0.0] * len(thresholds),
            "total_area": 0.0,
        }

    fractions = []
    above = []
    for thr in thresholds:
        s = 0.0
        for c, a in areas.items():
            if not np.isfinite(a):
                continue
            roc = country_roc_scores.get(c, np.nan)
            if roc is None or not np.isfinite(roc):
                continue
            if roc > thr:
                s += a
        above.append(float(s))
        fractions.append(float(s / total_area))
    return {
        "thresholds": list(thresholds),
        "area_fractions": fractions,
        "area_above": above,
        "total_area": float(total_area),
    }


# ---------------------------------------------------------------------------
# Composite answer-figure tools
#
# The three plotting helpers above (``plot_roc_world_map``,
# ``plot_roc_vs_lead_time``, ``plot_reliability_diagram``) draw a *single*
# panel each. The task's three answer figures are multi-panel composites
# (maize+wheat two-panel map; two-crop bar chart; six-country composite
# reliability). The three tools below each emit one of those exact answer
# figures at its documented ``artifacts/...`` default path so a re-run
# reproduces the committed reference PNG in place.
# ---------------------------------------------------------------------------

@mcp.tool()
def plot_roc_maps_two_panel(maize_roc: dict,
                            wheat_roc: dict,
                            output_path: str = "artifacts/fig2_roc_maps.png"
                            ) -> dict:
    """Render the two-panel (maize over wheat) ROC world map answer figure.

    Produces ``fig2_roc_maps.png``: a stacked two-panel world map where the
    top panel colours each country by its maize concurrent-ENSO LOO ROC area
    and the bottom panel does the same for wheat. Countries are shaded on a
    diverging RdBu scale centred at 0.5 (red < 0.5 < blue), and countries with
    no ROC score (no calendar entry / dropped) are drawn light grey. Uses
    cartopy for the Natural-Earth polygons when available and falls back to an
    approximate centroid scatter otherwise.

    Args:
        maize_roc: dict mapping FAOSTAT country name OR ISO-3 code -> maize ROC
            area (float). FAOSTAT names are resolved to ISO-3 internally.
        wheat_roc: same, for wheat.
        output_path: path for the saved figure (defaults to the committed
            answer-figure path ``artifacts/fig2_roc_maps.png``).

    Returns:
        dict with key ``"output_path"`` pointing to the saved file.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import matplotlib.colors as mcolors

    norm = mcolors.TwoSlopeNorm(vmin=0.3, vcenter=0.5, vmax=0.7)
    cmap = plt.cm.RdBu

    def _to_iso(scores):
        out = {}
        for key, score in scores.items():
            if score is None or not np.isfinite(score):
                continue
            iso = _FAOSTAT_TO_ISO3.get(key)
            if iso is None and isinstance(key, str):
                iso = _FAOSTAT_TO_ISO3.get(key.strip())
            if iso is not None:
                out[iso] = score
            out.setdefault(key, score)
        return out

    panels = [("Maize", maize_roc), ("Wheat", wheat_roc)]

    try:
        import cartopy.crs as ccrs
        import cartopy.io.shapereader as shpreader

        fig, axes = plt.subplots(
            2, 1, figsize=(11, 9),
            subplot_kw={"projection": ccrs.PlateCarree()})
        shpfilename = shpreader.natural_earth(resolution="110m",
                                              category="cultural",
                                              name="admin_0_countries")
        for ax, (title, scores) in zip(np.atleast_1d(axes), panels):
            iso_scores = _to_iso(scores)
            ax.set_global()
            ax.coastlines(linewidth=0.4)
            for record in shpreader.Reader(shpfilename).records():
                name = record.attributes.get("NAME", "")
                iso = record.attributes.get("ADM0_A3", "")
                score = iso_scores.get(iso, iso_scores.get(name, None))
                fc = cmap(norm(score)) if score is not None else "lightgrey"
                ax.add_geometries([record.geometry], ccrs.PlateCarree(),
                                  facecolor=fc, edgecolor="black",
                                  linewidth=0.2)
            ax.set_title(f"{title}: country-level concurrent-ENSO LOO ROC")
        sm = plt.cm.ScalarMappable(cmap=cmap, norm=norm)
        sm.set_array([])
        fig.colorbar(sm, ax=list(np.atleast_1d(axes)),
                     orientation="horizontal", fraction=0.04, pad=0.03,
                     label="ROC area")

    except ImportError:
        _centroids = {
            "USA": (-98, 39), "BRA": (-53, -10), "CHN": (104, 35),
            "IND": (78, 22), "ARG": (-64, -34), "AUS": (134, -25),
            "RUS": (100, 60), "FRA": (2, 46), "DEU": (10, 51),
            "ZAF": (25, -29), "NGA": (8, 10), "MEX": (-102, 23),
        }
        fig, axes = plt.subplots(2, 1, figsize=(11, 9))
        for ax, (title, scores) in zip(np.atleast_1d(axes), panels):
            iso_scores = _to_iso(scores)
            for country, score in iso_scores.items():
                lon, lat = _centroids.get(country, (0, 0))
                ax.scatter(lon, lat, c=[score], cmap=cmap, norm=norm,
                           s=120, edgecolors="black", linewidth=0.5, zorder=3)
            ax.set_xlim(-180, 180)
            ax.set_ylim(-60, 85)
            ax.set_title(f"{title}: country-level concurrent-ENSO LOO ROC")
        sm = plt.cm.ScalarMappable(cmap=cmap, norm=norm)
        sm.set_array([])
        fig.colorbar(sm, ax=list(np.atleast_1d(axes)),
                     orientation="horizontal", fraction=0.04, pad=0.06,
                     label="ROC area")

    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"output_path": output_path}


@mcp.tool()
def plot_roc_threshold_harvested_area(
        maize_area_fractions: dict,
        wheat_area_fractions: dict,
        thresholds: list = None,
        output_path: str = "artifacts/fig3_roc_harvested_area.png"
        ) -> dict:
    """Render the two-crop ROC-threshold harvested-area bar-chart answer figure.

    Produces ``fig3_roc_harvested_area.png``: a side-by-side two-panel bar
    chart (left = maize, right = wheat). For each crop the bars show the
    *percentage* of (calendar-covered) harvested area whose country-level
    concurrent-ENSO LOO ROC exceeds each threshold (0.5, 0.55, 0.6, 0.65, 0.7).
    Because the thresholds are nested, every bar is a true cumulative area
    fraction and the heights decrease monotonically as the threshold rises.

    Args:
        maize_area_fractions: either the dict returned by
            :func:`compute_harvested_area_weighted_roc` for maize (with keys
            ``"thresholds"`` and ``"area_fractions"``) OR a bare list of area
            fractions aligned to ``thresholds``.
        wheat_area_fractions: same, for wheat.
        thresholds: optional explicit threshold list; if omitted it is taken
            from the ``"thresholds"`` key of the supplied dicts, defaulting to
            ``[0.5, 0.55, 0.6, 0.65, 0.7]``.
        output_path: path for the saved figure (defaults to the committed
            answer-figure path ``artifacts/fig3_roc_harvested_area.png``).

    Returns:
        dict with key ``"output_path"`` pointing to the saved file.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    def _unpack(obj):
        if isinstance(obj, dict):
            return list(obj.get("thresholds", [])), list(obj["area_fractions"])
        return None, list(obj)

    m_thr, m_frac = _unpack(maize_area_fractions)
    w_thr, w_frac = _unpack(wheat_area_fractions)
    if thresholds is None:
        thresholds = m_thr or w_thr or [0.5, 0.55, 0.6, 0.65, 0.7]
    thr_labels = [str(t) for t in thresholds]

    fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))
    for ax, crop, frac, col in zip(
            axes, ["Maize", "Wheat"], [m_frac, w_frac],
            ["tab:green", "tab:olive"]):
        ax.bar(thr_labels, [100.0 * x for x in frac],
               color=col, edgecolor="black")
        ax.set_title(crop)
        ax.set_xlabel("ROC threshold")
        ax.set_ylabel("% of harvested area with ROC > threshold")
        ax.set_ylim(0, 80)
    fig.suptitle("Concurrent-ENSO LOO skill: harvested-area fraction "
                 "exceeding ROC thresholds")
    fig.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"output_path": output_path}


@mcp.tool()
def plot_country_reliability_composite(
        country_panels: dict,
        output_path: str = "artifacts/fig5_reliability.png"
        ) -> dict:
    """Render the six-country composite reliability-diagram answer figure.

    Produces ``fig5_reliability.png``: a 2x3 grid of reliability (calibration)
    diagrams, one panel per producing country. Each panel plots binned observed
    below-normal frequency against forecast probability with the 1:1
    perfect-calibration diagonal.

    Args:
        country_panels: dict mapping a panel label (e.g.
            ``"South Africa (maize)"``) to a per-country reliability dict with
            keys ``"bin_centers"`` and ``"obs_freq"`` (as returned by
            :func:`reliability_diagram`). Up to six entries are drawn in a 2x3
            grid in insertion order; ``obs_freq`` entries that are ``None`` /
            non-finite are skipped within a panel.
        output_path: path for the saved figure (defaults to the committed
            answer-figure path ``artifacts/fig5_reliability.png``).

    Returns:
        dict with key ``"output_path"`` pointing to the saved file.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    labels = list(country_panels.keys())
    fig, axes = plt.subplots(2, 3, figsize=(12, 8))
    flat_axes = axes.ravel()
    for ax, label in zip(flat_axes, labels):
        panel = country_panels[label]
        bc = np.asarray(panel.get("bin_centers", []), dtype=float)
        of = np.asarray([np.nan if v is None else v
                         for v in panel.get("obs_freq", [])], dtype=float)
        ax.plot([0, 1], [0, 1], "k--", linewidth=0.8)
        good = np.isfinite(bc) & np.isfinite(of)
        if good.any():
            ax.plot(bc[good], of[good], "o-", color="steelblue")
        ax.set_title(label)
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.set_xlabel("Forecast probability")
        ax.set_ylabel("Observed frequency")
    # Blank any unused panels.
    for ax in flat_axes[len(labels):]:
        ax.axis("off")
    fig.suptitle("Concurrent-ENSO LOO reliability diagrams (bundled data)")
    fig.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"output_path": output_path}


@mcp.tool()
def lookup_growing_season(country: str, crop: str,
                          calendar_path: str) -> dict:
    """Look up planting and harvest months for a country/crop pair.

    Reads the consolidated crop-calendar CSV (see
    ``input_data/data/crop_calendar.csv``) and returns the planting/harvest
    month range for the requested entry. The calendar's ``country`` column uses
    the FAOSTAT ``Area`` naming convention, so country matching is **exact, then
    case-insensitive only** — every calendar country is exact/case-insensitive
    matchable to a FAOSTAT ``Area`` name. A substring fallback is deliberately
    NOT used: it produced spurious cross-country matches (e.g. FAOSTAT "Oman" ->
    calendar "Romania", "Dominica" -> "Dominican Republic", "Papua New Guinea"
    -> "Guinea", aggregate "Africa" -> "South Africa") that silently invented
    calendar entries for countries that have none and inflated the analysed
    country count. Countries with no exact/case-insensitive calendar entry are
    reported ``found=False`` and dropped by the pipeline. Rows whose
    ``qualifier`` is ``Exclude`` are treated as failing quality control and are
    never matched (``found`` will be False if the only candidate row is
    excluded).

    Multi-season selection rule
    ---------------------------
    A few countries can carry more than one calendar row for the same crop
    (different growing seasons). The pipeline analyses exactly ONE concurrent
    growing season per country/crop, so a single, deterministic **main-season**
    rule is applied whenever a matched country/crop resolves to more than one
    (non-``Exclude``) row:

    1. **Prefer the primary/main season over any secondary season.** Rows whose
       ``qualifier`` begins with ``Season2`` (e.g. ``Season2:GIEWS``, the minor
       secondary harvest digitised for a few countries) are demoted; a primary
       row is always chosen ahead of a ``Season2`` row. (A country whose ONLY
       row is a ``Season2`` entry — e.g. Ghana and Nigeria maize, which have no
       primary national row in this calendar — still resolves to that single
       row, so it is never silently dropped.)
    2. Among rows of equal season priority, pick deterministically by the
       smallest ``harvest_month_end``, then by ``qualifier`` string, then by the
       country name as it appears in the file. This guarantees a stable,
       reproducible choice independent of CSV row order.

    The returned ``qualifier`` reflects the row actually selected, and the
    boolean ``"secondary_season"`` flag reports whether the resolved row is a
    ``Season2`` entry (True only when no primary row exists for that
    country/crop).

    Parameters
    ----------
    country : country name (FAOSTAT ``Area`` convention).
    crop : ``"maize"`` or ``"wheat"`` (case-insensitive).
    calendar_path : path to ``crop_calendar.csv``.

    Returns
    -------
    dict with keys:
        ``"country"`` : matched country name as it appears in the file
            (or empty string if no match).
        ``"crop"`` : echoed crop label (lower-case).
        ``"planting_month_start"`` / ``"planting_month_end"`` : ints 1-12
            (or ``None`` if not found / unspecified).
        ``"harvest_month_start"`` / ``"harvest_month_end"`` : ints 1-12
            (or ``None``).
        ``"qualifier"`` : qualifier string of the SELECTED (main-season) row
            (e.g. ``"Winter"``, ``"Manual:USDA"``) or empty.
        ``"secondary_season"`` : bool, ``True`` if the resolved row is a
            ``Season2`` secondary-season entry (only possible when no primary
            row exists for that country/crop).
        ``"found"`` : bool, ``True`` if a matching row was located.
    """
    import csv

    crop_l = (crop or "").strip().lower()

    def _to_int(v):
        if v is None or v == "":
            return None
        try:
            return int(float(v))
        except Exception:
            return None

    def _is_secondary(r):
        return r.get("qualifier", "").strip().lower().startswith("season2")

    def _season_sort_key(r):
        # Primary (0) before secondary (1); then deterministic tie-breaks.
        return (
            1 if _is_secondary(r) else 0,
            _to_int(r.get("harvest_month_end")) if _to_int(
                r.get("harvest_month_end")) is not None else 99,
            r.get("qualifier", "") or "",
            r.get("country", "") or "",
        )

    rows = []
    with open(calendar_path, encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for r in reader:
            if r.get("crop", "").strip().lower() == crop_l:
                # Calendar entries explicitly flagged with the ``Exclude``
                # qualifier are unreliable (e.g. sub-national-only or
                # contradictory source calendars) and are dropped from the
                # usable set so that downstream seasonal-window selection only
                # ever sees QC-passing rows.
                if r.get("qualifier", "").strip().lower() == "exclude":
                    continue
                rows.append(r)

    if not rows:
        return {
            "country": "", "crop": crop_l,
            "planting_month_start": None, "planting_month_end": None,
            "harvest_month_start": None, "harvest_month_end": None,
            "qualifier": "", "secondary_season": False,
            "found": False, "excluded": False,
        }

    target = (country or "").strip()

    # Resolve the matched COUNTRY NAME first (exact -> case-insensitive ->
    # substring), then collect ALL rows for that resolved name so the
    # multi-season selection rule can choose the main season deterministically.
    matched_name = None
    for r in rows:                                  # exact
        if r["country"] == target:
            matched_name = r["country"]
            break
    if matched_name is None:                        # case-insensitive
        tl = target.lower()
        for r in rows:
            if r["country"].lower() == tl:
                matched_name = r["country"]
                break
    # NOTE: no substring fallback — it produced spurious cross-country matches
    # (Oman->Romania, Dominica->Dominican Republic, Papua New Guinea->Guinea,
    # aggregate "Africa"->South Africa, etc.). Every real calendar country is
    # exact/case-insensitive matchable to a FAOSTAT Area name, so unmatched
    # names are genuinely uncovered and are dropped.

    if matched_name is None:
        return {
            "country": "", "crop": crop_l,
            "planting_month_start": None, "planting_month_end": None,
            "harvest_month_start": None, "harvest_month_end": None,
            "qualifier": "", "secondary_season": False,
            "found": False, "excluded": False,
        }

    candidates = [r for r in rows if r["country"] == matched_name]
    # Multi-season rule: primary before Season2, then deterministic tie-breaks.
    match = sorted(candidates, key=_season_sort_key)[0]

    return {
        "country": match["country"],
        "crop": crop_l,
        "planting_month_start": _to_int(match.get("planting_month_start")),
        "planting_month_end": _to_int(match.get("planting_month_end")),
        "harvest_month_start": _to_int(match.get("harvest_month_start")),
        "harvest_month_end": _to_int(match.get("harvest_month_end")),
        "qualifier": match.get("qualifier", "") or "",
        "secondary_season": _is_secondary(match),
        "found": True, "excluded": False,
    }


@mcp.tool()
def parse_faostat_yield_table(csv_path: str, country: str = None,
                               item_filter: str = None) -> dict:
    """Parse FAOSTAT wide-format yield/area CSV into per-country year arrays.

    The FAOSTAT wide format has rows = (Area Code, Area, Item Code, Item, Element,
    Unit, Y1961, Y1962, ..., Y2024). This tool extracts the year columns into a
    clean numeric array per country, handling country name matching.

    Args:
        csv_path: Path to FAOSTAT CSV (yield or area)
        country: Country name (matches FAOSTAT 'Area' column). If None, returns all.
        item_filter: Optional filter on 'Item' column (e.g., 'Maize (corn)')

    Returns:
        dict with 'years' (list of int), and either 'values' (1-D array if country
        specified) or 'countries' (dict of country → values array)
    """
    import csv
    with open(csv_path, encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    if not rows:
        return {"error": "empty file"}

    year_cols = [c for c in rows[0].keys() if c.startswith('Y') and c[1:].isdigit()]
    years = [int(c[1:]) for c in year_cols]

    def parse_row(row):
        # Missing / unparseable cells are emitted as ``None`` (JSON-clean,
        # never NaN). Consumers that load these into a numpy float array get
        # NaN back automatically via ``np.asarray(..., dtype=float)``.
        vals = []
        for c in year_cols:
            v = row.get(c, '')
            try:
                vals.append(float(v) if v and v != '' else None)
            except ValueError:
                vals.append(None)
        return vals

    filtered = rows
    if item_filter:
        filtered = [r for r in filtered if item_filter.lower() in r.get('Item', '').lower()]

    if country:
        target = country.strip().lower()
        for r in filtered:
            if r.get('Area', '').strip().lower() == target:
                return {"years": years, "values": parse_row(r),
                        "country": r['Area'], "item": r.get('Item', '')}
        return {"error": f"country '{country}' not found", "years": years}

    return {
        "years": years,
        "n_countries": len(filtered),
        "countries": {r['Area']: parse_row(r) for r in filtered}
    }


@mcp.tool()
def parse_noaa_nino_text(txt_path: str) -> dict:
    """Parse NOAA Nino 3.4 / ONI monthly anomaly fixed-width text file.

    Standard NOAA PSL format: header row, then year + 12 monthly columns.

    Args:
        txt_path: Path to NOAA monthly anomaly text file

    Returns:
        dict with 'years' (list of int), 'months' (1-12), 'monthly' (list of
        12-element lists, one per year), and 'flat' (dict mapping the string
        key ``"YYYY-MM"`` -> value). String keys keep the result
        JSON-serializable (tuple keys are not).
    """
    import re
    with open(txt_path) as f:
        lines = [l.strip() for l in f if l.strip()]

    data = []
    for ln in lines:
        parts = re.split(r'\s+', ln)
        if len(parts) < 13:
            continue
        try:
            year = int(parts[0])
            vals = [float(x) for x in parts[1:13]]
            data.append((year, vals))
        except ValueError:
            continue

    years = [y for y, _ in data]
    monthly = [v for _, v in data]
    flat = {f"{y:04d}-{m + 1:02d}": monthly[i][m]
            for i, y in enumerate(years) for m in range(12)}

    return {
        "years": years,
        "n_years": len(years),
        "months": list(range(1, 13)),
        "monthly": monthly,
        "flat": flat,
    }


if __name__ == "__main__":
    pass

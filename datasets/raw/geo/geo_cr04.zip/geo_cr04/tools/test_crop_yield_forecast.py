"""Self-checks for the crop-yield forecast primitives.

Covers the exact rank-based ROC-AUC algorithm (Mann-Whitney U with average-rank
tie handling) across the classifier edge cases — including a tie-heavy case and
a random cross-check against ``sklearn.metrics.roc_auc_score`` when available —
plus the harvest-window Nino 3.4 cross-year alignment. Run directly
(``python tools/test_crop_yield_forecast.py``) or via pytest; all assertions
must pass with no network / heavy dependencies (sklearn cross-check is skipped
if sklearn is not installed).
"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import crop_yield_forecast as T  # noqa: E402


def _call(tool, **kwargs):
    fn = tool.fn if hasattr(tool, "fn") else tool
    return fn(**kwargs)


def test_roc_perfect_classifier():
    r = _call(T.compute_roc_score,
              forecasts=[0.9, 0.8, 0.2, 0.1],
              observed=[True, True, False, False])
    assert r["status"] == "ok"
    assert abs(r["roc_area"] - 1.0) < 1e-9, r["roc_area"]


def test_roc_perfectly_inverted():
    r = _call(T.compute_roc_score,
              forecasts=[0.1, 0.2, 0.8, 0.9],
              observed=[True, True, False, False])
    assert r["status"] == "ok"
    assert abs(r["roc_area"] - 0.0) < 1e-9, r["roc_area"]


def test_roc_tied_forecasts():
    # All forecasts identical -> ROC curve collapses to the chance diagonal.
    r = _call(T.compute_roc_score,
              forecasts=[0.5, 0.5, 0.5, 0.5],
              observed=[True, False, True, False])
    assert r["status"] == "ok"
    assert abs(r["roc_area"] - 0.5) < 1e-9, r["roc_area"]


def test_roc_all_positive_is_status_not_number():
    r = _call(T.compute_roc_score,
              forecasts=[0.5, 0.6, 0.7],
              observed=[True, True, True])
    # Degenerate single-class label set: area is undefined, must NOT be a
    # misleading 0.5 / 0.0 number.
    assert r["roc_area"] is None
    assert r["status"] == "all_positive"


def test_roc_all_negative_is_status_not_number():
    r = _call(T.compute_roc_score,
              forecasts=[0.5, 0.6, 0.7],
              observed=[False, False, False])
    assert r["roc_area"] is None
    assert r["status"] == "all_negative"


def test_roc_no_valid_samples():
    r = _call(T.compute_roc_score,
              forecasts=[float("nan"), float("nan")],
              observed=[True, False])
    assert r["roc_area"] is None
    assert r["status"] == "no_valid_samples"


def test_roc_tie_heavy_partial():
    # Tie-heavy case: positives and negatives share scores. Expected exact AUC
    # by hand from the Mann-Whitney U with average ranks.
    # forecasts = [0.6, 0.6, 0.6, 0.4, 0.6], observed = [T, F, T, F, F].
    # Pooled ascending ranks: the single 0.4 -> rank 1; the four 0.6 values tie
    # for ranks 2,3,4,5 -> average rank 3.5 each.
    # Positives are at the two 0.6 entries -> sum of pos ranks = 3.5 + 3.5 = 7.0.
    # n_pos=2, n_neg=3. AUC = (7.0 - 2*3/2) / (2*3) = (7-3)/6 = 4/6 = 0.6667.
    r = _call(T.compute_roc_score,
              forecasts=[0.6, 0.6, 0.6, 0.4, 0.6],
              observed=[True, False, True, False, False])
    assert r["status"] == "ok"
    assert abs(r["roc_area"] - (4.0 / 6.0)) < 1e-9, r["roc_area"]


def test_roc_matches_sklearn_random():
    # The exact rank-AUC must equal sklearn.metrics.roc_auc_score on random
    # cases (including ties). Skipped cleanly if sklearn is unavailable.
    try:
        from sklearn.metrics import roc_auc_score
    except Exception:  # pragma: no cover - environment-dependent
        print("SKIP test_roc_matches_sklearn_random (sklearn not installed)")
        return
    rng = np.random.default_rng(12345)
    for _ in range(20):
        n = int(rng.integers(8, 40))
        obs = rng.integers(0, 2, size=n).astype(bool)
        if obs.all() or (~obs).all():
            continue  # need both classes for a defined AUC
        # Mix continuous and coarsely-rounded scores to exercise ties.
        f = np.round(rng.random(n), int(rng.integers(1, 3)))
        r = _call(T.compute_roc_score, forecasts=[float(x) for x in f],
                  observed=[bool(x) for x in obs])
        ref = roc_auc_score(obs.astype(int), f)
        assert abs(r["roc_area"] - ref) < 1e-9, (r["roc_area"], ref)


def test_harvest_window_cross_year_january():
    # Monthly value encodes year*100+month so we can read back which months
    # were averaged. M=1 (January harvest) -> window Nov(Y-1), Dec(Y-1), Jan(Y).
    months, years, vals = [], [], []
    for y in range(2000, 2004):
        for m in range(1, 13):
            months.append(m)
            years.append(y)
            vals.append(y * 100 + m)
    r = _call(T.harvest_window_nino34, monthly_nino34=vals, months=months,
              years=years, harvest_month_end=1, harvest_years=[2002])
    assert r["window_months"] == [[11, -1], [12, -1], [1, 0]]
    assert abs(r["nino34"][0] - np.mean([200111, 200112, 200201])) < 1e-6


def test_harvest_window_february_djf():
    months, years, vals = [], [], []
    for y in range(2000, 2004):
        for m in range(1, 13):
            months.append(m)
            years.append(y)
            vals.append(y * 100 + m)
    r = _call(T.harvest_window_nino34, monthly_nino34=vals, months=months,
              years=years, harvest_month_end=2, harvest_years=[2002])
    assert r["window_months"] == [[12, -1], [1, 0], [2, 0]]
    assert abs(r["nino34"][0] - np.mean([200112, 200201, 200202])) < 1e-6


def test_harvest_window_midyear_no_wrap():
    months, years, vals = [], [], []
    for y in range(2000, 2004):
        for m in range(1, 13):
            months.append(m)
            years.append(y)
            vals.append(y * 100 + m)
    r = _call(T.harvest_window_nino34, monthly_nino34=vals, months=months,
              years=years, harvest_month_end=5, harvest_years=[2002])
    assert r["window_months"] == [[3, 0], [4, 0], [5, 0]]
    assert abs(r["nino34"][0] - np.mean([200203, 200204, 200205])) < 1e-6


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    failures = 0
    for t in tests:
        try:
            t()
            print(f"PASS {t.__name__}")
        except AssertionError as exc:
            failures += 1
            print(f"FAIL {t.__name__}: {exc}")
    print(f"\n{len(tests) - failures}/{len(tests)} passed")
    sys.exit(1 if failures else 0)

"""Generic data-processing utilities for earthquake catalogs.

Format conversion, sorting, randomization, and lightweight transforms that are
not specific to magnitude clustering. Domain-specific transforms
(b-value, ECDF, magnitude-difference probabilities) live in the
seismicity_analysis module.
"""
from __future__ import annotations
import csv
import json
import random
from typing import Any, Optional

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Earthquake_Data_Processing")


@mcp.tool()
def read_csv(csv_path: str, max_rows: Optional[int] = None) -> dict:
    """Read a CSV file into a list of dict rows."""
    with open(csv_path) as f:
        reader = csv.DictReader(f)
        rows = list(reader) if max_rows is None else [r for _, r in zip(range(max_rows), reader)]
    return {"columns": list(rows[0].keys()) if rows else [], "n_rows": len(rows), "rows": rows}


@mcp.tool()
def write_csv(rows: list, out_csv: str) -> dict:
    """Write a list of dict rows to CSV using the first row's keys as header."""
    if not rows:
        open(out_csv, "w").close()
        return {"n_rows": 0, "csv_path": out_csv}
    with open(out_csv, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)
    return {"n_rows": len(rows), "csv_path": out_csv}


@mcp.tool()
def column_to_list(csv_path: str, column: str, dtype: str = "float") -> dict:
    """Extract a single column from a CSV as a typed list.

    Args:
        csv_path: input CSV.
        column: column name.
        dtype: "float" | "int" | "str".

    Returns:
        dict with values list (skipping unparseable rows).
    """
    with open(csv_path) as f:
        reader = csv.DictReader(f)
        out = []
        for r in reader:
            v = r.get(column, "")
            if v in ("", None):
                continue
            try:
                if dtype == "float":
                    out.append(float(v))
                elif dtype == "int":
                    out.append(int(float(v)))
                else:
                    out.append(str(v))
            except (TypeError, ValueError):
                continue
    return {"n_values": len(out), "values": out, "min": min(out) if out and dtype != "str" else None,
            "max": max(out) if out and dtype != "str" else None}


@mcp.tool()
def shuffle_column(csv_path: str, column: str, out_csv: str, seed: int = 0) -> dict:
    """Randomize the order of values in a single column while preserving the
    other columns and row order. Used to test the null hypothesis that the
    target column has no temporal correlation with the rest of the catalog.

    Args:
        csv_path: input CSV.
        column: column whose values are randomly permuted.
        out_csv: output CSV path.
        seed: PRNG seed for reproducibility.

    Returns:
        dict with row count and output path.
    """
    with open(csv_path) as f:
        rows = list(csv.DictReader(f))
    vals = [r[column] for r in rows]
    rng = random.Random(seed)
    rng.shuffle(vals)
    for r, v in zip(rows, vals):
        r[column] = v
    if rows:
        with open(out_csv, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader(); w.writerows(rows)
    return {"n_rows": len(rows), "shuffled_column": column, "csv_path": out_csv, "seed": seed}


@mcp.tool()
def sort_by_column(csv_path: str, column: str, out_csv: str, dtype: str = "str",
                   descending: bool = False) -> dict:
    """Stable sort of CSV rows by a single column (lexicographic by default)."""
    with open(csv_path) as f:
        rows = list(csv.DictReader(f))
    def key(r):
        v = r.get(column)
        if v in ("", None):
            return float("-inf") if dtype == "float" else ""
        try:
            return float(v) if dtype == "float" else str(v)
        except (TypeError, ValueError):
            return float("-inf") if dtype == "float" else ""
    rows.sort(key=key, reverse=descending)
    if rows:
        with open(out_csv, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader(); w.writerows(rows)
    return {"n_rows": len(rows), "csv_path": out_csv}


@mcp.tool()
def descriptive_stats(values: list) -> dict:
    """Mean, std, min/max, median, and selected percentiles for a list of floats."""
    import math
    arr = [float(v) for v in values if v is not None and v != ""]
    if not arr:
        return {"count": 0}
    arr_sorted = sorted(arr)
    n = len(arr_sorted)
    def pct(p):
        idx = (n - 1) * p / 100.0
        lo = int(idx); hi = min(lo + 1, n - 1)
        frac = idx - lo
        return arr_sorted[lo] * (1 - frac) + arr_sorted[hi] * frac
    mean = sum(arr) / n
    var = sum((x - mean) ** 2 for x in arr) / n
    return {
        "count": n,
        "mean": round(mean, 6),
        "std": round(math.sqrt(var), 6),
        "min": round(arr_sorted[0], 6),
        "max": round(arr_sorted[-1], 6),
        "median": round(pct(50), 6),
        "p10": round(pct(10), 6),
        "p25": round(pct(25), 6),
        "p75": round(pct(75), 6),
        "p90": round(pct(90), 6),
    }


@mcp.tool()
def histogram(values: list, n_bins: int = 50, range_min: Optional[float] = None,
              range_max: Optional[float] = None) -> dict:
    """Compute a 1-D histogram of values."""
    arr = [float(v) for v in values if v is not None and v != ""]
    if not arr:
        return {"n_bins": 0}
    lo = float(range_min) if range_min is not None else min(arr)
    hi = float(range_max) if range_max is not None else max(arr)
    if hi <= lo:
        hi = lo + 1.0
    width = (hi - lo) / n_bins
    counts = [0] * n_bins
    for v in arr:
        i = int((v - lo) / width)
        if 0 <= i < n_bins:
            counts[i] += 1
        elif v == hi:
            counts[-1] += 1
    edges = [lo + i * width for i in range(n_bins + 1)]
    centers = [(edges[i] + edges[i + 1]) / 2 for i in range(n_bins)]
    return {"n_bins": n_bins, "edges": edges, "centers": centers, "counts": counts,
            "range": [lo, hi], "n_values": len(arr)}


@mcp.tool()
def ecdf_values(values: list) -> dict:
    """Empirical cumulative density function values for each input.

    Returns sorted unique values, the rank-based ECDF, and (for each input
    in the original order) its ECDF value.
    """
    arr = [float(v) for v in values]
    n = len(arr)
    if n == 0:
        return {"n": 0}
    sorted_arr = sorted(enumerate(arr), key=lambda x: x[1])
    ecdf = [0.0] * n
    # rank-based ECDF: rank / n (1-based)
    for rank, (orig_idx, _) in enumerate(sorted_arr, start=1):
        ecdf[orig_idx] = rank / n
    return {"n": n, "ecdf": ecdf, "sorted_values": [v for _, v in sorted_arr]}


@mcp.tool()
def successive_differences(values: list) -> dict:
    """Compute differences between consecutive values: out[i] = values[i+1] - values[i]."""
    arr = [float(v) for v in values]
    diffs = [arr[i + 1] - arr[i] for i in range(len(arr) - 1)]
    return {"n_pairs": len(diffs), "diffs": diffs}


@mcp.tool()
def time_diffs_seconds(time_strings: list) -> dict:
    """Convert a list of ISO datetime strings to inter-event times in seconds."""
    import datetime as dt
    ts = []
    for s in time_strings:
        s = s.replace("Z", "")
        try:
            ts.append(dt.datetime.fromisoformat(s).timestamp())
        except Exception:
            ts.append(None)
    diffs = []
    for i in range(len(ts) - 1):
        if ts[i] is None or ts[i + 1] is None:
            diffs.append(None)
        else:
            diffs.append(ts[i + 1] - ts[i])
    valid = [d for d in diffs if d is not None and d >= 0]
    return {"n_pairs": len(diffs), "diffs_seconds": diffs,
            "median_seconds": round(sorted(valid)[len(valid) // 2], 3) if valid else None,
            "min_seconds": round(min(valid), 3) if valid else None,
            "max_seconds": round(max(valid), 3) if valid else None}


@mcp.tool()
def haversine_distances_km(lats: list, lons: list) -> dict:
    """Compute consecutive great-circle distances in km between lat/lon points."""
    import math
    R = 6371.0
    out = []
    for i in range(len(lats) - 1):
        try:
            phi1 = math.radians(float(lats[i])); phi2 = math.radians(float(lats[i + 1]))
            dphi = phi2 - phi1
            dlam = math.radians(float(lons[i + 1]) - float(lons[i]))
            a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlam / 2) ** 2
            out.append(2 * R * math.asin(min(1.0, math.sqrt(a))))
        except Exception:
            out.append(None)
    return {"n_pairs": len(out), "distances_km": out}


if __name__ == "__main__":
    mcp.run(transport="stdio")

# Tools — geo_eq14 (earthquake magnitude clustering)

Four FastMCP tool servers expose the primitives needed to retrieve a
USGS earthquake catalog, estimate the magnitude of completeness Mc and
the Gutenberg-Richter b-value, and test for magnitude clustering by
comparing the observed catalog against time-randomized null catalogs.

## Magnitude resolution (single source of truth)

The **analysis magnitude resolution is 0.1**: it is the `delta_p_curve`
histogram `bin_width` (0.1) AND the `synthetic_with_repeats`
repeat-noise `mag_uncertainty` sigma (0.1). The **raw USGS ComCat
catalog is reported to 0.01** magnitude units. This same statement —
"analysis resolution 0.1; raw ComCat 0.01" — is repeated identically in
the `delta_p_curve` docstring, the plotting figure captions, and the
answer; there is no other resolution value anywhere in the bundle.

## Servers

- `database_retrieval.py`
  - `fetch_usgs_comcat(starttime, endtime, minmagnitude, bbox, out_csv, allow_network=False)` —
    documents how the bundled catalog was produced by paging through the
    USGS FDSN API in monthly chunks (the API caps each request at 20 000
    events). **Offline by default**: it returns an error unless
    `allow_network=True` is passed explicitly, so the task runs
    deterministically from the bundled CSV. Use `load_catalog_csv` on
    `input_data/data/socal_catalog.csv` for the standard offline run.
  - `load_catalog_csv(csv_path)` — preview a saved catalog (columns,
    magnitude/time range, first 30 rows).
  - `filter_catalog(csv_path, out_csv, min_magnitude, ...)` — magnitude /
    time / bbox filter.

- `data_processing.py` — generic CSV utilities and statistical primitives:
  `read_csv`, `write_csv`, `column_to_list`, `shuffle_column`,
  `sort_by_column`, `descriptive_stats`, `histogram`, `ecdf_values`,
  `successive_differences`, `time_diffs_seconds`, `haversine_distances_km`.

- `seismicity_analysis.py` — magnitude-clustering primitives:
  - `frequency_magnitude_distribution`, `mc_max_curvature`,
    `mc_b_value_stability`, `b_value_aki` (Aki + Utsu + Shi-Bolt).
  - `successive_magnitude_diffs` — dm[i] = mag[i+1] - mag[i].
  - `delta_p_curve(magnitudes, n_shuffles, bin_width=0.1, ...)` — computes
    delta_P(m0) = P_real(dm = m0) - P_shuffled(dm = m0) using a fixed
    **0.1 magnitude-difference bin width** (the *analysis magnitude
    resolution* — see the resolution note below). Bins are **centered on
    integer multiples of `bin_width`**, so one bin is centered exactly on
    m0 = 0 (edges at ±0.05) and the dP peak sits at m0 = 0 by construction.
    `P_real` and `P_shuffled` are **normalized over the full
    magnitude-difference domain** (denominator = total number of successive
    pairs), so by default `sum(real_p) == sum(shuffled_mean_p) == 1` and
    `sum(delta_p) == 0`. 1-sigma uncertainty comes from `n_shuffles`
    time-randomized catalogs (cumulative or non-cumulative).
  - `ecdf_successive_test`, `ecdf_2d_grid` — ECDF-based diagonal-excess
    diagnostic (the test introduced in Methods of the target paper). Both
    compare the observed successive-pair contingency against a
    **time-randomization null** (event order shuffled `n_shuffles` times),
    so `diff_from_mean_percent` and the diagonal excess are measured
    relative to that independence baseline, not a flat uniform grid. Both
    assign equal-population ECDF bins with a **tie-aware (midrank) rank**
    (`_tie_aware_ecdf_bins`): every event with the same magnitude gets the
    same ECDF value/bin, so the heavily-binned catalog's ties are NOT split
    by their original time order. (A plain stable `sorted()` would rank tied
    magnitudes in time order and inject a spurious successive-time signal
    into the diagonal.) The diagonal `z = (observed - null_mean) / null_std`
    is computed against the shuffle distribution; the one-sided p-value is
    taken as the Gaussian tail above that z. (When the observed diagonal is
    not reached by any of the `n_shuffles` shuffles, the empirical shuffle p
    only resolves to `< 1/n_shuffles`, so the z-based Gaussian tail is the
    finer estimate.)
  - FMD binning is shared: `_fmd` (used by `frequency_magnitude_distribution`
    and `mc_max_curvature`) places bin **centers on the `dm` grid** (e.g.
    1.5, 1.6, ...) and is imported by `plotting.plot_fmd_and_mc`, so the FMD
    figure and the Mc estimator agree exactly on the location of the
    non-cumulative peak / max-curvature Mc (the same bin in both).
  - `synthetic_with_repeats` — Gutenberg-Richter draws with a tunable
    fraction of magnitude-repeating events, used for a *simplified analog* of
    the paper's repeat-fraction comparison (see the correspondence note below).

- `plotting.py` — one tool per output image:
  - `plot_fmd_and_mc` — frequency-magnitude distribution with Mc and GR fit.
  - `plot_delta_p_curve` — delta_P(m0) signature with shuffle-test error bars.
  - `plot_ecdf_grid` — 2-D ECDF(m_i) vs ECDF(m_{i+1}) heat map.
  - `plot_real_vs_synthetic_delta_p` — observed curve overlaid with a
    grid of synthetic catalogs at different repeat fractions.

## Dependencies

Python 3.9+ with:

- `mcp[server]>=1.0` (FastMCP)
- `numpy>=1.24`
- `matplotlib>=3.7`

`urllib.request`, `csv`, `json`, `random`, `math`, `datetime` are stdlib.

Install:

```
pip install "mcp[cli]" numpy matplotlib
```

## Running a server (stdio)

```
python tools/seismicity_analysis.py
python tools/plotting.py
python tools/database_retrieval.py
python tools/data_processing.py
```

## End-to-end pipeline (suggested call order)

1. `database_retrieval.fetch_usgs_comcat(...)` -> CSV (or
   `load_catalog_csv` if pre-bundled).
2. `data_processing.column_to_list(csv_path, "magnitude")` -> magnitude
   list.
3. `seismicity_analysis.mc_max_curvature(...)` and
   `mc_b_value_stability(...)` -> Mc estimate.
4. `database_retrieval.filter_catalog(min_magnitude=Mc)` -> filtered CSV.
5. `seismicity_analysis.b_value_aki(filtered_mags, mc=Mc)`.
6. `seismicity_analysis.delta_p_curve(filtered_mags, n_shuffles=200)`.
7. `seismicity_analysis.ecdf_2d_grid(filtered_mags)`.
8. `plotting.plot_*` to render artifacts.
9. `seismicity_analysis.synthetic_with_repeats` over a grid of
   repeat-fraction values, then
   `plotting.plot_real_vs_synthetic_delta_p` to overlay the observed dP(m0)
   curve on the synthetic family.

## Synthetic-catalog experiment: what it does vs. what the paper did

The paper (Xiong et al. 2023, Fig. 6) introduces an ETAS-style model in which a
fraction of events repeat a previous magnitude, and shows on the full
high-precision catalog that a repeat fraction of order ~10% (as small as ~2%)
reproduces the observed field signal.

The bundled `synthetic_with_repeats` + `plot_real_vs_synthetic_delta_p` chain is
a deliberately **simplified analog**, not a faithful reproduction of the paper's
Fig. 6:

- **Tool implementation.** `synthetic_with_repeats` draws independent
  Gutenberg-Richter magnitudes (truncated exponential at `mc`, slope `b`); with
  probability `repeat_fraction` an event copies the previous magnitude plus
  Gaussian noise of width `mag_uncertainty`. It is a single-parameter repeat
  model — it does NOT implement ETAS triggering, aftershock productivity, or
  time/space structure.
- **Answer correspondence.** The answer compares the observed dP(m0) peak height
  at m0 = 0 against this synthetic family and reports which bracketing
  repeat-fraction levels best match it on the bundled completeness-filtered
  subset. That bracketing is the SCORED result; it is qualitatively consistent
  in sign and rough magnitude with the paper, not a quantitative reproduction of
  the paper's fitted value.
- **Target-paper method.** The paper's quantitative repeat-fraction estimate
  comes from its full ETAS analysis on the much larger high-precision catalog,
  which is NOT bundled and is therefore NOT reproduced or scored here.

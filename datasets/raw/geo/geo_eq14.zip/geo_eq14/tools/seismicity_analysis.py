"""Seismicity-analysis primitives for magnitude-clustering studies.

Implements (1) magnitude-of-completeness (Mc) estimation via the
maximum-curvature and b-value-stability methods, (2) Aki/Bender maximum-
likelihood b-value, (3) the magnitude-difference probability function
delta_P(m0) = P_real(dm = m0) - P_random(dm = m0), and (4) the
ECDF-based successive-event comparison used to detect magnitude
clustering. These are LOW-LEVEL primitives: the operator wires them
together to reproduce the analysis.
"""
from __future__ import annotations
import csv
import math
import random
from typing import Optional

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Seismicity_Analysis")


# ------------------------------------------------------------------
# Frequency-magnitude distribution & Mc estimators
# ------------------------------------------------------------------
def _fmd(mags: list[float], dm: float = 0.1):
    """Build non-cumulative and cumulative frequency-magnitude distribution."""
    if not mags:
        return [], [], []
    lo = math.floor(min(mags) / dm) * dm
    hi = math.ceil(max(mags) / dm) * dm
    n = int(round((hi - lo) / dm)) + 1
    centers = [round(lo + i * dm, 4) for i in range(n)]
    non_cum = [0] * n
    for m in mags:
        i = int(round((m - lo) / dm))
        if 0 <= i < n:
            non_cum[i] += 1
    cum = [0] * n
    s = 0
    for i in range(n - 1, -1, -1):
        s += non_cum[i]; cum[i] = s
    return centers, non_cum, cum


@mcp.tool()
def frequency_magnitude_distribution(magnitudes: list, dm: float = 0.1) -> dict:
    """Compute non-cumulative and cumulative frequency-magnitude distributions."""
    mags = [float(m) for m in magnitudes if m is not None and m != ""]
    centers, non_cum, cum = _fmd(mags, dm)
    return {"n": len(mags), "dm": dm, "magnitude_centers": centers,
            "non_cumulative": non_cum, "cumulative": cum}


@mcp.tool()
def mc_max_curvature(magnitudes: list, dm: float = 0.1, correction: float = 0.2) -> dict:
    """Estimate magnitude of completeness Mc via the maximum-curvature method.

    Mc is taken as the magnitude with the largest non-cumulative frequency,
    optionally augmented by a small correction (Woessner & Wiemer 2005).
    """
    mags = [float(m) for m in magnitudes if m is not None and m != ""]
    centers, non_cum, _ = _fmd(mags, dm)
    if not non_cum:
        return {"error": "empty"}
    i_peak = max(range(len(non_cum)), key=lambda i: non_cum[i])
    return {"mc_raw": round(centers[i_peak], 3),
            "mc_corrected": round(centers[i_peak] + correction, 3),
            "n_at_peak": non_cum[i_peak], "n_total": len(mags)}


@mcp.tool()
def b_value_aki(magnitudes: list, mc: float, dm: float = 0.1) -> dict:
    """Aki (1965) maximum-likelihood b-value with Utsu (1965) bin correction.

    Args:
        magnitudes: list of magnitudes (>= mc).
        mc: magnitude of completeness.
        dm: catalog magnitude bin width.

    Returns:
        dict with b, sigma_b (Shi & Bolt 1982), a, mean_mag, n.
    """
    mags = [float(m) for m in magnitudes if m is not None and m != "" and float(m) >= mc - 1e-9]
    n = len(mags)
    if n < 5:
        return {"error": "too few events", "n": n}
    mean_m = sum(mags) / n
    # Utsu correction: subtract dm/2 from the difference (mean - mc)
    denom = mean_m - (mc - dm / 2.0)
    if denom <= 0:
        return {"error": "denominator <= 0", "n": n}
    b = math.log10(math.e) / denom
    # Shi & Bolt 1982 standard error
    var = sum((m - mean_m) ** 2 for m in mags) / (n * (n - 1))
    sigma_b = 2.30 * b ** 2 * math.sqrt(var)
    a = math.log10(n) + b * mc
    return {"b": round(b, 4), "sigma_b": round(sigma_b, 4), "a": round(a, 4),
            "mean_magnitude": round(mean_m, 4), "n": n, "mc": mc, "dm": dm}


@mcp.tool()
def mc_b_value_stability(magnitudes: list, dm: float = 0.1,
                         mc_min: float = 0.0, mc_max: float = 4.0,
                         tolerance: float = 0.03) -> dict:
    """b-value stability test for Mc (Cao & Gao 2002 / Woessner & Wiemer 2005).

    Sweeps Mc upward; the smallest Mc whose b is stable (within `tolerance`
    of the b-values for Mc+0.1, Mc+0.2, ... Mc+0.5) is returned.
    """
    mags = [float(m) for m in magnitudes if m is not None and m != ""]
    sweep = []
    cur = mc_min
    while cur <= mc_max + 1e-9:
        result = b_value_aki(mags, cur, dm)  # type: ignore[arg-type]
        if isinstance(result, dict) and "b" in result:
            sweep.append({"mc": round(cur, 3), "b": result["b"], "n": result["n"]})
        cur += dm
    chosen = None
    for i, e in enumerate(sweep):
        # average of next 5 b-values
        nxt = sweep[i + 1: i + 6]
        if len(nxt) < 5:
            break
        avg = sum(x["b"] for x in nxt) / len(nxt)
        if abs(avg - e["b"]) <= tolerance:
            chosen = e["mc"]
            break
    return {"mc_stability": chosen, "sweep": sweep}


# ------------------------------------------------------------------
# Magnitude clustering: delta_P(m0) and ECDF tests
# ------------------------------------------------------------------
@mcp.tool()
def successive_magnitude_diffs(magnitudes: list) -> dict:
    """Differences between consecutive magnitudes: dm[i] = mag[i+1] - mag[i]."""
    mags = [float(m) for m in magnitudes]
    diffs = [mags[i + 1] - mags[i] for i in range(len(mags) - 1)]
    return {"n_pairs": len(diffs), "diffs": diffs}


@mcp.tool()
def delta_p_curve(magnitudes: list, n_shuffles: int = 100, bin_width: float = 0.1,
                  m0_min: Optional[float] = None, m0_max: Optional[float] = None,
                  cumulative: bool = False, seed: int = 0) -> dict:
    """Compute delta_P(m0) = P_real(dm = m0) - P_shuffled(dm = m0) for
    successive-event magnitude differences. Repeats the shuffle test
    `n_shuffles` times to estimate the 1-sigma confidence band.

    The magnitude-difference histogram uses a fixed `bin_width` of 0.1
    magnitude units — the **analysis magnitude resolution is 0.1** (this bin
    width, which also equals the `synthetic_with_repeats` repeat-noise sigma;
    the raw ComCat catalog is reported to 0.01). Each bin is exactly one
    0.1-magnitude-difference step. Bins are
    **centered on integer multiples of `bin_width`**, so there is always a bin
    centered exactly on m0 = 0 whose edges are at ±bin_width/2 (e.g. with the
    default 0.1 width the zero bin spans [-0.05, 0.05], the next bins are
    centered at ±0.1 spanning [0.05, 0.15] and [-0.15, -0.05], etc.). This
    guarantees a magnitude difference of exactly 0 — the repeating-magnitude
    signal — falls in the center of the m0 = 0 bin, so the dP(m0) peak sits at
    m0 = 0 by construction.

    **Probability normalization (FULL domain).** ``P_real`` and ``P_shuffled``
    are *true* probability distributions over the magnitude-difference domain:
    each histogram is normalized by the TOTAL number of successive pairs
    (``n - 1``), NOT by the count that happens to fall inside a truncated m0
    window. The grid spans the **full** observed magnitude-difference range by
    default (``m0_min``/``m0_max`` are auto-set to floor/ceil of the minimum /
    maximum real difference onto the bin grid), so every difference lands in a
    bin and ``sum(real_p) == 1`` and ``sum(shuffled_mean_p) == 1`` to numerical
    precision (hence ``sum(delta_p) == 0``). If the caller passes an explicit
    ``m0_min``/``m0_max`` that does not cover the full domain, the normalization
    denominator is STILL the total pair count, so the returned probabilities
    remain a consistent sub-distribution of the same full-domain distribution
    (they integrate to the in-window probability mass, not renormalized to 1
    over the truncated window) — the dP definition is therefore independent of
    the chosen display window.

    Args:
        magnitudes: ordered (by time) catalog magnitudes >= mc.
        n_shuffles: number of random permutations for the null model.
        bin_width: magnitude-difference bin width (default 0.1 = analysis
            magnitude resolution). Bins are centered on integer multiples of
            bin_width (one bin centered on 0).
        m0_min, m0_max: optional m0 grid bounds. If ``None`` (default) the grid
            is auto-sized to the full observed magnitude-difference range so no
            difference is truncated and the probabilities sum to 1.
        cumulative: if True, return cumulative delta_P.
        seed: PRNG seed.

    Returns:
        dict with bin centers, real probability, mean shuffled probability,
        delta_p, and 1-sigma standard deviation across shuffles.
    """
    mags = [float(m) for m in magnitudes]
    n = len(mags)
    if n < 100:
        return {"error": "too few events", "n": n}
    width = bin_width
    real_diffs = [mags[i + 1] - mags[i] for i in range(n - 1)]

    # Default grid = FULL theoretical magnitude-difference domain. The extreme
    # possible successive difference is (max magnitude - min magnitude); the
    # shuffled null can realize those extremes even when the *observed* sequence
    # does not, so the default grid spans +/-(max - min). This guarantees that
    # EVERY difference (real AND shuffled) lands in a bin, so normalizing by the
    # total pair count makes both P_real and P_shuffled sum to exactly 1 over
    # the stated domain (and hence sum(delta_p) == 0).
    span = (max(mags) - min(mags)) if mags else 0.0
    lo_bound = m0_min if m0_min is not None else -span
    hi_bound = m0_max if m0_max is not None else span
    # Snap bounds onto integer multiples of width (round outward so the extreme
    # differences are included even when an explicit window is supplied wide
    # enough to contain them).
    k_min = int(math.floor((lo_bound + 1e-9) / width))
    k_max = int(math.ceil((hi_bound - 1e-9) / width))
    centers = [round(k * width, 6) for k in range(k_min, k_max + 1)]
    n_bins = len(centers)
    edge_lo = centers[0] - width / 2.0  # left edge of first bin

    def hist(diffs):
        h = [0] * n_bins
        # Bin j covers [centers[j] - width/2, centers[j] + width/2); index is
        # found by offsetting from the left edge of the first bin.
        for d in diffs:
            idx = int(math.floor((d - edge_lo) / width))
            if 0 <= idx < n_bins:
                h[idx] += 1
        return h

    # Normalize by the TOTAL pair count (full-domain probability), NOT by the
    # in-window count, so the probability definition is independent of any
    # display-window truncation.
    n_pairs = (n - 1) or 1
    real_h = hist(real_diffs)
    real_p = [c / n_pairs for c in real_h]

    rng = random.Random(seed)
    shuffled_p_runs = []
    for _ in range(n_shuffles):
        shuf = list(mags)
        rng.shuffle(shuf)
        sd = [shuf[i + 1] - shuf[i] for i in range(n - 1)]
        h = hist(sd)
        shuffled_p_runs.append([c / n_pairs for c in h])
    mean_p = [sum(r[b] for r in shuffled_p_runs) / n_shuffles for b in range(n_bins)]
    var_p = [sum((r[b] - mean_p[b]) ** 2 for r in shuffled_p_runs) / n_shuffles for b in range(n_bins)]
    sigma_p = [math.sqrt(v) for v in var_p]
    delta = [real_p[b] - mean_p[b] for b in range(n_bins)]

    out = {"centers": centers, "n_pairs": n - 1, "n_shuffles": n_shuffles,
           "real_p": real_p, "shuffled_mean_p": mean_p, "delta_p": delta,
           "sigma_shuffled": sigma_p}

    if cumulative:
        # cumulative delta_P: P(dm <= m0) - P(dm* <= m0)
        c_real = [0.0] * n_bins; c_mean = [0.0] * n_bins; c_sigma = [0.0] * n_bins
        s_r = 0.0; s_m = 0.0
        # also need cumulative for each shuffle to get sigma
        cum_runs = []
        for r in shuffled_p_runs:
            run = []; s = 0.0
            for v in r:
                s += v; run.append(s)
            cum_runs.append(run)
        for b in range(n_bins):
            s_r += real_p[b]; s_m += mean_p[b]
            c_real[b] = s_r; c_mean[b] = s_m
            c_sigma[b] = math.sqrt(sum((cum_runs[k][b] - c_mean[b]) ** 2 for k in range(n_shuffles)) / n_shuffles)
        out["cumulative_real_p"] = c_real
        out["cumulative_mean_p"] = c_mean
        out["cumulative_delta_p"] = [c_real[b] - c_mean[b] for b in range(n_bins)]
        out["cumulative_sigma"] = c_sigma
    return out


def _tie_aware_ecdf_bins(mags: list[float], n_bins: int) -> list[int]:
    """Assign each event an equal-population ECDF bin using a TIE-AWARE rank.

    A naive ``sorted(range(n), key=lambda i: mags[i])`` is a *stable* sort, so
    events with identical magnitudes are ranked in their original (time) order.
    For a heavily binned catalog (0.1-unit magnitude resolution) that injects a
    spurious successive-time signal: tied magnitudes straddling an
    equal-population bin edge get split by time position, artificially
    correlating ``bin(m_i)`` with ``bin(m_{i+1})``.

    To remove that, every event with the same magnitude is given the SAME
    midrank-based ECDF value ``F = mean_rank / n`` (average / fractional rank
    over the tie group), and the bin index is derived from ``F`` alone. Tied
    magnitudes therefore always land in the same bin regardless of time order,
    so no artificial time-ordering can leak into the successive-pair statistic.

    Returns a list ``bin_idx`` (one 0..n_bins-1 index per input event, in the
    original time order).
    """
    n = len(mags)
    order = sorted(range(n), key=lambda i: mags[i])
    # Midrank: events sharing a magnitude get the average of the 0-based ranks
    # they occupy. F = (midrank + 0.5) / n is the tie-aware ECDF value.
    bin_idx = [0] * n
    j = 0
    while j < n:
        k = j
        while k + 1 < n and mags[order[k + 1]] == mags[order[j]]:
            k += 1
        # ranks j..k all tie -> share the average rank.
        mid = (j + k) / 2.0
        f = (mid + 0.5) / n
        b = min(int(f * n_bins), n_bins - 1)
        for t in range(j, k + 1):
            bin_idx[order[t]] = b
        j = k + 1
    return bin_idx


@mcp.tool()
def ecdf_successive_test(magnitudes: list, n_bins: int = 5, n_shuffles: int = 200,
                          seed: int = 0) -> dict:
    """ECDF-based magnitude-clustering test.

    Each event is assigned an equal-population ECDF bin index via a TIE-AWARE
    (midrank) magnitude rank — events with identical magnitudes share the same
    bin (see :func:`_tie_aware_ecdf_bins`), so the heavily-binned catalog's ties
    do NOT get split by time order and cannot inject a spurious successive-time
    signal. The fraction of consecutive-event pairs that share the same ECDF
    bin is compared to the same fraction in randomly shuffled catalogs.

    Args:
        magnitudes: ordered catalog magnitudes (filtered to mc).
        n_bins: number of equal-population ECDF bins (5 -> 20% each).
        n_shuffles: number of randomized catalogs for the null model.

    Returns:
        dict with observed diagonal-count, mean and std of the null,
        z-score, and excess fraction (observed / mean - 1).
    """
    mags = [float(m) for m in magnitudes]
    n = len(mags)
    if n < 100:
        return {"error": "too few events", "n": n}
    bin_idx = _tie_aware_ecdf_bins(mags, n_bins)
    diag = sum(1 for i in range(n - 1) if bin_idx[i] == bin_idx[i + 1])
    rng = random.Random(seed)
    null_diags = []
    for _ in range(n_shuffles):
        shuf = list(bin_idx); rng.shuffle(shuf)
        null_diags.append(sum(1 for i in range(n - 1) if shuf[i] == shuf[i + 1]))
    mu = sum(null_diags) / n_shuffles
    var = sum((d - mu) ** 2 for d in null_diags) / n_shuffles
    sd = math.sqrt(var)
    z = (diag - mu) / sd if sd > 0 else float("nan")
    excess = (diag / mu - 1.0) if mu > 0 else float("nan")
    return {"observed_diagonal": diag, "null_mean": round(mu, 2),
            "null_std": round(sd, 3), "z_score": round(z, 3),
            "excess_fraction": round(excess, 4),
            "p_one_sided_lt_001": z > 3.09, "n_pairs": n - 1, "n_bins": n_bins}


@mcp.tool()
def ecdf_2d_grid(magnitudes: list, n_bins: int = 5, n_shuffles: int = 200,
                 seed: int = 0) -> dict:
    """ECDF(m_i) vs ECDF(m_{i+1}) 2-D contingency against a time-randomization
    null model.

    Each event is assigned an equal-population ECDF bin by a TIE-AWARE
    (midrank) magnitude rank (see :func:`_tie_aware_ecdf_bins`): events with
    identical magnitudes share the same bin, so tied magnitudes are never split
    by time order and cannot inject a spurious successive-time signal.
    The observed (n_bins x n_bins) count matrix over consecutive pairs is
    compared to the mean matrix obtained from `n_shuffles` time-randomized
    catalogs (the event order is shuffled, breaking any temporal correlation
    of successive magnitudes while preserving the marginal magnitude
    distribution). `diff_from_mean_percent` is the percent excess of each
    cell over this shuffled null (NOT over a flat uniform expectation), which
    is the independence baseline used in Fig. 2 of the target paper.

    Args:
        magnitudes: ordered (by time) catalog magnitudes (filtered to mc).
        n_bins: number of equal-population ECDF bins (5 -> 20% each).
        n_shuffles: number of time-randomized catalogs for the null model.
        seed: PRNG seed.

    Returns:
        dict with the observed count matrix, the shuffled-null mean matrix,
        per-cell percent excess over the null, the overall diagonal excess
        over the null, and a z-score for the diagonal.
    """
    mags = [float(m) for m in magnitudes]
    n = len(mags)
    if n < 100:
        return {"error": "too few events", "n": n}
    bin_idx = _tie_aware_ecdf_bins(mags, n_bins)
    counts = [[0] * n_bins for _ in range(n_bins)]
    for i in range(n - 1):
        counts[bin_idx[i]][bin_idx[i + 1]] += 1
    total = sum(sum(row) for row in counts)

    # Time-randomization null: shuffle the bin sequence and recompute the
    # successive-pair contingency. Average over n_shuffles realizations.
    rng = random.Random(seed)
    null_sum = [[0.0] * n_bins for _ in range(n_bins)]
    null_sq = [[0.0] * n_bins for _ in range(n_bins)]
    null_diag_vals = []
    for _ in range(n_shuffles):
        shuf = list(bin_idx)
        rng.shuffle(shuf)
        m_null = [[0] * n_bins for _ in range(n_bins)]
        for i in range(n - 1):
            m_null[shuf[i]][shuf[i + 1]] += 1
        d = 0
        for r in range(n_bins):
            for c in range(n_bins):
                null_sum[r][c] += m_null[r][c]
                null_sq[r][c] += m_null[r][c] ** 2
            d += m_null[r][r]
        null_diag_vals.append(d)
    null_mean = [[null_sum[r][c] / n_shuffles for c in range(n_bins)]
                 for r in range(n_bins)]
    diff_pct = [[round((counts[r][c] - null_mean[r][c]) / null_mean[r][c] * 100, 2)
                 if null_mean[r][c] > 0 else 0.0
                 for c in range(n_bins)] for r in range(n_bins)]

    diag_count = sum(counts[i][i] for i in range(n_bins))
    null_diag_mean = sum(null_diag_vals) / n_shuffles
    null_diag_var = sum((d - null_diag_mean) ** 2 for d in null_diag_vals) / n_shuffles
    null_diag_sd = math.sqrt(null_diag_var)
    z = (diag_count - null_diag_mean) / null_diag_sd if null_diag_sd > 0 else float("nan")
    return {"counts": counts, "null_mean": null_mean,
            "diff_from_mean_percent": diff_pct,
            "diagonal_total": diag_count, "n_pairs": total,
            "null_diagonal_mean": round(null_diag_mean, 2),
            "null_diagonal_std": round(null_diag_sd, 3),
            "diagonal_z_score": round(z, 3) if z == z else None,
            "diagonal_excess_pct": round((diag_count / null_diag_mean - 1) * 100, 2)
            if null_diag_mean > 0 else 0.0}


# ------------------------------------------------------------------
# Repeating-event modeling (Fig. 6 analysis)
# ------------------------------------------------------------------
@mcp.tool()
def synthetic_with_repeats(b_value: float, mc: float, n_events: int,
                           repeat_fraction: float, mag_uncertainty: float = 0.1,
                           seed: int = 0) -> dict:
    """Generate a synthetic catalog with a controllable fraction of
    magnitude-repeating events to compare against an observed delta_P curve.

    Each event is drawn from an exponential (Gutenberg-Richter) distribution
    truncated at mc; with probability `repeat_fraction` the event's
    magnitude is taken from the previous event plus Gaussian noise of
    standard deviation `mag_uncertainty`.

    Args:
        b_value: GR b-value used to draw new magnitudes.
        mc: magnitude of completeness (lower bound of GR draw).
        n_events: catalog size.
        repeat_fraction: fraction of events that repeat the previous magnitude.
        mag_uncertainty: 1-sigma Gaussian noise on repeated magnitudes.
        seed: PRNG seed.

    Returns:
        dict with the simulated magnitudes.
    """
    rng = random.Random(seed)
    beta = b_value * math.log(10)
    mags = []
    for i in range(n_events):
        if i > 0 and rng.random() < repeat_fraction:
            m = mags[-1] + rng.gauss(0, mag_uncertainty)
            if m < mc:
                m = mc + rng.expovariate(beta)
        else:
            m = mc + rng.expovariate(beta)
        mags.append(m)
    return {"magnitudes": mags, "n": n_events, "b": b_value, "mc": mc,
            "repeat_fraction": repeat_fraction}


if __name__ == "__main__":
    mcp.run(transport="stdio")

"""USGS ComCat catalog retrieval tools.

Provides a runnable USGS earthquake catalog fetcher and a local-CSV
loader so the analysis can proceed offline using a pre-bundled catalog.
"""
from __future__ import annotations
import csv
import datetime as dt
import json
import time
import urllib.request
from typing import Optional

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Earthquake_Catalog_Retrieval")


@mcp.tool()
def fetch_usgs_comcat(
    starttime: str,
    endtime: str,
    minmagnitude: float = 0.0,
    minlatitude: float = -90.0,
    maxlatitude: float = 90.0,
    minlongitude: float = -180.0,
    maxlongitude: float = 180.0,
    out_csv: Optional[str] = None,
    chunk_days: int = 30,
    allow_network: bool = False,
) -> dict:
    """Fetch events from the USGS FDSN earthquake catalog in monthly chunks.

    OFFLINE BY DEFAULT. This task ships the complete southern-California
    catalog in input_data/data/socal_catalog.csv; use `load_catalog_csv`
    on that file for a fully offline, deterministic run. This fetcher is
    provided only to document how the bundled catalog was produced and is
    DISABLED unless `allow_network=True` is passed explicitly, so the task
    does not depend on external network access.

    The USGS API caps each request at 20,000 events, so the time window is split
    into chunks (default 30 days each) to support multi-decade queries.

    Args:
        starttime: ISO date "YYYY-MM-DD" (inclusive lower bound).
        endtime: ISO date "YYYY-MM-DD" (exclusive upper bound).
        minmagnitude: minimum magnitude filter.
        minlatitude/maxlatitude/minlongitude/maxlongitude: bounding box.
        out_csv: optional path to write the catalog CSV.
        chunk_days: chunk length in days for paged downloads.
        allow_network: must be True to perform live HTTP requests; defaults
            to False so the task is offline-deterministic.

    Returns:
        dict with row count and (if requested) the path to the CSV.
    """
    if not allow_network:
        return {"error": "network disabled (offline-deterministic default); "
                         "use load_catalog_csv on the bundled "
                         "input_data/data/socal_catalog.csv, or pass "
                         "allow_network=True to fetch live from USGS.",
                "n_rows": 0}
    rows: list[dict] = []
    cur = dt.date.fromisoformat(starttime)
    end = dt.date.fromisoformat(endtime)
    while cur < end:
        nxt = cur + dt.timedelta(days=chunk_days)
        if nxt > end:
            nxt = end
        url = (
            "https://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson"
            f"&starttime={cur.isoformat()}&endtime={nxt.isoformat()}"
            f"&minlatitude={minlatitude}&maxlatitude={maxlatitude}"
            f"&minlongitude={minlongitude}&maxlongitude={maxlongitude}"
            f"&minmagnitude={minmagnitude}&orderby=time-asc"
        )
        try:
            req = urllib.request.urlopen(url, timeout=60)
            data = json.loads(req.read().decode())
            for f in data.get("features", []):
                p = f["properties"]; g = f["geometry"]
                t_ms = p.get("time")
                if t_ms is None:
                    continue
                rows.append({
                    "time": dt.datetime.fromtimestamp(t_ms / 1000, tz=dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S"),
                    "longitude": round(g["coordinates"][0], 5),
                    "latitude": round(g["coordinates"][1], 5),
                    "depth_km": g["coordinates"][2],
                    "magnitude": p.get("mag"),
                    "magtype": p.get("magType") or "",
                    "id": f.get("id", ""),
                })
        except Exception as e:
            return {"error": f"fetch failed at {cur}..{nxt}: {e}", "n_rows": len(rows)}
        cur = nxt
        time.sleep(0.15)

    result = {"n_rows": len(rows), "first_time": rows[0]["time"] if rows else None,
              "last_time": rows[-1]["time"] if rows else None}
    if out_csv and rows:
        with open(out_csv, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader(); w.writerows(rows)
        result["csv_path"] = out_csv
    return result


@mcp.tool()
def load_catalog_csv(csv_path: str) -> dict:
    """Load a previously-saved earthquake catalog CSV.

    Args:
        csv_path: path to the CSV.

    Returns:
        dict with column list, total row count, magnitude range, time range,
        and the first 30 rows for inspection.
    """
    with open(csv_path) as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    if not rows:
        return {"n_rows": 0, "error": "empty catalog"}

    mags = [float(r["magnitude"]) for r in rows if r.get("magnitude") not in ("", None)]
    times = [r["time"] for r in rows if r.get("time")]
    return {
        "columns": list(rows[0].keys()),
        "n_rows": len(rows),
        "magnitude_min": round(min(mags), 2) if mags else None,
        "magnitude_max": round(max(mags), 2) if mags else None,
        "time_first": times[0] if times else None,
        "time_last": times[-1] if times else None,
        "preview": rows[:30],
    }


@mcp.tool()
def filter_catalog(
    csv_path: str,
    out_csv: str,
    min_magnitude: Optional[float] = None,
    max_magnitude: Optional[float] = None,
    starttime: Optional[str] = None,
    endtime: Optional[str] = None,
    bbox: Optional[list] = None,
) -> dict:
    """Filter a catalog CSV by magnitude, time, and/or bounding box.

    Args:
        csv_path: input CSV.
        out_csv: output CSV path.
        min_magnitude / max_magnitude: optional magnitude bounds.
        starttime / endtime: optional ISO datetime bounds.
        bbox: optional [minlat, maxlat, minlon, maxlon].

    Returns:
        dict with retained row count and output path.
    """
    with open(csv_path) as f:
        rows = list(csv.DictReader(f))
    out: list[dict] = []
    for r in rows:
        try:
            mag = float(r["magnitude"])
        except (TypeError, ValueError):
            continue
        if min_magnitude is not None and mag < min_magnitude:
            continue
        if max_magnitude is not None and mag > max_magnitude:
            continue
        if starttime and r["time"] < starttime:
            continue
        if endtime and r["time"] >= endtime:
            continue
        if bbox is not None:
            lat = float(r["latitude"]); lon = float(r["longitude"])
            if not (bbox[0] <= lat <= bbox[1] and bbox[2] <= lon <= bbox[3]):
                continue
        out.append(r)
    if out:
        with open(out_csv, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(out[0].keys()))
            w.writeheader(); w.writerows(out)
    return {"n_in": len(rows), "n_out": len(out), "csv_path": out_csv}


if __name__ == "__main__":
    mcp.run(transport="stdio")

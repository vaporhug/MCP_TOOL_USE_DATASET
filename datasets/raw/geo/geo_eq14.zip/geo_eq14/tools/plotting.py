"""Plotting primitives for the magnitude-clustering analysis.

One tool per output image. Each tool writes a PNG to disk and returns
the absolute file path.
"""
from __future__ import annotations
import os
from typing import Optional

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from mcp.server.fastmcp import FastMCP

# Reuse the SAME frequency-magnitude binning as the Mc/b-value estimators so the
# FMD figure and `mc_max_curvature` / `_fmd` agree exactly on where each bin
# (and hence the non-cumulative peak / Mc) sits. `_fmd` places bin CENTERS on
# the dm grid (e.g. 1.5, 1.6, ...) and assigns each magnitude to the nearest
# grid point via round(); a plain np.histogram with arange edges would instead
# offset the reported centers by dm/2, shifting the apparent peak/Mc.
from seismicity_analysis import _fmd

mcp = FastMCP("Magnitude_Clustering_Plots")


def _ensure_dir(path: str) -> str:
    d = os.path.dirname(os.path.abspath(path))
    if d:
        os.makedirs(d, exist_ok=True)
    return os.path.abspath(path)


@mcp.tool()
def plot_fmd_and_mc(magnitudes: list, mc: float, b_value: float,
                     out_png: str, dm: float = 0.1, title: str = "") -> dict:
    """Plot the cumulative and non-cumulative frequency-magnitude distribution
    with the estimated Mc and the GR fit overlaid.
    """
    mag_list = [float(m) for m in magnitudes if m is not None and m != ""]
    if not mag_list:
        return {"error": "empty"}
    mags = np.array(mag_list, dtype=float)
    # Identical binning to `_fmd` / `mc_max_curvature`: centers on the dm grid,
    # each magnitude assigned to the nearest grid point.
    centers_list, non_cum_list, cum_list = _fmd(mag_list, dm)
    centers = np.asarray(centers_list, dtype=float)
    non_cum = np.asarray(non_cum_list, dtype=float)
    cum = np.asarray(cum_list, dtype=float)

    fig, ax = plt.subplots(figsize=(7, 5))
    ax.semilogy(centers, np.maximum(non_cum, 0.5), "o", color="tab:blue", label="Non-cumulative", markersize=4)
    ax.semilogy(centers, np.maximum(cum, 0.5), "s", color="tab:red", label="Cumulative", markersize=4)
    # GR fit line (cumulative): N>=m = 10^(a - b*m), with a from intercept
    n_at_mc = np.sum(mags >= mc)
    if n_at_mc > 0:
        a = np.log10(n_at_mc) + b_value * mc
        m_grid = np.linspace(mc, mags.max(), 50)
        ax.semilogy(m_grid, 10 ** (a - b_value * m_grid), "k--",
                    label=f"GR fit: b = {b_value:.2f}")
    ax.axvline(mc, color="green", linestyle=":", label=f"Mc = {mc:.1f}")
    ax.set_xlabel("Magnitude"); ax.set_ylabel("Number of events")
    ax.set_title(title or "Frequency-magnitude distribution")
    ax.legend(loc="best"); ax.grid(True, which="both", alpha=0.3)
    out = _ensure_dir(out_png)
    fig.tight_layout(); fig.savefig(out, dpi=150); plt.close(fig)
    return {"path": out, "n_events": int(mags.size), "mc": mc, "b_value": b_value}


@mcp.tool()
def plot_delta_p_curve(centers: list, delta_p: list, sigma: list,
                        out_png: str, n_events: int, mc: float,
                        cumulative: bool = False, title: str = "") -> dict:
    """Plot the magnitude-clustering signature delta_P(m0) with 1-sigma
    error bars from the random-shuffle null model.

    The x-axis bins are at the analysis magnitude resolution of 0.1 (the
    `delta_p_curve` bin width; the raw ComCat catalog is reported to 0.01).
    delta_P is the full-domain-normalized real-minus-shuffled probability, so
    the curve crosses zero with the positive peak centered on m0 = 0.

    If cumulative=True, the input is interpreted as the cumulative
    delta_P(P(dm <= m0) - P(dm* <= m0)) curve.
    """
    centers = np.asarray(centers, dtype=float)
    dp = np.asarray(delta_p, dtype=float)
    sg = np.asarray(sigma, dtype=float)
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.errorbar(centers, dp, yerr=sg, fmt="o-", color="tab:red", capsize=2,
                markersize=3, linewidth=1, label=f"n = {n_events}, Mc = {mc:.1f}")
    ax.axhline(0, color="k", linewidth=0.8)
    ax.set_xlabel(r"$m_0$ (magnitude difference)")
    ylab = r"cumulative $\delta P(m_0)$" if cumulative else r"$\delta P(m_0)$"
    ax.set_ylabel(ylab)
    ax.set_title(title or "Magnitude-clustering signature")
    ax.legend(loc="best"); ax.grid(True, alpha=0.3)
    out = _ensure_dir(out_png)
    fig.tight_layout(); fig.savefig(out, dpi=150); plt.close(fig)
    return {"path": out, "n_points": int(centers.size),
            "max_delta_p": float(np.nanmax(dp)),
            "min_delta_p": float(np.nanmin(dp))}


@mcp.tool()
def plot_ecdf_grid(diff_from_mean_percent: list, out_png: str,
                    n_bins: int = 5, title: str = "") -> dict:
    """Plot the (ECDF(m_i), ECDF(m_{i+1})) 2-D heat map showing percent
    excess relative to the time-randomization (shuffled-order) null model
    produced by ecdf_2d_grid (Fig. 2A of the paper).
    """
    arr = np.asarray(diff_from_mean_percent, dtype=float)
    fig, ax = plt.subplots(figsize=(6, 5))
    vmax = max(abs(arr.min()), abs(arr.max()))
    # The input matrix is indexed [row=bin of m_i][col=bin of m_{i+1}], i.e.
    # row = the EARLIER event in each successive pair, col = the LATER event
    # (see ecdf_2d_grid: counts[bin_idx[i]][bin_idx[i+1]]). In imshow the first
    # array axis (rows) maps to the y-axis and the second axis (cols) to the
    # x-axis, so with origin="lower" the y-axis is ECDF(m_i) (earlier event)
    # and the x-axis is ECDF(m_{i+1}) (later event). Cell [0,0] is the
    # bottom-left (both events in the lowest-magnitude ECDF bin).
    im = ax.imshow(arr, origin="lower", extent=[0, 1, 0, 1],
                   cmap="RdBu_r", vmin=-vmax, vmax=vmax, aspect="equal")
    ax.plot([0, 1], [0, 1], "k--", linewidth=1)
    ax.set_xticks(np.linspace(0, 1, n_bins + 1))
    ax.set_yticks(np.linspace(0, 1, n_bins + 1))
    # x-axis = later event m_{i+1} (array columns); y-axis = earlier event m_i
    # (array rows). Labelled explicitly so the magnitude ordering is unambiguous.
    ax.set_xlabel(r"ECDF$(m_{i+1})$  (later event in pair)")
    ax.set_ylabel(r"ECDF$(m_i)$  (earlier event in pair)")
    ax.set_title(title or "ECDF successive-event matrix")
    cbar = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    cbar.set_label("Difference from time-randomized null (%)\n(red = excess, blue = deficit)")
    out = _ensure_dir(out_png)
    fig.tight_layout(); fig.savefig(out, dpi=150); plt.close(fig)
    return {"path": out, "max_excess_pct": float(arr.max()),
            "min_excess_pct": float(arr.min()),
            "diagonal_excess_pct": float(np.mean(np.diag(arr)))}


@mcp.tool()
def plot_real_vs_synthetic_delta_p(real_centers: list, real_delta_p: list,
                                     real_sigma: list,
                                     synthetic_curves: list, out_png: str,
                                     title: str = "") -> dict:
    """Compare the observed delta_P(m0) curve with a family of synthetic
    catalogs containing different repeat-fraction levels.

    Both the observed and synthetic curves are built at the analysis magnitude
    resolution of 0.1 (the `delta_p_curve` bin width, which also equals the
    `synthetic_with_repeats` repeat-noise sigma; the raw ComCat catalog is
    reported to 0.01).

    Args:
        real_centers, real_delta_p, real_sigma: observed curve.
        synthetic_curves: list of {"label": str, "centers": list,
            "delta_p": list, "repeat_fraction": float}.
        out_png: output PNG path.
    """
    real_c = np.asarray(real_centers, dtype=float)
    real_dp = np.asarray(real_delta_p, dtype=float)
    real_sg = np.asarray(real_sigma, dtype=float)
    fig, ax = plt.subplots(figsize=(8, 5.5))
    ax.errorbar(real_c, real_dp, yerr=real_sg, fmt="o", color="black",
                markersize=4, capsize=2, label="Observed (USGS SoCal)", zorder=5)
    cmap = plt.get_cmap("viridis")
    n_syn = max(len(synthetic_curves), 1)
    for k, s in enumerate(synthetic_curves):
        color = cmap(k / n_syn)
        ax.plot(s["centers"], s["delta_p"], "-", color=color, linewidth=1.6,
                label=f"synthetic, repeat = {s['repeat_fraction']*100:.0f}%")
    ax.axhline(0, color="k", linewidth=0.8)
    ax.set_xlabel(r"$m_0$ (magnitude difference)")
    ax.set_ylabel(r"$\delta P(m_0)$")
    ax.set_title(title or "Observed vs synthetic magnitude-clustering")
    ax.legend(loc="best", fontsize=9); ax.grid(True, alpha=0.3)
    out = _ensure_dir(out_png)
    fig.tight_layout(); fig.savefig(out, dpi=150); plt.close(fig)
    return {"path": out, "n_synthetic": len(synthetic_curves)}


if __name__ == "__main__":
    mcp.run(transport="stdio")

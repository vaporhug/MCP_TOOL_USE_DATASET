#!/usr/bin/env python3
"""Generic spatial flux data loaders (Excel, CSV) for soil GHG datasets.

Low-level primitives only: read sheets, list contents, melt/reshape.
No domain logic.
"""

import numpy as np
import pandas as pd
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Spatial_Flux_Data_Loaders")


@mcp.tool()
def list_excel_sheets(xlsx_path: str) -> dict:
    """List all sheet names and shapes in an .xlsx file.

    Args:
        xlsx_path: Path to .xlsx file.

    Returns:
        dict with sheet_names and per-sheet shape (rows, cols).
    """
    import openpyxl
    wb = openpyxl.load_workbook(xlsx_path, read_only=True, data_only=True)
    sheets = []
    for s in wb.sheetnames:
        df = pd.read_excel(xlsx_path, sheet_name=s)
        sheets.append({"name": s, "rows": int(df.shape[0]), "cols": int(df.shape[1]),
                       "columns": list(df.columns)[:30]})
    return {"path": xlsx_path, "sheet_names": wb.sheetnames, "sheets": sheets}


@mcp.tool()
def load_excel_sheet(xlsx_path: str, sheet_name: str, header: int = 0,
                     skiprows: int = 0, max_rows: int = 200) -> dict:
    """Load one sheet of an .xlsx file as records.

    Args:
        xlsx_path: Excel path.
        sheet_name: Name of sheet.
        header: Header row index (0-based).
        skiprows: Number of leading rows to skip.
        max_rows: Maximum returned rows.

    Returns:
        dict {columns, total_rows, rows (truncated)}.
    """
    df = pd.read_excel(xlsx_path, sheet_name=sheet_name, header=header,
                       skiprows=skiprows)
    rows = df.head(max_rows).to_dict("records")
    return {"sheet": sheet_name, "columns": list(df.columns),
            "total_rows": int(len(df)), "rows": rows,
            "truncated": len(df) > max_rows}


@mcp.tool()
def load_chamber_daily_flux(xlsx_path: str, sheet_name: str = "Data4",
                             node_count: int = 4, chambers_per_node: int = 5) -> dict:
    """Reshape an autochamber daily-flux sheet (Date col + chamber columns) into long format.

    The conservation-tillage Data4 sheet stores daily mean N2O flux with a
    multi-row header: row 0 = NodeX columns, row 1 = ChamberX labels.
    This tool drops the chamber-label row and renames columns NxCy.

    Args:
        xlsx_path: Excel path.
        sheet_name: Sheet to load (default Data4).
        node_count: Number of spatial nodes (default 4).
        chambers_per_node: Chambers per node (default 5).

    Returns:
        dict {chamber_ids, dates, fluxes (dict of chamber_id->list)}.
    """
    df_raw = pd.read_excel(xlsx_path, sheet_name=sheet_name, header=0)
    # First data row contains chamber labels; drop it
    df = df_raw.iloc[1:].copy().reset_index(drop=True)
    chamber_ids = [f"N{n}C{c}" for n in range(1, node_count + 1)
                   for c in range(1, chambers_per_node + 1)]
    df.columns = ["Date"] + chamber_ids
    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    df = df.dropna(subset=["Date"]).reset_index(drop=True)
    for c in chamber_ids:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    fluxes = {c: [None if pd.isna(v) else float(v) for v in df[c]] for c in chamber_ids}
    return {"chamber_ids": chamber_ids,
            "dates": [d.strftime("%Y-%m-%d") for d in df["Date"]],
            "n_dates": int(len(df)),
            "fluxes": fluxes}


@mcp.tool()
def load_chamber_grid_flux(xlsx_path: str, sheet_name: str = "Data4",
                           id_col: str = "Chamber location",
                           date_col: str = "Date") -> dict:
    """Load a long-format chamber sheet (one row per chamber x date) as records.

    Suitable for the conventional-tillage 2022 Data4 sheet that stores 18 chambers
    on a 50 x 50 m grid with chamber IDs like G08, H07, etc.

    Args:
        xlsx_path: Excel path.
        sheet_name: Sheet to load.
        id_col: Column with chamber IDs.
        date_col: Column with sampling date.

    Returns:
        dict {chamber_ids, dates, columns, rows}.
    """
    df = pd.read_excel(xlsx_path, sheet_name=sheet_name)
    df.columns = [c.strip() for c in df.columns]
    return {"chamber_ids": sorted(df[id_col].dropna().unique().tolist()),
            "dates": sorted(df[date_col].dropna().unique().tolist()),
            "columns": list(df.columns),
            "n_rows": int(len(df)),
            "rows": df.to_dict("records")}


@mcp.tool()
def join_chamber_classification(records: list, chamber_id_col: str,
                                cold_ids: list, hot_ids: list) -> dict:
    """Append a `flux_class` field (cold/hot/intermediate) to records.

    Args:
        records: list of dicts.
        chamber_id_col: Key in records that holds the chamber identifier.
        cold_ids: chamber IDs classified as consistent cold spots.
        hot_ids: chamber IDs classified as episodic hot spots.

    Returns:
        dict {records, n_cold, n_hot, n_intermediate}.
    """
    cold_set = set(cold_ids); hot_set = set(hot_ids)
    out = []
    nc = nh = ni = 0
    for r in records:
        cid = r.get(chamber_id_col)
        if cid in cold_set:
            cls = "cold"; nc += 1
        elif cid in hot_set:
            cls = "hot"; nh += 1
        else:
            cls = "intermediate"; ni += 1
        out.append({**r, "flux_class": cls})
    return {"records": out, "n_cold": nc, "n_hot": nh,
            "n_intermediate": ni}


@mcp.tool()
def column_summary(rows: list, columns: list) -> dict:
    """Per-column descriptive statistics for a list of dict records."""
    df = pd.DataFrame(rows)
    out = {}
    for c in columns:
        if c in df.columns:
            s = pd.to_numeric(df[c], errors="coerce").dropna()
            if len(s) == 0:
                out[c] = {"n": 0}
            else:
                out[c] = {
                    "n": int(len(s)),
                    "mean": round(float(s.mean()), 4),
                    "std": round(float(s.std()), 4),
                    "min": round(float(s.min()), 4),
                    "median": round(float(s.median()), 4),
                    "max": round(float(s.max()), 4),
                    "cv_pct": round(float(s.std() / s.mean() * 100), 2)
                                if s.mean() != 0 else None,
                }
    return out


if __name__ == "__main__":
    mcp.run(transport="stdio")

#!/usr/bin/env python3
"""Spatial / temporal variability primitives for soil GHG flux data.

Includes time-stability indices (MRD/SDRD), coefficient-of-variation,
empirical variogram, Moran's I autocorrelation, group t-tests, and
Pearson/Spearman correlations.
"""

import numpy as np
import pandas as pd
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Spatial_Variability_Tools")


@mcp.tool()
def time_stability_indices(daily_fluxes: dict) -> dict:
    """Compute Mean Relative Difference (MRD) and Standard Deviation of Relative
    Difference (SDRD) per chamber from a daily-flux dictionary.

    Relative difference at time t for chamber i is:
        rd_i(t) = (flux_i(t) - mean_t) / mean_t
    where mean_t is the spatial average across all chambers on day t.

    Args:
        daily_fluxes: dict mapping chamber_id -> list of daily fluxes
                      (None or NaN entries are tolerated).

    Returns:
        dict {chambers, mrd, sdrd, n_dates}.
    """
    df = pd.DataFrame(daily_fluxes)
    df = df.apply(pd.to_numeric, errors="coerce")
    spatial_mean = df.mean(axis=1)
    mrd = {}; sdrd = {}
    for c in df.columns:
        rd = (df[c] - spatial_mean) / spatial_mean
        rd = rd.replace([np.inf, -np.inf], np.nan).dropna()
        mrd[c] = round(float(rd.mean()), 4)
        sdrd[c] = round(float(rd.std()), 4)
    return {"chambers": list(df.columns), "mrd": mrd, "sdrd": sdrd,
            "n_dates": int(len(df))}


@mcp.tool()
def classify_hot_cold(mrd: dict, sdrd: dict, sdrd_cold_max: float = 0.4,
                     sdrd_hot_min: float = 0.8) -> dict:
    """Classify chambers as cold spots, hot spots, or intermediate using MRD/SDRD thresholds.

    Cold:  MRD < 0 AND SDRD < sdrd_cold_max
    Hot:   MRD > 0 AND SDRD > sdrd_hot_min
    Intermediate: everything else.

    Args:
        mrd: per-chamber MRD dict (from time_stability_indices).
        sdrd: per-chamber SDRD dict.
        sdrd_cold_max: SDRD upper bound for cold spots.
        sdrd_hot_min: SDRD lower bound for hot spots.

    Returns:
        dict {cold, hot, intermediate, n_cold, n_hot, n_int}.
    """
    cold, hot, inter = [], [], []
    for c in mrd:
        m, s = mrd[c], sdrd[c]
        if m < 0 and s < sdrd_cold_max:
            cold.append(c)
        elif m > 0 and s > sdrd_hot_min:
            hot.append(c)
        else:
            inter.append(c)
    return {"cold": sorted(cold), "hot": sorted(hot),
            "intermediate": sorted(inter),
            "n_cold": len(cold), "n_hot": len(hot), "n_int": len(inter),
            "thresholds": {"sdrd_cold_max": sdrd_cold_max,
                           "sdrd_hot_min": sdrd_hot_min}}


@mcp.tool()
def coefficient_of_variation(values: list) -> dict:
    """Compute mean, std, and CV (%) of a numeric list."""
    arr = np.array([v for v in values if v is not None and not (isinstance(v, float)
                                                                 and np.isnan(v))],
                   dtype=float)
    if len(arr) == 0 or arr.mean() == 0:
        return {"n": int(len(arr)), "mean": None, "std": None, "cv_pct": None}
    return {"n": int(len(arr)),
            "mean": round(float(arr.mean()), 6),
            "std": round(float(arr.std()), 6),
            "cv_pct": round(float(arr.std() / arr.mean() * 100), 2),
            "range_ratio": round(float(arr.max() / max(arr.min(), 1e-12)), 1)}


@mcp.tool()
def empirical_variogram(coords: list, values: list, n_lags: int = 10,
                        max_dist: float = None) -> dict:
    """Compute the omnidirectional empirical semivariogram of a 2-D point set.

    gamma(h) = 0.5 * mean( (z_i - z_j)^2 ) over pairs in lag bin h.

    Args:
        coords: list of [x, y] (or [lon, lat]) pairs.
        values: list of measured values, same length as coords.
        n_lags: number of distance bins.
        max_dist: maximum pair distance to consider (default = half max distance).

    Returns:
        dict {lag_centers, semivariance, n_pairs, sample_variance, range_estimate}.
    """
    pts = np.array(coords, dtype=float)
    z = np.array(values, dtype=float)
    mask = ~np.isnan(z)
    pts, z = pts[mask], z[mask]
    n = len(pts)
    if n < 4:
        return {"error": "need >= 4 valid points"}

    # All pairs
    diff = pts[:, None, :] - pts[None, :, :]
    dist = np.sqrt((diff ** 2).sum(axis=2))
    iu, ju = np.triu_indices(n, k=1)
    d_pairs = dist[iu, ju]
    sq_pairs = (z[iu] - z[ju]) ** 2

    if max_dist is None:
        max_dist = d_pairs.max() / 2.0
    edges = np.linspace(0, max_dist, n_lags + 1)
    centers = (edges[:-1] + edges[1:]) / 2

    gamma = []; npairs = []
    for k in range(n_lags):
        m = (d_pairs >= edges[k]) & (d_pairs < edges[k + 1])
        if m.sum() > 0:
            gamma.append(0.5 * float(sq_pairs[m].mean()))
            npairs.append(int(m.sum()))
        else:
            gamma.append(None); npairs.append(0)

    sample_var = float(z.var(ddof=1))
    # crude range = first lag where gamma >= 0.95 * sample_var
    rng_est = None
    for c, g in zip(centers, gamma):
        if g is not None and g >= 0.95 * sample_var:
            rng_est = float(c); break
    return {"lag_centers": [round(float(c), 3) for c in centers],
            "semivariance": [None if g is None else round(g, 6) for g in gamma],
            "n_pairs": npairs,
            "sample_variance": round(sample_var, 6),
            "range_estimate": rng_est}


@mcp.tool()
def morans_i(coords: list, values: list, threshold: float = None) -> dict:
    """Global Moran's I spatial autocorrelation using a binary distance kernel.

    Weights w_ij = 1 if 0 < d_ij <= threshold (default = median pair distance).

    Returns Moran's I, expected I (-1/(n-1)), z-score under randomization,
    and approximate two-tailed p-value.
    """
    pts = np.array(coords, dtype=float)
    z = np.array(values, dtype=float)
    mask = ~np.isnan(z)
    pts, z = pts[mask], z[mask]
    n = len(pts)
    if n < 4:
        return {"error": "need >= 4 valid points"}
    diff = pts[:, None, :] - pts[None, :, :]
    dist = np.sqrt((diff ** 2).sum(axis=2))
    if threshold is None:
        iu, ju = np.triu_indices(n, k=1)
        threshold = float(np.median(dist[iu, ju]))
    W = ((dist > 0) & (dist <= threshold)).astype(float)
    S0 = W.sum()
    if S0 == 0:
        return {"error": "no neighbours within threshold"}
    z_dev = z - z.mean()
    num = (W * np.outer(z_dev, z_dev)).sum()
    den = (z_dev ** 2).sum()
    I = (n / S0) * (num / den)
    EI = -1.0 / (n - 1)

    # Variance under randomization (Cliff & Ord)
    S1 = 0.5 * ((W + W.T) ** 2).sum()
    S2 = (((W.sum(axis=1) + W.sum(axis=0)) ** 2)).sum()
    b2 = (n * (z_dev ** 4).sum()) / ((z_dev ** 2).sum() ** 2)
    A = n * ((n ** 2 - 3 * n + 3) * S1 - n * S2 + 3 * S0 ** 2)
    B = b2 * ((n ** 2 - n) * S1 - 2 * n * S2 + 6 * S0 ** 2)
    C = (n - 1) * (n - 2) * (n - 3) * S0 ** 2
    var_I = (A - B) / max(C, 1e-12) - EI ** 2
    if var_I <= 0:
        z_score = 0.0; p = 1.0
    else:
        z_score = (I - EI) / np.sqrt(var_I)
        from scipy.stats import norm
        p = 2 * (1 - norm.cdf(abs(z_score)))
    return {"morans_I": round(float(I), 4), "expected_I": round(float(EI), 4),
            "variance_I": round(float(var_I), 8),
            "z_score": round(float(z_score), 4),
            "p_value": round(float(p), 6),
            "neighbour_threshold": round(float(threshold), 4),
            "n_points": n, "S0": round(float(S0), 2)}


@mcp.tool()
def group_t_test(values_a: list, values_b: list, equal_var: bool = False) -> dict:
    """Independent-samples t-test (default: Welch's, unequal variances)."""
    from scipy.stats import ttest_ind
    a = np.array([v for v in values_a if v is not None and not np.isnan(v)],
                 dtype=float)
    b = np.array([v for v in values_b if v is not None and not np.isnan(v)],
                 dtype=float)
    t, p = ttest_ind(a, b, equal_var=equal_var)
    return {"t_statistic": round(float(t), 4), "p_value": round(float(p), 8),
            "n_a": int(len(a)), "n_b": int(len(b)),
            "mean_a": round(float(a.mean()), 4),
            "mean_b": round(float(b.mean()), 4),
            "diff": round(float(b.mean() - a.mean()), 4),
            "significant_at_005": bool(p < 0.05)}


@mcp.tool()
def correlation(x_values: list, y_values: list) -> dict:
    """Pearson r and R^2 between two lists (drops NaNs pairwise)."""
    from scipy.stats import pearsonr, spearmanr
    x = np.array(x_values, dtype=float); y = np.array(y_values, dtype=float)
    m = ~(np.isnan(x) | np.isnan(y))
    x, y = x[m], y[m]
    if len(x) < 3:
        return {"error": "need >= 3 paired observations"}
    pr, pp = pearsonr(x, y); sr, sp = spearmanr(x, y)
    return {"pearson_r": round(float(pr), 4),
            "pearson_r2": round(float(pr ** 2), 4),
            "pearson_p": round(float(pp), 8),
            "spearman_rho": round(float(sr), 4),
            "spearman_p": round(float(sp), 8),
            "n": int(len(x))}


@mcp.tool()
def gini_coefficient(values: list) -> dict:
    """Gini coefficient G in [0,1] for a non-negative distribution.

    G = sum_i sum_j |x_i - x_j| / (2 * n^2 * mean(x))
    """
    arr = np.array([v for v in values if v is not None and not np.isnan(v)
                    and v >= 0], dtype=float)
    n = len(arr)
    if n < 2 or arr.mean() == 0:
        return {"error": "need >= 2 non-zero values"}
    diffs = np.abs(arr[:, None] - arr[None, :]).sum()
    g = diffs / (2.0 * n * n * arr.mean())
    return {"gini": round(float(g), 4), "n": n,
            "mean": round(float(arr.mean()), 6),
            "max_over_min": round(float(arr.max() / max(arr.min(), 1e-12)), 1)}


if __name__ == "__main__":
    mcp.run(transport="stdio")

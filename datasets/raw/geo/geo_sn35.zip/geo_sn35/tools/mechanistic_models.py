#!/usr/bin/env python3
"""Mechanistic and statistical model fitters for soil N2O / CO2 emissions:
  * Multiple linear regression with standardized coefficients
  * Hole-in-the-pipe style multiplicative model (NO3 x DOC x WFPS)
  * Threshold (broken-stick) regression for substrate-limitation tests
  * Partial-correlation matrix for SEM-style path analysis
"""

import numpy as np
import pandas as pd
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Mechanistic_Model_Tools")


@mcp.tool()
def standardized_linear_model(rows: list, predictors: list, response: str) -> dict:
    """Fit OLS y ~ z(predictors) on z-scored variables to get standardized betas.

    Args:
        rows: list of dict records.
        predictors: predictor column names.
        response: response column name.

    Returns:
        dict {coefficients (standardized), intercept, r2, p_values, n}.
    """
    from scipy import stats as sps
    df = pd.DataFrame(rows)
    cols = predictors + [response]
    df = df[cols].apply(pd.to_numeric, errors="coerce").dropna()
    if len(df) < len(predictors) + 2:
        return {"error": f"need at least {len(predictors)+2} valid rows, got {len(df)}"}
    Xz = (df[predictors] - df[predictors].mean()) / df[predictors].std(ddof=0)
    yz = (df[response] - df[response].mean()) / df[response].std(ddof=0)
    X = np.column_stack([np.ones(len(Xz)), Xz.values])
    beta, *_ = np.linalg.lstsq(X, yz.values, rcond=None)
    yhat = X @ beta
    resid = yz.values - yhat
    n, p = X.shape
    rss = (resid ** 2).sum(); tss = ((yz - yz.mean()) ** 2).sum()
    r2 = 1 - rss / tss
    sigma2 = rss / (n - p)
    cov = sigma2 * np.linalg.inv(X.T @ X)
    se = np.sqrt(np.diag(cov))
    t = beta / se
    pvals = 2 * (1 - sps.t.cdf(np.abs(t), df=n - p))
    return {"intercept": round(float(beta[0]), 4),
            "coefficients": {p_: round(float(b), 4)
                             for p_, b in zip(predictors, beta[1:])},
            "p_values": {p_: round(float(pv), 6)
                         for p_, pv in zip(predictors, pvals[1:])},
            "r_squared": round(float(r2), 4),
            "n": int(n)}


@mcp.tool()
def hip_multiplicative_fit(rows: list, no3_col: str, doc_col: str,
                           wfps_col: str, n2o_col: str) -> dict:
    """Fit a hole-in-the-pipe-style multiplicative model:
        log(N2O) = b0 + b_NO3*log(NO3) + b_DOC*log(DOC) + b_WFPS*log(WFPS)

    Returns power-law exponents and overall R^2 on log scale.
    """
    df = pd.DataFrame(rows)[[no3_col, doc_col, wfps_col, n2o_col]].apply(
        pd.to_numeric, errors="coerce").dropna()
    df = df[(df > 0).all(axis=1)]
    if len(df) < 8:
        return {"error": f"need >= 8 strictly-positive rows, got {len(df)}"}
    X = np.log(df[[no3_col, doc_col, wfps_col]].values)
    y = np.log(df[n2o_col].values)
    Xc = np.column_stack([np.ones(len(X)), X])
    beta, *_ = np.linalg.lstsq(Xc, y, rcond=None)
    yhat = Xc @ beta
    rss = ((y - yhat) ** 2).sum(); tss = ((y - y.mean()) ** 2).sum()
    return {"intercept": round(float(beta[0]), 4),
            "exponent_NO3": round(float(beta[1]), 4),
            "exponent_DOC": round(float(beta[2]), 4),
            "exponent_WFPS": round(float(beta[3]), 4),
            "log_r_squared": round(float(1 - rss / tss), 4),
            "n": int(len(df))}


@mcp.tool()
def threshold_response(x_values: list, y_values: list,
                       n_search: int = 50) -> dict:
    """Fit a 'broken-stick' two-segment regression: y = a + b1*x for x <= x*,
    y = a + b1*x* + b2*(x - x*) for x > x*. Searches over candidate breakpoints
    x* between the 10th and 90th percentile of x.

    Returns the best-fit threshold, segment slopes, and improvement in R^2 over
    a single linear fit.
    """
    x = np.array(x_values, dtype=float); y = np.array(y_values, dtype=float)
    m = ~(np.isnan(x) | np.isnan(y))
    x, y = x[m], y[m]
    if len(x) < 8:
        return {"error": "need >= 8 valid points"}

    def fit(b):
        x1 = np.minimum(x, b); x2 = np.maximum(x - b, 0)
        X = np.column_stack([np.ones(len(x)), x1, x2])
        coef, *_ = np.linalg.lstsq(X, y, rcond=None)
        yhat = X @ coef; rss = ((y - yhat) ** 2).sum()
        return coef, rss

    # Linear baseline
    Xlin = np.column_stack([np.ones(len(x)), x])
    cl, *_ = np.linalg.lstsq(Xlin, y, rcond=None)
    rss_lin = ((y - Xlin @ cl) ** 2).sum()

    bs = np.linspace(np.percentile(x, 10), np.percentile(x, 90), n_search)
    best = None
    for b in bs:
        coef, rss = fit(b)
        if best is None or rss < best[1]:
            best = (b, rss, coef)

    tss = ((y - y.mean()) ** 2).sum()
    r2_seg = 1 - best[1] / tss
    r2_lin = 1 - rss_lin / tss
    return {"threshold": round(float(best[0]), 4),
            "intercept": round(float(best[2][0]), 4),
            "slope_below": round(float(best[2][1]), 6),
            "slope_above": round(float(best[2][1] + best[2][2]), 6),
            "r2_threshold": round(float(r2_seg), 4),
            "r2_linear": round(float(r2_lin), 4),
            "delta_r2": round(float(r2_seg - r2_lin), 4),
            "n": int(len(x))}


@mcp.tool()
def partial_correlation_matrix(rows: list, columns: list) -> dict:
    """Compute the partial correlation between every column pair, controlling
    for all other listed columns. Useful as input to PLS-SEM style path analyses.

    Returns the partial correlation matrix and full Pearson matrix for context.
    """
    df = pd.DataFrame(rows)[columns].apply(pd.to_numeric, errors="coerce").dropna()
    if len(df) < len(columns) + 2:
        return {"error": f"need >= {len(columns)+2} rows"}
    cor = df.corr().values
    try:
        precision = np.linalg.inv(cor)
    except np.linalg.LinAlgError:
        return {"error": "covariance matrix is singular"}
    p = len(columns)
    pcor = np.zeros_like(cor)
    for i in range(p):
        for j in range(p):
            if i == j:
                pcor[i, j] = 1.0
            else:
                pcor[i, j] = -precision[i, j] / np.sqrt(precision[i, i] * precision[j, j])
    return {"columns": columns,
            "pearson_correlation": [[round(float(v), 4) for v in r] for r in cor],
            "partial_correlation": [[round(float(v), 4) for v in r] for r in pcor],
            "n": int(len(df))}


@mcp.tool()
def order_of_magnitude_range(values: list) -> dict:
    """Return min, max, and the max/min ratio of a positive series."""
    arr = np.array([v for v in values if v is not None and not np.isnan(v) and v > 0],
                   dtype=float)
    if len(arr) == 0:
        return {"error": "no positive values"}
    return {"min": round(float(arr.min()), 4),
            "max": round(float(arr.max()), 4),
            "max_min_ratio": round(float(arr.max() / arr.min()), 1),
            "log10_range": round(float(np.log10(arr.max() / arr.min())), 2),
            "n": int(len(arr))}


if __name__ == "__main__":
    mcp.run(transport="stdio")

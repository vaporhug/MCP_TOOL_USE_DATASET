# tools/ — FastMCP servers for geo_sn35

Four FastMCP tool servers exposing low-level primitives. None of them
contain task-specific or paper-specific logic; the agent must compose
them to reach the answer.

| File | Purpose |
|------|---------|
| `data_loading.py`        | Excel sheet listing/loading, autochamber wide-to-long reshape, chamber-class joining, per-column descriptive summaries. |
| `spatial_analysis.py`    | Time-stability indices (MRD, SDRD), hot/cold classification, coefficient of variation, omnidirectional empirical variogram, global Moran's I, group Welch t-test, Pearson/Spearman correlation, Gini coefficient. |
| `mechanistic_models.py`  | Standardized OLS, hole-in-the-pipe-style multiplicative power-law fit, broken-stick threshold regression, partial-correlation matrix, range / order-of-magnitude utility. |
| `plotting.py`            | Time-stability bar chart, cold-vs-hot grouped bars, seasonal trajectories, semivariogram plot, net-vs-gross scatter, field-map bubble plot. |

Each `*.py` file is a standalone FastMCP stdio server.
Run with:
```
python tools/data_loading.py
```
and connect the agent through the MCP protocol.

## Dependencies
```
numpy>=1.24
pandas>=2.0
openpyxl>=3.1
scipy>=1.11
matplotlib>=3.7
mcp[cli]>=1.0
```

Install with:
```
pip install numpy pandas openpyxl scipy matplotlib "mcp[cli]"
```

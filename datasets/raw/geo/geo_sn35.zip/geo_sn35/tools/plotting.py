#!/usr/bin/env python3
"""Plotting primitives for soil greenhouse-gas spatial-variability analysis.

All plots write a PNG to disk and return its absolute path.
"""

import os
import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Spatial_Flux_Plotting")


@mcp.tool()
def plot_time_stability(mrd: dict, sdrd: dict, sdrd_cold_max: float, sdrd_hot_min: float,
                         out_path: str, title: str = "Time stability of N2O fluxes") -> dict:
    """Two-panel bar chart of MRD (top) and SDRD (bottom) sorted by SDRD.

    Bars are colored: blue = cold spot, red = hot spot, gray = intermediate.
    Dashed lines mark the SDRD cold/hot thresholds.

    Returns dict {path}.
    """
    chambers = list(mrd.keys())
    sdrd_vals = np.array([sdrd[c] for c in chambers])
    order = np.argsort(sdrd_vals)
    chambers = [chambers[i] for i in order]
    mrd_vals = [mrd[c] for c in chambers]
    sdrd_vals = [sdrd[c] for c in chambers]
    colors = []
    for c in chambers:
        m, s = mrd[c], sdrd[c]
        if m < 0 and s < sdrd_cold_max: colors.append("steelblue")
        elif m > 0 and s > sdrd_hot_min: colors.append("firebrick")
        else: colors.append("lightgray")

    fig, axes = plt.subplots(2, 1, figsize=(10, 6), sharex=True)
    axes[0].bar(chambers, mrd_vals, color=colors, edgecolor="black", linewidth=0.5)
    axes[0].axhline(0, color="black", lw=0.7)
    axes[0].set_ylabel("MRD")
    axes[0].set_title(title)
    axes[1].bar(chambers, sdrd_vals, color=colors, edgecolor="black", linewidth=0.5)
    axes[1].axhline(sdrd_cold_max, ls="--", color="black", lw=0.7,
                    label=f"cold SDRD<{sdrd_cold_max}")
    axes[1].axhline(sdrd_hot_min, ls="--", color="black", lw=0.7,
                    label=f"hot SDRD>{sdrd_hot_min}")
    axes[1].set_ylabel("SDRD")
    axes[1].set_xlabel("Chamber")
    axes[1].tick_params(axis="x", rotation=45)
    axes[1].legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": os.path.abspath(out_path)}


@mcp.tool()
def plot_cold_vs_hot_properties(rows: list, group_col: str, value_cols: list,
                                 out_path: str,
                                 title: str = "Soil properties by N2O flux class") -> dict:
    """Grouped bar chart comparing mean (+/- 1 SE) of value_cols between groups in group_col.
    """
    df = pd.DataFrame(rows)
    groups = sorted(df[group_col].dropna().unique())
    n_vars = len(value_cols)
    fig, axes = plt.subplots(1, n_vars, figsize=(3.2 * n_vars, 4))
    if n_vars == 1: axes = [axes]
    palette = {"cold": "steelblue", "hot": "firebrick", "intermediate": "lightgray"}
    for ax, var in zip(axes, value_cols):
        means = []; ses = []
        for g in groups:
            s = pd.to_numeric(df[df[group_col] == g][var], errors="coerce").dropna()
            means.append(float(s.mean()))
            ses.append(float(s.std() / np.sqrt(max(len(s), 1))))
        colors = [palette.get(g, "gray") for g in groups]
        ax.bar(groups, means, yerr=ses, color=colors, edgecolor="black",
               capsize=4)
        ax.set_title(var, fontsize=9)
        ax.tick_params(axis="x", rotation=15)
    fig.suptitle(title)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": os.path.abspath(out_path)}


@mcp.tool()
def plot_seasonal_n2o(rows: list, date_col: str, group_col: str,
                       value_col: str, out_path: str,
                       title: str = "Seasonal N2O production trajectories") -> dict:
    """Line plot of value_col over time, separate panels per group, one line per chamber."""
    df = pd.DataFrame(rows)
    df[date_col] = df[date_col].astype(str)
    groups = sorted(df[group_col].dropna().unique())
    fig, axes = plt.subplots(1, len(groups), figsize=(4.5 * len(groups), 4),
                              sharey=True)
    if len(groups) == 1: axes = [axes]
    palette = {"cold": "steelblue", "hot": "firebrick", "intermediate": "lightgray"}
    for ax, g in zip(axes, groups):
        sub = df[df[group_col] == g]
        for cid, c_grp in sub.groupby("ChamberID"):
            ax.plot(c_grp[date_col], pd.to_numeric(c_grp[value_col], errors="coerce"),
                    "o-", color=palette.get(g, "gray"), alpha=0.6, linewidth=1)
        ax.set_title(f"{g} (n_chambers={sub['ChamberID'].nunique()})")
        ax.set_xlabel("Sampling date")
        ax.tick_params(axis="x", rotation=30)
    axes[0].set_ylabel(value_col)
    fig.suptitle(title)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": os.path.abspath(out_path)}


@mcp.tool()
def plot_variogram(lag_centers: list, semivariance: list, sample_variance: float,
                    out_path: str, title: str = "Empirical semivariogram") -> dict:
    """Plot semivariance vs lag distance with sill (sample variance) line."""
    fig, ax = plt.subplots(figsize=(6.5, 4.5))
    ax.plot(lag_centers, semivariance, "o-", color="darkorange", lw=1.5,
            markersize=7, markeredgecolor="black")
    ax.axhline(sample_variance, ls="--", color="black", lw=1,
               label=f"sample variance = {sample_variance:.3g}")
    ax.set_xlabel("Lag distance")
    ax.set_ylabel("Semivariance gamma(h)")
    ax.set_title(title)
    ax.legend()
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": os.path.abspath(out_path)}


@mcp.tool()
def plot_net_vs_gross(net_values: list, gross_values: list, out_path: str,
                       r2: float = None,
                       title: str = "Net vs gross N2O production") -> dict:
    """Scatter of net vs gross N2O production with 1:1 line."""
    fig, ax = plt.subplots(figsize=(5.5, 5.5))
    ax.scatter(gross_values, net_values, c="purple", alpha=0.6,
               edgecolor="black", s=30)
    lo = min(min(gross_values), min(net_values))
    hi = max(max(gross_values), max(net_values))
    ax.plot([lo, hi], [lo, hi], "k--", lw=1, label="1:1")
    ax.set_xlabel("Gross N2O production (umol m-2 d-1)")
    ax.set_ylabel("Net N2O flux (umol m-2 d-1)")
    if r2 is not None:
        ax.text(0.05, 0.95, f"R² = {r2:.3f}", transform=ax.transAxes,
                ha="left", va="top",
                bbox=dict(boxstyle="round", facecolor="white"))
    ax.set_title(title)
    ax.legend()
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": os.path.abspath(out_path)}


@mcp.tool()
def plot_field_map(coords: list, values: list, labels: list, out_path: str,
                    title: str = "Spatial map of chamber values",
                    cmap: str = "RdYlBu_r") -> dict:
    """Bubble map of point measurements colored by value."""
    pts = np.array(coords, dtype=float); vals = np.array(values, dtype=float)
    fig, ax = plt.subplots(figsize=(6.5, 5.5))
    sc = ax.scatter(pts[:, 0], pts[:, 1], c=vals, s=200, cmap=cmap,
                     edgecolor="black", linewidth=0.7)
    for (x, y), lab in zip(pts, labels):
        ax.text(x, y, str(lab), fontsize=7, ha="center", va="center")
    ax.set_xlabel("X (m)")
    ax.set_ylabel("Y (m)")
    ax.set_title(title)
    fig.colorbar(sc, ax=ax, label="value")
    ax.set_aspect("equal", adjustable="datalim")
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": os.path.abspath(out_path)}


if __name__ == "__main__":
    mcp.run(transport="stdio")

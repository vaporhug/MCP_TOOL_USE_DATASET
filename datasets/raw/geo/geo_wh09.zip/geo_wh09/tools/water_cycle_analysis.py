#!/usr/bin/env python3
"""Water cycle non-stationarity analysis tools.

Low-level primitives for testing monotonic trends, ranking regions, and
classifying hotspot behaviour across water-cycle variables (terrestrial
water storage, evapotranspiration, runoff, gross primary production,
precipitation). All functions operate on regional annual anomaly time
series passed as plain python lists.

Plot helpers produce PNG files under an output directory and return the
absolute path so downstream answer items can cite them.
"""

from __future__ import annotations

import os
from typing import Any

import numpy as np
import pandas as pd
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Water_Cycle_NSI_Tools")


# ---------------------------------------------------------------------------
# 1. Data loading
# ---------------------------------------------------------------------------

@mcp.tool()
def load_hotspot_timeseries(csv_path: str) -> dict:
    """Load a hotspot-region annual anomaly CSV from the Johns Hopkins
    repository (files 09-13, doi:10.7281/T1/KOTDPY).

    The file layout is a two-row header (variable label, year) and one
    row per region labelled ``region N`` for N in 1..20. Returns a
    nested dict ``{region_name: {year: value}}`` plus the sorted year
    list.

    Args:
        csv_path: Path to one of the region time-series CSVs.

    Returns:
        dict with keys ``variable``, ``years``, ``regions``, ``data``.
    """
    df = pd.read_csv(csv_path, header=[0, 1], index_col=0)
    variable = str(df.columns.get_level_values(0)[0])
    years = [int(y) for y in df.columns.get_level_values(1)]
    data = {}
    for r in df.index:
        vals = [float(v) for v in df.loc[r].values]
        data[str(r)] = dict(zip(years, vals))
    return {
        "variable": variable,
        "years": years,
        "regions": [str(r) for r in df.index],
        "n_regions": int(len(df.index)),
        "data": data,
    }


@mcp.tool()
def extract_region_series(loaded: dict, region: str) -> dict:
    """Return the year-ordered value list for one region from a loaded
    CSV dict (as produced by ``load_hotspot_timeseries``).

    Args:
        loaded: The output of load_hotspot_timeseries.
        region: Region key (e.g. "region 5").

    Returns:
        dict with ``years`` and ``values`` aligned by index.
    """
    years = loaded["years"]
    data = loaded["data"][region]
    values = [float(data[y]) for y in years]
    return {"region": region, "years": years, "values": values}


# ---------------------------------------------------------------------------
# 2. Trend statistics (Theil-Sen + Mann-Kendall)
# ---------------------------------------------------------------------------

@mcp.tool()
def theil_sen_slope(values: list, x: list | None = None) -> dict:
    """Compute the Theil-Sen slope (median of pairwise slopes) of a
    time series. This is the ``TR`` estimator used in the paper's
    non-stationarity index (Eq. 4 pipeline).

    Args:
        values: y-values ordered in time.
        x: Optional x-values (default: integer index 0..n-1).

    Returns:
        dict with ``slope``, ``intercept``, ``slope_lo95``, ``slope_hi95``.
    """
    from scipy.stats import theilslopes

    y = np.asarray(values, dtype=float)
    if x is None:
        x_arr = np.arange(len(y), dtype=float)
    else:
        x_arr = np.asarray(x, dtype=float)
    mask = ~(np.isnan(x_arr) | np.isnan(y))
    slope, intercept, lo, hi = theilslopes(y[mask], x_arr[mask])
    return {
        "slope": float(slope),
        "intercept": float(intercept),
        "slope_lo95": float(lo),
        "slope_hi95": float(hi),
        "n_points": int(mask.sum()),
    }


@mcp.tool()
def mann_kendall(values: list, alpha: float = 0.05) -> dict:
    """Original Mann-Kendall monotonic-trend test (two-sided). No tie
    correction (paper uses ``pymannkendall.original_test``). Returns the
    MK S statistic, z score, p-value, classification and the Theil-Sen
    slope.

    Args:
        values: y-values ordered in time.
        alpha: Significance threshold for the 'trend' label.

    Returns:
        dict with keys ``S``, ``z``, ``p``, ``trend``, ``sens_slope``.
    """
    from scipy.stats import norm, theilslopes

    y = np.asarray(values, dtype=float)
    y = y[~np.isnan(y)]
    n = len(y)
    s = 0
    for i in range(n - 1):
        for j in range(i + 1, n):
            d = y[j] - y[i]
            if d > 0:
                s += 1
            elif d < 0:
                s -= 1
    var_s = n * (n - 1) * (2 * n + 5) / 18.0
    if s > 0:
        z = (s - 1) / np.sqrt(var_s)
    elif s < 0:
        z = (s + 1) / np.sqrt(var_s)
    else:
        z = 0.0
    p = 2 * (1 - norm.cdf(abs(z)))
    if p < alpha:
        trend = "increasing" if s > 0 else "decreasing"
    else:
        trend = "no significant trend"
    slope, intercept, _, _ = theilslopes(y, np.arange(n))
    return {
        "S": int(s),
        "z": float(z),
        "p": float(p),
        "trend": trend,
        "sens_slope": float(slope),
        "intercept": float(intercept),
        "n": int(n),
        "alpha": alpha,
    }


@mcp.tool()
def batch_region_trends(loaded: dict, alpha: float = 0.05) -> dict:
    """Run Mann-Kendall + Theil-Sen for every region in a loaded CSV
    dict. Returns per-region slopes and a summary partition into
    (significant negative, significant positive, non-significant)
    buckets.

    Args:
        loaded: output of ``load_hotspot_timeseries``.
        alpha: significance threshold.

    Returns:
        dict with ``results`` (list per region) and ``summary``.
    """
    out = []
    neg_sig, pos_sig, non_sig = [], [], []
    for r in loaded["regions"]:
        s = extract_region_series(loaded, r)
        res = mann_kendall(s["values"], alpha=alpha)
        rec = {"region": r, **res}
        out.append(rec)
        if res["p"] < alpha:
            if res["sens_slope"] < 0:
                neg_sig.append(r)
            else:
                pos_sig.append(r)
        else:
            non_sig.append(r)
    slopes = np.array([o["sens_slope"] for o in out])
    return {
        "variable": loaded["variable"],
        "alpha": alpha,
        "results": out,
        "summary": {
            "n_significant_negative": len(neg_sig),
            "n_significant_positive": len(pos_sig),
            "n_non_significant": len(non_sig),
            "significant_negative_regions": neg_sig,
            "significant_positive_regions": pos_sig,
            "non_significant_regions": non_sig,
            "min_slope": float(slopes.min()),
            "max_slope": float(slopes.max()),
            "median_slope": float(np.median(slopes)),
        },
    }


# ---------------------------------------------------------------------------
# 3. Change-point detection + extreme-frequency ratio
# ---------------------------------------------------------------------------

@mcp.tool()
def detect_change_point(values: list, n_breaks: int = 1) -> dict:
    """Binary-segmentation change-point detector (l2 cost). The paper
    applies this to the z-score binary indicator of the decomposed
    remainder time series; this helper runs the same algorithm on an
    arbitrary numeric series.

    Args:
        values: numeric series.
        n_breaks: number of break points to locate.

    Returns:
        dict with break indices, series length.
    """
    try:
        import ruptures as rpt
    except ImportError:
        return {"error": "ruptures not installed (pip install ruptures)"}
    y = np.asarray(values, dtype=float)
    if np.isnan(y).any():
        return {"error": "NaN values present"}
    algo = rpt.Binseg(model="l2").fit(y)
    bkps = algo.predict(n_bkps=n_breaks)
    return {"break_indices": bkps, "n_points": int(len(y)), "n_breaks": n_breaks}


@mcp.tool()
def extreme_frequency_ratio(values: list, z_threshold: float = 1.0) -> dict:
    """Compute the extreme-frequency ratio (EFR) metric from the paper.

    Given a series, we:
      1. convert to z-scores (absolute value);
      2. binarise by |z| > z_threshold (1 = extreme, 0 = normal);
      3. detect one change point with binary segmentation;
      4. return the ratio of extreme-event frequency AFTER the change
         point to that BEFORE.

    Args:
        values: numeric series (paper uses the RobustSTL residual).
        z_threshold: absolute z-score threshold for 'extreme' (default 1.0).

    Returns:
        dict with ``efr`` (post/pre ratio), ``cp_index``, counts.
    """
    try:
        import ruptures as rpt
    except ImportError:
        return {"error": "ruptures not installed"}
    y = np.asarray(values, dtype=float)
    z = np.abs((y - np.nanmean(y)) / np.nanstd(y))
    binary = (z > z_threshold).astype(int)
    algo = rpt.Binseg(model="l2").fit(binary)
    bkps = algo.predict(n_bkps=1)
    cp = bkps[0]
    before = binary[:cp]
    after = binary[cp:]
    freq_before = before.mean() if len(before) > 0 else np.nan
    freq_after = after.mean() if len(after) > 0 else np.nan
    efr = float(freq_after / freq_before) if freq_before > 0 else float("inf")
    return {
        "cp_index": int(cp),
        "freq_before": float(freq_before),
        "freq_after": float(freq_after),
        "efr": efr,
        "n_before": int(len(before)),
        "n_after": int(len(after)),
    }


# ---------------------------------------------------------------------------
# 4. Seasonal shift (circular-mean pipeline)
# ---------------------------------------------------------------------------

@mcp.tool()
def circular_mean_angle(positions: list, cycle_length: int) -> dict:
    """Circular-mean direction used by the paper's seasonal-shift
    metric (Eq. 5-6). Projects day-of-year style positions onto the
    unit circle and returns the mean angle plus its day-of-year form.

    Args:
        positions: list of integer positions (1..cycle_length) per cycle.
        cycle_length: length of one seasonal cycle (e.g., 52 for weeks).

    Returns:
        dict with mean angle (rad), mean position (index) and its fractional form.
    """
    pos = np.asarray(positions, dtype=float)
    theta = pos / cycle_length * 2 * np.pi
    C = np.cos(theta).sum()
    S = np.sin(theta).sum()
    if S > 0 and C >= 0:
        ang = np.arctan(S / C)
    elif C <= 0:
        ang = np.arctan(S / C) + np.pi
    else:
        ang = np.arctan(S / C) + 2 * np.pi
    idx = ang / (2 * np.pi) * cycle_length
    return {
        "mean_angle_rad": float(ang),
        "mean_position": float(idx),
        "n_cycles": int(len(pos)),
        "cycle_length": cycle_length,
    }


@mcp.tool()
def seasonal_shift_from_peaks(peak_positions: list, cycle_length: int) -> dict:
    """Seasonal-shift (SS) rate in days/year from a list of annual peak
    positions. Follows the paper's workflow: project each annual peak
    onto the unit circle, Theil-Sen slope over years, convert to days.

    Args:
        peak_positions: list of peak positions (index within each cycle).
        cycle_length: cycle length (e.g., 52 weeks or 365 days).

    Returns:
        dict with ``ss_rate_days_per_year`` and ``ss_trend_rad``.
    """
    from scipy.stats import theilslopes

    pos = np.asarray(peak_positions, dtype=float)
    theta = pos / cycle_length * 2 * np.pi
    n = len(theta)
    slope, intercept, lo, hi = theilslopes(theta, np.arange(n))
    # Paper Eq. 8: SS in days = 365/(2π) * |slope|^0.5 — retained as helper;
    # here we also give the linear-in-radians slope for transparency.
    ss_days = 365.0 / (2 * np.pi) * abs(slope) ** 0.5
    return {
        "ss_rad_per_year": float(slope),
        "ss_rate_days_per_year": float(ss_days),
        "n_years": int(n),
    }


# ---------------------------------------------------------------------------
# 5. Normalisation + Non-Stationarity Index (NSI)
# ---------------------------------------------------------------------------

@mcp.tool()
def percentile_rank(values: list, target: float) -> dict:
    """Return the percentile rank (0..1) of ``target`` within ``values``.
    Used by the paper to convert metric magnitudes into a globally
    comparable score.

    Args:
        values: reference distribution (e.g., global TR slopes).
        target: the metric value to be ranked.

    Returns:
        dict with ``percentile`` in [0,1] and the count strictly below.
    """
    v = np.asarray(values, dtype=float)
    v = v[~np.isnan(v)]
    if len(v) == 0:
        return {"percentile": None, "n": 0}
    below = (v < target).sum()
    pct = float(below) / float(len(v))
    return {"percentile": pct, "n": int(len(v))}


@mcp.tool()
def compute_nsi(tr_rank: float, ss_rank: float, efr_rank: float) -> dict:
    """Integrated Non-Stationarity Index (NSI) = mean of the three
    percentile ranks TR, SS, EFR (paper Eq. 12). Inputs must already be
    absolute-value percentile ranks in [0,1].

    Args:
        tr_rank: percentile rank of |Theil-Sen slope|.
        ss_rank: percentile rank of |seasonal-shift rate|.
        efr_rank: percentile rank of |log(EFR)|.

    Returns:
        dict with ``nsi`` and the dominant component label.
    """
    parts = {"TR": tr_rank, "SS": ss_rank, "EFR": efr_rank}
    nsi = float(np.mean([tr_rank, ss_rank, efr_rank]))
    dominant = max(parts, key=lambda k: parts[k])
    return {"nsi": nsi, "dominant": dominant, "components": parts}


# ---------------------------------------------------------------------------
# 6. Region classification
# ---------------------------------------------------------------------------

@mcp.tool()
def classify_regions_by_slope(batch_result: dict,
                              lower: float = -28.0,
                              upper: float = -8.0) -> dict:
    """Partition regions from a ``batch_region_trends`` result according
    to Theil-Sen slope thresholds. Defaults match the paper's
    ``-28 to -8 mm/yr`` negative-trend band for TWS.

    Args:
        batch_result: output of batch_region_trends.
        lower: lower bound of the band (inclusive).
        upper: upper bound of the band (inclusive).

    Returns:
        dict with lists of regions inside/outside the band.
    """
    inside, below, above = [], [], []
    for rec in batch_result["results"]:
        slope = rec["sens_slope"]
        if lower <= slope <= upper:
            inside.append(rec["region"])
        elif slope < lower:
            below.append(rec["region"])
        else:
            above.append(rec["region"])
    return {
        "band": [lower, upper],
        "inside_band": inside,
        "n_inside": len(inside),
        "below_band": below,
        "above_band": above,
    }


# ---------------------------------------------------------------------------
# 7. Plotting helpers (one function per answer image)
# ---------------------------------------------------------------------------

_REGION_NAMES = {
    1: "Central Canada", 2: "Missouri", 3: "Western US",
    4: "Texas Gulf & Central America", 5: "Lower Mississippi",
    6: "South America Eastern Highlands", 7: "La Plata",
    8: "Rio Negro & Central Patagonia",
    9: "South America Atlantic South Coast", 10: "North Africa",
    11: "Southern & Western Europe", 12: "Middle East & Central Asia",
    13: "Indus", 14: "Ganges", 15: "Tarim", 16: "High Mountain Asia",
    17: "Eastern China", 18: "Northern China", 19: "Eastern Russia",
    20: "Australia",
}


@mcp.tool()
def plot_region_trend_bars(batch_result: dict, output_path: str,
                           title: str | None = None,
                           ylabel: str = "Theil-Sen slope") -> dict:
    """Bar chart of per-region Theil-Sen slopes with a colour split
    between significant negative, significant positive and non-significant
    trends.

    Args:
        batch_result: output of batch_region_trends.
        output_path: PNG file to write.
        title: optional plot title (default uses variable name).
        ylabel: y-axis label.

    Returns:
        dict with ``path`` (absolute) and counts.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    recs = batch_result["results"]
    regions = [r["region"] for r in recs]
    slopes = [r["sens_slope"] for r in recs]
    ps = [r["p"] for r in recs]
    colors = []
    for s, p in zip(slopes, ps):
        if p < batch_result["alpha"]:
            colors.append("#c0392b" if s < 0 else "#2e86de")
        else:
            colors.append("#95a5a6")

    fig, ax = plt.subplots(figsize=(11, 4.5))
    x = np.arange(len(regions))
    ax.bar(x, slopes, color=colors, edgecolor="black", linewidth=0.4)
    ax.axhline(0, color="black", linewidth=0.6)
    labels = [f"{r}\n{_REGION_NAMES.get(int(r.split()[-1]), '')}"
              for r in regions]
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=75, fontsize=7)
    ax.set_ylabel(ylabel)
    ax.set_title(title or f"Per-region trends: {batch_result['variable']}")
    # legend
    from matplotlib.patches import Patch
    legend_elems = [
        Patch(facecolor="#c0392b", label="sig. negative"),
        Patch(facecolor="#2e86de", label="sig. positive"),
        Patch(facecolor="#95a5a6", label="not sig. (p>=alpha)"),
    ]
    ax.legend(handles=legend_elems, fontsize=8, loc="best")
    fig.tight_layout()
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {
        "path": os.path.abspath(output_path),
        "n_regions": len(regions),
        "variable": batch_result["variable"],
    }


@mcp.tool()
def plot_region_anomaly_timeseries(loaded: dict, regions: list,
                                   output_path: str,
                                   title: str | None = None) -> dict:
    """Line plot of annual anomaly series for a subset of regions with
    the Theil-Sen fit overlaid as dashed line. Useful for showing which
    regions have declining vs rising water storage.

    Args:
        loaded: output of load_hotspot_timeseries.
        regions: list of region keys to plot.
        output_path: PNG file to write.
        title: optional title.

    Returns:
        dict with ``path`` and regions plotted.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from scipy.stats import theilslopes

    years = np.array(loaded["years"], dtype=float)
    fig, ax = plt.subplots(figsize=(9, 5.2))
    cmap = plt.get_cmap("tab20")
    for i, r in enumerate(regions):
        vals = np.array([loaded["data"][r][int(y)] for y in years])
        label = f"{r} ({_REGION_NAMES.get(int(r.split()[-1]), '')})"
        ax.plot(years, vals, marker="o", markersize=3, linewidth=1.1,
                color=cmap(i % 20), label=label)
        slope, intercept, _, _ = theilslopes(vals, years)
        ax.plot(years, slope * years + intercept, linestyle="--",
                linewidth=0.9, color=cmap(i % 20), alpha=0.7)
    ax.axhline(0, color="black", linewidth=0.6)
    ax.set_xlabel("Year")
    ax.set_ylabel(f"{loaded['variable']} anomaly")
    ax.set_title(title or f"Regional anomaly series: {loaded['variable']}")
    ax.legend(fontsize=7, loc="best", ncol=1)
    fig.tight_layout()
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": os.path.abspath(output_path), "regions": list(regions)}


@mcp.tool()
def plot_classification_pie(batch_result: dict, output_path: str,
                            title: str | None = None) -> dict:
    """Pie chart of the three-way significance/direction partition
    (negative-sig, positive-sig, not-sig) for a batch-trend result.

    Args:
        batch_result: output of batch_region_trends.
        output_path: PNG file.
        title: optional title.

    Returns:
        dict with path and labels/values.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    summ = batch_result["summary"]
    sizes = [summ["n_significant_negative"],
             summ["n_significant_positive"],
             summ["n_non_significant"]]
    labels = ["sig. negative", "sig. positive", "not sig."]
    colors = ["#c0392b", "#2e86de", "#95a5a6"]
    fig, ax = plt.subplots(figsize=(6, 6))
    ax.pie(sizes, labels=labels, colors=colors,
           autopct=lambda v: f"{v:.0f}%",
           textprops={"fontsize": 11}, startangle=90)
    ax.set_title(title or f"Trend partition: {batch_result['variable']}")
    fig.tight_layout()
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": os.path.abspath(output_path),
            "labels": labels, "values": sizes}


@mcp.tool()
def plot_multivariable_heatmap(results_by_variable: dict, output_path: str,
                               title: str | None = None) -> dict:
    """Heat map of signed -log10(p)-scaled Theil-Sen slopes across
    (region x variable). ``results_by_variable`` is a dict mapping a
    short variable name to a ``batch_region_trends`` result.

    Args:
        results_by_variable: {label: batch_result}.
        output_path: PNG.
        title: optional.

    Returns:
        dict with path, shape, variable order.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    var_labels = list(results_by_variable.keys())
    any_res = next(iter(results_by_variable.values()))
    regions = [r["region"] for r in any_res["results"]]
    mat = np.full((len(regions), len(var_labels)), np.nan)
    for j, lbl in enumerate(var_labels):
        recs = {r["region"]: r for r in results_by_variable[lbl]["results"]}
        for i, reg in enumerate(regions):
            rec = recs.get(reg)
            if rec is None:
                continue
            sign = 1.0 if rec["sens_slope"] > 0 else -1.0
            mag = min(-np.log10(max(rec["p"], 1e-6)), 5.0)
            mat[i, j] = sign * mag
    fig, ax = plt.subplots(figsize=(1.5 + 0.8 * len(var_labels), 7.5))
    im = ax.imshow(mat, cmap="RdBu_r", vmin=-5, vmax=5, aspect="auto")
    ax.set_xticks(np.arange(len(var_labels)))
    ax.set_xticklabels(var_labels)
    labels = [f"{r} {_REGION_NAMES.get(int(r.split()[-1]), '')}"
              for r in regions]
    ax.set_yticks(np.arange(len(regions)))
    ax.set_yticklabels(labels, fontsize=7)
    fig.colorbar(im, ax=ax, label="sign x -log10(p)")
    ax.set_title(title or "Trend sign and significance (all variables)")
    fig.tight_layout()
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {
        "path": os.path.abspath(output_path),
        "shape": list(mat.shape),
        "variables": var_labels,
    }


if __name__ == "__main__":
    mcp.run(transport="stdio")

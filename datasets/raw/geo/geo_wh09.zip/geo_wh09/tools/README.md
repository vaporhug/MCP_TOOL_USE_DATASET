# geo_wh09 Tools

Low-level primitives for water-cycle non-stationarity analysis of the
20 hotspot regional time-series (2003-2020) provided in
`input_data/data/`.

## Files

- **`database_retrieval.py`** - external-lookup stubs (CrossRef / DOI
  resolver, fetch_url, websearch). Not required for the core pipeline.
- **`data_processing.py`** - generic CSV/JSON reshape, coercion and
  grouping helpers.
- **`water_cycle_analysis.py`** - domain module. Exposes 14 FastMCP
  tools covering:
    - `load_hotspot_timeseries`, `extract_region_series` - parse the
      two-row-header annual-anomaly CSVs.
    - `theil_sen_slope`, `mann_kendall`, `batch_region_trends` -
      monotonic-trend statistics aligning with the paper's
      `pymannkendall.original_test` usage (paper Eq. 4 pipeline).
    - `detect_change_point`, `extreme_frequency_ratio` - binary
      segmentation on z-score-binarised series (paper Eq. 9-11).
    - `circular_mean_angle`, `seasonal_shift_from_peaks` - projection of
      annual peak positions onto the unit circle and Theil-Sen slope in
      days/year (paper Eq. 5-8).
    - `percentile_rank`, `compute_nsi` - percentile-rank normalisation
      and the integrated NSI (paper Eq. 12).
    - `classify_regions_by_slope` - partition regions by Theil-Sen
      slope threshold band.
    - `plot_region_trend_bars`, `plot_region_anomaly_timeseries`,
      `plot_classification_pie`, `plot_multivariable_heatmap` - each
      produces one PNG used by the answer items.

## Dependencies

```
python>=3.10
numpy
pandas
scipy
matplotlib
pymannkendall
ruptures
mcp           # FastMCP tool server
```

Install with:
```
pip install numpy pandas scipy matplotlib pymannkendall ruptures mcp
```

## Usage

Run the FastMCP server:
```
python tools/water_cycle_analysis.py
```
Then connect any MCP-compatible client and call the registered tools.
All plot tools write a PNG to the supplied `output_path` and return
`{"path": <absolute path>, ...}` so the caller can cite them from an
answer.

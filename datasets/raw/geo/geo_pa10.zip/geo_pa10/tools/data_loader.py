#!/usr/bin/env python3
"""Generic CSV / Excel loaders and column inspection.

Low-level data primitives used to inspect Mg/Ca, CO3, temperature
proxy datasets without embedding any domain logic.
"""
import numpy as np
import pandas as pd
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Data_Loader_Tools")


@mcp.tool()
def load_csv(csv_path: str, filters: dict = None, max_preview_rows: int = 50) -> dict:
    """Load a CSV file, optionally filtering rows on equality.

    Args:
        csv_path: Absolute path to a CSV file.
        filters: Optional {column: value} equality filters.
        max_preview_rows: Number of rows to return in the preview.

    Returns:
        dict with columns, total_rows, dtypes, and a preview (first N rows).
    """
    df = pd.read_csv(csv_path)
    df.columns = [c.strip().lstrip("﻿") for c in df.columns]
    if filters:
        for col, val in filters.items():
            if col in df.columns:
                df = df[df[col] == val]
    return {
        "csv_path": csv_path,
        "columns": list(df.columns),
        "dtypes": {c: str(df[c].dtype) for c in df.columns},
        "total_rows": int(len(df)),
        "preview": df.head(max_preview_rows).to_dict("records"),
        "truncated": len(df) > max_preview_rows,
    }


@mcp.tool()
def load_excel(xlsx_path: str, sheet_name: str = None) -> dict:
    """Load an Excel file (first sheet by default).

    Args:
        xlsx_path: Absolute path to xlsx file.
        sheet_name: Optional sheet name.

    Returns:
        dict with columns, total_rows, and first 50 rows preview.
    """
    df = pd.read_excel(xlsx_path, sheet_name=sheet_name) if sheet_name else pd.read_excel(xlsx_path)
    df.columns = [c.strip().lstrip("﻿") for c in df.columns]
    return {
        "xlsx_path": xlsx_path,
        "sheet_name": sheet_name,
        "columns": list(df.columns),
        "total_rows": int(len(df)),
        "preview": df.head(50).to_dict("records"),
        "truncated": len(df) > 50,
    }


@mcp.tool()
def column_summary(csv_path: str, column: str) -> dict:
    """Summary statistics for a single numeric column.

    Args:
        csv_path: Absolute path to CSV.
        column: Column name (will strip BOM/whitespace).

    Returns:
        dict with count, mean, std, min, max, median, p10/p25/p75/p90.
    """
    df = pd.read_csv(csv_path)
    df.columns = [c.strip().lstrip("﻿") for c in df.columns]
    if column not in df.columns:
        return {"error": f"column '{column}' not in {list(df.columns)}"}
    arr = pd.to_numeric(df[column], errors="coerce").dropna().values
    if len(arr) == 0:
        return {"error": "no numeric values"}
    return {
        "column": column,
        "count": int(len(arr)),
        "mean": float(np.mean(arr)),
        "std": float(np.std(arr, ddof=1)),
        "min": float(np.min(arr)),
        "max": float(np.max(arr)),
        "median": float(np.median(arr)),
        "p10": float(np.percentile(arr, 10)),
        "p25": float(np.percentile(arr, 25)),
        "p75": float(np.percentile(arr, 75)),
        "p90": float(np.percentile(arr, 90)),
    }


@mcp.tool()
def concat_columns(csv_paths: list, column_pairs: list) -> dict:
    """Concatenate matching columns from multiple CSV files into one combined array.

    Args:
        csv_paths: List of CSV paths (e.g. pachyderma + incompta).
        column_pairs: List of column names to extract from each CSV — must have
            the same length as csv_paths. Each entry is the column to take from
            the corresponding CSV.

    Returns:
        dict with combined values and per-file lengths.
    """
    if len(csv_paths) != len(column_pairs):
        return {"error": "csv_paths and column_pairs must have same length"}
    chunks = []
    sizes = []
    for path, col in zip(csv_paths, column_pairs):
        df = pd.read_csv(path)
        df.columns = [c.strip().lstrip("﻿") for c in df.columns]
        if col not in df.columns:
            return {"error": f"column '{col}' not in {path}; columns={list(df.columns)}"}
        vals = pd.to_numeric(df[col], errors="coerce").dropna().values
        chunks.append(vals)
        sizes.append(int(len(vals)))
    combined = np.concatenate(chunks).tolist() if chunks else []
    return {
        "n_total": len(combined),
        "n_per_file": sizes,
        "values": combined,
    }


if __name__ == "__main__":
    mcp.run(transport="stdio")

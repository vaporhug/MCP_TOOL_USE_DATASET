#!/usr/bin/env python3
"""Generic regression and Monte-Carlo uncertainty propagation primitives.

These are domain-agnostic linear / log-linear / power-law fitters with
bootstrap-style uncertainty bounds. They are the building blocks that an
agent can chain to:
  - fit log(Mg/Ca) ~ CO3 (proxy normalisation),
  - fit log(Mg/Ca) ~ Temperature (Mg/Ca-T calibration),
  - fit power law Mg/Ca = A * x^k,
  - propagate measurement uncertainty into slope confidence intervals.
"""
import numpy as np
import pandas as pd
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Regression_Tools")


@mcp.tool()
def linear_regression(x_values: list, y_values: list) -> dict:
    """Ordinary least-squares y = m*x + c with R² and 95% CI on slope.

    Args:
        x_values: independent variable list.
        y_values: dependent variable list.

    Returns:
        dict with slope, intercept, r_squared, n, slope_se, slope_95ci.
    """
    x = np.array(x_values, dtype=float)
    y = np.array(y_values, dtype=float)
    mask = np.isfinite(x) & np.isfinite(y)
    x, y = x[mask], y[mask]
    n = int(len(x))
    if n < 3:
        return {"error": "need >=3 finite points"}
    slope, intercept = np.polyfit(x, y, 1)
    yhat = slope * x + intercept
    ss_res = float(np.sum((y - yhat) ** 2))
    ss_tot = float(np.sum((y - np.mean(y)) ** 2))
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else float("nan")
    # Slope standard error
    sx2 = float(np.sum((x - np.mean(x)) ** 2))
    sigma2 = ss_res / (n - 2) if n > 2 else float("nan")
    slope_se = float(np.sqrt(sigma2 / sx2)) if sx2 > 0 else float("nan")
    return {
        "slope": float(slope),
        "intercept": float(intercept),
        "r_squared": float(r2),
        "n": n,
        "slope_se": slope_se,
        "slope_95ci": [float(slope - 1.96 * slope_se), float(slope + 1.96 * slope_se)],
        "rmse": float(np.sqrt(ss_res / n)),
    }


@mcp.tool()
def log_linear_regression(x_values: list, y_values: list) -> dict:
    """Fit ln(y) = a + b*x  →  y = exp(a) * exp(b*x).

    Useful for thermal proxies where Mg/Ca ~ A * exp(B*T).

    Args:
        x_values: independent variable (e.g. temperature).
        y_values: positive dependent variable (e.g. Mg/Ca, mmol/mol).

    Returns:
        dict with b (= slope of ln(y) vs x), a (= intercept of ln(y)),
        prefactor exp(a), r_squared on log scale, n.
    """
    x = np.array(x_values, dtype=float)
    y = np.array(y_values, dtype=float)
    mask = np.isfinite(x) & np.isfinite(y) & (y > 0)
    x, y = x[mask], y[mask]
    n = int(len(x))
    if n < 3:
        return {"error": "need >=3 finite positive points"}
    ly = np.log(y)
    b, a = np.polyfit(x, ly, 1)
    yhat = a + b * x
    ss_res = float(np.sum((ly - yhat) ** 2))
    ss_tot = float(np.sum((ly - np.mean(ly)) ** 2))
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else float("nan")
    return {
        "b_slope_of_lnY": float(b),
        "a_intercept_of_lnY": float(a),
        "prefactor_exp_a": float(np.exp(a)),
        "model": "y = exp(a) * exp(b*x)",
        "r_squared_log": float(r2),
        "n": n,
    }


@mcp.tool()
def power_law_fit(x_values: list, y_values: list) -> dict:
    """Fit y = A * x^k via log-log linear regression.

    Args:
        x_values: positive independent variable.
        y_values: positive dependent variable.

    Returns:
        dict with A, k (= power-law exponent), r_squared, n, equation_string.
    """
    x = np.array(x_values, dtype=float)
    y = np.array(y_values, dtype=float)
    mask = np.isfinite(x) & np.isfinite(y) & (x > 0) & (y > 0)
    x, y = x[mask], y[mask]
    n = int(len(x))
    if n < 3:
        return {"error": "need >=3 finite positive points"}
    lx = np.log(x)
    ly = np.log(y)
    k, lnA = np.polyfit(lx, ly, 1)
    A = float(np.exp(lnA))
    yhat = lnA + k * lx
    ss_res = float(np.sum((ly - yhat) ** 2))
    ss_tot = float(np.sum((ly - np.mean(ly)) ** 2))
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else float("nan")
    return {
        "A": A,
        "k": float(k),
        "r_squared_log": float(r2),
        "n": n,
        "equation_string": f"y = {A:.4g} * x^{k:.4f}",
    }


@mcp.tool()
def monte_carlo_slope_uncertainty(
    x_values: list, y_values: list,
    x_sigma: float, y_sigma: float,
    n_iter: int = 1000, fit: str = "log-linear",
    seed: int = 1234,
) -> dict:
    """Bootstrap-style propagation of measurement uncertainty into the
    slope of a regression.

    For each of n_iter iterations, perturbs every (x_i, y_i) with Gaussian
    noise of given sigma and refits. Returns 14th/50th/86th percentiles
    (= 1σ band) and 2.5/97.5 (= 2σ band) of the resulting slopes/intercepts.

    Args:
        x_values: independent variable.
        y_values: dependent variable.
        x_sigma: 1σ measurement noise on x (absolute).
        y_sigma: 1σ measurement noise on y (relative for log-linear, absolute for linear).
        n_iter: Monte-Carlo iterations.
        fit: "linear" (y ~ x) or "log-linear" (ln(y) ~ x).
        seed: RNG seed for reproducibility.

    Returns:
        dict with slope/intercept percentiles and median best fit.
    """
    rng = np.random.default_rng(seed)
    x = np.array(x_values, dtype=float)
    y = np.array(y_values, dtype=float)
    mask = np.isfinite(x) & np.isfinite(y) & (y > 0 if fit == "log-linear" else np.ones_like(y, bool))
    x, y = x[mask], y[mask]
    n = len(x)
    slopes = []
    intercepts = []
    for _ in range(n_iter):
        x_p = x + rng.normal(0, x_sigma, n)
        if fit == "log-linear":
            # y_sigma is multiplicative (e.g. 0.025 = 2.5%)
            y_p = y + rng.normal(0, y * y_sigma, n)
            mok = y_p > 0
            if mok.sum() < 3:
                continue
            b, a = np.polyfit(x_p[mok], np.log(y_p[mok]), 1)
        else:
            y_p = y + rng.normal(0, y_sigma, n)
            b, a = np.polyfit(x_p, y_p, 1)
        slopes.append(b)
        intercepts.append(a)
    slopes = np.array(slopes)
    intercepts = np.array(intercepts)
    return {
        "fit": fit,
        "n_iter": int(n_iter),
        "slope_median": float(np.median(slopes)),
        "slope_p14": float(np.percentile(slopes, 14)),
        "slope_p86": float(np.percentile(slopes, 86)),
        "slope_p2_5": float(np.percentile(slopes, 2.5)),
        "slope_p97_5": float(np.percentile(slopes, 97.5)),
        "intercept_median": float(np.median(intercepts)),
        "intercept_p14": float(np.percentile(intercepts, 14)),
        "intercept_p86": float(np.percentile(intercepts, 86)),
    }


@mcp.tool()
def predict_from_calibration(
    a: float, b: float, x_values: list, model: str = "log-linear"
) -> dict:
    """Forward-predict y from a fitted calibration.

    Args:
        a: intercept of ln(y) (log-linear) or y (linear).
        b: slope on x.
        x_values: x values to evaluate.
        model: "log-linear" or "linear" or "power".

    Returns:
        dict with predicted y values.
    """
    x = np.array(x_values, dtype=float)
    if model == "log-linear":
        y = np.exp(a) * np.exp(b * x)
    elif model == "linear":
        y = a + b * x
    elif model == "power":
        y = np.exp(a) * np.power(x, b)
    else:
        return {"error": f"unknown model: {model}"}
    return {
        "x_values": x.tolist(),
        "y_predicted": y.tolist(),
        "model": model,
    }


@mcp.tool()
def correlation_test(x_values: list, y_values: list) -> dict:
    """Compute Pearson and Spearman correlations with p-values.

    Args:
        x_values: first variable.
        y_values: second variable.

    Returns:
        dict with pearson_r, pearson_p, spearman_rho, spearman_p, n.
    """
    from scipy.stats import pearsonr, spearmanr
    x = np.array(x_values, dtype=float)
    y = np.array(y_values, dtype=float)
    mask = np.isfinite(x) & np.isfinite(y)
    x, y = x[mask], y[mask]
    if len(x) < 3:
        return {"error": "need >=3 finite paired points"}
    pr, pp = pearsonr(x, y)
    sr, sp = spearmanr(x, y)
    return {
        "pearson_r": float(pr),
        "pearson_p": float(pp),
        "spearman_rho": float(sr),
        "spearman_p": float(sp),
        "n": int(len(x)),
    }


if __name__ == "__main__":
    mcp.run(transport="stdio")

#!/usr/bin/env python3
"""Generic plotting primitives for calibration figures.

These tools RENDER figures from data and (optionally) a pre-computed fit; they
do not read the calibration files, decide which regression to run, or return
any headline calibration coefficients. The caller is expected to:

  1. load the columns it wants (see ``data_loader.py``),
  2. compute any fit with the generic fitters in ``regression_tools.py``
     (``linear_regression``, ``log_linear_regression``, ``power_law_fit``,
     ``correlation_test``, ...),
  3. pass the raw scatter series — and, if a fit line is desired, the already
     computed fit parameters — to the plotting tool below.

This keeps the plotting layer free of domain conclusions: it takes computed
inputs and draws them. No final equation, coefficient, r², n, or scoring
target lives here.
"""
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import rcParams
from mcp.server.fastmcp import FastMCP

rcParams["font.family"] = "DejaVu Sans"
rcParams["font.size"] = 10

mcp = FastMCP("Proxy_Plotting_Tools")


def _curve(fit_model, params, x):
    """Evaluate a fit curve given a model name and parameter dict.

    Supported ``fit_model`` values and the keys they read from ``params``:

    * ``"power_law"``    : ``y = A * x**k``        -> keys ``A``, ``k``.
    * ``"log_linear"``   : ``y = exp(a) * exp(b*x)`` (a.k.a. multiplicative
                           exponential ``prefactor*exp(b*x)``) -> keys
                           ``a`` (or ``prefactor`` for ``exp(a)``) and ``b``.
    * ``"linear"``       : ``y = m*x + c``         -> keys ``m``/``slope`` and
                           ``c``/``intercept``.

    The model structure is generic; the numeric values come entirely from the
    caller's pre-computed fit.
    """
    x = np.asarray(x, dtype=float)
    if fit_model == "power_law":
        return params["A"] * np.power(x, params["k"])
    if fit_model == "log_linear":
        if "prefactor" in params:
            pref = params["prefactor"]
        else:
            pref = np.exp(params["a"])
        return pref * np.exp(params["b"] * x)
    if fit_model == "linear":
        m = params.get("m", params.get("slope"))
        c = params.get("c", params.get("intercept"))
        return m * x + c
    raise ValueError(f"unknown fit_model: {fit_model}")


@mcp.tool()
def plot_xy_series(
    out_path: str,
    series: list,
    x_label: str = "x",
    y_label: str = "y",
    title: str = "",
    fit_model: str = None,
    fit_params: dict = None,
    fit_label: str = "",
    annotation: str = "",
    xlim: list = None,
    ylim: list = None,
    log_x: bool = False,
    log_y: bool = False,
) -> dict:
    """Render a generic multi-series scatter plot, optionally with a fit line.

    This is a pure rendering primitive: it draws whatever (x, y) series the
    caller supplies and, if ``fit_model``/``fit_params`` are given, overlays
    the corresponding curve. It does NOT load data, choose a regression, or
    compute/return any coefficients — fit numbers must already have been
    produced by ``regression_tools`` and are passed in.

    Args:
        out_path: output PNG path.
        series: list of dicts, one per scatter series, each with keys
            ``"x"`` (list), ``"y"`` (list), and optional ``"label"``,
            ``"color"``, ``"marker"`` (default ``"o"``).
        x_label / y_label / title: axis labels and figure title.
        fit_model: one of ``"power_law"``, ``"log_linear"``, ``"linear"`` or
            ``None`` (no fit line). See :func:`_curve` for the structures.
        fit_params: dict of the caller's pre-computed fit parameters for
            ``fit_model`` (e.g. ``{"A": ..., "k": ...}``). Values are supplied
            by the caller; this tool never derives them.
        fit_label: legend label for the fit line (caller-formatted).
        annotation: optional text box drawn in the lower-left.
        xlim / ylim: optional ``[lo, hi]`` axis limits.
        log_x / log_y: optional log-scaled axes.

    Returns:
        dict with ``saved_path`` and the per-series finite-point counts. No
        fit coefficients are returned.
    """
    fig, ax = plt.subplots(figsize=(7, 5.2))
    default_colors = ["steelblue", "orange", "purple", "green", "firebrick"]
    counts = []
    xmins, xmaxs = [], []
    for idx, s in enumerate(series):
        x = np.asarray(s["x"], dtype=float)
        y = np.asarray(s["y"], dtype=float)
        m = np.isfinite(x) & np.isfinite(y)
        counts.append(int(m.sum()))
        if m.any():
            xmins.append(float(x[m].min()))
            xmaxs.append(float(x[m].max()))
        ax.scatter(
            x, y,
            c=s.get("color", default_colors[idx % len(default_colors)]),
            s=s.get("size", 32), alpha=0.85, edgecolor="k", linewidth=0.3,
            marker=s.get("marker", "o"), label=s.get("label"),
        )

    if fit_model and fit_params and xmins:
        xfit = np.linspace(min(xmins), max(xmaxs), 200)
        yfit = _curve(fit_model, fit_params, xfit)
        ax.plot(xfit, yfit, "k-", lw=2, label=fit_label or None)

    if log_x:
        ax.set_xscale("log")
    if log_y:
        ax.set_yscale("log")
    if xlim:
        ax.set_xlim(xlim)
    if ylim:
        ax.set_ylim(ylim)
    if annotation:
        ax.text(0.05, 0.05, annotation, transform=ax.transAxes, fontsize=10,
                bbox=dict(facecolor="white", alpha=0.8))

    ax.set_xlabel(x_label)
    ax.set_ylabel(y_label)
    if title:
        ax.set_title(title)
    if any(s.get("label") or fit_label for s in series) or fit_label:
        ax.legend(loc="best", fontsize=9)
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    plt.savefig(out_path, dpi=90, bbox_inches="tight")
    plt.close()
    return {"saved_path": out_path, "series_counts": counts}


@mcp.tool()
def plot_grouped_bars(
    out_path: str,
    group_labels: list,
    bar_series: list,
    y_label: str = "",
    title: str = "",
) -> dict:
    """Render a grouped bar chart from caller-supplied values.

    Pure rendering primitive: it bars whatever the caller computed (e.g.
    per-period ΔSST for several reconstruction methods). It does not compute
    the values or any amplification ratios.

    Args:
        out_path: output PNG path.
        group_labels: x-axis category labels (one per group).
        bar_series: list of dicts, each with keys ``"label"`` and ``"values"``
            (a list aligned with ``group_labels``) and optional ``"color"``.
        y_label / title: axis label and figure title.

    Returns:
        dict with ``saved_path`` and the number of groups/series drawn.
    """
    n_groups = len(group_labels)
    n_series = len(bar_series)
    x = np.arange(n_groups)
    fig, ax = plt.subplots(figsize=(7.5, 5.2))
    total_w = 0.8
    w = total_w / max(n_series, 1)
    default_colors = ["gray", "steelblue", "orange", "green"]
    for j, s in enumerate(bar_series):
        offset = (j - (n_series - 1) / 2.0) * w
        ax.bar(x + offset, s["values"], w,
               color=s.get("color", default_colors[j % len(default_colors)]),
               edgecolor="k", label=s.get("label"))
    ax.set_xticks(x)
    ax.set_xticklabels(group_labels, rotation=10)
    if y_label:
        ax.set_ylabel(y_label)
    if title:
        ax.set_title(title)
    if any(s.get("label") for s in bar_series):
        ax.legend(loc="best", fontsize=9)
    ax.grid(True, axis="y", alpha=0.3)
    plt.tight_layout()
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    plt.savefig(out_path, dpi=90, bbox_inches="tight")
    plt.close()
    return {"saved_path": out_path, "n_groups": n_groups, "n_series": n_series}


if __name__ == "__main__":
    mcp.run(transport="stdio")

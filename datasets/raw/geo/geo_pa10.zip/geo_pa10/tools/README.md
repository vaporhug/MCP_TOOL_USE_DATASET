# Tools — geo_pa10

Three FastMCP tool servers exposing low-level primitives for paleothermometry
calibration analysis. **No domain logic is hard-coded** — the agent must
choose which columns to load, which regression to fit, and how to combine
species datasets.

## Servers

| File | Server | Purpose |
|---|---|---|
| `data_loader.py` | `Data_Loader_Tools` | CSV/Excel I/O, column summaries, multi-file column concatenation |
| `regression_tools.py` | `Regression_Tools` | OLS, log-linear, power-law fits; Monte-Carlo slope uncertainty; correlation tests; calibration prediction |
| `proxy_plotting.py` | `Proxy_Plotting_Tools` | Generic rendering primitives (`plot_xy_series`, `plot_grouped_bars`) that draw caller-supplied data + pre-computed fits; they do not load data, choose a regression, or return coefficients |

## Dependencies

```
python>=3.10
numpy
pandas
scipy
matplotlib
mcp  # FastMCP
openpyxl  # for load_excel only
```

Install:
```bash
pip install numpy pandas scipy matplotlib mcp openpyxl
```

## Running individual servers

```bash
python tools/data_loader.py
python tools/regression_tools.py
python tools/proxy_plotting.py
```

Each speaks the FastMCP stdio protocol when invoked directly.

## Tool inventory

### `data_loader.py`
- `load_csv(csv_path, filters=None, max_preview_rows=50)`
- `load_excel(xlsx_path, sheet_name=None)`
- `column_summary(csv_path, column)`
- `concat_columns(csv_paths, column_pairs)`

### `regression_tools.py`
- `linear_regression(x_values, y_values)`
- `log_linear_regression(x_values, y_values)` — fit ln(y)=a+b·x
- `power_law_fit(x_values, y_values)` — fit y = A·x^k
- `monte_carlo_slope_uncertainty(x_values, y_values, x_sigma, y_sigma, n_iter, fit, seed)`
- `predict_from_calibration(a, b, x_values, model)`
- `correlation_test(x_values, y_values)`

### `proxy_plotting.py`
- `plot_xy_series(out_path, series, x_label, y_label, title, fit_model=None, fit_params=None, fit_label="", annotation="", xlim, ylim, log_x, log_y)` — generic multi-series scatter, optionally overlaying a fit curve. `fit_model` is one of `"power_law"` (y = A·x^k), `"log_linear"` (y = prefactor·exp(b·x)), or `"linear"` (y = m·x + c); the corresponding `fit_params` are supplied **by the caller** (e.g. from `regression_tools.power_law_fit`). The tool draws — it does not derive — any fit.
- `plot_grouped_bars(out_path, group_labels, bar_series, y_label, title)` — generic grouped bar chart from caller-computed values (e.g. per-period ΔSST for several reconstruction methods).

Typical use for this task's artifacts:
- fig1 (Mg/Ca[Norm] vs [CO3]): fit with `power_law_fit`, render with `plot_xy_series(fit_model="power_law")`.
- fig2 (Mg/Ca[Corr] vs T): fit with `log_linear_regression`, render with `plot_xy_series(fit_model="log_linear")`.
- fig3 (δ18Oc vs [CO3]): fit with `linear_regression` / `correlation_test`, render with `plot_xy_series(fit_model="linear")`.
- fig4 (glacial-interglacial ΔSST): render the caller's ΔSST values with `plot_grouped_bars`.

The plotting tools return only the saved file path and per-series point counts.
Regression coefficients, r², n, and the final calibration equations are
produced by `regression_tools` and reported only in the answer — never echoed
or baked into these rendering primitives.

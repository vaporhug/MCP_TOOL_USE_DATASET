# geo_no30 - Tools

Domain tools for the Noto Peninsula 2000-2024 seismicity / fluid-migration
analysis.

## Files

- `noto_seismicity.py` - **MCP tool module** (`@mcp.tool()`).
  Loaders for the JMA Unified Hypocenter CSV, the USGS ComCat CSV, and the
  3D-CMT solution table (`load_jma_catalog`, `load_usgs_catalog`,
  `load_cmt_solutions`); magnitude-of-completeness via maximum-curvature
  (`magnitude_completeness`); maximum-likelihood Gutenberg-Richter b-value
  with bootstrap standard error (`gutenberg_richter_bvalue`); per-cell
  spatial b-value mapping (`bvalue_grid`); space-time aftershock selection
  around a declared mainshock (`select_aftershocks`); aftershock
  productivity-density depth profile (`productivity_density_depth_profile`);
  swarm migration-front computation (`migration_front_distance`) and
  diffusion-envelope fit (`fit_diffusion_envelope`); and four plotting
  helpers (`plot_annual_seismicity`, `plot_bvalue_map`, `plot_depth_profile`,
  `plot_migration_front`) - **one figure per image**, each returning the
  absolute path of the PNG it wrote.
- `data_processing.py` - generic CSV / JSON readers, numeric coercion, and
  bounding-box / time-window filtering helpers.
- `database_retrieval.py` - documentation of the upstream sources (USGS
  ComCat FDSN URL builder, JMA Hypocenter zip URL builder, Zenodo CMT
  record). The local copies under `input_data/data/` are authoritative for
  this task. `fetch_url` here is an **optional, intentionally unimplemented**
  offline helper (raises `NotImplementedError`): it documents how the
  upstream files could be re-downloaded but is never invoked, since the
  analysis runs fully offline against the bundled CSVs.

## Scope

This bundle is a **summary-level seismicity diagnostic**, not a full
space-time ETAS refit. The provided primitives recompute the annual
counts / swarm timing, the spatial b-value map, and the 2007 / 2023
productivity-depth profiles directly from the bundled JMA catalog. The
2024 Mw7.5 ~27 km productivity scaling and the A / alpha / p ETAS
parameter anomalies are the paper's improved space-time ETAS
stochastic-reconstruction results (computed from a denser 2024 aftershock
catalog not shipped here) and are reported as paper findings, not
recomputed. No ETAS A/alpha/p estimation tool is bundled by design.

## Dependencies

- `numpy` (always required)
- `matplotlib` (plotting helpers)
- `mcp` (FastMCP server runtime)

Install: `pip install numpy matplotlib mcp`.

## Run as MCP server

```bash
python tools/noto_seismicity.py
```

The module also imports cleanly for ad-hoc use; each `@mcp.tool()`-decorated
function exposes its underlying implementation as `<tool>.fn(...)`.

"""Database-retrieval helpers for geo_no30 (Noto Peninsula seismicity).

The local copies under input_data/data/ are authoritative for this task -
two earthquake catalogs (USGS ComCat for the 2000-2024 window covering the
2024 mainshock, and JMA Unified Hypocenter Bulletin for 2000-2023) plus the
3D-CMT solutions (Zenodo record 14195303). These helpers describe where the
upstream data come from and provide URLs an agent could re-fetch from.
"""
from typing import Any


# ---------------------------------------------------------------------------
# USGS ComCat (FDSN event service)
# ---------------------------------------------------------------------------

def fetch_usgs_catalog(starttime: str, endtime: str,
                       minlat: float, maxlat: float,
                       minlon: float, maxlon: float,
                       minmag: float = 0.0,
                       fmt: str = "csv") -> str:
    """Build the USGS FDSN event-query URL for a region/time window.
    `fmt` may be 'csv', 'geojson', or 'quakeml'. Returns the URL string."""
    base = "https://earthquake.usgs.gov/fdsnws/event/1/query"
    return (f"{base}?format={fmt}"
            f"&starttime={starttime}&endtime={endtime}"
            f"&minlatitude={minlat}&maxlatitude={maxlat}"
            f"&minlongitude={minlon}&maxlongitude={maxlon}"
            f"&minmagnitude={minmag}&orderby=time-asc")


# ---------------------------------------------------------------------------
# JMA Seismological Bulletin (hypocenter format)
# ---------------------------------------------------------------------------

def jma_hypo_zip_url(year: int) -> str:
    """Return the JMA Unified Hypocenter Bulletin zip URL for a year (>=1997).
    The archive contains a single fixed-width text file (Shift-JIS encoding)."""
    return f"https://www.data.jma.go.jp/eqev/data/bulletin/data/hypo/h{year}.zip"


def jma_format_doc_url() -> str:
    """JMA hypocenter fixed-width column layout reference."""
    return "https://www.data.jma.go.jp/eqev/data/bulletin/data/format/hypfmt_e.html"


# ---------------------------------------------------------------------------
# 3D-CMT solutions (Zenodo)
# ---------------------------------------------------------------------------

def zenodo_noto_cmt_record_url() -> str:
    """Zenodo record 14195303 - 3D-CMT catalog of earthquakes in Noto
    Peninsula, central Japan (Noto_aftershock.zip, Noto_2007_2023.zip)."""
    return "https://zenodo.org/records/14195303"


# ---------------------------------------------------------------------------
# Generic HTTP (stub - heavy dep, kept here only as documentation)
# ---------------------------------------------------------------------------

def fetch_url(url: str, timeout: int = 60) -> bytes:
    """OPTIONAL, INTENTIONALLY UNIMPLEMENTED offline helper.

    Documents how a user could re-download the upstream sources (returns raw
    bytes from an HTTP GET, handling redirects). It is **not used by this
    task**: the bundled JMA / USGS / 3D-CMT CSVs under input_data/ are the
    authoritative inputs and the analysis runs fully offline. The body is a
    deliberate stub (no network dependency shipped); calling it raises
    NotImplementedError rather than silently returning None.
    """
    raise NotImplementedError(
        "fetch_url is an optional offline-unused documentation stub; the "
        "bundled CSVs in input_data/ are authoritative for geo_no30."
    )

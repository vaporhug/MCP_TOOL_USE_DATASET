"""Generic data-processing utilities for the geo_no30 task.

Format conversion, simple table reshaping, and lightweight transforms that
are *not* specific to seismology. Domain-specific transforms (Mc estimation,
b-value, ETAS productivity, spatiotemporal clustering) live in
`noto_seismicity.py`.
"""
from typing import Any
import csv
import json


def read_csv(path: str, delimiter: str = ",") -> list[dict]:
    """Parse CSV into list-of-dicts using csv.DictReader."""
    with open(path, newline="") as f:
        return list(csv.DictReader(f, delimiter=delimiter))


def write_csv(rows: list[dict], path: str) -> None:
    """Write list-of-dicts to CSV; header is taken from the first row."""
    if not rows:
        open(path, "w").close()
        return
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def read_json(path: str) -> Any:
    with open(path) as f:
        return json.load(f)


def write_json(obj: Any, path: str, indent: int = 2) -> None:
    with open(path, "w") as f:
        json.dump(obj, f, indent=indent, default=str)


def coerce_numeric(rows: list[dict], cols: list[str]) -> list[dict]:
    """Cast named columns to float; non-parseable -> None."""
    out = []
    for r in rows:
        r2 = dict(r)
        for c in cols:
            try:
                r2[c] = float(r2[c])
            except (TypeError, ValueError):
                r2[c] = None
        out.append(r2)
    return out


def drop_missing(rows: list[dict], cols: list[str] | None = None) -> list[dict]:
    """Remove rows where any (or listed) columns are None / empty / NaN."""
    def bad(v):
        return v is None or v == "" or v != v
    if cols is None:
        return [r for r in rows if not any(bad(v) for v in r.values())]
    return [r for r in rows if not any(bad(r.get(c)) for c in cols)]


def filter_box(rows: list[dict], lat_col: str, lon_col: str,
               lat_min: float, lat_max: float,
               lon_min: float, lon_max: float) -> list[dict]:
    """Return rows whose (lat, lon) fall inside the inclusive bounding box."""
    out = []
    for r in rows:
        try:
            la = float(r[lat_col]); lo = float(r[lon_col])
        except (KeyError, TypeError, ValueError):
            continue
        if lat_min <= la <= lat_max and lon_min <= lo <= lon_max:
            out.append(r)
    return out


def filter_time_window(rows: list[dict], time_col: str,
                       start_iso: str, end_iso: str) -> list[dict]:
    """Filter rows by ISO 8601 timestamp string column (lexicographic)."""
    out = []
    for r in rows:
        t = r.get(time_col, "")
        if start_iso <= str(t) <= end_iso:
            out.append(r)
    return out


def groupby_aggregate(rows: list[dict], by: str,
                      agg: dict[str, str]) -> list[dict]:
    """Group rows by `by` and apply per-column aggregations
    (mean | sum | min | max | count)."""
    from statistics import mean
    groups: dict = {}
    for r in rows:
        groups.setdefault(r[by], []).append(r)
    out = []
    for key, grp in groups.items():
        row = {by: key}
        for col, fn in agg.items():
            vals = [g[col] for g in grp if g.get(col) is not None]
            if fn == "mean":
                row[col] = mean(vals) if vals else None
            elif fn == "sum":
                row[col] = sum(vals)
            elif fn == "min":
                row[col] = min(vals) if vals else None
            elif fn == "max":
                row[col] = max(vals) if vals else None
            elif fn == "count":
                row[col] = len(vals)
        out.append(row)
    return out

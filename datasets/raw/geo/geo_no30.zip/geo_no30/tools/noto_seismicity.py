#!/usr/bin/env python3
"""Domain tools for the Noto Peninsula 2000-2024 seismicity / fluid migration
analysis. All tools take simple primitive inputs (paths, lists, scalars) and
return JSON-serialisable dicts.

Coverage:
  * loaders for the JMA hypocenter CSV, USGS ComCat CSV, and the 3D-CMT
    solution table
  * spatial subsetting / time-window filtering
  * magnitude-of-completeness Mc estimation (maximum-curvature and
    Mc + 0.2 stability)
  * Gutenberg-Richter b-value (maximum-likelihood Aki/Utsu) with bootstrap
    standard error
  * spatial productivity-density binning along a depth profile (paper
    Figure 3 / 4 style)
  * spatiotemporal swarm clustering and migration-front fitting
  * one-figure-per-image plotting helpers (each returns the absolute path
    of the PNG it wrote)
"""

from __future__ import annotations

from typing import Any
import math
import os

import numpy as np

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Noto_Seismicity_Analysis")


# ----------------------------------------------------------------------
# Loaders
# ----------------------------------------------------------------------

@mcp.tool()
def load_jma_catalog(csv_path: str) -> dict:
    """Load the JMA Unified Hypocenter CSV exported for the Noto study box
    (jma_noto_2000_2023.csv).  Returns flat per-event arrays plus an
    epoch-second `t_seconds` column convenient for later ETAS / clustering.
    Columns: year, month, day, hour, minute, second, latitude, longitude,
    depth_km, magnitude, mag_type, region.

    TIMEZONE CONVENTION: the JMA catalog reports origin times in Japan
    Standard Time (JST = UTC+9). This loader treats the year/month/.../second
    fields as a naive wall-clock timestamp and derives `t_seconds` /
    `t_iso` on that same JST clock WITHOUT converting to UTC (no tz offset is
    applied). The USGS loader, by contrast, returns UTC. Do NOT mix the two
    clocks: when using `aftershock_window` (default window_days=30) on the JMA
    catalog, pass a mainshock origin time on the SAME JST clock as the JMA
    `t_iso` values, otherwise the 30-day space-time window is shifted by the
    9-hour JST-vs-UTC offset. If a UTC mainshock time must be used, first add
    9 hours to it (or subtract 9 hours from the JMA times) so both sides share
    one clock before filtering.
    """
    import csv as _csv
    import datetime as _dt
    rows = []
    with open(csv_path, newline="") as f:
        for r in _csv.DictReader(f):
            try:
                yr = int(r["year"]); mo = int(r["month"]); dy = int(r["day"])
                hr = int(r["hour"]); mn = int(r["minute"])
                sc_f = float(r["second"]) if r["second"] not in ("", None) else 0.0
                sc_int = int(sc_f); us = int((sc_f - sc_int) * 1e6)
                # JMA 'second' values 60.x sometimes appear; clamp to 59.999999
                if sc_int >= 60:
                    sc_int = 59; us = 999999
                t = _dt.datetime(yr, mo, dy, hr, mn, sc_int, us)
                lat = float(r["latitude"]); lon = float(r["longitude"])
                dep = float(r["depth_km"]) if r["depth_km"] not in ("", None) else None
                mag = float(r["magnitude"]) if r["magnitude"] not in ("", None) else None
                rows.append({
                    "t_iso": t.isoformat(timespec="seconds"),
                    "t_seconds": (t - _dt.datetime(1970, 1, 1)).total_seconds(),
                    "year": yr, "latitude": lat, "longitude": lon,
                    "depth_km": dep, "magnitude": mag,
                    "mag_type": r.get("mag_type", ""),
                    "region": r.get("region", ""),
                })
            except (ValueError, KeyError):
                continue
    return {
        "n_events": len(rows),
        "year_range": [min(r["year"] for r in rows), max(r["year"] for r in rows)] if rows else None,
        "lat_range": [min(r["latitude"] for r in rows), max(r["latitude"] for r in rows)] if rows else None,
        "lon_range": [min(r["longitude"] for r in rows), max(r["longitude"] for r in rows)] if rows else None,
        "events": rows,
    }


@mcp.tool()
def load_usgs_catalog(csv_path: str) -> dict:
    """Load the USGS ComCat CSV (usgs_noto_2000_2024.csv).
    Returns the standard columns plus epoch-second `t_seconds`."""
    import csv as _csv
    import datetime as _dt
    rows = []
    with open(csv_path, newline="") as f:
        for r in _csv.DictReader(f):
            try:
                t = _dt.datetime.fromisoformat(r["time"].replace("Z", "+00:00"))
                rows.append({
                    "t_iso": t.isoformat(),
                    "t_seconds": t.timestamp(),
                    "latitude": float(r["latitude"]),
                    "longitude": float(r["longitude"]),
                    "depth_km": float(r["depth"]) if r["depth"] not in ("", None) else None,
                    "magnitude": float(r["mag"]) if r["mag"] not in ("", None) else None,
                    "magType": r.get("magType", ""),
                    "id": r.get("id", ""),
                    "place": r.get("place", ""),
                })
            except (ValueError, KeyError):
                continue
    return {"n_events": len(rows), "events": rows}


@mcp.tool()
def load_cmt_solutions(csv_path: str) -> dict:
    """Load the 3D-CMT solutions table (noto_cmt_solutions.csv).

    Returns one record per event with the hypocentre fields used downstream:
    date_utc, time_utc, latitude, longitude, depth_km and mw. The raw CSV also
    carries the moment-tensor components (mxx, mxy, mxz, myy, myz, mzz),
    variance and nodal_quality, but these are NOT included in the returned
    dict; read the CSV directly if the full moment tensor is required."""
    import csv as _csv
    rows = []
    with open(csv_path, newline="") as f:
        for r in _csv.DictReader(f):
            try:
                rows.append({
                    "date_utc": r["date_utc"],
                    "time_utc": r["time_utc"],
                    "latitude": float(r["latitude"]),
                    "longitude": float(r["longitude"]),
                    "depth_km": float(r["depth_km"]),
                    "mw": float(r["mw"]),
                })
            except (ValueError, KeyError):
                continue
    return {"n_events": len(rows), "events": rows}


# ----------------------------------------------------------------------
# Magnitude completeness Mc + b-value
# ----------------------------------------------------------------------

@mcp.tool()
def magnitude_completeness(magnitudes: list, bin_width: float = 0.1) -> dict:
    """Estimate Mc by the maximum-curvature (MAXC) method and report the
    Mc+0.2 stabilised value (Wiemer & Wyss 2000).

    Returns histogram, MAXC Mc, and a recommended Mc = MAXC + 0.2.
    """
    m = np.asarray([x for x in magnitudes if x is not None], dtype=float)
    m = m[~np.isnan(m)]
    if len(m) < 30:
        return {"error": f"need >=30 magnitudes, got {len(m)}"}
    edges = np.arange(np.floor(m.min()/bin_width)*bin_width,
                      np.ceil(m.max()/bin_width)*bin_width + bin_width,
                      bin_width)
    hist, _ = np.histogram(m, bins=edges)
    centers = 0.5 * (edges[:-1] + edges[1:])
    if hist.sum() == 0:
        return {"error": "empty histogram"}
    # MAXC = magnitude of the bin with peak frequency
    mc_maxc = float(centers[int(np.argmax(hist))])
    return {
        "n": int(len(m)),
        "bin_width": float(bin_width),
        "mc_maxc": round(mc_maxc, 3),
        "mc_recommended": round(mc_maxc + 0.2, 3),
        "histogram_centers": [round(float(c), 3) for c in centers],
        "histogram_counts": [int(h) for h in hist],
    }


@mcp.tool()
def gutenberg_richter_bvalue(magnitudes: list, mc: float,
                             bin_width: float = 0.1,
                             n_bootstrap: int = 200) -> dict:
    """Aki/Utsu maximum-likelihood Gutenberg-Richter b-value above Mc with a
    Marzocchi-Sandri (2003) bin-width correction.

    b = log10(e) / (mean(M | M >= Mc) - (Mc - bin_width/2))
    Bootstrap standard error is computed by resampling with replacement.
    Also returns 'a' (cumulative number normalisation) and the magnitudes
    counted above Mc.
    """
    m_all = np.asarray([x for x in magnitudes if x is not None], dtype=float)
    m_all = m_all[~np.isnan(m_all)]
    m = m_all[m_all >= mc - 1e-9]
    n = len(m)
    if n < 30:
        return {"error": f"need >=30 events above Mc, got {n}"}
    log10e = math.log10(math.e)
    b = log10e / (m.mean() - (mc - bin_width / 2.0))
    # bootstrap
    rng = np.random.default_rng(20240101)
    bs = []
    for _ in range(n_bootstrap):
        s = rng.choice(m, size=n, replace=True)
        bs.append(log10e / (s.mean() - (mc - bin_width / 2.0)))
    b_se = float(np.std(bs, ddof=1))
    a = math.log10(n) + b * mc
    return {
        "mc": float(mc),
        "n_above_mc": int(n),
        "b_value": round(float(b), 4),
        "b_std_error": round(b_se, 4),
        "a_value": round(float(a), 4),
        "min_mag": round(float(m.min()), 3),
        "max_mag": round(float(m.max()), 3),
    }


@mcp.tool()
def bvalue_grid(magnitudes: list, latitudes: list, longitudes: list,
                cell_deg: float = 0.05, mc: float | None = None,
                min_per_cell: int = 50) -> dict:
    """Compute the local b-value on a regular lat/lon grid by binning events
    into `cell_deg`-degree cells and applying Aki/Utsu MLE in each cell that
    contains at least `min_per_cell` events above Mc.

    If `mc` is None, it is estimated cell-by-cell with the maximum-curvature
    rule. Returns per-cell results suitable for a heat-map plot.
    """
    mags = np.asarray(magnitudes, dtype=float)
    la = np.asarray(latitudes, dtype=float)
    lo = np.asarray(longitudes, dtype=float)
    valid = ~(np.isnan(mags) | np.isnan(la) | np.isnan(lo))
    mags, la, lo = mags[valid], la[valid], lo[valid]
    if len(mags) == 0:
        return {"error": "no valid events"}
    lat_lo = np.floor(la.min() / cell_deg) * cell_deg
    lat_hi = np.ceil(la.max() / cell_deg) * cell_deg
    lon_lo = np.floor(lo.min() / cell_deg) * cell_deg
    lon_hi = np.ceil(lo.max() / cell_deg) * cell_deg
    lat_edges = np.arange(lat_lo, lat_hi + cell_deg, cell_deg)
    lon_edges = np.arange(lon_lo, lon_hi + cell_deg, cell_deg)
    log10e = math.log10(math.e)
    cells = []
    for i in range(len(lat_edges) - 1):
        for j in range(len(lon_edges) - 1):
            mask = ((la >= lat_edges[i]) & (la < lat_edges[i + 1]) &
                    (lo >= lon_edges[j]) & (lo < lon_edges[j + 1]))
            if mask.sum() < min_per_cell:
                continue
            sub = mags[mask]
            if mc is None:
                # MAXC per cell
                edges = np.arange(np.floor(sub.min()/0.1)*0.1,
                                  np.ceil(sub.max()/0.1)*0.1 + 0.1, 0.1)
                if len(edges) < 2:
                    continue
                hist, _ = np.histogram(sub, bins=edges)
                centers = 0.5 * (edges[:-1] + edges[1:])
                mc_loc = float(centers[int(np.argmax(hist))]) + 0.2
            else:
                mc_loc = float(mc)
            sub2 = sub[sub >= mc_loc - 1e-9]
            if len(sub2) < min_per_cell:
                continue
            b = log10e / (sub2.mean() - (mc_loc - 0.05))
            cells.append({
                "lat_center": round(float(0.5 * (lat_edges[i] + lat_edges[i + 1])), 4),
                "lon_center": round(float(0.5 * (lon_edges[j] + lon_edges[j + 1])), 4),
                "n_above_mc": int(len(sub2)),
                "mc": round(mc_loc, 2),
                "b_value": round(float(b), 3),
            })
    if not cells:
        return {"n_cells": 0, "cells": []}
    return {
        "cell_deg": float(cell_deg),
        "n_cells": len(cells),
        "b_min": round(min(c["b_value"] for c in cells), 3),
        "b_max": round(max(c["b_value"] for c in cells), 3),
        "b_median": round(float(np.median([c["b_value"] for c in cells])), 3),
        "cells": cells,
    }


# ----------------------------------------------------------------------
# Aftershock productivity / depth profile
# ----------------------------------------------------------------------

@mcp.tool()
def select_aftershocks(t_seconds: list, latitudes: list, longitudes: list,
                       magnitudes: list,
                       mainshock_t_iso: str,
                       mainshock_lat: float, mainshock_lon: float,
                       window_days: float = 30.0,
                       radius_km: float = 50.0) -> dict:
    """Return the indices of events that fall within a space-time window of a
    declared mainshock (Gardner-Knopoff style). Used to isolate the 2007
    Mw6.7, 2023 Mw6.2, and 2024 Mw7.5 aftershock sequences."""
    import datetime as _dt
    t_main = _dt.datetime.fromisoformat(mainshock_t_iso.replace("Z", "+00:00"))
    if t_main.tzinfo is None:
        t_main = t_main.replace(tzinfo=_dt.timezone.utc)
    t_main_s = t_main.timestamp()
    ts = np.asarray(t_seconds, dtype=float)
    la = np.asarray(latitudes, dtype=float)
    lo = np.asarray(longitudes, dtype=float)
    mg = np.asarray(magnitudes, dtype=float)
    dt_days = (ts - t_main_s) / 86400.0
    # great-circle approximation valid for small radii
    R = 6371.0
    dlat = np.radians(la - mainshock_lat)
    dlon = np.radians(lo - mainshock_lon) * np.cos(np.radians(mainshock_lat))
    dist_km = R * np.sqrt(dlat ** 2 + dlon ** 2)
    mask = (dt_days >= 0) & (dt_days <= window_days) & (dist_km <= radius_km)
    idx = np.where(mask)[0].tolist()
    return {
        "mainshock_t_iso": mainshock_t_iso,
        "window_days": float(window_days),
        "radius_km": float(radius_km),
        "n_aftershocks": int(mask.sum()),
        "indices": [int(i) for i in idx],
        "dt_days": [round(float(dt_days[i]), 5) for i in idx],
        "dist_km": [round(float(dist_km[i]), 3) for i in idx],
        "magnitudes": [round(float(mg[i]), 2) for i in idx
                       if not np.isnan(mg[i])],
    }


@mcp.tool()
def productivity_density_depth_profile(depths_km: list,
                                       depth_bin_km: float = 1.0,
                                       max_depth_km: float = 30.0,
                                       significant_fraction: float = 0.05) -> dict:
    """Bin aftershock counts into depth bins and report the productivity
    density (events per km).

    ``deepest_significant_km`` is the centre of the deepest bin whose density
    is still at least ``significant_fraction`` of the peak density (default
    0.05, i.e. 5% of peak) -- a simple proxy for the depth to which aftershock
    productivity remains significant (cf. paper Figure 3 / 4). Raise or lower
    ``significant_fraction`` to make the cutoff stricter or looser.

    Args:
        depths_km: per-event hypocentre depths (km).
        depth_bin_km: depth-bin width (km).
        max_depth_km: depths beyond this are dropped before binning.
        significant_fraction: fraction-of-peak density that still counts as
            significant (default 0.05).
    """
    d = np.asarray([x for x in depths_km if x is not None], dtype=float)
    d = d[~np.isnan(d) & (d >= 0) & (d <= max_depth_km)]
    if len(d) == 0:
        return {"error": "no valid depths"}
    edges = np.arange(0, max_depth_km + depth_bin_km, depth_bin_km)
    hist, _ = np.histogram(d, bins=edges)
    centers = 0.5 * (edges[:-1] + edges[1:])
    density = hist / depth_bin_km  # events per km
    # deepest bin whose density is still >= significant_fraction * peak
    peak = float(density.max())
    cutoff_idx = np.where(density >= significant_fraction * peak)[0]
    deepest_significant = float(centers[cutoff_idx[-1]]) if len(cutoff_idx) else None
    return {
        "depth_bin_km": float(depth_bin_km),
        "significant_fraction": float(significant_fraction),
        "centers_km": [round(float(c), 2) for c in centers],
        "counts": [int(h) for h in hist],
        "density_per_km": [round(float(x), 3) for x in density],
        "peak_density": round(peak, 3),
        "deepest_significant_km": round(deepest_significant, 2)
            if deepest_significant is not None else None,
    }


# ----------------------------------------------------------------------
# Spatiotemporal swarm clustering / fluid-migration front
# ----------------------------------------------------------------------

@mcp.tool()
def annual_event_count(t_iso_list: list) -> dict:
    """Count events per calendar year. Used to demonstrate the 2021-2023
    swarm acceleration."""
    import datetime as _dt
    counts: dict = {}
    for t in t_iso_list:
        try:
            yr = _dt.datetime.fromisoformat(str(t).replace("Z", "+00:00")).year
        except Exception:
            continue
        counts[yr] = counts.get(yr, 0) + 1
    items = sorted(counts.items())
    return {
        "years": [int(y) for y, _ in items],
        "counts": [int(c) for _, c in items],
        "total": int(sum(counts.values())),
        "peak_year": int(max(counts, key=counts.get)) if counts else None,
        "peak_count": int(max(counts.values())) if counts else None,
    }


@mcp.tool()
def migration_front_distance(t_seconds: list, latitudes: list, longitudes: list,
                             origin_t_iso: str,
                             origin_lat: float, origin_lon: float) -> dict:
    """Compute (time-since-origin, great-circle distance to origin) for every
    event.  Suitable input for a migration-front fit (distance vs sqrt(t)
    diffusion law D = sqrt(4*pi*c*t) used by paper Figure 7-style swarm
    plots)."""
    import datetime as _dt
    t0 = _dt.datetime.fromisoformat(origin_t_iso.replace("Z", "+00:00"))
    if t0.tzinfo is None:
        t0 = t0.replace(tzinfo=_dt.timezone.utc)
    t0_s = t0.timestamp()
    ts = np.asarray(t_seconds, dtype=float) - t0_s
    la = np.asarray(latitudes, dtype=float)
    lo = np.asarray(longitudes, dtype=float)
    R = 6371.0
    dlat = np.radians(la - origin_lat)
    dlon = np.radians(lo - origin_lon) * np.cos(np.radians(origin_lat))
    dist_km = R * np.sqrt(dlat ** 2 + dlon ** 2)
    return {
        "n": int(len(ts)),
        "dt_days": [round(float(t / 86400.0), 4) for t in ts.tolist()],
        "distance_km": [round(float(d), 4) for d in dist_km.tolist()],
    }


@mcp.tool()
def fit_diffusion_envelope(dt_days: list, distance_km: list,
                           quantile: float = 0.95) -> dict:
    """Fit the migration-envelope diffusion model r = sqrt(4 pi c t) to the
    upper-quantile (default 95%) of distance-vs-time points and report the
    hydraulic diffusivity c (m^2/s).  Only events with dt > 0 are used.
    """
    t = np.asarray(dt_days, dtype=float)
    r = np.asarray(distance_km, dtype=float)
    mask = (t > 0) & (~np.isnan(r))
    t, r = t[mask], r[mask]
    if len(t) < 20:
        return {"error": f"need >=20 points with dt>0, got {len(t)}"}
    # Bin by log-time, take upper quantile per bin
    log_t = np.log10(t)
    bins = np.linspace(log_t.min(), log_t.max(), 12)
    centers, env = [], []
    for i in range(len(bins) - 1):
        m = (log_t >= bins[i]) & (log_t < bins[i + 1])
        if m.sum() < 4:
            continue
        centers.append(0.5 * (bins[i] + bins[i + 1]))
        env.append(float(np.quantile(r[m], quantile)))
    centers = np.array(centers)
    env = np.array(env)
    # r = sqrt(4 pi c * t)  -> r^2 = 4 pi c * t  -> slope of r^2 vs t = 4 pi c
    t_lin = 10 ** centers * 86400.0
    r_m = env * 1000.0
    slope, intercept = np.polyfit(t_lin, r_m ** 2, 1)
    c = float(slope) / (4 * math.pi)
    return {
        "n_envelope_points": int(len(env)),
        "slope_r2_per_t": round(float(slope), 4),
        "diffusivity_m2_s": round(c, 4),
        "envelope_t_days_log10": [round(float(x), 3) for x in centers],
        "envelope_r_km": [round(float(x), 4) for x in env],
        "quantile": float(quantile),
    }


# ----------------------------------------------------------------------
# Plotting
# ----------------------------------------------------------------------

def _ensure_dir(path: str) -> None:
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)


@mcp.tool()
def plot_annual_seismicity(years: list, counts: list, out_path: str,
                           title: str = "Noto Peninsula annual M >= Mc count") -> str:
    """Bar plot of annual event counts emphasising the 2021-2023 swarm
    acceleration and the 2024 mainshock cluster (paper Figure 1c style)."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    _ensure_dir(out_path)
    fig, ax = plt.subplots(figsize=(8, 4))
    yrs = np.asarray(years)
    cs = np.asarray(counts)
    colours = ["royalblue" if y < 2020 else ("darkorange" if y < 2024 else "firebrick")
               for y in yrs]
    ax.bar(yrs, cs, color=colours, edgecolor="black", linewidth=0.5)
    ax.set_xlabel("Year")
    ax.set_ylabel("Annual event count")
    ax.set_title(title)
    ax.set_yscale("log")
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return os.path.abspath(out_path)


@mcp.tool()
def plot_bvalue_map(cells: list, out_path: str,
                    title: str = "Local Gutenberg-Richter b-value") -> str:
    """Heat-map of per-cell b-values (one figure)."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    _ensure_dir(out_path)
    if not cells:
        raise ValueError("no cells provided")
    lats = np.array([c["lat_center"] for c in cells])
    lons = np.array([c["lon_center"] for c in cells])
    bs = np.array([c["b_value"] for c in cells])
    fig, ax = plt.subplots(figsize=(6.5, 5))
    sc = ax.scatter(lons, lats, c=bs, cmap="RdYlBu_r", s=140, marker="s",
                    edgecolor="black", linewidth=0.4,
                    vmin=max(0.4, float(bs.min())),
                    vmax=min(2.0, float(bs.max())))
    plt.colorbar(sc, ax=ax, label="b-value")
    ax.set_xlabel("Longitude (deg E)")
    ax.set_ylabel("Latitude (deg N)")
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return os.path.abspath(out_path)


@mcp.tool()
def plot_depth_profile(depth_centers_km: list, density_per_km: list,
                       out_path: str, label: str = "All events",
                       title: str = "Aftershock depth profile") -> str:
    """Line plot of productivity density vs depth (one figure).  Use the
    productivity_density_depth_profile tool to compute the inputs."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    _ensure_dir(out_path)
    fig, ax = plt.subplots(figsize=(4.2, 6))
    ax.plot(density_per_km, depth_centers_km, color="navy", linewidth=2,
            label=label)
    ax.invert_yaxis()
    ax.set_xlabel("Productivity density (events / km)")
    ax.set_ylabel("Depth (km)")
    ax.set_title(title)
    ax.legend()
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return os.path.abspath(out_path)


@mcp.tool()
def plot_migration_front(dt_days: list, distance_km: list,
                         envelope_t_days_log10: list, envelope_r_km: list,
                         diffusivity_m2_s: float, out_path: str,
                         title: str = "Swarm migration: distance vs time") -> str:
    """Scatter of migration distance vs time with the fitted diffusion
    envelope overlaid (one figure, paper Figure 7-style)."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    _ensure_dir(out_path)
    fig, ax = plt.subplots(figsize=(6, 5))
    t = np.asarray(dt_days, dtype=float)
    r = np.asarray(distance_km, dtype=float)
    mask = t > 0
    ax.scatter(t[mask], r[mask], s=8, alpha=0.4, color="grey",
               label="Events")
    ax.scatter(10 ** np.asarray(envelope_t_days_log10),
               np.asarray(envelope_r_km), color="firebrick", s=40,
               label="Envelope")
    # plot fitted curve
    tt = np.logspace(np.log10(max(t[mask].min(), 1e-3)),
                     np.log10(t[mask].max()), 200)
    rr = np.sqrt(4 * math.pi * diffusivity_m2_s * tt * 86400.0) / 1000.0
    ax.plot(tt, rr, "k--", linewidth=1.5,
            label=f"r = sqrt(4 pi c t),  c = {diffusivity_m2_s:.2f} m^2/s")
    ax.set_xscale("log")
    ax.set_xlabel("Time since origin (days)")
    ax.set_ylabel("Great-circle distance (km)")
    ax.set_title(title)
    ax.legend(loc="upper left", fontsize=8)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return os.path.abspath(out_path)


if __name__ == "__main__":
    mcp.run(transport="stdio")

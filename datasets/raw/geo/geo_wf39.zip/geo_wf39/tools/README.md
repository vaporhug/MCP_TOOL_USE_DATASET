# geo_wf39 — Tool Reference

## Database Retrieval (`database_retrieval.py`)

- **websearch**: Generic web search (Google/Bing/DuckDuckGo via a scraping backend).
- **fetch_url**: HTTP GET with redirects. Used to download a CSV/PDF/JSON from a known URL.
- **query_pubchem**: PubChem PUG-REST lookup.
- **query_chembl**: ChEMBL bioactivity query.
- **query_uniprot**: UniProt entry fetch.
- **query_pdb**: RCSB PDB entry metadata + structure file URL.
- **query_geo**: NCBI GEO series/sample fetch (GSE/GSM).
- **query_ncbi_entrez**: Generic Entrez E-search + E-fetch.
- **query_usgs_comcat**: USGS ComCat earthquake catalog query.
- **query_world_bank**: World Bank WDI indicator series.
- **query_openalex**: OpenAlex works/authors/venues search.
- **query_doi**: Resolve a DOI to a Crossref metadata record.

## Data Processing (`data_processing.py`)

- **read_csv / write_csv**: list-of-dicts CSV I/O.
- **read_json / write_json**: JSON I/O.
- **read_excel / read_parquet / read_netcdf / read_shapefile**: heavy file readers (stub).
- **read_fasta**: FASTA sequence reader.
- **pivot_long_to_wide / pivot_wide_to_long**: reshape helpers.
- **drop_missing / coerce_numeric**: cleaning helpers.
- **join_tables / groupby_aggregate**: tabular join and aggregation.

## Domain-Specific Analysis (`wildfire_recovery.py`)

- **load_csv**: Load and preview a CSV with optional row filters.
- **summarise_column**: count/mean/std/min/median/max for a numeric column, optional group-by.
- **build_chronosequence**: Re-index burned-pixel GPP records by years-since-fire.
- **compute_dgpp**: Compute per (site, year) dGPP = burned − control GPP.
- **chronosequence_mean**: Bin-mean dGPP at each year-since-fire (with SE).
- **first_year_dgpp**: Mean dGPP in the first ``year_window`` year(s) after fire.
- **estimate_recovery_time**: Smallest year-since-fire where smoothed mean dGPP ≥ threshold.
- **fit_exponential_recovery**: Non-linear fit of dGPP(t) = -A·exp(-t/tau).
- **stratified_recovery**: Recovery curves stratified by quantiles of any fire attribute.
- **cumulative_landscape_legacy**: Area-weighted annual landscape dGPP legacy in Mt CO2.
- **plot_recovery_curve**: PNG of mean dGPP vs years-since-fire with 95% CI band.
- **plot_recovery_by_stratum**: PNG comparing recovery curves across attribute quantiles.
- **plot_landscape_legacy**: PNG of annual landscape dGPP legacy bars + rolling mean.
- **plot_fire_locations**: PNG scatter map of fire centroids over California.
- **correlate**: Pearson + Spearman correlation between two lists.
- **linear_regression**: OLS slope/intercept/r²/p between two lists.

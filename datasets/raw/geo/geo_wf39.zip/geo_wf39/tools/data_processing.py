"""Generic data-processing utilities.

Format conversion, reshaping, cleaning, and lightweight transforms that are
*not* specific to the task's scientific domain. Domain-specific transforms
(fingerprint generation, CLR, seasonal decomposition, etc.) live in the
task's main tools module.
"""
from typing import Any
import csv
import json


def read_csv(path: str, delimiter: str = ",") -> list[dict]:
    """Parse CSV into list-of-dicts using csv.DictReader."""
    with open(path, newline="") as f:
        return list(csv.DictReader(f, delimiter=delimiter))


def write_csv(rows: list[dict], path: str) -> None:
    """Write list-of-dicts to CSV, using the first row's keys as header."""
    if not rows:
        open(path, "w").close(); return
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)


def read_json(path: str) -> Any:
    with open(path) as f: return json.load(f)


def write_json(obj: Any, path: str, indent: int = 2) -> None:
    with open(path, "w") as f: json.dump(obj, f, indent=indent, default=str)


def read_excel(path: str, sheet_name: str | int | None = 0) -> list[dict]:
    """Read an .xlsx sheet into list-of-dicts via pandas/openpyxl."""
    import pandas as pd
    df = pd.read_excel(path, sheet_name=sheet_name if sheet_name is not None else 0)
    return df.to_dict("records")


def read_parquet(path: str) -> list[dict]:
    """Columnar parquet reader."""
    import pandas as pd
    return pd.read_parquet(path).to_dict("records")


def read_netcdf(path: str, variable: str | None = None) -> Any:
    """NetCDF / HDF5 gridded data reader. Returns the dataset (or specific
    variable) as an xarray object. Used for climate, oceanographic, and
    remote-sensing inputs."""
    import xarray as xr
    ds = xr.open_dataset(path)
    return ds[variable] if variable else ds


def read_shapefile(path: str) -> list[dict]:
    """ESRI shapefile / GeoJSON / geopackage vector reader. Returns one dict
    per feature with attribute fields plus a 'geometry_wkt' string."""
    import geopandas as gpd
    gdf = gpd.read_file(path)
    out = []
    for _, row in gdf.iterrows():
        d = {k: row[k] for k in gdf.columns if k != "geometry"}
        d["geometry_wkt"] = row.geometry.wkt if row.geometry is not None else None
        out.append(d)
    return out


def read_fasta(path: str) -> list[dict]:
    """FASTA sequence reader. Returns [{id, description, sequence}]."""
    with open(path) as f:
        records, cur = [], None
        for line in f:
            line = line.rstrip()
            if line.startswith(">"):
                if cur: records.append(cur)
                parts = line[1:].split(None, 1)
                cur = {"id": parts[0],
                       "description": parts[1] if len(parts) > 1 else "",
                       "sequence": ""}
            elif cur is not None:
                cur["sequence"] += line
        if cur: records.append(cur)
    return records


def pivot_long_to_wide(rows: list[dict], index: str, columns: str,
                      values: str) -> list[dict]:
    """Long-to-wide reshape (like pandas.pivot)."""
    wide: dict = {}
    col_set: set = set()
    for r in rows:
        idx = r[index]; col = r[columns]; val = r[values]
        wide.setdefault(idx, {index: idx})[col] = val
        col_set.add(col)
    return list(wide.values())


def pivot_wide_to_long(rows: list[dict], id_cols: list[str],
                      value_cols: list[str], var_name: str = "variable",
                      value_name: str = "value") -> list[dict]:
    """Wide-to-long melt."""
    out = []
    for r in rows:
        base = {k: r[k] for k in id_cols}
        for c in value_cols:
            out.append({**base, var_name: c, value_name: r.get(c)})
    return out


def drop_missing(rows: list[dict], cols: list[str] | None = None) -> list[dict]:
    """Remove rows where any (or listed) columns are None/empty."""
    def bad(v): return v is None or v == "" or v != v  # NaN
    if cols is None:
        return [r for r in rows if not any(bad(v) for v in r.values())]
    return [r for r in rows if not any(bad(r.get(c)) for c in cols)]


def coerce_numeric(rows: list[dict], cols: list[str]) -> list[dict]:
    """Cast named columns to float; non-parseable → None."""
    out = []
    for r in rows:
        r2 = dict(r)
        for c in cols:
            try: r2[c] = float(r2[c])
            except (TypeError, ValueError): r2[c] = None
        out.append(r2)
    return out


def join_tables(left: list[dict], right: list[dict], on: str,
               how: str = "inner") -> list[dict]:
    """SQL-style join on a single key."""
    idx = {r[on]: r for r in right}
    out = []
    for l in left:
        r = idx.get(l.get(on))
        if r is not None:
            out.append({**l, **{k: v for k, v in r.items() if k != on}})
        elif how == "left":
            out.append(dict(l))
    return out


def groupby_aggregate(rows: list[dict], by: str,
                     agg: dict[str, str]) -> list[dict]:
    """Group rows by `by` and apply per-column aggregations
    (mean|sum|min|max|count)."""
    from statistics import mean
    groups: dict = {}
    for r in rows: groups.setdefault(r[by], []).append(r)
    out = []
    for key, grp in groups.items():
        row = {by: key}
        for col, fn in agg.items():
            vals = [g[col] for g in grp if g.get(col) is not None]
            if fn == "mean": row[col] = mean(vals) if vals else None
            elif fn == "sum": row[col] = sum(vals)
            elif fn == "min": row[col] = min(vals) if vals else None
            elif fn == "max": row[col] = max(vals) if vals else None
            elif fn == "count": row[col] = len(vals)
        out.append(row)
    return out

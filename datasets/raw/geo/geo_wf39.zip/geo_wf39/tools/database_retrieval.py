"""Database retrieval tools.

Generic external-database queries. The two helpers used most often by this
task (`fetch_url` and `websearch`) have working implementations; the rest
raise NotImplementedError with a hint to the right Python client library so
that the agent can plug in the appropriate code if it needs them.
"""
from typing import Any
import json
import urllib.request
import urllib.parse


def websearch(query: str, max_results: int = 10) -> list[dict]:
    """Generic web search using the DuckDuckGo HTML endpoint.

    Returns a list of {title, url, snippet} dicts.
    """
    import re
    url = "https://duckduckgo.com/html/?q=" + urllib.parse.quote(query)
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=30) as r:
        html = r.read().decode(errors="ignore")
    pattern = re.compile(r'class="result__a"[^>]*href="([^"]+)"[^>]*>([^<]+)</a>')
    out = []
    for m in pattern.finditer(html):
        out.append({"url": m.group(1), "title": m.group(2), "snippet": ""})
        if len(out) >= max_results:
            break
    return out


def fetch_url(url: str, timeout: int = 30) -> bytes:
    """HTTP GET with redirects. Returns the raw response body bytes."""
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def query_pubchem(identifier: str, namespace: str = "cid") -> dict:
    """PubChem PUG-REST lookup. namespace in {cid, name, smiles, inchikey}."""
    url = (f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/"
           f"{namespace}/{urllib.parse.quote(str(identifier))}/JSON")
    return json.loads(fetch_url(url))


def query_chembl(target_id: str, activity_type: str = "IC50") -> list[dict]:
    """ChEMBL bioactivity query. Use the chembl_webresource_client library
    in the agent's environment for full pagination."""
    raise NotImplementedError("Install `chembl_webresource_client` and use the activity API")


def query_uniprot(accession: str) -> dict:
    """UniProt entry fetch via REST."""
    url = f"https://rest.uniprot.org/uniprotkb/{accession}.json"
    return json.loads(fetch_url(url))


def query_pdb(pdb_id: str) -> dict:
    """RCSB PDB entry metadata via REST."""
    url = f"https://data.rcsb.org/rest/v1/core/entry/{pdb_id}"
    return json.loads(fetch_url(url))


def query_geo(accession: str) -> dict:
    """NCBI GEO series/sample fetch (GSE/GSM). Use biopython Entrez or NCBI's
    e-utils. Returns metadata + supplementary file list."""
    raise NotImplementedError("Use biopython Entrez (Bio.Entrez.esearch / efetch) for GEO")


def query_ncbi_entrez(db: str, term: str, retmax: int = 100) -> list[dict]:
    """Generic Entrez E-search + E-fetch."""
    raise NotImplementedError("Use Bio.Entrez (biopython) for NCBI Entrez programmatic access")


def query_usgs_comcat(starttime: str, endtime: str, minmagnitude: float = 0,
                     bbox: tuple | None = None) -> list[dict]:
    """USGS ComCat earthquake catalog query."""
    params = {"format": "geojson", "starttime": starttime, "endtime": endtime,
              "minmagnitude": str(minmagnitude)}
    if bbox:
        params.update({"minlongitude": str(bbox[0]), "minlatitude": str(bbox[1]),
                       "maxlongitude": str(bbox[2]), "maxlatitude": str(bbox[3])})
    url = "https://earthquake.usgs.gov/fdsnws/event/1/query?" + urllib.parse.urlencode(params)
    data = json.loads(fetch_url(url))
    out = []
    for f in data.get("features", []):
        p = f.get("properties", {})
        c = f.get("geometry", {}).get("coordinates", [None, None, None])
        out.append({"time": p.get("time"), "mag": p.get("mag"),
                    "place": p.get("place"), "lon": c[0], "lat": c[1], "depth": c[2]})
    return out


def query_world_bank(indicator: str, country: str = "all",
                    start: int = 1960, end: int = 2023) -> list[dict]:
    """World Bank WDI indicator series."""
    url = (f"https://api.worldbank.org/v2/country/{country}/indicator/{indicator}"
           f"?date={start}:{end}&format=json&per_page=20000")
    j = json.loads(fetch_url(url))
    return j[1] if isinstance(j, list) and len(j) > 1 else []


def query_openalex(search: str, filters: dict | None = None) -> list[dict]:
    """OpenAlex works/authors/venues search."""
    params = {"search": search, "per-page": "25"}
    if filters:
        params["filter"] = ",".join(f"{k}:{v}" for k, v in filters.items())
    url = "https://api.openalex.org/works?" + urllib.parse.urlencode(params)
    return json.loads(fetch_url(url)).get("results", [])


def query_doi(doi: str) -> dict:
    """Resolve a DOI to a Crossref metadata record."""
    url = f"https://api.crossref.org/works/{urllib.parse.quote(doi)}"
    return json.loads(fetch_url(url)).get("message", {})

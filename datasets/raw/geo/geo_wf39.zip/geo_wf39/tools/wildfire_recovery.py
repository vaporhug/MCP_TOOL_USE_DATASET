#!/usr/bin/env python3
"""Tools for post-fire vegetation/photosynthetic recovery analysis.

Primitives for chronosequence construction, dGPP fitting, recovery time
estimation, severity-stratified summaries, and plotting. All MCP tools
return JSON-serialisable dicts; plotting tools return the artifact path.
"""

import os
import math
import json
import numpy as np
import pandas as pd
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Wildfire_Recovery_Tools")


# ---------------------------------------------------------------------------
#  I/O
# ---------------------------------------------------------------------------

@mcp.tool()
def load_csv(csv_path: str, filters: dict = None, max_rows: int = 100) -> dict:
    """Load a CSV file, optionally filtering rows by exact-match column values.

    Args:
        csv_path: Path to CSV
        filters: Optional dict of {column: value} for equality filtering
        max_rows: Maximum number of rows to return in the preview

    Returns:
        dict with columns, total_rows, preview rows.
    """
    df = pd.read_csv(csv_path)
    if filters:
        for c, v in filters.items():
            if c in df.columns:
                df = df[df[c] == v]
    return {
        "columns": list(df.columns),
        "total_rows": int(len(df)),
        "rows": df.head(max_rows).to_dict("records"),
        "truncated": len(df) > max_rows,
    }


@mcp.tool()
def summarise_column(csv_path: str, column: str, group_by: str = None) -> dict:
    """Compute count / mean / std / min / median / max for a numeric column.

    Args:
        csv_path: Path to CSV
        column: Numeric column to summarise
        group_by: Optional column to group by; returns a per-group dict
    """
    df = pd.read_csv(csv_path)
    if column not in df.columns:
        return {"error": f"Column {column!r} not found"}
    if group_by:
        grp = df.groupby(group_by)[column]
        out = {}
        for k, g in grp:
            arr = g.dropna().values.astype(float)
            if len(arr) == 0:
                continue
            out[str(k)] = {
                "count": int(len(arr)),
                "mean": round(float(arr.mean()), 4),
                "std": round(float(arr.std()), 4),
                "min": round(float(arr.min()), 4),
                "median": round(float(np.median(arr)), 4),
                "max": round(float(arr.max()), 4),
            }
        return {"by": group_by, "groups": out}
    arr = df[column].dropna().values.astype(float)
    return {
        "n": int(len(arr)),
        "mean": round(float(arr.mean()), 4),
        "std": round(float(arr.std()), 4),
        "min": round(float(arr.min()), 4),
        "median": round(float(np.median(arr)), 4),
        "max": round(float(arr.max()), 4),
    }


# ---------------------------------------------------------------------------
#  Chronosequence construction
# ---------------------------------------------------------------------------

@mcp.tool()
def build_chronosequence(gpp_csv: str, fire_metadata_csv: str = None) -> dict:
    """Re-organise per-site annual GPP into a chronosequence indexed by
    years-since-fire.

    The input GPP CSV must have columns:
        site_id, kind ('burned'|'control'), fire_year, year, annual_gpp_gC_m2_yr

    For each (site_id, year) row labelled 'burned' the years-since-fire
    is computed as ``year - fire_year``. Pre-fire records get negative
    values. Control rows are ignored here.

    Returns aggregate counts so the agent can see how many fires contributed
    data at each years-since-fire bin.
    """
    df = pd.read_csv(gpp_csv)
    bdf = df[df["kind"] == "burned"].copy()
    bdf["years_since_fire"] = bdf["year"] - bdf["fire_year"]
    bdf = bdf.dropna(subset=["annual_gpp_gC_m2_yr"])
    counts = bdf.groupby("years_since_fire").size().to_dict()
    counts = {int(k): int(v) for k, v in counts.items()}
    return {
        "n_unique_fires": int(bdf["site_id"].nunique()),
        "years_since_fire_range": [int(bdf.years_since_fire.min()),
                                   int(bdf.years_since_fire.max())],
        "n_total_records": int(len(bdf)),
        "counts_by_ysf": counts,
    }


@mcp.tool()
def compute_dgpp(gpp_csv: str, out_csv: str = None) -> dict:
    """Compute dGPP = burned_GPP - control_GPP for each (site_id, year).

    Pairs the burned and control records by site_id+year. Returns summary
    statistics of dGPP across all sites and years and optionally writes a
    long-format CSV with columns
        site_id, fire_year, year, years_since_fire, gpp_burned, gpp_control, dGPP
    """
    df = pd.read_csv(gpp_csv)
    burned = df[df["kind"] == "burned"][[
        "site_id", "fire_year", "year", "annual_gpp_gC_m2_yr"
    ]].rename(columns={"annual_gpp_gC_m2_yr": "gpp_burned"})
    control = df[df["kind"] == "control"][[
        "site_id", "year", "annual_gpp_gC_m2_yr"
    ]].rename(columns={"annual_gpp_gC_m2_yr": "gpp_control"})
    merged = burned.merge(control, on=["site_id", "year"], how="inner")
    merged["years_since_fire"] = merged["year"] - merged["fire_year"]
    merged["dGPP"] = merged["gpp_burned"] - merged["gpp_control"]
    if out_csv:
        merged.to_csv(out_csv, index=False)
    valid = merged.dropna(subset=["dGPP"])
    return {
        "n_records": int(len(merged)),
        "n_with_both": int(len(valid)),
        "dGPP_summary": {
            "mean": round(float(valid["dGPP"].mean()), 3),
            "std": round(float(valid["dGPP"].std()), 3),
            "median": round(float(np.median(valid["dGPP"])), 3),
            "n": int(len(valid)),
        },
        "out_csv": out_csv,
    }


@mcp.tool()
def chronosequence_mean(dgpp_csv: str, ysf_min: int = 0, ysf_max: int = 30) -> dict:
    """For each year-since-fire bin in [ysf_min, ysf_max] compute the mean,
    SE, and count of dGPP values across all fires.

    Args:
        dgpp_csv: CSV produced by :func:`compute_dgpp` (must have years_since_fire, dGPP)
        ysf_min: Minimum years-since-fire (inclusive)
        ysf_max: Maximum years-since-fire (inclusive)

    Returns a list of records with ``years_since_fire``, ``mean_dGPP``,
    ``se_dGPP``, ``n_fires``.
    """
    df = pd.read_csv(dgpp_csv)
    df = df.dropna(subset=["dGPP"])
    df = df[(df["years_since_fire"] >= ysf_min) & (df["years_since_fire"] <= ysf_max)]
    out = []
    for ysf, grp in df.groupby("years_since_fire"):
        arr = grp["dGPP"].values.astype(float)
        out.append({
            "years_since_fire": int(ysf),
            "mean_dGPP": round(float(arr.mean()), 3),
            "se_dGPP": round(float(arr.std(ddof=1) / max(np.sqrt(len(arr)), 1)), 3),
            "n_fires": int(len(arr)),
        })
    return {"recovery_curve": sorted(out, key=lambda r: r["years_since_fire"])}


@mcp.tool()
def first_year_dgpp(dgpp_csv: str, year_window: int = 1) -> dict:
    """Mean dGPP in the first ``year_window`` year(s) after fire.

    Year-1 mean dGPP is the mean
    dGPP at year 1 since fire across all forest fires. This function
    computes the analogous statistic at the chronosequence level for
    whatever subset of fires is in the input.

    Returns mean, SE, and n.
    """
    df = pd.read_csv(dgpp_csv)
    df = df.dropna(subset=["dGPP"])
    sub = df[(df["years_since_fire"] >= 1) & (df["years_since_fire"] <= year_window)]
    arr = sub["dGPP"].values.astype(float)
    if len(arr) == 0:
        return {"error": "No records in window"}
    return {
        "year_window": year_window,
        "mean_dGPP_g_C_m2_yr": round(float(arr.mean()), 3),
        "se_dGPP_g_C_m2_yr": round(float(arr.std(ddof=1) / np.sqrt(len(arr))), 3),
        "n_fire_years": int(len(arr)),
    }


# ---------------------------------------------------------------------------
#  Recovery-time estimation
# ---------------------------------------------------------------------------

@mcp.tool()
def estimate_recovery_time(dgpp_csv: str, threshold: float = 0.0,
                           min_n: int = 3, smoothing_window: int = 3,
                           ysf_max: int = 30) -> dict:
    """Estimate post-fire recovery time as the smallest year-since-fire ``Y``
    where the smoothed mean dGPP exceeds ``threshold``.

    The default threshold of zero corresponds to the paper's definition of
    "recovery to undisturbed baseline" (dGPP returns to 0).

    The procedure is:
    1. Compute mean dGPP at each year-since-fire bin from `dgpp_csv`
    2. Apply a centred rolling mean of width ``smoothing_window``
    3. Return the smallest YSF with smoothed mean dGPP >= threshold and
       at least ``min_n`` fires contributing.

    Returns dict with recovery_time_years (None if no crossing), the smoothed
    curve, and a confidence note.
    """
    df = pd.read_csv(dgpp_csv)
    df = df.dropna(subset=["dGPP"])
    df = df[(df["years_since_fire"] >= 1) & (df["years_since_fire"] <= ysf_max)]
    if len(df) == 0:
        return {"error": "No data"}
    grp = df.groupby("years_since_fire")["dGPP"].agg(['mean', 'count']).reset_index()
    grp = grp.sort_values("years_since_fire")
    smoothed = grp["mean"].rolling(window=smoothing_window, center=True, min_periods=1).mean()
    grp["smoothed"] = smoothed
    rec_year = None
    for _, row in grp.iterrows():
        if row["count"] >= min_n and row["smoothed"] >= threshold:
            rec_year = int(row["years_since_fire"])
            break
    return {
        "recovery_time_years": rec_year,
        "threshold": threshold,
        "min_n_fires_required": min_n,
        "smoothing_window": smoothing_window,
        "curve": grp.to_dict("records"),
    }


@mcp.tool()
def fit_exponential_recovery(dgpp_csv: str, ysf_max: int = 30) -> dict:
    """Fit the recovery curve mean_dGPP(ysf) = -A * exp(-ysf / tau) to the
    chronosequence-mean dGPP using non-linear least squares.

    The fitted curve approaches zero asymptotically, so it does not define
    a finite "time to exactly zero". For finite baseline recovery, use
    estimate_recovery_time(). This helper returns the magnitude A, e-folding
    time tau, and an approximate 95 % deficit-closure time (3 * tau).
    """
    from scipy.optimize import curve_fit
    df = pd.read_csv(dgpp_csv).dropna(subset=["dGPP"])
    df = df[(df["years_since_fire"] >= 1) & (df["years_since_fire"] <= ysf_max)]
    if len(df) == 0:
        return {"error": "No data"}
    grp = df.groupby("years_since_fire")["dGPP"].mean().reset_index()
    x = grp["years_since_fire"].values.astype(float)
    y = grp["dGPP"].values.astype(float)
    def model(t, A, tau):
        return -A * np.exp(-t / tau)
    try:
        popt, pcov = curve_fit(model, x, y, p0=[max(abs(y.min()), 50.0), 5.0],
                               bounds=([0, 0.1], [10000, 200]))
        A, tau = float(popt[0]), float(popt[1])
        yhat = model(x, A, tau)
        rss = float(np.sum((y - yhat) ** 2))
        tss = float(np.sum((y - y.mean()) ** 2))
        r2 = 1 - rss / tss if tss > 0 else float('nan')
        return {
            "A_g_C_m2_yr": round(A, 3),
            "tau_years": round(tau, 3),
            "time_to_95pct_deficit_closure_years": round(3 * tau, 2),
            "recovery_time_95pct_years": round(3 * tau, 2),
            "note": "Exponential recovery approaches zero asymptotically; use estimate_recovery_time for finite dGPP >= 0 crossing.",
            "r2": round(r2, 4),
            "n_points": int(len(x)),
        }
    except Exception as e:
        return {"error": f"Fit failed: {e}"}


# ---------------------------------------------------------------------------
#  Stratified analyses (size, severity, decade)
# ---------------------------------------------------------------------------

@mcp.tool()
def stratified_recovery(dgpp_csv: str, fire_metadata_csv: str,
                        stratify_by: str, n_quantiles: int = 5,
                        ysf_max: int = 30) -> dict:
    """Compute recovery curves stratified by quantiles of a fire-level
    attribute (e.g., area, prefire_gpp, mean_temp, mean_precip,
    elevation, severity).

    The metadata CSV must contain columns ``site_id`` plus the chosen
    stratification column. Returns one recovery curve per quantile with
    recovery time and initial dGPP loss.
    """
    df = pd.read_csv(dgpp_csv).dropna(subset=["dGPP"])
    md = pd.read_csv(fire_metadata_csv)
    if "site_id" not in md.columns or stratify_by not in md.columns:
        return {"error": f"metadata csv must have site_id and {stratify_by}"}
    df = df.merge(md[["site_id", stratify_by]], on="site_id", how="left")
    df = df.dropna(subset=[stratify_by])
    df = df[(df["years_since_fire"] >= 1) & (df["years_since_fire"] <= ysf_max)]

    # Compute quantile bin edges
    edges = np.quantile(df[stratify_by].values, np.linspace(0, 1, n_quantiles + 1))
    df["_qbin"] = pd.cut(df[stratify_by], bins=edges, labels=False, include_lowest=True)

    out = {}
    for q in sorted(df["_qbin"].dropna().unique()):
        sub = df[df["_qbin"] == q]
        if len(sub) == 0:
            continue
        gm = sub.groupby("years_since_fire")["dGPP"].agg(['mean', 'count']).reset_index()
        gm = gm.sort_values("years_since_fire")
        # First-year mean dGPP
        first = sub[sub.years_since_fire == 1]["dGPP"]
        first_year_mean = float(first.mean()) if len(first) else float('nan')
        first_year_se = float(first.std(ddof=1) / np.sqrt(max(len(first), 1))) if len(first) else float('nan')
        # Recovery time: smallest ysf with smoothed mean >= 0
        sm = gm["mean"].rolling(window=3, center=True, min_periods=1).mean()
        rec = None
        for ysf, val, cnt in zip(gm["years_since_fire"].values, sm.values, gm["count"].values):
            if cnt >= 3 and val >= 0:
                rec = int(ysf); break
        out[f"Q{int(q)+1}"] = {
            "value_range": [round(float(edges[int(q)]), 3),
                            round(float(edges[int(q)+1]), 3)],
            "n_records": int(len(sub)),
            "n_fires": int(sub["site_id"].nunique()),
            "first_year_mean_dGPP": round(first_year_mean, 3) if first_year_mean == first_year_mean else None,
            "first_year_se_dGPP": round(first_year_se, 3) if first_year_se == first_year_se else None,
            "recovery_time_years": rec,
        }
    return {"stratify_by": stratify_by, "quantile_bins": int(n_quantiles), "results": out}


@mcp.tool()
def cumulative_landscape_legacy(dgpp_csv: str, fire_metadata_csv: str,
                                area_col: str = "acres") -> dict:
    """Compute the area-weighted cumulative landscape GPP legacy time series.

    For each calendar year, sum (dGPP * area_ha) across all fires whose
    ysf >= 1 in that calendar year. Result is in megatonnes CO2 per year
    using GPP * 44/12 / 1e12 conversion.
    """
    df = pd.read_csv(dgpp_csv).dropna(subset=["dGPP"])
    md = pd.read_csv(fire_metadata_csv)
    if area_col not in md.columns:
        return {"error": f"area_col {area_col} missing"}
    md["area_ha"] = md[area_col].astype(float) * 0.404686  # acres -> ha
    df = df.merge(md[["site_id", "area_ha"]], on="site_id", how="left")
    df = df.dropna(subset=["area_ha"])
    df = df[df["years_since_fire"] >= 1]
    # convert dGPP (g C / m^2 / yr) * area (ha = 1e4 m^2) -> g C / yr -> Mt CO2
    df["legacy_MtCO2"] = df["dGPP"] * df["area_ha"] * 1e4 * (44.0/12.0) / 1e12
    yr = df.groupby("year")["legacy_MtCO2"].sum().reset_index()
    yr = yr.sort_values("year")
    return {
        "n_years": int(len(yr)),
        "year_range": [int(yr.year.min()), int(yr.year.max())],
        "results": yr.to_dict("records"),
    }


# ---------------------------------------------------------------------------
#  Plotting (one tool per image)
# ---------------------------------------------------------------------------

@mcp.tool()
def plot_recovery_curve(dgpp_csv: str, output_path: str,
                        ysf_max: int = 30, title: str = None) -> str:
    """Plot the chronosequence recovery curve: mean dGPP vs years-since-fire,
    with 95% confidence shading. Returns path to the PNG."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    df = pd.read_csv(dgpp_csv).dropna(subset=["dGPP"])
    df = df[(df["years_since_fire"] >= 1) & (df["years_since_fire"] <= ysf_max)]
    grp = df.groupby("years_since_fire")["dGPP"].agg(["mean", "std", "count"]).reset_index()
    grp["se"] = grp["std"] / np.sqrt(grp["count"])
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.fill_between(grp["years_since_fire"], grp["mean"] - 1.96 * grp["se"],
                    grp["mean"] + 1.96 * grp["se"], color="C3", alpha=0.25)
    ax.plot(grp["years_since_fire"], grp["mean"], "C3-", lw=2, label="mean dGPP")
    ax.axhline(0, color="k", lw=0.6, ls=":")
    ax.set_xlabel("years since fire")
    ax.set_ylabel("dGPP  (g C m$^{-2}$ yr$^{-1}$)")
    ax.set_title(title or "Post-fire GPP recovery (burned − control)")
    ax.legend()
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return output_path


@mcp.tool()
def plot_recovery_by_stratum(dgpp_csv: str, fire_metadata_csv: str,
                             stratify_by: str, output_path: str,
                             n_quantiles: int = 5, ysf_max: int = 30,
                             title: str = None) -> str:
    """Plot the recovery curve per quantile of a fire-level attribute on one
    figure. Useful for visualising e.g. how fire size shapes recovery."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    df = pd.read_csv(dgpp_csv).dropna(subset=["dGPP"])
    md = pd.read_csv(fire_metadata_csv)
    df = df.merge(md[["site_id", stratify_by]], on="site_id", how="left")
    df = df.dropna(subset=[stratify_by])
    df = df[(df["years_since_fire"] >= 1) & (df["years_since_fire"] <= ysf_max)]
    edges = np.quantile(df[stratify_by].values, np.linspace(0, 1, n_quantiles + 1))
    df["_q"] = pd.cut(df[stratify_by], bins=edges, labels=False, include_lowest=True)
    fig, ax = plt.subplots(figsize=(8, 5))
    cmap = plt.get_cmap("plasma")
    for q in sorted(df["_q"].dropna().unique()):
        sub = df[df["_q"] == q]
        gm = sub.groupby("years_since_fire")["dGPP"].mean().reset_index()
        gm = gm.sort_values("years_since_fire")
        col = cmap(int(q) / max(n_quantiles - 1, 1))
        ax.plot(gm["years_since_fire"], gm["dGPP"], "-",
                color=col, lw=2,
                label=f"Q{int(q)+1}: [{edges[int(q)]:.0f},{edges[int(q)+1]:.0f}]")
    ax.axhline(0, color="k", lw=0.5, ls=":")
    ax.set_xlabel("years since fire")
    ax.set_ylabel("dGPP  (g C m$^{-2}$ yr$^{-1}$)")
    ax.set_title(title or f"Recovery by {stratify_by} quantile")
    ax.legend(fontsize=8, loc="lower right")
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return output_path


@mcp.tool()
def plot_landscape_legacy(legacy_csv: str, output_path: str,
                          rolling_window: int = 3, title: str = None) -> str:
    """Plot annual landscape-scale dGPP legacy (Mt CO2) with a rolling-mean
    overlay. Input must have columns 'year' and 'legacy_MtCO2'."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    df = pd.read_csv(legacy_csv).sort_values("year")
    fig, ax = plt.subplots(figsize=(8, 4.5))
    pos = df["legacy_MtCO2"] >= 0
    ax.bar(df.year[pos], df.legacy_MtCO2[pos], color="C2", alpha=0.7,
           label="net GPP enhancement")
    ax.bar(df.year[~pos], df.legacy_MtCO2[~pos], color="C1", alpha=0.7,
           label="net GPP reduction")
    rolling = df["legacy_MtCO2"].rolling(window=rolling_window, center=True).mean()
    ax.plot(df.year, rolling, "k-", lw=2, label=f"{rolling_window}-yr rolling mean")
    ax.axhline(0, color="k", lw=0.5)
    ax.set_xlabel("year")
    ax.set_ylabel("fire GPP legacy  (Mt CO$_2$ yr$^{-1}$)")
    ax.set_title(title or "Landscape-scale fire GPP legacy")
    ax.legend(fontsize=9)
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return output_path


@mcp.tool()
def plot_fire_locations(fires_csv: str, output_path: str,
                        lat_col: str = "centroid_lat",
                        lon_col: str = "centroid_lon",
                        size_col: str = "acres",
                        year_col: str = "fire_year",
                        title: str = None) -> str:
    """Scatter map of fire centroids over California, colour-coded by year
    and sized by area. Returns the path."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    df = pd.read_csv(fires_csv).dropna(subset=[lat_col, lon_col])
    fig, ax = plt.subplots(figsize=(7, 8))
    sizes = np.clip(np.sqrt(df[size_col].values + 1), 5, 200)
    sc = ax.scatter(df[lon_col], df[lat_col], s=sizes, c=df[year_col],
                    cmap="viridis", alpha=0.7, edgecolor="k", lw=0.3)
    cb = plt.colorbar(sc, ax=ax, label="fire year", fraction=0.04, pad=0.02)
    ax.set_xlabel("longitude")
    ax.set_ylabel("latitude")
    ax.set_xlim(-125, -113.5)
    ax.set_ylim(32, 43)
    ax.set_title(title or "California fires sampled (size proportional to acres)")
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return output_path


# ---------------------------------------------------------------------------
#  Generic helpers
# ---------------------------------------------------------------------------

@mcp.tool()
def correlate(values_x: list, values_y: list) -> dict:
    """Pearson + Spearman correlation between two equal-length lists."""
    from scipy.stats import pearsonr, spearmanr
    x = np.array(values_x, dtype=float)
    y = np.array(values_y, dtype=float)
    mask = ~(np.isnan(x) | np.isnan(y))
    x, y = x[mask], y[mask]
    if len(x) < 3:
        return {"error": "Need at least 3 valid pairs"}
    pr, pp = pearsonr(x, y)
    sr, sp = spearmanr(x, y)
    return {"n": int(len(x)),
            "pearson_r": round(float(pr), 4), "pearson_p": round(float(pp), 6),
            "spearman_rho": round(float(sr), 4), "spearman_p": round(float(sp), 6)}


@mcp.tool()
def linear_regression(x_values: list, y_values: list) -> dict:
    """Ordinary least squares linear regression with slope / intercept / r^2 / p."""
    from scipy.stats import linregress
    x = np.array(x_values, dtype=float)
    y = np.array(y_values, dtype=float)
    mask = ~(np.isnan(x) | np.isnan(y))
    x, y = x[mask], y[mask]
    if len(x) < 3:
        return {"error": "Need at least 3 valid pairs"}
    res = linregress(x, y)
    return {
        "slope": round(float(res.slope), 6),
        "intercept": round(float(res.intercept), 4),
        "r_squared": round(float(res.rvalue) ** 2, 4),
        "p_value": round(float(res.pvalue), 6),
        "n": int(len(x)),
    }


if __name__ == "__main__":
    mcp.run(transport="stdio")

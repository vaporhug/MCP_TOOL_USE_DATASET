# Nutricline Trends on the GLODAPv2.2022 45S-45N / 0-1500 m Subset, 1972-2020

## Overview

Per Gerace et al. 2025, we apply Redfield-proportional nutricline thresholds
(NO3 = 3 umol/kg, PO4 = 3/16 umol/kg = 0.1875 umol/kg) cast-by-cast,
aggregate per 1-degree site, build site-annual means, fit per-site OLS
slopes, and aggregate to global / hemispheric / basin medians with
bootstrap CI95. Headline question: is the phosphacline deepening faster
than the nitracline on the bundled subset, and is the difference
hemispherically structured?

Numeric values below are the deterministic output of the bundled
pipeline at the documented default settings (`min_years=2`,
`grid_deg=1.0`, `n_bootstrap=10,000` for site-median CIs).

## Global annual time series (paper site-annual aggregation, 1972-2020)

| Series | OLS slope (m/yr) | bootstrap CI95 (m/yr) | p-value | n_years |
| --- | --- | --- | --- | --- |
| Nitracline (Z_NO3, threshold 3 umol/kg) | +0.327 | [-0.162, +0.790] | 0.121 | 47 |
| Phosphacline (Z_PO4, threshold 0.1875 umol/kg) | +0.273 | [-0.260, +0.785] | 0.347 | 47 |

Both global OLS slopes are positive (downward in depth) but not
individually significant on the bundled subset; the headline contrast
between nitracline and phosphacline emerges in the **per-site median
slopes** below (paper-aligned robustness statistic), not in the
all-cast global OLS.

## Per-site OLS slopes (1 deg x 1 deg grid)

| Nutrient | n_sites | median slope (m/yr) | bootstrap CI95 of median (m/yr) | n_positive sites | n_negative sites |
| --- | --- | --- | --- | --- | --- |
| Nitracline | 2,496 | -0.137 | [-0.212, -0.049] | 1,170 | 1,325 |
| Phosphacline | 1,893 | **+0.265** | **[+0.168, +0.398]** | 1,051 | 840 |

The phosphacline median is robustly positive across 1-deg sites
(95% CI excludes zero, with more positive than negative sites); the
nitracline median is robustly weakly negative (CI excludes zero).
This reproduces the paper's headline contrast in sign on the
bundled cohort.

## Regional median slopes (paper Fig. 2C-style breakdown)

### Phosphacline (PO4)

| Region | n_sites | median slope (m/yr) | bootstrap CI95 (m/yr) |
| --- | --- | --- | --- |
| Global             | 1,893 | +0.265 | [+0.167, +0.398] |
| Northern hemisphere | 1,087 | +0.191 | [+0.020, +0.371] |
| Southern hemisphere | 806  | **+0.373** | **[+0.224, +0.561]** |

The southern-hemisphere phosphacline median is roughly **2× the northern
median**, consistent with the paper's southern-hemisphere-dominant
phosphacline deepening pattern.

### Nitracline (NO3)

| Region | n_sites | median slope (m/yr) | bootstrap CI95 (m/yr) |
| --- | --- | --- | --- |
| Global             | 2,496 | -0.137 | [-0.211, -0.049] |
| Northern hemisphere | 1,291 | -0.083 | [-0.207, +0.027] |
| Southern hemisphere | 1,205 | -0.164 | [-0.293, -0.062] |

The nitracline shows weakly negative (i.e., shoaling) medians in both
hemispheres; the southern hemisphere is slightly more negative.

## Figures

1. `artifacts/global_nutricline_timeseries.png` — annual global mean
   nitracline and phosphacline depth (1972-2020) with OLS lines and
   bootstrap CI95 bands (n=1,000 resamples).
2. `artifacts/site_trend_histogram.png` — histogram of per-site OLS
   slopes for nitracline and phosphacline, with median markers.
3. `artifacts/regional_medians.png` — regional medians for both
   nutrients with bootstrap CI95 bars (global / NH / SH / four
   hemisphere x basin cells / Indian).

## Conclusions

1. On the bundled 1972-2020 GLODAPv2.2022 (45S-45N, 0-1500 m) subset,
   the phosphacline shows a robustly positive per-site median slope
   (+0.265 m/yr, CI95 +0.168..+0.398) while the nitracline shows a
   robustly negative median slope (-0.137 m/yr, CI95 -0.211..-0.049).
   The two median trends differ in sign, consistent with the paper's
   "phosphate availability declines faster than nitrate availability"
   finding.

2. Phosphacline deepening is hemispherically structured: SH median
   +0.373 m/yr is roughly twice the NH median +0.191 m/yr, with the
   SH CI95 entirely above zero. This reproduces the paper's
   southern-hemisphere-dominant phosphacline-deepening pattern on
   the bundled subset.

3. Method note: the global aggregation uses the paper's site-annual
   pipeline (per-site annual means first, then global mean across
   sites per year) implemented by `annual_global_means`; this avoids
   densely sampled cruises dominating the global signal.

## Supplementary non-parametric robustness checks

Computed on the same annual site-mean series via the bundled
`mann_kendall_test` and `theil_sen_slope` tools (no additional
assumptions about linearity or normality):

| Series | Mann-Kendall S | Mann-Kendall tau | MK p-value | MK verdict | Theil-Sen slope (m/yr) | TS bootstrap CI95 (m/yr) |
| --- | ---: | ---: | ---: | --- | ---: | --- |
| Nitracline   | 231 | 0.214 | 0.035 | increasing | +0.408 | [-0.046, +0.785] |
| Phosphacline | 171 | 0.158 | 0.119 | no trend  | +0.397 | [-0.069, +0.877] |

Both non-parametric estimators give positive Theil-Sen slopes
consistent in sign with the global OLS estimates above, but with
wider CIs that include zero — i.e., the simple global annual-mean
trend is not individually significant on this 1972-2020 cohort for
either nutrient. The robust per-site median analysis above is the
headline result and is unaffected by this limitation.

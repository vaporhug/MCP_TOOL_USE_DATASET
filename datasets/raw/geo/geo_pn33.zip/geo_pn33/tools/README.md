# geo_pn33 - Tool Reference

Tools for the upper-ocean nutricline-trend analysis based on
GLODAPv2.2022 hydrographic profiles.

## Files

- `nutricline_analysis.py` - domain MCP server
  (`FastMCP("Ocean_Nutricline_Tools")`). Loads the GLODAPv2.2022 CSV
  subset, applies QC flags, detects per-cast nutricline depths via
  threshold-crossing interpolation, computes site-specific OLS slopes,
  Mann-Kendall and Theil-Sen non-parametric trend tests, regional
  aggregation with bootstrap CIs, and renders the three answer plots.
- `data_processing.py` - generic CSV / JSON I/O, group-by, summary
  statistics, coordinate gridding helpers (no domain logic).
- `database_retrieval.py` - HTTP/DOI lookups (Crossref, NCEI catalog
  enumeration). Implementations rely on `urllib.request` only.

## Domain tools (FastMCP @mcp.tool decorators)

### Loaders / QC
- `load_glodap_csv(csv_path)` - inspect the staged GLODAP subset
  (row count, year range, lat range, basins).
- `filter_qc(csv_path, nutrient, output_csv)` - keep rows where the
  GLODAP quality flag for the chosen nutrient is 2 (good).

### Nutricline detection
- `detect_nutricline_depths(csv_path, nutrient, threshold, min_depth_m,
  output_csv)` - per-cast threshold-crossing depth via linear
  interpolation between the bracketing samples.

### Trend tests
- `linear_trend(years, values)` - OLS slope, SE, p-value, R-squared.
- `mann_kendall_test(values, times)` - non-parametric S statistic and
  Kendall's tau.
- `theil_sen_slope(years, values)` - median pairwise slope with 95%
  bootstrap CI.

### Aggregation
- `site_specific_trends(nutricline_csv, output_csv, min_years, grid_deg)`
  - per-1deg-cell OLS slope of depth vs. year.
- `regional_aggregate(site_trend_csv)` - hemispheric and basin medians
  with 10000-sample bootstrap CIs.
- `annual_global_means(nutricline_csv)` - annual mean depth time
  series for a globally averaged regression.

### Plotting (returns absolute PNG path)
- `plot_global_time_series(no3_summary, po4_summary, output_png)` -
  annual mean Z_NO3 and Z_PO4 vs. year with regression lines.
- `plot_site_trend_histogram(no3_site_csv, po4_site_csv, output_png)` -
  histogram of per-site slopes with median markers.
- `plot_regional_medians(regional_no3, regional_po4, output_png)` -
  bar chart of regional median slopes with bootstrap 95% CIs.

## Dependencies

```
numpy>=1.24
scipy>=1.11
matplotlib>=3.7
mcp>=0.9     # provides mcp.server.fastmcp
```

## Running

```bash
pip install numpy scipy matplotlib mcp
python tools/nutricline_analysis.py    # starts FastMCP server on stdio
```

## Data

Input file: `input_data/data/glodap_v2_2022_45S45N_0_1500m.csv`

A staged subset of the GLODAPv2.2022 merged data product
(https://doi.org/10.25921/1f4w-0t92, NOAA NCEI accession 0257247).
Restricted to 45S-45N latitude band and 0-1500 m depth, retaining
only the columns needed for nutricline analysis (G2cruise, G2station,
G2year, G2month, G2latitude, G2longitude, G2depth, G2temperature,
G2salinity, G2nitrate(+flag), G2phosphate(+flag) plus a basin tag).
~485 k bottle samples, ~37 MB.

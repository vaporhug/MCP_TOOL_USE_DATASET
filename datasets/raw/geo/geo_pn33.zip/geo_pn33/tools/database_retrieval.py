"""HTTP / DOI helpers for the geo_pn33 task.

Lightweight wrappers used to look up paper metadata and verify dataset
identifiers. Implementations rely only on the standard library
(`urllib.request`).
"""

from __future__ import annotations

import json
import os
import urllib.parse
import urllib.request


def fetch_url(url: str, timeout: int = 30) -> bytes:
    """HTTP GET with redirects; returns raw response bytes."""
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read()


def fetch_text(url: str, timeout: int = 30, encoding: str = "utf-8") -> str:
    """HTTP GET that decodes to text."""
    return fetch_url(url, timeout).decode(encoding, errors="replace")


def query_doi(doi: str, timeout: int = 30) -> dict:
    """Resolve a DOI via the Crossref REST API.

    Returns the Crossref `message` payload (title, authors, journal,
    year, abstract). Useful for verifying that a downloaded PDF
    matches the paper citation in the task spec.
    """
    url = f"https://api.crossref.org/works/{urllib.parse.quote(doi)}"
    return json.loads(fetch_text(url, timeout=timeout)).get("message", {})


def list_glodap_files(catalog_url: str = (
    "https://www.ncei.noaa.gov/data/oceans/ncei/ocads/data/0257247/"
), timeout: int = 30) -> list[str]:
    """List downloadable files in the GLODAPv2.2022 NOAA NCEI catalog."""
    html = fetch_text(catalog_url, timeout=timeout)
    out = []
    for tok in html.split("href=\""):
        end = tok.find("\"")
        if end <= 0:
            continue
        name = tok[:end]
        if name.endswith((".csv", ".mat", ".nc", ".zip")):
            out.append(catalog_url.rstrip("/") + "/" + name)
    return sorted(set(out))


def download_to_path(url: str, dest_path: str, timeout: int = 120) -> str:
    """Stream an HTTP resource to disk; returns the absolute destination."""
    os.makedirs(os.path.dirname(dest_path) or ".", exist_ok=True)
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=timeout) as resp, \
         open(dest_path, "wb") as f:
        while True:
            chunk = resp.read(65536)
            if not chunk:
                break
            f.write(chunk)
    return os.path.abspath(dest_path)

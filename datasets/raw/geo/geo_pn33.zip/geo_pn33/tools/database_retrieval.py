"""Offline metadata / catalog helpers for the geo_pn33 task.

This module previously offered HTTP/Crossref helpers; per the task's
self-contained offline requirement they have been replaced with static,
in-process lookup tables. No `urllib`, `socket`, or other network APIs
are imported. The task pipeline does not require any network access to
reproduce the bundled answer.
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# Static metadata for the bundled reference papers
# ---------------------------------------------------------------------------

PAPER_METADATA: dict[str, dict] = {
    # Main paper (target.pdf) -- the source of the [PAPER] context numbers.
    "10.1073/pnas.2411835122": {
        "title": ("Observed declines in upper ocean "
                  "phosphate-to-nitrate availability"),
        "authors": ["Gerace, S. D.", "et al."],
        "journal": "Proceedings of the National Academy of Sciences",
        "volume": "122",
        "elocation": "e2411835122",
        "year": 2025,
        "path": "input_data/reference_paper/target.pdf",
        "role": "main",
    },
    # Companion paper 1 (1.pdf): phosphorus limitation of N2-fixing
    # diazotroph Crocosphaera watsonii under ocean warming.
    "ref:1.pdf": {
        "title": ("Phosphorus limitation of the marine nitrogen-fixing "
                  "diazotroph Crocosphaera watsonii under ocean warming"),
        "path": "input_data/reference_paper/1.pdf",
        "role": "companion",
    },
    # Companion paper 2 (2.pdf): N and P differentially control marine
    # biomass production and stoichiometry.
    "ref:2.pdf": {
        "title": ("Nitrogen and phosphorus differentially control marine "
                  "biomass production and stoichiometry"),
        "path": "input_data/reference_paper/2.pdf",
        "role": "companion",
    },
    # Companion paper 3 (3.pdf): long-term decline of planktonic biomass
    # in a hotspot of nitrogen fixation.
    "ref:3.pdf": {
        "title": ("Long-term decline of planktonic biomass in a hotspot "
                  "of nitrogen fixation"),
        "path": "input_data/reference_paper/3.pdf",
        "role": "companion",
    },
}

# ---------------------------------------------------------------------------
# Static catalog of the bundled GLODAPv2.2022 subset
# ---------------------------------------------------------------------------

BUNDLED_DATA_CATALOG: dict[str, dict] = {
    "glodap_v2_2022_45S45N_0_1500m.csv": {
        "path": "input_data/data/glodap_v2_2022_45S45N_0_1500m.csv",
        "n_rows": 485_503,
        "year_range": (1972, 2021),
        "lat_range": (-45.0, 45.0),
        "depth_range_m": (0.0, 1500.0),
        "source": ("GLODAPv2.2022 merged data product, NOAA NCEI accession "
                   "0257247, restricted to the bundled lat / depth window."),
    },
}


def lookup_paper(doi: str) -> dict:
    """Return cached metadata for a reference DOI shipped with this task.

    Raises KeyError if the DOI is not one of the bundled references; no
    network call is attempted.
    """
    return dict(PAPER_METADATA[doi])


def list_bundled_data() -> list[dict]:
    """Return a copy of the bundled dataset catalog (no network)."""
    return [dict(v) for v in BUNDLED_DATA_CATALOG.values()]

#!/usr/bin/env python3
"""Domain tools for the geo_pn33 ocean nutricline trend task.

The task analyses the GLODAPv2.2022 hydrographic database to detect
contemporary trends in upper-ocean nitrate and phosphate availability.
The reference paper (Gerace et al. 2025, PNAS 122:e2411835122) defines
nutricline depth as the shallowest depth at which a nutrient first
exceeds a Redfield threshold concentration. These tools provide:

- profile-level loaders / quality-flag filtering for the GLODAPv2.2022
  CSV ingest (`G2nitrate`, `G2phosphate`, `G2depth`, ...)
- per-cast nutricline-depth detection (linear interpolation between the
  bracketing depths)
- per-site time-series construction (1 deg x 1 deg gridded)
- non-parametric trend tests (Mann-Kendall S statistic + tau, Theil-Sen
  slope, ordinary linear regression with bootstrap CI)
- regional aggregation by latitude band / hemisphere / basin
- Matplotlib plotting (one tool per answer image; returns the absolute
  PNG path).

All compute is in-process (numpy / scipy / matplotlib); no network calls.
"""

from __future__ import annotations

import csv
import math
import os
import statistics
from typing import Any

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Ocean_Nutricline_Tools")


# ---------------------------------------------------------------------------
# I/O loaders (GLODAPv2.2022 CSV)
# ---------------------------------------------------------------------------

# Column names in the staged input CSV.
COL_BASIN = "basin"
COL_CRUISE = "G2cruise"
COL_STATION = "G2station"
COL_YEAR = "G2year"
COL_MONTH = "G2month"
COL_LAT = "G2latitude"
COL_LON = "G2longitude"
COL_DEPTH = "G2depth"
COL_NO3 = "G2nitrate"
COL_NO3F = "G2nitratef"
COL_PO4 = "G2phosphate"
COL_PO4F = "G2phosphatef"

# GLODAP quality flag conventions: 2 = good. 9 = missing. 0 = not measured.
QC_GOOD = {"2"}
MISSING = -9999.0

# Paper's nutricline thresholds (Redfield proportions, mu mol/kg).
THRESH_NO3 = 3.0
THRESH_PO4 = 3.0 / 16.0


def _to_float(x: Any) -> float:
    try:
        v = float(x)
    except (TypeError, ValueError):
        return float("nan")
    if v <= -9000:
        return float("nan")
    return v


@mcp.tool()
def load_glodap_csv(csv_path: str) -> dict:
    """Load the staged GLODAPv2.2022 subset CSV.

    Reads the file into a list of dictionaries (one per bottle sample)
    and reports sample counts and date / latitude coverage.

    Args:
        csv_path: Absolute path to glodap_v2_2022_45S45N_0_1500m.csv.

    Returns:
        dict with keys {n_rows, year_min, year_max, lat_min, lat_max,
        basins, columns, sample}. `sample` is the first row.
    """
    rows: list[dict] = []
    with open(csv_path, newline="") as f:
        r = csv.DictReader(f)
        cols = r.fieldnames or []
        for row in r:
            rows.append(row)
    if not rows:
        raise ValueError(f"empty CSV: {csv_path}")
    years = [int(float(r[COL_YEAR])) for r in rows if r.get(COL_YEAR)]
    lats = [float(r[COL_LAT]) for r in rows if r.get(COL_LAT)]
    basins = sorted({r.get(COL_BASIN, "") for r in rows})
    return {
        "n_rows": len(rows),
        "columns": cols,
        "year_min": min(years), "year_max": max(years),
        "lat_min": min(lats), "lat_max": max(lats),
        "basins": basins,
        "sample": rows[0],
    }


@mcp.tool()
def filter_qc(csv_path: str, nutrient: str, output_csv: str) -> dict:
    """Keep only rows where the requested nutrient has GLODAP QC flag = 2.

    Args:
        csv_path: input CSV path.
        nutrient: one of {"nitrate", "phosphate"}.
        output_csv: destination CSV path.

    Returns:
        dict with {n_in, n_out, output_csv}.
    """
    if nutrient == "nitrate":
        flag_col, val_col = COL_NO3F, COL_NO3
    elif nutrient == "phosphate":
        flag_col, val_col = COL_PO4F, COL_PO4
    else:
        raise ValueError("nutrient must be 'nitrate' or 'phosphate'")
    n_in = n_out = 0
    with open(csv_path, newline="") as f, \
         open(output_csv, "w", newline="") as o:
        r = csv.DictReader(f)
        cols = r.fieldnames
        w = csv.DictWriter(o, fieldnames=cols)
        w.writeheader()
        for row in r:
            n_in += 1
            v = _to_float(row.get(val_col))
            if math.isnan(v):
                continue
            if str(row.get(flag_col, "")).strip() not in QC_GOOD:
                continue
            w.writerow(row); n_out += 1
    return {"n_in": n_in, "n_out": n_out, "output_csv": os.path.abspath(output_csv)}


# ---------------------------------------------------------------------------
# Nutricline depth detection (per cast)
# ---------------------------------------------------------------------------

def _interp_threshold_depth(depths: list[float], values: list[float], thr: float) -> float:
    """Return the shallowest depth at which `values` first reaches `thr`.

    Uses linear interpolation between the bracketing pair (depth_above,
    value_above) -> (depth_at, value_at). Returns NaN if the threshold is
    never reached or the cast has < 2 samples.
    """
    if len(depths) < 2:
        return float("nan")
    pairs = sorted(((d, v) for d, v in zip(depths, values) if not math.isnan(d) and not math.isnan(v)),
                   key=lambda x: x[0])
    if len(pairs) < 2:
        return float("nan")
    for i in range(1, len(pairs)):
        d0, v0 = pairs[i - 1]
        d1, v1 = pairs[i]
        if v1 >= thr and v0 < thr:
            if v1 == v0:
                return d1
            frac = (thr - v0) / (v1 - v0)
            return d0 + frac * (d1 - d0)
        if v0 >= thr and i == 1:
            # threshold met at the shallowest sample already
            return d0
    return float("nan")


@mcp.tool()
def detect_nutricline_depths(csv_path: str, nutrient: str,
                              threshold: float | None = None,
                              min_depth_m: float = 50.0,
                              enforce_qc: bool = True,
                              output_csv: str = "") -> dict:
    """Detect per-cast nutricline depths from a GLODAP-style CSV.

    A "cast" is grouped by (cruise, station, year, month, lat, lon).
    Within each cast, the function finds the shallowest depth at which
    the nutrient exceeds `threshold` via linear interpolation.

    Args:
        csv_path: GLODAP-style CSV (must contain depth + value + flag
            columns; rows can be raw GLODAP or pre-filtered with
            `filter_qc`).
        nutrient: one of {"nitrate", "phosphate"}.
        threshold: nutricline threshold in mu mol/kg. Defaults: 3.0 for
            nitrate, 3/16 for phosphate (the Gerace et al. 2025 values).
        min_depth_m: lower bound on accepted nutricline depths. The paper
            restricts site-trend analysis to nutriclines deeper than 50 m
            because shallower threshold crossings are not well resolved.
        enforce_qc: when True (default), the function still drops bottle
            rows whose nutrient flag is not "2" (GLODAP "good"), even if
            `filter_qc` was not run first. Set to False to honour an
            externally pre-filtered CSV verbatim. The returned dict
            reports how many rows were rejected by this safety check.
        output_csv: optional path to write per-cast nutricline rows.

    Returns:
        dict with {n_casts_total, n_casts_detected, n_casts_kept,
        n_rows_rejected_qc, median_depth_m, mean_depth_m, output_csv}.
    """
    if nutrient == "nitrate":
        val_col = COL_NO3; flag_col = COL_NO3F
        thr = THRESH_NO3 if threshold is None else float(threshold)
    elif nutrient == "phosphate":
        val_col = COL_PO4; flag_col = COL_PO4F
        thr = THRESH_PO4 if threshold is None else float(threshold)
    else:
        raise ValueError("nutrient must be 'nitrate' or 'phosphate'")

    casts: dict[tuple, list[tuple[float, float]]] = {}
    cast_meta: dict[tuple, dict] = {}
    n_rejected_qc = 0
    with open(csv_path, newline="") as f:
        r = csv.DictReader(f)
        for row in r:
            d = _to_float(row.get(COL_DEPTH))
            v = _to_float(row.get(val_col))
            if math.isnan(d) or math.isnan(v):
                continue
            if enforce_qc:
                fl = str(row.get(flag_col, "")).strip()
                if fl and fl not in QC_GOOD:
                    n_rejected_qc += 1
                    continue
            try:
                year = int(float(row[COL_YEAR]))
                month = int(float(row[COL_MONTH]))
                lat = float(row[COL_LAT])
                lon = float(row[COL_LON])
            except (KeyError, ValueError):
                continue
            cruise = str(row.get(COL_CRUISE, "")).strip()
            station = str(row.get(COL_STATION, "")).strip()
            key = (cruise, station, year, month, round(lat, 4), round(lon, 4))
            casts.setdefault(key, []).append((d, v))
            cast_meta[key] = {"cruise": cruise, "station": station, "year": year,
                              "month": month, "lat": lat, "lon": lon,
                              "basin": row.get(COL_BASIN, "")}

    detected = 0
    kept_rows: list[dict] = []
    for key, samples in casts.items():
        depths = [s[0] for s in samples]
        vals = [s[1] for s in samples]
        z = _interp_threshold_depth(depths, vals, thr)
        if math.isnan(z):
            continue
        detected += 1
        if z < min_depth_m:
            continue
        meta = dict(cast_meta[key])
        meta["nutricline_depth_m"] = z
        kept_rows.append(meta)

    depths_kept = [r["nutricline_depth_m"] for r in kept_rows]
    out = {
        "nutrient": nutrient,
        "threshold_umol_per_kg": thr,
        "n_casts_total": len(casts),
        "n_casts_detected": detected,
        "n_casts_kept": len(kept_rows),
        "n_rows_rejected_qc": int(n_rejected_qc),
        "median_depth_m": float(statistics.median(depths_kept)) if depths_kept else float("nan"),
        "mean_depth_m": float(statistics.mean(depths_kept)) if depths_kept else float("nan"),
        "output_csv": None,
    }
    if output_csv:
        with open(output_csv, "w", newline="") as o:
            w = csv.DictWriter(o, fieldnames=["basin", "cruise", "station",
                "year", "month", "lat", "lon", "nutricline_depth_m"])
            w.writeheader()
            w.writerows(kept_rows)
        out["output_csv"] = os.path.abspath(output_csv)
    return out


# ---------------------------------------------------------------------------
# Trend tests
# ---------------------------------------------------------------------------

@mcp.tool()
def linear_trend(years: list[float], values: list[float]) -> dict:
    """Ordinary least-squares linear regression of values on years.

    Returns {slope, intercept, slope_se, p_value (two-sided),
    r_squared, n}.
    """
    x = np.asarray(years, dtype=float)
    y = np.asarray(values, dtype=float)
    mask = ~(np.isnan(x) | np.isnan(y))
    x = x[mask]; y = y[mask]
    n = len(x)
    if n < 3:
        return {"slope": float("nan"), "intercept": float("nan"),
                "slope_se": float("nan"), "p_value": float("nan"),
                "r_squared": float("nan"), "n": n}
    xm = x.mean(); ym = y.mean()
    sxx = float(np.sum((x - xm) ** 2))
    sxy = float(np.sum((x - xm) * (y - ym)))
    slope = sxy / sxx if sxx > 0 else float("nan")
    intercept = ym - slope * xm
    yhat = slope * x + intercept
    resid = y - yhat
    sse = float(np.sum(resid ** 2))
    sst = float(np.sum((y - ym) ** 2))
    rsq = 1.0 - sse / sst if sst > 0 else float("nan")
    if n > 2 and sxx > 0:
        s2 = sse / (n - 2)
        slope_se = math.sqrt(s2 / sxx)
        # two-sided p-value via t-distribution
        from scipy.stats import t as student_t
        tstat = slope / slope_se if slope_se > 0 else float("nan")
        pval = 2.0 * (1.0 - student_t.cdf(abs(tstat), df=n - 2)) if slope_se > 0 else float("nan")
    else:
        slope_se = float("nan"); pval = float("nan")
    return {"slope": float(slope), "intercept": float(intercept),
            "slope_se": float(slope_se), "p_value": float(pval),
            "r_squared": float(rsq), "n": int(n)}


@mcp.tool()
def mann_kendall_test(values: list[float], times: list[float] | None = None) -> dict:
    """Non-parametric Mann-Kendall trend test.

    Computes the S statistic, Kendall's tau, and a normal-approximation
    two-sided p-value. The series is assumed to be ordered by `times`
    if given, otherwise by index.

    Returns {S, tau, z, p_value, n, trend ("increasing"/"decreasing"/
    "no trend")}.
    """
    if times is not None:
        idx = np.argsort(np.asarray(times, dtype=float))
        v = np.asarray(values, dtype=float)[idx]
    else:
        v = np.asarray(values, dtype=float)
    v = v[~np.isnan(v)]
    n = len(v)
    if n < 3:
        return {"S": 0, "tau": float("nan"), "z": float("nan"),
                "p_value": float("nan"), "n": n, "trend": "no trend"}
    s = 0
    for i in range(n - 1):
        diffs = v[i + 1:] - v[i]
        s += int(np.sum(diffs > 0)) - int(np.sum(diffs < 0))
    # variance with tie correction
    _, counts = np.unique(v, return_counts=True)
    var_s = (n * (n - 1) * (2 * n + 5)) / 18.0
    for c in counts:
        if c > 1:
            var_s -= c * (c - 1) * (2 * c + 5) / 18.0
    if s > 0:
        z = (s - 1) / math.sqrt(var_s)
    elif s < 0:
        z = (s + 1) / math.sqrt(var_s)
    else:
        z = 0.0
    from scipy.stats import norm
    p = 2.0 * (1.0 - norm.cdf(abs(z)))
    tau = 2.0 * s / (n * (n - 1))
    if p < 0.05 and s > 0:
        trend = "increasing"
    elif p < 0.05 and s < 0:
        trend = "decreasing"
    else:
        trend = "no trend"
    return {"S": int(s), "tau": float(tau), "z": float(z),
            "p_value": float(p), "n": int(n), "trend": trend}


@mcp.tool()
def theil_sen_slope(years: list[float], values: list[float]) -> dict:
    """Theil-Sen non-parametric slope estimator with 95% bootstrap CI.

    Computes the median of all pairwise slopes (y_j - y_i) / (x_j - x_i).
    Confidence interval is from 1000 paired bootstrap resamples.

    Returns {slope, intercept, ci95_lo, ci95_hi, n}.
    """
    x = np.asarray(years, dtype=float)
    y = np.asarray(values, dtype=float)
    mask = ~(np.isnan(x) | np.isnan(y))
    x = x[mask]; y = y[mask]
    n = len(x)
    if n < 3:
        return {"slope": float("nan"), "intercept": float("nan"),
                "ci95_lo": float("nan"), "ci95_hi": float("nan"), "n": n}

    def _ts(xv, yv):
        slopes = []
        for i in range(len(xv)):
            for j in range(i + 1, len(xv)):
                if xv[j] != xv[i]:
                    slopes.append((yv[j] - yv[i]) / (xv[j] - xv[i]))
        return float(np.median(slopes)) if slopes else float("nan")

    slope = _ts(x, y)
    intercept = float(np.median(y - slope * x))
    rng = np.random.default_rng(42)
    boot = []
    for _ in range(1000):
        idx = rng.integers(0, n, n)
        s = _ts(x[idx], y[idx])
        if not math.isnan(s):
            boot.append(s)
    if boot:
        lo = float(np.percentile(boot, 2.5))
        hi = float(np.percentile(boot, 97.5))
    else:
        lo = hi = float("nan")
    return {"slope": float(slope), "intercept": intercept,
            "ci95_lo": lo, "ci95_hi": hi, "n": int(n)}


# ---------------------------------------------------------------------------
# Site-level trend aggregation (1 deg grid)
# ---------------------------------------------------------------------------

@mcp.tool()
def site_specific_trends(nutricline_csv: str, output_csv: str = "",
                          min_years: int = 2, grid_deg: float = 1.0) -> dict:
    """Compute a temporal slope at every (lat, lon) site that has enough data.

    Grids depths to a `grid_deg` x `grid_deg` cell, then within each cell
    first averages cast-level nutricline depths to per-(site, year) annual
    means (the procedure described in Gerace et al. 2025 Materials and
    Methods) and finally fits an OLS slope (m / yr) of the annual mean
    versus year. Cells with fewer than `min_years` distinct sampling years
    are dropped. The dominant basin tag observed at each gridded site is
    propagated to the per-site output row so that downstream
    `regional_aggregate` can group by the GLODAP `basin` field instead of
    by raw longitude.

    Args:
        nutricline_csv: output of `detect_nutricline_depths`.
        output_csv: where to write per-site slopes
            (lat, lon, basin, slope, n).
        min_years: minimum distinct sampling years required. Defaults to 2,
            matching the paper Materials and Methods convention "for each
            unique site with annually averaged depths for two or more years,
            we fitted a linear regression". Callers can raise it for
            stricter filtering.
        grid_deg: gridding resolution in degrees (paper rounds the cast
            geographic coordinates to the nearest degree, i.e. 1 deg).

    Returns:
        dict with {n_sites, median_slope_m_per_yr, ci95_lo, ci95_hi,
        n_positive, n_negative, output_csv}.
    """
    rows: list[dict] = []
    with open(nutricline_csv, newline="") as f:
        for r in csv.DictReader(f):
            try:
                lat = round(float(r["lat"]) / grid_deg) * grid_deg
                lon = round(float(r["lon"]) / grid_deg) * grid_deg
                yr = int(float(r["year"]))
                z = float(r["nutricline_depth_m"])
            except (KeyError, ValueError):
                continue
            basin = (r.get("basin") or "").strip()
            rows.append({"lat": lat, "lon": lon, "year": yr, "z": z,
                          "basin": basin})

    # Group raw casts by (site, year), then take the annual mean depth at
    # each site-year (Gerace et al. 2025, Methods). This is the key
    # difference from a per-cast OLS fit: many casts in the same site-year
    # would otherwise dominate the regression.
    site_year: dict[tuple, list[float]] = {}
    site_basins: dict[tuple, dict[str, int]] = {}
    for r in rows:
        key_sy = (r["lat"], r["lon"], r["year"])
        site_year.setdefault(key_sy, []).append(r["z"])
        site = (r["lat"], r["lon"])
        if r["basin"]:
            site_basins.setdefault(site, {})
            site_basins[site][r["basin"]] = site_basins[site].get(r["basin"], 0) + 1

    annual_by_site: dict[tuple, list[tuple[int, float]]] = {}
    for (lat, lon, yr), zs in site_year.items():
        annual_by_site.setdefault((lat, lon), []).append((yr, float(np.mean(zs))))

    def _dominant_basin(site: tuple) -> str:
        counts = site_basins.get(site, {})
        if not counts:
            return ""
        return max(counts.items(), key=lambda kv: kv[1])[0]

    out_rows = []
    slopes = []
    for (lat, lon), pts in annual_by_site.items():
        years = [p[0] for p in pts]
        if len(set(years)) < min_years:
            continue
        x = np.array([p[0] for p in pts], dtype=float)
        y = np.array([p[1] for p in pts], dtype=float)
        xm = x.mean(); ym = y.mean()
        sxx = float(np.sum((x - xm) ** 2))
        if sxx <= 0:
            continue
        slope = float(np.sum((x - xm) * (y - ym)) / sxx)
        out_rows.append({"lat": lat, "lon": lon,
                          "basin": _dominant_basin((lat, lon)),
                          "n": len(pts),
                          "n_years": len(set(years)),
                          "slope_m_per_yr": slope,
                          "mean_depth_m": float(ym)})
        slopes.append(slope)

    # bootstrap CI95 of the median slope (paper's reported metric)
    rng = np.random.default_rng(7)
    boot = []
    arr = np.array(slopes)
    if len(arr) >= 5:
        for _ in range(10000):
            samp = arr[rng.integers(0, len(arr), len(arr))]
            boot.append(float(np.median(samp)))
    ci_lo = float(np.percentile(boot, 2.5)) if boot else float("nan")
    ci_hi = float(np.percentile(boot, 97.5)) if boot else float("nan")

    if output_csv and out_rows:
        with open(output_csv, "w", newline="") as o:
            w = csv.DictWriter(o, fieldnames=list(out_rows[0].keys()))
            w.writeheader(); w.writerows(out_rows)

    return {
        "n_sites": len(out_rows),
        "median_slope_m_per_yr": float(np.median(slopes)) if slopes else float("nan"),
        "mean_slope_m_per_yr": float(np.mean(slopes)) if slopes else float("nan"),
        "ci95_lo": ci_lo, "ci95_hi": ci_hi,
        "n_positive": int(sum(1 for s in slopes if s > 0)),
        "n_negative": int(sum(1 for s in slopes if s < 0)),
        "output_csv": os.path.abspath(output_csv) if output_csv else None,
    }


# ---------------------------------------------------------------------------
# Regional aggregation
# ---------------------------------------------------------------------------

@mcp.tool()
def regional_aggregate(site_trend_csv: str) -> dict:
    """Aggregate per-site nutricline slopes into hemispheres and basins.

    Splits the site-level slope CSV (output of `site_specific_trends`)
    into northern / southern hemispheres and returns the median slope
    plus 95% bootstrap CI for each region. Basin grouping prefers the
    GLODAP `basin` column propagated from `site_specific_trends` (which
    in turn comes from `detect_nutricline_depths` reading the input CSV's
    `basin` field). When that column is missing for a row, the function
    falls back to a longitude-bin classifier (Atlantic -70..20, Indian
    20..145, Pacific otherwise) so the tool remains usable with older
    per-site CSVs.
    """
    rows: list[dict] = []
    with open(site_trend_csv, newline="") as f:
        for r in csv.DictReader(f):
            try:
                rows.append({
                    "lat": float(r["lat"]),
                    "lon": float(r["lon"]),
                    "slope": float(r["slope_m_per_yr"]),
                    "basin": (r.get("basin") or "").strip(),
                })
            except (KeyError, ValueError):
                continue

    def _stats(slopes: list[float]) -> dict:
        if not slopes:
            return {"n": 0, "median": float("nan"),
                    "ci95_lo": float("nan"), "ci95_hi": float("nan")}
        arr = np.array(slopes)
        rng = np.random.default_rng(11)
        boot = [float(np.median(arr[rng.integers(0, len(arr), len(arr))]))
                for _ in range(10000)]
        return {"n": len(arr), "median": float(np.median(arr)),
                "ci95_lo": float(np.percentile(boot, 2.5)),
                "ci95_hi": float(np.percentile(boot, 97.5))}

    northern = [r["slope"] for r in rows if r["lat"] > 0]
    southern = [r["slope"] for r in rows if r["lat"] <= 0]

    def _basin_lon_fallback(lon: float) -> str:
        # Atlantic ~ -70..20, Indian ~ 20..145, Pacific else.
        if -70 <= lon <= 20:
            return "Atlantic"
        if 20 < lon <= 145:
            return "Indian"
        return "Pacific"

    def _basin_of(r: dict) -> str:
        # Prefer GLODAP basin label (Atlantic/Pacific/Indian/Arctic/...),
        # else fall back to the longitude bin.
        b = r.get("basin", "").strip()
        if b:
            return b.capitalize()
        return _basin_lon_fallback(r["lon"])

    def _slopes_for(predicate) -> list[float]:
        return [r["slope"] for r in rows if predicate(r)]

    south_atl = _slopes_for(lambda r: r["lat"] <= 0 and _basin_of(r) == "Atlantic")
    south_pac = _slopes_for(lambda r: r["lat"] <= 0 and _basin_of(r) == "Pacific")
    south_ind = _slopes_for(lambda r: r["lat"] <= 0 and _basin_of(r) == "Indian")
    north_atl = _slopes_for(lambda r: r["lat"] > 0 and _basin_of(r) == "Atlantic")
    north_pac = _slopes_for(lambda r: r["lat"] > 0 and _basin_of(r) == "Pacific")
    north_ind = _slopes_for(lambda r: r["lat"] > 0 and _basin_of(r) == "Indian")
    # GLODAP basin coverage check (informational)
    n_with_basin = sum(1 for r in rows if r.get("basin"))

    return {
        "global": _stats([r["slope"] for r in rows]),
        "northern": _stats(northern),
        "southern": _stats(southern),
        "southern_atlantic": _stats(south_atl),
        "southern_pacific": _stats(south_pac),
        "southern_indian": _stats(south_ind),
        "northern_atlantic": _stats(north_atl),
        "northern_pacific": _stats(north_pac),
        "northern_indian": _stats(north_ind),
        "basin_source": ("glodap_field" if n_with_basin >= max(1, len(rows) // 2)
                         else "longitude_fallback"),
        "n_sites_with_basin_field": n_with_basin,
    }


@mcp.tool()
def annual_global_means(nutricline_csv: str) -> dict:
    """Build a globally averaged nutricline-depth time series with
    non-parametric trend uncertainty.

    Groups all kept casts by year, returns the annual mean depth and
    sample count, then runs both Theil-Sen (with 1000-resample bootstrap
    CI95) and Mann-Kendall on the annual series so the caller can report
    a non-parametric global slope alongside the OLS trend used in the
    plot. Returns:

      {years, annual_mean_depth_m, n_casts,
       theil_sen: {slope, intercept, ci95_lo, ci95_hi, n},
       mann_kendall: {S, tau, z, p_value, trend, n},
       ols: {slope, intercept, slope_se, p_value, r_squared, n}}
    """
    by_year: dict[int, list[float]] = {}
    with open(nutricline_csv, newline="") as f:
        for r in csv.DictReader(f):
            try:
                y = int(float(r["year"]))
                z = float(r["nutricline_depth_m"])
            except (KeyError, ValueError):
                continue
            by_year.setdefault(y, []).append(z)
    years = sorted(by_year)
    means = [float(np.mean(by_year[y])) for y in years]
    counts = [len(by_year[y]) for y in years]
    ts = theil_sen_slope(years, means)
    mk = mann_kendall_test(means, times=years)
    ols = linear_trend(years, means)
    return {"years": years,
            "annual_mean_depth_m": means,
            "n_casts": counts,
            "theil_sen": ts,
            "mann_kendall": mk,
            "ols": ols}


# ---------------------------------------------------------------------------
# Plotting (one tool per answer image)
# ---------------------------------------------------------------------------

@mcp.tool()
def plot_global_time_series(no3_summary: dict, po4_summary: dict,
                             output_png: str) -> str:
    """Plot annual global mean nitracline / phosphacline depth vs. year.

    Both summaries are the dict returned by `annual_global_means`. The
    figure includes per-series OLS regression lines AND the Theil-Sen
    non-parametric slope with 95% bootstrap CI (legend entries report
    both slopes and the Mann-Kendall p-value).
    Returns the absolute PNG path.
    """
    fig, ax = plt.subplots(figsize=(7, 4.5))
    for name, summ, color, marker in [
        ("Nitracline (Z_NO3)", no3_summary, "tab:blue", "o"),
        ("Phosphacline (Z_PO4)", po4_summary, "tab:orange", "s"),
    ]:
        x = np.array(summ["years"], dtype=float)
        y = np.array(summ["annual_mean_depth_m"], dtype=float)
        ax.plot(x, y, marker=marker, ms=4, lw=0.8, color=color, label=name)
        if len(x) >= 3:
            slope, intercept = np.polyfit(x, y, 1)
            xx = np.array([x.min(), x.max()])
            ax.plot(xx, slope * xx + intercept, ls="--", color=color,
                     label=f"  OLS slope = {slope:.2f} m/yr")
            ts = summ.get("theil_sen") or theil_sen_slope(list(x), list(y))
            mk = summ.get("mann_kendall") or mann_kendall_test(list(y), times=list(x))
            ts_slope = ts.get("slope", float("nan"))
            ci_lo = ts.get("ci95_lo", float("nan"))
            ci_hi = ts.get("ci95_hi", float("nan"))
            mk_p = mk.get("p_value", float("nan"))
            ts_intercept = ts.get("intercept", float("nan"))
            ax.plot(xx, ts_slope * xx + ts_intercept, ls=":", color=color, lw=1.4,
                     label=("  TS slope = {:.2f} [{:.2f}, {:.2f}] m/yr; MK p = {:.3g}"
                            .format(ts_slope, ci_lo, ci_hi, mk_p)))
    ax.invert_yaxis()
    ax.set_xlabel("Year")
    ax.set_ylabel("Mean depth (m)")
    ax.set_title("Global annual mean nutricline depths, 1972-2021 (45S-45N)")
    ax.grid(True, ls=":", alpha=0.5)
    ax.legend(fontsize=8)
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_png) or ".", exist_ok=True)
    fig.savefig(output_png, dpi=160)
    plt.close(fig)
    return os.path.abspath(output_png)


@mcp.tool()
def plot_site_trend_histogram(no3_site_csv: str, po4_site_csv: str,
                               output_png: str) -> str:
    """Histogram of per-site nutricline trends for nitrate and phosphate.

    Reads the per-site slope CSVs produced by `site_specific_trends`,
    overlays kernel-density curves, and marks the medians.
    """
    def _load(path):
        s = []
        with open(path, newline="") as f:
            for r in csv.DictReader(f):
                try:
                    s.append(float(r["slope_m_per_yr"]))
                except (KeyError, ValueError):
                    continue
        return np.array(s)

    no3 = _load(no3_site_csv)
    po4 = _load(po4_site_csv)

    fig, ax = plt.subplots(figsize=(7, 4.5))
    bins = np.linspace(-5, 5, 61)
    ax.hist(no3, bins=bins, color="tab:blue", alpha=0.45,
             label=f"T_NO3 (n={len(no3)}, median={np.median(no3):.2f})")
    ax.hist(po4, bins=bins, color="tab:orange", alpha=0.45,
             label=f"T_PO4 (n={len(po4)}, median={np.median(po4):.2f})")
    ax.axvline(np.median(no3), color="tab:blue", ls="--", lw=1)
    ax.axvline(np.median(po4), color="tab:orange", ls="--", lw=1)
    ax.axvline(0, color="k", lw=0.5)
    ax.set_xlabel("Per-site slope (m / yr)")
    ax.set_ylabel("Number of 1 deg sites")
    ax.set_title("Distribution of site-specific nutricline trends")
    ax.grid(True, ls=":", alpha=0.5)
    ax.legend(fontsize=8)
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_png) or ".", exist_ok=True)
    fig.savefig(output_png, dpi=160)
    plt.close(fig)
    return os.path.abspath(output_png)


@mcp.tool()
def plot_regional_medians(regional_no3: dict, regional_po4: dict,
                            output_png: str) -> str:
    """Bar chart of regional median nutricline trends with bootstrap CIs.

    Both inputs are the dict returned by `regional_aggregate`.
    """
    keys = ["northern", "southern", "southern_atlantic", "southern_pacific",
             "southern_indian", "northern_atlantic", "northern_pacific",
             "northern_indian"]
    labels = ["N hemisphere", "S hemisphere", "S Atlantic", "S Pacific",
               "S Indian", "N Atlantic", "N Pacific", "N Indian"]
    x = np.arange(len(keys))
    no3_med = [regional_no3[k]["median"] for k in keys]
    po4_med = [regional_po4[k]["median"] for k in keys]
    no3_lo = [regional_no3[k]["median"] - regional_no3[k]["ci95_lo"] for k in keys]
    no3_hi = [regional_no3[k]["ci95_hi"] - regional_no3[k]["median"] for k in keys]
    po4_lo = [regional_po4[k]["median"] - regional_po4[k]["ci95_lo"] for k in keys]
    po4_hi = [regional_po4[k]["ci95_hi"] - regional_po4[k]["median"] for k in keys]

    fig, ax = plt.subplots(figsize=(8.5, 4.5))
    w = 0.35
    ax.bar(x - w / 2, no3_med, w, yerr=[no3_lo, no3_hi], capsize=3,
            color="tab:blue", label="Nitracline T_NO3")
    ax.bar(x + w / 2, po4_med, w, yerr=[po4_lo, po4_hi], capsize=3,
            color="tab:orange", label="Phosphacline T_PO4")
    ax.axhline(0, color="k", lw=0.6)
    ax.set_xticks(x); ax.set_xticklabels(labels, rotation=25, ha="right", fontsize=8)
    ax.set_ylabel("Median slope (m / yr)")
    ax.set_title("Regional medians of nutricline trends, 1972-2021")
    ax.grid(True, axis="y", ls=":", alpha=0.5)
    ax.legend(fontsize=8)
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_png) or ".", exist_ok=True)
    fig.savefig(output_png, dpi=160)
    plt.close(fig)
    return os.path.abspath(output_png)


# ---------------------------------------------------------------------------
# Server entry-point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    mcp.run()

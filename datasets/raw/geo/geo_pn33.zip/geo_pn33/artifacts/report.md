# Upper-ocean Nutricline Trends, 1972-2021

## Scope

This report summarises the nutricline-depth trend analysis run on the
bundled GLODAPv2.2022 subset (45S-45N, 0-1500 m, 485,503 bottle
samples spanning 1972-2021). The bundled subset is a simplification
of the dataset used in Gerace et al. 2025 (paper period 1972-2022;
paper additionally fuses WOD and GO-SHIP hydrography). Headline
numerical values from the published paper are quoted with [PAPER];
values computed from the shipped subset pipeline are quoted with
[BUNDLE]. Grading is based on the [BUNDLE] numbers computed from the
released CSV; [PAPER] numbers are context only.

## Method

1. Quality-controlled bottle samples are loaded
   (`load_glodap_csv` / `filter_qc`).
2. Per-cast nutricline depths Z_NO3 and Z_PO4 are computed as the
   shallowest depth at which the corresponding nutrient first
   exceeds a Redfield-proportional threshold (3 umol/kg for NO3,
   3/16 umol/kg for PO4); per-cast records carry the GLODAP `basin`
   tag forward.
3. Annual global mean Z_NO3 and Z_PO4 are aggregated and
   characterised with both OLS (`linear_trend`) and non-parametric
   statistics: Theil-Sen slope with 95% bootstrap CI
   (`theil_sen_slope`) and Mann-Kendall p-value
   (`mann_kendall_test`). All three are bundled into the
   `annual_global_means` output and overlaid on Figure 1.
4. Site-level OLS slopes are computed on a 1 deg x 1 deg grid:
   within each (site, year) the cast-level depths are first averaged
   to one annual mean (per Gerace et al. 2025 Materials and
   Methods), and the OLS slope is then fit on the annual series.
   The default `min_years` is 2, matching the paper Methods
   convention. Each site row carries the dominant GLODAP `basin` tag.
5. Regional aggregates group by hemisphere and by `basin` (using the
   propagated GLODAP basin field, with a longitude bin as fallback).
   Eight regional categories are reported: northern, southern,
   southern_atlantic, southern_pacific, southern_indian,
   northern_atlantic, northern_pacific, AND northern_indian. Median
   slope and 95% bootstrap CI are reported for each region.
6. Three figures are produced and saved to artifacts/.

## Headline conclusions

- [PAPER] Across 1972-2022 the paper reports that the global
  nitracline depth (Z_NO3, threshold 3 umol/kg) is statistically
  near-stable (p = 0.07), while the global phosphacline depth
  (Z_PO4, threshold 3/16 umol/kg) deepens by roughly 23 m total
  over the five decades (Z_PO4 slope 0.47 m/yr, p = 9e-7).
- [PAPER] The deepening is concentrated in the southern hemisphere:
  - SH basins: median T_PO4 = +0.60 m/yr [0.41, 0.71]; median
    T_NO3 = -0.27 m/yr [-0.40, -0.09].
  - NH basins: median T_PO4 = +0.13 m/yr [-0.05, 0.35]; median
    T_NO3 = -0.02 m/yr [-0.16, 0.13].
- [PAPER] Mechanism: reduced iron stress raises N2-fixation,
  buffering nitrate against rising N supply but not phosphate.
- [BUNDLE] Site median T_PO4 = 0.26
  m/yr [0.15, 0.38] over
  1876 sites.
- [BUNDLE] Site median T_NO3 = -0.14
  m/yr [-0.21, -0.05] over
  2496 sites.
- [BUNDLE] SH basins: T_PO4 = 0.38 m/yr
  [0.22, 0.56]
  (806 sites); T_NO3 =
  -0.16 m/yr
  [-0.29, -0.06]
  (1205 sites).
- [BUNDLE] NH basins: T_PO4 = 0.13 m/yr
  [0.00, 0.34]
  (1070 sites); T_NO3 =
  -0.08 m/yr
  [-0.21, 0.02]
  (1291 sites).
- [BUNDLE] Unweighted annual-global-mean Theil-Sen slope: PO4 =
  0.55 m/yr [-0.02,
  1.08] (MK p = 0.059); NO3
  = 0.54 m/yr [0.06,
  0.92] (MK p = 0.007).
- [BUNDLE] The phosphate-vs-nitrate asymmetry (T_PO4 > 0, T_NO3 < 0)
  shows up in the per-site medians (Figures 2 and 3), not in the
  unweighted annual-global-mean panel (Figure 1).
- [BUNDLE] Sign of the per-site medians and the SH > NH asymmetry
  match the paper; absolute m/yr values differ because the bundle
  lacks the WOD / GO-SHIP fusion and the 2022 year.

## Figures

### Figure 1 - Global nutricline time series

![Global annual-mean nutricline depths](global_nutricline_timeseries.png)

Annual globally averaged nitracline (Z_NO3) and phosphacline (Z_PO4)
depths versus year, with OLS *and* Theil-Sen regression overlays
(legend reports each slope plus its Mann-Kendall p-value). The
y-axis is inverted so that downward motion in the plot represents
nutricline deepening. On this unweighted global average both series
have positive Theil-Sen slopes of similar magnitude; the
species-asymmetry headline shows up in Figures 2 and 3.

### Figure 2 - Per-site slope histogram

![Per-site OLS slope histogram](site_trend_histogram.png)

Histogram of per-site OLS slopes of nutricline depth versus year,
gridded to 1 deg x 1 deg cells, for nitrate and phosphate
separately. Median markers are overlaid. The phosphacline
distribution is shifted to positive values (deepening); the
nitracline distribution is centred slightly below zero.

### Figure 3 - Regional medians

![Regional median trend bars](regional_medians.png)

Bar chart of regional medians for nitracline and phosphacline
trends with 95% bootstrap CIs, drawn for all eight regional
categories. The Southern hemisphere bars show the largest contrast
(strongly positive phosphacline trend, clearly negative nitracline
trend); the Northern hemisphere bars are near zero.

## Interpretation

Combined, Figures 2 and 3 plus the per-site median headlines
support the paper's central claim: contemporary upper-ocean
phosphate availability is declining faster than nitrate
availability, and the asymmetry is hemispherically structured
(strongest in the Southern Hemisphere). The mechanism the paper
proposes (iron-stress-driven modulation of N2-fixation that buffers
nitrate) is consistent with the observed phosphate-but-not-nitrate
deepening at the per-site level. Note that the unweighted
annual-global-mean series (Figure 1) does *not* by itself separate
the two species; the per-site / regional medians are the
diagnostic that carries the paper's headline.

## Caveats

- The bundled CSV is restricted to 1972-2021 (the paper uses
  1972-2022).
- The bundle is GLODAPv2.2022 only; the paper additionally fuses
  WOD and GO-SHIP hydrography. Numerical slope values from a
  from-scratch pipeline run on the bundle are therefore not
  expected to exactly reproduce the paper headline values.
- The bundled unweighted annual-global-mean series can be dominated
  by which sites happen to be sampled in any given year; per-site
  medians (Fig. 2 / Fig. 3) are the more robust diagnostic for the
  phosphate-vs-nitrate asymmetry.

## How this report was generated

Run `python3 tools/generate_report.py` from the task root. The
script reads the bundled CSV, calls the public functions in
`tools/nutricline_analysis.py` (`filter_qc`,
`detect_nutricline_depths`, `annual_global_means`,
`site_specific_trends`, `regional_aggregate`,
`plot_global_time_series`, `plot_site_trend_histogram`,
`plot_regional_medians`), writes the three PNG figures into
`artifacts/`, and rewrites this `report.md` with the freshly
computed numbers. The script depends only on numpy / scipy /
matplotlib; no network access is performed.

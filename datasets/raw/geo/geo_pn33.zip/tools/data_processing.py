"""Generic data-processing utilities for the geo_pn33 task.

Domain-agnostic helpers: CSV I/O, group-by aggregation, simple statistics,
binning. Domain-specific oceanographic logic (nutricline detection,
trend testing, regional aggregation, plotting) lives in
`nutricline_analysis.py`.
"""

from __future__ import annotations

import csv
import json
import math
import os
from typing import Any


def read_csv(path: str, delimiter: str = ",") -> list[dict]:
    """Parse a CSV file into a list of dictionaries via csv.DictReader."""
    with open(path, newline="") as f:
        return list(csv.DictReader(f, delimiter=delimiter))


def write_csv(rows: list[dict], path: str) -> None:
    """Write list-of-dicts to CSV, using the first row's keys as header."""
    if not rows:
        open(path, "w").close()
        return
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def read_json(path: str) -> Any:
    with open(path) as f:
        return json.load(f)


def write_json(obj: Any, path: str, indent: int = 2) -> None:
    with open(path, "w") as f:
        json.dump(obj, f, indent=indent, default=str)


def to_float(x: Any, fill: float = float("nan")) -> float:
    """Coerce to float; return `fill` on failure or GLODAP missing flag."""
    try:
        v = float(x)
    except (TypeError, ValueError):
        return fill
    if v <= -9000:  # GLODAP missing flag is -9999
        return fill
    return v


def list_files(directory: str, suffix: str | None = None) -> list[str]:
    """Sorted file list, optionally filtered by suffix (e.g. '.csv')."""
    out = []
    for fn in sorted(os.listdir(directory)):
        if suffix is None or fn.endswith(suffix):
            out.append(os.path.join(directory, fn))
    return out


def group_by(rows: list[dict], key: str) -> dict[Any, list[dict]]:
    """Bucket rows by `row[key]`."""
    out: dict[Any, list[dict]] = {}
    for r in rows:
        out.setdefault(r.get(key), []).append(r)
    return out


def mean(values: list[float]) -> float:
    """Arithmetic mean ignoring NaN."""
    vs = [v for v in values if v is not None and not math.isnan(v)]
    return sum(vs) / len(vs) if vs else float("nan")


def median(values: list[float]) -> float:
    """Median ignoring NaN."""
    vs = sorted(v for v in values if v is not None and not math.isnan(v))
    n = len(vs)
    if n == 0:
        return float("nan")
    if n % 2 == 1:
        return vs[n // 2]
    return 0.5 * (vs[n // 2 - 1] + vs[n // 2])


def percentile(values: list[float], q: float) -> float:
    """q-th percentile (linear interpolation), q in [0,100]."""
    vs = sorted(v for v in values if v is not None and not math.isnan(v))
    if not vs:
        return float("nan")
    k = (len(vs) - 1) * (q / 100.0)
    f = math.floor(k)
    c = math.ceil(k)
    if f == c:
        return vs[int(k)]
    return vs[f] * (c - k) + vs[c] * (k - f)


def round_coord(x: float, step: float = 1.0) -> float:
    """Round a coordinate to a multiple of `step` (default 1 degree)."""
    return float(round(float(x) / step) * step)


def filter_rows(rows: list[dict], **conds) -> list[dict]:
    """Keep rows where every key/value matches.

    Conditions can be a single value (equality) or a (lo, hi) tuple
    (inclusive range, applied to float-cast value).
    """
    out = []
    for r in rows:
        ok = True
        for k, v in conds.items():
            if isinstance(v, tuple) and len(v) == 2:
                try:
                    f = float(r.get(k, "nan"))
                except (TypeError, ValueError):
                    ok = False; break
                lo, hi = v
                if f < lo or f > hi:
                    ok = False; break
            else:
                if r.get(k) != v:
                    ok = False; break
        if ok:
            out.append(r)
    return out

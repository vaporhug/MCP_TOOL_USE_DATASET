This is a REDUCED benchmark subset of the supplementary data accompanying:
Benz et al. (2024) "Global groundwater warming due to climate change", Nature
Geoscience, DOI 10.1038/s41561-024-01453-x.

Files actually bundled for this benchmark task (this directory):
  - evaluation_meanGWT.csv : paired observed-vs-modelled mean groundwater
    temperatures at monitoring sites (used for model-skill evaluation,
    Fig. 2d in the paper).
  - streamSites_GWTchange.tab : 1,424 US stream sites with per-site
    Hare-2021 groundwater-signature classification and water-table dT
    projections (2000-2020 and 2000-2100 medians/IQRs under SSP2-4.5 and
    SSP5-8.5; paper Fig. 4c-f).
  - Temp_2020_*.tab : 2020 mean temperature versus depth at six paper-cited
    locations spanning six continents.
  - TempChange_2100to2000_ssp245_Model{1..9}_{Australia|Brazil|China|Mexico|Nigeria|Norway}.tab : per-location SSP2-4.5 2100-vs-2000 depth-profile temperature change from 9 CMIP6 ensemble
    of warming (used for the depth-attenuation analysis).

NOT included in this benchmark bundle (NOT required to solve the task):
  - The large global GeoTIFF rasters (Temp_2020_*.tif, depth-stratified
    projections, etc.) from the original Nature Geoscience supplementary
    release.
  - Full-grid SSP5-8.5 depth-profile NetCDFs.
  - The Google Earth Engine and Colab visualisation code.

The task can be solved entirely from the bundled CSV/TAB tables plus the
MCP tools shipped under ``tools/`` — no external downloads required.

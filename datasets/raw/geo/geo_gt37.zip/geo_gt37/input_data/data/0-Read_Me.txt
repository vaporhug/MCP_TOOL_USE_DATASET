These are data and codes used to generate all results in the study "Global groundwater warming due to climate change" by Benz et al. published under DOI 10.1038/s41561-024-01453-x in Nature Geoscience.


Table of Content:
1. Data
1.1 Images (.tif)
1.2. Tables (.csv)

2. Codes
2.1. Preparing Data
2.2. Main analysis
2.3. Visualization


------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
-------------------------------------1. Data---------------------------------------------------
------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------

We supply all data needed to make Figures 2 to 4 as well as Supplementary Figures S6-S8, and S12 and S13. Data used in all other figures can be generated through the provided codes.

------------------------------------------------------------------------------------------------
-------------------------------------1.1 Images (.tif) -----------------------------------------
------------------------------------------------------------------------------------------------


-Temp_2020_GWTable.tif: annual mean temperature of 2020 at the depth of the groundwater table (Fig 2a)
-Temp_2020_5m.tif: annual mean temperature of 2020 at 5m below the groundsurface (Fig 2b)
-Temp_2020_30m.tif: annual mean temperature of 2020 at 30m below the groundsurface (Fig 2c)

-TempChange_2020to2000_GWTable.tif: change in annual mean temperature between 2020 and 2000 at the depth of the groundwater table. (Fig 3a)
-TempChange_2020to2000_5m.tif: change in annual mean temperature between 2020 and 2000 at 5 m below ground. (Fig 3b)
-TempChange_2020to2000_30m.tif: change in annual mean temperature between 2020 and 2000 at 30 m below ground. (Fig 3c)
-TempChange_2100to2000_ssp245_GWTable.tif: change in annual mean temperature between 2100 and 2000 following SSP 245 at the depth of the groundwater table. The image has three bands showing median projections (p50, Fig 3e) as well as 25th and 75th percentile projections (Fig S6)
-TempChange_2100to2000_ssp245_5m.tif: change in annual mean temperature between 2100 and 2000 following SSP 245 at 5m below ground. The image has three bands showing median projections (p50, Fig 3f) as well as 25th and 75th percentile projections (Fig S6)
-TempChange_2100to2000_ssp245_30m.tif: change in annual mean temperature between 2100 and 2000 following SSP 245 at 30 m below ground. The image has three bands showing median projections (p50, Fig 3g) as well as 25th and 75th percentile projections (Fig S6)
-TempChange_2100to2000_ssp585_GWTable.tif: change in annual mean temperature between 2100 and 2000 following SSP 585 at the depth of the groundwater table. The image has three bands showing median projections (p50, Fig S7a) as well as 25th and 75th percentile projections (Fig S8)
-TempChange_2100to2000_ssp585_5m.tif: change in annual mean temperature between 2100 and 2000 following SSP 585 at 5m below ground. The image has three bands showing median projections (p50, Fig S7b) as well as 25th and 75th percentile projections (Fig S8)
-TempChange_2100to2000_ssp585_30m.tif: change in annual mean temperature between 2100 and 2000 following SSP 585 at 30 m below ground. The image has three bands showing median projections (p50, Fig S7c) as well as 25th and 75th percentile projections (Fig S8)



-Energy_2020.tif: Accumulated Energy in MJ/m^2 in 2020 from the surface down to 100m below ground (Fig 4a).
-Energy_2100_ssp245.tif: Accumulated Energy in MJ/m^2 in 2100 following SSP 245 from the surface down to 100m below ground (Fig 4d). The figure has 3 bands showing 25th, 50th (median), and 75th percentile projections. 
-Energy_2100_ssp585.tif: Accumulated Energy in MJ/m^2 in 2100 following SSP 585 from the surface down to 100m below ground (Fig S7e). The figure has 3 bands showing 25th, 50th (median), and 75th percentile projections. 
-Energy_2020_aquifer.tif: Accumulated Energy in MJ/m^2 in 2020 from the water table down to 100m below ground (Fig S12a).
-Energy_2100_ssp245_aquifer.tif: Accumulated Energy in MJ/m^2 in 2100 following SSP 245 from the water table down to 100m below ground (Fig S12b). The figure has 3 bands showing 25th, 50th (median), and 75th percentile projections. 
-Energy_2100_ssp585_aquifer.tif: Accumulated Energy in MJ/m^2 in 2100 following SSP 585 from the water table down to 100m below ground (Fig S12c). The figure has 3 bands showing 25th, 50th (median), and 75th percentile projections. 
-MaxTemp_2020_inflpoint.tif: maximum monthly temperature in 2020 at the depth of the thermal gradient inflection point (Fig 4b)
-MaxTemp_2020_GWTable.tif: maximum monthly temperature in 2020 at the depth of the groundwater table (Fig S13a)
-MaxTemp_2100_ssp245_inflpoint.tif: maximum monthly temperature in 2100 following SSP 245 at the depth of the thermal gradient inflection point. The three bands show median projections. Besides maximum temperatures, minimum and variation is also included.(Fig 4e)
-MaxTemp_2100_ssp245_GWTable.tif: maximum monthly temperature in 2100 following SSP 245 at the depth of the groundwater table. the three bands show median projections. Besides maximum temperatures, minimum and variation is also included.(Fig S13b)
-MaxTemp_2100_ssp585_inflpoint.tif: maximum monthly temperature in 2100 following SSP 585 at the depth of the thermal gradient inflection point. The three bands show median projections. Besides maximum temperatures, minimum and variation is also included.(Fig S7f)
-MaxTemp_2100_ssp585_GWTable.tif: maximum monthly temperature in 2100 following SP 585 at the depth of the groundwater table. The three bands show median projections. Besides maximum temperatures, minimum and variation is also included.(Fig S13c)


------------------------------------------------------------------------------------------------
-------------------------------------1.2 tables (.csv) -----------------------------------------
------------------------------------------------------------------------------------------------

-evaluation_meanGWT.csv: comparing modeled and measured GWTs for the dataset of (multi)-annual mean GWTs. Modeled temperatures are named in the column 'mean' with 'min' and 'max' giving uncertainties. Observed temperatures are labeled 'mGWT' (Fig 2d)
-evaluation_boreholes.csv: comparing modeled and measured GWTs for the dataset of (multi)-annual mean GWTs (Fig 2d). observed Temperatures are in the column 'observed_Temp', modeled temperatures in the column 'modeled_Temp'
-Temp_2020_*country name*.csv: temperature depth profiles for our six example locations. relevant columns are depth as well as max, min, and mean temperatures (Fig 2e)

-TempChange_2020to2000_*country name*.csv: temperature change between 2000 and 2020 as depth profiles for six example locations. the change in °C is given in column 'soil_temperature_level_1' (Fig 3d)
-TempChange_2100to2000_ssp245_Model*NR*_*country name*.csv: temperature change between 2000 and 2100 following SSP245 as depth profiles for six example locations and 9 models. the change in °C is given in column 'ssp245' (Fig 3h)
-TempChange_2100to2000_ssp585_Model*NR*_*country name*.csv: temperature change between 2000 and 2099 following RCP 8.5 as depth profiles for six example locations and 9 models. the change in °C is given in column 'ssp585' (Fig S7d)

-streamSites_GWTchange.csv - change in Temperatures at the groundwater level for all stream sites analyzed in Hare et al.(https://doi.org/10.1038/s41467-021-21651-0; Fig 4b,e and Fig S7g)


------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
-------------------------------------2. Codes---------------------------------------------------
------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------

This projects uses the google earth engine platform for most analysis, mainly their Javascript API but in some parts also python through google colab. These codes are provided as links in this document. All assets generated and used in this process are shared and can be accessed by anyone using the codes below.

In addition some figures are generated simply in python in jupyter notebook. 

------------------------------------------------------------------------------------------------
-------------------------------------2.1 Preparing Data-----------------------------------------
------------------------------------------------------------------------------------------------


-------------------------------------2.1.1 Diffusivity-----------------------------------------
Following the method outlined in our main publication, diffusivity (and heat capacity) were determined in Google earth engine and stored as an asset in form of an image using the following code: https://code.earthengine.google.com/0d3a40d0cd01c574a00ebbe77d68bff8


-------------------------------------2.1.2 Geothermal gradient-----------------------------------------
Similarly the geothermal gradient was saved as a google earth engine asset through this code: 
https://code.earthengine.google.com/83a2a50a7c6f26d21b8a1a7e8961cf76


-------------------------------------2.1.2 Ground Surface Temperature projections---------------------------------------
monthly ground surface temperatures of all CMIP6 scenarios (historic, SSP 245, SSP 585) discussed in this study for the 9 studied models were initially downloaded from in the .nc file format. We transformed them into the .tif file format through ArcGIS Pro before uploading these images to Google Earth Engine as assets (not shared to save on space in my GEE account). In their initial format they were represented in Google Earth Engine as images with multiple bands, each band representing one time step. We reformatted them in the desired format using the following code accessing google earth engine in python and google colab: 
https://colab.research.google.com/drive/1z_2_rPYCu2tzB2YDsN8DSaKBjIw-J8GA?usp=sharing

At this point the time series is not corrected based on the offset to the ERA-5 data. 


----------------------------------2.1.3 Depth to the Groundwater Table-------------------------------------------
groundwater table depth for each month is available from Fan et al (2013, 2017; https://doi.org/10.1126/science.1229881 and https://doi.org/10.1073/pnas.1712381114) and was uploaded to Google Earth Engine as an image asset for each continent. both the annual mean data is used as well as monthly mean - for the later each month is represented by a band named b1, b2 etc.   

----------------------------------2.1.3 Evaluation Data-------------------------------------------
(Multi-) annual mean groundwater temperatures from Benz et al 2022 (https://doi.org/10.1038/s41467-022-31624-6) were uploaded to Google earth engine as an asset.

Borehole temperatures from the Borehole Temperatures and Climate Reconstruction Database were scraped from their websites. First, we manually copied the overview of available data into an excel table ('boreholeData.xlsx', provided in this repository) and then accessing and downloading all of them using the python (jupyter notebook) code 'scrape borehole site.ipynb'. The first part of the code is run for each continent separately. 
We then uploaded the resulting file 'boreholes_GEE.csv' to Google Earth Engine as an asset.

------------------------------------------------------------------------------------------------
-------------------------------------2.2 Main analysis------------------------------------------
------------------------------------------------------------------------------------------------

-------------------------------------2.2.1 Google Earth Engine Java Script------------------------------------------

2.2.1.1 Primary Code
The main code needed to model subsurface temperatures is written in the javascript API of Google earth engine and accessible under https://code.earthengine.google.com/a9c9761323302734f58b3e22e2537f12

This code is used to calculate subsurface temperature from surface temperature time series, diffusivity, and geothermal gradient and exports the results for multiple depth and times. The main function here is getT(myT,t,z) which determines temperatures from the surface temperature time series myT (ImageCollection) for the time t (integer, given as an index for myT, not actual time), and depth z (as an image). It returns an image.

below the function, the model is run for a multitude of different depth and times (and scenarios). Most of this is commented out in the version shared above. in order from top to bottom it includes:

1) 'Export Input Parameters': Exporting as an image the input parameters geothermal gradient and diffusivity (Figure S16).
2) 'GST Offset': Exporting as assets the offset between the ERA-5 and CMIP5 Models. 
3) 'Temp Depth profiles for figures': Exporting as tables temperature depth profiles for selected locations. This part of the code needs to be run for each location separately. Resulting tables of this part are also made available in this repository.
4) 'Prep Maps for Figures': Exporting images of temperatures and temperature changes. the first part of the codes determines temperatures at a fixed depth, the second at the depth of the groundwater table. For future scenarios this only exports assets for each model and needs to be run separately for models 1 to 9. These are later combined as exported as images in the secondary analysis (see 2.2.1.2 Secondary Code). Results are shared in the 'Data' part of this repository.
5) 'Prep Maps for App': Exporting assets of annual mean temperatures at the groundwater table used in the accompanying app. For future scenario this needs to be run for each model separately and is again only the first half exporting assets for each model. These are combined in 2.2.1.2 Secondary Code. 
6) 'max temp infliction point' Exports maximum temperatures at the infliction point. Note - the code for the infliction points needs to be run before this (2.2.1.3. in this document). The code exports max temperatures in 2020 right away and saves as assets all data for 2100 for either scenario (see 2.2.1.2 Secondary Code).  
7) 'Prep Seasonality Figures': Exporting seasonal temperatures and seasonal changes in temperatures at the depth to the groundwater table as images. 
8) 'Prep evaluation data for GWT sites': Exporting to assets annual mean temperatures at 30m depth for each year between 2000 and 2014. These will be used in the 2.2.1.2 Secondary Code to validate our model with (multi)-annual mean temperatures.
9) 'Prep evaluation data for Boreholes': Exporting a table with temperature depth profiles at the time and locations of the profiles taken at the boreholes used for evaluation 
10) 'Prep evaluation time series': printing numbers showing changes in temp for specific locations (Table S1)

2.2.1.2 Secondary Code
The code https://code.earthengine.google.com/bef321a1a0cc345b8de8ed4d0de41ffd finalizes some of the analysis started in the main code described above. it contains several parts that are commented out in the version shared.

1) 'Compare modeled and observed data': following 7) from above this part of the code compares modeled to (multi-)annual mean data and exports it as a table. This table is  shared in the 'Data' section of this repository
2)'Summarize change in GWT for all depth and scenarios' exporting images of projected temperature changes at selected depth (5m, 30m and depth to the groundwater table). This part of the code accesses data generated in 4) above. Generated images are shared in the 'Data' folder of this repository.  
3) 'Getting seasonality (and max) temp 2100': exporting images showing maximum temperatures (and seasonality) at the groundwater table in 2100 for both scenarios. results are shared in the data section of this repository
4)) 'Getting seasonality (and max) temp 2100 at infl point': exporting images showing maximum temperatures (and seasonality) at the infliction point in 2100 for both scenarios. results are shared in the data section of this repository
5) 'for App Images': exports assets of annual mean, min, max temperatures and variations in temperatures for the median projections of both assessed scenarios in 2040, 2060, 2080 and 2100 to be used in the accompanying app. The code needs to be run multiple times with adjusted parameters. 

2.2.1.3 Inversion point
To generates maps showing the point at which the depth profile inverses we run the code https://code.earthengine.google.com/8b6b18637f7433232ba924d8539513c8 - it needs to be run three times: for the analysis in 2020, in 2100 SSP245 and 2100 SSP585. The exported file name needs to be adjusted and the corresponding part at the beginning commented out (or rather in). Data is exported as a assest (needed to find max temperatures at the infliction point, Seconary Code) as well as an image to drive. Be aware that the images for temperature depth profiles in the app (2.2.2.1 in this read me file) need to be run before as they are accessed. 


2.2.1.4. Impact of soil moisture
in Fig. S15 we test the impact of soil moisture of our model using this code: https://code.earthengine.google.com/8a30eb5747979faa4b378a4b3e05e9ad the code is run for each soil moisture category (dry, moist(default) and water saturated) and for each point separately.




-------------------------------------2.2.2 Google Earth Engine Python codes (Google Colab)---------------------------------------
Some of the analysis is run in google colab to minimize the needed input when generating images. 

2.2.2.1. Temperature Depth profiles in app.
The code https://colab.research.google.com/drive/1y31YMbbkLxOWvuKg8AlbLncR5N_NqOko?usp=sharing saves all images necessary to generate the temperature depth profiles in the app. some parts need to be run multiple times after adjusting variables as described in the code itself.

2.2.2.2. Temperature time series in app.
The code https://colab.research.google.com/drive/1SIJsRNHyY4C-og_4YSecpd1xbG6b5ThV?usp=sharing saves all images necessary to generate the time series in the app. some parts need to be run multiple times after adjusting variables as described in the code itself

2.2.2.3. Quantifying accumulated energy
The code https://colab.research.google.com/drive/17J8-OD_1lIeEeR482XNNoHwcgzxpKy-3?usp=sharing prepares assets needed to determine the accumulated energy. Some parts need to be multiple times (i.e., for each scenario and model). Be aware that these assets need a long time to export. (Each a couple of hours).

The java script code https://code.earthengine.google.com/6bbababf2de1a95acdb3c3ddd005b02c then summarizes the resulting assets and exports the total accumulated energy (of the entire subsurface or of the aquifer) as images.  


------------------------------------------------------------------------------------------------
-------------------------------------2.3 Visualization -------------------------------------
------------------------------------------------------------------------------------------------

While all maps shown in the main publications are soley based on the Google Earth Engine exports, we run several python (jupyter notebook) codes to prepare charts. Here these codes are described

-------------------------------------2.3.1 Model evaluation ------------------------------------- 
as first step we compare modeled and observed data in the boreholes - that is the data exported in 2.2.1.1 8). These data are read into the last codeblock of 'scrape borehole site.ipynb' (compare 2.1.3 Evaluation Data) where Figure S4 is created and a new evaluation_boreholes.csv file is created - that file is also shared in the data section of this repository.

The code 'Compare estimated and observed GWTs.ipynb' reads this file as well as evaluation_meanGWT.csv to generate all figures showing information on the evaluation of our model.

-------------------------------------2.3.2 Temperature depth profiles ------------------------------------- 
'Temp Depth Profiles.ipynb' reads all tables exported in 2.2.1.1. 3) and made available in this repository and generates temperature depth profiles. 

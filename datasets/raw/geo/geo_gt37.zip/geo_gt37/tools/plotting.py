#!/usr/bin/env python3
"""Plotting tools — one MCP tool per figure type.

Each plotting tool writes a PNG file and returns the absolute path. Inputs are
generic (lists / list-of-lists), so the tools can be reused across analyses.
"""

from __future__ import annotations

import os
from typing import Optional

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Plotting_Tools")


def _ensure_dir(path: str) -> None:
    d = os.path.dirname(os.path.abspath(path))
    if d:
        os.makedirs(d, exist_ok=True)


@mcp.tool()
def plot_scatter_evaluation(observed: list, modelled: list, output_path: str,
                            title: str = "Modelled vs observed",
                            xlabel: str = "Observed",
                            ylabel: str = "Modelled") -> dict:
    """Scatter of modelled vs observed values with 1:1 line, RMSE / R^2 annotation.

    Returns dict with file path, RMSE, R^2, and number of points.
    """
    _ensure_dir(output_path)
    o = np.asarray(observed, dtype=float)
    m = np.asarray(modelled, dtype=float)
    mask = ~(np.isnan(o) | np.isnan(m))
    o, m = o[mask], m[mask]
    err = m - o
    rmse = float(np.sqrt((err ** 2).mean())) if len(o) else float("nan")
    ss_res = float(((o - m) ** 2).sum())
    ss_tot = float(((o - o.mean()) ** 2).sum())
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else float("nan")
    fig, ax = plt.subplots(figsize=(7, 6))
    ax.scatter(o, m, s=12, alpha=0.45, color="#2a6cb6", edgecolor="none")
    lo = float(min(o.min(), m.min()))
    hi = float(max(o.max(), m.max()))
    ax.plot([lo, hi], [lo, hi], "k--", lw=1.0, label="1:1")
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.text(0.04, 0.94, f"N={len(o)}\nRMSE={rmse:.2f} °C\nR²={r2:.2f}",
            transform=ax.transAxes, va="top", ha="left",
            bbox=dict(facecolor="white", alpha=0.85, edgecolor="0.7"))
    ax.legend(loc="lower right")
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(output_path, dpi=160)
    plt.close(fig)
    return {"path": os.path.abspath(output_path),
            "n": int(len(o)), "rmse": rmse, "r_squared": r2}


@mcp.tool()
def plot_global_map(longitudes: list, latitudes: list, values: list,
                    output_path: str,
                    title: str = "Global distribution",
                    cmap: str = "RdYlBu_r",
                    vmin: Optional[float] = None,
                    vmax: Optional[float] = None,
                    cbar_label: str = "Value") -> dict:
    """Scatter points on a flat lon/lat map (no projection lib required).

    Coastlines are not drawn (no cartopy dep) — the figure shows points colour-
    coded by value with a global lon/lat frame.
    """
    _ensure_dir(output_path)
    lon = np.asarray(longitudes, dtype=float)
    lat = np.asarray(latitudes, dtype=float)
    val = np.asarray(values, dtype=float)
    mask = ~(np.isnan(val) | np.isnan(lat) | np.isnan(lon))
    lon, lat, val = lon[mask], lat[mask], val[mask]
    fig, ax = plt.subplots(figsize=(11, 5.5))
    sc = ax.scatter(lon, lat, c=val, cmap=cmap, s=8, alpha=0.75,
                    vmin=vmin, vmax=vmax, edgecolor="none")
    ax.set_xlim(-180, 180)
    ax.set_ylim(-90, 90)
    ax.set_xlabel("Longitude")
    ax.set_ylabel("Latitude")
    ax.set_title(title)
    ax.grid(alpha=0.25, linestyle=":")
    cb = fig.colorbar(sc, ax=ax, fraction=0.04, pad=0.02)
    cb.set_label(cbar_label)
    fig.tight_layout()
    fig.savefig(output_path, dpi=160)
    plt.close(fig)
    return {"path": os.path.abspath(output_path), "n_points": int(len(val))}


@mcp.tool()
def plot_depth_profile(depths_per_series: list, values_per_series: list,
                       labels: list, output_path: str,
                       title: str = "Depth profile",
                       xlabel: str = "Value",
                       ylabel: str = "Depth (m)",
                       invert_y: bool = True,
                       shade_band: Optional[dict] = None) -> dict:
    """Multi-series depth profile (depth on y-axis, value on x-axis).

    Args:
        depths_per_series: list of lists — one depth list per series.
        values_per_series: list of lists — matching value list per series.
        labels: list of legend labels (same length as series).
        shade_band: optional dict {"depths": [...], "lower": [...], "upper": [...]}
            to draw a shaded uncertainty envelope.
    """
    _ensure_dir(output_path)
    fig, ax = plt.subplots(figsize=(7, 8))
    colors = plt.cm.tab10(np.linspace(0, 1, max(len(labels), 3)))
    for d, v, lab, c in zip(depths_per_series, values_per_series, labels, colors):
        ax.plot(v, d, "-o", ms=3, lw=1.4, label=str(lab), color=c)
    if shade_band:
        d = np.asarray(shade_band["depths"], dtype=float)
        lo = np.asarray(shade_band["lower"], dtype=float)
        hi = np.asarray(shade_band["upper"], dtype=float)
        ax.fill_betweenx(d, lo, hi, color="0.6", alpha=0.25,
                         label=shade_band.get("label", "envelope"))
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    if invert_y:
        ax.invert_yaxis()
    ax.legend(loc="best", fontsize=9)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(output_path, dpi=160)
    plt.close(fig)
    return {"path": os.path.abspath(output_path), "n_series": int(len(labels))}


@mcp.tool()
def plot_histogram(values: list, output_path: str,
                   title: str = "Histogram",
                   xlabel: str = "Value",
                   ylabel: str = "Frequency",
                   bins: int = 40,
                   reference_lines: Optional[list] = None) -> dict:
    """Single-variable histogram with optional vertical reference lines."""
    _ensure_dir(output_path)
    a = np.asarray(values, dtype=float)
    a = a[~np.isnan(a)]
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.hist(a, bins=bins, color="#3a86ff", alpha=0.78, edgecolor="white")
    if reference_lines:
        for line in reference_lines:
            x = float(line.get("x"))
            ax.axvline(x, color=line.get("color", "red"),
                       linestyle=line.get("linestyle", "--"),
                       lw=1.4,
                       label=line.get("label"))
        ax.legend(loc="best")
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(output_path, dpi=160)
    plt.close(fig)
    return {"path": os.path.abspath(output_path),
            "n": int(len(a)), "mean": float(a.mean()) if len(a) else None}


@mcp.tool()
def plot_grouped_bars(group_labels: list, series_labels: list,
                      values_matrix: list, output_path: str,
                      title: str = "Grouped bar chart",
                      ylabel: str = "Value",
                      yerr_matrix: Optional[list] = None) -> dict:
    """Grouped bar chart.

    values_matrix: shape [n_series][n_groups]; one bar group per group_label,
    one bar per series within each group. Optional yerr_matrix for error bars.
    """
    _ensure_dir(output_path)
    n_groups = len(group_labels)
    n_series = len(series_labels)
    x = np.arange(n_groups)
    width = 0.8 / max(n_series, 1)
    fig, ax = plt.subplots(figsize=(max(7, n_groups * 1.2), 5))
    colors = plt.cm.viridis(np.linspace(0.15, 0.85, n_series))
    for i, (slab, vals) in enumerate(zip(series_labels, values_matrix)):
        offset = (i - (n_series - 1) / 2) * width
        err = yerr_matrix[i] if yerr_matrix is not None else None
        ax.bar(x + offset, vals, width, label=slab, color=colors[i],
               yerr=err, capsize=3)
    ax.set_xticks(x)
    ax.set_xticklabels(group_labels, rotation=20, ha="right")
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.legend(loc="best", fontsize=9)
    ax.grid(alpha=0.3, axis="y")
    fig.tight_layout()
    fig.savefig(output_path, dpi=160)
    plt.close(fig)
    return {"path": os.path.abspath(output_path)}


if __name__ == "__main__":
    mcp.run(transport="stdio")

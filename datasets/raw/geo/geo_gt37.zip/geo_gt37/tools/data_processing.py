"""Generic data-processing utilities (format conversion, reshape, clean, join).

Domain-specific transforms (depth-profile interpolation, ensemble percentiles,
trend tests, etc.) live in temperature_analysis.py. This module is reusable
across tasks.
"""

from __future__ import annotations

import csv
import json
from typing import Any, Optional


def read_csv(path: str, delimiter: str = ",") -> list[dict]:
    """Parse CSV into list-of-dicts using csv.DictReader."""
    with open(path, newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f, delimiter=delimiter))


def write_csv(rows: list[dict], path: str) -> None:
    """Write list-of-dicts to CSV using the first row's keys as header."""
    if not rows:
        open(path, "w").close(); return
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)


def read_json(path: str) -> Any:
    with open(path) as f:
        return json.load(f)


def write_json(obj: Any, path: str, indent: int = 2) -> None:
    with open(path, "w") as f:
        json.dump(obj, f, indent=indent, default=str)


def read_excel(path: str, sheet_name: str | int | None = 0) -> list[dict]:
    """Read an .xlsx sheet into list-of-dicts (requires openpyxl/pandas)."""
    pass  # heavy: requires pandas or openpyxl — fill in at runtime


def read_geotiff(path: str) -> dict:
    """Read a single-band GeoTIFF and return array, transform, and CRS.

    Returns: {"array": list-of-lists, "shape": (h, w), "transform": affine,
              "crs": str, "nodata": float}
    """
    pass  # heavy: rasterio


def read_shapefile(path: str) -> list[dict]:
    """ESRI shapefile / GeoJSON / geopackage vector reader (geopandas)."""
    pass  # heavy


def drop_missing(rows: list[dict], cols: Optional[list[str]] = None) -> list[dict]:
    """Remove rows where any (or listed) columns are None / empty / NaN."""
    def bad(v):
        return v is None or v == "" or (isinstance(v, float) and v != v)
    if cols is None:
        return [r for r in rows if not any(bad(v) for v in r.values())]
    return [r for r in rows if not any(bad(r.get(c)) for c in cols)]


def coerce_numeric(rows: list[dict], cols: list[str]) -> list[dict]:
    """Cast named columns to float; non-parseable → None."""
    out = []
    for r in rows:
        r2 = dict(r)
        for c in cols:
            try:
                r2[c] = float(r2[c])
            except (TypeError, ValueError):
                r2[c] = None
        out.append(r2)
    return out


def join_tables(left: list[dict], right: list[dict], on: str,
                how: str = "inner") -> list[dict]:
    """SQL-style join on a single key."""
    idx = {r[on]: r for r in right}
    out = []
    for l in left:
        r = idx.get(l.get(on))
        if r is not None:
            out.append({**l, **{k: v for k, v in r.items() if k != on}})
        elif how == "left":
            out.append(dict(l))
    return out


def groupby_aggregate(rows: list[dict], by: str,
                      agg: dict[str, str]) -> list[dict]:
    """Group rows by `by` and apply per-column aggregations
    (mean | sum | min | max | count)."""
    from statistics import mean
    groups: dict = {}
    for r in rows:
        groups.setdefault(r[by], []).append(r)
    out = []
    for key, grp in groups.items():
        row = {by: key}
        for col, fn in agg.items():
            vals = []
            for g in grp:
                try:
                    vals.append(float(g.get(col)))
                except (TypeError, ValueError):
                    pass
            if fn == "mean":
                row[col] = mean(vals) if vals else None
            elif fn == "sum":
                row[col] = sum(vals)
            elif fn == "min":
                row[col] = min(vals) if vals else None
            elif fn == "max":
                row[col] = max(vals) if vals else None
            elif fn == "count":
                row[col] = len(vals)
        out.append(row)
    return out

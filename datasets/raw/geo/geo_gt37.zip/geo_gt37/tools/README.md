# geo_gt37 — Tool Reference

## Domain Analysis (`temperature_analysis.py`)

FastMCP server providing reusable primitives for groundwater-temperature analysis.

- **load_table**: Read a CSV/TSV/SSV with auto-detected delimiter; returns columns + preview.
- **load_column**: Pull one numeric column out of a table as a list of floats.
- **theil_sen_slope**: Robust median-of-pairwise-slopes regression with 95% CI.
- **mann_kendall_test**: Non-parametric monotonic-trend test (S, z, p, Sen's slope).
- **compare_observed_vs_modelled**: RMSE / MAE / bias / R² between two paired series.
- **descriptive_stats**: mean / std / min / median / 10-25-75-90 percentiles / max.
- **quantiles**: arbitrary quantiles of a numeric list.
- **threshold_count**: count and percentage of values satisfying a comparison.
- **group_aggregate**: groupby + (mean|median|sum|count|min|max|std) on list-of-dicts.
- **ensemble_summary**: per-ensemble p50/p25/p75 statistics (e.g., across 9 climate models).
- **ensemble_pointwise**: pointwise percentiles across a stack of equal-length profiles.
- **spatial_bin_by_latitude**: aggregate point values into latitudinal bands.
- **filter_rows**: filter list-of-dicts by a column condition.
- **interpolate_at_depth**: linearly interpolate a depth profile at a target depth.
- **find_inflection_depth**: locate the first slope-reversal in a depth profile.

## Plotting (`plotting.py`)

Each plotting tool writes a PNG and returns its absolute path.

- **plot_scatter_evaluation**: modelled vs observed scatter with 1:1 line, RMSE/R² annotation.
- **plot_global_map**: lon/lat scatter coloured by value (no projection deps).
- **plot_depth_profile**: multi-series temperature-vs-depth with optional shaded envelope.
- **plot_histogram**: single-variable histogram with optional vertical reference lines.
- **plot_grouped_bars**: grouped bars (multi-series per group) with optional error bars.

## Generic Data Processing (`data_processing.py`)

- **read_csv / write_csv / read_json / write_json**: tabular IO helpers.
- **read_excel / read_geotiff / read_shapefile**: executable readers with clear
  runtime dependency checks (pandas/openpyxl, rasterio, geopandas).
- **drop_missing / coerce_numeric**: row cleaning.
- **join_tables / groupby_aggregate**: relational helpers.

## Database Retrieval (`database_retrieval.py`)

Lightweight executable helpers for online metadata retrieval.

- **websearch**: OpenAlex-based literature search.
- **fetch_url**: generic HTTP byte download.
- **query_doi**: Crossref DOI metadata resolution.
- **query_borealis / query_zenodo**: repository metadata calls.
- **query_era5 / query_cmip6**: structured query descriptors for downstream
  climate-data clients (not full authenticated download pipelines).

These retrieval helpers are optional for `geo_gt37`; core scoring analyses are
fully supported by local files plus `temperature_analysis.py` and `plotting.py`.

## Data File Format Notes (geo_gt37 bundle)

- `streamSites_GWTchange.tab` is tab-delimited.
- `Temp_2020_<country>.tab` files are tab-delimited depth profiles.
- `TempChange_2020to2000_<country>.csv` files are CSV depth profiles.

## Dependencies

```
numpy
scipy
pandas
matplotlib
mcp           # fastmcp server
```

Run a server: `python tools/temperature_analysis.py` (stdio transport).

#!/usr/bin/env python3
"""Domain-level analysis tools for groundwater temperature time-series and depth profiles.

These are general-purpose primitives (load tabular data, fit trends, aggregate by
category, ensemble statistics) — no project-specific logic baked in. They can be
reused for any temperature-vs-depth or temperature-vs-time analysis.
"""

from __future__ import annotations

import csv
import math
from typing import Optional

import numpy as np
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Groundwater_Temperature_Tools")


# ----------------------------------------------------------------------------
# Loaders
# ----------------------------------------------------------------------------


def _read_table(path: str, sep: Optional[str] = None) -> tuple[list[str], list[list[str]]]:
    """Read a delimited table; auto-detect ; \\t , when sep is None."""
    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        first = f.readline()
        if sep is None:
            sep = ";" if first.count(";") > first.count("\t") else (
                "\t" if "\t" in first else ",")
        f.seek(0)
        reader = csv.reader(f, delimiter=sep)
        rows = list(reader)
    if not rows:
        return [], []
    header = [h.strip() for h in rows[0]]
    body = rows[1:]
    return header, body


@mcp.tool()
def load_table(path: str, sep: Optional[str] = None, max_rows: int = 50) -> dict:
    """Load a CSV/TSV/SSV file and return columns and a row preview.

    Args:
        path: Path to file (.csv .tsv .tab .txt). Delimiter auto-detected.
        sep: Optional explicit delimiter; when None, ; \\t , are tried in order.
        max_rows: Number of preview rows returned (full file is counted).
    """
    header, body = _read_table(path, sep)
    rows = [dict(zip(header, r)) for r in body]
    return {
        "columns": header,
        "n_rows": len(rows),
        "preview": rows[:max_rows],
        "truncated": len(rows) > max_rows,
    }


@mcp.tool()
def load_column(path: str, column: str, sep: Optional[str] = None,
                drop_missing: bool = True) -> dict:
    """Load one column from a CSV/TSV file as a list of floats."""
    header, body = _read_table(path, sep)
    if column not in header:
        return {"error": f"Column {column!r} not in {header}"}
    idx = header.index(column)
    out = []
    for r in body:
        if idx >= len(r):
            v = None
        else:
            try:
                v = float(r[idx])
            except (ValueError, TypeError):
                v = None
        if drop_missing and v is None:
            continue
        out.append(v)
    return {"column": column, "values": out, "n": len(out)}


# ----------------------------------------------------------------------------
# Trend tests
# ----------------------------------------------------------------------------


@mcp.tool()
def theil_sen_slope(x_values: list, y_values: list) -> dict:
    """Theil-Sen robust slope and 95% CI (median of pairwise slopes).

    Returns slope, intercept, lower/upper 95% bounds, and number of points.
    """
    from scipy.stats import theilslopes
    x = np.asarray(x_values, dtype=float)
    y = np.asarray(y_values, dtype=float)
    mask = ~(np.isnan(x) | np.isnan(y))
    x, y = x[mask], y[mask]
    if len(x) < 3:
        return {"error": "Need at least 3 points"}
    slope, intercept, lo, hi = theilslopes(y, x)
    return {
        "slope": float(slope),
        "intercept": float(intercept),
        "slope_lower_95": float(lo),
        "slope_upper_95": float(hi),
        "n_points": int(len(x)),
    }


@mcp.tool()
def mann_kendall_test(values: list) -> dict:
    """Mann-Kendall non-parametric trend test on an ordered series.

    Returns S statistic, z-score, two-sided p-value, trend label, and Sen's slope.
    """
    from scipy.stats import norm, theilslopes
    y = np.asarray(values, dtype=float)
    y = y[~np.isnan(y)]
    n = len(y)
    if n < 3:
        return {"error": "Need at least 3 points"}
    s = 0
    for i in range(n - 1):
        diffs = y[i + 1:] - y[i]
        s += int((diffs > 0).sum()) - int((diffs < 0).sum())
    var_s = n * (n - 1) * (2 * n + 5) / 18.0
    if s > 0:
        z = (s - 1) / math.sqrt(var_s)
    elif s < 0:
        z = (s + 1) / math.sqrt(var_s)
    else:
        z = 0.0
    p = 2 * (1 - norm.cdf(abs(z)))
    if p < 0.05:
        trend = "increasing" if s > 0 else "decreasing"
    else:
        trend = "no significant trend"
    slope, intercept, _, _ = theilslopes(y, np.arange(n))
    return {
        "S": int(s),
        "z_statistic": float(z),
        "p_value": float(p),
        "trend": trend,
        "sens_slope": float(slope),
        "n_points": int(n),
    }


# ----------------------------------------------------------------------------
# Comparison / error metrics
# ----------------------------------------------------------------------------


@mcp.tool()
def compare_observed_vs_modelled(observed: list, modelled: list) -> dict:
    """Compute RMSE, MAE, bias, R^2 between two equally-long numeric series."""
    o = np.asarray(observed, dtype=float)
    m = np.asarray(modelled, dtype=float)
    mask = ~(np.isnan(o) | np.isnan(m))
    o, m = o[mask], m[mask]
    if len(o) < 2:
        return {"error": "Need at least 2 paired points"}
    err = m - o
    rmse = float(math.sqrt(float((err ** 2).mean())))
    mae = float(np.abs(err).mean())
    bias = float(err.mean())
    ss_res = float(((o - m) ** 2).sum())
    ss_tot = float(((o - o.mean()) ** 2).sum())
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else float("nan")
    return {
        "n": int(len(o)),
        "rmse": rmse,
        "mae": mae,
        "bias_modelled_minus_observed": bias,
        "r_squared": r2,
        "observed_mean": float(o.mean()),
        "modelled_mean": float(m.mean()),
    }


# ----------------------------------------------------------------------------
# Aggregations (descriptive stats / quantiles / classification)
# ----------------------------------------------------------------------------


@mcp.tool()
def descriptive_stats(values: list) -> dict:
    """Mean / std / min / max / median / 10-25-75-90 percentiles."""
    a = np.asarray(values, dtype=float)
    a = a[~np.isnan(a)]
    if len(a) == 0:
        return {"error": "Empty array"}
    return {
        "n": int(len(a)),
        "mean": float(a.mean()),
        "std": float(a.std(ddof=0)),
        "min": float(a.min()),
        "p10": float(np.percentile(a, 10)),
        "p25": float(np.percentile(a, 25)),
        "median": float(np.median(a)),
        "p75": float(np.percentile(a, 75)),
        "p90": float(np.percentile(a, 90)),
        "max": float(a.max()),
    }


@mcp.tool()
def quantiles(values: list, qs: list) -> dict:
    """Return the requested quantiles (each in [0,1]) of a list of floats."""
    a = np.asarray(values, dtype=float)
    a = a[~np.isnan(a)]
    return {"q": qs, "values": [float(np.quantile(a, q)) for q in qs], "n": int(len(a))}


@mcp.tool()
def threshold_count(values: list, operator: str, threshold: float) -> dict:
    """Count how many values satisfy a comparison (> < >= <= ==).

    Returns count, total non-NaN, fraction, and percentage.
    """
    a = np.asarray(values, dtype=float)
    a = a[~np.isnan(a)]
    ops = {">": a > threshold, "<": a < threshold,
           ">=": a >= threshold, "<=": a <= threshold,
           "==": a == threshold}
    if operator not in ops:
        return {"error": f"Unknown operator: {operator}"}
    mask = ops[operator]
    n = int(len(a))
    k = int(mask.sum())
    return {
        "count": k,
        "total": n,
        "fraction": k / n if n else 0.0,
        "percentage": 100 * k / n if n else 0.0,
        "operator": operator,
        "threshold": threshold,
    }


@mcp.tool()
def group_aggregate(rows: list, group_by: str, value_column: str,
                    statistic: str = "mean") -> dict:
    """Group a list-of-dicts by a column and compute an aggregate of another.

    statistic: mean | median | sum | count | min | max | std
    """
    groups: dict = {}
    for r in rows:
        k = r.get(group_by)
        try:
            v = float(r.get(value_column))
        except (TypeError, ValueError):
            continue
        if math.isnan(v):
            continue
        groups.setdefault(k, []).append(v)
    out = {}
    for k, vs in groups.items():
        a = np.asarray(vs)
        if statistic == "mean":
            out[str(k)] = float(a.mean())
        elif statistic == "median":
            out[str(k)] = float(np.median(a))
        elif statistic == "sum":
            out[str(k)] = float(a.sum())
        elif statistic == "count":
            out[str(k)] = int(len(a))
        elif statistic == "min":
            out[str(k)] = float(a.min())
        elif statistic == "max":
            out[str(k)] = float(a.max())
        elif statistic == "std":
            out[str(k)] = float(a.std(ddof=0))
        else:
            return {"error": f"Unknown statistic: {statistic}"}
    return {
        "group_by": group_by,
        "value_column": value_column,
        "statistic": statistic,
        "n_groups": len(out),
        "results": out,
    }


# ----------------------------------------------------------------------------
# Ensemble (multi-model) statistics
# ----------------------------------------------------------------------------


@mcp.tool()
def ensemble_summary(values: list) -> dict:
    """Summary stats for an ensemble of values (e.g. one value per climate model).

    Returns median (p50), p25, p75, mean, std, min, max, n.
    """
    a = np.asarray(values, dtype=float)
    a = a[~np.isnan(a)]
    if len(a) == 0:
        return {"error": "Empty"}
    return {
        "n_members": int(len(a)),
        "median_p50": float(np.median(a)),
        "p25": float(np.percentile(a, 25)),
        "p75": float(np.percentile(a, 75)),
        "mean": float(a.mean()),
        "std": float(a.std(ddof=0)),
        "min": float(a.min()),
        "max": float(a.max()),
    }


@mcp.tool()
def ensemble_pointwise(profiles: list, percentiles: list = [25, 50, 75]) -> dict:
    """Compute pointwise percentiles across a stack of equal-length profiles.

    Args:
        profiles: list of equal-length numeric lists (one per ensemble member).
        percentiles: list of percentile levels (0-100) to compute at each index.
    Returns:
        dict mapping each percentile to a list giving that percentile across
        members at every position in the profile.
    """
    arr = np.asarray(profiles, dtype=float)
    if arr.ndim != 2:
        return {"error": "profiles must be a list of equal-length lists"}
    out = {}
    for p in percentiles:
        out[f"p{int(p)}"] = [float(x) for x in np.percentile(arr, p, axis=0)]
    return {
        "n_members": int(arr.shape[0]),
        "n_points": int(arr.shape[1]),
        "percentiles": out,
    }


# ----------------------------------------------------------------------------
# Spatial: bin by latitude, by category, by region
# ----------------------------------------------------------------------------


@mcp.tool()
def spatial_bin_by_latitude(latitudes: list, values: list, n_bands: int = 18) -> dict:
    """Bin point values into latitude bands (default 10° each, -90..90).

    Returns each band's lat range, count, and mean / median value.
    """
    lat = np.asarray(latitudes, dtype=float)
    v = np.asarray(values, dtype=float)
    edges = np.linspace(-90, 90, n_bands + 1)
    out = []
    for i in range(n_bands):
        lo, hi = edges[i], edges[i + 1]
        mask = (lat >= lo) & (lat < hi) & ~np.isnan(v)
        if mask.sum() == 0:
            continue
        out.append({
            "lat_range": [float(lo), float(hi)],
            "n": int(mask.sum()),
            "mean": float(v[mask].mean()),
            "median": float(np.median(v[mask])),
        })
    return {"n_bands": n_bands, "n_with_data": len(out), "bands": out}


@mcp.tool()
def filter_rows(rows: list, column: str, operator: str, value) -> dict:
    """Filter a list-of-dicts by a column condition. Operator: == != > < >= <= in."""
    out = []
    for r in rows:
        cell = r.get(column)
        try:
            keep = False
            if operator == "==":
                keep = str(cell) == str(value)
            elif operator == "!=":
                keep = str(cell) != str(value)
            elif operator in (">", "<", ">=", "<="):
                a = float(cell); b = float(value)
                keep = {">": a > b, "<": a < b, ">=": a >= b, "<=": a <= b}[operator]
            elif operator == "in":
                keep = cell in value
            else:
                return {"error": f"Unknown operator: {operator}"}
        except (TypeError, ValueError):
            keep = False
        if keep:
            out.append(r)
    return {"n_kept": len(out), "rows": out}


# ----------------------------------------------------------------------------
# Depth-profile helpers (general-purpose, not paper-specific)
# ----------------------------------------------------------------------------


@mcp.tool()
def interpolate_at_depth(depths: list, values: list, target_depth: float) -> dict:
    """Linearly interpolate a profile value at an arbitrary depth.

    Useful for extracting values at, e.g., 5 m or 30 m from a depth/value pair.
    """
    d = np.asarray(depths, dtype=float)
    v = np.asarray(values, dtype=float)
    order = np.argsort(d)
    d, v = d[order], v[order]
    if target_depth < d.min() or target_depth > d.max():
        return {"warning": "Extrapolating", "value": float(np.interp(target_depth, d, v))}
    return {"depth": float(target_depth), "value": float(np.interp(target_depth, d, v))}


@mcp.tool()
def find_inflection_depth(depths: list, values: list) -> dict:
    """Locate the depth at which a profile reverses direction (inflection point).

    Returns the depth where the profile transitions from decreasing to increasing
    or vice versa, the corresponding value, and direction labels above/below.
    """
    d = np.asarray(depths, dtype=float)
    v = np.asarray(values, dtype=float)
    order = np.argsort(d)
    d, v = d[order], v[order]
    if len(d) < 4:
        return {"error": "Need at least 4 points"}
    diffs = np.sign(np.diff(v))
    # locate first sign change in slope
    for i in range(1, len(diffs)):
        if diffs[i] != 0 and diffs[i - 1] != 0 and diffs[i] != diffs[i - 1]:
            return {
                "inflection_depth": float(d[i]),
                "inflection_value": float(v[i]),
                "direction_above": ("increasing" if diffs[0] > 0 else "decreasing"),
                "direction_below": ("increasing" if diffs[i] > 0 else "decreasing"),
            }
    return {"inflection_depth": None, "note": "No inflection in monotonic profile"}


if __name__ == "__main__":
    mcp.run(transport="stdio")

"""Thin placeholders for external-database retrieval calls.

Heavy network/parsing implementations are intentionally stubbed out — fill in
at execution time with the appropriate library (requests, owslib, etc.).
"""

from typing import Any, Optional


def websearch(query: str, max_results: int = 10) -> list[dict]:
    """Generic web search. Returns list of {title, url, snippet}."""
    pass  # heavy: requires search API


def fetch_url(url: str, timeout: int = 30) -> bytes:
    """HTTP GET with redirects; download a file from a known URL."""
    pass  # heavy


def query_borealis(persistent_id: str) -> dict:
    """Borealis (Dataverse) dataset metadata + file listing."""
    pass  # heavy: REST API + auth


def query_zenodo(record_id: str) -> dict:
    """Zenodo record metadata + file listing."""
    pass  # heavy


def query_era5(variable: str, lat: float, lon: float,
               start_year: int, end_year: int) -> list[dict]:
    """ERA-5 reanalysis time series at a point (CDS API)."""
    pass  # heavy


def query_cmip6(variable: str, model: str, scenario: str,
                lat: float, lon: float) -> list[dict]:
    """CMIP6 climate-model output at a point (ESGF / Pangeo)."""
    pass  # heavy


def query_doi(doi: str) -> dict:
    """Resolve DOI to Crossref metadata + Unpaywall OA full-text URL."""
    pass  # heavy

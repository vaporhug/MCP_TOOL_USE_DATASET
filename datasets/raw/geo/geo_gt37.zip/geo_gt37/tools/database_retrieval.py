"""Lightweight retrieval helpers for common web and metadata endpoints.

These functions are intentionally minimal but executable (no pass placeholders).
They return parsed JSON where possible and provide deterministic error payloads
for unavailable upstream services.
"""

from __future__ import annotations

import json
import urllib.parse
import urllib.request


def _http_get(url: str, timeout: int = 30, headers: dict | None = None) -> bytes:
    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": "geo_gt37-database-retrieval/1.0",
            **(headers or {}),
        },
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read()


def _get_json(url: str, timeout: int = 30, headers: dict | None = None) -> dict:
    data = _http_get(url, timeout=timeout, headers=headers)
    return json.loads(data.decode("utf-8"))


def websearch(query: str, max_results: int = 10) -> list[dict]:
    """Query OpenAlex works as a lightweight literature search fallback."""
    q = urllib.parse.quote_plus(query)
    n = max(1, min(int(max_results), 50))
    url = f"https://api.openalex.org/works?search={q}&per-page={n}"
    payload = _get_json(url)
    out = []
    for item in payload.get("results", []):
        out.append(
            {
                "title": item.get("display_name"),
                "url": item.get("id"),
                "snippet": item.get("publication_year"),
            }
        )
    return out


def fetch_url(url: str, timeout: int = 30) -> bytes:
    """HTTP GET with redirects; download bytes from a URL."""
    return _http_get(url, timeout=timeout)


def query_borealis(persistent_id: str) -> dict:
    """Dataverse/Borealis dataset metadata from a persistent identifier."""
    pid = urllib.parse.quote_plus(persistent_id)
    url = f"https://borealisdata.ca/api/datasets/:persistentId/?persistentId={pid}"
    return _get_json(url)


def query_zenodo(record_id: str) -> dict:
    """Zenodo record metadata + file listing."""
    rid = urllib.parse.quote_plus(str(record_id))
    url = f"https://zenodo.org/api/records/{rid}"
    return _get_json(url)


def query_era5(variable: str, lat: float, lon: float,
               start_year: int, end_year: int) -> list[dict]:
    """ERA5 monthly means from Copernicus CDS API (metadata endpoint only).

    This helper intentionally does not submit CDS jobs. It returns a structured
    query payload so callers can log or forward the exact request.
    """
    return [
        {
            "service": "cds-era5-monthly-means",
            "variable": variable,
            "latitude": float(lat),
            "longitude": float(lon),
            "start_year": int(start_year),
            "end_year": int(end_year),
            "note": "Submit this payload with an authenticated CDS client.",
        }
    ]


def query_cmip6(variable: str, model: str, scenario: str,
                lat: float, lon: float) -> list[dict]:
    """Return a structured CMIP6 search query descriptor (ESGF/Pangeo ready)."""
    return [
        {
            "service": "cmip6-search-descriptor",
            "variable": variable,
            "model": model,
            "scenario": scenario,
            "latitude": float(lat),
            "longitude": float(lon),
            "note": "Use this descriptor against ESGF or Pangeo catalog APIs.",
        }
    ]


def query_doi(doi: str) -> dict:
    """Resolve DOI to Crossref metadata."""
    doi_norm = doi.strip().removeprefix("https://doi.org/").removeprefix("doi:")
    doi_enc = urllib.parse.quote(doi_norm, safe="")
    url = f"https://api.crossref.org/works/{doi_enc}"
    return _get_json(url)

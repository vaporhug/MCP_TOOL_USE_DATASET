#!/usr/bin/env python3
"""Agrivoltaics / ecovoltaic niche-analysis primitives.

Low-level functions for converting between energy units, scoring sites for
solar suitability against multi-criteria thresholds, fitting simple
classification / regression models on site features, aggregating
state-level statistics, and producing publication-quality figures.

These are general-purpose primitives — none of them embed the paper's
headline numerical conclusions.  An agent must chain them together with
the supplied input CSVs to reproduce the analysis.
"""
from __future__ import annotations

import csv
import os
from typing import Any

import numpy as np
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Agrivoltaics_Niche_Tools")


# ---------------------------------------------------------------------------
# Loading helpers
# ---------------------------------------------------------------------------
@mcp.tool()
def load_parameter_table(csv_path: str) -> dict:
    """Load a key/value parameter CSV into a dict.

    Expects columns named 'parameter' and 'value' (extra columns ignored).

    Args:
        csv_path: Path to the parameters CSV.

    Returns:
        dict with parameter name -> float value, plus metadata.
    """
    out: dict[str, float] = {}
    units: dict[str, str] = {}
    sources: dict[str, str] = {}
    with open(csv_path, newline="") as f:
        for r in csv.DictReader(f):
            try:
                out[r["parameter"]] = float(r["value"])
            except (ValueError, KeyError):
                continue
            if "unit" in r:
                units[r["parameter"]] = r["unit"]
            if "source" in r:
                sources[r["parameter"]] = r["source"]
    return {"parameters": out, "units": units, "sources": sources,
            "n_parameters": len(out)}


@mcp.tool()
def load_table(csv_path: str) -> dict:
    """Load any CSV into a list-of-dicts plus column summary.

    Args:
        csv_path: Path to CSV file.

    Returns:
        dict with columns, total_rows, and the first 200 rows.
    """
    with open(csv_path, newline="") as f:
        rows = list(csv.DictReader(f))
    cols = list(rows[0].keys()) if rows else []
    return {"columns": cols, "total_rows": len(rows),
            "rows": rows[:200], "truncated": len(rows) > 200}


# ---------------------------------------------------------------------------
# Energy unit conversions
# ---------------------------------------------------------------------------
@mcp.tool()
def ethanol_gallons_to_mwh(gallons: float, btu_per_gallon: float = 84595,
                           btu_per_kwh: float = 3412) -> dict:
    """Convert ethanol fuel volume to electricity-equivalent energy.

    Uses EIA conversion factors: ethanol heat content (Btu/gallon) ->
    Btu -> kWh -> MWh.  Defaults are EIA 2022 values.

    Args:
        gallons: Ethanol volume in US gallons.
        btu_per_gallon: Heat content (default 84,595 Btu/gal).
        btu_per_kwh: Energy conversion (default 3,412 Btu/kWh).

    Returns:
        dict with btu, kwh, mwh, twh values.
    """
    btu = gallons * btu_per_gallon
    kwh = btu / btu_per_kwh
    mwh = kwh / 1000.0
    twh = mwh / 1_000_000.0
    return {"gallons": gallons, "btu": btu, "kwh": kwh, "mwh": mwh, "twh": twh,
            "quad_btu": btu / 1e15}


@mcp.tool()
def mwh_to_solar_capacity(mwh: float, capacity_factor: float = 0.247,
                          hours_per_year: float = 8760) -> dict:
    """Convert annual MWh generation requirement to nameplate MW capacity.

    Capacity_MW = Generation_MWh / (hours_per_year * capacity_factor).

    Args:
        mwh: Annual electricity generation requirement (MWh).
        capacity_factor: Fraction (default 0.247 for utility-scale solar).
        hours_per_year: Default 8760.

    Returns:
        dict with capacity_mw and inputs echoed.
    """
    cap_mw = mwh / (hours_per_year * capacity_factor)
    return {"mwh_input": mwh, "capacity_factor": capacity_factor,
            "capacity_mw": cap_mw}


@mcp.tool()
def solar_capacity_to_area(capacity_mw: float,
                           power_density_mw_per_ha: float = 0.45) -> dict:
    """Convert solar nameplate capacity (MW) to land-area requirement (ha).

    Area_ha = Capacity_MW / power_density_MW_per_ha.

    Args:
        capacity_mw: Required nameplate solar capacity in MW.
        power_density_mw_per_ha: Median MWac/ha (default 0.45).

    Returns:
        dict with area_ha and area_acres.
    """
    area_ha = capacity_mw / power_density_mw_per_ha
    area_acres = area_ha / 0.40468564
    return {"capacity_mw": capacity_mw,
            "power_density_mw_per_ha": power_density_mw_per_ha,
            "area_ha": area_ha, "area_acres": area_acres}


@mcp.tool()
def land_use_efficiency_ratio(corn_ethanol_area_ha: float,
                              equivalent_solar_area_ha: float) -> dict:
    """Ratio of corn-ethanol land use to solar land use for the same energy.

    Args:
        corn_ethanol_area_ha: Hectares of corn-ethanol cropland (numerator).
        equivalent_solar_area_ha: Hectares of solar to match the same
            energy (denominator).

    Returns:
        dict with ratio and percent of corn-ethanol footprint.
    """
    ratio = corn_ethanol_area_ha / equivalent_solar_area_ha
    pct = 100.0 * equivalent_solar_area_ha / corn_ethanol_area_ha
    return {"corn_ethanol_ha": corn_ethanol_area_ha,
            "solar_equivalent_ha": equivalent_solar_area_ha,
            "land_use_ratio": ratio,
            "solar_share_of_corn_footprint_pct": pct}


@mcp.tool()
def conversion_fraction(equivalent_solar_area_ha: float,
                        corn_ethanol_area_ha: float) -> dict:
    """Fraction of the corn-ethanol footprint that must be converted to solar.

    conversion_fraction (%) = 100 * equivalent_solar_area_ha / corn_ethanol_area_ha.
    This is the small targeted-conversion share; it is derived here from the
    two land areas, never read from an input table.

    Args:
        equivalent_solar_area_ha: Solar hectares needed for energy parity.
        corn_ethanol_area_ha: Current corn-ethanol cropland footprint (ha).

    Returns:
        dict with conversion_fraction_pct.
    """
    frac = 100.0 * equivalent_solar_area_ha / corn_ethanol_area_ha
    return {"equivalent_solar_area_ha": equivalent_solar_area_ha,
            "corn_ethanol_area_ha": corn_ethanol_area_ha,
            "conversion_fraction_pct": frac}


@mcp.tool()
def national_solar_share_uplift(added_solar_generation_mwh: float,
                                total_generation_twh: float,
                                baseline_solar_share_pct: float) -> dict:
    """Post-conversion national solar generation share.

    Adds the energy generated by the converted-cropland solar to the existing
    solar share: new_share = baseline_solar_share + 100 * added_TWh / total_TWh.
    All inputs are raw quantities (baseline share, total national generation)
    or computed upstream (added generation); the post-conversion share is
    derived here, not read from any input table.

    Args:
        added_solar_generation_mwh: Annual solar generation added by the
            converted cropland (MWh).
        total_generation_twh: National total annual net generation (TWh).
        baseline_solar_share_pct: Current national solar share (percent).

    Returns:
        dict with added_share_pct and new_solar_share_pct.
    """
    added_twh = added_solar_generation_mwh / 1_000_000.0
    added_share = 100.0 * added_twh / total_generation_twh
    new_share = baseline_solar_share_pct + added_share
    return {"added_generation_twh": added_twh,
            "added_share_pct": added_share,
            "baseline_solar_share_pct": baseline_solar_share_pct,
            "new_solar_share_pct": new_share}


# ---------------------------------------------------------------------------
# Niche / suitability scoring
# ---------------------------------------------------------------------------
@mcp.tool()
def threshold_screen(values: list, thresholds: dict) -> dict:
    """Apply multi-threshold filtering to a list of numeric values.

    Args:
        values: List of numeric scores.
        thresholds: dict with keys 'low', 'mid', 'high' (each numeric);
            classify each value as below_low, low_mid, mid_high, or above_high.

    Returns:
        dict with counts and percentages per class.
    """
    arr = np.array(values, dtype=float)
    arr = arr[~np.isnan(arr)]
    lo, mid, hi = thresholds["low"], thresholds["mid"], thresholds["high"]
    classes = {
        f"below_{lo}": int((arr < lo).sum()),
        f"{lo}_to_{mid}": int(((arr >= lo) & (arr < mid)).sum()),
        f"{mid}_to_{hi}": int(((arr >= mid) & (arr < hi)).sum()),
        f"above_{hi}": int((arr >= hi).sum()),
    }
    n = len(arr)
    pct = {k: round(100.0 * v / n, 2) if n else 0.0 for k, v in classes.items()}
    return {"counts": classes, "percentages": pct, "n": n,
            "thresholds": thresholds}


@mcp.tool()
def weighted_suitability_score(features: list, weights: dict,
                               normalize: bool = True) -> dict:
    """Compute a weighted multi-criteria suitability score per site.

    Args:
        features: List of dicts, one per site, each containing the keys
            named in 'weights'.
        weights: dict mapping feature name -> weight (will be normalized
            if normalize=True).
        normalize: If True, min-max scale each feature to [0,1] before
            applying weights.  Negative weights are allowed (lower is
            better for that feature).

    Returns:
        dict with per-site scores, ranks, and the normalized weights used.
    """
    if not features:
        return {"error": "empty feature list"}
    feat_names = list(weights.keys())
    arr = np.array([[float(f.get(k, 0) or 0) for k in feat_names]
                    for f in features], dtype=float)
    if normalize:
        mins = arr.min(axis=0)
        maxs = arr.max(axis=0)
        rng = np.where(maxs - mins > 0, maxs - mins, 1.0)
        arr = (arr - mins) / rng
    w = np.array([weights[k] for k in feat_names], dtype=float)
    if abs(w.sum()) > 1e-9:
        w_norm = w / np.abs(w).sum()
    else:
        w_norm = w
    scores = arr @ w_norm
    order = np.argsort(-scores)
    ranked = [
        {"index": int(i), "score": round(float(scores[i]), 4),
         "rank": int(r + 1)}
        for r, i in enumerate(order)
    ]
    return {"weights_normalized": {k: round(float(v), 4)
                                   for k, v in zip(feat_names, w_norm)},
            "ranked_sites": ranked,
            "n_sites": len(features),
            "score_min": round(float(scores.min()), 4),
            "score_max": round(float(scores.max()), 4),
            "score_mean": round(float(scores.mean()), 4)}


@mcp.tool()
def haversine_buffer_filter(point_lat: float, point_lon: float,
                            target_lats: list, target_lons: list,
                            max_distance_km: float) -> dict:
    """Identify which target points fall within a buffer around a point.

    Implements a vectorized haversine great-circle distance.

    Args:
        point_lat: Center latitude (degrees).
        point_lon: Center longitude (degrees).
        target_lats: List of target latitudes.
        target_lons: List of target longitudes.
        max_distance_km: Buffer radius (km).

    Returns:
        dict with indices_in_buffer, distances_km, and counts.
    """
    R = 6371.0
    p1 = np.radians(float(point_lat))
    p2 = np.radians(np.array(target_lats, dtype=float))
    dl = np.radians(np.array(target_lons, dtype=float) - float(point_lon))
    dp = p2 - p1
    a = np.sin(dp / 2) ** 2 + np.cos(p1) * np.cos(p2) * np.sin(dl / 2) ** 2
    d = 2 * R * np.arcsin(np.sqrt(a))
    in_buf = np.where(d <= max_distance_km)[0]
    return {"indices_in_buffer": in_buf.tolist(),
            "distances_km": [round(float(d[i]), 3) for i in in_buf],
            "n_in_buffer": int(len(in_buf)),
            "n_total": int(len(d)),
            "fraction_in_buffer": round(float(len(in_buf) / max(1, len(d))), 4),
            "max_distance_km": float(max_distance_km)}


# ---------------------------------------------------------------------------
# Statistical analysis
# ---------------------------------------------------------------------------
@mcp.tool()
def linear_regression(x_values: list, y_values: list) -> dict:
    """OLS linear regression with slope, intercept, R^2, and p-value.

    Args:
        x_values: Independent variable.
        y_values: Dependent variable.

    Returns:
        dict with slope, intercept, r_squared, p_value, and n.
    """
    from scipy.stats import linregress
    x = np.array(x_values, dtype=float)
    y = np.array(y_values, dtype=float)
    mask = ~(np.isnan(x) | np.isnan(y))
    x, y = x[mask], y[mask]
    res = linregress(x, y)
    return {"slope": round(float(res.slope), 6),
            "intercept": round(float(res.intercept), 4),
            "r_squared": round(float(res.rvalue ** 2), 4),
            "p_value": round(float(res.pvalue), 6),
            "stderr": round(float(res.stderr), 6),
            "n": int(len(x))}


@mcp.tool()
def kmeans_cluster(features: list, n_clusters: int = 3,
                   random_state: int = 0) -> dict:
    """Cluster sites into k groups using k-means.

    Args:
        features: List of dicts (each with the same numeric keys).
        n_clusters: Number of clusters (default 3).
        random_state: RNG seed.

    Returns:
        dict with cluster labels, cluster centers, and inertia.
    """
    from sklearn.cluster import KMeans
    if not features:
        return {"error": "empty features"}
    keys = [k for k in features[0].keys()]
    arr = np.array([[float(f.get(k, 0) or 0) for k in keys] for f in features],
                   dtype=float)
    km = KMeans(n_clusters=n_clusters, random_state=random_state, n_init=10)
    labels = km.fit_predict(arr)
    return {"feature_names": keys,
            "labels": labels.tolist(),
            "centers": km.cluster_centers_.tolist(),
            "inertia": float(km.inertia_),
            "n_clusters": int(n_clusters),
            "n_samples": int(len(features))}


@mcp.tool()
def logistic_classifier(features: list, target_key: str,
                        feature_keys: list) -> dict:
    """Fit a logistic regression to predict a binary target from features.

    Args:
        features: List of dicts with feature columns and the binary target.
        target_key: Name of the binary target column in features.
        feature_keys: List of feature column names to use as predictors.

    Returns:
        dict with coefficients, intercept, accuracy, and predicted classes.
    """
    from sklearn.linear_model import LogisticRegression
    X, y = [], []
    for f in features:
        try:
            row = [float(f.get(k, 0) or 0) for k in feature_keys]
            t = f.get(target_key)
            if isinstance(t, str):
                t = t.lower() in {"true", "1", "yes"}
            y.append(int(bool(t)))
            X.append(row)
        except (TypeError, ValueError):
            continue
    X = np.array(X, dtype=float)
    y = np.array(y, dtype=int)
    if len(set(y)) < 2:
        return {"error": "target has fewer than 2 classes",
                "n_positive": int(y.sum()), "n": int(len(y))}
    clf = LogisticRegression(max_iter=1000)
    clf.fit(X, y)
    pred = clf.predict(X)
    acc = float((pred == y).mean())
    return {"coefficients": dict(zip(feature_keys,
                                     [round(float(c), 4) for c in clf.coef_[0]])),
            "intercept": round(float(clf.intercept_[0]), 4),
            "accuracy": round(acc, 4),
            "n_positive": int(y.sum()),
            "n_samples": int(len(y)),
            "predictions": pred.tolist()}


@mcp.tool()
def aggregate_by_state(csv_path: str, state_col: str = "state",
                       value_col: str = "capacity_mmgal_yr",
                       agg: str = "sum") -> dict:
    """Group rows by a state column and aggregate a value column.

    Args:
        csv_path: Path to a CSV file.
        state_col: Name of the column to group by (default 'state').
        value_col: Name of the value column to aggregate.
        agg: One of 'sum', 'mean', 'count', 'max', 'min'.

    Returns:
        dict with per-state aggregated value and rank.
    """
    by: dict[str, list[float]] = {}
    with open(csv_path, newline="") as f:
        for r in csv.DictReader(f):
            st = r.get(state_col, "")
            try:
                v = float(r[value_col])
            except (KeyError, ValueError, TypeError):
                continue
            by.setdefault(st, []).append(v)
    funcs = {"sum": float, "mean": float, "count": int, "max": float, "min": float}
    if agg not in funcs:
        return {"error": f"unknown agg {agg}"}
    out: dict[str, float] = {}
    for st, vs in by.items():
        if agg == "sum":
            out[st] = float(sum(vs))
        elif agg == "mean":
            out[st] = float(np.mean(vs))
        elif agg == "count":
            out[st] = int(len(vs))
        elif agg == "max":
            out[st] = float(max(vs))
        elif agg == "min":
            out[st] = float(min(vs))
    ranked = sorted(out.items(), key=lambda kv: -kv[1])
    return {"agg": agg, "value_col": value_col,
            "n_states": len(out),
            "results": {k: round(float(v), 3) for k, v in out.items()},
            "ranked": [{"state": k, "value": round(float(v), 3)}
                       for k, v in ranked]}


# ---------------------------------------------------------------------------
# Plotting tools (one per image-answer)
# ---------------------------------------------------------------------------
@mcp.tool()
def plot_corn_solar_landuse(harvest_csv: str,
                            corn_ethanol_area_ha: float,
                            solar_equivalent_area_ha: float,
                            output_path: str = "artifacts/Fig1_corn_solar_landuse.png"
                            ) -> dict:
    """Render the corn-ethanol vs solar land-use figure from PRE-COMPUTED areas.

    This is a pure rendering tool: the corn-ethanol footprint and the
    energy-equivalent solar area must be computed upstream (e.g. via
    ethanol_gallons_to_mwh -> mwh_to_solar_capacity -> solar_capacity_to_area)
    and passed in. The tool does not recompute or read the headline land-use
    numbers itself; it only draws the supplied areas plus the corn-harvest
    time series.

    Args:
        harvest_csv: Path to us_corn_harvest_1980_2022.csv (time-series panel).
        corn_ethanol_area_ha: Pre-computed 2022 corn-ethanol footprint (ha).
        solar_equivalent_area_ha: Pre-computed energy-equivalent solar area (ha).
        output_path: Output PNG path (relative to cwd).

    Returns:
        dict with output_path (rendering metadata only).
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    years, hect = [], []
    with open(harvest_csv, newline="") as f:
        for r in csv.DictReader(f):
            years.append(int(r["year"]))
            hect.append(float(r["harvest_hectares"]))

    corn_ha = float(corn_ethanol_area_ha)
    solar_ha = float(solar_equivalent_area_ha)
    ratio = corn_ha / solar_ha if solar_ha else float("nan")

    fig, axes = plt.subplots(1, 2, figsize=(11, 4.4))
    ax = axes[0]
    bars = ax.bar(["Corn for ethanol\n(2022)",
                   "Equivalent\nutility-scale solar"],
                  [corn_ha / 1e6, solar_ha / 1e6],
                  color=["#3a7d44", "#fcb53b"], edgecolor="black")
    ax.set_ylabel("Land area (million ha)")
    ax.set_title(f"Land-use ratio = {ratio:.0f}x")
    for b, v in zip(bars, [corn_ha / 1e6, solar_ha / 1e6]):
        ax.text(b.get_x() + b.get_width() / 2, v + 0.2, f"{v:.2f} M ha",
                ha="center")
    ax.set_ylim(0, max(corn_ha, solar_ha) / 1e6 * 1.2)
    ax.grid(axis="y", alpha=0.3)

    ax = axes[1]
    ax.plot(years, np.array(hect) / 1e6, color="#3a7d44", linewidth=2)
    ax.set_xlabel("Year")
    ax.set_ylabel("Corn harvest area (million ha)")
    ax.set_title("US corn grain harvest 1980-2022")
    ax.grid(alpha=0.3)

    fig.suptitle("Energy-equivalent corn-ethanol vs utility-scale solar land use",
                 y=1.02)
    plt.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"output_path": output_path,
            "n_years_plotted": len(years),
            "rendered_corn_area_ha": corn_ha,
            "rendered_solar_area_ha": solar_ha}


@mcp.tool()
def state_decarb_contributions(coloc_csv: str, params_csv: str) -> dict:
    """Derive per-state decarbonization contribution from raw colocation area.

    For each state with nonzero colocation hectares, converts the raw area to
    nameplate solar capacity (MWac/ha) and annual generation
    (capacity_factor * hours_per_year), then expresses it as a percentage of
    the 2050 national decarbonization target (TWh). Only the raw colocation
    hectares are read from the input CSV; the contribution is computed here.

    Args:
        coloc_csv: Path to state_corn_ethanol_wind_colocation.csv
            (columns: state, colocation_ha).
        params_csv: Path to energy_conversion_parameters.csv (supplies
            solar_power_density_median, solar_capacity_factor_avg,
            hours_per_year, decarb_2050_target_twh).

    Returns:
        dict with per-state rows (state, colocation_ha, decarb_pct), ranked by
        area, plus the portfolio totals.
    """
    params = {}
    with open(params_csv, newline="") as f:
        for r in csv.DictReader(f):
            params[r["parameter"]] = float(r["value"])
    power_density = params.get("solar_power_density_median", 0.45)   # MWac/ha
    capacity_factor = params.get("solar_capacity_factor_avg", 0.247)
    target_twh = params.get("decarb_2050_target_twh", 5340.0)
    hours = params.get("hours_per_year", 8760.0)

    def decarb_pct(ha_value: float) -> float:
        cap_mw = ha_value * power_density
        gen_twh = cap_mw * hours * capacity_factor / 1e6
        return 100.0 * gen_twh / target_twh

    rows = []
    with open(coloc_csv, newline="") as f:
        for r in csv.DictReader(f):
            ha_value = float(r["colocation_ha"])
            if ha_value > 0:
                rows.append({"state": r["state"],
                             "colocation_ha": ha_value,
                             "decarb_pct": decarb_pct(ha_value)})
    rows.sort(key=lambda d: -d["colocation_ha"])
    return {"states": rows,
            "n_states": len(rows),
            "total_colocation_ha": sum(d["colocation_ha"] for d in rows),
            "total_decarb_pct": sum(d["decarb_pct"] for d in rows)}


@mcp.tool()
def plot_state_suitability_ranking(state_contributions: list,
                                   output_path: str = "artifacts/Fig3_state_ranking.png"
                                   ) -> dict:
    """Render the state-level colocation ranking from PRE-COMPUTED contributions.

    Pure rendering tool: the per-state colocation area and decarbonization
    contribution must be computed upstream by state_decarb_contributions and
    passed in. This tool does not read the colocation CSV or recompute the
    contribution; it only draws the supplied values.

    Args:
        state_contributions: list of dicts
            {"state": str, "colocation_ha": float, "decarb_pct": float}
            (e.g. the "states" list returned by state_decarb_contributions).
        output_path: Output PNG path.

    Returns:
        dict with output_path (rendering metadata only).
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    rows = [d for d in state_contributions
            if float(d.get("colocation_ha", 0) or 0) > 0]
    rows.sort(key=lambda d: -float(d["colocation_ha"]))
    states = [d["state"] for d in rows]
    ha = [float(d["colocation_ha"]) / 1000 for d in rows]
    pct = [float(d["decarb_pct"]) for d in rows]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.2))
    ax1.barh(states, ha, color="#3a7d44", edgecolor="black")
    ax1.invert_yaxis()
    ax1.set_xlabel("Corn-ethanol + wind colocation area (1000 ha)")
    ax1.set_title("State-level high-suitability area")
    ax1.grid(axis="x", alpha=0.3)
    for i, v in enumerate(ha):
        ax1.text(v + 5, i, f"{v:.0f}", va="center")

    ax2.barh(states, pct, color="#fcb53b", edgecolor="black")
    ax2.invert_yaxis()
    ax2.set_xlabel("Contribution to 2050 decarbonization goal (%)")
    ax2.set_title("Per-state decarbonization contribution")
    ax2.grid(axis="x", alpha=0.3)
    for i, v in enumerate(pct):
        ax2.text(v + 0.1, i, f"{v:.1f}%", va="center")

    plt.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"output_path": output_path,
            "n_states_plotted": len(states),
            "states_plotted": states}


@mcp.tool()
def plot_state_yield_trends(yield_csv: str,
                            output_path: str = "artifacts/Fig4_yield_trends.png"
                            ) -> dict:
    """Render per-state corn yield trends 1980-2022.

    Args:
        yield_csv: Path to state_corn_yield_1980_2022.csv.
        output_path: Output PNG path.

    Returns:
        dict with output_path and per-state slopes (BU/acre/yr).
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from scipy.stats import linregress

    by_state: dict[str, list[tuple[int, float]]] = {}
    with open(yield_csv, newline="") as f:
        for r in csv.DictReader(f):
            by_state.setdefault(r["state"], []).append(
                (int(r["year"]), float(r["yield_bu_per_acre"]))
            )

    fig, ax = plt.subplots(figsize=(9, 5))
    slopes = {}
    for st in sorted(by_state):
        pts = sorted(by_state[st])
        ys = [p[0] for p in pts]
        vs = [p[1] for p in pts]
        ax.plot(ys, vs, marker=".", linewidth=1, alpha=0.7, label=st)
        s = linregress(ys, vs)
        slopes[st] = round(float(s.slope), 3)
    ax.set_xlabel("Year")
    ax.set_ylabel("Corn yield (bushels per acre)")
    ax.set_title("Per-state corn yield 1980-2022 (top 10 corn states)")
    ax.legend(fontsize=8, ncol=2)
    ax.grid(alpha=0.3)

    plt.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"output_path": output_path,
            "per_state_slope_bu_per_yr": slopes,
            "n_states": len(slopes)}


if __name__ == "__main__":
    mcp.run(transport="stdio")

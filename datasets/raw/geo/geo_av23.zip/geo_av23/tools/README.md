# geo_av23 — Tool Reference

## Dependencies

```
python>=3.10
numpy
scipy
scikit-learn
matplotlib
openpyxl
mcp[cli]   # FastMCP server framework
```

Install: `pip install numpy scipy scikit-learn matplotlib openpyxl "mcp[cli]"`

## Database Retrieval (`database_retrieval.py`)

Generic external-database access primitives.

- **websearch** — generic web search.
- **fetch_url** — HTTP GET (handles redirects).
- **query_doi** — DOI -> Crossref + open-access URL.
- **query_openalex** — OpenAlex works/authors search.
- **query_world_bank** — World Bank WDI indicator series.
- **query_ncbi_entrez** — Generic Entrez E-search + E-fetch.

(Same primitive list as the other 2026-04 task packages.)

## Data Processing (`data_processing.py`)

- **read_csv / write_csv** — CSV I/O via csv.DictReader.
- **read_excel** — XLSX reader (openpyxl).
- **read_shapefile** — geopandas vector reader (optional).
- **pivot_long_to_wide / pivot_wide_to_long** — reshape tabular data.
- **drop_missing / coerce_numeric** — cleaning helpers.
- **join_tables / groupby_aggregate** — SQL-style joins and group ops.

## Domain-Specific Analysis (`agrivoltaics_analysis.py`)

Niche analysis primitives for evaluating agricultural-solar suitability.

### Loading
- **load_parameter_table** — load a parameter/value CSV into a dict with units and sources.
- **load_table** — generic CSV -> list-of-dicts loader with column summary.

### Energy unit conversions
- **ethanol_gallons_to_mwh** — convert ethanol volume (gal) to electricity-equivalent MWh / TWh / Btu.
- **mwh_to_solar_capacity** — convert annual MWh -> nameplate MW capacity using a capacity factor.
- **solar_capacity_to_area** — convert MW capacity -> land area (ha) using a power density (MWac/ha).
- **land_use_efficiency_ratio** — corn-ethanol ha vs solar-equivalent ha; reports the fold ratio.
- **conversion_fraction** — derive the % of the corn-ethanol footprint that must be converted to solar (solar ha / corn ha). The input parameter table does NOT contain this value; it is computed here.
- **national_solar_share_uplift** — derive the post-conversion national solar generation share from the added solar generation, the raw 2022 total US generation (TWh), and the raw 2022 baseline solar share. The post-conversion share is NOT supplied in the inputs; it is computed here.
- **state_decarb_contributions** — derive per-state decarbonization contribution (%) from the raw colocation hectares + energy parameters; ranks states by area.

### Niche / suitability scoring
- **threshold_screen** — multi-threshold (low/mid/high) classifier of numeric scores.
- **weighted_suitability_score** — weighted-sum multi-criteria scoring with min-max normalization.
- **haversine_buffer_filter** — vectorized great-circle distance for proximity buffers (refinery-to-cropland, transmission, etc.).

### Statistical analysis
- **linear_regression** — OLS slope, intercept, R², p-value.
- **kmeans_cluster** — k-means clustering on multi-feature site tables.
- **logistic_classifier** — logistic regression to predict a binary niche label.
- **aggregate_by_state** — group rows by a state column, sum/mean/count/max/min on a value column.

### Plotting (one tool per image answer)
- **plot_corn_solar_landuse** — Fig1: corn-ethanol vs equivalent-solar bar comparison + harvest time series. Takes the **pre-computed** corn-ethanol footprint (ha) and energy-equivalent solar area (ha) as arguments; it renders them and does not recompute or return the headline land-use numbers.
- **plot_state_suitability_ranking** — Fig3: per-state colocation ha + decarbonization-contribution horizontal bars. Takes the **pre-computed** per-state contribution list (from `state_decarb_contributions`); it renders the supplied values and does not recompute them.
- **plot_state_yield_trends** — supplementary: per-state corn yield trends 1980-2022 (top 10 states).

The plotting tools are pure renderers: they consume results produced by the analytical primitives and return only rendering metadata (output path, what was plotted), not the headline conclusions. Chain the conversion / derivation tools first, then pass their outputs into the plot tools.

## Suggested pipeline

1. `load_parameter_table(energy_conversion_parameters.csv)`.
2. `ethanol_gallons_to_mwh(gallons)` → `mwh_to_solar_capacity(mwh)` → `solar_capacity_to_area(capacity_mw)` → equivalent solar ha.
3. `land_use_efficiency_ratio(corn_ha, solar_ha)` and `conversion_fraction(solar_ha, corn_ha)`.
4. `national_solar_share_uplift(added_solar_mwh, total_generation_twh, baseline_solar_share_pct)`.
5. `state_decarb_contributions(coloc_csv, params_csv)` for the per-state niche.
6. `plot_corn_solar_landuse(...)` and `plot_state_suitability_ranking(...)` to render the figures from the computed values.

#!/usr/bin/env python3
"""
Seismicity analysis primitives.

Low-level, domain-agnostic numerical functions for analysing earthquake
catalogues: magnitude-completeness estimation, Gutenberg-Richter b-value,
modified Omori law fitting, ETAS log-likelihood, spatial distance, surrogate
counts, percentile / quantile tests, and helpers for plotting.

All functions are exposed as FastMCP tools.
"""

from __future__ import annotations

import math
import os
import json
from typing import List, Tuple, Dict, Optional

import numpy as np
import pandas as pd
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Seismicity_Analysis_Tools")

R_EARTH_KM = 6371.0088


def _parse_user_time(iso: str) -> pd.Timestamp:
    """Parse a user-supplied ISO time string to a UTC-aware Timestamp.

    Uses ``pd.to_datetime(..., utc=True)`` so that strings carrying an
    explicit ``Z`` / ``+00:00`` offset (as in the bundled USGS CSV, e.g.
    ``2011-03-11T05:46:24.000Z``) parse correctly. ``pd.Timestamp(s, tz=...)``
    raises on tz-aware input, so it must not be used for user time strings.
    """
    return pd.to_datetime(iso, utc=True)


# ---------------------------------------------------------------------------
# IO
# ---------------------------------------------------------------------------
def _load_earthquake_catalog(csv_path: str, min_magnitude: float) -> pd.DataFrame:
    """Read a USGS CSV, drop non-seismic records, and apply the magnitude
    filter. The raw USGS FDSN export mixes tectonic earthquakes with
    `nuclear explosion`, `volcanic eruption`, `explosion`, `rock burst`, and
    `mine collapse` rows; only ``type == "earthquake"`` rows belong in the
    seismicity statistics, so they are removed here. All catalog-reading tools
    route through this helper to keep the caliber consistent.
    """
    df = pd.read_csv(csv_path)
    df["time"] = pd.to_datetime(df["time"], utc=True, errors="coerce")
    df = df.dropna(subset=["time", "mag", "latitude", "longitude"])
    if "type" in df.columns:
        df = df[df["type"].astype(str).str.lower() == "earthquake"]
    df = df[df["mag"] >= float(min_magnitude)]
    return df


@mcp.tool()
def load_usgs_catalog(csv_path: str, min_magnitude: float = 5.1,
                      start_iso: str = None, end_iso: str = None) -> dict:
    """Load a USGS-format earthquake catalog CSV.

    Non-earthquake records (``type`` in {nuclear explosion, volcanic eruption,
    explosion, rock burst, mine collapse}) are dropped before any statistics
    are computed; only tectonic earthquakes are retained.

    Args:
        csv_path: path to USGS CSV (columns include time, latitude, longitude,
                  depth, mag, type, ...)
        min_magnitude: minimum magnitude filter (paper uses 5.1)
        start_iso: optional ISO start datetime (inclusive)
        end_iso: optional ISO end datetime (inclusive)

    Returns:
        dict with columns, total_rows, and sample rows (first 50).
    """
    df = _load_earthquake_catalog(csv_path, min_magnitude)
    if start_iso:
        df = df[df["time"] >= _parse_user_time(start_iso)]
    if end_iso:
        df = df[df["time"] <= _parse_user_time(end_iso)]
    df = df.sort_values("time").reset_index(drop=True)
    rows = df.head(50).to_dict("records")
    for r in rows:
        r["time"] = str(r["time"])
    return {
        "columns": list(df.columns),
        "total_rows": int(len(df)),
        "rows": rows,
        "min_mag": float(df["mag"].min()),
        "max_mag": float(df["mag"].max()),
    }


# ---------------------------------------------------------------------------
# Distance & spatial
# ---------------------------------------------------------------------------
@mcp.tool()
def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Great-circle distance between two lat/lon points in kilometres."""
    p1 = math.radians(lat1)
    p2 = math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlmb = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dlmb / 2) ** 2
    c = 2 * math.asin(min(1.0, math.sqrt(a)))
    return R_EARTH_KM * c


@mcp.tool()
def distances_from_event(catalog_csv: str, ref_lat: float, ref_lon: float,
                         out_csv: str = None, min_magnitude: float = 5.1) -> dict:
    """Compute great-circle distance (km) of every event in a catalog from a
    reference point. Optionally writes (time, mag, distance_km) to a CSV.

    The catalog is read through the shared ``_load_earthquake_catalog`` helper,
    so non-earthquake records (nuclear explosion, volcanic eruption, etc.) are
    dropped and the ``min_magnitude`` filter is applied first, keeping the row
    set consistent with every other catalog-reading tool.
    """
    df = _load_earthquake_catalog(catalog_csv, min_magnitude)
    lat = df["latitude"].to_numpy()
    lon = df["longitude"].to_numpy()
    p1 = np.radians(ref_lat)
    p2 = np.radians(lat)
    dphi = np.radians(lat - ref_lat)
    dlmb = np.radians(lon - ref_lon)
    a = np.sin(dphi / 2) ** 2 + np.cos(p1) * np.cos(p2) * np.sin(dlmb / 2) ** 2
    c = 2 * np.arcsin(np.clip(np.sqrt(a), 0, 1))
    dist = R_EARTH_KM * c
    df = df.assign(distance_km=dist)
    if out_csv:
        out_df = df[["time", "mag", "latitude", "longitude", "distance_km"]].copy()
        out_df["time"] = out_df["time"].astype(str)
        out_df.to_csv(out_csv, index=False)
    return {
        "n": int(len(df)),
        "min_km": float(dist.min()),
        "max_km": float(dist.max()),
        "median_km": float(np.median(dist)),
        "out_csv": out_csv,
    }


# ---------------------------------------------------------------------------
# Magnitude of completeness & Gutenberg-Richter b-value
# ---------------------------------------------------------------------------
@mcp.tool()
def estimate_mc_maxc(magnitudes: list, bin_width: float = 0.1) -> dict:
    """Maximum-curvature Mc estimator (Wiemer & Wyss 2000).

    Returns Mc as the magnitude bin with the maximum non-cumulative count.
    Conservative: many studies add +0.2.
    """
    m = np.asarray(magnitudes, dtype=float)
    if m.size == 0:
        return {"Mc": None, "n": 0}
    edges = np.arange(np.floor(m.min() * 10) / 10,
                      np.ceil(m.max() * 10) / 10 + bin_width,
                      bin_width)
    counts, _ = np.histogram(m, bins=edges)
    centers = edges[:-1] + bin_width / 2
    Mc = float(centers[int(np.argmax(counts))])
    return {"Mc": Mc, "n": int(m.size), "bin_width": bin_width}


@mcp.tool()
def gutenberg_richter_bvalue(magnitudes: list, mc: float = None,
                             bin_width: float = 0.1) -> dict:
    """Aki (1965) maximum-likelihood Gutenberg-Richter b-value above Mc.

    b = log10(e) / (mean(M) - (Mc - bin_width/2))

    Args:
        magnitudes: list of magnitudes
        mc: completeness threshold; if None, estimated by max-curvature
        bin_width: catalog magnitude bin width
    Returns:
        dict with b, b_uncert, a, mc, n
    """
    m = np.asarray(magnitudes, dtype=float)
    if mc is None:
        mc = estimate_mc_maxc(magnitudes, bin_width)["Mc"]
    above = m[m >= mc - 1e-9]
    n = int(above.size)
    if n < 2:
        return {"b": None, "b_uncert": None, "n": n, "mc": mc}
    mean_m = float(above.mean())
    b = math.log10(math.e) / (mean_m - (mc - bin_width / 2))
    # Shi & Bolt 1982 uncertainty
    var = np.sum((above - mean_m) ** 2) / (n * (n - 1))
    b_unc = 2.30 * (b ** 2) * math.sqrt(var)
    a = math.log10(n) + b * mc
    return {"b": float(b), "b_uncert": float(b_unc), "a": float(a),
            "mc": float(mc), "n": n}


# ---------------------------------------------------------------------------
# Modified Omori law (aftershock decay)
# ---------------------------------------------------------------------------
@mcp.tool()
def fit_modified_omori(times_days: list, t_min: float = 0.0,
                       t_max: float = None) -> dict:
    """MLE fit of the modified Omori law n(t) = K / (t + c)^p
    to a sequence of aftershock occurrence times (days since mainshock).

    Uses scipy.optimize.differential_evolution (multi-modal landscape).

    Args:
        times_days: list of post-mainshock event times in days (>0)
        t_min: lower truncation (days; default 0)
        t_max: upper truncation (days; default = max(times)+1)
    Returns:
        dict with K, c, p, log_likelihood, n
    """
    from scipy.optimize import differential_evolution

    t = np.asarray([x for x in times_days if x > t_min], dtype=float)
    if t.size < 5:
        return {"K": None, "c": None, "p": None, "n": int(t.size)}
    if t_max is None:
        t_max = float(t.max()) + 1.0

    def neg_log_lik(params):
        log_K, log_c, p = params
        K = math.exp(log_K)
        c = math.exp(log_c)
        if p <= 0 or K <= 0 or c <= 0:
            return 1e12
        # integrated rate
        if abs(p - 1) < 1e-6:
            integ = K * (math.log(t_max + c) - math.log(t_min + c))
        else:
            integ = K * (((t_max + c) ** (1 - p)) - ((t_min + c) ** (1 - p))) / (1 - p)
        if integ <= 0:
            return 1e12
        ll = float(np.sum(np.log(K) - p * np.log(t + c))) - integ
        return -ll

    bounds = [(-5, 8), (-8, 3), (0.3, 3.0)]
    res = differential_evolution(neg_log_lik, bounds, seed=42,
                                 maxiter=200, popsize=20, tol=1e-7)
    log_K, log_c, p = res.x
    return {
        "K": float(math.exp(log_K)),
        "c": float(math.exp(log_c)),
        "p": float(p),
        "log_likelihood": float(-res.fun),
        "n": int(t.size),
        "t_min": t_min,
        "t_max": t_max,
    }


# ---------------------------------------------------------------------------
# Activity rate change / quiescence
# ---------------------------------------------------------------------------
@mcp.tool()
def count_in_window(catalog_csv: str, ref_lat: float, ref_lon: float,
                    ref_time_iso: str, T_days: float = 5.0,
                    R_km: float = 500.0, R_max_km: float = None,
                    min_mag: float = 5.1,
                    exclude_same_event_seconds: float = 60.0) -> dict:
    """Count events within T days of a reference time and beyond (or within)
    a distance R_km of a reference epicenter.

    Args:
        catalog_csv: USGS CSV
        ref_lat, ref_lon: reference epicenter
        ref_time_iso: reference time (ISO string)
        T_days: temporal window in days (post-event only)
        R_km: lower distance bound (km). Events with d > R_km are counted by default.
        R_max_km: upper distance bound (km). If set, count R_km < d <= R_max_km.
        min_mag: minimum magnitude filter
        exclude_same_event_seconds: drop events within this many seconds of
            ref_time_iso to avoid counting the mainshock itself.

    Returns:
        dict with n_events and selected event list (first 200).
    """
    df = _load_earthquake_catalog(catalog_csv, min_mag)
    t0 = _parse_user_time(ref_time_iso)
    dt = (df["time"] - t0).dt.total_seconds()
    df = df[(dt > exclude_same_event_seconds) & (dt <= T_days * 86400.0)]
    p1 = np.radians(ref_lat)
    p2 = np.radians(df["latitude"].to_numpy())
    dphi = np.radians(df["latitude"].to_numpy() - ref_lat)
    dlmb = np.radians(df["longitude"].to_numpy() - ref_lon)
    a = np.sin(dphi / 2) ** 2 + np.cos(p1) * np.cos(p2) * np.sin(dlmb / 2) ** 2
    d = R_EARTH_KM * 2 * np.arcsin(np.clip(np.sqrt(a), 0, 1))
    df = df.assign(distance_km=d)
    if R_max_km is None:
        sel = df[df["distance_km"] > R_km]
    else:
        sel = df[(df["distance_km"] > R_km) & (df["distance_km"] <= R_max_km)]
    out_rows = sel.head(200).copy()
    out_rows["time"] = out_rows["time"].astype(str)
    return {
        "n_events": int(len(sel)),
        "T_days": T_days,
        "R_km": R_km,
        "R_max_km": R_max_km,
        "events": out_rows[["time", "latitude", "longitude", "mag", "distance_km"]].to_dict("records"),
    }


@mcp.tool()
def surrogate_count_distribution(catalog_csv: str, ref_lat: float,
                                 ref_lon: float, T_days: float = 5.0,
                                 R_km: float = 500.0, min_mag: float = 5.1,
                                 n_surr: int = 10000, seed: int = 42) -> dict:
    """Build the null PDF of n(T,R) by drawing n_surr random reference times
    uniformly from the catalog span, keeping the same epicenter / R / T.

    Returns the surrogate counts plus 10/50/90 percentiles. This is exactly
    the procedure described in the paper's Methods 'Significance test'.
    """
    df = _load_earthquake_catalog(catalog_csv, min_mag)
    df = df.sort_values("time").reset_index(drop=True)
    t_start = df["time"].iloc[0]
    t_end = df["time"].iloc[-1]
    span_s = (t_end - t_start).total_seconds() - T_days * 86400.0

    p1 = np.radians(ref_lat)
    lat = df["latitude"].to_numpy()
    lon = df["longitude"].to_numpy()
    p2 = np.radians(lat)
    dphi = np.radians(lat - ref_lat)
    dlmb = np.radians(lon - ref_lon)
    a = np.sin(dphi / 2) ** 2 + np.cos(p1) * np.cos(p2) * np.sin(dlmb / 2) ** 2
    d_all = R_EARTH_KM * 2 * np.arcsin(np.clip(np.sqrt(a), 0, 1))
    keep = d_all > R_km
    times_keep = df["time"][keep].to_numpy()

    rng = np.random.default_rng(seed)
    offsets = rng.uniform(0, span_s, size=int(n_surr))
    counts = np.empty(int(n_surr), dtype=int)
    times_keep_s = (pd.DatetimeIndex(times_keep).asi8 // 1_000_000_000).astype(float)
    t0_s = t_start.value // 1_000_000_000
    for i, off in enumerate(offsets):
        t_lo = t0_s + off
        t_hi = t_lo + T_days * 86400.0
        counts[i] = int(np.sum((times_keep_s > t_lo) & (times_keep_s <= t_hi)))
    p10, p50, p90 = np.percentile(counts, [10, 50, 90])
    return {
        "n_surrogates": int(n_surr),
        "T_days": T_days,
        "R_km": R_km,
        "p10": float(p10),
        "p50": float(p50),
        "p90": float(p90),
        "mean": float(counts.mean()),
        "std": float(counts.std()),
        "counts_sample": counts[:200].tolist(),
        "all_counts": counts.tolist(),
    }


@mcp.tool()
def percentile_of_count(observed_n: int, surrogate_counts: list) -> dict:
    """Empirical percentile of observed_n in the surrogate distribution
    (paper Table 1 'Percentile' column = fraction of surrogates strictly
    smaller than n, with the marginal /equal alternative also returned)."""
    arr = np.asarray(surrogate_counts, dtype=float)
    n = arr.size
    if n == 0:
        return {"percentile_strict": None, "percentile_with_equal": None,
                "n_surrogates": 0}
    p_lt = float(np.mean(arr < observed_n))
    p_le = float(np.mean(arr <= observed_n))
    return {
        "percentile_strict": p_lt,
        "percentile_with_equal": p_le,
        "below_10pct": bool(p_lt < 0.10),
        "above_90pct": bool(p_lt > 0.90),
        "n_surrogates": int(n),
    }


# ---------------------------------------------------------------------------
# Ratio of significant events (paper's main statistic r = N_s / N_m)
# ---------------------------------------------------------------------------
@mcp.tool()
def reduced_increased_ratio(events_csv: str, catalog_csv: str,
                            T_days: float = 5.0, R_km: float = 500.0,
                            min_mag_quake: float = 7.5,
                            min_mag_catalog: float = 5.1,
                            n_surr: int = 10000,
                            seed: int = 42,
                            require_full_window: bool = True,
                            out_json: str = None) -> dict:
    """For every mega-earthquake in events_csv, compute the surrogate
    distribution of n(T,R) at its location and decide if the *real* count
    falls below the 10% quantile (reduced activity), above the 90% quantile
    (increased activity), or in between.

    Returns r_below = N_below / N_total and r_above = N_above / N_total
    (paper Eq. 'r = N_s / N_m' in 'The ratio of significant events').

    Observation-window completeness: a mainshock contributes a valid n(T,R)
    only if its full T-day post-mainshock window lies inside the catalog's
    time span (otherwise the observed count is truncated relative to the
    surrogate counts, which are always drawn from full-length T-day windows).
    With ``require_full_window=True`` (default) mainshocks whose window
    ``t_mainshock + T_days`` exceeds the catalog end time are EXCLUDED from
    the statistics, and the count of such excluded events is reported as
    ``n_excluded_window``. The surrogate reference times are likewise drawn
    only from offsets that leave a full T-day window before the catalog end
    (``span_s`` below), so observed and surrogate counts are on the same
    footing. Set ``require_full_window=False`` to score every mainshock
    regardless of truncation.

    Args:
        events_csv: USGS CSV restricted to mega-earthquakes (m >= min_mag_quake)
        catalog_csv: USGS CSV with all events m >= min_mag_catalog
        T_days, R_km: paper defaults T=5, R=500
        n_surr: number of surrogate draws per mega-event
        require_full_window: drop mainshocks whose T-day window runs past the
            catalog end time (default True)
        out_json: optional path to dump per-event results
    """
    ev = _load_earthquake_catalog(events_csv, min_mag_quake).reset_index(drop=True)

    cat = _load_earthquake_catalog(catalog_csv, min_mag_catalog)
    cat = cat.sort_values("time").reset_index(drop=True)
    t_start = cat["time"].iloc[0].value // 1_000_000_000
    t_end = cat["time"].iloc[-1].value // 1_000_000_000
    span_s = (t_end - t_start) - T_days * 86400.0
    cat_t_s = (pd.DatetimeIndex(cat["time"]).asi8 // 1_000_000_000).astype(float)
    cat_lat = cat["latitude"].to_numpy()
    cat_lon = cat["longitude"].to_numpy()

    rng = np.random.default_rng(seed)
    results = []
    n_below = 0
    n_above = 0
    n_total = 0
    n_excluded_window = 0
    for _, row in ev.iterrows():
        rlat = float(row["latitude"])
        rlon = float(row["longitude"])
        rmag = float(row["mag"])
        rtime = row["time"]
        rt_s = rtime.value // 1_000_000_000

        # Observation-window completeness: skip mainshocks whose full T-day
        # window extends past the catalog end (truncated observed count would
        # not be comparable to the full-window surrogate counts).
        if require_full_window and (rt_s + T_days * 86400.0 > t_end):
            n_excluded_window += 1
            results.append({
                "time": str(rtime), "lat": rlat, "lon": rlon, "mag": rmag,
                "n_obs": None, "p10": None, "p90": None,
                "below_10pct": False, "above_90pct": False,
                "excluded_incomplete_window": True,
            })
            continue

        p1 = math.radians(rlat)
        p2 = np.radians(cat_lat)
        dphi = np.radians(cat_lat - rlat)
        dlmb = np.radians(cat_lon - rlon)
        a = np.sin(dphi / 2) ** 2 + np.cos(p1) * np.cos(p2) * np.sin(dlmb / 2) ** 2
        d = R_EARTH_KM * 2 * np.arcsin(np.clip(np.sqrt(a), 0, 1))
        keep_far = d > R_km
        cat_far_t = cat_t_s[keep_far]

        # observed
        n_obs = int(np.sum((cat_far_t > rt_s + 60) &
                           (cat_far_t <= rt_s + T_days * 86400.0)))
        # surrogates
        offs = rng.uniform(0, span_s, size=int(n_surr))
        starts = t_start + offs
        # vectorised count via searchsorted
        sorted_t = np.sort(cat_far_t)
        lo = np.searchsorted(sorted_t, starts, side="right")
        hi = np.searchsorted(sorted_t, starts + T_days * 86400.0, side="right")
        surr = hi - lo
        p10 = np.percentile(surr, 10)
        p90 = np.percentile(surr, 90)
        below = bool(n_obs < p10)
        above = bool(n_obs > p90)
        if below:
            n_below += 1
        if above:
            n_above += 1
        n_total += 1
        results.append({
            "time": str(rtime),
            "lat": rlat,
            "lon": rlon,
            "mag": rmag,
            "n_obs": n_obs,
            "p10": float(p10),
            "p90": float(p90),
            "below_10pct": below,
            "above_90pct": above,
        })
    r_below = n_below / n_total if n_total else 0
    r_above = n_above / n_total if n_total else 0
    out = {
        "n_total_megaquakes": n_total,
        "n_excluded_window": n_excluded_window,
        "n_below_10pct": n_below,
        "n_above_90pct": n_above,
        "r_below": r_below,
        "r_above": r_above,
        "T_days": T_days,
        "R_km": R_km,
        "n_surrogates": n_surr,
        "require_full_window": bool(require_full_window),
        "events": results,
    }
    if out_json:
        with open(out_json, "w") as f:
            json.dump(out, f, indent=2, default=str)
    return out


# ---------------------------------------------------------------------------
# ETAS log-likelihood (Eq. 1 of the paper) — single tool for completeness
# ---------------------------------------------------------------------------
@mcp.tool()
def etas_intensity(times_days: list, mags: list, t_eval: float,
                   mu0: float, A: float, alpha: float,
                   c: float, p: float, m0: float = 5.1) -> float:
    """Conditional intensity of the temporal ETAS model at time t_eval given
    past events (times_days, mags). λ = μ₀ + Σ A·exp(α(M_i-m0)) (1+(t-t_i)/c)^-p

    Reference (paper Eq. 1, 2, 3).
    """
    t = np.asarray(times_days, dtype=float)
    m = np.asarray(mags, dtype=float)
    past = t < t_eval
    contrib = A * np.exp(alpha * (m[past] - m0)) * \
              (1.0 + (t_eval - t[past]) / c) ** (-p)
    return float(mu0 + contrib.sum())


# ---------------------------------------------------------------------------
# Plotting tools (one per answer image)
# ---------------------------------------------------------------------------
@mcp.tool()
def plot_global_distribution(catalog_csv: str, mega_csv: str,
                             out_png: str,
                             min_mag: float = 5.1) -> dict:
    """Reproduce paper Fig. 1a/1b: world map of all earthquakes vs
    mega-earthquakes (m >= 7.5)."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    cat = _load_earthquake_catalog(catalog_csv, min_mag)
    mega = _load_earthquake_catalog(mega_csv, 7.5)

    fig, axes = plt.subplots(1, 2, figsize=(13, 5))
    ax = axes[0]
    ax.scatter(cat["longitude"], cat["latitude"], s=0.3,
               c="firebrick", alpha=0.35, rasterized=True)
    ax.set_title(f"All events m≥{min_mag} (n={len(cat)})")
    ax.set_xlabel("Longitude"); ax.set_ylabel("Latitude")
    ax.set_xlim(-180, 180); ax.set_ylim(-90, 90)
    ax.grid(alpha=0.3)

    ax = axes[1]
    ax.scatter(mega["longitude"], mega["latitude"], s=20,
               c="darkred", alpha=0.8, edgecolor="k", linewidth=0.4)
    ax.set_title(f"Mega-earthquakes m≥7.5 (n={len(mega)})")
    ax.set_xlabel("Longitude"); ax.set_ylabel("Latitude")
    ax.set_xlim(-180, 180); ax.set_ylim(-90, 90)
    ax.grid(alpha=0.3)

    plt.tight_layout()
    fig.savefig(out_png, dpi=140)
    plt.close(fig)
    return {"out_png": out_png, "n_catalog": int(len(cat)),
            "n_megaquakes": int(len(mega))}


@mcp.tool()
def plot_significance_scatter(per_event_json: str, out_png: str) -> dict:
    """Reproduce paper Fig. 2a: per-mega-earthquake n(T,R) vs index plus
    surrogate p10/p90 envelope. Reads output of reduced_increased_ratio."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    with open(per_event_json) as f:
        d = json.load(f)
    # Drop mainshocks excluded for incomplete observation windows (n_obs None).
    ev = [e for e in d["events"]
          if e.get("n_obs") is not None and not e.get("excluded_incomplete_window")]
    n = np.array([e["n_obs"] for e in ev])
    p10 = np.array([e["p10"] for e in ev])
    p90 = np.array([e["p90"] for e in ev])
    mags = np.array([e["mag"] for e in ev])
    idx = np.arange(len(ev))

    fig, ax = plt.subplots(figsize=(10, 5))
    ax.fill_between(idx, p10, p90, color="0.7", alpha=0.5,
                    label="Surrogate 10-90%")
    sc = ax.scatter(idx, n, c=mags, cmap="viridis", s=22,
                    edgecolor="k", linewidth=0.3)
    ax.set_yscale("log")
    ax.set_xlabel("Mega-earthquake index")
    ax.set_ylabel("Number of events n(T=5d, R>500km)")
    cb = plt.colorbar(sc, ax=ax)
    cb.set_label("Mainshock magnitude")
    ax.legend(loc="upper right")
    ax.set_title(f"Activity vs surrogate envelope: "
                 f"r_below={d['r_below']:.3f}, r_above={d['r_above']:.3f}")
    plt.tight_layout()
    fig.savefig(out_png, dpi=140)
    plt.close(fig)
    return {"out_png": out_png, "r_below": d["r_below"],
            "r_above": d["r_above"]}


@mcp.tool()
def plot_ratio_vs_distance(events_csv: str, catalog_csv: str, out_png: str,
                           T_days_list: list = None,
                           R_edges_km: list = None,
                           n_surr: int = 2000,
                           min_mag_quake: float = 7.5,
                           min_mag_catalog: float = 5.1,
                           seed: int = 42) -> dict:
    """Reproduce paper Fig. 3: ratio (below 10% / above 90%) as a function
    of distance R for several time windows T."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    if T_days_list is None:
        T_days_list = [3, 5, 25, 60]
    if R_edges_km is None:
        # log-spaced from 10 km to 8000 km, ~12 bins
        R_edges_km = list(np.logspace(1.0, 3.9, 12))

    fig, axes = plt.subplots(2, 2, figsize=(11, 8), sharex=True)
    axes = axes.ravel()

    summary = []
    for ax, T in zip(axes, T_days_list):
        ratios_below = []
        ratios_above = []
        for R in R_edges_km:
            res = reduced_increased_ratio(
                events_csv=events_csv,
                catalog_csv=catalog_csv,
                T_days=float(T),
                R_km=float(R),
                min_mag_quake=min_mag_quake,
                min_mag_catalog=min_mag_catalog,
                n_surr=int(n_surr),
                seed=seed,
            )
            ratios_below.append(res["r_below"])
            ratios_above.append(res["r_above"])
        summary.append({"T_days": float(T), "R": list(R_edges_km),
                        "r_below": ratios_below, "r_above": ratios_above})
        ax.semilogx(R_edges_km, ratios_below, "o-", color="firebrick",
                    label="Below 10% (reduced)")
        ax.semilogx(R_edges_km, ratios_above, "s-", color="steelblue",
                    label="Above 90% (increased)")
        ax.axhline(0.10, color="k", lw=0.8, ls="--")
        ax.axvline(500, color="red", lw=0.8, ls=":")
        ax.set_title(f"T = {T} days")
        ax.set_xlabel("R (km)"); ax.set_ylabel("Ratio")
        ax.legend(fontsize=8); ax.grid(alpha=0.3)

    plt.tight_layout()
    fig.savefig(out_png, dpi=140)
    plt.close(fig)
    return {"out_png": out_png, "summary": summary}


@mcp.tool()
def plot_omori_decay(times_days: list, fit: dict, out_png: str,
                     bins: int = 25) -> dict:
    """Plot empirical aftershock rate vs modified Omori law fit (log-log)."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    t = np.asarray([x for x in times_days if x > 0], dtype=float)
    if t.size < 5:
        return {"out_png": None, "n": int(t.size)}
    edges = np.logspace(np.log10(max(t.min(), 1e-3)),
                        np.log10(t.max() + 1e-6), bins + 1)
    counts, e = np.histogram(t, bins=edges)
    centers = (e[:-1] * e[1:]) ** 0.5
    rate = counts / np.diff(e)

    K = fit["K"]; c = fit["c"]; p = fit["p"]
    tt = np.logspace(np.log10(max(t.min(), 1e-3)),
                     np.log10(t.max()), 200)
    model = K / (tt + c) ** p

    fig, ax = plt.subplots(figsize=(7, 5))
    ax.loglog(centers, rate, "o", ms=5, label="empirical")
    ax.loglog(tt, model, "-", lw=2,
              label=f"K={K:.3g}, c={c:.3g}, p={p:.3f}")
    ax.set_xlabel("Time after mainshock (days)")
    ax.set_ylabel("Rate (events / day)")
    ax.set_title("Modified Omori law fit")
    ax.legend(); ax.grid(which="both", alpha=0.3)
    plt.tight_layout()
    fig.savefig(out_png, dpi=140)
    plt.close(fig)
    return {"out_png": out_png, "n_events": int(t.size),
            "K": K, "c": c, "p": p}


if __name__ == "__main__":
    mcp.run()

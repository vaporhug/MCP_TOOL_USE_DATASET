"""Database retrieval — documentation of catalog provenance only.

This task is fully OFFLINE and DETERMINISTIC: both catalogs are bundled
under ``input_data/data/`` and every analysis tool reads them directly. No
network access is required or used.

The single function below documents how the bundled USGS catalog was
produced (FDSN query parameters). It is intentionally not wired as an MCP
tool and performs no network I/O; it is disabled unless ``allow_network``
is set, in which case an explicit implementation would be supplied at
run time. Cross-domain database stubs (PubChem, ChEMBL, UniProt, GEO,
etc.) that are not relevant to this seismicity task have been removed.
"""
from __future__ import annotations


def query_usgs_comcat(starttime: str, endtime: str, minmagnitude: float = 5.1,
                      bbox: tuple | None = None,
                      allow_network: bool = False) -> dict:
    """Document how the bundled USGS ComCat catalog was assembled.

    The bundled files were exported from the USGS FDSN event service
    (https://earthquake.usgs.gov/fdsnws/event/1/query) with format=csv,
    starttime=1979-05-01, endtime=2023-05-31, minmagnitude=5.1, global box.
    (The bundled catalog's last retained earthquake is 2023-05-30.)
    This function does NOT fetch over the network unless allow_network=True
    (no offline implementation is bundled, since the catalog ships with the
    task); use input_data/data/usgs_global_m51_1979_2023.csv directly.

    Args:
        starttime, endtime: ISO date bounds (documentation only).
        minmagnitude: magnitude threshold (paper uses 5.1).
        bbox: optional (minlon, minlat, maxlon, maxlat).
        allow_network: must be True to attempt a live fetch; defaults False
            so the task stays offline-deterministic.

    Returns:
        dict describing the provenance / disabled state.
    """
    return {
        "status": "offline",
        "message": "Use the bundled input_data/data/usgs_global_m51_1979_2023.csv; "
                   "this task does not fetch over the network.",
        "fdsn_query": {
            "service": "https://earthquake.usgs.gov/fdsnws/event/1/query",
            "format": "csv",
            "starttime": starttime,
            "endtime": endtime,
            "minmagnitude": minmagnitude,
            "bbox": bbox,
        },
        "allow_network": allow_network,
    }

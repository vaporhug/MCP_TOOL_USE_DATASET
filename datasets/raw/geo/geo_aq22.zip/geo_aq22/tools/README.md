# geo_aq22 — Tool Reference

## Dependencies
```
python>=3.10
numpy
pandas
scipy
matplotlib
mcp[cli]      # FastMCP server
```

## Database Retrieval (`database_retrieval.py`)

This task is **fully offline and deterministic** — both catalogs ship under
`input_data/data/` and every tool reads them directly. No network access is
used.

- **query_usgs_comcat**: Documents the FDSN query parameters used to build the
  bundled catalog (offline by default; performs no network I/O unless
  `allow_network=True`). The unrelated cross-domain database stubs from earlier
  rounds (PubChem/ChEMBL/UniProt/GEO/etc.) have been removed.

## Data Processing (`data_processing.py`)

Generic helpers. This task is CSV-only, so the heavy optional-format readers
are not required (and not exercised) here.

- **read_csv / write_csv / read_json / write_json / read_fasta**: implemented
  I/O primitives.
- **pivot_long_to_wide / pivot_wide_to_long**: reshape.
- **drop_missing / coerce_numeric / join_tables / groupby_aggregate**: cleaning + tabular ops.
- `read_excel`, `read_parquet`, `read_netcdf`, `read_shapefile` are intentional
  `pass` placeholders for heavy optional formats; they are **not implemented**
  and **not needed** for this CSV-only seismicity task — do not call them.

## Domain-Specific (`seismicity_analysis.py`)

### IO
- **load_usgs_catalog**: Read a USGS-format CSV with magnitude/time filters. Non-earthquake records (`type` in {nuclear explosion, volcanic eruption, explosion, rock burst, mine collapse}) are dropped before any statistics; only tectonic earthquakes are retained. All catalog-reading tools share this caliber. On the bundled catalog (spanning 1979-05-01 to 2023-05-30) the filter leaves 56,878 earthquakes (M>=5.1) and 194 mainshocks (M>=7.5).

All user-supplied ISO time strings are parsed with `pd.to_datetime(..., utc=True)`,
so `Z`-suffixed times from the bundled USGS CSV (e.g. `2011-03-11T05:46:24.000Z`)
parse correctly.

### Spatial
- **haversine_km**: Great-circle distance between two lat/lon points (km).
- **distances_from_event**: Compute distance from a reference point for every
  catalog row. Reads through the shared non-earthquake / magnitude filter
  (`min_magnitude`, default 5.1), so its row set matches every other tool.

### Magnitude / completeness
- **estimate_mc_maxc**: Maximum-curvature Mc (Wiemer & Wyss 2000).
- **gutenberg_richter_bvalue**: Aki MLE b-value with Shi & Bolt uncertainty.

### Aftershock decay
- **fit_modified_omori**: MLE fit of n(t)=K/(t+c)^p via differential_evolution.
- **etas_intensity**: Conditional intensity of the temporal ETAS model
  (paper Eq. 1) — a single-point intensity primitive provided for context.
  Note: a full space-time ETAS simulation/fit is **not** bundled; whether
  ETAS reproduces the far-field reduction is reported as a paper conclusion
  ([PAPER]), not re-derived here.

### Activity-rate change / quiescence
- **count_in_window**: Count events within (T days, R km lower bound) of a reference epicenter+time.
- **surrogate_count_distribution**: Build the null PDF of n(T,R) via random reference times (paper Methods 'Significance test').
- **percentile_of_count**: Empirical percentile of an observed count vs surrogates.
- **reduced_increased_ratio**: Loop over a mega-earthquake set, compute r_below=N_below/N_total and r_above=N_above/N_total (paper Eq. 'r=N_s/N_m'). With `require_full_window=True` (default) mainshocks whose T-day post window runs past the catalog end are excluded (reported as `n_excluded_window`) so observed and surrogate counts use equal-length windows; at the headline T=5 d all 194 mainshocks are validly windowed (0 excluded).

### Plotting (one tool per answer image)
- **plot_global_distribution**: Reproduces Fig. 1a/1b (world map of all events vs mega-quakes).
- **plot_significance_scatter**: Reproduces Fig. 2a (n(T,R) vs index plus 10/90% surrogate envelope).
- **plot_ratio_vs_distance**: Reproduces Fig. 3 (ratio vs R for several T values).
- **plot_omori_decay**: Aftershock rate vs Omori law fit (log-log).

#!/usr/bin/env python3
"""Drought / climatology analysis primitives for the Mesoamerica task.

These are general-purpose tools for working with gridded netCDF climate
data (precipitation, PDSI), rolling-window aggregation, percentile-based
masking, regional spatial averaging, and trend testing. They do not encode
any conclusion of the study and may be combined freely.
"""
from __future__ import annotations

import json
import os
from typing import Any

import numpy as np
import xarray as xr
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Drought_Analysis_Tools")


# ---------------------------------------------------------------------------
# Loading / inspection
# ---------------------------------------------------------------------------
@mcp.tool()
def inspect_netcdf(nc_path: str) -> dict:
    """Open a netCDF file and return its variables, coordinates, and shape.

    Args:
        nc_path: path to a .nc file

    Returns:
        dict with variables, coords, dims, time range, and small sample.
    """
    ds = xr.open_dataset(nc_path, decode_times=True)
    info: dict[str, Any] = {
        "variables": list(ds.data_vars),
        "coords": list(ds.coords),
        "dims": {k: int(v) for k, v in ds.sizes.items()},
        "attrs": {k: str(v)[:200] for k, v in ds.attrs.items()},
    }
    if "time" in ds.coords:
        t = ds.time.values
        info["time_first"] = str(t[0])
        info["time_last"] = str(t[-1])
        info["time_n"] = int(len(t))
    for c in ("lat", "latitude", "lon", "longitude"):
        if c in ds.coords:
            v = ds[c].values
            info[f"{c}_min"] = float(np.nanmin(v))
            info[f"{c}_max"] = float(np.nanmax(v))
            info[f"{c}_n"] = int(len(v))
    ds.close()
    return info


@mcp.tool()
def subset_netcdf(
    nc_path: str,
    variable: str,
    lat_min: float | None = None,
    lat_max: float | None = None,
    lon_min: float | None = None,
    lon_max: float | None = None,
    time_start: str | None = None,
    time_end: str | None = None,
    output_path: str | None = None,
) -> dict:
    """Subset a netCDF dataset by lat/lon/time and optionally write to disk.

    Args:
        nc_path: input netCDF path
        variable: name of variable to retain
        lat_min, lat_max, lon_min, lon_max: bounding box (inclusive)
        time_start, time_end: ISO date strings (YYYY-MM-DD)
        output_path: if provided, save the subset and return its path

    Returns:
        dict with shape, value summary, and optional output_path.
    """
    ds = xr.open_dataset(nc_path)
    da = ds[variable]
    lat_name = "lat" if "lat" in ds.coords else "latitude"
    lon_name = "lon" if "lon" in ds.coords else "longitude"
    if lat_min is not None and lat_max is not None:
        # respect descending lat ordering (CRU stores 89 -> -89)
        lat_vals = ds[lat_name].values
        if lat_vals[0] > lat_vals[-1]:
            da = da.sel({lat_name: slice(lat_max, lat_min)})
        else:
            da = da.sel({lat_name: slice(lat_min, lat_max)})
    if lon_min is not None and lon_max is not None:
        da = da.sel({lon_name: slice(lon_min, lon_max)})
    if time_start is not None and time_end is not None and "time" in da.coords:
        da = da.sel(time=slice(time_start, time_end))
    arr = da.values
    out = {
        "shape": list(arr.shape),
        "dims": list(da.dims),
        "min": float(np.nanmin(arr)),
        "max": float(np.nanmax(arr)),
        "mean": float(np.nanmean(arr)),
        "n_nonnan": int(np.sum(~np.isnan(arr))),
    }
    if output_path is not None:
        da.to_dataset(name=variable).to_netcdf(output_path)
        out["output_path"] = output_path
    ds.close()
    return out


# ---------------------------------------------------------------------------
# Seasonal aggregation
# ---------------------------------------------------------------------------
@mcp.tool()
def seasonal_aggregate(
    nc_path: str,
    variable: str,
    months: list[int],
    operation: str = "sum",
    output_path: str | None = None,
    missing_value: float | None = -9999.0,
) -> dict:
    """Aggregate a gridded monthly variable over a custom set of months per year.

    Args:
        nc_path: input netCDF
        variable: variable to aggregate
        months: list of integers in 1..12 (e.g., [5,6,7,8,9,10] for May-Oct)
        operation: 'sum' or 'mean'
        output_path: if given, save the (year, lat, lon) result
        missing_value: sentinel value to convert to NaN before aggregation
            (the CRU scPDSI file stores missing values as -9999; set to None
            to disable). Aggregation uses skipna=False so any masked month
            propagates as NaN, keeping the regional average clean.

    Returns:
        dict with shape, year range, summary stats, optional output_path.
    """
    ds = xr.open_dataset(nc_path)
    da = ds[variable]
    if missing_value is not None:
        da = da.where(da != missing_value)
    sel = da.where(da["time.month"].isin(months), drop=True)
    grouped = sel.groupby("time.year")
    if operation == "sum":
        agg = grouped.sum("time", skipna=False)
    elif operation == "mean":
        agg = grouped.mean("time", skipna=False)
    else:
        raise ValueError("operation must be 'sum' or 'mean'")
    out: dict[str, Any] = {
        "shape": list(agg.shape),
        "dims": list(agg.dims),
        "year_min": int(agg.year.values.min()),
        "year_max": int(agg.year.values.max()),
        "global_mean": float(np.nanmean(agg.values)),
    }
    if output_path is not None:
        agg.to_dataset(name=variable).to_netcdf(output_path)
        out["output_path"] = output_path
    ds.close()
    return out


@mcp.tool()
def gridcell_seasonal_fraction_mask(
    precip_nc_path: str,
    variable: str = "precip",
    months: list[int] = (5, 6, 7, 8, 9, 10),  # noqa: B008
    threshold_pct: float = 75.0,
    output_path: str | None = None,
) -> dict:
    """Build a 2D (lat, lon) mask of grid cells where the specified months
    contribute more than `threshold_pct` percent of total annual precipitation
    on average across the record.

    Args:
        precip_nc_path: monthly precipitation netCDF
        variable: precipitation variable name
        months: months defining the fraction's numerator
        threshold_pct: minimum percent contribution required
        output_path: if given, save the boolean mask

    Returns:
        dict with the mask shape, count of True cells, and optional output path.
    """
    ds = xr.open_dataset(precip_nc_path)
    da = ds[variable]
    annual = da.groupby("time.year").sum("time", skipna=False)
    sel = da.where(da["time.month"].isin(list(months)), drop=True)
    season = sel.groupby("time.year").sum("time", skipna=False)
    pct = (season / annual * 100.0).mean("year")
    mask = pct > threshold_pct
    out: dict[str, Any] = {
        "shape": list(mask.shape),
        "n_cells_true": int(mask.values.sum()),
        "n_cells_total": int(mask.values.size),
        "threshold_pct": threshold_pct,
        "months": list(months),
    }
    if output_path is not None:
        mask.to_dataset(name="mask").to_netcdf(output_path)
        out["output_path"] = output_path
    ds.close()
    return out


@mcp.tool()
def apply_mask_and_regional_average(
    nc_path: str,
    variable: str,
    mask_nc_path: str | None = None,
    mask_variable: str = "mask",
    output_csv: str | None = None,
    missing_value: float | None = -9999.0,
) -> dict:
    """Apply an optional 2D mask to a (year, lat, lon) field then take the
    spatial mean (over lat, lon) at every year. Also returns the percent
    anomaly relative to the full-record mean.

    This computes the regional average as spatial-mean-then-anomaly (region
    mean first, then percent anomaly versus the full-record mean). For the
    paper's gridcell-percent-anomaly-then-mean convention (Figure 1e/f, "based
    on % anomalies") use `gridcell_pct_anomaly_then_regional_mean` instead;
    the two differ by a few percentage points on this region.

    Args:
        nc_path: gridded annual or seasonal field with dims (year, lat, lon)
        variable: name of variable
        mask_nc_path: optional mask netCDF (boolean)
        mask_variable: variable name in mask
        output_csv: if given, write {year, value, anomaly_pct} to CSV
        missing_value: sentinel converted to NaN before averaging (CRU scPDSI
            uses -9999; set to None to disable).

    Returns:
        dict with the per-year time series, climatology mean, and stats.
    """
    ds = xr.open_dataset(nc_path)
    da = ds[variable]
    if missing_value is not None:
        da = da.where(da != missing_value)
    if mask_nc_path is not None:
        m = xr.open_dataset(mask_nc_path)[mask_variable]
        da = da.where(m)
    spatial_dims = [d for d in da.dims if d not in ("year",)]
    ts = da.mean(spatial_dims, skipna=True)
    yrs = ts.year.values.astype(int).tolist()
    vals = ts.values.astype(float).tolist()
    clim = float(np.nanmean(vals))
    anom_pct = [
        float((v - clim) / clim * 100.0) if (clim != 0 and not np.isnan(v)) else float("nan")
        for v in vals
    ]
    if output_csv is not None:
        with open(output_csv, "w") as f:
            f.write("year,value,anomaly_pct\n")
            for y, v, a in zip(yrs, vals, anom_pct):
                f.write(f"{y},{v},{a}\n")
    ds.close()
    return {
        "n_years": len(yrs),
        "year_min": yrs[0],
        "year_max": yrs[-1],
        "climatology_mean": round(clim, 4),
        "values": [round(v, 4) for v in vals],
        "anomaly_pct": [round(a, 4) for a in anom_pct],
        "years": yrs,
        "output_csv": output_csv,
    }


@mcp.tool()
def gridcell_pct_anomaly_then_regional_mean(
    nc_path: str,
    variable: str,
    mask_nc_path: str | None = None,
    mask_variable: str = "mask",
    output_csv: str | None = None,
    missing_value: float | None = -9999.0,
) -> dict:
    """Regional percent-anomaly time series using the paper's Figure 1e/f
    convention: compute the percent anomaly at each grid cell relative to that
    cell's full-record mean, then take the (masked) spatial mean of those
    per-cell percent anomalies. This differs from
    `apply_mask_and_regional_average` (which averages first, then takes the
    anomaly) and matches the paper's "based on % anomalies" regional curves.

    Args:
        nc_path: gridded (year, lat, lon) seasonal field.
        variable: variable name.
        mask_nc_path: optional boolean mask netCDF.
        mask_variable: mask variable name.
        output_csv: if given, write {year, anomaly_pct}.
        missing_value: sentinel converted to NaN before computing (default
            -9999 for CRU scPDSI; set to None to disable).

    Returns:
        dict with the per-year regional percent-anomaly series.
    """
    ds = xr.open_dataset(nc_path)
    da = ds[variable]
    if missing_value is not None:
        da = da.where(da != missing_value)
    if mask_nc_path is not None:
        m = xr.open_dataset(mask_nc_path)[mask_variable]
        da = da.where(m)
    cell_clim = da.mean("year", skipna=True)
    cell_pct = (da - cell_clim) / cell_clim * 100.0
    spatial_dims = [d for d in da.dims if d != "year"]
    ts = cell_pct.mean(spatial_dims, skipna=True)
    yrs = ts.year.values.astype(int).tolist()
    anom_pct = [float(v) for v in ts.values]
    if output_csv is not None:
        with open(output_csv, "w") as f:
            f.write("year,anomaly_pct\n")
            for y, a in zip(yrs, anom_pct):
                f.write(f"{y},{a}\n")
    ds.close()
    return {
        "n_years": len(yrs),
        "year_min": yrs[0],
        "year_max": yrs[-1],
        "anomaly_pct": [round(a, 4) for a in anom_pct],
        "years": yrs,
        "output_csv": output_csv,
    }


# ---------------------------------------------------------------------------
# Rolling window / ranking
# ---------------------------------------------------------------------------
@mcp.tool()
def rolling_mean(values: list[float], window: int) -> dict:
    """Rolling mean of a 1D series. The first (window-1) entries are NaN.

    Args:
        values: 1D series (NaN-aware)
        window: window length

    Returns:
        dict with rolled values and the index of minimum/maximum.
    """
    arr = np.asarray(values, dtype=float)
    n = len(arr)
    out = np.full(n, np.nan)
    for i in range(window - 1, n):
        seg = arr[i - window + 1 : i + 1]
        if not np.any(np.isnan(seg)):
            out[i] = float(np.mean(seg))
    valid_idx = np.where(~np.isnan(out))[0]
    if valid_idx.size == 0:
        return {"rolled": [None] * n, "argmin": None, "argmax": None}
    sub = out[valid_idx]
    amin = int(valid_idx[int(np.argmin(sub))])
    amax = int(valid_idx[int(np.argmax(sub))])
    return {
        "rolled": [None if np.isnan(v) else round(float(v), 6) for v in out],
        "min_value": round(float(sub.min()), 6),
        "max_value": round(float(sub.max()), 6),
        "argmin_index": amin,
        "argmax_index": amax,
        "window": window,
    }


@mcp.tool()
def rank_value_in_record(
    values: list[float], target_value: float, exclude_indices: list[int] | None = None
) -> dict:
    """Compute the rank of `target_value` among `values`. Rank 1 = lowest.

    Args:
        values: list of numbers (NaN allowed; NaN ignored)
        target_value: value to rank
        exclude_indices: optional indices in `values` to skip during ranking

    Returns:
        dict with rank (1 = lowest), n_total, percentile_below, and the
        next-lowest value plus its index.
    """
    arr = np.asarray(values, dtype=float)
    keep = ~np.isnan(arr)
    if exclude_indices:
        for i in exclude_indices:
            if 0 <= i < len(arr):
                keep[i] = False
    sub = arr[keep]
    n = len(sub)
    n_below = int(np.sum(sub <= target_value))
    sorted_arr = np.sort(sub)
    next_lower = None
    next_lower_idx = None
    below = sub[sub < target_value]
    if below.size:
        next_lower = float(below.max())
        # find original index of the maximum-of-below
        full_idx = np.where(arr == next_lower)[0]
        next_lower_idx = int(full_idx[0]) if full_idx.size else None
    # When `target_value` is the driest (lowest) value, the "next-driest"
    # non-overlapping window is the smallest value strictly greater than the
    # target. `exclude_indices` already removes the windows that overlap the
    # target period, so this directly supports the next-driest-window gap.
    next_higher = None
    next_higher_idx = None
    above = sub[sub > target_value]
    if above.size:
        next_higher = float(above.min())
        full_idx = np.where(arr == next_higher)[0]
        next_higher_idx = int(full_idx[0]) if full_idx.size else None
    return {
        "n_compared": n,
        "n_at_or_below_target": n_below,
        "rank_lowest_first": n_below + (0 if (sub == target_value).any() else 1),
        "percentile_at_or_below": round(n_below / n * 100.0, 4),
        "target_value": round(float(target_value), 6),
        "next_lowest_value": round(next_lower, 6) if next_lower is not None else None,
        "next_lowest_index": next_lower_idx,
        "next_higher_value": round(next_higher, 6) if next_higher is not None else None,
        "next_higher_index": next_higher_idx,
        "gap_to_next_higher": (round(float(next_higher) - float(target_value), 6)
                               if next_higher is not None else None),
        "all_sorted_first10": [round(float(x), 6) for x in sorted_arr[:10]],
    }


# ---------------------------------------------------------------------------
# Spatial percentile maps
# ---------------------------------------------------------------------------
@mcp.tool()
def spatial_anomaly_map(
    nc_path: str,
    variable: str,
    target_years: list[int],
    output_path: str | None = None,
) -> dict:
    """Compute the percent anomaly of the mean over `target_years` versus the
    full-record mean at every grid cell.

    Args:
        nc_path: (year, lat, lon) field
        variable: variable name
        target_years: list of years to average over (e.g., [2015..2019])
        output_path: optional .nc output

    Returns:
        dict with min/mean/max anomaly_pct and gridcell summary.
    """
    ds = xr.open_dataset(nc_path)
    da = ds[variable]
    clim = da.mean("year", skipna=True)
    period = da.sel(year=target_years).mean("year", skipna=True)
    anom = (period - clim) / clim * 100.0
    out = {
        "target_years": target_years,
        "anom_min": float(np.nanmin(anom.values)),
        "anom_max": float(np.nanmax(anom.values)),
        "anom_mean": float(np.nanmean(anom.values)),
        "n_cells": int(np.sum(~np.isnan(anom.values))),
        "n_cells_below_zero": int(np.nansum(anom.values < 0)),
    }
    if output_path is not None:
        anom.to_dataset(name="anomaly_pct").to_netcdf(output_path)
        out["output_path"] = output_path
    ds.close()
    return out


# ---------------------------------------------------------------------------
# Trend testing
# ---------------------------------------------------------------------------
@mcp.tool()
def mann_kendall_theil_sen(values: list[float]) -> dict:
    """Mann-Kendall test + Theil-Sen slope on an ordered series.

    Returns:
        dict with S, z, p_value, trend, sens_slope, intercept, n.
    """
    from scipy.stats import norm, theilslopes

    y = np.asarray(values, dtype=float)
    y = y[~np.isnan(y)]
    n = len(y)
    s = 0
    for i in range(n - 1):
        for j in range(i + 1, n):
            d = y[j] - y[i]
            if d > 0:
                s += 1
            elif d < 0:
                s -= 1
    var_s = n * (n - 1) * (2 * n + 5) / 18.0
    if s > 0:
        z = (s - 1) / np.sqrt(var_s)
    elif s < 0:
        z = (s + 1) / np.sqrt(var_s)
    else:
        z = 0.0
    p = 2 * (1 - norm.cdf(abs(z)))
    slope, intercept, _, _ = theilslopes(y, np.arange(n))
    if p < 0.05:
        trend = "increasing" if s > 0 else "decreasing"
    else:
        trend = "no significant trend"
    return {
        "S": int(s),
        "z_statistic": round(float(z), 4),
        "p_value": round(float(p), 6),
        "trend": trend,
        "sens_slope": round(float(slope), 6),
        "intercept": round(float(intercept), 4),
        "n_points": int(n),
    }


# ---------------------------------------------------------------------------
# Climate mode time series (CVDP combined file)
# ---------------------------------------------------------------------------
@mcp.tool()
def load_climate_mode_series(
    nc_path: str,
    mode_variable: str,
    months: list[int] | None = None,
    aggregate: str = "mean",
) -> dict:
    """Read a 1D climate-mode time series (monthly) and optionally collapse
    to seasonal annual values.

    Args:
        nc_path: netCDF with mode time series (units may be 'Months since YYYY')
        mode_variable: variable name (e.g., 'nino34', 'cllj_timeseries_mon')
        months: list of months to keep (e.g., [5,6,7,8,9,10]); None -> all months
        aggregate: 'mean' across kept months per year

    Returns:
        dict with year list (if seasonal) and value list.
    """
    ds = xr.open_dataset(nc_path, decode_times=False)
    da = ds[mode_variable]
    n = int(da.shape[0])
    # Time coord typically 'Months since 1920-01-01'
    units = ds["time"].attrs.get("units", "Months since 1920-01-01 00:00:00")
    base_year = 1920
    try:
        base_year = int(units.split("since")[1].strip().split("-")[0])
    except Exception:
        pass
    years_full = np.array([base_year + i // 12 for i in range(n)])
    months_full = np.array([(i % 12) + 1 for i in range(n)])
    vals = da.values
    if months is None:
        return {
            "years": years_full.tolist(),
            "months": months_full.tolist(),
            "values": [float(v) for v in vals],
            "n": int(n),
        }
    keep = np.isin(months_full, months)
    sub_yrs = years_full[keep]
    sub_vals = vals[keep]
    # Seasonal aggregate per year
    out_years = []
    out_vals = []
    for y in sorted(set(sub_yrs.tolist())):
        m = sub_yrs == y
        if aggregate == "mean":
            v = float(np.nanmean(sub_vals[m]))
        else:
            v = float(np.nansum(sub_vals[m]))
        out_years.append(int(y))
        out_vals.append(v)
    ds.close()
    return {
        "years": out_years,
        "values": [round(v, 6) for v in out_vals],
        "n": len(out_years),
        "months_kept": list(months),
    }


# ---------------------------------------------------------------------------
# Plotting tools (each writes a PNG)
# ---------------------------------------------------------------------------
@mcp.tool()
def plot_spatial_anomaly(
    nc_path: str,
    variable: str,
    target_years: list[int],
    output_png: str,
    title: str = "Anomaly map",
    vmin: float | None = None,
    vmax: float | None = None,
    cmap: str = "RdBu",
) -> dict:
    """Plot the percent-anomaly map for a (year, lat, lon) field over target
    years and save as PNG.

    Returns:
        dict with output_png path and value summary.
    """
    import matplotlib.pyplot as plt

    ds = xr.open_dataset(nc_path)
    da = ds[variable]
    clim = da.mean("year", skipna=True)
    period = da.sel(year=target_years).mean("year", skipna=True)
    anom = (period - clim) / clim * 100.0
    fig, ax = plt.subplots(figsize=(7, 6))
    extent_range = float(np.nanmax(np.abs(anom.values))) if (vmin is None or vmax is None) else None
    if vmin is None:
        vmin = -extent_range
    if vmax is None:
        vmax = extent_range
    im = ax.pcolormesh(anom.lon, anom.lat, anom.values, cmap=cmap, vmin=vmin, vmax=vmax, shading="auto")
    cb = plt.colorbar(im, ax=ax, label="% anomaly")
    ax.set_xlabel("Longitude")
    ax.set_ylabel("Latitude")
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(output_png, dpi=150)
    plt.close(fig)
    ds.close()
    return {
        "output_png": output_png,
        "anom_min": float(np.nanmin(anom.values)),
        "anom_max": float(np.nanmax(anom.values)),
        "anom_mean": float(np.nanmean(anom.values)),
    }


@mcp.tool()
def plot_time_series_with_rolling(
    years: list[int],
    values: list[float],
    rolling: list[float | None] | None,
    output_png: str,
    title: str = "Regional time series",
    ylabel: str = "value",
    highlight_years: list[int] | None = None,
) -> dict:
    """Plot annual values + a rolling mean overlay and save PNG. Optionally
    shade a `highlight_years` block.

    Returns:
        dict with output_png and basic summary.
    """
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(10, 4.5))
    arr = np.asarray(values, dtype=float)
    ax.axhline(0.0, color="black", linestyle="--", alpha=0.6)
    ax.plot(years, arr, color="grey", label="Annual")
    if rolling is not None:
        roll = np.asarray([np.nan if v is None else v for v in rolling], dtype=float)
        ax.plot(years, roll, color="C0", linewidth=2.5, label="Rolling mean")
    if highlight_years and len(highlight_years) >= 2:
        ax.axvspan(min(highlight_years), max(highlight_years), color="orange", alpha=0.25,
                   label=f"{min(highlight_years)}-{max(highlight_years)}")
    ax.set_title(title)
    ax.set_xlabel("Year")
    ax.set_ylabel(ylabel)
    ax.legend(loc="lower left")
    fig.tight_layout()
    fig.savefig(output_png, dpi=150)
    plt.close(fig)
    return {
        "output_png": output_png,
        "n_years": len(years),
        "value_min": float(np.nanmin(arr)),
        "value_max": float(np.nanmax(arr)),
    }


@mcp.tool()
def plot_climate_mode_scatter(
    x_values: list[float],
    y_values: list[float],
    output_png: str,
    x_label: str = "ENSO",
    y_label: str = "CLLJ",
    target_x: float | None = None,
    target_y: float | None = None,
    target_label: str = "2015-2019",
    title: str = "Climate mode 5-year means",
) -> dict:
    """Scatter plot of two climate-mode time series (one point per year),
    with an optional star marker for an observed value.

    Returns:
        dict with output_png and Pearson correlation.
    """
    import matplotlib.pyplot as plt
    from scipy.stats import pearsonr

    x = np.asarray(x_values, dtype=float)
    y = np.asarray(y_values, dtype=float)
    mask = ~(np.isnan(x) | np.isnan(y))
    r, p = pearsonr(x[mask], y[mask]) if int(mask.sum()) > 3 else (np.nan, np.nan)
    fig, ax = plt.subplots(figsize=(6, 5))
    ax.scatter(x, y, s=14, alpha=0.5, color="C0")
    if target_x is not None and target_y is not None:
        ax.scatter([target_x], [target_y], s=180, marker="*", color="red", label=target_label, zorder=5)
        ax.legend()
    ax.set_xlabel(x_label)
    ax.set_ylabel(y_label)
    ax.set_title(title)
    ax.axhline(0, color="grey", lw=0.8)
    ax.axvline(0, color="grey", lw=0.8)
    fig.tight_layout()
    fig.savefig(output_png, dpi=150)
    plt.close(fig)
    return {
        "output_png": output_png,
        "pearson_r": round(float(r), 4) if not np.isnan(r) else None,
        "p_value": round(float(p), 6) if not np.isnan(p) else None,
        "n": int(mask.sum()),
    }


@mcp.tool()
def plot_ranked_periods_bar(
    period_labels: list[str],
    values: list[float],
    output_png: str,
    title: str = "Driest 5-year periods (regional anomaly %)",
    ylabel: str = "Anomaly (%)",
    highlight_label: str | None = None,
) -> dict:
    """Bar chart of ranked periods (e.g., the 10 driest 5-year windows).

    Returns:
        dict with output_png path.
    """
    import matplotlib.pyplot as plt

    colors = []
    for lbl in period_labels:
        colors.append("red" if (highlight_label is not None and lbl == highlight_label) else "steelblue")
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.bar(period_labels, values, color=colors)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.axhline(0.0, color="black", lw=0.8)
    plt.xticks(rotation=45, ha="right")
    fig.tight_layout()
    fig.savefig(output_png, dpi=150)
    plt.close(fig)
    return {"output_png": output_png}


if __name__ == "__main__":
    mcp.run(transport="stdio")

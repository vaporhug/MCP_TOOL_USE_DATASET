# geo_dr28 — Tool Reference

Tools for Mesoamerican drought analysis: gridded netCDF I/O, seasonal aggregation,
regional masking, rolling-window statistics, ranking, trend detection, and plotting.

## Dependencies

```
numpy
scipy
xarray
netCDF4
matplotlib
mcp                # for FastMCP decorator
pandas             # used by data_processing helpers
```

Python >=3.10 recommended.

## Database Retrieval (`database_retrieval.py`)

Generic stubs for external data lookup (websearch, fetch_url, query_doi, etc.).
Implementations are deferred; agents fill in network calls at runtime.

## Data Processing (`data_processing.py`)

Generic table I/O and reshaping helpers (CSV/JSON/Excel readers, pivot,
groupby_aggregate, drop_missing, coerce_numeric, etc.). Domain-agnostic.

## Domain Analysis (`drought_analysis.py`)

- **inspect_netcdf**: Open a netCDF file and return its variables, coords, and time/space ranges.
- **subset_netcdf**: Subset a netCDF dataset by lat/lon/time and optionally save the slice.
- **seasonal_aggregate**: Sum or mean a monthly variable over chosen months per year.
- **gridcell_seasonal_fraction_mask**: Boolean mask of cells where chosen months
  contribute >= a threshold percent of the annual total.
- **apply_mask_and_regional_average**: Apply a 2D mask and take spatial mean per year.
- **rolling_mean**: NaN-aware rolling-window mean; reports min/max/argmin/argmax.
- **rank_value_in_record**: Rank a target value among series; supports excluding indices.
- **spatial_anomaly_map**: Per-cell percent anomaly of target years vs full record.
- **mann_kendall_theil_sen**: Mann-Kendall + Theil-Sen on an ordered series.
- **load_climate_mode_series**: Read a 1D mode time series, optionally collapse to
  seasonal annual values.
- **plot_spatial_anomaly**: PNG of percent anomaly map.
- **plot_time_series_with_rolling**: PNG of annual values plus rolling overlay.
- **plot_climate_mode_scatter**: PNG scatter of two modes with optional star marker.
- **plot_ranked_periods_bar**: PNG bar chart of ranked windows.

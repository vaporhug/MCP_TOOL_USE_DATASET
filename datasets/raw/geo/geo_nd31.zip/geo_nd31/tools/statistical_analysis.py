#!/usr/bin/env python3
"""
Statistical analysis utilities: correlations, OLS regression, and linear mixed
effects models with categorical interactions and a species random intercept.
"""

from __future__ import annotations

import math
import os
import re
from typing import Any

import numpy as np
import pandas as pd
import warnings
import statsmodels.formula.api as smf
from scipy.stats import pearsonr, spearmanr
from scipy.stats import norm
try:
    from mcp.server.fastmcp import FastMCP
except Exception:
    class FastMCP:
        """Decorator-compatible fallback for local non-MCP tests."""
        def __init__(self, *args, **kwargs):
            pass

        def tool(self):
            def decorator(func):
                return func
            return decorator

        def run(self, *args, **kwargs):
            return None


def _robust_mixedlm_fit(model):
    """Fit a statsmodels MixedLM with optimizer fallbacks.

    Tries L-BFGS-B (the typical default for MixedLM via statsmodels), then
    BFGS, then Powell. Returns the first ``MixedLMResults`` whose fit raises
    no exception. Re-raises the last exception only if all optimizers fail.
    """
    last_exc: Exception | None = None
    for method in ("lbfgs", "bfgs", "powell"):
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                return model.fit(method=method, disp=False)
        except Exception as exc:  # convergence / linalg / ValueError variants
            last_exc = exc
            continue
    assert last_exc is not None
    raise last_exc

mcp = FastMCP("Stoichiometry_Statistics")


def _clean_xy(x: list, y: list) -> tuple[np.ndarray, np.ndarray]:
    a = np.array(x, dtype=float)
    b = np.array(y, dtype=float)
    m = ~(np.isnan(a) | np.isnan(b))
    return a[m], b[m]


def _bh_adjust(p_values: list[float]) -> list[float]:
    vals = np.asarray([np.nan if p is None else float(p) for p in p_values], dtype=float)
    out = np.full(vals.shape, np.nan, dtype=float)
    finite_idx = np.where(np.isfinite(vals))[0]
    if finite_idx.size == 0:
        return out.tolist()
    order = finite_idx[np.argsort(vals[finite_idx])]
    ranked = vals[order]
    m = float(len(ranked))
    adjusted = ranked * m / np.arange(1, len(ranked) + 1)
    adjusted = np.minimum.accumulate(adjusted[::-1])[::-1]
    adjusted = np.clip(adjusted, 0.0, 1.0)
    out[order] = adjusted
    return out.tolist()


def _paper_base_dataframe(csv_path: str) -> pd.DataFrame:
    df = pd.read_csv(csv_path)
    df = df.rename(columns={
        "data.source1": "data.source",
        "P_ter": "P_terr_lab",
        "P_mar": "P_marine",
        "temperature": "nasa.T10M",
        "radiation": "nasa.ALLSKY_SFC_SW_DWN",
        "N": "meanN_tot",
    })
    df = df[~df["class_revised"].isin(["Aves", "Mammalia"])].copy()
    df = df[~df["data.source"].isin(["Freschet et al (2010)"])].copy()
    df = df[~df["habitat"].isin(["marine"])].copy()
    df["Penv_raw"] = np.where(
        df["habitat"].isin(["freshwater", "terrestrial"]),
        df["P_terr_lab"],
        np.where(df["habitat"].isin(["marine"]), df["P_marine"], np.nan),
    )
    df["autohetero"] = np.select(
        [
            df["invert.vert.auto"].eq("autotroph"),
            df["invert.vert.auto"].isin(["invertebrate", "vertebrate"]),
        ],
        ["autotroph", "heterotroph"],
        default=df["invert.vert.auto"].astype(str),
    )
    df["Temp"] = pd.to_numeric(df["nasa.T10M"], errors="coerce")
    df["Rad"] = pd.to_numeric(df["nasa.ALLSKY_SFC_SW_DWN"], errors="coerce")
    df["Nenv"] = pd.to_numeric(df["meanN_tot"], errors="coerce")
    df["Penv"] = pd.to_numeric(df["Penv_raw"], errors="coerce")
    df["log_Nenv"] = np.log(df["Nenv"].where(df["Nenv"] > 0))
    df["log_Penv"] = np.log(df["Penv"].where(df["Penv"] > 0))
    df["species"] = df["sp.morphosp_revised"].astype(str)
    df["abs_lat_dec"] = pd.to_numeric(df["lat.dec"], errors="coerce").abs()
    for raw, out in [("taxa.n", "logit_pN"), ("taxa.p", "logit_pP")]:
        vals = pd.to_numeric(df[raw], errors="coerce")
        frac = vals / 100.0
        valid = (frac > 0.0) & (frac < 1.0)
        df[out] = np.where(valid, np.log(frac / (1.0 - frac)), np.nan)
    np_vals = pd.to_numeric(df["taxa.np"], errors="coerce")
    df["log_NP"] = np.log(np_vals.where(np_vals > 0))
    return df


@mcp.tool()
def prepare_paper_analysis_table(csv_path: str, output_csv: str | None = None) -> dict:
    """Reproduce the paper/R-notebook cohort filter and transformations.

    The source notebook excludes Aves, Mammalia, the Freschet et al. (2010)
    source, and marine rows; maps invertebrate/vertebrate to heterotroph;
    creates absolute latitude, logit(%N), logit(%P), log(N:P), log(N
    deposition), and log(labile P). The returned model counts match the
    Methods latitude/environmental-driver counts when applied to the bundled
    StoichLife CSV.
    """
    if not os.path.exists(csv_path):
        return {"error": f"File not found: {csv_path}"}
    df = _paper_base_dataframe(csv_path)
    if output_csv:
        os.makedirs(os.path.dirname(output_csv) or ".", exist_ok=True)
        df.to_csv(output_csv, index=False)
    response_cols = {"logit_pN": "N", "logit_pP": "P", "log_NP": "NP"}
    counts = {}
    for response, label in response_cols.items():
        lat_cols = [response, "abs_lat_dec", "habitat", "autohetero", "species"]
        env_cols = [response, "Temp", "Rad", "log_Nenv", "log_Penv",
                    "habitat", "autohetero", "species"]
        counts[f"{label}_latitude_n_obs"] = int(df[lat_cols].dropna().shape[0])
        counts[f"{label}_environment_n_obs"] = int(df[env_cols].dropna().shape[0])
    return {
        "output_csv": output_csv,
        "n_rows_after_paper_filters": int(len(df)),
        "n_rows_with_latitude": int(df.dropna(subset=["lat.dec"]).shape[0]),
        "n_rows_with_lat_long": int(df.dropna(subset=["lat.dec", "long.dec"]).shape[0]),
        "n_species_or_morphospecies": int(df["species"].nunique()),
        "model_counts": counts,
        "columns_added": [
            "abs_lat_dec", "logit_pN", "logit_pP", "log_NP",
            "Temp", "Rad", "log_Nenv", "log_Penv", "species",
        ],
    }


def _paper_formula(mode: str) -> tuple[str, list[str]]:
    if mode == "latitude":
        return (
            "_y ~ abs_lat_dec + C(_realm, Sum) + C(_trophic, Sum) + "
            "abs_lat_dec:C(_realm, Sum) + abs_lat_dec:C(_trophic, Sum) + "
            "C(_realm, Sum):C(_trophic, Sum)",
            ["abs_lat_dec"],
        )
    if mode == "environment":
        predictors = ["Temp", "Rad", "log_Nenv", "log_Penv"]
        main = " + ".join(predictors)
        interactions = " + ".join(
            [f"{p}:C(_realm, Sum)" for p in predictors] +
            [f"{p}:C(_trophic, Sum)" for p in predictors]
        )
        return (
            f"_y ~ C(_realm, Sum) + C(_trophic, Sum) + {main} + "
            f"{interactions} + C(_realm, Sum):C(_trophic, Sum)",
            predictors,
        )
    raise ValueError("mode must be 'latitude' or 'environment'")


def _fit_paper_model(df: pd.DataFrame, response: str, mode: str):
    formula, predictors = _paper_formula(mode)
    needed = [response, "habitat", "autohetero", "species"] + predictors
    sub = df[needed].dropna().copy()
    sub = sub.rename(columns={
        response: "_y",
        "habitat": "_realm",
        "autohetero": "_trophic",
    })
    if len(sub) < 50:
        raise ValueError(f"insufficient rows for {response}/{mode}: {len(sub)}")
    mdl = smf.mixedlm(formula, sub, groups=sub["species"])
    res = _robust_mixedlm_fit(mdl)
    return sub, res, predictors


def _slope_contrast_vector(res, model_df: pd.DataFrame, predictor: str,
                           realm: str | None = None,
                           trophic: str | None = None) -> np.ndarray:
    design_info = res.model.data.design_info
    base = {
        "abs_lat_dec": float(model_df["abs_lat_dec"].mean()) if "abs_lat_dec" in model_df else 0.0,
        "Temp": float(model_df["Temp"].mean()) if "Temp" in model_df else 0.0,
        "Rad": float(model_df["Rad"].mean()) if "Rad" in model_df else 0.0,
        "log_Nenv": float(model_df["log_Nenv"].mean()) if "log_Nenv" in model_df else 0.0,
        "log_Penv": float(model_df["log_Penv"].mean()) if "log_Penv" in model_df else 0.0,
        "_realm": realm or sorted(model_df["_realm"].dropna().unique())[0],
        "_trophic": trophic or sorted(model_df["_trophic"].dropna().unique())[0],
    }
    import patsy
    lo = dict(base)
    hi = dict(base)
    hi[predictor] = lo[predictor] + 1.0
    x_lo = patsy.build_design_matrices([design_info], pd.DataFrame([lo]))[0]
    x_hi = patsy.build_design_matrices([design_info], pd.DataFrame([hi]))[0]
    return np.asarray(x_hi - x_lo, dtype=float).reshape(-1)


def _slope_from_contrast(res, L: np.ndarray) -> dict:
    params = np.asarray(res.fe_params, dtype=float)
    cov = np.asarray(res.cov_params().loc[res.fe_params.index, res.fe_params.index], dtype=float)
    slope = float(L @ params)
    var = float(L @ cov @ L.T)
    se = float(math.sqrt(max(var, 0.0)))
    z = float(slope / se) if se > 0 else float("nan")
    p = float(2.0 * norm.sf(abs(z))) if math.isfinite(z) else float("nan")
    return {"slope": slope, "std_err": se, "z": z, "p_value": p}


def _marginal_slope(res, model_df: pd.DataFrame, predictor: str,
                    realm: str | None = None, trophic: str | None = None) -> dict:
    L = _slope_contrast_vector(res, model_df, predictor, realm, trophic)
    return _slope_from_contrast(res, L)


@mcp.tool()
def paper_lmm_slope_table(
    csv_path: str,
    responses: list[str] | None = None,
    modes: list[str] | None = None,
) -> dict:
    """Fit the paper-aligned six LMMs and return marginal slope rows.

    Latitude models use one continuous predictor, absolute latitude.
    Environmental-driver models fit temperature, radiation, log(N deposition)
    and log(labile P) jointly. Both model families include habitat,
    autohetero, continuous-predictor-by-habitat terms,
    continuous-predictor-by-autohetero terms, habitat:autohetero, and a
    species/morphospecies random intercept, matching the archived R notebook
    structure. P-values are normal-approximation Wald p-values with BH
    adjustment over the returned slope tests.
    """
    if not os.path.exists(csv_path):
        return {"error": f"File not found: {csv_path}"}
    df = _paper_base_dataframe(csv_path)
    response_map = {
        "logit_pN": "organismal_percent_N",
        "logit_pP": "organismal_percent_P",
        "log_NP": "organismal_N_to_P_ratio",
    }
    responses = responses or list(response_map)
    modes = modes or ["latitude", "environment"]
    rows = []
    model_summaries = []
    for response in responses:
        for mode in modes:
            model_df, res, predictors = _fit_paper_model(df, response, mode)
            model_summaries.append({
                "response": response,
                "response_label": response_map.get(response, response),
                "mode": mode,
                "n_obs": int(len(model_df)),
                "n_species": int(model_df["species"].nunique()),
                "formula": str(res.model.formula),
                "converged": bool(getattr(res, "converged", True)),
            })
            realms = sorted(model_df["_realm"].dropna().unique().tolist())
            trophics = sorted(model_df["_trophic"].dropna().unique().tolist())
            for predictor in predictors:
                cell_slopes = []
                cell_contrasts = []
                for realm in realms:
                    for trophic in trophics:
                        L = _slope_contrast_vector(res, model_df, predictor, realm, trophic)
                        slope = _slope_from_contrast(res, L)
                        n_cell = int(((model_df["_realm"] == realm) &
                                      (model_df["_trophic"] == trophic)).sum())
                        row = {
                            "response": response,
                            "response_label": response_map.get(response, response),
                            "mode": mode,
                            "predictor": predictor,
                            "scope": "cell",
                            "cell": f"{realm}|{trophic}",
                            "habitat": realm,
                            "autohetero": trophic,
                            "n_obs": n_cell,
                            **slope,
                        }
                        rows.append(row)
                        cell_slopes.append(slope)
                        cell_contrasts.append(L)
                pooled_L = np.nanmean(np.vstack(cell_contrasts), axis=0)
                pooled = _slope_from_contrast(res, pooled_L)
                rows.append({
                    "response": response,
                    "response_label": response_map.get(response, response),
                    "mode": mode,
                    "predictor": predictor,
                    "scope": "pooled_marginal_equal_cell",
                    "cell": "all",
                    "habitat": "all",
                    "autohetero": "all",
                    "n_obs": int(len(model_df)),
                    **pooled,
                })
    adjusted = _bh_adjust([r["p_value"] for r in rows])
    for row, adj in zip(rows, adjusted):
        row["bh_p_value"] = adj
        row["significant_bh_0_05"] = bool(np.isfinite(adj) and adj < 0.05)
        row["direction"] = "positive" if row["slope"] > 0 else "negative" if row["slope"] < 0 else "zero"
    return {"rows": rows, "model_summaries": model_summaries}


@mcp.tool()
def paper_main_conclusion_summary(csv_path: str) -> dict:
    """Summarize the key paper-aligned model conclusions from slope rows."""
    table = paper_lmm_slope_table(csv_path)
    if "error" in table:
        return table
    rows = table["rows"]
    env_pooled = [
        r for r in rows
        if r["mode"] == "environment" and r["scope"] == "pooled_marginal_equal_cell"
    ]
    by_predictor: dict[str, dict] = {}
    for predictor in ["Temp", "Rad", "log_Nenv", "log_Penv"]:
        subset = [r for r in env_pooled if r["predictor"] == predictor]
        by_predictor[predictor] = {
            "n_tests": len(subset),
            "n_bh_significant": sum(1 for r in subset if r["significant_bh_0_05"]),
            "directions": [r["direction"] for r in subset],
            "responses": [r["response"] for r in subset],
        }
    strongest = sorted(
        by_predictor.items(),
        key=lambda kv: (kv[1]["n_bh_significant"], kv[0] == "log_Nenv"),
        reverse=True,
    )[0][0] if by_predictor else None
    return {
        "paper_aligned_model_counts": table["model_summaries"],
        "environment_pooled_predictor_summary": by_predictor,
        "most_consistent_environmental_predictor": strongest,
        "interpretation": (
            "Nitrogen deposition should emerge as the most consistent "
            "environmental predictor if log_Nenv has the strongest pattern "
            "of positive/significant N and N:P responses, while temperature, "
            "radiation and labile P remain weaker or inconsistent."
        ),
    }


@mcp.tool()
def paper_permutation_slope_test(
    csv_path: str,
    response: str,
    mode: str,
    predictor: str,
    n_permutations: int = 1000,
    seed: int = 0,
) -> dict:
    """Approximate the source notebook's permutation p-value route.

    For the selected paper model, fit the original model, extract pooled and
    per-cell marginal slope z statistics, then repeatedly permute the selected
    predictor by location identity and refit. The empirical two-sided p-value
    is the fraction of permuted |z| values at least as large as the observed
    |z|. This exposes the paper's inference path without forcing every smoke
    test to run all six models x 1000 permutations.
    """
    if not os.path.exists(csv_path):
        return {"error": f"File not found: {csv_path}"}
    rng = np.random.default_rng(seed)
    df = _paper_base_dataframe(csv_path)
    model_df, res, predictors = _fit_paper_model(df, response, mode)
    if predictor not in predictors:
        return {"error": f"predictor {predictor!r} not in {mode} predictors {predictors}"}
    realms = sorted(model_df["_realm"].dropna().unique().tolist())
    trophics = sorted(model_df["_trophic"].dropna().unique().tolist())
    tests = []
    contrasts = []
    labels = []
    for realm in realms:
        for trophic in trophics:
            L = _slope_contrast_vector(res, model_df, predictor, realm, trophic)
            tests.append(_slope_from_contrast(res, L))
            contrasts.append(L)
            labels.append(f"{realm}|{trophic}")
    pooled_L = np.nanmean(np.vstack(contrasts), axis=0)
    tests.append(_slope_from_contrast(res, pooled_L))
    contrasts.append(pooled_L)
    labels.append("all")

    perm_abs_z = {label: [] for label in labels}
    # Match MacroStoichiometry.R's permutation unit:
    # latitude models group by abs_lat.dec and shuffle the location id assigned
    # to each unique latitude; environmental models group by the full
    # (Temp, Rad, N, P) environmental vector and shuffle that vector as a unit.
    if mode == "latitude":
        unique_lat = model_df[["abs_lat_dec"]].drop_duplicates().reset_index(drop=True)

        def make_permuted_frame() -> pd.DataFrame:
            shuffled = unique_lat["abs_lat_dec"].to_numpy().copy()
            rng.shuffle(shuffled)
            mapping = dict(zip(unique_lat["abs_lat_dec"], shuffled))
            permuted = df.copy()
            permuted["abs_lat_dec"] = permuted["abs_lat_dec"].map(mapping)
            return permuted

    else:
        env_cols = ["Temp", "Rad", "log_Nenv", "log_Penv"]
        unique_env = model_df[env_cols].drop_duplicates().reset_index(drop=True)

        def make_permuted_frame() -> pd.DataFrame:
            order = np.arange(len(unique_env))
            rng.shuffle(order)
            shuffled = unique_env.iloc[order].reset_index(drop=True)
            key = unique_env.copy()
            key["_perm_id"] = np.arange(len(key))
            permuted = df.merge(key, on=env_cols, how="left")
            for col in env_cols:
                permuted[col] = permuted["_perm_id"].map(shuffled[col].to_dict())
            return permuted.drop(columns=["_perm_id"])

    for _ in range(int(n_permutations)):
        permuted = make_permuted_frame()
        try:
            perm_df, perm_res, _ = _fit_paper_model(permuted, response, mode)
            for label in labels:
                if label == "all":
                    perm_contrasts = [
                        _slope_contrast_vector(perm_res, perm_df, predictor, r, t)
                        for r in realms for t in trophics
                    ]
                    L = np.nanmean(np.vstack(perm_contrasts), axis=0)
                else:
                    r, t = label.split("|", 1)
                    L = _slope_contrast_vector(perm_res, perm_df, predictor, r, t)
                stat = _slope_from_contrast(perm_res, L)
                perm_abs_z[label].append(abs(stat["z"]))
        except Exception:
            continue

    rows = []
    for label, obs in zip(labels, tests):
        null = np.asarray(perm_abs_z[label], dtype=float)
        p_emp = float((np.sum(null >= abs(obs["z"])) + 1.0) / (len(null) + 1.0)) if len(null) else float("nan")
        rows.append({
            "response": response,
            "mode": mode,
            "predictor": predictor,
            "cell": label,
            "scope": "pooled_marginal_equal_cell" if label == "all" else "cell",
            **obs,
            "permutation_p_value": p_emp,
            "n_successful_permutations": int(len(null)),
        })
    adjusted = _bh_adjust([r["permutation_p_value"] for r in rows])
    for row, adj in zip(rows, adjusted):
        row["permutation_bh_p_value"] = adj
        row["permutation_significant_bh_0_05"] = bool(np.isfinite(adj) and adj < 0.05)
    return {"rows": rows, "n_permutations_requested": int(n_permutations)}


@mcp.tool()
def correlation(x_values: list, y_values: list, method: str = "spearman") -> dict:
    """Compute Pearson or Spearman correlation between two numeric arrays.

    Args:
        x_values: First variable.
        y_values: Second variable.
        method: 'pearson' or 'spearman'.

    Returns:
        dict with coefficient, p-value, n.
    """
    x, y = _clean_xy(x_values, y_values)
    if len(x) < 3:
        return {"error": "need at least 3 paired non-null observations"}
    if method == "pearson":
        r, p = pearsonr(x, y)
    else:
        r, p = spearmanr(x, y)
    return {
        "method": method,
        "coefficient": round(float(r), 4),
        "p_value": float(p),
        "n": int(len(x)),
    }


@mcp.tool()
def correlation_table(
    csv_path: str,
    columns: list,
    method: str = "spearman",
) -> dict:
    """Pairwise correlations among a list of numeric columns.

    Args:
        csv_path: Path to CSV file.
        columns: List of numeric column names.
        method: 'pearson' or 'spearman'.

    Returns:
        dict with matrix-form correlations and p-values.
    """
    if not os.path.exists(csv_path):
        return {"error": f"File not found: {csv_path}"}
    df = pd.read_csv(csv_path)
    missing = [c for c in columns if c not in df.columns]
    if missing:
        return {"error": f"Missing columns: {missing}"}
    sub = df[columns].astype(float)
    pairs: dict[str, dict] = {}
    for i, a in enumerate(columns):
        for b in columns[i + 1 :]:
            x = sub[a].to_numpy()
            y = sub[b].to_numpy()
            mask = ~(np.isnan(x) | np.isnan(y))
            if mask.sum() < 3:
                continue
            if method == "pearson":
                r, p = pearsonr(x[mask], y[mask])
            else:
                r, p = spearmanr(x[mask], y[mask])
            pairs[f"{a}__{b}"] = {
                "coefficient": round(float(r), 4),
                "p_value": float(p),
                "n": int(mask.sum()),
            }
    return {"method": method, "pairs": pairs}


@mcp.tool()
def ols_regression(x_values: list, y_values: list) -> dict:
    """Simple OLS slope, intercept, R^2, p-value.

    Args:
        x_values: predictor array.
        y_values: response array.

    Returns:
        dict with slope, intercept, r_squared, p_value, n.
    """
    from scipy.stats import linregress

    x, y = _clean_xy(x_values, y_values)
    if len(x) < 3:
        return {"error": "need at least 3 paired observations"}
    res = linregress(x, y)
    return {
        "slope": float(res.slope),
        "intercept": float(res.intercept),
        "r_squared": round(float(res.rvalue ** 2), 4),
        "p_value": float(res.pvalue),
        "stderr": float(res.stderr),
        "n": int(len(x)),
    }


@mcp.tool()
def linear_mixed_model(
    csv_path: str,
    response: str,
    fixed_effects: list,
    group_column: str,
    interactions: list | None = None,
    drop_na: bool = True,
) -> dict:
    """Fit a linear mixed effects model with one random intercept.

    Builds formula:  response ~ fe1 + fe2 + ... [+ interactions] + (1 | group)

    Args:
        csv_path: Path to CSV.
        response: Response column name (already transformed if needed, e.g. logit_pN).
        fixed_effects: List of fixed-effect terms.  Wrap categorical columns as
            "C(habitat)" if you want them treated as factors.
        group_column: Random-intercept grouping column (e.g. species).
        interactions: Optional list of interaction terms, e.g. ["C(habitat):C(autohetero)"].
        drop_na: Whether to drop rows with NaN in any model variable (default True).

    Returns:
        dict with coefficients, standard errors, t/z, p-values, n, and group count.
    """
    if not os.path.exists(csv_path):
        return {"error": f"File not found: {csv_path}"}
    df = pd.read_csv(csv_path)

    rhs = " + ".join(fixed_effects)
    if interactions:
        rhs = rhs + " + " + " + ".join(interactions)
    formula = f"{response} ~ {rhs}"

    # Extract every bare column-name token from the formula (response + RHS) so
    # the NA filter covers every column patsy/statsmodels will touch, including
    # interaction parts and tokens inside C(...) wrappers. This prevents the
    # silent-row-drop bug where unfiltered NaN columns shrink the effective
    # cohort below the reported n_obs.
    formula_tokens = set(re.findall(r"[A-Za-z_][A-Za-z0-9_.]*", formula))
    needed = sorted(formula_tokens.union({group_column}).intersection(df.columns))
    if drop_na:
        df = df.dropna(subset=needed)
    if len(df) < 50:
        return {"error": f"insufficient rows after NA filtering: {len(df)}"}

    # Patsy treats `.` as an operator, so any column name containing dots
    # (e.g. ``lat.dec`` or ``sp.morphosp_revised``) needs to be re-mapped to
    # an underscore alias before the formula is parsed. Build a rename map
    # for every column that appears in the formula (including the response
    # and every fixed-effect / interaction term) and emit a sanitised
    # formula that uses the aliased names.
    def _safe(name: str) -> str:
        return name.replace(".", "_")
    rename_map = {c: _safe(c) for c in needed if "." in c}
    if "." in response:
        rename_map[response] = _safe(response)
    if "." in group_column:
        rename_map[group_column] = _safe(group_column)
    # Always derive a safe grouping column name so downstream code does not
    # depend on the rename_map being non-empty. If the group_column itself
    # contains dots we add it to the rename_map; otherwise safe_group stays
    # equal to group_column and df[safe_group] resolves the original column.
    if "." in group_column and group_column not in rename_map:
        rename_map[group_column] = _safe(group_column)
    if rename_map:
        df = df.rename(columns=rename_map)
        safe_response = rename_map.get(response, response)

        def _sub_term(term: str) -> str:
            for old, new in rename_map.items():
                term = re.sub(rf"\b{re.escape(old)}\b", new, term)
            return term
        safe_rhs = " + ".join(_sub_term(t) for t in fixed_effects)
        if interactions:
            safe_rhs += " + " + " + ".join(_sub_term(t) for t in interactions)
        formula = f"{safe_response} ~ {safe_rhs}"
    safe_group = rename_map.get(group_column, group_column)

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        mdl = smf.mixedlm(formula, df, groups=df[safe_group])
        model = _robust_mixedlm_fit(mdl)
    coef = {}
    for name in model.params.index:
        coef[name] = {
            "estimate": float(model.params[name]),
            "stderr": float(model.bse[name]),
            "t_or_z": float(model.tvalues[name]),
            "p_value": float(model.pvalues[name]),
        }
    return {
        "formula": formula,
        "n_obs": int(len(df)),
        "n_groups": int(df[safe_group].nunique()),
        "coefficients": coef,
        "scale": float(model.scale),
    }


@mcp.tool()
def fit_per_group(
    csv_path: str,
    response: str,
    predictor: str,
    grouping_column: str,
) -> dict:
    """Fit a simple OLS slope (response ~ predictor) within each level of a grouping
    column.  Used to obtain realm- or trophic-group-specific responses.

    Args:
        csv_path: Path to CSV.
        response: Response column.
        predictor: Continuous predictor column.
        grouping_column: Categorical column whose levels are used to subset.

    Returns:
        dict {group_value: {slope, intercept, r_squared, p_value, n}}.
    """
    if not os.path.exists(csv_path):
        return {"error": f"File not found: {csv_path}"}
    df = pd.read_csv(csv_path)
    if any(c not in df.columns for c in [response, predictor, grouping_column]):
        return {"error": "missing column"}
    from scipy.stats import linregress

    out: dict[str, Any] = {}
    for k, sub in df.groupby(grouping_column):
        x = sub[predictor].astype(float).to_numpy()
        y = sub[response].astype(float).to_numpy()
        m = ~(np.isnan(x) | np.isnan(y))
        if m.sum() < 5:
            continue
        r = linregress(x[m], y[m])
        out[str(k)] = {
            "slope": float(r.slope),
            "intercept": float(r.intercept),
            "r_squared": round(float(r.rvalue ** 2), 4),
            "p_value": float(r.pvalue),
            "n": int(m.sum()),
        }
    return {
        "response": response,
        "predictor": predictor,
        "grouping_column": grouping_column,
        "groups": out,
    }


@mcp.tool()
def mixed_model_per_realm_trophic(
    csv_path: str,
    response: str,
    predictor: str,
    realm_column: str = "habitat",
    trophic_column: str = "autohetero",
    species_column: str = "sp.morphosp_revised",
    realms: list = None,
    trophic_groups: list = None,
) -> dict:
    """Fit one linear mixed-effects model per (realm, trophic) combination.

    For each (realm, trophic_group) pair, fit `response ~ predictor` with a species
    random intercept. Returns the per-cell slope/intercept/p_value/n_obs map
    under the ``subgroup_slopes`` key so the return shape matches
    ``mixed_model_interaction_subgroup_slopes`` and ``predictor_panel_slope_table``
    can treat both routes uniformly.

    Args:
        csv_path: input CSV (e.g. the StoichLife subset with abs_lat or
            log_Ndep columns already populated).
        response: response variable (e.g. logit_pN, logit_pP, log_NP).
        predictor: predictor variable (e.g. abs_lat, log_Ndep).
        realm_column / trophic_column / species_column: schema column names.
        realms: subset of realms to include (default: all observed).
        trophic_groups: subset of trophic groups to include.

    Returns:
        dict with keys:
          - ``subgroup_slopes``: {f"{realm}|{trophic}":
                {slope, intercept, p_value, n_obs}}
          - ``response`` / ``predictor`` / ``realm_column`` /
            ``trophic_column`` / ``species_column``: echoed inputs
          - ``n_cells``: number of populated cells
        Or ``{"error": "..."}`` if the input file or schema is invalid.
    """
    if not os.path.exists(csv_path):
        return {"error": f"File not found: {csv_path}"}
    df = pd.read_csv(csv_path)
    for c in (response, predictor, realm_column, trophic_column, species_column):
        if c not in df.columns:
            return {"error": f"missing column: {c}"}
    sub = df[[response, predictor, realm_column, trophic_column, species_column]].dropna()
    realms = realms or list(sub[realm_column].dropna().unique())
    trophic_groups = trophic_groups or list(sub[trophic_column].dropna().unique())
    out = {}
    for r in realms:
        for tg in trophic_groups:
            mask = (sub[realm_column] == r) & (sub[trophic_column] == tg)
            n = int(mask.sum())
            if n < 10:
                out[f"{r}|{tg}"] = {"n_obs": n, "skipped": "too few obs"}
                continue
            sub_g = sub[mask].copy()
            sub_g = sub_g.rename(columns={response: "_y", predictor: "_x", species_column: "_species"})
            try:
                mdl = smf.mixedlm("_y ~ _x", sub_g, groups=sub_g["_species"])
                res = _robust_mixedlm_fit(mdl)
                slope = float(res.params.get("_x", float("nan")))
                p = float(res.pvalues.get("_x", float("nan")))
                intercept = float(res.params.get("Intercept", float("nan")))
                try:
                    std_err = float(res.bse.get("_x", float("nan")))
                except Exception:
                    std_err = float("nan")
                try:
                    z = float(res.tvalues.get("_x", float("nan")))
                except Exception:
                    z = float("nan")
                out[f"{r}|{tg}"] = {
                    "slope": slope,
                    "std_err": std_err,
                    "z": z,
                    "p_value": p,
                    "intercept": intercept,
                    "n_obs": n,
                }
            except Exception as exc:
                out[f"{r}|{tg}"] = {"n_obs": n, "error": str(exc)}

    # Also fit a pooled no-interaction model `response ~ predictor + (1|species)`
    # on the same filtered subset so callers can report pooled slope/SE/p
    # alongside the per-cell refits.
    pooled_slope = float("nan")
    pooled_se = float("nan")
    pooled_p = float("nan")
    pooled_n_obs = int(len(sub))
    if len(sub) >= 50:
        sub_pool = sub.rename(columns={
            response: "_y", predictor: "_x", species_column: "_species",
        })
        try:
            mdl_p = smf.mixedlm("_y ~ _x", sub_pool, groups=sub_pool["_species"])
            res_p = _robust_mixedlm_fit(mdl_p)
            pooled_slope = float(res_p.params.get("_x", float("nan")))
            pooled_se = float(res_p.bse.get("_x", float("nan")))
            pooled_p = float(res_p.pvalues.get("_x", float("nan")))
        except Exception:
            pass

    return {
        "subgroup_slopes": out,
        "pooled_main_slope": pooled_slope,
        "pooled_main_std_err": pooled_se,
        "pooled_main_p_value": pooled_p,
        "pooled_n_obs": pooled_n_obs,
        "response": response,
        "predictor": predictor,
        "realm_column": realm_column,
        "trophic_column": trophic_column,
        "species_column": species_column,
        "n_cells": int(len(out)),
    }


@mcp.tool()
def mixed_model_interaction_subgroup_slopes(
    csv_path: str,
    response: str,
    predictor: str,
    realm_column: str = "habitat",
    trophic_column: str = "autohetero",
    species_column: str = "sp.morphosp_revised",
    realms: list = None,
    trophic_groups: list = None,
) -> dict:
    """Fit ONE linear mixed-effects model with the full three-way interaction
    response ~ predictor * realm * trophic + (1 | species), then for each
    (realm, trophic) cell extract the marginal slope and its delta-method
    standard error and z/p-value.

    This is the paper-methods-aligned alternative to mixed_model_per_realm_trophic
    (which refits separate models per cell). One global model uses all rows,
    so species random intercepts and residual variance are estimated jointly;
    per-cell slopes are derived analytically from the fixed-effect parameter
    vector and covariance matrix.

    Args:
        csv_path: CSV with the StoichLife subset (with abs_lat / log_Ndep /
            logit_pN etc. already populated).
        response: response variable name.
        predictor: predictor variable name (continuous).
        realm_column / trophic_column / species_column: schema column names.
        realms: subset of realms to include; defaults to all observed.
        trophic_groups: subset of trophic groups; defaults to all observed.

    Returns:
        dict with:
          - 'formula': the fitted interaction formula
          - 'n_obs': total rows used after NA filter
          - 'n_groups': number of species random-intercept groups
          - 'pooled_main_slope': the bare predictor coefficient
          - 'subgroup_slopes': {f"{realm}|{trophic}":
                {slope, std_err, z, p_value, n_obs}}
    """
    if not os.path.exists(csv_path):
        return {"error": f"File not found: {csv_path}"}
    df = pd.read_csv(csv_path)
    needed = [response, predictor, realm_column, trophic_column, species_column]
    for c in needed:
        if c not in df.columns:
            return {"error": f"missing column: {c}"}
    sub = df[needed].dropna().copy()
    realms = realms or sorted(sub[realm_column].dropna().unique().tolist())
    trophic_groups = trophic_groups or sorted(sub[trophic_column].dropna().unique().tolist())
    sub = sub[sub[realm_column].isin(realms) & sub[trophic_column].isin(trophic_groups)]
    if len(sub) < 50:
        return {"error": f"insufficient rows after filter: {len(sub)}"}

    # Rename to safe formula identifiers (response/predictor names may contain
    # dots, e.g. "lat.dec"; patsy treats dots as operators).
    sub = sub.rename(columns={
        response: "_y",
        predictor: "_x",
        realm_column: "_realm",
        trophic_column: "_trophic",
        species_column: "_species",
    })
    formula = "_y ~ _x * C(_realm) * C(_trophic)"
    try:
        mdl = smf.mixedlm(formula, sub, groups=sub["_species"])
        res = _robust_mixedlm_fit(mdl)
    except Exception as exc:
        return {"error": f"mixedlm fit failed: {exc}"}

    params = res.params
    cov = res.cov_params()
    # Establish the reference levels statsmodels picked (alphabetical first).
    ref_realm = sorted(sub["_realm"].unique())[0]
    ref_trophic = sorted(sub["_trophic"].unique())[0]
    # Slope-component names patsy emits for the interactions:
    def slope_components(realm_val: str, trophic_val: str) -> list[str]:
        names = ["_x"]
        if realm_val != ref_realm:
            names.append(f"_x:C(_realm)[T.{realm_val}]")
        if trophic_val != ref_trophic:
            names.append(f"_x:C(_trophic)[T.{trophic_val}]")
        if realm_val != ref_realm and trophic_val != ref_trophic:
            names.append(
                f"_x:C(_realm)[T.{realm_val}]:C(_trophic)[T.{trophic_val}]"
            )
        return names

    subgroup_out: dict[str, Any] = {}
    for r in realms:
        for tg in trophic_groups:
            comps = slope_components(r, tg)
            available = [c for c in comps if c in params.index]
            if not available:
                subgroup_out[f"{r}|{tg}"] = {
                    "skipped": "no parameters for cell",
                }
                continue
            slope = float(sum(float(params[c]) for c in available))
            # variance of the sum of components via covariance matrix
            sub_cov = cov.loc[available, available].to_numpy(dtype=float)
            var = float(sub_cov.sum())
            std_err = float(math.sqrt(max(var, 0.0)))
            z = float(slope / std_err) if std_err > 0 else float("nan")
            # Two-sided normal approximation
            from math import erf, sqrt
            p_value = float(2.0 * (1.0 - 0.5 * (1.0 + erf(abs(z) / sqrt(2.0)))))
            n_cell = int(((sub["_realm"] == r) & (sub["_trophic"] == tg)).sum())
            subgroup_out[f"{r}|{tg}"] = {
                "slope": slope,
                "std_err": std_err,
                "z": z,
                "p_value": p_value,
                "n_obs": n_cell,
                "components": available,
            }

    # The bare "_x" coefficient from a treatment-coded interaction model is
    # the slope for the *reference* (realm, trophic) cell, NOT a pooled
    # marginal slope across all freshwater+terrestrial records. Compute the
    # true pooled main effect by also fitting a no-interaction model
    # (response ~ predictor + (1 | species)) on the same filtered subset.
    pooled_ref_slope = float(params.get("_x", float("nan")))
    try:
        pooled_ref_se = float(res.bse.get("_x", float("nan")))
    except Exception:
        pooled_ref_se = float("nan")
    try:
        pooled_ref_p = float(res.pvalues.get("_x", float("nan")))
    except Exception:
        pooled_ref_p = float("nan")

    pooled_no_int_slope = float("nan")
    pooled_no_int_se = float("nan")
    pooled_no_int_p = float("nan")
    try:
        mdl_pool = smf.mixedlm("_y ~ _x", sub, groups=sub["_species"])
        res_pool = _robust_mixedlm_fit(mdl_pool)
        pooled_no_int_slope = float(res_pool.params.get("_x", float("nan")))
        pooled_no_int_se = float(res_pool.bse.get("_x", float("nan")))
        pooled_no_int_p = float(res_pool.pvalues.get("_x", float("nan")))
    except Exception:
        pass

    return {
        "formula": formula.replace("_y", response).replace("_x", predictor)
                          .replace("_realm", realm_column)
                          .replace("_trophic", trophic_column),
        "n_obs": int(len(sub)),
        "n_groups": int(sub["_species"].nunique()),
        # Backwards-compatible: pooled_main_slope is the no-interaction
        # pooled marginal slope (this is the value most users expect).
        "pooled_main_slope": pooled_no_int_slope,
        "pooled_main_std_err": pooled_no_int_se,
        "pooled_main_p_value": pooled_no_int_p,
        # The reference-cell slope from the interaction model is exposed
        # separately so analyses that need both can recover it.
        "interaction_reference_cell_slope": pooled_ref_slope,
        "interaction_reference_cell_std_err": pooled_ref_se,
        "interaction_reference_cell_p_value": pooled_ref_p,
        "subgroup_slopes": subgroup_out,
    }


@mcp.tool()
def predictor_panel_slope_table(
    csv_path: str,
    response: str,
    predictors: list,
    realm_column: str = "habitat",
    trophic_column: str = "autohetero",
    species_column: str = "sp.morphosp_revised",
    realms: list = None,
    trophic_groups: list = None,
    use_interaction: bool = True,
) -> dict:
    """Run mixed_model_interaction_subgroup_slopes (or
    mixed_model_per_realm_trophic, when ``use_interaction=False``) once per
    predictor in ``predictors`` and assemble a single per-predictor x
    per-(realm, trophic) slope table.

    For each predictor the per-cell slope, std_err and p_value are pulled
    from the subgroup_slopes block; the pooled slope (the ``_x`` main effect
    in the interaction model, or the per-cell slope in the per-cell route)
    is also reported. The function also computes, across the predictors,
    which one has the largest fraction of cells with consistent slope sign
    among the cells where the slope passes p<0.05 — a process answer to
    "which predictor is most consistently directional on the bundled data".

    Args:
        csv_path: input CSV with the StoichLife subset.
        response: response column (logit_pN / logit_pP / log_NP).
        predictors: list of continuous predictor column names. Use abs_lat,
            log_Ndep, temperature, radiation, log_P_soil to cover the five
            environmental axes referenced by the benchmark.
        realm_column / trophic_column / species_column: schema column names.
        realms / trophic_groups: subset filters (default: all observed).
        use_interaction: if True (default), use the single-interaction-model
            route; otherwise use separate per-cell refits.

    Returns:
        dict {
          "per_predictor": {predictor_name: subgroup_slopes_block},
          "pooled_main_slopes": {predictor_name: pooled slope from interaction model},
          "most_consistent_predictor": str  # by fraction-of-cells-same-sign-and-sig,
          "consistency_table": [{predictor, n_cells, n_significant, n_same_sign_significant, fraction_same_sign}]
        }
    """
    per_pred: dict[str, Any] = {}
    pooled: dict[str, dict] = {}
    summaries = []
    for p in predictors:
        if use_interaction:
            out = mixed_model_interaction_subgroup_slopes(
                csv_path, response, p,
                realm_column=realm_column,
                trophic_column=trophic_column,
                species_column=species_column,
                realms=realms, trophic_groups=trophic_groups,
            )
        else:
            sgrp_out = mixed_model_per_realm_trophic(
                csv_path, response, p,
                realm_column=realm_column,
                trophic_column=trophic_column,
                species_column=species_column,
                realms=realms, trophic_groups=trophic_groups,
            )
            # mixed_model_per_realm_trophic now returns
            # {subgroup_slopes: {...}, response: ..., predictor: ..., ...}
            # or {"error": "..."}.
            if isinstance(sgrp_out, dict) and "error" in sgrp_out:
                out = {"error": sgrp_out["error"]}
            else:
                out = {
                    "subgroup_slopes": sgrp_out.get("subgroup_slopes", {}),
                    "pooled_main_slope": sgrp_out.get("pooled_main_slope"),
                    "pooled_main_std_err": sgrp_out.get("pooled_main_std_err"),
                    "pooled_main_p_value": sgrp_out.get("pooled_main_p_value"),
                }
        if "error" in out:
            per_pred[p] = out
            continue
        per_pred[p] = out["subgroup_slopes"]
        pooled[p] = {
            "slope": out.get("pooled_main_slope"),
            "std_err": out.get("pooled_main_std_err"),
            "p_value": out.get("pooled_main_p_value"),
        }
        sigs = []
        for cell, blk in out["subgroup_slopes"].items():
            if isinstance(blk, dict) and "slope" in blk and "p_value" in blk:
                sigs.append((blk["slope"], blk["p_value"]))
        n_cells = len(sigs)
        n_sig = sum(1 for s, pv in sigs if (pv is not None) and pv < 0.05)
        if n_sig > 0:
            pos = sum(1 for s, pv in sigs if pv is not None and pv < 0.05 and s > 0)
            neg = n_sig - pos
            n_same = max(pos, neg)
            frac = float(n_same) / float(n_sig)
        else:
            frac = 0.0
            n_same = 0
        summaries.append({
            "predictor": p,
            "n_cells": int(n_cells),
            "n_significant": int(n_sig),
            "n_same_sign_significant": int(n_same),
            "fraction_same_sign_among_significant": round(frac, 4),
        })
    summaries.sort(
        key=lambda r: (r["fraction_same_sign_among_significant"],
                       r["n_same_sign_significant"]),
        reverse=True,
    )
    most_consistent = summaries[0]["predictor"] if summaries else None

    # Flat row-wise table: one row per (predictor, cell).
    rows = []
    for pred, cells in per_pred.items():
        if not isinstance(cells, dict) or "error" in cells:
            continue
        for cell_key, blk in cells.items():
            if not isinstance(blk, dict) or "slope" not in blk:
                continue
            if "|" in cell_key:
                realm_val, trophic_val = cell_key.split("|", 1)
            else:
                realm_val, trophic_val = cell_key, ""
            rows.append({
                "predictor": pred,
                "cell": cell_key,
                "realm": realm_val,
                "trophic": trophic_val,
                "slope": blk.get("slope"),
                "std_err": blk.get("std_err"),
                "p_value": blk.get("p_value"),
                "n_obs": blk.get("n_obs"),
            })

    return {
        # per_predictor[predictor] is the cell-keyed {realm|trophic: {slope, std_err, p_value, ...}}
        # block; this is also the shape that plot_latitude_response /
        # plot_ndep_response consume as the mixed_slopes keyword argument.
        "per_predictor": per_pred,
        "pooled_main_slopes": pooled,
        "most_consistent_predictor": most_consistent,
        "consistency_table": summaries,
        "rows": rows,
    }



@mcp.tool()
def two_pair_slope_table(
    csv_path: str,
    pairs: list,
    realm_column: str = "habitat",
    trophic_column: str = "autohetero",
    species_column: str = "sp.morphosp_revised",
    use_interaction: bool = True,
) -> dict:
    """Emit the final benchmark slope table for a list of (response, predictor)
    pairs on a single filtered cohort CSV.

    For each pair, runs the chosen route (interaction or per-cell) and
    returns one row per (response, predictor, scope, cell), where scope is
    either "pooled" (one row with cell="all") or "per_cell" (one row per
    realm|trophic). Each row reports slope, std_err, p_value, n_obs.

    Args:
        csv_path: filtered cohort CSV with the required transformed columns
            already populated (e.g. logit_pN, logit_pP, abs_lat, log_Ndep).
        pairs: list of two-tuples (response, predictor) — e.g.
            [("logit_pN", "log_Ndep"), ("logit_pP", "abs_lat")].
        realm_column / trophic_column / species_column: schema names.
        use_interaction: True → use mixed_model_interaction_subgroup_slopes
            (single interaction model per pair, marginal slopes by algebra);
            False → use mixed_model_per_realm_trophic (separate per-cell refits).

    Returns:
        dict {
          "rows": [
            {response, predictor, scope, cell, slope, std_err, p_value, n_obs},
            ...
          ],
          "by_pair": {"<response>__<predictor>": {pooled: {...}, per_cell: {cell: {...}}}}
        }
    """
    rows: list = []
    by_pair: dict = {}
    for entry in pairs:
        if isinstance(entry, dict):
            response = entry.get("response")
            predictor = entry.get("predictor")
        else:
            try:
                response, predictor = entry
            except Exception:
                continue
        if not response or not predictor:
            continue
        if use_interaction:
            out = mixed_model_interaction_subgroup_slopes(
                csv_path, response, predictor,
                realm_column=realm_column,
                trophic_column=trophic_column,
                species_column=species_column,
            )
        else:
            out = mixed_model_per_realm_trophic(
                csv_path, response, predictor,
                realm_column=realm_column,
                trophic_column=trophic_column,
                species_column=species_column,
            )
        key = f"{response}__{predictor}"
        if isinstance(out, dict) and "error" in out:
            by_pair[key] = {"error": out["error"]}
            continue
        pooled_slope = out.get("pooled_main_slope")
        pooled_se = out.get("pooled_main_std_err")
        pooled_p = out.get("pooled_main_p_value")
        # The interaction route returns top-level "n_obs"; the per-cell route
        # returns "pooled_n_obs" (because its top level holds per-cell maps).
        # Fall through both so neither route silently reports 0.
        pooled_n = int(out.get("n_obs") or out.get("pooled_n_obs") or 0)
        rows.append({
            "response": response,
            "predictor": predictor,
            "scope": "pooled",
            "cell": "all",
            "slope": pooled_slope,
            "std_err": pooled_se,
            "p_value": pooled_p,
            "n_obs": pooled_n,
        })
        cells = out.get("subgroup_slopes") or {}
        per_cell_out: dict = {}
        for cell_key, blk in cells.items():
            if not isinstance(blk, dict) or "slope" not in blk:
                continue
            rows.append({
                "response": response,
                "predictor": predictor,
                "scope": "per_cell",
                "cell": cell_key,
                "slope": blk.get("slope"),
                "std_err": blk.get("std_err"),
                "p_value": blk.get("p_value"),
                "n_obs": int(blk.get("n_obs") or 0),
            })
            per_cell_out[cell_key] = blk
        by_pair[key] = {
            "pooled": {
                "slope": pooled_slope,
                "std_err": pooled_se,
                "p_value": pooled_p,
                "n_obs": pooled_n,
            },
            "per_cell": per_cell_out,
        }
    return {"rows": rows, "by_pair": by_pair}


if __name__ == "__main__":
    mcp.run()

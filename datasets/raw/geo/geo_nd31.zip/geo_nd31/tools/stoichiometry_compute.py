#!/usr/bin/env python3
"""
Stoichiometric ratio computation utilities.
- Convert %N, %P (mass dry-mass percentages) to molar N:P ratio.
- Logit / log transforms required by the published Methods.
- Group-wise summaries (mean, range, count) by realm and trophic group.
"""

from __future__ import annotations

import math
import os
from typing import Any

import numpy as np
import pandas as pd
from scipy.special import expit, logit
try:
    from mcp.server.fastmcp import FastMCP
except Exception:
    class FastMCP:
        def __init__(self, *args, **kwargs):
            pass
        def tool(self):
            def decorator(func):
                return func
            return decorator
        def run(self, *args, **kwargs):
            return None

mcp = FastMCP("Stoichiometry_Compute")

# Atomic weights (g/mol) for converting mass-percent -> moles
_M_N = 14.007
_M_P = 30.974


def _safe_float(x: float) -> float | None:
    if x is None:
        return None
    f = float(x)
    if math.isnan(f) or math.isinf(f):
        return None
    return f


@mcp.tool()
def molar_np_from_mass_percent(percent_n: float, percent_p: float) -> dict:
    """Convert dry-mass percent N and P to molar N:P ratio.

    n_moles = (mass_percent_N / 100) / atomic_mass_N
    p_moles = (mass_percent_P / 100) / atomic_mass_P
    N:P    = n_moles / p_moles

    Args:
        percent_n: %N of dry mass (0-100).
        percent_p: %P of dry mass (0-100).

    Returns:
        dict with mass_ratio, molar_ratio, atomic masses used.
    """
    pn = _safe_float(percent_n)
    pp = _safe_float(percent_p)
    if pn is None or pp is None or pp <= 0:
        return {"error": "percent_n and percent_p must be positive numbers"}
    mass_ratio = pn / pp
    n_mol = (pn / 100.0) / _M_N
    p_mol = (pp / 100.0) / _M_P
    return {
        "mass_ratio_N_over_P": round(mass_ratio, 4),
        "molar_ratio_N_over_P": round(n_mol / p_mol, 4),
        "atomic_mass_N": _M_N,
        "atomic_mass_P": _M_P,
    }


@mcp.tool()
def add_environmental_transforms(
    csv_path: str,
    output_csv: str,
    lat_column: str = "lat.dec",
    temp_column: str = "temperature",
    rad_column: str = "radiation",
    ndep_column: str = "N",
    p_soil_column: str = "P_ter",
) -> dict:
    """Add absolute latitude and natural-log transforms of environmental axes.

    The published Methods (and the task instruction) require the four mixed-model
    environmental predictors are abs_lat, temperature, radiation (entered untransformed),
    and log_Ndep / log_P_soil (the two skewed axes the paper Methods log-transform). This helper appends those columns so the
    downstream plotting and MixedLM tools can consume them directly.

    Args:
        csv_path: Input CSV with raw environmental columns.
        output_csv: Output path for the CSV with transformed columns appended.
        lat_column / temp_column / rad_column / ndep_column / p_soil_column:
            Source column names (defaults match the bundled CSV schema).

    Returns:
        dict with output path and per-column counts of valid transformed rows.
    """
    if not os.path.exists(csv_path):
        return {"error": f"File not found: {csv_path}"}
    df = pd.read_csv(csv_path)
    out = df.copy()
    src_to_log = {
        ndep_column: "log_Ndep",  # plotting.plot_ndep_response alias
        p_soil_column: "log_P_soil",
    }
    if lat_column in out.columns:
        out["abs_lat"] = out[lat_column].astype(float).abs()
    for src, new in src_to_log.items():
        if src in out.columns:
            arr = out[src].astype(float).where(out[src] > 0)
            out[new] = np.log(arr)
    os.makedirs(os.path.dirname(output_csv) or ".", exist_ok=True)
    out.to_csv(output_csv, index=False)
    return {
        "output_csv": output_csv,
        "n_rows": int(len(out)),
        "columns_added": [c for c in ("abs_lat", "log_Ndep", "log_P_soil") if c in out.columns],
    }


@mcp.tool()
def add_logit_log_columns(
    csv_path: str,
    output_csv: str,
    n_column: str = "taxa.n",
    p_column: str = "taxa.p",
    np_column: str = "taxa.np",
    eps: float = 1e-6,
) -> dict:
    """Add logit-transformed %N, %P and log-transformed N:P columns.

    Methods text states %N and %P are bounded in (0,100) and were modelled on
    the logit scale (with logits computed on the fraction p in (0,1)).
    N:P was log-transformed.

    Args:
        csv_path: Path to a CSV with %N, %P, N:P columns (typical %values 0-100).
        output_csv: Path to write the new CSV with logit/log columns appended.
        n_column: Column name for %N.
        p_column: Column name for %P.
        np_column: Column name for N:P molar ratio.
        eps: Numerical floor used to clip the fraction before logit (default 1e-6).

    Returns:
        dict with output path and counts of valid transformed rows per column.
    """
    if not os.path.exists(csv_path):
        return {"error": f"File not found: {csv_path}"}
    df = pd.read_csv(csv_path)

    def _logit_pct(s: pd.Series) -> pd.Series:
        """Map a 0-100 percentage to logit scale.

        Rows whose percentage falls outside the valid (0, 100) open
        interval are MASKED to NaN rather than clipped to ``eps``; clipping
        would compress invalid values onto a finite logit at ±log(1/eps - 1),
        producing spurious outliers in the downstream mixed-effects fits.
        """
        arr = s.astype(float)
        frac = arr / 100.0
        valid = (frac > 0.0) & (frac < 1.0)
        # Clip valid rows away from the boundary so logit is finite.
        clipped = frac.where(valid).clip(eps, 1.0 - eps)
        logit_vals = pd.Series(
            np.where(valid, logit(clipped.to_numpy()), np.nan),
            index=s.index,
        )
        return logit_vals

    out = df.copy()
    if n_column in out.columns:
        out["logit_pN"] = _logit_pct(out[n_column])
    if p_column in out.columns:
        out["logit_pP"] = _logit_pct(out[p_column])
    if np_column in out.columns:
        np_arr = out[np_column].astype(float).where(out[np_column] > 0)
        out["log_NP"] = np.log(np_arr)

    os.makedirs(os.path.dirname(output_csv) or ".", exist_ok=True)
    out.to_csv(output_csv, index=False)
    counts = {
        "logit_pN_valid": int(out.get("logit_pN", pd.Series(dtype=float)).notna().sum()),
        "logit_pP_valid": int(out.get("logit_pP", pd.Series(dtype=float)).notna().sum()),
        "log_NP_valid": int(out.get("log_NP", pd.Series(dtype=float)).notna().sum()),
    }
    return {
        "output_csv": output_csv,
        "n_rows": int(len(out)),
        "counts": counts,
        "columns_added": [c for c in ("logit_pN", "logit_pP", "log_NP") if c in out.columns],
    }


@mcp.tool()
def group_summary(
    csv_path: str,
    group_columns: list,
    value_columns: list,
) -> dict:
    """Compute mean, median, min, max and count per group for selected columns.

    Args:
        csv_path: Path to CSV.
        group_columns: List of grouping columns, e.g. ["habitat","autohetero"].
        value_columns: List of numeric columns to summarise (NaN-aware).

    Returns:
        dict {group_key: {value_col: {mean, median, min, max, n}}}.
    """
    if not os.path.exists(csv_path):
        return {"error": f"File not found: {csv_path}"}
    df = pd.read_csv(csv_path)
    missing = [c for c in group_columns + value_columns if c not in df.columns]
    if missing:
        return {"error": f"Columns missing: {missing}"}
    grp = df.groupby(group_columns)
    out: dict[str, Any] = {}
    for keys, sub in grp:
        if not isinstance(keys, tuple):
            keys = (keys,)
        gkey = " | ".join(str(k) for k in keys)
        out[gkey] = {}
        for v in value_columns:
            arr = sub[v].astype(float).dropna()
            out[gkey][v] = {
                "n": int(len(arr)),
                "mean": round(float(arr.mean()), 4) if len(arr) else None,
                "median": round(float(arr.median()), 4) if len(arr) else None,
                "min": round(float(arr.min()), 4) if len(arr) else None,
                "max": round(float(arr.max()), 4) if len(arr) else None,
            }
    return {"groups": out, "n_groups": len(out)}


@mcp.tool()
def back_transform_logit(logit_value: float, scale: float = 100.0) -> dict:
    """Back-transform a logit-scale prediction to percent dry mass.

    pct = scale * exp(y) / (1 + exp(y))

    Args:
        logit_value: Value on logit scale.
        scale: Multiplier (default 100 to obtain percent).

    Returns:
        dict with percent value.
    """
    val = _safe_float(logit_value)
    if val is None:
        return {"error": "logit_value must be a finite number"}
    pct = scale * float(expit(val))
    return {"percent": round(pct, 4)}


@mcp.tool()
def back_transform_log(log_value: float) -> dict:
    """Back-transform a log-scale prediction (e.g. log(N:P)).

    Args:
        log_value: Natural-log-scale prediction.

    Returns:
        dict with linear-scale value.
    """
    val = _safe_float(log_value)
    if val is None:
        return {"error": "log_value must be a finite number"}
    return {"value": round(float(np.exp(val)), 4)}


if __name__ == "__main__":
    mcp.run()

# geo_nd31 Tools

Generic ecological-stoichiometry analysis primitives delivered as four MCP servers.

## Files

| File                          | MCP server name              | Purpose |
|-------------------------------|------------------------------|---------|
| `data_loading.py`             | Stoichiometry_Data_Loading   | List xlsx sheets, read sheets, filter rows, summarise columns |
| `stoichiometry_compute.py`    | Stoichiometry_Compute        | Mass-percent to molar conversions, logit/log transforms, group summaries, back-transforms |
| `statistical_analysis.py`     | Stoichiometry_Statistics     | Pearson/Spearman correlations, OLS regression, paper-aligned linear mixed-effect models with species random intercept, marginal slope extraction, BH/FDR flags |
| `plotting.py`                 | Stoichiometry_Plotting       | Sampling-site map, latitude vs response 2x2 panel, log(N deposition) vs response 2x2 panel, slope-comparison forest plot |

## Dependencies

```
mcp
numpy
pandas
scipy
statsmodels
matplotlib
openpyxl
```

Install with:

```bash
pip install mcp numpy pandas scipy statsmodels matplotlib openpyxl
```

## Run a server

```bash
python3 tools/data_loading.py
```

Each tool registers itself with the local MCP runtime.  Tools are deliberately
general-purpose primitives: filenames, column names, transformations, predictor
sets, and plot paths are passed in as arguments rather than hard-coded, so the
same tool can be reused across stoichiometry datasets, not only StoichLife.

## Output artefacts

The plotting tools write PNG figures to absolute paths supplied by the caller.
For the StoichLife task the agent is expected to place outputs under
`artifacts/`:

* `Fig1_sites_map.png` - global sampling site distribution by realm and trophic group
* `Fig2_latitude_logitP.png` - logit %P vs absolute latitude per realm-trophic panel
* `Fig3_Ndep_logitN.png` - logit %N vs log(N deposition) per realm-trophic panel

## Paper-Aligned Route

The canonical route is the original Nature Communications analysis, not a
simplified univariate substitute. The bundle includes the archived source
notebook at `input_data/data/source_code/MacroStoichiometry.R`; the Python
tools expose the same core filter and model structure for benchmark execution:

1. `prepare_paper_analysis_table()` reproduces the source-notebook cohort
   filter: exclude `Aves`, `Mammalia`, `Freschet et al. (2010)`, and marine
   rows; map invertebrate/vertebrate to heterotroph; create absolute latitude,
   logit(%N), logit(%P), log(N:P), log(N deposition), and log(labile P).
   On the bundled CSV, the complete-case model counts should match the paper
   Methods: N 22,467/19,040, P 11,200/8,479, and N:P 9,253/6,777 for
   latitude/environmental-driver models.
2. `paper_lmm_slope_table()` fits the six paper-aligned LMMs. Latitude models
   use `abs_lat_dec`; environmental-driver models include `Temp`, `Rad`,
   `log_Nenv`, and `log_Penv` jointly. Both model families include habitat,
   autohetero, continuous-predictor-by-habitat terms,
   continuous-predictor-by-autohetero terms, habitat:autohetero, and a
   species/morphospecies random intercept.
3. `paper_main_conclusion_summary()` summarizes the main paper conclusion:
   nitrogen deposition should emerge as the most consistent environmental
   predictor, while temperature, radiation, and labile P are weaker or
   inconsistent.

The older `mixed_model_interaction_subgroup_slopes()` and
`two_pair_slope_table()` functions remain as composable diagnostics, but they
are not the canonical paper reproduction path because they can fit a
continuous-predictor x habitat x trophic interaction that is not present in the
archived R notebook.

# geo_nd31 Tools

Generic ecological-stoichiometry analysis primitives delivered as four MCP servers.

## Files

| File                          | MCP server name              | Purpose |
|-------------------------------|------------------------------|---------|
| `data_loading.py`             | Stoichiometry_Data_Loading   | List xlsx sheets, read sheets, filter rows, summarise columns |
| `stoichiometry_compute.py`    | Stoichiometry_Compute        | Mass-percent to molar conversions, logit/log transforms, group summaries, back-transforms |
| `statistical_analysis.py`     | Stoichiometry_Statistics     | Pearson/Spearman correlations, OLS regression, linear mixed-effect models with species random intercept, per-group OLS fits |
| `plotting.py`                 | Stoichiometry_Plotting       | Sampling-site map, latitude vs response 2x2 panel, log(N deposition) vs response 2x2 panel, slope-comparison forest plot |

## Dependencies

```
mcp
numpy
pandas
scipy
statsmodels
matplotlib
openpyxl
```

Install with:

```bash
pip install mcp numpy pandas scipy statsmodels matplotlib openpyxl
```

## Run a server

```bash
python3 tools/data_loading.py
```

Each tool registers itself with the local MCP runtime.  Tools are deliberately
general-purpose primitives: filenames, column names, transformations, predictor
sets, and plot paths are passed in as arguments rather than hard-coded, so the
same tool can be reused across stoichiometry datasets, not only StoichLife.

## Output artefacts

The plotting tools write PNG figures to absolute paths supplied by the caller.
For the StoichLife task the agent is expected to place outputs under
`artifacts/`:

* `Fig1_sites_map.png` - global sampling site distribution by realm and trophic group
* `Fig2_latitude_logitP.png` - logit %P vs absolute latitude per realm-trophic panel
* `Fig3_Ndep_logitN.png` - logit %N vs log(N deposition) per realm-trophic panel

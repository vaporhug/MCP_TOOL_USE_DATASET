#!/usr/bin/env python3
"""
Plotting tools.  One MCP tool per output figure as required by the task spec.
"""

from __future__ import annotations

import math
import os
from typing import Any

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.stats import linregress
try:
    from mcp.server.fastmcp import FastMCP
except Exception:
    class FastMCP:
        def __init__(self, *args, **kwargs):
            pass
        def tool(self):
            def decorator(func):
                return func
            return decorator
        def run(self, *args, **kwargs):
            return None

mcp = FastMCP("Stoichiometry_Plotting")


_REALM_COLOR = {
    "freshwater": "#1f77b4",
    "terrestrial": "#8c564b",
}
_TROPH_MARKER = {"autotroph": "o", "heterotroph": "s"}


def _ensure_dir(path: str) -> None:
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)


@mcp.tool()
def plot_global_sites_map(
    csv_path: str,
    output_path: str,
    lat_column: str = "lat.dec",
    lon_column: str = "long.dec",
    realm_column: str = "habitat",
    troph_column: str = "autohetero",
    deduplicate_sites: bool = True,
    site_round_decimals: int = 3,
    include_habitats: list | None = None,
    exclude_class: list | None = None,
    class_column: str = "class_revised",
    require_non_null_columns: list | None = None,
) -> dict:
    """Scatter the geographic distribution of sampling sites coloured by realm
    and shaped by trophic group.

    Args:
        csv_path: Path to CSV with lat, lon, realm and trophic columns.
        output_path: Absolute path where PNG will be written.
        lat_column: Latitude column name.
        lon_column: Longitude column name.
        realm_column: Column with realm labels (freshwater / terrestrial).
        troph_column: Column with autotroph / heterotroph labels.
        deduplicate_sites: If True (default), one point is drawn per unique
            (rounded lat, rounded lon, realm, trophic) tuple so the figure
            is a SITE map rather than a record map. If False, every row is
            plotted (legacy behaviour).
        site_round_decimals: Decimal places used to round lat/lon when
            collapsing rows into unique sites; 3 decimals corresponds to
            ~110 m, which is finer than typical site-scale resolution.

    Returns:
        dict with file path, n_records, and n_unique_sites.
    """
    if not os.path.exists(csv_path):
        return {"error": f"File not found: {csv_path}"}
    df = pd.read_csv(csv_path)
    # Optionally enforce the modeled-cohort filter inline so the rendered
    # sites correspond to the same cohort the mixed-effects models operate
    # on (terrestrial + freshwater, non-Aves/non-Mammalia, paired non-null
    # %N/%P). This lets the caller produce the sites figure directly from
    # the raw input without first materialising a filtered CSV.
    if include_habitats and realm_column in df.columns:
        df = df[df[realm_column].isin(list(include_habitats))]
    if exclude_class and class_column in df.columns:
        df = df[~df[class_column].isin(list(exclude_class))]
    if require_non_null_columns:
        present = [c for c in require_non_null_columns if c in df.columns]
        if present:
            df = df.dropna(subset=present)
    # Drop rows missing lat/lon (cannot plot), and rows missing realm or
    # trophic labels (they would be silently excluded from the plotted layers
    # but would otherwise inflate the deduplicated-site count).
    drop_cols = [c for c in (lat_column, lon_column, realm_column, troph_column)
                 if c in df.columns]
    df = df.dropna(subset=drop_cols)
    # Restrict to the realm/trophic combinations the legend actually plots so
    # the deduplicated-site count matches the figure.
    df = df[df[realm_column].isin(list(_REALM_COLOR.keys()))]
    df = df[df[troph_column].isin(list(_TROPH_MARKER.keys()))]
    n_records_total = int(len(df))

    if deduplicate_sites:
        df = df.copy()
        df["_lat_round"] = df[lat_column].astype(float).round(site_round_decimals)
        df["_lon_round"] = df[lon_column].astype(float).round(site_round_decimals)
        df = df.drop_duplicates(
            subset=["_lat_round", "_lon_round", realm_column, troph_column]
        )

    fig, ax = plt.subplots(figsize=(11, 5.5))
    for realm, color in _REALM_COLOR.items():
        for troph, marker in _TROPH_MARKER.items():
            sub = df[(df[realm_column] == realm) & (df[troph_column] == troph)]
            if len(sub) == 0:
                continue
            ax.scatter(
                sub[lon_column],
                sub[lat_column],
                s=10,
                marker=marker,
                facecolor=color,
                edgecolor="none",
                alpha=0.55,
                label=f"{realm} {troph} (n_sites={len(sub)})" if deduplicate_sites
                       else f"{realm} {troph} (n={len(sub)})",
            )
    ax.set_xlabel("Longitude")
    ax.set_ylabel("Latitude")
    ax.set_xlim(-180, 180)
    ax.set_ylim(-90, 90)
    ax.axhline(0, color="grey", lw=0.5)
    ax.grid(alpha=0.25)
    ax.set_title("StoichLife sampling sites: realm and trophic group")
    ax.legend(loc="lower left", fontsize=8, ncol=2, frameon=True)
    plt.tight_layout()
    _ensure_dir(output_path)
    plt.savefig(output_path, dpi=150)
    plt.close(fig)

    # n_unique_sites: unique (lat, lon, realm, trophic) marker positions —
    # what the figure legend counts.
    # n_unique_locations: unique physical (lat, lon) pairs irrespective of
    # realm/trophic, which is the closer analogue to the paper's "998 sites
    # with lat/lon" count.
    if deduplicate_sites:
        n_unique_sites = int(len(df))
    else:
        n_unique_sites = int(len(df[[lat_column, lon_column, realm_column, troph_column]].drop_duplicates()))
    n_unique_locations = int(len(df[[lat_column, lon_column]].drop_duplicates()))
    return {
        "output": output_path,
        "n_records": n_records_total,
        "n_unique_sites": n_unique_sites,
        "n_unique_locations": n_unique_locations,
        "deduplicated": bool(deduplicate_sites),
    }


@mcp.tool()
def plot_latitude_response(
    csv_path: str,
    output_path: str,
    response_column: str,
    abs_lat_column: str = "abs_lat",
    realm_column: str = "habitat",
    troph_column: str = "autohetero",
    response_label: str = "logit(%P)",
    mixed_slopes: dict | None = None,
) -> dict:
    """Scatter and regression of a logit/log-transformed elemental response
    against absolute latitude, separately for each realm-trophic combination.

    If ``mixed_slopes`` is supplied (a dict keyed by ``"{realm}|{trophic}"``
    with ``{slope, p_value}`` entries — i.e. the ``subgroup_slopes`` block
    returned by ``statistical_analysis.mixed_model_interaction_subgroup_slopes``
    or ``mixed_model_per_realm_trophic``), the per-panel regression line and
    significance flag are taken from the mixed-effects model, matching the
    paper's per-realm × trophic slope reporting. If left ``None``, the
    function falls back to per-panel OLS via ``scipy.stats.linregress`` purely
    for visual reference (this OLS fallback is NOT the paper-aligned
    significance source and should only be used when no mixed-model output
    is available).

    Args:
        csv_path: Path to CSV with response, absolute latitude, realm, trophic columns.
        output_path: Absolute path where PNG will be written.
        response_column: Column with the (transformed) response variable.
        abs_lat_column: Column with absolute latitude (already computed).
        realm_column: Realm column.
        troph_column: Trophic-group column.
        response_label: Y-axis label.
        mixed_slopes: Optional dict of mixed-model slopes (see above).

    Returns:
        dict with output path, per-panel slope and p-value (and the source).
    """
    if not os.path.exists(csv_path):
        return {"error": f"File not found: {csv_path}"}
    df = pd.read_csv(csv_path)
    df = df.dropna(subset=[response_column, abs_lat_column, realm_column, troph_column])

    # Accept either the flat {realm|trophic: {slope, p_value, ...}} dict OR
    # the full object returned by mixed_model_interaction_subgroup_slopes /
    # mixed_model_per_realm_trophic (which nests that dict under a
    # "subgroup_slopes" key).
    if mixed_slopes and isinstance(mixed_slopes, dict) and "subgroup_slopes" in mixed_slopes:
        mixed_slopes = mixed_slopes["subgroup_slopes"]

    fig, axes = plt.subplots(2, 2, figsize=(10, 7), sharex=True, sharey=True)
    panels = [
        ("freshwater", "autotroph"),
        ("terrestrial", "autotroph"),
        ("freshwater", "heterotroph"),
        ("terrestrial", "heterotroph"),
    ]
    summary: dict[str, Any] = {}
    for ax, (realm, troph) in zip(axes.flat, panels):
        sub = df[(df[realm_column] == realm) & (df[troph_column] == troph)]
        ax.scatter(
            sub[abs_lat_column],
            sub[response_column],
            s=8,
            alpha=0.4,
            color=_REALM_COLOR[realm],
            edgecolor="none",
        )
        slope = pval = float("nan")
        intercept = 0.0
        source = "none"
        n = len(sub)
        if n >= 5:
            x = sub[abs_lat_column].astype(float).to_numpy()
            y = sub[response_column].astype(float).to_numpy()
            mm_key = f"{realm}|{troph}"
            if mixed_slopes and mm_key in mixed_slopes and (
                "slope" in mixed_slopes[mm_key]
            ):
                slope = float(mixed_slopes[mm_key]["slope"])
                pval = float(mixed_slopes[mm_key].get("p_value", float("nan")))
                # Anchor the line through the mean (x_bar, y_bar)
                intercept = float(np.mean(y) - slope * np.mean(x))
                source = "mixed_model"
            else:
                res = linregress(x, y)
                slope, pval = float(res.slope), float(res.pvalue)
                intercept = float(res.intercept)
                source = "ols_fallback"
            xs = np.linspace(x.min(), x.max(), 80)
            ys = slope * xs + intercept
            ax.plot(
                xs, ys,
                color="black", lw=1.5,
                linestyle="-" if (not math.isnan(pval) and pval < 0.05) else "--",
            )
        ax.set_title(
            f"{realm} {troph} (n={n}, slope={slope:.2e}, p={pval:.2g}, src={source})",
            fontsize=9,
        )
        ax.grid(alpha=0.25)
        summary[f"{realm}|{troph}"] = {
            "slope": slope, "p_value": pval, "n": int(n), "source": source,
        }

    for ax in axes[-1, :]:
        ax.set_xlabel("Absolute latitude (deg)")
    for ax in axes[:, 0]:
        ax.set_ylabel(response_label)
    plt.suptitle(f"{response_label} vs absolute latitude", y=1.02)
    plt.tight_layout()
    _ensure_dir(output_path)
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"output": output_path, "panels": summary}


@mcp.tool()
def plot_ndep_response(
    csv_path: str,
    output_path: str,
    response_column: str,
    log_ndep_column: str = "log_Ndep",
    realm_column: str = "habitat",
    troph_column: str = "autohetero",
    response_label: str = "logit(%N)",
    mixed_slopes: dict | None = None,
) -> dict:
    """Scatter and regression of an elemental response against log(N deposition),
    one panel per realm x trophic combination.

    If ``mixed_slopes`` is supplied (a dict keyed by ``"{realm}|{trophic}"``
    with ``{slope, p_value}`` entries — i.e. the ``subgroup_slopes`` block
    returned by ``statistical_analysis.mixed_model_interaction_subgroup_slopes``
    or ``mixed_model_per_realm_trophic``), the per-panel regression line and
    significance flag are taken from the mixed-effects model, matching the
    paper's per-realm × trophic slope reporting. If left ``None``, the
    function falls back to per-panel OLS via ``scipy.stats.linregress`` purely
    for visual reference (this OLS fallback is NOT the paper-aligned
    significance source).

    Args:
        csv_path: Path to CSV with response, log(N deposition), realm, trophic columns.
        output_path: Absolute path where PNG will be written.
        response_column: Response column.
        log_ndep_column: Column with log(N deposition).
        realm_column: Realm column.
        troph_column: Trophic group column.
        response_label: Y-axis label.
        mixed_slopes: Optional dict of mixed-model slopes (see above).

    Returns:
        dict with output path, per-panel slopes, p-values, and the source
        (mixed_model or ols_fallback) per panel.
    """
    if not os.path.exists(csv_path):
        return {"error": f"File not found: {csv_path}"}
    df = pd.read_csv(csv_path)
    df = df.dropna(subset=[response_column, log_ndep_column, realm_column, troph_column])

    # Accept either the flat {realm|trophic: {slope, p_value, ...}} dict OR
    # the full object returned by mixed_model_interaction_subgroup_slopes /
    # mixed_model_per_realm_trophic (which nests that dict under a
    # "subgroup_slopes" key).
    if mixed_slopes and isinstance(mixed_slopes, dict) and "subgroup_slopes" in mixed_slopes:
        mixed_slopes = mixed_slopes["subgroup_slopes"]

    fig, axes = plt.subplots(2, 2, figsize=(10, 7), sharex=True, sharey=True)
    panels = [
        ("freshwater", "autotroph"),
        ("terrestrial", "autotroph"),
        ("freshwater", "heterotroph"),
        ("terrestrial", "heterotroph"),
    ]
    summary: dict[str, Any] = {}
    for ax, (realm, troph) in zip(axes.flat, panels):
        sub = df[(df[realm_column] == realm) & (df[troph_column] == troph)]
        ax.scatter(
            sub[log_ndep_column],
            sub[response_column],
            s=8,
            alpha=0.4,
            color=_REALM_COLOR[realm],
            edgecolor="none",
        )
        slope = pval = float("nan")
        intercept = 0.0
        source = "none"
        n = len(sub)
        if n >= 5:
            x = sub[log_ndep_column].astype(float).to_numpy()
            y = sub[response_column].astype(float).to_numpy()
            mm_key = f"{realm}|{troph}"
            if mixed_slopes and mm_key in mixed_slopes and (
                "slope" in mixed_slopes[mm_key]
            ):
                slope = float(mixed_slopes[mm_key]["slope"])
                pval = float(mixed_slopes[mm_key].get("p_value", float("nan")))
                intercept = float(np.mean(y) - slope * np.mean(x))
                source = "mixed_model"
            else:
                res = linregress(x, y)
                slope, pval = float(res.slope), float(res.pvalue)
                intercept = float(res.intercept)
                source = "ols_fallback"
            xs = np.linspace(x.min(), x.max(), 80)
            ys = slope * xs + intercept
            ax.plot(
                xs, ys,
                color="black", lw=1.5,
                linestyle="-" if (not math.isnan(pval) and pval < 0.05) else "--",
            )
        ax.set_title(
            f"{realm} {troph} (n={n}, slope={slope:.2e}, p={pval:.2g}, src={source})",
            fontsize=9,
        )
        ax.grid(alpha=0.25)
        summary[f"{realm}|{troph}"] = {
            "slope": slope, "p_value": pval, "n": int(n), "source": source,
        }

    for ax in axes[-1, :]:
        ax.set_xlabel("log(N deposition) [kg N km^-2 y^-1]")
    for ax in axes[:, 0]:
        ax.set_ylabel(response_label)
    plt.suptitle(f"{response_label} vs log(N deposition)", y=1.02)
    plt.tight_layout()
    _ensure_dir(output_path)
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"output": output_path, "panels": summary}


@mcp.tool()
def plot_predictor_comparison(
    coefficients_json: dict,
    output_path: str,
    title: str = "Standardised slope coefficients across environmental predictors",
) -> dict:
    """Forest-plot-style bar chart comparing slope coefficients (with SE) across
    predictors and groups.

    Args:
        coefficients_json: dict {label: {estimate, stderr, p_value}}.  Labels can
            include any string (e.g. "freshwater autotroph: log Ndep").
        output_path: Where to write PNG.
        title: Plot title.

    Returns:
        dict with file path and number of bars.
    """
    if not coefficients_json:
        return {"error": "empty coefficients"}
    labels = list(coefficients_json.keys())
    estimates = [coefficients_json[k]["estimate"] for k in labels]
    errors = [coefficients_json[k].get("stderr", 0.0) for k in labels]
    pvals = [coefficients_json[k].get("p_value", float("nan")) for k in labels]

    n = len(labels)
    fig, ax = plt.subplots(figsize=(9, max(3, 0.45 * n)))
    y = np.arange(n)
    bar_colors = ["#d62728" if (p < 0.05 if not math.isnan(p) else False) else "#7f7f7f"
                  for p in pvals]
    ax.errorbar(estimates, y, xerr=errors, fmt="o", color="black",
                ecolor="grey", capsize=3, markersize=4, lw=1)
    for yi, est, color in zip(y, estimates, bar_colors):
        ax.scatter(est, yi, color=color, zorder=3, s=40)
    ax.axvline(0, color="black", lw=0.5)
    ax.set_yticks(y)
    ax.set_yticklabels(labels, fontsize=8)
    ax.set_xlabel("Slope coefficient (transformed scale)")
    ax.set_title(title, fontsize=10)
    ax.grid(axis="x", alpha=0.25)
    plt.tight_layout()
    _ensure_dir(output_path)
    plt.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"output": output_path, "n_bars": n}


if __name__ == "__main__":
    mcp.run()

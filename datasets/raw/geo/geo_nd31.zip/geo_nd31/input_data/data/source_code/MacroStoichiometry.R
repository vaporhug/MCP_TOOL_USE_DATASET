library(dplyr)
library(ggplot2)
library(ggeffects)
library(data.table)
library(emmeans)
library(ggh4x)
library(qqplotr)
library(performance)
library(partR2)
library(piecewiseSEM)
library(car)
library(data.table)
library(MuMIn)
library(qqplotr)
library(ggExtra)
library(cowplot)
library(lme4)
library(grid)
library(openxlsx)

#StoichLife: https://doi.org/10.5061/dryad.3tx95x6r2 
db<-read.xlsx("~/Proposal/2019_sDiv_sTOCHIOMETREE/Analyses/Plots/data paper/datapaper_2025_02_11.xlsx",sheet="data",colNames=TRUE)%>%
  rename(c(data.source=data.source1,
           P_terr_lab=P_ter,
           P_marine=P_mar,
           nasa.T10M=temperature,
           nasa.ALLSKY_SFC_SW_DWN=radiation,
           meanN_tot=N))
invlogit<-function(x) exp(x)/(1+exp(x))

###color chart
"freshwater autotroph" = "cyan1"
"freshwater heterotroph" = "cyan4"
"terrestrial autotroph" = "goldenrod1"
"terrestrial heterotroph" = "goldenrod4" 
"autotroph" = "chartreuse4"
"heterotroph" = "chocolate"
"aquatic" = "cyan3"        
"terrestrial" = "goldenrod3"

###############################################################################################################
####Model Latitude Nitrogen
#############################################
#set combinations of elements
combi<-c("taxa.p","taxa.n","taxa.c","taxa.np","taxa.cp","taxa.cn")

#set element to response: 1=taxa.p, 2=taxa.n, 4=taxa.np
element=2

#use lm_robust:mixed=FALSE or lmer(): mixed=TRUE
mixed=TRUE

#set number of iterations for estimating pvalues
iter=1000
####

dbdx<-db%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_terr_lab,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         species=as.factor(sp.morphosp_revised),
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(lat.dec),
         abs_lat.dec=abs(lat.dec))%>%
  dplyr::select(combi[element],abs_lat.dec,habitat,autohetero,species,location)%>%
  as.data.frame()%>%
  na.omit()

if(element %in% c(1,2,3)){
  dbdx$Yl<-log((dbdx[,combi[element]]/100)/(1-(dbdx[,combi[element]]/100))) #for n,p,c when logit
}

if(element %in% c(4,5,6)){
  dbdx$Yl<-log(dbdx[,combi[element]]) #for n,p,c when logit
}


### contrast coding of factors
contrasts(dbdx$habitat) <-contr.sum(2)#"contr.sum"
contrasts(dbdx$autohetero) <-contr.sum(2)

###log or scale predictors
# dbdx=dbdx%>%
#   mutate(Temp=scale(Temp),
#          Rad=log(Rad),
#          N=log(N),
#          P=log(P))


lmemod<-lmer(Yl~abs_lat.dec+habitat+autohetero+abs_lat.dec:habitat+abs_lat.dec:autohetero+habitat*autohetero+
               (1|species),data=as.data.frame(dbdx))

te7<-as.data.frame(pairs(emmeans(lmemod, pairwise ~ habitat*autohetero),adjust="none"))
te71<-te7[c(1,2,5,6),]
teDat4<-data.frame(type="effect",
                   case=c(as.character(te71$contrast)),
                   trend=c(te71$estimate),
                   SE=c(te71$SE),
                   df=c(te71$df))
#abs_lat.dec
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("abs_lat.dec") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("abs_lat.dec") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("abs_lat.dec") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(abs_lat.dec=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(abs_lat.dec=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("abs_lat.dec") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$abs_lat.dec.trend,te21$abs_lat.dec.trend,te12$estimate,te22$estimate,te3$abs_lat.dec.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$abs_lat.dec.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("abs_lat.dec") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsA<-rbind(teDat,teDat2,teDat3,teDat4)%>%
  mutate(var="abs_lat.dec")%>%
  mutate(iteration=0)

#ll2random<-list()
dbdx1<-dbdx%>%group_by(abs_lat.dec)%>%mutate(loc_id = cur_group_id())%>%ungroup() 
dbdx2<-dbdx1%>%group_by(abs_lat.dec)%>%summarise(loc_id =loc_id[1])%>%ungroup()
datCp<-list()
set.seed(3333)
for(i in 1:iter){
  dbdx2x<-dbdx2
  dbdx2x$loc_id<-sample(dbdx2$loc_id)
  names(dbdx2x)<-c("abs_lat.decS","loc_id")
  dbdx3<-left_join(dbdx1,dbdx2x,by="loc_id")%>%
    mutate(abs_lat.dec=abs_lat.decS)
  
  lmemodperm<-lmer(Yl~abs_lat.dec+habitat+autohetero+abs_lat.dec:habitat+abs_lat.dec:autohetero+habitat*autohetero+
                     (1|species),
                   data=as.data.frame(dbdx3))#,control = list( LP_tol_ll = 5e-2, LP_max_iter = 1000)
  
  suppressMessages({
    
    te7<-as.data.frame(pairs(emmeans(lmemodperm, pairwise ~ habitat*autohetero),adjust="none"))
    te71<-te7[c(1,2,5,6),]
    teDat4<-data.frame(type="effect",
                       case=c(as.character(te71$contrast)),
                       trend=c(te71$estimate),
                       SE=c(te71$SE),
                       df=c(te71$df))
    
    #abs_lat.dec
    te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("abs_lat.dec") )
    te11<-as.data.frame(te1$emtrends)
    te12<-as.data.frame(te1$contrasts)
    te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("abs_lat.dec") )
    te21<-as.data.frame(te2$emtrends)
    te22<-as.data.frame(te2$contrast)
    te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("abs_lat.dec") ))
    te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(abs_lat.dec=0) ),adjust="none"))
    te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(abs_lat.dec=0) ),adjust="none"))
    te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("abs_lat.dec") )$emtrends)
    teDat<-data.frame(type="slope",
                      case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                      trend=c(te11$abs_lat.dec.trend,te21$abs_lat.dec.trend,te12$estimate,te22$estimate,te3$abs_lat.dec.trend),
                      SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                      df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
    )
    teDat2<-data.frame(type="intercept",
                       case=c(as.character(te4$contrast),as.character(te5$contrast)),
                       trend=c(te4$estimate,te5$estimate),
                       SE=c(te4$SE,te5$SE),
                       df=c(te4$df,te5$df)
    )
    teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$abs_lat.dec.trend,SE=te6$SE,df=te6$df)%>%
      rbind(
        data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("abs_lat.dec") )$contrasts)%>%
          mutate(case=contrast,trend=estimate)%>%
          filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                             "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
          dplyr::select(type,case,trend,SE,df)
      )
    
    obsAx<-rbind(teDat,teDat2,teDat3,teDat4)%>%
      mutate(var="abs_lat.dec")%>%
      mutate(iteration=i)
    
  })
  
  obsA<-rbind(obsA,obsAx)
  
  #ll2random[[i]]<-ranef(lmemodperm)
  datte<-ggemmeans(lmemodperm,c("abs_lat.dec","autohetero","habitat"))%>%
    mutate(var="abs_lat.dec")
  
  datCp[[i]]<-rbind(datte)
}

obsA_1<-obsA
datCp_1<-datCp
save(obsA_1,
     datCp_1,
     lmemod,
     file="data.lmer_1k_em_perm_lat_N_1_sp.RData")
#############################################

####Model Latitude Phosphorus
#############################################
#set combinations of elements
combi<-c("taxa.p","taxa.n","taxa.c","taxa.np","taxa.cp","taxa.cn")

#set element to response: 1=taxa.p, 2=taxa.n, 4=taxa.np
element=1

#use lm_robust:mixed=FALSE or lmer(): mixed=TRUE
mixed=TRUE

#set number of iterations for estimating pvalues
iter=1000
####

dbdx<-db%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_terr_lab,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         species=as.factor(sp.morphosp_revised),
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(lat.dec),
         abs_lat.dec=abs(lat.dec))%>%
  dplyr::select(combi[element],abs_lat.dec,habitat,autohetero,species,location)%>%
  as.data.frame()%>%
  na.omit()

if(element %in% c(1,2,3)){
  dbdx$Yl<-log((dbdx[,combi[element]]/100)/(1-(dbdx[,combi[element]]/100))) #for n,p,c when logit
}

if(element %in% c(4,5,6)){
  dbdx$Yl<-log(dbdx[,combi[element]]) #for n,p,c when logit
}


### contrast coding of factors
contrasts(dbdx$habitat) <-contr.sum(2)#"contr.sum"
contrasts(dbdx$autohetero) <-contr.sum(2)

###log or scale predictors
# dbdx=dbdx%>%
#   mutate(Temp=scale(Temp),
#          Rad=log(Rad),
#          N=log(N),
#          P=log(P))


lmemod<-lmer(Yl~abs_lat.dec+habitat+autohetero+abs_lat.dec:habitat+abs_lat.dec:autohetero+habitat*autohetero+
               (1|species),data=as.data.frame(dbdx))

te7<-as.data.frame(pairs(emmeans(lmemod, pairwise ~ habitat*autohetero),adjust="none"))
te71<-te7[c(1,2,5,6),]
teDat4<-data.frame(type="effect",
                   case=c(as.character(te71$contrast)),
                   trend=c(te71$estimate),
                   SE=c(te71$SE),
                   df=c(te71$df))

#abs_lat.dec
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("abs_lat.dec") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("abs_lat.dec") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("abs_lat.dec") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(abs_lat.dec=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(abs_lat.dec=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("abs_lat.dec") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$abs_lat.dec.trend,te21$abs_lat.dec.trend,te12$estimate,te22$estimate,te3$abs_lat.dec.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$abs_lat.dec.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("abs_lat.dec") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsA<-rbind(teDat,teDat2,teDat3,teDat4)%>%
  mutate(var="abs_lat.dec")%>%
  mutate(iteration=0)

#ll2random<-list()
dbdx1<-dbdx%>%group_by(abs_lat.dec)%>%mutate(loc_id = cur_group_id())%>%ungroup() 
dbdx2<-dbdx1%>%group_by(abs_lat.dec)%>%summarise(loc_id =loc_id[1])%>%ungroup()
datCp<-list()
set.seed(3333)
for(i in 1:iter){
  dbdx2x<-dbdx2
  dbdx2x$loc_id<-sample(dbdx2$loc_id)
  names(dbdx2x)<-c("abs_lat.decS","loc_id")
  dbdx3<-left_join(dbdx1,dbdx2x,by="loc_id")%>%
    mutate(abs_lat.dec=abs_lat.decS)
  
  lmemodperm<-lmer(Yl~abs_lat.dec+habitat+autohetero+abs_lat.dec:habitat+abs_lat.dec:autohetero+habitat*autohetero+
                     (1|species),
                   data=as.data.frame(dbdx3))#,control = list( LP_tol_ll = 5e-2, LP_max_iter = 1000)
  
  suppressMessages({
    
    te7<-as.data.frame(pairs(emmeans(lmemodperm, pairwise ~ habitat*autohetero),adjust="none"))
    te71<-te7[c(1,2,5,6),]
    teDat4<-data.frame(type="effect",
                       case=c(as.character(te71$contrast)),
                       trend=c(te71$estimate),
                       SE=c(te71$SE),
                       df=c(te71$df))
    
    #abs_lat.dec
    te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("abs_lat.dec") )
    te11<-as.data.frame(te1$emtrends)
    te12<-as.data.frame(te1$contrasts)
    te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("abs_lat.dec") )
    te21<-as.data.frame(te2$emtrends)
    te22<-as.data.frame(te2$contrast)
    te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("abs_lat.dec") ))
    te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(abs_lat.dec=0) ),adjust="none"))
    te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(abs_lat.dec=0) ),adjust="none"))
    te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("abs_lat.dec") )$emtrends)
    teDat<-data.frame(type="slope",
                      case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                      trend=c(te11$abs_lat.dec.trend,te21$abs_lat.dec.trend,te12$estimate,te22$estimate,te3$abs_lat.dec.trend),
                      SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                      df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
    )
    teDat2<-data.frame(type="intercept",
                       case=c(as.character(te4$contrast),as.character(te5$contrast)),
                       trend=c(te4$estimate,te5$estimate),
                       SE=c(te4$SE,te5$SE),
                       df=c(te4$df,te5$df)
    )
    teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$abs_lat.dec.trend,SE=te6$SE,df=te6$df)%>%
      rbind(
        data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("abs_lat.dec") )$contrasts)%>%
          mutate(case=contrast,trend=estimate)%>%
          filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                             "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
          dplyr::select(type,case,trend,SE,df)
      )
    
    obsAx<-rbind(teDat,teDat2,teDat3,teDat4)%>%
      mutate(var="abs_lat.dec")%>%
      mutate(iteration=i)
    
  })
  
  obsA<-rbind(obsA,obsAx)
  
  #ll2random[[i]]<-ranef(lmemodperm)
  datte<-ggemmeans(lmemodperm,c("abs_lat.dec","autohetero","habitat"))%>%
    mutate(var="abs_lat.dec")
  
  datCp[[i]]<-rbind(datte)
}

obsA_1<-obsA
datCp_1<-datCp
save(obsA_1,
     datCp_1,
     lmemod,
     file="data.lmer_1k_em_perm_lat_P_1_sp.RData")
#############################################

####Model Latitude N:P
#############################################
#set combinations of elements
combi<-c("taxa.p","taxa.n","taxa.c","taxa.np","taxa.cp","taxa.cn")

#set element to response: 1=taxa.p, 2=taxa.n, 4=taxa.np
element=4

#use lm_robust:mixed=FALSE or lmer(): mixed=TRUE
mixed=TRUE

#set number of iterations for estimating pvalues
iter=1000
####

dbdx<-db%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_terr_lab,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         species=as.factor(sp.morphosp_revised),
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(lat.dec),
         abs_lat.dec=abs(lat.dec))%>%
  dplyr::select(combi[element],abs_lat.dec,habitat,autohetero,species,location)%>%
  as.data.frame()%>%
  na.omit()

if(element %in% c(1,2,3)){
  dbdx$Yl<-log((dbdx[,combi[element]]/100)/(1-(dbdx[,combi[element]]/100))) #for n,p,c when logit
}

if(element %in% c(4,5,6)){
  dbdx$Yl<-log(dbdx[,combi[element]]) #for n,p,c when logit
}


### contrast coding of factors
contrasts(dbdx$habitat) <-contr.sum(2)#"contr.sum"
contrasts(dbdx$autohetero) <-contr.sum(2)

###log or scale predictors
# dbdx=dbdx%>%
#   mutate(Temp=scale(Temp),
#          Rad=log(Rad),
#          N=log(N),
#          P=log(P))


lmemod<-lmer(Yl~abs_lat.dec+habitat+autohetero+abs_lat.dec:habitat+abs_lat.dec:autohetero+habitat*autohetero+
               (1|species),data=as.data.frame(dbdx))

te7<-as.data.frame(pairs(emmeans(lmemod, pairwise ~ habitat*autohetero),adjust="none"))
te71<-te7[c(1,2,5,6),]
teDat4<-data.frame(type="effect",
                   case=c(as.character(te71$contrast)),
                   trend=c(te71$estimate),
                   SE=c(te71$SE),
                   df=c(te71$df))

#abs_lat.dec
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("abs_lat.dec") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("abs_lat.dec") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("abs_lat.dec") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(abs_lat.dec=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(abs_lat.dec=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("abs_lat.dec") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$abs_lat.dec.trend,te21$abs_lat.dec.trend,te12$estimate,te22$estimate,te3$abs_lat.dec.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$abs_lat.dec.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("abs_lat.dec") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsA<-rbind(teDat,teDat2,teDat3,teDat4)%>%
  mutate(var="abs_lat.dec")%>%
  mutate(iteration=0)

#ll2random<-list()
dbdx1<-dbdx%>%group_by(abs_lat.dec)%>%mutate(loc_id = cur_group_id())%>%ungroup() 
dbdx2<-dbdx1%>%group_by(abs_lat.dec)%>%summarise(loc_id =loc_id[1])%>%ungroup()
datCp<-list()
set.seed(3333)
for(i in 1:iter){
  dbdx2x<-dbdx2
  dbdx2x$loc_id<-sample(dbdx2$loc_id)
  names(dbdx2x)<-c("abs_lat.decS","loc_id")
  dbdx3<-left_join(dbdx1,dbdx2x,by="loc_id")%>%
    mutate(abs_lat.dec=abs_lat.decS)
  
  lmemodperm<-lmer(Yl~abs_lat.dec+habitat+autohetero+abs_lat.dec:habitat+abs_lat.dec:autohetero+habitat*autohetero+
                     (1|species),
                   data=as.data.frame(dbdx3))#,control = list( LP_tol_ll = 5e-2, LP_max_iter = 1000)
  
  suppressMessages({
    
    te7<-as.data.frame(pairs(emmeans(lmemodperm, pairwise ~ habitat*autohetero),adjust="none"))
    te71<-te7[c(1,2,5,6),]
    teDat4<-data.frame(type="effect",
                       case=c(as.character(te71$contrast)),
                       trend=c(te71$estimate),
                       SE=c(te71$SE),
                       df=c(te71$df))
    
    #abs_lat.dec
    te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("abs_lat.dec") )
    te11<-as.data.frame(te1$emtrends)
    te12<-as.data.frame(te1$contrasts)
    te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("abs_lat.dec") )
    te21<-as.data.frame(te2$emtrends)
    te22<-as.data.frame(te2$contrast)
    te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("abs_lat.dec") ))
    te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(abs_lat.dec=0) ),adjust="none"))
    te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(abs_lat.dec=0) ),adjust="none"))
    te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("abs_lat.dec") )$emtrends)
    teDat<-data.frame(type="slope",
                      case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                      trend=c(te11$abs_lat.dec.trend,te21$abs_lat.dec.trend,te12$estimate,te22$estimate,te3$abs_lat.dec.trend),
                      SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                      df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
    )
    teDat2<-data.frame(type="intercept",
                       case=c(as.character(te4$contrast),as.character(te5$contrast)),
                       trend=c(te4$estimate,te5$estimate),
                       SE=c(te4$SE,te5$SE),
                       df=c(te4$df,te5$df)
    )
    teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$abs_lat.dec.trend,SE=te6$SE,df=te6$df)%>%
      rbind(
        data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("abs_lat.dec") )$contrasts)%>%
          mutate(case=contrast,trend=estimate)%>%
          filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                             "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
          dplyr::select(type,case,trend,SE,df)
      )
    
    obsAx<-rbind(teDat,teDat2,teDat3,teDat4)%>%
      mutate(var="abs_lat.dec")%>%
      mutate(iteration=i)
    
  })
  
  obsA<-rbind(obsA,obsAx)
  
  #ll2random[[i]]<-ranef(lmemodperm)
  datte<-ggemmeans(lmemodperm,c("abs_lat.dec","autohetero","habitat"))%>%
    mutate(var="abs_lat.dec")
  
  datCp[[i]]<-rbind(datte)
}

obsA_1<-obsA
datCp_1<-datCp
save(obsA_1,
     datCp_1,
     lmemod,
     file="data.lmer_1k_em_perm_lat_NP_1_sp.RData")
#############################################

####Model Environment N
#############################################
#set combinations of elements
combi<-c("taxa.p","taxa.n","taxa.c","taxa.np","taxa.cp","taxa.cn")

#set element to response: 1=taxa.p, 2=taxa.n, 4=taxa.np
element=2

#use lm_robust:mixed=FALSE or lmer(): mixed=TRUE
mixed=TRUE

#set number of iterations for estimating pvalues
iter=1000
####

dbdx<-db%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_terr_lab,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         species=as.factor(sp.morphosp_revised),
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(paste0(lat.dec," ",long.dec)))%>%
  dplyr::select(combi[element],Temp,Rad,N,P,habitat,autohetero,species,location)%>%
  as.data.frame()%>%
  na.omit()

if(element %in% c(1,2,3)){
  dbdx$Yl<-log((dbdx[,combi[element]]/100)/(1-(dbdx[,combi[element]]/100))) #for n,p,c when logit
}

if(element %in% c(4,5,6)){
  dbdx$Yl<-log(dbdx[,combi[element]]) #for n,p,c when logit
}


### contrast coding of factors
contrasts(dbdx$habitat) <-contr.sum(2)
contrasts(dbdx$autohetero) <-contr.sum(2)

###log or scale predictors
dbdx=dbdx%>%
  mutate(N=log(N),
         P=log(P))

lmemod<-lmer(Yl~habitat+autohetero+Temp+Rad+N+P+
               Temp:habitat+Rad:habitat+P:habitat+N:habitat+Temp:autohetero+Rad:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
               (1|species),data=as.data.frame(dbdx))


te7<-as.data.frame(pairs(emmeans(lmemod, pairwise ~ habitat*autohetero),adjust="none"))
te71<-te7[c(1,2,5,6),]
teDat4<-data.frame(type="effect",
                   case=c(as.character(te71$contrast)),
                   trend=c(te71$estimate),
                   SE=c(te71$SE),
                   df=c(te71$df))

#Temp
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("Temp") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("Temp") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("Temp") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$Temp.trend,te21$Temp.trend,te12$estimate,te22$estimate,te3$Temp.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Temp.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsT<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="Temp")

#Rad
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("Rad") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("Rad") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("Rad") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$Rad.trend,te21$Rad.trend,te12$estimate,te22$estimate,te3$Rad.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Rad.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsR<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="Rad")

#N
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("N") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("N") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("N") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$N.trend,te21$N.trend,te12$estimate,te22$estimate,te3$N.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$N.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsN<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="N")

#P
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("P") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("P") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("P") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$P.trend,te21$P.trend,te12$estimate,te22$estimate,te3$P.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$P.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsP<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="P")

obsA<-rbind(obsT,obsR,obsN,obsP,mutate(teDat4,var="habtrop"))%>%
  mutate(iteration=0)

#ll2random<-list()
dbdx1<-dbdx%>%group_by(Temp,Rad,N,P)%>%mutate(loc_id = cur_group_id())%>%ungroup() 
dbdx2<-dbdx1%>%group_by(Temp,Rad,N,P)%>%summarise(loc_id =loc_id[1])%>%ungroup()
datCp<-list()
set.seed(3333)
for(i in 1:iter){
  dbdx2x<-dbdx2
  dbdx2x$loc_id<-sample(dbdx2$loc_id)
  names(dbdx2x)<-c("TempS","RadS","NS","PS","loc_id")
  dbdx3<-left_join(dbdx1,dbdx2x,by="loc_id")%>%
    mutate(Temp=TempS,Rad=RadS,N=NS,P=PS)
  
  lmemodperm<-lmer(Yl~habitat+autohetero+Temp+Rad+N+P+
                     Temp:habitat+Rad:habitat+P:habitat+N:habitat+Temp:autohetero+Rad:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
                     (1|species),data=as.data.frame(dbdx3))
  
  te7<-as.data.frame(pairs(emmeans(lmemodperm, pairwise ~ habitat*autohetero),adjust="none"))
  te71<-te7[c(1,2,5,6),]
  teDat4<-data.frame(type="effect",
                     case=c(as.character(te71$contrast)),
                     trend=c(te71$estimate),
                     SE=c(te71$SE),
                     df=c(te71$df))
  
  suppressMessages({te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Temp") )
  #Temp
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Temp") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("Temp") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("Temp") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("Temp") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$Temp.trend,te21$Temp.trend,te12$estimate,te22$estimate,te3$Temp.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Temp.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsT<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="Temp")
  
  #Rad
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat"))
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Rad") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("Rad") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("Rad") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("Rad") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$Rad.trend,te21$Rad.trend,te12$estimate,te22$estimate,te3$Rad.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Rad.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsR<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="Rad")
  
  #N
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("N") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("N") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("N") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$N.trend,te21$N.trend,te12$estimate,te22$estimate,te3$N.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$N.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsN<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="N")
  
  #P
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("P") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("P") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("P") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("P") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$P.trend,te21$P.trend,te12$estimate,te22$estimate,te3$P.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$P.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsP<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="P")
  obsAx<-rbind(obsT,obsR,obsN,obsP,mutate(teDat4,var="habtrop"))%>%
    mutate(iteration=i)
  
  })
  
  obsA<-rbind(obsA,obsAx)
  #ll2random[[i]]<-ranef(lmemodperm)
  datte<-ggemmeans(lmemodperm,c("Temp","autohetero","habitat") ,typical="mean")%>%
    mutate(var="Temp")
  datra<-ggemmeans(lmemodperm,c("Rad","autohetero","habitat") ,typical="mean")%>%
    mutate(var="Rad")
  datn<-ggemmeans(lmemodperm,c("N","autohetero","habitat") ,typical="mean")%>%
    mutate(var="N")
  datp<-ggemmeans(lmemodperm,c("P","autohetero","habitat") ,typical="mean")%>%
    mutate(var="P")
  
  datCp[[i]]<-rbind(datte,datra,datn,datp)
}

obsA_1<-obsA
datCp_1<-datCp
save(obsA_1,
     datCp_1,
     lmemod,
     file="data.lmer_1k_em_perm_N_1_sp_log_pred.RData")
#############################################

####Model Environment P
#############################################
#set combinations of elements
combi<-c("taxa.p","taxa.n","taxa.c","taxa.np","taxa.cp","taxa.cn")

#set element to response: 1=taxa.p, 2=taxa.n, 4=taxa.np
element=1

#use lm_robust:mixed=FALSE or lmer(): mixed=TRUE
mixed=TRUE

#set number of iterations for estimating pvalues
iter=1000
####

dbdx<-db%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_terr_lab,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         species=as.factor(sp.morphosp_revised),
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(paste0(lat.dec," ",long.dec)))%>%
  dplyr::select(combi[element],Temp,Rad,N,P,habitat,autohetero,species,location)%>%
  as.data.frame()%>%
  na.omit()

if(element %in% c(1,2,3)){
  dbdx$Yl<-log((dbdx[,combi[element]]/100)/(1-(dbdx[,combi[element]]/100))) #for n,p,c when logit
}

if(element %in% c(4,5,6)){
  dbdx$Yl<-log(dbdx[,combi[element]]) #for n,p,c when logit
}


### contrast coding of factors
contrasts(dbdx$habitat) <-contr.sum(2)
contrasts(dbdx$autohetero) <-contr.sum(2)

###log or scale predictors
dbdx=dbdx%>%
  mutate(N=log(N),
         P=log(P))


lmemod<-lmer(Yl~habitat+autohetero+Temp+Rad+N+P+
               Temp:habitat+Rad:habitat+P:habitat+N:habitat+Temp:autohetero+Rad:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
               (1|species),data=as.data.frame(dbdx))

te7<-as.data.frame(pairs(emmeans(lmemod, pairwise ~ habitat*autohetero),adjust="none"))
te71<-te7[c(1,2,5,6),]
teDat4<-data.frame(type="effect",
                   case=c(as.character(te71$contrast)),
                   trend=c(te71$estimate),
                   SE=c(te71$SE),
                   df=c(te71$df))

#Temp
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("Temp") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("Temp") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("Temp") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$Temp.trend,te21$Temp.trend,te12$estimate,te22$estimate,te3$Temp.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Temp.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsT<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="Temp")

#Rad
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("Rad") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("Rad") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("Rad") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$Rad.trend,te21$Rad.trend,te12$estimate,te22$estimate,te3$Rad.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Rad.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsR<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="Rad")

#N
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("N") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("N") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("N") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$N.trend,te21$N.trend,te12$estimate,te22$estimate,te3$N.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$N.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsN<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="N")

#P
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("P") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("P") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("P") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$P.trend,te21$P.trend,te12$estimate,te22$estimate,te3$P.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$P.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsP<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="P")

obsA<-rbind(obsT,obsR,obsN,obsP,mutate(teDat4,var="habtrop"))%>%
  mutate(iteration=0)

#ll2random<-list()
dbdx1<-dbdx%>%group_by(Temp,Rad,N,P)%>%mutate(loc_id = cur_group_id())%>%ungroup() 
dbdx2<-dbdx1%>%group_by(Temp,Rad,N,P)%>%summarise(loc_id =loc_id[1])%>%ungroup()
datCp<-list()
set.seed(3333)
for(i in 1:iter){
  dbdx2x<-dbdx2
  dbdx2x$loc_id<-sample(dbdx2$loc_id)
  names(dbdx2x)<-c("TempS","RadS","NS","PS","loc_id")
  dbdx3<-left_join(dbdx1,dbdx2x,by="loc_id")%>%
    mutate(Temp=TempS,Rad=RadS,N=NS,P=PS)
  
  lmemodperm<-lmer(Yl~habitat+autohetero+Temp+Rad+N+P+
                     Temp:habitat+Rad:habitat+P:habitat+N:habitat+Temp:autohetero+Rad:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
                     (1|species),data=as.data.frame(dbdx3))
  
  te7<-as.data.frame(pairs(emmeans(lmemodperm, pairwise ~ habitat*autohetero),adjust="none"))
  te71<-te7[c(1,2,5,6),]
  teDat4<-data.frame(type="effect",
                     case=c(as.character(te71$contrast)),
                     trend=c(te71$estimate),
                     SE=c(te71$SE),
                     df=c(te71$df))
  
  suppressMessages({te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Temp") )
  #Temp
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Temp") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("Temp") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("Temp") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("Temp") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$Temp.trend,te21$Temp.trend,te12$estimate,te22$estimate,te3$Temp.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Temp.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsT<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="Temp")
  
  #Rad
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat"))
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Rad") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("Rad") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("Rad") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("Rad") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$Rad.trend,te21$Rad.trend,te12$estimate,te22$estimate,te3$Rad.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Rad.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsR<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="Rad")
  
  #N
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("N") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("N") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("N") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$N.trend,te21$N.trend,te12$estimate,te22$estimate,te3$N.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$N.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsN<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="N")
  
  #P
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("P") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("P") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("P") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("P") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$P.trend,te21$P.trend,te12$estimate,te22$estimate,te3$P.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$P.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsP<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="P")
  obsAx<-rbind(obsT,obsR,obsN,obsP,mutate(teDat4,var="habtrop"))%>%
    mutate(iteration=i)
  
  })
  
  obsA<-rbind(obsA,obsAx)
  #ll2random[[i]]<-ranef(lmemodperm)
  datte<-ggemmeans(lmemodperm,c("Temp","autohetero","habitat") ,typical="mean")%>%
    mutate(var="Temp")
  datra<-ggemmeans(lmemodperm,c("Rad","autohetero","habitat") ,typical="mean")%>%
    mutate(var="Rad")
  datn<-ggemmeans(lmemodperm,c("N","autohetero","habitat") ,typical="mean")%>%
    mutate(var="N")
  datp<-ggemmeans(lmemodperm,c("P","autohetero","habitat") ,typical="mean")%>%
    mutate(var="P")
  
  datCp[[i]]<-rbind(datte,datra,datn,datp)
}

obsA_1<-obsA
datCp_1<-datCp
save(obsA_1,
     datCp_1,
     lmemod,
     file="data.lmer_1k_em_perm_P_1_sp_log_pred.RData")
#############################################

####Model Environment N:P
#############################################
#set combinations of elements
combi<-c("taxa.p","taxa.n","taxa.c","taxa.np","taxa.cp","taxa.cn")

#set element to response: 1=taxa.p, 2=taxa.n, 4=taxa.np
element=4

#use lm_robust:mixed=FALSE or lmer(): mixed=TRUE
mixed=TRUE

#set number of iterations for estimating pvalues
iter=1000
###

dbdx<-db%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_terr_lab,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         species=as.factor(sp.morphosp_revised),
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(paste0(lat.dec," ",long.dec)))%>%
  dplyr::select(combi[element],Temp,Rad,N,P,habitat,autohetero,species,location)%>%
  as.data.frame()%>%
  na.omit()

if(element %in% c(1,2,3)){
  dbdx$Yl<-log((dbdx[,combi[element]]/100)/(1-(dbdx[,combi[element]]/100))) #for n,p,c when logit
}

if(element %in% c(4,5,6)){
  dbdx$Yl<-log(dbdx[,combi[element]]) #for n,p,c when logit
}


### contrast coding of factors
contrasts(dbdx$habitat) <-contr.sum(2)
contrasts(dbdx$autohetero) <-contr.sum(2)

###log or scale predictors
dbdx=dbdx%>%
  mutate(N=log(N),
         P=log(P))

lmemod<-lmer(Yl~habitat+autohetero+Temp+Rad+N+P+
               Temp:habitat+Rad:habitat+P:habitat+N:habitat+Temp:autohetero+Rad:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
               (1|species),data=as.data.frame(dbdx))


te7<-as.data.frame(pairs(emmeans(lmemod, pairwise ~ habitat*autohetero),adjust="none"))
te71<-te7[c(1,2,5,6),]
teDat4<-data.frame(type="effect",
                   case=c(as.character(te71$contrast)),
                   trend=c(te71$estimate),
                   SE=c(te71$SE),
                   df=c(te71$df))

#Temp
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("Temp") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("Temp") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("Temp") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$Temp.trend,te21$Temp.trend,te12$estimate,te22$estimate,te3$Temp.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Temp.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsT<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="Temp")

#Rad
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("Rad") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("Rad") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("Rad") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$Rad.trend,te21$Rad.trend,te12$estimate,te22$estimate,te3$Rad.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Rad.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsR<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="Rad")

#N
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("N") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("N") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("N") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$N.trend,te21$N.trend,te12$estimate,te22$estimate,te3$N.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$N.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsN<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="N")

#P
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("P") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("P") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("P") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$P.trend,te21$P.trend,te12$estimate,te22$estimate,te3$P.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$P.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsP<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="P")

obsA<-rbind(obsT,obsR,obsN,obsP,mutate(teDat4,var="habtrop"))%>%
  mutate(iteration=0)

#ll2random<-list()
dbdx1<-dbdx%>%group_by(Temp,Rad,N,P)%>%mutate(loc_id = cur_group_id())%>%ungroup() 
dbdx2<-dbdx1%>%group_by(Temp,Rad,N,P)%>%summarise(loc_id =loc_id[1])%>%ungroup()
datCp<-list()
set.seed(3333)
for(i in 1:iter){
  dbdx2x<-dbdx2
  dbdx2x$loc_id<-sample(dbdx2$loc_id)
  names(dbdx2x)<-c("TempS","RadS","NS","PS","loc_id")
  dbdx3<-left_join(dbdx1,dbdx2x,by="loc_id")%>%
    mutate(Temp=TempS,Rad=RadS,N=NS,P=PS)
  
  lmemodperm<-lmer(Yl~habitat+autohetero+Temp+Rad+N+P+
                     Temp:habitat+Rad:habitat+P:habitat+N:habitat+Temp:autohetero+Rad:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
                     (1|species),data=as.data.frame(dbdx3))
  
  te7<-as.data.frame(pairs(emmeans(lmemodperm, pairwise ~ habitat*autohetero),adjust="none"))
  te71<-te7[c(1,2,5,6),]
  teDat4<-data.frame(type="effect",
                     case=c(as.character(te71$contrast)),
                     trend=c(te71$estimate),
                     SE=c(te71$SE),
                     df=c(te71$df))
  
  suppressMessages({te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Temp") )
  #Temp
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Temp") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("Temp") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("Temp") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("Temp") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$Temp.trend,te21$Temp.trend,te12$estimate,te22$estimate,te3$Temp.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Temp.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsT<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="Temp")
  
  #Rad
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat"))
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Rad") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("Rad") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("Rad") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("Rad") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$Rad.trend,te21$Rad.trend,te12$estimate,te22$estimate,te3$Rad.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Rad.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsR<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="Rad")
  
  #N
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("N") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("N") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("N") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$N.trend,te21$N.trend,te12$estimate,te22$estimate,te3$N.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$N.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsN<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="N")
  
  #P
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("P") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("P") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("P") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("P") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$P.trend,te21$P.trend,te12$estimate,te22$estimate,te3$P.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$P.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsP<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="P")
  obsAx<-rbind(obsT,obsR,obsN,obsP,mutate(teDat4,var="habtrop"))%>%
    mutate(iteration=i)
  
  })
  
  obsA<-rbind(obsA,obsAx)
  datte<-ggemmeans(lmemodperm,c("Temp","autohetero","habitat") ,typical="mean")%>%
    mutate(var="Temp")
  datra<-ggemmeans(lmemodperm,c("Rad","autohetero","habitat") ,typical="mean")%>%
    mutate(var="Rad")
  datn<-ggemmeans(lmemodperm,c("N","autohetero","habitat") ,typical="mean")%>%
    mutate(var="N")
  datp<-ggemmeans(lmemodperm,c("P","autohetero","habitat") ,typical="mean")%>%
    mutate(var="P")
  
  datCp[[i]]<-rbind(datte,datra,datn,datp)
  #ll2random[[i]]<-ranef(lmemodperm)
}

obsA_1<-obsA
datCp_1<-datCp
save(obsA_1,
     datCp_1,
     lmemod,
     file="data.lmer_1k_em_perm_NP_1_sp_log_pred.RData")
#############################################

####Main model checks
#############################################
#Model Absolute Latitude
load("data.lmer_1k_em_perm_lat_N_1_sp.RData")
load("data.lmer_1k_em_perm_lat_P_1_sp.RData")
load("data.lmer_1k_em_perm_lat_NP_1_sp.RData")

Anova(lmemod,type="III")
summary(lmemod)
AICc(lmemod)
BIC(lmemod)

#QQplot
data.frame(sample=ranef(lmemod)$species[,1])%>%
  ggplot(aes(sample=sample))+
  stat_qq_point()+
  geom_abline(slope=1,intercept=0)+
  labs(x = "Theoretical Quantiles", y = "Sample Quantiles")

#Residuals against fitted
data.frame(fitted=fitted(lmemod),residuals=residuals(lmemod,type="pearson"))%>%
  ggplot(aes(x=fitted,y=residuals))+
  geom_point()+
  labs(x = "Fitted values",y = "Pearson Residuals")

#Residuals against independent variable
data.frame(var=lmemod@frame$abs_lat.dec,residuals=residuals(lmemod,type="pearson"))%>%
  ggplot(aes(x=var,y=residuals))+
  geom_point()+
  labs(x = "Absolute Latitude",y = "Pearson Residuals")

#Model environmental drivers
load("data.lmer_1k_em_perm_N_1_sp_log_pred.RData")
load("data.lmer_1k_em_perm_P_1_sp_log_pred.RData")
load("data.lmer_1k_em_perm_NP_1_sp_log_pred.RData")

Anova(lmemod,type="III")
summary(lmemod)
AICc(lmemod)
BIC(lmemod)

#QQplot
data.frame(sample=ranef(lmemod)$species[,1])%>%
  ggplot(aes(sample=sample))+
  stat_qq_point()+
  geom_abline(slope=1,intercept=0)+
  labs(x = "Theoretical Quantiles", y = "Sample Quantiles")

#Residuals against fitted
data.frame(fitted=fitted(lmemod),residuals=residuals(lmemod,type="pearson"))%>%
  ggplot(aes(x=fitted,y=residuals))+
  geom_point()+
  labs(x = "Fitted values",y = "Pearson Residuals")

#Residuals against independent variables
data.frame(var=lmemod@frame$Temp,residuals=residuals(lmemod,type="pearson"))%>%
  ggplot(aes(x=var,y=residuals))+
  geom_point()+
  labs(x = "Temperature",y = "Pearson Residuals")

data.frame(var=lmemod@frame$Rad,residuals=residuals(lmemod,type="pearson"))%>%
  ggplot(aes(x=var,y=residuals))+
  geom_point()+
  labs(x = "Radiation",y = "Pearson Residuals")

data.frame(var=lmemod@frame$N,residuals=residuals(lmemod,type="pearson"))%>%
  ggplot(aes(x=var,y=residuals))+
  geom_point()+
  labs(x = "N availability",y = "Pearson Residuals")

data.frame(var=lmemod@frame$P,residuals=residuals(lmemod,type="pearson"))%>%
  ggplot(aes(x=var,y=residuals))+
  geom_point()+
  labs(x = "P availability",y = "Pearson Residuals")

#############################################

####Appendices main models
#############################################
####latitude data
load("data.lmer_1k_em_perm_lat_N_1_sp.RData")

dbdx=lmemod@frame

ll1<-obsA_1
obsA<-obsA_1%>%
  filter(!(type %in% c("intercept","effect")))%>%
  group_by(type,case,var)%>%
  summarise(pvalue=mean(abs(trend[iteration!=0]/SE[iteration!=0]) >= abs(trend[iteration==0]/SE[iteration==0])))
obsA$padjustBO<-p.adjust(obsA$pvalue)
obsA$padjustBH<-p.adjust(obsA$pvalue,method="BH")

test_lat_N=ll1%>%
  filter(iteration %in% 0)%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% "intercept"))%>%
  dplyr::select(type,case,var,trend,SE)%>%
  left_join(obsA,by=c("type","case","var"))%>%
  mutate(element="N",
         trend=formatC(trend, format = "e", digits = 1),
         SE=formatC(SE, format = "e", digits = 1),
         pvalue=formatC(round(pvalue,3),format = "f",digits = 3),
         padjustBH=formatC(round(padjustBH,3),format = "f",digits = 3),
         sig=ifelse(padjustBH < 0.05,"sig","nonsig"))%>%
  dplyr::select(element,case,var,trend,SE,pvalue,padjustBH,sig)%>%
  arrange(factor(case,levels=c("overall",
                               "freshwater","terrestrial","freshwater - terrestrial",
                               "autotroph","heterotroph","autotroph - heterotroph",
                               "freshwater autotroph","terrestrial autotroph","freshwater heterotroph","terrestrial heterotroph",
                               "freshwater autotroph - terrestrial autotroph",
                               "freshwater autotroph - freshwater heterotroph",
                               "terrestrial autotroph - terrestrial heterotroph",
                               "freshwater heterotroph - terrestrial heterotroph")))
#write.table(test,file="results_lat_N.doc",row.names=F,quote=F,sep=";")

load("data.lmer_1k_em_perm_lat_P_1_sp.RData")

dbdx=lmemod@frame

ll1<-obsA_1
obsA<-obsA_1%>%
  filter(!(type %in% c("intercept","effect")))%>%
  group_by(type,case,var)%>%
  summarise(pvalue=mean(abs(trend[iteration!=0]/SE[iteration!=0]) >= abs(trend[iteration==0]/SE[iteration==0])))
obsA$padjustBO<-p.adjust(obsA$pvalue)
obsA$padjustBH<-p.adjust(obsA$pvalue,method="BH")

test_lat_P=ll1%>%
  filter(iteration %in% 0)%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% "intercept"))%>%
  dplyr::select(type,case,var,trend,SE)%>%
  left_join(obsA,by=c("type","case","var"))%>%
  mutate(element="P",
         trend=formatC(trend, format = "e", digits = 1),
         SE=formatC(SE, format = "e", digits = 1),
         pvalue=formatC(round(pvalue,3),format = "f",digits = 3),
         padjustBH=formatC(round(padjustBH,3),format = "f",digits = 3),
         sig=ifelse(padjustBH < 0.05,"sig","nonsig"))%>%
  dplyr::select(element,case,var,trend,SE,pvalue,padjustBH,sig)%>%
  arrange(factor(case,levels=c("overall",
                               "freshwater","terrestrial","freshwater - terrestrial",
                               "autotroph","heterotroph","autotroph - heterotroph",
                               "freshwater autotroph","terrestrial autotroph","freshwater heterotroph","terrestrial heterotroph",
                               "freshwater autotroph - terrestrial autotroph",
                               "freshwater autotroph - freshwater heterotroph",
                               "terrestrial autotroph - terrestrial heterotroph",
                               "freshwater heterotroph - terrestrial heterotroph")))
#write.table(test,file="results_lat_P.doc",row.names=F,quote=F,sep=";")

load("data.lmer_1k_em_perm_lat_NP_1_sp.RData")

dbdx=lmemod@frame

ll1<-obsA_1
obsA<-obsA_1%>%
  filter(!(type %in% c("intercept","effect")))%>%
  group_by(type,case,var)%>%
  summarise(pvalue=mean(abs(trend[iteration!=0]/SE[iteration!=0]) >= abs(trend[iteration==0]/SE[iteration==0])))
obsA$padjustBO<-p.adjust(obsA$pvalue)
obsA$padjustBH<-p.adjust(obsA$pvalue,method="BH")

test_lat_NP=ll1%>%
  filter(iteration %in% 0)%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% "intercept"))%>%
  dplyr::select(type,case,var,trend,SE)%>%
  left_join(obsA,by=c("type","case","var"))%>%
  mutate(element="N:P",
         trend=formatC(trend, format = "e", digits = 1),
         SE=formatC(SE, format = "e", digits = 1),
         pvalue=formatC(round(pvalue,3),format = "f",digits = 3),
         padjustBH=formatC(round(padjustBH,3),format = "f",digits = 3),
         sig=ifelse(padjustBH < 0.05,"sig","nonsig"))%>%
  dplyr::select(element,case,var,trend,SE,pvalue,padjustBH,sig)%>%
  arrange(factor(case,levels=c("overall",
                               "freshwater","terrestrial","freshwater - terrestrial",
                               "autotroph","heterotroph","autotroph - heterotroph",
                               "freshwater autotroph","terrestrial autotroph","freshwater heterotroph","terrestrial heterotroph",
                               "freshwater autotroph - terrestrial autotroph",
                               "freshwater autotroph - freshwater heterotroph",
                               "terrestrial autotroph - terrestrial heterotroph",
                               "freshwater heterotroph - terrestrial heterotroph")))
#write.table(test,file="results_lat_NP.doc",row.names=F,quote=F,sep=";")
test=rbind(test_lat_N,test_lat_P,test_lat_NP)
#write.table(test,file="results_lat.doc",row.names=F,quote=F,sep=";")


####environmental data

load("data.lmer_1k_em_perm_N_1_sp_log_pred.RData")

dbdx=lmemod@frame

ll1<-obsA_1
obsA<-obsA_1%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% c("intercept","effect")))%>%
  group_by(type,case,var)%>%
  summarise(pvalue=mean(abs(trend[iteration!=0]/SE[iteration!=0]) >= abs(trend[iteration==0]/SE[iteration==0])))
obsA$padjustBO<-p.adjust(obsA$pvalue)
obsA$padjustBH<-p.adjust(obsA$pvalue,method="BH")

test=ll1%>%
  filter(iteration %in% 0)%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% "intercept"))%>%
  dplyr::select(type,case,var,trend,SE)%>%
  left_join(obsA,by=c("type","case","var"))%>%
  mutate(element="N",
         trend=formatC(trend, format = "e", digits = 1),
         SE=formatC(SE, format = "e", digits = 1),
         pvalue=formatC(round(pvalue,3),format = "f",digits = 3),
         padjustBH=formatC(round(padjustBH,3),format = "f",digits = 3),
         sig=ifelse(padjustBH < 0.05,"sig","nonsig"))%>%
  dplyr::select(element,case,var,trend,SE,pvalue,padjustBH,sig)%>%
  arrange(factor(var,levels=c("Temp","Rad","N","P")),factor(case,levels=c("overall",
                                                                    "freshwater","terrestrial","freshwater - terrestrial",
                                                                    "autotroph","heterotroph","autotroph - heterotroph",
                                                                    "freshwater autotroph","terrestrial autotroph","freshwater heterotroph","terrestrial heterotroph",
                                                                    "freshwater autotroph - terrestrial autotroph",
                                                                    "freshwater autotroph - freshwater heterotroph",
                                                                    "terrestrial autotroph - terrestrial heterotroph",
                                                                    "freshwater heterotroph - terrestrial heterotroph")))

#write.table(test,file="resultsN.doc",row.names=F,quote=F,sep=";")

load("data.lmer_1k_em_perm_P_1_sp_log_pred.RData")

dbdx=lmemod@frame

ll1<-obsA_1
obsA<-obsA_1%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% c("intercept","effect")))%>%
  group_by(type,case,var)%>%
  summarise(pvalue=mean(abs(trend[iteration!=0]/SE[iteration!=0]) >= abs(trend[iteration==0]/SE[iteration==0])))
obsA$padjustBO<-p.adjust(obsA$pvalue)
obsA$padjustBH<-p.adjust(obsA$pvalue,method="BH")

test=ll1%>%
  filter(iteration %in% 0)%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% "intercept"))%>%
  dplyr::select(type,case,var,trend,SE)%>%
  left_join(obsA,by=c("type","case","var"))%>%
  mutate(element="P",
         trend=formatC(trend, format = "e", digits = 1),
         SE=formatC(SE, format = "e", digits = 1),
         pvalue=formatC(round(pvalue,3),format = "f",digits = 3),
         padjustBH=formatC(round(padjustBH,3),format = "f",digits = 3),
         sig=ifelse(padjustBH < 0.05,"sig","nonsig"))%>%
  dplyr::select(element,case,var,trend,SE,pvalue,padjustBH,sig)%>%
  arrange(factor(var,levels=c("Temp","Rad","N","P")),factor(case,levels=c("overall",
                                                                    "freshwater","terrestrial","freshwater - terrestrial",
                                                                    "autotroph","heterotroph","autotroph - heterotroph",
                                                                    "freshwater autotroph","terrestrial autotroph","freshwater heterotroph","terrestrial heterotroph",
                                                                    "freshwater autotroph - terrestrial autotroph",
                                                                    "freshwater autotroph - freshwater heterotroph",
                                                                    "terrestrial autotroph - terrestrial heterotroph",
                                                                    "freshwater heterotroph - terrestrial heterotroph")))
#write.table(test,file="resultsP.doc",row.names=F,quote=F,sep=";")

load("data.lmer_1k_em_perm_NP_1_sp_log_pred.RData")

dbdx=lmemod@frame

ll1<-obsA_1
obsA<-obsA_1%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% c("intercept","effect")))%>%
  group_by(type,case,var)%>%
  summarise(pvalue=mean(abs(trend[iteration!=0]/SE[iteration!=0]) >= abs(trend[iteration==0]/SE[iteration==0])))
obsA$padjustBO<-p.adjust(obsA$pvalue)
obsA$padjustBH<-p.adjust(obsA$pvalue,method="BH")

test=ll1%>%
  filter(iteration %in% 0)%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% "intercept"))%>%
  dplyr::select(type,case,var,trend,SE)%>%
  left_join(obsA,by=c("type","case","var"))%>%
  mutate(element="N:P",
         trend=formatC(trend, format = "e", digits = 1),
         SE=formatC(SE, format = "e", digits = 1),
         pvalue=formatC(round(pvalue,3),format = "f",digits = 3),
         padjustBH=formatC(round(padjustBH,3),format = "f",digits = 3),
         sig=ifelse(padjustBH < 0.05,"sig","nonsig"))%>%
  dplyr::select(element,case,var,trend,SE,pvalue,padjustBH,sig)%>%
  arrange(factor(var,levels=c("Temp","Rad","N","P")),factor(case,levels=c("overall",
                                                                    "freshwater","terrestrial","freshwater - terrestrial",
                                                                    "autotroph","heterotroph","autotroph - heterotroph",
                                                                    "freshwater autotroph","terrestrial autotroph","freshwater heterotroph","terrestrial heterotroph",
                                                                    "freshwater autotroph - terrestrial autotroph",
                                                                    "freshwater autotroph - freshwater heterotroph",
                                                                    "terrestrial autotroph - terrestrial heterotroph",
                                                                    "freshwater heterotroph - terrestrial heterotroph")))
#write.table(test,file="resultsNP.doc",row.names=F,quote=F,sep=";")


ll1%>%
  filter(iteration %in% 0)%>%
  dplyr::select(type,case,var,trend,SE)%>%
  left_join(obsA,by=c("type","case","var"))%>%
  filter(padjustBH < 0.05)%>%#pvalue, padjustBH, padjustBO
  View()

#############################################

####various intext
#############################################
##Material and Method various info:
dp<-db

#abstract
dp%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source1 %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  filter(!is.na(lat.dec))%>%
  summarize(nsp=length(unique(sp.morphosp_revised)))

dp%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source1 %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  dplyr::select(lat.dec,long.dec)%>%
  distinct()%>%
  filter(!is.na(lat.dec))%>%
  #filter(!is.na(long.dec))%>%
  dim()

#m&m
dim(dp)

dp%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source1 %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  filter(!is.na(lat.dec))%>%
  dim()

dp%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source1 %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  dplyr::select(lat.dec,long.dec)%>%
  distinct()%>%
  filter(!is.na(lat.dec))%>%
  #filter(!is.na(long.dec))%>%
  dim()

dp%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source1 %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  dplyr::select(lat.dec,long.dec)%>%
  distinct()%>%
  filter(!is.na(lat.dec))%>%
  filter(!is.na(long.dec))%>%
  dim()

dp%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source1 %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  filter(!is.na(lat.dec))%>%
  filter(!is.na(long.dec))%>%
  group_by(habitat)%>%
  summarize(n=length(unique(as.character(location))))

dp%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source1 %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  filter(!is.na(lat.dec))%>%
  filter(!is.na(long.dec))%>%
  group_by(location)%>%
  summarize(n=length(unique((habitat))))%>%
  filter(n>1)%>%
  dim()

dp%>%
  filter((habitat %in% "marine"))%>%
  dim()

dp%>%
  filter((class_revised %in% c("Aves")))%>%
  dim()

dp%>%
  filter((class_revised %in% c("Mammalia")))%>%
  dim()

dp%>%
  filter((data.source1 %in% "Freschet et al (2010)"))%>%
  dim()

dp%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source1 %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  filter(autohetero %in% "autotroph")%>%
  filter(!is.na(lat.dec))%>%
  summarize(ph=length(unique(phylum_revised)),
            cl=length(unique(class_revised)),
            or=length(unique(order_revised)),
            fa=length(unique(family_revised)),
            sp=length(unique(sp.morphosp_revised)))

dp%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source1 %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  filter(autohetero %in% "autotroph")%>%
  filter(!is.na(lat.dec))%>%
  group_by(habitat)%>%
  summarize(miN=min(taxa.n,na.rm=T),maN=max(taxa.n,na.rm=T),
            miP=min(taxa.p,na.rm=T),maP=max(taxa.p,na.rm=T),
            miNP=min(taxa.np,na.rm=T),maNP=max(taxa.np,na.rm=T))

dp%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source1 %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  filter(autohetero %in% "heterotroph")%>%
  filter(!is.na(lat.dec))%>%
  summarize(ph=length(unique(phylum_revised)),
            cl=length(unique(class_revised)),
            or=length(unique(order_revised)),
            fa=length(unique(family_revised)),
            sp=length(unique(sp.morphosp_revised)))

dp%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source1 %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  filter(autohetero %in% "heterotroph")%>%
  filter(!is.na(lat.dec))%>%
  group_by(habitat)%>%
  summarize(miN=min(taxa.n,na.rm=T),maN=max(taxa.n,na.rm=T),
            miP=min(taxa.p,na.rm=T),maP=max(taxa.p,na.rm=T),
            miNP=min(taxa.np,na.rm=T),maNP=max(taxa.np,na.rm=T))

#interpreting N:P ratio and P limitation
#NP
load("data.lmer_1k_em_perm_lat_NP_1_sp.RData")

dbdx=lmemod@frame
mean(exp(dbdx$Yl))
min(exp(dbdx$Yl))
max(exp(dbdx$Yl))

ll1<-obsA_1
obsA<-obsA_1%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% "intercept"))%>%
  group_by(type,case,var)%>%
  summarise(pvalue=mean(abs(trend[iteration!=0]/SE[iteration!=0]) >= abs(trend[iteration==0]/SE[iteration==0])))
obsA$padjustBO<-p.adjust(obsA$pvalue)
obsA$padjustBH<-p.adjust(obsA$pvalue,method="BH")

#HABITAT TROPHIC INTERACTION
datte<-ggemmeans(lmemod,c("abs_lat.dec","autohetero","habitat") ,typical="mean")%>%
  mutate(var="abs_lat.dec")

datC<-rbind(datte)%>%
  mutate(case=paste0(facet," ",group))%>%
  left_join(obsA,by=c("case","var"))%>%
  mutate(significance=ifelse(padjustBH < 0.05,"significant","not significant")) #pvalue, padjustBO, padjustBH

dbdx2<-data.frame(predicted=(dbdx$Yl),facet=dbdx$habitat,group=dbdx$autohetero,x=c(dbdx$abs_lat.dec),var=rep(c("abs_lat.dec"),each=nrow(dbdx)))

datC1<-datC%>%
  #filter(x >= -2.5 & x <= 4)%>%
  mutate(group=ifelse(group %in% "autotroph","AUTOTROPH","HETEROTROPH"),
         facet=case_when(facet == "freshwater" ~ "FRESHWATER",
                         facet == "marine" ~ "MARINE",
                         facet == "terrestrial" ~ "TERRESTRIAL",
                         TRUE ~ as.character(facet)),
         var=case_when(var == "abs_lat.dec" ~ "Absolute latitude",
                       TRUE ~ as.character(var)))%>%
  mutate(var=factor(var,levels=c("Absolute latitude")))

mean(exp(datC1[datC1$group %in% "AUTOTROPH" & datC1$facet %in% "TERRESTRIAL",]$predicted))
min(exp(datC1[datC1$group %in% "AUTOTROPH" & datC1$facet %in% "TERRESTRIAL",]$predicted))
max(exp(datC1[datC1$group %in% "AUTOTROPH" & datC1$facet %in% "TERRESTRIAL",]$predicted))

exp(datC1[datC1$group %in% "AUTOTROPH" & datC1$facet %in% "TERRESTRIAL",]$conf.low)
exp(datC1[datC1$group %in% "AUTOTROPH" & datC1$facet %in% "TERRESTRIAL",]$conf.high)

#percent increase in P over latitude
pinc_dat<-ggemmeans(lmemod,c("abs_lat.dec") ,typical="mean")%>%
  mutate(var="abs_lat.dec")
pinc=pinc_dat%>%
  mutate(backpredicted=invlogit(predicted))%>%
  group_by(x)%>%
  summarise(meanp=mean(predicted),
            meanbp=mean(backpredicted))

pinc_dat<-ggemmeans(lmemod,c("abs_lat.dec","autohetero","habitat") ,typical="mean")%>%
  mutate(var="abs_lat.dec")
pinc=pinc_dat%>%
  mutate(backpredicted=invlogit(predicted))%>%
  group_by(x)%>%
  summarise(meanp=mean(predicted),
            meanbp=mean(backpredicted))

pinc_dat<-ggemmeans(lmemod,c("abs_lat.dec","autohetero","habitat") ,typical="mean")%>%
  mutate(var="abs_lat.dec")
pinc=pinc_dat%>%
  filter(group %in% "autotroph")%>%
  filter(facet %in% "terrestrial")%>%
  mutate(backpredicted=invlogit(predicted))%>%
  group_by(x)%>%
  summarise(meanp=mean(predicted),
            meanbp=mean(backpredicted))

(pinc[pinc$x%in% 80,"meanp"] - pinc[pinc$x%in% 0,"meanp"])/abs(pinc[pinc$x%in% 0,"meanp"])*100
(pinc[pinc$x%in% 80,"meanbp"] - pinc[pinc$x%in% 0,"meanbp"])/abs(pinc[pinc$x%in% 0,"meanbp"])*100
#############################################

####Figure 1
#############################################
library(ggplot2)
theme_set(theme_bw())
library(sf)
library(RgoogleMaps)
library(DataCombine)
library(tidyr)
library(colorBlindness)
library(hrbrthemes)
library(dplyr)
library(viridis)
library(here)
library(cowplot)
library(rnaturalearth)
library(rnaturalearthdata)

# 1. Load data

# load world surface for projection

world <- ne_countries(scale = "medium", returnclass = "sf")

# load data 

#stoich <- read.csv(here("db_sub_2022_09_19.csv"),sep=";", stringsAsFactors=TRUE)
stoich <- db
# set file path

save_file <- "C:/"#indicates path of folder where you want to save figures

# Converting factor variables to factors

stoich$invert.vert.auto<- as.factor(stoich$invert.vert.auto)
stoich$troph<- as.factor(stoich$troph)
stoich$habitat.gen<- as.factor(stoich$habitat.gen)
stoich$habitat<- as.factor(stoich$habitat)
levels(stoich$habitat)

# excluding marine data and plotting only aquatic for freshwater, and terrestrial###

stoich_subset <- stoich %>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_terr_lab,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         species=as.factor(sp.morphosp_revised),
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(paste0(lat.dec," ",long.dec))) %>%
  mutate(use_cols=ifelse(habitat %in% "terrestrial","goldenrod3","cyan3"))

# create your colours for the two groups

use_cols = c("terrestrial" = "goldenrod3", "freshwater" = "cyan3")
use_cols

# Extract only data being used

data_stoich <- stoich_subset %>%
  dplyr::select(long.dec,lat.dec,habitat, troph,use_cols)%>%
  drop_na()

# creating a new column with habitat and troph together

data_stoich <- data_stoich %>% 
  unite(habitat_troph, c(habitat, troph), sep = " ", remove = FALSE)

data_stoich$habitat_troph <- as.factor(data_stoich$habitat_troph)
str(data_stoich)

# Add colors for different habitats and trophic groups

data_stoich$use_cols[data_stoich$habitat_troph == "freshwater autotroph"] = "cyan1"
data_stoich$use_cols[data_stoich$habitat_troph == "freshwater heterotroph"] = "cyan4"
data_stoich$use_cols[data_stoich$habitat_troph == "terrestrial autotroph"] = "goldenrod1"
data_stoich$use_cols[data_stoich$habitat_troph == "terrestrial heterotroph"] = "goldenrod4"

# add n to groups

data_stoich <- data_stoich %>%
  group_by(habitat_troph) %>%
  mutate(n = n()) %>%
  mutate(new_habitat_troph = as.factor(paste(habitat_troph,' ','(',n,')',sep="")))


# set customized theme

theme_niwot <- function(){
  theme_bw() +
    theme(text = element_text(family = "Helvetica Light"),
          axis.text = element_text(size = 16), 
          axis.title.y = element_text(size = 18),
          axis.title.x= element_text(size = 18),
          axis.line.x = element_line(color="black"), 
          axis.line.y = element_line(color="black"),
          panel.border = element_blank(),
          panel.grid.major.x = element_blank(),                                          
          panel.grid.minor.x = element_blank(),
          panel.grid.minor.y = element_blank(),
          panel.grid.major.y = element_blank(),  
          plot.margin = unit(c(1, 1, 1, 1), units = , "cm"),
          plot.title = element_text(size = 18, vjust = 1, hjust = 0),
          legend.text = element_text(size = 12),  
          legend.key = element_blank(),
          legend.background = element_rect(color = "black", 
                                           fill = "transparent", 
                                           size = 2, linetype = "blank"))
}


# 2. Figure 1

#Note: CorelDraw was used to add a customized legend and to combine individual plots

## 2.1 Map


# This map displays four groups considering habitat and trophic mode

world <- map_data("world")

map <- ggplot(data= data_stoich,aes(x=long, y = lat,fill=habitat_troph)) + 
  geom_polygon(data = world, aes(x=long, y = lat, group = group), fill = "lightgrey", col="black") + 
  coord_fixed(1.3) +
  geom_point(data= data_stoich,
             aes(x = data_stoich$long.dec,y = data_stoich$lat.dec,fill=habitat_troph), 
             size = 4, pch=21,col="black") +
  scale_size(range = c(0, 10)) +
  theme(plot.background=element_blank(), 
        panel.background=element_blank(), 
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.title = element_blank(),
        axis.text = element_blank(),
        axis.ticks = element_blank(),
        panel.border = element_blank(),
        legend.position = "none") +
  labs(y= "Latitude", x = "Longitude") +
  scale_x_continuous(expand = c(0.1, 0.1)) +
  scale_y_continuous(limits = c(-60,80),expand = c(0, 0)) +
  scale_fill_manual("", 
                    breaks = c("freshwater autotroph", "freshwater heterotroph", 
                               "terrestrial autotroph","terrestrial heterotroph"),
                    values = c("cyan1", "cyan4", "goldenrod1","goldenrod4"))

postscript(paste0(save_file,"/Figure1.a.eps"), width = 12, height = 6)
map
dev.off()


## 2.2 Correlation of environmental variables


# plot distribution for temperature

Fig1.DP1 <- stoich_subset %>%
  mutate(lat.abs  = abs(lat.dec)) %>%
  select(long.dec,lat.abs,Temp) %>%
  drop_na() %>%
  ggplot(aes(lat.abs,Temp)) +
  stat_density_2d(aes(fill = ..level..), geom = "polygon") +
  geom_point() +
  scale_fill_continuous(low="lavenderblush", high="red") +
  geom_jitter(size = 1.1) +
  xlim(c(0,80)) +
  theme_niwot() +
  labs(y="Temperature") +
  theme(axis.title.x = element_blank())

# plot distribution for Radiation

Fig1.DP2 <- stoich_subset %>%
  mutate(lat.abs  = abs(lat.dec)) %>%
  select(long.dec,lat.abs,Rad) %>%
  drop_na() %>%
  ggplot(aes(lat.abs,Rad)) +
  stat_density_2d(aes(fill = ..level..), geom = "polygon") +
  geom_point() +
  scale_fill_continuous(low="lavenderblush", high="red") +
  geom_jitter(size = 1.1) +
  xlim(c(0,80)) +
  theme_niwot() +
  labs(y="Radiation") +
  theme(axis.title.x = element_blank())

# plot distribution for nitrogen 

Fig1.DP3 <- stoich_subset %>%
  mutate(lat.abs  = abs(lat.dec)) %>%
  select(long.dec,lat.abs,N) %>%
  drop_na() %>%
  ggplot(aes(lat.abs,N)) +
  stat_density_2d(aes(fill = ..level..), geom = "polygon") +
  scale_fill_continuous(low="lavenderblush", high="red") +
  geom_point() +
  geom_jitter(size = 1.1) +
  xlim(c(0,80)) +
  theme_niwot() +
  labs(y="Nitrogen") +
  theme(axis.title.x = element_blank())

# plot distribution for phosphorus   

Fig1.DP4 <- stoich_subset %>%
  mutate(lat.abs  = abs(lat.dec)) %>%
  select(long.dec,lat.abs,P) %>%
  drop_na() %>%
  ggplot(aes(lat.abs,P)) +
  stat_density_2d(aes(fill = ..level..), geom = "polygon") +
  scale_fill_continuous(low="lavenderblush", high="red") +
  geom_point() +
  geom_jitter(size = 1.1) +
  xlim(c(0,80)) +
  theme_niwot() +
  labs(y="Phosphorus")

# save plots

postscript(paste0(save_file,"/Fig1.DP1.eps"), width = 10, height = 10)
Fig1.DP1
dev.off()

postscript(paste0(save_file,"/Fig1.DP2.eps"), width = 10, height = 10)
Fig1.DP2
dev.off()

postscript(paste0(save_file,"/Fig1.DP3.eps"), width = 10, height = 10)
Fig1.DP3
dev.off()

postscript(paste0(save_file,"/Fig1.DP4.eps"), width = 10, height = 10)
Fig1.DP4
dev.off()

# assess correlations between environmental variables

temp <- stoich_subset %>%
  mutate(lat.abs  = abs(lat.dec)) %>%
  select(long.dec,lat.abs,Temp) %>%
  drop_na()

rad <- stoich_subset %>%
  mutate(lat.abs  = abs(lat.dec)) %>%
  select(long.dec,lat.abs,Rad) %>%
  drop_na()

n <- stoich_subset %>%
  mutate(lat.abs  = abs(lat.dec)) %>%
  select(long.dec,lat.abs,N) %>%
  drop_na()

p <- stoich_subset %>%
  mutate(lat.abs  = abs(lat.dec)) %>%
  select(long.dec,lat.abs,P) %>%
  drop_na()

cor.test(temp$Temp,temp$lat.abs,method="spearman")
cor.test(rad$Rad,rad$lat.abs,method="spearman")
cor.test(n$N,n$lat.abs,method="spearman")
cor.test(p$P,p$lat.abs,method="spearman")


#NB: ask Dr George Perry (george.perry@auckland.ac.nz) for the code of Figure 1B
#############################################

####Figure2
#############################################
#P
load("data.lmer_1k_em_perm_lat_P_1_sp.RData")

dbdx=lmemod@frame

ll1<-obsA_1
obsA<-obsA_1%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% "intercept"))%>%
  group_by(type,case,var)%>%
  summarise(pvalue=mean(abs(trend[iteration!=0]/SE[iteration!=0]) >= abs(trend[iteration==0]/SE[iteration==0])))
obsA$padjustBO<-p.adjust(obsA$pvalue)
obsA$padjustBH<-p.adjust(obsA$pvalue,method="BH")



#TROPHIC
datte<-ggemmeans(lmemod,c("abs_lat.dec","autohetero") ,typical="mean")%>%
  data.frame()%>%
  mutate(var="abs_lat.dec")

datC<-rbind(datte)%>%
  mutate(case=group)%>%
  left_join(obsA,by=c("case","var"))%>%
  mutate(significance=ifelse(padjustBH < 0.05,"significant","not significant")) #pvalue, padjustBO, padjustBH

dbdx2<-data.frame(predicted=(dbdx$Yl),facet=dbdx$habitat,group=dbdx$autohetero,x=c(dbdx$abs_lat.dec),var=rep(c("abs_lat.dec"),each=nrow(dbdx)))

datC1<-datC%>%
  #filter(x >= -2.5 & x <= 4)%>%
  mutate(group=ifelse(group %in% "autotroph","AUTOTROPH","HETEROTROPH"),
         
         var=case_when(var == "abs_lat.dec" ~ "Absolute latitude",
                       TRUE ~ as.character(var)))%>%
  mutate(var=factor(var,levels=c("Absolute latitude")))
dbdx21<-dbdx2%>%
  #filter(x >= -2.5 & x <= 4)%>%
  mutate(group=ifelse(group %in% "autotroph","AUTOTROPH","HETEROTROPH"),
         
         var=case_when(var == "abs_lat.dec" ~ "Absolute latitude",
                       TRUE ~ as.character(var)))%>%
  mutate(var=factor(var,levels=c("Absolute latitude")))

dat_text <- data.frame(label = c("A", ""),facet   = c("FRESHWATER","TERRESTRIAL"), group=c("AUTOTROPH","HETEROTROPH"))
test2=datC1%>%
  ggplot(aes(x=x,y=(predicted),group=group,fill=group))+
  geom_point(data=mutate(dbdx21,facet=ifelse(facet %in% "FRESHWATER","AQUATIC",facet)),aes(x=x,y=(predicted),color=group,shape=group),
             alpha=0.2,show.legend = TRUE)+
  #geom_ribbon(aes(ymin=invlogit(conf.low)*100,ymax=invlogit(conf.high)*100),alpha=0.3,show.legend = FALSE)+
  geom_line(aes(color=group,linetype=significance),linewidth=1,show.legend = FALSE)+
  scale_shape_manual(values=c(16, 16))+#1 or 16;  or 3 and 4
  scale_linetype_manual(values=c("dotted", "solid"),guide="none")+
  scale_color_manual(values=c("AUTOTROPH"="chartreuse4","HETEROTROPH"="chocolate"))+
  scale_fill_manual(values=c("AUTOTROPH"="chartreuse4","HETEROTROPH"="chocolate"))+
  #facet_nested(~var,scales="free",independent="x")+
  theme_classic()+xlab("")+ylab("logit(P)")+xlim(0,80)+
  theme(legend.position=c(0.5, 0.95),legend.title=element_blank(),legend.direction = "horizontal")+
  guides(colour = guide_legend(override.aes = list(alpha = 1)))+
  geom_text(
    data    = dat_text,
    mapping = aes(x = 0, y = -1, label = label),
    fontface = "bold")+
  scale_y_continuous(
    #sec.axis = sec_axis(~.,name = "P (% dry mass)",labels=as.character(round(c(0,invlogit(seq(-8,-2,2))*100),2)))
    limits=c(-8,-1),
    breaks=seq(-8,-2,1),
    sec.axis = sec_axis(~.,name = "P (% dry mass)",breaks=derive(),labels=c("0.0",as.character(round(c(invlogit(seq(-7,-2,1))*100),1))))
    #sec.axis = sec_axis(~.,name = "P (% dry mass)",breaks=derive(),labels=as.character(round(c(invlogit(seq(-8,-2,1))*100),1)))
    #sec.axis = sec_axis(~.,name = "P (% dry mass)",labels=as.character(round(c(0,invlogit(seq(-8,-2,1))*100),2)))
    #sec.axis = sec_axis(~.,name = "P (% dry mass)",breaks=derive())
    
  )

#HABITAT
datte<-ggemmeans(lmemod,c("abs_lat.dec","habitat") ,typical="mean")%>%
  data.frame()%>%
  mutate(var="abs_lat.dec")

datC<-rbind(datte)%>%
  mutate(case=group)%>%
  left_join(obsA,by=c("case","var"))%>%
  mutate(significance=ifelse(padjustBH < 0.05,"significant","not significant")) #pvalue, padjustBO, padjustBH

dbdx2<-data.frame(predicted=(dbdx$Yl),facet=dbdx$habitat,group=dbdx$autohetero,x=c(dbdx$abs_lat.dec),var=rep(c("abs_lat.dec"),each=nrow(dbdx)))

datC1<-datC%>%
  #filter(x >= -2.5 & x <= 4)%>%
  mutate(group=ifelse(case %in% "freshwater","FRESHWATER","TERRESTRIAL"),
         var=case_when(var == "abs_lat.dec" ~ "Absolute latitude",
                       TRUE ~ as.character(var)))%>%
  mutate(var=factor(var,levels=c("Absolute latitude")))
dbdx21<-dbdx2%>%
  #filter(x >= -2.5 & x <= 4)%>%
  mutate(group=ifelse(facet %in% "freshwater","FRESHWATER","TERRESTRIAL"),
         
         var=case_when(var == "abs_lat.dec" ~ "Absolute latitude",
                       TRUE ~ as.character(var)))%>%
  mutate(var=factor(var,levels=c("Absolute latitude")))
new_label<-c("Absolute latitude" = "")
dat_text <- data.frame(label = c("B"),facet   = c("FRESHWATER","TERRESTRIAL"), group=c("Autotrophs","Heterotrophs"))
test3=datC1%>%
  ggplot(aes(x=x,y=(predicted),group=group,fill=group))+
  geom_point(data=mutate(dbdx21,facet=ifelse(facet %in% "FRESHWATER","FRESHWATER",facet)),aes(x=x,y=(predicted),color=group,shape=group),
             alpha=0.2,show.legend = TRUE)+
  #geom_ribbon(aes(ymin=invlogit(conf.low)*100,ymax=invlogit(conf.high)*100),alpha=0.3,show.legend = FALSE)+
  geom_line(aes(color=group,linetype=significance),linewidth=1,show.legend = FALSE)+
  scale_shape_manual(values=c(16, 16))+#1 or 16;  or 3 and 4
  scale_linetype_manual(values=c("dotted", "solid"),guide="none")+
  scale_color_manual(values=c("FRESHWATER"="cyan3","TERRESTRIAL"="goldenrod3"))+
  scale_fill_manual(values=c("FRESHWATER"="cyan3","TERRESTRIAL"="goldenrod3"))+
  facet_nested(~var,scales="free",independent="x",labeller=labeller(var=new_label))+
  theme_classic()+xlab("")+ylab("logit(P)")+xlim(0,80)+
  theme(legend.position=c(0.5, 0.95),legend.title=element_blank(),legend.direction = "horizontal",
        strip.background = element_rect(color="white", fill="white", size=0))+
  guides(colour = guide_legend(override.aes = list(alpha = 1)))+
  geom_text(
    data    = dat_text,
    mapping = aes(x = 0, y = -1, label = label),
    fontface = "bold")+
  scale_y_continuous(
    limits=c(-8,-1),
    breaks=seq(-8,-2,1),
    sec.axis = sec_axis(~.,name = "P (% dry mass)",breaks=derive(),labels=c("0.0",as.character(round(c(invlogit(seq(-7,-2,1))*100),1))))
    
  )

#HABITAT*TROPHIC INTERACTION
datte<-ggemmeans(lmemod,c("abs_lat.dec","autohetero","habitat") ,typical="mean")%>%
  data.frame()%>%
  mutate(var="abs_lat.dec")

datC<-rbind(datte)%>%
  mutate(case=paste0(facet," ",group))%>%
  left_join(obsA,by=c("case","var"))%>%
  mutate(significance=ifelse(padjustBH < 0.05,"significant","not significant")) #pvalue, padjustBO, padjustBH

dbdx2<-data.frame(predicted=(dbdx$Yl),facet=dbdx$habitat,group=dbdx$autohetero,x=c(dbdx$abs_lat.dec),var=rep(c("abs_lat.dec"),each=nrow(dbdx)))

datC1<-datC%>%
  #filter(x >= -2.5 & x <= 4)%>%
  mutate(group=ifelse(group %in% "autotroph","AUTOTROPH","HETEROTROPH"),
         facet=case_when(facet == "freshwater" ~ "FRESHWATER",
                         facet == "marine" ~ "MARINE",
                         facet == "terrestrial" ~ "TERRESTRIAL",
                         TRUE ~ as.character(facet)),
         var=case_when(var == "abs_lat.dec" ~ "Absolute latitude",
                       TRUE ~ as.character(var)))%>%
  mutate(var=factor(var,levels=c("Absolute latitude")))
dbdx21<-dbdx2%>%
  mutate(group=ifelse(group %in% "autotroph","AUTOTROPH","HETEROTROPH"),
         facet=case_when(facet == "freshwater" ~ "FRESHWATER",
                         facet == "marine" ~ "MARINE",
                         facet == "terrestrial" ~ "TERRESTRIAL",
                         TRUE ~ as.character(facet)),
         var=case_when(var == "abs_lat.dec" ~ "Absolute latitude",
                       TRUE ~ as.character(var)))%>%
  mutate(var=factor(var,levels=c("Absolute latitude")))
dat_text <- data.frame(
  label = c("C", ""),
  facet   = c("FRESHWATER","TERRESTRIAL"),
  group=c("Aquatic Autotrophs","Aquatic Heterotrophs","Terrestrial Autotrophs","Terrestrial Heterotrophs")
)

test4=datC1%>%
  mutate(facet=ifelse(facet %in% "FRESHWATER","FRESHWATER",facet),
         group=case_when(case=="freshwater autotroph" ~ "FRESHWATER AUTOTROPH",
                         case=="freshwater heterotroph" ~ "FRESHWATER HETEROTROPH",
                         case=="terrestrial autotroph" ~ "TERRESTRIAL AUTOTROPH",
                         case=="terrestrial heterotroph" ~ "TERRESTRIAL HETEROTROPH",
                         TRUE~case))%>%
  ggplot(aes(x=x,y=(predicted),group=group,fill=group))+
  geom_point(data=mutate(dbdx21,facet=ifelse(facet %in% "FRESHWATER","FRESHWATER",facet),
                         group=case_when(facet %in% "FRESHWATER" & group %in% "AUTOTROPH" ~ "FRESHWATER AUTOTROPH",
                                         facet %in% "FRESHWATER" & group %in% "HETEROTROPH" ~ "FRESHWATER HETEROTROPH",
                                         facet %in% "TERRESTRIAL" & group %in% "AUTOTROPH" ~ "TERRESTRIAL AUTOTROPH",
                                         facet %in% "TERRESTRIAL" & group %in% "HETEROTROPH" ~ "TERRESTRIAL HETEROTROPH",
                                         TRUE~group)),aes(x=x,y=(predicted),color=group,shape=group),
             alpha=0.3,show.legend = TRUE)+
  geom_line(aes(color=group,linetype=significance),linewidth=1,alpha=1,show.legend = FALSE)+
  scale_shape_manual(values=c(16,16,16,16),guide = guide_legend(ncol=2),labels=c('AUTOTROPH', 'HETEROTROPH','AUTOTROPH', 'HETEROTROPH'))+#1 or 16;  or 3 and 4
  scale_linetype_manual(values=c("dotted", "solid"),guide="none")+
  scale_color_manual(values=(c("FRESHWATER AUTOTROPH" = "cyan1",
                               "FRESHWATER HETEROTROPH" = "cyan4",
                               "TERRESTRIAL AUTOTROPH" = "goldenrod1",
                               "TERRESTRIAL HETEROTROPH" = "goldenrod4")),guide = guide_legend(ncol=4),labels=c('AUTOTROPH', 'HETEROTROPH','AUTOTROPH', 'HETEROTROPH'))+
  scale_fill_manual(values=(c("FRESHWATER AUTOTROPH" = "cyan1",
                              "FRESHWATER HETEROTROPH" = "cyan4",
                              "TERRESTRIAL AUTOTROPH" = "goldenrod1",
                              "TERRESTRIAL HETEROTROPH" = "goldenrod4" )),guide = guide_legend(ncol=4),labels=c('AUTOTROPH', 'HETEROTROPH','AUTOTROPH', 'HETEROTROPH'))+
  facet_nested(~facet,scales="free",independent="x")+
  theme_classic()+xlab("Absolute latitude")+ylab("logit(P)")+xlim(0,80)+
  theme(legend.position=c(0.5, 0.90),legend.title=element_blank())+#+guides(fill = "none"); "top"
  guides(colour = guide_legend(override.aes = list(alpha = 1)))+
  geom_text(data    = dat_text,  mapping = aes(x = 0, y =-1, label = label),  fontface = "bold")+
  scale_y_continuous(
    limits=c(-8,-1),
    breaks=seq(-8,-2,1),
    sec.axis = sec_axis(~.,name = "P (% dry mass)",breaks=derive(),labels=c("0.0",as.character(round(c(invlogit(seq(-7,-2,1))*100),1))))
    
  )

#pdf(file = "Figure 2.pdf", width = 6, height = 12, pointsize = 12)
pushViewport(viewport(layout = grid.layout(3, 1)))
vplayout <- function(x, y) viewport(layout.pos.row = x, layout.pos.col = y)
print(test2, vp = vplayout(1, 1))
print(test3, vp = vplayout(2, 1))
print(test4, vp = vplayout(3, 1))
dev.off()
#############################################

####Figure3
#############################################
#NP
load("data.lmer_1k_em_perm_lat_NP_1_sp.RData")

dbdx=lmemod@frame

ll1<-obsA_1
obsA<-obsA_1%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% "intercept"))%>%
  group_by(type,case,var)%>%
  summarise(pvalue=mean(abs(trend[iteration!=0]/SE[iteration!=0]) >= abs(trend[iteration==0]/SE[iteration==0])))
obsA$padjustBO<-p.adjust(obsA$pvalue)
obsA$padjustBH<-p.adjust(obsA$pvalue,method="BH")

#HABITAT
datte<-ggemmeans(lmemod,c("abs_lat.dec","habitat") ,typical="mean")%>%
  data.frame()%>%
  mutate(var="abs_lat.dec")

datC<-rbind(datte)%>%
  mutate(case=group)%>%
  left_join(obsA,by=c("case","var"))%>%
  mutate(significance=ifelse(padjustBH < 0.05,"significant","not significant")) #pvalue, padjustBO, padjustBH

dbdx2<-data.frame(predicted=(dbdx$Yl),facet=dbdx$habitat,group=dbdx$autohetero,x=c(dbdx$abs_lat.dec),var=rep(c("abs_lat.dec"),each=nrow(dbdx)))

datC1<-datC%>%
  mutate(group=ifelse(case %in% "freshwater","AQUATIC","TERRESTRIAL"),
         var=case_when(var == "abs_lat.dec" ~ "Absolute latitude",
                       TRUE ~ as.character(var)))%>%
  mutate(var=factor(var,levels=c("Absolute latitude")))
dbdx21<-dbdx2%>%
  mutate(group=ifelse(facet %in% "freshwater","AQUATIC","TERRESTRIAL"),
         
         var=case_when(var == "abs_lat.dec" ~ "Absolute latitude",
                       TRUE ~ as.character(var)))%>%
  mutate(var=factor(var,levels=c("Absolute latitude")))
dat_text <- data.frame(label = c("A", ""),facet   = c("FRESHWATER","TERRESTRIAL"),group=c("Autotrophs","Heterotrophs"))
new_label<-c("Absolute latitude" = "")
test5=datC1%>%
  mutate(group=ifelse(group %in% "AQUATIC","FRESHWATER",group))%>%
  ggplot(aes(x=x,y=(predicted),group=group,fill=group))+
  geom_point(data=mutate(dbdx21,group=ifelse(group %in% "AQUATIC","FRESHWATER",group)),aes(x=x,y=(predicted),color=group,shape=group),
             alpha=0.1,show.legend = TRUE)+
  geom_line(aes(color=group,linetype=significance),linewidth=1,show.legend = FALSE)+
  scale_shape_manual(values=c(16, 16))+#1 or 16;  or 3 and 4
  scale_linetype_manual(values=c("dotted", "solid"),guide = 'none')+
  scale_color_manual(values=c("FRESHWATER"="cyan3","TERRESTRIAL"="goldenrod3"))+
  scale_fill_manual(values=c("FRESHWATER"="cyan3","TERRESTRIAL"="goldenrod3"))+
  facet_nested(~var,scales="free",independent="x",labeller=labeller(var=new_label))+
  theme_classic()+xlab("Absolute Latitude")+ylab("log(N:P)")+
  xlim(0,80)+#ylim(c(0,200))+
  theme(legend.position=c(0.5,0.95),legend.title=element_blank(),legend.direction = "horizontal",
        strip.background = element_rect(color="white", fill="white", size=0))+
  guides(colour = guide_legend(override.aes = list(alpha = 1)))+
  geom_text(
    data    = dat_text,
    mapping = aes(x = 0, y = 7.5, label = label),
    fontface = "bold")+
  scale_y_continuous(
    limits=c(0,7.5),
    breaks=seq(0,6,2),
    sec.axis = sec_axis(~.,name = "N:P (molar ratio)",breaks=derive(),labels=c(as.character(round(c(exp(seq(0,6,2))),0))))
    
  )

#HABITAT TROPHIC INTERECTION
datte<-ggemmeans(lmemod,c("abs_lat.dec","autohetero","habitat") ,typical="mean")%>%
  data.frame()%>%
  mutate(var="abs_lat.dec")

datC<-rbind(datte)%>%
  mutate(case=paste0(facet," ",group))%>%
  left_join(obsA,by=c("case","var"))%>%
  mutate(significance=ifelse(padjustBH < 0.05,"significant","not significant")) #pvalue, padjustBO, padjustBH

dbdx2<-data.frame(predicted=(dbdx$Yl),facet=dbdx$habitat,group=dbdx$autohetero,x=c(dbdx$abs_lat.dec),var=rep(c("abs_lat.dec"),each=nrow(dbdx)))

datC1<-datC%>%
  mutate(group=ifelse(group %in% "autotroph","AUTOTROPH","HETEROTROPH"),
         facet=case_when(facet == "freshwater" ~ "FRESHWATER",
                         facet == "marine" ~ "MARINE",
                         facet == "terrestrial" ~ "TERRESTRIAL",
                         TRUE ~ as.character(facet)),
         var=case_when(var == "abs_lat.dec" ~ "Absolute latitude",
                       TRUE ~ as.character(var)))%>%
  mutate(var=factor(var,levels=c("Absolute latitude")))
dbdx21<-dbdx2%>%
  mutate(group=ifelse(group %in% "autotroph","AUTOTROPH","HETEROTROPH"),
         facet=case_when(facet == "freshwater" ~ "FRESHWATER",
                         facet == "marine" ~ "MARINE",
                         facet == "terrestrial" ~ "TERRESTRIAL",
                         TRUE ~ as.character(facet)),
         var=case_when(var == "abs_lat.dec" ~ "Absolute latitude",
                       TRUE ~ as.character(var)))%>%
  mutate(var=factor(var,levels=c("Absolute latitude")))
dat_text <- data.frame(label = c("B", ""),facet   = c("FRESHWATER","TERRESTRIAL"),group=c("Aquatic Autotrophs","Aquatic Heterotrophs","Terrestrial Autotrophs","Terrestrial Heterotrophs"))

test6=datC1%>%
  mutate(facet=ifelse(facet %in% "FRESHWATER","FRESHWATER",facet),
         group=case_when(case=="freshwater autotroph" ~ "FRESHWATER AUTOTROPH",
                         case=="freshwater heterotroph" ~ "FRESHWATER HETEROTROPH",
                         case=="terrestrial autotroph" ~ "TERRESTRIAL AUTOTROPH",
                         case=="terrestrial heterotroph" ~ "TERRESTRIAL HETEROTROPH",
                         TRUE~case))%>%
  ggplot(aes(x=x,y=(predicted),group=group,fill=group))+
  geom_point(data=mutate(dbdx21,facet=ifelse(facet %in% "FRESHWATER","FRESHWATER",facet),
                         group=case_when(facet %in% "FRESHWATER" & group %in% "AUTOTROPH" ~ "FRESHWATER AUTOTROPH",
                                         facet %in% "FRESHWATER" & group %in% "HETEROTROPH" ~ "FRESHWATER HETEROTROPH",
                                         facet %in% "TERRESTRIAL" & group %in% "AUTOTROPH" ~ "TERRESTRIAL AUTOTROPH",
                                         facet %in% "TERRESTRIAL" & group %in% "HETEROTROPH" ~ "TERRESTRIAL HETEROTROPH",
                                         TRUE~group)),aes(x=x,y=(predicted),color=group,shape=group),
             alpha=0.06,show.legend = TRUE)+
  geom_line(aes(color=group,linetype=significance),linewidth=1,alpha=0.9,show.legend = FALSE)+
  scale_shape_manual(values=c(16,16,16,16),guide = guide_legend(ncol=2),labels=c('AUTOTROPH', 'HETEROTROPH','AUTOTROPH', 'HETEROTROPH'))+#1 or 16;  or 3 and 4
  scale_linetype_manual(values=c("dotted", "solid"),guide="none")+
  scale_color_manual(values=(c("FRESHWATER AUTOTROPH" = "cyan1",
                               "FRESHWATER HETEROTROPH" = "cyan4",
                               "TERRESTRIAL AUTOTROPH" = "goldenrod1",
                               "TERRESTRIAL HETEROTROPH" = "goldenrod4")),guide = guide_legend(ncol=2),labels=c('AUTOTROPH', 'HETEROTROPH','AUTOTROPH', 'HETEROTROPH'))+
  scale_fill_manual(values=(c("FRESHWATER AUTOTROPH" = "cyan1",
                              "FRESHWATER HETEROTROPH" = "cyan4",
                              "TERRESTRIAL AUTOTROPH" = "goldenrod1",
                              "TERRESTRIAL HETEROTROPH" = "goldenrod4" )),guide = guide_legend(ncol=2),labels=c('AUTOTROPH', 'HETEROTROPH','AUTOTROPH', 'HETEROTROPH'))+
  facet_nested(~facet,scales="free",independent="x")+
  xlim(0,80)+#ylim(c(0,200))+
  theme_classic()+xlab("Absolute Latitude")+ylab("log(N:P)")+
  theme(legend.position=c(0.5, 0.86),legend.title=element_blank())+#+guides(fill = "none"); "top"
  guides(colour = guide_legend(override.aes = list(alpha = 1)))+
  geom_text(
    data    = dat_text,
    mapping = aes(x = 0, y = 7.5, label = label),
    fontface = "bold")+
  scale_y_continuous(
    limits=c(0,7.5),
    breaks=seq(0,6,2),
    sec.axis = sec_axis(~.,name = "N:P (molar ratio)",breaks=derive(),labels=c(as.character(round(c(exp(seq(0,6,2))),0))))
    
  )

#pdf(file = "Figure 3.pdf", width = 10, height = 4, pointsize = 12)
pushViewport(viewport(layout = grid.layout(1, 2)))
vplayout <- function(x, y) viewport(layout.pos.row = x, layout.pos.col = y)
print(test5, vp = vplayout(1, 1))
print(test6, vp = vplayout(1, 2))
dev.off()
#############################################

####Figure4
#############################################
load("data.lmer_1k_em_perm_N_1_sp_log_pred.RData")

dbdx=lmemod@frame

ll1<-obsA_1
obsA<-obsA_1%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% "intercept"))%>%
  group_by(type,case,var)%>%
  summarise(pvalue=mean(abs(trend[iteration!=0]/SE[iteration!=0]) >= abs(trend[iteration==0]/SE[iteration==0])))
obsA$padjustBO<-p.adjust(obsA$pvalue)
obsA$padjustBH<-p.adjust(obsA$pvalue,method="BH")

#OVERALL
datte<-ggemmeans(lmemod,c("N") ,typical="mean")%>%
  data.frame()%>%
  mutate(var="N")

datC<-rbind(datte)%>%
  mutate(case="overall")%>%
  left_join(obsA,by=c("case","var"))%>%
  mutate(significance=ifelse(padjustBH < 0.05,"significant","not significant")) #pvalue, padjustBO, padjustBH

dbdx2<-data.frame(predicted=(dbdx$Yl),facet=dbdx$habitat,group=dbdx$autohetero,x=c(dbdx$N),var=rep(c("N"),each=nrow(dbdx)))

datC1<-datC%>%
  mutate(group=ifelse(case %in% "freshwater","AQUATIC","TERRESTRIAL"),
         var=case_when(var == "N" ~ "N",
                       TRUE ~ as.character(var)))%>%
  mutate(var=factor(var,levels=c("N")))
dbdx21<-dbdx2%>%
  mutate(group=ifelse(facet %in% "freshwater","AQUATIC","TERRESTRIAL"),
         
         var=case_when(var == "N" ~ "N",
                       TRUE ~ as.character(var)))%>%
  mutate(var=factor(var,levels=c("Absolute latitude")))

dat_text <- data.frame(label = c("A"),group="TERRESTRIAL")
test1=datC1%>%
  mutate(group="OVERALL")%>%
  ggplot(aes(x=x,y=(predicted),group=group,fill=group))+
  geom_point(data=mutate(dbdx21,group="OVERALL"),aes(x=x,y=(predicted),color=group,shape=group),
             alpha=0.2,show.legend = TRUE)+
  geom_line(aes(color=group,linetype=significance),linewidth=1,show.legend = FALSE)+
  scale_shape_manual(values=c(16, 16))+#1 or 16;  or 3 and 4
  scale_linetype_manual(values=c("solid"),guide="none")+
  scale_color_manual(values=c("OVERALL"="darkgrey"))+##CC79A7
  scale_fill_manual(values=c("OVERALL"="darkgrey"))+
  theme_classic()+xlab("")+ylab("logit(N)")+
  theme(legend.position=c(0.5, 0.95),legend.title=element_blank())+#+guides(fill = "none")
  guides(colour = guide_legend(override.aes = list(alpha = 1)))+
  geom_text(
    data    = dat_text,
    mapping = aes(x = 3, y = -1, label = label),
    fontface = "bold")+
  scale_y_continuous(
    limits=c(-6,-1),
    breaks=seq(-6,-1,1),
    sec.axis = sec_axis(~.,name = "N (% dry mass)",breaks=derive(),labels=c(as.character(round(c(invlogit(seq(-6,-1,1))*100),1))))
    
  )

#TROPHIC
datte<-ggemmeans(lmemod,c("N","autohetero") ,typical="mean")%>%
  data.frame()%>%
  mutate(var="N")

datC<-rbind(datte)%>%
  mutate(case=group)%>%
  left_join(obsA,by=c("case","var"))%>%
  mutate(significance=ifelse(padjustBH < 0.05,"significant","not significant")) #pvalue, padjustBO, padjustBH

dbdx2<-data.frame(predicted=(dbdx$Yl),facet=dbdx$habitat,group=dbdx$autohetero,x=c(dbdx$N),var=rep(c("N"),each=nrow(dbdx)))

datC1<-datC%>%
  mutate(group=ifelse(group %in% "autotroph","AUTOTROPH","HETEROTROPH"),
         
         var=case_when(var == "N" ~ "N",
                       TRUE ~ as.character(var)))%>%
  mutate(var=factor(var,levels=c("N")))
dbdx21<-dbdx2%>%
  mutate(group=ifelse(group %in% "autotroph","AUTOTROPH","HETEROTROPH"),
         
         var=case_when(var == "N" ~ "N",
                       TRUE ~ as.character(var)))%>%
  mutate(var=factor(var,levels=c("N")))

dat_text <- data.frame(label = c("B", ""),facet   = c("FRESHWATER","TERRESTRIAL"), group=c("AUTOTROPH","HETEROTROPH"))
test2=datC1%>%
  ggplot(aes(x=x,y=(predicted),group=group,fill=group))+
  geom_point(data=mutate(dbdx21,facet=ifelse(facet %in% "FRESHWATER","AQUATIC",facet)),aes(x=x,y=(predicted),color=group,shape=group),
             alpha=0.1,show.legend = TRUE)+
  geom_line(aes(color=group,linetype=significance),linewidth=1,show.legend = FALSE)+
  scale_shape_manual(values=c(16, 16))+#1 or 16;  or 3 and 4
  scale_linetype_manual(values=c("dotted", "solid"),guide="none")+
  scale_color_manual(values=c("AUTOTROPH"="chartreuse4","HETEROTROPH"="chocolate"))+
  scale_fill_manual(values=c("AUTOTROPH"="chartreuse4","HETEROTROPH"="chocolate"))+
  theme_classic()+xlab("")+ylab("logit(N)")+
  theme(legend.position=c(0.5, 0.95),legend.title=element_blank(),legend.direction = "horizontal")+
  guides(colour = guide_legend(override.aes = list(alpha = 1)))+
  geom_text(
    data    = dat_text,
    mapping = aes(x = 3, y = -1, label = label),
    fontface = "bold")+
  scale_y_continuous(
    limits=c(-6,-1),
    breaks=seq(-6,-1,1),
    sec.axis = sec_axis(~.,name = "N (% dry mass)",breaks=derive(),labels=c(as.character(round(c(invlogit(seq(-6,-1,1))*100),1))))
    
  )

#HABITAT
datte<-ggemmeans(lmemod,c("N","habitat") ,typical="mean")%>%
  data.frame()%>%
  mutate(var="N")

datC<-rbind(datte)%>%
  mutate(case=group)%>%
  left_join(obsA,by=c("case","var"))%>%
  mutate(significance=ifelse(padjustBH < 0.05,"significant","not significant")) #pvalue, padjustBO, padjustBH

dbdx2<-data.frame(predicted=(dbdx$Yl),facet=dbdx$habitat,group=dbdx$autohetero,x=c(dbdx$N),var=rep(c("N"),each=nrow(dbdx)))

datC1<-datC%>%
  mutate(group=ifelse(case %in% "freshwater","AQUATIC","TERRESTRIAL"),
         var=case_when(var == "N" ~ "N",
                       TRUE ~ as.character(var)))%>%
  mutate(var=factor(var,levels=c("N")))
dbdx21<-dbdx2%>%
  mutate(group=ifelse(facet %in% "freshwater","AQUATIC","TERRESTRIAL"),
         
         var=case_when(var == "N" ~ "N",
                       TRUE ~ as.character(var)))%>%
  mutate(var=factor(var,levels=c("N")))
dat_text <- data.frame(label = c("C", ""),facet   = c("FRESHWATER","TERRESTRIAL"),group=c("Autotrophs","Heterotrophs"))
new_label<-c("N" = "")
test3=datC1%>%
  mutate(group=ifelse(group %in% "AQUATIC","FRESHWATER",group))%>%
  ggplot(aes(x=x,y=(predicted),group=group,fill=group))+
  geom_point(data=mutate(dbdx21,group=ifelse(group %in% "AQUATIC","FRESHWATER",group)),aes(x=x,y=(predicted),color=group,shape=group),
             alpha=0.1,show.legend = TRUE)+
  geom_line(aes(color=group,linetype=significance),linewidth=1,show.legend = FALSE)+
  scale_shape_manual(values=c(16, 16))+#1 or 16;  or 3 and 4
  scale_linetype_manual(values=c("dotted", "solid"),guide = 'none')+
  scale_color_manual(values=c("FRESHWATER"="cyan3","TERRESTRIAL"="goldenrod3"))+
  scale_fill_manual(values=c("FRESHWATER"="cyan3","TERRESTRIAL"="goldenrod3"))+
  facet_nested(~var,scales="free",independent="x",labeller=labeller(var=new_label))+
  theme_classic()+xlab("")+ylab("logit(N)")+
  theme(legend.position=c(0.5,0.95),legend.title=element_blank(),legend.direction = "horizontal",
        strip.background = element_rect(color="white", fill="white", size=0))+
  guides(colour = guide_legend(override.aes = list(alpha = 1)))+
  geom_text(
    data    = dat_text,
    mapping = aes(x = 3, y = 0, label = label),
    fontface = "bold")+
  scale_y_continuous(
    limits=c(-6,0),
    breaks=seq(-6,-1,1),
    sec.axis = sec_axis(~.,name = "N (% dry mass)",breaks=derive(),labels=c(as.character(round(c(invlogit(seq(-6,-1,1))*100),1))))
    
  )

#HABITAT TROPHIC INTERACTION
datn<-ggemmeans(lmemod,c("N","autohetero","habitat") ,typical="mean")%>%
  data.frame()%>%
  mutate(var="N")

datC<-rbind(datn)%>%
  mutate(case=paste0(facet," ",group))%>%
  left_join(obsA,by=c("case","var"))%>%
  mutate(significance=ifelse(padjustBH < 0.05,"significant","not significant")) #pvalue, padjustBO, padjustBH

dbdx2<-data.frame(predicted=(dbdx$Yl),facet=dbdx$habitat,group=dbdx$autohetero,x=c(dbdx$N),var=rep(c("N"),each=nrow(dbdx)))

datC1<-datC%>%
  mutate(group=ifelse(group %in% "autotroph","AUTOTROPH","HETEROTROPH"),
         facet=ifelse(facet %in% "freshwater","AQUATIC","TERRESTRIAL"),
         var=case_when(var == "Temp" ~ "Temperature",
                       var == "Rad" ~ "Radiation",
                       var == "N" ~ "N availability",
                       var == "P" ~ "P availability",
                       TRUE ~ as.character(var)))%>%
  mutate(var=factor(var,levels=c("Temperature", "Radiation","N availability", "P availability")))
dbdx21<-dbdx2%>%
  mutate(group=ifelse(group %in% "autotroph","AUTOTROPH","HETEROTROPH"),
         facet=ifelse(facet %in% "freshwater","AQUATIC","TERRESTRIAL"),
         var=case_when(var == "Temp" ~ "Temperature",
                       var == "Rad" ~ "Radiation",
                       var == "N" ~ "N availability",
                       var == "P" ~ "P availability",
                       TRUE ~ as.character(var)))%>%
  mutate(var=factor(var,levels=c("Temperature", "Radiation","N availability", "P availability")))

dat_text <- data.frame(label = c("D", ""),facet   = c("FRESHWATER","TERRESTRIAL"),group=c("Aquatic Autotrophs","Aquatic Heterotrophs","Terrestrial Autotrophs","Terrestrial Heterotrophs"))

test4=datC1%>%
  filter((var %in% c("N availability") & facet %in% c("AQUATIC"))|
           (var %in% c("N availability") & facet %in% c("TERRESTRIAL")))%>%
  mutate(facet=ifelse(facet %in% "AQUATIC","FRESHWATER",facet),
         group=case_when(case=="freshwater autotroph" ~ "FRESHWATER AUTOTROPH",
                         case=="freshwater heterotroph" ~ "FRESHWATER HETEROTROPH",
                         case=="terrestrial autotroph" ~ "TERRESTRIAL AUTOTROPH",
                         case=="terrestrial heterotroph" ~ "TERRESTRIAL HETEROTROPH",
                         TRUE~case))%>%
  ggplot(aes(x=x,y=(predicted),group=group,fill=group))+
  geom_point(data=filter(dbdx21,(var %in% c("N availability") & facet %in% c("AQUATIC"))|
                           (var %in% c("N availability") & facet %in% c("TERRESTRIAL")))%>%
               mutate(facet=ifelse(facet %in% "AQUATIC","FRESHWATER",facet),
                      group=case_when(facet %in% "FRESHWATER" & group %in% "AUTOTROPH" ~ "FRESHWATER AUTOTROPH",
                                      facet %in% "FRESHWATER" & group %in% "HETEROTROPH" ~ "FRESHWATER HETEROTROPH",
                                      facet %in% "TERRESTRIAL" & group %in% "AUTOTROPH" ~ "TERRESTRIAL AUTOTROPH",
                                      facet %in% "TERRESTRIAL" & group %in% "HETEROTROPH" ~ "TERRESTRIAL HETEROTROPH",
                                      TRUE~group)),aes(x=x,y=(predicted),color=group,shape=group),alpha=0.2,show.legend = TRUE)+
  geom_line(aes(color=group,linetype=significance),linewidth=1,alpha=0.9,show.legend = FALSE)+
  scale_shape_manual(values=c(16,16,16,16),guide = guide_legend(ncol=2),labels=c('AUTOTROPH', 'HETEROTROPH','AUTOTROPH', 'HETEROTROPH'))+#1 or 16;  or 3 and 4
  scale_linetype_manual(values=c("dotted", "solid"),guide="none")+
  scale_color_manual(values=(c("FRESHWATER AUTOTROPH" = "cyan1",
                               "FRESHWATER HETEROTROPH" = "cyan4",
                               "TERRESTRIAL AUTOTROPH" = "goldenrod1",
                               "TERRESTRIAL HETEROTROPH" = "goldenrod4")),guide = guide_legend(ncol=2),labels=c('AUTOTROPH', 'HETEROTROPH','AUTOTROPH', 'HETEROTROPH'))+
  scale_fill_manual(values=(c("FRESHWATER AUTOTROPH" = "cyan1",
                              "FRESHWATER HETEROTROPH" = "cyan4",
                              "TERRESTRIAL AUTOTROPH" = "goldenrod1",
                              "TERRESTRIAL HETEROTROPH" = "goldenrod4" )),guide = guide_legend(ncol=2),labels=c('AUTOTROPH', 'HETEROTROPH','AUTOTROPH', 'HETEROTROPH'))+
  facet_nested(~facet,scales="free",independent="x")+
  theme_classic()+xlab("")+ylab("logit(N)")+
  theme(legend.position=c(0.5, 0.88),legend.title=element_blank())+
  guides(colour = guide_legend(override.aes = list(alpha = 1)))+
  geom_text(
    data    = dat_text,
    mapping = aes(x = 3, y = 0, label = label),
    fontface = "bold")+
  scale_y_continuous(
    limits=c(-6,0),
    breaks=seq(-6,-1,1),
    sec.axis = sec_axis(~.,name = "N (% dry mass)",breaks=derive(),labels=c(as.character(round(c(invlogit(seq(-6,-1,1))*100),1))))
    
  )

load("data.lmer_1k_em_perm_NP_1_sp_log_pred.RData")

dbdx=lmemod@frame

ll1<-obsA_1
obsA<-obsA_1%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% "intercept"))%>%
  group_by(type,case,var)%>%
  summarise(pvalue=mean(abs(trend[iteration!=0]/SE[iteration!=0]) >= abs(trend[iteration==0]/SE[iteration==0])))
obsA$padjustBO<-p.adjust(obsA$pvalue)
obsA$padjustBH<-p.adjust(obsA$pvalue,method="BH")


#HABITAT
datte<-ggemmeans(lmemod,c("N","habitat") ,typical="mean")%>%
  data.frame()%>%
  mutate(var="N")

datC<-rbind(datte)%>%
  mutate(case=group)%>%
  left_join(obsA,by=c("case","var"))%>%
  mutate(significance=ifelse(padjustBH < 0.05,"significant","not significant")) #pvalue, padjustBO, padjustBH

dbdx2<-data.frame(predicted=(dbdx$Yl),facet=dbdx$habitat,group=dbdx$autohetero,x=c(dbdx$N),var=rep(c("N"),each=nrow(dbdx)))

datC1<-datC%>%
  mutate(group=ifelse(case %in% "freshwater","AQUATIC","TERRESTRIAL"),
         var=case_when(var == "N" ~ "N",
                       TRUE ~ as.character(var)))%>%
  mutate(var=factor(var,levels=c("N")))
dbdx21<-dbdx2%>%
  mutate(group=ifelse(facet %in% "freshwater","AQUATIC","TERRESTRIAL"),
         
         var=case_when(var == "N" ~ "N",
                       TRUE ~ as.character(var)))%>%
  mutate(var=factor(var,levels=c("N")))
dat_text <- data.frame(label = c("E", ""),facet   = c("FRESHWATER","TERRESTRIAL"),group=c("Autotrophs","Heterotrophs"))
new_label<-c("N" = "")
test5=datC1%>%
  mutate(group=ifelse(group %in% "AQUATIC","FRESHWATER",group))%>%
  ggplot(aes(x=x,y=(predicted),group=group,fill=group))+
  geom_point(data=mutate(dbdx21,group=ifelse(group %in% "AQUATIC","FRESHWATER",group)),aes(x=x,y=(predicted),color=group,shape=group),
             alpha=0.2,show.legend = TRUE)+
  geom_line(aes(color=group,linetype=significance),linewidth=1,show.legend = FALSE)+
  scale_shape_manual(values=c(16, 16))+#1 or 16;  or 3 and 4
  scale_linetype_manual(values=c("dotted", "solid"),guide = 'none')+
  scale_color_manual(values=c("FRESHWATER"="cyan3","TERRESTRIAL"="goldenrod3"))+
  scale_fill_manual(values=c("FRESHWATER"="cyan3","TERRESTRIAL"="goldenrod3"))+
  facet_nested(~var,scales="free",independent="x",labeller=labeller(var=new_label))+
  theme_classic()+xlab(expression("log(N deposition)"))+ylab("log(N:P)")+
  theme(legend.position=c(0.5,0.95),legend.title=element_blank(),legend.direction = "horizontal",
        strip.background = element_rect(color="white", fill="white", size=0))+
  guides(colour = guide_legend(override.aes = list(alpha = 1)))+
  geom_text(
    data    = dat_text,
    mapping = aes(x = 3, y = 7, label = label),
    fontface = "bold")+
  scale_y_continuous(
    limits=c(0,7),
    breaks=seq(0,5,1),
    sec.axis = sec_axis(~.,name = "N:P (molar ratio)",breaks=derive(),labels=c(as.character(round(c(exp(seq(0,5,1))),0))))
     
  )

#HABITAT TROPHIC INTERACTION
datn<-ggemmeans(lmemod,c("N","autohetero","habitat") ,typical="mean")%>%
  data.frame()%>%
  mutate(var="N")

datC<-rbind(datn)%>%
  mutate(case=paste0(facet," ",group))%>%
  left_join(obsA,by=c("case","var"))%>%
  mutate(significance=ifelse(padjustBH < 0.05,"significant","not significant")) #pvalue, padjustBO, padjustBH

dbdx2<-data.frame(predicted=(dbdx$Yl),facet=dbdx$habitat,group=dbdx$autohetero,x=c(dbdx$N),var=rep(c("N"),each=nrow(dbdx)))

datC1<-datC%>%
  mutate(group=ifelse(group %in% "autotroph","AUTOTROPH","HETEROTROPH"),
         facet=ifelse(facet %in% "freshwater","AQUATIC","TERRESTRIAL"),
         var=case_when(var == "Temp" ~ "Temperature",
                       var == "Rad" ~ "Radiation",
                       var == "N" ~ "N availability",
                       var == "P" ~ "P availability",
                       TRUE ~ as.character(var)))%>%
  mutate(var=factor(var,levels=c("Temperature", "Radiation","N availability", "P availability")))
dbdx21<-dbdx2%>%
  mutate(group=ifelse(group %in% "autotroph","AUTOTROPH","HETEROTROPH"),
         facet=ifelse(facet %in% "freshwater","AQUATIC","TERRESTRIAL"),
         var=case_when(var == "Temp" ~ "Temperature",
                       var == "Rad" ~ "Radiation",
                       var == "N" ~ "N availability",
                       var == "P" ~ "P availability",
                       TRUE ~ as.character(var)))%>%
  mutate(var=factor(var,levels=c("Temperature", "Radiation","N availability", "P availability")))

dat_text <- data.frame(label = c("F", ""),facet   = c("FRESHWATER","TERRESTRIAL"),group=c("Aquatic Autotrophs","Aquatic Heterotrophs","Terrestrial Autotrophs","Terrestrial Heterotrophs"))

test6=datC1%>%
  filter((var %in% c("N availability") & facet %in% c("AQUATIC"))|
           (var %in% c("N availability") & facet %in% c("TERRESTRIAL")))%>%
  mutate(facet=ifelse(facet %in% "AQUATIC","FRESHWATER",facet),
         group=case_when(case=="freshwater autotroph" ~ "FRESHWATER AUTOTROPH",
                         case=="freshwater heterotroph" ~ "FRESHWATER HETEROTROPH",
                         case=="terrestrial autotroph" ~ "TERRESTRIAL AUTOTROPH",
                         case=="terrestrial heterotroph" ~ "TERRESTRIAL HETEROTROPH",
                         TRUE~case))%>%
  ggplot(aes(x=x,y=(predicted),group=group,fill=group))+
  geom_point(data=filter(dbdx21,(var %in% c("N availability") & facet %in% c("AQUATIC"))|
                           (var %in% c("N availability") & facet %in% c("TERRESTRIAL")))%>%
               mutate(facet=ifelse(facet %in% "AQUATIC","FRESHWATER",facet),
                      group=case_when(facet %in% "FRESHWATER" & group %in% "AUTOTROPH" ~ "FRESHWATER AUTOTROPH",
                                      facet %in% "FRESHWATER" & group %in% "HETEROTROPH" ~ "FRESHWATER HETEROTROPH",
                                      facet %in% "TERRESTRIAL" & group %in% "AUTOTROPH" ~ "TERRESTRIAL AUTOTROPH",
                                      facet %in% "TERRESTRIAL" & group %in% "HETEROTROPH" ~ "TERRESTRIAL HETEROTROPH",
                                      TRUE~group)),aes(x=x,y=(predicted),color=group,shape=group),alpha=0.1,show.legend = TRUE)+
  geom_line(aes(color=group,linetype=significance),linewidth=1,alpha=0.9,show.legend = FALSE)+
  scale_shape_manual(values=c(16,16,16,16),guide = guide_legend(ncol=2),labels=c('AUTOTROPH', 'HETEROTROPH','AUTOTROPH', 'HETEROTROPH'))+#1 or 16;  or 3 and 4
  scale_linetype_manual(values=c("dotted", "solid"),guide="none")+
  scale_color_manual(values=(c("FRESHWATER AUTOTROPH" = "cyan1",
                               "FRESHWATER HETEROTROPH" = "cyan4",
                               "TERRESTRIAL AUTOTROPH" = "goldenrod1",
                               "TERRESTRIAL HETEROTROPH" = "goldenrod4")),guide = guide_legend(ncol=2),labels=c('AUTOTROPH', 'HETEROTROPH','AUTOTROPH', 'HETEROTROPH'))+
  scale_fill_manual(values=(c("FRESHWATER AUTOTROPH" = "cyan1",
                              "FRESHWATER HETEROTROPH" = "cyan4",
                              "TERRESTRIAL AUTOTROPH" = "goldenrod1",
                              "TERRESTRIAL HETEROTROPH" = "goldenrod4" )),guide = guide_legend(ncol=2),labels=c('AUTOTROPH', 'HETEROTROPH','AUTOTROPH', 'HETEROTROPH'))+
  facet_nested(~facet,scales="free",independent="x")+
  theme_classic()+xlab(expression("log(N deposition)"))+ylab("log(N:P)")+
  theme(legend.position=c(0.5, 0.88),legend.title=element_blank())+
  guides(colour = guide_legend(override.aes = list(alpha = 1)))+
  geom_text(
    data    = dat_text,
    mapping = aes(x = 3, y = 7, label = label),
    fontface = "bold")+
  scale_y_continuous(
    limits=c(0,7),
    breaks=seq(0,5,1),
    sec.axis = sec_axis(~.,name = "N:P (molar ratio)",breaks=derive(),labels=c(as.character(round(c(exp(seq(0,5,1))),0))))
     
  )

#pdf(file = "Figure 4.pdf",width = 10, height = 12,pointsize = 12)
pushViewport(viewport(layout = grid.layout(3, 2)))
vplayout <- function(x, y) viewport(layout.pos.row = x, layout.pos.col = y)
print(test1, vp = vplayout(1, 1))
print(test2, vp = vplayout(1, 2))
print(test3, vp = vplayout(2, 1))
print(test4, vp = vplayout(2, 2))
print(test5, vp = vplayout(3, 1))
print(test6, vp = vplayout(3, 2))
dev.off()
#############################################

####Figure S2 - nitrogen
#############################################
#N
load("data.lmer_1k_em_perm_lat_N_1_sp.RData")

dbdx=lmemod@frame

ll1<-obsA_1
obsA<-obsA_1%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% "intercept"))%>%
  group_by(type,case,var)%>%
  summarise(pvalue=mean(abs(trend[iteration!=0]/SE[iteration!=0]) >= abs(trend[iteration==0]/SE[iteration==0])))
obsA$padjustBO<-p.adjust(obsA$pvalue)
obsA$padjustBH<-p.adjust(obsA$pvalue,method="BH")

#TROPHIC
datte<-ggemmeans(lmemod,c("abs_lat.dec","autohetero") ,typical="mean")%>%
  data.frame()%>%
  mutate(var="abs_lat.dec")

datC<-rbind(datte)%>%
  mutate(case=group)%>%
  left_join(obsA,by=c("case","var"))%>%
  mutate(significance=ifelse(padjustBH < 0.05,"significant","not significant")) #pvalue, padjustBO, padjustBH

dbdx2<-data.frame(predicted=(dbdx$Yl),facet=dbdx$habitat,group=dbdx$autohetero,x=c(dbdx$abs_lat.dec),var=rep(c("abs_lat.dec"),each=nrow(dbdx)))

datC1<-datC%>%
  mutate(group=ifelse(group %in% "autotroph","AUTOTROPH","HETEROTROPH"),
         
         var=case_when(var == "abs_lat.dec" ~ "Absolute latitude",
                       TRUE ~ as.character(var)))%>%
  mutate(var=factor(var,levels=c("Absolute latitude")))
dbdx21<-dbdx2%>%
  mutate(group=ifelse(group %in% "autotroph","AUTOTROPH","HETEROTROPH"),
         
         var=case_when(var == "abs_lat.dec" ~ "Absolute latitude",
                       TRUE ~ as.character(var)))%>%
  mutate(var=factor(var,levels=c("Absolute latitude")))

dat_text <- data.frame(label = c("A", ""),facet   = c("FRESHWATER","TERRESTRIAL"), group=c("AUTOTROPH","HETEROTROPH"))
test2=datC1%>%
  ggplot(aes(x=x,y=(predicted),group=group,fill=group))+
  geom_point(data=mutate(dbdx21,facet=ifelse(facet %in% "FRESHWATER","AQUATIC",facet)),aes(x=x,y=(predicted),color=group,shape=group),
             alpha=0.2,show.legend = TRUE)+
  geom_line(aes(color=group,linetype=significance),linewidth=1,show.legend = FALSE)+
  scale_shape_manual(values=c(16, 16))+#1 or 16;  or 3 and 4
  scale_linetype_manual(values=c("dotted", "solid"),guide="none")+
  scale_color_manual(values=c("AUTOTROPH"="chartreuse4","HETEROTROPH"="chocolate"))+
  scale_fill_manual(values=c("AUTOTROPH"="chartreuse4","HETEROTROPH"="chocolate"))+
  theme_classic()+xlab("")+ylab("logit(N)")+xlim(0,80)+
  theme(legend.position=c(0.5, 0.08),legend.title=element_blank(), legend.direction = "horizontal")+
  guides(colour = guide_legend(override.aes = list(alpha = 1)))+
  geom_text(
    data    = dat_text,
    mapping = aes(x = 0, y = -1, label = label),
    fontface = "bold")+
  scale_y_continuous(
    limits=c(-7.5,-1),
    breaks=seq(-7,-1,1),
    sec.axis = sec_axis(~.,name = "N (% dry mass)",breaks=derive(),labels=c(as.character(round(c(invlogit(seq(-7,-1,1))*100),1))))
    
  )

#HABITAT
datte<-ggemmeans(lmemod,c("abs_lat.dec","habitat") ,typical="mean")%>%
  data.frame()%>%
  mutate(var="abs_lat.dec")

datC<-rbind(datte)%>%
  mutate(case=group)%>%
  left_join(obsA,by=c("case","var"))%>%
  mutate(significance=ifelse(padjustBH < 0.05,"significant","not significant")) #pvalue, padjustBO, padjustBH

dbdx2<-data.frame(predicted=(dbdx$Yl),facet=dbdx$habitat,group=dbdx$autohetero,x=c(dbdx$abs_lat.dec),var=rep(c("abs_lat.dec"),each=nrow(dbdx)))

datC1<-datC%>%
  mutate(group=ifelse(case %in% "freshwater","FRESHWATER","TERRESTRIAL"),
         var=case_when(var == "abs_lat.dec" ~ "Absolute latitude",
                       TRUE ~ as.character(var)))%>%
  mutate(var=factor(var,levels=c("Absolute latitude")))
dbdx21<-dbdx2%>%
  mutate(group=ifelse(facet %in% "freshwater","FRESHWATER","TERRESTRIAL"),
         
         var=case_when(var == "abs_lat.dec" ~ "Absolute latitude",
                       TRUE ~ as.character(var)))%>%
  mutate(var=factor(var,levels=c("Absolute latitude")))
new_label<-c("Absolute latitude" = "")
dat_text <- data.frame(label = c("B"),facet   = c("FRESHWATER","TERRESTRIAL"), group=c("Autotrophs","Heterotrophs"))
test3=datC1%>%
  ggplot(aes(x=x,y=(predicted),group=group,fill=group))+
  geom_point(data=mutate(dbdx21,facet=ifelse(facet %in% "FRESHWATER","FRESHWATER",facet)),aes(x=x,y=(predicted),color=group,shape=group),
             alpha=0.2,show.legend = TRUE)+
  geom_line(aes(color=group,linetype=significance),linewidth=1,show.legend = FALSE)+
  scale_shape_manual(values=c(16, 16))+#1 or 16;  or 3 and 4
  scale_linetype_manual(values=c("dotted", "solid"),guide="none")+
  scale_color_manual(values=c("FRESHWATER"="cyan3","TERRESTRIAL"="goldenrod3"))+
  scale_fill_manual(values=c("FRESHWATER"="cyan3","TERRESTRIAL"="goldenrod3"))+
  facet_nested(~var,scales="free",independent="x",labeller=labeller(var=new_label))+
  theme_classic()+xlab("")+ylab("logit(N)")+xlim(0,80)+
  theme(legend.position=c(0.5, 0.08),legend.title=element_blank(), legend.direction = "horizontal",
        strip.background = element_rect(color="white", fill="white", size=0))+
  guides(colour = guide_legend(override.aes = list(alpha = 1)))+
  geom_text(
    data    = dat_text,
    mapping = aes(x = 0, y = -1, label = label),
    fontface = "bold")+
  scale_y_continuous(
    limits=c(-7.5,-1),
    breaks=seq(-7,-1,1),
    sec.axis = sec_axis(~.,name = "N (% dry mass)",breaks=derive(),labels=c(as.character(round(c(invlogit(seq(-7,-1,1))*100),1))))
     
  )

#HABITAT*TROPHIC INTERACTION
datte<-ggemmeans(lmemod,c("abs_lat.dec","autohetero","habitat") ,typical="mean")%>%
  data.frame()%>%
  mutate(var="abs_lat.dec")

datC<-rbind(datte)%>%
  mutate(case=paste0(facet," ",group))%>%
  left_join(obsA,by=c("case","var"))%>%
  mutate(significance=ifelse(padjustBH < 0.05,"significant","not significant")) #pvalue, padjustBO, padjustBH

dbdx2<-data.frame(predicted=(dbdx$Yl),facet=dbdx$habitat,group=dbdx$autohetero,x=c(dbdx$abs_lat.dec),var=rep(c("abs_lat.dec"),each=nrow(dbdx)))

datC1<-datC%>%
  mutate(group=ifelse(group %in% "autotroph","AUTOTROPH","HETEROTROPH"),
         facet=case_when(facet == "freshwater" ~ "FRESHWATER",
                         facet == "marine" ~ "MARINE",
                         facet == "terrestrial" ~ "TERRESTRIAL",
                         TRUE ~ as.character(facet)),
         var=case_when(var == "abs_lat.dec" ~ "Absolute latitude",
                       TRUE ~ as.character(var)))%>%
  mutate(var=factor(var,levels=c("Absolute latitude")))
dbdx21<-dbdx2%>%
  mutate(group=ifelse(group %in% "autotroph","AUTOTROPH","HETEROTROPH"),
         facet=case_when(facet == "freshwater" ~ "FRESHWATER",
                         facet == "marine" ~ "MARINE",
                         facet == "terrestrial" ~ "TERRESTRIAL",
                         TRUE ~ as.character(facet)),
         var=case_when(var == "abs_lat.dec" ~ "Absolute latitude",
                       TRUE ~ as.character(var)))%>%
  mutate(var=factor(var,levels=c("Absolute latitude")))
dat_text <- data.frame(
  label = c("C", ""),
  facet   = c("FRESHWATER","TERRESTRIAL"),
  group=c("Aquatic Autotrophs","Aquatic Heterotrophs","Terrestrial Autotrophs","Terrestrial Heterotrophs")
)

test4=datC1%>%
  mutate(facet=ifelse(facet %in% "FRESHWATER","FRESHWATER",facet),
         group=case_when(case=="freshwater autotroph" ~ "FRESHWATER AUTOTROPH",
                         case=="freshwater heterotroph" ~ "FRESHWATER HETEROTROPH",
                         case=="terrestrial autotroph" ~ "TERRESTRIAL AUTOTROPH",
                         case=="terrestrial heterotroph" ~ "TERRESTRIAL HETEROTROPH",
                         TRUE~case))%>%
  ggplot(aes(x=x,y=(predicted),group=group,fill=group))+
  geom_point(data=mutate(dbdx21,facet=ifelse(facet %in% "FRESHWATER","FRESHWATER",facet),
                         group=case_when(facet %in% "FRESHWATER" & group %in% "AUTOTROPH" ~ "FRESHWATER AUTOTROPH",
                                         facet %in% "FRESHWATER" & group %in% "HETEROTROPH" ~ "FRESHWATER HETEROTROPH",
                                         facet %in% "TERRESTRIAL" & group %in% "AUTOTROPH" ~ "TERRESTRIAL AUTOTROPH",
                                         facet %in% "TERRESTRIAL" & group %in% "HETEROTROPH" ~ "TERRESTRIAL HETEROTROPH",
                                         TRUE~group)),aes(x=x,y=(predicted),color=group,shape=group),
             alpha=0.3,show.legend = TRUE)+
  geom_line(aes(color=group,linetype=significance),linewidth=1,alpha=1,show.legend = FALSE)+
  scale_shape_manual(values=c(16,16,16,16),guide = guide_legend(ncol=2),labels=c('AUTOTROPH', 'HETEROTROPH','AUTOTROPH', 'HETEROTROPH'))+#1 or 16;  or 3 and 4
  scale_linetype_manual(values=c("dotted", "solid"),guide="none")+
  scale_color_manual(values=(c("FRESHWATER AUTOTROPH" = "cyan1",
                               "FRESHWATER HETEROTROPH" = "cyan4",
                               "TERRESTRIAL AUTOTROPH" = "goldenrod1",
                               "TERRESTRIAL HETEROTROPH" = "goldenrod4")),guide = guide_legend(ncol=4),labels=c('AUTOTROPH', 'HETEROTROPH','AUTOTROPH', 'HETEROTROPH'))+
  scale_fill_manual(values=(c("FRESHWATER AUTOTROPH" = "cyan1",
                              "FRESHWATER HETEROTROPH" = "cyan4",
                              "TERRESTRIAL AUTOTROPH" = "goldenrod1",
                              "TERRESTRIAL HETEROTROPH" = "goldenrod4" )),guide = guide_legend(ncol=4),labels=c('AUTOTROPH', 'HETEROTROPH','AUTOTROPH', 'HETEROTROPH'))+
  facet_nested(~facet,scales="free",independent="x")+
  theme_classic()+xlab("Absolute latitude")+ylab("logit(N)")+xlim(0,80)+
  theme(legend.position=c(0.5, 0.112),legend.title=element_blank())+#+guides(fill = "none"); "top"
  guides(colour = guide_legend(override.aes = list(alpha = 1)))+
  geom_text(data    = dat_text,  mapping = aes(x = 0, y =-1, label = label),  fontface = "bold")+
  scale_y_continuous(
    limits=c(-7.5,-1),
    breaks=seq(-7,-1,1),
    sec.axis = sec_axis(~.,name = "N (% dry mass)",breaks=derive(),labels=c(as.character(round(c(invlogit(seq(-7,-1,1))*100),1))))
    
  )


#pdf(file = "Figure S2.pdf",width = 6, height = 11,pointsize = 12)
pushViewport(viewport(layout = grid.layout(3, 1)))
vplayout <- function(x, y) viewport(layout.pos.row = x, layout.pos.col = y)
print(test2, vp = vplayout(1, 1))
print(test3, vp = vplayout(2, 1))
print(test4, vp = vplayout(3, 1))
dev.off()
#############################################

####Figure S3, S4, S5 - plasticity vs turnover
#############################################
library(forcats)
library(glue)
#set combinations of elements
combi<-c("taxa.p","taxa.n","taxa.c","taxa.np","taxa.cp","taxa.cn")

#set element to response: 1=taxa.p, 2=taxa.n, 4=taxa.np
element=2

test<-db%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_terr_lab,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(paste0(lat.dec," ",long.dec)))%>%
  dplyr::select(combi[element],Temp,Rad,N,P,habitat,autohetero,sp.morphosp_revised,location)%>%
  as.data.frame()%>%
  na.omit()

test_large_range=test%>%
  group_by(sp.morphosp_revised,habitat,autohetero)%>%
  summarize(medN=median(N,na.rm=TRUE),
            minN=min(N,na.rm=TRUE),
            maxN=max(N,na.rm=TRUE),
            rangeN=maxN-minN)%>%
  arrange(desc(rangeN))%>%
  ungroup()%>%
  filter(rangeN>500)

FigSX1=test%>%
  group_by(sp.morphosp_revised,habitat,autohetero)%>%
  summarize(medN=median(N,na.rm=TRUE),
            minN=min(N,na.rm=TRUE),
            maxN=max(N,na.rm=TRUE))%>%
  filter(!is.na(medN))%>%
  arrange(medN)%>%
  ungroup()%>%
  mutate(rangeN=maxN-minN,
         rangeN=ifelse(rangeN>500,"broad","narrow"))%>%
  mutate(
    category3 = interaction(habitat,autohetero,sp.morphosp_revised),
    category3 = forcats::fct_inorder(fct_drop(category3))) %>%
  mutate(group=case_when(habitat %in% "freshwater" & autohetero %in% "autotroph" ~ "AQUATIC AUTOTROPH",
                         habitat %in% "freshwater" & autohetero %in% "heterotroph" ~ "AQUATIC HETEROTROPH",
                         habitat %in% "terrestrial" & autohetero %in% "autotroph" ~ "TERRESTRIAL AUTOTROPH",
                         habitat %in% "terrestrial" & autohetero %in% "heterotroph" ~ "TERRESTRIAL HETEROTROPH",
                         TRUE~as.character(habitat)))%>%
  mutate(habitat=case_when(habitat %in% "freshwater" ~ "FRESHWATER",
                           habitat %in% "terrestrial" ~ "TERRESTRIAL",
                           TRUE~as.character(habitat)))%>%
  mutate(autohetero=case_when(autohetero %in% "autotroph" ~ "AUTOTROPH",
                              autohetero %in% "heterotroph" ~ "HETEROTROPH",
                              TRUE~as.character(autohetero)))%>%
  ungroup()%>%
  ggplot(aes(x = category3, y = medN,group=category3,fill=sp.morphosp_revised,colour=group,linetype=rangeN),show.legend=F) +
  geom_point(size=2,show.legend=F)+
  geom_errorbar(aes(ymin=minN, ymax=maxN), width=1,show.legend=F)+
  scale_color_manual(values=(c("AQUATIC AUTOTROPH" = "cyan1",
                               "AQUATIC HETEROTROPH" = "cyan4",
                               "TERRESTRIAL AUTOTROPH" = "goldenrod1",
                               "TERRESTRIAL HETEROTROPH" = "goldenrod4")))+
  scale_linetype_manual(values = c("solid", "dashed"))+
  facet_nested(autohetero~habitat,scales="free")+
  theme(axis.text.y=element_blank(),axis.ticks.y=element_blank(),)+
  theme(strip.background = element_rect(color="black", fill="white", size=0))+
  annotate("segment", x=-Inf, xend=Inf, y=-Inf, yend=-Inf)+
  annotate("segment", x=-Inf, xend=-Inf, y=-Inf, yend=Inf)+
  xlab("Species")+ylab(expression("N deposition ( kg N /"~km^2~"/"~year~")"))+
  coord_flip()

#pdf(file = "Figure S4.pdf",width = 7, height = 7,pointsize = 12)
pushViewport(viewport(layout = grid.layout(1, 1)))
vplayout <- function(x, y) viewport(layout.pos.row = x, layout.pos.col = y)
print(FigSX1, vp = vplayout(1, 1))
dev.off()


FigSX2=test%>%
  filter(!is.na(N))%>%
  group_by(sp.morphosp_revised,habitat,autohetero)%>%
  summarize(medN=median(taxa.n,na.rm=TRUE),
            minN=min(taxa.n,na.rm=TRUE),
            maxN=max(taxa.n,na.rm=TRUE))%>%
  arrange(medN)%>%
  filter(!is.na(medN))%>%
  ungroup()%>%
  mutate(
    category3 = interaction(habitat,autohetero,sp.morphosp_revised),
    category3 = forcats::fct_inorder(fct_drop(category3))) %>%
  mutate(group=case_when(habitat %in% "freshwater" & autohetero %in% "autotroph" ~ "AQUATIC AUTOTROPH",
                         habitat %in% "freshwater" & autohetero %in% "heterotroph" ~ "AQUATIC HETEROTROPH",
                         habitat %in% "terrestrial" & autohetero %in% "autotroph" ~ "TERRESTRIAL AUTOTROPH",
                         habitat %in% "terrestrial" & autohetero %in% "heterotroph" ~ "TERRESTRIAL HETEROTROPH",
                         TRUE~as.character(habitat)))%>%
  mutate(habitat=case_when(habitat %in% "freshwater" ~ "AQUATIC",
                           habitat %in% "terrestrial" ~ "TERRESTRIAL",
                           TRUE~as.character(habitat)))%>%
  mutate(autohetero=case_when(autohetero %in% "autotroph" ~ "AUTOTROPH",
                              autohetero %in% "heterotroph" ~ "HETEROTROPH",
                              TRUE~as.character(autohetero)))%>%
  ggplot(aes(x = category3, y = medN,group=category3,fill=sp.morphosp_revised,colour=group),show.legend=F) +
  geom_point(size=2,show.legend=F)+
  geom_errorbar(aes(ymin=minN, ymax=maxN), width=1,show.legend=F)+
  scale_color_manual(values=(c("AQUATIC AUTOTROPH" = "cyan1",
                               "AQUATIC HETEROTROPH" = "cyan4",
                               "TERRESTRIAL AUTOTROPH" = "goldenrod1",
                               "TERRESTRIAL HETEROTROPH" = "goldenrod4")))+
  facet_nested(autohetero~habitat,scales="free")+
  theme(axis.text.y=element_blank(),axis.ticks.y=element_blank(),)+
  theme(strip.background = element_rect(color="black", fill="white", size=0))+
  annotate("segment", x=-Inf, xend=Inf, y=-Inf, yend=-Inf)+
  annotate("segment", x=-Inf, xend=-Inf, y=-Inf, yend=Inf)+
  xlab("Species")+ylab("N content")+
  coord_flip()

#jpeg("FigSX2.jpeg",width=2000,height=2000,res=300)
pushViewport(viewport(layout = grid.layout(1, 1)))
vplayout <- function(x, y) viewport(layout.pos.row = x, layout.pos.col = y)
print(FigSX2, vp = vplayout(1, 1))
dev.off()



#range
test1=test%>%
  group_by(sp.morphosp_revised,habitat,autohetero)%>%
  summarize(rg.Nenv=max(N,na.rm=T)-min(N,na.rm=T),
            rg.Ncontent=max(taxa.n,na.rm=T)-min(taxa.n,na.rm=T))%>%
  filter((!is.na(rg.Ncontent)&(!is.na(rg.Nenv))))#%>%filter(rg.Nenv>0)

aa=cor.test(test1[test1$habitat %in% "freshwater" & test1$autohetero %in% "autotroph",]$rg.Nenv,
            test1[test1$habitat %in% "freshwater" & test1$autohetero %in% "autotroph",]$rg.Ncontent,method = "spearman")
ah=cor.test(test1[test1$habitat %in% "freshwater" & test1$autohetero %in% "heterotroph",]$rg.Nenv,
            test1[test1$habitat %in% "freshwater" & test1$autohetero %in% "heterotroph",]$rg.Ncontent,method = "spearman")
ta=cor.test(test1[test1$habitat %in% "terrestrial" & test1$autohetero %in% "autotroph",]$rg.Nenv,
            test1[test1$habitat %in% "terrestrial" & test1$autohetero %in% "autotroph",]$rg.Ncontent,method = "spearman")
th=cor.test(test1[test1$habitat %in% "terrestrial" & test1$autohetero %in% "heterotroph",]$rg.Nenv,
            test1[test1$habitat %in% "terrestrial" & test1$autohetero %in% "heterotroph",]$rg.Ncontent,method = "spearman")


aa1=ifelse(round(aa$p.value,3)<0.0001,"< 0.0001", paste0("= ",round(aa$p.value,3)))
ah1=ifelse(round(ah$p.value,3)<0.0001,"< 0.0001", paste0("= ",round(ah$p.value,3)))
ta1=ifelse(round(ta$p.value,3)<0.0001,"< 0.0001", paste0("= ",round(ta$p.value,3)))
th1=ifelse(round(th$p.value,3)<0.0001,"< 0.0001", paste0("= ",round(th$p.value,3)))

dat_text <- data.frame(label = c(glue("r = {round(aa$estimate,2)} \n  {aa1}"),
                                 glue("r = {round(ah$estimate,2)} \n  {ah1}"),
                                 glue("r = {round(ta$estimate,2)} \n  {ta1}"),
                                 glue("r = {round(th$estimate,2)}0 \n  {th1}")),
                       habitat   = rep(c("FRESHWATER","TERRESTRIAL"),each=2),
                       autohetero=rep(c("AUTOTROPH","HETEROTROPH"),2))%>%
  mutate(
    category3 = interaction(habitat,autohetero),
    category3 = forcats::fct_inorder(fct_drop(category3))) %>%
  mutate(group=case_when(habitat %in% "AQUATIC" & autohetero %in% "AUTOTROPH" ~ "AQUATIC AUTOTROPH",
                         habitat %in% "AQUATIC" & autohetero %in% "HETEROTROPH" ~ "AQUATIC HETEROTROPH",
                         habitat %in% "TERRESTRIAL" & autohetero %in% "AUTOTROPH" ~ "TERRESTRIAL AUTOTROPH",
                         habitat %in% "TERRESTRIAL" & autohetero %in% "HETEROTROPH" ~ "TERRESTRIAL HETEROTROPH",
                         TRUE~as.character(habitat)))

FigSX3=test%>%
  group_by(sp.morphosp_revised,habitat,autohetero)%>%
  summarize(rg.Nenv=max(N,na.rm=T)-min(N,na.rm=T),
            rg.Ncontent=max(taxa.n,na.rm=T)-min(taxa.n,na.rm=T))%>%
  filter((!is.na(rg.Ncontent)&(!is.na(rg.Nenv))))%>%
  ungroup()%>%
  mutate(
    category3 = interaction(habitat,autohetero),
    category3 = forcats::fct_inorder(fct_drop(category3))) %>%
  mutate(group=case_when(habitat %in% "freshwater" & autohetero %in% "autotroph" ~ "AQUATIC AUTOTROPH",
                         habitat %in% "freshwater" & autohetero %in% "heterotroph" ~ "AQUATIC HETEROTROPH",
                         habitat %in% "terrestrial" & autohetero %in% "autotroph" ~ "TERRESTRIAL AUTOTROPH",
                         habitat %in% "terrestrial" & autohetero %in% "heterotroph" ~ "TERRESTRIAL HETEROTROPH",
                         TRUE~as.character(habitat)))%>%
  mutate(habitat=case_when(habitat %in% "freshwater" ~ "FRESHWATER",
                           habitat %in% "terrestrial" ~ "TERRESTRIAL",
                           TRUE~as.character(habitat)))%>%
  mutate(autohetero=case_when(autohetero %in% "autotroph" ~ "AUTOTROPH",
                              autohetero %in% "heterotroph" ~ "HETEROTROPH",
                              TRUE~as.character(autohetero)))%>%
  mutate(large=ifelse(sp.morphosp_revised %in% test_large_range$sp.morphosp_revised,"large","small"))%>%
  ggplot(aes(x = rg.Nenv, y = rg.Ncontent,group=category3,colour=group),show.legend=F) +
  geom_point(aes(shape=large),size=3,show.legend=F)+
  scale_shape_manual(values=c(16,1))+
  scale_color_manual(values=(c("AQUATIC AUTOTROPH" = "cyan2",
                               "AQUATIC HETEROTROPH" = "cyan4",
                               "TERRESTRIAL AUTOTROPH" = "goldenrod1",
                               "TERRESTRIAL HETEROTROPH" = "goldenrod4")))+
  theme_classic()+
  theme(strip.background = element_rect(color="black", fill="white", size=0.5))+
  annotate("segment", x=-Inf, xend=Inf, y=-Inf, yend=-Inf)+
  annotate("segment", x=-Inf, xend=-Inf, y=-Inf, yend=Inf)+
  facet_nested(autohetero~habitat,scales="free")+
  ylab("range N (% dry mass)")+xlab(expression("range N deposition ( kg N /"~km^2~"/"~year~")"))+
  geom_text(
    data    = dat_text,
    mapping = aes(x = c(1620,1620,1800,1800), y = c(0.6,2.1,0.6,2.1), label = label),color="black",
    )

#pdf(file = "Figure S3.pdf",width = 10, height = 7,pointsize = 12)
pushViewport(viewport(layout = grid.layout(1, 1)))
vplayout <- function(x, y) viewport(layout.pos.row = x, layout.pos.col = y)
print(FigSX3, vp = vplayout(1, 1))
dev.off()


test%>%
  group_by(sp.morphosp_revised,habitat,autohetero)%>%
  summarize(cv.Nenv=sd(N,na.rm=T)/mean(N,na.rm=T),
            cv.Ncontent=sd(taxa.n,na.rm=T)/mean(taxa.n,na.rm=T))%>%
  filter((!is.na(cv.Ncontent)&(!is.na(cv.Nenv))))%>%
  filter(cv.Nenv>0)%>%
  filter(habitat %in% "freshwater",autohetero %in% "heterotroph" & cv.Ncontent>0.6)


#simple ITV vs turnover

min(test$N,na.rm=T)
max(test$N,na.rm=T)

test%>%
  group_by(sp.morphosp_revised,habitat,autohetero)%>%
  summarize(range.Nenv=max(N,na.rm=T)-min(N,na.rm=T))%>%
  ungroup()%>%
  mutate(broad=ifelse(range.Nenv >= 500,1,0))%>%
  group_by(habitat,autohetero)%>%
  summarize(Nsp=length(unique(sp.morphosp_revised)),
            Nbroad=sum(broad),
            propbroad=Nbroad/Nsp*100)



test2=test%>%
  group_by(habitat,autohetero)%>%
  mutate(range.Nenv.tot=max(N,na.rm=T)-min(N,na.rm=T),
         range.Ncontent.tot=max(taxa.n,na.rm=T)-min(taxa.n,na.rm=T))%>%
  group_by(sp.morphosp_revised,habitat,autohetero,range.Nenv.tot,range.Ncontent.tot)%>%
  summarize(range.Nenv=max(N,na.rm=T)-min(N,na.rm=T),
            range.Ncontent=max(taxa.n,na.rm=T)-min(taxa.n,na.rm=T))%>%
  filter((!is.na(range.Ncontent)&(!is.na(range.Nenv))))%>%
  ungroup()%>%
  mutate(prop.Ncontent=range.Ncontent/range.Ncontent.tot*100,
         prop.Nenv=range.Nenv/range.Nenv.tot*100)%>%
  group_by(habitat,autohetero)%>%
  summarize(mean.cont.Ncontent=mean(prop.Ncontent),
            sd.cont.Ncontent=sd(prop.Ncontent),
            mean.cont.Nenv=mean(prop.Nenv),
            sd.cont.Nenv=sd(prop.Nenv)
  )

##similar to Borer et al. species spanning 15 Latitudinal degrees

#LMM model with broad-ranged species
dbdx<-db%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_terr_lab,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         species=as.factor(sp.morphosp_revised),
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(paste0(lat.dec," ",long.dec)))%>%
  dplyr::select(combi[element],Temp,Rad,N,P,habitat,autohetero,species,location)%>%
  as.data.frame()%>%
  na.omit()%>%
  filter(species %in% test_large_range$sp.morphosp_revised)

if(element %in% c(1,2,3)){
  dbdx$Yl<-log((dbdx[,combi[element]]/100)/(1-(dbdx[,combi[element]]/100))) #for n,p,c when logit
}


### contrast coding of factors
contrasts(dbdx$habitat) <-contr.sum(2)
contrasts(dbdx$autohetero) <-contr.sum(2)

###log or scale predictors
dbdx=dbdx%>%
  mutate(N=log(N),
         P=log(P))


lmemod_large<-lmer(Yl~habitat+autohetero+Temp+Rad+N+P+
                     Temp:habitat+Rad:habitat+P:habitat+N:habitat+Temp:autohetero+Rad:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
                     (1|species),data=as.data.frame(dbdx))

te6<-as.data.frame(emtrends(lmemod_large, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)%>%
  mutate(model="large_range")%>%
  dplyr::select(-df,-lower.CL,-upper.CL)

#LMM model without broad-ranged species
dbdx<-db%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_terr_lab,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         species=as.factor(sp.morphosp_revised),
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(paste0(lat.dec," ",long.dec)))%>%
  dplyr::select(combi[element],Temp,Rad,N,P,habitat,autohetero,species,location)%>%
  as.data.frame()%>%
  na.omit()%>%
  filter(!(species %in% test_large_range$sp.morphosp_revised))

if(element %in% c(1,2,3)){
  dbdx$Yl<-log((dbdx[,combi[element]]/100)/(1-(dbdx[,combi[element]]/100))) #for n,p,c when logit
}

### contrast coding of factors
contrasts(dbdx$habitat) <-contr.sum(2)
contrasts(dbdx$autohetero) <-contr.sum(2)

###log or scale predictors
dbdx=dbdx%>%
  mutate(N=log(N),
         P=log(P))


lmemod_restrict<-lmer(Yl~habitat+autohetero+Temp+Rad+N+P+
                        Temp:habitat+Rad:habitat+P:habitat+N:habitat+Temp:autohetero+Rad:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
                        (1|species),data=as.data.frame(dbdx))

te61<-as.data.frame(emtrends(lmemod_restrict, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)%>%
  mutate(model="restricted")%>%
  dplyr::select(-df,-asymp.LCL,-asymp.UCL)

#LMM model with all species no ITV
dbdx<-db%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_terr_lab,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         species=as.factor(sp.morphosp_revised),
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(paste0(lat.dec," ",long.dec)))%>%
  dplyr::select(combi[element],Temp,Rad,N,P,habitat,autohetero,species,location)%>%
  na.omit()%>%
  group_by(species)%>%
  mutate(taxa.n=mean(taxa.n,na.rm=T))%>%
  distinct()%>%
  as.data.frame()

if(element %in% c(1,2,3)){
  dbdx$Yl<-log((dbdx[,combi[element]]/100)/(1-(dbdx[,combi[element]]/100))) #for n,p,c when logit
}


### contrast coding of factors
contrasts(dbdx$habitat) <-contr.sum(2)
contrasts(dbdx$autohetero) <-contr.sum(2)

###log or scale predictors
dbdx=dbdx%>%
  mutate(N=log(N),
         P=log(P))


lmemod_no_itv<-glm(Yl~habitat+autohetero+Temp+Rad+N+P+
                     Temp:habitat+Rad:habitat+P:habitat+N:habitat+Temp:autohetero+Rad:autohetero+P:autohetero+N:autohetero+autohetero:habitat
                   ,data=as.data.frame(dbdx))

te7<-as.data.frame(emtrends(lmemod_no_itv, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)%>%
  mutate(model="no itv")%>%
  dplyr::select(-df,-lower.CL,-upper.CL)


##GLM individual species slope models
dbdx<-db%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_terr_lab,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         species=as.factor(sp.morphosp_revised),
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(paste0(lat.dec," ",long.dec)))%>%
  dplyr::select(combi[element],Temp,Rad,N,P,habitat,autohetero,species,location)%>%
  na.omit()%>%
  group_by(species)%>%
  mutate(n_obs=n(),
         n_loc=length(unique(N)))%>%
  ungroup()%>%
  filter(n_loc>=4)%>%
  as.data.frame()#%>%


if(element %in% c(1,2,3)){
  dbdx$Yl<-log((dbdx[,combi[element]]/100)/(1-(dbdx[,combi[element]]/100))) #for n,p,c when logit
}

### contrast coding of factors
contrasts(dbdx$habitat) <-contr.sum(2)
contrasts(dbdx$autohetero) <-contr.sum(2)

###log or scale predictors
dbdx=dbdx%>%
  mutate(N=log(N),
         P=log(P))

mod.ind.slope=list()
for(i in 1:length(unique(dbdx$species))){
  mod<-glm(Yl~N,data=as.data.frame(filter(dbdx,species %in% unique(dbdx$species)[i])))
  
  mod.ind.slope[[i]]=emtrends(mod, ~ 1,var=c("N"))%>%
    as.data.frame()%>%
    mutate(species=unique(dbdx$species)[i])
}

mod.ind.slope=do.call("rbind",mod.ind.slope)%>%
  left_join(distinct((dplyr::select(dbdx,species,habitat,autohetero))),by="species")%>%
  mutate(nb.pos=case_when(N.trend > 0 ~ 1,
                          N.trend < 0 ~ 0,
                          N.trend == 0 ~ 0,
                          TRUE ~ (N.trend)))%>%
  group_by(habitat,autohetero)%>%
  summarize(n_sp=length(unique(species)),
            N.trend=mean(N.trend),
            percent.pos=sum(nb.pos)/n_sp*100)%>%
  mutate(SE=sd(N.trend)/sqrt(n_sp),
         model="species slopes")

#Full LMM model with species average within locations
load("C:/Users/odezerald/Documents/Proposal/2019_sDiv_sTOCHIOMETREE/Analyses/Plots/species log Navai Pavai/Species average lmm/lmm_avsp_data.lmer_1k_em_perm_N_1_sp_log_pred.RData")
te8<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)%>%
  dplyr::select(-df,-asymp.LCL,-asymp.UCL)%>%
  mutate(model="low itv")

#Full LMM model with both narrow and broad
load("data.lmer_1k_em_perm_N_1_sp_log_pred.RData")
te<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)%>%
  mutate(model="full")%>%
  dplyr::select(-df,-asymp.LCL,-asymp.UCL)%>%
  rbind(te6)%>%
  rbind(te61)%>%
  rbind(te7)%>%
  rbind(te8)%>%
  rbind(dplyr::select(mod.ind.slope,habitat,autohetero,N.trend,SE,model))%>%
  mutate(model=case_when(model %in% "large_range" ~ "broad",
                         model %in% "restricted" ~ "narrow",
                         TRUE~as.character(model)))%>%
  mutate(model=factor(model,levels=c("full","narrow","broad","no itv","low itv","species slopes")))

FigSX4=te%>%
  mutate(
    category3 = interaction(habitat,autohetero),
    category3 = forcats::fct_inorder(fct_drop(category3))) %>%
  mutate(group=case_when(habitat %in% "freshwater" & autohetero %in% "autotroph" ~ "AQUATIC AUTOTROPH",
                         habitat %in% "freshwater" & autohetero %in% "heterotroph" ~ "AQUATIC HETEROTROPH",
                         habitat %in% "terrestrial" & autohetero %in% "autotroph" ~ "TERRESTRIAL AUTOTROPH",
                         habitat %in% "terrestrial" & autohetero %in% "heterotroph" ~ "TERRESTRIAL HETEROTROPH",
                         TRUE~as.character(habitat)))%>%
  mutate(habitat=case_when(habitat %in% "freshwater" ~ "FRESHWATER",
                           habitat %in% "terrestrial" ~ "TERRESTRIAL",
                           TRUE~as.character(habitat)))%>%
  mutate(autohetero=case_when(autohetero %in% "autotroph" ~ "AUTOTROPH",
                              autohetero %in% "heterotroph" ~ "HETEROTROPH",
                              TRUE~as.character(autohetero)))%>%
  mutate(model=case_when(model %in% "no itv" ~ "no IV",
                         model %in% "low itv" ~ "low IV",
                         TRUE~as.character(model)))%>%
  mutate(model=factor(model,levels=c("full","narrow","broad","no IV","low IV","species slopes")))%>%
  ggplot(aes(x = model, y = N.trend,group=category3,colour=group),show.legend=F) +
  geom_point(size=2.5,show.legend=F)+
  geom_hline(yintercept=0,linetype ="solid")+
  geom_vline(xintercept=5.5,linetype ="dashed")+
  geom_vline(xintercept=3.5,linetype ="dotted")+
  geom_errorbar(aes(ymin=N.trend-SE, ymax=N.trend+SE), size=0.5,width=0.1,show.legend=F)+
  scale_color_manual(values=(c("AQUATIC AUTOTROPH" = "cyan2",
                               "AQUATIC HETEROTROPH" = "cyan4",
                               "TERRESTRIAL AUTOTROPH" = "goldenrod1",
                               "TERRESTRIAL HETEROTROPH" = "goldenrod4")))+
  facet_nested(autohetero~habitat,scales="free")+
  theme_classic()+
  theme(strip.background = element_rect(color="black", fill="white", size=0.5))+
  annotate("segment", x=-Inf, xend=Inf, y=-Inf, yend=-Inf)+
  annotate("segment", x=-Inf, xend=-Inf, y=-Inf, yend=Inf)+
  xlab("")+ylab("slopes of N content across N deposition (± SE)")

#pdf(file = "Figure S5.pdf",width = 9, height = 4,pointsize = 12)
pushViewport(viewport(layout = grid.layout(1, 1)))
vplayout <- function(x, y) viewport(layout.pos.row = x, layout.pos.col = y)
print(FigSX4, vp = vplayout(1, 1))
dev.off()

test%>%
  group_by(habitat,autohetero)%>%
  summarize(obs=n(),n_sp=length(unique(sp.morphosp_revised)))

test_large_range%>%
  group_by(habitat,autohetero)%>%
  summarize(n_sp=length(unique(sp.morphosp_revised)))%>%
  ungroup()%>%
  mutate(n_obs_tot=test%>%
           group_by(habitat,autohetero)%>%
           summarize(obs=n(),n_sp=length(unique(sp.morphosp_revised)))%>%
           ungroup()%>%
           dplyr::select(obs)%>%
           as.data.frame()%>%
           unlist(),
         n_obs_broad=unlist(dplyr::select(summarize(group_by(filter(test ,sp.morphosp_revised %in% test_large_range$sp.morphosp_revised),habitat,autohetero),n_obs_broad=n())%>%ungroup(),n_obs_broad)),
         n_sp_tot=test%>%
           group_by(habitat,autohetero)%>%
           summarize(obs=n(),n_sp=length(unique(sp.morphosp_revised)))%>%
           ungroup()%>%
           dplyr::select(n_sp)%>%
           as.data.frame()%>%
           unlist(),
         percent=round(n_sp/n_sp_tot*100,1),
         obs_per_sp_broad=n_obs_broad/n_sp,
         trend=unlist(dplyr::select(arrange(filter(te,model %in% "broad"),habitat,autohetero),N.trend)))%>%
  arrange(desc(trend))


##individual species slope models
dbdx<-test%>%
  mutate(species=as.factor(sp.morphosp_revised))%>%
  filter(species %in% test_large_range$sp.morphosp_revised)%>%
  mutate(N=log(N))%>%
  group_by(species)%>%
  mutate(n_obs=n(),
         n_loc=length(unique(N)))%>%
  ungroup()%>%
  filter(n_loc>=3)%>%
  as.data.frame()


if(element %in% c(1,2,3)){
  dbdx$Yl<-log((dbdx[,combi[element]]/100)/(1-(dbdx[,combi[element]]/100))) #for n,p,c when logit
}

mod.ind.slope=list()
for(i in 1:length(unique(dbdx$species))){
  mod<-glm(Yl~N,data=as.data.frame(filter(dbdx,species %in% unique(dbdx$species)[i])))
  
  mod.ind.slope[[i]]=emtrends(mod, ~ 1,var=c("N"))%>%
    as.data.frame()%>%
    mutate(species=unique(dbdx$species)[i])
  
}

mod.ind.slope=do.call("rbind",mod.ind.slope)%>%
  left_join(distinct((dplyr::select(dbdx,species,habitat,autohetero))),by="species")


mod.av.sp.slope=list()
for(i in 1:4){
  tttt=dbdx%>%
    filter(habitat %in% rep(c("freshwater","terrestrial"),each=2)[i])%>%
    filter(autohetero %in% rep(c("autotroph","heterotroph"),2)[i])%>%
    group_by(species,N)%>%
    summarize(av.sp=mean(taxa.n),
              Yl=log((av.sp/100)/(1-(av.sp/100))))%>%
    as.data.frame()
  
  mod<-glm(Yl~N,data=tttt)
  
  mod.av.sp.slope[[i]]=emtrends(mod, ~ 1,var=c("N"))%>%
    as.data.frame()%>%
    mutate(habitat=rep(c("freshwater","terrestrial"),each=2)[i],
           autohetero=rep(c("autotroph","heterotroph"),2)[i])
  
}
mod.av.sp.slope=do.call("rbind",mod.av.sp.slope)

mod.ind.level.slope=list()
for(i in 1:4){
  tttt=dbdx%>%
    filter(habitat %in% rep(c("freshwater","terrestrial"),each=2)[i])%>%
    filter(autohetero %in% rep(c("autotroph","heterotroph"),2)[i])%>%
    as.data.frame()
  
  mod<-glm(Yl~N,data=tttt)
  
  mod.ind.level.slope[[i]]=emtrends(mod, ~ 1,var=c("N"))%>%
    as.data.frame()%>%
    mutate(habitat=rep(c("freshwater","terrestrial"),each=2)[i],
           autohetero=rep(c("autotroph","heterotroph"),2)[i])
  
}
mod.ind.level.slope=do.call("rbind",mod.ind.level.slope)


mod.ind.av.sp.slope=list()
for(i in 1:length(unique(dbdx$species))){
  tttt=dbdx%>%
    filter(species %in% unique(dbdx$species)[i])%>%
    group_by(species,N)%>%
    summarize(av.sp=mean(taxa.n),
              Yl=log((av.sp/100)/(1-(av.sp/100))))%>%
    as.data.frame()
  
  mod<-glm(Yl~N,data=tttt)
  
  mod.ind.av.sp.slope[[i]]=emtrends(mod, ~ 1,var=c("N"))%>%
    as.data.frame()%>%
    mutate(species=unique(dbdx$species)[i])
  
}
mod.ind.av.sp.slope=do.call("rbind",mod.ind.av.sp.slope)%>%
  left_join(distinct((dplyr::select(dbdx,species,habitat,autohetero))),by="species")

mod.no.itv.slope=list()
for(i in 1:4){
  tttt=dbdx%>%
    filter(habitat %in% rep(c("freshwater","terrestrial"),each=2)[i])%>%
    filter(autohetero %in% rep(c("autotroph","heterotroph"),2)[i])%>%
    group_by(species)%>%
    mutate(taxa.n=mean(taxa.n,na.rm=T))%>%
    mutate(Yl=log((taxa.n/100)/(1-(taxa.n/100))))%>%
    dplyr::select(species,Yl,N,Temp,Rad,P)%>%
    distinct()%>%
    as.data.frame()
  
  mod<-glm(Yl~N+Temp+Rad+P,data=tttt)
  
  mod.no.itv.slope[[i]]=emtrends(mod, ~ 1,var=c("N"))%>%
    as.data.frame()%>%
    mutate(habitat=rep(c("freshwater","terrestrial"),each=2)[i],
           autohetero=rep(c("autotroph","heterotroph"),2)[i])
  
}
mod.no.itv.slope=do.call("rbind",mod.no.itv.slope)

mod.ind.slope%>%
  mutate(nb.pos=case_when(N.trend > 0 ~ 1,
                          N.trend < 0 ~ 0,
                          N.trend == 0 ~ 0,
                          TRUE ~ (N.trend)))%>%
  group_by(habitat,autohetero)%>%
  summarize(n_sp=length(unique(species)),
            mean.slope=mean(N.trend),
            se.slope=sd(N.trend)/sqrt(n_sp),
            percent.pos=sum(nb.pos)/n_sp*100)
mod.av.sp.slope
mod.ind.level.slope

mod.ind.av.sp.slope%>%
  mutate(nb.pos=case_when(N.trend > 0 ~ 1,
                          N.trend < 0 ~ 0,
                          N.trend == 0 ~ 0,
                          TRUE ~ (N.trend)))%>%
  group_by(habitat,autohetero)%>%
  summarize(n_sp=length(unique(species)),
            mean.slope=mean(N.trend),
            se.slope=sd(N.trend)/sqrt(n_sp),
            percent.pos=sum(nb.pos)/n_sp*100)

mod.no.itv.slope

#############################################

####Figure S6
#############################################
library("PupillometryR")
library("cowplot")
library("here")
library("scales")

data=db%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  filter(!is.na(lat.dec))%>%
  mutate(habitat = case_when(
    habitat == "freshwater" ~ "FRESHWATER",
    habitat == "terrestrial" ~ "TERRESTRIAL",
    TRUE ~ as.character(habitat)))%>%
  mutate(troph = case_when(
    troph == "autotroph" ~ "AUTOTROPH",
    troph == "heterotroph" ~ "HETEROTROPH",
    TRUE ~ as.character(troph)))%>%
  mutate(habitat_troph = paste(habitat,troph)) %>%
  mutate(use_cols = case_when(
    habitat_troph == "FRESHWATER AUTOTROPH" ~ "cyan1",
    habitat_troph == "FRESHWATER HETEROTROPH" ~ "cyan4",
    habitat_troph == "TERRESTRIAL AUTOTROPH" ~ "goldenrod1",
    habitat_troph == "TERRESTRIAL HETEROTROPH" ~ "goldenrod4",
    TRUE ~ as.character(habitat_troph)
  ))

theme_niwot <- function(){
  theme_bw() +
    theme(#text = element_text(family = "Helvetica Light"),
      axis.text = element_text(size = 16), 
      axis.title.y = element_text(size = 18),
      axis.title.x= element_text(vjust=-1),
      axis.line.x = element_line(color="black"), 
      axis.line.y = element_line(color="black"),
      panel.border = element_blank(),
      panel.grid.major.x = element_blank(),                                          
      panel.grid.minor.x = element_blank(),
      panel.grid.minor.y = element_blank(),
      panel.grid.major.y = element_blank(),  
      plot.margin = unit(c(1, 1, 1, 1), units = , "cm"),
      plot.title = element_text(size = 18, vjust = 1, hjust = 0),
      legend.text = element_text(size = 12),          
      legend.title = element_blank(),                              
      legend.position="bottom",
      legend.key = element_blank(),
      legend.background = element_rect(color = "black", 
                                       fill = "transparent", 
                                       size = 2, linetype = "blank"))
}


summary_n <- data %>%
  group_by(habitat,troph,habitat_troph) %>%
  filter(!is.na(taxa.n)) %>%
  summarize(n    = paste0("n = ",n()),
            mean = paste0("mean = ",round(mean(taxa.n),2)),
            sd   = paste0("sd = ",round(sd(taxa.n),2)),
            max.taxa.n = max(taxa.n)+3,
            max.taxa.mean = max(taxa.n)+2,
            max.taxa.sd = max(taxa.n)+1)

habitat.n <- ggplot(data = data, aes(x = troph, y = taxa.n, fill= habitat_troph)) + 
  geom_violin(trim = FALSE,position = position_dodge(width =0.9),alpha=0.5) +
  geom_boxplot(width=0.2,position = position_dodge(width =0.9)) +
  labs(y = "N (% dry mass)", x = NULL) +
  scale_fill_manual(values = c("cyan1","cyan4","goldenrod1","goldenrod4")) +
  scale_colour_manual(values = c("cyan1","cyan4","goldenrod1","goldenrod4")) + #"goldoldenrod1",
  theme_niwot()+
  geom_text(data=summary_n,aes(x=troph,y=max.taxa.n,label = n,fill= habitat_troph),position = position_dodge(width =0.9))+
  geom_text(data=summary_n,aes(x=troph,y=max.taxa.mean,label = mean,fill= habitat_troph),position = position_dodge(width =0.9))+
  geom_text(data=summary_n,aes(x=troph,y=max.taxa.sd,label = sd,fill= habitat_troph),position = position_dodge(width =0.9))

summary_p <- data %>%
  group_by(habitat,troph,habitat_troph) %>%
  filter(!is.na(taxa.p)) %>%
  summarize(n    = paste0("n = ",n()),
            mean = paste0("mean = ",round(mean(taxa.p),2)),
            sd   = paste0("sd = ",round(sd(taxa.p),2)),
            max.taxa.n = max(taxa.p)+1.5,
            max.taxa.mean = max(taxa.p)+1,
            max.taxa.sd = max(taxa.p)+0.5)

habitat.p <- ggplot(data = data, aes(x = troph, y = taxa.p, fill= habitat_troph)) + 
  geom_violin(trim = FALSE,position = position_dodge(width =0.9),alpha=0.5) +
  geom_boxplot(width=0.2,position = position_dodge(width =0.9)) +
  labs(y = "P (% dry mass)", x = NULL) +
  scale_fill_manual(values = c("cyan1","cyan4","goldenrod1","goldenrod4")) +
  scale_colour_manual(values = c("cyan1","cyan4","goldenrod1","goldenrod4")) + #"gold #"goldenrod1",
  theme_niwot()+
  geom_text(data=summary_p,aes(x=troph,y=max.taxa.n,label = n,fill= habitat_troph),position = position_dodge(width =0.9))+
  geom_text(data=summary_p,aes(x=troph,y=max.taxa.mean,label = mean,fill= habitat_troph),position = position_dodge(width =0.9))+
  geom_text(data=summary_p,aes(x=troph,y=max.taxa.sd,label = sd,fill= habitat_troph),position = position_dodge(width =0.9))

summary_np <- data %>%
  group_by(habitat,troph,habitat_troph) %>%
  filter(!is.na(taxa.np)) %>%
  summarize(n    = paste0("n = ",n()),
            mean = paste0("mean = ",round(mean(taxa.np),2)),
            sd   = paste0("sd = ",round(sd(taxa.np),2)),
            max.taxa.n = max(taxa.np)+100,
            max.taxa.mean = max(taxa.np)+60,
            max.taxa.sd = max(taxa.np)+20)

habitat.np <- ggplot(data = data, aes(x = troph, y = taxa.np, fill= habitat_troph)) + 
  geom_violin(trim = FALSE,position = position_dodge(width =0.9),alpha=0.5) +
  geom_boxplot(width=0.2,position = position_dodge(width =0.9)) +
  labs(y = "N:P (molar ratio)", x = NULL) +
  scale_fill_manual(values = c("cyan1","cyan4","goldenrod1","goldenrod4")) +
  scale_colour_manual(values = c("cyan1","cyan4","goldenrod1","goldenrod4")) + #"goldenrod1",
  theme_niwot()+
  geom_text(data=summary_np,aes(x=troph,y=max.taxa.n,label = n,fill= habitat_troph),position = position_dodge(width =0.9))+
  geom_text(data=summary_np,aes(x=troph,y=max.taxa.mean,label = mean,fill= habitat_troph),position = position_dodge(width =0.9))+
  geom_text(data=summary_np,aes(x=troph,y=max.taxa.sd,label = sd,fill= habitat_troph),position = position_dodge(width =0.9))


# store legend

#legend <- get_legend(habitat.np)
legend <- get_plot_component(habitat.np, 'guide-box', return_all = TRUE)
# combine figures

combined_plot <- plot_grid(habitat.n  + theme(legend.position = "none"), 
                           habitat.p  + theme(legend.position = "none"),
                           habitat.np + theme(legend.position = "none"),
                           labels = c("A","B","C"), ncol=3, label_size =20)
plot <- plot_grid(legend[[3]],combined_plot,ncol=1,rel_heights = c(0.1, 1))

#pdf(file = "Figure S6.pdf",width = 18, height = 5,pointsize = 12)
pushViewport(viewport(layout = grid.layout(1, 1)))
vplayout <- function(x, y) viewport(layout.pos.row = x, layout.pos.col = y)
print(plot, vp = vplayout(1, 1))
dev.off()

#############################################

####variance explained full models - partial R2
#############################################
#check at the end of this script to run all models belonging to appendices
load("data.lmer_1k_em_perm_lat_N_1_sp.RData")
test=data.frame(mod="lat_N",mod1="Latitude: N content",marginal.R2=rsquared(lmemod)$Marginal,conditional.R2=rsquared(lmemod)$Conditional)
load("data.lmer_1k_em_perm_lat_P_1_sp.RData")
test=rbind(test,data.frame(mod="lat_P",mod1="Latitude: P content",marginal.R2=rsquared(lmemod)$Marginal,conditional.R2=rsquared(lmemod)$Conditional))
load("data.lmer_1k_em_perm_lat_NP_1_sp.RData")
test=rbind(test,data.frame(mod="lat_NP",mod1="Latitude: N:P content",marginal.R2=rsquared(lmemod)$Marginal,conditional.R2=rsquared(lmemod)$Conditional))

load("data.lmer_1k_em_perm_N_1_sp_log_pred.RData")
test=rbind(test,data.frame(mod="env_N",mod1="Environmental drivers: N content",marginal.R2=rsquared(lmemod)$Marginal,conditional.R2=rsquared(lmemod)$Conditional))
load("data.lmer_1k_em_perm_P_1_sp_log_pred.RData")
test=rbind(test,data.frame(mod="env_P",mod1="Environmental drivers: P content",marginal.R2=rsquared(lmemod)$Marginal,conditional.R2=rsquared(lmemod)$Conditional))
load("data.lmer_1k_em_perm_NP_1_sp_log_pred.RData")
test=rbind(test,data.frame(mod="env_NP",mod1="Environmental drivers: N:P content",marginal.R2=rsquared(lmemod)$Marginal,conditional.R2=rsquared(lmemod)$Conditional))


load("lmm_avsp_data.lmer_1k_em_perm_lat_N_1_sp.RData")
test=rbind(test,data.frame(mod="lat_N_av_sp",mod1="Latitude: N content",marginal.R2=rsquared(lmemod)$Marginal,conditional.R2=rsquared(lmemod)$Conditional))
load("lmm_avsp_data.lmer_1k_em_perm_lat_P_1_sp.RData")
test=rbind(test,data.frame(mod="lat_P_av_sp",mod1="Latitude: P content",marginal.R2=rsquared(lmemod)$Marginal,conditional.R2=rsquared(lmemod)$Conditional))
load("lmm_avsp_data.lmer_1k_em_perm_lat_NP_1_sp.RData")
test=rbind(test,data.frame(mod="lat_NP_av_sp",mod1="Latitude: N:P content",marginal.R2=rsquared(lmemod)$Marginal,conditional.R2=rsquared(lmemod)$Conditional))

load("lmm_avsp_data.lmer_1k_em_perm_N_1_sp_log_pred.RData")
test=rbind(test,data.frame(mod="env_N_av_sp",mod1="Environmental drivers: N content",marginal.R2=rsquared(lmemod)$Marginal,conditional.R2=rsquared(lmemod)$Conditional))
load("lmm_avsp_data.lmer_1k_em_perm_P_1_sp_log_pred.RData")
test=rbind(test,data.frame(mod="env_P_av_sp",mod1="Environmental drivers: P content",marginal.R2=rsquared(lmemod)$Marginal,conditional.R2=rsquared(lmemod)$Conditional))
load("lmm_avsp_data.lmer_1k_em_perm_NP_1_sp_log_pred.RData")
test=rbind(test,data.frame(mod="env_NP_av_sp",mod1="Environmental drivers: NP content",marginal.R2=rsquared(lmemod)$Marginal,conditional.R2=rsquared(lmemod)$Conditional))

load("rm_rad_data.lmer_1k_em_perm_N_1_sp_log_pred.RData")
test=rbind(test,data.frame(mod="env_N_rm_rad",mod1="Environmental drivers: N content",marginal.R2=rsquared(lmemod)$Marginal,conditional.R2=rsquared(lmemod)$Conditional))
load("rm_rad_data.lmer_1k_em_perm_P_1_sp_log_pred.RData")
test=rbind(test,data.frame(mod="env_P_rm_rad",mod1="Environmental drivers: P content",marginal.R2=rsquared(lmemod)$Marginal,conditional.R2=rsquared(lmemod)$Conditional))
load("rm_rad_data.lmer_1k_em_perm_NP_1_sp_log_pred.RData")
test=rbind(test,data.frame(mod="env_NP_rm_rad",mod1="Environmental drivers: NP content",marginal.R2=rsquared(lmemod)$Marginal,conditional.R2=rsquared(lmemod)$Conditional))

load("rm_temp_data.lmer_1k_em_perm_N_1_sp_log_pred.RData")
test=rbind(test,data.frame(mod="env_N_rm_temp",mod1="Environmental drivers: N content",marginal.R2=rsquared(lmemod)$Marginal,conditional.R2=rsquared(lmemod)$Conditional))
load("rm_temp_data.lmer_1k_em_perm_P_1_sp_log_pred.RData")
test=rbind(test,data.frame(mod="env_P_rm_temp",mod1="Environmental drivers: P content",marginal.R2=rsquared(lmemod)$Marginal,conditional.R2=rsquared(lmemod)$Conditional))
load("rm_temp_data.lmer_1k_em_perm_NP_1_sp_log_pred.RData")
test=rbind(test,data.frame(mod="env_NP_rm_temp",mod1="Environmental drivers: NP content",marginal.R2=rsquared(lmemod)$Marginal,conditional.R2=rsquared(lmemod)$Conditional))



load("inter_lmer_em_N.P.NP_sp_log_pred.RData")
test=rbind(test,
            data.frame(mod="env_N_inter",mod1="Environmental drivers: N content",marginal.R2=rsquared(mod.list[[2]])$Marginal,conditional.R2=rsquared(mod.list[[2]])$Conditional),
            data.frame(mod="env_P_inter",mod1="Environmental drivers: P content",marginal.R2=rsquared(mod.list[[1]])$Marginal,conditional.R2=rsquared(mod.list[[1]])$Conditional),
            data.frame(mod="env_NP_inter",mod1="Environmental drivers: N:P content",marginal.R2=rsquared(mod.list[[4]])$Marginal,conditional.R2=rsquared(mod.list[[4]])$Conditional))%>%
  mutate(marginal.R2=round(marginal.R2,2),
         conditional.R2=round(conditional.R2,2))%>%
  dplyr::select(mod,mod1,marginal.R2,conditional.R2)

##write.table(test,file="resultsR_squared.doc",row.names=F,quote=F,sep=";")

library(partR2)
##
#set combinations of elements
combi<-c("taxa.p","taxa.n","taxa.c","taxa.np","taxa.cp","taxa.cn")
R2_merged=list()
for(i in c(2,1,4)){
#set element to response: 1=taxa.p, 2=taxa.n, 4=taxa.np
element=i

##

dbdx<-db%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_terr_lab,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         species=as.factor(sp.morphosp_revised),
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(paste0(lat.dec," ",long.dec)))%>%
  dplyr::select(combi[element],Temp,Rad,N,P,habitat,autohetero,species,location)%>%
  as.data.frame()%>%
  na.omit()

if(element %in% c(1,2,3)){
  dbdx$Yl<-log((dbdx[,combi[element]]/100)/(1-(dbdx[,combi[element]]/100))) #for n,p,c when logit
}

if(element %in% c(4,5,6)){
  dbdx$Yl<-log(dbdx[,combi[element]]) #for n,p,c when logit
}


### contrast coding of factors
contrasts(dbdx$habitat) <-contr.sum(2)
contrasts(dbdx$autohetero) <-contr.sum(2)

###log or scale predictors
dbdx=dbdx%>%
  mutate(N=log(N),
         P=log(P))



lmemod<-lmer(Yl~Temp:habitat+Rad:habitat+P:habitat+N:habitat+Temp:autohetero+Rad:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
               (1|species),data=as.data.frame(dbdx))
R2_int <- partR2(lmemod, partvars = c("Temp:habitat","Rad:habitat","P:habitat","N:habitat",
                                  "Temp:autohetero","Rad:autohetero","P:autohetero","N:autohetero",
                                  "autohetero:habitat"),
             R2_type = "marginal", nboot=10, max_level = 1)

lmemod<-lmer(Yl~habitat+autohetero+Temp+Rad+N+P+
               (1|species),data=as.data.frame(dbdx))
R2_main <- partR2(lmemod, partvars = c("habitat","autohetero","Temp","Rad","N","P"),
             R2_type = "marginal", nboot=10, max_level = 1)

R2_merged[[i]]<-mergeR2(R2_main,R2_int)

}

combi[2];R2_merged[[2]]
combi[1];R2_merged[[1]]
combi[4];R2_merged[[4]]
sum(R2_merged[[2]]$R2$estimate[-1])

test=cbind(
R2_merged[[2]]$R2%>%
  mutate(partialR2.N=formatC(estimate, format = "e", digits = 1),
         CI.N=paste0("(",formatC(CI_lower, format = "e", digits = 1)," / ",formatC(CI_upper, format = "e", digits = 1),")")
         )%>%
  dplyr::select(term,partialR2.N,CI.N),
R2_merged[[1]]$R2%>%
  mutate(partialR2.P=formatC(estimate, format = "e", digits = 1),
         CI.P=paste0("(",formatC(CI_lower, format = "e", digits = 1)," / ",formatC(CI_upper, format = "e", digits = 1),")")
  )%>%
  dplyr::select(partialR2.P,CI.P),
R2_merged[[4]]$R2%>%
  mutate(partialR2.NP=formatC(estimate, format = "e", digits = 1),
         CI.NP=paste0("(",formatC(CI_lower, format = "e", digits = 1)," / ",formatC(CI_upper, format = "e", digits = 1),")")
  )%>%
  dplyr::select(partialR2.NP,CI.NP)
)

##write.table(test,file="resultspartialR_squared.doc",row.names=F,quote=F,sep=";")
#############################################

####in text robustness/sensitivity test
#############################################
#set combinations of elements
sensitivitylist<-list()
for (j in 1:6){
  combi<-c("taxa.p","taxa.n","taxa.c","taxa.np","taxa.cp","taxa.cn")
  
  #set element to response: 1=taxa.p, 2=taxa.n, 4=taxa.np
  element=j
  
  #use lm_robust:mixed=FALSE or lmer(): mixed=TRUE
  mixed=TRUE
  
  #set number of iterations for estimating pvalues
  iter=1000
  ###############################
  
  dbdx<-db%>%
    dplyr::select(combi[element],Temp,Rad,N,P,habitat,autohetero,species,location)%>%
    as.data.frame()%>%
    na.omit()
  
  if(element %in% c(1,2,3)){
    dbdx$Yl<-log((dbdx[,combi[element]]/100)/(1-(dbdx[,combi[element]]/100))) #for n,p,c when logit
  }
  
  if(element %in% c(4,5,6)){
    dbdx$Yl<-log(dbdx[,combi[element]]) #for n,p,c when logit
  }
  
  test=data.frame(sp_rm=rep(NA,1000),sp_record_sub=rep(NA,1000),sp_record_full=rep(NA,1000),sp_percent_record=rep(NA,1000),
                  loc_rm=rep(NA,1000),loc_record_sub=rep(NA,1000),loc_record_full=rep(NA,1000),loc_percent_record=rep(NA,1000))
  set.seed(3333)
  for(i in 1:iter){
    sp_rm<-sample(unique(dbdx$species),round(length(unique(dbdx$species))*5/100,0))
    dbdx3_sp<-dbdx%>%
      filter(!(species %in% sp_rm))
    
    test[i,"sp_rm"]<-length(sp_rm)
    test[i,"sp_record_sub"]<-dim(dbdx3_sp)[1]
    test[i,"sp_record_full"]<-dim(dbdx)[1]
    test[i,"sp_percent_record"]<-round((dim(dbdx3_sp)[1])/(dim(dbdx)[1])*100,0)
    
    loc_rm<-sample(unique(dbdx$location),round(length(unique(dbdx$location))*5/100,0))
    dbdx3_loc<-dbdx%>%
      filter(!(location %in% loc_rm))
    
    test[i,"loc_rm"]<-length(loc_rm)
    test[i,"loc_record_sub"]<-dim(dbdx3_loc)[1]
    test[i,"loc_record_full"]<-dim(dbdx)[1]
    test[i,"loc_percent_record"]<-round((dim(dbdx3_loc)[1])/(dim(dbdx)[1])*100,0)
  }
  
  sensitivitylist[[j]]<-test
}

test=do.call("rbind",sensitivitylist)
sort(unique(test$sp_rm))
sort(unique(test$loc_rm))

mean(test$sp_rm);sd(test$sp_rm)

mean(test$loc_rm);sd(test$loc_rm)

min(test$sp_percent_record);max(test$sp_percent_record)
mean(test$sp_percent_record);sd(test$sp_percent_record)

min(test$loc_percent_record);max(test$loc_percent_record)
mean(test$loc_percent_record);sd(test$loc_percent_record)

#############################################

####correlation among predictors
#############################################
dbdx<-db%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_terr_lab,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         species=as.factor(sp.morphosp_revised),
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(paste0(lat.dec," ",long.dec)))%>%
  dplyr::select(Temp,Rad,N,P)

cor(dbdx,use="pairwise.complete.obs",method="pearson")
library(Hmisc)
rcorr(as.matrix(dbdx),type="pearson")
rcorr(as.matrix(dbdx),type="spearman")
#############################################

####Appendix removing 5% location or species ID
#############################################
####Locations - Latitude - N
#set combinations of elements
combi<-c("taxa.p","taxa.n","taxa.c","taxa.np","taxa.cp","taxa.cn")

#set element to response: 1=taxa.p, 2=taxa.n, 4=taxa.np
element=2

#use lm_robust:mixed=FALSE or lmer(): mixed=TRUE
mixed=TRUE

#set number of iterations for estimating pvalues
iter=1000
##

dbdx<-db%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_terr_lab,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         species=as.factor(sp.morphosp_revised),
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(lat.dec),
         abs_lat.dec=abs(lat.dec))%>%
  dplyr::select(combi[element],abs_lat.dec,habitat,autohetero,species,location)%>%
  as.data.frame()%>%
  na.omit()

if(element %in% c(1,2,3)){
  dbdx$Yl<-log((dbdx[,combi[element]]/100)/(1-(dbdx[,combi[element]]/100))) #for n,p,c when logit
}

if(element %in% c(4,5,6)){
  dbdx$Yl<-log(dbdx[,combi[element]]) #for n,p,c when logit
}


### contrast coding of factors
contrasts(dbdx$habitat) <-contr.sum(2)#"contr.sum"
contrasts(dbdx$autohetero) <-contr.sum(2)


lmemod<-lmer(Yl~abs_lat.dec+habitat+autohetero+abs_lat.dec:habitat+abs_lat.dec:autohetero+habitat*autohetero+
               (1|species),data=as.data.frame(dbdx))

te7<-as.data.frame(pairs(emmeans(lmemod, pairwise ~ habitat*autohetero),adjust="none"))
te71<-te7[c(1,2,5,6),]
teDat4<-data.frame(type="effect",
                   case=c(as.character(te71$contrast)),
                   trend=c(te71$estimate),
                   SE=c(te71$SE),
                   df=c(te71$df))

#abs_lat.dec
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("abs_lat.dec") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("abs_lat.dec") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("abs_lat.dec") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(abs_lat.dec=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(abs_lat.dec=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("abs_lat.dec") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$abs_lat.dec.trend,te21$abs_lat.dec.trend,te12$estimate,te22$estimate,te3$abs_lat.dec.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$abs_lat.dec.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("abs_lat.dec") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsA<-rbind(teDat,teDat2,teDat3,teDat4)%>%
  mutate(var="abs_lat.dec")%>%
  mutate(iteration=0)


locremoved<-list()
datCp<-list()
set.seed(3333)
for(i in 1:iter){
  loc_rm<-sample(unique(dbdx$location),round(length(unique(dbdx$location))*5/100,0))
  dbdx3<-dbdx%>%
    filter(!(location %in% loc_rm))
  
  lmemodperm<-lmer(Yl~abs_lat.dec+habitat+autohetero+abs_lat.dec:habitat+abs_lat.dec:autohetero+habitat*autohetero+
                     (1|species),
                   data=as.data.frame(dbdx3))#,control = list( LP_tol_ll = 5e-2, LP_max_iter = 1000)
  locremoved[[i]]<-loc_rm
  suppressMessages({
    
    te7<-as.data.frame(pairs(emmeans(lmemodperm, pairwise ~ habitat*autohetero),adjust="none"))
    te71<-te7[c(1,2,5,6),]
    teDat4<-data.frame(type="effect",
                       case=c(as.character(te71$contrast)),
                       trend=c(te71$estimate),
                       SE=c(te71$SE),
                       df=c(te71$df))
    
    #abs_lat.dec
    te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("abs_lat.dec") )
    te11<-as.data.frame(te1$emtrends)
    te12<-as.data.frame(te1$contrasts)
    te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("abs_lat.dec") )
    te21<-as.data.frame(te2$emtrends)
    te22<-as.data.frame(te2$contrast)
    te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("abs_lat.dec") ))
    te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(abs_lat.dec=0) ),adjust="none"))
    te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(abs_lat.dec=0) ),adjust="none"))
    te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("abs_lat.dec") )$emtrends)
    teDat<-data.frame(type="slope",
                      case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                      trend=c(te11$abs_lat.dec.trend,te21$abs_lat.dec.trend,te12$estimate,te22$estimate,te3$abs_lat.dec.trend),
                      SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                      df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
    )
    teDat2<-data.frame(type="intercept",
                       case=c(as.character(te4$contrast),as.character(te5$contrast)),
                       trend=c(te4$estimate,te5$estimate),
                       SE=c(te4$SE,te5$SE),
                       df=c(te4$df,te5$df)
    )
    teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$abs_lat.dec.trend,SE=te6$SE,df=te6$df)%>%
      rbind(
        data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("abs_lat.dec") )$contrasts)%>%
          mutate(case=contrast,trend=estimate)%>%
          filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                             "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
          dplyr::select(type,case,trend,SE,df)
      )
    
    obsAx<-rbind(teDat,teDat2,teDat3,teDat4)%>%
      mutate(var="abs_lat.dec")%>%
      mutate(iteration=i)
    
  })
  
  obsA<-rbind(obsA,obsAx)
  
  #ll2random[[i]]<-ranef(lmemodperm)
  datte<-ggemmeans(lmemodperm,c("abs_lat.dec","autohetero","habitat"))%>%
    mutate(var="abs_lat.dec")
  
  datCp[[i]]<-rbind(datte)
}

obsA_1<-obsA
locremoved_1<-locremoved
datCp_1<-datCp
save(obsA_1,
     locremoved_1,
     datCp_1,
     lmemod,
     file="data.lmer_1k_em_loc_lat_N_1_sp.RData")

####Locations - Latitude - P
#set combinations of elements
combi<-c("taxa.p","taxa.n","taxa.c","taxa.np","taxa.cp","taxa.cn")

#set element to response: 1=taxa.p, 2=taxa.n, 4=taxa.np
element=1

#use lm_robust:mixed=FALSE or lmer(): mixed=TRUE
mixed=TRUE

#set number of iterations for estimating pvalues
iter=1000
#

dbdx<-db%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_terr_lab,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         species=as.factor(sp.morphosp_revised),
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(lat.dec),
         abs_lat.dec=abs(lat.dec))%>%
  dplyr::select(combi[element],abs_lat.dec,habitat,autohetero,species,location)%>%
  as.data.frame()%>%
  na.omit()

if(element %in% c(1,2,3)){
  dbdx$Yl<-log((dbdx[,combi[element]]/100)/(1-(dbdx[,combi[element]]/100))) #for n,p,c when logit
}

if(element %in% c(4,5,6)){
  dbdx$Yl<-log(dbdx[,combi[element]]) #for n,p,c when logit
}


### contrast coding of factors
contrasts(dbdx$habitat) <-contr.sum(2)#"contr.sum"
contrasts(dbdx$autohetero) <-contr.sum(2)


lmemod<-lmer(Yl~abs_lat.dec+habitat+autohetero+abs_lat.dec:habitat+abs_lat.dec:autohetero+habitat*autohetero+
               (1|species),data=as.data.frame(dbdx))

te7<-as.data.frame(pairs(emmeans(lmemod, pairwise ~ habitat*autohetero),adjust="none"))
te71<-te7[c(1,2,5,6),]
teDat4<-data.frame(type="effect",
                   case=c(as.character(te71$contrast)),
                   trend=c(te71$estimate),
                   SE=c(te71$SE),
                   df=c(te71$df))

#abs_lat.dec
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("abs_lat.dec") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("abs_lat.dec") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("abs_lat.dec") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(abs_lat.dec=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(abs_lat.dec=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("abs_lat.dec") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$abs_lat.dec.trend,te21$abs_lat.dec.trend,te12$estimate,te22$estimate,te3$abs_lat.dec.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$abs_lat.dec.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("abs_lat.dec") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsA<-rbind(teDat,teDat2,teDat3,teDat4)%>%
  mutate(var="abs_lat.dec")%>%
  mutate(iteration=0)

#ll2random<-list()
locremoved<-list()
datCp<-list()
set.seed(3333)
for(i in 1:iter){
  loc_rm<-sample(unique(dbdx$location),round(length(unique(dbdx$location))*5/100,0))
  dbdx3<-dbdx%>%
    filter(!(location %in% loc_rm))
  
  lmemodperm<-lmer(Yl~abs_lat.dec+habitat+autohetero+abs_lat.dec:habitat+abs_lat.dec:autohetero+habitat*autohetero+
                     (1|species),
                   data=as.data.frame(dbdx3))#,control = list( LP_tol_ll = 5e-2, LP_max_iter = 1000)
  locremoved[[i]]<-loc_rm
  suppressMessages({
    
    te7<-as.data.frame(pairs(emmeans(lmemodperm, pairwise ~ habitat*autohetero),adjust="none"))
    te71<-te7[c(1,2,5,6),]
    teDat4<-data.frame(type="effect",
                       case=c(as.character(te71$contrast)),
                       trend=c(te71$estimate),
                       SE=c(te71$SE),
                       df=c(te71$df))
    
    #abs_lat.dec
    te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("abs_lat.dec") )
    te11<-as.data.frame(te1$emtrends)
    te12<-as.data.frame(te1$contrasts)
    te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("abs_lat.dec") )
    te21<-as.data.frame(te2$emtrends)
    te22<-as.data.frame(te2$contrast)
    te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("abs_lat.dec") ))
    te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(abs_lat.dec=0) ),adjust="none"))
    te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(abs_lat.dec=0) ),adjust="none"))
    te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("abs_lat.dec") )$emtrends)
    teDat<-data.frame(type="slope",
                      case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                      trend=c(te11$abs_lat.dec.trend,te21$abs_lat.dec.trend,te12$estimate,te22$estimate,te3$abs_lat.dec.trend),
                      SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                      df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
    )
    teDat2<-data.frame(type="intercept",
                       case=c(as.character(te4$contrast),as.character(te5$contrast)),
                       trend=c(te4$estimate,te5$estimate),
                       SE=c(te4$SE,te5$SE),
                       df=c(te4$df,te5$df)
    )
    teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$abs_lat.dec.trend,SE=te6$SE,df=te6$df)%>%
      rbind(
        data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("abs_lat.dec") )$contrasts)%>%
          mutate(case=contrast,trend=estimate)%>%
          filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                             "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
          dplyr::select(type,case,trend,SE,df)
      )
    
    obsAx<-rbind(teDat,teDat2,teDat3,teDat4)%>%
      mutate(var="abs_lat.dec")%>%
      mutate(iteration=i)
    
  })
  
  obsA<-rbind(obsA,obsAx)
  
  #ll2random[[i]]<-ranef(lmemodperm)
  datte<-ggemmeans(lmemodperm,c("abs_lat.dec","autohetero","habitat"))%>%
    mutate(var="abs_lat.dec")
  
  datCp[[i]]<-rbind(datte)
}

obsA_1<-obsA
locremoved_1<-locremoved
datCp_1<-datCp
save(obsA_1,
     locremoved_1,
     datCp_1,
     lmemod,
     file="data.lmer_1k_em_loc_lat_P_1_sp.RData")

####Locations - Latitude - N:P
#set combinations of elements
combi<-c("taxa.p","taxa.n","taxa.c","taxa.np","taxa.cp","taxa.cn")

#set element to response: 1=taxa.p, 2=taxa.n, 4=taxa.np
element=4

#use lm_robust:mixed=FALSE or lmer(): mixed=TRUE
mixed=TRUE

#set number of iterations for estimating pvalues
iter=1000
#

dbdx<-db%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_terr_lab,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         species=as.factor(sp.morphosp_revised),
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(lat.dec),
         abs_lat.dec=abs(lat.dec))%>%
  dplyr::select(combi[element],abs_lat.dec,habitat,autohetero,species,location)%>%
  as.data.frame()%>%
  na.omit()

if(element %in% c(1,2,3)){
  dbdx$Yl<-log((dbdx[,combi[element]]/100)/(1-(dbdx[,combi[element]]/100))) #for n,p,c when logit
}

if(element %in% c(4,5,6)){
  dbdx$Yl<-log(dbdx[,combi[element]]) #for n,p,c when logit
}


### contrast coding of factors
contrasts(dbdx$habitat) <-contr.sum(2)#"contr.sum"
contrasts(dbdx$autohetero) <-contr.sum(2)


lmemod<-lmer(Yl~abs_lat.dec+habitat+autohetero+abs_lat.dec:habitat+abs_lat.dec:autohetero+habitat*autohetero+
               (1|species),data=as.data.frame(dbdx))

te7<-as.data.frame(pairs(emmeans(lmemod, pairwise ~ habitat*autohetero),adjust="none"))
te71<-te7[c(1,2,5,6),]
teDat4<-data.frame(type="effect",
                   case=c(as.character(te71$contrast)),
                   trend=c(te71$estimate),
                   SE=c(te71$SE),
                   df=c(te71$df))

#abs_lat.dec
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("abs_lat.dec") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("abs_lat.dec") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("abs_lat.dec") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(abs_lat.dec=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(abs_lat.dec=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("abs_lat.dec") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$abs_lat.dec.trend,te21$abs_lat.dec.trend,te12$estimate,te22$estimate,te3$abs_lat.dec.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$abs_lat.dec.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("abs_lat.dec") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsA<-rbind(teDat,teDat2,teDat3,teDat4)%>%
  mutate(var="abs_lat.dec")%>%
  mutate(iteration=0)

#ll2random<-list()
locremoved<-list()
datCp<-list()
set.seed(3333)
for(i in 1:iter){
  loc_rm<-sample(unique(dbdx$location),round(length(unique(dbdx$location))*5/100,0))
  dbdx3<-dbdx%>%
    filter(!(location %in% loc_rm))
  
  lmemodperm<-lmer(Yl~abs_lat.dec+habitat+autohetero+abs_lat.dec:habitat+abs_lat.dec:autohetero+habitat*autohetero+
                     (1|species),
                   data=as.data.frame(dbdx3))#,control = list( LP_tol_ll = 5e-2, LP_max_iter = 1000)
  locremoved[[i]]<-loc_rm
  suppressMessages({
    
    te7<-as.data.frame(pairs(emmeans(lmemodperm, pairwise ~ habitat*autohetero),adjust="none"))
    te71<-te7[c(1,2,5,6),]
    teDat4<-data.frame(type="effect",
                       case=c(as.character(te71$contrast)),
                       trend=c(te71$estimate),
                       SE=c(te71$SE),
                       df=c(te71$df))
    
    #abs_lat.dec
    te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("abs_lat.dec") )
    te11<-as.data.frame(te1$emtrends)
    te12<-as.data.frame(te1$contrasts)
    te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("abs_lat.dec") )
    te21<-as.data.frame(te2$emtrends)
    te22<-as.data.frame(te2$contrast)
    te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("abs_lat.dec") ))
    te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(abs_lat.dec=0) ),adjust="none"))
    te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(abs_lat.dec=0) ),adjust="none"))
    te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("abs_lat.dec") )$emtrends)
    teDat<-data.frame(type="slope",
                      case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                      trend=c(te11$abs_lat.dec.trend,te21$abs_lat.dec.trend,te12$estimate,te22$estimate,te3$abs_lat.dec.trend),
                      SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                      df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
    )
    teDat2<-data.frame(type="intercept",
                       case=c(as.character(te4$contrast),as.character(te5$contrast)),
                       trend=c(te4$estimate,te5$estimate),
                       SE=c(te4$SE,te5$SE),
                       df=c(te4$df,te5$df)
    )
    teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$abs_lat.dec.trend,SE=te6$SE,df=te6$df)%>%
      rbind(
        data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("abs_lat.dec") )$contrasts)%>%
          mutate(case=contrast,trend=estimate)%>%
          filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                             "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
          dplyr::select(type,case,trend,SE,df)
      )
    
    obsAx<-rbind(teDat,teDat2,teDat3,teDat4)%>%
      mutate(var="abs_lat.dec")%>%
      mutate(iteration=i)
    
  })
  
  obsA<-rbind(obsA,obsAx)
  
  #ll2random[[i]]<-ranef(lmemodperm)
  datte<-ggemmeans(lmemodperm,c("abs_lat.dec","autohetero","habitat"))%>%
    mutate(var="abs_lat.dec")
  
  datCp[[i]]<-rbind(datte)
}

obsA_1<-obsA
locremoved_1<-locremoved
datCp_1<-datCp
save(obsA_1,
     locremoved_1,
     datCp_1,
     lmemod,
     file="data.lmer_1k_em_loc_lat_NP_1_sp.RData")

####Locations - Environment - N
#set combinations of elements
combi<-c("taxa.p","taxa.n","taxa.c","taxa.np","taxa.cp","taxa.cn")

#set element to response: 1=taxa.p, 2=taxa.n, 4=taxa.np
element=2

#use lm_robust:mixed=FALSE or lmer(): mixed=TRUE
mixed=TRUE

#set number of iterations for estimating pvalues
iter=1000
#

dbdx<-db%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_terr_lab,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         species=as.factor(sp.morphosp_revised),
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(paste0(lat.dec," ",long.dec)))%>%
  dplyr::select(combi[element],Temp,Rad,N,P,habitat,autohetero,species,location)%>%
  as.data.frame()%>%
  na.omit()

if(element %in% c(1,2,3)){
  dbdx$Yl<-log((dbdx[,combi[element]]/100)/(1-(dbdx[,combi[element]]/100))) #for n,p,c when logit
}

if(element %in% c(4,5,6)){
  dbdx$Yl<-log(dbdx[,combi[element]]) #for n,p,c when logit
}


### contrast coding of factors
contrasts(dbdx$habitat) <-contr.sum(2)
contrasts(dbdx$autohetero) <-contr.sum(2)

###log or scale predictors
dbdx=dbdx%>%
  mutate(N=log(N),
         P=log(P))


lmemod<-lmer(Yl~habitat+autohetero+Temp+Rad+N+P+
               Temp:habitat+Rad:habitat+P:habitat+N:habitat+Temp:autohetero+Rad:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
               (1|species),data=as.data.frame(dbdx))

te7<-as.data.frame(pairs(emmeans(lmemod, pairwise ~ habitat*autohetero),adjust="none"))
te71<-te7[c(1,2,5,6),]
teDat4<-data.frame(type="effect",
                   case=c(as.character(te71$contrast)),
                   trend=c(te71$estimate),
                   SE=c(te71$SE),
                   df=c(te71$df))

#Temp
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("Temp") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("Temp") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("Temp") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$Temp.trend,te21$Temp.trend,te12$estimate,te22$estimate,te3$Temp.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Temp.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsT<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="Temp")

#Rad
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("Rad") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("Rad") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("Rad") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$Rad.trend,te21$Rad.trend,te12$estimate,te22$estimate,te3$Rad.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Rad.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsR<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="Rad")

#N
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("N") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("N") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("N") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$N.trend,te21$N.trend,te12$estimate,te22$estimate,te3$N.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$N.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsN<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="N")

#P
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("P") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("P") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("P") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$P.trend,te21$P.trend,te12$estimate,te22$estimate,te3$P.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$P.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsP<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="P")

obsA<-rbind(obsT,obsR,obsN,obsP,mutate(teDat4,var="habtrop"))%>%
  mutate(iteration=0)

#ll2random<-list()
locremoved<-list()
datCp<-list()
set.seed(3333)
for(i in 1:iter){
  loc_rm<-sample(unique(dbdx$location),round(length(unique(dbdx$location))*5/100,0))
  dbdx3<-dbdx%>%
    filter(!(location %in% loc_rm))
  
  lmemodperm<-lmer(Yl~habitat+autohetero+Temp+Rad+N+P+
                     Temp:habitat+Rad:habitat+P:habitat+N:habitat+Temp:autohetero+Rad:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
                     (1|species),
                   data=as.data.frame(dbdx3))#,control = list( LP_tol_ll = 5e-2, LP_max_iter = 1000)
  
  locremoved[[i]]<-loc_rm
  
  suppressMessages({
    te7<-as.data.frame(pairs(emmeans(lmemodperm, pairwise ~ habitat*autohetero),adjust="none"))
    te71<-te7[c(1,2,5,6),]
    teDat4<-data.frame(type="effect",
                       case=c(as.character(te71$contrast)),
                       trend=c(te71$estimate),
                       SE=c(te71$SE),
                       df=c(te71$df))
    #Temp
    #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
    te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Temp") )
    te11<-as.data.frame(te1$emtrends)
    te12<-as.data.frame(te1$contrasts)
    te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("Temp") )
    te21<-as.data.frame(te2$emtrends)
    te22<-as.data.frame(te2$contrast)
    te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("Temp") ))
    te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("Temp") )$emtrends)
    teDat<-data.frame(type="slope",
                      case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                      trend=c(te11$Temp.trend,te21$Temp.trend,te12$estimate,te22$estimate,te3$Temp.trend),
                      SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                      df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
    )
    teDat2<-data.frame(type="intercept",
                       case=c(as.character(te4$contrast),as.character(te5$contrast)),
                       trend=c(te4$estimate,te5$estimate),
                       SE=c(te4$SE,te5$SE),
                       df=c(te4$df,te5$df)
    )
    teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Temp.trend,SE=te6$SE,df=te6$df)%>%
      rbind(
        data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$contrasts)%>%
          mutate(case=contrast,trend=estimate)%>%
          filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                             "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
          dplyr::select(type,case,trend,SE,df)
      )
    
    obsT<-rbind(teDat,teDat2,teDat3)%>%
      mutate(var="Temp")
    
    #Rad
    #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat"))
    te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Rad") )
    te11<-as.data.frame(te1$emtrends)
    te12<-as.data.frame(te1$contrasts)
    te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("Rad") )
    te21<-as.data.frame(te2$emtrends)
    te22<-as.data.frame(te2$contrast)
    te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("Rad") ))
    te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("Rad") )$emtrends)
    teDat<-data.frame(type="slope",
                      case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                      trend=c(te11$Rad.trend,te21$Rad.trend,te12$estimate,te22$estimate,te3$Rad.trend),
                      SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                      df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
    )
    teDat2<-data.frame(type="intercept",
                       case=c(as.character(te4$contrast),as.character(te5$contrast)),
                       trend=c(te4$estimate,te5$estimate),
                       SE=c(te4$SE,te5$SE),
                       df=c(te4$df,te5$df)
    )
    teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Rad.trend,SE=te6$SE,df=te6$df)%>%
      rbind(
        data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$contrasts)%>%
          mutate(case=contrast,trend=estimate)%>%
          filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                             "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
          dplyr::select(type,case,trend,SE,df)
      )
    
    obsR<-rbind(teDat,teDat2,teDat3)%>%
      mutate(var="Rad")
    
    #N
    #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
    te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("N") )
    te11<-as.data.frame(te1$emtrends)
    te12<-as.data.frame(te1$contrasts)
    te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("N") )
    te21<-as.data.frame(te2$emtrends)
    te22<-as.data.frame(te2$contrast)
    te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("N") ))
    te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)
    teDat<-data.frame(type="slope",
                      case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                      trend=c(te11$N.trend,te21$N.trend,te12$estimate,te22$estimate,te3$N.trend),
                      SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                      df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
    )
    teDat2<-data.frame(type="intercept",
                       case=c(as.character(te4$contrast),as.character(te5$contrast)),
                       trend=c(te4$estimate,te5$estimate),
                       SE=c(te4$SE,te5$SE),
                       df=c(te4$df,te5$df)
    )
    teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$N.trend,SE=te6$SE,df=te6$df)%>%
      rbind(
        data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$contrasts)%>%
          mutate(case=contrast,trend=estimate)%>%
          filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                             "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
          dplyr::select(type,case,trend,SE,df)
      )
    
    obsN<-rbind(teDat,teDat2,teDat3)%>%
      mutate(var="N")
    
    #P
    #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
    te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("P") )
    te11<-as.data.frame(te1$emtrends)
    te12<-as.data.frame(te1$contrasts)
    te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("P") )
    te21<-as.data.frame(te2$emtrends)
    te22<-as.data.frame(te2$contrast)
    te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("P") ))
    te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("P") )$emtrends)
    teDat<-data.frame(type="slope",
                      case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                      trend=c(te11$P.trend,te21$P.trend,te12$estimate,te22$estimate,te3$P.trend),
                      SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                      df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
    )
    teDat2<-data.frame(type="intercept",
                       case=c(as.character(te4$contrast),as.character(te5$contrast)),
                       trend=c(te4$estimate,te5$estimate),
                       SE=c(te4$SE,te5$SE),
                       df=c(te4$df,te5$df)
    )
    teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$P.trend,SE=te6$SE,df=te6$df)%>%
      rbind(
        data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$contrasts)%>%
          mutate(case=contrast,trend=estimate)%>%
          filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                             "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
          dplyr::select(type,case,trend,SE,df)
      )
    
    obsP<-rbind(teDat,teDat2,teDat3)%>%
      mutate(var="P")
    obsAx<-rbind(obsT,obsR,obsN,obsP,mutate(teDat4,var="habtrop"))%>%
      mutate(iteration=i)
    
  })
  
  obsA<-rbind(obsA,obsAx)
  
  #ll2random[[i]]<-ranef(lmemodperm)
  datte<-ggemmeans(lmemodperm,c("Temp","autohetero","habitat") ,typical="mean")%>%
    mutate(var="Temp")
  datra<-ggemmeans(lmemodperm,c("Rad","autohetero","habitat") ,typical="mean")%>%
    mutate(var="Rad")
  datn<-ggemmeans(lmemodperm,c("N","autohetero","habitat") ,typical="mean")%>%
    mutate(var="N")
  datp<-ggemmeans(lmemodperm,c("P","autohetero","habitat") ,typical="mean")%>%
    mutate(var="P")
  
  datCp[[i]]<-rbind(datte,datra,datn,datp)
}

obsA_1<-obsA
locremoved_1<-locremoved
datCp_1<-datCp
save(obsA_1,
     locremoved_1,
     datCp_1,
     lmemod,
     file="data.lmer_1k_em_loc_N_1_sp_log_pred.RData")

####Locations - Environment - P
#set combinations of elements
combi<-c("taxa.p","taxa.n","taxa.c","taxa.np","taxa.cp","taxa.cn")

#set element to response: 1=taxa.p, 2=taxa.n, 4=taxa.np
element=1

#use lm_robust:mixed=FALSE or lmer(): mixed=TRUE
mixed=TRUE

#set number of iterations for estimating pvalues
iter=1000
#

dbdx<-db%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_terr_lab,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         species=as.factor(sp.morphosp_revised),
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(paste0(lat.dec," ",long.dec)))%>%
  dplyr::select(combi[element],Temp,Rad,N,P,habitat,autohetero,species,location)%>%
  as.data.frame()%>%
  na.omit()

if(element %in% c(1,2,3)){
  dbdx$Yl<-log((dbdx[,combi[element]]/100)/(1-(dbdx[,combi[element]]/100))) #for n,p,c when logit
}

if(element %in% c(4,5,6)){
  dbdx$Yl<-log(dbdx[,combi[element]]) #for n,p,c when logit
}


### contrast coding of factors
contrasts(dbdx$habitat) <-contr.sum(2)
contrasts(dbdx$autohetero) <-contr.sum(2)

###log or scale predictors
dbdx=dbdx%>%
  mutate(N=log(N),
         P=log(P))


lmemod<-lmer(Yl~habitat+autohetero+Temp+Rad+N+P+
               Temp:habitat+Rad:habitat+P:habitat+N:habitat+Temp:autohetero+Rad:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
               (1|species),data=as.data.frame(dbdx))

te7<-as.data.frame(pairs(emmeans(lmemod, pairwise ~ habitat*autohetero),adjust="none"))
te71<-te7[c(1,2,5,6),]
teDat4<-data.frame(type="effect",
                   case=c(as.character(te71$contrast)),
                   trend=c(te71$estimate),
                   SE=c(te71$SE),
                   df=c(te71$df))

#Temp
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("Temp") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("Temp") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("Temp") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$Temp.trend,te21$Temp.trend,te12$estimate,te22$estimate,te3$Temp.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Temp.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsT<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="Temp")

#Rad
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("Rad") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("Rad") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("Rad") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$Rad.trend,te21$Rad.trend,te12$estimate,te22$estimate,te3$Rad.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Rad.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsR<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="Rad")

#N
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("N") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("N") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("N") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$N.trend,te21$N.trend,te12$estimate,te22$estimate,te3$N.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$N.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsN<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="N")

#P
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("P") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("P") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("P") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$P.trend,te21$P.trend,te12$estimate,te22$estimate,te3$P.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$P.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsP<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="P")

obsA<-rbind(obsT,obsR,obsN,obsP,mutate(teDat4,var="habtrop"))%>%
  mutate(iteration=0)

#ll2random<-list()
locremoved<-list()
datCp<-list()
set.seed(3333)
for(i in 1:iter){
  loc_rm<-sample(unique(dbdx$location),round(length(unique(dbdx$location))*5/100,0))
  dbdx3<-dbdx%>%
    filter(!(location %in% loc_rm))
  
  lmemodperm<-lmer(Yl~habitat+autohetero+Temp+Rad+N+P+
                     Temp:habitat+Rad:habitat+P:habitat+N:habitat+Temp:autohetero+Rad:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
                     (1|species),
                   data=as.data.frame(dbdx3))#,control = list( LP_tol_ll = 5e-2, LP_max_iter = 1000)
  
  locremoved[[i]]<-loc_rm
  
  suppressMessages({
    te7<-as.data.frame(pairs(emmeans(lmemodperm, pairwise ~ habitat*autohetero),adjust="none"))
    te71<-te7[c(1,2,5,6),]
    teDat4<-data.frame(type="effect",
                       case=c(as.character(te71$contrast)),
                       trend=c(te71$estimate),
                       SE=c(te71$SE),
                       df=c(te71$df))
    #Temp
    #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
    te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Temp") )
    te11<-as.data.frame(te1$emtrends)
    te12<-as.data.frame(te1$contrasts)
    te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("Temp") )
    te21<-as.data.frame(te2$emtrends)
    te22<-as.data.frame(te2$contrast)
    te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("Temp") ))
    te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("Temp") )$emtrends)
    teDat<-data.frame(type="slope",
                      case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                      trend=c(te11$Temp.trend,te21$Temp.trend,te12$estimate,te22$estimate,te3$Temp.trend),
                      SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                      df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
    )
    teDat2<-data.frame(type="intercept",
                       case=c(as.character(te4$contrast),as.character(te5$contrast)),
                       trend=c(te4$estimate,te5$estimate),
                       SE=c(te4$SE,te5$SE),
                       df=c(te4$df,te5$df)
    )
    teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Temp.trend,SE=te6$SE,df=te6$df)%>%
      rbind(
        data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$contrasts)%>%
          mutate(case=contrast,trend=estimate)%>%
          filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                             "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
          dplyr::select(type,case,trend,SE,df)
      )
    
    obsT<-rbind(teDat,teDat2,teDat3)%>%
      mutate(var="Temp")
    
    #Rad
    #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat"))
    te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Rad") )
    te11<-as.data.frame(te1$emtrends)
    te12<-as.data.frame(te1$contrasts)
    te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("Rad") )
    te21<-as.data.frame(te2$emtrends)
    te22<-as.data.frame(te2$contrast)
    te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("Rad") ))
    te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("Rad") )$emtrends)
    teDat<-data.frame(type="slope",
                      case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                      trend=c(te11$Rad.trend,te21$Rad.trend,te12$estimate,te22$estimate,te3$Rad.trend),
                      SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                      df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
    )
    teDat2<-data.frame(type="intercept",
                       case=c(as.character(te4$contrast),as.character(te5$contrast)),
                       trend=c(te4$estimate,te5$estimate),
                       SE=c(te4$SE,te5$SE),
                       df=c(te4$df,te5$df)
    )
    teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Rad.trend,SE=te6$SE,df=te6$df)%>%
      rbind(
        data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$contrasts)%>%
          mutate(case=contrast,trend=estimate)%>%
          filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                             "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
          dplyr::select(type,case,trend,SE,df)
      )
    
    obsR<-rbind(teDat,teDat2,teDat3)%>%
      mutate(var="Rad")
    
    #N
    #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
    te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("N") )
    te11<-as.data.frame(te1$emtrends)
    te12<-as.data.frame(te1$contrasts)
    te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("N") )
    te21<-as.data.frame(te2$emtrends)
    te22<-as.data.frame(te2$contrast)
    te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("N") ))
    te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)
    teDat<-data.frame(type="slope",
                      case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                      trend=c(te11$N.trend,te21$N.trend,te12$estimate,te22$estimate,te3$N.trend),
                      SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                      df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
    )
    teDat2<-data.frame(type="intercept",
                       case=c(as.character(te4$contrast),as.character(te5$contrast)),
                       trend=c(te4$estimate,te5$estimate),
                       SE=c(te4$SE,te5$SE),
                       df=c(te4$df,te5$df)
    )
    teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$N.trend,SE=te6$SE,df=te6$df)%>%
      rbind(
        data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$contrasts)%>%
          mutate(case=contrast,trend=estimate)%>%
          filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                             "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
          dplyr::select(type,case,trend,SE,df)
      )
    
    obsN<-rbind(teDat,teDat2,teDat3)%>%
      mutate(var="N")
    
    #P
    #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
    te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("P") )
    te11<-as.data.frame(te1$emtrends)
    te12<-as.data.frame(te1$contrasts)
    te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("P") )
    te21<-as.data.frame(te2$emtrends)
    te22<-as.data.frame(te2$contrast)
    te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("P") ))
    te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("P") )$emtrends)
    teDat<-data.frame(type="slope",
                      case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                      trend=c(te11$P.trend,te21$P.trend,te12$estimate,te22$estimate,te3$P.trend),
                      SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                      df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
    )
    teDat2<-data.frame(type="intercept",
                       case=c(as.character(te4$contrast),as.character(te5$contrast)),
                       trend=c(te4$estimate,te5$estimate),
                       SE=c(te4$SE,te5$SE),
                       df=c(te4$df,te5$df)
    )
    teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$P.trend,SE=te6$SE,df=te6$df)%>%
      rbind(
        data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$contrasts)%>%
          mutate(case=contrast,trend=estimate)%>%
          filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                             "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
          dplyr::select(type,case,trend,SE,df)
      )
    
    obsP<-rbind(teDat,teDat2,teDat3)%>%
      mutate(var="P")
    obsAx<-rbind(obsT,obsR,obsN,obsP,mutate(teDat4,var="habtrop"))%>%
      mutate(iteration=i)
    
  })
  
  obsA<-rbind(obsA,obsAx)
  
  #ll2random[[i]]<-ranef(lmemodperm)
  datte<-ggemmeans(lmemodperm,c("Temp","autohetero","habitat") ,typical="mean")%>%
    mutate(var="Temp")
  datra<-ggemmeans(lmemodperm,c("Rad","autohetero","habitat") ,typical="mean")%>%
    mutate(var="Rad")
  datn<-ggemmeans(lmemodperm,c("N","autohetero","habitat") ,typical="mean")%>%
    mutate(var="N")
  datp<-ggemmeans(lmemodperm,c("P","autohetero","habitat") ,typical="mean")%>%
    mutate(var="P")
  
  datCp[[i]]<-rbind(datte,datra,datn,datp)
}

obsA_1<-obsA
locremoved_1<-locremoved
datCp_1<-datCp
save(obsA_1,
     locremoved_1,
     datCp_1,
     lmemod,
     file="data.lmer_1k_em_loc_P_1_sp_log_pred.RData")

####Locations - Environment - N:P
#set combinations of elements
combi<-c("taxa.p","taxa.n","taxa.c","taxa.np","taxa.cp","taxa.cn")

#set element to response: 1=taxa.p, 2=taxa.n, 4=taxa.np
element=4

#use lm_robust:mixed=FALSE or lmer(): mixed=TRUE
mixed=TRUE

#set number of iterations for estimating pvalues
iter=1000
#

dbdx<-db%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_terr_lab,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         species=as.factor(sp.morphosp_revised),
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(paste0(lat.dec," ",long.dec)))%>%
  dplyr::select(combi[element],Temp,Rad,N,P,habitat,autohetero,species,location)%>%
  as.data.frame()%>%
  na.omit()

if(element %in% c(1,2,3)){
  dbdx$Yl<-log((dbdx[,combi[element]]/100)/(1-(dbdx[,combi[element]]/100))) #for n,p,c when logit
}

if(element %in% c(4,5,6)){
  dbdx$Yl<-log(dbdx[,combi[element]]) #for n,p,c when logit
}


### contrast coding of factors
contrasts(dbdx$habitat) <-contr.sum(2)
contrasts(dbdx$autohetero) <-contr.sum(2)

###log or scale predictors
dbdx=dbdx%>%
  mutate(N=log(N),
         P=log(P))


lmemod<-lmer(Yl~habitat+autohetero+Temp+Rad+N+P+
               Temp:habitat+Rad:habitat+P:habitat+N:habitat+Temp:autohetero+Rad:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
               (1|species),data=as.data.frame(dbdx))

te7<-as.data.frame(pairs(emmeans(lmemod, pairwise ~ habitat*autohetero),adjust="none"))
te71<-te7[c(1,2,5,6),]
teDat4<-data.frame(type="effect",
                   case=c(as.character(te71$contrast)),
                   trend=c(te71$estimate),
                   SE=c(te71$SE),
                   df=c(te71$df))

#Temp
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("Temp") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("Temp") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("Temp") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$Temp.trend,te21$Temp.trend,te12$estimate,te22$estimate,te3$Temp.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Temp.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsT<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="Temp")

#Rad
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("Rad") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("Rad") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("Rad") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$Rad.trend,te21$Rad.trend,te12$estimate,te22$estimate,te3$Rad.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Rad.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsR<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="Rad")

#N
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("N") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("N") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("N") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$N.trend,te21$N.trend,te12$estimate,te22$estimate,te3$N.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$N.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsN<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="N")

#P
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("P") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("P") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("P") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$P.trend,te21$P.trend,te12$estimate,te22$estimate,te3$P.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$P.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsP<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="P")

obsA<-rbind(obsT,obsR,obsN,obsP,mutate(teDat4,var="habtrop"))%>%
  mutate(iteration=0)

#ll2random<-list()
locremoved<-list()
datCp<-list()
set.seed(3333)
for(i in 1:iter){
  loc_rm<-sample(unique(dbdx$location),round(length(unique(dbdx$location))*5/100,0))
  dbdx3<-dbdx%>%
    filter(!(location %in% loc_rm))
  
  lmemodperm<-lmer(Yl~habitat+autohetero+Temp+Rad+N+P+
                     Temp:habitat+Rad:habitat+P:habitat+N:habitat+Temp:autohetero+Rad:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
                     (1|species),
                   data=as.data.frame(dbdx3))#,control = list( LP_tol_ll = 5e-2, LP_max_iter = 1000)
  
  locremoved[[i]]<-loc_rm
  
  suppressMessages({
    te7<-as.data.frame(pairs(emmeans(lmemodperm, pairwise ~ habitat*autohetero),adjust="none"))
    te71<-te7[c(1,2,5,6),]
    teDat4<-data.frame(type="effect",
                       case=c(as.character(te71$contrast)),
                       trend=c(te71$estimate),
                       SE=c(te71$SE),
                       df=c(te71$df))
    #Temp
    #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
    te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Temp") )
    te11<-as.data.frame(te1$emtrends)
    te12<-as.data.frame(te1$contrasts)
    te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("Temp") )
    te21<-as.data.frame(te2$emtrends)
    te22<-as.data.frame(te2$contrast)
    te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("Temp") ))
    te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("Temp") )$emtrends)
    teDat<-data.frame(type="slope",
                      case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                      trend=c(te11$Temp.trend,te21$Temp.trend,te12$estimate,te22$estimate,te3$Temp.trend),
                      SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                      df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
    )
    teDat2<-data.frame(type="intercept",
                       case=c(as.character(te4$contrast),as.character(te5$contrast)),
                       trend=c(te4$estimate,te5$estimate),
                       SE=c(te4$SE,te5$SE),
                       df=c(te4$df,te5$df)
    )
    teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Temp.trend,SE=te6$SE,df=te6$df)%>%
      rbind(
        data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$contrasts)%>%
          mutate(case=contrast,trend=estimate)%>%
          filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                             "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
          dplyr::select(type,case,trend,SE,df)
      )
    
    obsT<-rbind(teDat,teDat2,teDat3)%>%
      mutate(var="Temp")
    
    #Rad
    #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat"))
    te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Rad") )
    te11<-as.data.frame(te1$emtrends)
    te12<-as.data.frame(te1$contrasts)
    te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("Rad") )
    te21<-as.data.frame(te2$emtrends)
    te22<-as.data.frame(te2$contrast)
    te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("Rad") ))
    te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("Rad") )$emtrends)
    teDat<-data.frame(type="slope",
                      case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                      trend=c(te11$Rad.trend,te21$Rad.trend,te12$estimate,te22$estimate,te3$Rad.trend),
                      SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                      df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
    )
    teDat2<-data.frame(type="intercept",
                       case=c(as.character(te4$contrast),as.character(te5$contrast)),
                       trend=c(te4$estimate,te5$estimate),
                       SE=c(te4$SE,te5$SE),
                       df=c(te4$df,te5$df)
    )
    teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Rad.trend,SE=te6$SE,df=te6$df)%>%
      rbind(
        data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$contrasts)%>%
          mutate(case=contrast,trend=estimate)%>%
          filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                             "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
          dplyr::select(type,case,trend,SE,df)
      )
    
    obsR<-rbind(teDat,teDat2,teDat3)%>%
      mutate(var="Rad")
    
    #N
    #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
    te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("N") )
    te11<-as.data.frame(te1$emtrends)
    te12<-as.data.frame(te1$contrasts)
    te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("N") )
    te21<-as.data.frame(te2$emtrends)
    te22<-as.data.frame(te2$contrast)
    te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("N") ))
    te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)
    teDat<-data.frame(type="slope",
                      case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                      trend=c(te11$N.trend,te21$N.trend,te12$estimate,te22$estimate,te3$N.trend),
                      SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                      df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
    )
    teDat2<-data.frame(type="intercept",
                       case=c(as.character(te4$contrast),as.character(te5$contrast)),
                       trend=c(te4$estimate,te5$estimate),
                       SE=c(te4$SE,te5$SE),
                       df=c(te4$df,te5$df)
    )
    teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$N.trend,SE=te6$SE,df=te6$df)%>%
      rbind(
        data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$contrasts)%>%
          mutate(case=contrast,trend=estimate)%>%
          filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                             "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
          dplyr::select(type,case,trend,SE,df)
      )
    
    obsN<-rbind(teDat,teDat2,teDat3)%>%
      mutate(var="N")
    
    #P
    #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
    te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("P") )
    te11<-as.data.frame(te1$emtrends)
    te12<-as.data.frame(te1$contrasts)
    te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("P") )
    te21<-as.data.frame(te2$emtrends)
    te22<-as.data.frame(te2$contrast)
    te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("P") ))
    te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("P") )$emtrends)
    teDat<-data.frame(type="slope",
                      case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                      trend=c(te11$P.trend,te21$P.trend,te12$estimate,te22$estimate,te3$P.trend),
                      SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                      df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
    )
    teDat2<-data.frame(type="intercept",
                       case=c(as.character(te4$contrast),as.character(te5$contrast)),
                       trend=c(te4$estimate,te5$estimate),
                       SE=c(te4$SE,te5$SE),
                       df=c(te4$df,te5$df)
    )
    teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$P.trend,SE=te6$SE,df=te6$df)%>%
      rbind(
        data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$contrasts)%>%
          mutate(case=contrast,trend=estimate)%>%
          filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                             "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
          dplyr::select(type,case,trend,SE,df)
      )
    
    obsP<-rbind(teDat,teDat2,teDat3)%>%
      mutate(var="P")
    obsAx<-rbind(obsT,obsR,obsN,obsP,mutate(teDat4,var="habtrop"))%>%
      mutate(iteration=i)
    
  })
  
  obsA<-rbind(obsA,obsAx)
  
  #ll2random[[i]]<-ranef(lmemodperm)
  datte<-ggemmeans(lmemodperm,c("Temp","autohetero","habitat") ,typical="mean")%>%
    mutate(var="Temp")
  datra<-ggemmeans(lmemodperm,c("Rad","autohetero","habitat") ,typical="mean")%>%
    mutate(var="Rad")
  datn<-ggemmeans(lmemodperm,c("N","autohetero","habitat") ,typical="mean")%>%
    mutate(var="N")
  datp<-ggemmeans(lmemodperm,c("P","autohetero","habitat") ,typical="mean")%>%
    mutate(var="P")
  
  datCp[[i]]<-rbind(datte,datra,datn,datp)
}

obsA_1<-obsA
locremoved_1<-locremoved
datCp_1<-datCp
save(obsA_1,
     locremoved_1,
     datCp_1,
     lmemod,
     file="data.lmer_1k_em_loc_NP_1_sp_log_pred.RData")

####Species - Latitude - N
#set combinations of elements
combi<-c("taxa.p","taxa.n","taxa.c","taxa.np","taxa.cp","taxa.cn")

#set element to response: 1=taxa.p, 2=taxa.n, 4=taxa.np
element=2

#use lm_robust:mixed=FALSE or lmer(): mixed=TRUE
mixed=TRUE

#set number of iterations for estimating pvalues
iter=1000
#

dbdx<-db%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_terr_lab,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         species=as.factor(sp.morphosp_revised),
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(lat.dec),
         abs_lat.dec=abs(lat.dec))%>%
  dplyr::select(combi[element],abs_lat.dec,habitat,autohetero,species,location)%>%
  as.data.frame()%>%
  na.omit()

if(element %in% c(1,2,3)){
  dbdx$Yl<-log((dbdx[,combi[element]]/100)/(1-(dbdx[,combi[element]]/100))) #for n,p,c when logit
}

if(element %in% c(4,5,6)){
  dbdx$Yl<-log(dbdx[,combi[element]]) #for n,p,c when logit
}


### contrast coding of factors
contrasts(dbdx$habitat) <-contr.sum(2)#"contr.sum"
contrasts(dbdx$autohetero) <-contr.sum(2)


lmemod<-lmer(Yl~abs_lat.dec+habitat+autohetero+abs_lat.dec:habitat+abs_lat.dec:autohetero+habitat*autohetero+
               (1|species),data=as.data.frame(dbdx))

te7<-as.data.frame(pairs(emmeans(lmemod, pairwise ~ habitat*autohetero),adjust="none"))
te71<-te7[c(1,2,5,6),]
teDat4<-data.frame(type="effect",
                   case=c(as.character(te71$contrast)),
                   trend=c(te71$estimate),
                   SE=c(te71$SE),
                   df=c(te71$df))

#abs_lat.dec
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("abs_lat.dec") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("abs_lat.dec") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("abs_lat.dec") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(abs_lat.dec=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(abs_lat.dec=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("abs_lat.dec") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$abs_lat.dec.trend,te21$abs_lat.dec.trend,te12$estimate,te22$estimate,te3$abs_lat.dec.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$abs_lat.dec.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("abs_lat.dec") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsA<-rbind(teDat,teDat2,teDat3,teDat4)%>%
  mutate(var="abs_lat.dec")%>%
  mutate(iteration=0)

#ll2random<-list()
speciesremoved<-list()
datCp<-list()
set.seed(3333)
for(i in 1:iter){
  sp_rm<-sample(unique(dbdx$species),round(length(unique(dbdx$species))*5/100,0))
  dbdx3<-dbdx%>%
    filter(!(species %in% sp_rm))
  
  lmemodperm<-lmer(Yl~abs_lat.dec+habitat+autohetero+abs_lat.dec:habitat+abs_lat.dec:autohetero+habitat*autohetero+
                     (1|species),
                   data=as.data.frame(dbdx3))#,control = list( LP_tol_ll = 5e-2, LP_max_iter = 1000)
  speciesremoved[[i]]<-sp_rm
  suppressMessages({
    
    te7<-as.data.frame(pairs(emmeans(lmemodperm, pairwise ~ habitat*autohetero),adjust="none"))
    te71<-te7[c(1,2,5,6),]
    teDat4<-data.frame(type="effect",
                       case=c(as.character(te71$contrast)),
                       trend=c(te71$estimate),
                       SE=c(te71$SE),
                       df=c(te71$df))
    
    #abs_lat.dec
    te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("abs_lat.dec") )
    te11<-as.data.frame(te1$emtrends)
    te12<-as.data.frame(te1$contrasts)
    te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("abs_lat.dec") )
    te21<-as.data.frame(te2$emtrends)
    te22<-as.data.frame(te2$contrast)
    te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("abs_lat.dec") ))
    te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(abs_lat.dec=0) ),adjust="none"))
    te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(abs_lat.dec=0) ),adjust="none"))
    te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("abs_lat.dec") )$emtrends)
    teDat<-data.frame(type="slope",
                      case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                      trend=c(te11$abs_lat.dec.trend,te21$abs_lat.dec.trend,te12$estimate,te22$estimate,te3$abs_lat.dec.trend),
                      SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                      df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
    )
    teDat2<-data.frame(type="intercept",
                       case=c(as.character(te4$contrast),as.character(te5$contrast)),
                       trend=c(te4$estimate,te5$estimate),
                       SE=c(te4$SE,te5$SE),
                       df=c(te4$df,te5$df)
    )
    teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$abs_lat.dec.trend,SE=te6$SE,df=te6$df)%>%
      rbind(
        data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("abs_lat.dec") )$contrasts)%>%
          mutate(case=contrast,trend=estimate)%>%
          filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                             "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
          dplyr::select(type,case,trend,SE,df)
      )
    
    obsAx<-rbind(teDat,teDat2,teDat3,teDat4)%>%
      mutate(var="abs_lat.dec")%>%
      mutate(iteration=i)
    
  })
  
  obsA<-rbind(obsA,obsAx)
  
  #ll2random[[i]]<-ranef(lmemodperm)
  datte<-ggemmeans(lmemodperm,c("abs_lat.dec","autohetero","habitat"))%>%
    mutate(var="abs_lat.dec")
  
  datCp[[i]]<-rbind(datte)
}

obsA_1<-obsA
speciesremoved_1<-speciesremoved
datCp_1<-datCp
save(obsA_1,
     speciesremoved_1,
     datCp_1,
     lmemod,
     file="data.lmer_1k_em_sp_lat_N_1_sp.RData")

####Species - Latitude - P
#set combinations of elements
combi<-c("taxa.p","taxa.n","taxa.c","taxa.np","taxa.cp","taxa.cn")

#set element to response: 1=taxa.p, 2=taxa.n, 4=taxa.np
element=1

#use lm_robust:mixed=FALSE or lmer(): mixed=TRUE
mixed=TRUE

#set number of iterations for estimating pvalues
iter=1000
#

dbdx<-db%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_terr_lab,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         species=as.factor(sp.morphosp_revised),
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(lat.dec),
         abs_lat.dec=abs(lat.dec))%>%
  dplyr::select(combi[element],abs_lat.dec,habitat,autohetero,species,location)%>%
  as.data.frame()%>%
  na.omit()

if(element %in% c(1,2,3)){
  dbdx$Yl<-log((dbdx[,combi[element]]/100)/(1-(dbdx[,combi[element]]/100))) #for n,p,c when logit
}

if(element %in% c(4,5,6)){
  dbdx$Yl<-log(dbdx[,combi[element]]) #for n,p,c when logit
}


### contrast coding of factors
contrasts(dbdx$habitat) <-contr.sum(2)#"contr.sum"
contrasts(dbdx$autohetero) <-contr.sum(2)


lmemod<-lmer(Yl~abs_lat.dec+habitat+autohetero+abs_lat.dec:habitat+abs_lat.dec:autohetero+habitat*autohetero+
               (1|species),data=as.data.frame(dbdx))

te7<-as.data.frame(pairs(emmeans(lmemod, pairwise ~ habitat*autohetero),adjust="none"))
te71<-te7[c(1,2,5,6),]
teDat4<-data.frame(type="effect",
                   case=c(as.character(te71$contrast)),
                   trend=c(te71$estimate),
                   SE=c(te71$SE),
                   df=c(te71$df))

#abs_lat.dec
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("abs_lat.dec") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("abs_lat.dec") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("abs_lat.dec") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(abs_lat.dec=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(abs_lat.dec=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("abs_lat.dec") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$abs_lat.dec.trend,te21$abs_lat.dec.trend,te12$estimate,te22$estimate,te3$abs_lat.dec.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$abs_lat.dec.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("abs_lat.dec") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsA<-rbind(teDat,teDat2,teDat3,teDat4)%>%
  mutate(var="abs_lat.dec")%>%
  mutate(iteration=0)

#ll2random<-list()
speciesremoved<-list()
datCp<-list()
set.seed(3333)
for(i in 1:iter){
  sp_rm<-sample(unique(dbdx$species),round(length(unique(dbdx$species))*5/100,0))
  dbdx3<-dbdx%>%
    filter(!(species %in% sp_rm))
  
  lmemodperm<-lmer(Yl~abs_lat.dec+habitat+autohetero+abs_lat.dec:habitat+abs_lat.dec:autohetero+habitat*autohetero+
                     (1|species),
                   data=as.data.frame(dbdx3))#,control = list( LP_tol_ll = 5e-2, LP_max_iter = 1000)
  speciesremoved[[i]]<-sp_rm
  
  suppressMessages({
    
    te7<-as.data.frame(pairs(emmeans(lmemodperm, pairwise ~ habitat*autohetero),adjust="none"))
    te71<-te7[c(1,2,5,6),]
    teDat4<-data.frame(type="effect",
                       case=c(as.character(te71$contrast)),
                       trend=c(te71$estimate),
                       SE=c(te71$SE),
                       df=c(te71$df))
    
    #abs_lat.dec
    te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("abs_lat.dec") )
    te11<-as.data.frame(te1$emtrends)
    te12<-as.data.frame(te1$contrasts)
    te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("abs_lat.dec") )
    te21<-as.data.frame(te2$emtrends)
    te22<-as.data.frame(te2$contrast)
    te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("abs_lat.dec") ))
    te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(abs_lat.dec=0) ),adjust="none"))
    te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(abs_lat.dec=0) ),adjust="none"))
    te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("abs_lat.dec") )$emtrends)
    teDat<-data.frame(type="slope",
                      case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                      trend=c(te11$abs_lat.dec.trend,te21$abs_lat.dec.trend,te12$estimate,te22$estimate,te3$abs_lat.dec.trend),
                      SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                      df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
    )
    teDat2<-data.frame(type="intercept",
                       case=c(as.character(te4$contrast),as.character(te5$contrast)),
                       trend=c(te4$estimate,te5$estimate),
                       SE=c(te4$SE,te5$SE),
                       df=c(te4$df,te5$df)
    )
    teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$abs_lat.dec.trend,SE=te6$SE,df=te6$df)%>%
      rbind(
        data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("abs_lat.dec") )$contrasts)%>%
          mutate(case=contrast,trend=estimate)%>%
          filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                             "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
          dplyr::select(type,case,trend,SE,df)
      )
    
    obsAx<-rbind(teDat,teDat2,teDat3,teDat4)%>%
      mutate(var="abs_lat.dec")%>%
      mutate(iteration=i)
    
  })
  
  obsA<-rbind(obsA,obsAx)
  
  #ll2random[[i]]<-ranef(lmemodperm)
  datte<-ggemmeans(lmemodperm,c("abs_lat.dec","autohetero","habitat"))%>%
    mutate(var="abs_lat.dec")
  
  datCp[[i]]<-rbind(datte)
}

obsA_1<-obsA
speciesremoved_1<-speciesremoved
datCp_1<-datCp
save(obsA_1,
     speciesremoved_1,
     datCp_1,
     lmemod,
     file="data.lmer_1k_em_sp_lat_P_1_sp.RData")

####Species - Latitude - N:P
#set combinations of elements
combi<-c("taxa.p","taxa.n","taxa.c","taxa.np","taxa.cp","taxa.cn")

#set element to response: 1=taxa.p, 2=taxa.n, 4=taxa.np
element=4

#use lm_robust:mixed=FALSE or lmer(): mixed=TRUE
mixed=TRUE

#set number of iterations for estimating pvalues
iter=1000
#

dbdx<-db%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_terr_lab,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         species=as.factor(sp.morphosp_revised),
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(lat.dec),
         abs_lat.dec=abs(lat.dec))%>%
  dplyr::select(combi[element],abs_lat.dec,habitat,autohetero,species,location)%>%
  as.data.frame()%>%
  na.omit()

if(element %in% c(1,2,3)){
  dbdx$Yl<-log((dbdx[,combi[element]]/100)/(1-(dbdx[,combi[element]]/100))) #for n,p,c when logit
}

if(element %in% c(4,5,6)){
  dbdx$Yl<-log(dbdx[,combi[element]]) #for n,p,c when logit
}


### contrast coding of factors
contrasts(dbdx$habitat) <-contr.sum(2)#"contr.sum"
contrasts(dbdx$autohetero) <-contr.sum(2)


lmemod<-lmer(Yl~abs_lat.dec+habitat+autohetero+abs_lat.dec:habitat+abs_lat.dec:autohetero+habitat*autohetero+
               (1|species),data=as.data.frame(dbdx))

te7<-as.data.frame(pairs(emmeans(lmemod, pairwise ~ habitat*autohetero),adjust="none"))
te71<-te7[c(1,2,5,6),]
teDat4<-data.frame(type="effect",
                   case=c(as.character(te71$contrast)),
                   trend=c(te71$estimate),
                   SE=c(te71$SE),
                   df=c(te71$df))

#abs_lat.dec
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("abs_lat.dec") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("abs_lat.dec") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("abs_lat.dec") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(abs_lat.dec=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(abs_lat.dec=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("abs_lat.dec") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$abs_lat.dec.trend,te21$abs_lat.dec.trend,te12$estimate,te22$estimate,te3$abs_lat.dec.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$abs_lat.dec.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("abs_lat.dec") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsA<-rbind(teDat,teDat2,teDat3,teDat4)%>%
  mutate(var="abs_lat.dec")%>%
  mutate(iteration=0)

#ll2random<-list()
speciesremoved<-list()
datCp<-list()
set.seed(3333)
for(i in 1:iter){
  sp_rm<-sample(unique(dbdx$species),round(length(unique(dbdx$species))*5/100,0))
  dbdx3<-dbdx%>%
    filter(!(species %in% sp_rm))
  
  lmemodperm<-lmer(Yl~abs_lat.dec+habitat+autohetero+abs_lat.dec:habitat+abs_lat.dec:autohetero+habitat*autohetero+
                     (1|species),
                   data=as.data.frame(dbdx3))#,control = list( LP_tol_ll = 5e-2, LP_max_iter = 1000)
  speciesremoved[[i]]<-sp_rm
  suppressMessages({
    
    te7<-as.data.frame(pairs(emmeans(lmemodperm, pairwise ~ habitat*autohetero),adjust="none"))
    te71<-te7[c(1,2,5,6),]
    teDat4<-data.frame(type="effect",
                       case=c(as.character(te71$contrast)),
                       trend=c(te71$estimate),
                       SE=c(te71$SE),
                       df=c(te71$df))
    
    #abs_lat.dec
    te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("abs_lat.dec") )
    te11<-as.data.frame(te1$emtrends)
    te12<-as.data.frame(te1$contrasts)
    te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("abs_lat.dec") )
    te21<-as.data.frame(te2$emtrends)
    te22<-as.data.frame(te2$contrast)
    te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("abs_lat.dec") ))
    te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(abs_lat.dec=0) ),adjust="none"))
    te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(abs_lat.dec=0) ),adjust="none"))
    te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("abs_lat.dec") )$emtrends)
    teDat<-data.frame(type="slope",
                      case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                      trend=c(te11$abs_lat.dec.trend,te21$abs_lat.dec.trend,te12$estimate,te22$estimate,te3$abs_lat.dec.trend),
                      SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                      df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
    )
    teDat2<-data.frame(type="intercept",
                       case=c(as.character(te4$contrast),as.character(te5$contrast)),
                       trend=c(te4$estimate,te5$estimate),
                       SE=c(te4$SE,te5$SE),
                       df=c(te4$df,te5$df)
    )
    teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$abs_lat.dec.trend,SE=te6$SE,df=te6$df)%>%
      rbind(
        data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("abs_lat.dec") )$contrasts)%>%
          mutate(case=contrast,trend=estimate)%>%
          filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                             "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
          dplyr::select(type,case,trend,SE,df)
      )
    
    obsAx<-rbind(teDat,teDat2,teDat3,teDat4)%>%
      mutate(var="abs_lat.dec")%>%
      mutate(iteration=i)
    
  })
  
  obsA<-rbind(obsA,obsAx)
  
  #ll2random[[i]]<-ranef(lmemodperm)
  datte<-ggemmeans(lmemodperm,c("abs_lat.dec","autohetero","habitat"))%>%
    mutate(var="abs_lat.dec")
  
  datCp[[i]]<-rbind(datte)
}

obsA_1<-obsA
speciesremoved_1<-speciesremoved
datCp_1<-datCp
save(obsA_1,
     speciesremoved_1,
     datCp_1,
     lmemod,
     file="data.lmer_1k_em_sp_lat_NP_1_sp.RData")

####Species - Environment - N
#set combinations of elements
combi<-c("taxa.p","taxa.n","taxa.c","taxa.np","taxa.cp","taxa.cn")

#set element to response: 1=taxa.p, 2=taxa.n, 4=taxa.np
element=2

#use lm_robust:mixed=FALSE or lmer(): mixed=TRUE
mixed=TRUE

#set number of iterations for estimating pvalues
iter=1000
#

dbdx<-db%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_terr_lab,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         species=as.factor(sp.morphosp_revised),
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(paste0(lat.dec," ",long.dec)))%>%
  dplyr::select(combi[element],Temp,Rad,N,P,habitat,autohetero,species,location)%>%
  as.data.frame()%>%
  na.omit()

if(element %in% c(1,2,3)){
  dbdx$Yl<-log((dbdx[,combi[element]]/100)/(1-(dbdx[,combi[element]]/100))) #for n,p,c when logit
}

if(element %in% c(4,5,6)){
  dbdx$Yl<-log(dbdx[,combi[element]]) #for n,p,c when logit
}


### contrast coding of factors
contrasts(dbdx$habitat) <-contr.sum(2)
contrasts(dbdx$autohetero) <-contr.sum(2)

###log or scale predictors
dbdx=dbdx%>%
  mutate(N=log(N),
         P=log(P))


lmemod<-lmer(Yl~habitat+autohetero+Temp+Rad+N+P+
               Temp:habitat+Rad:habitat+P:habitat+N:habitat+Temp:autohetero+Rad:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
               (1|species),data=as.data.frame(dbdx))

te7<-as.data.frame(pairs(emmeans(lmemod, pairwise ~ habitat*autohetero),adjust="none"))
te71<-te7[c(1,2,5,6),]
teDat4<-data.frame(type="effect",
                   case=c(as.character(te71$contrast)),
                   trend=c(te71$estimate),
                   SE=c(te71$SE),
                   df=c(te71$df))

#Temp
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("Temp") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("Temp") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("Temp") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$Temp.trend,te21$Temp.trend,te12$estimate,te22$estimate,te3$Temp.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Temp.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsT<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="Temp")

#Rad
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("Rad") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("Rad") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("Rad") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$Rad.trend,te21$Rad.trend,te12$estimate,te22$estimate,te3$Rad.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Rad.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsR<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="Rad")

#N
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("N") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("N") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("N") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$N.trend,te21$N.trend,te12$estimate,te22$estimate,te3$N.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$N.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsN<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="N")

#P
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("P") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("P") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("P") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$P.trend,te21$P.trend,te12$estimate,te22$estimate,te3$P.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$P.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsP<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="P")

obsA<-rbind(obsT,obsR,obsN,obsP,mutate(teDat4,var="habtrop"))%>%
  mutate(iteration=0)

#ll2random<-list()
speciesremoved<-list()
datCp<-list()
set.seed(3333)
for(i in 1:iter){
  sp_rm<-sample(unique(dbdx$species),round(length(unique(dbdx$species))*5/100,0))
  dbdx3<-dbdx%>%
    filter(!(species %in% sp_rm))
  
  lmemodperm<-lmer(Yl~habitat+autohetero+Temp+Rad+N+P+
                     Temp:habitat+Rad:habitat+P:habitat+N:habitat+Temp:autohetero+Rad:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
                     (1|species),
                   data=as.data.frame(dbdx3))#,control = list( LP_tol_ll = 5e-2, LP_max_iter = 1000)
  
  speciesremoved[[i]]<-sp_rm
  
  suppressMessages({
    te7<-as.data.frame(pairs(emmeans(lmemodperm, pairwise ~ habitat*autohetero),adjust="none"))
    te71<-te7[c(1,2,5,6),]
    teDat4<-data.frame(type="effect",
                       case=c(as.character(te71$contrast)),
                       trend=c(te71$estimate),
                       SE=c(te71$SE),
                       df=c(te71$df))
    #Temp
    #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
    te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Temp") )
    te11<-as.data.frame(te1$emtrends)
    te12<-as.data.frame(te1$contrasts)
    te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("Temp") )
    te21<-as.data.frame(te2$emtrends)
    te22<-as.data.frame(te2$contrast)
    te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("Temp") ))
    te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("Temp") )$emtrends)
    teDat<-data.frame(type="slope",
                      case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                      trend=c(te11$Temp.trend,te21$Temp.trend,te12$estimate,te22$estimate,te3$Temp.trend),
                      SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                      df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
    )
    teDat2<-data.frame(type="intercept",
                       case=c(as.character(te4$contrast),as.character(te5$contrast)),
                       trend=c(te4$estimate,te5$estimate),
                       SE=c(te4$SE,te5$SE),
                       df=c(te4$df,te5$df)
    )
    teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Temp.trend,SE=te6$SE,df=te6$df)%>%
      rbind(
        data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$contrasts)%>%
          mutate(case=contrast,trend=estimate)%>%
          filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                             "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
          dplyr::select(type,case,trend,SE,df)
      )
    
    obsT<-rbind(teDat,teDat2,teDat3)%>%
      mutate(var="Temp")
    
    #Rad
    #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat"))
    te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Rad") )
    te11<-as.data.frame(te1$emtrends)
    te12<-as.data.frame(te1$contrasts)
    te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("Rad") )
    te21<-as.data.frame(te2$emtrends)
    te22<-as.data.frame(te2$contrast)
    te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("Rad") ))
    te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("Rad") )$emtrends)
    teDat<-data.frame(type="slope",
                      case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                      trend=c(te11$Rad.trend,te21$Rad.trend,te12$estimate,te22$estimate,te3$Rad.trend),
                      SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                      df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
    )
    teDat2<-data.frame(type="intercept",
                       case=c(as.character(te4$contrast),as.character(te5$contrast)),
                       trend=c(te4$estimate,te5$estimate),
                       SE=c(te4$SE,te5$SE),
                       df=c(te4$df,te5$df)
    )
    teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Rad.trend,SE=te6$SE,df=te6$df)%>%
      rbind(
        data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$contrasts)%>%
          mutate(case=contrast,trend=estimate)%>%
          filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                             "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
          dplyr::select(type,case,trend,SE,df)
      )
    
    obsR<-rbind(teDat,teDat2,teDat3)%>%
      mutate(var="Rad")
    
    #N
    #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
    te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("N") )
    te11<-as.data.frame(te1$emtrends)
    te12<-as.data.frame(te1$contrasts)
    te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("N") )
    te21<-as.data.frame(te2$emtrends)
    te22<-as.data.frame(te2$contrast)
    te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("N") ))
    te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)
    teDat<-data.frame(type="slope",
                      case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                      trend=c(te11$N.trend,te21$N.trend,te12$estimate,te22$estimate,te3$N.trend),
                      SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                      df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
    )
    teDat2<-data.frame(type="intercept",
                       case=c(as.character(te4$contrast),as.character(te5$contrast)),
                       trend=c(te4$estimate,te5$estimate),
                       SE=c(te4$SE,te5$SE),
                       df=c(te4$df,te5$df)
    )
    teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$N.trend,SE=te6$SE,df=te6$df)%>%
      rbind(
        data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$contrasts)%>%
          mutate(case=contrast,trend=estimate)%>%
          filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                             "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
          dplyr::select(type,case,trend,SE,df)
      )
    
    obsN<-rbind(teDat,teDat2,teDat3)%>%
      mutate(var="N")
    
    #P
    #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
    te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("P") )
    te11<-as.data.frame(te1$emtrends)
    te12<-as.data.frame(te1$contrasts)
    te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("P") )
    te21<-as.data.frame(te2$emtrends)
    te22<-as.data.frame(te2$contrast)
    te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("P") ))
    te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("P") )$emtrends)
    teDat<-data.frame(type="slope",
                      case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                      trend=c(te11$P.trend,te21$P.trend,te12$estimate,te22$estimate,te3$P.trend),
                      SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                      df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
    )
    teDat2<-data.frame(type="intercept",
                       case=c(as.character(te4$contrast),as.character(te5$contrast)),
                       trend=c(te4$estimate,te5$estimate),
                       SE=c(te4$SE,te5$SE),
                       df=c(te4$df,te5$df)
    )
    teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$P.trend,SE=te6$SE,df=te6$df)%>%
      rbind(
        data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$contrasts)%>%
          mutate(case=contrast,trend=estimate)%>%
          filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                             "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
          dplyr::select(type,case,trend,SE,df)
      )
    
    obsP<-rbind(teDat,teDat2,teDat3)%>%
      mutate(var="P")
    obsAx<-rbind(obsT,obsR,obsN,obsP,mutate(teDat4,var="habtrop"))%>%
      mutate(iteration=i)
    
  })
  
  obsA<-rbind(obsA,obsAx)
  
  #ll2random[[i]]<-ranef(lmemodperm)
  datte<-ggemmeans(lmemodperm,c("Temp","autohetero","habitat") ,typical="mean")%>%
    mutate(var="Temp")
  datra<-ggemmeans(lmemodperm,c("Rad","autohetero","habitat") ,typical="mean")%>%
    mutate(var="Rad")
  datn<-ggemmeans(lmemodperm,c("N","autohetero","habitat") ,typical="mean")%>%
    mutate(var="N")
  datp<-ggemmeans(lmemodperm,c("P","autohetero","habitat") ,typical="mean")%>%
    mutate(var="P")
  
  datCp[[i]]<-rbind(datte,datra,datn,datp)
}

obsA_1<-obsA
speciesremoved_1<-speciesremoved
datCp_1<-datCp
save(obsA_1,
     speciesremoved_1,
     datCp_1,
     lmemod,
     file="data.lmer_1k_em_sp_N_1_sp_log_pred.RData")

####Species - Environment - P
#set combinations of elements
combi<-c("taxa.p","taxa.n","taxa.c","taxa.np","taxa.cp","taxa.cn")

#set element to response: 1=taxa.p, 2=taxa.n, 4=taxa.np
element=1

#use lm_robust:mixed=FALSE or lmer(): mixed=TRUE
mixed=TRUE

#set number of iterations for estimating pvalues
iter=1000
#

dbdx<-db%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_terr_lab,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         species=as.factor(sp.morphosp_revised),
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(paste0(lat.dec," ",long.dec)))%>%
  dplyr::select(combi[element],Temp,Rad,N,P,habitat,autohetero,species,location)%>%
  as.data.frame()%>%
  na.omit()

if(element %in% c(1,2,3)){
  dbdx$Yl<-log((dbdx[,combi[element]]/100)/(1-(dbdx[,combi[element]]/100))) #for n,p,c when logit
}

if(element %in% c(4,5,6)){
  dbdx$Yl<-log(dbdx[,combi[element]]) #for n,p,c when logit
}


### contrast coding of factors
contrasts(dbdx$habitat) <-contr.sum(2)
contrasts(dbdx$autohetero) <-contr.sum(2)

###log or scale predictors
dbdx=dbdx%>%
  mutate(N=log(N),
         P=log(P))


lmemod<-lmer(Yl~habitat+autohetero+Temp+Rad+N+P+
               Temp:habitat+Rad:habitat+P:habitat+N:habitat+Temp:autohetero+Rad:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
               (1|species),data=as.data.frame(dbdx))

te7<-as.data.frame(pairs(emmeans(lmemod, pairwise ~ habitat*autohetero),adjust="none"))
te71<-te7[c(1,2,5,6),]
teDat4<-data.frame(type="effect",
                   case=c(as.character(te71$contrast)),
                   trend=c(te71$estimate),
                   SE=c(te71$SE),
                   df=c(te71$df))

#Temp
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("Temp") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("Temp") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("Temp") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$Temp.trend,te21$Temp.trend,te12$estimate,te22$estimate,te3$Temp.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Temp.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsT<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="Temp")

#Rad
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("Rad") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("Rad") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("Rad") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$Rad.trend,te21$Rad.trend,te12$estimate,te22$estimate,te3$Rad.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Rad.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsR<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="Rad")

#N
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("N") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("N") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("N") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$N.trend,te21$N.trend,te12$estimate,te22$estimate,te3$N.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$N.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsN<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="N")

#P
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("P") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("P") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("P") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$P.trend,te21$P.trend,te12$estimate,te22$estimate,te3$P.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$P.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsP<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="P")

obsA<-rbind(obsT,obsR,obsN,obsP,mutate(teDat4,var="habtrop"))%>%
  mutate(iteration=0)

#ll2random<-list()
speciesremoved<-list()
datCp<-list()
set.seed(3333)
for(i in 1:iter){
  sp_rm<-sample(unique(dbdx$species),round(length(unique(dbdx$species))*5/100,0))
  dbdx3<-dbdx%>%
    filter(!(species %in% sp_rm))
  
  lmemodperm<-lmer(Yl~habitat+autohetero+Temp+Rad+N+P+
                     Temp:habitat+Rad:habitat+P:habitat+N:habitat+Temp:autohetero+Rad:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
                     (1|species),
                   data=as.data.frame(dbdx3))#,control = list( LP_tol_ll = 5e-2, LP_max_iter = 1000)
  
  speciesremoved[[i]]<-sp_rm
  
  suppressMessages({
    te7<-as.data.frame(pairs(emmeans(lmemodperm, pairwise ~ habitat*autohetero),adjust="none"))
    te71<-te7[c(1,2,5,6),]
    teDat4<-data.frame(type="effect",
                       case=c(as.character(te71$contrast)),
                       trend=c(te71$estimate),
                       SE=c(te71$SE),
                       df=c(te71$df))
    #Temp
    #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
    te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Temp") )
    te11<-as.data.frame(te1$emtrends)
    te12<-as.data.frame(te1$contrasts)
    te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("Temp") )
    te21<-as.data.frame(te2$emtrends)
    te22<-as.data.frame(te2$contrast)
    te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("Temp") ))
    te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("Temp") )$emtrends)
    teDat<-data.frame(type="slope",
                      case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                      trend=c(te11$Temp.trend,te21$Temp.trend,te12$estimate,te22$estimate,te3$Temp.trend),
                      SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                      df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
    )
    teDat2<-data.frame(type="intercept",
                       case=c(as.character(te4$contrast),as.character(te5$contrast)),
                       trend=c(te4$estimate,te5$estimate),
                       SE=c(te4$SE,te5$SE),
                       df=c(te4$df,te5$df)
    )
    teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Temp.trend,SE=te6$SE,df=te6$df)%>%
      rbind(
        data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$contrasts)%>%
          mutate(case=contrast,trend=estimate)%>%
          filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                             "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
          dplyr::select(type,case,trend,SE,df)
      )
    
    obsT<-rbind(teDat,teDat2,teDat3)%>%
      mutate(var="Temp")
    
    #Rad
    #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat"))
    te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Rad") )
    te11<-as.data.frame(te1$emtrends)
    te12<-as.data.frame(te1$contrasts)
    te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("Rad") )
    te21<-as.data.frame(te2$emtrends)
    te22<-as.data.frame(te2$contrast)
    te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("Rad") ))
    te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("Rad") )$emtrends)
    teDat<-data.frame(type="slope",
                      case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                      trend=c(te11$Rad.trend,te21$Rad.trend,te12$estimate,te22$estimate,te3$Rad.trend),
                      SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                      df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
    )
    teDat2<-data.frame(type="intercept",
                       case=c(as.character(te4$contrast),as.character(te5$contrast)),
                       trend=c(te4$estimate,te5$estimate),
                       SE=c(te4$SE,te5$SE),
                       df=c(te4$df,te5$df)
    )
    teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Rad.trend,SE=te6$SE,df=te6$df)%>%
      rbind(
        data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$contrasts)%>%
          mutate(case=contrast,trend=estimate)%>%
          filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                             "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
          dplyr::select(type,case,trend,SE,df)
      )
    
    obsR<-rbind(teDat,teDat2,teDat3)%>%
      mutate(var="Rad")
    
    #N
    #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
    te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("N") )
    te11<-as.data.frame(te1$emtrends)
    te12<-as.data.frame(te1$contrasts)
    te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("N") )
    te21<-as.data.frame(te2$emtrends)
    te22<-as.data.frame(te2$contrast)
    te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("N") ))
    te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)
    teDat<-data.frame(type="slope",
                      case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                      trend=c(te11$N.trend,te21$N.trend,te12$estimate,te22$estimate,te3$N.trend),
                      SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                      df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
    )
    teDat2<-data.frame(type="intercept",
                       case=c(as.character(te4$contrast),as.character(te5$contrast)),
                       trend=c(te4$estimate,te5$estimate),
                       SE=c(te4$SE,te5$SE),
                       df=c(te4$df,te5$df)
    )
    teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$N.trend,SE=te6$SE,df=te6$df)%>%
      rbind(
        data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$contrasts)%>%
          mutate(case=contrast,trend=estimate)%>%
          filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                             "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
          dplyr::select(type,case,trend,SE,df)
      )
    
    obsN<-rbind(teDat,teDat2,teDat3)%>%
      mutate(var="N")
    
    #P
    #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
    te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("P") )
    te11<-as.data.frame(te1$emtrends)
    te12<-as.data.frame(te1$contrasts)
    te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("P") )
    te21<-as.data.frame(te2$emtrends)
    te22<-as.data.frame(te2$contrast)
    te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("P") ))
    te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("P") )$emtrends)
    teDat<-data.frame(type="slope",
                      case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                      trend=c(te11$P.trend,te21$P.trend,te12$estimate,te22$estimate,te3$P.trend),
                      SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                      df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
    )
    teDat2<-data.frame(type="intercept",
                       case=c(as.character(te4$contrast),as.character(te5$contrast)),
                       trend=c(te4$estimate,te5$estimate),
                       SE=c(te4$SE,te5$SE),
                       df=c(te4$df,te5$df)
    )
    teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$P.trend,SE=te6$SE,df=te6$df)%>%
      rbind(
        data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$contrasts)%>%
          mutate(case=contrast,trend=estimate)%>%
          filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                             "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
          dplyr::select(type,case,trend,SE,df)
      )
    
    obsP<-rbind(teDat,teDat2,teDat3)%>%
      mutate(var="P")
    obsAx<-rbind(obsT,obsR,obsN,obsP,mutate(teDat4,var="habtrop"))%>%
      mutate(iteration=i)
    
  })
  
  obsA<-rbind(obsA,obsAx)
  
  #ll2random[[i]]<-ranef(lmemodperm)
  datte<-ggemmeans(lmemodperm,c("Temp","autohetero","habitat") ,typical="mean")%>%
    mutate(var="Temp")
  datra<-ggemmeans(lmemodperm,c("Rad","autohetero","habitat") ,typical="mean")%>%
    mutate(var="Rad")
  datn<-ggemmeans(lmemodperm,c("N","autohetero","habitat") ,typical="mean")%>%
    mutate(var="N")
  datp<-ggemmeans(lmemodperm,c("P","autohetero","habitat") ,typical="mean")%>%
    mutate(var="P")
  
  datCp[[i]]<-rbind(datte,datra,datn,datp)
}

obsA_1<-obsA
speciesremoved_1<-speciesremoved
datCp_1<-datCp
save(obsA_1,
     speciesremoved_1,
     datCp_1,
     lmemod,
     file="data.lmer_1k_em_sp_P_1_sp_log_pred.RData")

####Species - Environment - N:P
#set combinations of elements
combi<-c("taxa.p","taxa.n","taxa.c","taxa.np","taxa.cp","taxa.cn")

#set element to response: 1=taxa.p, 2=taxa.n, 4=taxa.np
element=4

#use lm_robust:mixed=FALSE or lmer(): mixed=TRUE
mixed=TRUE

#set number of iterations for estimating pvalues
iter=1000
#

dbdx<-db%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_terr_lab,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         species=as.factor(sp.morphosp_revised),
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(paste0(lat.dec," ",long.dec)))%>%
  dplyr::select(combi[element],Temp,Rad,N,P,habitat,autohetero,species,location)%>%
  as.data.frame()%>%
  na.omit()

if(element %in% c(1,2,3)){
  dbdx$Yl<-log((dbdx[,combi[element]]/100)/(1-(dbdx[,combi[element]]/100))) #for n,p,c when logit
}

if(element %in% c(4,5,6)){
  dbdx$Yl<-log(dbdx[,combi[element]]) #for n,p,c when logit
}


### contrast coding of factors
contrasts(dbdx$habitat) <-contr.sum(2)
contrasts(dbdx$autohetero) <-contr.sum(2)

###log or scale predictors
dbdx=dbdx%>%
  mutate(N=log(N),
         P=log(P))


lmemod<-lmer(Yl~habitat+autohetero+Temp+Rad+N+P+
               Temp:habitat+Rad:habitat+P:habitat+N:habitat+Temp:autohetero+Rad:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
               (1|species),data=as.data.frame(dbdx))

te7<-as.data.frame(pairs(emmeans(lmemod, pairwise ~ habitat*autohetero),adjust="none"))
te71<-te7[c(1,2,5,6),]
teDat4<-data.frame(type="effect",
                   case=c(as.character(te71$contrast)),
                   trend=c(te71$estimate),
                   SE=c(te71$SE),
                   df=c(te71$df))

#Temp
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("Temp") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("Temp") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("Temp") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$Temp.trend,te21$Temp.trend,te12$estimate,te22$estimate,te3$Temp.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Temp.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsT<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="Temp")

#Rad
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("Rad") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("Rad") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("Rad") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$Rad.trend,te21$Rad.trend,te12$estimate,te22$estimate,te3$Rad.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Rad.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsR<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="Rad")

#N
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("N") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("N") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("N") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$N.trend,te21$N.trend,te12$estimate,te22$estimate,te3$N.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$N.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsN<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="N")

#P
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("P") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("P") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("P") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$P.trend,te21$P.trend,te12$estimate,te22$estimate,te3$P.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$P.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsP<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="P")

obsA<-rbind(obsT,obsR,obsN,obsP,mutate(teDat4,var="habtrop"))%>%
  mutate(iteration=0)

#ll2random<-list()
speciesremoved<-list()
datCp<-list()
set.seed(3333)
for(i in 1:iter){
  sp_rm<-sample(unique(dbdx$species),round(length(unique(dbdx$species))*5/100,0))
  dbdx3<-dbdx%>%
    filter(!(species %in% sp_rm))
  
  lmemodperm<-lmer(Yl~habitat+autohetero+Temp+Rad+N+P+
                     Temp:habitat+Rad:habitat+P:habitat+N:habitat+Temp:autohetero+Rad:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
                     (1|species),
                   data=as.data.frame(dbdx3))#,control = list( LP_tol_ll = 5e-2, LP_max_iter = 1000)
  
  speciesremoved[[i]]<-sp_rm
  
  suppressMessages({
    te7<-as.data.frame(pairs(emmeans(lmemodperm, pairwise ~ habitat*autohetero),adjust="none"))
    te71<-te7[c(1,2,5,6),]
    teDat4<-data.frame(type="effect",
                       case=c(as.character(te71$contrast)),
                       trend=c(te71$estimate),
                       SE=c(te71$SE),
                       df=c(te71$df))
    #Temp
    #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
    te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Temp") )
    te11<-as.data.frame(te1$emtrends)
    te12<-as.data.frame(te1$contrasts)
    te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("Temp") )
    te21<-as.data.frame(te2$emtrends)
    te22<-as.data.frame(te2$contrast)
    te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("Temp") ))
    te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("Temp") )$emtrends)
    teDat<-data.frame(type="slope",
                      case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                      trend=c(te11$Temp.trend,te21$Temp.trend,te12$estimate,te22$estimate,te3$Temp.trend),
                      SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                      df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
    )
    teDat2<-data.frame(type="intercept",
                       case=c(as.character(te4$contrast),as.character(te5$contrast)),
                       trend=c(te4$estimate,te5$estimate),
                       SE=c(te4$SE,te5$SE),
                       df=c(te4$df,te5$df)
    )
    teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Temp.trend,SE=te6$SE,df=te6$df)%>%
      rbind(
        data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$contrasts)%>%
          mutate(case=contrast,trend=estimate)%>%
          filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                             "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
          dplyr::select(type,case,trend,SE,df)
      )
    
    obsT<-rbind(teDat,teDat2,teDat3)%>%
      mutate(var="Temp")
    
    #Rad
    #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat"))
    te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Rad") )
    te11<-as.data.frame(te1$emtrends)
    te12<-as.data.frame(te1$contrasts)
    te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("Rad") )
    te21<-as.data.frame(te2$emtrends)
    te22<-as.data.frame(te2$contrast)
    te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("Rad") ))
    te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("Rad") )$emtrends)
    teDat<-data.frame(type="slope",
                      case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                      trend=c(te11$Rad.trend,te21$Rad.trend,te12$estimate,te22$estimate,te3$Rad.trend),
                      SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                      df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
    )
    teDat2<-data.frame(type="intercept",
                       case=c(as.character(te4$contrast),as.character(te5$contrast)),
                       trend=c(te4$estimate,te5$estimate),
                       SE=c(te4$SE,te5$SE),
                       df=c(te4$df,te5$df)
    )
    teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Rad.trend,SE=te6$SE,df=te6$df)%>%
      rbind(
        data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$contrasts)%>%
          mutate(case=contrast,trend=estimate)%>%
          filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                             "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
          dplyr::select(type,case,trend,SE,df)
      )
    
    obsR<-rbind(teDat,teDat2,teDat3)%>%
      mutate(var="Rad")
    
    #N
    #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
    te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("N") )
    te11<-as.data.frame(te1$emtrends)
    te12<-as.data.frame(te1$contrasts)
    te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("N") )
    te21<-as.data.frame(te2$emtrends)
    te22<-as.data.frame(te2$contrast)
    te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("N") ))
    te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)
    teDat<-data.frame(type="slope",
                      case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                      trend=c(te11$N.trend,te21$N.trend,te12$estimate,te22$estimate,te3$N.trend),
                      SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                      df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
    )
    teDat2<-data.frame(type="intercept",
                       case=c(as.character(te4$contrast),as.character(te5$contrast)),
                       trend=c(te4$estimate,te5$estimate),
                       SE=c(te4$SE,te5$SE),
                       df=c(te4$df,te5$df)
    )
    teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$N.trend,SE=te6$SE,df=te6$df)%>%
      rbind(
        data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$contrasts)%>%
          mutate(case=contrast,trend=estimate)%>%
          filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                             "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
          dplyr::select(type,case,trend,SE,df)
      )
    
    obsN<-rbind(teDat,teDat2,teDat3)%>%
      mutate(var="N")
    
    #P
    #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
    te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("P") )
    te11<-as.data.frame(te1$emtrends)
    te12<-as.data.frame(te1$contrasts)
    te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("P") )
    te21<-as.data.frame(te2$emtrends)
    te22<-as.data.frame(te2$contrast)
    te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("P") ))
    te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
    te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("P") )$emtrends)
    teDat<-data.frame(type="slope",
                      case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                      trend=c(te11$P.trend,te21$P.trend,te12$estimate,te22$estimate,te3$P.trend),
                      SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                      df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
    )
    teDat2<-data.frame(type="intercept",
                       case=c(as.character(te4$contrast),as.character(te5$contrast)),
                       trend=c(te4$estimate,te5$estimate),
                       SE=c(te4$SE,te5$SE),
                       df=c(te4$df,te5$df)
    )
    teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$P.trend,SE=te6$SE,df=te6$df)%>%
      rbind(
        data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$contrasts)%>%
          mutate(case=contrast,trend=estimate)%>%
          filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                             "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
          dplyr::select(type,case,trend,SE,df)
      )
    
    obsP<-rbind(teDat,teDat2,teDat3)%>%
      mutate(var="P")
    obsAx<-rbind(obsT,obsR,obsN,obsP,mutate(teDat4,var="habtrop"))%>%
      mutate(iteration=i)
    
  })
  
  obsA<-rbind(obsA,obsAx)
  
  #ll2random[[i]]<-ranef(lmemodperm)
  datte<-ggemmeans(lmemodperm,c("Temp","autohetero","habitat") ,typical="mean")%>%
    mutate(var="Temp")
  datra<-ggemmeans(lmemodperm,c("Rad","autohetero","habitat") ,typical="mean")%>%
    mutate(var="Rad")
  datn<-ggemmeans(lmemodperm,c("N","autohetero","habitat") ,typical="mean")%>%
    mutate(var="N")
  datp<-ggemmeans(lmemodperm,c("P","autohetero","habitat") ,typical="mean")%>%
    mutate(var="P")
  
  datCp[[i]]<-rbind(datte,datra,datn,datp)
}

obsA_1<-obsA
speciesremoved_1<-speciesremoved
datCp_1<-datCp
save(obsA_1,
     speciesremoved_1,
     datCp_1,
     lmemod,
     file="data.lmer_1k_em_sp_NP_1_sp_log_pred.RData")

####prepare tables appendices - five percent remove sp and loc
load("data.lmer_1k_em_sp_N_1_sp_log_pred.RData")#
dbdx=lmemod@frame

ll1<-obsA_1
obsA<-obsA_1%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% c("intercept","effect")))%>%
  group_by(type,case,var)%>%
  summarise(pvalue=mean(abs(trend[iteration!=0]/SE[iteration!=0]) >= abs(trend[iteration==0]/SE[iteration==0])))
obsA$padjustBO<-p.adjust(obsA$pvalue)
obsA$padjustBH<-p.adjust(obsA$pvalue,method="BH")

test.sp.N=ll1%>%
  filter(iteration %in% 0)%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% "intercept"))%>%
  dplyr::select(type,case,var,trend,SE)%>%
  left_join(obsA,by=c("type","case","var"))%>%
  mutate(element="N",
         trend=formatC(trend, format = "e", digits = 1),
         SE=formatC(SE, format = "e", digits = 1),
         pvalue=round(pvalue,3),
         padjustBH=round(padjustBH,3),
         sig=ifelse(padjustBH < 0.05,"sig","nonsig"))%>%
  dplyr::select(element,type,case,var,trend,SE,pvalue,padjustBH,sig)%>%
  .[c(7,1:2,5,3:4,6,8:15,
      22,16:17,20,18:19,21,23:30,
      37,31:32,35,33:34,36,38:45,
      52,46:47,50,48:49,51,53:60),]

load("data.lmer_1k_em_sp_P_1_sp_log_pred.RData") #
dbdx=lmemod@frame

ll1<-obsA_1
obsA<-obsA_1%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% c("intercept","effect")))%>%
  group_by(type,case,var)%>%
  summarise(pvalue=mean(abs(trend[iteration!=0]/SE[iteration!=0]) >= abs(trend[iteration==0]/SE[iteration==0])))
obsA$padjustBO<-p.adjust(obsA$pvalue)
obsA$padjustBH<-p.adjust(obsA$pvalue,method="BH")

test.sp.P=ll1%>%
  filter(iteration %in% 0)%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% "intercept"))%>%
  dplyr::select(type,case,var,trend,SE)%>%
  left_join(obsA,by=c("type","case","var"))%>%
  mutate(element="P",
         trend=formatC(trend, format = "e", digits = 1),
         SE=formatC(SE, format = "e", digits = 1),
         pvalue=round(pvalue,3),
         padjustBH=round(padjustBH,3),
         sig=ifelse(padjustBH < 0.05,"sig","nonsig"))%>%
  dplyr::select(element,type,case,var,trend,SE,pvalue,padjustBH,sig)%>%
  .[c(7,1:2,5,3:4,6,8:15,
      22,16:17,20,18:19,21,23:30,
      37,31:32,35,33:34,36,38:45,
      52,46:47,50,48:49,51,53:60),]

load("data.lmer_1k_em_sp_NP_1_sp_log_pred.RData") #
dbdx=lmemod@frame

ll1<-obsA_1
obsA<-obsA_1%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% c("intercept","effect")))%>%
  group_by(type,case,var)%>%
  summarise(pvalue=mean(abs(trend[iteration!=0]/SE[iteration!=0]) >= abs(trend[iteration==0]/SE[iteration==0])))
obsA$padjustBO<-p.adjust(obsA$pvalue)
obsA$padjustBH<-p.adjust(obsA$pvalue,method="BH")

test.sp.NP=ll1%>%
  filter(iteration %in% 0)%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% "intercept"))%>%
  dplyr::select(type,case,var,trend,SE)%>%
  left_join(obsA,by=c("type","case","var"))%>%
  mutate(element="N:P",
         trend=formatC(trend, format = "e", digits = 1),
         SE=formatC(SE, format = "e", digits = 1),
         pvalue=round(pvalue,3),
         padjustBH=round(padjustBH,3),
         sig=ifelse(padjustBH < 0.05,"sig","nonsig"))%>%
  dplyr::select(element,type,case,var,trend,SE,pvalue,padjustBH,sig)%>%
  .[c(7,1:2,5,3:4,6,8:15,
      22,16:17,20,18:19,21,23:30,
      37,31:32,35,33:34,36,38:45,
      52,46:47,50,48:49,51,53:60),]

load("data.lmer_1k_em_loc_N_1_sp_log_pred.RData") #
dbdx=lmemod@frame

ll1<-obsA_1
obsA<-obsA_1%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% c("intercept","effect")))%>%
  group_by(type,case,var)%>%
  summarise(pvalue=mean(abs(trend[iteration!=0]/SE[iteration!=0]) >= abs(trend[iteration==0]/SE[iteration==0])))
obsA$padjustBO<-p.adjust(obsA$pvalue)
obsA$padjustBH<-p.adjust(obsA$pvalue,method="BH")

test.loc.N=ll1%>%
  filter(iteration %in% 0)%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% "intercept"))%>%
  dplyr::select(type,case,var,trend,SE)%>%
  left_join(obsA,by=c("type","case","var"))%>%
  mutate(element="N",
         trend=formatC(trend, format = "e", digits = 1),
         SE=formatC(SE, format = "e", digits = 1),
         pvalue=round(pvalue,3),
         padjustBH=round(padjustBH,3),
         sig=ifelse(padjustBH < 0.05,"sig","nonsig"))%>%
  dplyr::select(element,type,case,var,trend,SE,pvalue,padjustBH,sig)%>%
  .[c(7,1:2,5,3:4,6,8:15,
      22,16:17,20,18:19,21,23:30,
      37,31:32,35,33:34,36,38:45,
      52,46:47,50,48:49,51,53:60),]

load("data.lmer_1k_em_loc_P_1_sp_log_pred.RData") #
dbdx=lmemod@frame

ll1<-obsA_1
obsA<-obsA_1%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% c("intercept","effect")))%>%
  group_by(type,case,var)%>%
  summarise(pvalue=mean(abs(trend[iteration!=0]/SE[iteration!=0]) >= abs(trend[iteration==0]/SE[iteration==0])))
obsA$padjustBO<-p.adjust(obsA$pvalue)
obsA$padjustBH<-p.adjust(obsA$pvalue,method="BH")

test.loc.P=ll1%>%
  filter(iteration %in% 0)%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% "intercept"))%>%
  dplyr::select(type,case,var,trend,SE)%>%
  left_join(obsA,by=c("type","case","var"))%>%
  mutate(element="P",
         trend=formatC(trend, format = "e", digits = 1),
         SE=formatC(SE, format = "e", digits = 1),
         pvalue=round(pvalue,3),
         padjustBH=round(padjustBH,3),
         sig=ifelse(padjustBH < 0.05,"sig","nonsig"))%>%
  dplyr::select(element,type,case,var,trend,SE,pvalue,padjustBH,sig)%>%
  .[c(7,1:2,5,3:4,6,8:15,
      22,16:17,20,18:19,21,23:30,
      37,31:32,35,33:34,36,38:45,
      52,46:47,50,48:49,51,53:60),]

load("data.lmer_1k_em_loc_NP_1_sp_log_pred.RData") #
dbdx=lmemod@frame

ll1<-obsA_1
obsA<-obsA_1%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% c("intercept","effect")))%>%
  group_by(type,case,var)%>%
  summarise(pvalue=mean(abs(trend[iteration!=0]/SE[iteration!=0]) >= abs(trend[iteration==0]/SE[iteration==0])))
obsA$padjustBO<-p.adjust(obsA$pvalue)
obsA$padjustBH<-p.adjust(obsA$pvalue,method="BH")

test.loc.NP=ll1%>%
  filter(iteration %in% 0)%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% "intercept"))%>%
  dplyr::select(type,case,var,trend,SE)%>%
  left_join(obsA,by=c("type","case","var"))%>%
  mutate(element="N:P",
         trend=formatC(trend, format = "e", digits = 1),
         SE=formatC(SE, format = "e", digits = 1),
         pvalue=round(pvalue,3),
         padjustBH=round(padjustBH,3),
         sig=ifelse(padjustBH < 0.05,"sig","nonsig"))%>%
  dplyr::select(element,type,case,var,trend,SE,pvalue,padjustBH,sig)%>%
  .[c(7,1:2,5,3:4,6,8:15,
      22,16:17,20,18:19,21,23:30,
      37,31:32,35,33:34,36,38:45,
      52,46:47,50,48:49,51,53:60),]

test.N=test.sp.N%>%
  mutate(pvalue.sp=pvalue,
         padjustBH.sp=padjustBH,
         sig.sp=sig)%>%
  dplyr::select(case,var,pvalue.sp,padjustBH.sp,sig.sp)%>%
  left_join(test.loc.N%>%
              mutate(pvalue.loc=pvalue,
                     padjustBH.loc=padjustBH,
                     sig.loc=sig)%>%
              dplyr::select(case,var,pvalue.loc,padjustBH.loc,sig.loc),by=c("case","var"))

##write.table(test.N,file="rmfive_resultsN.doc",row.names=F,quote=F,sep=";")
test.P=test.sp.P%>%
  mutate(pvalue.sp=pvalue,
         padjustBH.sp=padjustBH,
         sig.sp=sig)%>%
  dplyr::select(case,var,pvalue.sp,padjustBH.sp,sig.sp)%>%
  left_join(test.loc.P%>%
              mutate(pvalue.loc=pvalue,
                     padjustBH.loc=padjustBH,
                     sig.loc=sig)%>%
              dplyr::select(case,var,pvalue.loc,padjustBH.loc,sig.loc),by=c("case","var"))
##write.table(test.P,file="rmfive_resultsP.doc",row.names=F,quote=F,sep=";")
test.NP=test.sp.NP%>%
  mutate(pvalue.sp=pvalue,
         padjustBH.sp=padjustBH,
         sig.sp=sig)%>%
  dplyr::select(case,var,pvalue.sp,padjustBH.sp,sig.sp)%>%
  left_join(test.loc.NP%>%
              mutate(pvalue.loc=pvalue,
                     padjustBH.loc=padjustBH,
                     sig.loc=sig)%>%
              dplyr::select(case,var,pvalue.loc,padjustBH.loc,sig.loc),by=c("case","var"))
##write.table(test.NP,file="rmfive_resultsNP.doc",row.names=F,quote=F,sep=";")

####lat data
load("data.lmer_1k_em_sp_lat_N_1_sp.RData")#
dbdx=lmemod@frame

ll1<-obsA_1
obsA<-obsA_1%>%
  filter(!(type %in% c("intercept","effect")))%>%
  group_by(type,case,var)%>%
  summarise(pvalue=mean(abs(trend[iteration!=0]/SE[iteration!=0]) >= abs(trend[iteration==0]/SE[iteration==0])))
obsA$padjustBO<-p.adjust(obsA$pvalue)
obsA$padjustBH<-p.adjust(obsA$pvalue,method="BH")

test_lat_N_sp=ll1%>%
  filter(iteration %in% 0)%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% "intercept"))%>%
  dplyr::select(type,case,var,trend,SE)%>%
  left_join(obsA,by=c("type","case","var"))%>%
  mutate(element="N",
         pvalue.sp=round(pvalue,3),
         padjustBH.sp=round(padjustBH,3),
         sig.sp=ifelse(padjustBH < 0.05,"sig","nonsig"))%>%
  dplyr::select(element,case,var,pvalue.sp,padjustBH.sp,sig.sp)%>%
  .[c(7,1:2,5,3:4,6,8:15),]

load("data.lmer_1k_em_sp_lat_P_1_sp.RData")#
dbdx=lmemod@frame

ll1<-obsA_1
obsA<-obsA_1%>%
  filter(!(type %in% c("intercept","effect")))%>%
  group_by(type,case,var)%>%
  summarise(pvalue=mean(abs(trend[iteration!=0]/SE[iteration!=0]) >= abs(trend[iteration==0]/SE[iteration==0])))
obsA$padjustBO<-p.adjust(obsA$pvalue)
obsA$padjustBH<-p.adjust(obsA$pvalue,method="BH")

test_lat_P_sp=ll1%>%
  filter(iteration %in% 0)%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% "intercept"))%>%
  dplyr::select(type,case,var,trend,SE)%>%
  left_join(obsA,by=c("type","case","var"))%>%
  mutate(element="P",
         pvalue.sp=round(pvalue,3),
         padjustBH.sp=round(padjustBH,3),
         sig.sp=ifelse(padjustBH < 0.05,"sig","nonsig"))%>%
  dplyr::select(element,case,var,pvalue.sp,padjustBH.sp,sig.sp)%>%
  .[c(7,1:2,5,3:4,6,8:15),]

load("data.lmer_1k_em_sp_lat_NP_1_sp.RData") #
dbdx=lmemod@frame

ll1<-obsA_1
obsA<-obsA_1%>%
  filter(!(type %in% c("intercept","effect")))%>%
  group_by(type,case,var)%>%
  summarise(pvalue=mean(abs(trend[iteration!=0]/SE[iteration!=0]) >= abs(trend[iteration==0]/SE[iteration==0])))
obsA$padjustBO<-p.adjust(obsA$pvalue)
obsA$padjustBH<-p.adjust(obsA$pvalue,method="BH")

test_lat_NP_sp=ll1%>%
  filter(iteration %in% 0)%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% "intercept"))%>%
  dplyr::select(type,case,var,trend,SE)%>%
  left_join(obsA,by=c("type","case","var"))%>%
  mutate(element="NP",
         pvalue.sp=round(pvalue,3),
         padjustBH.sp=round(padjustBH,3),
         sig.sp=ifelse(padjustBH < 0.05,"sig","nonsig"))%>%
  dplyr::select(element,case,var,pvalue.sp,padjustBH.sp,sig.sp)%>%
  .[c(7,1:2,5,3:4,6,8:15),]

load("data.lmer_1k_em_loc_lat_N_1_sp.RData") #
dbdx=lmemod@frame

ll1<-obsA_1
obsA<-obsA_1%>%
  filter(!(type %in% c("intercept","effect")))%>%
  group_by(type,case,var)%>%
  summarise(pvalue=mean(abs(trend[iteration!=0]/SE[iteration!=0]) >= abs(trend[iteration==0]/SE[iteration==0])))
obsA$padjustBO<-p.adjust(obsA$pvalue)
obsA$padjustBH<-p.adjust(obsA$pvalue,method="BH")

test_lat_N_loc=ll1%>%
  filter(iteration %in% 0)%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% "intercept"))%>%
  dplyr::select(type,case,var,trend,SE)%>%
  left_join(obsA,by=c("type","case","var"))%>%
  mutate(element="N",
         pvalue.loc=round(pvalue,3),
         padjustBH.loc=round(padjustBH,3),
         sig.loc=ifelse(padjustBH < 0.05,"sig","nonsig"))%>%
  dplyr::select(element,case,var,pvalue.loc,padjustBH.loc,sig.loc)%>%
  .[c(7,1:2,5,3:4,6,8:15),]

load("data.lmer_1k_em_loc_lat_P_1_sp.RData") #
dbdx=lmemod@frame

ll1<-obsA_1
obsA<-obsA_1%>%
  filter(!(type %in% c("intercept","effect")))%>%
  group_by(type,case,var)%>%
  summarise(pvalue=mean(abs(trend[iteration!=0]/SE[iteration!=0]) >= abs(trend[iteration==0]/SE[iteration==0])))
obsA$padjustBO<-p.adjust(obsA$pvalue)
obsA$padjustBH<-p.adjust(obsA$pvalue,method="BH")

test_lat_P_loc=ll1%>%
  filter(iteration %in% 0)%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% "intercept"))%>%
  dplyr::select(type,case,var,trend,SE)%>%
  left_join(obsA,by=c("type","case","var"))%>%
  mutate(element="P",
         pvalue.loc=round(pvalue,3),
         padjustBH.loc=round(padjustBH,3),
         sig.loc=ifelse(padjustBH < 0.05,"sig","nonsig"))%>%
  dplyr::select(element,case,var,pvalue.loc,padjustBH.loc,sig.loc)%>%
  .[c(7,1:2,5,3:4,6,8:15),]

load("data.lmer_1k_em_loc_lat_NP_1_sp.RData") #
dbdx=lmemod@frame

ll1<-obsA_1
obsA<-obsA_1%>%
  filter(!(type %in% c("intercept","effect")))%>%
  group_by(type,case,var)%>%
  summarise(pvalue=mean(abs(trend[iteration!=0]/SE[iteration!=0]) >= abs(trend[iteration==0]/SE[iteration==0])))
obsA$padjustBO<-p.adjust(obsA$pvalue)
obsA$padjustBH<-p.adjust(obsA$pvalue,method="BH")

test_lat_NP_loc=ll1%>%
  filter(iteration %in% 0)%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% "intercept"))%>%
  dplyr::select(type,case,var,trend,SE)%>%
  left_join(obsA,by=c("type","case","var"))%>%
  mutate(element="NP",
         pvalue.loc=round(pvalue,3),
         padjustBH.loc=round(padjustBH,3),
         sig.loc=ifelse(padjustBH < 0.05,"sig","nonsig"))%>%
  dplyr::select(element,case,var,pvalue.loc,padjustBH.loc,sig.loc)%>%
  .[c(7,1:2,5,3:4,6,8:15),]

test=rbind(test_lat_N_sp,test_lat_P_sp,test_lat_NP_sp)%>%
  left_join(rbind(test_lat_N_loc,test_lat_P_loc,test_lat_NP_loc),
            by=c("element","case","var"))

##write.table(test,file="rmfive_results_lat.doc",row.names=F,quote=F,sep=";")

#############################################

####Appendix removing radiation
#############################################
####rm rad - model N
#set combinations of elements
combi<-c("taxa.p","taxa.n","taxa.c","taxa.np","taxa.cp","taxa.cn")

#set element to response: 1=taxa.p, 2=taxa.n, 4=taxa.np
element=2

#use lm_robust:mixed=FALSE or lmer(): mixed=TRUE
mixed=TRUE

#set number of iterations for estimating pvalues
iter=1000
#

dbdx<-db%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_terr_lab,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         species=as.factor(sp.morphosp_revised),
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(paste0(lat.dec," ",long.dec)))%>%
  dplyr::select(combi[element],Temp,Rad,N,P,habitat,autohetero,species,location)%>%
  as.data.frame()%>%
  na.omit()

if(element %in% c(1,2,3)){
  dbdx$Yl<-log((dbdx[,combi[element]]/100)/(1-(dbdx[,combi[element]]/100))) #for n,p,c when logit
}

if(element %in% c(4,5,6)){
  dbdx$Yl<-log(dbdx[,combi[element]]) #for n,p,c when logit
}


### contrast coding of factors
contrasts(dbdx$habitat) <-contr.sum(2)
contrasts(dbdx$autohetero) <-contr.sum(2)

###log or scale predictors
dbdx=dbdx%>%
  mutate(N=log(N),
         P=log(P))


lmemod<-lmer(Yl~habitat+autohetero+Temp+N+P+
               Temp:habitat+P:habitat+N:habitat+Temp:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
               (1|species),data=as.data.frame(dbdx))

te7<-as.data.frame(pairs(emmeans(lmemod, pairwise ~ habitat*autohetero),adjust="none"))
te71<-te7[c(1,2,5,6),]
teDat4<-data.frame(type="effect",
                   case=c(as.character(te71$contrast)),
                   trend=c(te71$estimate),
                   SE=c(te71$SE),
                   df=c(te71$df))

#Temp
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("Temp") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("Temp") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("Temp") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$Temp.trend,te21$Temp.trend,te12$estimate,te22$estimate,te3$Temp.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Temp.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsT<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="Temp")


#N
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("N") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("N") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("N") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$N.trend,te21$N.trend,te12$estimate,te22$estimate,te3$N.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$N.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsN<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="N")

#P
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("P") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("P") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("P") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$P.trend,te21$P.trend,te12$estimate,te22$estimate,te3$P.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$P.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsP<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="P")

obsA<-rbind(obsT,obsN,obsP,mutate(teDat4,var="habtrop"))%>%
  mutate(iteration=0)

#ll2random<-list()
dbdx1<-dbdx%>%group_by(Temp,N,P)%>%mutate(loc_id = cur_group_id())%>%ungroup() 
dbdx2<-dbdx1%>%group_by(Temp,N,P)%>%summarise(loc_id =loc_id[1])%>%ungroup()
datCp<-list()
set.seed(3333)
for(i in 1:iter){
  dbdx2x<-dbdx2
  dbdx2x$loc_id<-sample(dbdx2$loc_id)
  names(dbdx2x)<-c("TempS","NS","PS","loc_id")
  dbdx3<-left_join(dbdx1,dbdx2x,by="loc_id")%>%
    mutate(Temp=TempS,N=NS,P=PS)
  
  lmemodperm<-lmer(Yl~habitat+autohetero+Temp+N+P+
                     Temp:habitat+P:habitat+N:habitat+Temp:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
                     (1|species),
                   data=as.data.frame(dbdx3))#,control = list( LP_tol_ll = 5e-2, LP_max_iter = 1000)
  
  te7<-as.data.frame(pairs(emmeans(lmemodperm, pairwise ~ habitat*autohetero),adjust="none"))
  te71<-te7[c(1,2,5,6),]
  teDat4<-data.frame(type="effect",
                     case=c(as.character(te71$contrast)),
                     trend=c(te71$estimate),
                     SE=c(te71$SE),
                     df=c(te71$df))
  
  suppressMessages({te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Temp") )
  #Temp
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Temp") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("Temp") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("Temp") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("Temp") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$Temp.trend,te21$Temp.trend,te12$estimate,te22$estimate,te3$Temp.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Temp.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsT<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="Temp")
  
  
  
  #N
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("N") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("N") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("N") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$N.trend,te21$N.trend,te12$estimate,te22$estimate,te3$N.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$N.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsN<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="N")
  
  #P
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("P") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("P") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("P") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("P") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$P.trend,te21$P.trend,te12$estimate,te22$estimate,te3$P.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$P.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsP<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="P")
  obsAx<-rbind(obsT,obsN,obsP,mutate(teDat4,var="habtrop"))%>%
    mutate(iteration=i)
  
  })
  
  obsA<-rbind(obsA,obsAx)
  #ll2random[[i]]<-ranef(lmemodperm)
  datte<-ggemmeans(lmemodperm,c("Temp","autohetero","habitat") ,typical="mean")%>%
    mutate(var="Temp")
  datn<-ggemmeans(lmemodperm,c("N","autohetero","habitat") ,typical="mean")%>%
    mutate(var="N")
  datp<-ggemmeans(lmemodperm,c("P","autohetero","habitat") ,typical="mean")%>%
    mutate(var="P")
  
  datCp[[i]]<-rbind(datte,datn,datp)
}

obsA_1<-obsA
datCp_1<-datCp
save(obsA_1,
     datCp_1,
     lmemod,
     file="rm_rad_data.lmer_1k_em_perm_N_1_sp_log_pred.RData")

####rm rad - model P
#set combinations of elements
combi<-c("taxa.p","taxa.n","taxa.c","taxa.np","taxa.cp","taxa.cn")

#set element to response: 1=taxa.p, 2=taxa.n, 4=taxa.np
element=1

#use lm_robust:mixed=FALSE or lmer(): mixed=TRUE
mixed=TRUE

#set number of iterations for estimating pvalues
iter=1000
#

dbdx<-db%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_terr_lab,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         species=as.factor(sp.morphosp_revised),
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(paste0(lat.dec," ",long.dec)))%>%
  dplyr::select(combi[element],Temp,Rad,N,P,habitat,autohetero,species,location)%>%
  as.data.frame()%>%
  na.omit()

if(element %in% c(1,2,3)){
  dbdx$Yl<-log((dbdx[,combi[element]]/100)/(1-(dbdx[,combi[element]]/100))) #for n,p,c when logit
}

if(element %in% c(4,5,6)){
  dbdx$Yl<-log(dbdx[,combi[element]]) #for n,p,c when logit
}


### contrast coding of factors
contrasts(dbdx$habitat) <-contr.sum(2)
contrasts(dbdx$autohetero) <-contr.sum(2)

###log or scale predictors
dbdx=dbdx%>%
  mutate(N=log(N),
         P=log(P))


lmemod<-lmer(Yl~habitat+autohetero+Temp+N+P+
               Temp:habitat+P:habitat+N:habitat+Temp:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
               (1|species),data=as.data.frame(dbdx))

te7<-as.data.frame(pairs(emmeans(lmemod, pairwise ~ habitat*autohetero),adjust="none"))
te71<-te7[c(1,2,5,6),]
teDat4<-data.frame(type="effect",
                   case=c(as.character(te71$contrast)),
                   trend=c(te71$estimate),
                   SE=c(te71$SE),
                   df=c(te71$df))

#Temp
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("Temp") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("Temp") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("Temp") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$Temp.trend,te21$Temp.trend,te12$estimate,te22$estimate,te3$Temp.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Temp.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsT<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="Temp")


#N
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("N") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("N") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("N") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$N.trend,te21$N.trend,te12$estimate,te22$estimate,te3$N.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$N.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsN<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="N")

#P
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("P") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("P") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("P") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$P.trend,te21$P.trend,te12$estimate,te22$estimate,te3$P.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$P.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsP<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="P")

obsA<-rbind(obsT,obsN,obsP,mutate(teDat4,var="habtrop"))%>%
  mutate(iteration=0)

#ll2random<-list()
dbdx1<-dbdx%>%group_by(Temp,N,P)%>%mutate(loc_id = cur_group_id())%>%ungroup() 
dbdx2<-dbdx1%>%group_by(Temp,N,P)%>%summarise(loc_id =loc_id[1])%>%ungroup()
datCp<-list()
set.seed(3333)
for(i in 1:iter){
  dbdx2x<-dbdx2
  dbdx2x$loc_id<-sample(dbdx2$loc_id)
  names(dbdx2x)<-c("TempS","NS","PS","loc_id")
  dbdx3<-left_join(dbdx1,dbdx2x,by="loc_id")%>%
    mutate(Temp=TempS,N=NS,P=PS)
  
  lmemodperm<-lmer(Yl~habitat+autohetero+Temp+N+P+
                     Temp:habitat+P:habitat+N:habitat+Temp:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
                     (1|species),
                   data=as.data.frame(dbdx3))#,control = list( LP_tol_ll = 5e-2, LP_max_iter = 1000)
  
  te7<-as.data.frame(pairs(emmeans(lmemodperm, pairwise ~ habitat*autohetero),adjust="none"))
  te71<-te7[c(1,2,5,6),]
  teDat4<-data.frame(type="effect",
                     case=c(as.character(te71$contrast)),
                     trend=c(te71$estimate),
                     SE=c(te71$SE),
                     df=c(te71$df))
  
  suppressMessages({te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Temp") )
  #Temp
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Temp") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("Temp") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("Temp") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("Temp") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$Temp.trend,te21$Temp.trend,te12$estimate,te22$estimate,te3$Temp.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Temp.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsT<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="Temp")
  
  
  #N
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("N") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("N") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("N") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$N.trend,te21$N.trend,te12$estimate,te22$estimate,te3$N.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$N.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsN<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="N")
  
  #P
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("P") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("P") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("P") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("P") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$P.trend,te21$P.trend,te12$estimate,te22$estimate,te3$P.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$P.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsP<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="P")
  obsAx<-rbind(obsT,obsN,obsP,mutate(teDat4,var="habtrop"))%>%
    mutate(iteration=i)
  
  })
  
  obsA<-rbind(obsA,obsAx)
  #ll2random[[i]]<-ranef(lmemodperm)
  datte<-ggemmeans(lmemodperm,c("Temp","autohetero","habitat") ,typical="mean")%>%
    mutate(var="Temp")
  datn<-ggemmeans(lmemodperm,c("N","autohetero","habitat") ,typical="mean")%>%
    mutate(var="N")
  datp<-ggemmeans(lmemodperm,c("P","autohetero","habitat") ,typical="mean")%>%
    mutate(var="P")
  
  datCp[[i]]<-rbind(datte,datn,datp)
}

obsA_1<-obsA
datCp_1<-datCp
save(obsA_1,
     datCp_1,
     lmemod,
     file="rm_rad_data.lmer_1k_em_perm_P_1_sp_log_pred.RData")

####rm rad - model N:P
#set combinations of elements
combi<-c("taxa.p","taxa.n","taxa.c","taxa.np","taxa.cp","taxa.cn")

#set element to response: 1=taxa.p, 2=taxa.n, 4=taxa.np
element=4

#use lm_robust:mixed=FALSE or lmer(): mixed=TRUE
mixed=TRUE

#set number of iterations for estimating pvalues
iter=1000
#

dbdx<-db%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_terr_lab,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         species=as.factor(sp.morphosp_revised),
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(paste0(lat.dec," ",long.dec)))%>%
  dplyr::select(combi[element],Temp,Rad,N,P,habitat,autohetero,species,location)%>%
  as.data.frame()%>%
  na.omit()

if(element %in% c(1,2,3)){
  dbdx$Yl<-log((dbdx[,combi[element]]/100)/(1-(dbdx[,combi[element]]/100))) #for n,p,c when logit
}

if(element %in% c(4,5,6)){
  dbdx$Yl<-log(dbdx[,combi[element]]) #for n,p,c when logit
}


### contrast coding of factors
contrasts(dbdx$habitat) <-contr.sum(2)
contrasts(dbdx$autohetero) <-contr.sum(2)

###log or scale predictors
dbdx=dbdx%>%
  mutate(N=log(N),
         P=log(P))


lmemod<-lmer(Yl~habitat+autohetero+Temp+N+P+
               Temp:habitat+P:habitat+N:habitat+Temp:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
               (1|species),data=as.data.frame(dbdx))

te7<-as.data.frame(pairs(emmeans(lmemod, pairwise ~ habitat*autohetero),adjust="none"))
te71<-te7[c(1,2,5,6),]
teDat4<-data.frame(type="effect",
                   case=c(as.character(te71$contrast)),
                   trend=c(te71$estimate),
                   SE=c(te71$SE),
                   df=c(te71$df))

#Temp
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("Temp") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("Temp") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("Temp") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$Temp.trend,te21$Temp.trend,te12$estimate,te22$estimate,te3$Temp.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Temp.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsT<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="Temp")



#N
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("N") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("N") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("N") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$N.trend,te21$N.trend,te12$estimate,te22$estimate,te3$N.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$N.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsN<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="N")

#P
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("P") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("P") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("P") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$P.trend,te21$P.trend,te12$estimate,te22$estimate,te3$P.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$P.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsP<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="P")

obsA<-rbind(obsT,obsN,obsP,mutate(teDat4,var="habtrop"))%>%
  mutate(iteration=0)

#ll2random<-list()
dbdx1<-dbdx%>%group_by(Temp,N,P)%>%mutate(loc_id = cur_group_id())%>%ungroup() 
dbdx2<-dbdx1%>%group_by(Temp,N,P)%>%summarise(loc_id =loc_id[1])%>%ungroup()
datCp<-list()
set.seed(3333)
for(i in 1:iter){
  dbdx2x<-dbdx2
  dbdx2x$loc_id<-sample(dbdx2$loc_id)
  names(dbdx2x)<-c("TempS","NS","PS","loc_id")
  dbdx3<-left_join(dbdx1,dbdx2x,by="loc_id")%>%
    mutate(Temp=TempS,N=NS,P=PS)
  
  lmemodperm<-lmer(Yl~habitat+autohetero+Temp+N+P+
                     Temp:habitat+P:habitat+N:habitat+Temp:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
                     (1|species),
                   data=as.data.frame(dbdx3))#,control = list( LP_tol_ll = 5e-2, LP_max_iter = 1000)
  
  te7<-as.data.frame(pairs(emmeans(lmemodperm, pairwise ~ habitat*autohetero),adjust="none"))
  te71<-te7[c(1,2,5,6),]
  teDat4<-data.frame(type="effect",
                     case=c(as.character(te71$contrast)),
                     trend=c(te71$estimate),
                     SE=c(te71$SE),
                     df=c(te71$df))
  
  suppressMessages({te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Temp") )
  #Temp
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Temp") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("Temp") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("Temp") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("Temp") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$Temp.trend,te21$Temp.trend,te12$estimate,te22$estimate,te3$Temp.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Temp.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsT<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="Temp")
  
  
  #N
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("N") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("N") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("N") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$N.trend,te21$N.trend,te12$estimate,te22$estimate,te3$N.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$N.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsN<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="N")
  
  #P
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("P") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("P") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("P") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("P") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$P.trend,te21$P.trend,te12$estimate,te22$estimate,te3$P.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$P.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsP<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="P")
  obsAx<-rbind(obsT,obsN,obsP,mutate(teDat4,var="habtrop"))%>%
    mutate(iteration=i)
  
  })
  
  obsA<-rbind(obsA,obsAx)
  datte<-ggemmeans(lmemodperm,c("Temp","autohetero","habitat") ,typical="mean")%>%
    mutate(var="Temp")
  datn<-ggemmeans(lmemodperm,c("N","autohetero","habitat") ,typical="mean")%>%
    mutate(var="N")
  datp<-ggemmeans(lmemodperm,c("P","autohetero","habitat") ,typical="mean")%>%
    mutate(var="P")
  
  datCp[[i]]<-rbind(datte,datn,datp)
  #ll2random[[i]]<-ranef(lmemodperm)
}

obsA_1<-obsA
datCp_1<-datCp
save(obsA_1,
     datCp_1,
     lmemod,
     file="rm_rad_data.lmer_1k_em_perm_NP_1_sp_log_pred.RData")

####prepare appendix rm rad
load("rm_rad_data.lmer_1k_em_perm_N_1_sp_log_pred.RData")
load("rm_rad_data.lmer_1k_em_perm_P_1_sp_log_pred.RData")
load("rm_rad_data.lmer_1k_em_perm_NP_1_sp_log_pred.RData")

dbdx=lmemod@frame

ll1<-obsA_1
obsA<-obsA_1%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% c("intercept","effect")))%>%
  group_by(type,case,var)%>%
  summarise(pvalue=mean(abs(trend[iteration!=0]/SE[iteration!=0]) >= abs(trend[iteration==0]/SE[iteration==0])))
obsA$padjustBO<-p.adjust(obsA$pvalue)
obsA$padjustBH<-p.adjust(obsA$pvalue,method="BH")



ll1%>%
  filter(iteration %in% 0)%>%
  dplyr::select(type,case,var,trend,SE)%>%
  left_join(obsA,by=c("type","case","var"))%>%
  filter(padjustBH < 0.05)%>%#pvalue, padjustBH, padjustBO
  View()

##prepare tables appendices
test=ll1%>%
  filter(iteration %in% 0)%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% "intercept"))%>%
  dplyr::select(type,case,var,trend,SE)%>%
  left_join(obsA,by=c("type","case","var"))%>%
  mutate(element="N",
         trend=formatC(trend, format = "e", digits = 1),
         SE=formatC(SE, format = "e", digits = 1),
         pvalue=round(pvalue,3),
         padjustBH=round(padjustBH,3),
         sig=ifelse(padjustBH < 0.05,"sig","nonsig"))%>%
  dplyr::select(element,type,case,var,trend,SE,pvalue,padjustBH,sig)%>%
  .[c(7,1:2,5,3:4,6,8:15,
      22,16:17,20,18:19,21,23:30,
      37,31:32,35,33:34,36,38:45),]

##write.table(test,file="rmrad_resultsN.doc",row.names=F,quote=F,sep=";")
test=ll1%>%
  filter(iteration %in% 0)%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% "intercept"))%>%
  dplyr::select(type,case,var,trend,SE)%>%
  left_join(obsA,by=c("type","case","var"))%>%
  mutate(element="P",
         trend=formatC(trend, format = "e", digits = 1),
         SE=formatC(SE, format = "e", digits = 1),
         pvalue=round(pvalue,3),
         padjustBH=round(padjustBH,3),
         sig=ifelse(padjustBH < 0.05,"sig","nonsig"))%>%
  dplyr::select(element,type,case,var,trend,SE,pvalue,padjustBH,sig)%>%
  .[c(7,1:2,5,3:4,6,8:15,
      22,16:17,20,18:19,21,23:30,
      37,31:32,35,33:34,36,38:45),]
##write.table(test,file="rmrad_resultsP.doc",row.names=F,quote=F,sep=";")
test=ll1%>%
  filter(iteration %in% 0)%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% "intercept"))%>%
  dplyr::select(type,case,var,trend,SE)%>%
  left_join(obsA,by=c("type","case","var"))%>%
  mutate(element="N:P",
         trend=formatC(trend, format = "e", digits = 1),
         SE=formatC(SE, format = "e", digits = 1),
         pvalue=round(pvalue,3),
         padjustBH=round(padjustBH,3),
         sig=ifelse(padjustBH < 0.05,"sig","nonsig"))%>%
  dplyr::select(element,type,case,var,trend,SE,pvalue,padjustBH,sig)%>%
  .[c(7,1:2,5,3:4,6,8:15,
      22,16:17,20,18:19,21,23:30,
      37,31:32,35,33:34,36,38:45),]
##write.table(test,file="rmrad_resultsNP.doc",row.names=F,quote=F,sep=";")
#############################################

####Appendix removing temperature
#############################################
####rm tmp - model N
#set combinations of elements
combi<-c("taxa.p","taxa.n","taxa.c","taxa.np","taxa.cp","taxa.cn")

#set element to response: 1=taxa.p, 2=taxa.n, 4=taxa.np
element=2

#use lm_robust:mixed=FALSE or lmer(): mixed=TRUE
mixed=TRUE

#set number of iterations for estimating pvalues
iter=1000
#

dbdx<-db%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_terr_lab,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         species=as.factor(sp.morphosp_revised),
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(paste0(lat.dec," ",long.dec)))%>%
  dplyr::select(combi[element],Temp,Rad,N,P,habitat,autohetero,species,location)%>%
  as.data.frame()%>%
  na.omit()

if(element %in% c(1,2,3)){
  dbdx$Yl<-log((dbdx[,combi[element]]/100)/(1-(dbdx[,combi[element]]/100))) #for n,p,c when logit
}

if(element %in% c(4,5,6)){
  dbdx$Yl<-log(dbdx[,combi[element]]) #for n,p,c when logit
}


### contrast coding of factors
contrasts(dbdx$habitat) <-contr.sum(2)
contrasts(dbdx$autohetero) <-contr.sum(2)

###log or scale predictors
dbdx=dbdx%>%
  mutate(N=log(N),
         P=log(P))


lmemod<-lmer(Yl~habitat+autohetero+Rad+N+P+
               Rad:habitat+P:habitat+N:habitat+Rad:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
               (1|species),data=as.data.frame(dbdx))

te7<-as.data.frame(pairs(emmeans(lmemod, pairwise ~ habitat*autohetero),adjust="none"))
te71<-te7[c(1,2,5,6),]
teDat4<-data.frame(type="effect",
                   case=c(as.character(te71$contrast)),
                   trend=c(te71$estimate),
                   SE=c(te71$SE),
                   df=c(te71$df))

#Rad
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("Rad") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("Rad") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("Rad") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$Rad.trend,te21$Rad.trend,te12$estimate,te22$estimate,te3$Rad.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Rad.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsT<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="Rad")


#N
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("N") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("N") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("N") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$N.trend,te21$N.trend,te12$estimate,te22$estimate,te3$N.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$N.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsN<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="N")

#P
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("P") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("P") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("P") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$P.trend,te21$P.trend,te12$estimate,te22$estimate,te3$P.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$P.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsP<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="P")

obsA<-rbind(obsT,obsN,obsP,mutate(teDat4,var="habtrop"))%>%
  mutate(iteration=0)

#ll2random<-list()
dbdx1<-dbdx%>%group_by(Rad,N,P)%>%mutate(loc_id = cur_group_id())%>%ungroup() 
dbdx2<-dbdx1%>%group_by(Rad,N,P)%>%summarise(loc_id =loc_id[1])%>%ungroup()
datCp<-list()
set.seed(3333)
for(i in 1:iter){
  dbdx2x<-dbdx2
  dbdx2x$loc_id<-sample(dbdx2$loc_id)
  names(dbdx2x)<-c("RadS","NS","PS","loc_id")
  dbdx3<-left_join(dbdx1,dbdx2x,by="loc_id")%>%
    mutate(Rad=RadS,N=NS,P=PS)
  
  lmemodperm<-lmer(Yl~habitat+autohetero+Rad+N+P+
                     Rad:habitat+P:habitat+N:habitat+Rad:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
                     (1|species),
                   data=as.data.frame(dbdx3))#,control = list( LP_tol_ll = 5e-2, LP_max_iter = 1000)
  
  te7<-as.data.frame(pairs(emmeans(lmemodperm, pairwise ~ habitat*autohetero),adjust="none"))
  te71<-te7[c(1,2,5,6),]
  teDat4<-data.frame(type="effect",
                     case=c(as.character(te71$contrast)),
                     trend=c(te71$estimate),
                     SE=c(te71$SE),
                     df=c(te71$df))
  
  suppressMessages({te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Rad") )
  #Rad
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Rad") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("Rad") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("Rad") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("Rad") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$Rad.trend,te21$Rad.trend,te12$estimate,te22$estimate,te3$Rad.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Rad.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsT<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="Rad")
  
  
  
  #N
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("N") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("N") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("N") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$N.trend,te21$N.trend,te12$estimate,te22$estimate,te3$N.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$N.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsN<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="N")
  
  #P
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("P") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("P") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("P") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("P") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$P.trend,te21$P.trend,te12$estimate,te22$estimate,te3$P.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$P.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsP<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="P")
  obsAx<-rbind(obsT,obsN,obsP,mutate(teDat4,var="habtrop"))%>%
    mutate(iteration=i)
  
  })
  
  obsA<-rbind(obsA,obsAx)
  #ll2random[[i]]<-ranef(lmemodperm)
  datte<-ggemmeans(lmemodperm,c("Rad","autohetero","habitat") ,typical="mean")%>%
    mutate(var="")
  datn<-ggemmeans(lmemodperm,c("N","autohetero","habitat") ,typical="mean")%>%
    mutate(var="N")
  datp<-ggemmeans(lmemodperm,c("P","autohetero","habitat") ,typical="mean")%>%
    mutate(var="P")
  
  datCp[[i]]<-rbind(datte,datn,datp)
}

obsA_1<-obsA
datCp_1<-datCp
save(obsA_1,
     datCp_1,
     lmemod,
     file="rm_temp_data.lmer_1k_em_perm_N_1_sp_log_pred.RData")

####rm tmp - model P
#set combinations of elements
combi<-c("taxa.p","taxa.n","taxa.c","taxa.np","taxa.cp","taxa.cn")

#set element to response: 1=taxa.p, 2=taxa.n, 4=taxa.np
element=1

#use lm_robust:mixed=FALSE or lmer(): mixed=TRUE
mixed=TRUE

#set number of iterations for estimating pvalues
iter=1000
#

dbdx<-db%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_terr_lab,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         species=as.factor(sp.morphosp_revised),
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(paste0(lat.dec," ",long.dec)))%>%
  dplyr::select(combi[element],Temp,Rad,N,P,habitat,autohetero,species,location)%>%
  as.data.frame()%>%
  na.omit()

if(element %in% c(1,2,3)){
  dbdx$Yl<-log((dbdx[,combi[element]]/100)/(1-(dbdx[,combi[element]]/100))) #for n,p,c when logit
}

if(element %in% c(4,5,6)){
  dbdx$Yl<-log(dbdx[,combi[element]]) #for n,p,c when logit
}


### contrast coding of factors
contrasts(dbdx$habitat) <-contr.sum(2)
contrasts(dbdx$autohetero) <-contr.sum(2)

###log or scale predictors
dbdx=dbdx%>%
  mutate(N=log(N),
         P=log(P))


lmemod<-lmer(Yl~habitat+autohetero+Rad+N+P+
               Rad:habitat+P:habitat+N:habitat+Rad:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
               (1|species),data=as.data.frame(dbdx))

te7<-as.data.frame(pairs(emmeans(lmemod, pairwise ~ habitat*autohetero),adjust="none"))
te71<-te7[c(1,2,5,6),]
teDat4<-data.frame(type="effect",
                   case=c(as.character(te71$contrast)),
                   trend=c(te71$estimate),
                   SE=c(te71$SE),
                   df=c(te71$df))

#Rad
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("Rad") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("Rad") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("Rad") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$Rad.trend,te21$Rad.trend,te12$estimate,te22$estimate,te3$Rad.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Rad.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsT<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="Rad")


#N
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("N") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("N") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("N") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$N.trend,te21$N.trend,te12$estimate,te22$estimate,te3$N.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$N.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsN<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="N")

#P
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("P") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("P") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("P") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$P.trend,te21$P.trend,te12$estimate,te22$estimate,te3$P.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$P.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsP<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="P")

obsA<-rbind(obsT,obsN,obsP,mutate(teDat4,var="habtrop"))%>%
  mutate(iteration=0)

#ll2random<-list()
dbdx1<-dbdx%>%group_by(Rad,N,P)%>%mutate(loc_id = cur_group_id())%>%ungroup() 
dbdx2<-dbdx1%>%group_by(Rad,N,P)%>%summarise(loc_id =loc_id[1])%>%ungroup()
datCp<-list()
set.seed(3333)
for(i in 1:iter){
  dbdx2x<-dbdx2
  dbdx2x$loc_id<-sample(dbdx2$loc_id)
  names(dbdx2x)<-c("RadS","NS","PS","loc_id")
  dbdx3<-left_join(dbdx1,dbdx2x,by="loc_id")%>%
    mutate(Rad=RadS,N=NS,P=PS)
  
  lmemodperm<-lmer(Yl~habitat+autohetero+Rad+N+P+
                     Rad:habitat+P:habitat+N:habitat+Rad:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
                     (1|species),
                   data=as.data.frame(dbdx3))#,control = list( LP_tol_ll = 5e-2, LP_max_iter = 1000)
  
  te7<-as.data.frame(pairs(emmeans(lmemodperm, pairwise ~ habitat*autohetero),adjust="none"))
  te71<-te7[c(1,2,5,6),]
  teDat4<-data.frame(type="effect",
                     case=c(as.character(te71$contrast)),
                     trend=c(te71$estimate),
                     SE=c(te71$SE),
                     df=c(te71$df))
  
  suppressMessages({te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Rad") )
  #Rad
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Rad") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("Rad") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("Rad") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("Rad") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$Rad.trend,te21$Rad.trend,te12$estimate,te22$estimate,te3$Rad.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Rad.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsT<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="Rad")
  
  
  #N
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("N") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("N") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("N") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$N.trend,te21$N.trend,te12$estimate,te22$estimate,te3$N.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$N.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsN<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="N")
  
  #P
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("P") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("P") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("P") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("P") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$P.trend,te21$P.trend,te12$estimate,te22$estimate,te3$P.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$P.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsP<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="P")
  obsAx<-rbind(obsT,obsN,obsP,mutate(teDat4,var="habtrop"))%>%
    mutate(iteration=i)
  
  })
  
  obsA<-rbind(obsA,obsAx)
  #ll2random[[i]]<-ranef(lmemodperm)
  datte<-ggemmeans(lmemodperm,c("Rad","autohetero","habitat") ,typical="mean")%>%
    mutate(var="Rad")
  datn<-ggemmeans(lmemodperm,c("N","autohetero","habitat") ,typical="mean")%>%
    mutate(var="N")
  datp<-ggemmeans(lmemodperm,c("P","autohetero","habitat") ,typical="mean")%>%
    mutate(var="P")
  
  datCp[[i]]<-rbind(datte,datn,datp)
}

obsA_1<-obsA
datCp_1<-datCp
save(obsA_1,
     datCp_1,
     lmemod,
     file="rm_temp_data.lmer_1k_em_perm_P_1_sp_log_pred.RData")

####rm tmp - model N:P
#set combinations of elements
combi<-c("taxa.p","taxa.n","taxa.c","taxa.np","taxa.cp","taxa.cn")

#set element to response: 1=taxa.p, 2=taxa.n, 4=taxa.np
element=4

#use lm_robust:mixed=FALSE or lmer(): mixed=TRUE
mixed=TRUE

#set number of iterations for estimating pvalues
iter=1000
#

dbdx<-db%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_terr_lab,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         species=as.factor(sp.morphosp_revised),
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(paste0(lat.dec," ",long.dec)))%>%
  dplyr::select(combi[element],Temp,Rad,N,P,habitat,autohetero,species,location)%>%
  as.data.frame()%>%
  na.omit()

if(element %in% c(1,2,3)){
  dbdx$Yl<-log((dbdx[,combi[element]]/100)/(1-(dbdx[,combi[element]]/100))) #for n,p,c when logit
}

if(element %in% c(4,5,6)){
  dbdx$Yl<-log(dbdx[,combi[element]]) #for n,p,c when logit
}


### contrast coding of factors
contrasts(dbdx$habitat) <-contr.sum(2)
contrasts(dbdx$autohetero) <-contr.sum(2)

###log or scale predictors
dbdx=dbdx%>%
  mutate(N=log(N),
         P=log(P))


lmemod<-lmer(Yl~habitat+autohetero+Rad+N+P+
               Rad:habitat+P:habitat+N:habitat+Rad:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
               (1|species),data=as.data.frame(dbdx))

te7<-as.data.frame(pairs(emmeans(lmemod, pairwise ~ habitat*autohetero),adjust="none"))
te71<-te7[c(1,2,5,6),]
teDat4<-data.frame(type="effect",
                   case=c(as.character(te71$contrast)),
                   trend=c(te71$estimate),
                   SE=c(te71$SE),
                   df=c(te71$df))

#Rad
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("Rad") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("Rad") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("Rad") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$Rad.trend,te21$Rad.trend,te12$estimate,te22$estimate,te3$Rad.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Rad.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsT<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="Rad")



#N
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("N") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("N") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("N") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$N.trend,te21$N.trend,te12$estimate,te22$estimate,te3$N.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$N.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsN<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="N")

#P
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("P") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("P") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("P") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$P.trend,te21$P.trend,te12$estimate,te22$estimate,te3$P.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$P.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsP<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="P")

obsA<-rbind(obsT,obsN,obsP,mutate(teDat4,var="habtrop"))%>%
  mutate(iteration=0)

#ll2random<-list()
dbdx1<-dbdx%>%group_by(Rad,N,P)%>%mutate(loc_id = cur_group_id())%>%ungroup() 
dbdx2<-dbdx1%>%group_by(Rad,N,P)%>%summarise(loc_id =loc_id[1])%>%ungroup()
datCp<-list()
set.seed(3333)
for(i in 1:iter){
  dbdx2x<-dbdx2
  dbdx2x$loc_id<-sample(dbdx2$loc_id)
  names(dbdx2x)<-c("RadS","NS","PS","loc_id")
  dbdx3<-left_join(dbdx1,dbdx2x,by="loc_id")%>%
    mutate(Rad=RadS,N=NS,P=PS)
  
  lmemodperm<-lmer(Yl~habitat+autohetero+Rad+N+P+
                     Rad:habitat+P:habitat+N:habitat+Rad:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
                     (1|species),
                   data=as.data.frame(dbdx3))#,control = list( LP_tol_ll = 5e-2, LP_max_iter = 1000)
  
  te7<-as.data.frame(pairs(emmeans(lmemodperm, pairwise ~ habitat*autohetero),adjust="none"))
  te71<-te7[c(1,2,5,6),]
  teDat4<-data.frame(type="effect",
                     case=c(as.character(te71$contrast)),
                     trend=c(te71$estimate),
                     SE=c(te71$SE),
                     df=c(te71$df))
  
  suppressMessages({te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Rad") )
  #Rad
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Rad") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("Rad") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("Rad") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("Rad") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$Rad.trend,te21$Rad.trend,te12$estimate,te22$estimate,te3$Rad.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Rad.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsT<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="Rad")
  
  
  #N
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("N") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("N") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("N") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$N.trend,te21$N.trend,te12$estimate,te22$estimate,te3$N.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$N.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsN<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="N")
  
  #P
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("P") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("P") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("P") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("P") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$P.trend,te21$P.trend,te12$estimate,te22$estimate,te3$P.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$P.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsP<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="P")
  obsAx<-rbind(obsT,obsN,obsP,mutate(teDat4,var="habtrop"))%>%
    mutate(iteration=i)
  
  })
  
  obsA<-rbind(obsA,obsAx)
  datte<-ggemmeans(lmemodperm,c("Rad","autohetero","habitat") ,typical="mean")%>%
    mutate(var="Rad")
  datn<-ggemmeans(lmemodperm,c("N","autohetero","habitat") ,typical="mean")%>%
    mutate(var="N")
  datp<-ggemmeans(lmemodperm,c("P","autohetero","habitat") ,typical="mean")%>%
    mutate(var="P")
  
  datCp[[i]]<-rbind(datte,datn,datp)
  #ll2random[[i]]<-ranef(lmemodperm)
}

obsA_1<-obsA
datCp_1<-datCp
save(obsA_1,
     datCp_1,
     lmemod,
     file="rm_temp_data.lmer_1k_em_perm_NP_1_sp_log_pred.RData")

####prepare appendix rm tmp
##model N
load("rm_temp_data.lmer_1k_em_perm_N_1_sp_log_pred.RData")

dbdx=lmemod@frame

ll1<-obsA_1
obsA<-obsA_1%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% c("intercept","effect")))%>%
  group_by(type,case,var)%>%
  summarise(pvalue=mean(abs(trend[iteration!=0]/SE[iteration!=0]) >= abs(trend[iteration==0]/SE[iteration==0])))
obsA$padjustBO<-p.adjust(obsA$pvalue)
obsA$padjustBH<-p.adjust(obsA$pvalue,method="BH")

test_N=ll1%>%
  filter(iteration %in% 0)%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% "intercept"))%>%
  dplyr::select(type,case,var,trend,SE)%>%
  left_join(obsA,by=c("type","case","var"))%>%
  mutate(element="N",
         trend=formatC(trend, format = "e", digits = 1),
         SE=formatC(SE, format = "e", digits = 1),
         pvalue=formatC(round(pvalue,3),format = "f",digits = 3),
         padjustBH=formatC(round(padjustBH,3),format = "f",digits = 3),
         sig=ifelse(padjustBH < 0.05,"sig","nonsig"))%>%
  dplyr::select(element,case,var,trend,SE,pvalue,padjustBH,sig)%>%
  arrange(factor(var,levels=c("Rad","N","P")),factor(case,levels=c("overall",
                                                                   "freshwater","terrestrial","freshwater - terrestrial",
                                                                   "autotroph","heterotroph","autotroph - heterotroph",
                                                                   "freshwater autotroph","terrestrial autotroph","freshwater heterotroph","terrestrial heterotroph",
                                                                   "freshwater autotroph - terrestrial autotroph",
                                                                   "freshwater autotroph - freshwater heterotroph",
                                                                   "terrestrial autotroph - terrestrial heterotroph",
                                                                   "freshwater heterotroph - terrestrial heterotroph")))

##model P
load("rm_temp_data.lmer_1k_em_perm_P_1_sp_log_pred.RData")

dbdx=lmemod@frame

ll1<-obsA_1
obsA<-obsA_1%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% c("intercept","effect")))%>%
  group_by(type,case,var)%>%
  summarise(pvalue=mean(abs(trend[iteration!=0]/SE[iteration!=0]) >= abs(trend[iteration==0]/SE[iteration==0])))
obsA$padjustBO<-p.adjust(obsA$pvalue)
obsA$padjustBH<-p.adjust(obsA$pvalue,method="BH")

test_P=ll1%>%
  filter(iteration %in% 0)%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% "intercept"))%>%
  dplyr::select(type,case,var,trend,SE)%>%
  left_join(obsA,by=c("type","case","var"))%>%
  mutate(element="P",
         trend=formatC(trend, format = "e", digits = 1),
         SE=formatC(SE, format = "e", digits = 1),
         pvalue=formatC(round(pvalue,3),format = "f",digits = 3),
         padjustBH=formatC(round(padjustBH,3),format = "f",digits = 3),
         sig=ifelse(padjustBH < 0.05,"sig","nonsig"))%>%
  dplyr::select(element,case,var,trend,SE,pvalue,padjustBH,sig)%>%
  arrange(factor(var,levels=c("Rad","N","P")),factor(case,levels=c("overall",
                                                                   "freshwater","terrestrial","freshwater - terrestrial",
                                                                   "autotroph","heterotroph","autotroph - heterotroph",
                                                                   "freshwater autotroph","terrestrial autotroph","freshwater heterotroph","terrestrial heterotroph",
                                                                   "freshwater autotroph - terrestrial autotroph",
                                                                   "freshwater autotroph - freshwater heterotroph",
                                                                   "terrestrial autotroph - terrestrial heterotroph",
                                                                   "freshwater heterotroph - terrestrial heterotroph")))

##model NP
load("rm_temp_data.lmer_1k_em_perm_NP_1_sp_log_pred.RData")

dbdx=lmemod@frame

ll1<-obsA_1
obsA<-obsA_1%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% c("intercept","effect")))%>%
  group_by(type,case,var)%>%
  summarise(pvalue=mean(abs(trend[iteration!=0]/SE[iteration!=0]) >= abs(trend[iteration==0]/SE[iteration==0])))
obsA$padjustBO<-p.adjust(obsA$pvalue)
obsA$padjustBH<-p.adjust(obsA$pvalue,method="BH")

test_NP=ll1%>%
  filter(iteration %in% 0)%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% "intercept"))%>%
  dplyr::select(type,case,var,trend,SE)%>%
  left_join(obsA,by=c("type","case","var"))%>%
  mutate(element="N:P",
         trend=formatC(trend, format = "e", digits = 1),
         SE=formatC(SE, format = "e", digits = 1),
         pvalue=formatC(round(pvalue,3),format = "f",digits = 3),
         padjustBH=formatC(round(padjustBH,3),format = "f",digits = 3),
         sig=ifelse(padjustBH < 0.05,"sig","nonsig"))%>%
  dplyr::select(element,case,var,trend,SE,pvalue,padjustBH,sig)%>%
  arrange(factor(var,levels=c("Rad","N","P")),factor(case,levels=c("overall",
                                                                   "freshwater","terrestrial","freshwater - terrestrial",
                                                                   "autotroph","heterotroph","autotroph - heterotroph",
                                                                   "freshwater autotroph","terrestrial autotroph","freshwater heterotroph","terrestrial heterotroph",
                                                                   "freshwater autotroph - terrestrial autotroph",
                                                                   "freshwater autotroph - freshwater heterotroph",
                                                                   "terrestrial autotroph - terrestrial heterotroph",
                                                                   "freshwater heterotroph - terrestrial heterotroph")))
test=rbind(test_N,test_P,test_NP)
test1=test%>%
  mutate(Effects=case,Slopes=trend,P=pvalue,'P-B&H'=padjustBH)%>%
  dplyr::select(element,var,Effects,Slopes,SE,P,'P-B&H',sig)
##write.table(test1,file="C:/Users/odezerald/Documents/Proposal/2019_sDiv_sTOCHIOMETREE/Analyses/Plots/species log Navai Pavai/Remove temperature/rmtemp_results_all.doc",row.names=F,quote=F,sep=";")

ll1%>%
  filter(iteration %in% 0)%>%
  dplyr::select(type,case,var,trend,SE)%>%
  left_join(obsA,by=c("type","case","var"))%>%
  filter(padjustBH < 0.05)%>%#pvalue, padjustBH, padjustBO
  View()

#############################################

####Appendix additional interactions
#############################################
load("data.lmer_1k_em_perm_N_1_sp_log_pred.RData")
test=rsquared(lmemod)%>%
  dplyr::select(-family,-link,-method)%>%
  mutate(AICc=AICc(lmemod),
         Response="N")
load("data.lmer_1k_em_perm_P_1_sp_log_pred.RData")
test=rbind(test,rsquared(lmemod)%>%
             dplyr::select(-family,-link,-method)%>%
             mutate(AICc=AICc(lmemod),
                    Response="P"))
load("data.lmer_1k_em_perm_NP_1_sp_log_pred.RData")
test=rbind(test,rsquared(lmemod)%>%
             dplyr::select(-family,-link,-method)%>%
             mutate(AICc=AICc(lmemod),
                    Response="NP"))

#set combinations of elements
combi<-c("taxa.p","taxa.n","taxa.c","taxa.np","taxa.cp","taxa.cn")
mod.list<-list()
for(i in c(2,1,4)){
#set element to response: 1=taxa.p, 2=taxa.n, 4=taxa.np
element=i

#use lm_robust:mixed=FALSE or lmer(): mixed=TRUE
mixed=TRUE

#select datasets
dbdx<-db%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_terr_lab,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         species=as.factor(sp.morphosp_revised),
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(paste0(lat.dec," ",long.dec)))%>%
  dplyr::select(combi[element],Temp,Rad,N,P,habitat,autohetero,species,location)%>%
  as.data.frame()%>%
  na.omit()

if(element %in% c(1,2,3)){
  dbdx$Yl<-log((dbdx[,combi[element]]/100)/(1-(dbdx[,combi[element]]/100))) #for n,p,c when logit
}

if(element %in% c(4,5,6)){
  dbdx$Yl<-log(dbdx[,combi[element]]) #for n,p,c when logit
}


### contrast coding of factors
contrasts(dbdx$habitat) <-contr.sum(2)
contrasts(dbdx$autohetero) <-contr.sum(2)

###log or scale predictors
dbdx=dbdx%>%
  mutate(N=log(N),
         P=log(P))


lmemod<-lmer(Yl~habitat+autohetero+Temp+Rad+N+P+
               Temp:N+N:P+
               Temp:habitat+Rad:habitat+P:habitat+N:habitat+Temp:autohetero+Rad:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
               (1|species),data=as.data.frame(dbdx))
mod.list[[i]]<-lmemod
}

# save(mod.list,
#      file="inter_lmer_em_N.P.NP_sp_log_pred.RData")

test1=rbind(rsquared(mod.list[[2]])%>%
              dplyr::select(-family,-link,-method)%>%
              mutate(AICc=AICc(mod.list[[2]]),
                     Response="N"),
            rsquared(mod.list[[1]])%>%
              dplyr::select(-family,-link,-method)%>%
              mutate(AICc=AICc(mod.list[[1]]),
                     Response="P"),
            rsquared(mod.list[[4]])%>%
             dplyr::select(-family,-link,-method)%>%
             mutate(AICc=AICc(mod.list[[4]]),
                    Response="NP"))

test%>%
  left_join(test1,by="Response")%>%
  mutate(delta.marg.R2=Marginal.x-Marginal.y,
    delta.AICc=AICc.x-AICc.y)

##significance
element=2
#select datasets
dbdx<-db%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_terr_lab,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         species=as.factor(sp.morphosp_revised),
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(paste0(lat.dec," ",long.dec)))%>%
  dplyr::select(combi[element],Temp,Rad,N,P,habitat,autohetero,species,location)%>%
  as.data.frame()%>%
  na.omit()

if(element %in% c(1,2,3)){
  dbdx$Yl<-log((dbdx[,combi[element]]/100)/(1-(dbdx[,combi[element]]/100))) #for n,p,c when logit
}

### contrast coding of factors
contrasts(dbdx$habitat) <-contr.sum(2)
contrasts(dbdx$autohetero) <-contr.sum(2)

###log or scale predictors
dbdx=dbdx%>%
  mutate(N=log(N),
         P=log(P))


obsA1=emtrends(mod.list[[2]], pairwise ~ Temp, var="N", at=list(Temp=c(mean(mod.list[[2]]@frame$Temp)-sd(mod.list[[2]]@frame$Temp),mean(mod.list[[2]]@frame$Temp)+sd(mod.list[[2]]@frame$Temp),
                                                                      quantile(mod.list[[2]]@frame$Temp,0.025),quantile(mod.list[[2]]@frame$Temp,0.975))))$emtrends%>%
  as.data.frame()%>%
  mutate(iteration=0,
         type=c("mmsd","mpsd","q2.5","q97.5"),
         var="Temp",
         trend=N.trend,
         value.orig=Temp,
         value.rand=c(mean(mod.list[[2]]@frame$Temp)-sd(mod.list[[2]]@frame$Temp),mean(mod.list[[2]]@frame$Temp)+sd(mod.list[[2]]@frame$Temp),
                 quantile(mod.list[[2]]@frame$Temp,0.025),quantile(mod.list[[2]]@frame$Temp,0.975)))%>%
  dplyr::select(var,type,trend,SE,iteration,value.orig,value.rand)
obsA2=emtrends(mod.list[[2]], pairwise ~ P, var="N", at=list(P=c(mean(mod.list[[2]]@frame$P)-sd(mod.list[[2]]@frame$P),mean(mod.list[[2]]@frame$P)+sd(mod.list[[2]]@frame$P),
                                                                       quantile(mod.list[[2]]@frame$P,0.025),quantile(mod.list[[2]]@frame$P,0.975))))$emtrends%>%
  as.data.frame()%>%
  mutate(iteration=0,
         type=c("mmsd","mpsd","q2.5","q97.5"),
         var="P",
         trend=N.trend,
         value.orig=P,
         value.rand=c(mean(mod.list[[2]]@frame$P)-sd(mod.list[[2]]@frame$P),mean(mod.list[[2]]@frame$P)+sd(mod.list[[2]]@frame$P),
                      quantile(mod.list[[2]]@frame$P,0.025),quantile(mod.list[[2]]@frame$P,0.975)))%>%
  dplyr::select(var,type,trend,SE,iteration,value.orig,value.rand)
obsA=rbind(obsA1,obsA2)

dbdx1<-dbdx%>%group_by(Temp,Rad,N,P)%>%mutate(loc_id = cur_group_id())%>%ungroup() 
dbdx2<-dbdx1%>%group_by(Temp,Rad,N,P)%>%summarise(loc_id =loc_id[1])%>%ungroup()
set.seed(3333)
for(i in 1:1000){
  dbdx2x<-dbdx2
  dbdx2x$loc_id<-sample(dbdx2$loc_id)
  names(dbdx2x)<-c("TempS","RadS","NS","PS","loc_id")
  dbdx3<-left_join(dbdx1,dbdx2x,by="loc_id")%>%
    mutate(Temp=TempS,Rad=RadS,N=NS,P=PS)
  suppressMessages({
  lmemodperm<-lmer(Yl~habitat+autohetero+Temp+Rad+N+P+
                 Temp:N+N:P+
                 Temp:habitat+Rad:habitat+P:habitat+N:habitat+Temp:autohetero+Rad:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
                 (1|species),data=as.data.frame(dbdx3))
  obsAx1=emtrends(lmemodperm, pairwise ~ Temp, var="N", at=list(Temp=c(mean(dbdx$Temp)-sd(dbdx$Temp),mean(dbdx$Temp)+sd(dbdx$Temp),quantile(dbdx$Temp,0.025),quantile(dbdx$Temp,0.975))))$emtrends%>%
    as.data.frame()%>%
    mutate(iteration=i,
           type=c("mmsd","mpsd","q2.5","q97.5"),
           var="Temp",
           trend=N.trend,
           value.orig=Temp,
           value.rand=c(mean(dbdx3$Temp)-sd(dbdx3$Temp),mean(dbdx3$Temp)+sd(dbdx3$Temp),quantile(dbdx3$Temp,0.025),quantile(dbdx3$Temp,0.975)))%>%
    dplyr::select(var,type,trend,SE,iteration,value.orig,value.rand)
  obsAx2=emtrends(lmemodperm, pairwise ~ P, var="N", at=list(P=c(mean(dbdx$P)-sd(dbdx$P),mean(dbdx$P)+sd(dbdx$P),quantile(dbdx$P,0.025),quantile(dbdx$P,0.975))))$emtrends%>%
    as.data.frame()%>%
    mutate(iteration=i,
           type=c("mmsd","mpsd","q2.5","q97.5"),
           var="P",
           trend=N.trend,
           value.orig=P,
           value.rand=c(mean(dbdx3$P)-sd(dbdx3$P),mean(dbdx3$P)+sd(dbdx3$P),quantile(dbdx3$P,0.025),quantile(dbdx3$P,0.975)))%>%
    dplyr::select(var,type,trend,SE,iteration,value.orig,value.rand)
  })
  obsAx=rbind(obsAx1,obsAx2)
  obsA=rbind(obsA,obsAx)
  print(i)
}
# save(obsA,
#      file="~/Proposal/2019_sDiv_sTOCHIOMETREE/Analyses/Plots/species log Navai Pavai/predictor interaction/inter_data.lmer_1k_em_perm_N_1_sp_log_pred.RData")

load("inter_data.lmer_1k_em_perm_N_1_sp_log_pred.RData")

obsA_1<-obsA
ll1<-obsA_1
obsA<-obsA_1%>%
  group_by(type,var,value.orig)%>%
  summarise(pvalue=mean(abs(trend[iteration!=0]/SE[iteration!=0]) >= abs(trend[iteration==0]/SE[iteration==0])))
obsA$padjustBO<-p.adjust(obsA$pvalue)
obsA$padjustBH<-p.adjust(obsA$pvalue,method="BH")

ll1%>%
  filter(iteration %in% 0)%>%
  dplyr::select(type,var,trend,SE)%>%
  left_join(obsA,by=c("type","var"))%>%
  filter(padjustBH < 0.05)%>%#pvalue, padjustBH, padjustBO
  View()

##prepare tables appendices
test=ll1%>%
  filter(iteration %in% 0)%>%
  dplyr::select(type,var,trend,SE)%>%
  left_join(obsA,by=c("type","var"))%>%
  mutate(element="N",
         trend=formatC(trend, format = "e", digits = 1),
         SE=formatC(SE, format = "e", digits = 1),
         value.orig=round(value.orig,1),
         pvalue=round(pvalue,3),
         padjustBH=round(padjustBH,3),
         sig=ifelse(padjustBH <= 0.05,"sig","nonsig"))%>%
  dplyr::select(element,var,type,value.orig,trend,SE,pvalue,padjustBH,sig)%>%
  .[c(3,1,2,4,7,5,6,8),]

##write.table(test,file="interaction_resultsN.doc",row.names=F,quote=F,sep=";")

#############################################

####Get P Olsen values
#############################################
#Obtain P Olsen data here and extract from spatial coordinates
##https://figshare.com/articles/dataset/Global_Available_Soil_Phosphorus_Database/14241854?file=43758732


P_olsen=c(
  c(4.69302892684937, 4.69302892684937, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 4.25048685073853, 
    NA, 4.25048685073853, NA, NA, 4.25048685073853, 4.25048685073853, 
    4.25048685073853, NA, 4.25048685073853, NA, 4.25048685073853, 
    NA, 4.25048685073853, 4.25048685073853, NA, 4.25048685073853, 
    4.25048685073853, 4.25048685073853, 4.25048685073853, NA, 4.25048685073853, 
    NA, 4.25048685073853, NA, 4.25048685073853, 4.25048685073853, 
    4.25048685073853, NA, NA, 4.25048685073853, 4.25048685073853, 
    4.25048685073853, NA, 4.25048685073853, NA, 4.25048685073853, 
    NA, 4.25048685073853, 4.25048685073853, NA, 4.25048685073853, 
    NA, NA, NA, NA, NA, 4.25048685073853, NA, NA, 4.25048685073853, 
    4.25048685073853, NA, NA, NA, 4.25048685073853, NA, NA, NA, 4.25048685073853, 
    NA, NA, NA, 4.25048685073853, NA, 4.25048685073853, 4.25048685073853, 
    4.25048685073853, NA, NA, NA, NA, 4.25048685073853, NA, NA, NA, 
    NA, NA, NA, NA, 4.25048685073853, NA, NA, NA, NA, 4.25048685073853, 
    NA, NA, 4.25048685073853, NA, NA, 4.25048685073853, NA, 4.25048685073853, 
    NA, NA, 4.25048685073853, NA, NA, 4.25048685073853, NA, NA, 4.25048685073853, 
    NA, 4.25048685073853, NA, 4.25048685073853, NA, NA, NA, 4.25048685073853, 
    4.25048685073853, 4.25048685073853, NA, NA, NA, 4.25048685073853, 
    NA, NA, 4.25048685073853, 4.25048685073853, NA, 4.25048685073853, 
    NA, NA, 4.25048685073853, 4.25048685073853, 4.25048685073853, 
    NA, NA, NA, 4.25048685073853, NA, 4.25048685073853, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 4.25048685073853, 4.25048685073853, 
    4.25048685073853, 4.25048685073853, 4.25048685073853, NA, NA, 
    NA, 4.25048685073853, 4.25048685073853, NA, NA, 4.25048685073853, 
    4.25048685073853, NA, NA, 4.25048685073853, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, 4.25048685073853, NA, NA, NA, NA, NA, NA, 
    NA, NA, 4.25048685073853, NA, 4.25048685073853, NA, NA, NA, NA, 
    4.25048685073853, NA, NA, NA, NA, NA, 4.25048685073853, NA, NA, 
    4.25048685073853, 4.25048685073853, NA, NA, 4.25048685073853, 
    NA, 4.25048685073853, NA, 4.25048685073853, 4.25048685073853, 
    NA, NA, NA, NA, NA, NA, NA, NA, 4.25048685073853, NA, 4.25048685073853, 
    NA, 4.25048685073853, NA, 4.25048685073853, NA, NA, NA, 4.25048685073853, 
    4.25048685073853, NA, 4.25048685073853, 4.25048685073853, NA, 
    NA, NA, NA, NA, NA, NA, 4.25048685073853, NA, NA, 4.25048685073853, 
    NA, 4.25048685073853, NA, NA, 4.25048685073853, NA, 4.25048685073853, 
    4.25048685073853, NA, 4.25048685073853, NA, NA, 4.25048685073853, 
    NA, 4.25048685073853, NA, NA, 4.25048685073853, NA, 4.25048685073853, 
    4.25048685073853, 4.25048685073853, 4.25048685073853, 4.25048685073853, 
    4.25048685073853, 4.25048685073853, 4.25048685073853, NA, 4.25048685073853, 
    NA, NA, 4.25048685073853, NA, 4.25048685073853, NA, NA, NA, 4.25048685073853, 
    4.25048685073853, NA, 4.25048685073853, NA, NA, NA, NA, 4.25048685073853, 
    NA, 4.25048685073853, 4.25048685073853, NA, 4.25048685073853, 
    4.25048685073853, 4.25048685073853, NA, 4.25048685073853, NA, 
    4.25048685073853, 4.25048685073853, 4.25048685073853, 4.25048685073853, 
    4.25048685073853, 4.25048685073853, 4.25048685073853, 4.25048685073853, 
    4.25048685073853, NA, 4.25048685073853, 4.25048685073853, 4.25048685073853, 
    4.25048685073853, 4.25048685073853, 4.25048685073853, 4.25048685073853, 
    4.25048685073853, 4.25048685073853, 4.25048685073853, 4.25048685073853, 
    4.25048685073853, 4.25048685073853, 4.25048685073853, 4.25048685073853, 
    4.25048685073853, 4.25048685073853, 4.25048685073853, 4.25048685073853, 
    4.25048685073853, 4.25048685073853, 4.25048685073853, 4.25048685073853, 
    4.25048685073853, 4.25048685073853, 4.25048685073853, 4.25048685073853, 
    4.25048685073853, 4.25048685073853, 4.25048685073853, 4.25048685073853, 
    4.25048685073853, 4.25048685073853, 4.25048685073853, 4.25048685073853, 
    4.25048685073853, 3.37500357627869, 4.25048685073853, 4.25048685073853, 
    4.25048685073853, 4.25048685073853, 4.25048685073853, 4.25048685073853, 
    4.25048685073853, 4.25048685073853, 4.25048685073853, NA, NA, 
    4.25048685073853, 4.25048685073853, 4.25048685073853, 4.25048685073853, 
    4.25048685073853, NA, 3.37500357627869, 4.25048685073853, 4.25048685073853, 
    NA, 3.37500357627869, 4.25048685073853, 3.37500357627869, 4.25048685073853, 
    4.25048685073853, 3.37500357627869, 3.37500357627869, 4.25048685073853, 
    NA, NA, NA, 4.25048685073853, NA, 4.25048685073853, 4.25048685073853, 
    3.37500357627869, NA, 4.25048685073853, 3.37500357627869, 3.37500357627869, 
    3.37500357627869, 3.37500357627869, 4.25048685073853, 4.25048685073853, 
    3.37500357627869, 4.25048685073853, 4.25048685073853, 4.25048685073853, 
    3.37500357627869, 4.25048685073853, 4.25048685073853, 4.25048685073853, 
    3.37500357627869, 4.25048685073853, NA, NA, 4.25048685073853, 
    3.37500357627869, NA, NA, 3.37500357627869, NA, 4.25048685073853, 
    4.25048685073853, 4.25048685073853, 4.25048685073853, NA, NA, 
    4.25048685073853, NA, NA, 3.37500357627869, 4.25048685073853, 
    4.25048685073853, 4.25048685073853, 3.37500357627869, NA, NA, 
    NA, NA, NA, NA, 4.25048685073853, NA, 3.81395483016968, NA, 3.37500357627869, 
    NA, 3.37500357627869, NA, 3.37500357627869, 3.37500357627869, 
    NA, 3.37500357627869, 4.25048685073853, 4.25048685073853, 4.25048685073853, 
    4.25048685073853, NA, NA, NA, NA, 3.37500357627869, 4.25048685073853, 
    NA, NA, NA, 4.25048685073853, NA, 4.25048685073853, NA, 4.25048685073853, 
    4.25048685073853, 4.25048685073853, NA, NA, 4.25048685073853, 
    NA, 3.37500357627869, 3.37500357627869, 4.25048685073853, 3.81395483016968, 
    4.25048685073853, 3.81395483016968, NA, NA, NA, NA, NA, NA, NA, 
    NA, 3.37500357627869, NA, NA, 4.25048685073853, 4.25048685073853, 
    4.25048685073853, NA, 4.25048685073853, 4.25048685073853, 3.37500357627869, 
    NA, 3.81395483016968, 3.37500357627869, 4.25048685073853, 3.37500357627869, 
    NA, 4.25048685073853, NA, NA, 3.37500357627869, NA, 3.37500357627869, 
    NA, NA, NA, NA, 3.37500357627869, 3.37500357627869, 4.25048685073853, 
    NA, NA, 3.37500357627869, 3.81395483016968, 4.25048685073853, 
    NA, 3.37500357627869, 4.25048685073853, 3.81395483016968, 4.25048685073853, 
    3.37500357627869, 4.25048685073853, 3.37500357627869, NA, 4.25048685073853, 
    3.37500357627869, NA, NA, NA, 3.37500357627869, 3.37500357627869, 
    NA, 3.37500357627869, NA, NA, 3.37500357627869, 3.37500357627869, 
    4.25048685073853, 4.25048685073853, NA, NA, NA, 4.25048685073853, 
    3.81395483016968, 4.25048685073853, 4.25048685073853, 3.81395483016968, 
    4.25048685073853, NA, NA, 4.25048685073853, 3.37500357627869, 
    NA, 4.25048685073853, 3.81395483016968, NA, NA, 3.37500357627869, 
    4.25048685073853, 4.25048685073853, 4.25048685073853, NA, 4.25048685073853, 
    NA, NA, 3.81395483016968, 3.37500357627869, 4.25048685073853, 
    4.25048685073853, NA, NA, 3.37500357627869, 4.25048685073853, 
    4.25048685073853, NA, NA, NA, 3.37500357627869, 4.25048685073853, 
    4.25048685073853, 3.81395483016968, 3.81395483016968, 3.81395483016968, 
    3.37500357627869, 3.37500357627869, NA, 4.25048685073853, 4.25048685073853, 
    NA, 3.81395483016968, 4.25048685073853, 4.25048685073853, NA, 
    NA, 4.25048685073853, NA, NA, 3.81395483016968, NA, 3.81395483016968, 
    3.81395483016968, 4.25048685073853, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, 3.81395483016968, NA, NA, NA, NA, 3.81395483016968, 
    NA, 3.81395483016968, 3.81395483016968, NA, 4.25048685073853, 
    NA, NA, 3.37500357627869, NA, 3.37500357627869, 3.81395483016968, 
    3.37500357627869, 3.37500357627869, 3.81395483016968, 3.37500357627869, 
    NA, NA, 3.37500357627869, NA, NA, NA, NA, 3.81395483016968, 3.81395483016968, 
    NA, NA, NA, NA, NA, 4.25048685073853, 4.25048685073853, NA, NA, 
    NA, NA, NA, NA, 4.25048685073853, NA, 4.25048685073853, 3.81395483016968, 
    4.25048685073853, NA, 4.25048685073853, 3.37500357627869, 4.25048685073853, 
    NA, 4.25048685073853, NA, NA, NA, NA, 3.81395483016968, NA, NA, 
    NA, NA, NA, NA, NA, NA, 3.37500357627869, 3.81395483016968, 3.37500357627869, 
    NA, NA, 3.81395483016968, NA, NA, 3.81395483016968, 3.37500357627869, 
    NA, NA, 3.81395483016968, NA, NA, 3.81395483016968, NA, 3.81395483016968, 
    NA, NA, NA, 3.37500357627869, 4.25048685073853, 3.81395483016968, 
    NA, 4.25048685073853, NA, 3.37500357627869, 4.25048685073853, 
    4.25048685073853, NA, 4.25048685073853, NA, 4.25048685073853, 
    4.25048685073853, NA, NA, NA, 3.37500357627869, NA, NA, NA, NA, 
    4.25048685073853, 4.25048685073853, NA, NA, NA, NA, NA, 3.37500357627869, 
    NA, 4.25048685073853, 3.81395483016968, 3.81395483016968, NA, 
    NA, NA, 4.25048685073853, NA, NA, 4.25048685073853, NA, 3.37500357627869, 
    NA, 3.37500357627869, 4.25048685073853, NA, NA, NA, NA, 3.37500357627869, 
    3.37500357627869, NA, NA, 3.37500357627869, NA, NA, NA, NA, NA, 
    3.81395483016968, NA, NA, NA, 3.37500357627869, 4.25048685073853, 
    NA, 3.81395483016968, 3.37500357627869, NA, NA, NA, NA, 3.81395483016968, 
    4.25048685073853, 3.81395483016968, NA, NA, NA, NA, 3.81395483016968, 
    NA, 3.37500357627869, 3.81395483016968, NA, NA, 4.25048685073853, 
    3.81395483016968, 3.81395483016968, NA, 4.25048685073853, NA, 
    NA, NA, 3.81395483016968, NA, 4.25048685073853, NA, NA, NA, NA, 
    NA, 3.37500357627869, 3.81395483016968, 3.81395483016968, NA, 
    3.81395483016968, 4.25048685073853, 3.81395483016968, 3.37500357627869, 
    3.81395483016968, NA, NA, NA, NA, NA, NA, NA, NA, 3.81395483016968, 
    NA, NA, NA, NA, 4.25048685073853, NA, 4.25048685073853, NA, NA, 
    NA, NA, 3.81395483016968, NA, 3.37500357627869, NA, NA, NA, NA, 
    NA, NA, 3.37500357627869, NA, NA, NA, 4.25048685073853, 3.37500357627869, 
    3.37500357627869, NA, NA, NA, NA, 3.37500357627869, NA, NA, NA, 
    4.25048685073853, 4.25048685073853, NA, NA, NA, 4.25048685073853, 
    4.25048685073853, 3.81395483016968, 3.81395483016968, 3.81395483016968, 
    NA, 3.37500357627869, 4.25048685073853, NA, NA, NA, NA, NA, NA, 
    3.37500357627869, NA, 4.25048685073853, NA, NA, NA, NA, NA, 3.37500357627869, 
    NA, NA, NA, NA, 3.37500357627869, NA, 4.25048685073853, 4.25048685073853, 
    4.25048685073853, NA, 3.81395483016968, 3.81395483016968, NA, 
    NA, NA, 3.81395483016968, 3.81395483016968, NA, 4.25048685073853, 
    NA, NA, NA, NA, NA, NA, 4.25048685073853, NA, NA, NA, 4.25048685073853, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 3.81395483016968, 
    3.37500357627869, NA, 3.81395483016968, NA, NA, NA, NA, NA, NA, 
    3.37500357627869, NA, NA, 4.25048685073853, NA, NA, NA, NA, NA, 
    NA, 3.81395483016968, NA, NA, NA, NA, 4.25048685073853, 4.25048685073853, 
    3.81395483016968, 4.25048685073853, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, 3.37500357627869, NA, NA, NA, NA, NA, NA, NA, NA, 4.25048685073853, 
    NA, 3.81395483016968, 4.25048685073853, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, 4.25048685073853, NA, NA, NA, 3.81395483016968, 
    3.81395483016968, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 3.81395483016968, 
    NA, NA, 3.81395483016968, NA, NA, 3.81395483016968, NA, 3.81395483016968, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 3.81395483016968, 
    4.25048685073853, NA, NA, NA, NA, NA, 4.25048685073853, NA, NA, 
    NA, 3.37500357627869, 3.37500357627869, NA, 4.25048685073853, 
    3.81395483016968, 3.81395483016968, NA, NA, NA, 3.37500357627869, 
    NA, NA, NA, NA, 4.25048685073853, NA, NA, 3.81395483016968, NA, 
    NA, NA, NA, 4.25048685073853, NA, NA, NA, NA, NA, 4.25048685073853, 
    3.81395483016968, NA, NA, NA, NA, NA, NA, NA, NA, 4.25048685073853, 
    4.25048685073853, 3.81395483016968, NA, 4.25048685073853, 4.25048685073853, 
    NA, NA, 4.25048685073853, 3.37500357627869, 4.25048685073853, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 3.37500357627869, NA, 
    NA, NA, NA, 3.37500357627869, 3.81395483016968, 3.37500357627869, 
    4.25048685073853, 4.25048685073853, 4.25048685073853, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 4.25048685073853, 
    4.25048685073853, NA, 3.81395483016968, NA, NA, NA, NA, 4.25048685073853, 
    3.81395483016968, 4.25048685073853, NA, NA, 4.25048685073853, 
    3.37500357627869, NA, NA, NA, NA, NA, NA, NA, NA, NA, 4.25048685073853, 
    4.25048685073853, 3.37500357627869, NA, 3.37500357627869, NA, 
    NA, NA, 4.25048685073853, 4.25048685073853, NA, 4.25048685073853, 
    NA, 4.25048685073853, 4.25048685073853, 4.25048685073853, NA, 
    4.25048685073853, NA, 4.25048685073853, NA, 4.25048685073853, 
    4.25048685073853, 3.81395483016968, 4.25048685073853, 3.37500357627869, 
    4.25048685073853, 3.37500357627869, 4.25048685073853, NA, 4.25048685073853, 
    4.25048685073853, NA, NA, 4.25048685073853, NA, NA, NA, 3.37500357627869, 
    3.37500357627869, 3.81395483016968, 3.37500357627869, 3.37500357627869, 
    3.37500357627869, 3.81395483016968, 3.37500357627869, 3.81395483016968, 
    3.81395483016968, 3.81395483016968, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 9.40217685699463, 
    11.8962240219116, 9.40217685699463, 9.40217685699463, 9.40217685699463, 
    9.40217685699463, 9.40217685699463, 9.40217685699463, 11.8962240219116, 
    9.40217685699463, 9.40217685699463, 9.40217685699463, 11.8962240219116, 
    11.8962240219116, 11.8962240219116, 11.8962240219116, 11.8962240219116, 
    11.8962240219116, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, 8.31370162963867, 11.22092628479, 11.8962240219116, 
    11.8962240219116, 9.40217685699463, 9.40217685699463, 9.48974990844727, 
    11.22092628479, 9.26438045501709, 9.48974990844727, 9.26438045501709, 
    8.31370162963867, 13.8227529525757, NA, 2, NA, 13.8227529525757, 
    NA, NA, 3.22958493232727, 3.22958493232727, 4.3160400390625, 
    4.3160400390625, 4.3160400390625, 4.3160400390625, 4.3160400390625, 
    4.3160400390625, 4.3160400390625, 4.3160400390625, 4.3160400390625, 
    4.3160400390625, 4.3160400390625, 4.3160400390625, 4.3160400390625, 
    3.22958493232727, 4.3160400390625, 4.3160400390625, 3.22958493232727, 
    4.3160400390625, 4.3160400390625, 3.22958493232727, 4.3160400390625, 
    4.3160400390625, 4.3160400390625, 4.3160400390625, 3.22958493232727, 
    4.3160400390625, 3.22958493232727, 3.22958493232727, 4.3160400390625, 
    4.3160400390625, 4.3160400390625, 4.3160400390625, 4.3160400390625, 
    3.22958493232727, 4.3160400390625, 3.22958493232727, 4.3160400390625, 
    4.3160400390625, 4.3160400390625, 4.3160400390625, 4.3160400390625, 
    3.22958493232727, 4.3160400390625, 4.3160400390625, 3.22958493232727, 
    3.22958493232727, 4.3160400390625, 4.3160400390625, 4.3160400390625, 
    4.3160400390625, 3.22958493232727, 4.3160400390625, 4.3160400390625, 
    3.22958493232727, 4.3160400390625, 4.3160400390625, 4.3160400390625, 
    4.3160400390625, 4.3160400390625, 3.22958493232727, 4.3160400390625, 
    4.3160400390625, 4.3160400390625, 3.22958493232727, 3.22958493232727, 
    3.22958493232727, 4.3160400390625, 4.3160400390625, 3.22958493232727, 
    3.22958493232727, 4.3160400390625, 4.3160400390625, 4.3160400390625, 
    3.22958493232727, 4.3160400390625, 3.22958493232727, 4.3160400390625, 
    4.3160400390625, 3.22958493232727, 4.3160400390625, 3.22958493232727, 
    4.3160400390625, 4.3160400390625, 4.3160400390625, 4.3160400390625, 
    4.3160400390625, 4.3160400390625, 4.3160400390625, 4.3160400390625, 
    3.22958493232727, 4.3160400390625, 3.22958493232727, 3.22958493232727, 
    4.3160400390625, 4.3160400390625, 3.22958493232727, 4.3160400390625, 
    3.22958493232727, 4.3160400390625, 3.22958493232727, 4.3160400390625, 
    4.3160400390625, 3.22958493232727, 3.22958493232727, 3.22958493232727, 
    4.3160400390625, 4.3160400390625, 3.22958493232727, 4.3160400390625, 
    4.3160400390625, 4.3160400390625, 3.22958493232727, 4.3160400390625, 
    4.3160400390625, 4.3160400390625, 4.3160400390625, 3.22958493232727, 
    4.3160400390625, 4.3160400390625, 4.3160400390625, 4.3160400390625, 
    3.22958493232727, 4.3160400390625, 3.22958493232727, 3.22958493232727, 
    4.3160400390625, 4.3160400390625, 4.3160400390625, 3.22958493232727, 
    4.3160400390625, 3.22958493232727, 4.3160400390625, 3.22958493232727, 
    3.22958493232727, 4.3160400390625, 4.3160400390625, 4.3160400390625, 
    4.3160400390625, 3.22958493232727, 3.22958493232727, 4.3160400390625, 
    4.3160400390625, 3.22958493232727, 3.22958493232727, 3.22958493232727, 
    3.22958493232727, 4.3160400390625, 4.3160400390625, 4.3160400390625, 
    3.22958493232727, 4.3160400390625, 4.3160400390625, 3.22958493232727, 
    3.22958493232727, 4.3160400390625, 4.3160400390625, 4.3160400390625, 
    4.3160400390625, 4.3160400390625, 4.3160400390625, 3.22958493232727, 
    4.3160400390625, 4.3160400390625, 3.22958493232727, 3.22958493232727, 
    4.3160400390625, 3.22958493232727, 4.3160400390625, 3.22958493232727, 
    4.3160400390625, 3.22958493232727, 3.22958493232727, 3.22958493232727, 
    4.3160400390625, 3.22958493232727, 3.22958493232727, 4.3160400390625, 
    3.22958493232727, 3.22958493232727, 3.22958493232727, 3.22958493232727, 
    4.3160400390625, 3.22958493232727, 4.3160400390625, 3.22958493232727, 
    4.3160400390625, 3.22958493232727, 3.22958493232727, 3.22958493232727, 
    3.22958493232727, 3.22958493232727, 3.22958493232727, 4.3160400390625, 
    4.3160400390625, 4.3160400390625, 4.3160400390625, 4.3160400390625, 
    4.3160400390625, 4.3160400390625, 3.22958493232727, 4.3160400390625, 
    4.3160400390625, 4.3160400390625, 3.22958493232727, 3.22958493232727, 
    3.22958493232727, 3.22958493232727, 3.22958493232727, 4.3160400390625, 
    3.22958493232727, 4.3160400390625, 3.22958493232727, 4.3160400390625, 
    3.22958493232727, 3.22958493232727, 4.3160400390625, 3.22958493232727, 
    4.3160400390625, 4.3160400390625, 4.3160400390625, 3.22958493232727, 
    3.22958493232727, 3.22958493232727, 4.3160400390625, 3.22958493232727, 
    3.22958493232727, 3.22958493232727, 3.22958493232727, 4.3160400390625, 
    3.22958493232727, 3.22958493232727, 3.22958493232727, 4.3160400390625, 
    3.22958493232727, 4.3160400390625, 3.22958493232727, 4.3160400390625, 
    3.22958493232727, 3.22958493232727, 3.22958493232727, 3.22958493232727, 
    3.22958493232727, 4.3160400390625, 3.22958493232727, 3.22958493232727, 
    4.3160400390625, 3.22958493232727, 3.22958493232727, 3.22958493232727, 
    4.3160400390625, 3.22958493232727, 3.22958493232727, 4.3160400390625, 
    4.3160400390625, 3.22958493232727, 3.22958493232727, 3.22958493232727, 
    4.3160400390625, 3.22958493232727, 3.22958493232727, 4.3160400390625, 
    4.3160400390625, 3.22958493232727, 4.3160400390625, 3.22958493232727, 
    4.3160400390625, 4.3160400390625, 3.22958493232727, 4.3160400390625, 
    3.22958493232727, 3.22958493232727, 3.22958493232727, 3.22958493232727, 
    4.3160400390625, 4.3160400390625, 3.22958493232727, 3.22958493232727, 
    4.3160400390625, 3.22958493232727, 4.3160400390625, 3.22958493232727, 
    4.3160400390625, 3.22958493232727, 3.22958493232727, 4.3160400390625, 
    3.22958493232727, 3.22958493232727, 3.22958493232727, 3.22958493232727, 
    3.22958493232727, 4.3160400390625, 3.22958493232727, 3.22958493232727, 
    3.22958493232727, 3.22958493232727, 3.22958493232727, 3.22958493232727, 
    4.3160400390625, 4.3160400390625, 3.22958493232727, 3.22958493232727, 
    3.22958493232727, 3.22958493232727, 3.22958493232727, 4.3160400390625, 
    4.3160400390625, 3.22958493232727, 3.22958493232727, 4.3160400390625, 
    3.22958493232727, 4.3160400390625, 3.22958493232727, 4.3160400390625, 
    3.22958493232727, 3.22958493232727, 4.3160400390625, 3.22958493232727, 
    3.22958493232727, 3.22958493232727, 4.3160400390625, 4.3160400390625, 
    4.3160400390625, 4.3160400390625, 4.3160400390625, 4.3160400390625, 
    3.22958493232727, 4.3160400390625, 3.22958493232727, 3.22958493232727, 
    4.3160400390625, 3.22958493232727, 3.22958493232727, 4.3160400390625, 
    3.22958493232727, 3.22958493232727, 3.22958493232727, 3.22958493232727, 
    3.22958493232727, 4.3160400390625, 4.3160400390625, 4.3160400390625, 
    4.3160400390625, 3.22958493232727, 3.22958493232727, 3.22958493232727, 
    4.3160400390625, 4.3160400390625, 3.22958493232727, 3.22958493232727, 
    4.3160400390625, 4.3160400390625, 4.3160400390625, 4.3160400390625, 
    4.3160400390625, 4.3160400390625, 4.3160400390625, 3.22958493232727, 
    3.22958493232727, 4.3160400390625, 4.3160400390625, 4.3160400390625, 
    3.22958493232727, 3.22958493232727, 4.3160400390625, 3.22958493232727, 
    4.3160400390625, 3.22958493232727, 3.22958493232727, 4.3160400390625, 
    3.22958493232727, 4.3160400390625, 3.22958493232727, 4.3160400390625, 
    4.3160400390625, 3.22958493232727, 4.3160400390625, 3.22958493232727, 
    3.22958493232727, 4.3160400390625, 4.3160400390625, 4.3160400390625, 
    4.3160400390625, 4.3160400390625, 3.22958493232727, 4.3160400390625, 
    4.3160400390625, 4.3160400390625, 3.22958493232727, 4.3160400390625, 
    3.22958493232727, 4.3160400390625, 4.3160400390625, 4.3160400390625, 
    4.3160400390625, 4.3160400390625, 4.3160400390625, 4.3160400390625, 
    4.3160400390625, 4.3160400390625, 4.3160400390625, 4.3160400390625, 
    4.3160400390625, 4.3160400390625, 4.3160400390625, 4.3160400390625, 
    4.3160400390625, 4.3160400390625, 4.3160400390625, 4.3160400390625, 
    4.3160400390625, 4.3160400390625, 4.3160400390625, 4.3160400390625, 
    4.3160400390625, 4.3160400390625, 4.3160400390625, 4.3160400390625, 
    4.3160400390625, 4.3160400390625, 4.3160400390625, 4.3160400390625, 
    2, 2, 2, 2, NA, 2, 3, 3, 3, NA, 2, NA, 3, NA, NA, 2, 3, 2, 2, 
    3, NA, NA, 3, NA, 3, 2, 3, NA, 3, NA, NA, 3, 2, 2, 2, 3, 2, 3, 
    NA, NA, 3, NA, 3, NA, 3, 3, 2, NA, 2, 3.89233326911926, 3.89233326911926, 
    3.04966378211975, 3.42988348007202, 4.13483238220215, 4.44465827941895, 
    3.80116105079651, 3.89233326911926, 4.1669807434082, 4.50690889358521, 
    3.73320078849792, 4.44465827941895, 3.68909692764282, 3.89233326911926, 
    3.55374670028687, 4.11319398880005, 3.42988348007202, 4.50690889358521, 
    3.9676730632782, 4.44465827941895, 4.11319398880005, 3.9676730632782, 
    3.42988348007202, 4.11319398880005, 3.49693608283997, 3.8900043964386, 
    4.2267279624939, 4.30660581588745, 3.04966378211975, 3.9676730632782, 
    4.11319398880005, 3.42988348007202, 3.9676730632782, 2.81198644638062, 
    3.37559580802917, 4.44465827941895, 4.50690889358521, 4.02559185028076, 
    3.20671105384827, 3.55374670028687, 4.13483238220215, 4.1669807434082, 
    3.9676730632782, 4.44465827941895, 4.11319398880005, 3.73320078849792, 
    3.8900043964386, 3.99542927742004, 3.55459308624268, 4.13483238220215, 
    3.89233326911926, 2.81198644638062, 2.81198644638062, 3.04966378211975, 
    3.89233326911926, 4.30660581588745, 3.55374670028687, 3.89233326911926, 
    3.63561010360718, 3.20671105384827, 4.50690889358521, 3.69694781303406, 
    2.77944040298462, 4.50690889358521, 3.04966378211975, 2.81198644638062, 
    4.30660581588745, 3.04966378211975, 4.02559185028076, 4.2267279624939, 
    3.04966378211975, 3.89233326911926, 3.04966378211975, 4.2267279624939, 
    4.50690889358521, 3.89233326911926, 4.02559185028076, 4.11319398880005, 
    2.77944040298462, 4.50690889358521, 3.80116105079651, 3.45173335075378, 
    3.80116105079651, 3.04966378211975, 2.81198644638062, 3.55459308624268, 
    3.80116105079651, 3.20671105384827, 3.45173335075378, 2.77944040298462, 
    3.63561010360718, 4.13483238220215, 3.04966378211975, 4.50690889358521, 
    3.49693608283997, 3.42988348007202, 2.77944040298462, 3.69694781303406, 
    3.9676730632782, 3.73320078849792, 3.9676730632782, 4.50690889358521, 
    3.69694781303406, 4.2267279624939, 3.04966378211975, 3.42988348007202, 
    3.80116105079651, 3.69694781303406, 3.9676730632782, 4.30660581588745, 
    3.20671105384827, 3.49693608283997, 3.8900043964386, 3.49693608283997, 
    3.73320078849792, 3.63561010360718, 3.80116105079651, 4.2267279624939, 
    3.8900043964386, 3.89233326911926, 3.68909692764282, 3.80116105079651, 
    4.2267279624939, 3.49693608283997, 4.02559185028076, 3.04966378211975, 
    4.1669807434082, 3.68909692764282, 3.89233326911926, 3.73320078849792, 
    4.13483238220215, 4.02559185028076, 3.9676730632782, 3.89233326911926, 
    3.55374670028687, 4.11319398880005, 4.50690889358521, 3.73320078849792, 
    3.89233326911926, 3.89233326911926, 3.89233326911926, 3.55374670028687, 
    3.99542927742004, 3.45173335075378, 4.30660581588745, 3.89233326911926, 
    4.30660581588745, 3.63561010360718, 3.55459308624268, 4.11319398880005, 
    4.13483238220215, 4.13483238220215, 3.8900043964386, 3.04966378211975, 
    3.80116105079651, 3.04966378211975, 4.13483238220215, 3.63561010360718, 
    4.50690889358521, 4.13483238220215, 3.42988348007202, 3.69694781303406, 
    4.44465827941895, 3.42988348007202, 4.11319398880005, 3.80116105079651, 
    4.02559185028076, 3.9676730632782, 3.99542927742004, 3.9676730632782, 
    4.44465827941895, 3.99542927742004, 3.73320078849792, 3.99542927742004, 
    3.04966378211975, 3.8900043964386, 3.73320078849792, 3.42988348007202, 
    4.30660581588745, 3.37559580802917, 2.77944040298462, 4.44465827941895, 
    3.99542927742004, 4.44465827941895, 3.89233326911926, 4.44465827941895, 
    4.13483238220215, 3.68909692764282, 4.02559185028076, 2.81198644638062, 
    3.20671105384827, 4.11319398880005, 4.44465827941895, 4.44465827941895, 
    4.11319398880005, 3.55374670028687, 4.11319398880005, 3.37559580802917, 
    3.04966378211975, 3.73320078849792, 3.8900043964386, 4.50690889358521, 
    4.1669807434082, 3.42988348007202, 3.55374670028687, 4.13483238220215, 
    3.42988348007202, 3.99542927742004, 3.55374670028687, 3.9676730632782, 
    3.04966378211975, 4.11319398880005, 4.2267279624939, 3.04966378211975, 
    3.55374670028687, 3.49693608283997, 3.69694781303406, 3.04966378211975, 
    4.2267279624939, 4.13483238220215, 3.9676730632782, 3.89233326911926, 
    3.80116105079651, 3.55459308624268, 3.63561010360718, 3.99542927742004, 
    4.13483238220215, 3.49693608283997, 4.13483238220215, 4.02559185028076, 
    3.45173335075378, 3.42988348007202, 4.11319398880005, 3.99542927742004, 
    3.99542927742004, 3.04966378211975, 3.89233326911926, 3.04966378211975, 
    4.44465827941895, 3.04966378211975, 3.04966378211975, 3.04966378211975, 
    3.63561010360718, 4.1669807434082, 4.13483238220215, 3.42988348007202, 
    3.37559580802917, 3.9676730632782, 3.37559580802917, 3.04966378211975, 
    3.45173335075378, 4.30660581588745, 3.8900043964386, 3.8900043964386, 
    4.13483238220215, 3.04966378211975, 4.13483238220215, 3.42988348007202, 
    4.50690889358521, 3.63561010360718, 3.04966378211975, 4.50690889358521, 
    3.20671105384827, 4.11319398880005, 3.04966378211975, 3.89233326911926, 
    4.11319398880005, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, 5.08384323120117, 5.08384323120117, 
    7.78828001022339, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, 7.9153208732605, NA, NA, NA, NA, 7.78828001022339, 
    NA, NA, NA, NA, 7.9153208732605, NA, 10.9868993759155, 7.9153208732605, 
    7.9153208732605, NA, 7.78828001022339, NA, 7.9153208732605, 5.08384323120117, 
    10.9868993759155, 7.78828001022339, 5.08384323120117, 7.78828001022339, 
    5.08384323120117, 10.9868993759155, 7.9153208732605, 7.9153208732605, 
    10.9868993759155, 7.78828001022339, 10.9868993759155, 7.78828001022339, 
    7.78828001022339, 5.08384323120117, 10.9868993759155, NA, 5.08384323120117, 
    5.08384323120117, 7.78828001022339, 10.9868993759155, 7.9153208732605, 
    10.9868993759155, 10.9868993759155, 10.9868993759155, 7.78828001022339, 
    7.78828001022339, 7.78828001022339, 10.9868993759155, 10.9868993759155, 
    10.9868993759155, 7.9153208732605, 7.78828001022339, 7.9153208732605, 
    10.9868993759155, 10.9868993759155, 7.78828001022339, 7.9153208732605, 
    7.9153208732605, 7.78828001022339, 10.9868993759155, 7.78828001022339, 
    7.9153208732605, 10.9868993759155, 7.78828001022339, 7.78828001022339, 
    5.08384323120117, 10.9868993759155, 7.78828001022339, 7.78828001022339, 
    5.08384323120117, 5.08384323120117, 7.78828001022339, 5.08384323120117, 
    7.78828001022339, 10.9868993759155, 5.08384323120117, 5.08384323120117, 
    7.9153208732605, 5.08384323120117, 7.78828001022339, 7.78828001022339, 
    7.78828001022339, 5.08384323120117, 7.78828001022339, 7.78828001022339, 
    10.9868993759155, 5.08384323120117, 5.08384323120117, 10.9868993759155, 
    5.08384323120117, 5.08384323120117, 7.9153208732605, 7.9153208732605, 
    10.9868993759155, 5.08384323120117, 7.78828001022339, 10.9868993759155, 
    10.9868993759155, 7.9153208732605, 7.9153208732605, 7.78828001022339, 
    7.9153208732605, 10.9868993759155, 10.9868993759155, 7.9153208732605, 
    7.9153208732605, 7.78828001022339, 7.78828001022339, 5.08384323120117, 
    10.9868993759155, 10.9868993759155, 5.08384323120117, 5.08384323120117, 
    5.08384323120117, 5.08384323120117, 7.9153208732605, 7.78828001022339, 
    5.08384323120117, 10.9868993759155, 10.9868993759155, 5.08384323120117, 
    7.9153208732605, 7.78828001022339, 5.08384323120117, 7.78828001022339, 
    10.9868993759155, 5.08384323120117, 7.78828001022339, 7.9153208732605, 
    10.9868993759155, 10.9868993759155, 7.78828001022339, 10.9868993759155, 
    7.78828001022339, 7.9153208732605, 5.08384323120117, 7.78828001022339, 
    10.9868993759155, 7.78828001022339, 10.9868993759155, 7.78828001022339, 
    5.08384323120117, 7.9153208732605, 7.78828001022339, 5.08384323120117, 
    7.78828001022339, 7.78828001022339, 10.9868993759155, 7.9153208732605, 
    10.9868993759155, 5.08384323120117, 5.08384323120117, 7.9153208732605, 
    5.08384323120117, 7.78828001022339, 7.9153208732605, 5.08384323120117, 
    7.78828001022339, 7.9153208732605, 7.9153208732605, 7.78828001022339, 
    7.9153208732605, 10.9868993759155, 10.9868993759155, 7.9153208732605, 
    7.9153208732605, 5.08384323120117, 5.08384323120117, 7.9153208732605, 
    7.78828001022339, 7.78828001022339, 7.78828001022339, 7.9153208732605, 
    7.9153208732605, 10.9868993759155, 10.9868993759155, 7.9153208732605, 
    5.08384323120117, 7.9153208732605, 5.08384323120117, 7.78828001022339, 
    7.78828001022339, 5.08384323120117, 10.9868993759155, 5.08384323120117, 
    5.08384323120117, 10.9868993759155, 10.9868993759155, 10.9868993759155, 
    10.9868993759155, 7.78828001022339, 10.9868993759155, 5.08384323120117, 
    7.9153208732605, 10.9868993759155, 10.9868993759155, 10.9868993759155, 
    5.08384323120117, 7.78828001022339, 7.78828001022339, 5.08384323120117, 
    5.08384323120117, 10.9868993759155, 10.9868993759155, 7.78828001022339, 
    10.9868993759155, 7.78828001022339, 10.9868993759155, 7.9153208732605, 
    10.9868993759155, 5.08384323120117, 5.08384323120117, 10.9868993759155, 
    10.9868993759155, 10.9868993759155, 10.9868993759155, 10.9868993759155, 
    10.9868993759155, 5.08384323120117, 7.78828001022339, 10.9868993759155, 
    7.78828001022339, 7.9153208732605, 5.08384323120117, 7.78828001022339, 
    5.08384323120117, 7.9153208732605, 7.9153208732605, 10.9868993759155, 
    7.78828001022339, 10.9868993759155, 10.9868993759155, 10.9868993759155, 
    7.9153208732605, 10.9868993759155, 7.9153208732605, 10.9868993759155, 
    10.9868993759155, 7.78828001022339, 7.9153208732605, 10.9868993759155, 
    10.9868993759155, 5.08384323120117, 7.78828001022339, 5.08384323120117, 
    5.08384323120117, 7.9153208732605, 5.08384323120117, 5.08384323120117, 
    10.9868993759155, 5.08384323120117, 10.9868993759155, 7.78828001022339, 
    10.9868993759155, 10.9868993759155, 10.9868993759155, 10.9868993759155, 
    7.78828001022339, 5.08384323120117, 7.9153208732605, 10.9868993759155, 
    10.9868993759155, 7.9153208732605, 7.78828001022339, 10.9868993759155, 
    5.08384323120117, 5.08384323120117, 7.9153208732605, 5.08384323120117, 
    7.78828001022339, 10.9868993759155, 7.78828001022339, 10.9868993759155, 
    10.9868993759155, 7.78828001022339, 7.9153208732605, 10.9868993759155, 
    7.78828001022339, 5.08384323120117, 10.9868993759155, 10.9868993759155, 
    5.08384323120117, 7.9153208732605, 7.78828001022339, 10.9868993759155, 
    10.9868993759155, 10.9868993759155, 10.9868993759155, 10.9868993759155, 
    10.9868993759155, 7.78828001022339, 10.9868993759155, 7.9153208732605, 
    5.08384323120117, 7.9153208732605, 5.08384323120117, 7.78828001022339, 
    7.78828001022339, 10.9868993759155, 5.08384323120117, 10.9868993759155, 
    10.9868993759155, 10.9868993759155, 5.08384323120117, 10.9868993759155, 
    10.9868993759155, 10.9868993759155, 7.78828001022339, 5.08384323120117, 
    10.9868993759155, 7.78828001022339, 7.78828001022339, 7.9153208732605, 
    10.9868993759155, 10.9868993759155, 10.9868993759155, 10.9868993759155, 
    10.9868993759155, 5.08384323120117, 10.9868993759155, 10.9868993759155, 
    7.78828001022339, 7.9153208732605, 10.9868993759155, 10.9868993759155, 
    5.08384323120117, 10.9868993759155, 7.78828001022339, 7.9153208732605, 
    10.9868993759155, 7.9153208732605, 7.78828001022339, 7.78828001022339, 
    7.78828001022339, 5.08384323120117, 7.78828001022339, 7.9153208732605, 
    7.78828001022339, 10.9868993759155, 5.08384323120117, 5.08384323120117, 
    5.08384323120117, 10.9868993759155, 7.9153208732605, 7.9153208732605, 
    10.9868993759155, 5.08384323120117, 10.9868993759155, 7.78828001022339, 
    5.08384323120117, 10.9868993759155, 10.9868993759155, 5.08384323120117, 
    10.9868993759155, 7.78828001022339, 7.78828001022339, 10.9868993759155, 
    7.78828001022339, 10.9868993759155, 7.78828001022339, 10.9868993759155, 
    5.08384323120117, 10.9868993759155, 5.08384323120117, 10.9868993759155, 
    10.9868993759155, 10.9868993759155, 5.08384323120117, 5.08384323120117, 
    7.9153208732605, 10.9868993759155, 7.78828001022339, 7.9153208732605, 
    7.78828001022339, 10.9868993759155, 10.9868993759155, 10.9868993759155, 
    5.08384323120117, 7.78828001022339, 7.9153208732605, 10.9868993759155, 
    7.9153208732605, 7.78828001022339, 7.9153208732605, 7.78828001022339, 
    10.9868993759155, 7.9153208732605, 5.08384323120117, 7.78828001022339, 
    10.9868993759155, 7.78828001022339, 7.78828001022339, 5.08384323120117, 
    10.9868993759155, 5.08384323120117, 7.78828001022339, 10.9868993759155, 
    10.9868993759155, 7.78828001022339, 10.9868993759155, 7.78828001022339, 
    10.9868993759155, 10.9868993759155, 7.9153208732605, 7.78828001022339, 
    7.78828001022339, 10.9868993759155, 10.9868993759155, 7.9153208732605, 
    10.9868993759155, 7.78828001022339, 10.9868993759155, 7.78828001022339, 
    7.78828001022339, 10.9868993759155, 7.9153208732605, 7.9153208732605, 
    10.9868993759155, 10.9868993759155, 10.9868993759155, 7.9153208732605, 
    7.78828001022339, 7.78828001022339, 7.78828001022339, 10.9868993759155, 
    7.9153208732605, 7.9153208732605, 7.78828001022339, 5.08384323120117, 
    7.9153208732605, 10.9868993759155, 10.9868993759155, 7.78828001022339, 
    7.78828001022339, 7.9153208732605, 7.9153208732605, 5.08384323120117, 
    7.78828001022339, 5.08384323120117, 7.78828001022339, 5.08384323120117, 
    5.08384323120117, 5.08384323120117, 10.9868993759155, 10.9868993759155, 
    5.08384323120117, 10.9868993759155, 10.9868993759155, 10.9868993759155, 
    7.9153208732605, 10.9868993759155, 10.9868993759155, 10.9868993759155, 
    5.08384323120117, 7.78828001022339, 7.78828001022339, 10.9868993759155, 
    5.08384323120117, 7.78828001022339, 10.9868993759155, 7.9153208732605, 
    7.78828001022339, 5.08384323120117, 7.9153208732605, 10.9868993759155, 
    7.78828001022339, 5.08384323120117, 7.78828001022339, 5.08384323120117, 
    5.08384323120117, 10.9868993759155, 7.78828001022339, 7.78828001022339, 
    7.78828001022339, 7.78828001022339, 7.9153208732605, 5.08384323120117, 
    5.08384323120117, 10.9868993759155, 7.9153208732605, 7.78828001022339, 
    7.78828001022339, 7.78828001022339, 7.9153208732605, 10.9868993759155, 
    10.9868993759155, 7.9153208732605, 7.9153208732605, 7.78828001022339, 
    5.08384323120117, 10.9868993759155, 10.9868993759155, 10.9868993759155, 
    5.08384323120117, 7.78828001022339, 10.9868993759155, 7.9153208732605, 
    10.9868993759155, 10.9868993759155, 7.9153208732605, 7.78828001022339, 
    10.9868993759155, 10.9868993759155, 7.9153208732605, 7.9153208732605, 
    7.9153208732605, 7.78828001022339, 7.78828001022339, 10.9868993759155, 
    7.9153208732605, 5.08384323120117, 7.78828001022339, 7.9153208732605, 
    7.78828001022339, 7.78828001022339, 5.08384323120117, 10.9868993759155, 
    10.9868993759155, 10.9868993759155, 7.78828001022339, 10.9868993759155, 
    7.9153208732605, 10.9868993759155, 10.9868993759155, 7.78828001022339, 
    10.9868993759155, 7.78828001022339, 7.78828001022339, 5.08384323120117, 
    5.08384323120117, 7.78828001022339, 10.9868993759155, 5.08384323120117, 
    7.9153208732605, 10.9868993759155, 5.08384323120117, 10.9868993759155, 
    5.08384323120117, 10.9868993759155, 7.9153208732605, 7.78828001022339, 
    10.9868993759155, 10.9868993759155, 5.08384323120117, 5.08384323120117, 
    10.9868993759155, 7.78828001022339, 10.9868993759155, 10.9868993759155, 
    10.9868993759155, 10.9868993759155, 10.9868993759155, 7.78828001022339, 
    10.9868993759155, 7.78828001022339, 5.08384323120117, 5.08384323120117, 
    10.9868993759155, 5.08384323120117, 10.9868993759155, 7.78828001022339, 
    7.78828001022339, 7.9153208732605, 5.08384323120117, 7.9153208732605, 
    7.78828001022339, 7.78828001022339, 7.9153208732605, 10.9868993759155, 
    10.9868993759155, 10.9868993759155, 10.9868993759155, 7.78828001022339, 
    7.9153208732605, 10.9868993759155, 7.78828001022339, 10.9868993759155, 
    7.9153208732605, 10.9868993759155, 7.78828001022339, 10.9868993759155, 
    10.9868993759155, 7.78828001022339, 5.08384323120117, 7.78828001022339, 
    10.9868993759155, 10.9868993759155, 7.78828001022339, 7.78828001022339, 
    10.9868993759155, 10.9868993759155, 7.78828001022339, 7.9153208732605, 
    10.9868993759155, 10.9868993759155, 5.08384323120117, 5.08384323120117, 
    10.9868993759155, 10.9868993759155, 10.9868993759155, 10.9868993759155, 
    7.78828001022339, 5.08384323120117, 10.9868993759155, 7.78828001022339, 
    7.9153208732605, 7.78828001022339, 7.9153208732605, 10.9868993759155, 
    7.78828001022339, 5.08384323120117, 7.78828001022339, 5.08384323120117, 
    5.08384323120117, 7.78828001022339, 7.78828001022339, 7.78828001022339, 
    5.08384323120117, 7.78828001022339, 7.78828001022339, 7.9153208732605, 
    10.9868993759155, 10.9868993759155, 10.9868993759155, 10.9868993759155, 
    5.08384323120117, 5.08384323120117, 7.78828001022339, 7.78828001022339, 
    5.08384323120117, 7.78828001022339, 5.08384323120117, 10.9868993759155, 
    7.78828001022339, 7.78828001022339, 10.9868993759155, 10.9868993759155, 
    10.9868993759155, 7.9153208732605, 7.78828001022339, 7.9153208732605, 
    7.78828001022339, 10.9868993759155, 7.78828001022339, 7.78828001022339, 
    5.08384323120117, 5.08384323120117, 7.78828001022339, 7.9153208732605, 
    10.9868993759155, 5.08384323120117, 10.9868993759155, 10.9868993759155, 
    10.9868993759155, 10.9868993759155, 5.08384323120117, 7.78828001022339, 
    5.08384323120117, 10.9868993759155, 5.08384323120117, 5.08384323120117, 
    7.78828001022339, 5.08384323120117, 5.08384323120117, 10.9868993759155, 
    10.9868993759155, 5.08384323120117, 7.9153208732605, 10.9868993759155, 
    10.9868993759155, 7.9153208732605, 5.08384323120117, 10.9868993759155, 
    7.78828001022339, 7.9153208732605, 10.9868993759155, 10.9868993759155, 
    7.78828001022339, 5.08384323120117, 7.78828001022339, 5.08384323120117, 
    5.08384323120117, 10.9868993759155, 7.78828001022339, 7.9153208732605, 
    5.08384323120117, 7.9153208732605, 10.9868993759155, 10.9868993759155, 
    7.9153208732605, 7.9153208732605, 10.9868993759155, 10.9868993759155, 
    7.9153208732605, 10.9868993759155, 7.9153208732605, 5.08384323120117, 
    10.9868993759155, 10.9868993759155, 5.08384323120117, 7.9153208732605, 
    7.9153208732605, 7.9153208732605, 5.08384323120117, 7.9153208732605, 
    7.9153208732605, 10.9868993759155, 7.78828001022339, 7.9153208732605, 
    10.9868993759155, 10.9868993759155, 7.9153208732605, 7.9153208732605, 
    10.9868993759155, 10.9868993759155, NA, 12.6832180023193, 11.9581689834595, 
    13.0901937484741, NA, 13.0901937484741, NA, NA, 11.9581689834595, 
    11.9581689834595, NA, 13.0901937484741, NA, 12.9085054397583, 
    NA, 11.9581689834595, 13.0901937484741, 12.9085054397583, NA, 
    NA, 13.0901937484741, 13.0901937484741, NA, NA, NA, NA, 11.9581689834595, 
    11.9581689834595, 11.9581689834595, NA, 13.0901937484741, 12.6832180023193, 
    NA, NA, 11.9581689834595, 11.9581689834595, NA, 13.0901937484741, 
    12.6832180023193, NA, 11.9581689834595, 13.0901937484741, NA, 
    11.9581689834595, NA, 11.9581689834595, 12.9085054397583, 12.9085054397583, 
    11.9581689834595, 12.6832180023193, 11.9581689834595, NA, NA, 
    12.9085054397583, NA, 12.6832180023193, NA, 11.9581689834595, 
    12.9085054397583, NA, 11.9581689834595, 12.9085054397583, NA, 
    NA, 13.0901937484741, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, 30.5476398468018, 30.5476398468018, 30.5476398468018, 
    30.5476398468018, 30.5476398468018, 30.5476398468018, 30.5476398468018, 
    30.5476398468018, NA, 30.5476398468018, 30.5476398468018, 30.5476398468018, 
    NA, 30.5476398468018, 30.5476398468018, 30.5476398468018, 30.5476398468018, 
    30.5476398468018, 30.5476398468018, NA, 30.5476398468018, 30.5476398468018, 
    30.5476398468018, NA, 30.5476398468018, NA, NA, NA, NA, NA, 30.5476398468018, 
    30.5476398468018, 30.5476398468018, 30.5476398468018, 30.5476398468018, 
    30.5476398468018, 30.5476398468018, 30.5476398468018, 30.5476398468018, 
    30.5476398468018, 30.5476398468018, 30.5476398468018, 30.5476398468018, 
    30.5476398468018, 30.5476398468018, 30.5476398468018, 30.5476398468018, 
    NA, 30.5476398468018, 30.5476398468018, 30.5476398468018, NA, 
    NA, NA, NA, NA, 30.5476398468018, 30.5476398468018, 30.5476398468018, 
    30.5476398468018, 30.5476398468018, 30.5476398468018, 30.5476398468018, 
    30.5476398468018, 30.5476398468018, 30.5476398468018, NA, 30.5476398468018, 
    NA, NA, NA, NA, 30.5476398468018, 30.5476398468018, 30.5476398468018, 
    30.5476398468018, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, 30.5476398468018, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, 30.5476398468018, NA, NA, NA, 30.5476398468018, 30.5476398468018, 
    30.5476398468018, NA, NA, 30.5476398468018, 30.5476398468018, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, 30.5476398468018, 30.5476398468018, 30.5476398468018, 
    30.5476398468018, 30.5476398468018, 30.5476398468018, 30.5476398468018, 
    30.5476398468018, 30.5476398468018, 30.5476398468018, 30.5476398468018, 
    30.5476398468018, 30.5476398468018, 30.5476398468018, 30.5476398468018, 
    30.5476398468018, 30.5476398468018, 30.5476398468018, 30.5476398468018, 
    30.5476398468018, 30.5476398468018, 30.5476398468018, 30.5476398468018, 
    NA, NA, NA, NA, 30.5476398468018, NA, NA, NA, NA, NA, NA, NA, 
    30.5476398468018, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, 30.5476398468018, NA, 30.5476398468018, 30.5476398468018, 
    30.5476398468018, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, 30.5476398468018, 30.5476398468018, 30.5476398468018, 
    30.5476398468018, 30.5476398468018, 30.5476398468018, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, 30.5476398468018, 30.5476398468018, 30.5476398468018, 
    30.5476398468018, 30.5476398468018, 30.5476398468018, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, 153.927719116211, 153.927719116211, 153.927719116211, 
    153.927719116211, 153.927719116211, 153.927719116211, 153.927719116211, 
    153.927719116211, 153.927719116211, 153.927719116211, 153.927719116211, 
    153.927719116211, 153.927719116211, 153.927719116211, 8.3098087310791, 
    6.88642168045044, 6.69394540786743, 6.88642168045044, 7.08579874038696, 
    7.74177837371826, 7.74177837371826, 7.11380386352539, 7.74177837371826, 
    6.08842039108276, 6.88642168045044, 6.02720928192139, 6.02720928192139, 
    8.44301128387451, 5.43175840377808, 8.0387601852417, 8.49756908416748, 
    6.88642168045044, 7.08579874038696, 6.88642168045044, 5.08998727798462, 
    6.049973487854, 6.08842039108276, 8.4395170211792, 8.58236598968506, 
    7.00500679016113, 7.74177837371826, 6.049973487854, 8.4395170211792, 
    6.08842039108276, 7.29503440856934, 6.88642168045044, 7.00500679016113, 
    6.69394540786743, 6.08842039108276, 7.00500679016113, 5.08998727798462, 
    7.7702522277832, 5.88427782058716, 7.11380386352539, 5.88427782058716, 
    6.69394540786743, 7.29503440856934, 6.049973487854, 6.88642168045044, 
    7.30501985549927, 8.57161712646484, 7.7702522277832, 8.57161712646484, 
    8.0387601852417, 6.88642168045044, 7.7702522277832, 5.08998727798462, 
    6.36139392852783, 5.43175840377808, 5.08998727798462, 7.11380386352539, 
    8.5859317779541, 6.08962440490723, 8.44301128387451, 8.44301128387451, 
    6.45949649810791, 6.45949649810791, 6.88642168045044, 7.74177837371826, 
    6.08962440490723, 6.049973487854, 6.08842039108276, 8.3098087310791, 
    7.29503440856934, 6.45949649810791, 7.29503440856934, 8.49756908416748, 
    7.11380386352539, 6.88642168045044, 7.30501985549927, 8.58236598968506, 
    6.88642168045044, 5.08998727798462, 7.7702522277832, 7.08579874038696, 
    6.02720928192139, 6.69394540786743, 8.58236598968506, 6.049973487854, 
    8.5859317779541, 7.08579874038696, 8.13191413879395, 8.57161712646484, 
    7.00500679016113, 6.08842039108276, 5.43175840377808, 8.3098087310791, 
    8.57161712646484, 7.26948213577271, 6.88642168045044, 7.74177837371826, 
    5.43175840377808, 7.74177837371826, 8.5859317779541, 8.5859317779541, 
    6.69394540786743, 7.08579874038696, 6.08842039108276, 8.13191413879395, 
    7.11380386352539, 8.57161712646484, 6.69394540786743, 7.08579874038696, 
    6.45949649810791, 7.29503440856934, 7.30501985549927, 7.11380386352539, 
    8.0387601852417, 8.58236598968506, 8.0387601852417, 8.13191413879395, 
    8.0387601852417, 6.88642168045044, 6.08842039108276, 7.11380386352539, 
    5.88427782058716, 7.26948213577271, 6.02720928192139, 8.57161712646484, 
    6.36139392852783, 7.26948213577271, 5.08998727798462, 7.29503440856934, 
    7.11380386352539, 6.45949649810791, 7.74177837371826, 6.69394540786743, 
    8.4395170211792, 8.3098087310791, 8.0387601852417, 7.08579874038696, 
    8.13191413879395, 5.08998727798462, 6.08842039108276, 7.08579874038696, 
    6.08842039108276, 8.3098087310791, 6.08842039108276, 8.4395170211792, 
    6.08842039108276, 6.45949649810791, 6.049973487854, 8.44301128387451, 
    5.43175840377808, 6.08962440490723, 5.43175840377808, 5.43175840377808, 
    8.3098087310791, 8.57161712646484, 8.58236598968506, 6.08842039108276, 
    7.74177837371826, 7.26948213577271, 6.69394540786743, 8.49756908416748, 
    6.08962440490723, 8.0387601852417, 6.049973487854, 7.08579874038696, 
    8.13191413879395, 6.049973487854, 8.13191413879395, 6.049973487854, 
    6.02720928192139, 6.88642168045044, 5.08998727798462, 6.08842039108276, 
    8.44301128387451, 8.3098087310791, 8.44301128387451, 6.69394540786743, 
    6.66747808456421, 8.4395170211792, 7.74177837371826, 8.3098087310791, 
    5.08998727798462, 7.30501985549927, 7.74177837371826, 8.0387601852417, 
    8.44301128387451, 5.43175840377808, 6.08962440490723, 5.88427782058716, 
    7.00500679016113, 6.08842039108276, 7.7702522277832, 8.57161712646484, 
    6.36139392852783, 5.88427782058716, 6.88642168045044, 6.08842039108276, 
    6.36139392852783, 8.4395170211792, 6.02720928192139, 7.30501985549927, 
    8.44301128387451, 6.02720928192139, 7.74177837371826, 6.88642168045044, 
    8.44301128387451, 7.11380386352539, 8.49756908416748, 5.88427782058716, 
    8.44301128387451, 6.08842039108276, 7.74177837371826, 7.7702522277832, 
    5.43175840377808, 6.36139392852783, 7.26948213577271, 5.88427782058716, 
    6.69394540786743, 8.3098087310791, 7.00500679016113, 6.45949649810791, 
    7.74177837371826, 8.58236598968506, 6.88642168045044, 7.29503440856934, 
    6.08842039108276, 6.08842039108276, 7.29503440856934, 5.08998727798462, 
    8.49756908416748, 8.5859317779541, 8.0387601852417, 8.58236598968506, 
    8.49756908416748, 8.4395170211792, 5.88427782058716, 8.44301128387451, 
    8.49756908416748, 8.5859317779541, 6.08842039108276, 8.44301128387451, 
    8.58236598968506, 7.11380386352539, 7.00500679016113, 7.30501985549927, 
    5.43175840377808, 7.74177837371826, 7.74177837371826, 8.5859317779541, 
    7.30501985549927, 6.08842039108276, 8.49756908416748, 6.08962440490723, 
    8.0387601852417, 8.49756908416748, 6.08842039108276, 7.00500679016113, 
    6.02720928192139, 7.29503440856934, 6.08842039108276, 7.26948213577271, 
    6.88642168045044, 6.36139392852783, 5.08998727798462, 8.13191413879395, 
    6.08842039108276, 7.00500679016113, 6.08842039108276, 8.5859317779541, 
    6.02720928192139, 6.66747808456421, 6.08962440490723, 5.08998727798462, 
    6.45949649810791, 8.5859317779541, 7.7702522277832, 6.08962440490723, 
    5.43175840377808, 8.3098087310791, 8.0387601852417, 6.08842039108276, 
    6.66747808456421, 5.88427782058716, 6.69394540786743, 7.74177837371826, 
    6.66747808456421, 6.69394540786743, 5.43175840377808, 5.43175840377808, 
    7.26948213577271, 8.4395170211792, 6.08842039108276, 7.26948213577271, 
    5.08998727798462, 8.57161712646484, 7.29503440856934, 7.11380386352539, 
    6.36139392852783, 8.57161712646484, 8.0387601852417, 8.5859317779541, 
    5.88427782058716, 6.88642168045044, 6.049973487854, 7.74177837371826, 
    7.74177837371826, 7.7702522277832, 8.5859317779541, 7.74177837371826, 
    8.0387601852417, 6.45949649810791, 7.00500679016113, 8.58236598968506, 
    6.45949649810791, 8.0387601852417, 6.88642168045044, 6.69394540786743, 
    8.0387601852417, 8.4395170211792, 7.29503440856934, 6.88642168045044, 
    7.00500679016113, 5.88427782058716, 7.74177837371826, 7.26948213577271, 
    7.11380386352539, 6.049973487854, 6.08962440490723, 8.3098087310791, 
    5.88427782058716, 8.3098087310791, 7.30501985549927, 5.88427782058716, 
    8.5859317779541, 7.30501985549927, 6.69394540786743, 6.02720928192139, 
    5.88427782058716, 6.08962440490723, 6.66747808456421, 6.88642168045044, 
    6.45949649810791, 8.3098087310791, 7.30501985549927, 6.69394540786743, 
    7.7702522277832, 7.26948213577271, 6.45949649810791, 5.88427782058716, 
    6.08842039108276, 8.13191413879395, 6.08962440490723, 6.66747808456421, 
    6.66747808456421, 5.88427782058716, 8.4395170211792, 7.30501985549927, 
    7.7702522277832, 6.049973487854, 5.88427782058716, 8.13191413879395, 
    8.49756908416748, 7.29503440856934, 7.00500679016113, 5.88427782058716, 
    7.7702522277832, 7.30501985549927, 6.02720928192139, 8.0387601852417, 
    8.44301128387451, 7.00500679016113, 6.69394540786743, 7.7702522277832, 
    7.11380386352539, 5.43175840377808, 5.08998727798462, 7.26948213577271, 
    8.58236598968506, 5.43175840377808, 8.5859317779541, 8.5859317779541, 
    6.66747808456421, 7.26948213577271, 6.08842039108276, 6.88642168045044, 
    5.43175840377808, 6.08842039108276, 7.74177837371826, 7.74177837371826, 
    5.43175840377808, 7.74177837371826, 6.66747808456421, 5.43175840377808, 
    6.66747808456421, 5.08998727798462, 7.00500679016113, 6.69394540786743, 
    7.74177837371826, 6.08962440490723, 6.08842039108276, 6.08842039108276, 
    7.08579874038696, 6.36139392852783, 6.049973487854, 7.74177837371826, 
    8.57161712646484, 8.44301128387451, 7.74177837371826, 8.58236598968506, 
    7.26948213577271, 5.43175840377808, 6.88642168045044, 8.0387601852417, 
    6.36139392852783, 7.00500679016113, 7.11380386352539, 7.7702522277832, 
    6.02720928192139, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 5.32630586624146, 5.32630586624146, 
    5.32630586624146, 5.32630586624146, 7.64244794845581, 6.03130960464478, 
    17.4352893829346, 5.3662428855896, 6.03130960464478, 6.03130960464478, 
    7.64244794845581, 5.3662428855896, 7.64244794845581, 7.64244794845581, 
    7.64244794845581, 17.4352893829346, 5.3662428855896, 6.03130960464478, 
    6.03130960464478, 5.3662428855896, 5.3662428855896, 17.4352893829346, 
    5.3662428855896, 6.03130960464478, 6.03130960464478, 17.4352893829346, 
    17.4352893829346, 5.3662428855896, 6.03130960464478, 6.03130960464478, 
    6.03130960464478, 5.3662428855896, 6.03130960464478, 7.64244794845581, 
    7.64244794845581, 5.3662428855896, 5.3662428855896, 5.3662428855896, 
    6.03130960464478, 3, 7.64244794845581, 6.03130960464478, 7.64244794845581, 
    17.4352893829346, 5.3662428855896, 17.4352893829346, 17.4352893829346, 
    5.3662428855896, 5.19028806686401, 6.03130960464478, 6.03130960464478, 
    6.03130960464478, 6.03130960464478, 17.4352893829346, 7.64244794845581, 
    6.03130960464478, 7.64244794845581, 7.64244794845581, 17.4352893829346, 
    17.4352893829346, 5.3662428855896, 8.87769794464111, 5.3662428855896, 
    5.3662428855896, 17.4352893829346, 7.64244794845581, 5.3662428855896, 
    5.3662428855896, 6.03130960464478, 17.4352893829346, 5.3662428855896, 
    7.64244794845581, 4.9691367149353, 7.64244794845581, 5.3662428855896, 
    17.4352893829346, 8.87769794464111, 7.64244794845581, 7.64244794845581, 
    5.3662428855896, 17.4352893829346, 7.64244794845581, 5.3662428855896, 
    17.4352893829346, 17.4352893829346, 17.4352893829346, 17.4352893829346, 
    7.64244794845581, 7.64244794845581, 6.03130960464478, 5.3662428855896, 
    17.4352893829346, 5.3662428855896, 17.4352893829346, 7.64244794845581, 
    6.03130960464478, 5.3662428855896, 17.4352893829346, 17.4352893829346, 
    6.03130960464478, 17.4352893829346, 5.3662428855896, 6.03130960464478, 
    17.4352893829346, 17.4352893829346, 7.64244794845581, 7.64244794845581, 
    17.4352893829346, 17.4352893829346, 17.4352893829346, 5.3662428855896, 
    17.4352893829346, 6.03130960464478, 17.4352893829346, 17.4352893829346, 
    3, 6.03130960464478, 17.4352893829346, 17.4352893829346, 7.64244794845581, 
    7.5171422958374, 17.4352893829346, 5.3662428855896, 17.4352893829346, 
    17.4352893829346, 7.64244794845581, 17.4352893829346, 5.3662428855896, 
    6.03130960464478, 6.03130960464478, 7.64244794845581, 5.3662428855896, 
    5.19028806686401, 7.64244794845581, 17.4352893829346, 17.4352893829346, 
    18.7214279174805),
  c(6.03130960464478, 7.64244794845581, 7.64244794845581, 17.4352893829346, 
    7.64244794845581, 7.64244794845581, 6.03130960464478, 6.03130960464478, 
    4.9691367149353, 7.64244794845581, 4.9691367149353, 17.4352893829346, 
    17.4352893829346, 17.4352893829346, 5.19028806686401, 5.3662428855896, 
    17.4352893829346, 5.3662428855896, 6.03130960464478, 17.4352893829346, 
    7.64244794845581, 17.4352893829346, 17.4352893829346, 4.9691367149353, 
    5.3662428855896, 7.64244794845581, 7.64244794845581, 18.7214279174805, 
    7.64244794845581, 7.64244794845581, 6.03130960464478, 18.7214279174805, 
    5.3662428855896, 17.4352893829346, 7.64244794845581, 7.64244794845581, 
    6.03130960464478, 7.64244794845581, 7.64244794845581, 5.3662428855896, 
    5.3662428855896, 3, 7.64244794845581, 5.3662428855896, 5.3662428855896, 
    7.64244794845581, 6.03130960464478, 7.64244794845581, 5.3662428855896, 
    7.64244794845581, 6.03130960464478, 7.64244794845581, 6.03130960464478, 
    8.87769794464111, 17.4352893829346, 18.7214279174805, 6.03130960464478, 
    6.03130960464478, 5.3662428855896, 17.4352893829346, 7.64244794845581, 
    17.4352893829346, 6.03130960464478, 17.4352893829346, 7.64244794845581, 
    6.03130960464478, 5.3662428855896, 6.03130960464478, 7.64244794845581, 
    7.64244794845581, 5.3662428855896, 7.64244794845581, 7.64244794845581, 
    17.4352893829346, 6.03130960464478, 18.7214279174805, 5.3662428855896, 
    7.64244794845581, 17.4352893829346, 7.64244794845581, 7.64244794845581, 
    6.03130960464478, 5.3662428855896, 7.64244794845581, 6.03130960464478, 
    6.03130960464478, 5.3662428855896, 6.03130960464478, 6.03130960464478, 
    7.64244794845581, 3, 6.03130960464478, 6.03130960464478, 4.9691367149353, 
    6.03130960464478, 6.03130960464478, 7.64244794845581, 7.64244794845581, 
    17.4352893829346, 6.03130960464478, 7.64244794845581, 7.64244794845581, 
    4.9691367149353, 7.64244794845581, 6.03130960464478, 7.64244794845581, 
    4.69281244277954, 17.4352893829346, 6.03130960464478, 5.3662428855896, 
    6.03130960464478, 17.4352893829346, 7.64244794845581, 5.3662428855896, 
    17.4352893829346, 6.03130960464478, 5.3662428855896, 6.03130960464478, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 7.99653673171997, 
    7.99653673171997, 7.99653673171997, 3.73251748085022, 3.73251748085022, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 8.9248743057251, 2.70645475387573, 
    2.34416222572327, 2.70645475387573, 2.34416222572327, 7.92288303375244, 
    3.44812321662903, 2.56324887275696, 2.79201769828796, 2.34416222572327, 
    4.4913763999939, 4.65236663818359, 3.4338366985321, 4.4913763999939, 
    3.44812321662903, 2.6282799243927, 2.6282799243927, 4.65236663818359, 
    3.44812321662903, 2.56324887275696, 10.307580947876, 2.6282799243927, 
    NA, 2.98091292381287, 5.63597679138184, 3.57086420059204, 4.4913763999939, 
    3.57086420059204, 4.92835092544556, 2.93301486968994, 4.37962293624878, 
    4.37962293624878, 4.4913763999939, 2.26117086410522, 4.65236663818359, 
    2.98091292381287, 4.37962293624878, 7.32008790969849, 2.98091292381287, 
    7.74337291717529, 10.47718334198, 2.98091292381287, NA, 3.57086420059204, 
    3.4338366985321, NA, 6.55190467834473, 7.68824052810669, 3.87955093383789, 
    3.4338366985321, 2.71659350395203, 2.40259218215942, 2.98091292381287, 
    NA, 2.6282799243927, 2.26117086410522, 2.56324887275696, 3.87955093383789, 
    2.53063368797302, 2.53063368797302, 10.6564826965332, 3.55448627471924, 
    3, 8.9248743057251, 2.6282799243927, 4.4913763999939, 2.46020460128784, 
    2.71659350395203, 7.92288303375244, 2.79201769828796, 10.8690690994263, 
    3, 2.6282799243927, 7.92288303375244, 3, NA, 3.44812321662903, 
    5.30023670196533, 2.26117086410522, 3, 6.55190467834473, 2.6282799243927, 
    8.9248743057251, 2.26117086410522, 7.68824052810669, NA, 3.57086420059204, 
    2.56324887275696, 2.93301486968994, 6.54325485229492, NA, NA, 
    3.23786544799805, 2.79201769828796, 2.6282799243927, 4.37962293624878, 
    7.68824052810669, 10.47718334198, 10.6564826965332, 3, 7.92288303375244, 
    7.32008790969849, 4.92835092544556, 2.40259218215942, 8.9248743057251, 
    3, NA, 6.54325485229492, 5.30023670196533, NA, 2.71659350395203, 
    NA, 7.68824052810669, 2.79201769828796, 2.70645475387573, 4.92835092544556, 
    7.92288303375244, 2.6282799243927, 8.9248743057251, 10.8690690994263, 
    10.8690690994263, 7.68824052810669, 7.74337291717529, 9.69409656524658, 
    3.55448627471924, NA, NA, 7.74337291717529, 4.4913763999939, 
    7.92288303375244, 4.92835092544556, 10.47718334198, 10.307580947876, 
    10.307580947876, NA, NA, NA, 10.6564826965332, 3.55448627471924, 
    2.40259218215942, 2.70645475387573, NA, NA, NA, 4.65236663818359, 
    2.93301486968994, 2.6282799243927, 2.93301486968994, 10.8690690994263, 
    10.47718334198, 4.37962293624878, 7.92288303375244, 7.54688596725464, 
    2.71659350395203, 10.8690690994263, 10.47718334198, 3, 6.55190467834473, 
    7.92288303375244, 10.47718334198, 2.40259218215942, 8.9248743057251, 
    5.63597679138184, 3.23786544799805, 10.307580947876, 7.32008790969849, 
    NA, 6.90036725997925, 3.87955093383789, 6.54325485229492, 5.30023670196533, 
    2.71659350395203, 2.46282815933228, 10.6564826965332, 3.23786544799805, 
    10.8690690994263, 7.74337291717529, 6.54325485229492, NA, 2.40259218215942, 
    3, 4.4913763999939, NA, 10.307580947876, 10.6564826965332, 7.74337291717529, 
    10.6564826965332, 7.54688596725464, 7.32008790969849, 7.54688596725464, 
    7.92288303375244, 3.87955093383789, NA, NA, NA, 7.74337291717529, 
    NA, NA, 2.46020460128784, 7.74337291717529, 2.6282799243927, 
    2.6282799243927, 5.30023670196533, 7.92288303375244, 4.4913763999939, 
    NA, NA, 3.23786544799805, NA, NA, 4.37962293624878, 5.30023670196533, 
    10.6564826965332, 7.92288303375244, 6.90036725997925, NA, 7.74337291717529, 
    10.307580947876, 7.92288303375244, 7.92288303375244, 2.93301486968994, 
    NA, NA, 10.8690690994263, 7.54688596725464, 4.92835092544556, 
    5.30023670196533, 7.54688596725464, 3, 6.54325485229492, 7.74337291717529, 
    7.68824052810669, 7.74337291717529, 7.92288303375244, NA, 6.54325485229492, 
    7.74337291717529, 7.92288303375244, NA, 2.39313745498657, 7.54688596725464, 
    7.92288303375244, 2.71659350395203, 4.37962293624878, 7.54688596725464, 
    5.30023670196533, NA, 10.6564826965332, NA, 5.30023670196533, 
    NA, 7.74337291717529, NA, 3, 7.74337291717529, 3, 5.30023670196533, 
    5.63597679138184, 7.74337291717529, 3, 7.92288303375244, 7.54688596725464, 
    NA, NA, 3, 7.92288303375244, 2.6282799243927, 7.92288303375244, 
    5.30023670196533, 7.54688596725464, NA, 2.6282799243927, 7.54688596725464, 
    3, 7.74337291717529, 7.54688596725464, 7.92288303375244, NA, 
    7.68824052810669, NA, 2.39313745498657, 7.54688596725464, 7.68824052810669, 
    7.54688596725464, 7.54688596725464, NA, 7.92288303375244, 7.92288303375244, 
    7.54688596725464, 7.92288303375244, 2.93301486968994, 7.92288303375244, 
    4.92835092544556, 7.32008790969849, 7.54688596725464, 7.92288303375244, 
    7.92288303375244, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, 9.66024398803711, 9.59123134613037, 
    8.96804904937744, 9.59123134613037, 10.1148157119751, 9.59123134613037, 
    9.59123134613037, 8.96804904937744, 9.66024398803711, 9.59123134613037, 
    8.96804904937744, 8.96804904937744, 9.59123134613037, 10.0468587875366, 
    9.59123134613037, 9.66024398803711, 10.1148157119751, 9.59123134613037, 
    9.59123134613037, 8.96804904937744, 8.96804904937744, 10.1148157119751, 
    10.0468587875366, 9.59123134613037, 9.59123134613037, 10.1148157119751, 
    8.96804904937744, 9.66024398803711, 10.1148157119751, 10.1148157119751, 
    9.66024398803711, 10.0468587875366, 9.66024398803711, 9.59123134613037, 
    10.1148157119751, 9.66024398803711, 10.0468587875366, 9.59123134613037, 
    9.01767635345459, 9.01767635345459, 10.1148157119751, 9.01767635345459, 
    8.96804904937744, 9.01767635345459, 10.0468587875366, 9.66024398803711, 
    9.01767635345459, 9.66024398803711, 9.66024398803711, 9.59123134613037, 
    8.96804904937744, 8.96804904937744, 10.0468587875366, 9.01767635345459, 
    10.0468587875366, 10.1148157119751, 10.1148157119751, 9.59123134613037, 
    10.0468587875366, 9.59123134613037, 9.59123134613037, 9.59123134613037, 
    9.59123134613037, 9.01767635345459, 10.1148157119751, 10.0468587875366, 
    8.96804904937744, 9.66024398803711, 9.01767635345459, 10.0468587875366, 
    9.66024398803711, 9.59123134613037, 9.01767635345459, 9.59123134613037, 
    9.66024398803711, 9.59123134613037, 8.96804904937744, 8.96804904937744, 
    9.01767635345459, 8.96804904937744, 9.66024398803711, 9.59123134613037, 
    9.66024398803711, 9.59123134613037, 10.0468587875366, 9.59123134613037, 
    10.0468587875366, 9.66024398803711, 9.59123134613037, 10.1148157119751, 
    9.59123134613037, 8.96804904937744, 9.01767635345459, 10.0468587875366, 
    8.96804904937744, 10.0468587875366, 9.59123134613037, 10.0468587875366, 
    8.96804904937744, 8.96804904937744, 10.0468587875366, 9.66024398803711, 
    9.59123134613037, 9.01767635345459, 9.59123134613037, 8.96804904937744, 
    9.59123134613037, 10.0468587875366, 10.0468587875366, 10.0468587875366, 
    10.0468587875366, 9.01767635345459, 9.01767635345459, 9.01767635345459, 
    9.66024398803711, 10.0468587875366, 9.01767635345459, 8.96804904937744, 
    8.96804904937744, 8.96804904937744, 10.1148157119751, 10.0468587875366, 
    8.96804904937744, 9.59123134613037, 9.01767635345459, 9.66024398803711, 
    8.96804904937744, 9.59123134613037, 9.59123134613037, 9.01767635345459, 
    9.66024398803711, 8.96804904937744, 9.01767635345459, 9.01767635345459, 
    10.0468587875366, 9.01767635345459, 9.01767635345459, 8.96804904937744, 
    9.01767635345459, 10.0468587875366, 10.1148157119751, 9.01767635345459, 
    10.1148157119751, 9.01767635345459, 8.96804904937744, 9.66024398803711, 
    9.59123134613037, 9.66024398803711, 9.59123134613037, 10.0468587875366, 
    10.0468587875366, 9.59123134613037, 9.59123134613037, 10.0468587875366, 
    10.0468587875366, 9.59123134613037, 9.59123134613037, 9.59123134613037, 
    10.1148157119751, 9.01767635345459, 10.1148157119751, 9.59123134613037, 
    8.96804904937744, 10.0468587875366, 10.0468587875366, 9.59123134613037, 
    9.66024398803711, 10.0468587875366, 9.59123134613037, 9.59123134613037, 
    9.59123134613037, 9.59123134613037, 9.59123134613037, 10.0468587875366, 
    9.01767635345459, 10.1148157119751, 9.66024398803711, 10.1148157119751, 
    10.0468587875366, 9.59123134613037, 8.96804904937744, 10.1148157119751, 
    9.66024398803711, 9.59123134613037, 8.96804904937744, 9.66024398803711, 
    10.0468587875366, 8.96804904937744, 8.96804904937744, 10.1148157119751, 
    10.1148157119751, 10.0468587875366, 9.59123134613037, 9.01767635345459, 
    9.01767635345459, 9.66024398803711, 8.96804904937744, 8.96804904937744, 
    10.0468587875366, 8.96804904937744, 9.01767635345459, 9.66024398803711, 
    10.0468587875366, 10.1148157119751, 9.59123134613037, 10.1148157119751, 
    10.0468587875366, 10.1148157119751, 10.0468587875366, 9.01767635345459, 
    9.59123134613037, 9.66024398803711, 10.0468587875366, 8.96804904937744, 
    10.0468587875366, 10.0468587875366, 9.59123134613037, 9.59123134613037, 
    9.59123134613037, 9.01767635345459, 8.96804904937744, 9.01767635345459, 
    9.59123134613037, 10.1148157119751, 9.01767635345459, 9.66024398803711, 
    9.01767635345459, 8.96804904937744, 9.01767635345459, 10.1148157119751, 
    9.01767635345459, 9.59123134613037, 9.59123134613037, 8.96804904937744, 
    8.96804904937744, 10.0468587875366, 9.66024398803711, 10.0468587875366, 
    9.01767635345459, 9.59123134613037, 9.59123134613037, 9.59123134613037, 
    10.1148157119751, 9.66024398803711, 9.59123134613037, 8.96804904937744, 
    9.01767635345459, 9.66024398803711, 10.0468587875366, 10.0468587875366, 
    9.59123134613037, 9.59123134613037, 10.0468587875366, 10.0468587875366, 
    8.96804904937744, 10.0468587875366, 8.96804904937744, 9.01767635345459, 
    10.1148157119751, 9.01767635345459, 10.0468587875366, 8.96804904937744, 
    9.66024398803711, 10.1148157119751, 10.1148157119751, 10.1148157119751, 
    8.96804904937744, 10.0468587875366, 8.96804904937744, 10.1148157119751, 
    9.59123134613037, 8.96804904937744, 9.01767635345459, 8.96804904937744, 
    9.59123134613037, 9.59123134613037, 9.01767635345459, 10.0468587875366, 
    9.59123134613037, 10.0468587875366, 8.96804904937744, 9.01767635345459, 
    10.0468587875366, 10.1148157119751, 10.0468587875366, 10.0468587875366, 
    9.01767635345459, 9.66024398803711, 8.96804904937744, 9.01767635345459, 
    9.01767635345459, 10.0468587875366, 9.66024398803711, 9.01767635345459, 
    8.96804904937744, 10.1148157119751, 10.1148157119751, 9.59123134613037, 
    8.96804904937744, 9.01767635345459, 8.96804904937744, 10.0468587875366, 
    9.01767635345459, 8.96804904937744, 8.96804904937744, 9.66024398803711, 
    8.96804904937744, 10.0468587875366, 10.1148157119751, 9.59123134613037, 
    10.0468587875366, 9.01767635345459, 10.1148157119751, 9.59123134613037, 
    10.0468587875366, 10.0468587875366, 9.01767635345459, 10.0468587875366, 
    8.96804904937744, 9.59123134613037, 10.1148157119751, 8.96804904937744, 
    10.1148157119751, 9.59123134613037, 10.1148157119751, 9.59123134613037, 
    10.0468587875366, 8.96804904937744, 9.66024398803711, 8.96804904937744, 
    9.66024398803711, 8.96804904937744, 10.0468587875366, 9.01767635345459, 
    9.01767635345459, 9.59123134613037, 9.66024398803711, 9.59123134613037, 
    9.01767635345459, 8.96804904937744, 10.1148157119751, 10.1148157119751, 
    8.96804904937744, 10.1148157119751, 9.59123134613037, 9.59123134613037, 
    9.59123134613037, 8.96804904937744, 8.96804904937744, 9.01767635345459, 
    8.96804904937744, 8.96804904937744, 9.59123134613037, 9.66024398803711, 
    9.59123134613037, 10.1148157119751, 8.96804904937744, 9.66024398803711, 
    9.59123134613037, 9.01767635345459, 8.96804904937744, 10.0468587875366, 
    9.66024398803711, 9.66024398803711, 9.59123134613037, 9.66024398803711, 
    10.1148157119751, 9.01767635345459, 9.01767635345459, 10.0468587875366, 
    8.96804904937744, 10.0468587875366, 9.59123134613037, 8.96804904937744, 
    8.96804904937744, 9.66024398803711, 10.1148157119751, 10.1148157119751, 
    8.96804904937744, 8.96804904937744, 10.0468587875366, 8.96804904937744, 
    8.96804904937744, 10.0468587875366, 10.0468587875366, 8.96804904937744, 
    10.0468587875366, 10.1148157119751, 10.0468587875366, 8.96804904937744, 
    10.1148157119751, 10.0468587875366, 9.01767635345459, 8.96804904937744, 
    8.96804904937744, 10.0468587875366, 10.0468587875366, 8.96804904937744, 
    10.1148157119751, 10.0468587875366, 9.59123134613037, 9.59123134613037, 
    10.1148157119751, 10.1148157119751, 9.59123134613037, 9.59123134613037, 
    9.66024398803711, 10.1148157119751, 8.96804904937744, 10.1148157119751, 
    9.01767635345459, 9.66024398803711, 9.66024398803711, 10.1148157119751, 
    9.66024398803711, 10.1148157119751, 10.0468587875366, 9.59123134613037, 
    10.1148157119751, 10.0468587875366, 10.1148157119751, 10.1148157119751, 
    10.0468587875366, 10.0468587875366, 9.59123134613037, 9.66024398803711, 
    9.59123134613037, 9.66024398803711, 9.59123134613037, 8.96804904937744, 
    10.0468587875366, 8.96804904937744, 9.01767635345459, 9.01767635345459, 
    10.0468587875366, 8.96804904937744, 10.0468587875366, 10.1148157119751, 
    9.66024398803711, 10.1148157119751, 9.59123134613037, 9.59123134613037, 
    10.1148157119751, 10.1148157119751, 8.96804904937744, 10.1148157119751, 
    8.96804904937744, 10.1148157119751, 9.66024398803711, 8.96804904937744, 
    9.01767635345459, 8.96804904937744, 8.96804904937744, 9.01767635345459, 
    10.0468587875366, 10.1148157119751, 10.0468587875366, 8.96804904937744, 
    9.59123134613037, 8.96804904937744, 9.59123134613037, 8.96804904937744, 
    10.0468587875366, 10.1148157119751, 9.66024398803711, 9.66024398803711, 
    10.0468587875366, 9.01767635345459, 10.1148157119751, 9.59123134613037, 
    10.0468587875366, 8.96804904937744, 10.1148157119751, 9.01767635345459, 
    10.0468587875366, 10.0468587875366, 9.66024398803711, 9.59123134613037, 
    10.0468587875366, 9.01767635345459, 10.0468587875366, 10.0468587875366, 
    10.0468587875366, 8.96804904937744, 10.1148157119751, 9.59123134613037, 
    10.0468587875366, 8.96804904937744, 10.1148157119751, 10.0468587875366, 
    8.96804904937744, 10.0468587875366, 9.59123134613037, 9.59123134613037, 
    10.1148157119751, 8.96804904937744, 8.96804904937744, 9.59123134613037, 
    9.01767635345459, 9.59123134613037, 10.1148157119751, 10.1148157119751, 
    9.59123134613037, 9.01767635345459, 8.96804904937744, 10.0468587875366, 
    10.0468587875366, 8.96804904937744, 9.66024398803711, 10.1148157119751, 
    9.01767635345459, 10.0468587875366, 9.59123134613037, 9.66024398803711, 
    9.01767635345459, 10.1148157119751, 9.01767635345459, 9.01767635345459, 
    9.01767635345459, 10.1148157119751, 9.66024398803711, 10.1148157119751, 
    9.59123134613037, 10.1148157119751, 9.59123134613037, 10.1148157119751, 
    10.1148157119751, 10.1148157119751, 9.59123134613037, 10.0468587875366, 
    9.01767635345459, 9.59123134613037, 9.01767635345459, 8.96804904937744, 
    9.01767635345459, 10.1148157119751, 9.59123134613037, 8.96804904937744, 
    9.01767635345459, 10.1148157119751, 9.59123134613037, 9.66024398803711, 
    10.0468587875366, 9.66024398803711, 9.59123134613037, 10.0468587875366, 
    10.1148157119751, 8.96804904937744, 9.66024398803711, 9.59123134613037, 
    10.0468587875366, 10.0468587875366, 9.59123134613037, 10.1148157119751, 
    9.59123134613037, 10.0468587875366, 10.0468587875366, 10.1148157119751, 
    9.59123134613037, 9.66024398803711, 10.1148157119751, 8.96804904937744, 
    8.96804904937744, 9.66024398803711, 10.0468587875366, 10.0468587875366, 
    9.01767635345459, 9.01767635345459, 9.59123134613037, 9.66024398803711, 
    10.0468587875366, 9.59123134613037, 10.0468587875366, 9.01767635345459, 
    10.0468587875366, 10.1148157119751, 10.1148157119751, 9.66024398803711, 
    10.1148157119751, 9.59123134613037, 10.1148157119751, 9.59123134613037, 
    10.0468587875366, 9.59123134613037, 9.01767635345459, 8.96804904937744, 
    10.0468587875366, 9.01767635345459, 10.0468587875366, 9.59123134613037, 
    10.1148157119751, 10.1148157119751, 10.1148157119751, 9.66024398803711, 
    10.1148157119751, 9.66024398803711, 10.1148157119751, 8.96804904937744, 
    10.0468587875366, 9.59123134613037, 8.96804904937744, 9.01767635345459, 
    9.01767635345459, 9.01767635345459, 10.0468587875366, 9.01767635345459, 
    9.66024398803711, 9.01767635345459, 10.0468587875366, 8.96804904937744, 
    9.59123134613037, 8.96804904937744, 9.59123134613037, 9.66024398803711, 
    9.01767635345459, 9.59123134613037, 9.01767635345459, 9.01767635345459, 
    10.1148157119751, 9.01767635345459, 9.66024398803711, 10.1148157119751, 
    9.59123134613037, 9.59123134613037, 9.66024398803711, 9.01767635345459, 
    10.0468587875366, 10.0468587875366, 10.1148157119751, 10.0468587875366, 
    10.1148157119751, 9.01767635345459, 9.01767635345459, 10.1148157119751, 
    9.66024398803711, 9.01767635345459, 10.1148157119751, 9.59123134613037, 
    8.96804904937744, 10.1148157119751, 9.01767635345459, 9.66024398803711, 
    9.66024398803711, 9.66024398803711, 9.59123134613037, 9.66024398803711, 
    10.1148157119751, 9.01767635345459, 10.1148157119751, 9.01767635345459, 
    9.01767635345459, 9.01767635345459, 10.1148157119751, 9.66024398803711, 
    9.66024398803711, 9.01767635345459, 10.1148157119751, 10.1148157119751, 
    9.59123134613037, 10.1148157119751, 9.66024398803711, 8.96804904937744, 
    9.59123134613037, 8.96804904937744, 9.66024398803711, 10.0468587875366, 
    9.01767635345459, 10.0468587875366, 10.1148157119751, 9.01767635345459, 
    9.01767635345459, 9.01767635345459, 10.0468587875366, 9.01767635345459, 
    9.01767635345459, 9.01767635345459, 9.01767635345459, 9.01767635345459, 
    9.01767635345459, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, 2.42727637290955, 2.42727637290955, 2.42727637290955, 
    2.42727637290955, NA, 22.7760543823242, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 22.7760543823242, 
    NA, 22.7760543823242, NA, 22.7760543823242, NA, NA, NA, NA, 22.7760543823242, 
    22.7760543823242, NA, NA, NA, NA, NA, NA, 22.7760543823242, 22.7760543823242, 
    22.7760543823242, NA, NA, NA, 22.7760543823242, NA, NA, NA, 22.7760543823242, 
    22.7760543823242, 22.7760543823242, 22.7760543823242, 22.7760543823242, 
    NA, 22.7760543823242, NA, NA, NA, NA, 22.7760543823242, 22.7760543823242, 
    22.7760543823242, 22.7760543823242, NA, NA, 22.7760543823242, 
    NA, 22.7760543823242, NA, NA, NA, NA, NA, NA, NA, NA, 22.7760543823242, 
    NA, 22.7760543823242, 22.7760543823242, NA, NA, NA, NA, 22.7760543823242, 
    NA, NA, NA, 22.7760543823242, 22.7760543823242, NA, NA, NA, NA, 
    NA, NA, NA, NA, 22.7760543823242, 22.7760543823242, NA, NA, NA, 
    NA, 22.7760543823242, 22.7760543823242, 22.7760543823242, 22.7760543823242, 
    NA, 22.7760543823242, NA, NA, NA, 22.7760543823242, NA, NA, 22.7760543823242, 
    NA, NA, NA, NA, 22.7760543823242, NA, NA, 22.7760543823242, NA, 
    22.7760543823242, 22.7760543823242, 22.7760543823242, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 22.7760543823242, NA, 
    NA, 22.7760543823242, NA, 22.7760543823242, NA, 22.7760543823242, 
    NA, NA, NA, NA, NA, NA, 22.7760543823242, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, 22.7760543823242, 22.7760543823242, 
    NA, NA, NA, NA, 22.7760543823242, NA, 22.7760543823242, NA, 22.7760543823242, 
    22.7760543823242, 22.7760543823242, 22.7760543823242, 22.7760543823242, 
    22.7760543823242, 22.7760543823242, NA, NA, NA, NA, NA, 22.7760543823242, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, 3.01649451255798, 3.01649451255798, NA, 3.01649451255798, 
    3.01649451255798, 3.01649451255798, 3.01649451255798, 3.01649451255798, 
    3.01649451255798, 3.01649451255798, NA, 3.01649451255798, NA, 
    NA, NA, 3.01649451255798, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, 3.01649451255798, NA, 3.01649451255798, 3.01649451255798, 
    NA, NA, NA, 1.89697599411011, 5.25679016113281, 5.25679016113281, 
    3.06, 3.06, 5.25679016113281, 5.25679016113281, 5.25679016113281, 
    2.51816558837891, 3.06, 2.51816558837891, 2.51816558837891, 3.06, 
    3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 
    5.25679016113281, 3.06, 5.25679016113281, 5.25679016113281, 3.06, 
    3.06, 2.51816558837891, 5.25679016113281, 5.25679016113281, 3.06, 
    5.25679016113281, 3.06, 3.06, 3.06, 3.06, 3.06, 5.25679016113281, 
    5.25679016113281, 5.25679016113281, 5.25679016113281, 3.06, 3.06, 
    3.06, 5.25679016113281, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 
    5.25679016113281, 5.25679016113281, 3.06, 3.06, 3.06, 3.06, 5.25679016113281, 
    3.06, 3.06, 3.06, 3.06, 3.06, 5.25679016113281, 3.06, 3.06, 3.06, 
    3.06, 5.25679016113281, 3.06, 3.06, 5.25679016113281, 2.51816558837891, 
    5.25679016113281, 2.51816558837891, 3.06, 3.06, 3.06, 3.06, 3.06, 
    5.25679016113281, 3.06, 3.06, 3.06, 5.25679016113281, 5.25679016113281, 
    2.51816558837891, 5.25679016113281, 3.06, 5.25679016113281, 3.06, 
    3.06, 3.06, 3.06, 5.25679016113281, 5.25679016113281, 5.25679016113281, 
    5.25679016113281, 3.06, 3.06, 3.06, 5.25679016113281, 3.06, 3.06, 
    3.06, 3.06, 5.25679016113281, 3.06, 3.06, 5.25679016113281, 3.06, 
    22.438102722168, 8.35879802703857, 8.35879802703857, 8.35879802703857, 
    8.35879802703857, 8.35879802703857, 8.35879802703857, 8.35879802703857, 
    8.35879802703857, 8.35879802703857, 8.35879802703857, 8.35879802703857, 
    8.35879802703857, 8.35879802703857, 8.35879802703857, 8.35879802703857, 
    8.35879802703857, 8.35879802703857, 8.35879802703857, 8.35879802703857, 
    8.35879802703857, 8.35879802703857, 8.35879802703857, 8.35879802703857, 
    8.35879802703857, 8.35879802703857, 8.35879802703857, 8.35879802703857, 
    8.35879802703857, 8.35879802703857, 8.35879802703857, 8.35879802703857, 
    8.35879802703857, 8.35879802703857, 8.35879802703857, 8.35879802703857, 
    8.35879802703857, 8.35879802703857, 8.35879802703857, 8.35879802703857, 
    8.35879802703857, 8.35879802703857, 8.35879802703857, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, 3.73251748085022, 
    3.73251748085022, 3.73251748085022, 3.73251748085022, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 3.54526901245117, 
    26.1309700012207, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, NA, 
    3.06, NA, 3.06, NA, 3.06, NA, 3.06, 3.06, 3.06, NA, NA, NA, NA, 
    NA, 3.06, NA, NA, NA, 3.06, 3.06, 3.06, 3.06, NA, NA, 3.06, NA, 
    NA, NA, 3.06, 3.06, NA, 3.06, 3.06, 3.06, NA, NA, 3.06, 3.06, 
    3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 
    3.06, NA, 3.06, 3.06, 3.06, NA, NA, 3.06, NA, NA, NA, 3.06, 3.06, 
    NA, NA, NA, NA, NA, 3.06, 3.06, NA, NA, NA, NA, 3.06, NA, NA, 
    NA, NA, 3.06, NA, NA, NA, NA, 3.06, NA, NA, NA, 3.06, NA, 3.06, 
    NA, NA, 3.06, 3.06, NA, NA, 3.06, NA, NA, 3.06, 3.06, 3.06, NA, 
    3.06, NA, 3.06, NA, NA, NA, NA, NA, NA, NA, 3.06, NA, NA, 3.06, 
    NA, NA, 3.06, NA, NA, NA, 3.06, NA, NA, NA, NA, NA, 3.06, NA, 
    NA, NA, NA, 3.06, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, 3.06, NA, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 
    3.06, 3.06, 3.06, 3.06, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    2, 7.85156536102295, 9.50105381011963, 2, 9.50105381011963, 2, 
    2, 7.85156536102295, 2, 5.98447275161743, 7.85156536102295, 2, 
    2, 2, 7.85156536102295, 7.85156536102295, 2, 2, 9.50105381011963, 
    2, 2, 2, 2, 9.50105381011963, 8.55553150177002, 2, 5.98447275161743, 
    5.98447275161743, 2, 2, 2, 2, 2, 9.50105381011963, 2, 5.98447275161743, 
    2, 9.50105381011963, 8.55553150177002, 5.98447275161743, 8.55553150177002, 
    9.50105381011963, 7.85156536102295, 2, 2, 2, 8.55553150177002, 
    2, 7.85156536102295, 5.98447275161743, 8.55553150177002, 8.55553150177002, 
    9.50105381011963, 7.85156536102295, 7.85156536102295, 2, 2, 5.98447275161743, 
    2, 2, 5.98447275161743, 2, 2, 8.55553150177002, 9.50105381011963, 
    2, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 5.4, 5.4, 5.4, 
    5.4, 5.4, 5.4, 5.4, 5.4, 5.4, 5.4, 5.4, 5.4, 5.4, 5.4, 5.4, 5.4, 
    5.4, 5.4, 5.4, 5.4, 5.4, 5.4, 5.4, 5.4, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 41.8847160339355, 
    41.8847160339355, 41.8847160339355, 41.8847160339355, 41.8847160339355, 
    41.8847160339355, 41.8847160339355, 41.8847160339355, 41.8847160339355, 
    41.8847160339355, 41.8847160339355, 41.8847160339355, 41.8847160339355, 
    41.8847160339355, 41.8847160339355, 41.8847160339355, 41.8847160339355, 
    41.8847160339355, 41.8847160339355, 41.8847160339355, 41.8847160339355, 
    41.8847160339355, 41.8847160339355, 41.8847160339355, 41.8847160339355, 
    41.8847160339355, 41.8847160339355, 41.8847160339355, 41.8847160339355, 
    41.8847160339355, 41.8847160339355, 41.8847160339355, 41.8847160339355, 
    2, 2, 1.83497667312622, 2, 2, 2, 2, 1.83497667312622, 2, 1.83497667312622, 
    2, 2, 2, 1.83497667312622, 2, 1.83497667312622, 2, 1.83497667312622, 
    1.83497667312622, 2, 2, 2, 1.83497667312622, 2, 1.83497667312622, 
    1.83497667312622, 2, 2, 1.83497667312622, 1.83497667312622, 1.83497667312622, 
    1.83497667312622, 1.83497667312622, 1.83497667312622, 1.83497667312622, 
    1.83497667312622, 18.3622894287109, 18.3622894287109, 18.3622894287109, 
    18.3622894287109, 18.3622894287109, 18.3622894287109, 18.3622894287109, 
    18.3622894287109, 18.3622894287109, 18.3622894287109, 18.3622894287109, 
    18.3622894287109, 18.3622894287109, 18.3622894287109, 18.3622894287109, 
    18.3622894287109, 18.3622894287109, 18.3622894287109, 18.3622894287109, 
    18.3622894287109, 18.3622894287109, 18.3622894287109, 18.3622894287109, 
    18.3622894287109, 18.3622894287109, 18.3622894287109, 18.3622894287109, 
    18.3622894287109, 18.3622894287109, 18.3622894287109, 18.3622894287109, 
    18.3622894287109, 18.3622894287109, 18.3622894287109, 18.3622894287109, 
    18.3622894287109, 18.3622894287109, 18.3622894287109, 18.3622894287109, 
    18.3622894287109, 18.3622894287109, 18.3622894287109, 18.3622894287109, 
    18.3622894287109, 18.3622894287109, 18.3622894287109, 18.3622894287109, 
    18.3622894287109, 18.3622894287109, 18.3622894287109, 18.3622894287109, 
    18.3622894287109, 18.3622894287109, 18.3622894287109, 18.3622894287109, 
    18.3622894287109, 18.3622894287109, 18.3622894287109, 18.3622894287109, 
    18.3622894287109, 18.3622894287109, 18.3622894287109, 18.3622894287109, 
    18.3622894287109, 18.3622894287109, 18.3622894287109, 18.3622894287109, 
    18.3622894287109, 18.3622894287109, 18.3622894287109, 18.3622894287109, 
    18.3622894287109, 18.3622894287109, 18.3622894287109, 18.3622894287109, 
    18.3622894287109, 18.3622894287109, 18.3622894287109, 18.3622894287109, 
    18.3622894287109, 18.3622894287109, 18.3622894287109, 18.3622894287109, 
    18.3622894287109, 18.3622894287109, 18.3622894287109, 18.3622894287109, 
    18.3622894287109, 18.3622894287109, 18.3622894287109, 18.3622894287109, 
    18.3622894287109, 18.3622894287109, 18.3622894287109, 18.3622894287109, 
    18.3622894287109, 18.3622894287109, 18.3622894287109, 18.3622894287109, 
    18.3622894287109, 18.3622894287109, 18.3622894287109, 18.3622894287109, 
    18.3622894287109, 18.3622894287109, 18.3622894287109, 18.3622894287109, 
    18.3622894287109, 18.3622894287109, 18.3622894287109, 18.3622894287109, 
    18.3622894287109, 18.3622894287109, 18.3622894287109, 18.3622894287109, 
    18.3622894287109, 18.3622894287109, 18.3622894287109, 18.3622894287109, 
    18.3622894287109, 18.3622894287109, 18.3622894287109, 18.3622894287109, 
    18.3622894287109, 18.3622894287109, 18.3622894287109, 18.3622894287109, 
    18.3622894287109, 18.3622894287109, 18.3622894287109, 18.3622894287109, 
    18.3622894287109, 18.3622894287109, 18.3622894287109, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 20.4969882965088, 
    20.4969882965088, 20.4969882965088, 20.4969882965088, 20.4969882965088, 
    20.4969882965088, 20.4969882965088, 20.4969882965088, 20.4969882965088, 
    20.4969882965088, 20.4969882965088, 20.4969882965088, 20.4969882965088, 
    20.4969882965088, 20.4969882965088, 20.4969882965088, 20.4969882965088, 
    20.4969882965088, 20.4969882965088, 20.4969882965088, 20.4969882965088, 
    20.4969882965088, 20.4969882965088, 20.4969882965088, 20.4969882965088, 
    20.4969882965088, 20.4969882965088, 20.4969882965088, 20.4969882965088, 
    20.4969882965088, 20.4969882965088, 20.4969882965088, 20.4969882965088, 
    20.4969882965088, 20.4969882965088, 20.4969882965088, 20.4969882965088, 
    20.4969882965088, 20.4969882965088, 20.4969882965088, 20.4969882965088, 
    20.4969882965088, 20.4969882965088, 20.4969882965088, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 9.06460189819336
  ),
  c(9.06460189819336, NA, 9.06460189819336, NA, NA, NA, 9.06460189819336, 
    NA, NA, 9.06460189819336, NA, NA, NA, 9.06460189819336, NA, NA, 
    9.06460189819336, NA, NA, 9.06460189819336, 9.06460189819336, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 9.06460189819336, 
    9.06460189819336, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, 9.06460189819336, NA, 9.06460189819336, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, 9.06460189819336, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, 9.06460189819336, NA, NA, 9.06460189819336, 9.06460189819336, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, 13.4414472579956, 13.4414472579956, 13.4414472579956, 
    13.4414472579956, 13.4414472579956, 13.4414472579956, 13.4414472579956, 
    13.4414472579956, 13.4414472579956, 13.4414472579956, 13.4414472579956, 
    13.4414472579956, 13.4414472579956, 13.4414472579956, 13.4414472579956, 
    13.4414472579956, 13.4414472579956, 13.4414472579956, 13.4414472579956, 
    13.4414472579956, 13.4414472579956, 13.4414472579956, 13.4414472579956, 
    13.4414472579956, 13.4414472579956, 13.4414472579956, 13.4414472579956, 
    13.4414472579956, 13.4414472579956, 13.4414472579956, 13.4414472579956, 
    13.4414472579956, 13.4414472579956, 13.4414472579956, 13.4414472579956, 
    13.4414472579956, 13.4414472579956, 13.4414472579956, 13.4414472579956, 
    13.4414472579956, 13.4414472579956, 13.4414472579956, 13.4414472579956, 
    13.4414472579956, 13.4414472579956, 13.4414472579956, 13.4414472579956, 
    13.4414472579956, 13.4414472579956, 13.4414472579956, 13.4414472579956, 
    13.4414472579956, 13.4414472579956, 13.4414472579956, 13.4414472579956, 
    13.4414472579956, 13.4414472579956, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, 2.4138355255127, 9.49538612365723, 27.1207866668701, 
    27.1207866668701, 2.4138355255127, 1.08345317840576, 2.4138355255127, 
    6.60264539718628, 27.1207866668701, 2.88756704330444, 2.41122555732727, 
    6.77630519866943, 26.9133853912354, 2.31053566932678, 20.1820430755615, 
    15.3166275024414, 37.8960266113281, 27.1207866668701, 32.2189712524414, 
    6.37020826339722, 2.4138355255127, 12.0960712432861, 18.2560348510742, 
    26.9133853912354, 6.37020826339722, 26.9133853912354, 20.1820430755615, 
    20.1820430755615, 6.70990943908691, 3.83571290969849, 3.83571290969849, 
    37.8960266113281, 6.70990943908691, 2.10256600379944, 27.1207866668701, 
    20.1820430755615, 15.3166275024414, 12.931191444397, 35.0612525939941, 
    27.1207866668701, 2.88756704330444, 10.9932403564453, 2.31053566932678, 
    6.60264539718628, 0.823701620101929, 1.08345317840576, 2.10256600379944, 
    45.9383239746094, 26.9133853912354, 32.2189712524414, 0.823701620101929, 
    NA, 2.45201873779297, 2.41122555732727, 35.0612525939941, 18.2560348510742, 
    6.60264539718628, 0.823701620101929, 2.41122555732727, 12.0960712432861, 
    45.9383239746094, 2.4138355255127, 27.1207866668701, 12.931191444397, 
    0.823701620101929, 26.9133853912354, 37.8960266113281, 9.49538612365723, 
    6.60264539718628, 3.83571290969849, 18.2560348510742, 27.1207866668701, 
    11.1269645690918, 0.823701620101929, 2.4138355255127, 20.1820430755615, 
    2.10256600379944, 15.3166275024414, 0.823701620101929, 18.2560348510742, 
    0.823701620101929, 6.37020826339722, 2.45201873779297, 2.10256600379944, 
    2.4138355255127, 15.3166275024414, 29.5760669708252, 2.10256600379944, 
    20.1820430755615, 2.10256600379944, 15.3166275024414, 2.41122555732727, 
    32.2189712524414, 1.08345317840576, 29.5760669708252, 2.88756704330444, 
    45.9383239746094, 3.83571290969849, 2.41122555732727, 2.41122555732727, 
    6.70990943908691, 35.0612525939941, 20.1820430755615, 2.4138355255127, 
    27.1207866668701, 6.77630519866943, 45.9383239746094, 6.60264539718628, 
    18.2560348510742, 29.5760669708252, 2.31053566932678, 15.3166275024414, 
    6.60264539718628, 2.31053566932678, 12.931191444397, 2.31053566932678, 
    18.2560348510742, 2.88756704330444, 26.9133853912354, 26.9133853912354, 
    2.41122555732727, 0.823701620101929, 35.0612525939941, 20.1820430755615, 
    2.31053566932678, 32.2189712524414, 12.931191444397, 3.83571290969849, 
    NA, 6.77630519866943, 3.83571290969849, 2.45201873779297, 6.60264539718628, 
    3.83571290969849, 2.45201873779297, 26.9133853912354, 37.8960266113281, 
    12.931191444397, 32.2189712524414, 18.2560348510742, 15.3166275024414, 
    20.1820430755615, 3.83571290969849, 20.1820430755615, 32.2189712524414, 
    2.10256600379944, 6.60264539718628, 6.77630519866943, 6.77630519866943, 
    20.1820430755615, 18.2560348510742, 2.4138355255127, 11.1269645690918, 
    3.83571290969849, 26.9133853912354, 2.45201873779297, 1.08345317840576, 
    NA, 9.49538612365723, 2.4138355255127, 2.31053566932678, 26.9133853912354, 
    27.1207866668701, 2.4138355255127, 45.9383239746094, 18.2560348510742, 
    20.1820430755615, NA, 35.0612525939941, 18.2560348510742, 2.10256600379944, 
    NA, 2.31053566932678, 26.9133853912354, 10.9932403564453, 27.1207866668701, 
    15.3166275024414, 12.0960712432861, 2.10256600379944, NA, 20.1820430755615, 
    10.9932403564453, NA, 15.3166275024414, 12.0960712432861, 45.9383239746094, 
    NA, 2.41122555732727, 26.9133853912354, 9.49538612365723, 35.0612525939941, 
    18.2560348510742, 18.2560348510742, 26.9133853912354, 27.1207866668701, 
    10.9932403564453, 2.10256600379944, 20.1820430755615, 27.1207866668701, 
    26.9133853912354, 2.88756704330444, 9.49538612365723, 18.2560348510742, 
    20.1820430755615, 11.1269645690918, 3.83571290969849, 27.1207866668701, 
    0.823701620101929, 27.1207866668701, 32.2189712524414, 18.2560348510742, 
    2.31053566932678, 9.49538612365723, 11.1269645690918, 20.1820430755615, 
    6.70990943908691, 37.8960266113281, NA, 29.5760669708252, 1.08345317840576, 
    20.1820430755615, 2.4138355255127, 3.83571290969849, 32.2189712524414, 
    12.0960712432861, NA, 11.1269645690918, 11.1269645690918, 20.1820430755615, 
    20.1820430755615, 2.10256600379944, 35.0612525939941, 20.1820430755615, 
    20.1820430755615, 37.8960266113281, 1.08345317840576, 37.8960266113281, 
    45.9383239746094, 18.2560348510742, 27.1207866668701, 27.1207866668701, 
    27.1207866668701, 9.49538612365723, 45.9383239746094, 11.1269645690918, 
    27.1207866668701, 11.1269645690918, 0.823701620101929, 18.2560348510742, 
    2.10256600379944, 18.2560348510742, 20.1820430755615, 20.1820430755615, 
    32.2189712524414, 27.1207866668701, 26.9133853912354, 26.9133853912354, 
    2.4138355255127, 1.08345317840576, 29.5760669708252, 15.3166275024414, 
    32.2189712524414, 37.8960266113281, 6.37020826339722, 9.49538612365723, 
    2.45201873779297, 2.88756704330444, 2.10256600379944, 26.9133853912354, 
    2.88756704330444, 20.1820430755615, 29.5760669708252, 18.2560348510742, 
    20.1820430755615, 20.1820430755615, 2.10256600379944, 27.1207866668701, 
    26.9133853912354, 20.1820430755615, 12.0960712432861, 32.2189712524414, 
    35.0612525939941, 26.9133853912354, 6.60264539718628, 18.2560348510742, 
    12.0960712432861, 2.88756704330444, NA, 12.931191444397, 15.3166275024414, 
    3.83571290969849, 18.2560348510742, 45.9383239746094, 32.2189712524414, 
    3.83571290969849, 45.9383239746094, 15.3166275024414, 35.0612525939941, 
    18.2560348510742, 2.10256600379944, 2.45201873779297, 27.1207866668701, 
    27.1207866668701, 3.83571290969849, 6.70990943908691, 2.4138355255127, 
    6.60264539718628, 2.4138355255127, 26.9133853912354, 35.0612525939941, 
    10.9932403564453, 6.60264539718628, 12.0960712432861, 18.2560348510742, 
    0.823701620101929, 2.31053566932678, 20.1820430755615, 32.2189712524414, 
    29.5760669708252, 2.45201873779297, 32.2189712524414, 12.0960712432861, 
    27.1207866668701, 1.08345317840576, 18.2560348510742, 6.70990943908691, 
    2.31053566932678, 0.823701620101929, 29.5760669708252, 27.1207866668701, 
    2.41122555732727, 45.9383239746094, 27.1207866668701, 2.31053566932678, 
    18.2560348510742, 10.9932403564453, 6.60264539718628, 18.2560348510742, 
    10.9932403564453, 9.49538612365723, 6.60264539718628, 0.823701620101929, 
    6.60264539718628, NA, 18.2560348510742, 27.1207866668701, 2.45201873779297, 
    2.33129978179932, 6.77630519866943, 45.9383239746094, 32.2189712524414, 
    6.70990943908691, 0.823701620101929, 26.9133853912354, 0.823701620101929, 
    0.823701620101929, 26.9133853912354, NA, 26.9133853912354, 6.70990943908691, 
    18.2560348510742, 2.88756704330444, 32.2189712524414, 20.1820430755615, 
    12.0960712432861, 1.08345317840576, 20.1820430755615, 1.08345317840576, 
    6.60264539718628, 6.77630519866943, 20.1820430755615, 2.10256600379944, 
    12.0960712432861, 10.9932403564453, 2.3965961933136, 6.60264539718628, 
    9.49538612365723, NA, 32.2189712524414, 2.41122555732727, 12.0960712432861, 
    6.60264539718628, 26.9133853912354, 18.2560348510742, 27.1207866668701, 
    37.8960266113281, 0.823701620101929, 6.70990943908691, 6.77630519866943, 
    2.88756704330444, 2.88756704330444, 2.88756704330444, 2.45201873779297, 
    2.4138355255127, 18.2560348510742, 6.37020826339722, 18.2560348510742, 
    26.9133853912354, 20.1820430755615, 2.4138355255127, 2.45201873779297, 
    26.9133853912354, 18.2560348510742, 2.31053566932678, 6.37020826339722, 
    18.2560348510742, 27.1207866668701, 3.83571290969849, 0.823701620101929, 
    6.70990943908691, 18.2560348510742, 6.70990943908691, 37.8960266113281, 
    37.8960266113281, 3.83571290969849, 2.4138355255127, 2.10256600379944, 
    2.45201873779297, 2.88756704330444, 27.1207866668701, 12.0960712432861, 
    0.823701620101929, 27.1207866668701, 0.823701620101929, 20.1820430755615, 
    3.83571290969849, 26.9133853912354, 15.3166275024414, 3.83571290969849, 
    2.88756704330444, 26.9133853912354, 29.5760669708252, 27.1207866668701, 
    9.49538612365723, 2.41122555732727, 12.0960712432861, 6.60264539718628, 
    29.5760669708252, 6.60264539718628, 6.70990943908691, 6.60264539718628, 
    11.1269645690918, 6.60264539718628, 3.83571290969849, 26.9133853912354, 
    6.60264539718628, 27.1207866668701, 6.60264539718628, 3.83571290969849, 
    18.2560348510742, 20.1820430755615, 6.70990943908691, 35.0612525939941, 
    2.10256600379944, 18.2560348510742, 12.0960712432861, 9.49538612365723, 
    29.5760669708252, 27.1207866668701, 3.83571290969849, 37.8960266113281, 
    32.2189712524414, 3.83571290969849, 1.08345317840576, 32.2189712524414, 
    1.08345317840576, 2.88756704330444, 37.8960266113281, 6.60264539718628, 
    26.9133853912354, 18.2560348510742, 0.823701620101929, 9.49538612365723, 
    2.4138355255127, 3.83571290969849, 2.88756704330444, 27.1207866668701, 
    27.1207866668701, 26.9133853912354, 6.70990943908691, 6.60264539718628, 
    27.1207866668701, 9.49538612365723, 3.83571290969849, 12.931191444397, 
    6.60264539718628, 12.0960712432861, 26.9133853912354, 12.0960712432861, 
    2.10256600379944, 32.2189712524414, 6.37020826339722, 6.70990943908691, 
    26.9133853912354, 6.60264539718628, 6.60264539718628, 2.4138355255127, 
    2.45201873779297, 20.1820430755615, 2.45201873779297, 6.60264539718628, 
    6.70990943908691, 32.2189712524414, 2.31053566932678, 6.37020826339722, 
    6.60264539718628, 6.70990943908691, 2.41122555732727, 2.45201873779297, 
    6.37020826339722, 18.2560348510742, 2.3965961933136, 12.0960712432861, 
    2.41122555732727, 6.60264539718628, 2.41122555732727, 6.77630519866943, 
    6.60264539718628, 26.9133853912354, 2.3965961933136, 26.9133853912354, 
    29.5760669708252, 9.49538612365723, NA, 0.823701620101929, 6.60264539718628, 
    NA, 27.1207866668701, 27.1207866668701, 2.10256600379944, 12.0960712432861, 
    NA, 10.9932403564453, 2.41122555732727, 20.1820430755615, 20.1820430755615, 
    6.70990943908691, 1.08345317840576, 27.1207866668701, 9.49538612365723, 
    32.2189712524414, 35.0612525939941, 6.37020826339722, 15.3166275024414, 
    18.2560348510742, 6.37020826339722, 29.5760669708252, 2.88756704330444, 
    26.9133853912354, 27.1207866668701, 35.0612525939941, 2.4138355255127, 
    26.9133853912354, 2.31053566932678, 9.49538612365723, 2.10256600379944, 
    45.9383239746094, 0.823701620101929, 37.8960266113281, 26.9133853912354, 
    NA, 37.8960266113281, 0.823701620101929, 45.9383239746094, 11.1269645690918, 
    18.2560348510742, 2.10256600379944, 6.70990943908691, 6.70990943908691, 
    3.83571290969849, 3.83571290969849, 2.10256600379944, 3.83571290969849, 
    2.4138355255127, 1.08345317840576, 2.31053566932678, 29.5760669708252, 
    NA, 18.2560348510742, 29.5760669708252, NA, 6.70990943908691, 
    2.41122555732727, 2.10256600379944, 6.60264539718628, 18.2560348510742, 
    37.8960266113281, 2.41122555732727, 3.83571290969849, 6.70990943908691, 
    2.31053566932678, 37.8960266113281, 26.9133853912354, 18.2560348510742, 
    6.60264539718628, 6.60264539718628, 27.1207866668701, 32.2189712524414, 
    2.33129978179932, 2.45201873779297, 29.5760669708252, 2.88756704330444, 
    6.77630519866943, 37.8960266113281, 9.49538612365723, 6.70990943908691, 
    20.1820430755615, 32.2189712524414, 2.4138355255127, 12.931191444397, 
    3.83571290969849, 11.1269645690918, 6.37020826339722, 26.9133853912354, 
    37.8960266113281, 6.77630519866943, 27.1207866668701, 27.1207866668701, 
    27.1207866668701, 9.49538612365723, 35.0612525939941, 8.79444408416748, 
    2.33129978179932, 15.3166275024414, 29.5760669708252, 15.3166275024414, 
    2.31053566932678, 2.4138355255127, 11.1269645690918, 20.1820430755615, 
    0.823701620101929, 6.60264539718628, 2.4138355255127, 29.5760669708252, 
    2.4138355255127, 6.70990943908691, 27.1207866668701, 9.49538612365723, 
    18.2560348510742, 26.9133853912354, 18.2560348510742, 26.9133853912354, 
    0.823701620101929, 2.88756704330444, 2.41122555732727, 15.3166275024414, 
    20.1820430755615, 6.70990943908691, 18.2560348510742, 6.60264539718628, 
    10.9932403564453, 6.60264539718628, 20.1820430755615, 2.88756704330444, 
    20.1820430755615, 2.31053566932678, 6.60264539718628, 6.77630519866943, 
    6.70990943908691, 26.9133853912354, 6.37020826339722, 10.9932403564453, 
    6.60264539718628, 6.37020826339722, 18.2560348510742, 2.4138355255127, 
    12.931191444397, 2.3965961933136, 27.1207866668701, 18.2560348510742, 
    20.1820430755615, 26.9133853912354, 29.5760669708252, 6.70990943908691, 
    29.5760669708252, 2.88756704330444, 32.2189712524414, 2.10256600379944, 
    0.823701620101929, 2.88756704330444, 12.0960712432861, 26.9133853912354, 
    2.10256600379944, 18.2560348510742, 6.60264539718628, 27.1207866668701, 
    6.77630519866943, 6.60264539718628, 3.83571290969849, 27.1207866668701, 
    NA, 27.1207866668701, 11.1269645690918, 6.37020826339722, 18.2560348510742, 
    26.9133853912354, 6.60264539718628, 1.08345317840576, 18.2560348510742, 
    1.08345317840576, 27.1207866668701, 6.70990943908691, 29.5760669708252, 
    6.37020826339722, 18.2560348510742, 20.1820430755615, 2.88756704330444, 
    2.31053566932678, 29.5760669708252, 2.4138355255127, 18.2560348510742, 
    2.45201873779297, 2.88756704330444, 6.37020826339722, 3.83571290969849, 
    32.2189712524414, 11.1269645690918, 2.31053566932678, 18.2560348510742, 
    26.9133853912354, 0.823701620101929, 2.4138355255127, 18.2560348510742, 
    27.1207866668701, 2.10256600379944, NA, 6.70990943908691, 11.1269645690918, 
    37.8960266113281, 6.60264539718628, 2.4138355255127, 35.0612525939941, 
    12.0960712432861, 26.9133853912354, 15.3166275024414, 2.41122555732727, 
    6.37020826339722, 0.823701620101929, 2.45201873779297, 6.70990943908691, 
    2.4138355255127, 18.2560348510742, 6.60264539718628, 2.10256600379944, 
    2.3965961933136, 1.08345317840576, 2.45201873779297, 2.33129978179932, 
    26.9133853912354, 26.9133853912354, 2.33129978179932, 45.9383239746094, 
    2.31053566932678, 0.823701620101929, 26.9133853912354, 10.9932403564453, 
    2.88756704330444, 2.45201873779297, 0.823701620101929, 32.2189712524414, 
    18.2560348510742, 1.08345317840576, 2.3965961933136, 18.2560348510742, 
    2.4138355255127, 6.60264539718628, 6.37020826339722, 1.08345317840576, 
    2.3965961933136, 0.823701620101929, 2.41122555732727, 18.2560348510742, 
    18.2560348510742, 35.0612525939941, 32.2189712524414, 1.08345317840576, 
    1.08345317840576, 2.31053566932678, 6.37020826339722, 18.2560348510742, 
    2.4138355255127, 2.33129978179932, 26.9133853912354, 26.9133853912354, 
    20.1820430755615, 2.41122555732727, 0.823701620101929, 6.37020826339722, 
    6.60264539718628, 2.10256600379944, 45.9383239746094, 12.0960712432861, 
    1.08345317840576, 45.9383239746094, 3.83571290969849, 12.931191444397, 
    37.8960266113281, 26.9133853912354, 1.08345317840576, 18.2560348510742, 
    0.823701620101929, 35.0612525939941, 10.9932403564453, 8.79444408416748, 
    6.60264539718628, 26.9133853912354, 2.88756704330444, 2.31053566932678, 
    18.2560348510742, 6.60264539718628, 6.70990943908691, 2.33129978179932, 
    1.08345317840576, 2.88756704330444, 6.60264539718628, 26.9133853912354, 
    9.49538612365723, 2.10256600379944, 18.2560348510742, 20.1820430755615, 
    6.70990943908691, 18.2560348510742, 2.4138355255127, 2.33129978179932, 
    2.88756704330444, 26.9133853912354, 8.79444408416748, 2.33129978179932, 
    2.41122555732727, 6.70990943908691, 2.4138355255127, 12.931191444397, 
    27.1207866668701, 35.0612525939941, 6.60264539718628, 15.3166275024414, 
    2.4138355255127, 26.9133853912354, 10.9932403564453, 2.41122555732727, 
    0.823701620101929, 2.3965961933136, 35.0612525939941, 6.77630519866943, 
    27.1207866668701, 2.3965961933136, 2.88756704330444, 35.0612525939941, 
    18.2560348510742, 27.1207866668701, 32.2189712524414, 2.88756704330444, 
    35.0612525939941, 6.37020826339722, 27.1207866668701, 18.2560348510742, 
    26.9133853912354, 2.10256600379944, 15.3166275024414, 2.3965961933136, 
    18.2560348510742, 2.33129978179932, 26.9133853912354, 2.33129978179932, 
    37.8960266113281, 27.1207866668701, 2.88756704330444, 20.1820430755615, 
    2.33129978179932, 26.9133853912354, 1.08345317840576, 2.45201873779297, 
    6.70990943908691, 2.31053566932678, 6.70990943908691, 6.60264539718628, 
    2.4138355255127, 1.08345317840576, 1.08345317840576, 1.08345317840576, 
    0.823701620101929, 15.3166275024414, 2.10256600379944, 6.37020826339722, 
    0.823701620101929, 2.33129978179932, 6.70990943908691, 2.10256600379944, 
    2.10256600379944, 6.60264539718628, 2.10256600379944, 8.79444408416748, 
    2.33129978179932, 11.1269645690918, 2.4138355255127, 6.77630519866943, 
    32.2189712524414, 18.2560348510742, 27.1207866668701, 2.41122555732727, 
    6.60264539718628, 26.9133853912354, 2.88756704330444, 2.33129978179932, 
    2.33129978179932, 27.1207866668701, 20.1820430755615, 29.5760669708252, 
    2.33129978179932, 2.4138355255127, 6.60264539718628, 26.9133853912354, 
    9.49538612365723, 26.9133853912354, 0.823701620101929, 0.823701620101929, 
    15.3166275024414, 2.4138355255127, 26.9133853912354, 27.1207866668701, 
    27.1207866668701, 6.37020826339722, 2.41122555732727, 18.2560348510742, 
    2.33129978179932, 6.60264539718628, 0.823701620101929, 0.823701620101929, 
    27.1207866668701, 12.0960712432861, 2.33129978179932, 6.70990943908691, 
    0.823701620101929, 26.9133853912354, 45.9383239746094, 2.4138355255127, 
    26.9133853912354, 2.3965961933136, 29.5760669708252, 2.88756704330444, 
    27.1207866668701, 2.88756704330444, 0.823701620101929, 6.70990943908691, 
    27.1207866668701, 35.0612525939941, 45.9383239746094, 29.5760669708252, 
    6.77630519866943, 2.4138355255127, 6.70990943908691, 6.70990943908691, 
    2.4138355255127, 2.33129978179932, 12.931191444397, 2.3965961933136, 
    15.3166275024414, 3.83571290969849, 37.8960266113281, 3.83571290969849, 
    6.60264539718628, 2.3965961933136, 2.4138355255127, 1.08345317840576, 
    0.823701620101929, 6.60264539718628, 32.2189712524414, 2.45201873779297, 
    35.0612525939941, 2.10256600379944, 27.1207866668701, 2.33129978179932, 
    6.60264539718628, 6.77630519866943, 27.1207866668701, 2.45201873779297, 
    18.2560348510742, 2.3965961933136, 3.83571290969849, 2.88756704330444, 
    2.33129978179932, 2.33129978179932, 29.5760669708252, 20.1820430755615, 
    27.1207866668701, 11.1269645690918, 26.9133853912354, 6.70990943908691, 
    11.1269645690918, 2.3965961933136, 6.70990943908691, 6.60264539718628, 
    2.3965961933136, 27.1207866668701, 29.5760669708252, 27.1207866668701, 
    2.10256600379944, 6.60264539718628, 6.60264539718628, 15.3166275024414, 
    2.31053566932678, 6.37020826339722, 6.60264539718628, 2.33129978179932, 
    2.3965961933136, 2.33129978179932, 0.823701620101929, 2.3965961933136, 
    0.823701620101929, 45.9383239746094, 9.49538612365723, 2.33129978179932, 
    NA, 27.1207866668701, 2.4138355255127, 2.4138355255127, 2.3965961933136, 
    2.33129978179932, 2.31053566932678, 6.37020826339722, 2.33129978179932, 
    2.3965961933136, 2.33129978179932, 35.0612525939941, 2.3965961933136, 
    2.88756704330444, 29.5760669708252, 26.9133853912354, 9.49538612365723, 
    2.41122555732727, 3.83571290969849, 37.8960266113281, 2.3965961933136, 
    9.49538612365723, 29.5760669708252, 2.33129978179932, 2.4138355255127, 
    2.33129978179932, 2.33129978179932, 6.60264539718628, 3.83571290969849, 
    26.9133853912354, 20.1820430755615, 10.9932403564453, 27.1207866668701, 
    2.4138355255127, 8.79444408416748, 10.9932403564453, 2.88756704330444, 
    37.8960266113281, 6.70990943908691, 2.10256600379944, 2.3965961933136, 
    8.79444408416748, 45.9383239746094, 2.33129978179932, 32.2189712524414, 
    15.3166275024414, 20.1820430755615, 9.49538612365723, 0.823701620101929, 
    20.1820430755615, 11.1269645690918, 0.823701620101929, 0.823701620101929, 
    29.5760669708252, 9.49538612365723, 20.1820430755615, 35.0612525939941, 
    6.37020826339722, 12.931191444397, 2.10256600379944, 2.41122555732727, 
    8.79444408416748, 2.10256600379944, 8.79444408416748, 37.8960266113281, 
    35.0612525939941, 2.4138355255127, 3.83571290969849, 26.9133853912354, 
    0.823701620101929, 2.3965961933136, 2.3965961933136, 27.1207866668701, 
    27.1207866668701, 27.1207866668701, 10.9932403564453, 6.60264539718628, 
    2.10256600379944, 2.88756704330444, 45.9383239746094, 3.83571290969849, 
    2.10256600379944, 37.8960266113281, 2.10256600379944, 2.3965961933136, 
    27.1207866668701, 35.0612525939941, 2.33129978179932, 12.931191444397, 
    9.49538612365723, 2.3965961933136, 2.10256600379944, 12.931191444397, 
    10.9932403564453, 2.88756704330444, 11.1269645690918, 3.83571290969849, 
    NA, 27.1207866668701, 26.9133853912354, 15.3166275024414, 8.79444408416748, 
    11.1269645690918, 9.49538612365723, 2.45201873779297, 29.5760669708252, 
    8.79444408416748, 10.9932403564453, 45.9383239746094, 2.33129978179932, 
    45.9383239746094, 2.4138355255127, 3.83571290969849, 20.1820430755615, 
    18.2560348510742, 27.1207866668701, 2.41122555732727, 12.0960712432861, 
    2.88756704330444, 0.823701620101929, 2.3965961933136, 12.931191444397, 
    2.3965961933136, 32.2189712524414, 2.4138355255127, 8.79444408416748, 
    2.3965961933136, 1.08345317840576, 32.2189712524414, 9.49538612365723, 
    11.1269645690918, 18.2560348510742, 6.37020826339722, 35.0612525939941, 
    0.823701620101929, 2.10256600379944, 2.10256600379944, 45.9383239746094, 
    2.3965961933136, 11.1269645690918, 6.70990943908691, 15.3166275024414, 
    2.88756704330444, 26.9133853912354, 2.88756704330444, 2.3965961933136, 
    1.08345317840576, 2.31053566932678, 35.0612525939941, 1.08345317840576, 
    2.3965961933136, 6.60264539718628, 2.33129978179932, 37.8960266113281, 
    6.60264539718628, 9.49538612365723, 3.83571290969849, 2.41122555732727, 
    8.79444408416748, 12.931191444397, 8.79444408416748, 2.33129978179932, 
    6.60264539718628, 32.2189712524414, 2.10256600379944, 6.37020826339722, 
    2.3965961933136, 2.88756704330444, 27.1207866668701, 32.2189712524414, 
    2.3965961933136, 15.3166275024414, 27.1207866668701, 2.41122555732727, 
    NA, 18.2560348510742, 29.5760669708252, 27.1207866668701, 2.3965961933136, 
    6.60264539718628, 35.0612525939941, 37.8960266113281, 2.31053566932678, 
    8.79444408416748, 3.83571290969849, 8.79444408416748, 3.83571290969849, 
    26.9133853912354, 2.3965961933136, 6.37020826339722, 12.931191444397, 
    26.9133853912354, 35.0612525939941, 12.931191444397, 2.3965961933136, 
    35.0612525939941, 3.83571290969849, 2.3965961933136, 8.79444408416748, 
    26.9133853912354, 26.9133853912354, 8.79444408416748, 27.1207866668701, 
    45.9383239746094, 2.3965961933136, 26.9133853912354, 45.9383239746094, 
    20.1820430755615, 2.33129978179932, 2.33129978179932, 12.931191444397, 
    26.9133853912354, 2.33129978179932, 2.10256600379944, 27.1207866668701, 
    2.31053566932678, 45.9383239746094, 2.33129978179932, 3.83571290969849, 
    32.2189712524414, 37.8960266113281, 26.9133853912354, 26.9133853912354, 
    8.79444408416748, 20.1820430755615, 20.1820430755615, 1.08345317840576, 
    2.3965961933136, 27.1207866668701, 2.3965961933136, 29.5760669708252, 
    35.0612525939941, 2.10256600379944, 12.931191444397, 45.9383239746094, 
    18.2560348510742, 18.2560348510742, 2.3965961933136, 32.2189712524414, 
    2.88756704330444, 2.31053566932678, 2.3965961933136, 2.3965961933136, 
    32.2189712524414, 26.9133853912354, 2.31053566932678, 1.08345317840576, 
    3.83571290969849, 8.79444408416748, 6.37020826339722, 2.3965961933136, 
    37.8960266113281, 2.10256600379944, 35.0612525939941, 27.1207866668701, 
    2.3965961933136, 8.79444408416748, 8.79444408416748, 8.79444408416748, 
    12.931191444397, 8.79444408416748, 26.9133853912354, 8.79444408416748, 
    8.79444408416748, 27.1207866668701, 8.79444408416748, 20.1820430755615, 
    29.5760669708252, 8.79444408416748, 45.9383239746094, 10.9932403564453, 
    20.1820430755615, 45.9383239746094, 2.3965961933136, 29.5760669708252, 
    8.79444408416748, 2.3965961933136, 8.79444408416748, 20.1820430755615, 
    2.3965961933136, 26.9133853912354, 27.1207866668701, 32.2189712524414, 
    18.2560348510742, 18.2560348510742, 26.9133853912354, 8.79444408416748, 
    8.79444408416748, 27.1207866668701, 8.79444408416748, 8.79444408416748, 
    8.79444408416748, 2.4138355255127, NA, 45.9383239746094, 18.2560348510742, 
    2.88756704330444, 18.2560348510742, 8.79444408416748, 2.3965961933136, 
    29.5760669708252, 6.60264539718628, 29.5760669708252, 2.33129978179932, 
    8.79444408416748, 18.2560348510742, 2.33129978179932, 27.1207866668701, 
    2.3965961933136, 2.10256600379944, 2.33129978179932, 29.5760669708252, 
    8.79444408416748, 29.5760669708252, 35.0612525939941, 26.9133853912354, 
    8.79444408416748, 45.9383239746094, 8.79444408416748, 26.9133853912354, 
    8.79444408416748, 2.3965961933136, 12.0960712432861, 2.10256600379944, 
    8.79444408416748, 2.33129978179932, 8.79444408416748, 2.33129978179932, 
    2.31053566932678, 2.10256600379944, 2.88756704330444, 45.9383239746094, 
    2.3965961933136, 6.60264539718628, 3.83571290969849, 32.2189712524414, 
    6.77630519866943, 8.79444408416748, 2.88756704330444, 2.4138355255127, 
    26.9133853912354, 35.0612525939941, 26.9133853912354, 8.79444408416748, 
    3.83571290969849, 8.79444408416748, 29.5760669708252, 8.79444408416748, 
    26.9133853912354, 2.33129978179932, 35.0612525939941, 2.33129978179932, 
    12.0960712432861, 26.9133853912354, 3.83571290969849, 2.3965961933136, 
    26.9133853912354, 8.79444408416748, 2.33129978179932, 6.60264539718628, 
    6.70990943908691, 2.4138355255127, 2.33129978179932, 2.33129978179932, 
    29.5760669708252, 8.79444408416748, 29.5760669708252, 45.9383239746094, 
    20.1820430755615, 29.5760669708252, 29.5760669708252, 45.9383239746094, 
    2.3965961933136, 8.79444408416748, 2.33129978179932, 20.1820430755615, 
    8.79444408416748, 29.5760669708252, 2.3965961933136, 32.2189712524414, 
    0.823701620101929, 29.5760669708252, 27.1207866668701, 26.9133853912354, 
    8.79444408416748, 29.5760669708252, 2.88756704330444, 35.0612525939941, 
    35.0612525939941, 2.88756704330444, 3.83571290969849, 2.88756704330444, 
    35.0612525939941, 35.0612525939941, 2.88756704330444, 29.5760669708252, 
    35.0612525939941, 8.79444408416748, 2.4138355255127, 6.77630519866943, 
    3.83571290969849, 15.3166275024414, 1.08345317840576, 12.0960712432861, 
    1.08345317840576, 6.60264539718628, 1.08345317840576, 1.08345317840576, 
    27.1207866668701, 6.60264539718628, 45.9383239746094, 2.31053566932678, 
    6.60264539718628, 2.88756704330444, 1.08345317840576, 1.08345317840576, 
    2.88756704330444, 1.08345317840576, 45.9383239746094, 2.31053566932678, 
    6.60264539718628, 2.4138355255127, 6.60264539718628, 27.1207866668701, 
    2.41122555732727, 6.60264539718628, 2.41122555732727, 15.3166275024414, 
    6.60264539718628, 2.31053566932678, 2.4138355255127, 2.10256600379944, 
    2.88756704330444, 8.79444408416748, 6.77630519866943, 6.77630519866943, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 2.65048766136169, 
    3.08845138549805, 2.84084796905518, 2.7748544216156, 6.84822177886963, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, 2.85901069641113, 2.85901069641113, 2.85901069641113, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 1.86964964866638, 
    1.86964964866638, 1.86964964866638, 1.86964964866638, 1.86964964866638, 
    1.86964964866638, 1.86964964866638, 1.86964964866638, 1.86964964866638, 
    1.86964964866638, 1.86964964866638, 1.86964964866638, 1.86964964866638, 
    1.86964964866638, 1.86964964866638, 1.86964964866638, 1.86964964866638, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 2.66860222816467, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, 4.16919851303101, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, 7.20080327987671, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 3, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    3.76768445968628, 3.76768445968628, 3.76768445968628, 3.76768445968628, 
    3.76768445968628, 3.76768445968628, 3.76768445968628, 3.76768445968628, 
    3.76768445968628, 3.76768445968628, 3.76768445968628, 3.76768445968628, 
    3.76768445968628, 3.76768445968628, 3.76768445968628, 3.76768445968628, 
    3.76768445968628, 3.76768445968628, 3.76768445968628, 3.76768445968628, 
    3.76768445968628, 3.76768445968628, 3.76768445968628, 3.76768445968628, 
    3.76768445968628, 3.76768445968628, 3.76768445968628, 3.76768445968628, 
    3.76768445968628, 3.76768445968628, 3.76768445968628, 3.76768445968628, 
    3.76768445968628, 3.76768445968628, 3.76768445968628, 3.76768445968628, 
    3.76768445968628, 3.76768445968628, 3.76768445968628, 3.76768445968628, 
    3.76768445968628, 3.76768445968628, 3.76768445968628, 3.76768445968628, 
    3.76768445968628, 3.76768445968628, 3.76768445968628, 3.76768445968628, 
    3.76768445968628, 3.76768445968628, 3.76768445968628, 3.76768445968628, 
    3.76768445968628, 3.76768445968628, 3.76768445968628, 3.76768445968628, 
    3.76768445968628, 3.76768445968628, 3.76768445968628, 3.76768445968628, 
    3.76768445968628, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, 3, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 3, 3, 3, 3, 3, 3, 
    3, 3, 3, 3, 3, 3, 3, 6.75787973403931, 6.75787973403931, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, 3, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, 2.70424032211304, 2.70424032211304, 2.70424032211304, 
    2.70424032211304, 4.61707639694214, 2.09489607810974, 2.09489607810974, 
    2.09489607810974, 2.09489607810974, 2.09489607810974, 2.09489607810974, 
    5.29422330856323, 5.29422330856323, 5.29422330856323, 3.41922450065613, 
    3.41922450065613, NA, NA, NA, NA, NA, NA, 2.98469018936157, 2.98469018936157, 
    2.98469018936157, 2.98469018936157, 2.98469018936157, 2.98469018936157, 
    2.98469018936157, 2.98469018936157, 2.98469018936157, 2.98469018936157, 
    2.98469018936157, 2.98469018936157, 2.98469018936157, 2.98469018936157, 
    2.98469018936157, 2.98469018936157, 2.98469018936157, 2.98469018936157, 
    2.98469018936157, 2.98469018936157, 2.98469018936157, 2.98469018936157, 
    2.98469018936157, 2.98469018936157, 2.98469018936157, 2.98469018936157, 
    2.98469018936157, 2.98469018936157, 2.98469018936157, 2.98469018936157, 
    2.98469018936157, 2.98469018936157, 2.98469018936157, 2.98469018936157, 
    2.98469018936157, 2.98469018936157, 2.98469018936157, 2.98469018936157, 
    2.98469018936157, 2.98469018936157, 2.98469018936157, 2.98469018936157, 
    2.98469018936157, 2.98469018936157, 2.98469018936157, 2.98469018936157, 
    2.98469018936157, 2.98469018936157, 2.98469018936157, 2.98469018936157, 
    2.98469018936157, 2.98469018936157, 2.98469018936157, 2.98469018936157, 
    2.98469018936157, 2.98469018936157, 2.98469018936157, 2.98469018936157, 
    2.98469018936157, 2.98469018936157, 2.98469018936157, 2.98469018936157, 
    2.98469018936157, 2.98469018936157, 2.98469018936157, 2.98469018936157, 
    2.98469018936157, 2.98469018936157, 2.98469018936157, 2.98469018936157, 
    2.98469018936157, 2.98469018936157, 2.98469018936157, 2.98469018936157, 
    2.98469018936157, 2.98469018936157, 2.98469018936157, 2.98469018936157, 
    2.98469018936157, 2.98469018936157, 2.98469018936157, 2.98469018936157, 
    2.98469018936157, 2.98469018936157, 2.98469018936157, 2.98469018936157, 
    2.98469018936157, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, 3.79788756370544, 2.35819268226624, 2.35819268226624, NA, 
    NA, NA, NA, 1.95378232002258, 1.95378232002258, 1.95378232002258, 
    1.95378232002258, 1.95378232002258, 1.95378232002258, 1.95378232002258, 
    1.95378232002258, 1.95378232002258, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, 5.01203203201294, 5.01203203201294, 
    5.01203203201294, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 9.49320793151855, 
    NA, NA, NA, 4.92572116851807, 4.92572116851807, 4.92572116851807, 
    4.92572116851807, 4.92572116851807, 4.92572116851807, 4.92572116851807, 
    4.92572116851807, 4.92572116851807, 4.92572116851807, 4.92572116851807, 
    4.92572116851807, 4.92572116851807, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 7.21587085723877, 
    7.21587085723877, 7.21587085723877, 7.21587085723877, 7.21587085723877, 
    7.21587085723877, 7.21587085723877, 7.21587085723877, 7.21587085723877, 
    7.21587085723877, 7.21587085723877, 7.21587085723877, 7.21587085723877, 
    7.21587085723877, 7.21587085723877, 7.21587085723877, 7.21587085723877, 
    7.21587085723877, 7.21587085723877, 7.21587085723877, 7.21587085723877, 
    7.21587085723877, 6.26480150222778, 6.26480150222778, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 14.6800994873047, 
    14.6800994873047, 3, 3, 3, NA, 14.6800994873047, 14.6800994873047, 
    NA, 3, 3, 14.6800994873047, NA, 14.6800994873047, 14.6800994873047, 
    14.6800994873047, 14.6800994873047, 14.6800994873047, 14.6800994873047, 
    3, NA, NA, 14.6800994873047, 14.6800994873047, 14.6800994873047, 
    14.6800994873047, NA, 14.6800994873047, 14.6800994873047, 3, 
    3, 14.6800994873047, 14.6800994873047, 14.6800994873047, 14.6800994873047, 
    NA, 3, 14.6800994873047, NA, NA, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, 4.07582998275757, 4.07582998275757, 4.07582998275757, 
    4.07582998275757, 4.07582998275757, 4.07582998275757, 4.07582998275757, 
    4.07582998275757, 4.07582998275757, 2.32011580467224, 2.32011580467224, 
    NA, NA),
  c(NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 4.30986309051514, 
    4.30986309051514, 4.30986309051514, 4.30986309051514, 4.30986309051514, 
    4.30986309051514, 4.30986309051514, 4.30986309051514, 4.30986309051514, 
    4.30986309051514, 4.30986309051514, 4.30986309051514, 4.30986309051514, 
    4.30986309051514, 4.30986309051514, 4.30986309051514, 4.30986309051514, 
    4.30986309051514, 4.30986309051514, 4.30986309051514, 4.30986309051514, 
    4.30986309051514, 4.30986309051514, 4.30986309051514, 4.30986309051514, 
    4.30986309051514, 4.30986309051514, 4.30986309051514, 4.30986309051514, 
    4.30986309051514, 4.30986309051514, 4.30986309051514, 4.30986309051514, 
    4.30986309051514, 4.30986309051514, 4.30986309051514, 4.30986309051514, 
    4.30986309051514, 4.30986309051514, 4.30986309051514, 4.30986309051514, 
    4.30986309051514, 4.30986309051514, 4.30986309051514, 4.30986309051514, 
    4.30986309051514, 4.30986309051514, 4.30986309051514, 4.30986309051514, 
    4.30986309051514, 4.30986309051514, 4.30986309051514, 4.30986309051514, 
    4.30986309051514, 4.30986309051514, 4.30986309051514, 4.30986309051514, 
    4.30986309051514, 4.30986309051514, 4.30986309051514, NA, NA, 
    NA, NA, NA, NA, NA, NA, 3.98686575889587, 3.98686575889587, 3.98686575889587, 
    3.98686575889587, 3.98686575889587, 3.98686575889587, 3.98686575889587, 
    NA, NA, NA, NA, 3.98686575889587, 3.98686575889587, 3.00582647323608, 
    3.00582647323608, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, 3.77895379066467, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 3.02535462379456, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, 3.58806014060974, 3.58806014060974, 3.58806014060974, 
    3.58806014060974, 3.58806014060974, 3.58806014060974, 3.58806014060974, 
    3.58806014060974, 3.58806014060974, 3.58806014060974, 3.58806014060974, 
    3.58806014060974, 3.58806014060974, 3.58806014060974, 3.58806014060974, 
    3.58806014060974, 3.58806014060974, 3.58806014060974, 3.58806014060974, 
    3.58806014060974, 3.58806014060974, 3.58806014060974, 3.58806014060974, 
    3.58806014060974, 3.58806014060974, 3.58806014060974, 3.58806014060974, 
    3.58806014060974, 3.58806014060974, 3.58806014060974, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    5.37714815139771, 5.37714815139771, 5.37714815139771, 5.37714815139771, 
    5.37714815139771, 5.37714815139771, 5.37714815139771, 5.37714815139771, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, 6.03890419006348, 5.77593469619751, 5.77593469619751, 
    5.77593469619751, NA, NA, NA, 4.39588928222656, NA, 5.42286682128906, 
    5.42286682128906, 5.42286682128906, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 5.22044849395752, NA, 
    7.12789249420166, 7.12789249420166, 7.12789249420166, 7.12789249420166, 
    7.12789249420166, 7.12789249420166, 7.12789249420166, 7.12789249420166, 
    7.12789249420166, 7.12789249420166, 7.12789249420166, 7.12789249420166, 
    7.12789249420166, 7.12789249420166, 7.12789249420166, 7.12789249420166, 
    7.12789249420166, 7.12789249420166, 4.63164234161377, 4.63164234161377, 
    4.63164234161377, 4.63164234161377, 4.63164234161377, 4.63164234161377, 
    4.63164234161377, 4.63164234161377, 4.63164234161377, 4.63164234161377, 
    4.63164234161377, 4.63164234161377, 4.63164234161377, 4.63164234161377, 
    4.63164234161377, 4.63164234161377, 4.63164234161377, 4.63164234161377, 
    4.63164234161377, 4.63164234161377, 4.63164234161377, 4.63164234161377, 
    4.63164234161377, 4.63164234161377, 4.63164234161377, 4.63164234161377, 
    4.63164234161377, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, 1.43824875354767, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, 4.50906133651733, 4.50906133651733, 
    4.50906133651733, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, 6.23552417755127, 3.87042570114136, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, 7.78996086120605, 7.78996086120605, 
    7.78996086120605, 7.78996086120605, 7.78996086120605, NA, 4.40398645401001, 
    NA, NA, NA, 8.46162986755371, 8.46162986755371, 8.46162986755371, 
    8.46162986755371, 8.46162986755371, 8.46162986755371, 8.46162986755371, 
    8.46162986755371, 8.46162986755371, 8.46162986755371, 8.46162986755371, 
    8.46162986755371, 8.46162986755371, 8.46162986755371, 8.46162986755371, 
    8.46162986755371, 8.46162986755371, 8.46162986755371, 8.46162986755371, 
    8.46162986755371, 8.46162986755371, NA, NA, 4.23725700378418, 
    4.23725700378418, 4.23725700378418, 4.23725700378418, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, 4.57299327850342, 4.57299327850342, 4.57299327850342, 
    4.57299327850342, 4.57299327850342, 4.57299327850342, 4.57299327850342, 
    4.57299327850342, 4.57299327850342, 4.57299327850342, 4.57299327850342, 
    4.57299327850342, NA, NA, NA, 2.75578141212463, 2.75578141212463, 
    2.75578141212463, 2.75578141212463, 2.75578141212463, 2.75578141212463, 
    2.75578141212463, 2.75578141212463, 2.75578141212463, 2.75578141212463, 
    3.82935571670532, 2.75578141212463, 2.75578141212463, 2.75578141212463, 
    2.75578141212463, 2.75578141212463, 2.75578141212463, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, 5.35872030258179, 5.35872030258179, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, 3.35177636146545, 3.35177636146545, 3.7307333946228, 
    3.7307333946228, 3.7307333946228, 3.7307333946228, 3.7307333946228, 
    3.7307333946228, 3.7307333946228, 3.7307333946228, 3.7307333946228, 
    3.7307333946228, 3.7307333946228, 3.7307333946228, 3.7307333946228, 
    3.7307333946228, 3.7307333946228, 3.7307333946228, 3.7307333946228, 
    3.7307333946228, 3.7307333946228, 3.7307333946228, 3.7307333946228, 
    3.7307333946228, 3.7307333946228, 3.7307333946228, 3.7307333946228, 
    3.7307333946228, 3.7307333946228, 3.7307333946228, 3.7307333946228, 
    3.7307333946228, 3.7307333946228, 3.7307333946228, 3.7307333946228, 
    3.7307333946228, 3.7307333946228, 3.7307333946228, 3.7307333946228, 
    3.7307333946228, 3.7307333946228, 3.7307333946228, 3.7307333946228, 
    3.7307333946228, 3.7307333946228, 3.7307333946228, 3.7307333946228, 
    3.7307333946228, 3.7307333946228, 3.7307333946228, 3.7307333946228, 
    3.7307333946228, 3.7307333946228, 3.7307333946228, 3.7307333946228, 
    3.7307333946228, 3.7307333946228, 3.7307333946228, 3.7307333946228, 
    3.7307333946228, 3.7307333946228, 3.7307333946228, 3.7307333946228, 
    3.7307333946228, 3.7307333946228, 3.7307333946228, 3.7307333946228, 
    3.7307333946228, 3.7307333946228, NA, NA, NA, 4.13275575637817, 
    4.13275575637817, 4.13275575637817, 4.13275575637817, 4.13275575637817, 
    NA, NA, NA, NA, 5.52040672302246, 5.52040672302246, 5.52040672302246, 
    5.52040672302246, 5.52040672302246, 5.52040672302246, 5.52040672302246, 
    5.52040672302246, NA, NA, NA, 7.59481859207153, 7.59481859207153, 
    7.59481859207153, 3.93865060806274, 3.93865060806274, 3.93865060806274, 
    3.93865060806274, 3.93865060806274, 3.93865060806274, 3.93865060806274, 
    3.93865060806274, 3.93865060806274, 3.93865060806274, 3.93865060806274, 
    NA, NA, NA, 3.93865060806274, 3.93865060806274, 3.93865060806274, 
    3.93865060806274, 3.93865060806274, 3.93865060806274, 3.93865060806274, 
    3.93865060806274, NA, 3.93865060806274, NA, NA, NA, NA, NA, NA, 
    NA, 3.93865060806274, NA, NA, 3.93865060806274, NA, 3.93865060806274, 
    3.93865060806274, 3.93865060806274, 3.93865060806274, 3.93865060806274, 
    3.93865060806274, 3.93865060806274, 3.93865060806274, 3.93865060806274, 
    3.93865060806274, NA, NA, NA, NA, NA, 3.93865060806274, 3.93865060806274, 
    NA, NA, NA, 6.28768491744995, 6.28768491744995, 6.28768491744995, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, 5.02803039550781, 5.02803039550781, 
    5.02803039550781, 5.02803039550781, 5.02803039550781, 5.02803039550781, 
    5.02803039550781, 5.02803039550781, 5.02803039550781, 5.02803039550781, 
    5.02803039550781, 5.02803039550781, 5.02803039550781, 5.02803039550781, 
    4.08529043197632, 8.29484558105469, 8.29484558105469, 8.29484558105469, 
    8.29484558105469, 8.29484558105469, 8.29484558105469, 8.29484558105469, 
    8.29484558105469, 8.29484558105469, 8.29484558105469, 8.29484558105469, 
    8.29484558105469, 8.29484558105469, 8.29484558105469, 8.29484558105469, 
    8.29484558105469, 8.29484558105469, 6.56168699264526, 6.56168699264526, 
    6.56168699264526, 6.56168699264526, 6.56168699264526, 6.56168699264526, 
    6.56168699264526, 6.56168699264526, 6.56168699264526, 6.56168699264526, 
    6.56168699264526, 6.56168699264526, 6.56168699264526, 6.56168699264526, 
    6.56168699264526, 6.56168699264526, 6.56168699264526, 6.56168699264526, 
    6.56168699264526, 6.56168699264526, 6.56168699264526, 6.56168699264526, 
    6.56168699264526, 6.56168699264526, 6.56168699264526, NA, NA, 
    NA, 7.13395357131958, 7.13395357131958, 7.13395357131958, 7.13395357131958, 
    7.13395357131958, 7.13395357131958, 7.13395357131958, 7.13395357131958, 
    7.13395357131958, 7.13395357131958, 7.13395357131958, 7.13395357131958, 
    7.13395357131958, 7.13395357131958, 7.13395357131958, 7.13395357131958, 
    7.13395357131958, 7.13395357131958, 7.13395357131958, 7.13395357131958, 
    7.13395357131958, 7.13395357131958, 7.13395357131958, 7.13395357131958, 
    7.13395357131958, 7.13395357131958, NA, NA, NA, NA, 7.13395357131958, 
    7.13395357131958, 7.13395357131958, 7.13395357131958, 7.13395357131958, 
    7.13395357131958, 7.13395357131958, 7.13395357131958, 7.13395357131958, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, 7.13395357131958, 7.13395357131958, 
    7.13395357131958, 7.13395357131958, NA, NA, NA, 7.13395357131958, 
    7.13395357131958, NA, NA, NA, 7.13395357131958, 7.13395357131958, 
    7.13395357131958, 7.13395357131958, 7.13395357131958, 7.13395357131958, 
    7.13395357131958, 7.13395357131958, NA, NA, 7.13395357131958, 
    7.13395357131958, 7.13395357131958, 7.13395357131958, 7.13395357131958, 
    7.13395357131958, 7.13395357131958, 7.13395357131958, 7.13395357131958, 
    7.13395357131958, 7.13395357131958, 7.13395357131958, 7.13395357131958, 
    7.13395357131958, 7.13395357131958, 7.13395357131958, 7.13395357131958, 
    7.13395357131958, 7.13395357131958, 7.13395357131958, 7.13395357131958, 
    7.13395357131958, 7.13395357131958, 7.13395357131958, 7.13395357131958, 
    7.13395357131958, 7.13395357131958, NA, NA, NA, 7.13395357131958, 
    7.13395357131958, 7.13395357131958, 7.13395357131958, 7.13395357131958, 
    7.13395357131958, 7.13395357131958, 7.13395357131958, 7.13395357131958, 
    7.13395357131958, 7.13395357131958, 7.13395357131958, 7.13395357131958, 
    7.13395357131958, 7.13395357131958, 7.13395357131958, 7.13395357131958, 
    7.13395357131958, 7.13395357131958, 7.13395357131958, 7.13395357131958, 
    7.13395357131958, 7.13395357131958, 7.13395357131958, 7.13395357131958, 
    7.13395357131958, 7.13395357131958, NA, NA, NA, NA, NA, NA, 7.13395357131958, 
    7.13395357131958, 7.13395357131958, 7.13395357131958, 7.13395357131958, 
    7.13395357131958, 7.13395357131958, 7.13395357131958, 7.13395357131958, 
    7.13395357131958, 7.13395357131958, 7.13395357131958, 7.13395357131958, 
    7.13395357131958, 7.13395357131958, 7.13395357131958, 7.13395357131958, 
    7.13395357131958, NA, NA, NA, NA, NA, NA, NA, NA, 5.74348783493042, 
    5.74348783493042, 5.74348783493042, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, 5.74348783493042, NA, 5.74348783493042, 5.74348783493042, 
    5.74348783493042, 5.74348783493042, NA, 5.74348783493042, 5.74348783493042, 
    NA, 5.74348783493042, NA, NA, 5.74348783493042, 5.74348783493042, 
    5.74348783493042, 5.74348783493042, 5.74348783493042, 5.74348783493042, 
    5.74348783493042, 5.74348783493042, 5.74348783493042, 9.09463977813721, 
    9.09463977813721, 9.09463977813721, 9.09463977813721, 9.09463977813721, 
    NA, 5.74348783493042, 5.74348783493042, NA, NA, NA, NA, 5.74348783493042, 
    NA, 5.74348783493042, NA, 5.74348783493042, 5.74348783493042, 
    5.74348783493042, 5.74348783493042, NA, 5.74348783493042, 5.74348783493042, 
    5.74348783493042, 5.74348783493042, 5.74348783493042, 5.74348783493042, 
    5.74348783493042, 5.74348783493042, 9.09463977813721, 9.09463977813721, 
    9.09463977813721, 5.74348783493042, 5.74348783493042, 5.74348783493042, 
    5.74348783493042, 5.74348783493042, 5.74348783493042, NA, NA, 
    5.74348783493042, 5.74348783493042, 5.74348783493042, 5.74348783493042, 
    5.74348783493042, 5.74348783493042, NA, 5.74348783493042, 5.74348783493042, 
    5.74348783493042, 5.74348783493042, 5.74348783493042, 5.74348783493042, 
    5.74348783493042, 5.74348783493042, 5.74348783493042, 5.74348783493042, 
    5.74348783493042, NA, NA, 5.97513103485107, NA, NA, NA, NA, 6.86173486709595, 
    8.22707462310791, 6.64044094085693, 6.64044094085693, 6.64044094085693, 
    6.64044094085693, 6.64044094085693, 6.64044094085693, 6.64044094085693, 
    6.64044094085693, 6.64044094085693, 6.64044094085693, 6.64044094085693, 
    6.64044094085693, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 13.5328016281128, 13.5328016281128, 
    13.5328016281128, 13.5328016281128, 13.5328016281128, 13.5328016281128, 
    13.5328016281128, 13.5328016281128, 13.5328016281128, 13.5328016281128, 
    13.5328016281128, 13.5328016281128, 13.5328016281128, 13.5328016281128, 
    NA, NA, NA, NA, NA, NA, NA, 6.6658787727356, 6.6658787727356, 
    6.6658787727356, 6.6658787727356, 6.6658787727356, 6.6658787727356, 
    6.6658787727356, 6.6658787727356, 6.6658787727356, 6.6658787727356, 
    6.6658787727356, 6.6658787727356, 6.6658787727356, 6.6658787727356, 
    6.6658787727356, 6.6658787727356, 6.6658787727356, 6.6658787727356, 
    6.6658787727356, 6.6658787727356, 6.6658787727356, 6.6658787727356, 
    6.6658787727356, 6.6658787727356, 6.6658787727356, 6.6658787727356, 
    6.6658787727356, 6.6658787727356, 6.6658787727356, 6.6658787727356, 
    6.6658787727356, 6.6658787727356, 6.6658787727356, 6.6658787727356, 
    6.6658787727356, 6.6658787727356, 6.6658787727356, 6.6658787727356, 
    6.6658787727356, 6.6658787727356, 6.6658787727356, 6.6658787727356, 
    6.6658787727356, 6.6658787727356, 6.6658787727356, 6.6658787727356, 
    6.6658787727356, 6.6658787727356, 6.6658787727356, 6.6658787727356, 
    6.6658787727356, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, 5.57331609725952, 17.2213306427002, 
    NA, NA, NA, NA, NA, 2, 2, 2, 2, 2, 2, 2, 2, 2, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, NA, 
    NA, NA, NA, NA, NA, NA, NA, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 
    2, 2, NA, NA, NA, NA, NA, NA, NA, NA, NA, 3, NA, NA, NA, NA, 
    NA, 3, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, 3, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 2.28555607795715, 2.28555607795715, 
    2.28555607795715, NA, NA, 2.28555607795715, 2.28555607795715, 
    2.28555607795715, 2.28555607795715, 2.28555607795715, NA, 2.28555607795715, 
    2.28555607795715, NA, 2.28555607795715, NA, 8.72966957092285, 
    2.28555607795715, 2.28555607795715, 2.28555607795715, 2.28555607795715, 
    2.28555607795715, NA, NA, NA, NA, NA, 2.28555607795715, 2.28555607795715, 
    NA, NA, NA, NA, NA, 16.7982940673828, 8.72966957092285, 16.7982940673828, 
    NA, NA, NA, 8.72966957092285, 8.72966957092285, 8.72966957092285, 
    8.72966957092285, 8.72966957092285, 8.72966957092285, NA, NA, 
    NA, NA, 16.7982940673828, NA, 8.72966957092285, 8.72966957092285, 
    NA, NA, NA, 16.7982940673828, 8.72966957092285, 8.72966957092285, 
    16.7982940673828, 16.7982940673828, 8.72966957092285, 8.72966957092285, 
    8.72966957092285, 8.72966957092285, 8.72966957092285, 8.72966957092285, 
    8.72966957092285, 8.72966957092285, 8.72966957092285, 8.72966957092285, 
    8.72966957092285, 2.28555607795715, NA, NA, NA, 2.28555607795715, 
    8.72966957092285, 8.72966957092285, 8.72966957092285, 8.72966957092285, 
    8.72966957092285, 8.72966957092285, 8.72966957092285, 8.72966957092285, 
    8.72966957092285, 8.72966957092285, 16.7982940673828, 16.7982940673828, 
    8.72966957092285, 8.72966957092285, 8.72966957092285, NA, NA, 
    NA, NA, 8.72966957092285, 8.72966957092285, 8.72966957092285, 
    NA, NA, NA, NA, NA, NA, NA, 8.72966957092285, 8.72966957092285, 
    NA, 2.28555607795715, 2.28555607795715, NA, 2.28555607795715, 
    8.72966957092285, 2.28555607795715, 2.28555607795715, NA, NA, 
    NA, NA, NA, 2.28555607795715, NA, 3, 8.72966957092285, 8.72966957092285, 
    8.72966957092285, 8.72966957092285, 8.72966957092285, 8.72966957092285, 
    8.72966957092285, 8.72966957092285, 8.72966957092285, 8.72966957092285, 
    8.72966957092285, 8.72966957092285, 8.72966957092285, 8.72966957092285, 
    8.72966957092285, 8.72966957092285, 8.72966957092285, 8.72966957092285, 
    8.72966957092285, 8.72966957092285, 8.72966957092285, 8.72966957092285, 
    8.72966957092285, 8.72966957092285, 8.72966957092285, 8.72966957092285, 
    8.72966957092285, 8.72966957092285, 8.72966957092285, 8.72966957092285, 
    8.72966957092285, 8.72966957092285, 8.72966957092285, 8.72966957092285, 
    8.72966957092285, 8.72966957092285, 8.72966957092285, 8.72966957092285, 
    8.72966957092285, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, 16.7982940673828, 8.72966957092285, 8.72966957092285, 
    NA, NA, NA, NA, NA, 8.72966957092285, 8.72966957092285, NA, 16.7982940673828, 
    16.7982940673828, 2.28555607795715, NA, NA, NA, NA, NA, 8.72966957092285, 
    8.72966957092285, NA, NA, NA, 2.28555607795715, 2.28555607795715, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 16.7982940673828, 
    NA, 8.72966957092285, 8.72966957092285, NA, NA, NA, NA, NA, NA, 
    NA, 16.7982940673828, 8.72966957092285, 8.72966957092285, NA, 
    NA, NA, NA, 2.28555607795715, NA, NA, NA, NA, NA, NA, NA, 8.72966957092285, 
    NA, NA, 16.7982940673828, 16.7982940673828, NA, NA, NA, 16.7982940673828, 
    NA, NA, NA, NA, NA, NA, 2.28555607795715, NA, NA, 8.72966957092285, 
    NA, 1, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 16.4257869720459, 
    16.4257869720459, NA, 16.4257869720459, 16.4257869720459, 16.4257869720459, 
    16.4257869720459, 16.4257869720459, 16.4257869720459, 16.4257869720459, 
    16.4257869720459, 16.4257869720459, 16.4257869720459, 16.4257869720459, 
    16.4257869720459, 16.4257869720459, 16.4257869720459, 16.4257869720459, 
    16.4257869720459, 16.4257869720459, 16.4257869720459, 16.4257869720459, 
    NA, 16.4257869720459, 16.4257869720459, 16.4257869720459, 16.4257869720459, 
    16.4257869720459, 16.4257869720459, 16.4257869720459, 16.4257869720459, 
    16.4257869720459, 16.4257869720459, 16.4257869720459, 16.4257869720459, 
    16.4257869720459, 16.4257869720459, 16.4257869720459, 16.4257869720459, 
    16.4257869720459, 16.4257869720459, 16.4257869720459, 16.4257869720459, 
    16.4257869720459, 16.4257869720459, 16.4257869720459, 16.4257869720459, 
    16.4257869720459, 16.4257869720459, 16.4257869720459, 16.4257869720459, 
    NA, 16.4257869720459, 16.4257869720459, 16.4257869720459, 16.4257869720459, 
    16.4257869720459, 16.4257869720459, 16.4257869720459, 16.4257869720459, 
    NA, 16.4257869720459, NA, 16.4257869720459, 16.4257869720459, 
    16.4257869720459, 16.4257869720459, 16.4257869720459, 16.4257869720459, 
    16.4257869720459, 16.4257869720459, 16.4257869720459, 16.4257869720459, 
    NA, 16.4257869720459, NA, NA, NA, 16.4257869720459, 16.4257869720459, 
    16.4257869720459, 16.4257869720459, 16.4257869720459, 16.4257869720459, 
    16.4257869720459, NA, NA, 16.4257869720459, 16.4257869720459, 
    16.4257869720459, 16.4257869720459, 16.4257869720459, 16.4257869720459, 
    16.4257869720459, 16.4257869720459, 16.4257869720459, 16.4257869720459, 
    NA, NA, 16.4257869720459, 16.4257869720459, NA, 16.4257869720459, 
    NA, NA, 16.4257869720459, NA, 16.4257869720459, 16.4257869720459, 
    16.4257869720459, 16.4257869720459, 16.4257869720459, 16.4257869720459, 
    16.4257869720459, NA, 16.4257869720459, NA, 16.4257869720459, 
    16.4257869720459, 16.4257869720459, 16.4257869720459, 16.4257869720459, 
    16.4257869720459, 16.4257869720459, 16.4257869720459, 16.4257869720459, 
    16.4257869720459, 16.4257869720459, 16.4257869720459, 16.4257869720459, 
    16.4257869720459, 16.4257869720459, 16.4257869720459, 16.4257869720459, 
    16.4257869720459, 16.4257869720459, 16.4257869720459, 16.4257869720459, 
    16.4257869720459, 16.4257869720459, 16.4257869720459, 16.4257869720459, 
    16.4257869720459, 16.4257869720459, 16.4257869720459, 16.4257869720459, 
    NA, NA, NA, NA, 16.4257869720459, 16.4257869720459, 16.4257869720459, 
    NA, 16.4257869720459, 16.4257869720459, 16.4257869720459, 16.4257869720459, 
    16.4257869720459, NA, NA, NA, 6.74433851242065, 6.74433851242065, 
    6.74433851242065, 6.74433851242065, 6.74433851242065, 6.74433851242065, 
    6.74433851242065, 6.74433851242065, 6.74433851242065, 6.74433851242065, 
    6.74433851242065, 6.74433851242065, 6.74433851242065, 6.74433851242065, 
    6.74433851242065, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, 3, 3, 3, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 3, 3, NA, NA, 
    3, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, 3, 3, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, 3, 3, 3, NA, NA, NA, NA, 3, 3, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, 11.1082906723022, 11.1082906723022, 11.1082906723022, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, 2.57168030738831, 2.57168030738831, 2.57168030738831, 
    2.57168030738831, 2.57168030738831, 2.57168030738831, 2.57168030738831, 
    2.57168030738831, 2.57168030738831, 2.57168030738831, 2.57168030738831, 
    2.57168030738831, NA, NA, NA, NA, NA, NA, 26.6084804534912, 26.6084804534912, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, 9.42660236358643, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, 31.384485244751, 31.384485244751, 
    31.384485244751, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, 33.2790946960449, 33.2790946960449, 
    33.2790946960449, 31.7101898193359, 31.7101898193359, 31.7101898193359, 
    31.7101898193359, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 17.5931777954102, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 24.9721641540527, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    2, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 22.5557041168213, 
    22.5557041168213, NA, NA, NA, 2, 2, NA, NA, NA, NA, NA, NA, NA, 
    NA, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 6.62251281738281, 
    6.62251281738281, 6.62251281738281, 6.62251281738281, 6.62251281738281, 
    6.62251281738281, 6.62251281738281, 6.62251281738281, 6.62251281738281, 
    6.62251281738281, 6.62251281738281, 6.62251281738281, 6.62251281738281, 
    6.62251281738281, 6.62251281738281, 6.62251281738281, 6.62251281738281, 
    6.62251281738281, 6.62251281738281, 6.62251281738281, 6.62251281738281, 
    6.62251281738281, 6.62251281738281, 6.62251281738281, 6.62251281738281, 
    6.62251281738281, 2.56834292411804, 2.56834292411804, 2.56834292411804, 
    2.56834292411804, 2.56834292411804, 2.56834292411804, 2.56834292411804, 
    2.56834292411804, 2.56834292411804, 2.56834292411804, 2.56834292411804, 
    NA, NA, NA, 2, 2, 2, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, 2.74649286270142, 2.74649286270142, 10.0106620788574, 10.0106620788574, 
    10.0106620788574, 10.0106620788574, 10.0106620788574, 10.0106620788574, 
    10.0106620788574, 10.0106620788574, 10.0106620788574, 2, 2, 2, 
    2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, 2, 2, NA, NA, NA, NA, NA, NA, 24.2535800933838, 24.2535800933838, 
    24.2535800933838, 24.2535800933838, 24.2535800933838, 24.2535800933838, 
    24.2535800933838, 24.2535800933838, 24.2535800933838, 24.2535800933838, 
    24.2535800933838, 24.2535800933838, 24.2535800933838, 24.2535800933838, 
    24.2535800933838, 24.2535800933838, 24.2535800933838, 24.2535800933838, 
    24.2535800933838, 24.2535800933838, 24.2535800933838, 24.2535800933838, 
    24.2535800933838, 24.2535800933838, 24.2535800933838, 24.2535800933838, 
    24.2535800933838, 24.2535800933838, 24.2535800933838, 24.2535800933838, 
    24.2535800933838, 24.2535800933838, 24.2535800933838, 24.2535800933838, 
    2, 2, 2, 2, 1.91488003730774, 1.91488003730774, 1.91488003730774, 
    1.91488003730774, 1.91488003730774, 1.91488003730774, 1.91488003730774, 
    1.91488003730774, 1.91488003730774, 1.91488003730774, 1.91488003730774, 
    1.91488003730774, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, 2, 2, 2, 2, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 8.56975841522217, 
    8.56975841522217, 8.56975841522217, 8.56975841522217, 8.56975841522217, 
    8.56975841522217, 8.56975841522217, 8.56975841522217, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 2, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 1.92817807197571, 
    1.92817807197571, 1.92817807197571, 1.92817807197571, 1.92817807197571, 
    1.92817807197571, 1.92817807197571, 1.92817807197571, 1.92817807197571, 
    1.92817807197571, 1.92817807197571, 1.92817807197571, 1.92817807197571, 
    1.92817807197571, 1.92817807197571, 1.92817807197571, 1.92817807197571, 
    1.92817807197571, 1.92817807197571, 1.92817807197571, 45.7548027038574, 
    2.74032831192017, 2.74032831192017, 2.74032831192017, 2.74032831192017, 
    2.74032831192017, 2.74032831192017, 2.74032831192017, 2.74032831192017, 
    2.74032831192017, 2.74032831192017, 2.74032831192017, 2.74032831192017, 
    2.74032831192017, 2.74032831192017, 2.74032831192017, 2.74032831192017, 
    2.74032831192017, 2.74032831192017, 2.74032831192017, 2.74032831192017, 
    2.74032831192017, 2.74032831192017, 2.74032831192017, 2.74032831192017, 
    2.74032831192017, 2.74032831192017, 3.4499614238739, 3.4499614238739, 
    3.4499614238739, 3.4499614238739, 3.4499614238739, 3.4499614238739, 
    3.4499614238739, 3.4499614238739, 3.4499614238739, 3.4499614238739, 
    3.4499614238739, 3.4499614238739, 5.4, 5.4, 5.4, 5.4, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, 3, 3, 3, 3, 3, 3, 3, 3, NA, NA, 24.2535800933838, 
    24.2535800933838, 24.2535800933838, 24.2535800933838, 24.2535800933838, 
    24.2535800933838, 24.2535800933838, 24.2535800933838, 24.2535800933838, 
    24.2535800933838, 24.2535800933838, 24.2535800933838, 24.2535800933838, 
    24.2535800933838, 2.58767127990723, 2.58767127990723, 2.58767127990723, 
    2.00839877128601, 2.00839877128601, 2.00839877128601, 2.00839877128601, 
    2.00839877128601, 2.00839877128601, 2.00839877128601, 2.00839877128601, 
    2.00839877128601, 2.00839877128601, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, 33.3249778747559, 33.3249778747559, 
    33.3249778747559, 33.3249778747559, 33.3249778747559, 33.3249778747559, 
    33.3249778747559, 33.3249778747559, 33.3249778747559, 33.3249778747559, 
    33.3249778747559, 2.74873280525208, 2.74873280525208, 2.74873280525208, 
    2.74873280525208, 2.74873280525208, 2.74873280525208, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 7.48709869384766, 7.48709869384766, 
    7.48709869384766, 7.48709869384766, 7.48709869384766, NA, NA, 
    3.75924396514893, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 2.56834292411804, NA, 
    NA, NA, NA, NA, 3.89028573036194, 3.89028573036194, 3.89028573036194, 
    3.89028573036194, 3.89028573036194, 3.89028573036194, 3.89028573036194, 
    2.54248833656311, 2.54248833656311, 2.54248833656311, NA, 10.7376689910889, 
    8.06049823760986, NA, 11.4165287017822, 6.62251281738281, 6.62251281738281, 
    6.62251281738281, 6.62251281738281, 6.62251281738281, 6.62251281738281, 
    27.8903999328613, 27.8903999328613, 27.8903999328613, 6.25273990631104, 
    6.62251281738281, 6.62251281738281, 6.62251281738281, NA, 2, 
    2, 2, 2, 2, 2.49990606307983, 2.49990606307983, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, 0.837284922599792, 2, 2, 10.0106620788574, 
    67.9408111572266, NA, NA, NA, NA, NA, 73.8814239501953, NA, 40.0247192382812, 
    67.9408111572266, NA, NA, NA, NA, NA, 12.9708995819092, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 12.9708995819092, 
    NA, NA, NA, NA, NA, NA, NA, 12.779317855835, 12.779317855835, 
    12.779317855835, 12.779317855835, 27.8903999328613, 27.8903999328613, 
    27.8903999328613, 27.8903999328613, 27.8903999328613, 27.8903999328613, 
    27.8903999328613, 27.8903999328613, 27.8903999328613, 27.8903999328613, 
    27.8903999328613, 27.8903999328613, 27.8903999328613, 27.8903999328613, 
    27.8903999328613, 27.8903999328613, 27.8903999328613, 27.8903999328613, 
    27.8903999328613, 27.8903999328613, 27.8903999328613, 27.8903999328613, 
    27.8903999328613, 27.8903999328613, 27.8903999328613, 27.8903999328613, 
    27.8903999328613, 27.8903999328613, 27.8903999328613, 27.8903999328613, 
    27.8903999328613, 27.8903999328613, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 2, 
    2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA),
  c(NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 3.29310631752014, 
    3.29310631752014, 3.29310631752014, 3.29310631752014, 3.29310631752014, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 3.29310631752014, 
    3.29310631752014, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
    NA, NA, NA, NA, NA, NA, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 5.31567478179932, 5.31567478179932, 5.31567478179932, 
    5.31567478179932, 8.2303466796875, 10.4503526687622, 12.4822282791138, 
    10.4503526687622, 11.0592489242554, 13.3054208755493, 9.90894603729248, 
    8.88764953613281, 9.22435474395752, 9.83372116088867, 13.3054208755493, 
    10.4503526687622, 9.22435474395752, 11.0683422088623, 10.4503526687622, 
    8.2303466796875, 12.4822282791138, 12.4822282791138, 13.3054208755493, 
    13.3054208755493, 13.4645929336548, 9.22435474395752, 9.90894603729248, 
    NA, 11.0683422088623, 11.0592489242554, 13.3054208755493, 13.3054208755493, 
    9.22435474395752, 10.8271951675415, NA, NA, 13.3054208755493, 
    13.3054208755493, 12.4822282791138, 10.4503526687622, 8.2303466796875, 
    NA, 10.8271951675415, 8.21176815032959, NA, 13.3054208755493, 
    13.3054208755493, 9.83372116088867, 2.21209073066711, 13.4645929336548, 
    13.3054208755493, 13.3054208755493, 13.3054208755493, 13.3054208755493, 
    NA, 10.4503526687622, 13.4645929336548, 8.88764953613281, 13.4645929336548, 
    10.4503526687622, 10.8271951675415, NA, 2.23508191108704, 13.3054208755493, 
    8.2303466796875, 10.4503526687622, NA, NA, 13.3054208755493, 
    2.25702857971191, 11.0592489242554, 10.6333713531494, 10.8271951675415, 
    NA, NA, 10.6333713531494, NA, 2.22239232063293, 9.90894603729248, 
    2.21170902252197, 13.3054208755493, 10.8271951675415, 9.90894603729248, 
    10.8271951675415, 10.4503526687622, NA, 8.21176815032959, NA, 
    13.3054208755493, 10.8271951675415, 9.90894603729248, NA, 13.4645929336548, 
    10.4503526687622, 8.88764953613281, 9.90894603729248, 9.90894603729248, 
    10.8271951675415, 2.23210120201111, NA, NA, 11.0592489242554, 
    NA, 13.3054208755493, 2.23210120201111, 13.4645929336548, 10.8271951675415, 
    NA, NA, 10.4503526687622, 10.4503526687622, 10.4503526687622, 
    13.3054208755493, 10.8271951675415, 13.4645929336548, 10.4503526687622, 
    2.19766998291016, 11.0592489242554, 13.3054208755493, NA, NA, 
    NA, NA, 10.4503526687622, 13.3054208755493, 9.90894603729248, 
    2.19140577316284, 10.4503526687622, 10.8271951675415, 10.4503526687622, 
    NA, 10.8271951675415, 9.90894603729248, 13.3054208755493, 10.5675477981567, 
    NA, NA, 13.4645929336548, 10.8271951675415, 13.3054208755493, 
    13.3054208755493, 13.3054208755493, 2.19601655006409, 10.6333713531494, 
    2.248206615448, NA, NA, 8.88764953613281, NA, 13.3054208755493, 
    9.22435474395752, 10.8271951675415, 2.25702857971191, NA, 13.4645929336548, 
    2.21209073066711, 8.2303466796875, 9.90894603729248, NA, NA, 
    2.19140577316284, NA, 2.19140577316284, 10.8271951675415, 10.8271951675415, 
    NA, 13.3054208755493, 13.4645929336548, 11.5358457565308, NA, 
    NA, 10.8271951675415, 9.83372116088867, 2.26027250289917, 13.3054208755493, 
    10.6333713531494, NA, 12.4822282791138, 10.8271951675415, 2.20265436172485, 
    10.8271951675415, 11.0592489242554, 2.23210120201111, 2.20265436172485, 
    11.0592489242554, 11.0683422088623, NA, 2.17654180526733, 11.0683422088623, 
    NA, 2.21170902252197, 8.2303466796875, 12.4822282791138, 10.5675477981567, 
    10.5675477981567, 13.3054208755493, 10.4503526687622, NA, 13.3054208755493, 
    2.23508191108704, 2.23508191108704, 12.4822282791138, 11.5358457565308, 
    10.8271951675415, 13.3054208755493, NA, NA, NA, NA, 10.8271951675415, 
    13.4645929336548, NA, NA, NA, 13.4645929336548, 13.3054208755493, 
    9.83372116088867, 11.0683422088623, 9.90894603729248, 2.19601655006409, 
    10.8271951675415, 11.0683422088623, 8.88764953613281, 11.0683422088623, 
    13.4645929336548, 8.2303466796875, 10.4503526687622, 13.3054208755493, 
    10.4503526687622, 2.21170902252197, 2.19766998291016, NA, 9.22435474395752, 
    11.0592489242554, 10.8271951675415, NA, NA, 10.8271951675415, 
    2.248206615448, 8.2303466796875, 13.3054208755493, 10.8271951675415, 
    11.5358457565308, 10.4503526687622, 12.4822282791138, 8.21176815032959, 
    2.23508191108704, NA, 8.88764953613281, 13.3054208755493, NA, 
    10.4503526687622, NA, 10.8271951675415, 2.22239232063293, 8.21176815032959, 
    NA, 9.83372116088867, NA, 2.21209073066711, NA, 13.4645929336548, 
    NA, NA, 9.83372116088867, 9.90894603729248, 13.4645929336548, 
    13.4645929336548, 2.23349380493164, 13.3054208755493, 13.3054208755493, 
    13.4645929336548, NA, 8.88764953613281, 10.8271951675415, 11.5358457565308, 
    NA, 13.4645929336548, 2.19601655006409, 2.19140577316284, 13.3054208755493, 
    10.8271951675415, 2.17654180526733, 8.88764953613281, NA, 13.3054208755493, 
    10.8271951675415, 9.22435474395752, 2.23508191108704, NA, NA, 
    10.8271951675415, NA, 10.4503526687622, 13.4645929336548, 10.4503526687622, 
    8.21176815032959, 9.22435474395752, NA, 2.23508191108704, NA, 
    13.4645929336548, 11.0592489242554, 2.248206615448, 2.23210120201111, 
    13.3054208755493, 2.21209073066711, NA, 10.8271951675415, 10.8271951675415, 
    13.3054208755493, 9.90894603729248, 13.3054208755493, 9.90894603729248, 
    11.5358457565308, 10.4503526687622, NA, NA, 2.19601655006409, 
    11.0592489242554, 10.6333713531494, 10.4503526687622, NA, 10.4503526687622, 
    10.8271951675415, NA, 2.22239232063293, NA, NA, 8.2303466796875, 
    NA, NA, 10.4503526687622, 10.4503526687622, 8.21176815032959, 
    NA, 2.19140577316284, NA, NA, NA, 9.22435474395752, NA, 10.5675477981567, 
    10.5675477981567, 11.0592489242554, NA, 13.3054208755493, 13.4645929336548, 
    NA, 2.26027250289917, 9.83372116088867, 8.2303466796875, 13.3054208755493, 
    13.3054208755493, 11.0683422088623, 9.90894603729248, 8.21176815032959, 
    2.20850968360901, NA, NA, 2.25702857971191, 9.22435474395752, 
    2.21170902252197, 2.22239232063293, NA, 2.21209073066711, 2.21170902252197, 
    NA, 8.88764953613281, NA, 2.23508191108704, NA, 2.21170902252197, 
    10.4503526687622, 13.3054208755493, 2.20987129211426, NA, 13.3054208755493, 
    8.2303466796875, 9.90894603729248, NA, 2.26027250289917, NA, 
    2.20265436172485, 11.5358457565308, NA, 2.20850968360901, NA, 
    10.4503526687622, 2.21170902252197, 2.26027250289917, 10.4503526687622, 
    NA, 13.3054208755493, 2.20850968360901, 13.3054208755493, 13.4645929336548, 
    10.8271951675415, NA, NA, NA, 10.8271951675415, NA, 11.5358457565308, 
    11.0592489242554, 13.4645929336548, 10.8271951675415, NA, 11.0592489242554, 
    10.8271951675415, NA, NA, 11.0683422088623, 2.20850968360901, 
    2.23508191108704, 10.5675477981567, 13.4645929336548, 11.5358457565308, 
    10.8271951675415, 10.6333713531494, 2.19766998291016, NA, 8.88764953613281, 
    8.21176815032959, NA, 2.21170902252197, 10.8271951675415, NA, 
    8.2303466796875, 13.3054208755493, 10.4503526687622, 2.20265436172485, 
    NA, 13.4645929336548, 2.19140577316284, 13.4645929336548, 8.88764953613281, 
    13.4645929336548, 10.8271951675415, 13.4645929336548, 13.3054208755493, 
    12.4822282791138, NA, 2.23349380493164, NA, NA, 13.4645929336548, 
    2.23210120201111, NA, NA, NA, 9.22435474395752, 13.4645929336548, 
    NA, 8.21176815032959, 2.20850968360901, 13.4645929336548, NA, 
    10.4503526687622, NA, 2.19140577316284, 2.22239232063293, 13.3054208755493, 
    NA, 8.88764953613281, 2.17654180526733, 13.4645929336548, 10.8271951675415, 
    2.25702857971191, 10.8271951675415, 13.4645929336548, 2.22239232063293, 
    NA, 8.88764953613281, 13.3054208755493, 2.21170902252197, 2.19601655006409, 
    8.2303466796875, NA, 10.4503526687622, 13.4645929336548, NA, 
    NA, 13.4645929336548, 12.4822282791138, 9.83372116088867, 10.8271951675415, 
    NA, 2.23349380493164, 9.83372116088867, 12.4822282791138, 11.5358457565308, 
    13.4645929336548, 10.4503526687622, NA, 13.3054208755493, 10.4503526687622, 
    2.26027250289917, 2.19766998291016, NA, NA, NA, 9.22435474395752, 
    2.23210120201111, 2.248206615448, 2.17654180526733, 9.90894603729248, 
    2.248206615448, 13.3054208755493, NA, 13.3054208755493, 10.6333713531494, 
    10.8271951675415, 2.21209073066711, 8.21176815032959, 2.19140577316284, 
    10.8271951675415, 10.8271951675415, 13.3054208755493, 10.8271951675415, 
    NA, 13.3054208755493, 2.21209073066711, 2.22239232063293, NA, 
    11.0683422088623, 10.4503526687622, 2.23508191108704, 2.23508191108704, 
    9.22435474395752, 8.88764953613281, 13.3054208755493, NA, 2.17654180526733, 
    13.3054208755493, 10.4503526687622, 10.8271951675415, 2.20987129211426, 
    10.8271951675415, NA, NA, NA, 10.6333713531494, 2.20987129211426, 
    11.0683422088623, 13.3054208755493, 10.8271951675415, NA, 10.8271951675415, 
    10.8271951675415, 11.0592489242554, 2.20850968360901, NA, 2.19601655006409, 
    2.248206615448, NA, NA, 10.5675477981567, 13.3054208755493, 9.83372116088867, 
    NA, 2.23210120201111, NA, NA, NA, 2.23508191108704, 13.4645929336548, 
    13.3054208755493, 11.0592489242554, 2.23349380493164, 2.20987129211426, 
    2.20265436172485, 2.20850968360901, 2.19766998291016, 2.19140577316284, 
    2.19766998291016, 10.8271951675415, 13.4645929336548, NA, 9.83372116088867, 
    10.6333713531494, 10.8271951675415, 10.4503526687622, NA, 13.3054208755493, 
    NA, 8.88764953613281, NA, 2.17654180526733, 13.3054208755493, 
    2.19140577316284, NA, NA, NA, 13.4645929336548, 11.0592489242554, 
    NA, 10.5675477981567, 2.20987129211426, 2.19766998291016, 8.2303466796875, 
    2.23210120201111, 13.3054208755493, NA, NA, 13.4645929336548, 
    NA, 2.248206615448, 11.0683422088623, NA, 11.0683422088623, 13.4645929336548, 
    2.19766998291016, NA, 10.5675477981567, 11.0592489242554, NA, 
    NA, 13.3054208755493, 9.90894603729248, 2.26027250289917, NA, 
    13.4645929336548, 2.23210120201111, 2.20265436172485, 13.4645929336548, 
    2.26027250289917, 2.19601655006409, 10.8271951675415, 10.6333713531494, 
    9.11795711517334, NA, 9.90894603729248, 11.5358457565308, 2.17654180526733, 
    13.4645929336548, 11.7926549911499, 10.8271951675415, NA, 2.23508191108704, 
    NA, NA, NA, 10.8271951675415, 13.3054208755493, 2.23508191108704, 
    2.20850968360901, 11.0683422088623, 13.3054208755493, 10.8271951675415, 
    10.8271951675415, 13.3054208755493, 13.4645929336548, 12.4822282791138, 
    13.4645929336548, 12.4822282791138, 13.4645929336548, 2.19140577316284, 
    NA, NA, NA, 2.25702857971191, 2.19140577316284, 9.11795711517334, 
    NA, 11.3721113204956, 13.3054208755493, NA, 10.8271951675415, 
    10.4503526687622, 10.8271951675415, NA, 10.8271951675415, 2.19601655006409, 
    10.8271951675415, 8.88764953613281, 10.8271951675415, 11.0592489242554, 
    2.248206615448, NA, 2.21170902252197, 13.3054208755493, 13.3054208755493, 
    11.0683422088623, 2.19140577316284, 10.6333713531494, NA, NA, 
    9.11795711517334, 10.4503526687622, 13.4645929336548, 10.8271951675415, 
    13.4645929336548, NA, 2.23210120201111, 13.3054208755493, 9.90894603729248, 
    2.26027250289917, 11.3721113204956, 13.3054208755493, 9.90894603729248, 
    NA, NA, 10.8271951675415, 11.5358457565308, 13.4645929336548, 
    13.3054208755493, 8.21176815032959, 2.23508191108704, 2.22239232063293, 
    10.8271951675415, 2.23210120201111, NA, 10.8271951675415, 8.21176815032959, 
    NA, 11.0592489242554, 13.3054208755493, 2.19140577316284, 11.0592489242554, 
    8.2303466796875, 2.21170902252197, 2.248206615448, 11.3721113204956, 
    9.22435474395752, 2.23349380493164, NA, 10.8271951675415, 13.4645929336548, 
    9.11795711517334, 10.8271951675415, 2.19140577316284, NA, 2.26027250289917, 
    2.21209073066711, 13.4645929336548, 8.21176815032959, 13.4645929336548, 
    11.0592489242554, 2.17654180526733, 11.0592489242554, NA, NA, 
    8.21176815032959, 8.88764953613281, 9.22435474395752, 9.11795711517334, 
    2.20850968360901, 8.2303466796875, 11.7926549911499, NA, 10.4503526687622, 
    2.19140577316284, 8.88764953613281, 13.3054208755493, 13.3054208755493, 
    NA, 10.8271951675415, NA, 2.20265436172485, NA, NA, NA, 9.83372116088867, 
    10.8271951675415, 8.21176815032959, 2.23210120201111, 9.90894603729248, 
    2.17654180526733, 2.20850968360901, 8.21176815032959, 2.20850968360901, 
    2.21170902252197, 2.19601655006409, 11.5358457565308, 2.20265436172485, 
    8.2303466796875, 10.8271951675415, 10.8271951675415, 13.3054208755493, 
    NA, 13.3054208755493, NA, 10.8271951675415, 13.3054208755493, 
    10.8271951675415, 13.3054208755493, 2.21209073066711, 2.20987129211426, 
    NA, 2.248206615448, 9.90894603729248, 2.20850968360901, NA, 2.248206615448, 
    2.19140577316284, NA, 2.19140577316284, 10.5675477981567, 13.3054208755493, 
    11.0683422088623, 11.0683422088623, 9.11795711517334, 13.4645929336548, 
    13.3054208755493, 11.0592489242554, 13.3054208755493, 10.8271951675415, 
    10.8271951675415, NA, 2.20987129211426, 13.3054208755493, 2.22239232063293, 
    10.4503526687622, 11.0592489242554, 2.19766998291016, 2.20850968360901, 
    2.21170902252197, 13.3054208755493, 9.90894603729248, 10.8271951675415, 
    NA, 2.19140577316284, 13.4645929336548, 2.20850968360901, NA, 
    10.4503526687622, 8.21176815032959, 8.2303466796875, NA, 13.3054208755493, 
    13.4645929336548, 10.8271951675415, 10.8271951675415, 13.3054208755493, 
    10.8271951675415, NA, 2.19601655006409, 2.22239232063293, 11.0683422088623, 
    9.90894603729248, 13.3054208755493, NA, 8.88764953613281, NA, 
    2.23508191108704, 8.21176815032959, 2.20265436172485, 2.19140577316284, 
    9.22435474395752, 2.20850968360901, 11.5358457565308, 9.22435474395752, 
    NA, NA, 12.4822282791138, 9.11795711517334, 10.4503526687622, 
    9.90894603729248, 10.4503526687622, 11.3721113204956, 8.72981071472168, 
    11.7926549911499, 10.4503526687622, 13.3054208755493, 2.23508191108704, 
    9.90894603729248, 10.8271951675415, 9.90894603729248, 9.11795711517334, 
    10.4503526687622, 11.3721113204956, NA, 8.21176815032959, NA, 
    11.5358457565308, 12.4822282791138, 13.4645929336548, 9.90894603729248, 
    8.88764953613281, 2.23210120201111, 2.248206615448, 13.3054208755493, 
    9.90894603729248, 2.20265436172485, 8.2303466796875, 2.21209073066711, 
    10.5675477981567, 10.4503526687622, 2.22239232063293, 2.20265436172485, 
    10.8271951675415, 9.22435474395752, NA, 8.2303466796875, 2.21170902252197, 
    2.20850968360901, 2.22239232063293, 8.21176815032959, 11.7926549911499, 
    8.2303466796875, 8.88764953613281, 10.8271951675415, 9.22435474395752, 
    13.4645929336548, 2.19601655006409, 11.0592489242554, 12.4822282791138, 
    NA, NA, 10.5675477981567, 10.4503526687622, 10.4503526687622, 
    10.8271951675415, 10.4503526687622, 8.21176815032959, 11.3721113204956, 
    2.23508191108704, 11.7926549911499, 8.88764953613281, 11.0683422088623, 
    9.83372116088867, 2.248206615448, NA, 8.21176815032959, NA, 9.83372116088867, 
    10.8271951675415, 9.22435474395752, 2.20987129211426, 11.0592489242554, 
    NA, 13.4645929336548, 2.20850968360901, 2.23349380493164, 2.21170902252197, 
    2.20987129211426, 2.20265436172485, 2.23349380493164, 8.88764953613281, 
    9.22435474395752, 10.6333713531494, NA, 11.0592489242554, NA, 
    10.8271951675415, 11.3721113204956, 10.8271951675415, 2.20987129211426, 
    9.90894603729248, 2.20987129211426, 2.19601655006409, 2.23210120201111, 
    2.248206615448, 10.6333713531494, 8.21176815032959, 2.26027250289917, 
    9.22435474395752, 11.0683422088623, 10.6333713531494, 9.90894603729248, 
    NA, 2.21209073066711, 2.20850968360901, 9.83372116088867, 2.20850968360901, 
    2.20850968360901, 2.20850968360901, 8.2303466796875, 9.22435474395752, 
    10.4503526687622, 10.5675477981567, 2.23210120201111, 11.0683422088623, 
    2.23349380493164, 2.20850968360901, 2.23508191108704, 11.0592489242554, 
    2.23508191108704, 10.5675477981567, 2.22239232063293, 10.6333713531494, 
    2.23508191108704, 2.19140577316284, 11.0683422088623, 10.4503526687622, 
    8.21176815032959, 13.3054208755493, 8.2303466796875, 9.11795711517334, 
    10.5675477981567, 11.5358457565308, 8.88764953613281, 8.72981071472168, 
    NA, 11.0683422088623, 8.88764953613281, NA, 11.0592489242554, 
    13.3054208755493, 2.20265436172485, 11.0683422088623, 2.19766998291016, 
    9.83372116088867, 8.88764953613281, 13.4645929336548, 11.0683422088623, 
    2.20265436172485, 13.4645929336548, 8.88764953613281, 2.23210120201111, 
    13.3054208755493, 9.83372116088867, 2.21170902252197, 2.19140577316284, 
    9.83372116088867, NA, 9.22435474395752, 8.2303466796875, 8.72981071472168, 
    10.8271951675415, 10.4503526687622, 11.0683422088623, 11.3721113204956, 
    2.19601655006409, 2.19140577316284, 8.72981071472168, 10.4503526687622, 
    9.11795711517334, NA, NA, NA, 2.20850968360901, 13.3054208755493, 
    NA, 2.22239232063293, 2.21170902252197, 9.22435474395752, 2.19140577316284, 
    2.23349380493164, 2.20850968360901, 2.20850968360901, 9.11795711517334, 
    9.90894603729248, NA, 11.0592489242554, 9.83372116088867, 11.0683422088623, 
    9.83372116088867, 13.4645929336548, 9.22435474395752, 2.20987129211426, 
    2.20987129211426, 2.20265436172485, 2.23210120201111, 9.22435474395752, 
    9.22435474395752, 8.2303466796875, 10.5675477981567, 2.19140577316284, 
    2.21170902252197, 2.19601655006409, 11.3721113204956, 2.248206615448, 
    2.19601655006409, 10.4503526687622, 9.90894603729248, 2.20987129211426, 
    8.2303466796875, 8.21176815032959, 2.20987129211426, 2.19140577316284, 
    2.20987129211426, 11.0592489242554, 11.0683422088623, 2.20850968360901, 
    2.20850968360901, 2.19601655006409, 2.20850968360901, 11.3721113204956, 
    2.19601655006409, 9.83372116088867, 9.22435474395752, 11.0592489242554, 
    13.3054208755493, 2.19140577316284, 2.19140577316284, 8.21176815032959, 
    NA, 2.19140577316284, 10.4503526687622, 13.4645929336548, 10.6333713531494, 
    2.22239232063293, 2.23508191108704, 2.20850968360901, 9.22435474395752, 
    8.21176815032959, 2.21170902252197, 11.0592489242554, 13.3054208755493, 
    8.21176815032959, 10.6333713531494, 10.6333713531494, NA, 10.5675477981567, 
    2.22239232063293, NA, 2.20265436172485, 2.19140577316284, 11.3721113204956, 
    13.3054208755493, 2.23210120201111, 2.19601655006409, 8.88764953613281, 
    2.20265436172485, 2.19601655006409, 2.19601655006409, 2.19140577316284, 
    12.4822282791138, 13.3054208755493, 12.4822282791138, 2.248206615448, 
    8.2303466796875, 9.90894603729248, 9.11795711517334, 8.2303466796875, 
    13.3054208755493, NA, 11.0683422088623, 2.23508191108704, NA, 
    8.2303466796875, 2.17654180526733, 9.22435474395752, 11.5358457565308, 
    2.19601655006409, 12.4822282791138, 13.4645929336548, 8.88764953613281, 
    2.22239232063293, 11.5358457565308, 10.5675477981567, 2.19140577316284, 
    10.8271951675415, 13.4645929336548, 2.23349380493164, 2.25702857971191, 
    8.21176815032959, 10.4503526687622, 2.248206615448, 10.6333713531494, 
    NA, 2.20850968360901, NA, 2.248206615448, 10.6333713531494, 2.21209073066711, 
    2.19140577316284, 2.21170902252197, 11.7926549911499, 11.7926549911499, 
    11.0683422088623, 2.20850968360901, 9.22435474395752, 2.248206615448, 
    2.248206615448, 11.3721113204956, 12.4822282791138, 9.83372116088867, 
    2.26027250289917, 9.90894603729248, 13.4645929336548, 8.88764953613281, 
    NA, 2.23210120201111, 2.248206615448, 11.0683422088623, 2.20850968360901, 
    10.6333713531494, 9.90894603729248, 2.20850968360901, 10.8271951675415, 
    9.11795711517334, 2.23210120201111, 2.23349380493164, 2.23508191108704, 
    13.4645929336548, 9.83372116088867, 2.19601655006409, 2.23508191108704, 
    12.4822282791138, 2.23349380493164, NA, NA, 9.90894603729248, 
    10.8271951675415, 2.20850968360901, 8.72981071472168, 2.20265436172485, 
    10.4503526687622, 12.4822282791138, 9.22435474395752, 10.5675477981567, 
    2.248206615448, NA, 2.20850968360901, 11.7926549911499, 10.4503526687622, 
    2.19601655006409, 2.19140577316284, 8.21176815032959, 2.23349380493164, 
    10.4503526687622, 2.22239232063293, 11.0683422088623, 2.20850968360901, 
    9.11795711517334, 8.2303466796875, 9.90894603729248, 9.22435474395752, 
    2.19766998291016, NA, 13.4645929336548, 10.5675477981567, 13.4645929336548, 
    10.4503526687622, 10.4503526687622, 11.5358457565308, 13.4645929336548, 
    2.21209073066711, 13.3054208755493, 2.23508191108704, 10.8271951675415, 
    2.19140577316284, 2.22239232063293, 13.4645929336548, 11.5358457565308, 
    10.6333713531494, 2.20987129211426, 9.11795711517334, 8.2303466796875, 
    10.4503526687622, 13.3054208755493, 10.5675477981567, 11.0592489242554, 
    9.83372116088867, 2.19766998291016, 2.23349380493164, 10.8271951675415, 
    10.4503526687622, 2.20987129211426, 9.22435474395752, 2.23210120201111, 
    10.4503526687622, 13.3054208755493, 13.3054208755493, 10.8271951675415, 
    10.8271951675415, 13.4645929336548, NA, 8.0387601852417, 6.66747808456421, 
    6.08842039108276, 7.08579874038696, 6.36139392852783, 5.88427782058716, 
    8.58236598968506, 7.7702522277832, 7.26948213577271, 6.08842039108276, 
    8.44301128387451, 5.88427782058716, 6.66747808456421, 7.29503440856934, 
    6.88642168045044, 5.88427782058716, 6.36139392852783, 6.08962440490723, 
    5.43175840377808, 8.49756908416748, 6.88642168045044, 6.08842039108276, 
    8.49756908416748, 6.08842039108276, 6.08962440490723, 6.32296323776245, 
    6.08962440490723, 6.69394540786743, 8.13191413879395, 8.49756908416748, 
    6.049973487854, 6.88642168045044, 6.049973487854, 8.5859317779541, 
    7.29503440856934, 7.29503440856934, 5.88427782058716, 5.43175840377808, 
    7.7702522277832, 8.44301128387451, 6.08962440490723, 6.08962440490723, 
    6.08842039108276, 7.74177837371826, 6.69394540786743, 7.74177837371826, 
    7.29503440856934, 7.00500679016113, 6.32296323776245, 8.5859317779541, 
    6.08962440490723, 6.36139392852783, 6.08962440490723, 6.08962440490723, 
    6.88642168045044, 6.32296323776245, 5.08998727798462, 8.58236598968506, 
    7.08579874038696, 6.08842039108276, 10.5390634536743, 10.5390634536743, 
    10.5390634536743, 10.5390634536743, 10.5390634536743, 10.5390634536743, 
    10.5390634536743, 10.5390634536743, 10.5390634536743, 10.5390634536743, 
    10.5390634536743, 10.5390634536743, 10.5390634536743, 10.5390634536743, 
    10.5390634536743, 10.5390634536743, 10.5390634536743, 10.5390634536743, 
    10.5390634536743, 10.5390634536743, 10.5390634536743, 10.5390634536743, 
    10.5390634536743, 10.5390634536743, 10.5390634536743, 10.5390634536743, 
    10.5390634536743, 10.5390634536743, 10.5390634536743, 10.5390634536743, 
    10.5390634536743, 10.5390634536743, 10.5390634536743, 10.5390634536743, 
    10.5390634536743, 10.5390634536743, 10.5390634536743, 10.5390634536743, 
    10.5390634536743, 10.5390634536743, 10.5390634536743, 10.5390634536743, 
    10.5390634536743, 10.5390634536743, 10.5390634536743, 10.5390634536743, 
    10.5390634536743, 10.5390634536743, 10.5390634536743, 10.5390634536743, 
    10.5390634536743, 10.5390634536743, 10.5390634536743, 10.5390634536743, 
    10.5390634536743, 10.5390634536743, 10.5390634536743, 10.5390634536743, 
    10.5390634536743, 10.5390634536743, 10.5390634536743, 10.5390634536743, 
    10.5390634536743, 10.5390634536743, 10.5390634536743, 10.5390634536743, 
    10.5390634536743, 10.5390634536743, 10.5390634536743, 10.5390634536743, 
    10.5390634536743, 10.5390634536743, 10.5390634536743, 10.5390634536743, 
    10.5390634536743, 10.5390634536743, 10.5390634536743, 10.5390634536743, 
    10.5390634536743, 10.5390634536743, 10.5390634536743, 10.5390634536743, 
    10.5390634536743, 10.5390634536743, 10.5390634536743, 10.5390634536743, 
    10.5390634536743, 10.5390634536743, 10.5390634536743, 10.5390634536743, 
    10.5390634536743, 10.5390634536743, 2.31458950042725, 2.31458950042725, 
    2.31458950042725, 2.31458950042725, 2.31458950042725, 2.31458950042725, 
    2.31458950042725, 2.31458950042725, 2.31458950042725, 2.31458950042725, 
    2.31458950042725, 2.31458950042725, 2.31458950042725, 2.31458950042725, 
    2.31458950042725, 2.31458950042725, 2.31458950042725, 2.31458950042725, 
    2.31458950042725, 2.31458950042725, 2.31458950042725, 2.31458950042725, 
    2.31458950042725, 2.31458950042725, 2.31458950042725, 2.31458950042725, 
    2.31458950042725, 2.31458950042725, 2.31458950042725, 2.31458950042725, 
    2.31458950042725, 2.31458950042725, 2.31458950042725, 2.31458950042725, 
    2.31458950042725, 2.31458950042725, 2.31458950042725, 2.31458950042725, 
    2.31458950042725, 2.31458950042725, 2.31458950042725, 2.31458950042725, 
    2.31458950042725, 2.31458950042725, 2.31458950042725, 2.31458950042725, 
    2.31458950042725, 2.31458950042725, 2.31458950042725, 2.31458950042725, 
    2.31458950042725, 2.31458950042725, 2.31458950042725, 2.31458950042725, 
    2.31458950042725, 2.31458950042725, 2.31458950042725, 2.31458950042725, 
    2.31458950042725, 2.31458950042725, 2.31458950042725, 2.31458950042725, 
    2.31458950042725, 2.31458950042725, 2.31458950042725, 2.31458950042725, 
    2.31458950042725, 2.31458950042725, 2.31458950042725, 2.31458950042725, 
    2.31458950042725, 2.31458950042725, 2.31458950042725, 2.31458950042725, 
    2.31458950042725, 2.31458950042725, 2.31458950042725, 2.31458950042725, 
    2.31458950042725, 2.31458950042725, 2.31458950042725, 2.31458950042725, 
    2.31458950042725, 2.31458950042725, 2.31458950042725, 2.31458950042725, 
    2.31458950042725, 2.31458950042725, 2.31458950042725, 2.31458950042725, 
    2.31458950042725, 2.31458950042725, 2.31458950042725, 2.31458950042725, 
    2.31458950042725, 2.31458950042725, 2.31458950042725, 2.31458950042725, 
    2.31458950042725, 2.31458950042725, 2.31458950042725, 2.31458950042725, 
    2.31458950042725, 2.31458950042725, 2.31458950042725, 2.31458950042725, 
    2.31458950042725, 2.31458950042725, 2.31458950042725, 2.31458950042725, 
    2.31458950042725, 2.31458950042725, 2.31458950042725, 2.31458950042725, 
    22.314998626709, 22.314998626709, 22.314998626709, 20.4969882965088, 
    11.7768239974976, 20.4969882965088, 25.3301219940186, 20.4969882965088, 
    21.7515506744385, 22.314998626709, 11.9850568771362, 22.314998626709, 
    11.7768239974976, 20.4969882965088, 11.9850568771362, 11.9850568771362, 
    20.4969882965088, 21.7515506744385, 25.3301219940186, 11.9850568771362, 
    22.7133331298828, 20.4969882965088, 22.314998626709, 11.9850568771362, 
    39.7916374206543, 22.314998626709, 20.4969882965088, 20.4969882965088, 
    21.7515506744385, 20.4969882965088, 22.314998626709, 5.08998727798462, 
    39.7916374206543, 8.4395170211792, 11.7768239974976, 11.7768239974976, 
    11.7768239974976, 20.4969882965088, 7.00500679016113, 11.9850568771362, 
    20.4969882965088, 25.3301219940186, 8.13191413879395, 22.314998626709, 
    11.7768239974976, 11.9850568771362, 22.314998626709, 11.9850568771362, 
    39.7916374206543, 20.4969882965088, 22.7133331298828, 20.4969882965088, 
    11.9850568771362, 22.314998626709, 21.7515506744385, 20.4969882965088, 
    22.314998626709, 11.9850568771362, 22.314998626709, 11.7768239974976, 
    11.9850568771362, 20.4969882965088, 20.4969882965088, 22.7133331298828, 
    11.7768239974976, 22.314998626709, 25.3301219940186, 11.7768239974976, 
    20.4969882965088, 20.4969882965088, 22.314998626709, 22.7133331298828, 
    11.9850568771362, 25.3301219940186, 11.9850568771362, 11.9850568771362, 
    22.314998626709, 11.7768239974976, 20.4969882965088, 6.69394540786743, 
    20.4969882965088, 20.4969882965088, 6.08842039108276, 22.314998626709, 
    20.4969882965088, 22.314998626709, 25.3301219940186, 21.7515506744385, 
    20.4969882965088, 11.9850568771362, 22.314998626709, 22.314998626709, 
    22.314998626709, 22.314998626709, 20.4969882965088, 20.4969882965088, 
    22.314998626709, 11.9850568771362, 21.7515506744385, 20.4969882965088, 
    20.4969882965088, 20.4969882965088, 22.314998626709, 22.314998626709, 
    25.3301219940186, 11.9850568771362, 22.314998626709, 20.4969882965088, 
    5.08998727798462, 22.314998626709, 22.7133331298828, 22.314998626709, 
    20.4969882965088, 22.314998626709, 5.88427782058716, 20.4969882965088, 
    6.08842039108276, 22.314998626709, 22.314998626709, 22.314998626709, 
    22.314998626709, 22.314998626709, 8.49756908416748, 22.314998626709, 
    20.4969882965088, 11.7768239974976, 20.4969882965088, 20.4969882965088, 
    11.9850568771362, 11.9850568771362, 7.29503440856934, 25.3301219940186, 
    21.7515506744385, 20.4969882965088, 7.7702522277832, 20.4969882965088, 
    20.4969882965088, 22.7133331298828, 22.314998626709, 25.3301219940186, 
    22.314998626709, 11.9850568771362, 22.7133331298828, 20.4969882965088, 
    11.7768239974976, 22.314998626709, 11.9850568771362, 22.314998626709, 
    25.3301219940186, 11.7768239974976, 20.4969882965088, 22.314998626709, 
    22.7133331298828, 20.4969882965088, 22.7133331298828, 20.4969882965088, 
    25.3301219940186, 22.7133331298828, 20.4969882965088, 22.314998626709, 
    20.4969882965088, 25.3301219940186, 22.314998626709, 20.4969882965088, 
    20.4969882965088, 22.7133331298828, 20.4969882965088, 21.7515506744385, 
    20.4969882965088, 22.314998626709, 11.9850568771362, 22.314998626709, 
    11.9850568771362, 20.4969882965088, 20.4969882965088, 20.4969882965088, 
    20.4969882965088, 11.9850568771362, 11.9850568771362, 22.314998626709, 
    22.314998626709, 22.314998626709, 22.314998626709, 20.4969882965088, 
    22.314998626709, 22.7133331298828, 22.314998626709, 22.314998626709, 
    22.314998626709, 25.3301219940186, 39.7916374206543, 20.4969882965088, 
    20.4969882965088, 39.7916374206543, 7.74177837371826, 25.3301219940186, 
    20.4969882965088, 11.7768239974976, 22.314998626709, 20.4969882965088, 
    11.7768239974976, 22.7133331298828, 22.314998626709, 11.9850568771362, 
    11.7768239974976, 20.4969882965088, 11.9850568771362, 21.7515506744385, 
    11.9850568771362, 22.314998626709, 22.314998626709, 20.4969882965088, 
    21.7515506744385, 22.7133331298828, 11.9850568771362, 11.9850568771362, 
    20.4969882965088, 22.7133331298828, 22.314998626709, 20.4969882965088, 
    22.314998626709, 11.9850568771362, 25.3301219940186, 20.4969882965088, 
    11.7768239974976, 11.9850568771362, 20.4969882965088, 11.9850568771362, 
    20.4969882965088, 20.4969882965088, 22.7133331298828, 20.4969882965088, 
    22.7133331298828, 22.7133331298828, 22.314998626709, 22.7133331298828, 
    22.314998626709, 20.4969882965088, 20.4969882965088, 11.9850568771362, 
    22.314998626709, 39.7916374206543, 22.314998626709, 11.9850568771362, 
    25.3301219940186, 20.4969882965088, 22.314998626709, 20.4969882965088, 
    11.9850568771362, 20.4969882965088, 20.4969882965088, 8.0387601852417, 
    21.7515506744385, 22.314998626709, 22.314998626709, 20.4969882965088, 
    22.7133331298828, 21.7515506744385, 20.4969882965088, 20.4969882965088, 
    22.314998626709, 22.314998626709, 20.4969882965088, 20.4969882965088, 
    22.314998626709, 20.4969882965088, 20.4969882965088, 11.9850568771362, 
    11.9850568771362, 11.9850568771362, 20.4969882965088, 20.4969882965088, 
    11.7768239974976, 22.314998626709, 6.69394540786743, 22.314998626709, 
    20.4969882965088, 22.314998626709, 22.314998626709, 22.314998626709, 
    25.3301219940186, 22.314998626709, 20.4969882965088, 11.7768239974976, 
    11.9850568771362, 11.9850568771362, 11.7768239974976, 25.3301219940186, 
    20.4969882965088, 22.314998626709, 22.314998626709, 22.7133331298828, 
    20.4969882965088, 22.314998626709, 20.4969882965088, 11.9850568771362, 
    20.4969882965088, 20.4969882965088, 22.314998626709, 20.4969882965088, 
    20.4969882965088, 20.4969882965088, 20.4969882965088, 20.4969882965088, 
    20.4969882965088, 22.314998626709, 22.314998626709, 22.314998626709, 
    22.314998626709, 11.9850568771362, 22.314998626709, 20.4969882965088, 
    22.314998626709, 7.74177837371826, 22.314998626709, 6.88642168045044, 
    8.0387601852417, 20.4969882965088, 7.00500679016113, 11.7768239974976, 
    11.7768239974976, 20.4969882965088, 20.4969882965088, 11.7768239974976, 
    20.4969882965088, 11.7768239974976, 5.88427782058716, 11.7768239974976, 
    20.4969882965088, 22.7133331298828, 7.29503440856934, 22.314998626709, 
    20.4969882965088, 20.4969882965088, 22.314998626709, 22.314998626709, 
    11.9850568771362, 22.314998626709, 7.11380386352539, 21.7515506744385, 
    20.4969882965088, 20.4969882965088, 20.4969882965088, 22.314998626709, 
    22.314998626709, 22.7133331298828, 22.314998626709, 22.314998626709, 
    22.314998626709, 7.74177837371826, 11.9850568771362, 25.3301219940186, 
    22.314998626709, 20.4969882965088, 11.9850568771362, 22.7133331298828, 
    21.7515506744385, 22.314998626709, 20.4969882965088, 11.7768239974976, 
    20.4969882965088, 11.9850568771362, 11.9850568771362, 11.7768239974976, 
    11.9850568771362, 20.4969882965088, 11.9850568771362, 11.7768239974976, 
    20.4969882965088, 20.4969882965088, 20.4969882965088, 20.4969882965088, 
    20.4969882965088, 11.7768239974976, 20.4969882965088, 20.4969882965088, 
    8.3098087310791, 20.4969882965088, 21.7515506744385, 20.4969882965088, 
    8.13191413879395, 11.9850568771362, 20.4969882965088, 22.314998626709, 
    22.7133331298828, 11.9850568771362, 20.4969882965088, 6.21464824676514, 
    20.4969882965088, 11.7768239974976, 25.3301219940186, 22.314998626709, 
    20.4969882965088, 20.4969882965088, 22.314998626709, 20.4969882965088, 
    20.4969882965088, 22.314998626709, 22.314998626709, 11.7768239974976, 
    22.314998626709, 20.4969882965088, 39.7916374206543, 20.4969882965088, 
    22.7133331298828, 22.314998626709, 20.4969882965088, 20.4969882965088, 
    11.9850568771362, 20.4969882965088, 22.314998626709, 20.4969882965088, 
    11.9850568771362, 22.314998626709, 11.9850568771362, 20.4969882965088, 
    22.7133331298828, 11.9850568771362, 6.08962440490723, 20.4969882965088, 
    21.7515506744385, 20.4969882965088, 22.314998626709, 21.7515506744385, 
    20.4969882965088, 11.9850568771362, 11.9850568771362, 22.314998626709, 
    20.4969882965088, 11.7768239974976, 11.7768239974976, 11.9850568771362, 
    11.9850568771362, 25.3301219940186, 22.7133331298828, 7.7702522277832, 
    20.4969882965088, 22.314998626709, 20.4969882965088, 22.314998626709, 
    20.4969882965088, 20.4969882965088, 25.3301219940186, 20.4969882965088, 
    11.7768239974976, 22.7133331298828, 22.314998626709, 20.4969882965088, 
    11.7768239974976, 20.4969882965088, 22.314998626709, 11.9850568771362, 
    11.7768239974976, 22.314998626709, 20.4969882965088, 11.9850568771362, 
    22.314998626709, 39.7916374206543, 20.4969882965088, 22.314998626709, 
    20.4969882965088, 25.3301219940186, 20.4969882965088, 22.314998626709, 
    11.7768239974976, 8.5859317779541, 22.7133331298828, 25.3301219940186, 
    39.7916374206543, 11.2740077972412, 10.7770595550537, 11.2740077972412, 
    11.2740077972412, 11.2740077972412, 11.2740077972412, 10.7770595550537, 
    10.7770595550537, 11.2740077972412, 11.2740077972412, 10.7770595550537, 
    11.2740077972412, 10.7770595550537, 10.7770595550537, 11.2740077972412, 
    11.2740077972412, 11.2740077972412, 10.7770595550537, 11.2740077972412, 
    11.2740077972412, 11.5140657424927, 10.7770595550537, 11.2740077972412, 
    10.7770595550537, 11.2740077972412, 11.2740077972412, 11.2740077972412, 
    11.2740077972412, 11.2740077972412, 10.7770595550537, 11.5140657424927, 
    11.2740077972412, 10.7770595550537, 11.2740077972412, 11.2740077972412, 
    11.2740077972412, 10.7770595550537, 10.7770595550537, 10.7770595550537, 
    11.2740077972412, 11.5140657424927, 11.2740077972412, 11.5140657424927, 
    11.2740077972412, 10.7770595550537, 11.2740077972412, 11.5140657424927, 
    11.2740077972412, 11.2740077972412, 10.7770595550537, 11.2740077972412, 
    11.2740077972412, 11.2740077972412, 11.2740077972412, 11.2740077972412, 
    11.2740077972412, 11.2740077972412, 11.2740077972412, 10.7770595550537, 
    11.2740077972412, 11.5140657424927, 11.2740077972412, 11.2740077972412, 
    10.7770595550537, 11.5140657424927, 10.7770595550537, 11.2740077972412, 
    11.2740077972412, 10.7770595550537, 11.2740077972412, 11.2740077972412, 
    11.2740077972412, 11.2740077972412, 10.7770595550537, 10.7770595550537, 
    11.2740077972412, 11.5140657424927, 11.2740077972412, 11.2740077972412, 
    10.7770595550537, 10.7770595550537, 11.2740077972412, 11.2740077972412, 
    11.2740077972412, 11.2740077972412, 11.2740077972412, 11.2740077972412, 
    10.7770595550537, 11.5140657424927, 10.7770595550537, 11.2740077972412, 
    11.2740077972412, 11.2740077972412, 11.2740077972412, 10.7770595550537, 
    11.5140657424927, 11.2740077972412, 11.2740077972412, 11.5140657424927, 
    11.2740077972412, 11.2740077972412, 25.7949275970459, 25.7949275970459, 
    30.4427890777588, 25.7949275970459, 30.4427890777588, 30.4427890777588, 
    25.7949275970459, 30.4427890777588, 25.7949275970459, 30.4427890777588, 
    30.4427890777588, 25.7949275970459, 30.4427890777588, 30.4427890777588, 
    25.7949275970459, 30.4427890777588, 25.7949275970459, 30.4427890777588, 
    25.7949275970459, 30.4427890777588, 30.4427890777588, 30.4427890777588, 
    30.4427890777588, 25.7949275970459, 30.4427890777588, 25.7949275970459, 
    30.4427890777588, 25.7949275970459, 30.4427890777588, 25.7949275970459, 
    30.4427890777588, 25.7949275970459, 30.4427890777588, 30.4427890777588, 
    30.4427890777588, 30.4427890777588, 30.4427890777588, 30.4427890777588, 
    30.4427890777588, 25.7949275970459, 25.7949275970459, 25.7949275970459, 
    25.7949275970459, 25.7949275970459, 30.4427890777588, 30.4427890777588, 
    25.7949275970459, 30.4427890777588, 30.4427890777588, 30.4427890777588, 
    30.4427890777588, 25.7949275970459, 30.4427890777588, 30.4427890777588, 
    30.4427890777588, 18.3337802886963, 7.89005327224731, 16.849739074707, 
    18.9414253234863, 6.08842039108276, 18.9414253234863, 18.3337802886963, 
    18.9414253234863, 18.9414253234863, 7.89005327224731, 18.9414253234863, 
    16.849739074707, 16.849739074707, 11.9850568771362, 22.314998626709, 
    8.5859317779541, 22.314998626709, 16.849739074707, 7.89005327224731, 
    16.849739074707, 11.9850568771362, 11.9850568771362, 18.9414253234863, 
    22.314998626709, 18.9414253234863, 18.9414253234863, 22.314998626709, 
    16.849739074707, 11.9850568771362, 7.89005327224731, 7.89005327224731, 
    16.849739074707, 16.849739074707, 16.849739074707, 18.9414253234863, 
    18.9414253234863, 11.7768239974976, 16.849739074707, 22.314998626709, 
    18.9414253234863, 18.9414253234863, 18.3337802886963, 18.3337802886963, 
    16.849739074707, 18.9414253234863, 22.314998626709, 18.9414253234863, 
    18.9414253234863, 11.7768239974976, 18.9414253234863, 18.3337802886963, 
    7.89005327224731, 8.5859317779541, 18.9414253234863, 7.89005327224731, 
    7.89005327224731, 22.314998626709, 22.314998626709, 16.849739074707, 
    16.849739074707, 18.3337802886963, 22.314998626709, 18.9414253234863, 
    7.89005327224731, 7.26948213577271, 18.9414253234863, 18.9414253234863, 
    11.9850568771362, 21.7515506744385, 18.9414253234863, 22.314998626709, 
    22.314998626709, 18.9414253234863, 18.9414253234863, 22.314998626709, 
    7.89005327224731, 18.9414253234863, 18.3337802886963, 16.849739074707, 
    16.849739074707, 16.849739074707, 18.9414253234863, 7.89005327224731, 
    16.849739074707, 21.7515506744385, 16.849739074707, 16.849739074707, 
    21.7515506744385, 7.89005327224731, 16.849739074707, 11.7768239974976, 
    18.9414253234863, 7.89005327224731, 21.7515506744385, 18.9414253234863, 
    16.849739074707, 16.849739074707, 21.7515506744385, 22.314998626709, 
    18.3337802886963, 22.314998626709, 18.9414253234863, 18.9414253234863, 
    16.849739074707, 22.314998626709, 18.9414253234863, 16.849739074707, 
    7.89005327224731, 7.89005327224731, 11.9850568771362, 18.9414253234863, 
    8.0387601852417, 16.849739074707, 18.9414253234863, 22.314998626709, 
    5.08998727798462, 22.314998626709, 18.9414253234863, 18.3337802886963, 
    18.9414253234863, 7.89005327224731, 18.9414253234863, 18.9414253234863, 
    11.9850568771362, 7.89005327224731, 18.3337802886963, 18.9414253234863, 
    16.849739074707, 7.89005327224731, 18.9414253234863, 16.849739074707, 
    16.849739074707, 8.49756908416748, 16.849739074707, 16.849739074707, 
    16.849739074707, 18.9414253234863, 7.89005327224731, 18.9414253234863, 
    18.3337802886963, 18.3337802886963, 18.9414253234863, 18.9414253234863, 
    22.314998626709, 22.314998626709, 18.9414253234863, 7.89005327224731, 
    18.9414253234863, 11.9850568771362, 16.849739074707, 16.849739074707, 
    18.9414253234863, 18.9414253234863, 18.9414253234863, 18.9414253234863, 
    16.849739074707, 16.849739074707, 7.89005327224731, 22.314998626709, 
    6.08842039108276, 16.849739074707, 16.849739074707, 18.9414253234863, 
    18.9414253234863, 18.9414253234863, 18.9414253234863, 18.9414253234863, 
    11.9850568771362, 18.9414253234863, 18.9414253234863, 18.9414253234863, 
    18.9414253234863, 16.849739074707, 22.314998626709, 18.9414253234863, 
    18.9414253234863, 22.314998626709, 18.9414253234863, 18.9414253234863, 
    18.9414253234863, 5.08998727798462, 16.849739074707, 16.849739074707, 
    22.314998626709, 18.3337802886963, 18.9414253234863, 16.849739074707, 
    22.314998626709, 18.9414253234863, 16.849739074707, 16.849739074707, 
    18.9414253234863, 7.89005327224731, 18.9414253234863, 22.314998626709, 
    18.9414253234863, 11.7768239974976, 18.9414253234863, 18.9414253234863, 
    18.9414253234863, 22.314998626709, 11.9850568771362, 18.9414253234863, 
    18.3337802886963, 7.89005327224731, 16.849739074707, 16.849739074707, 
    16.849739074707, 16.849739074707, 7.89005327224731, 11.9850568771362, 
    16.849739074707, 11.9850568771362, 18.3337802886963, 18.9414253234863, 
    18.3337802886963, 18.9414253234863, 18.9414253234863, 18.3337802886963, 
    22.314998626709, 7.89005327224731, 18.9414253234863, 22.314998626709, 
    18.9414253234863, 18.9414253234863, 22.314998626709, 11.7768239974976, 
    18.9414253234863, 7.89005327224731, 11.7768239974976, 11.7768239974976, 
    18.9414253234863, 16.849739074707, 18.9414253234863, 18.9414253234863, 
    16.849739074707, 7.89005327224731, 16.849739074707, 22.314998626709, 
    16.849739074707, 18.9414253234863, 18.3337802886963, 11.9850568771362, 
    22.314998626709, 11.9850568771362, 16.849739074707, 16.849739074707, 
    16.849739074707, 11.9850568771362, 18.9414253234863, 18.3337802886963, 
    16.849739074707, 18.9414253234863, 18.3337802886963, 18.3337802886963, 
    18.9414253234863, 7.89005327224731, 18.9414253234863, 7.89005327224731, 
    22.314998626709, 18.9414253234863, 7.89005327224731, 18.9414253234863, 
    18.9414253234863, 18.9414253234863, 11.9850568771362, 16.849739074707, 
    11.7768239974976, 11.9850568771362, 18.9414253234863, 18.9414253234863, 
    18.9414253234863, 22.314998626709, 18.9414253234863, 16.849739074707, 
    18.9414253234863, 16.849739074707, 18.9414253234863, 18.9414253234863, 
    16.849739074707, 7.89005327224731, 7.89005327224731, 7.89005327224731, 
    22.314998626709, 18.3337802886963, 11.9850568771362, 16.849739074707, 
    7.89005327224731, 18.9414253234863, 18.9414253234863, 11.9850568771362, 
    22.314998626709, 11.7768239974976, 18.9414253234863, 16.849739074707, 
    7.89005327224731, 22.314998626709, 22.314998626709, 18.9414253234863, 
    16.849739074707, 18.9414253234863, 11.7768239974976, 18.9414253234863, 
    16.849739074707, 11.9850568771362, 18.3337802886963, 18.9414253234863, 
    11.9850568771362, 16.849739074707, 22.314998626709, 18.9414253234863, 
    18.3337802886963, 7.89005327224731, 16.849739074707, 18.9414253234863, 
    11.7768239974976, 22.314998626709, 16.849739074707, 16.849739074707, 
    18.9414253234863, 18.3337802886963, 16.849739074707, 16.849739074707, 
    16.849739074707, 11.9850568771362, 22.314998626709, 11.7768239974976, 
    18.9414253234863, 18.9414253234863, 16.849739074707, 11.9850568771362, 
    16.849739074707, 16.849739074707, 18.9414253234863, 7.89005327224731, 
    18.9414253234863, 11.9850568771362, 11.9850568771362, 18.9414253234863, 
    18.9414253234863, 18.9414253234863, 22.314998626709, 7.89005327224731, 
    16.849739074707, 18.9414253234863, 11.9850568771362, 16.849739074707, 
    7.89005327224731, 18.9414253234863, 7.89005327224731, 22.314998626709, 
    16.849739074707, 16.849739074707, 18.9414253234863, 22.314998626709, 
    16.849739074707, 18.9414253234863, 18.3337802886963, 16.849739074707, 
    18.9414253234863, 11.9850568771362, 18.9414253234863, 16.849739074707, 
    16.849739074707, 18.9414253234863, 16.849739074707, 18.3337802886963, 
    18.9414253234863, 16.849739074707, 18.3337802886963, 22.314998626709, 
    18.9414253234863, 18.9414253234863, 18.9414253234863, 18.9414253234863, 
    18.9414253234863, 18.9414253234863, 18.9414253234863, 7.89005327224731, 
    18.3337802886963, 22.314998626709, 16.849739074707, 18.9414253234863, 
    22.314998626709, 18.3337802886963, 11.7768239974976, 5.43175840377808, 
    7.74177837371826, 7.00500679016113, 6.88642168045044, 8.4395170211792, 
    7.30501985549927, 8.13191413879395, 7.74177837371826, 7.74177837371826, 
    8.5859317779541, 8.0387601852417, 7.7702522277832, 5.43175840377808, 
    6.08842039108276, 6.08842039108276, 6.32296323776245, 6.88642168045044, 
    8.3098087310791, 7.7702522277832, 6.21464824676514, 8.58236598968506, 
    8.5859317779541, 6.08842039108276, 6.08962440490723, 8.58236598968506, 
    7.08579874038696, 8.44301128387451, 5.08998727798462, 7.30501985549927, 
    7.08579874038696, 7.30501985549927, 7.11380386352539, 5.88427782058716, 
    6.08842039108276, 6.88642168045044, 7.00500679016113, 7.74177837371826, 
    6.32296323776245, 8.3098087310791, 7.74177837371826, 6.21464824676514, 
    5.43175840377808, 8.58236598968506, 6.32296323776245, 8.5859317779541, 
    6.32296323776245, 7.26948213577271, 7.29503440856934, 8.44301128387451, 
    5.43175840377808, 6.21464824676514, 8.3098087310791, 6.66747808456421, 
    8.49756908416748, 6.08962440490723, 5.08998727798462, 6.88642168045044, 
    8.44301128387451, 7.29503440856934, 6.08962440490723, 7.26948213577271, 
    8.49756908416748, 7.30501985549927, 8.3098087310791, 7.30501985549927, 
    7.74177837371826, 7.26948213577271, 7.74177837371826, 8.5859317779541, 
    7.29503440856934, 6.36139392852783, 6.08962440490723, 6.69394540786743, 
    5.43175840377808, 8.49756908416748, 8.13191413879395, 6.88642168045044, 
    8.49756908416748, 7.30501985549927, 6.66747808456421, 7.08579874038696, 
    7.30501985549927, 7.26948213577271, 6.08962440490723, 6.21464824676514, 
    6.08842039108276),
  c(6.69394540786743, 6.88642168045044, 8.44301128387451, 5.08998727798462, 
    5.88427782058716, 6.36139392852783, 7.26948213577271, 8.4395170211792, 
    8.58236598968506, 6.049973487854, 8.58236598968506, 6.049973487854, 
    6.88642168045044, 6.69394540786743, 8.0387601852417, 6.049973487854, 
    8.5859317779541, 5.88427782058716, 5.88427782058716, 7.30501985549927, 
    6.08842039108276, 6.32296323776245, 6.08962440490723, 6.049973487854, 
    6.049973487854, 8.57161712646484, 8.3098087310791, 5.43175840377808, 
    7.26948213577271, 7.00500679016113, 7.74177837371826, 7.11380386352539, 
    6.08842039108276, 7.30501985549927, 6.02720928192139, 6.08962440490723, 
    5.43175840377808, 5.88427782058716, 6.66747808456421, 5.08998727798462, 
    5.08998727798462, 6.08962440490723, 8.58236598968506, 6.08842039108276, 
    7.11380386352539, 8.4395170211792, 6.08842039108276, 6.88642168045044, 
    8.3098087310791, 8.0387601852417, 8.49756908416748, 6.88642168045044, 
    6.049973487854, 5.08998727798462, 8.49756908416748, 7.00500679016113, 
    8.57161712646484, 6.08962440490723, 7.74177837371826, 6.08842039108276, 
    6.02720928192139, 6.21464824676514, 7.7702522277832, 8.57161712646484, 
    6.08842039108276, 6.88642168045044, 5.88427782058716, 6.08842039108276, 
    8.49756908416748, 8.4395170211792, 6.08842039108276, 7.29503440856934, 
    8.57161712646484, 5.08998727798462, 7.29503440856934, 8.3098087310791, 
    7.11380386352539, 8.13191413879395, 8.58236598968506, 8.58236598968506, 
    8.58236598968506, 7.7702522277832, 7.74177837371826, 8.44301128387451, 
    6.21464824676514, 8.49756908416748, 8.5859317779541, 8.44301128387451, 
    5.43175840377808, 6.88642168045044, 6.08962440490723, 6.049973487854, 
    8.0387601852417, 5.08998727798462, 6.36139392852783, 5.08998727798462, 
    6.02720928192139, 7.74177837371826, 8.0387601852417, 8.13191413879395, 
    6.69394540786743, 7.29503440856934, 7.30501985549927, 7.00500679016113, 
    7.74177837371826, 6.08842039108276, 6.08962440490723, 7.11380386352539, 
    6.21464824676514, 7.29503440856934, 7.74177837371826, 6.88642168045044, 
    5.43175840377808, 5.08998727798462, 7.7702522277832, 6.69394540786743, 
    8.44301128387451, 5.43175840377808, 7.00500679016113, 8.44301128387451, 
    6.36139392852783, 6.36139392852783, 8.49756908416748, 8.57161712646484, 
    6.88642168045044, 6.88642168045044, 6.69394540786743, 7.7702522277832, 
    7.74177837371826, 8.4395170211792, 6.02720928192139, 8.57161712646484, 
    7.00500679016113, 6.32296323776245, 6.88642168045044, 6.08842039108276, 
    8.4395170211792, 8.5859317779541, 8.5859317779541, 6.32296323776245, 
    6.69394540786743, 5.08998727798462, 7.26948213577271, 6.88642168045044, 
    8.0387601852417, 8.0387601852417, 6.08842039108276, 6.08842039108276, 
    8.3098087310791, 7.26948213577271, 6.21464824676514, 6.08962440490723, 
    6.08842039108276, 7.74177837371826, 7.7702522277832, 7.74177837371826, 
    7.74177837371826, 7.11380386352539, 6.88642168045044, 8.3098087310791, 
    6.66747808456421, 7.08579874038696, 5.88427782058716, 6.08962440490723, 
    8.5859317779541, 8.4395170211792, 8.58236598968506, 6.21464824676514, 
    5.43175840377808, 7.74177837371826, 5.88427782058716, 8.44301128387451, 
    8.44301128387451, 5.43175840377808, 7.30501985549927, 6.08962440490723, 
    8.44301128387451, 7.26948213577271, 6.08842039108276, 6.08962440490723, 
    7.08579874038696, 8.5859317779541, 8.3098087310791, 7.00500679016113, 
    5.08998727798462, 8.0387601852417, 5.88427782058716, 7.29503440856934, 
    7.30501985549927, 6.08842039108276, 7.11380386352539, 6.08962440490723, 
    6.08962440490723, 8.44301128387451, 6.66747808456421, 5.43175840377808, 
    7.29503440856934, 6.049973487854, 6.02720928192139, 8.58236598968506, 
    8.5859317779541, 8.44301128387451, 6.08842039108276, 5.43175840377808, 
    8.49756908416748, 6.08842039108276, 8.58236598968506, 8.58236598968506, 
    8.49756908416748, 8.5859317779541, 7.74177837371826, 8.5859317779541, 
    6.049973487854, 7.30501985549927, 8.44301128387451, 5.08998727798462, 
    8.0387601852417, 8.49756908416748, 8.5859317779541, 6.049973487854, 
    6.08962440490723, 6.32296323776245, 6.08962440490723, 6.69394540786743, 
    6.88642168045044, 8.0387601852417, 8.49756908416748, 7.30501985549927, 
    7.26948213577271, 6.66747808456421, 7.74177837371826, 6.08842039108276, 
    6.88642168045044, 6.08842039108276, 8.49756908416748, 6.36139392852783, 
    7.08579874038696, 6.08842039108276, 7.74177837371826, 8.49756908416748, 
    8.0387601852417, 6.02720928192139, 5.88427782058716, 6.21464824676514, 
    7.11380386352539, 8.0387601852417, 5.08998727798462, 6.32296323776245, 
    7.74177837371826, 7.74177837371826, 8.5859317779541, 6.69394540786743, 
    6.32296323776245, 7.00500679016113, 7.7702522277832, 6.88642168045044, 
    6.36139392852783, 7.26948213577271, 8.57161712646484, 6.08842039108276, 
    6.66747808456421, 8.13191413879395, 6.049973487854, 6.88642168045044, 
    7.08579874038696, 8.4395170211792, 7.11380386352539, 6.66747808456421, 
    5.43175840377808, 6.08842039108276, 5.43175840377808, 8.57161712646484, 
    8.3098087310791, 7.30501985549927, 5.43175840377808, 6.69394540786743, 
    6.36139392852783, 8.0387601852417, 8.58236598968506, 7.74177837371826, 
    8.3098087310791, 6.32296323776245, 6.049973487854, 6.08842039108276, 
    6.32296323776245, 8.13191413879395, 6.32296323776245, 7.30501985549927, 
    7.74177837371826, 5.08998727798462, 5.43175840377808, 8.3098087310791, 
    6.88642168045044, 8.0387601852417, 6.049973487854, 7.7702522277832, 
    8.13191413879395, 5.88427782058716, 5.43175840377808, 7.00500679016113, 
    8.3098087310791, 8.4395170211792, 8.0387601852417, 6.36139392852783, 
    6.69394540786743, 6.69394540786743, 6.049973487854, 8.13191413879395, 
    8.0387601852417, 6.08842039108276, 7.30501985549927, 6.08842039108276, 
    8.5859317779541, 7.11380386352539, 8.4395170211792, 7.30501985549927, 
    6.66747808456421, 6.66747808456421, 7.00500679016113, 6.66747808456421, 
    6.69394540786743, 6.69394540786743, 6.08842039108276, 7.7702522277832, 
    5.88427782058716, 7.26948213577271, 6.36139392852783, 6.69394540786743, 
    6.32296323776245, 7.08579874038696, 7.74177837371826, 2, 3.05976724624634, 
    2, 22.4463157653809, 3.05976724624634, 2, 22.4463157653809, 2, 
    41.1513023376465, 3.05976724624634, 22.4463157653809, 22.4463157653809, 
    22.4463157653809, 5.59314155578613, 3.05976724624634, 22.4463157653809, 
    2, 3.05976724624634, 2, 41.1513023376465, 41.1513023376465, 2, 
    2, 5.59314155578613, 3.05976724624634, 3.05976724624634, 22.4463157653809, 
    2, 41.1513023376465, 5.59314155578613, 2, 41.1513023376465, 41.1513023376465, 
    2, 5.59314155578613, 22.4463157653809, 5.59314155578613, 5.59314155578613, 
    5.59314155578613, 3.05976724624634, 3.05976724624634, 5.59314155578613, 
    22.4463157653809, 2, 41.1513023376465, 2, 2, 22.4463157653809, 
    41.1513023376465, 5.59314155578613, 41.1513023376465, 5.59314155578613, 
    2, 2, 7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.02041482925415, 7.02041482925415, 7.02041482925415, 
    7.02041482925415, 7.67765665054321, 7.67765665054321, 7.67765665054321, 
    7.67765665054321, 7.67765665054321, 7.67765665054321, 7.67765665054321, 
    7.67765665054321, 7.67765665054321, 7.67765665054321, 7.67765665054321, 
    7.67765665054321, 7.67765665054321, 7.67765665054321, 7.67765665054321, 
    7.67765665054321, 7.67765665054321, 7.67765665054321, 7.67765665054321, 
    7.67765665054321, 7.67765665054321, 7.67765665054321, 7.67765665054321, 
    7.67765665054321, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 2.56226706504822, 
    2.56226706504822, 2.56226706504822, 2.56226706504822, 7.37679290771484, 
    7.37679290771484, 23.2337379455566, 7.37679290771484, 21.1048812866211, 
    7.76446151733398, 21.1048812866211, 23.2337379455566, 7.76446151733398, 
    7.37679290771484, 7.76446151733398, 6.27709436416626, 6.27709436416626, 
    23.2337379455566, 6.27709436416626, 21.1048812866211, 7.76446151733398, 
    7.76446151733398, 21.1048812866211, 6.27709436416626, 7.76446151733398, 
    23.2337379455566, 21.1048812866211, 7.37679290771484, 21.1048812866211, 
    21.1048812866211, 7.37679290771484, 21.1048812866211, 23.2337379455566, 
    21.1048812866211, 6.27709436416626, 21.1048812866211, 6.27709436416626, 
    7.37679290771484, 7.76446151733398, 23.2337379455566, 23.2337379455566, 
    6.27709436416626, 21.1048812866211, 7.37679290771484, 23.2337379455566, 
    7.76446151733398, 6.27709436416626, 7.76446151733398, 23.2337379455566, 
    23.2337379455566, 23.2337379455566, 7.37679290771484, 6.27709436416626, 
    21.1048812866211, 21.1048812866211, 21.1048812866211, 7.37679290771484, 
    7.76446151733398, 23.2337379455566, 23.2337379455566, 7.76446151733398, 
    6.27709436416626, 7.37679290771484, 7.76446151733398, 21.1048812866211, 
    21.1048812866211, 21.1048812866211, 7.37679290771484, 23.2337379455566, 
    23.2337379455566, 7.37679290771484, 7.37679290771484, 7.37679290771484, 
    7.37679290771484, 23.2337379455566, 23.2337379455566, 6.27709436416626, 
    23.2337379455566, 21.1048812866211, 23.2337379455566, 23.2337379455566, 
    21.1048812866211, 23.2337379455566, 6.27709436416626, 7.37679290771484, 
    6.27709436416626, 7.37679290771484, 7.76446151733398, 21.1048812866211, 
    7.37679290771484, 6.27709436416626, 7.37679290771484, 21.1048812866211, 
    7.37679290771484, 7.37679290771484, 21.1048812866211, 7.37679290771484, 
    21.1048812866211, 7.37679290771484, 23.2337379455566, 21.1048812866211, 
    21.1048812866211, 7.76446151733398, 21.1048812866211, 6.27709436416626, 
    21.1048812866211, 6.27709436416626, 23.2337379455566, 7.76446151733398, 
    21.1048812866211, 21.1048812866211, 23.2337379455566, 7.76446151733398, 
    23.2337379455566, 21.1048812866211, 7.37679290771484, 23.2337379455566, 
    21.1048812866211, 23.2337379455566, 23.2337379455566, 6.27709436416626, 
    7.37679290771484, 6.27709436416626, 6.27709436416626, 7.37679290771484, 
    23.2337379455566, 21.1048812866211, 23.2337379455566, 23.2337379455566, 
    7.76446151733398, 7.37679290771484, 21.1048812866211, 7.37679290771484, 
    7.37679290771484, 6.27709436416626, 7.37679290771484, 6.27709436416626, 
    21.1048812866211, 7.37679290771484, 6.27709436416626, 21.1048812866211, 
    7.37679290771484, 23.2337379455566, 7.37679290771484, 7.37679290771484, 
    7.76446151733398, 23.2337379455566, 7.37679290771484, 7.76446151733398, 
    6.27709436416626, 23.2337379455566, 7.37679290771484, 7.37679290771484, 
    6.27709436416626, 21.1048812866211, 7.76446151733398, 21.1048812866211, 
    21.1048812866211, 7.37679290771484, 7.37679290771484, 23.2337379455566, 
    7.76446151733398, 23.2337379455566, 23.2337379455566, 7.37679290771484, 
    6.27709436416626, 21.1048812866211, 7.37679290771484, 21.1048812866211, 
    7.37679290771484, 23.2337379455566, 7.76446151733398, 23.2337379455566, 
    7.37679290771484, 7.76446151733398, 23.2337379455566, 21.1048812866211, 
    7.37679290771484, 21.1048812866211, 23.2337379455566, 6.27709436416626, 
    7.76446151733398, 6.27709436416626, 21.1048812866211, 21.1048812866211, 
    21.1048812866211, 6.27709436416626, 7.37679290771484, 21.1048812866211, 
    21.1048812866211, 21.1048812866211, 21.1048812866211, 21.1048812866211, 
    7.37679290771484, 23.2337379455566, 21.1048812866211, 21.1048812866211, 
    7.76446151733398, 7.37679290771484, 7.76446151733398, 23.2337379455566, 
    21.1048812866211, 7.76446151733398, 23.2337379455566, 6.27709436416626, 
    21.1048812866211, 7.37679290771484, 23.2337379455566, 7.37679290771484, 
    23.2337379455566, 7.37679290771484, 21.1048812866211, 21.1048812866211, 
    7.37679290771484, 23.2337379455566, 7.37679290771484, 6.27709436416626, 
    21.1048812866211, 23.2337379455566, 21.1048812866211, 21.1048812866211, 
    7.37679290771484, 7.76446151733398, 7.76446151733398, 23.2337379455566, 
    23.2337379455566, 7.37679290771484, 7.76446151733398, 21.1048812866211, 
    6.27709436416626, 7.76446151733398, 23.2337379455566, 21.1048812866211, 
    23.2337379455566, 7.37679290771484, 21.1048812866211, 7.37679290771484, 
    7.76446151733398, 7.37679290771484, 23.2337379455566, 7.37679290771484, 
    7.37679290771484, 7.37679290771484, 7.37679290771484, 23.2337379455566, 
    7.37679290771484, 7.37679290771484, 23.2337379455566, 21.1048812866211, 
    7.37679290771484, 7.37679290771484, 23.2337379455566, 23.2337379455566, 
    7.76446151733398, 23.2337379455566, 21.1048812866211, 7.76446151733398, 
    6.27709436416626, 7.37679290771484, 7.37679290771484, 6.27709436416626, 
    7.37679290771484, 7.76446151733398, 7.76446151733398, 7.76446151733398, 
    7.76446151733398, 21.1048812866211, 7.37679290771484, 23.2337379455566, 
    7.37679290771484, 7.37679290771484, 7.37679290771484, 7.37679290771484, 
    21.1048812866211, 21.1048812866211, 21.1048812866211, 7.37679290771484, 
    6.27709436416626, 7.37679290771484, 21.1048812866211, 7.37679290771484, 
    7.37679290771484, 7.76446151733398, 6.27709436416626, 23.2337379455566, 
    23.2337379455566, 7.76446151733398, 23.2337379455566, 21.1048812866211, 
    6.27709436416626, 21.1048812866211, 7.37679290771484, 21.1048812866211, 
    7.37679290771484, 23.2337379455566, 6.27709436416626, 7.76446151733398, 
    23.2337379455566, 6.27709436416626, 7.37679290771484, 6.27709436416626, 
    21.1048812866211, 7.76446151733398, 7.37679290771484, 21.1048812866211, 
    6.27709436416626, 21.1048812866211, 7.37679290771484, 7.37679290771484, 
    21.1048812866211, 21.1048812866211, 7.37679290771484, 21.1048812866211, 
    7.76446151733398, 21.1048812866211, 7.37679290771484, 7.76446151733398, 
    23.2337379455566, 7.37679290771484, 7.37679290771484, 6.27709436416626, 
    21.1048812866211, 21.1048812866211, 7.37679290771484, 7.37679290771484, 
    7.37679290771484, 23.2337379455566, 7.37679290771484, 21.1048812866211, 
    23.2337379455566, 21.1048812866211, 7.76446151733398, 7.37679290771484, 
    21.1048812866211, 21.1048812866211, 7.76446151733398, 21.1048812866211, 
    23.2337379455566, 7.37679290771484, 7.76446151733398, 7.37679290771484, 
    7.76446151733398, 21.1048812866211, 23.2337379455566, 7.37679290771484, 
    23.2337379455566, 23.2337379455566, 7.37679290771484, 21.1048812866211, 
    7.37679290771484, 21.1048812866211, 7.37679290771484, 21.1048812866211, 
    21.1048812866211, 21.1048812866211, 7.76446151733398, 7.76446151733398, 
    23.2337379455566, 23.2337379455566, 21.1048812866211, 23.2337379455566, 
    7.76446151733398, 7.76446151733398, 23.2337379455566, 23.2337379455566, 
    6.27709436416626, 23.2337379455566, 7.76446151733398, 7.76446151733398, 
    7.76446151733398, 21.1048812866211, 23.2337379455566, 7.37679290771484, 
    7.37679290771484, 23.2337379455566, 6.27709436416626, 21.1048812866211, 
    21.1048812866211, 7.76446151733398, 23.2337379455566, 7.37679290771484, 
    23.2337379455566, 6.27709436416626, 7.76446151733398, 23.2337379455566, 
    7.76446151733398, 21.1048812866211, 7.76446151733398, 7.37679290771484, 
    7.37679290771484, 21.1048812866211, 23.2337379455566, 21.1048812866211, 
    21.1048812866211, 21.1048812866211, 23.2337379455566, 23.2337379455566, 
    23.2337379455566, 23.2337379455566, 7.37679290771484, 23.2337379455566, 
    23.2337379455566, 21.1048812866211, 23.2337379455566, 7.37679290771484, 
    7.37679290771484, 21.1048812866211, 23.2337379455566, 21.1048812866211, 
    21.1048812866211, 7.76446151733398, 23.2337379455566, 21.1048812866211, 
    21.1048812866211, 7.37679290771484, 23.2337379455566, 7.37679290771484, 
    23.2337379455566, 7.37679290771484, 7.76446151733398, 23.2337379455566, 
    21.1048812866211, 21.1048812866211, 23.2337379455566, 7.37679290771484, 
    21.1048812866211, 7.76446151733398, 21.1048812866211, 21.1048812866211, 
    7.76446151733398, 21.1048812866211, 23.2337379455566, 7.37679290771484, 
    7.76446151733398, 21.1048812866211, 21.1048812866211, 7.37679290771484, 
    7.37679290771484, 23.2337379455566, 21.1048812866211, 7.76446151733398, 
    7.37679290771484, 7.37679290771484, 7.37679290771484, 21.1048812866211, 
    7.37679290771484, 7.37679290771484, 21.1048812866211, 23.2337379455566, 
    23.2337379455566, 23.2337379455566, 6.27709436416626, 21.1048812866211, 
    7.76446151733398, 21.1048812866211, 23.2337379455566, 21.1048812866211, 
    7.37679290771484, 7.76446151733398, 7.37679290771484, 21.1048812866211, 
    23.2337379455566, 21.1048812866211, 21.1048812866211, 23.2337379455566, 
    6.27709436416626, 7.37679290771484, 23.2337379455566, 23.2337379455566, 
    21.1048812866211, 21.1048812866211, 7.76446151733398, 21.1048812866211, 
    7.76446151733398, 21.1048812866211, 23.2337379455566, 7.37679290771484, 
    21.1048812866211, 7.76446151733398, 23.2337379455566, 7.76446151733398, 
    7.76446151733398, 21.1048812866211, 21.1048812866211, 6.27709436416626, 
    23.2337379455566, 7.37679290771484, 21.1048812866211, 21.1048812866211, 
    7.37679290771484, 7.37679290771484, 23.2337379455566, 21.1048812866211, 
    23.2337379455566, 21.1048812866211, 23.2337379455566, 23.2337379455566, 
    23.2337379455566, 23.2337379455566, 23.2337379455566, 7.37679290771484, 
    21.1048812866211, 23.2337379455566, 7.37679290771484, 23.2337379455566, 
    21.1048812866211, 21.1048812866211, 23.2337379455566, 23.2337379455566, 
    23.2337379455566, 7.76446151733398, 23.2337379455566, 21.1048812866211, 
    7.76446151733398, 7.37679290771484, 7.37679290771484, 7.76446151733398, 
    6.27709436416626, 23.2337379455566, 21.1048812866211, 23.2337379455566, 
    7.37679290771484, 7.76446151733398, 23.2337379455566, 21.1048812866211, 
    23.2337379455566, 7.37679290771484, 23.2337379455566, 21.1048812866211, 
    23.2337379455566, 7.37679290771484, 21.1048812866211, 23.2337379455566, 
    23.2337379455566, 21.1048812866211, 7.76446151733398, 23.2337379455566, 
    21.1048812866211, 21.1048812866211, 7.76446151733398, 7.76446151733398, 
    21.1048812866211, 7.37679290771484, 21.1048812866211, 23.2337379455566, 
    7.37679290771484, 21.1048812866211, 23.2337379455566, 7.76446151733398, 
    7.37679290771484, 7.37679290771484, 7.37679290771484, 23.2337379455566, 
    7.76446151733398, 21.1048812866211, 23.2337379455566, 7.37679290771484, 
    7.37679290771484, 21.1048812866211, 7.37679290771484, 21.1048812866211, 
    7.76446151733398, 21.1048812866211, 7.37679290771484, 21.1048812866211, 
    21.1048812866211, 21.1048812866211, 23.2337379455566, 21.1048812866211, 
    7.37679290771484, 23.2337379455566, 7.37679290771484, 7.37679290771484, 
    7.76446151733398, 23.2337379455566, 21.1048812866211, 7.37679290771484, 
    21.1048812866211, 23.2337379455566, 23.2337379455566, 23.2337379455566, 
    21.1048812866211, 7.37679290771484, 7.37679290771484, 23.2337379455566, 
    21.1048812866211, 23.2337379455566, 21.1048812866211, 21.1048812866211, 
    7.37679290771484, 21.1048812866211, 7.37679290771484, 21.1048812866211, 
    23.2337379455566, 23.2337379455566, 21.1048812866211, 23.2337379455566, 
    23.2337379455566, 7.37679290771484, 21.1048812866211, 21.1048812866211, 
    23.2337379455566, 21.1048812866211, 6.27709436416626, 7.37679290771484, 
    7.37679290771484, 7.76446151733398, 7.76446151733398, 21.1048812866211, 
    21.1048812866211, 21.1048812866211, 7.76446151733398, 7.76446151733398, 
    7.76446151733398, 7.37679290771484, 7.37679290771484, 7.37679290771484, 
    7.37679290771484, 7.37679290771484, 7.37679290771484, 23.2337379455566, 
    7.76446151733398, 7.76446151733398, 21.1048812866211, 7.76446151733398, 
    7.76446151733398, 7.37679290771484, 7.76446151733398, 23.2337379455566, 
    7.37679290771484, 7.76446151733398, 21.1048812866211, 7.76446151733398, 
    21.1048812866211, 7.37679290771484, 21.1048812866211, 7.76446151733398, 
    23.2337379455566, 7.76446151733398, 21.1048812866211, 7.37679290771484, 
    7.76446151733398, 21.1048812866211, 21.1048812866211, 7.76446151733398, 
    21.1048812866211, 23.2337379455566, 21.1048812866211, 23.2337379455566, 
    7.76446151733398, 21.1048812866211, 21.1048812866211, 23.2337379455566, 
    23.2337379455566, 7.37679290771484, 7.37679290771484, 7.37679290771484, 
    7.37679290771484, 21.1048812866211, 21.1048812866211, 21.1048812866211, 
    23.2337379455566, 21.1048812866211, 7.37679290771484, 21.1048812866211, 
    23.2337379455566, 7.37679290771484, 23.2337379455566, 7.76446151733398, 
    7.76446151733398, 23.2337379455566, 7.76446151733398, 7.37679290771484, 
    23.2337379455566, 7.37679290771484, 7.76446151733398, 7.37679290771484, 
    7.37679290771484, 21.1048812866211, 7.76446151733398, 21.1048812866211, 
    7.37679290771484, 23.2337379455566, 23.2337379455566, 21.1048812866211, 
    23.2337379455566, 6.27709436416626, 23.2337379455566, 7.76446151733398, 
    7.37679290771484, 7.37679290771484, 23.2337379455566, 21.1048812866211, 
    7.37679290771484, 23.2337379455566, 21.1048812866211, 7.37679290771484, 
    23.2337379455566, 21.1048812866211, 23.2337379455566, 7.76446151733398, 
    7.76446151733398, 6.27709436416626, 7.37679290771484, 7.76446151733398, 
    21.1048812866211, 7.37679290771484, 23.2337379455566, 23.2337379455566, 
    7.37679290771484, 7.76446151733398, 6.27709436416626, 7.37679290771484, 
    23.2337379455566, 21.1048812866211, 21.1048812866211, 21.1048812866211, 
    21.1048812866211, 7.76446151733398, 7.37679290771484, 21.1048812866211, 
    7.37679290771484, 23.2337379455566, 23.2337379455566, 7.37679290771484, 
    21.1048812866211, 7.76446151733398, 23.2337379455566, 7.37679290771484, 
    7.37679290771484, 7.37679290771484, 6.27709436416626, 23.2337379455566, 
    7.37679290771484, 21.1048812866211, 7.37679290771484, 21.1048812866211, 
    7.37679290771484, 7.37679290771484, 7.76446151733398, 21.1048812866211, 
    7.37679290771484, 7.76446151733398, 6.27709436416626, 7.76446151733398, 
    21.1048812866211, 7.76446151733398, 7.76446151733398, 23.2337379455566, 
    7.76446151733398, 7.37679290771484, 21.1048812866211, 23.2337379455566, 
    7.37679290771484, 21.1048812866211, 7.76446151733398, 7.76446151733398, 
    23.2337379455566, 7.76446151733398, 7.76446151733398, 7.37679290771484, 
    21.1048812866211, 7.37679290771484, 7.76446151733398, 6.27709436416626, 
    7.37679290771484, 21.1048812866211, 7.37679290771484, 6.27709436416626, 
    7.76446151733398, 21.1048812866211, 23.2337379455566, 21.1048812866211, 
    21.1048812866211, 21.1048812866211, 21.1048812866211, 7.37679290771484, 
    21.1048812866211, 21.1048812866211, 23.2337379455566, 7.37679290771484, 
    21.1048812866211, 21.1048812866211, 23.2337379455566, 23.2337379455566, 
    7.37679290771484, 7.37679290771484, 7.37679290771484, 7.37679290771484, 
    7.37679290771484, 21.1048812866211, 7.37679290771484, 7.37679290771484, 
    21.1048812866211, 21.1048812866211, 7.37679290771484, 23.2337379455566, 
    21.1048812866211, 7.37679290771484, 21.1048812866211, 7.76446151733398, 
    21.1048812866211, 21.1048812866211, 21.1048812866211, 6.27709436416626, 
    7.76446151733398, 23.2337379455566, 7.76446151733398, 21.1048812866211, 
    7.37679290771484, 6.27709436416626, 7.37679290771484, 6.27709436416626, 
    7.76446151733398, 21.1048812866211, 7.37679290771484, 21.1048812866211, 
    7.76446151733398, 7.37679290771484, 21.1048812866211, 7.37679290771484, 
    21.1048812866211, 21.1048812866211, 21.1048812866211, 21.1048812866211, 
    21.1048812866211, 21.1048812866211, 7.37679290771484, 21.1048812866211, 
    21.1048812866211, 6.27709436416626, 7.76446151733398, 7.37679290771484, 
    23.2337379455566, 7.37679290771484, 21.1048812866211, 7.37679290771484, 
    7.76446151733398, 23.2337379455566, 7.37679290771484, 7.37679290771484, 
    7.37679290771484, 7.76446151733398, 23.2337379455566, 23.2337379455566, 
    7.76446151733398, 7.37679290771484, 21.1048812866211, 6.27709436416626, 
    7.37679290771484, 21.1048812866211, 7.37679290771484, 23.2337379455566, 
    7.76446151733398, 21.1048812866211, 7.76446151733398, 23.2337379455566, 
    7.37679290771484, 6.27709436416626, 7.37679290771484, 7.76446151733398, 
    7.37679290771484, 21.1048812866211, 7.37679290771484, 7.37679290771484, 
    23.2337379455566, 7.37679290771484, 7.76446151733398, 7.37679290771484, 
    21.1048812866211, 23.2337379455566, 7.76446151733398, 23.2337379455566, 
    21.1048812866211, 7.76446151733398, 21.1048812866211, 7.37679290771484, 
    7.37679290771484, 7.37679290771484, 7.37679290771484, 21.1048812866211, 
    7.76446151733398, 7.76446151733398, 7.76446151733398, 7.37679290771484, 
    23.2337379455566, 23.2337379455566, 21.1048812866211, 6.27709436416626, 
    7.37679290771484, 21.1048812866211, 23.2337379455566, 7.76446151733398, 
    7.76446151733398, 23.2337379455566, 7.37679290771484, 23.2337379455566, 
    21.1048812866211, 7.37679290771484, 7.76446151733398, 21.1048812866211, 
    21.1048812866211, 23.2337379455566, 7.37679290771484, 7.76446151733398, 
    7.37679290771484, 23.2337379455566, 7.37679290771484, 7.76446151733398, 
    7.37679290771484, 21.1048812866211, 7.37679290771484, 21.1048812866211, 
    7.37679290771484, 7.37679290771484, 23.2337379455566, 21.1048812866211, 
    23.2337379455566, 7.76446151733398, 7.76446151733398, 21.1048812866211, 
    21.1048812866211, 6.27709436416626, 7.37679290771484, 7.37679290771484, 
    7.37679290771484, 7.76446151733398, 7.37679290771484, 7.37679290771484, 
    7.37679290771484, 23.2337379455566, 7.76446151733398, 7.37679290771484, 
    7.76446151733398, 7.37679290771484, 23.2337379455566, 7.37679290771484, 
    23.2337379455566, 23.2337379455566, 7.76446151733398, 7.37679290771484, 
    23.2337379455566, 21.1048812866211, 21.1048812866211, 7.37679290771484, 
    21.1048812866211, 7.76446151733398, 21.1048812866211, 7.37679290771484, 
    7.37679290771484, 21.1048812866211, 21.1048812866211, 21.1048812866211, 
    7.76446151733398, 7.37679290771484, 23.2337379455566, 23.2337379455566, 
    23.2337379455566, 21.1048812866211, 7.37679290771484, 7.37679290771484, 
    21.1048812866211, 7.76446151733398, 23.2337379455566, 7.76446151733398, 
    23.2337379455566, 23.2337379455566, 23.2337379455566, 7.37679290771484, 
    7.37679290771484, 7.76446151733398, 23.2337379455566, 23.2337379455566, 
    23.2337379455566, 21.1048812866211, 21.1048812866211, 7.37679290771484, 
    7.76446151733398, 7.37679290771484, 23.2337379455566, 23.2337379455566, 
    21.1048812866211, 23.2337379455566, 21.1048812866211, 7.76446151733398, 
    23.2337379455566, 21.1048812866211, 7.37679290771484, 23.2337379455566, 
    7.37679290771484, 21.1048812866211, 23.2337379455566, 7.76446151733398, 
    21.1048812866211, 7.37679290771484, 7.76446151733398, 2.56194615364075, 
    2.55563926696777, 2.55563926696777, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.55563926696777, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.55563926696777, 2.55563926696777, 2.56194615364075, 
    2.55563926696777, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.55563926696777, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.55563926696777, 
    2.56194615364075, 2.55563926696777, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.55563926696777, 2.55563926696777, 2.55563926696777, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.55563926696777, 2.55563926696777, 2.56194615364075, 2.55563926696777, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.55563926696777, 2.56194615364075, 2.55563926696777, 2.56194615364075, 
    2.55563926696777, 2.56194615364075, 2.55563926696777, 2.55563926696777, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.55563926696777, 2.56194615364075, 
    2.55563926696777, 2.56194615364075, 2.56194615364075, 2.55563926696777, 
    2.55563926696777, 2.56194615364075, 2.55563926696777, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.55563926696777, 2.55563926696777, 2.56194615364075, 2.56194615364075, 
    2.55563926696777, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.55563926696777, 2.55563926696777, 2.56194615364075, 
    2.55563926696777, 2.55563926696777, 2.56194615364075, 2.55563926696777, 
    2.55563926696777, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.55563926696777, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.55563926696777, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.55563926696777, 2.56194615364075, 
    2.55563926696777, 2.56194615364075, 2.55563926696777, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.55563926696777, 2.56194615364075, 
    2.55563926696777, 2.55563926696777, 2.56194615364075, 2.55563926696777, 
    2.56194615364075, 2.55563926696777, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.55563926696777, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.55563926696777, 2.55563926696777, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.55563926696777, 2.56194615364075, 2.56194615364075, 2.55563926696777, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.55563926696777, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.55563926696777, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.55563926696777, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.55563926696777, 
    2.56194615364075, 2.56194615364075, 2.55563926696777, 2.56194615364075, 
    2.55563926696777, 2.55563926696777, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.55563926696777, 2.55563926696777, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.55563926696777, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.55563926696777, 
    2.55563926696777, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.55563926696777, 
    2.56194615364075, 2.56194615364075, 2.55563926696777, 2.55563926696777, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.55563926696777, 2.56194615364075, 
    2.55563926696777, 2.56194615364075, 2.55563926696777, 2.55563926696777, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.55563926696777, 
    2.56194615364075, 2.56194615364075, 2.56194615364075, 2.56194615364075, 
    11.7768239974976, 11.9850568771362, 11.9850568771362, 11.9850568771362, 
    22.314998626709, 11.9850568771362, 11.7768239974976, 11.9850568771362, 
    11.9850568771362, 11.9850568771362, 11.9850568771362, 11.9850568771362, 
    11.9850568771362, 11.9850568771362, 11.9850568771362, 7.26948213577271, 
    7.29503440856934, 6.049973487854, 7.74177837371826, 5.88427782058716, 
    8.4395170211792, 8.3098087310791, 8.3098087310791, 6.08962440490723, 
    7.11380386352539, 6.88642168045044, 8.0387601852417, 8.5859317779541, 
    7.08579874038696, 5.43175840377808, 6.32296323776245, 6.88642168045044, 
    7.74177837371826, 6.69394540786743, 8.5859317779541, 5.08998727798462, 
    6.36139392852783, 6.36139392852783, 6.049973487854, 6.08842039108276, 
    6.08962440490723, 8.0387601852417, 7.00500679016113, 7.11380386352539, 
    5.88427782058716, 7.74177837371826, 8.3098087310791, 8.3098087310791, 
    6.69394540786743, 7.29503440856934, 22.7133331298828, 21.7515506744385, 
    21.7515506744385, 21.7515506744385, 8.44301128387451, 7.89005327224731, 
    7.89005327224731, 7.89005327224731, 7.89005327224731, 6.88642168045044, 
    6.08962440490723, 7.74177837371826, 7.08579874038696, 7.29503440856934, 
    6.66747808456421, 6.08842039108276, 7.74177837371826, 5.08998727798462, 
    7.08579874038696, 8.49756908416748, 6.32296323776245, 8.49756908416748, 
    8.13191413879395, 7.30501985549927, 6.32296323776245, 21.7515506744385, 
    21.7515506744385, 21.7515506744385, 21.7515506744385, 21.7515506744385, 
    6.21464824676514, 7.7702522277832, 7.00500679016113, 8.57161712646484, 
    7.08579874038696, 7.11380386352539, 8.58236598968506, 8.49756908416748, 
    8.44301128387451, 7.30501985549927, 7.74177837371826, 8.5859317779541, 
    7.00500679016113, 8.44301128387451, 8.58236598968506, 6.08842039108276, 
    6.21464824676514, 8.49756908416748, 6.08842039108276, 7.30501985549927, 
    21.7515506744385, 21.7515506744385, 21.7515506744385, 6.08842039108276, 
    6.88642168045044, 7.08579874038696, 5.08998727798462, 7.29503440856934, 
    7.74177837371826, 7.08579874038696, 8.4395170211792, 6.08962440490723, 
    6.69394540786743, 7.74177837371826, 8.13191413879395, 7.00500679016113, 
    6.08842039108276, 7.26948213577271, 8.4395170211792, 8.57161712646484, 
    7.7702522277832, 8.58236598968506, 5.88427782058716, 6.21464824676514, 
    5.43175840377808, 6.32296323776245, 6.08842039108276, 21.7515506744385, 
    21.7515506744385, 8.49756908416748, 5.88427782058716, 7.89005327224731, 
    7.89005327224731, 7.89005327224731, 7.89005327224731, 7.74177837371826, 
    7.89005327224731, 8.58236598968506, 7.29503440856934, 5.88427782058716, 
    7.74177837371826, 8.3098087310791, 6.66747808456421, 7.00500679016113, 
    7.29503440856934, 5.88427782058716, 8.5859317779541, 7.00500679016113, 
    8.0387601852417, 8.58236598968506, 8.58236598968506, 5.88427782058716, 
    5.88427782058716, 6.21464824676514, 5.88427782058716, 7.26948213577271, 
    5.43175840377808, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    8.12717437744141, 8.12717437744141, 8.12717437744141, 8.12717437744141, 
    41.5680847167969, 41.5680847167969, 41.5680847167969, 41.5680847167969, 
    41.5680847167969, 41.5680847167969, 41.5680847167969, 41.5680847167969, 
    41.5680847167969, 41.5680847167969, 41.5680847167969, NA, NA, 
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA)
)
#############################################

####Analyses P Olsen
#############################################
####P Olsen - model N
#set combinations of elements
combi<-c("taxa.p","taxa.n","taxa.c","taxa.np","taxa.cp","taxa.cn")

#set element to response: 1=taxa.p, 2=taxa.n, 4=taxa.np
element=2

#use lm_robust:mixed=FALSE or lmer(): mixed=TRUE
mixed=TRUE

#set number of iterations for estimating pvalues
iter=1000
#

dbdx<-db%>%
  cbind(P_olsen)%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source1 %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_olsen,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         species=as.factor(sp.morphosp_revised),
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(paste0(lat.dec," ",long.dec)))%>%
  dplyr::select(combi[element],Temp,Rad,N,P,habitat,autohetero,species,location)%>%
  as.data.frame()%>%
  na.omit()

if(element %in% c(1,2,3)){
  dbdx$Yl<-log((dbdx[,combi[element]]/100)/(1-(dbdx[,combi[element]]/100))) #for n,p,c when logit
}

if(element %in% c(4,5,6)){
  dbdx$Yl<-log(dbdx[,combi[element]]) #for n,p,c when logit
}


### contrast coding of factors
contrasts(dbdx$habitat) <-contr.sum(2)
contrasts(dbdx$autohetero) <-contr.sum(2)

###log or scale predictors
dbdx=dbdx%>%
  mutate(N=log(N),
         P=log(P))

lmemod<-lmer(Yl~habitat+autohetero+Temp+Rad+N+P+
               Temp:habitat+Rad:habitat+P:habitat+N:habitat+Temp:autohetero+Rad:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
               (1|species),data=as.data.frame(dbdx))


te7<-as.data.frame(pairs(emmeans(lmemod, pairwise ~ habitat*autohetero),adjust="none"))
te71<-te7[c(1,2,5,6),]
teDat4<-data.frame(type="effect",
                   case=c(as.character(te71$contrast)),
                   trend=c(te71$estimate),
                   SE=c(te71$SE),
                   df=c(te71$df))

#Temp
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("Temp") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("Temp") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("Temp") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$Temp.trend,te21$Temp.trend,te12$estimate,te22$estimate,te3$Temp.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Temp.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsT<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="Temp")

#Rad
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("Rad") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("Rad") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("Rad") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$Rad.trend,te21$Rad.trend,te12$estimate,te22$estimate,te3$Rad.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Rad.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsR<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="Rad")

#N
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("N") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("N") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("N") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$N.trend,te21$N.trend,te12$estimate,te22$estimate,te3$N.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$N.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsN<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="N")

#P
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("P") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("P") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("P") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$P.trend,te21$P.trend,te12$estimate,te22$estimate,te3$P.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$P.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsP<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="P")

obsA<-rbind(obsT,obsR,obsN,obsP,mutate(teDat4,var="habtrop"))%>%
  mutate(iteration=0)

#ll2random<-list()
dbdx1<-dbdx%>%group_by(Temp,Rad,N,P)%>%mutate(loc_id = cur_group_id())%>%ungroup() 
dbdx2<-dbdx1%>%group_by(Temp,Rad,N,P)%>%summarise(loc_id =loc_id[1])%>%ungroup()
datCp<-list()
set.seed(3333)
for(i in 1:iter){
  dbdx2x<-dbdx2
  dbdx2x$loc_id<-sample(dbdx2$loc_id)
  names(dbdx2x)<-c("TempS","RadS","NS","PS","loc_id")
  dbdx3<-left_join(dbdx1,dbdx2x,by="loc_id")%>%
    mutate(Temp=TempS,Rad=RadS,N=NS,P=PS)
  
  lmemodperm<-lmer(Yl~habitat+autohetero+Temp+Rad+N+P+
                     Temp:habitat+Rad:habitat+P:habitat+N:habitat+Temp:autohetero+Rad:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
                     (1|species),data=as.data.frame(dbdx3))
  
  te7<-as.data.frame(pairs(emmeans(lmemodperm, pairwise ~ habitat*autohetero),adjust="none"))
  te71<-te7[c(1,2,5,6),]
  teDat4<-data.frame(type="effect",
                     case=c(as.character(te71$contrast)),
                     trend=c(te71$estimate),
                     SE=c(te71$SE),
                     df=c(te71$df))
  
  suppressMessages({te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Temp") )
  #Temp
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Temp") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("Temp") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("Temp") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("Temp") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$Temp.trend,te21$Temp.trend,te12$estimate,te22$estimate,te3$Temp.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Temp.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsT<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="Temp")
  
  #Rad
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat"))
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Rad") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("Rad") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("Rad") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("Rad") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$Rad.trend,te21$Rad.trend,te12$estimate,te22$estimate,te3$Rad.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Rad.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsR<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="Rad")
  
  #N
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("N") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("N") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("N") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$N.trend,te21$N.trend,te12$estimate,te22$estimate,te3$N.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$N.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsN<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="N")
  
  #P
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("P") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("P") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("P") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("P") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$P.trend,te21$P.trend,te12$estimate,te22$estimate,te3$P.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$P.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsP<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="P")
  obsAx<-rbind(obsT,obsR,obsN,obsP,mutate(teDat4,var="habtrop"))%>%
    mutate(iteration=i)
  
  })
  
  obsA<-rbind(obsA,obsAx)
  #ll2random[[i]]<-ranef(lmemodperm)
  datte<-ggemmeans(lmemodperm,c("Temp","autohetero","habitat") ,typical="mean")%>%
    mutate(var="Temp")
  datra<-ggemmeans(lmemodperm,c("Rad","autohetero","habitat") ,typical="mean")%>%
    mutate(var="Rad")
  datn<-ggemmeans(lmemodperm,c("N","autohetero","habitat") ,typical="mean")%>%
    mutate(var="N")
  datp<-ggemmeans(lmemodperm,c("P","autohetero","habitat") ,typical="mean")%>%
    mutate(var="P")
  
  datCp[[i]]<-rbind(datte,datra,datn,datp)
}

obsA_1<-obsA
datCp_1<-datCp
save(obsA_1,
     datCp_1,
     lmemod,
     file="data.lmer_1k_em_perm_N_1_sp_log_pred_polsen.RData")

####P Olsen - model P
#set combinations of elements
combi<-c("taxa.p","taxa.n","taxa.c","taxa.np","taxa.cp","taxa.cn")

#set element to response: 1=taxa.p, 2=taxa.n, 4=taxa.np
element=1

#use lm_robust:mixed=FALSE or lmer(): mixed=TRUE
mixed=TRUE

#set number of iterations for estimating pvalues
iter=1000
#

dbdx<-db%>%
  cbind(P_olsen)%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source1 %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_olsen,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         species=as.factor(sp.morphosp_revised),
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(paste0(lat.dec," ",long.dec)))%>%
  dplyr::select(combi[element],Temp,Rad,N,P,habitat,autohetero,species,location)%>%
  as.data.frame()%>%
  na.omit()

if(element %in% c(1,2,3)){
  dbdx$Yl<-log((dbdx[,combi[element]]/100)/(1-(dbdx[,combi[element]]/100))) #for n,p,c when logit
}

if(element %in% c(4,5,6)){
  dbdx$Yl<-log(dbdx[,combi[element]]) #for n,p,c when logit
}


### contrast coding of factors
contrasts(dbdx$habitat) <-contr.sum(2)
contrasts(dbdx$autohetero) <-contr.sum(2)

###log or scale predictors
dbdx=dbdx%>%
  mutate(N=log(N),
         P=log(P))


lmemod<-lmer(Yl~habitat+autohetero+Temp+Rad+N+P+
               Temp:habitat+Rad:habitat+P:habitat+N:habitat+Temp:autohetero+Rad:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
               (1|species),data=as.data.frame(dbdx))

te7<-as.data.frame(pairs(emmeans(lmemod, pairwise ~ habitat*autohetero),adjust="none"))
te71<-te7[c(1,2,5,6),]
teDat4<-data.frame(type="effect",
                   case=c(as.character(te71$contrast)),
                   trend=c(te71$estimate),
                   SE=c(te71$SE),
                   df=c(te71$df))

#Temp
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("Temp") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("Temp") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("Temp") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$Temp.trend,te21$Temp.trend,te12$estimate,te22$estimate,te3$Temp.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Temp.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsT<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="Temp")

#Rad
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("Rad") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("Rad") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("Rad") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$Rad.trend,te21$Rad.trend,te12$estimate,te22$estimate,te3$Rad.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Rad.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsR<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="Rad")

#N
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("N") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("N") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("N") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$N.trend,te21$N.trend,te12$estimate,te22$estimate,te3$N.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$N.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsN<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="N")

#P
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("P") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("P") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("P") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$P.trend,te21$P.trend,te12$estimate,te22$estimate,te3$P.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$P.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsP<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="P")

obsA<-rbind(obsT,obsR,obsN,obsP,mutate(teDat4,var="habtrop"))%>%
  mutate(iteration=0)

#ll2random<-list()
dbdx1<-dbdx%>%group_by(Temp,Rad,N,P)%>%mutate(loc_id = cur_group_id())%>%ungroup() 
dbdx2<-dbdx1%>%group_by(Temp,Rad,N,P)%>%summarise(loc_id =loc_id[1])%>%ungroup()
datCp<-list()
set.seed(3333)
for(i in 1:iter){
  dbdx2x<-dbdx2
  dbdx2x$loc_id<-sample(dbdx2$loc_id)
  names(dbdx2x)<-c("TempS","RadS","NS","PS","loc_id")
  dbdx3<-left_join(dbdx1,dbdx2x,by="loc_id")%>%
    mutate(Temp=TempS,Rad=RadS,N=NS,P=PS)
  
  lmemodperm<-lmer(Yl~habitat+autohetero+Temp+Rad+N+P+
                     Temp:habitat+Rad:habitat+P:habitat+N:habitat+Temp:autohetero+Rad:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
                     (1|species),data=as.data.frame(dbdx3))
  
  te7<-as.data.frame(pairs(emmeans(lmemodperm, pairwise ~ habitat*autohetero),adjust="none"))
  te71<-te7[c(1,2,5,6),]
  teDat4<-data.frame(type="effect",
                     case=c(as.character(te71$contrast)),
                     trend=c(te71$estimate),
                     SE=c(te71$SE),
                     df=c(te71$df))
  
  suppressMessages({te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Temp") )
  #Temp
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Temp") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("Temp") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("Temp") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("Temp") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$Temp.trend,te21$Temp.trend,te12$estimate,te22$estimate,te3$Temp.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Temp.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsT<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="Temp")
  
  #Rad
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat"))
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Rad") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("Rad") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("Rad") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("Rad") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$Rad.trend,te21$Rad.trend,te12$estimate,te22$estimate,te3$Rad.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Rad.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsR<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="Rad")
  
  #N
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("N") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("N") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("N") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$N.trend,te21$N.trend,te12$estimate,te22$estimate,te3$N.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$N.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsN<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="N")
  
  #P
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("P") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("P") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("P") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("P") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$P.trend,te21$P.trend,te12$estimate,te22$estimate,te3$P.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$P.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsP<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="P")
  obsAx<-rbind(obsT,obsR,obsN,obsP,mutate(teDat4,var="habtrop"))%>%
    mutate(iteration=i)
  
  })
  
  obsA<-rbind(obsA,obsAx)
  #ll2random[[i]]<-ranef(lmemodperm)
  datte<-ggemmeans(lmemodperm,c("Temp","autohetero","habitat") ,typical="mean")%>%
    mutate(var="Temp")
  datra<-ggemmeans(lmemodperm,c("Rad","autohetero","habitat") ,typical="mean")%>%
    mutate(var="Rad")
  datn<-ggemmeans(lmemodperm,c("N","autohetero","habitat") ,typical="mean")%>%
    mutate(var="N")
  datp<-ggemmeans(lmemodperm,c("P","autohetero","habitat") ,typical="mean")%>%
    mutate(var="P")
  
  datCp[[i]]<-rbind(datte,datra,datn,datp)
}

obsA_1<-obsA
datCp_1<-datCp
save(obsA_1,
     datCp_1,
     lmemod,
     file="data.lmer_1k_em_perm_P_1_sp_log_pred_polsen.RData")

####P Olsen - model N:P
#set combinations of elements
combi<-c("taxa.p","taxa.n","taxa.c","taxa.np","taxa.cp","taxa.cn")

#set element to response: 1=taxa.p, 2=taxa.n, 4=taxa.np
element=4

#use lm_robust:mixed=FALSE or lmer(): mixed=TRUE
mixed=TRUE

#set number of iterations for estimating pvalues
iter=1000
#

dbdx<-db%>%
  cbind(P_olsen)%>%
  filter(!(class_revised %in% c("Aves","Mammalia")))%>%
  filter(!(data.source1 %in% "Freschet et al (2010)"))%>%
  filter(!(habitat %in% "marine"))%>%
  mutate(P=ifelse(habitat %in% c("freshwater","terrestrial"),P_olsen,
                  ifelse(habitat %in% c("marine"),P_marine,NA)),
         autohetero=case_when(invert.vert.auto == "autotroph" ~ "autotroph",
                              invert.vert.auto == "invertebrate" ~ "heterotroph",
                              invert.vert.auto == "vertebrate" ~ "heterotroph",
                              TRUE ~ as.character(invert.vert.auto)))%>%
  mutate(Temp=nasa.T10M,Rad=nasa.ALLSKY_SFC_SW_DWN,P=P,N=meanN_tot,
         taxa.p=taxa.p,taxa.n=taxa.n,taxa.np=taxa.np,
         species=as.factor(sp.morphosp_revised),
         habitat=as.factor(habitat),
         autohetero=as.factor(autohetero),
         location=as.factor(paste0(lat.dec," ",long.dec)))%>%
  dplyr::select(combi[element],Temp,Rad,N,P,habitat,autohetero,species,location)%>%
  as.data.frame()%>%
  na.omit()

if(element %in% c(1,2,3)){
  dbdx$Yl<-log((dbdx[,combi[element]]/100)/(1-(dbdx[,combi[element]]/100))) #for n,p,c when logit
}

if(element %in% c(4,5,6)){
  dbdx$Yl<-log(dbdx[,combi[element]]) #for n,p,c when logit
}


### contrast coding of factors
contrasts(dbdx$habitat) <-contr.sum(2)
contrasts(dbdx$autohetero) <-contr.sum(2)

###log or scale predictors
dbdx=dbdx%>%
  mutate(N=log(N),
         P=log(P))

lmemod<-lmer(Yl~habitat+autohetero+Temp+Rad+N+P+
               Temp:habitat+Rad:habitat+P:habitat+N:habitat+Temp:autohetero+Rad:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
               (1|species),data=as.data.frame(dbdx))


te7<-as.data.frame(pairs(emmeans(lmemod, pairwise ~ habitat*autohetero),adjust="none"))
te71<-te7[c(1,2,5,6),]
teDat4<-data.frame(type="effect",
                   case=c(as.character(te71$contrast)),
                   trend=c(te71$estimate),
                   SE=c(te71$SE),
                   df=c(te71$df))

#Temp
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("Temp") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("Temp") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("Temp") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$Temp.trend,te21$Temp.trend,te12$estimate,te22$estimate,te3$Temp.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Temp.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsT<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="Temp")

#Rad
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("Rad") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("Rad") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("Rad") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$Rad.trend,te21$Rad.trend,te12$estimate,te22$estimate,te3$Rad.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Rad.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsR<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="Rad")

#N
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("N") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("N") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("N") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$N.trend,te21$N.trend,te12$estimate,te22$estimate,te3$N.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$N.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsN<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="N")

#P
#emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("lat") )
te1<-emtrends(lmemod, pairwise ~ habitat, var = c("P") )
te11<-as.data.frame(te1$emtrends)
te12<-as.data.frame(te1$contrasts)
te2<-emtrends(lmemod, pairwise ~ autohetero, var = c("P") )
te21<-as.data.frame(te2$emtrends)
te22<-as.data.frame(te2$contrast)
te3<-as.data.frame(emtrends(lmemod,  ~ 1, var = c("P") ))
te4<-as.data.frame(pairs(emmeans(lmemod, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te5<-as.data.frame(pairs(emmeans(lmemod, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
te6<-as.data.frame(emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$emtrends)
teDat<-data.frame(type="slope",
                  case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                  trend=c(te11$P.trend,te21$P.trend,te12$estimate,te22$estimate,te3$P.trend),
                  SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                  df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
)
teDat2<-data.frame(type="intercept",
                   case=c(as.character(te4$contrast),as.character(te5$contrast)),
                   trend=c(te4$estimate,te5$estimate),
                   SE=c(te4$SE,te5$SE),
                   df=c(te4$df,te5$df)
)
teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$P.trend,SE=te6$SE,df=te6$df)%>%
  rbind(
    data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$contrasts)%>%
      mutate(case=contrast,trend=estimate)%>%
      filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                         "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
      dplyr::select(type,case,trend,SE,df)
  )

obsP<-rbind(teDat,teDat2,teDat3)%>%
  mutate(var="P")

obsA<-rbind(obsT,obsR,obsN,obsP,mutate(teDat4,var="habtrop"))%>%
  mutate(iteration=0)

#ll2random<-list()
dbdx1<-dbdx%>%group_by(Temp,Rad,N,P)%>%mutate(loc_id = cur_group_id())%>%ungroup() 
dbdx2<-dbdx1%>%group_by(Temp,Rad,N,P)%>%summarise(loc_id =loc_id[1])%>%ungroup()
datCp<-list()
set.seed(3333)
for(i in 1:iter){
  dbdx2x<-dbdx2
  dbdx2x$loc_id<-sample(dbdx2$loc_id)
  names(dbdx2x)<-c("TempS","RadS","NS","PS","loc_id")
  dbdx3<-left_join(dbdx1,dbdx2x,by="loc_id")%>%
    mutate(Temp=TempS,Rad=RadS,N=NS,P=PS)
  
  lmemodperm<-lmer(Yl~habitat+autohetero+Temp+Rad+N+P+
                     Temp:habitat+Rad:habitat+P:habitat+N:habitat+Temp:autohetero+Rad:autohetero+P:autohetero+N:autohetero+autohetero:habitat+
                     (1|species),data=as.data.frame(dbdx3))
  
  te7<-as.data.frame(pairs(emmeans(lmemodperm, pairwise ~ habitat*autohetero),adjust="none"))
  te71<-te7[c(1,2,5,6),]
  teDat4<-data.frame(type="effect",
                     case=c(as.character(te71$contrast)),
                     trend=c(te71$estimate),
                     SE=c(te71$SE),
                     df=c(te71$df))
  
  suppressMessages({te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Temp") )
  #Temp
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Temp") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("Temp") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("Temp") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("Temp") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$Temp.trend,te21$Temp.trend,te12$estimate,te22$estimate,te3$Temp.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Temp.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Temp") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsT<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="Temp")
  
  #Rad
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat"))
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("Rad") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("Rad") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("Rad") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("Rad") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$Rad.trend,te21$Rad.trend,te12$estimate,te22$estimate,te3$Rad.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$Rad.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("Rad") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsR<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="Rad")
  
  #N
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("N") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("N") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("N") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("N") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$N.trend,te21$N.trend,te12$estimate,te22$estimate,te3$N.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$N.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("N") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsN<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="N")
  
  #P
  #emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("lat") )
  te1<-emtrends(lmemodperm, pairwise ~ habitat, var = c("P") )
  te11<-as.data.frame(te1$emtrends)
  te12<-as.data.frame(te1$contrasts)
  te2<-emtrends(lmemodperm, pairwise ~ autohetero, var = c("P") )
  te21<-as.data.frame(te2$emtrends)
  te22<-as.data.frame(te2$contrast)
  te3<-as.data.frame(emtrends(lmemodperm,  ~ 1, var = c("P") ))
  te4<-as.data.frame(pairs(emmeans(lmemodperm, ~habitat,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te5<-as.data.frame(pairs(emmeans(lmemodperm, ~autohetero,at=list(Temp=0,Rad=0,N=0,P=0) ),adjust="none"))
  te6<-as.data.frame(emtrends(lmemodperm, pairwise ~ habitat*autohetero, var = c("P") )$emtrends)
  teDat<-data.frame(type="slope",
                    case=c(as.character(te11$habitat),as.character(te21$autohetero),as.character(te12$contrast),as.character(te22$contrast),as.character(te3$`1`)),
                    trend=c(te11$P.trend,te21$P.trend,te12$estimate,te22$estimate,te3$P.trend),
                    SE=c(te11$SE,te21$SE,te12$SE,te22$SE,te3$SE),
                    df=c(te11$df,te21$df,te12$df,te22$df,te3$df)
  )
  teDat2<-data.frame(type="intercept",
                     case=c(as.character(te4$contrast),as.character(te5$contrast)),
                     trend=c(te4$estimate,te5$estimate),
                     SE=c(te4$SE,te5$SE),
                     df=c(te4$df,te5$df)
  )
  teDat3<-data.frame(type="slope",case=as.character(paste0(te6$habitat," ",te6$autohetero)),trend=te6$P.trend,SE=te6$SE,df=te6$df)%>%
    rbind(
      data.frame(type="slope",emtrends(lmemod, pairwise ~ habitat*autohetero, var = c("P") )$contrasts)%>%
        mutate(case=contrast,trend=estimate)%>%
        filter(case %in% c("freshwater autotroph - terrestrial autotroph","freshwater autotroph - freshwater heterotroph",
                           "terrestrial autotroph - terrestrial heterotroph","freshwater heterotroph - terrestrial heterotroph"))%>%
        dplyr::select(type,case,trend,SE,df)
    )
  
  obsP<-rbind(teDat,teDat2,teDat3)%>%
    mutate(var="P")
  obsAx<-rbind(obsT,obsR,obsN,obsP,mutate(teDat4,var="habtrop"))%>%
    mutate(iteration=i)
  
  })
  
  obsA<-rbind(obsA,obsAx)
  datte<-ggemmeans(lmemodperm,c("Temp","autohetero","habitat") ,typical="mean")%>%
    mutate(var="Temp")
  datra<-ggemmeans(lmemodperm,c("Rad","autohetero","habitat") ,typical="mean")%>%
    mutate(var="Rad")
  datn<-ggemmeans(lmemodperm,c("N","autohetero","habitat") ,typical="mean")%>%
    mutate(var="N")
  datp<-ggemmeans(lmemodperm,c("P","autohetero","habitat") ,typical="mean")%>%
    mutate(var="P")
  
  datCp[[i]]<-rbind(datte,datra,datn,datp)
  #ll2random[[i]]<-ranef(lmemodperm)
}

obsA_1<-obsA
datCp_1<-datCp
save(obsA_1,
     datCp_1,
     lmemod,
     file="data.lmer_1k_em_perm_NP_1_sp_log_pred_polsen.RData")

####prepare table result P Olsen
load("data.lmer_1k_em_perm_N_1_sp_log_pred_polsen.RData")
load("data.lmer_1k_em_perm_P_1_sp_log_pred_polsen.RData")
load("data.lmer_1k_em_perm_NP_1_sp_log_pred_polsen.RData")


dbdx=lmemod@frame


ll1<-obsA_1
obsA<-obsA_1%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% c("intercept","effect")))%>%
  group_by(type,case,var)%>%
  summarise(pvalue=mean(abs(trend[iteration!=0]/SE[iteration!=0]) >= abs(trend[iteration==0]/SE[iteration==0])))
obsA$padjustBO<-p.adjust(obsA$pvalue)
obsA$padjustBH<-p.adjust(obsA$pvalue,method="BH")

datte<-ggemmeans(lmemod,c("Temp","autohetero","habitat") ,typical="mean")%>%
  mutate(var="Temp")
datra<-ggemmeans(lmemod,c("Rad","autohetero","habitat") ,typical="mean")%>%
  mutate(var="Rad")
datn<-ggemmeans(lmemod,c("N","autohetero","habitat") ,typical="mean")%>%
  mutate(var="N")
datp<-ggemmeans(lmemod,c("P","autohetero","habitat") ,typical="mean")%>%
  mutate(var="P")

datC<-rbind(datte,datra,datn,datp)%>%
  mutate(case=paste0(facet," ",group))%>%
  left_join(obsA,by=c("case","var"))%>%
  mutate(significance=ifelse(padjustBH < 0.05,"significant","not significant")) #pvalue, padjustBO, padjustBH

dbdx2<-data.frame(predicted=(dbdx$Yl),facet=dbdx$habitat,group=dbdx$autohetero,x=c(dbdx$Temp,dbdx$P,dbdx$N,dbdx$Rad),var=rep(c("Temp","P","N","Rad"),each=nrow(dbdx)))


ll1%>%
  filter(iteration %in% 0)%>%
  dplyr::select(type,case,var,trend,SE)%>%
  left_join(obsA,by=c("type","case","var"))%>%
  filter(padjustBH < 0.05)%>%#pvalue, padjustBH, padjustBO
  View()

##prepare tables appendices
test=ll1%>%
  filter(iteration %in% 0)%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% "intercept"))%>%
  dplyr::select(type,case,var,trend,SE)%>%
  left_join(obsA,by=c("type","case","var"))%>%
  mutate(element="N",
         trend=formatC(trend, format = "e", digits = 1),
         SE=formatC(SE, format = "e", digits = 1),
         pvalue=round(pvalue,3),
         padjustBH=round(padjustBH,3),
         sig=ifelse(padjustBH < 0.05,"sig","nonsig"))%>%
  dplyr::select(element,type,case,var,trend,SE,pvalue,padjustBH,sig)%>%
  .[c(7,1:2,5,3:4,6,8:15,
      22,16:17,20,18:19,21,23:30,
      37,31:32,35,33:34,36,38:45,
      52,46:47,50,48:49,51,53:60),]

##write.table(test,file="resultsN_polsen.doc",row.names=F,quote=F,sep=";")
test=ll1%>%
  filter(iteration %in% 0)%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% "intercept"))%>%
  dplyr::select(type,case,var,trend,SE)%>%
  left_join(obsA,by=c("type","case","var"))%>%
  mutate(element="P",
         trend=formatC(trend, format = "e", digits = 1),
         SE=formatC(SE, format = "e", digits = 1),
         pvalue=round(pvalue,3),
         padjustBH=round(padjustBH,3),
         sig=ifelse(padjustBH < 0.05,"sig","nonsig"))%>%
  dplyr::select(element,type,case,var,trend,SE,pvalue,padjustBH,sig)%>%
  .[c(7,1:2,5,3:4,6,8:15,
      22,16:17,20,18:19,21,23:30,
      37,31:32,35,33:34,36,38:45,
      52,46:47,50,48:49,51,53:60),]
##write.table(test,file="resultsP_polsen.doc",row.names=F,quote=F,sep=";")
test=ll1%>%
  filter(iteration %in% 0)%>%
  filter(!(type %in% c("intercept","effect")))%>%#filter(!(type %in% "intercept"))%>%
  dplyr::select(type,case,var,trend,SE)%>%
  left_join(obsA,by=c("type","case","var"))%>%
  mutate(element="N:P",
         trend=formatC(trend, format = "e", digits = 1),
         SE=formatC(SE, format = "e", digits = 1),
         pvalue=round(pvalue,3),
         padjustBH=round(padjustBH,3),
         sig=ifelse(padjustBH < 0.05,"sig","nonsig"))%>%
  dplyr::select(element,type,case,var,trend,SE,pvalue,padjustBH,sig)%>%
  .[c(7,1:2,5,3:4,6,8:15,
      22,16:17,20,18:19,21,23:30,
      37,31:32,35,33:34,36,38:45,
      52,46:47,50,48:49,51,53:60),]
##write.table(test,file="resultsNP_polsen.doc",row.names=F,quote=F,sep=";")

#############################################

####responses to reviewers of Nat.Comm.
#############################################
#find what taxa are dominating terrestrial and aquatic autotrophs
db%>%
  filter(troph %in% "autotroph")%>%
  select(habitat.gen,class_revised)%>%
  group_by(habitat.gen,class_revised)%>%
  summarize(n=n())%>%
  arrange(desc(habitat.gen),n)%>%
  mutate(percent=n/sum(n)*100)%>%
  #filter(n>300)%>%
  View()
db%>%
  filter(troph %in% "heterotroph")%>%
  select(habitat.gen,class_revised)%>%
  group_by(habitat.gen,class_revised)%>%
  summarize(n=n())%>%
  arrange(desc(habitat.gen),n)%>%
  mutate(percent=n/sum(n)*100)%>%
  #filter(n>300)%>%
  View()
db%>%
  filter(troph %in% "autotroph")%>%
  select(habitat.gen,family_revised)%>%
  group_by(habitat.gen,family_revised)%>%
  summarize(n=n())%>%
  arrange(desc(habitat.gen),n)%>%
  #filter(n>300)%>%
  View()

filter(db, habitat.gen %in% "aquatic")%>%
  filter(class_revised %in% "Liliopsida")%>%
  select(ends_with("_revised"))%>%
  distinct()%>%
  View()
#############################################

####second round of revisions by reviewers of Nat.Comm.
#############################################
load("data.lmer_1k_em_perm_lat_N_1_sp.RData")
lat_N=lmemod@frame
load("data.lmer_1k_em_perm_lat_P_1_sp.RData")
lat_P=lmemod@frame
load("data.lmer_1k_em_perm_lat_NP_1_sp.RData")
lat_NP=lmemod@frame

load("data.lmer_1k_em_perm_N_1_sp_log_pred.RData")
env_N=lmemod@frame
load("data.lmer_1k_em_perm_P_1_sp_log_pred.RData")
env_P=lmemod@frame
load("data.lmer_1k_em_perm_NP_1_sp_log_pred.RData")
env_NP=lmemod@frame

rm(datCp_1,lmemod,obsA_1)
24598#subset of the dataset used in the study 
dim(lat_N)[1]
dim(lat_P)[1]
dim(lat_NP)[1]

dim(env_N)[1]
dim(env_P)[1]
dim(env_NP)[1]

round((100 - (dim(lat_N)[1]/24598)*100),1)
round((100 - (dim(lat_P)[1]/24598)*100),1)
round((100 - (dim(lat_NP)[1]/24598)*100),1)

round((100 - (dim(env_N)[1]/24598)*100),1)
round((100 - (dim(env_P)[1]/24598)*100),1)
round((100 - (dim(env_NP)[1]/24598)*100),1)



#############################################
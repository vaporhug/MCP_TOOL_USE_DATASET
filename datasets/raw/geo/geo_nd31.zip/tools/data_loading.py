#!/usr/bin/env python3
"""
Generic ecological / chemistry data loading utilities.
Reads xlsx and csv with optional sheet selection, column subset, and row filters.
Returns columns, row count, and head preview as JSON-friendly dicts.
"""

from __future__ import annotations

import math
import os
from typing import Any

import numpy as np
import pandas as pd
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Stoichiometry_Data_Loading")


def _to_jsonable(rec: dict) -> dict:
    out = {}
    for k, v in rec.items():
        if isinstance(v, float) and (math.isnan(v) or math.isinf(v)):
            out[k] = None
        elif isinstance(v, (np.floating,)):
            f = float(v)
            out[k] = None if (math.isnan(f) or math.isinf(f)) else f
        elif isinstance(v, (np.integer,)):
            out[k] = int(v)
        else:
            out[k] = v
    return out


@mcp.tool()
def list_sheets(xlsx_path: str) -> dict:
    """List sheet names in an Excel workbook.

    Args:
        xlsx_path: Absolute path to .xlsx file.

    Returns:
        dict with list of sheets and per-sheet (rows, columns) counts.
    """
    if not os.path.exists(xlsx_path):
        return {"error": f"File not found: {xlsx_path}"}
    xl = pd.ExcelFile(xlsx_path)
    info = {}
    for sh in xl.sheet_names:
        df = pd.read_excel(xlsx_path, sheet_name=sh, nrows=0)
        # full-row count via separate quick read of one column
        try:
            full = pd.read_excel(xlsx_path, sheet_name=sh, usecols=[0])
            n_rows = len(full)
        except Exception:
            n_rows = -1
        info[sh] = {"columns": list(df.columns), "n_rows": n_rows}
    return {"file": xlsx_path, "sheets": xl.sheet_names, "details": info}


@mcp.tool()
def load_excel_sheet(
    xlsx_path: str,
    sheet_name: str,
    columns: list | None = None,
    head: int = 50,
) -> dict:
    """Read one sheet of an Excel file, return preview rows.

    Args:
        xlsx_path: Absolute path to .xlsx file.
        sheet_name: Sheet name to read.
        columns: Optional list of columns to keep.
        head: Number of preview rows to return (default 50).

    Returns:
        dict with columns, n_rows, dtype map, and head rows as list of dicts.
    """
    if not os.path.exists(xlsx_path):
        return {"error": f"File not found: {xlsx_path}"}
    df = pd.read_excel(xlsx_path, sheet_name=sheet_name)
    if columns:
        keep = [c for c in columns if c in df.columns]
        df = df[keep]
    dtypes = {c: str(df[c].dtype) for c in df.columns}
    preview = [_to_jsonable(r) for r in df.head(head).to_dict("records")]
    return {
        "sheet": sheet_name,
        "columns": list(df.columns),
        "dtypes": dtypes,
        "n_rows": int(len(df)),
        "head": preview,
    }


@mcp.tool()
def filter_rows(
    xlsx_path: str,
    sheet_name: str,
    include_in: dict | None = None,
    exclude_in: dict | None = None,
    require_non_null: list | None = None,
    output_csv: str | None = None,
) -> dict:
    """Filter rows of a sheet by categorical inclusion/exclusion and required non-null columns.

    Useful for paper-style filters such as keeping only realm in {terrestrial, freshwater},
    excluding class in {Aves, Mammalia}, and requiring %N + %P + N deposition.

    Args:
        xlsx_path: Absolute path to .xlsx file.
        sheet_name: Sheet to read.
        include_in: dict like {"habitat": ["terrestrial","freshwater"]} - keep rows whose value is in list.
        exclude_in: dict like {"class_revised": ["Aves","Mammalia"]} - drop rows whose value is in list.
        require_non_null: list of columns that must not be NaN.
        output_csv: Optional absolute path to write the filtered subset as CSV.

    Returns:
        dict with n_in, n_out, head preview, and output_csv if written.
    """
    if not os.path.exists(xlsx_path):
        return {"error": f"File not found: {xlsx_path}"}
    df = pd.read_excel(xlsx_path, sheet_name=sheet_name)
    n_in = len(df)
    if include_in:
        for col, vals in include_in.items():
            if col in df.columns:
                df = df[df[col].isin(list(vals))]
    if exclude_in:
        for col, vals in exclude_in.items():
            if col in df.columns:
                df = df[~df[col].isin(list(vals))]
    if require_non_null:
        df = df.dropna(subset=[c for c in require_non_null if c in df.columns])
    n_out = len(df)
    out = {
        "n_in": int(n_in),
        "n_out": int(n_out),
        "fraction_kept": round(n_out / n_in, 4) if n_in else None,
        "columns": list(df.columns),
        "head": [_to_jsonable(r) for r in df.head(20).to_dict("records")],
    }
    if output_csv:
        os.makedirs(os.path.dirname(output_csv), exist_ok=True)
        df.to_csv(output_csv, index=False)
        out["output_csv"] = output_csv
    return out


@mcp.tool()
def load_csv(csv_path: str, head: int = 50) -> dict:
    """Read a CSV file and return preview rows.

    Args:
        csv_path: Absolute path to CSV.
        head: Number of preview rows.

    Returns:
        dict with columns, n_rows, dtypes, head.
    """
    if not os.path.exists(csv_path):
        return {"error": f"File not found: {csv_path}"}
    df = pd.read_csv(csv_path)
    dtypes = {c: str(df[c].dtype) for c in df.columns}
    return {
        "file": csv_path,
        "columns": list(df.columns),
        "dtypes": dtypes,
        "n_rows": int(len(df)),
        "head": [_to_jsonable(r) for r in df.head(head).to_dict("records")],
    }


@mcp.tool()
def column_summary(csv_or_xlsx_path: str, sheet_name: str | None = None) -> dict:
    """Per-column summary: dtype, n_missing, n_unique, sample values.

    Args:
        csv_or_xlsx_path: Path to CSV or XLSX.
        sheet_name: Sheet name if XLSX.

    Returns:
        dict {column: {dtype, n_missing, n_unique, examples}}
    """
    if not os.path.exists(csv_or_xlsx_path):
        return {"error": f"File not found: {csv_or_xlsx_path}"}
    if csv_or_xlsx_path.lower().endswith(".csv"):
        df = pd.read_csv(csv_or_xlsx_path)
    else:
        df = pd.read_excel(csv_or_xlsx_path, sheet_name=sheet_name) if sheet_name else pd.read_excel(csv_or_xlsx_path)
    out: dict[str, Any] = {}
    for c in df.columns:
        s = df[c]
        examples = s.dropna().astype(str).unique().tolist()[:5]
        out[c] = {
            "dtype": str(s.dtype),
            "n_missing": int(s.isna().sum()),
            "n_unique": int(s.nunique()),
            "examples": examples,
        }
    return {"n_rows": int(len(df)), "columns": out}


if __name__ == "__main__":
    mcp.run()

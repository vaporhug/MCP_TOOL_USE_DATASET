# math_sl01 — packaging notes

## File inventory

All files are physically present in the zip. Verify with
`unzip -l datasets/raw/math/math_sl01.zip`. Text-readable schema in
`input_data/data/_bundle_manifest.txt`. Programmatic verification:
`python tools/verify_bundle.py .`.

| File                                          | Bytes      | Rows / Notes              |
| --------------------------------------------- | ---------- | ------------------------- |
| input_data/data/riboflavin_expression.csv     | 5,254,521  | 71 rows × 4090 cols       |
| artifacts/coefficient_path.png                |   172,153  | LASSO coef path           |
| artifacts/cv_curve.png                        |    37,806  | 10-fold CV MSE curve      |
| artifacts/stability_bars.png                  |    51,094  | top stability-selection genes |
| artifacts/method_comparison.png               |    69,399  | held-out MSE comparison   |
| artifacts/verification_summary.json           |     5,171  | numeric anchor values     |
| tools/data_io.py                              |            | CSV load / standardise    |
| tools/sparse_regression.py                    |            | LASSO / EN / BIC / CV     |
| tools/stability_selection.py                  |            | B=100 subsampling         |
| tools/plots.py                                |            | bundled figures           |
| tools/verify_bundle.py                        |            | this verification script  |

## Reference paper

- target.pdf — Bühlmann, Kalisch & Meier (2014). 'High-Dimensional
  Statistics with a View Toward Applications in Biology'. Annu. Rev.
  Stat. Appl. 1, 255-278. The riboflavin worked example (n=71, p=4088)
  is in §3 of that paper. The arXiv version (arXiv:1310.5320) carries a
  2024-on-PDF coversheet date but the article content is the 2014
  publication.

- 1.pdf — Friedman, Hastie & Tibshirani (2010). 'Regularization Paths
  for Generalized Linear Models via Coordinate Descent'. JSS 33(1).
- 2.pdf — Meinshausen & Bühlmann (2010). 'Stability Selection'. JRSS-B
  72(4), 417-473.
- 3.pdf — Zou & Hastie (2005). 'Regularization and Variable Selection
  via the Elastic Net'. JRSS-B 67(2), 301-320.

## Grader contract

- The graded answer items derive from a deterministic B=100, seed=0 run
  of the bundled stability_selection. The paper's B=500 numbers in
  target.pdf are PAPER CONTEXT only and are NOT the grader's anchor.
- ALL paper-cited numbers and bundle-cited numbers are explicitly tagged
  in task_content.json answer items.
- The agent should reproduce the workflow (coordinate descent LASSO,
  CV / BIC lambda selection, B=100 stability selection, π_thr =
  1/2 + q^2/(2pE[V]) = 0.5489) and produce outputs that match the
  bundled artifact magnitudes within the tolerances stated in the
  answer.

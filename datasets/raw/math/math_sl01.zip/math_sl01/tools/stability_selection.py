"""
Stability selection primitives.

Implements the Meinshausen-Buhlmann (2010) subsample-and-vote
procedure: B random subsamples of size n/2 are drawn; on each
subsample, a LASSO regularization path is run, and a feature is
counted as selected on that subsample when it enters the path
within the first q variables (q chosen externally to control the
expected number of false positives).

Selection frequencies pi_j are then thresholded by pi_thr to obtain
the stable set; the formula

    pi_thr = 1/2 + q^2 / (2 p E[V])

with E[V] the desired upper bound on the expected number of false
positives gives the connection to type-I-error control under the
exchangeability assumption (eq. 10 of the source paper).

The path code in lasso_path is reused for each subsample.
"""

from typing import Dict, List, Optional
import numpy as np

from sparse_regression import (
    lasso_coordinate_descent,
    lasso_max_lambda,
)


def first_q_entries_lars_like(X: np.ndarray, y: np.ndarray, q: int,
                              n_lambda: int = 80,
                              lam_ratio: float = 1e-4,
                              alpha: float = 1.0) -> List[int]:
    """Run a LASSO regularization path and return the indices of the
    first q variables to enter (i.e. those with the largest lambdas at
    which their coefficient becomes non-zero).

    This emulates the "selector" recommended in Meinshausen and
    Buhlmann (2010): at each subsample, the LASSO is run from
    lambda_max downward and the first q distinct variables to leave
    zero are recorded.

    Parameters
    ----------
    X : (m, p) standardized subsample design.
    y : (m,) centered subsample response.
    q : int, number of variables to record.
    n_lambda : int, density of the lambda grid.
    lam_ratio : float.
    alpha : float in (0, 1].

    Returns
    -------
    list of int
        Up to q distinct feature indices, in order of entry.
    """
    X = np.asarray(X, dtype=float)
    y = np.asarray(y, dtype=float)
    p = X.shape[1]
    lam_max = lasso_max_lambda(X, y, alpha=alpha)
    lam_min = lam_max * lam_ratio
    lambdas = np.exp(np.linspace(np.log(lam_max), np.log(lam_min), n_lambda))
    seen = []
    seen_set = set()
    beta = np.zeros(p)
    for lam in lambdas:
        out = lasso_coordinate_descent(X, y, float(lam), alpha=alpha,
                                       beta_init=beta, max_iter=1500,
                                       tol=1e-6)
        beta = out["beta"]
        nz = np.where(np.abs(beta) > 1e-10)[0]
        for j in nz:
            jj = int(j)
            if jj not in seen_set:
                seen_set.add(jj)
                seen.append(jj)
                if len(seen) >= q:
                    return seen
    return seen


def stability_selection(X: np.ndarray, y: np.ndarray,
                        B: int = 500, q: int = 20,
                        EV: float = 1.0,
                        alpha: float = 1.0,
                        seed: int = 37) -> Dict:
    """Run subsampling-based stability selection on (X, y).

    For each of B random subsamples I* of size floor(n/2), the LASSO
    selector with parameter q is applied to the subsample (after
    glmnet-style standardization), and selection counts are
    accumulated. The threshold pi_thr is computed from (q, p, EV) per
    eq. (10) of Meinshausen-Buhlmann (2010).

    Parameters
    ----------
    X : (n, p) RAW design.
    y : (n,) raw response.
    B : int, number of subsamples.
    q : int, number of variables to retain on each subsample.
    EV : float, upper bound on the expected number of false positives
        (used only to compute pi_thr).
    alpha : float in (0, 1], elastic-net mixing.
    seed : int.

    Returns
    -------
    dict
        {"selection_frequency": np.ndarray (p,) in [0, 1],
         "counts": np.ndarray (p,) of int,
         "pi_threshold": float,
         "stable_indices": list of int (selection_frequency >= pi_threshold),
         "B": int, "q": int, "EV": float}
    """
    X = np.asarray(X, dtype=float)
    y = np.asarray(y, dtype=float)
    n, p = X.shape
    half = n // 2
    rng = np.random.default_rng(seed)
    counts = np.zeros(p, dtype=int)
    for b in range(B):
        idx = rng.choice(n, size=half, replace=False)
        Xb = X[idx]
        yb = y[idx]
        # Standardize within the subsample (glmnet convention)
        mu = Xb.mean(axis=0)
        Xc = Xb - mu
        sc = np.linalg.norm(Xc, axis=0) / np.sqrt(half)
        sc_safe = np.where(sc > 1e-12, sc, 1.0)
        Xs = Xc / sc_safe
        ym = yb.mean()
        yc = yb - ym
        sel = first_q_entries_lars_like(Xs, yc, q=q, alpha=alpha)
        for j in sel:
            counts[j] += 1
    freq = counts / float(B)
    pi_thr = 0.5 + (q ** 2) / (2.0 * p * EV)
    stable = [int(j) for j in range(p) if freq[j] >= pi_thr]
    return {"selection_frequency": freq,
            "counts": counts,
            "pi_threshold": float(pi_thr),
            "stable_indices": stable,
            "B": int(B), "q": int(q), "EV": float(EV)}


def rank_features_by_stability(stability_result: Dict,
                               feature_names: List[str],
                               top_k: int = 25) -> List[Dict]:
    """Return the top features by stability frequency with their names.

    Parameters
    ----------
    stability_result : dict
        Output of stability_selection.
    feature_names : list of str of length p.
    top_k : int.

    Returns
    -------
    list of dicts
        [{"feature": str, "freq": float, "is_stable": bool}, ...]
        sorted by freq descending.
    """
    freq = np.asarray(stability_result["selection_frequency"], dtype=float)
    pi_thr = float(stability_result["pi_threshold"])
    order = np.argsort(-freq)[:top_k]
    return [{"feature": feature_names[int(j)], "freq": float(freq[int(j)]),
             "is_stable": bool(freq[int(j)] >= pi_thr)} for j in order]

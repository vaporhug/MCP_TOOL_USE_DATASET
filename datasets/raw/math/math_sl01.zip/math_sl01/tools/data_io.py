"""
Data input / output and basic preprocessing primitives for the
high-dimensional gene-expression task.

All paths are relative to the task root (input_data/data/...).
"""

from typing import Optional, Tuple, Dict
import os
import csv
import json
import numpy as np


def load_expression_csv(path: str) -> Dict:
    """Load the riboflavin gene-expression CSV.

    The file has columns: sample (str), log_riboflavin_rate (float),
    then p columns of gene expression (float). Rows = samples.

    Path handling: if ``path`` is absolute it is used as-is; if it is
    relative it is resolved against the current working directory of
    the caller (i.e. via os.path.abspath). The caller is expected to
    invoke this function from the task root so that
    "input_data/data/riboflavin_expression.csv" resolves correctly; if
    the working directory differs, pass an absolute path.

    Parameters
    ----------
    path : str
        Absolute or relative path to the CSV file (e.g.,
        "input_data/data/riboflavin_expression.csv" when called from
        the task root).

    Returns
    -------
    dict
        {
          "sample_ids": list of n strings (sample names),
          "y": np.ndarray shape (n,) (log-riboflavin production rate),
          "X": np.ndarray shape (n, p) (gene-expression design matrix),
          "feature_names": list of p strings (gene probe names),
          "n": int, "p": int
        }
    """
    if not os.path.isabs(path):
        # Resolve relative to the task root. This file lives at
        # <task_root>/tools/data_io.py, so the task root is one
        # directory up from this module file.
        task_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        candidate = os.path.join(task_root, path)
        if os.path.isfile(candidate):
            path = candidate
        else:
            # Fall back to the caller's cwd-relative resolution.
            path = os.path.abspath(path)
    sample_ids = []
    ys = []
    rows = []
    with open(path, "r", newline="") as fh:
        reader = csv.reader(fh)
        header = next(reader)
        feature_names = header[2:]
        for row in reader:
            sample_ids.append(row[0])
            ys.append(float(row[1]))
            rows.append([float(v) for v in row[2:]])
    X = np.array(rows, dtype=float)
    y = np.array(ys, dtype=float)
    return {
        "sample_ids": sample_ids,
        "y": y,
        "X": X,
        "feature_names": list(feature_names),
        "n": int(X.shape[0]),
        "p": int(X.shape[1]),
    }


def standardize_design(X: np.ndarray, mode: str = "glmnet") -> Dict:
    """Center and scale the columns of the design matrix.

    Parameters
    ----------
    X : np.ndarray of shape (n, p)
        Raw design matrix.
    mode : str
        "glmnet" : columns are centered to mean 0 and scaled so that
                   ||X[:, j]||_2^2 / n = 1 (i.e. the glmnet convention,
                   which divides by sample-size sd, not n-1 sd).
        "zscore" : columns are centered and divided by the unbiased
                   sample sd (denominator n - 1).

    Returns
    -------
    dict
        {"Xs": standardized design (n, p),
         "center": column means (p,),
         "scale": column scaling factors (p,),
         "mode": str}
    """
    X = np.asarray(X, dtype=float)
    n, p = X.shape
    center = X.mean(axis=0)
    Xc = X - center
    if mode == "glmnet":
        scale = np.linalg.norm(Xc, axis=0) / np.sqrt(n)
    elif mode == "zscore":
        scale = X.std(axis=0, ddof=1)
    else:
        raise ValueError("mode must be 'glmnet' or 'zscore'")
    scale_safe = np.where(scale > 1e-12, scale, 1.0)
    Xs = Xc / scale_safe
    return {"Xs": Xs, "center": center, "scale": scale_safe, "mode": mode}


def center_response(y: np.ndarray) -> Dict:
    """Subtract the mean from a response vector and report it.

    Parameters
    ----------
    y : np.ndarray shape (n,)

    Returns
    -------
    dict
        {"yc": centered response, "mean": mean used}
    """
    y = np.asarray(y, dtype=float)
    mu = float(y.mean())
    return {"yc": y - mu, "mean": mu}


def kfold_indices(n: int, k: int = 10, seed: int = 0) -> list:
    """Generate k-fold CV partitions by random permutation.

    The sample indices 0..n-1 are randomly permuted and split into k
    near-equal contiguous blocks. There is no stratification because the
    response in this task is continuous; suggested seeds for
    reproducibility: 0 for the CV folds.

    Parameters
    ----------
    n : int
        Number of samples.
    k : int
        Number of folds.
    seed : int
        Random seed for the permutation. Use 0 for the canonical CV
        protocol referenced in the task instruction.

    Returns
    -------
    list of dicts
        Each entry is {"train": np.ndarray, "test": np.ndarray} with
        integer indices into rows of the full sample.
    """
    rng = np.random.default_rng(seed)
    perm = rng.permutation(n)
    folds = np.array_split(perm, k)
    out = []
    for i in range(k):
        test = np.array(folds[i], dtype=int)
        train = np.concatenate([folds[j] for j in range(k) if j != i]).astype(int)
        out.append({"train": train, "test": test})
    return out


def train_test_split_indices(n: int, test_frac: float = 0.3, seed: int = 1) -> Dict:
    """Split sample indices into train and test sets.

    Parameters
    ----------
    n : int
    test_frac : float in (0, 1)
    seed : int

    Returns
    -------
    dict
        {"train": np.ndarray, "test": np.ndarray}
    """
    rng = np.random.default_rng(seed)
    perm = rng.permutation(n)
    n_test = int(round(test_frac * n))
    return {"train": perm[n_test:], "test": perm[:n_test]}


def save_json(obj, path: str) -> str:
    """Persist a dict / list-of-dicts to JSON. Returns the path."""
    if not os.path.isabs(path):
        path = os.path.abspath(path)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    def conv(o):
        if isinstance(o, (np.ndarray,)):
            return o.tolist()
        if isinstance(o, (np.floating,)):
            return float(o)
        if isinstance(o, (np.integer,)):
            return int(o)
        return str(o)
    with open(path, "w") as fh:
        json.dump(obj, fh, indent=2, default=conv)
    return path


def list_top_marginal_correlations(X: np.ndarray, y: np.ndarray,
                                   feature_names: list, top_k: int = 25) -> list:
    """Rank features by absolute marginal Pearson correlation with the response.

    Used as a sanity check, NOT as a selection method.

    Parameters
    ----------
    X : (n, p) design.
    y : (n,) response.
    feature_names : list of length p.
    top_k : int.

    Returns
    -------
    list of dicts [{"feature": str, "corr": float, "abs_corr": float}, ...]
        sorted by abs_corr descending, length min(p, top_k).
    """
    X = np.asarray(X, dtype=float)
    y = np.asarray(y, dtype=float)
    Xc = X - X.mean(axis=0)
    yc = y - y.mean()
    sx = Xc.std(axis=0, ddof=0)
    sy = yc.std(ddof=0)
    sx_safe = np.where(sx > 1e-12, sx, 1.0)
    corrs = (Xc.T @ yc) / (sx_safe * sy * len(y))
    order = np.argsort(-np.abs(corrs))[:top_k]
    return [
        {"feature": feature_names[j], "corr": float(corrs[j]),
         "abs_corr": float(abs(corrs[j]))}
        for j in order
    ]

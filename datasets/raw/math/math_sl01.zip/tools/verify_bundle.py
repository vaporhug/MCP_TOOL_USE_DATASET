#!/usr/bin/env python3
"""verify_bundle.py — confirm math_sl01 zip contents match task_content.json.

Runs the following checks; exit 0 = all pass:

  - riboflavin_expression.csv exists with 71 data rows and 4090 columns
    (sample, log_riboflavin_rate, 4088 _at gene columns)
  - all 5 bundled artifacts exist:
      artifacts/coefficient_path.png
      artifacts/cv_curve.png
      artifacts/stability_bars.png
      artifacts/method_comparison.png
      artifacts/verification_summary.json
  - every input_data path declared in task_content.json is physically present
  - artifacts/ contains no agent_-prefixed files (the agent writes those at
    solve time; the bundled artifacts/ holds only the canonical reference run)

Usage:
    python tools/verify_bundle.py <bundle_root_or_zip>
"""

from __future__ import annotations

import csv
import json
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path

EXPECTED_INPUT_CSV = {
    "input_data/data/riboflavin_expression.csv":
        {"rows": 71, "n_cols": 4090,
         "header_prefix": ["sample", "log_riboflavin_rate"]},
}
EXPECTED_ARTIFACTS = [
    "artifacts/coefficient_path.png",
    "artifacts/cv_curve.png",
    "artifacts/stability_bars.png",
    "artifacts/method_comparison.png",
    "artifacts/verification_summary.json",
]


def main(root_or_zip: str) -> int:
    p = Path(root_or_zip)
    cleanup_dir: Path | None = None
    if p.suffix == ".zip" and p.is_file():
        # Fresh temp dir per call so a stale earlier extraction can't
        # contaminate the verification (no shared /tmp/math_sl01_verify).
        extract = Path(tempfile.mkdtemp(prefix="math_sl01_verify_"))
        cleanup_dir = extract
        with zipfile.ZipFile(p) as zf:
            zf.extractall(extract)
        root = extract
    else:
        root = p

    errs: list[str] = []

    # 1. Input CSV schema + rows
    for rel, spec in EXPECTED_INPUT_CSV.items():
        path = root / rel
        if not path.is_file():
            errs.append(f"MISSING file: {rel}")
            continue
        with open(path, newline="") as f:
            rdr = csv.reader(f)
            header = next(rdr)
            if header[:2] != spec["header_prefix"]:
                errs.append(f"{rel}: header[:2] = {header[:2]} != "
                            f"{spec['header_prefix']}")
            if len(header) != spec["n_cols"]:
                errs.append(f"{rel}: {len(header)} columns != "
                            f"{spec['n_cols']}")
            n = sum(1 for _ in rdr)
            if n != spec["rows"]:
                errs.append(f"{rel}: {n} data rows != {spec['rows']}")

    # 2. Bundled artifacts present
    for rel in EXPECTED_ARTIFACTS:
        if not (root / rel).is_file():
            errs.append(f"MISSING artifact: {rel}")

    # 3. Cross-check task_content.json input_data
    tc = root / "task_content" / "task_content.json"
    if tc.is_file():
        j = json.load(open(tc))
        for item in j.get("input_data", []):
            if not (root / item["path"]).is_file():
                errs.append(f"task_content declares missing input: "
                            f"{item['path']}")
    else:
        errs.append("MISSING task_content/task_content.json")

    # 4. artifacts/ namespace separation
    art = root / "artifacts"
    if art.is_dir():
        for f in art.iterdir():
            if f.name.startswith("agent_"):
                errs.append(f"agent_-prefixed file should not be bundled "
                            f"(agent writes them at runtime): {f.name}")

    if cleanup_dir is not None:
        shutil.rmtree(cleanup_dir, ignore_errors=True)
    if errs:
        print("verify_bundle: FAIL")
        for e in errs:
            print(" -", e)
        return 1
    print("verify_bundle: OK — riboflavin_expression.csv (71 rows × 4090 cols), "
          "5 bundled artifacts (4 PNG + 1 JSON), all input_data declarations "
          "resolved; no agent_-prefixed leakage in artifacts/.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1] if len(sys.argv) > 1 else "."))

"""math_sl01 tools package.

Bundled helpers for sparse regression, stability selection, and plotting on
the riboflavin dataset. See individual module docstrings for details.
"""

"""
Plotting primitives for the high-dimensional sparse regression task.

All plot functions return {"path": output_path}. Files are written
under ``artifacts/`` by default. The functions use matplotlib only
and are intentionally low-level: no algorithmic logic is hidden in
plotting.
"""

from typing import Dict, List, Optional
import os

import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


def _ensure_dir(p: str) -> None:
    os.makedirs(os.path.dirname(p), exist_ok=True)


def plot_coefficient_path(lambdas: np.ndarray, betas: np.ndarray,
                          highlight_indices: Optional[List[int]] = None,
                          highlight_labels: Optional[List[str]] = None,
                          output_path: str = "artifacts/coefficient_path.png",
                          title: str = "LASSO regularization path") -> Dict:
    """Plot coefficient trajectories beta_j(lambda) versus log(lambda).

    Parameters
    ----------
    lambdas : (n_lambda,) decreasing.
    betas : (n_lambda, p).
    highlight_indices : list of feature indices drawn in colour with labels.
    highlight_labels : labels for each highlight index.
    output_path : str.
    title : str.

    Returns
    -------
    {"path": output_path}
    """
    _ensure_dir(output_path)
    fig, ax = plt.subplots(figsize=(7.0, 5.0))
    log_lam = np.log10(np.asarray(lambdas))
    p = betas.shape[1]
    # Background: all features in light grey
    for j in range(p):
        ax.plot(log_lam, betas[:, j], color="0.85", linewidth=0.4, zorder=1)
    # Highlights
    if highlight_indices is not None:
        cmap = plt.get_cmap("tab10")
        for k, j in enumerate(highlight_indices):
            label = (highlight_labels[k] if highlight_labels is not None
                     and k < len(highlight_labels) else f"feat {j}")
            ax.plot(log_lam, betas[:, j], color=cmap(k % 10),
                    linewidth=1.6, zorder=3, label=label)
        ax.legend(loc="best", fontsize=8)
    ax.axhline(0.0, color="k", linewidth=0.5, linestyle=":")
    ax.set_xlabel(r"$\log_{10}(\lambda)$")
    ax.set_ylabel(r"coefficient $\hat\beta_j(\lambda)$")
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(output_path, dpi=140)
    plt.close(fig)
    return {"path": output_path}


def plot_cv_curve(lambdas: np.ndarray, mse_mean: np.ndarray, mse_se: np.ndarray,
                  ix_min: int, ix_1se: int,
                  output_path: str = "artifacts/cv_curve.png",
                  title: str = "K-fold CV mean squared error") -> Dict:
    """Plot mean CV MSE +/- 1 standard error versus log(lambda).

    Vertical lines mark lambda_min and lambda_1se.

    Parameters
    ----------
    lambdas : (n_lambda,) decreasing.
    mse_mean : (n_lambda,)
    mse_se : (n_lambda,)
    ix_min : int.
    ix_1se : int.
    output_path : str.
    title : str.

    Returns
    -------
    {"path": output_path}
    """
    _ensure_dir(output_path)
    log_lam = np.log10(np.asarray(lambdas))
    fig, ax = plt.subplots(figsize=(7.0, 4.5))
    ax.errorbar(log_lam, mse_mean, yerr=mse_se,
                fmt="o", markersize=3, ecolor="0.7",
                capsize=2, color="C0", linewidth=0.8)
    ax.axvline(log_lam[ix_min], color="C3", linestyle="--",
               label=fr"$\lambda_{{\min}}$ ($\log_{{10}}={log_lam[ix_min]:.2f}$)")
    ax.axvline(log_lam[ix_1se], color="C2", linestyle="--",
               label=fr"$\lambda_{{1\,SE}}$ ($\log_{{10}}={log_lam[ix_1se]:.2f}$)")
    ax.set_xlabel(r"$\log_{10}(\lambda)$")
    ax.set_ylabel("CV MSE")
    ax.set_title(title)
    ax.legend(loc="best", fontsize=9)
    fig.tight_layout()
    fig.savefig(output_path, dpi=140)
    plt.close(fig)
    return {"path": output_path}


def plot_stability_frequencies(features: List[str], freqs: List[float],
                               pi_threshold: float,
                               output_path: str = "artifacts/stability_bars.png",
                               title: str = "Stability selection frequencies") -> Dict:
    """Bar chart of the subsample selection frequency for the top features.

    Parameters
    ----------
    features : list of str (already top-K, in display order).
    freqs : matching list of float in [0, 1].
    pi_threshold : float, drawn as a horizontal line.
    output_path : str.
    title : str.

    Returns
    -------
    {"path": output_path}
    """
    _ensure_dir(output_path)
    fig, ax = plt.subplots(figsize=(8.0, max(3.5, 0.28 * len(features) + 1.5)))
    y_pos = np.arange(len(features))
    colors = ["C2" if f >= pi_threshold else "0.55" for f in freqs]
    ax.barh(y_pos, freqs, color=colors, edgecolor="black", linewidth=0.4)
    ax.set_yticks(y_pos)
    ax.set_yticklabels(features, fontsize=8)
    ax.invert_yaxis()
    ax.axvline(pi_threshold, color="red", linestyle="--",
               label=fr"$\pi_{{thr}}={pi_threshold:.3f}$")
    ax.set_xlim(0.0, 1.0)
    ax.set_xlabel("subsample selection frequency")
    ax.set_title(title)
    ax.legend(loc="lower right", fontsize=9)
    fig.tight_layout()
    fig.savefig(output_path, dpi=140)
    plt.close(fig)
    return {"path": output_path}


def plot_method_comparison(method_names: List[str],
                           n_selected: List[int],
                           test_mse: List[float],
                           output_path: str = "artifacts/method_comparison.png",
                           title: str = "Variable selection methods compared") -> Dict:
    """Two-panel comparison of methods: number of selected features and test MSE.

    Parameters
    ----------
    method_names : list of str.
    n_selected : list of int (one per method).
    test_mse : list of float (one per method).
    output_path : str.
    title : str.

    Returns
    -------
    {"path": output_path}
    """
    _ensure_dir(output_path)
    fig, axes = plt.subplots(1, 2, figsize=(10.0, 4.0))
    x = np.arange(len(method_names))
    axes[0].bar(x, n_selected, color="C0", edgecolor="black", linewidth=0.4)
    axes[0].set_xticks(x)
    axes[0].set_xticklabels(method_names, rotation=20, ha="right", fontsize=9)
    axes[0].set_ylabel("# features selected")
    axes[0].set_title("Sparsity")
    for xi, ni in zip(x, n_selected):
        axes[0].text(xi, ni, str(ni), ha="center", va="bottom", fontsize=8)

    axes[1].bar(x, test_mse, color="C3", edgecolor="black", linewidth=0.4)
    axes[1].set_xticks(x)
    axes[1].set_xticklabels(method_names, rotation=20, ha="right", fontsize=9)
    axes[1].set_ylabel("held-out MSE")
    axes[1].set_title("Predictive accuracy")
    for xi, mi in zip(x, test_mse):
        axes[1].text(xi, mi, f"{mi:.3f}", ha="center", va="bottom", fontsize=8)
    fig.suptitle(title, y=1.02)
    fig.tight_layout()
    fig.savefig(output_path, dpi=140, bbox_inches="tight")
    plt.close(fig)
    return {"path": output_path}


def plot_predicted_vs_observed(y_true: np.ndarray, y_pred: np.ndarray,
                               method_label: str = "model",
                               output_path: str = "artifacts/pred_vs_obs.png") -> Dict:
    """Scatter of predicted vs observed responses with the y = x line.

    Parameters
    ----------
    y_true : (n,)
    y_pred : (n,)
    method_label : str.
    output_path : str.

    Returns
    -------
    {"path": output_path}
    """
    _ensure_dir(output_path)
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    fig, ax = plt.subplots(figsize=(5.0, 5.0))
    ax.scatter(y_true, y_pred, color="C0", s=24, edgecolor="black", linewidth=0.3)
    lo = float(min(y_true.min(), y_pred.min()))
    hi = float(max(y_true.max(), y_pred.max()))
    ax.plot([lo, hi], [lo, hi], "k--", linewidth=0.8, label="y = x")
    ax.set_xlabel("observed")
    ax.set_ylabel("predicted")
    ax.set_title(f"{method_label}: predicted vs observed")
    ax.legend(loc="best", fontsize=9)
    fig.tight_layout()
    fig.savefig(output_path, dpi=140)
    plt.close(fig)
    return {"path": output_path}

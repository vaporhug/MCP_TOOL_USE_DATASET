# Corn NIR PLSR/PCR calibration report (M5, canonical fixed split)

Bundled fixed split.csv assigns sample_id 1-60 to the calibration subset and 61-80 to the prediction subset. Reproducible setup: raw un-pretreated M5 absorbance, candidate grid LV=1..10 for PLSR and PC=1..10 for PCR, complexity selected by 5-fold cross-validation on the 60-sample calibration subset (n_folds=5, random_seed=0, contiguous folds, rule='min' RMSECV).

## Calibration / prediction performance (PLSR LV chosen by CV)

| Constituent | LV | R2_C | R2_P | RMSEC | RMSEP |
| --- | ---: | ---: | ---: | ---: | ---: |
| Moisture | 10 | 0.9987 | 0.9975 | 0.0120 | 0.0222 |
| Oil      | 10 | 0.9160 | 0.7784 | 0.0467 | 0.0924 |
| Protein  | 10 | 0.9726 | 0.8765 | 0.0798 | 0.1801 |
| Starch   | 10 | 0.9625 | 0.7521 | 0.1597 | 0.3898 |

Prediction R^2 ordering on this canonical split: Moisture > Protein > Oil > Starch.

## PLSR vs PCR comparison (R2_P)

| Constituent | PLSR | PCR |
| --- | ---: | ---: |
| Moisture | 0.997 | 0.982 |
| Oil      | 0.778 | * |
| Protein  | 0.877 | 0.688 |
| Starch   | 0.752 | 0.347 |

PLSR dominates on Protein and Starch; Moisture is nearly tied.

## Moisture VIP region

Peak VIP ≈ 1.54 at 1922 nm inside the 1900–1940 nm O-H combination band; 261 of 700 channels exceed VIP > 1. A secondary contribution near the 1450 nm O-H first-overtone is also present.

## Background note (not a scoring target)

The target paper reports its own random-60/20 split PLSR LV=10 M5 values in Table 5 — Moisture 0.9978 / 0.9957, Oil 0.9254 / 0.7554, Protein 0.9630 / 0.9172, Starch 0.9525 / 0.8538 — for reference only.

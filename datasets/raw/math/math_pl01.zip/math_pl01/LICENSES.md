# math_pl01 — bundle file licenses & sources

This benchmark bundle redistributes a small number of third-party assets. Each is listed below with its source URL and license. Per-file license records are mirrored inline in the descriptions below so a single inspection of this file is sufficient to audit redistribution.

## Reference papers

### `input_data/reference_paper/target.pdf`
- **Citation**: Cataltas, O. & Tutuncu, K. (2023). "Detection of protein, starch, oil, and moisture content of corn kernels using one-dimensional convolutional autoencoder and near-infrared spectroscopy." *PeerJ Computer Science* 9: e1241.
- **DOI**: 10.7717/peerj-cs.1241
- **License**: PeerJ is an open-access publisher; article is licensed under **Creative Commons Attribution 4.0 International (CC BY 4.0)**. Redistribution permitted with attribution.

### `input_data/reference_paper/2.pdf`
- **Citation**: Mateos-Aparicio, G. (2011). "Partial Least Squares (PLS) Methods: Origins, Evolution and Application to Social Sciences." *Communications in Statistics — Theory and Methods*, 40(13): 2305–2317.
- **License**: This file is the author-deposited working-paper version (UCM open archive). Redistribution requires that the author/version attribution be preserved; otherwise treat as link-only citation.

### `input_data/reference_paper/3.pdf`
- **Citation**: Mevik, B.-H. & Wehrens, R. (2007). "The pls Package: Principal Component and Partial Least Squares Regression in R." *Journal of Statistical Software*, 18(2): 1–24.
- **License**: *Journal of Statistical Software* publishes under **Creative Commons Attribution 3.0 (CC BY 3.0)**. Redistribution permitted with attribution.

### Removed in PR #287 round 3:
- `1.pdf` — Westerhuis et al. 2008 "Assessment of PLSDA cross validation" was removed because the UvA-DARE deposit carries a restrictive "General rights" clause forbidding redistribution. Citation retained as link-only reference: DOI 10.1007/s11306-007-0099-6, Metabolomics 4(1): 81–89.

## Data

### `input_data/data/spectra_m5.csv`, `spectra_mp5.csv`, `spectra_mp6.csv`, `properties.csv`, `wavelengths_nm.csv`, `split.csv`, `nbs_glass_standards/*`
- **Source**: "NIR of Corn Samples for Standardization Benchmarking" — Cargill / Eigenvector Research, 2005. The dataset is the canonical public corn NIR benchmark distributed by Eigenvector Research Inc. for educational and benchmarking use (https://eigenvector.com/resources/data-sets/#corn).
- **License**: Eigenvector lists this dataset on the public benchmark page without an explicit restrictive license; it has been redistributed in numerous published chemometrics studies for decades. Treated here as public-domain-equivalent benchmark data; attribution to Cargill/Eigenvector is given in `task_content.json` `input_data` descriptions.

## Tools

`tools/*.py` are written from scratch for this benchmark; standard MIT-style permissive use applies. Implementations follow the algorithms described in the PLS / PCR literature (Mevik & Wehrens 2007, Wold 1975) and use only NumPy / pandas / matplotlib.

## Bundle author license

All bundle-authored content (`task_content/`, `tools/`, `artifacts/` figures generated from the bundled tools) is released under the MIT License for use as a Claude benchmark task package.

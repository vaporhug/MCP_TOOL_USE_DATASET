"""Variable Importance in Projection (VIP) scores for a fitted PLS model.

VIP_j = sqrt( p * sum_k ( SS_k * (W_jk / ||W_k||)^2 ) / sum_k SS_k )

where SS_k is the explained Y-variance of latent variable k and p is the number
of predictors. The convention is that VIP_j > 1 marks variable j as
"important" because the average of VIP^2 across variables equals 1.
"""
from __future__ import annotations

from typing import Tuple

import numpy as np

from .pls_nipals import PLSModel


def vip_scores(model: PLSModel, X_calib: np.ndarray, y_calib: np.ndarray
               ) -> np.ndarray:
    """Return the (p,) array of VIP scores from a fitted PLS model.

    Parameters
    ----------
    model    : PLSModel returned by fit_pls_nipals.
    X_calib  : (n, p) calibration matrix the model was fitted on (un-centred).
    y_calib  : (n,) or (n, 1) calibration response.
    """
    Xc = np.asarray(X_calib, dtype=float) - model.x_mean
    yc = np.asarray(y_calib, dtype=float).reshape(-1, 1) - model.y_mean.reshape(1, -1)
    if yc.shape[1] != 1:
        # Use the first target only — VIP is naturally PLS1
        yc = yc[:, [0]]
    n, p = Xc.shape
    K = model.n_components

    SS = np.zeros(K)
    for k in range(K):
        t = model.T[:, [k]]
        q = model.Q[:, [k]] if model.Q.shape[0] == 1 else model.Q[[0], [k]].reshape(1, 1)
        # variance of Y explained by component k = (t^T t) * q^2
        SS[k] = float((t.T @ t).item()) * float(q.item()) ** 2 if q.size == 1 \
            else float((t.T @ t).item()) * float(np.sum(q ** 2))

    total_SS = float(np.sum(SS))
    if total_SS < 1e-14:
        return np.zeros(p)

    # weight ratios
    Wn = model.W / np.linalg.norm(model.W, axis=0, keepdims=True)
    vip = np.sqrt(p * np.sum((Wn ** 2) * SS[np.newaxis, :], axis=1) / total_SS)
    return vip


def top_k_variables(vip: np.ndarray, wavelengths: np.ndarray, k: int = 20
                    ) -> Tuple[np.ndarray, np.ndarray]:
    """Return the top-k VIP wavelengths and their VIP values, sorted descending."""
    vip = np.asarray(vip, dtype=float)
    if k > vip.size:
        k = vip.size
    order = np.argsort(vip)[::-1][:k]
    return wavelengths[order], vip[order]

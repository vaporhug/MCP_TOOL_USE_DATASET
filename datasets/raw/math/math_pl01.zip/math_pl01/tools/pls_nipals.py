"""Partial Least Squares regression via the NIPALS algorithm.

This module provides a from-scratch numpy-only implementation of PLS1 (one
target) and PLS2 (multi-column target). The intent is to expose the latent
structure (W, T, P, Q) so that downstream tools (VIP, regression-coefficient
plots, parity plots) can be built on top.

References
----------
* Wold, Sjöström, Eriksson (2001), Chemom. Intell. Lab. Syst. 58:109-130.
* Geladi & Kowalski (1986), Anal. Chim. Acta 185:1-17 (NIPALS PLS).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple

import numpy as np


@dataclass
class PLSModel:
    """Container for a fitted PLS regression model in original units.

    Use ``predict(X_new)`` to obtain predictions; ``B_centred`` are the
    regression coefficients linking the centred X to the centred Y.
    """
    n_components: int
    x_mean: np.ndarray            # (p,)
    y_mean: np.ndarray            # (m,)
    W: np.ndarray                 # (p, n_components) X-weights
    P: np.ndarray                 # (p, n_components) X-loadings
    T: np.ndarray                 # (n, n_components) X-scores on calibration
    Q: np.ndarray                 # (m, n_components) Y-loadings
    B_centred: np.ndarray         # (p, m) regression coefficients

    def predict(self, X_new: np.ndarray) -> np.ndarray:
        """Predict Y for new spectra X_new (n_new, p)."""
        Xc = np.asarray(X_new, dtype=float) - self.x_mean
        Y_pred = Xc @ self.B_centred + self.y_mean
        return Y_pred


def fit_pls_nipals(X: np.ndarray, Y: np.ndarray, n_components: int,
                   tol: float = 1e-10, max_iter: int = 500) -> PLSModel:
    """Fit a PLS regression model with the NIPALS algorithm.

    Parameters
    ----------
    X : (n, p) ndarray
        Predictor matrix (spectra). Will be mean-centred internally; original X
        is not modified.
    Y : (n,) or (n, m) ndarray
        Response matrix. 1-D Y is treated as PLS1; 2-D Y triggers PLS2.
    n_components : int
        Number of latent variables to extract. Must satisfy 1 <= n_components <=
        min(n-1, p).

    Returns
    -------
    PLSModel
        Fitted model with weights, loadings, scores, and regression coefficients
        in original (un-centred) units.
    """
    X = np.asarray(X, dtype=float)
    Y_in = np.asarray(Y, dtype=float)
    if Y_in.ndim == 1:
        Y_mat = Y_in.reshape(-1, 1)
    else:
        Y_mat = Y_in
    n, p = X.shape
    n_y, m = Y_mat.shape
    if n_y != n:
        raise ValueError(f"X has {n} rows but Y has {n_y}")
    n_max = min(n - 1, p)
    if n_components < 1 or n_components > n_max:
        raise ValueError(f"n_components must lie in [1, {n_max}], got {n_components}")

    x_mean = X.mean(axis=0)
    y_mean = Y_mat.mean(axis=0)
    Xres = X - x_mean
    Yres = Y_mat - y_mean

    W = np.zeros((p, n_components))
    P = np.zeros((p, n_components))
    T = np.zeros((n, n_components))
    Q = np.zeros((m, n_components))

    for k in range(n_components):
        if m == 1:
            # PLS1 closed form
            w = Xres.T @ Yres[:, 0]
            wn = np.linalg.norm(w)
            if wn < 1e-14:
                break
            w = w / wn
            t = Xres @ w
            tt = float(t @ t)
            if tt < 1e-14:
                break
            q = float(Yres[:, 0] @ t) / tt
            p_load = (Xres.T @ t) / tt
            Yres[:, 0] = Yres[:, 0] - t * q
        else:
            # PLS2: NIPALS inner loop
            u = Yres[:, 0].copy()
            for _ in range(max_iter):
                w = Xres.T @ u
                wn = np.linalg.norm(w)
                if wn < 1e-14:
                    break
                w = w / wn
                t_new = Xres @ w
                q = Yres.T @ t_new
                qn = np.linalg.norm(q)
                if qn < 1e-14:
                    break
                q = q / qn
                u_new = Yres @ q
                if np.linalg.norm(u_new - u) < tol:
                    u = u_new
                    break
                u = u_new
            t = Xres @ w
            tt = float(t @ t)
            if tt < 1e-14:
                break
            p_load = (Xres.T @ t) / tt
            # un-normalised q for regression
            q = (Yres.T @ t) / tt
            Yres = Yres - np.outer(t, q)
        Xres = Xres - np.outer(t, p_load)
        W[:, k] = w
        P[:, k] = p_load
        T[:, k] = t
        if m == 1:
            Q[0, k] = float(q) if np.isscalar(q) else float(np.asarray(q).flatten()[0])
        else:
            Q[:, k] = np.asarray(q).flatten()

    # Regression coefficients in centred units: B = W (P^T W)^-1 Q^T
    PtW = P.T @ W
    B_centred = W @ np.linalg.pinv(PtW) @ Q.T  # (p, m)

    return PLSModel(
        n_components=n_components,
        x_mean=x_mean,
        y_mean=y_mean,
        W=W,
        P=P,
        T=T,
        Q=Q,
        B_centred=B_centred,
    )


def regression_coefficients(model: PLSModel, target_index: int = 0
                            ) -> np.ndarray:
    """Return the (p,) vector of regression coefficients for one target column."""
    return model.B_centred[:, target_index].copy()


def explained_variance(X: np.ndarray, Y: np.ndarray, model: PLSModel
                       ) -> Tuple[np.ndarray, np.ndarray]:
    """Cumulative explained variance in X and in Y for k = 1..n_components.

    Returns two (n_components,) arrays.
    """
    X = np.asarray(X, dtype=float) - model.x_mean
    Y_in = np.asarray(Y, dtype=float)
    if Y_in.ndim == 1:
        Y_in = Y_in.reshape(-1, 1)
    Y_in = Y_in - model.y_mean
    total_x = float(np.sum(X ** 2))
    total_y = float(np.sum(Y_in ** 2))
    expl_x = np.zeros(model.n_components)
    expl_y = np.zeros(model.n_components)
    Xres = X.copy()
    Yres = Y_in.copy()
    for k in range(model.n_components):
        t = Xres @ model.W[:, [k]]
        tt = float(t.T @ t)
        if tt < 1e-14:
            expl_x[k] = expl_x[k - 1] if k else 0.0
            expl_y[k] = expl_y[k - 1] if k else 0.0
            continue
        Xres = Xres - t @ model.P[:, [k]].T
        Yres = Yres - t @ model.Q[:, [k]].T
        expl_x[k] = 1.0 - float(np.sum(Xres ** 2)) / max(total_x, 1e-14)
        expl_y[k] = 1.0 - float(np.sum(Yres ** 2)) / max(total_y, 1e-14)
    return expl_x, expl_y

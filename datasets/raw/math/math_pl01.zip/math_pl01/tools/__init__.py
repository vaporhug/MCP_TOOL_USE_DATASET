"""Tool package for the corn NIR PLS regression task.

Sub-modules:
    data_loader        - load CSV spectra and reference property data
    preprocessing      - SNV, MSC, Savitzky-Golay derivatives, mean centering
    pls_nipals         - PLS regression via NIPALS algorithm (PLS1, PLS2)
    pcr_baseline       - principal component regression via SVD (baseline)
    cross_validation   - K-fold and leave-one-out CV for latent-variable selection
    metrics            - RMSE, RMSEC, RMSECV, RMSEP, R2, RPD, bias
    vip_scores         - Variable Importance in Projection from a fitted PLS model
    plotting           - matplotlib helpers; each returns {"path": <png>}

All tools are pure-numpy / pandas / matplotlib. No sklearn imports are required
by the agent — every primitive needed for the pipeline is provided here.
"""

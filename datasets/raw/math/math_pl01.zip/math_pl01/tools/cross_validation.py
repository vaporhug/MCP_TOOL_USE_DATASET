"""Cross-validation helpers for choosing the number of PLS / PCR components.

K-fold and leave-one-out CV are implemented from scratch (no sklearn). They
return the per-component RMSECV curve so that the agent can either pick the
minimum or apply a one-standard-error rule.
"""
from __future__ import annotations

from typing import Callable, Tuple

import numpy as np

from .pls_nipals import fit_pls_nipals
from .pcr_baseline import fit_pcr


def kfold_indices(n_samples: int, n_folds: int = 5,
                  random_seed: int = 0) -> list:
    """Return a list of (train_idx, test_idx) tuples for K-fold CV."""
    if n_folds < 2 or n_folds > n_samples:
        raise ValueError(f"n_folds must lie in [2, {n_samples}], got {n_folds}")
    rng = np.random.default_rng(random_seed)
    perm = rng.permutation(n_samples)
    folds = np.array_split(perm, n_folds)
    out = []
    for k in range(n_folds):
        test = np.sort(folds[k])
        train = np.sort(np.concatenate([folds[j] for j in range(n_folds) if j != k]))
        out.append((train, test))
    return out


def loo_indices(n_samples: int) -> list:
    """Return a list of (train_idx, test_idx) tuples for leave-one-out CV."""
    out = []
    for i in range(n_samples):
        test = np.array([i])
        train = np.array([j for j in range(n_samples) if j != i])
        out.append((train, test))
    return out


def cv_rmse_curve_pls(X: np.ndarray, y: np.ndarray, max_components: int,
                      n_folds: int = 5, random_seed: int = 0
                      ) -> Tuple[np.ndarray, np.ndarray]:
    """RMSECV vs number of latent variables for PLS regression.

    Returns
    -------
    components : (max_components,) integer array (1, 2, ..., max_components)
    rmsecv     : (max_components,) array of RMSE values from K-fold CV
    """
    folds = kfold_indices(X.shape[0], n_folds, random_seed)
    return _cv_curve(X, y, max_components, folds, fit_pls_nipals)


def cv_rmse_curve_pcr(X: np.ndarray, y: np.ndarray, max_components: int,
                      n_folds: int = 5, random_seed: int = 0
                      ) -> Tuple[np.ndarray, np.ndarray]:
    """RMSECV vs number of principal components for PCR (same K-fold scheme)."""
    folds = kfold_indices(X.shape[0], n_folds, random_seed)
    return _cv_curve(X, y, max_components, folds, fit_pcr)


def _cv_curve(X, y, max_components, folds, fit_fn) -> Tuple[np.ndarray, np.ndarray]:
    n = X.shape[0]
    components = np.arange(1, max_components + 1)
    rmsecv = np.zeros(max_components)
    for kk, k in enumerate(components):
        preds = np.zeros(n)
        for train, test in folds:
            try:
                model = fit_fn(X[train], y[train], n_components=int(k))
                preds[test] = np.asarray(model.predict(X[test])).flatten()
            except Exception:
                preds[test] = np.nan
        diff = preds - y
        diff = diff[~np.isnan(diff)]
        rmsecv[kk] = float(np.sqrt(np.mean(diff ** 2))) if diff.size else np.nan
    return components, rmsecv


def select_optimal_components(components: np.ndarray, rmsecv: np.ndarray,
                              rule: str = "min") -> int:
    """Pick the optimal number of components from an RMSECV curve.

    rule = "min" : argmin of RMSECV
    rule = "1se" : smallest k whose RMSECV is within one standard error of the
                   minimum (one-standard-error rule from Hastie/Tibshirani).
    """
    rmsecv = np.asarray(rmsecv, dtype=float)
    components = np.asarray(components, dtype=int)
    if rule == "min":
        return int(components[int(np.nanargmin(rmsecv))])
    elif rule == "1se":
        idx_min = int(np.nanargmin(rmsecv))
        rmin = rmsecv[idx_min]
        se = float(np.nanstd(rmsecv, ddof=1)) / np.sqrt(len(rmsecv))
        threshold = rmin + se
        candidates = np.where(rmsecv <= threshold)[0]
        return int(components[candidates[0]])
    else:
        raise ValueError(f"unknown rule {rule!r}; expected 'min' or '1se'")

"""Spectral preprocessing primitives.

All functions accept and return numpy arrays. They never look at Y / labels,
so they can be applied identically to any (n, p) spectra matrix. The classic
chemometrics preprocessing options are provided as named functions:

    - ``snv``                : standard normal variate row scaling
    - ``msc``                : multiplicative scatter correction (against a reference)
    - ``savgol_smooth``      : Savitzky-Golay smoothing
    - ``savgol_derivative``  : Savitzky-Golay first / second derivative
    - ``mean_center``        : column mean removal
    - ``autoscale``          : column z-scoring (centre + unit variance)
    - ``select_wavelength_window`` : keep a contiguous nm window
"""
from __future__ import annotations

import math
from typing import Tuple

import numpy as np


def snv(X: np.ndarray) -> np.ndarray:
    """Standard Normal Variate.

    For each row, subtract the row mean and divide by the row standard
    deviation. Removes additive (baseline) and multiplicative (scaling)
    scatter effects on a per-spectrum basis.
    """
    X = np.asarray(X, dtype=float)
    mu = X.mean(axis=1, keepdims=True)
    sd = X.std(axis=1, keepdims=True, ddof=1)
    sd = np.where(sd < 1e-12, 1.0, sd)
    return (X - mu) / sd


def msc(X: np.ndarray, reference: np.ndarray | None = None
        ) -> Tuple[np.ndarray, np.ndarray]:
    """Multiplicative Scatter Correction.

    For every spectrum x_i, find scalars (a_i, b_i) by least-squares such that
    x_i ≈ a_i + b_i * reference, then return  X_corr_i = (x_i - a_i) / b_i.
    If ``reference`` is None, the column-wise mean spectrum is used.

    Returns the corrected matrix and the reference spectrum used.
    """
    X = np.asarray(X, dtype=float)
    if reference is None:
        reference = X.mean(axis=0)
    reference = np.asarray(reference, dtype=float).flatten()
    Xc = np.empty_like(X)
    for i in range(X.shape[0]):
        # Linear regression of x_i on reference: x = a + b * reference
        A = np.vstack([np.ones_like(reference), reference]).T
        coef, *_ = np.linalg.lstsq(A, X[i, :], rcond=None)
        a, b = coef[0], coef[1]
        if abs(b) < 1e-12:
            b = 1.0
        Xc[i, :] = (X[i, :] - a) / b
    return Xc, reference


def _savgol_coeffs(window: int, polyorder: int, deriv: int) -> np.ndarray:
    """Compute Savitzky-Golay convolution coefficients for one window centre.

    The coefficients are the (deriv-th derivative * factorial(deriv))-th row of
    the pseudo-inverse of the Vandermonde matrix at the half-window points.
    """
    if window % 2 == 0 or window < 1:
        raise ValueError("window must be an odd positive integer")
    if polyorder >= window:
        raise ValueError("polyorder must be < window")
    half = (window - 1) // 2
    x = np.arange(-half, half + 1, dtype=float)
    A = np.vander(x, polyorder + 1, increasing=True)  # shape (window, polyorder+1)
    pinv = np.linalg.pinv(A)
    coeffs = pinv[deriv, :] * float(math.factorial(deriv))
    return coeffs


def _convolve_rows(X: np.ndarray, coeffs: np.ndarray) -> np.ndarray:
    """Apply the same 1-D convolution kernel to each row of X (mode='same')."""
    out = np.empty_like(X)
    half = (len(coeffs) - 1) // 2
    for i in range(X.shape[0]):
        # numpy convolve in 'same' mode flips the kernel; use np.convolve
        out[i, :] = np.convolve(X[i, :], coeffs[::-1], mode="same")
        # Edges (first/last `half`) are unreliable; replace with nearest valid value
        if half > 0:
            out[i, :half] = out[i, half]
            out[i, -half:] = out[i, -half - 1]
    return out


def savgol_smooth(X: np.ndarray, window: int = 11, polyorder: int = 2
                  ) -> np.ndarray:
    """Savitzky-Golay smoothing (deriv=0) with the given window and polyorder."""
    coeffs = _savgol_coeffs(window, polyorder, deriv=0)
    return _convolve_rows(np.asarray(X, dtype=float), coeffs)


def savgol_derivative(X: np.ndarray, window: int = 11, polyorder: int = 2,
                      deriv: int = 1) -> np.ndarray:
    """Savitzky-Golay derivative (1st or 2nd) of each spectrum row."""
    if deriv not in (1, 2):
        raise ValueError("deriv must be 1 or 2")
    coeffs = _savgol_coeffs(window, polyorder, deriv=deriv)
    return _convolve_rows(np.asarray(X, dtype=float), coeffs)


def mean_center(X: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """Subtract the column-mean from each column. Returns (X_centred, col_mean)."""
    X = np.asarray(X, dtype=float)
    mu = X.mean(axis=0)
    return X - mu, mu


def autoscale(X: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Column-wise z-score (mean 0, unit variance). Returns (X_scaled, mu, sd)."""
    X = np.asarray(X, dtype=float)
    mu = X.mean(axis=0)
    sd = X.std(axis=0, ddof=1)
    sd = np.where(sd < 1e-12, 1.0, sd)
    return (X - mu) / sd, mu, sd


def select_wavelength_window(X: np.ndarray, wavelengths: np.ndarray,
                             nm_min: int, nm_max: int
                             ) -> Tuple[np.ndarray, np.ndarray]:
    """Restrict the spectra to the wavelength range [nm_min, nm_max] (inclusive).

    Returns (X_subset, wavelengths_subset).
    """
    wavelengths = np.asarray(wavelengths)
    mask = (wavelengths >= nm_min) & (wavelengths <= nm_max)
    if not np.any(mask):
        raise ValueError(f"no wavelengths in window [{nm_min}, {nm_max}] nm")
    return X[:, mask], wavelengths[mask]

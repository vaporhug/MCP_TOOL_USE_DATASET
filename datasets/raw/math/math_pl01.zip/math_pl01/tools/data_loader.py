"""Data-loading primitives for the corn NIR task.

Each function returns numpy arrays / pandas DataFrames. They do not contain
any modelling or preprocessing logic — the agent composes them with the
analytical tools.
"""
from __future__ import annotations

import os
from typing import Tuple, Dict

import numpy as np
import pandas as pd


def load_spectra(csv_path: str) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Load a spectra CSV.

    The expected file has columns ``sample_id, nm_1100, nm_1102, ..., nm_2498``.
    Returns
    -------
    sample_ids : (n,) int array
    wavelengths : (p,) int array of nm
    X : (n, p) float matrix of absorbance values
    """
    if not os.path.isfile(csv_path):
        raise FileNotFoundError(csv_path)
    df = pd.read_csv(csv_path)
    if "sample_id" not in df.columns:
        raise ValueError(f"missing 'sample_id' column in {csv_path}")
    sample_ids = df["sample_id"].astype(int).to_numpy()
    wl_cols = [c for c in df.columns if c.startswith("nm_")]
    wavelengths = np.array([int(c.split("_")[1]) for c in wl_cols], dtype=int)
    X = df[wl_cols].to_numpy(dtype=float)
    return sample_ids, wavelengths, X


def load_properties(csv_path: str) -> Tuple[np.ndarray, np.ndarray, list]:
    """Load the reference property table.

    Expected columns: ``sample_id, Moisture, Oil, Protein, Starch`` (any of these
    four, in this order). Returns sample_ids, Y matrix, and column names.
    """
    if not os.path.isfile(csv_path):
        raise FileNotFoundError(csv_path)
    df = pd.read_csv(csv_path)
    if "sample_id" not in df.columns:
        raise ValueError(f"missing 'sample_id' column in {csv_path}")
    sample_ids = df["sample_id"].astype(int).to_numpy()
    target_cols = [c for c in df.columns if c != "sample_id"]
    Y = df[target_cols].to_numpy(dtype=float)
    return sample_ids, Y, target_cols


def load_wavelengths(csv_path: str) -> np.ndarray:
    """Read the standalone wavelengths CSV (single column ``wavelength_nm``)."""
    if not os.path.isfile(csv_path):
        raise FileNotFoundError(csv_path)
    df = pd.read_csv(csv_path)
    if "wavelength_nm" not in df.columns:
        # accept first column
        return df.iloc[:, 0].to_numpy(dtype=int)
    return df["wavelength_nm"].to_numpy(dtype=int)


def split_calibration_prediction(n_samples: int, n_calibration: int,
                                 random_seed: int = 42
                                 ) -> Tuple[np.ndarray, np.ndarray]:
    """Random split of ``n_samples`` indices into a calibration set of size
    ``n_calibration`` and a prediction set with the remaining samples.

    Returns two int arrays (sorted) of the calibration and prediction indices.

    Note: the canonical task split is the deterministic 60/20 split bundled
    as ``input_data/data/split.csv``; prefer ``load_canonical_split`` below
    for any expected-metric comparison against the target paper Tables 5-7.
    """
    if n_calibration >= n_samples or n_calibration < 1:
        raise ValueError(f"n_calibration must lie in (0, {n_samples})")
    rng = np.random.default_rng(random_seed)
    perm = rng.permutation(n_samples)
    calib = np.sort(perm[:n_calibration])
    pred = np.sort(perm[n_calibration:])
    return calib, pred


def load_canonical_split(csv_path: str) -> Tuple[np.ndarray, np.ndarray]:
    """Load the bundled fixed ``split.csv`` (sample_id, split) and return
    ``(calib_idx, pred_idx)`` as 0-based numpy int arrays of row positions
    aligned with the spectra/properties files.
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    df = df.sort_values("sample_id").reset_index(drop=True)
    calib = np.where(df["split"].str.lower().str.strip() == "calibration")[0]
    pred = np.where(df["split"].str.lower().str.strip() == "prediction")[0]
    return calib.astype(int), pred.astype(int)


def select_target(Y: np.ndarray, target_cols: list, name: str) -> np.ndarray:
    """Return the 1-D array for the named target column from a Y matrix."""
    name_l = name.strip().lower()
    for j, c in enumerate(target_cols):
        if c.strip().lower() == name_l:
            return Y[:, j].astype(float).copy()
    raise KeyError(f"target {name!r} not found among {target_cols}")


def summarise_target(y: np.ndarray) -> Dict[str, float]:
    """Return min / max / mean / std of a target vector as a plain dict."""
    return {
        "min": float(np.min(y)),
        "max": float(np.max(y)),
        "mean": float(np.mean(y)),
        "std": float(np.std(y, ddof=1)),
        "n": int(y.size),
    }

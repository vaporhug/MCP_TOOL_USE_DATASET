"""Principal Component Regression (PCR) baseline.

PCR projects mean-centred X onto its first ``n_components`` left singular
vectors and then performs OLS regression of Y on the scores. It is the natural
chemometric foil to PLS because both are latent-variable methods, but PCR's
components are chosen for X-variance only (not Y-relevance).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple

import numpy as np


@dataclass
class PCRModel:
    n_components: int
    x_mean: np.ndarray            # (p,)
    y_mean: np.ndarray            # (m,)
    P: np.ndarray                 # (p, n_components) loadings (= V[:, :k])
    B_centred: np.ndarray         # (p, m) regression coefficients

    def predict(self, X_new: np.ndarray) -> np.ndarray:
        Xc = np.asarray(X_new, dtype=float) - self.x_mean
        return Xc @ self.B_centred + self.y_mean


def fit_pcr(X: np.ndarray, Y: np.ndarray, n_components: int) -> PCRModel:
    """Fit a Principal Component Regression model.

    1. Mean-centre X (and Y).
    2. SVD of centred X = U * S * V^T.
    3. Truncate to the first ``n_components``.
    4. OLS regression of Y on T = U_k * S_k.
    """
    X = np.asarray(X, dtype=float)
    Y_in = np.asarray(Y, dtype=float)
    if Y_in.ndim == 1:
        Y_mat = Y_in.reshape(-1, 1)
    else:
        Y_mat = Y_in
    n, p = X.shape
    if Y_mat.shape[0] != n:
        raise ValueError(f"X has {n} rows but Y has {Y_mat.shape[0]}")
    n_max = min(n - 1, p)
    if n_components < 1 or n_components > n_max:
        raise ValueError(f"n_components must lie in [1, {n_max}], got {n_components}")

    x_mean = X.mean(axis=0)
    y_mean = Y_mat.mean(axis=0)
    Xc = X - x_mean
    Yc = Y_mat - y_mean

    U, S, Vt = np.linalg.svd(Xc, full_matrices=False)
    V = Vt.T
    Pk = V[:, :n_components]
    Sk = S[:n_components]
    Uk = U[:, :n_components]
    Tk = Uk * Sk  # equivalent to Xc @ Pk

    # OLS of Y on Tk
    # B_t  has shape (n_components, m)
    B_t = np.linalg.pinv(Tk) @ Yc
    B_centred = Pk @ B_t  # (p, m)

    return PCRModel(
        n_components=n_components,
        x_mean=x_mean,
        y_mean=y_mean,
        P=Pk,
        B_centred=B_centred,
    )

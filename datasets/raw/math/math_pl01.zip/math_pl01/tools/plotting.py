"""Plotting helpers. Each function returns a JSON-style dict ``{"path": <png>}``.

All plots use matplotlib's ``Agg`` backend so the functions work head-less in
notebooks, scripts and unit tests.
"""
from __future__ import annotations

import os
from typing import Dict, Sequence

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def _save(fig, out_path: str) -> Dict[str, str]:
    os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
    fig.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"path": out_path}


def plot_spectra_panel(spectra_matrices: Sequence[np.ndarray],
                       wavelengths: np.ndarray,
                       titles: Sequence[str],
                       out_path: str,
                       max_lines: int = 80) -> Dict[str, str]:
    """Side-by-side panel of NIR spectra from one or more instruments.

    Each entry of ``spectra_matrices`` is an (n, p) array; lines (samples) are
    overlaid in a thin transparent style.
    """
    n_panels = len(spectra_matrices)
    if n_panels < 1:
        raise ValueError("at least one spectra matrix is required")
    fig, axes = plt.subplots(1, n_panels, figsize=(4.5 * n_panels, 3.6),
                             sharey=True, squeeze=False)
    for ax, X, title in zip(axes[0], spectra_matrices, titles):
        n_show = min(max_lines, X.shape[0])
        for i in range(n_show):
            ax.plot(wavelengths, X[i, :], lw=0.6, alpha=0.5)
        ax.set_xlabel("Wavelength (nm)")
        ax.set_title(title)
        ax.grid(True, alpha=0.3)
    axes[0, 0].set_ylabel("Absorbance")
    fig.suptitle("NIR spectra (raw)")
    fig.tight_layout()
    return _save(fig, out_path)


def plot_rmsecv_curve(components: np.ndarray, rmsecv: np.ndarray,
                      out_path: str, title: str = "RMSECV vs n_components",
                      ylabel: str = "RMSECV",
                      best_k: int | None = None) -> Dict[str, str]:
    """Plot the RMSECV curve and mark the chosen optimum (if provided)."""
    fig, ax = plt.subplots(figsize=(5.5, 3.8))
    ax.plot(components, rmsecv, "o-", color="tab:blue", lw=1.6, ms=5)
    if best_k is not None:
        ax.axvline(best_k, color="tab:red", ls="--", lw=1.0,
                   label=f"selected k={int(best_k)}")
        ax.legend()
    ax.set_xlabel("n components")
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    return _save(fig, out_path)


def plot_vip_bar(wavelengths: np.ndarray, vip: np.ndarray,
                 out_path: str, title: str = "VIP scores",
                 threshold: float = 1.0) -> Dict[str, str]:
    """Bar plot of VIP scores against wavelength with a horizontal threshold."""
    fig, ax = plt.subplots(figsize=(7.5, 3.6))
    ax.bar(wavelengths, vip, width=2.0, color="tab:purple", alpha=0.85)
    ax.axhline(threshold, color="tab:red", ls="--", lw=1.0,
               label=f"VIP = {threshold:.1f}")
    ax.set_xlabel("Wavelength (nm)")
    ax.set_ylabel("VIP score")
    ax.set_title(title)
    ax.legend()
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    return _save(fig, out_path)


def plot_parity(y_true_calib: np.ndarray, y_pred_calib: np.ndarray,
                y_true_pred: np.ndarray, y_pred_pred: np.ndarray,
                out_path: str, target_name: str = "Y") -> Dict[str, str]:
    """Parity plot: predicted vs reference for both calibration and prediction sets."""
    fig, ax = plt.subplots(figsize=(4.6, 4.6))
    ax.scatter(y_true_calib, y_pred_calib, color="tab:blue",
               edgecolor="white", label="Calibration", alpha=0.85)
    ax.scatter(y_true_pred, y_pred_pred, color="tab:orange",
               marker="s", edgecolor="white", label="Prediction", alpha=0.85)
    lo = float(min(np.min(y_true_calib), np.min(y_true_pred)))
    hi = float(max(np.max(y_true_calib), np.max(y_true_pred)))
    pad = 0.05 * (hi - lo)
    ax.plot([lo - pad, hi + pad], [lo - pad, hi + pad], "k--", lw=1.0,
            label="y = x")
    ax.set_xlim(lo - pad, hi + pad)
    ax.set_ylim(lo - pad, hi + pad)
    ax.set_xlabel(f"Reference {target_name} (%)")
    ax.set_ylabel(f"Predicted {target_name} (%)")
    ax.set_title(f"PLS parity plot - {target_name}")
    ax.legend(loc="upper left")
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    return _save(fig, out_path)


def plot_pls_vs_pcr_bar(target_names: Sequence[str],
                        pls_r2: Sequence[float], pcr_r2: Sequence[float],
                        out_path: str, title: str = "PLS vs PCR R^2 (prediction)"
                        ) -> Dict[str, str]:
    """Grouped bar chart comparing PLS and PCR R^2 across multiple targets."""
    x = np.arange(len(target_names))
    w = 0.35
    fig, ax = plt.subplots(figsize=(6.0, 3.8))
    ax.bar(x - w / 2, pls_r2, w, color="tab:blue", label="PLS")
    ax.bar(x + w / 2, pcr_r2, w, color="tab:gray", label="PCR")
    ax.set_xticks(x)
    ax.set_xticklabels(target_names, rotation=0)
    ax.set_ylabel(r"$R^{2}$ (prediction)")
    ax.set_ylim(0.0, 1.05)
    ax.set_title(title)
    ax.legend()
    ax.grid(True, alpha=0.3, axis="y")
    fig.tight_layout()
    return _save(fig, out_path)

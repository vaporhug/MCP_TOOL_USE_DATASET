"""Standard regression-quality metrics for chemometric calibration.

All functions accept 1-D arrays (n,) — for multi-target use, call them per
column. Computations are numpy-only, no scikit-learn dependency.

The naming convention matches the chemometrics literature:
    - RMSEC  : RMSE on the calibration set
    - RMSECV : RMSE under cross-validation
    - RMSEP  : RMSE on the held-out prediction set
    - R2     : coefficient of determination (1 - SSres / SStot, NOT Pearson r^2)
    - RPD    : Ratio of Performance to Deviation (std(y) / RMSEP)
    - bias   : mean(y_pred - y_true)
"""
from __future__ import annotations

from typing import Dict

import numpy as np


def rmse(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    y_true = np.asarray(y_true, dtype=float).flatten()
    y_pred = np.asarray(y_pred, dtype=float).flatten()
    return float(np.sqrt(np.mean((y_true - y_pred) ** 2)))


def r2_score(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Coefficient of determination R^2 = 1 - SS_res / SS_tot.

    This is the standard chemometric definition. It is **not** the squared
    Pearson correlation; the two only agree when the predictor is OLS-linear.
    R^2 < 0 is allowed (model worse than predicting the mean).
    """
    y_true = np.asarray(y_true, dtype=float).flatten()
    y_pred = np.asarray(y_pred, dtype=float).flatten()
    ss_tot = float(np.sum((y_true - y_true.mean()) ** 2))
    ss_res = float(np.sum((y_true - y_pred) ** 2))
    if ss_tot < 1e-14:
        return float("nan")
    return 1.0 - ss_res / ss_tot


def rpd(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Ratio of Performance to Deviation = std(y_true, ddof=1) / RMSE."""
    y_true = np.asarray(y_true, dtype=float).flatten()
    sd = float(np.std(y_true, ddof=1))
    err = rmse(y_true, y_pred)
    if err < 1e-14:
        return float("inf")
    return sd / err


def bias(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Mean of (predicted - observed). Positive => over-prediction on average."""
    y_true = np.asarray(y_true, dtype=float).flatten()
    y_pred = np.asarray(y_pred, dtype=float).flatten()
    return float(np.mean(y_pred - y_true))


def report_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> Dict[str, float]:
    """Convenience wrapper returning the four common metrics as a dict."""
    return {
        "RMSE": rmse(y_true, y_pred),
        "R2": r2_score(y_true, y_pred),
        "RPD": rpd(y_true, y_pred),
        "bias": bias(y_true, y_pred),
    }

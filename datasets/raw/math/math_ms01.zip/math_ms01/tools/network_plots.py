"""
Plotting tools for network community-detection results.

All functions return {'path': output_path} after writing a PNG.
"""

import os
from typing import Optional, Sequence

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import networkx as nx


def _ensure_dir(path: str) -> None:
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)


def plot_graph_with_communities(G: nx.Graph, communities: dict,
                                output_path: str,
                                title: str = "Communities",
                                seed: int = 42,
                                node_size: int = 200,
                                with_labels: bool = False,
                                figsize=(8, 6)) -> dict:
    """Draw the graph with nodes coloured by community label.

    Uses spring-layout for placement; community ids are mapped to a
    qualitative colormap.

    Parameters
    ----------
    G : networkx.Graph
    communities : dict
        node -> int community id.
    output_path : str
        Where to write the PNG.
    title : str
    seed : int
        Layout seed (reproducibility).
    node_size : int
    with_labels : bool
        Whether to print node identifiers on top of nodes.

    Returns
    -------
    dict
        {'path': output_path}.
    """
    _ensure_dir(output_path)
    pos = nx.spring_layout(G, seed=seed)
    cs = sorted(set(communities.values()))
    cmap = plt.colormaps.get_cmap("tab10").resampled(max(len(cs), 1))
    color_map = {c: cmap(i) for i, c in enumerate(cs)}
    node_colors = [color_map[communities[n]] for n in G.nodes()]
    fig, ax = plt.subplots(figsize=figsize)
    nx.draw_networkx_edges(G, pos, alpha=0.4, ax=ax)
    nx.draw_networkx_nodes(G, pos, node_color=node_colors,
                           node_size=node_size, edgecolors="black",
                           linewidths=0.5, ax=ax)
    if with_labels:
        nx.draw_networkx_labels(G, pos, font_size=7, ax=ax)
    ax.set_title(title)
    ax.set_axis_off()
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path}


def plot_community_size_distribution(communities: dict,
                                     output_path: str,
                                     title: str = "Community size distribution") -> dict:
    """Bar chart of community sizes (sorted descending).

    Parameters
    ----------
    communities : dict
        node -> int community id.
    output_path : str
    title : str

    Returns
    -------
    dict
    """
    _ensure_dir(output_path)
    vals = list(communities.values())
    unique, counts = np.unique(vals, return_counts=True)
    order = np.argsort(-counts)
    sorted_counts = counts[order]
    sorted_ids = unique[order]
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.bar(range(len(sorted_counts)), sorted_counts, color="steelblue",
           edgecolor="black", linewidth=0.5)
    ax.set_xticks(range(len(sorted_counts)))
    ax.set_xticklabels([str(c) for c in sorted_ids])
    ax.set_xlabel("Community id")
    ax.set_ylabel("Number of nodes")
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path}


def plot_modularity_comparison(results: dict, output_path: str,
                               title: str = "Modularity by network and method") -> dict:
    """Grouped bar chart comparing modularity Q across networks/methods.

    Parameters
    ----------
    results : dict
        Mapping of {network_name: {method_name: Q_value}}.
    output_path : str
    title : str

    Returns
    -------
    dict
    """
    _ensure_dir(output_path)
    networks = list(results.keys())
    methods = sorted({m for v in results.values() for m in v})
    n_net = len(networks)
    n_meth = len(methods)
    if n_net == 0 or n_meth == 0:
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, "No data", ha="center")
        fig.savefig(output_path, dpi=150)
        plt.close(fig)
        return {"path": output_path}
    width = 0.8 / n_meth
    x_base = np.arange(n_net)
    fig, ax = plt.subplots(figsize=(max(6, n_net * 1.3), 4.5))
    cmap = plt.colormaps.get_cmap("tab10").resampled(n_meth)
    for j, m in enumerate(methods):
        ys = [results[n].get(m, 0.0) for n in networks]
        ax.bar(x_base + j * width - 0.4 + width / 2, ys, width=width,
               label=m, color=cmap(j), edgecolor="black", linewidth=0.4)
    ax.set_xticks(x_base)
    ax.set_xticklabels(networks)
    ax.set_ylabel("Modularity Q")
    ax.set_title(title)
    ax.legend(loc="best", frameon=False)
    ax.grid(axis="y", alpha=0.3)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path}


def plot_eigenvector_split(eigenvector: np.ndarray,
                           output_path: str,
                           title: str = "Leading eigenvector of modularity matrix",
                           node_labels: Optional[Sequence] = None) -> dict:
    """Bar chart of the leading eigenvector elements with sign-based split.

    Parameters
    ----------
    eigenvector : np.ndarray
        Length-n leading eigenvector.
    output_path : str
    title : str
    node_labels : optional sequence
        If given, used as x-axis tick labels.

    Returns
    -------
    dict
    """
    _ensure_dir(output_path)
    eigenvector = np.asarray(eigenvector)
    colors = ["tab:red" if v >= 0 else "tab:blue" for v in eigenvector]
    fig, ax = plt.subplots(figsize=(max(6, len(eigenvector) * 0.18), 4))
    ax.bar(range(len(eigenvector)), eigenvector, color=colors,
           edgecolor="black", linewidth=0.3)
    ax.axhline(0, color="black", linewidth=0.6)
    ax.set_xlabel("Node")
    ax.set_ylabel("Leading eigenvector element")
    ax.set_title(title)
    if node_labels is not None:
        ax.set_xticks(range(len(eigenvector)))
        ax.set_xticklabels([str(l) for l in node_labels],
                           rotation=90, fontsize=7)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path}


def plot_confusion_matrix(matrix: np.ndarray,
                          output_path: str,
                          row_labels=None,
                          col_labels=None,
                          title: str = "Confusion matrix") -> dict:
    """Heatmap of a confusion / contingency matrix between two labellings.

    Parameters
    ----------
    matrix : np.ndarray
    output_path : str
    row_labels, col_labels : list-like, optional
    title : str

    Returns
    -------
    dict
    """
    _ensure_dir(output_path)
    M = np.asarray(matrix)
    fig, ax = plt.subplots(figsize=(max(4, M.shape[1] * 0.7),
                                    max(3, M.shape[0] * 0.7)))
    im = ax.imshow(M, cmap="Blues", aspect="auto")
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            ax.text(j, i, str(int(M[i, j])), ha="center", va="center",
                    color="black" if M[i, j] < M.max() / 2 else "white",
                    fontsize=9)
    if row_labels is not None:
        ax.set_yticks(range(M.shape[0]))
        ax.set_yticklabels([str(r) for r in row_labels])
    if col_labels is not None:
        ax.set_xticks(range(M.shape[1]))
        ax.set_xticklabels([str(c) for c in col_labels])
    ax.set_xlabel("Predicted community")
    ax.set_ylabel("True / external label")
    ax.set_title(title)
    fig.colorbar(im, ax=ax, fraction=0.045, pad=0.04)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path}


def plot_q_vs_n_communities(history: list, output_path: str,
                            title: str = "Modularity contribution by split") -> dict:
    """Plot the cumulative modularity gained at each recursive split.

    Parameters
    ----------
    history : list of dict
        Output of newman_recursive_split, each item with key 'dQ'.
    output_path : str
    title : str

    Returns
    -------
    dict
    """
    _ensure_dir(output_path)
    if not history:
        fig, ax = plt.subplots(figsize=(5, 3))
        ax.text(0.5, 0.5, "No splits", ha="center")
        fig.savefig(output_path, dpi=150)
        plt.close(fig)
        return {"path": output_path}
    dQ = [h["dQ"] for h in history]
    cum = np.cumsum(dQ)
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.bar(range(1, len(dQ) + 1), dQ, color="lightsteelblue",
           edgecolor="black", linewidth=0.4, label="dQ this split")
    ax.plot(range(1, len(dQ) + 1), cum, "o-", color="firebrick",
            label="cumulative Q")
    ax.set_xlabel("Split index")
    ax.set_ylabel("Modularity")
    ax.set_title(title)
    ax.legend(loc="best", frameon=False)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path}

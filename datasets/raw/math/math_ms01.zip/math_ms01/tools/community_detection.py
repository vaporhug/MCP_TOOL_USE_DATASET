"""
Community detection primitives.

Spectral leading-eigenvector method on the modularity matrix,
recursive bipartition with sub-graph modularity matrix correction,
Kernighan-Lin-style fine-tuning, and a Louvain-like greedy reference.
"""

from typing import Optional

import numpy as np
import networkx as nx


def modularity_matrix(A: np.ndarray) -> np.ndarray:
    """Build the modularity matrix B from an adjacency matrix.

    B_ij = A_ij - k_i * k_j / (2m), where k is the degree vector and m
    is the total number of edges.

    Parameters
    ----------
    A : np.ndarray
        Symmetric adjacency matrix of shape (n, n).

    Returns
    -------
    np.ndarray
        Modularity matrix B of shape (n, n).
    """
    A = np.asarray(A, dtype=float)
    k = A.sum(axis=1)
    m = A.sum() / 2.0
    if m <= 0:
        return np.zeros_like(A)
    return A - np.outer(k, k) / (2.0 * m)


def subgraph_modularity_matrix(A: np.ndarray, sub_idx: np.ndarray) -> np.ndarray:
    """Build the corrected sub-graph modularity matrix B^(g).

    For a subgraph g defined by row indices sub_idx in the global
    adjacency A, returns the matrix B^(g) where
        B^(g)_ij = A_ij - k_i * k_j / (2m) - delta_ij * (k_i^(g) - k_i * d_g / (2m))
    with k_i^(g) = sum of A within g for vertex i and d_g = sum of global
    degrees of vertices in g.

    Parameters
    ----------
    A : np.ndarray
        Full adjacency matrix.
    sub_idx : array-like of int
        Indices into A defining the sub-graph.

    Returns
    -------
    np.ndarray
        Corrected sub-graph modularity matrix of shape (|sub_idx|, |sub_idx|).
    """
    A = np.asarray(A, dtype=float)
    sub_idx = np.asarray(sub_idx, dtype=int)
    k_full = A.sum(axis=1)
    m_full = A.sum() / 2.0
    A_sub = A[np.ix_(sub_idx, sub_idx)]
    kg = A_sub.sum(axis=1)
    dg = k_full[sub_idx].sum()
    B_sub = A_sub - np.outer(k_full[sub_idx], k_full[sub_idx]) / (2.0 * m_full)
    correction = kg - k_full[sub_idx] * dg / (2.0 * m_full)
    np.fill_diagonal(B_sub, np.diag(B_sub) - correction)
    return B_sub


def leading_eigenvector_split(B: np.ndarray) -> dict:
    """Compute leading-eigenvector spectral split of a modularity matrix.

    Returns the assignment vector s in {-1, +1}^n produced by the sign of
    the eigenvector associated with the most positive eigenvalue. If the
    leading eigenvalue is non-positive, the sub-graph is reported as
    indivisible.

    Parameters
    ----------
    B : np.ndarray
        Modularity matrix or sub-graph modularity matrix.

    Returns
    -------
    dict
        {'s': array of +/-1 (length n) or None if indivisible,
         'leading_eigenvalue': float,
         'leading_eigenvector': np.ndarray length n,
         'indivisible': bool}.
    """
    B = np.asarray(B, dtype=float)
    if B.shape[0] < 2:
        return {"s": None, "leading_eigenvalue": 0.0,
                "leading_eigenvector": np.zeros(B.shape[0]),
                "indivisible": True}
    eigvals, eigvecs = np.linalg.eigh(B)
    idx = int(np.argmax(eigvals))
    lead_val = float(eigvals[idx])
    lead_vec = eigvecs[:, idx]
    if lead_val <= 1e-10:
        return {"s": None, "leading_eigenvalue": lead_val,
                "leading_eigenvector": lead_vec, "indivisible": True}
    s = np.where(lead_vec >= 0, 1, -1).astype(int)
    return {"s": s, "leading_eigenvalue": lead_val,
            "leading_eigenvector": lead_vec, "indivisible": False}


def modularity_from_assignment(A: np.ndarray, comm: np.ndarray) -> float:
    """Compute Newman's modularity Q from a community assignment vector.

    Q = (1 / 2m) * sum_{ij} (A_ij - k_i k_j / 2m) * delta(c_i, c_j).

    Parameters
    ----------
    A : np.ndarray
        Adjacency matrix.
    comm : np.ndarray
        Community label per node (length n).

    Returns
    -------
    float
        Modularity in [-0.5, 1].
    """
    A = np.asarray(A, dtype=float)
    comm = np.asarray(comm)
    k = A.sum(axis=1)
    m = A.sum() / 2.0
    if m <= 0:
        return 0.0
    same = (comm[:, None] == comm[None, :]).astype(float)
    Q = (A - np.outer(k, k) / (2.0 * m)) * same
    return float(Q.sum() / (2.0 * m))


def newman_recursive_split(A: np.ndarray, max_communities: int = 64) -> dict:
    """Recursive leading-eigenvector community detection (Newman 2006).

    Splits the network into two using the modularity matrix; for each
    resulting subgraph, builds the corrected sub-graph modularity matrix
    B^(g) and attempts to split again. Terminates a branch when the leading
    eigenvalue of B^(g) is non-positive (subgraph is "indivisible") or
    when splitting would not increase total modularity.

    Parameters
    ----------
    A : np.ndarray
        Symmetric adjacency matrix.
    max_communities : int
        Safety cap on number of communities.

    Returns
    -------
    dict
        {'community': np.ndarray of community labels (0..K-1) per node,
         'Q': float total modularity,
         'n_communities': int,
         'history': list of (parent_size, dQ_contribution) per split}.
    """
    A = np.asarray(A, dtype=float)
    n = A.shape[0]
    comm = np.zeros(n, dtype=int)
    next_id = 1
    history = []
    queue = [np.arange(n)]
    while queue and next_id < max_communities:
        sub = queue.pop()
        if len(sub) < 2:
            continue
        if len(sub) == n:
            B = modularity_matrix(A)
        else:
            B = subgraph_modularity_matrix(A, sub)
        split = leading_eigenvector_split(B)
        if split["indivisible"]:
            continue
        s = split["s"]
        # Sub-graph contribution to total Q (eq. 4 in Newman 2006)
        m_full = A.sum() / 2.0
        dQ = float(s @ B @ s) / (4.0 * m_full)
        if dQ <= 1e-10:
            continue
        pos_idx = sub[s == 1]
        neg_idx = sub[s == -1]
        if len(pos_idx) == 0 or len(neg_idx) == 0:
            continue
        # Assign new community id to one side
        comm[neg_idx] = next_id
        history.append({"parent_size": int(len(sub)),
                        "pos_size": int(len(pos_idx)),
                        "neg_size": int(len(neg_idx)),
                        "dQ": dQ,
                        "leading_eigenvalue": split["leading_eigenvalue"]})
        next_id += 1
        if len(pos_idx) >= 2:
            queue.append(pos_idx)
        if len(neg_idx) >= 2:
            queue.append(neg_idx)
    Q = modularity_from_assignment(A, comm)
    # Re-label to be contiguous 0..K-1
    unique = sorted(set(comm.tolist()))
    relabel = {c: i for i, c in enumerate(unique)}
    comm_relabeled = np.array([relabel[c] for c in comm.tolist()], dtype=int)
    return {
        "community": comm_relabeled,
        "Q": Q,
        "n_communities": len(unique),
        "history": history,
    }


def kernighan_lin_finetune(A: np.ndarray, comm: np.ndarray,
                           max_iters: int = 30) -> dict:
    """Kernighan-Lin-style fine-tuning of a community partition.

    Iteratively considers moving each node to the community whose move
    yields the largest increase in modularity, repeating until no positive
    move exists. This is the post-processing step described in Newman
    2006 section "Further techniques for modularity maximization".

    Parameters
    ----------
    A : np.ndarray
        Adjacency matrix.
    comm : np.ndarray
        Initial community assignment of length n.

    Returns
    -------
    dict
        {'community': improved assignment, 'Q': new modularity,
         'n_iters': iterations until convergence}.
    """
    A = np.asarray(A, dtype=float)
    comm = np.asarray(comm, dtype=int).copy()
    k = A.sum(axis=1)
    m = A.sum() / 2.0
    n = A.shape[0]

    def Q_of(c):
        same = (c[:, None] == c[None, :]).astype(float)
        return float(((A - np.outer(k, k) / (2 * m)) * same).sum() / (2 * m))

    Q_cur = Q_of(comm)
    for it in range(max_iters):
        improved = False
        for i in range(n):
            best_c = comm[i]
            best_dQ = 0.0
            unique = sorted(set(comm.tolist()))
            for c in unique:
                if c == comm[i]:
                    continue
                old = comm[i]
                comm[i] = c
                Q_new = Q_of(comm)
                dQ = Q_new - Q_cur
                if dQ > best_dQ + 1e-12:
                    best_dQ = dQ
                    best_c = c
                comm[i] = old
            if best_c != comm[i]:
                comm[i] = best_c
                Q_cur += best_dQ
                improved = True
        if not improved:
            break
    return {"community": comm, "Q": Q_cur, "n_iters": it + 1}


def greedy_modularity_clustering(G: nx.Graph) -> dict:
    """Greedy agglomerative modularity clustering (Clauset-Newman-Moore).

    Reference: Clauset, Newman, Moore 2004 (PRE), as implemented in
    networkx. Used as a baseline to compare against the spectral method.

    Parameters
    ----------
    G : networkx.Graph

    Returns
    -------
    dict
        {'community': dict node->int,
         'Q': float modularity,
         'n_communities': int}.
    """
    from networkx.algorithms.community import greedy_modularity_communities, modularity
    comms = list(greedy_modularity_communities(G))
    node_to_c = {}
    for cid, c in enumerate(comms):
        for v in c:
            node_to_c[v] = cid
    return {
        "community": node_to_c,
        "Q": float(modularity(G, comms)),
        "n_communities": len(comms),
    }


def spectral_communities_from_graph(G: nx.Graph,
                                    fine_tune: bool = True) -> dict:
    """Convenience wrapper: run the Newman 2006 spectral algorithm on a graph.

    Parameters
    ----------
    G : networkx.Graph
    fine_tune : bool
        If True, applies Kernighan-Lin-style finetuning after recursion.

    Returns
    -------
    dict
        {'community': dict node->int,
         'Q': float total modularity,
         'n_communities': int,
         'history': list of split records}.
    """
    nodes = list(G.nodes())
    A = nx.to_numpy_array(G, nodelist=nodes, weight=None)
    A = ((A + A.T) > 0).astype(float)
    np.fill_diagonal(A, 0.0)
    res = newman_recursive_split(A)
    if fine_tune and res["n_communities"] > 1:
        ft = kernighan_lin_finetune(A, res["community"])
        # Re-label contiguous
        unique = sorted(set(ft["community"].tolist()))
        relabel = {c: i for i, c in enumerate(unique)}
        comm_arr = np.array([relabel[c] for c in ft["community"].tolist()])
        Q_final = ft["Q"]
        n_c = len(unique)
    else:
        comm_arr = res["community"]
        Q_final = res["Q"]
        n_c = res["n_communities"]
    return {
        "community": {nodes[i]: int(comm_arr[i]) for i in range(len(nodes))},
        "Q": float(Q_final),
        "n_communities": n_c,
        "history": res["history"],
    }

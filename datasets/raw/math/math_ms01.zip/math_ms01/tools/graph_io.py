"""
Graph input/output primitives.

Functions for loading networks from various file formats, building
adjacency representations, and basic graph descriptive statistics.
"""

import csv
import os
from typing import Any, Optional

import numpy as np
import networkx as nx


def load_edge_list_csv(file_path: str, source_col: str = "source",
                       target_col: str = "target",
                       directed: bool = False) -> nx.Graph:
    """Load an undirected (or directed) graph from a CSV edge list.

    Each row of the CSV must contain two integer-or-string node identifiers.
    Self-loops and parallel edges are de-duplicated.

    Parameters
    ----------
    file_path : str
        Path to the CSV file.
    source_col, target_col : str
        Column names of the two endpoints.
    directed : bool
        If True, returns a DiGraph; otherwise an undirected Graph.

    Returns
    -------
    networkx.Graph
        Graph with integer node ids if all entries parse as int, else strings.
    """
    G = nx.DiGraph() if directed else nx.Graph()
    with open(file_path, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            u = row[source_col]
            v = row[target_col]
            try:
                u = int(u)
                v = int(v)
            except (TypeError, ValueError):
                pass
            if u == v:
                continue
            G.add_edge(u, v)
    return G


def load_gml(file_path: str, label: str = "label") -> nx.Graph:
    """Load a graph from a GML file using networkx.

    Falls back to label='id' if the requested label key is missing.

    Parameters
    ----------
    file_path : str
        Path to the .gml file.
    label : str
        Node attribute used as the networkx node identifier.

    Returns
    -------
    networkx.Graph
    """
    try:
        return nx.read_gml(file_path, label=label)
    except Exception:
        return nx.read_gml(file_path)


def load_node_labels_csv(file_path: str, node_col: str,
                         label_col: str) -> dict:
    """Load a per-node label table from a CSV file.

    Parameters
    ----------
    file_path : str
        CSV with at least node_col and label_col columns.
    node_col, label_col : str
        Column names for the node identifier and label.

    Returns
    -------
    dict
        Mapping from node id (int if convertible) to label string.
    """
    out = {}
    with open(file_path, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            n = row[node_col]
            try:
                n = int(n)
            except (TypeError, ValueError):
                pass
            out[n] = row[label_col]
    return out


def graph_to_adjacency(G: nx.Graph) -> dict:
    """Return adjacency matrix and node-list of an undirected graph.

    Parameters
    ----------
    G : networkx.Graph

    Returns
    -------
    dict
        {'A': numpy.ndarray (n,n) symmetric 0/1 adjacency,
         'nodes': list of node identifiers in row/column order,
         'n': int, 'm': int (edges)}.
    """
    nodes = list(G.nodes())
    A = nx.to_numpy_array(G, nodelist=nodes, weight=None)
    A = ((A + A.T) > 0).astype(float)
    np.fill_diagonal(A, 0.0)
    return {
        "A": A,
        "nodes": nodes,
        "n": len(nodes),
        "m": int(A.sum() / 2),
    }


def basic_graph_summary(G: nx.Graph) -> dict:
    """Compute basic graph statistics (size, density, degree stats).

    Parameters
    ----------
    G : networkx.Graph

    Returns
    -------
    dict
        n, m, density, mean_degree, max_degree, min_degree,
        n_connected_components, largest_cc_size.
    """
    G_und = G.to_undirected() if G.is_directed() else G
    degrees = [d for _, d in G_und.degree()]
    ccs = list(nx.connected_components(G_und))
    return {
        "n": G_und.number_of_nodes(),
        "m": G_und.number_of_edges(),
        "density": nx.density(G_und),
        "mean_degree": float(np.mean(degrees)) if degrees else 0.0,
        "max_degree": int(np.max(degrees)) if degrees else 0,
        "min_degree": int(np.min(degrees)) if degrees else 0,
        "n_connected_components": len(ccs),
        "largest_cc_size": max((len(c) for c in ccs), default=0),
    }


def largest_connected_component(G: nx.Graph) -> nx.Graph:
    """Extract the largest connected component subgraph.

    Parameters
    ----------
    G : networkx.Graph

    Returns
    -------
    networkx.Graph
        Induced subgraph on the largest CC, with original node ids.
    """
    G_und = G.to_undirected() if G.is_directed() else G
    ccs = list(nx.connected_components(G_und))
    if not ccs:
        return G_und.copy()
    largest = max(ccs, key=len)
    return G_und.subgraph(largest).copy()


def degree_distribution(G: nx.Graph) -> dict:
    """Return degree distribution histogram.

    Parameters
    ----------
    G : networkx.Graph

    Returns
    -------
    dict
        {'degrees': sorted unique degree values,
         'counts': matching count for each unique degree value}.
    """
    G_und = G.to_undirected() if G.is_directed() else G
    degrees = [d for _, d in G_und.degree()]
    if not degrees:
        return {"degrees": [], "counts": []}
    vals, counts = np.unique(degrees, return_counts=True)
    return {"degrees": vals.tolist(), "counts": counts.tolist()}

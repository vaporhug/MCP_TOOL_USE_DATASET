"""
Clustering quality and comparison metrics.

Modularity from a partition, Normalized Mutual Information (NMI),
Adjusted Rand Index (ARI), confusion matrices for community comparison.
"""

from typing import Sequence

import numpy as np


def _to_label_array(labels) -> np.ndarray:
    """Coerce a labelling (dict, list, or array) into an integer label array."""
    if isinstance(labels, dict):
        keys_sorted = sorted(labels.keys(), key=lambda x: (str(type(x)), x))
        arr = [labels[k] for k in keys_sorted]
    else:
        arr = list(labels)
    # Map distinct labels to 0..K-1
    unique = sorted(set(arr), key=lambda x: (str(type(x)), str(x)))
    mapping = {u: i for i, u in enumerate(unique)}
    return np.array([mapping[a] for a in arr], dtype=int)


def confusion_matrix_communities(true_labels, pred_labels) -> dict:
    """Compute the contingency table between two labellings.

    Parameters
    ----------
    true_labels, pred_labels : array-like or dict
        Per-node labels. If both are dicts, the keys are aligned.

    Returns
    -------
    dict
        {'matrix': np.ndarray of shape (K_true, K_pred),
         'true_labels': sorted unique true labels,
         'pred_labels': sorted unique pred labels,
         'n': total nodes}.
    """
    if isinstance(true_labels, dict) and isinstance(pred_labels, dict):
        common = sorted(set(true_labels.keys()) & set(pred_labels.keys()),
                        key=lambda x: (str(type(x)), x))
        t = [true_labels[k] for k in common]
        p = [pred_labels[k] for k in common]
    else:
        t = list(true_labels)
        p = list(pred_labels)
    t_arr = _to_label_array(t)
    p_arr = _to_label_array(p)
    K_t = int(t_arr.max()) + 1 if len(t_arr) else 0
    K_p = int(p_arr.max()) + 1 if len(p_arr) else 0
    M = np.zeros((K_t, K_p), dtype=int)
    for ti, pi in zip(t_arr, p_arr):
        M[ti, pi] += 1
    t_labels_sorted = sorted(set(t), key=lambda x: (str(type(x)), str(x)))
    p_labels_sorted = sorted(set(p), key=lambda x: (str(type(x)), str(x)))
    return {
        "matrix": M,
        "true_labels": t_labels_sorted,
        "pred_labels": p_labels_sorted,
        "n": int(M.sum()),
    }


def normalized_mutual_information(true_labels, pred_labels) -> float:
    """Compute the symmetric Normalized Mutual Information (NMI).

    NMI = 2 * I(T; P) / (H(T) + H(P)).

    Parameters
    ----------
    true_labels, pred_labels : array-like or dict

    Returns
    -------
    float
        NMI in [0, 1]; 1 means perfect agreement.
    """
    cm = confusion_matrix_communities(true_labels, pred_labels)
    M = cm["matrix"].astype(float)
    n = M.sum()
    if n == 0:
        return 0.0
    Pi = M.sum(axis=1) / n
    Pj = M.sum(axis=0) / n
    Pij = M / n
    eps = 1e-15
    H_T = -np.sum(Pi[Pi > 0] * np.log(Pi[Pi > 0]))
    H_P = -np.sum(Pj[Pj > 0] * np.log(Pj[Pj > 0]))
    I = 0.0
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            if Pij[i, j] > 0:
                I += Pij[i, j] * np.log(Pij[i, j] / (Pi[i] * Pj[j] + eps))
    if H_T + H_P <= 0:
        return 0.0
    return float(2.0 * I / (H_T + H_P))


def adjusted_rand_index(true_labels, pred_labels) -> float:
    """Compute the Adjusted Rand Index (ARI) between two labellings.

    ARI corrects the Rand Index for chance agreement.

    Parameters
    ----------
    true_labels, pred_labels : array-like or dict

    Returns
    -------
    float
        ARI in [-1, 1]; 0 = chance, 1 = perfect.
    """
    from math import comb
    cm = confusion_matrix_communities(true_labels, pred_labels)
    M = cm["matrix"]
    n = M.sum()
    if n < 2:
        return 0.0
    sum_comb_M = sum(comb(int(v), 2) for v in M.flatten())
    sum_comb_a = sum(comb(int(s), 2) for s in M.sum(axis=1))
    sum_comb_b = sum(comb(int(s), 2) for s in M.sum(axis=0))
    expected = sum_comb_a * sum_comb_b / comb(int(n), 2)
    max_index = 0.5 * (sum_comb_a + sum_comb_b)
    if max_index == expected:
        return 0.0
    return float((sum_comb_M - expected) / (max_index - expected))


def purity(true_labels, pred_labels) -> float:
    """Compute clustering purity.

    For each predicted cluster, assign it to the most frequent true label
    in that cluster, then compute the fraction of correctly labelled
    nodes.

    Parameters
    ----------
    true_labels, pred_labels : array-like or dict

    Returns
    -------
    float
        Purity in [0, 1].
    """
    cm = confusion_matrix_communities(true_labels, pred_labels)
    M = cm["matrix"]
    n = M.sum()
    if n == 0:
        return 0.0
    return float(M.max(axis=0).sum() / n)


def best_match_accuracy(true_labels, pred_labels) -> dict:
    """Hungarian-style best-match accuracy between two clusterings.

    Returns the maximum classification accuracy under any one-to-one
    re-labelling of pred clusters to true clusters. Equivalent to
    matching when number of clusters is the same; greedy fallback used
    otherwise.

    Parameters
    ----------
    true_labels, pred_labels : array-like or dict

    Returns
    -------
    dict
        {'accuracy': float, 'mapping': dict pred_label->true_label,
         'matched': int correctly matched, 'n': int total}.
    """
    cm = confusion_matrix_communities(true_labels, pred_labels)
    M = cm["matrix"].copy()
    n = M.sum()
    if n == 0:
        return {"accuracy": 0.0, "mapping": {}, "matched": 0, "n": 0}
    K_t, K_p = M.shape
    # Greedy matching
    mapping = {}
    used_true = set()
    M_work = M.copy()
    for _ in range(min(K_t, K_p)):
        idx = np.unravel_index(np.argmax(M_work), M_work.shape)
        if M_work[idx] <= 0:
            break
        ti, pi = idx
        mapping[cm["pred_labels"][pi]] = cm["true_labels"][ti]
        used_true.add(ti)
        M_work[ti, :] = -1
        M_work[:, pi] = -1
    matched = sum(M[list(cm["true_labels"]).index(mapping[p]), j]
                  for j, p in enumerate(cm["pred_labels"]) if p in mapping)
    return {
        "accuracy": float(matched / n),
        "mapping": mapping,
        "matched": int(matched),
        "n": int(n),
    }


def community_size_distribution(labels) -> dict:
    """Count the size of each community.

    Parameters
    ----------
    labels : array-like or dict

    Returns
    -------
    dict
        {'community_id': sorted list, 'size': matching list}.
    """
    if isinstance(labels, dict):
        vals = list(labels.values())
    else:
        vals = list(labels)
    unique, counts = np.unique(vals, return_counts=True)
    order = np.argsort(-counts)
    return {
        "community_id": [int(unique[i]) if isinstance(unique[i], (int, np.integer)) else unique[i] for i in order],
        "size": counts[order].tolist(),
    }


def fraction_label_in_cluster(node_labels: dict, communities: dict) -> dict:
    """Compute per-cluster composition by label.

    For each cluster, returns the fraction of nodes carrying each label
    (e.g. fraction conservative vs liberal in a community of books).

    Parameters
    ----------
    node_labels : dict
        Mapping node -> external label string (e.g. 'c'/'l'/'n').
    communities : dict
        Mapping node -> community id (int).

    Returns
    -------
    dict
        {'cluster_id': list, 'label': list, 'count': list, 'fraction': list}.
    """
    common = sorted(set(node_labels.keys()) & set(communities.keys()),
                    key=lambda x: (str(type(x)), x))
    cid = []
    lab = []
    cnt = []
    frac = []
    cluster_sizes = {}
    for c in {communities[n] for n in common}:
        cluster_sizes[c] = sum(1 for n in common if communities[n] == c)
    seen = set()
    for n in common:
        c = communities[n]
        l = node_labels[n]
        key = (c, l)
        if key in seen:
            continue
        seen.add(key)
        k = sum(1 for m in common
                if communities[m] == c and node_labels[m] == l)
        cid.append(int(c))
        lab.append(l)
        cnt.append(int(k))
        frac.append(float(k / cluster_sizes[c]) if cluster_sizes[c] else 0.0)
    return {"cluster_id": cid, "label": lab, "count": cnt, "fraction": frac}

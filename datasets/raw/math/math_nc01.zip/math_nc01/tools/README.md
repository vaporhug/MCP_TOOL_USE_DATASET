# Network Community Detection Tools

## Tool Categories

### network_analysis.py — Domain Primitives
Core network analysis functions for community detection via graph embeddings:
- **Data loading**: `load_network`, `build_adjacency_matrix`
- **Spectral methods**: `compute_normalized_laplacian`, `spectral_embedding`, `modularity_spectral_embedding`, `adjacency_spectral_embedding`
- **Random-walk embeddings**: `random_walk_sequences`, `node2vec_embedding` (genuine random-walk PMI factorization), `deepwalk_embedding`, `verify_spectral_equivalence` (empirically checks the node2vec / normalized-Laplacian equivalence; the Laplacian eigenvectors `Gamma` are rescaled by `D^{1/2}` to match the node2vec-matrix eigenvectors `U = D^{1/2} Gamma` of paper Eq. 9)
- **Clustering**: `kmeans_clustering` (row-normalizes embeddings by default), `voronoi_clustering`, `estimate_n_clusters_silhouette`
- **Evaluation**: `element_centric_similarity` (baseline-corrected per the paper: `S = (S_raw - E[S_random])/(1 - E[S_random])`, so a random relabelling scores 0 on expectation and `S>0` means better-than-chance; pass `adjusted=False` for the raw Gates-et-al. metric), `normalized_mutual_information`, `adjusted_rand_index`
- **Detectability**: `compute_detectability_limit`, `generate_planted_partition_model`, `sweep_mixing_parameter`
- **Network statistics**: `compute_network_statistics`, `compute_community_mixing_matrix`
- **Plotting**: `plot_embedding_2d`, `plot_method_comparison`, `plot_detectability_curves`, `plot_multi_network_comparison`, `plot_graph_kernel`

### data_processing.py — Shared Data Helpers
- `list_data_files`, `inspect_csv`, `merge_node_edge_data`, `compute_label_permutation_invariant_score`

### database_retrieval.py — Reference Metadata
- `get_benchmark_network_info`: metadata for standard benchmark networks

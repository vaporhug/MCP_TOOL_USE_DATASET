"""
Gaussian-process regression primitives:

  * exact GP fit and predict via Cholesky
  * negative log marginal likelihood
  * leave-one-out cross-validation predictive log density
  * MLE hyperparameter optimisation by L-BFGS-B over a log-scale
    parameterisation
  * local approximate GP prediction (nearest-neighbour subset)

Dependencies: this module imports numpy and scipy
(scipy.linalg, scipy.optimize, scipy.stats, scipy.special). The agent
does NOT need to call scikit-learn — these helpers cover the full GP
pipeline. The agent passes the kernel name from `kernels.py`.

Note on scalability: exact gp_fit / gp_predict build dense N x N kernel
matrices, so they are only practical on training subsets (a few thousand
points). For full-grid prediction over the 105,569-pixel MODIS training
set the agent should use local_gp_predict (nearest-neighbour subset
approximation), which is the path the task instruction's Simplified-task
scope endorses.
"""

from __future__ import annotations

from typing import Callable, Optional, Sequence, Tuple

import numpy as np
from scipy.linalg import cho_factor, cho_solve, solve_triangular
from scipy.optimize import minimize

from .data_processing import euclidean_distance_matrix
from . import kernels as K


# ---------------------------------------------------------------------------
# Exact GP fit / predict
# ---------------------------------------------------------------------------


def gp_fit(X: np.ndarray, y: np.ndarray, kernel_name: str,
           params: dict, nugget: float = 1e-6, mean: float = 0.0) -> dict:
    """Fit an exact GP given fixed kernel hyperparameters.

    Computes the Cholesky factor of K + nugget*I and the alpha vector
    used in subsequent prediction calls.

    Parameters
    ----------
    X : (n,d) array
    y : (n,) array of observations
    kernel_name : str
        See `kernels.kernel_dispatch` for accepted names.
    params : dict
        Hyperparameter dict containing at least ``sigma2`` and
        ``length_scale``. Matern needs ``nu``; periodic needs ``period``.
    nugget : float
        Diagonal jitter / observation noise variance (sigma_n^2).
    mean : float
        Constant mean subtracted from y before the GP fit.

    Returns
    -------
    dict with keys: 'X', 'y_centred', 'mean', 'kernel_name', 'params',
        'nugget', 'L', 'alpha', 'log_marginal_likelihood'.
    """
    X = np.asarray(X, dtype=float)
    y = np.asarray(y, dtype=float)
    yc = y - float(mean)
    D = euclidean_distance_matrix(X)
    Kmat = K.kernel_dispatch(kernel_name, D, params)
    Kmat = K.add_nugget(Kmat, nugget)
    L, low = cho_factor(Kmat, lower=True)
    alpha = cho_solve((L, low), yc)
    n = len(yc)
    log_det = 2.0 * np.sum(np.log(np.diag(L)))
    lml = -0.5 * yc @ alpha - 0.5 * log_det - 0.5 * n * np.log(2.0 * np.pi)
    return {
        "X": X,
        "y_centred": yc,
        "mean": float(mean),
        "kernel_name": kernel_name,
        "params": dict(params),
        "nugget": float(nugget),
        "L": L,
        "low": low,
        "alpha": alpha,
        "log_marginal_likelihood": float(lml),
    }


def gp_predict(model: dict, X_star: np.ndarray,
               return_var: bool = True,
               include_nugget_in_variance: bool = False) -> dict:
    """Predict the GP posterior at new locations.

    Parameters
    ----------
    model : dict
        Output of `gp_fit`.
    X_star : (m,d) array
    return_var : bool
        If True, also return predictive variance.
    include_nugget_in_variance : bool
        If True, add nugget (observation noise) to predictive variance.

    Returns
    -------
    dict with keys 'mean' and (optionally) 'variance', 'std'.
    """
    X = model["X"]
    Xs = np.asarray(X_star, dtype=float)
    Dxs = euclidean_distance_matrix(Xs, X)
    Ks = K.kernel_dispatch(model["kernel_name"], Dxs, model["params"])
    mu = Ks @ model["alpha"] + model["mean"]
    out = {"mean": mu}
    if return_var:
        L, low = model["L"], model["low"]
        v = solve_triangular(L, Ks.T, lower=True, check_finite=False)
        # k(x*, x*) is sigma2 (kernel value at distance 0) for stationary
        sigma2 = float(model["params"]["sigma2"])
        var = sigma2 - np.sum(v * v, axis=0)
        if include_nugget_in_variance:
            var = var + float(model["nugget"])
        var = np.maximum(var, 1e-10)
        out["variance"] = var
        out["std"] = np.sqrt(var)
    return out


# ---------------------------------------------------------------------------
# Negative log marginal likelihood for fixed kernel name
# ---------------------------------------------------------------------------


def neg_log_marginal_likelihood(theta_log: np.ndarray, X: np.ndarray,
                                y: np.ndarray, kernel_name: str,
                                extra_params: Optional[dict] = None) -> float:
    """NLML for a 3-parameter (sigma2, length_scale, nugget) GP given
    log-scaled hyperparameters.

    theta_log = [log sigma2, log length_scale, log nugget]
    """
    sigma2 = float(np.exp(theta_log[0]))
    ell = float(np.exp(theta_log[1]))
    nugget = float(np.exp(theta_log[2]))
    params = {"sigma2": sigma2, "length_scale": ell}
    if extra_params:
        params.update(extra_params)
    try:
        m = gp_fit(X, y, kernel_name, params, nugget=nugget,
                   mean=float(np.mean(y)))
        return -m["log_marginal_likelihood"]
    except np.linalg.LinAlgError:
        return 1e12


def fit_gp_mle(X: np.ndarray, y: np.ndarray, kernel_name: str,
               init_params: Optional[dict] = None,
               extra_params: Optional[dict] = None,
               bounds: Optional[Sequence[Tuple[float, float]]] = None,
               method: str = "L-BFGS-B",
               max_iter: int = 200) -> dict:
    """Optimise (sigma2, length_scale, nugget) by maximum marginal
    likelihood.

    Optimises in log space. Returns a dict with the fitted hyper-
    parameters, the final NLML and the converged GP model (so the
    caller can immediately call `gp_predict`).
    """
    X = np.asarray(X, dtype=float)
    y = np.asarray(y, dtype=float)
    if init_params is None:
        # heuristics: variance of y, half the median pairwise distance
        # (capped to avoid extremely small starting ell), small nugget
        Dmed = np.median(euclidean_distance_matrix(X[: min(len(X), 500)]))
        init_params = {
            "sigma2": float(np.var(y)),
            "length_scale": float(max(Dmed / 2.0, 0.1)),
            "nugget": float(max(np.var(y) * 0.05, 1e-3)),
        }
    theta0 = np.log([init_params["sigma2"], init_params["length_scale"],
                     init_params["nugget"]])
    if bounds is None:
        bounds = [(np.log(1e-4), np.log(1e6)),
                  (np.log(1e-3), np.log(1e3)),
                  (np.log(1e-6), np.log(1e3))]
    res = minimize(neg_log_marginal_likelihood, theta0,
                   args=(X, y, kernel_name, extra_params),
                   method=method, bounds=bounds,
                   options={"maxiter": max_iter})
    sigma2 = float(np.exp(res.x[0]))
    ell = float(np.exp(res.x[1]))
    nugget = float(np.exp(res.x[2]))
    params = {"sigma2": sigma2, "length_scale": ell}
    if extra_params:
        params.update(extra_params)
    model = gp_fit(X, y, kernel_name, params, nugget=nugget,
                   mean=float(np.mean(y)))
    return {
        "kernel_name": kernel_name,
        "params": params,
        "nugget": nugget,
        "neg_log_marginal_likelihood": float(res.fun),
        "log_marginal_likelihood": -float(res.fun),
        "n_iter": int(res.nit),
        "converged": bool(res.success),
        "model": model,
    }


# ---------------------------------------------------------------------------
# Leave-one-out predictive density
# ---------------------------------------------------------------------------


def loo_predictive(model: dict) -> dict:
    """Closed-form leave-one-out (LOO) predictive mean and variance for
    a fitted exact GP. Returns dict with 'mean', 'variance', 'std',
    'log_pred_density' (per-point) and the mean negative log predictive
    density (NLPD = mean of -log_pred_density).

    Uses the standard identities (Rasmussen & Williams 2006, Eq. 5.12):
        mu_-i = y_i - alpha_i / [K^-1]_ii
        var_-i = 1 / [K^-1]_ii
    """
    L, low = model["L"], model["low"]
    n = L.shape[0]
    Kinv = cho_solve((L, low), np.eye(n))
    diag_inv = np.diag(Kinv)
    alpha = model["alpha"]
    var = 1.0 / diag_inv
    mu = model["y_centred"] - alpha / diag_inv + model["mean"]
    y = model["y_centred"] + model["mean"]
    log_pred = -0.5 * np.log(2.0 * np.pi * var) - 0.5 * (y - mu) ** 2 / var
    return {
        "mean": mu,
        "variance": var,
        "std": np.sqrt(var),
        "log_pred_density": log_pred,
        "nlpd": float(-np.mean(log_pred)),
    }


# ---------------------------------------------------------------------------
# Local approximate GP — nearest-neighbour subset prediction
# ---------------------------------------------------------------------------


def local_gp_predict(X_train: np.ndarray, y_train: np.ndarray,
                     X_star: np.ndarray, kernel_name: str, params: dict,
                     nugget: float = 1e-3, n_neighbours: int = 50,
                     use_global_mean: bool = True,
                     batch_size: int = 256,
                     include_nugget_in_variance: bool = True,
                     verbose: bool = False) -> dict:
    """Local-approximate GP prediction (Gramacy 2016).

    For each test location, fit an exact GP on its `n_neighbours` closest
    training points and predict mean + variance. This recovers the simple
    nearest-neighbour version (`m0 = m`) of laGP. Distances are Euclidean
    in the input space — pre-scale your coordinates if anisotropy matters.

    Parameters
    ----------
    X_train : (n,d) array
    y_train : (n,) array
    X_star : (m,d) array
    kernel_name : str
    params : dict
        Kernel hyperparameters (must contain ``sigma2`` and
        ``length_scale``).
    nugget : float
        Observation noise variance.
    n_neighbours : int
        Subset size m (Gramacy 2016 recommends 30-100).
    use_global_mean : bool
        If True, subtract the mean of `y_train` before each local fit;
        otherwise subtract the local subset mean.
    batch_size : int
        Number of test points to process at a time (only affects memory).
    include_nugget_in_variance : bool
        If True (default), the returned ``variance`` includes the nugget
        observation-noise term sigma2_nug, matching the canonical
        reference-strategy convention used by this task package (so
        95% intervals are mean +/- 1.96 sqrt(var_local + sigma2_nug)).
        Pass ``False`` to obtain the local latent-process variance only
        (useful for diagnostics).
    verbose : bool
        Print a progress message every batch.

    Returns
    -------
    dict with keys 'mean', 'variance', 'std', 'n_neighbours'.
    """
    X_train = np.asarray(X_train, dtype=float)
    y_train = np.asarray(y_train, dtype=float)
    X_star = np.asarray(X_star, dtype=float)
    n_test = len(X_star)
    mu_out = np.empty(n_test)
    var_out = np.empty(n_test)
    global_mean = float(np.mean(y_train)) if use_global_mean else None

    for start in range(0, n_test, batch_size):
        end = min(start + batch_size, n_test)
        Xs_batch = X_star[start:end]
        # distance from each test point to all training points
        Db = euclidean_distance_matrix(Xs_batch, X_train)
        # nearest n_neighbours indices per test point
        if n_neighbours >= len(X_train):
            sel = np.tile(np.arange(len(X_train)), (len(Xs_batch), 1))
        else:
            sel = np.argpartition(Db, n_neighbours, axis=1)[:, :n_neighbours]
        for i, idx in enumerate(sel):
            Xi = X_train[idx]
            yi = y_train[idx]
            mean_i = global_mean if use_global_mean else float(np.mean(yi))
            try:
                m_local = gp_fit(Xi, yi, kernel_name, params,
                                 nugget=nugget, mean=mean_i)
                pred = gp_predict(m_local, Xs_batch[i:i + 1],
                                  return_var=True,
                                  include_nugget_in_variance=include_nugget_in_variance)
                mu_out[start + i] = float(pred["mean"][0])
                var_out[start + i] = float(pred["variance"][0])
            except np.linalg.LinAlgError:
                # extremely degenerate neighbourhood: fall back to mean
                mu_out[start + i] = mean_i
                fallback_var = float(params["sigma2"])
                if include_nugget_in_variance:
                    fallback_var = fallback_var + float(nugget)
                var_out[start + i] = fallback_var
        if verbose:
            print(f"local_gp_predict: {end}/{n_test}")
    return {"mean": mu_out, "variance": var_out,
            "std": np.sqrt(np.maximum(var_out, 1e-10)),
            "n_neighbours": int(n_neighbours)}


# ---------------------------------------------------------------------------
# Predictive scoring
# ---------------------------------------------------------------------------


def rmse(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Root-mean-square error."""
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    return float(np.sqrt(np.mean((y_true - y_pred) ** 2)))


def mae(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Mean absolute error."""
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    return float(np.mean(np.abs(y_true - y_pred)))


def crps_gaussian(y_true: np.ndarray, mu: np.ndarray,
                  sigma: np.ndarray) -> np.ndarray:
    """Continuous ranked probability score, vectorised, assuming a
    Gaussian predictive distribution (Gneiting & Raftery 2007).

    Returns per-point CRPS.
    """
    from scipy.stats import norm
    y_true = np.asarray(y_true, dtype=float)
    mu = np.asarray(mu, dtype=float)
    sigma = np.maximum(np.asarray(sigma, dtype=float), 1e-10)
    z = (y_true - mu) / sigma
    return sigma * (z * (2.0 * norm.cdf(z) - 1.0)
                    + 2.0 * norm.pdf(z) - 1.0 / np.sqrt(np.pi))


def mean_crps_gaussian(y_true, mu, sigma) -> float:
    """Mean CRPS over all points."""
    return float(np.mean(crps_gaussian(y_true, mu, sigma)))


def interval_score_gaussian(y_true: np.ndarray, mu: np.ndarray,
                            sigma: np.ndarray, alpha: float = 0.05) -> dict:
    """Gneiting & Raftery (2007) interval score for a (1-alpha) Gaussian
    predictive interval, plus the empirical coverage rate.

    Returns dict with 'mean_interval_score' and 'coverage'.
    """
    from scipy.stats import norm
    y_true = np.asarray(y_true, dtype=float)
    mu = np.asarray(mu, dtype=float)
    sigma = np.maximum(np.asarray(sigma, dtype=float), 1e-10)
    z = norm.ppf(1.0 - alpha / 2.0)
    L = mu - z * sigma
    U = mu + z * sigma
    width = U - L
    below = np.maximum(L - y_true, 0.0)
    above = np.maximum(y_true - U, 0.0)
    score = width + (2.0 / alpha) * (below + above)
    inside = (y_true >= L) & (y_true <= U)
    return {
        "mean_interval_score": float(np.mean(score)),
        "coverage": float(np.mean(inside)),
        "lower": L,
        "upper": U,
    }

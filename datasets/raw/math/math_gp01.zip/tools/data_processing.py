"""
Generic data-loading and array-shaping primitives for spatial Gaussian
process tasks. Pure-numpy / pandas helpers; no domain logic.
"""

from __future__ import annotations

import os
from typing import Optional, Sequence, Tuple

import numpy as np
import pandas as pd


def read_csv(file_path: str) -> pd.DataFrame:
    """Read a CSV file into a pandas DataFrame.

    Parameters
    ----------
    file_path : str
        Path to a CSV file with a header row.

    Returns
    -------
    pandas.DataFrame
    """
    return pd.read_csv(file_path)


def write_csv(df: pd.DataFrame, file_path: str) -> str:
    """Write a DataFrame to CSV (no row index).

    Auto-creates the parent directory if it does not exist (matching the
    auto-mkdir contract used by the plotting helpers), so callers can
    write directly to ``artifacts/predictions.csv`` etc. without an
    explicit ``os.makedirs`` step.

    Returns the path written.
    """
    parent = os.path.dirname(os.path.abspath(file_path))
    if parent:
        os.makedirs(parent, exist_ok=True)
    df.to_csv(file_path, index=False)
    return file_path


def split_train_test(df: pd.DataFrame,
                     coord_cols: Sequence[str],
                     observed_col: str,
                     truth_col: Optional[str] = None) -> dict:
    """Split a long-form spatial table into train/test arrays.

    Rows with `observed_col` not NaN form the training set. Rows where
    `observed_col` is NaN AND `truth_col` is not NaN form the test set.
    Rows where both are NaN are masked out (e.g. cloud-covered pixels
    with no ground truth).

    Parameters
    ----------
    df : pandas.DataFrame
    coord_cols : sequence of str
        Column names of the coordinates (e.g. ['lon','lat']).
    observed_col : str
        Column with the partially observed value (training labels).
    truth_col : str, optional
        Column with full ground-truth values used for held-out
        validation. If None, no test set is returned.

    Returns
    -------
    dict with keys
        'X_train', 'y_train', 'X_test', 'y_test', 'train_idx', 'test_idx'.
    """
    X_all = df[list(coord_cols)].to_numpy(dtype=float)
    y_obs = df[observed_col].to_numpy(dtype=float)
    train_mask = ~np.isnan(y_obs)
    out = {
        "X_train": X_all[train_mask],
        "y_train": y_obs[train_mask],
        "train_idx": np.where(train_mask)[0],
    }
    if truth_col is not None:
        y_true = df[truth_col].to_numpy(dtype=float)
        test_mask = np.isnan(y_obs) & ~np.isnan(y_true)
        out["X_test"] = X_all[test_mask]
        out["y_test"] = y_true[test_mask]
        out["test_idx"] = np.where(test_mask)[0]
    return out


def standardise(x: np.ndarray, mean: Optional[np.ndarray] = None,
                std: Optional[np.ndarray] = None) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Centre and scale an array along axis 0.

    If `mean`/`std` are given (e.g. computed on training data), apply
    them; otherwise compute from `x`.

    Returns (standardised_array, mean, std).
    """
    x = np.asarray(x, dtype=float)
    if mean is None:
        mean = x.mean(axis=0)
    if std is None:
        std = x.std(axis=0)
        std = np.where(std == 0.0, 1.0, std)
    return (x - mean) / std, np.asarray(mean), np.asarray(std)


def haversine_km(lon1, lat1, lon2, lat2) -> np.ndarray:
    """Great-circle distance in kilometres between (lon1,lat1) and
    (lon2,lat2). Inputs in degrees; arrays broadcast.

    Returns
    -------
    numpy.ndarray
        Distances in km, same shape as the broadcast.
    """
    R = 6371.0088
    lon1 = np.asarray(lon1, dtype=float) * np.pi / 180.0
    lat1 = np.asarray(lat1, dtype=float) * np.pi / 180.0
    lon2 = np.asarray(lon2, dtype=float) * np.pi / 180.0
    lat2 = np.asarray(lat2, dtype=float) * np.pi / 180.0
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = np.sin(dlat / 2.0) ** 2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon / 2.0) ** 2
    a = np.clip(a, 0.0, 1.0)
    return 2.0 * R * np.arcsin(np.sqrt(a))


def euclidean_distance_matrix(X: np.ndarray, Y: Optional[np.ndarray] = None) -> np.ndarray:
    """Pairwise Euclidean distance matrix.

    Parameters
    ----------
    X : (n,d) array
    Y : (m,d) array, optional
        If None, returns the (n,n) distance matrix of X with itself.

    Returns
    -------
    (n,m) numpy.ndarray
    """
    X = np.asarray(X, dtype=float)
    if Y is None:
        Y = X
    else:
        Y = np.asarray(Y, dtype=float)
    sx = np.sum(X * X, axis=1)
    sy = np.sum(Y * Y, axis=1)
    d2 = sx[:, None] + sy[None, :] - 2.0 * X @ Y.T
    np.maximum(d2, 0.0, out=d2)
    return np.sqrt(d2)


def random_subsample(X: np.ndarray, y: np.ndarray, n: int,
                     random_state: int = 0) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Random index subsample of (X,y).

    Returns (X_sub, y_sub, indices). If n >= len(X) returns the full set.
    """
    n_total = len(X)
    if n >= n_total:
        idx = np.arange(n_total)
    else:
        rng = np.random.default_rng(random_state)
        idx = rng.choice(n_total, size=n, replace=False)
    return X[idx], y[idx], idx


def fit_linear_trend(X: np.ndarray, y: np.ndarray) -> dict:
    """Least-squares fit of a linear trend y ~ 1 + X[:,0] + X[:,1] + ...

    Useful for removing a low-frequency mean before fitting a stationary
    GP to the residuals (Heaton et al. 2019 use a 1 + lon + lat trend
    on the satellite data).

    Returns
    -------
    dict with 'beta' (coefficients) and 'design_columns' (list of
    column names in order: ['intercept', 'x0', 'x1', ...]).
    """
    X = np.asarray(X, dtype=float)
    y = np.asarray(y, dtype=float)
    A = np.column_stack([np.ones(len(X)), X])
    beta, *_ = np.linalg.lstsq(A, y, rcond=None)
    cols = ["intercept"] + [f"x{i}" for i in range(X.shape[1])]
    return {"beta": beta, "design_columns": cols}


def apply_linear_trend(X: np.ndarray, beta: np.ndarray) -> np.ndarray:
    """Predict the linear trend at locations X using coefficients
    `beta` from `fit_linear_trend`.
    """
    X = np.asarray(X, dtype=float)
    A = np.column_stack([np.ones(len(X)), X])
    return A @ np.asarray(beta, dtype=float)


def grid_to_image(lon: np.ndarray, lat: np.ndarray, value: np.ndarray,
                  tol: Optional[float] = None) -> dict:
    """Reshape a long-form (lon,lat,value) table into a 2-D image array.

    The lon/lat axes are inferred from the unique values present; rows are
    assigned to the *nearest* axis bin within ``tol`` (default: half the
    minimum non-zero axis step) to avoid floating-point misalignment when
    the input grid is not perfectly regular. Pixels with no row contributing
    within tolerance stay NaN.

    Returns
    -------
    dict with keys
        'image' : (n_lat, n_lon) ndarray with NaN for missing pixels
        'lon_axis' : (n_lon,) ascending longitudes
        'lat_axis' : (n_lat,) ascending latitudes
    """
    lon = np.asarray(lon, dtype=float)
    lat = np.asarray(lat, dtype=float)
    value = np.asarray(value, dtype=float)
    lon_axis = np.unique(lon)
    lat_axis = np.unique(lat)
    n_lon = len(lon_axis)
    n_lat = len(lat_axis)
    img = np.full((n_lat, n_lon), np.nan, dtype=float)

    def _nearest_idx(axis: np.ndarray, values: np.ndarray,
                     tolerance: float) -> np.ndarray:
        # snap each value to the closest axis bin; reject (idx=-1) if
        # the distance exceeds ``tolerance`` (so caller can skip).
        pos = np.searchsorted(axis, values)
        pos = np.clip(pos, 1, len(axis) - 1)
        left = axis[pos - 1]
        right = axis[pos]
        choose_left = np.abs(values - left) <= np.abs(values - right)
        idx = np.where(choose_left, pos - 1, pos)
        snapped = axis[idx]
        bad = np.abs(values - snapped) > tolerance
        idx = idx.copy()
        idx[bad] = -1
        return idx

    if tol is None:
        if n_lon > 1:
            lon_step = float(np.min(np.diff(lon_axis)))
        else:
            lon_step = 1.0
        if n_lat > 1:
            lat_step = float(np.min(np.diff(lat_axis)))
        else:
            lat_step = 1.0
        tol_lon = 0.5 * lon_step
        tol_lat = 0.5 * lat_step
    else:
        tol_lon = tol_lat = float(tol)

    lon_idx = _nearest_idx(lon_axis, lon, tol_lon)
    lat_idx = _nearest_idx(lat_axis, lat, tol_lat)
    keep = (lon_idx >= 0) & (lat_idx >= 0)
    img[lat_idx[keep], lon_idx[keep]] = value[keep]
    return {"image": img, "lon_axis": lon_axis, "lat_axis": lat_axis}

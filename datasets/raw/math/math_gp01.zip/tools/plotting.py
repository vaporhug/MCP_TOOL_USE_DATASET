"""
Plotting helpers for spatial Gaussian-process analyses.

Each function writes a PNG and returns a dict {'path': out_path}.
No interactive display is performed.
"""

from __future__ import annotations

from typing import Optional, Sequence
import os

import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize


def _ensure_parent_dir(out_path: str) -> None:
    """Create the parent directory of ``out_path`` if it does not exist."""
    parent = os.path.dirname(os.path.abspath(out_path))
    if parent:
        os.makedirs(parent, exist_ok=True)


def plot_spatial_image(image: np.ndarray, lon_axis: np.ndarray,
                       lat_axis: np.ndarray, title: str, out_path: str,
                       cmap: str = "turbo", vmin: Optional[float] = None,
                       vmax: Optional[float] = None,
                       cbar_label: str = "value",
                       figsize=(7, 5)) -> dict:
    """Render a 2-D spatial image with a colour bar.

    `image` is (n_lat, n_lon) and assumed to follow the convention of
    `data_processing.grid_to_image` (lat ascending bottom-to-top).
    """
    fig, ax = plt.subplots(figsize=figsize)
    extent = [float(lon_axis.min()), float(lon_axis.max()),
              float(lat_axis.min()), float(lat_axis.max())]
    im = ax.imshow(image, origin="lower", extent=extent,
                   aspect="auto", cmap=cmap,
                   norm=Normalize(vmin=vmin, vmax=vmax))
    ax.set_xlabel("Longitude (deg)")
    ax.set_ylabel("Latitude (deg)")
    ax.set_title(title)
    cbar = fig.colorbar(im, ax=ax, fraction=0.045, pad=0.04)
    cbar.set_label(cbar_label)
    fig.tight_layout()
    _ensure_parent_dir(out_path)
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return {"path": out_path}


def plot_train_test_panels(X_train, y_train, X_test, y_test,
                           title: str, out_path: str,
                           cmap: str = "turbo",
                           figsize=(11, 5)) -> dict:
    """Two-panel scatter of training observations and test ground truth.
    """
    fig, axes = plt.subplots(1, 2, figsize=figsize, sharex=True, sharey=True)
    vmin = float(min(np.nanmin(y_train), np.nanmin(y_test)))
    vmax = float(max(np.nanmax(y_train), np.nanmax(y_test)))
    sc0 = axes[0].scatter(X_train[:, 0], X_train[:, 1], c=y_train, s=2,
                          cmap=cmap, vmin=vmin, vmax=vmax)
    axes[0].set_title(f"Training set (n={len(y_train)})")
    sc1 = axes[1].scatter(X_test[:, 0], X_test[:, 1], c=y_test, s=2,
                          cmap=cmap, vmin=vmin, vmax=vmax)
    axes[1].set_title(f"Held-out test (n={len(y_test)})")
    for ax in axes:
        ax.set_xlabel("Longitude (deg)")
        ax.set_ylabel("Latitude (deg)")
    fig.colorbar(sc1, ax=axes, fraction=0.04, pad=0.02, label="value")
    fig.suptitle(title)
    _ensure_parent_dir(out_path)
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return {"path": out_path}


def plot_variogram(empirical: dict, fitted_models: Optional[dict] = None,
                   title: str = "Empirical variogram",
                   out_path: str = "variogram.png",
                   figsize=(7, 5)) -> dict:
    """Plot the empirical variogram and overlay one or more parametric
    fits.

    `fitted_models` is an optional dict {label: model_dict_from_
    fit_variogram_model}. The function reuses
    `variogram.predict_variogram` to evaluate them.
    """
    from .variogram import predict_variogram

    fig, ax = plt.subplots(figsize=figsize)
    ax.plot(empirical["distance"], empirical["gamma"], "o", color="black",
            label="empirical", markersize=5)
    if fitted_models:
        d_grid = np.linspace(np.nanmin(empirical["distance"]),
                             np.nanmax(empirical["distance"]), 200)
        for label, m in fitted_models.items():
            ax.plot(d_grid, predict_variogram(m, d_grid), "-", lw=1.5,
                    label=label)
    ax.set_xlabel("distance")
    ax.set_ylabel("semivariance gamma(h)")
    ax.set_title(title)
    ax.legend()
    ax.grid(alpha=0.3)
    fig.tight_layout()
    _ensure_parent_dir(out_path)
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return {"path": out_path}


def plot_predicted_vs_observed(y_true, y_pred, sigma=None,
                               title: str = "Predicted vs observed",
                               out_path: str = "pred_vs_obs.png",
                               figsize=(6, 6)) -> dict:
    """Scatter of predicted vs observed values with optional 1-sigma
    error bars and a y=x reference line.
    """
    fig, ax = plt.subplots(figsize=figsize)
    if sigma is not None:
        ax.errorbar(y_true, y_pred, yerr=sigma, fmt="o", ms=2,
                    elinewidth=0.4, alpha=0.4, color="steelblue")
    else:
        ax.scatter(y_true, y_pred, s=2, alpha=0.4, color="steelblue")
    lo = min(np.min(y_true), np.min(y_pred))
    hi = max(np.max(y_true), np.max(y_pred))
    ax.plot([lo, hi], [lo, hi], "r--", lw=1.2, label="y = x")
    ax.set_xlabel("observed")
    ax.set_ylabel("predicted")
    ax.set_title(title)
    ax.legend()
    ax.grid(alpha=0.3)
    fig.tight_layout()
    _ensure_parent_dir(out_path)
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return {"path": out_path}


def plot_residual_map(X, residuals, title: str, out_path: str,
                      cmap: str = "RdBu_r", figsize=(8, 5),
                      symmetric: bool = True) -> dict:
    """Spatial scatter of residuals (e.g. test_y - predicted_mean)."""
    fig, ax = plt.subplots(figsize=figsize)
    if symmetric:
        v = float(np.percentile(np.abs(residuals), 99))
        vmin, vmax = -v, v
    else:
        vmin, vmax = float(residuals.min()), float(residuals.max())
    sc = ax.scatter(X[:, 0], X[:, 1], c=residuals, s=2, cmap=cmap,
                    vmin=vmin, vmax=vmax)
    ax.set_xlabel("Longitude (deg)")
    ax.set_ylabel("Latitude (deg)")
    ax.set_title(title)
    fig.colorbar(sc, ax=ax, fraction=0.045, pad=0.04, label="residual")
    fig.tight_layout()
    _ensure_parent_dir(out_path)
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return {"path": out_path}


def plot_kernel_comparison(rows: list,
                           metrics: Sequence[str] = ("MAE", "RMSE", "CRPS"),
                           title: str = "Kernel comparison",
                           out_path: str = "kernel_compare.png",
                           figsize=(9, 4.5)) -> dict:
    """Bar chart comparing several kernels on a set of scoring metrics.

    `rows` is a list of dicts; each dict must contain a 'kernel' key
    plus the metric values. The function annotates each bar with its
    numeric metric value.
    """
    df = pd.DataFrame(rows)
    n_metrics = len(metrics)
    fig, axes = plt.subplots(1, n_metrics, figsize=figsize, sharey=False)
    if n_metrics == 1:
        axes = [axes]
    for ax, met in zip(axes, metrics):
        bars = ax.bar(df["kernel"], df[met], color="steelblue",
                      edgecolor="black")
        ax.set_title(met)
        ax.set_ylabel(met)
        ax.tick_params(axis="x", rotation=30)
        ax.grid(alpha=0.3, axis="y")
        for b, v in zip(bars, df[met]):
            ax.text(b.get_x() + b.get_width() / 2.0, v, f"{v:.2f}",
                    ha="center", va="bottom", fontsize=8)
    fig.suptitle(title)
    fig.tight_layout()
    _ensure_parent_dir(out_path)
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return {"path": out_path}


def plot_predictive_image(image: np.ndarray, sd_image: np.ndarray,
                          lon_axis: np.ndarray, lat_axis: np.ndarray,
                          truth_image: Optional[np.ndarray] = None,
                          title: str = "GP predictive surface",
                          out_path: str = "pred_surface.png",
                          figsize=(13, 4.4)) -> dict:
    """Three-panel display of (a) predictive mean surface, (b)
    predictive standard deviation, optionally (c) ground truth.
    """
    extent = [float(lon_axis.min()), float(lon_axis.max()),
              float(lat_axis.min()), float(lat_axis.max())]
    n_panels = 3 if truth_image is not None else 2
    fig, axes = plt.subplots(1, n_panels, figsize=figsize, sharex=True,
                             sharey=True)
    vmin = float(np.nanmin(image))
    vmax = float(np.nanmax(image))
    if truth_image is not None:
        vmin = min(vmin, float(np.nanmin(truth_image)))
        vmax = max(vmax, float(np.nanmax(truth_image)))
    im0 = axes[0].imshow(image, origin="lower", extent=extent,
                         aspect="auto", cmap="turbo",
                         norm=Normalize(vmin=vmin, vmax=vmax))
    axes[0].set_title("Predictive mean")
    fig.colorbar(im0, ax=axes[0], fraction=0.045, pad=0.04)
    im1 = axes[1].imshow(sd_image, origin="lower", extent=extent,
                         aspect="auto", cmap="magma")
    axes[1].set_title("Predictive sd")
    fig.colorbar(im1, ax=axes[1], fraction=0.045, pad=0.04)
    if truth_image is not None:
        im2 = axes[2].imshow(truth_image, origin="lower", extent=extent,
                             aspect="auto", cmap="turbo",
                             norm=Normalize(vmin=vmin, vmax=vmax))
        axes[2].set_title("Ground truth")
        fig.colorbar(im2, ax=axes[2], fraction=0.045, pad=0.04)
    for ax in axes:
        ax.set_xlabel("Longitude (deg)")
        ax.set_ylabel("Latitude (deg)")
    fig.suptitle(title)
    fig.tight_layout()
    _ensure_parent_dir(out_path)
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return {"path": out_path}


def plot_metric_table(rows: list, columns: Sequence[str],
                      title: str, out_path: str,
                      figsize=(8.5, 0.45)) -> dict:
    """Render a small metric table as a PNG.

    `rows` is a list of dicts; columns picked in order.
    """
    df = pd.DataFrame(rows)[list(columns)]
    n = len(df)
    fig, ax = plt.subplots(figsize=(figsize[0], max(2.0, figsize[1] * (n + 1.2))))
    ax.axis("off")
    cell_text = [[f"{v:.3f}" if isinstance(v, float) else str(v) for v in row]
                 for row in df.values]
    tbl = ax.table(cellText=cell_text, colLabels=list(columns),
                   loc="center", cellLoc="center")
    tbl.auto_set_font_size(False)
    tbl.set_fontsize(9)
    tbl.scale(1.0, 1.4)
    ax.set_title(title)
    fig.tight_layout()
    _ensure_parent_dir(out_path)
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return {"path": out_path}

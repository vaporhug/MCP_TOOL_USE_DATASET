"""
Empirical variogram estimation and parametric (exponential, Matern,
spherical, Gaussian) variogram model fitting.

Uses pure numpy + scipy.optimize for the curve fits. Returns python
primitives so the agent can read the output directly.
"""

from __future__ import annotations

from typing import Optional, Sequence, Tuple

import numpy as np
from scipy.optimize import least_squares

from .data_processing import euclidean_distance_matrix


def empirical_variogram(X: np.ndarray, y: np.ndarray,
                        n_bins: int = 25,
                        max_distance: Optional[float] = None,
                        max_pairs: int = 200_000,
                        random_state: int = 0) -> dict:
    """Compute Matheron's classical empirical variogram.

    For all (or a random subsample of) point pairs (i,j) with i<j,
    compute (y_i - y_j)^2 / 2 and bin by Euclidean distance. Returns
    bin centres, mean semivariance, pair counts.

    Parameters
    ----------
    X : (n,d) array of locations
    y : (n,) array of observations
    n_bins : int
        Number of equal-width distance bins.
    max_distance : float, optional
        Upper truncation; defaults to half the maximum pairwise
        distance in a 1000-point random subsample.
    max_pairs : int
        Upper limit on the number of pairs evaluated (random subsample).
    random_state : int

    Returns
    -------
    dict with keys 'distance', 'gamma', 'count'.
    """
    X = np.asarray(X, dtype=float)
    y = np.asarray(y, dtype=float)
    n = len(X)
    rng = np.random.default_rng(random_state)
    if max_distance is None:
        sub = rng.choice(n, size=min(n, 1000), replace=False)
        Dsub = euclidean_distance_matrix(X[sub])
        max_distance = float(np.max(Dsub) / 2.0)

    # sample pairs
    n_total_pairs = n * (n - 1) // 2
    if n_total_pairs <= max_pairs:
        ii, jj = np.triu_indices(n, k=1)
    else:
        ii = rng.integers(0, n, size=max_pairs)
        jj = rng.integers(0, n, size=max_pairs)
        keep = ii != jj
        ii = ii[keep]
        jj = jj[keep]
        # Enforce i < j so each unordered pair is sampled at most once and
        # the empirical Matheron estimator does not double-count (i,j) / (j,i).
        swap = ii > jj
        ii_new = np.where(swap, jj, ii)
        jj_new = np.where(swap, ii, jj)
        # Deduplicate identical (i,j) pairs that may have arisen by chance.
        pair_keys = ii_new.astype(np.int64) * n + jj_new.astype(np.int64)
        _, unique_idx = np.unique(pair_keys, return_index=True)
        ii = ii_new[unique_idx]
        jj = jj_new[unique_idx]
    diffs = X[ii] - X[jj]
    d = np.sqrt(np.sum(diffs * diffs, axis=1))
    gamma_pair = 0.5 * (y[ii] - y[jj]) ** 2

    bins = np.linspace(0.0, max_distance, n_bins + 1)
    bin_idx = np.digitize(d, bins) - 1
    valid = (bin_idx >= 0) & (bin_idx < n_bins)
    bin_idx = bin_idx[valid]
    d = d[valid]
    gamma_pair = gamma_pair[valid]

    count = np.bincount(bin_idx, minlength=n_bins)
    sumg = np.bincount(bin_idx, weights=gamma_pair, minlength=n_bins)
    sumd = np.bincount(bin_idx, weights=d, minlength=n_bins)
    with np.errstate(invalid="ignore", divide="ignore"):
        gamma_bin = np.where(count > 0, sumg / count, np.nan)
        dist_bin = np.where(count > 0, sumd / count, np.nan)
    return {"distance": dist_bin, "gamma": gamma_bin, "count": count.astype(int)}


# ---------------------------------------------------------------------------
# Parametric variogram models
# ---------------------------------------------------------------------------


def variogram_exponential(d: np.ndarray, sill: float, ell: float,
                          nugget: float = 0.0) -> np.ndarray:
    """Exponential variogram: nugget + sill * (1 - exp(-d/ell))."""
    return float(nugget) + float(sill) * (1.0 - np.exp(-d / float(ell)))


def variogram_gaussian(d: np.ndarray, sill: float, ell: float,
                       nugget: float = 0.0) -> np.ndarray:
    """Squared-exponential (Gaussian) variogram.

    Parameterised so that the implied covariance form
    C(d) = sill * exp(-0.5 * (d/ell)^2) matches
    ``kernel_squared_exponential`` in tools/kernels.py (which uses
    the 0.5 factor in its squared distance). This keeps the
    variogram length-scale ``ell`` directly interpretable as the
    Gaussian-kernel length-scale ``length_scale`` used by the
    GP fitter, so a Matheron variogram fit and a kernel MLE can be
    compared on the same axis.

    gamma(d) = nugget + sill * (1 - exp(-0.5 * (d/ell)^2))
    """
    return (float(nugget)
            + float(sill) * (1.0 - np.exp(-0.5 * (d / float(ell)) ** 2)))


def variogram_spherical(d: np.ndarray, sill: float, range_: float,
                        nugget: float = 0.0) -> np.ndarray:
    """Spherical variogram with finite range."""
    d = np.asarray(d, dtype=float)
    out = np.where(
        d < range_,
        float(nugget) + float(sill) * (1.5 * d / range_
                                       - 0.5 * (d / range_) ** 3),
        float(nugget) + float(sill),
    )
    return out


def variogram_matern_32(d: np.ndarray, sill: float, ell: float,
                        nugget: float = 0.0) -> np.ndarray:
    """Matern 3/2 variogram."""
    import math
    s3r = math.sqrt(3.0) * d / float(ell)
    return float(nugget) + float(sill) * (1.0 - (1.0 + s3r) * np.exp(-s3r))


def variogram_matern_52(d: np.ndarray, sill: float, ell: float,
                        nugget: float = 0.0) -> np.ndarray:
    """Matern 5/2 variogram.

    gamma(d) = nugget + sill * (1 - (1 + sqrt(5)d/ell + 5d^2/(3 ell^2)) * exp(-sqrt(5)d/ell))

    Convention used uniformly by every variogram_* helper in this module: the
    nugget term is added at EVERY lag including d=0, so gamma(0) = nugget here
    (NOT zero) and the curve is shifted up by `nugget` at all distances. This
    matches `fit_variogram_model` which inverts the same parametric form, and
    matches the geostatistics convention used by `kernels.add_nugget` on the
    covariance side (kernel + nugget*I diagonal). The parametric term itself
    is continuous at d=0 (collapses to 0); the discontinuity comes entirely
    from the nugget constant.
    """
    import math
    d_arr = np.asarray(d, dtype=float)
    s5r = math.sqrt(5.0) * d_arr / float(ell)
    quad = 5.0 * d_arr * d_arr / (3.0 * float(ell) * float(ell))
    return float(nugget) + float(sill) * (1.0 - (1.0 + s5r + quad) * np.exp(-s5r))


def fit_variogram_model(distance: np.ndarray, gamma: np.ndarray,
                        model: str = "exponential",
                        weights: Optional[np.ndarray] = None,
                        init: Optional[Sequence[float]] = None) -> dict:
    """Weighted nonlinear least-squares fit of a variogram model to the
    empirical (distance, gamma) curve.

    Parameters
    ----------
    distance, gamma : 1-D arrays
    model : str
        One of 'exponential', 'gaussian', 'spherical', 'matern32', 'matern52'.
    weights : 1-D array, optional
        Per-bin weights (e.g. pair counts). Defaults to 1.
    init : sequence of 3 floats, optional
        Starting [sill, range/length_scale, nugget].

    Returns
    -------
    dict with 'sill', 'length_scale' (or 'range'), 'nugget',
    'cost', 'success'.
    """
    distance = np.asarray(distance, dtype=float)
    gamma = np.asarray(gamma, dtype=float)
    valid = ~np.isnan(distance) & ~np.isnan(gamma)
    d = distance[valid]
    g = gamma[valid]
    if weights is not None:
        w = np.sqrt(np.asarray(weights, dtype=float)[valid])
    else:
        w = np.ones_like(d)
    if init is None:
        init = [float(np.nanmax(g)) * 0.9, float(np.nanmedian(d)), float(np.nanmin(g))]

    def residuals(theta):
        sill, ell, nug = theta
        if sill <= 0 or ell <= 0 or nug < 0:
            return 1e6 * np.ones_like(d)
        if model == "exponential":
            pred = variogram_exponential(d, sill, ell, nug)
        elif model == "gaussian":
            pred = variogram_gaussian(d, sill, ell, nug)
        elif model == "spherical":
            pred = variogram_spherical(d, sill, ell, nug)
        elif model == "matern32":
            pred = variogram_matern_32(d, sill, ell, nug)
        elif model == "matern52":
            pred = variogram_matern_52(d, sill, ell, nug)
        else:
            raise ValueError(f"unknown variogram model {model}")
        return w * (g - pred)

    res = least_squares(residuals, init, bounds=(
        [1e-6, 1e-6, 0.0], [1e6, 1e6, 1e6]))
    sill, ell, nug = res.x
    label = "range" if model == "spherical" else "length_scale"
    return {
        "model": model,
        "sill": float(sill),
        label: float(ell),
        "nugget": float(nug),
        "cost": float(res.cost),
        "success": bool(res.success),
    }


def predict_variogram(model_dict: dict, distance: np.ndarray) -> np.ndarray:
    """Evaluate a fitted parametric variogram on new distances."""
    model = model_dict["model"]
    sill = model_dict["sill"]
    nug = model_dict["nugget"]
    if model == "spherical":
        return variogram_spherical(distance, sill, model_dict["range"], nug)
    ell = model_dict["length_scale"]
    if model == "exponential":
        return variogram_exponential(distance, sill, ell, nug)
    if model == "gaussian":
        return variogram_gaussian(distance, sill, ell, nug)
    if model == "matern32":
        return variogram_matern_32(distance, sill, ell, nug)
    if model == "matern52":
        return variogram_matern_52(distance, sill, ell, nug)
    raise ValueError(f"unknown variogram model {model}")

"""
External database retrieval stubs.

These helpers wrap citations and metadata lookups for the analysis.
None of them perform a real network call within the task environment;
they exist so the agent has a uniform place to record external lookups.
"""

from __future__ import annotations

from typing import Optional


_CITATIONS = {
    "heaton2019": {
        "authors": "Heaton, M. J. et al.",
        "year": 2019,
        "title": ("A Case Study Competition Among Methods for Analyzing "
                  "Large Spatial Data"),
        "journal": "Journal of Agricultural, Biological and Environmental Statistics",
        "volume": 24,
        "pages": "398-425",
        "doi": "10.1007/s13253-018-00348-w",
    },
    "lindgren2015": {
        "authors": "Lindgren, F., Rue, H.",
        "year": 2015,
        "title": "Bayesian Spatial Modelling with R-INLA",
        "journal": "Journal of Statistical Software",
        "volume": 63,
        "issue": 19,
    },
    "gramacy2016": {
        "authors": "Gramacy, R. B.",
        "year": 2016,
        "title": ("laGP: Large-Scale Spatial Modeling via Local Approximate "
                  "Gaussian Processes in R"),
        "journal": "Journal of Statistical Software",
        "volume": 72,
        "issue": 1,
    },
    "gramacy2007": {
        "authors": "Gramacy, R. B.",
        "year": 2007,
        "title": ("tgp: An R Package for Bayesian Nonstationary, "
                  "Semiparametric Nonlinear Regression and Design by "
                  "Treed Gaussian Process Models"),
        "journal": "Journal of Statistical Software",
        "volume": 19,
        "issue": 9,
        "pages": "1-46",
    },
}


def lookup_citation(key: str) -> dict:
    """Return the metadata dict for a known citation key, or raise."""
    if key not in _CITATIONS:
        raise KeyError(
            f"unknown citation key '{key}'. Known keys: "
            f"{sorted(_CITATIONS.keys())}"
        )
    return dict(_CITATIONS[key])


def list_known_datasets() -> dict:
    """Return a dictionary describing the input datasets that ship with
    this task. Values include the source URL and the expected row count.
    """
    return {
        "modis_lst_observed.csv": {
            "source": "https://github.com/finnlindgren/heatoncomparison (file Data/AllSatelliteTemps.RData)",
            "rows": 150_000,
            "grid_shape": (300, 500),
            "columns": ("lon", "lat", "mask_temp_c"),
            "training_column": "mask_temp_c",
            "n_train_not_nan": 105_569,
            "n_mask_nan_total": 44_431,
            "n_scoring_test": 42_740,
            "n_unrecoverable": 1_691,
            "held_out_truth_file": "modis_lst_test_gold.csv",
            "held_out_truth_column": "true_temp_c",
            "prediction_coordinates_file": "modis_lst_test_coordinates.csv",
        },
        "modis_lst_test_coordinates.csv": {
            "rows": 42_740,
            "columns": ("test_id", "lon", "lat"),
            "join_key": ("test_id",),
            "description": (
                "test_id (0..42739, canonical integer join key), lon, lat of the 42,740 MODIS scoring test pixels (no labels). "
                "The agent MUST echo test_id into agent_predictions.csv so the grader joins on (test_id, kernel) without lon/lat floating-point equality. "
                "Use as the prediction-time pixel set; the gold file is reserved for evaluation."
            ),
        },
        "modis_lst_test_gold.csv": {
            "rows": 42_740,
            "columns": ("test_id", "lon", "lat", "true_temp_c"),
            "join_key": ("test_id",),
            "description": (
                "test_id matches the integer key in modis_lst_test_coordinates.csv (same row order, same 0..42739 values). "
                "Held-out ground truth for the 42,740 MODIS scoring test pixels (mask_temp_c=NaN AND truth available). "
                "Excludes the 1,691 unrecoverable cloud-corrupted pixels. Use ONLY for evaluation."
            ),
        },
        "sim_gp_observed.csv": {
            "source": "https://github.com/finnlindgren/heatoncomparison (file Data/AllSimulatedTemps.RData)",
            "rows": 150_000,
            "grid_shape": (300, 500),
            "columns": ("lon", "lat", "mask_temp"),
            "training_column": "mask_temp",
            "n_train_not_nan": 105_569,
            "n_test_held_out": 44_431,
            "held_out_truth_file": "sim_gp_test_gold.csv",
            "held_out_truth_column": "true_temp",
        },
        "sim_gp_test_gold.csv": {
            "rows": 44_431,
            "columns": ("test_id", "lon", "lat", "true_temp"),
            "join_key": ("test_id",),
            "description": (
                "test_id (0..44430, canonical integer join key for schema parity with the MODIS gold file), lon, lat, true_temp. "
                "Held-out ground truth for the 44,431 simulated GP test pixels (mask_temp=NaN). "
                "All simulated held-out pixels have truth (no unrecoverable subset). Use ONLY for evaluation."
            ),
        },
    }


def list_competition_methods() -> list:
    """Return the list of method names that participated in the
    case-study competition documented by the main reference paper.

    The actual numerical performance of each method on the satellite
    data is reported in the paper (Tables 2 and 3); the agent should
    consult the PDF directly when cross-checking.
    """
    return [
        "FRK", "Gapfill", "LatticeKrig", "LAGP", "Metakriging", "MRA",
        "NNGP", "Partition", "Pred. Proc.", "SPDE", "Tapering",
        "Periodic Embedding",
    ]

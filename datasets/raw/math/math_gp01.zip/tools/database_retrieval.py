"""
External database retrieval stubs.

These helpers wrap citations and metadata lookups for the analysis.
None of them perform a real network call within the task environment;
they exist so the agent has a uniform place to record external lookups.
"""

from __future__ import annotations

from typing import Optional


_CITATIONS = {
    "heaton2019": {
        "authors": "Heaton, M. J. et al.",
        "year": 2019,
        "title": ("A Case Study Competition Among Methods for Analyzing "
                  "Large Spatial Data"),
        "journal": "Journal of Agricultural, Biological and Environmental Statistics",
        "volume": 24,
        "pages": "398-425",
        "doi": "10.1007/s13253-018-00348-w",
    },
    "lindgren2015": {
        "authors": "Lindgren, F., Rue, H.",
        "year": 2015,
        "title": "Bayesian Spatial Modelling with R-INLA",
        "journal": "Journal of Statistical Software",
        "volume": 63,
        "issue": 19,
    },
    "gramacy2016": {
        "authors": "Gramacy, R. B.",
        "year": 2016,
        "title": ("laGP: Large-Scale Spatial Modeling via Local Approximate "
                  "Gaussian Processes in R"),
        "journal": "Journal of Statistical Software",
        "volume": 72,
        "issue": 1,
    },
}


def lookup_citation(key: str) -> dict:
    """Return the metadata dict for a known citation key, or raise."""
    if key not in _CITATIONS:
        raise KeyError(
            f"unknown citation key '{key}'. Known keys: "
            f"{sorted(_CITATIONS.keys())}"
        )
    return dict(_CITATIONS[key])


def list_known_datasets() -> dict:
    """Return a dictionary describing the input datasets that ship with
    this task. Values include the source URL and the expected row count.
    """
    return {
        "modis_lst_full_grid.csv": {
            "source": "https://github.com/finnlindgren/heatoncomparison (file Data/AllSatelliteTemps.RData)",
            "rows": 150_000,
            "grid_shape": (300, 500),
            "value_column": "true_temp_c",
            "training_column": "mask_temp_c",
        },
        "sim_gp_full_grid.csv": {
            "source": "https://github.com/finnlindgren/heatoncomparison (file Data/AllSimulatedTemps.RData)",
            "rows": 150_000,
            "grid_shape": (300, 500),
            "value_column": "true_temp",
            "training_column": "mask_temp",
        },
    }


def list_competition_methods() -> list:
    """Return the list of method names that participated in the
    case-study competition documented by the main reference paper.

    The actual numerical performance of each method on the satellite
    data is reported in the paper (Tables 2 and 3); the agent should
    consult the PDF directly when cross-checking.
    """
    return [
        "FRK", "Gapfill", "LatticeKrig", "LAGP", "Metakriging", "MRA",
        "NNGP", "Partition", "Pred. Proc.", "SPDE", "Tapering",
        "Periodic Embedding",
    ]

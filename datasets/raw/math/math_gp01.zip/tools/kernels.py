"""
Stationary covariance kernels used in Gaussian process regression.

All kernels take a distance matrix `D` (any non-negative numpy array)
and a hyperparameter dict and return a covariance matrix of the same
shape. Hyperparameter conventions:

    sigma2 : signal variance (marginal variance of the latent process)
    length_scale : length scale ell, in the same units as the distance
        matrix
    nu : Matern smoothness (only for matern kernel)

Use a pure-numpy implementation so the agent does not need scikit-learn
or GPy.
"""

from __future__ import annotations

import math
from typing import Optional

import numpy as np


def _safe_div(d: np.ndarray, ell: float) -> np.ndarray:
    """Compute d / ell guarding against ell <= 0."""
    if ell <= 0.0:
        raise ValueError(f"length_scale must be positive, got {ell}")
    return d / ell


def kernel_squared_exponential(D: np.ndarray, sigma2: float,
                               length_scale: float) -> np.ndarray:
    """Squared-exponential (Gaussian / RBF) kernel.

    k(d) = sigma2 * exp(-0.5 * (d / ell)^2)
    """
    r = _safe_div(D, length_scale)
    return float(sigma2) * np.exp(-0.5 * r * r)


def kernel_exponential(D: np.ndarray, sigma2: float,
                       length_scale: float) -> np.ndarray:
    """Exponential (Matern nu=1/2) kernel.

    k(d) = sigma2 * exp(-d / ell)

    This is the covariance specified in the Heaton et al. (2019)
    competition for both simulated and real datasets.
    """
    r = _safe_div(D, length_scale)
    return float(sigma2) * np.exp(-r)


def kernel_matern_32(D: np.ndarray, sigma2: float,
                     length_scale: float) -> np.ndarray:
    """Matern 3/2 kernel.

    k(d) = sigma2 * (1 + sqrt(3) d / ell) * exp(-sqrt(3) d / ell)
    """
    r = _safe_div(D, length_scale)
    s3r = math.sqrt(3.0) * r
    return float(sigma2) * (1.0 + s3r) * np.exp(-s3r)


def kernel_matern_52(D: np.ndarray, sigma2: float,
                     length_scale: float) -> np.ndarray:
    """Matern 5/2 kernel.

    k(d) = sigma2 * (1 + sqrt(5) d / ell + 5 d^2 / (3 ell^2)) *
           exp(-sqrt(5) d / ell)
    """
    r = _safe_div(D, length_scale)
    s5r = math.sqrt(5.0) * r
    poly = 1.0 + s5r + (5.0 / 3.0) * r * r
    return float(sigma2) * poly * np.exp(-s5r)


def kernel_matern_general(D: np.ndarray, sigma2: float,
                          length_scale: float, nu: float) -> np.ndarray:
    """General Matern kernel for arbitrary smoothness nu > 0.

    Falls back to specialised closed forms for nu = 0.5, 1.5, 2.5.
    """
    if abs(nu - 0.5) < 1e-9:
        return kernel_exponential(D, sigma2, length_scale)
    if abs(nu - 1.5) < 1e-9:
        return kernel_matern_32(D, sigma2, length_scale)
    if abs(nu - 2.5) < 1e-9:
        return kernel_matern_52(D, sigma2, length_scale)
    from scipy.special import gamma, kv  # local import to keep top clean
    r = _safe_div(D, length_scale)
    r = np.where(r < 1e-12, 1e-12, r)
    coef = (2.0 ** (1.0 - nu)) / gamma(nu)
    arg = math.sqrt(2.0 * nu) * r
    return float(sigma2) * coef * (arg ** nu) * kv(nu, arg)


def kernel_periodic(D: np.ndarray, sigma2: float,
                    length_scale: float, period: float) -> np.ndarray:
    """Periodic (MacKay) kernel.

    k(d) = sigma2 * exp(-2 sin^2(pi d / period) / ell^2)
    """
    if period <= 0.0:
        raise ValueError("period must be positive")
    s = np.sin(np.pi * D / period) / length_scale
    return float(sigma2) * np.exp(-2.0 * s * s)


def add_nugget(K: np.ndarray, nugget: float) -> np.ndarray:
    """Return K + nugget * I (square matrices only). Modifies a copy."""
    K2 = K.copy()
    n = K2.shape[0]
    if K2.shape[0] != K2.shape[1]:
        raise ValueError("add_nugget expects a square matrix")
    K2[np.arange(n), np.arange(n)] += float(nugget)
    return K2


def kernel_dispatch(name: str, D: np.ndarray, params: dict) -> np.ndarray:
    """Resolve a kernel by name.

    Supported names: 'rbf' / 'squared_exponential' / 'se',
    'exponential' / 'matern12', 'matern32', 'matern52',
    'periodic', 'matern' (uses params['nu']).
    """
    name = name.lower()
    sigma2 = float(params["sigma2"])
    ell = float(params["length_scale"])
    if name in ("rbf", "se", "squared_exponential"):
        return kernel_squared_exponential(D, sigma2, ell)
    if name in ("exponential", "matern12", "exp"):
        return kernel_exponential(D, sigma2, ell)
    if name == "matern32":
        return kernel_matern_32(D, sigma2, ell)
    if name == "matern52":
        return kernel_matern_52(D, sigma2, ell)
    if name == "matern":
        return kernel_matern_general(D, sigma2, ell, float(params["nu"]))
    if name == "periodic":
        return kernel_periodic(D, sigma2, ell, float(params["period"]))
    raise ValueError(f"unknown kernel: {name}")

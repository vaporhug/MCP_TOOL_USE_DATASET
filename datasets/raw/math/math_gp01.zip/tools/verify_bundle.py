#!/usr/bin/env python3
"""verify_bundle.py — confirm the math_gp01 zip contents match task_content.json.

Run this once at unzip time. The script asserts that:

  - every input CSV listed in EXPECTED_INPUT_CSVS is present with the
    expected row count and header
  - every ground-truth CSV listed in EXPECTED_GROUND_TRUTH_CSVS is present
    with the expected row count and header (these files exist in the zip
    but are hidden from the agent at runtime via type=ground_truth)
  - every reference artifact listed in EXPECTED_REFERENCE_ARTIFACTS is
    present (PNGs and CSVs)
  - every input_data path declared in task_content.json is physically
    present in the bundle
  - every ground_truth entry in task_content.json input_data appears in
    EXPECTED_GROUND_TRUTH_CSVS (catches unexpected ground-truth additions)
  - the artifacts/ directory contains no agent_-prefixed files (those
    are produced by the agent at solve time, not bundled)

What this script DOES NOT check: it does not walk answer.answer_items[*].path
(those are agent-produced runtime outputs, not bundled artifacts), and it
does not parse PACKAGING_NOTES.md for free-text claims.

Exit code 0 = all checks pass; non-zero = one or more verifications failed.

Usage:
    python tools/verify_bundle.py path/to/math_gp01.zip
or, on an already-extracted bundle:
    cd <bundle_root> && python tools/verify_bundle.py .
"""

from __future__ import annotations

import csv
import json
import os
import sys
import zipfile
from pathlib import Path


EXPECTED_INPUT_CSVS = {
    "input_data/data/modis_lst_observed.csv":
        {"rows": 150000, "header": ["lon", "lat", "mask_temp_c"]},
    "input_data/data/modis_lst_sample20.csv":
        {"rows": 20,     "header": ["lon", "lat", "mask_temp_c"]},
    "input_data/data/modis_lst_test_coordinates.csv":
        {"rows": 42740,  "header": ["test_id", "lon", "lat"]},
    "input_data/data/sim_gp_observed.csv":
        {"rows": 150000, "header": ["lon", "lat", "mask_temp"]},
}
EXPECTED_GROUND_TRUTH_CSVS = {
    "input_data/data/modis_lst_test_gold.csv":
        {"rows": 42740, "header": ["test_id", "lon", "lat", "true_temp_c"]},
    "input_data/data/sim_gp_test_gold.csv":
        {"rows": 44431, "header": ["test_id", "lon", "lat", "true_temp"]},
}
EXPECTED_REFERENCE_ARTIFACTS = [
    "artifacts/reference_kernel_metrics.csv",
    "artifacts/reference_metric_comparison.csv",
    "artifacts/reference_summary.txt",
    "artifacts/reference_Fig1_train_test_panels.png",
    "artifacts/reference_Fig2_variogram_fits.png",
    "artifacts/reference_Fig3_kernel_compare.png",
    "artifacts/reference_Fig4_residual_map.png",
    "artifacts/reference_Fig5_predictive_surface.png",
    "artifacts/reference_Fig6_metric_table.png",
]


def _check_csv(path: Path, expected_rows: int, expected_header: list[str]) -> list[str]:
    errs: list[str] = []
    if not path.is_file():
        return [f"MISSING file: {path}"]
    with open(path, newline="") as f:
        rdr = csv.reader(f)
        header = next(rdr)
        if header != expected_header:
            errs.append(f"{path}: header {header} != expected {expected_header}")
        n = sum(1 for _ in rdr)
        if n != expected_rows:
            errs.append(f"{path}: {n} data rows != expected {expected_rows}")
    return errs


def main(root_or_zip: str) -> int:
    p = Path(root_or_zip)
    if p.suffix == ".zip" and p.is_file():
        extract = Path("/tmp/math_gp01_verify")
        extract.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(p) as zf:
            zf.extractall(extract)
        root = extract
    else:
        root = p

    errs: list[str] = []

    # 1. Input CSVs
    for rel, spec in EXPECTED_INPUT_CSVS.items():
        errs += _check_csv(root / rel, spec["rows"], spec["header"])

    # 2. Ground-truth CSVs (hidden from agent at runtime, but must exist in zip)
    for rel, spec in EXPECTED_GROUND_TRUTH_CSVS.items():
        errs += _check_csv(root / rel, spec["rows"], spec["header"])

    # 3. Reference artifacts
    for rel in EXPECTED_REFERENCE_ARTIFACTS:
        if not (root / rel).is_file():
            errs.append(f"MISSING file: {rel}")

    # 4. Cross-check against task_content.json input_data declarations
    tc_path = root / "task_content" / "task_content.json"
    if tc_path.is_file():
        j = json.load(open(tc_path))
        for item in j.get("input_data", []):
            ipath = root / item["path"]
            if not ipath.is_file():
                errs.append(f"task_content declares missing input: {item['path']}")
            if item.get("type") == "ground_truth" and item["path"] not in EXPECTED_GROUND_TRUTH_CSVS:
                errs.append(f"unexpected ground_truth: {item['path']}")
    else:
        errs.append("MISSING task_content/task_content.json")

    # 5. artifacts/ namespace separation: every reference_* file lives in artifacts/
    art = root / "artifacts"
    if art.is_dir():
        for f in art.iterdir():
            if f.name.startswith("agent_"):
                errs.append(f"agent_-prefixed file SHOULD NOT be in the bundled "
                            f"artifacts/ (the agent writes those at runtime): {f}")

    if errs:
        print("verify_bundle: FAIL")
        for e in errs:
            print(" -", e)
        return 1
    print("verify_bundle: OK — all 4 input CSVs, 2 ground-truth CSVs, and 9 reference artifacts present with expected row counts and headers; ground_truth files declared via type=ground_truth (hidden from agent at runtime); no agent_-prefixed leakage in artifacts/.")
    return 0


if __name__ == "__main__":
    target = sys.argv[1] if len(sys.argv) > 1 else "."
    raise SystemExit(main(target))

"""Domain primitives for the GP regression / kriging task package."""

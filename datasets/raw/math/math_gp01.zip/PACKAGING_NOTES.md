# math_gp01 — packaging + grader confirmation notes

This file collects the maintainer-side and grader-side confirmations that
review automation has previously asked for. Each item is closed by an
explicit statement in this bundle's task_content.json or by a verification
artifact below.

## 1. Bundle file inventory

All input CSVs and reference artifacts are physically present in the zip.
Verify with:

```
unzip -l datasets/raw/math/math_gp01.zip
```

For a text-readable schema of every file (byte size, row count, header)
see `input_data/data/_bundle_manifest.txt`.

Expected file counts:

| File                                            | Bytes      | Rows       | Schema                                |
| ----------------------------------------------- | ---------- | ---------- | ------------------------------------- |
| input_data/data/modis_lst_observed.csv          |  3,793,265 |    150,000 | lon, lat, mask_temp_c                 |
| input_data/data/modis_lst_sample20.csv          |        491 |         20 | lon, lat, mask_temp_c                 |
| input_data/data/modis_lst_test_coordinates.csv  |  1,132,506 |     42,740 | test_id, lon, lat                     |
| input_data/data/modis_lst_test_gold.csv         |  1,388,958 |     42,740 | test_id, lon, lat, true_temp_c        |
| input_data/data/sim_gp_observed.csv             |  4,203,724 |    150,000 | lon, lat, mask_temp                   |
| input_data/data/sim_gp_test_gold.csv            |  1,617,089 |     44,431 | test_id, lon, lat, true_temp          |
| artifacts/reference_kernel_metrics.csv          |        803 |          5 | kernel, scope, MAE, RMSE, CRPS, ...   |
| artifacts/reference_metric_comparison.csv       |        740 |          5 | (alternate column layout)             |
| artifacts/reference_summary.txt                 |        796 | (1-line)   | (free text)                           |
| artifacts/reference_Fig*.png                    | (binary)   |  -         | 6 grader-side reference plots         |

## 2. Runtime visibility filter (agent vs grader)

The agent's mounted file view is filtered by the `type` field in
task_content.json's `input_data` blocks, NOT by physical zip path. The
project schema requires every bundled file to live under `input_data/` or
`artifacts/` regardless of role.

- `type` ∈ {`sequence_data`, `parameter_table`, `reference`} → AGENT-VISIBLE
- `type` = `ground_truth` → HIDDEN from agent (grader-only)
- `answer` field of task_content.json → HIDDEN from agent
- `artifacts/` files whose name begins with `reference_` → HIDDEN from agent
- `artifacts/` files whose name begins with `agent_` → emitted BY the agent
  into the agent's working directory; collected by the grader for scoring

Grader operators: please confirm that the harness implements this `type`
field filter rather than mounting every file under `input_data/` to the
agent.

## 3. Grader scoring contract

- `artifacts/agent_predictions.csv` MUST exist and contain exactly
  **170,960 rows** = 42,740 test pixels × 4 kernels (exponential,
  matern32, matern52, rbf). `test_id` values must cover the complete set
  0..42739 for every kernel. Missing rows or kernels → structural fail.

- The grader computes the per-kernel MAE / RMSE / CRPS / INT / CVG by
  joining `agent_predictions.csv` on `(test_id, kernel)` with the FULL
  `modis_lst_test_gold.csv` (42,740 rows). The 8,000-row subset rows in
  `reference_kernel_metrics.csv` (for matern32/matern52/rbf) are
  **sanity-check provenance only** and do NOT define the grading
  contract; the grader recomputes from the full 42,740-row hidden gold.

- No exact paper-Table-3 numeric value is a hard pass/fail threshold;
  qualitative kernel ordering + structural completeness are graded.

## 4. Reference-artifact provenance

`reference_kernel_metrics.csv` is a mixed-provenance sanity-check sweep —
the `scope` column tags each row explicitly:

- `full_42740_test` — exponential row, computed over the full 42,740-pixel
  hidden gold; this is the canonical scope.
- `8000_test_subset` — matern32 / matern52 / rbf rows, computed over an
  8,000-row test subset (regenerated faster).

The qualitative kernel ordering and hyperparameter size-class statements
in the answer are stable under the 8,000-subset choice; the grader still
scores against the full 42,740-pixel hidden gold at grade time.

## 5. Automated verification

Run `python tools/verify_bundle.py path/to/math_gp01.zip` (or `python
tools/verify_bundle.py .` on an already-extracted bundle) to confirm:

- every declared CSV / PNG / JSON is physically present at its declared path
- every CSV has the expected row count and header
- every ground_truth file is declared with type=ground_truth (and is
  therefore hidden from the agent's mounted view at runtime per §2)
- the artifacts/ directory contains no agent_-prefixed files (those are
  produced by the agent at solve time, not bundled)

Exit code 0 = all checks pass. The bundle in this commit has been verified
locally with this script.

"""Tabular policy iteration for the ICU sepsis MDP.

Standard policy iteration on the empirical transition tensor T(s'|s,a) and
reward R(s'). Yields the data-driven optimal policy that the off-policy
evaluation routines then compare against the clinician (behaviour) policy.
"""

from __future__ import annotations

from typing import Tuple

import numpy as np


def _terminal_mask(n_states: int, terminal_states: tuple | list | None = None) -> np.ndarray:
    mask = np.zeros(n_states, dtype=bool)
    if terminal_states is not None:
        for s in terminal_states:
            if 0 <= int(s) < n_states:
                mask[int(s)] = True
    return mask


def policy_evaluation(
    T: np.ndarray,
    reward: np.ndarray,
    policy: np.ndarray,
    gamma: float = 1.0,
    tol: float = 1e-6,
    max_iter: int = 1000,
    terminal_states: tuple | list | None = None,
) -> np.ndarray:
    """Iterative policy evaluation: solve V^pi for a stochastic policy.

    Bellman equation:
        V(s) = sum_a pi(a|s) sum_{s'} T(s'|s,a) [ R(s') + gamma V(s') ]

    Parameters
    ----------
    T : np.ndarray, shape (S, A, S)
    reward : np.ndarray, shape (S,)
        Reward upon entering each state.
    policy : np.ndarray, shape (S, A)
    gamma : float
        Discount factor. The default is 1.0 so values are undiscounted terminal-survival probabilities for this task.
    tol : float
        Convergence tolerance on max |V_new - V|.
    max_iter : int
        Hard cap on iterations.

    Returns
    -------
    V : np.ndarray, shape (S,)
    """
    S, A, _ = T.shape
    terminal = _terminal_mask(S, terminal_states)
    V = np.zeros(S)
    expected_r = T @ reward  # (S, A)
    for _ in range(max_iter):
        # V_next: (S,A) = sum_s' T(s,a,s') * V(s')
        future_V = V.copy()
        future_V[terminal] = 0.0
        V_next = T @ future_V
        Q = expected_r + gamma * V_next
        V_new = (policy * Q).sum(axis=1)
        V_new[terminal] = reward[terminal]
        if np.max(np.abs(V_new - V)) < tol:
            V = V_new
            break
        V = V_new
    return V


def policy_improvement(
    T: np.ndarray,
    reward: np.ndarray,
    V: np.ndarray,
    gamma: float = 1.0,
    admissible_mask: np.ndarray = None,
    terminal_states: tuple | list | None = None,
) -> np.ndarray:
    """Greedy policy improvement step.

    Parameters
    ----------
    T : np.ndarray, shape (S, A, S)
    reward : np.ndarray, shape (S,)
    V : np.ndarray, shape (S,)
    gamma : float
    admissible_mask : np.ndarray, shape (S, A), optional
        Boolean mask of admissible (historically observed) actions per state
        (from ``data_loading.load_admissible_actions(...)['mask']``). When
        supplied, inadmissible actions are excluded from the argmax so the
        learned policy never recommends an action that was never observed
        in that state.

    Returns
    -------
    pi : np.ndarray, shape (S, A)
        Deterministic one-hot policy that is greedy w.r.t. Q (restricted to
        admissible actions if a mask is given).
    """
    S = T.shape[0]
    terminal = _terminal_mask(S, terminal_states)
    future_V = V.copy()
    future_V[terminal] = 0.0
    Q = T @ reward + gamma * (T @ future_V)  # (S, A)
    S, A = Q.shape
    if admissible_mask is not None:
        Qm = np.where(admissible_mask.astype(bool), Q, -np.inf)
    else:
        Qm = Q
    pi = np.zeros((S, A))
    for s in range(S):
        if terminal[s]:
            pi[s, 0] = 1.0
            continue
        if not np.isfinite(Qm[s]).any():
            raise ValueError(f"state {s} has no admissible non-terminal actions")
        pi[s, int(np.argmax(Qm[s]))] = 1.0
    return pi


def policy_iteration(
    T: np.ndarray,
    reward: np.ndarray,
    gamma: float = 1.0,
    tol: float = 1e-6,
    max_outer: int = 50,
    max_eval: int = 200,
    admissible_mask: np.ndarray = None,
    terminal_states: tuple | list | None = None,
) -> Tuple[np.ndarray, np.ndarray]:
    """Run full policy iteration to convergence.

    Parameters
    ----------
    T : np.ndarray, shape (S, A, S)
    reward : np.ndarray, shape (S,)
    gamma : float
    tol : float
        Inner evaluation tolerance and outer convergence tolerance.
    max_outer : int
        Max outer iterations.
    max_eval : int
        Max iterations of inner policy evaluation.
    admissible_mask : np.ndarray, shape (S, A), optional
        If supplied, every improvement step is restricted to the
        admissible (historically observed) actions for each state, so the
        learned optimal policy only ever recommends observed clinical
        actions. Pass ``load_admissible_actions(...)['mask']``.

    Returns
    -------
    V : np.ndarray, shape (S,)
    pi : np.ndarray, shape (S, A)
        Deterministic optimal policy as one-hot rows.
    """
    S, A, _ = T.shape
    pi = np.full((S, A), 1.0 / A)
    terminal = _terminal_mask(S, terminal_states)
    if terminal.any():
        pi[terminal] = 0.0
        pi[terminal, 0] = 1.0
    V = np.zeros(S)
    for _ in range(max_outer):
        V = policy_evaluation(T, reward, pi, gamma=gamma, tol=tol,
                              max_iter=max_eval, terminal_states=terminal_states)
        pi_new = policy_improvement(T, reward, V, gamma=gamma,
                                    admissible_mask=admissible_mask,
                                    terminal_states=terminal_states)
        if np.allclose(pi_new, pi):
            pi = pi_new
            break
        pi = pi_new
    return V, pi


def value_iteration(
    T: np.ndarray,
    reward: np.ndarray,
    gamma: float = 1.0,
    tol: float = 1e-6,
    max_iter: int = 2000,
    terminal_states: tuple | list | None = None,
) -> Tuple[np.ndarray, np.ndarray]:
    """Run value iteration. Useful as a sanity-check for policy iteration.

    Parameters
    ----------
    T, reward, gamma, tol, max_iter : standard MDP solver inputs.

    Returns
    -------
    V : np.ndarray, shape (S,)
    pi : np.ndarray, shape (S, A) deterministic.
    """
    S, A, _ = T.shape
    terminal = _terminal_mask(S, terminal_states)
    V = np.zeros(S)
    expected_r = T @ reward
    for _ in range(max_iter):
        future_V = V.copy()
        future_V[terminal] = 0.0
        Q = expected_r + gamma * (T @ future_V)
        V_new = Q.max(axis=1)
        V_new[terminal] = reward[terminal]
        if np.max(np.abs(V_new - V)) < tol:
            V = V_new
            break
        V = V_new
    future_V = V.copy()
    future_V[terminal] = 0.0
    Q = expected_r + gamma * (T @ future_V)
    pi = np.zeros((S, A))
    pi[np.arange(S), np.argmax(Q, axis=1)] = 1.0
    return V, pi


def average_policy_value(V: np.ndarray, p0: np.ndarray) -> float:
    """Expected return under initial state distribution.

    Parameters
    ----------
    V : np.ndarray, shape (S,)
    p0 : np.ndarray, shape (S,)

    Returns
    -------
    float
    """
    return float(np.dot(p0, V))

"""Plotting helpers for the AI-Clinician-style sepsis bandit task.

All functions return the path of the produced PNG so they can be wired
into the artifacts/ folder of the task.
"""

from __future__ import annotations

import os
from typing import Dict, List, Optional, Tuple

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def _ensure_parent(path: str) -> None:
    parent = os.path.dirname(os.path.abspath(path))
    if parent:
        os.makedirs(parent, exist_ok=True)


def plot_cumulative_regret(
    runs: Dict[str, np.ndarray], output_path: str, title: str = "Cumulative regret"
) -> Dict[str, str]:
    """Plot cumulative regret curves for several bandit algorithms.

    Parameters
    ----------
    runs : dict of name -> regret array
        Each array is shape (T,), the cumulative regret series.
    output_path : str
        Where to write the PNG.
    title : str

    Returns
    -------
    dict with key ``path``.
    """
    _ensure_parent(output_path)
    fig, ax = plt.subplots(figsize=(7, 5))
    for name, regret in runs.items():
        ax.plot(np.arange(1, len(regret) + 1), regret, label=name, lw=1.6)
    ax.set_xlabel("Round t")
    ax.set_ylabel("Cumulative regret")
    ax.set_title(title)
    ax.legend(loc="upper left", fontsize=9)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path}


def plot_action_distribution_grids(
    grids: Dict[str, np.ndarray], output_path: str
) -> Dict[str, str]:
    """Side-by-side 5x5 heatmaps of action probabilities.

    Parameters
    ----------
    grids : dict of name -> (5,5) array
        Action distribution per policy.
    output_path : str

    Returns
    -------
    dict with key ``path``.
    """
    _ensure_parent(output_path)
    n = len(grids)
    fig, axes = plt.subplots(1, n, figsize=(4.5 * n, 4))
    if n == 1:
        axes = [axes]
    vmax = max(g.max() for g in grids.values())
    for ax, (name, g) in zip(axes, grids.items()):
        im = ax.imshow(g, cmap="viridis", vmin=0.0, vmax=vmax, origin="lower")
        ax.set_xticks(range(5))
        ax.set_yticks(range(5))
        ax.set_xticklabels(["0", "1", "2", "3", "4"])
        ax.set_yticklabels(["0", "1", "2", "3", "4"])
        ax.set_xlabel("Vasopressor bin")
        ax.set_ylabel("IV-fluid bin")
        ax.set_title(name)
        for i in range(5):
            for j in range(5):
                ax.text(
                    j,
                    i,
                    f"{g[i, j]:.2f}",
                    ha="center",
                    va="center",
                    color="white" if g[i, j] < 0.5 * vmax else "black",
                    fontsize=8,
                )
        fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path}


def plot_ope_comparison(
    estimates: Dict[str, Tuple[float, float, float]],
    output_path: str,
    reference_value: Optional[float] = None,
    title: str = "Off-policy value estimates",
) -> Dict[str, str]:
    """Bar plot of (point, lower, upper) OPE estimates per policy/estimator.

    Parameters
    ----------
    estimates : dict of label -> (point, lower, upper)
    output_path : str
    reference_value : float or None
        Optional horizontal reference (e.g. behaviour policy MC value).
    title : str

    Returns
    -------
    dict with key ``path``.
    """
    _ensure_parent(output_path)
    labels = list(estimates.keys())
    points = np.array([estimates[k][0] for k in labels])
    lowers = np.array([estimates[k][1] for k in labels])
    uppers = np.array([estimates[k][2] for k in labels])
    err = np.vstack([points - lowers, uppers - points])
    fig, ax = plt.subplots(figsize=(max(7, 1.2 * len(labels)), 5))
    xs = np.arange(len(labels))
    bars = ax.bar(xs, points, yerr=err, capsize=4, color="steelblue", edgecolor="black")
    if reference_value is not None:
        ax.axhline(reference_value, color="firebrick", ls="--", lw=1.5, label=f"behaviour MC = {reference_value:.3f}")
        ax.legend(fontsize=9)
    ax.set_xticks(xs)
    ax.set_xticklabels(labels, rotation=20, ha="right")
    ax.set_ylabel("Estimated policy value")
    ax.set_title(title)
    ax.grid(alpha=0.3, axis="y")
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path}


def plot_mortality_vs_dose_excess(
    iv_bin_centers: np.ndarray,
    iv_mortality: np.ndarray,
    vp_bin_centers: np.ndarray,
    vp_mortality: np.ndarray,
    output_path: str,
) -> Dict[str, str]:
    """Two-panel mortality versus dose excess curves (IV and vasopressor).

    Two-panel plot: IV-fluid excess vs mortality and vasopressor excess
    vs mortality (one panel each).

    Parameters
    ----------
    iv_bin_centers, iv_mortality, vp_bin_centers, vp_mortality : np.ndarray
    output_path : str

    Returns
    -------
    dict with key ``path``.
    """
    _ensure_parent(output_path)
    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    for ax, x, y, label in [
        (axes[0], iv_bin_centers, iv_mortality, "IV fluids"),
        (axes[1], vp_bin_centers, vp_mortality, "Vasopressor"),
    ]:
        mask = ~np.isnan(y)
        ax.plot(x[mask], y[mask], marker="o", color="navy", lw=1.8)
        ax.axvline(0.0, color="grey", ls="--", lw=1.0)
        ax.set_xlabel("Mean dose excess (clinician - AI), bin units")
        ax.set_ylabel("Mortality")
        ax.set_title(label)
        ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path}


def plot_bootstrap_distribution(
    samples_a: np.ndarray,
    samples_b: np.ndarray,
    label_a: str,
    label_b: str,
    output_path: str,
    title: str = "Bootstrap value distribution",
) -> Dict[str, str]:
    """Two-policy histogram of bootstrap policy-value samples.

    Parameters
    ----------
    samples_a, samples_b : np.ndarray
    label_a, label_b : str
    output_path : str
    title : str

    Returns
    -------
    dict with key ``path``.
    """
    _ensure_parent(output_path)
    fig, ax = plt.subplots(figsize=(7, 4.5))
    bins = np.linspace(
        min(samples_a.min(), samples_b.min()),
        max(samples_a.max(), samples_b.max()),
        40,
    )
    ax.hist(samples_a, bins=bins, alpha=0.6, label=label_a, color="steelblue")
    ax.hist(samples_b, bins=bins, alpha=0.6, label=label_b, color="firebrick")
    ax.set_xlabel("Policy value (probability of survival)")
    ax.set_ylabel("Bootstrap count")
    ax.set_title(title)
    ax.legend(fontsize=9)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path}

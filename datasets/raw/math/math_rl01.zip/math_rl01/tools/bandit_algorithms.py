"""Online bandit algorithms run on the ICU sepsis logged stream.

Each algorithm consumes a stream of contexts (state indices and/or feature
vectors) and an oracle reward function, sequentially picks an action,
observes a reward, and updates internal state. They return per-step
selected-action and observed-reward sequences which are then aggregated
into cumulative reward and regret curves.

The algorithms implemented:
    - epsilon-greedy (tabular per-state)
    - UCB1 (tabular per-state)
    - Thompson Sampling with Beta posterior (tabular per-state)
    - LinUCB disjoint (contextual / linear)

All four take the same data-generating loop interface so they can be
benchmarked head-to-head.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, List, Optional

import numpy as np


@dataclass
class BanditRunResult:
    """Container for a bandit run's per-step traces."""

    selected_actions: np.ndarray
    rewards: np.ndarray
    cumulative_reward: np.ndarray
    name: str

    def total_reward(self) -> float:
        return float(self.rewards.sum())


def _ensure_rng(seed: Optional[int]) -> np.random.Generator:
    return np.random.default_rng(seed)


def epsilon_greedy(
    contexts: np.ndarray,
    reward_oracle: Callable[[int, int], float],
    n_actions: int,
    n_states: int,
    epsilon: float = 0.1,
    seed: int = 0,
) -> BanditRunResult:
    """Tabular per-state epsilon-greedy bandit.

    Maintains a Q-table Q[s,a] = mean reward and a count table N[s,a].
    With probability ``epsilon`` picks uniformly at random; otherwise the
    argmax of Q.

    Parameters
    ----------
    contexts : np.ndarray, shape (T,)
        Sequence of state indices observed at each round.
    reward_oracle : callable
        ``reward_oracle(state, action) -> float`` returning the (stochastic)
        reward observed for that arm.
    n_actions, n_states : int
    epsilon : float
        Exploration probability.
    seed : int

    Returns
    -------
    BanditRunResult
    """
    rng = _ensure_rng(seed)
    Q = np.zeros((n_states, n_actions))
    N = np.zeros((n_states, n_actions), dtype=int)
    T = len(contexts)
    sel = np.empty(T, dtype=int)
    rew = np.empty(T, dtype=float)
    for t in range(T):
        s = int(contexts[t])
        if rng.random() < epsilon:
            a = int(rng.integers(n_actions))
        else:
            a = int(np.argmax(Q[s]))
        r = float(reward_oracle(s, a))
        N[s, a] += 1
        Q[s, a] += (r - Q[s, a]) / N[s, a]
        sel[t] = a
        rew[t] = r
    return BanditRunResult(sel, rew, np.cumsum(rew), name="epsilon_greedy")


def ucb1(
    contexts: np.ndarray,
    reward_oracle: Callable[[int, int], float],
    n_actions: int,
    n_states: int,
    c: float = 1.4,
    seed: int = 0,
) -> BanditRunResult:
    """Tabular per-state UCB1 bandit.

    Selects ``argmax_a Q[s,a] + c * sqrt(log(t_s) / N[s,a])`` where ``t_s``
    is the number of times state s has been seen.

    Parameters
    ----------
    contexts : np.ndarray, shape (T,)
    reward_oracle : callable
    n_actions, n_states : int
    c : float
        Exploration coefficient.
    seed : int

    Returns
    -------
    BanditRunResult
    """
    rng = _ensure_rng(seed)
    Q = np.zeros((n_states, n_actions))
    N = np.zeros((n_states, n_actions), dtype=int)
    Ns = np.zeros(n_states, dtype=int)
    T = len(contexts)
    sel = np.empty(T, dtype=int)
    rew = np.empty(T, dtype=float)
    for t in range(T):
        s = int(contexts[t])
        Ns[s] += 1
        # Force trying each arm at least once per state
        if (N[s] == 0).any():
            a = int(rng.choice(np.where(N[s] == 0)[0]))
        else:
            ucb = Q[s] + c * np.sqrt(np.log(max(Ns[s], 2)) / N[s])
            a = int(np.argmax(ucb))
        r = float(reward_oracle(s, a))
        N[s, a] += 1
        Q[s, a] += (r - Q[s, a]) / N[s, a]
        sel[t] = a
        rew[t] = r
    return BanditRunResult(sel, rew, np.cumsum(rew), name="ucb1")


def thompson_sampling_beta(
    contexts: np.ndarray,
    reward_oracle: Callable[[int, int], float],
    n_actions: int,
    n_states: int,
    alpha_prior: float = 1.0,
    beta_prior: float = 1.0,
    seed: int = 0,
) -> BanditRunResult:
    """Tabular Thompson Sampling with Beta(alpha,beta) posterior.

    Suitable for the ICU-sepsis MDP because the terminal reward is binary
    (survival = 1, death = 0). At each step samples theta_a ~ Beta and
    picks argmax.

    Parameters
    ----------
    contexts : np.ndarray, shape (T,)
    reward_oracle : callable
    n_actions, n_states : int
    alpha_prior, beta_prior : float
        Beta prior parameters.
    seed : int

    Returns
    -------
    BanditRunResult
    """
    rng = _ensure_rng(seed)
    alpha = np.full((n_states, n_actions), alpha_prior)
    beta = np.full((n_states, n_actions), beta_prior)
    T = len(contexts)
    sel = np.empty(T, dtype=int)
    rew = np.empty(T, dtype=float)
    for t in range(T):
        s = int(contexts[t])
        samples = rng.beta(alpha[s], beta[s])
        a = int(np.argmax(samples))
        r = float(reward_oracle(s, a))
        # Clip to [0,1] if reward is not strictly Bernoulli
        r_clipped = max(0.0, min(1.0, r))
        alpha[s, a] += r_clipped
        beta[s, a] += 1.0 - r_clipped
        sel[t] = a
        rew[t] = r
    return BanditRunResult(sel, rew, np.cumsum(rew), name="thompson_sampling")


def linucb_disjoint(
    contexts: np.ndarray,
    feature_lookup: np.ndarray,
    reward_oracle: Callable[[int, int], float],
    n_actions: int,
    alpha: float = 1.0,
    seed: int = 0,
) -> BanditRunResult:
    """Disjoint LinUCB contextual bandit (Li et al. 2010).

    Each arm a maintains its own ridge regression on features x_s with
    A_a = I + sum x x^T and b_a = sum r * x. UCB score is
    x^T theta_a + alpha * sqrt(x^T A_a^-1 x).

    Parameters
    ----------
    contexts : np.ndarray, shape (T,)
        State indices used to look up the feature vector.
    feature_lookup : np.ndarray, shape (n_states, d)
        Feature matrix indexed by state.
    reward_oracle : callable
    n_actions : int
    alpha : float
        UCB exploration parameter.
    seed : int

    Returns
    -------
    BanditRunResult
    """
    rng = _ensure_rng(seed)
    d = feature_lookup.shape[1]
    A = np.stack([np.eye(d) for _ in range(n_actions)])  # (A, d, d)
    b = np.zeros((n_actions, d))
    T_steps = len(contexts)
    sel = np.empty(T_steps, dtype=int)
    rew = np.empty(T_steps, dtype=float)
    for t in range(T_steps):
        s = int(contexts[t])
        x = feature_lookup[s]
        ucbs = np.empty(n_actions)
        for a in range(n_actions):
            A_inv = np.linalg.inv(A[a])
            theta = A_inv @ b[a]
            ucbs[a] = x @ theta + alpha * np.sqrt(x @ A_inv @ x)
        a = int(np.argmax(ucbs))
        # Random tie break with rng to avoid systematic bias
        if (ucbs == ucbs[a]).sum() > 1:
            a = int(rng.choice(np.where(ucbs == ucbs[a])[0]))
        r = float(reward_oracle(s, a))
        A[a] += np.outer(x, x)
        b[a] += r * x
        sel[t] = a
        rew[t] = r
    return BanditRunResult(sel, rew, np.cumsum(rew), name="linucb")


def cumulative_regret(rewards_alg: np.ndarray, rewards_optimal: np.ndarray) -> np.ndarray:
    """Per-step cumulative regret = cum(opt) - cum(alg).

    Parameters
    ----------
    rewards_alg : np.ndarray, shape (T,)
        Rewards earned by the algorithm.
    rewards_optimal : np.ndarray, shape (T,)
        Rewards the oracle-best arm would have earned at the same contexts.

    Returns
    -------
    regret : np.ndarray, shape (T,)
        Non-decreasing cumulative regret.
    """
    return np.cumsum(rewards_optimal - rewards_alg)


def best_action_per_state(reward_table: np.ndarray) -> np.ndarray:
    """Return the argmax-reward action for each state.

    Parameters
    ----------
    reward_table : np.ndarray, shape (n_states, n_actions)
        Expected reward for each (s, a) pair.

    Returns
    -------
    best_a : np.ndarray, shape (n_states,)
    """
    return np.argmax(reward_table, axis=1)

"""Data loading utilities for the ICU sepsis MDP task.

Loads the 716-state x 25-action tabular MDP derived from intensive-care
sepsis patient records. All loaders return numpy arrays in the conventions
used by the bandit and policy-evaluation routines elsewhere in this tools/
folder.
"""

from __future__ import annotations

import csv
import json
import os
from typing import Tuple

import numpy as np


N_STATES_DEFAULT = 716
N_ACTIONS_DEFAULT = 25


def load_metadata(json_path: str) -> dict:
    """Load MDP metadata (number of states, actions, terminal rewards).

    Parameters
    ----------
    json_path : str
        Path to ``metadata.json`` file.

    Returns
    -------
    dict
        Dictionary with keys ``n_states``, ``n_actions``, ``r_survive``,
        ``r_death``, ``transition_threshold``.
    """
    with open(json_path, "r") as f:
        return json.load(f)


def load_clinician_policy(csv_path: str) -> np.ndarray:
    """Load the empirical clinician (behaviour) policy pi_b(a|s).

    Parameters
    ----------
    csv_path : str
        Path to ``clinician_policy.csv``: each row is a state, each column
        the empirical action probability.

    Returns
    -------
    pi_b : np.ndarray, shape (n_states, n_actions)
        Behaviour policy. Each row sums to 1 (or 0 for unreachable states).
    """
    rows = []
    with open(csv_path, "r") as f:
        reader = csv.reader(f)
        for row in reader:
            rows.append([float(v) for v in row])
    return np.asarray(rows, dtype=float)


def load_initial_state_distribution(csv_path: str) -> np.ndarray:
    """Load p0(s), the empirical initial state distribution.

    Parameters
    ----------
    csv_path : str
        Path to ``initial_state_distribution.csv`` (single row of length n_states).

    Returns
    -------
    p0 : np.ndarray, shape (n_states,)
        Initial state probabilities. Sums to 1.
    """
    with open(csv_path, "r") as f:
        reader = csv.reader(f)
        row = next(reader)
    return np.asarray([float(v) for v in row], dtype=float)


def load_reward_function(csv_path: str) -> np.ndarray:
    """Load R(s'), the terminal reward indexed by next state.

    Parameters
    ----------
    csv_path : str
        Path to ``reward_function.csv``.

    Returns
    -------
    r : np.ndarray, shape (n_states,)
        Reward received upon entering each state. Only the survivor absorbing
        state has reward 1; all others are 0.
    """
    with open(csv_path, "r") as f:
        reader = csv.reader(f)
        row = next(reader)
    return np.asarray([float(v) for v in row], dtype=float)


def load_transition_function(
    csv_path: str,
    n_states: int = N_STATES_DEFAULT,
    n_actions: int = N_ACTIONS_DEFAULT,
) -> np.ndarray:
    """Load T(s'|s,a), the empirical transition probability tensor.

    The CSV stores transitions row-major as (s * n_actions + a) by s'.

    Parameters
    ----------
    csv_path : str
        Path to ``transition_function.csv``.
    n_states, n_actions : int
        MDP dimensions (defaults match the canonical ICU-sepsis MDP).

    Returns
    -------
    T : np.ndarray, shape (n_states, n_actions, n_states)
        Transition tensor. ``T[s, a, :]`` sums to 1 for every (s, a).
    """
    flat = np.zeros((n_states * n_actions, n_states), dtype=np.float32)
    with open(csv_path, "r") as f:
        reader = csv.reader(f)
        for i, row in enumerate(reader):
            flat[i] = [float(v) for v in row]
    return flat.reshape(n_states, n_actions, n_states)


def load_state_features(csv_path: str) -> np.ndarray:
    """Load 47-dim feature vector centroid for each state.

    These centroids are the k-means cluster centres of 47 standardised
    patient features (vital signs, labs, demographics) that serve as the
    context vector for contextual bandit algorithms.

    Parameters
    ----------
    csv_path : str
        Path to ``state_features.csv``.

    Returns
    -------
    X : np.ndarray, shape (n_states, n_features)
        Feature matrix.
    """
    rows = []
    with open(csv_path, "r") as f:
        reader = csv.reader(f)
        for row in reader:
            rows.append([float(v) for v in row])
    return np.asarray(rows, dtype=float)


def load_sofa_scores(csv_path: str) -> np.ndarray:
    """Load mean SOFA score for each state.

    Parameters
    ----------
    csv_path : str
        Path to ``sofa_scores.csv`` (single row of length n_states).

    Returns
    -------
    sofa : np.ndarray, shape (n_states,)
        Mean SOFA score; absorbing terminal states are 0.
    """
    with open(csv_path, "r") as f:
        reader = csv.reader(f)
        row = next(reader)
    return np.asarray([float(v) for v in row], dtype=float)


def load_admissible_actions(txt_path: str, n_states: int = N_STATES_DEFAULT,
                            n_actions: int = N_ACTIONS_DEFAULT) -> dict:
    """Load the per-state admissible-action sets.

    File format of ``admissible_actions.txt`` (1 + n_states lines):
      * Line 0  -- whitespace-separated COUNTS: the number of distinct
        actions historically observed in each of the ``n_states`` states.
      * Lines 1..n_states -- one line per state listing the 0-indexed
        admissible action indices for that state (length equals the count
        on line 0). Terminal/absorbing states list no real action.

    Returns
    -------
    dict with:
      * ``counts``  : np.ndarray (n_states,) admissible-action count per state
      * ``indices`` : list[list[int]] the admissible action indices per state
      * ``mask``    : np.ndarray (n_states, n_actions) boolean - True where
                      the action is admissible for that state. Use this to
                      restrict policy improvement to observed actions.
    """
    with open(txt_path, "r") as f:
        lines = [ln for ln in f.read().splitlines() if ln.strip() != ""]
    counts = np.asarray([int(t) for t in lines[0].split()][:n_states], dtype=int)
    indices: list = []
    mask = np.zeros((n_states, n_actions), dtype=bool)
    for s in range(n_states):
        if s + 1 < len(lines):
            idx = [int(t) for t in lines[s + 1].split()]
        else:
            idx = []
        indices.append(idx)
        for a in idx:
            if 0 <= a < n_actions:
                mask[s, a] = True
    # A state with no admissible action (terminal) -> allow all so masking is a
    # no-op there rather than producing an all-False (un-improvable) row.
    mask[~mask.any(axis=1)] = True
    return {"counts": counts, "indices": indices, "mask": mask}


def identify_terminal_states(reward: np.ndarray) -> Tuple[int, int]:
    """Return indices of (death, survival) absorbing states.

    Convention follows ICU-sepsis MDP: state with reward 1 is the survival
    absorbing state; the immediately preceding integer index is the death
    absorbing state (verified against the metadata).

    Parameters
    ----------
    reward : np.ndarray, shape (n_states,)
        Reward function loaded by ``load_reward_function``.

    Returns
    -------
    death_state : int
    survival_state : int
    """
    survival_state = int(np.argmax(reward))
    death_state = survival_state - 1
    return death_state, survival_state


def decode_action(action_id: int) -> Tuple[int, int]:
    """Decode action index 0..24 into (iv_fluid_bin, vasopressor_bin).

    The 25 actions form a 5x5 grid: bin 0 = no drug, bins 1-4 = quartiles
    of administered doses. Encoding: action = iv * 5 + vp.

    Parameters
    ----------
    action_id : int
        Integer in [0, 24].

    Returns
    -------
    iv_bin : int, in [0, 4]
    vp_bin : int, in [0, 4]
    """
    if not 0 <= action_id < 25:
        raise ValueError(f"action_id must be in [0,24], got {action_id}")
    return action_id // 5, action_id % 5


def encode_action(iv_bin: int, vp_bin: int) -> int:
    """Encode (iv_fluid_bin, vasopressor_bin) -> action index.

    Inverse of ``decode_action``.

    Parameters
    ----------
    iv_bin, vp_bin : int
        Bins in [0, 4].

    Returns
    -------
    int : action_id in [0, 24].
    """
    if not (0 <= iv_bin < 5 and 0 <= vp_bin < 5):
        raise ValueError("Bins must be in [0,4].")
    return iv_bin * 5 + vp_bin

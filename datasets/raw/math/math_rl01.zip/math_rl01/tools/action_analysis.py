"""Action-distribution and dose-mismatch analysis tools.

Compute (a) marginal probability mass on each (IV-fluid, vasopressor)
bin under any policy, (b) per-patient mean dose excess between two
policies, and (c) the terminal-mortality versus dose-excess curve from
logged trajectories.
"""

from __future__ import annotations

from typing import List, Tuple

import numpy as np


def policy_action_distribution(
    policy: np.ndarray,
    state_weights: np.ndarray,
) -> np.ndarray:
    """Return the marginal probability of each of the 25 actions under policy.

    Parameters
    ----------
    policy : np.ndarray, shape (S, A)
        Either deterministic one-hot or stochastic.
    state_weights : np.ndarray, shape (S,)
        Probability of being in each state (e.g. initial-state distribution
        or stationary visitation under behaviour policy). Must sum to 1.

    Returns
    -------
    p_a : np.ndarray, shape (A,)
        Marginal action distribution.
    """
    return state_weights @ policy


def action_distribution_grid(action_marginals: np.ndarray) -> np.ndarray:
    """Reshape (25,) action marginals to 5x5 (IV fluid x vasopressor) grid.

    Row index = IV fluid bin (0=no fluids, 1-4 = quartiles).
    Column index = vasopressor bin.

    Parameters
    ----------
    action_marginals : np.ndarray, shape (25,)

    Returns
    -------
    grid : np.ndarray, shape (5, 5)
    """
    if action_marginals.shape[0] != 25:
        raise ValueError("Expected 25 actions for 5x5 reshape.")
    return action_marginals.reshape(5, 5)


def vasopressor_use_probability(action_marginals: np.ndarray) -> float:
    """Probability that any vasopressor (bin >= 1) is administered.

    Parameters
    ----------
    action_marginals : np.ndarray, shape (25,)

    Returns
    -------
    float
    """
    grid = action_distribution_grid(action_marginals)
    # Sum over rows (IV) for vp_bin >= 1
    return float(grid[:, 1:].sum())


def iv_fluid_use_probability(action_marginals: np.ndarray) -> float:
    """Probability that any IV fluids (bin >= 1) are administered.

    Parameters
    ----------
    action_marginals : np.ndarray, shape (25,)

    Returns
    -------
    float
    """
    grid = action_distribution_grid(action_marginals)
    return float(grid[1:, :].sum())


def per_state_action_disagreement(
    policy_a: np.ndarray, policy_b: np.ndarray, state_weights: np.ndarray
) -> float:
    """Expected probability of action disagreement between two policies.

    For deterministic policies this equals the fraction of state mass at
    which argmax differs; for stochastic policies it is
    sum_s w_s * (1 - sum_a min(pi_a, pi_b)).

    Parameters
    ----------
    policy_a, policy_b : np.ndarray, shape (S, A)
    state_weights : np.ndarray, shape (S,)

    Returns
    -------
    float
    """
    overlap = np.minimum(policy_a, policy_b).sum(axis=1)  # per-state agreement mass
    disagreement = 1.0 - overlap
    return float(state_weights @ disagreement)


def dose_excess_per_state(
    policy_clinician: np.ndarray,
    policy_ai: np.ndarray,
    drug_index: str = "iv",
) -> np.ndarray:
    """Per-state mean dose-bin difference (clinician - AI) for a drug.

    Parameters
    ----------
    policy_clinician, policy_ai : np.ndarray, shape (S, 25)
    drug_index : {'iv', 'vp'}
        Which drug to project on.

    Returns
    -------
    diff : np.ndarray, shape (S,)
        Positive => clinician gives more than AI; negative => clinician less.
    """
    bin_index = np.arange(5)
    grid_c = policy_clinician.reshape(-1, 5, 5)
    grid_a = policy_ai.reshape(-1, 5, 5)
    if drug_index == "iv":
        # Mean IV bin = sum_iv iv_idx * p(iv_idx)
        c = (grid_c.sum(axis=2) * bin_index[None, :]).sum(axis=1)
        a = (grid_a.sum(axis=2) * bin_index[None, :]).sum(axis=1)
    elif drug_index == "vp":
        c = (grid_c.sum(axis=1) * bin_index[None, :]).sum(axis=1)
        a = (grid_a.sum(axis=1) * bin_index[None, :]).sum(axis=1)
    else:
        raise ValueError("drug_index must be 'iv' or 'vp'.")
    return c - a


def mortality_vs_dose_excess(
    trajectories,
    policy_ai: np.ndarray,
    drug_index: str = "vp",
    n_bins: int = 21,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Compute mortality rate vs mean dose-bin excess (clinician minus AI).

    For each logged trajectory, compute the average over its (s, a) tuples
    of ``a_iv_bin - argmax_a' policy_ai[s,a'].iv_bin`` (or vasopressor),
    bin into ``n_bins`` evenly spaced intervals, and return the empirical
    mortality (1 - reward) within each bin.

    Parameters
    ----------
    trajectories : list of Trajectory
    policy_ai : np.ndarray, shape (S, 25)
        Deterministic AI policy as one-hot or any policy whose argmax is used.
    drug_index : {'iv', 'vp'}
    n_bins : int

    Returns
    -------
    bin_centers : np.ndarray, shape (n_bins,)
    mortality : np.ndarray, shape (n_bins,)
    counts : np.ndarray, shape (n_bins,)
    """
    excesses = []
    outcomes = []
    bin_idx = np.arange(5)
    ai_actions = np.argmax(policy_ai, axis=1)
    for tr in trajectories:
        if tr.length() == 0:
            continue
        diffs = []
        for s, a in zip(tr.states[:-1], tr.actions):
            ai_a = ai_actions[s]
            iv_c, vp_c = a // 5, a % 5
            iv_a, vp_a = ai_a // 5, ai_a % 5
            diff = (iv_c - iv_a) if drug_index == "iv" else (vp_c - vp_a)
            diffs.append(diff)
        excesses.append(float(np.mean(diffs)))
        # Mortality = 1 - terminal reward
        outcomes.append(1.0 - tr.rewards[-1])
    if not excesses:
        return np.array([]), np.array([]), np.array([])
    excesses = np.asarray(excesses)
    outcomes = np.asarray(outcomes)
    bin_edges = np.linspace(excesses.min(), excesses.max(), n_bins + 1)
    bin_centers = 0.5 * (bin_edges[:-1] + bin_edges[1:])
    mortality = np.full(n_bins, np.nan)
    counts = np.zeros(n_bins, dtype=int)
    for i in range(n_bins):
        mask = (excesses >= bin_edges[i]) & (excesses < bin_edges[i + 1])
        if i == n_bins - 1:
            mask = (excesses >= bin_edges[i]) & (excesses <= bin_edges[i + 1])
        counts[i] = int(mask.sum())
        if counts[i] > 0:
            mortality[i] = float(outcomes[mask].mean())
    return bin_centers, mortality, counts


def stationary_visitation(
    T: np.ndarray, policy: np.ndarray, p0: np.ndarray, max_iter: int = 100, tol: float = 1e-8
) -> np.ndarray:
    """Approximate state-visitation frequency under a policy.

    Iterates d_{t+1}(s') = sum_{s,a} d_t(s) pi(a|s) T(s'|s,a) until the
    distribution stabilises. Useful as state_weights when computing action
    marginals because it accounts for the dynamics of the MDP, not just
    the initial distribution.

    Parameters
    ----------
    T : np.ndarray, shape (S, A, S)
    policy : np.ndarray, shape (S, A)
    p0 : np.ndarray, shape (S,)
    max_iter, tol : control parameters.

    Returns
    -------
    d : np.ndarray, shape (S,)
        Time-averaged visitation, sum to 1.
    """
    S = T.shape[0]
    d = p0.copy()
    visit_sum = d.copy()
    for _ in range(max_iter):
        # Marginalise: P(s'|s) = sum_a pi(a|s) T(s'|s,a)
        Ppi = np.einsum("sa,sat->st", policy, T)
        d_next = d @ Ppi
        visit_sum += d_next
        if np.max(np.abs(d_next - d)) < tol:
            d = d_next
            break
        d = d_next
    visit_sum = visit_sum / visit_sum.sum()
    return visit_sum

"""Bootstrap confidence intervals and statistical comparisons for OPE.

A standard percentile-bootstrap protocol applied to any scalar estimator
that takes a list of trajectories. Use ~2000 resamples for stable CIs;
500 is enough for quick sanity checks.
"""

from __future__ import annotations

from typing import Callable, List, Tuple

import numpy as np


def bootstrap_estimator_ci(
    trajectories: List,
    estimator: Callable[[List], float],
    n_resamples: int = 2000,
    alpha: float = 0.05,
    seed: int = 0,
) -> Tuple[float, float, float, np.ndarray]:
    """Bootstrap a scalar estimator from trajectory data.

    Parameters
    ----------
    trajectories : list
        Pool to resample from with replacement.
    estimator : callable
        Function that takes a list of trajectories and returns a float.
    n_resamples : int
        Number of bootstrap replicates.
    alpha : float
        Two-sided significance level (CI is 1 - alpha).
    seed : int

    Returns
    -------
    point_estimate : float
        ``estimator(trajectories)``.
    lower : float
        Lower bound of the (1-alpha) percentile CI.
    upper : float
        Upper bound of the (1-alpha) percentile CI.
    samples : np.ndarray, shape (n_resamples,)
        Array of bootstrap replicate values.
    """
    rng = np.random.default_rng(seed)
    n = len(trajectories)
    samples = np.empty(n_resamples)
    for b in range(n_resamples):
        idx = rng.integers(0, n, size=n)
        samples[b] = estimator([trajectories[i] for i in idx])
    point = estimator(trajectories)
    lo, hi = np.quantile(samples, [alpha / 2, 1 - alpha / 2])
    return float(point), float(lo), float(hi), samples


def percentile_ci(samples: np.ndarray, alpha: float = 0.05) -> Tuple[float, float]:
    """Compute percentile CI from bootstrap samples.

    Parameters
    ----------
    samples : np.ndarray
    alpha : float

    Returns
    -------
    lower, upper : float
    """
    lo, hi = np.quantile(samples, [alpha / 2, 1 - alpha / 2])
    return float(lo), float(hi)


def median_iqr(samples: np.ndarray) -> Tuple[float, float, float]:
    """Median and 25th/75th percentiles of a bootstrap sample.

    Returns ``(median, q25, q75)``.
    """
    q25, m, q75 = np.quantile(samples, [0.25, 0.5, 0.75])
    return float(m), float(q25), float(q75)


def bootstrap_difference(
    samples_a: np.ndarray, samples_b: np.ndarray, alpha: float = 0.05
) -> Tuple[float, float, float]:
    """Bootstrap CI for the paired difference samples_a - samples_b.

    Useful for comparing two policy-value bootstraps drawn with the same
    seed/resample indices.

    Parameters
    ----------
    samples_a, samples_b : np.ndarray, same length
    alpha : float

    Returns
    -------
    diff_median : float
    diff_lo, diff_hi : float
    """
    if samples_a.shape != samples_b.shape:
        raise ValueError("samples must be paired (same shape)")
    diff = samples_a - samples_b
    return float(np.median(diff)), *percentile_ci(diff, alpha=alpha)

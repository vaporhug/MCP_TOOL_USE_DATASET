"""MDP simulation utilities for generating logged bandit-style trajectories.

Given the empirical transition function T(s'|s,a), reward R(s'), and an
initial state distribution p0, this module simulates trajectories under any
behaviour policy. The resulting (context, action, reward, next_state)
tuples are used as the logged dataset by the contextual bandit algorithms
and by the off-policy evaluation routines.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional

import numpy as np


@dataclass
class Trajectory:
    """Container for a single rollout of the MDP.

    Attributes
    ----------
    states : list of int
        State visited at each step (length T+1, includes terminal).
    actions : list of int
        Actions taken at steps 0..T-1.
    rewards : list of float
        Rewards received after each action (length T).
    behaviour_probs : list of float
        Probability mass the behaviour policy placed on the chosen action at
        each step (length T). Used for importance sampling.
    """

    states: List[int]
    actions: List[int]
    rewards: List[float]
    behaviour_probs: List[float]
    truncated: bool = False

    def length(self) -> int:
        """Number of decision steps (= len(actions))."""
        return len(self.actions)

    def total_return(self, gamma: float = 1.0) -> float:
        """Compute discounted cumulative return."""
        g = 0.0
        for t, r in enumerate(self.rewards):
            g += (gamma ** t) * r
        return g


def simulate_trajectory(
    T: np.ndarray,
    reward: np.ndarray,
    initial_state_distribution: np.ndarray,
    policy: np.ndarray,
    terminal_states: tuple,
    rng: np.random.Generator,
    max_horizon: int = 50,
) -> Trajectory:
    """Roll out a single trajectory under a given stochastic policy.

    Parameters
    ----------
    T : np.ndarray, shape (S, A, S)
        Transition tensor.
    reward : np.ndarray, shape (S,)
        Reward received on entering each state.
    initial_state_distribution : np.ndarray, shape (S,)
        Sampling distribution over starting states.
    policy : np.ndarray, shape (S, A)
        Stochastic policy. Each row is a probability distribution over actions.
    terminal_states : tuple of int
        States that end the episode (death, survival).
    rng : np.random.Generator
        Random number generator.
    max_horizon : int
        Hard cap on trajectory length to ensure termination.

    Returns
    -------
    Trajectory
    """
    s = int(rng.choice(len(initial_state_distribution), p=initial_state_distribution))
    states = [s]
    actions: List[int] = []
    rewards: List[float] = []
    bprobs: List[float] = []

    truncated = False
    for step in range(max_horizon):
        if s in terminal_states:
            break
        pa = policy[s]
        # Defensive renormalisation for numerical drift
        pa_sum = pa.sum()
        if pa_sum <= 0:
            # Forced uniform if behaviour mass is zero (rare unreachable states)
            pa = np.ones_like(pa) / len(pa)
        else:
            pa = pa / pa_sum
        a = int(rng.choice(len(pa), p=pa))
        ts = T[s, a]
        ts_sum = ts.sum()
        if ts_sum <= 0:
            # Self-loop guard
            s_next = s
        else:
            s_next = int(rng.choice(len(ts), p=ts / ts_sum))
        r = float(reward[s_next])
        actions.append(a)
        rewards.append(r)
        bprobs.append(float(pa[a]))
        states.append(s_next)
        s = s_next
    if s not in terminal_states and len(actions) >= max_horizon:
        truncated = True
    return Trajectory(states=states, actions=actions, rewards=rewards,
                      behaviour_probs=bprobs, truncated=truncated)


def simulate_dataset(
    T: np.ndarray,
    reward: np.ndarray,
    initial_state_distribution: np.ndarray,
    policy: np.ndarray,
    terminal_states: tuple,
    n_trajectories: int,
    seed: int = 0,
    max_horizon: int = 50,
) -> List[Trajectory]:
    """Simulate ``n_trajectories`` rollouts under a behaviour policy.

    Parameters
    ----------
    T, reward, initial_state_distribution, policy, terminal_states : see
        ``simulate_trajectory``.
    n_trajectories : int
        Number of episodes to draw.
    seed : int
        Seed for ``np.random.default_rng``.
    max_horizon : int
        Maximum decision steps per trajectory.

    Returns
    -------
    list of Trajectory
    """
    rng = np.random.default_rng(seed)
    return [
        simulate_trajectory(
            T,
            reward,
            initial_state_distribution,
            policy,
            terminal_states,
            rng,
            max_horizon=max_horizon,
        )
        for _ in range(n_trajectories)
    ]


def flatten_to_bandit_tuples(trajectories: List[Trajectory],
                             drop_truncated: bool = True) -> dict:
    """Collapse list of trajectories to (state, action, reward, prob) arrays.

    This helper is for logged-context diagnostics and behaviour-policy Monte
    Carlo summaries only. It propagates the realised terminal outcome to the
    logged action actually taken in that episode; those realised rewards are
    NOT valid counterfactual rewards for actions that were not taken. Use
    ``bandit_algorithms.expected_survival_reward_table`` plus
    ``constrained_oracle_rewards`` for cumulative-regret baselines.

    Parameters
    ----------
    trajectories : list of Trajectory
    drop_truncated : bool
        If True, omit max-horizon-truncated rollouts whose terminal outcome is
        unknown, preventing censored final states from being treated as death
        or survival.

    Returns
    -------
    dict with keys
        ``states`` : (N,) int array of context state indices
        ``actions`` : (N,) int array of selected actions
        ``rewards`` : (N,) float array of episode terminal reward (0/1)
        ``behaviour_probs`` : (N,) float array of pi_b(a|s) at logging time
    """
    s_all, a_all, r_all, p_all = [], [], [], []
    for tr in trajectories:
        if tr.length() == 0:
            continue
        if drop_truncated and getattr(tr, "truncated", False):
            continue
        terminal_r = tr.rewards[-1]
        for st, ac, p in zip(tr.states[:-1], tr.actions, tr.behaviour_probs):
            s_all.append(st)
            a_all.append(ac)
            r_all.append(terminal_r)
            p_all.append(p)
    return {
        "states": np.asarray(s_all, dtype=int),
        "actions": np.asarray(a_all, dtype=int),
        "rewards": np.asarray(r_all, dtype=float),
        "behaviour_probs": np.asarray(p_all, dtype=float),
    }


def trajectory_completion_summary(trajectories: List[Trajectory]) -> dict:
    """Count completed versus max-horizon-truncated simulated trajectories."""
    n = len(trajectories)
    n_truncated = sum(1 for tr in trajectories if getattr(tr, "truncated", False))
    return {
        "n_trajectories": n,
        "n_completed": n - n_truncated,
        "n_truncated": n_truncated,
        "truncation_fraction": n_truncated / n if n else 0.0,
    }


def sample_random_policy(n_states: int, n_actions: int) -> np.ndarray:
    """Return a uniform random stochastic policy.

    Parameters
    ----------
    n_states, n_actions : int

    Returns
    -------
    pi : np.ndarray, shape (n_states, n_actions), each row uniform.
    """
    return np.full((n_states, n_actions), 1.0 / n_actions)


def softmax_policy_from_q(q_values: np.ndarray, temperature: float = 1.0) -> np.ndarray:
    """Convert Q values to a softmax (Boltzmann) stochastic policy.

    Parameters
    ----------
    q_values : np.ndarray, shape (S, A)
        Q-function table.
    temperature : float
        Larger -> closer to uniform; smaller -> closer to greedy.

    Returns
    -------
    pi : np.ndarray, shape (S, A)
    """
    z = q_values / max(temperature, 1e-8)
    z = z - z.max(axis=1, keepdims=True)
    e = np.exp(z)
    return e / e.sum(axis=1, keepdims=True)


def epsilon_smooth_policy(deterministic_actions: np.ndarray, n_actions: int,
                          epsilon: float,
                          admissible_mask: np.ndarray | None = None,
                          support_policy: np.ndarray | None = None) -> np.ndarray:
    """Build an epsilon-smoothed policy from deterministic action choices.

    Parameters
    ----------
    deterministic_actions : np.ndarray, shape (S,)
        Action chosen by the underlying greedy policy at each state.
    n_actions : int
        Total number of actions.
    epsilon : float
        Mass spread uniformly across the row-level support actions;
        (1-epsilon) on the chosen action when it is supported.

    Returns
    -------
    pi : np.ndarray, shape (S, n_actions)
    """
    n_states = len(deterministic_actions)
    if admissible_mask is not None:
        support = np.asarray(admissible_mask, dtype=bool)
    elif support_policy is not None:
        support = np.asarray(support_policy, dtype=float) > 0
    else:
        support = np.ones((n_states, n_actions), dtype=bool)
    pi = np.zeros((n_states, n_actions), dtype=float)
    for s, a in enumerate(deterministic_actions):
        allowed = np.where(support[s])[0]
        if len(allowed) == 0:
            pi[s, 0] = 1.0
            continue
        pi[s, allowed] = epsilon / len(allowed)
        chosen = int(a) if int(a) in set(allowed.tolist()) else int(allowed[0])
        pi[s, chosen] += 1.0 - epsilon
    return pi

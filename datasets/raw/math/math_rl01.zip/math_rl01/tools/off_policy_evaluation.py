"""Off-policy evaluation (OPE) estimators for ICU sepsis.

Given trajectories collected under a behaviour policy pi_b, estimate the
expected return of a target (evaluation) policy pi_e. Implements:

    - IPS (Importance Sampling), trajectory-wise
    - WIS (Weighted Importance Sampling), trajectory-wise
    - Per-decision IPS
    - Doubly Robust (DR) estimator

A small ``soften_policy`` helper enforces minimum action probability epsilon
on the target policy so that importance ratios are bounded, a standard
practice for off-policy evaluation in healthcare-style sparse-reward MDPs.
"""

from __future__ import annotations

from typing import List, Optional, Tuple

import numpy as np


def soften_policy(policy: np.ndarray, epsilon: float = 0.01) -> np.ndarray:
    """Mix policy with uniform to bound importance ratios.

    Parameters
    ----------
    policy : np.ndarray, shape (S, A)
        Original (possibly deterministic) target policy.
    epsilon : float
        Total uniform mass. Each action receives at least ``epsilon / A``.

    Returns
    -------
    pi_soft : np.ndarray, shape (S, A), each row sums to 1.
    """
    A = policy.shape[1]
    return (1.0 - epsilon) * policy + epsilon / A


def trajectory_importance_ratio(
    actions: List[int],
    states: List[int],
    pi_e: np.ndarray,
    behaviour_probs: List[float],
) -> float:
    """Compute the trajectory-wise IS ratio prod_t pi_e(a|s)/pi_b(a|s).

    Parameters
    ----------
    actions : list of int
    states : list of int
        States at which actions were taken (length = len(actions)).
    pi_e : np.ndarray, shape (S, A)
        Target policy.
    behaviour_probs : list of float
        pi_b(a|s) at each step (already recorded at logging time).

    Returns
    -------
    rho : float
    """
    rho = 1.0
    for s, a, pb in zip(states, actions, behaviour_probs):
        if pb <= 0:
            return 0.0
        rho *= float(pi_e[s, a]) / float(pb)
    return rho


def ips_estimator(trajectories, pi_e: np.ndarray, gamma: float = 1.0) -> float:
    """Trajectory-wise Importance Sampling estimator of V(pi_e).

    V_IPS = (1/N) sum_i rho_i * G_i

    Parameters
    ----------
    trajectories : list of Trajectory (mdp_simulation.Trajectory)
    pi_e : np.ndarray, shape (S, A)
    gamma : float

    Returns
    -------
    float
    """
    estimates = []
    for tr in trajectories:
        rho = trajectory_importance_ratio(
            tr.actions, tr.states[:-1], pi_e, tr.behaviour_probs
        )
        estimates.append(rho * tr.total_return(gamma=gamma))
    return float(np.mean(estimates)) if estimates else 0.0


def wis_estimator(trajectories, pi_e: np.ndarray, gamma: float = 1.0) -> float:
    """Trajectory-wise Weighted Importance Sampling estimator.

    V_WIS = sum_i rho_i G_i / sum_i rho_i.

    Parameters
    ----------
    trajectories, pi_e, gamma : see ``ips_estimator``.

    Returns
    -------
    float
    """
    rhos, gs = [], []
    for tr in trajectories:
        rho = trajectory_importance_ratio(
            tr.actions, tr.states[:-1], pi_e, tr.behaviour_probs
        )
        rhos.append(rho)
        gs.append(tr.total_return(gamma=gamma))
    rhos = np.asarray(rhos)
    gs = np.asarray(gs)
    denom = rhos.sum()
    if denom <= 0:
        return 0.0
    return float((rhos * gs).sum() / denom)


def per_decision_ips(trajectories, pi_e: np.ndarray, gamma: float = 1.0) -> float:
    """Per-decision IPS (PDIS) estimator.

    Uses cumulative ratios up to step t multiplied by reward at step t,
    summed across the horizon, averaged over trajectories. Lower variance
    than trajectory IS for sparse/terminal rewards.

    Parameters
    ----------
    trajectories, pi_e, gamma : standard.

    Returns
    -------
    float
    """
    estimates = []
    for tr in trajectories:
        cum_rho = 1.0
        v = 0.0
        for t, (s, a, pb) in enumerate(zip(tr.states[:-1], tr.actions, tr.behaviour_probs)):
            if pb <= 0:
                cum_rho = 0.0
            else:
                cum_rho *= pi_e[s, a] / pb
            v += (gamma ** t) * cum_rho * tr.rewards[t]
        estimates.append(v)
    return float(np.mean(estimates)) if estimates else 0.0


def fit_q_model_from_trajectories(
    trajectories,
    n_states: int,
    n_actions: int,
    gamma: float = 1.0,
    alpha: float = 0.1,
    n_passes: int = 5,
) -> np.ndarray:
    """Fit a tabular Q estimate using TD(0) on the logged trajectories.

    Used by the doubly robust estimator as the model-based component.

    Parameters
    ----------
    trajectories : list of Trajectory
    n_states, n_actions : int
    gamma : float
    alpha : float
        TD learning rate.
    n_passes : int
        Number of passes through the dataset.

    Returns
    -------
    Q : np.ndarray, shape (S, A)
    """
    Q = np.zeros((n_states, n_actions))
    for _ in range(n_passes):
        for tr in trajectories:
            for t, (s, a, r) in enumerate(zip(tr.states[:-1], tr.actions, tr.rewards)):
                s_next = tr.states[t + 1]
                target = r + gamma * np.max(Q[s_next])
                Q[s, a] += alpha * (target - Q[s, a])
    return Q


def doubly_robust_estimator(
    trajectories,
    pi_e: np.ndarray,
    Q: np.ndarray,
    gamma: float = 1.0,
) -> float:
    """Doubly robust OPE (Jiang & Li 2015 trajectory form).

    V_DR per trajectory:
        V_hat(s_0) + sum_t cum_rho_t * ( r_t + gamma V_hat(s_{t+1}) - Q(s_t, a_t) )
    where V_hat(s) = sum_a pi_e(a|s) Q(s,a).

    Parameters
    ----------
    trajectories : list of Trajectory
    pi_e : np.ndarray, shape (S, A)
    Q : np.ndarray, shape (S, A)
        Fitted Q model (e.g. from ``fit_q_model_from_trajectories``).
    gamma : float

    Returns
    -------
    float
    """
    V_hat = (pi_e * Q).sum(axis=1)
    estimates = []
    for tr in trajectories:
        s0 = tr.states[0]
        v = float(V_hat[s0])
        cum_rho = 1.0
        for t, (s, a, pb, r) in enumerate(
            zip(tr.states[:-1], tr.actions, tr.behaviour_probs, tr.rewards)
        ):
            if pb <= 0:
                cum_rho = 0.0
            else:
                cum_rho *= pi_e[s, a] / pb
            s_next = tr.states[t + 1]
            v += (gamma ** t) * cum_rho * (r + gamma * V_hat[s_next] - Q[s, a])
        estimates.append(v)
    return float(np.mean(estimates)) if estimates else 0.0


def behaviour_policy_value(trajectories, gamma: float = 1.0) -> float:
    """Return the on-policy Monte Carlo estimate of pi_b's value.

    Simply the empirical mean trajectory return; useful as an anchor in
    the OPE comparison plot.
    """
    if not trajectories:
        return 0.0
    return float(np.mean([tr.total_return(gamma=gamma) for tr in trajectories]))

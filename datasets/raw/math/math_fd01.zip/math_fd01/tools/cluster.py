"""Functional ``k``-means in FPCA-score space.

Curves are first projected onto their leading FPCA basis; we then run plain
Lloyd's algorithm on the resulting low-dimensional vectors, with multiple
random restarts to mitigate local minima.

This is sufficient for the toy 93-curve Berkeley clustering (sex
discrimination from growth-velocity scores).
"""
from __future__ import annotations

from typing import Tuple
import numpy as np


def kmeans_pp_init(X: np.ndarray, k: int, rng: np.random.Generator) -> np.ndarray:
    """k-means++ centre initialisation."""
    N = X.shape[0]
    if k > N:
        raise ValueError("k cannot exceed N")
    centres = np.empty((k, X.shape[1]))
    first = int(rng.integers(0, N))
    centres[0] = X[first]
    closest_sq = np.sum((X - centres[0]) ** 2, axis=1)
    for j in range(1, k):
        probs = closest_sq / closest_sq.sum() if closest_sq.sum() > 0 else np.ones(N) / N
        idx = int(rng.choice(N, p=probs))
        centres[j] = X[idx]
        new_sq = np.sum((X - centres[j]) ** 2, axis=1)
        closest_sq = np.minimum(closest_sq, new_sq)
    return centres


def kmeans_lloyd(
    X: np.ndarray, k: int, max_iter: int = 50, rng_seed: int = 0
) -> Tuple[np.ndarray, np.ndarray, float]:
    """Run a single Lloyd iteration; returns ``(labels, centres, inertia)``."""
    if X.ndim != 2:
        raise ValueError("X must be 2-D")
    rng = np.random.default_rng(rng_seed)
    centres = kmeans_pp_init(X, k, rng)
    labels = np.zeros(X.shape[0], dtype=np.int64)
    for _ in range(max_iter):
        dists = np.sum((X[:, None, :] - centres[None, :, :]) ** 2, axis=2)
        new_labels = np.argmin(dists, axis=1)
        if np.array_equal(new_labels, labels):
            labels = new_labels
            break
        labels = new_labels
        for j in range(k):
            members = X[labels == j]
            if members.shape[0] > 0:
                centres[j] = members.mean(axis=0)
    inertia = float(np.sum(np.min(
        np.sum((X[:, None, :] - centres[None, :, :]) ** 2, axis=2), axis=1
    )))
    return labels, centres, inertia


def kmeans_best_of(
    X: np.ndarray, k: int, n_restarts: int = 10, max_iter: int = 50,
    rng_seed: int = 0,
) -> Tuple[np.ndarray, np.ndarray, float]:
    """Run ``n_restarts`` Lloyd attempts and return the lowest-inertia clustering."""
    best_labels = None
    best_centres = None
    best_inertia = float("inf")
    for r in range(n_restarts):
        labels, centres, inertia = kmeans_lloyd(
            X, k, max_iter=max_iter, rng_seed=rng_seed + r
        )
        if inertia < best_inertia:
            best_labels = labels
            best_centres = centres
            best_inertia = inertia
    if best_labels is None:
        raise RuntimeError("kmeans failed on all restarts")
    return best_labels, best_centres, best_inertia


def confusion_matrix(
    true_labels: np.ndarray, pred_labels: np.ndarray, n_classes: int
) -> np.ndarray:
    """``n_classes x n_classes`` integer count matrix."""
    M = np.zeros((n_classes, n_classes), dtype=np.int64)
    for t, p in zip(true_labels, pred_labels):
        M[int(t), int(p)] += 1
    return M


def best_cluster_accuracy(true_labels: np.ndarray, pred_labels: np.ndarray) -> float:
    """Best label-permutation accuracy (Hungarian-equivalent for k=2,3)."""
    n_true = int(np.max(true_labels)) + 1
    n_pred = int(np.max(pred_labels)) + 1
    n = max(n_true, n_pred)
    cm = confusion_matrix(true_labels, pred_labels, n)
    from itertools import permutations
    best = 0
    for perm in permutations(range(n)):
        acc = sum(cm[i, perm[i]] for i in range(n))
        if acc > best:
            best = acc
    return best / len(true_labels)

"""Scalar-on-function regression with FPCA basis truncation.

Model::

    y_i = alpha + sum_{j=1..k} beta_j * xi_{i, j} + eps_i

where ``xi_{i, j}`` are the FPCA scores from :mod:`tools.fpca`.  We solve via
ordinary least squares.

Used in this task to predict each girl's adult height (mean of the last three
ages, 17-18 years) from the FPCA scores of her growth-velocity curve.
"""
from __future__ import annotations

from typing import Tuple
import numpy as np


def design_with_intercept(X: np.ndarray) -> np.ndarray:
    """Prepend a column of ones to a (N, k) matrix; returns (N, k+1)."""
    if X.ndim != 2:
        raise ValueError("X must be 2-D")
    N = X.shape[0]
    return np.concatenate([np.ones((N, 1)), X], axis=1)


def ols_fit(X: np.ndarray, y: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """Plain-vanilla OLS: returns ``(coef, residuals)`` where ``coef`` includes intercept.

    Solves ``min_b || y - [1 X] b ||^2`` via numpy.linalg.lstsq.
    """
    A = design_with_intercept(X)
    coef, _, _, _ = np.linalg.lstsq(A, y, rcond=None)
    res = y - A @ coef
    return coef, res


def predict(X: np.ndarray, coef: np.ndarray) -> np.ndarray:
    """Apply a fitted ``coef`` (intercept first) to a new (N, k) score matrix."""
    A = design_with_intercept(X)
    return A @ coef


def r_squared(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Coefficient of determination ``1 - RSS / TSS``."""
    res = y_true - y_pred
    rss = float(res @ res)
    tss = float(((y_true - y_true.mean()) ** 2).sum())
    if tss <= 0.0:
        return 0.0
    return 1.0 - rss / tss


def cv_score(
    X: np.ndarray, y: np.ndarray, n_folds: int = 5,
    rng_seed: int = 0,
) -> Tuple[float, float]:
    """k-fold CV mean R^2 and its standard error.

    Parameters
    ----------
    X : (N, k) score matrix.
    y : (N,) targets.
    n_folds : number of folds.
    rng_seed : seed for the fold permutation.
    """
    rng = np.random.default_rng(rng_seed)
    N = X.shape[0]
    perm = rng.permutation(N)
    folds = np.array_split(perm, n_folds)
    r2s = []
    for k in range(n_folds):
        test_idx = folds[k]
        train_mask = np.ones(N, dtype=bool)
        train_mask[test_idx] = False
        coef, _ = ols_fit(X[train_mask], y[train_mask])
        pred = predict(X[test_idx], coef)
        r2s.append(r_squared(y[test_idx], pred))
    r2s = np.array(r2s)
    return float(r2s.mean()), float(r2s.std(ddof=1) / np.sqrt(len(r2s)))

"""Square-root slope (SRSF) representation and dynamic-programming alignment.

This is a from-scratch numpy port of the elastic-FDA primitives used in
Tucker, Wu, Srivastava (2013).  We implement only what the Berkeley-growth
example needs: SRSF transform, gamma-action on a function, dynamic-programming
optimal warping between two SRSFs, Karcher mean of SRSFs.

Conventions
-----------
- Time domain is normalised to ``[0, 1]`` for the alignment step (a helper
  rescales back to physical units afterwards).
- Warping function ``gamma`` satisfies ``gamma(0) = 0``, ``gamma(1) = 1`` and
  monotone non-decreasing.
- For a curve ``f`` with derivative ``f'``, the SRSF is
  ``q(t) = sign(f'(t)) sqrt(|f'(t)|)``.  Then ``L2`` distance between SRSFs is
  invariant to time warping in a precise sense.
"""
from __future__ import annotations

from typing import Tuple
import numpy as np


def normalise_time(t: np.ndarray) -> np.ndarray:
    """Map an arbitrary ascending grid to ``[0, 1]``."""
    t = np.asarray(t, dtype=float)
    if not np.all(np.diff(t) > 0):
        raise ValueError("t must be strictly ascending")
    return (t - t[0]) / (t[-1] - t[0])


def numerical_derivative(f: np.ndarray, t: np.ndarray) -> np.ndarray:
    """Central-difference derivative on a (possibly non-uniform) grid."""
    f = np.asarray(f, dtype=float)
    t = np.asarray(t, dtype=float)
    if f.shape[0] != t.shape[0]:
        raise ValueError("f and t must have the same length")
    df = np.empty_like(f)
    df[0] = (f[1] - f[0]) / (t[1] - t[0])
    df[-1] = (f[-1] - f[-2]) / (t[-1] - t[-2])
    df[1:-1] = (f[2:] - f[:-2]) / (t[2:] - t[:-2])
    return df


def srsf_transform(f: np.ndarray, t: np.ndarray) -> np.ndarray:
    """Compute the square-root slope function ``q``.

    ``q(t) = sign(f'(t)) sqrt(|f'(t)|)`` evaluated on the same grid as ``f``.
    """
    df = numerical_derivative(f, t)
    return np.sign(df) * np.sqrt(np.abs(df))


def warp_curve(f: np.ndarray, gamma: np.ndarray, t: np.ndarray) -> np.ndarray:
    """Action of the warping ``gamma`` on a function ``f``: returns ``f(gamma(t))``.

    ``gamma`` is given as values on the same grid ``t``.
    """
    return np.interp(gamma, t, f)


def warp_srsf(q: np.ndarray, gamma: np.ndarray, t: np.ndarray) -> np.ndarray:
    """Action of ``gamma`` on an SRSF ``q``: ``q(gamma(t)) sqrt(gamma'(t))``."""
    qg = np.interp(gamma, t, q)
    g_prime = numerical_derivative(gamma, t)
    g_prime = np.maximum(g_prime, 0.0)
    return qg * np.sqrt(g_prime)


def dp_optimal_warping(
    q1: np.ndarray, q2: np.ndarray, lam: float = 0.0
) -> np.ndarray:
    """Dynamic-programming search for the warping ``gamma`` aligning ``q2`` to ``q1``.

    The cost being minimised is ``\\int (q1(t) - q2(gamma(t)) sqrt(gamma'(t)))^2 dt``
    and the search is restricted to monotone piecewise-linear paths on the grid
    with slopes in ``{(i - i_prev)/(j - j_prev) : 1 <= step <= max_step}``.

    Parameters
    ----------
    q1, q2 : 1-D arrays of equal length T (SRSFs on a uniform [0, 1] grid).
    lam : non-negative penalty on departure from identity (acts on slope).

    Returns
    -------
    gamma : 1-D length-T warping that aligns ``q2`` to ``q1`` (monotone, with
        ``gamma[0] = 0``, ``gamma[-1] = 1``).
    """
    T = len(q1)
    if T != len(q2):
        raise ValueError("q1 and q2 must have the same length")
    if T < 2:
        raise ValueError("need T >= 2")
    grid = np.linspace(0.0, 1.0, T)
    INF = np.inf
    cost = np.full((T, T), INF)
    parent = np.full((T, T), -1, dtype=np.int64)
    cost[0, 0] = 0.0
    # local slope set: (delta_i, delta_j) pairs
    moves = [
        (1, 1), (1, 2), (2, 1),
        (1, 3), (3, 1), (2, 3), (3, 2),
        (1, 4), (4, 1)
    ]
    for j in range(T):
        for i in range(T):
            if not np.isfinite(cost[i, j]):
                continue
            for (di, dj) in moves:
                ni = i + di
                nj = j + dj
                if ni >= T or nj >= T:
                    continue
                slope = di / dj
                # SRSF cost contribution along the segment from (i, j) to (ni, nj)
                # approximate with trapezoid over (di+1) interior points.
                # We use a coarse 2-point quadrature for speed.
                t_a = grid[j]
                t_b = grid[nj]
                # gamma(t) on segment is i + slope * (j' - j), evaluated at midpoint
                t_mid = 0.5 * (t_a + t_b)
                gamma_mid = grid[i] + slope * (t_mid - t_a)
                # interpolate q2 at gamma_mid
                if gamma_mid <= 0.0:
                    q2_val = q2[0]
                elif gamma_mid >= 1.0:
                    q2_val = q2[-1]
                else:
                    p = gamma_mid * (T - 1)
                    p_lo = int(np.floor(p))
                    frac = p - p_lo
                    q2_val = (1.0 - frac) * q2[p_lo] + frac * q2[p_lo + 1]
                q1_val = q1[j] if j == 0 else 0.5 * (q1[j] + q1[nj])
                seg_len = t_b - t_a
                resid = q1_val - q2_val * np.sqrt(slope)
                add = (resid * resid) * seg_len
                add += lam * (slope - 1.0) ** 2 * seg_len
                new_cost = cost[i, j] + add
                if new_cost < cost[ni, nj]:
                    cost[ni, nj] = new_cost
                    parent[ni, nj] = i * T + j
    # backtrace
    if not np.isfinite(cost[T - 1, T - 1]):
        # fallback to identity
        return grid.copy()
    # build piecewise-linear gamma between visited (i, j) breakpoints
    bp_i = [T - 1]
    bp_j = [T - 1]
    cur_i, cur_j = T - 1, T - 1
    while not (cur_i == 0 and cur_j == 0):
        p = parent[cur_i, cur_j]
        if p < 0:
            break
        cur_i, cur_j = p // T, p % T
        bp_i.append(cur_i)
        bp_j.append(cur_j)
    bp_i.reverse()
    bp_j.reverse()
    # interpolate gamma on the dense grid
    bp_t = grid[np.array(bp_j)]
    bp_g = grid[np.array(bp_i)]
    gamma = np.interp(grid, bp_t, bp_g)
    # enforce boundary and monotonicity
    gamma[0] = 0.0
    gamma[-1] = 1.0
    return np.maximum.accumulate(gamma)


def align_pair(
    f1: np.ndarray, f2: np.ndarray, t: np.ndarray, lam: float = 0.0
) -> Tuple[np.ndarray, np.ndarray]:
    """Align ``f2`` to ``f1``: returns ``(f2_aligned, gamma)``."""
    grid01 = normalise_time(t)
    q1 = srsf_transform(f1, grid01)
    q2 = srsf_transform(f2, grid01)
    gamma = dp_optimal_warping(q1, q2, lam=lam)
    f2_aligned = warp_curve(f2, gamma, grid01)
    return f2_aligned, gamma


def karcher_mean_srsf(
    Y: np.ndarray, t: np.ndarray, n_iter: int = 6, lam: float = 0.0
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Iterative Karcher mean of SRSFs and corresponding warpings.

    Parameters
    ----------
    Y : (T, N) curve matrix.
    t : (T,) ascending time grid.
    n_iter : number of refinement iterations.
    lam : warping regularisation passed to the DP.

    Returns
    -------
    Y_aligned : (T, N) curves after applying their estimated warpings.
    gammas : (T, N) warpings, one per curve.
    f_mean : (T,) elastic mean curve.
    """
    T, N = Y.shape
    grid01 = normalise_time(t)
    Q = np.stack([srsf_transform(Y[:, i], grid01) for i in range(N)], axis=1)
    q_mean = Q.mean(axis=1)
    gammas = np.tile(grid01[:, None], (1, N))
    for _ in range(n_iter):
        new_gammas = np.zeros_like(gammas)
        Q_aligned = np.zeros_like(Q)
        for i in range(N):
            g = dp_optimal_warping(q_mean, Q[:, i], lam=lam)
            new_gammas[:, i] = g
            Q_aligned[:, i] = warp_srsf(Q[:, i], g, grid01)
        q_mean = Q_aligned.mean(axis=1)
        gammas = new_gammas
    Y_aligned = np.zeros_like(Y)
    for i in range(N):
        Y_aligned[:, i] = warp_curve(Y[:, i], gammas[:, i], grid01)
    f_mean = Y_aligned.mean(axis=1)
    return Y_aligned, gammas, f_mean


def landmark_register(
    Y: np.ndarray, t: np.ndarray, target_landmark: float | None = None,
    search_window: tuple = (8.0, 16.0),
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Align curves so that each curve's argmax sits at the same time.

    This is a Kneip-Gasser-style landmark registration; for the Berkeley
    growth-velocity curves the landmark of interest is the pubertal-spurt
    peak, which lies in the ``search_window`` (default 8-16 years).

    For each curve ``i`` we build a piecewise-linear monotone warping
    ``gamma_i`` that maps ``target_landmark`` to ``peak_i`` (and the domain
    end-points to themselves), then evaluate the curve at ``gamma_i(t)``.

    Returns ``(Y_aligned, gammas, peak_times)``.
    """
    T, N = Y.shape
    win_mask = (t >= search_window[0]) & (t <= search_window[1])
    if not np.any(win_mask):
        raise ValueError("search_window does not overlap t")
    win_idx = np.where(win_mask)[0]
    # Compute peak times within the search window only
    Y_win = Y[win_idx, :]
    peak_idx_local = np.argmax(Y_win, axis=0)
    peak_times = t[win_idx[peak_idx_local]]
    if target_landmark is None:
        target_landmark = float(np.median(peak_times))
    Y_aligned = np.zeros_like(Y)
    gammas = np.zeros_like(Y)
    grid01 = normalise_time(t)
    for i in range(N):
        # Build piecewise-linear gamma:
        # gamma maps (t[0], target_landmark, t[-1]) -> (t[0], peak_times[i], t[-1]).
        # We compute gamma at evaluation points t and then evaluate the curve there.
        if peak_times[i] == target_landmark:
            gamma_t = t.copy()
        else:
            gamma_t = np.empty_like(t)
            mask_left = t <= target_landmark
            mask_right = ~mask_left
            # left segment
            t0, t1 = t[0], target_landmark
            g0, g1 = t[0], peak_times[i]
            denom = max(t1 - t0, 1e-12)
            gamma_t[mask_left] = g0 + (g1 - g0) * (t[mask_left] - t0) / denom
            t0, t1 = target_landmark, t[-1]
            g0, g1 = peak_times[i], t[-1]
            denom = max(t1 - t0, 1e-12)
            gamma_t[mask_right] = g0 + (g1 - g0) * (t[mask_right] - t0) / denom
        Y_aligned[:, i] = np.interp(gamma_t, t, Y[:, i])
        # store gamma in normalised time for the plotting helper
        gammas[:, i] = (gamma_t - t[0]) / (t[-1] - t[0])
    return Y_aligned, gammas, peak_times


def amplitude_phase_variance(
    Y: np.ndarray, Y_aligned: np.ndarray, gammas: np.ndarray, t: np.ndarray
) -> Tuple[float, float, float]:
    """Cumulative cross-sectional variances ``Var({f_i})``, ``Var({~f_i})``,
    ``Var({f_mean . gamma_i})`` -- the trio used in Tucker (2013) Table 1.

    Returns
    -------
    var_orig : float -- original cumulative variance.
    var_amp : float -- amplitude (post-alignment) cumulative variance.
    var_phase : float -- phase variance (mean composed with each gamma).
    """
    from .inner import trapz_weights
    w = trapz_weights(t)
    def cum_var(M: np.ndarray) -> float:
        mu = M.mean(axis=1)
        D = M - mu[:, None]
        v = (D ** 2).mean(axis=1) * (M.shape[1] / max(M.shape[1] - 1, 1))
        return float(np.sum(w * v))
    grid01 = normalise_time(t)
    f_mean = Y_aligned.mean(axis=1)
    M_phase = np.stack(
        [warp_curve(f_mean, gammas[:, i], grid01) for i in range(Y.shape[1])],
        axis=1,
    )
    return cum_var(Y), cum_var(Y_aligned), cum_var(M_phase)

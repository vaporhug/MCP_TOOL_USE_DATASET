"""Matplotlib plotting helpers (each returns ``{"path": ...}``).

Imports matplotlib lazily and uses the non-interactive ``Agg`` backend so the
plots can be produced in headless environments.
"""
from __future__ import annotations

from typing import Dict, Iterable, Sequence
import numpy as np


def _setup_mpl():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    return plt


def plot_sample_curves(
    Y: np.ndarray, t: np.ndarray, group_labels: Sequence[int] | None,
    out_path: str, title: str = "Berkeley growth curves",
    xlabel: str = "age (years)", ylabel: str = "height (cm)",
    legend_labels: Sequence[str] | None = None,
) -> Dict[str, str]:
    """Plot every curve as a thin line, coloured by ``group_labels``.

    Returns ``{"path": out_path}``.
    """
    plt = _setup_mpl()
    fig, ax = plt.subplots(figsize=(7.5, 4.5), dpi=120)
    if group_labels is None:
        group_labels = [0] * Y.shape[1]
    group_labels = list(group_labels)
    cmap = plt.get_cmap("tab10")
    seen = {}
    for i in range(Y.shape[1]):
        g = int(group_labels[i])
        col = cmap(g % 10)
        lab = None
        if legend_labels is not None and g not in seen:
            lab = legend_labels[g]
            seen[g] = True
        ax.plot(t, Y[:, i], color=col, alpha=0.55, linewidth=0.9, label=lab)
    ax.set_title(title)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    if legend_labels is not None:
        ax.legend(loc="lower right", fontsize=8)
    fig.tight_layout()
    fig.savefig(out_path, bbox_inches="tight")
    plt.close(fig)
    return {"path": out_path}


def plot_mean_pm_pcs(
    mu: np.ndarray, phi: np.ndarray, eigvals: np.ndarray, t: np.ndarray,
    out_path: str, n_components: int = 2,
    title: str = "Mean +/- 2 SD x principal modes",
    xlabel: str = "age (years)", ylabel: str = "height (cm)",
) -> Dict[str, str]:
    """Plot the mean curve and ``mu +/- 2 sqrt(lambda_j) phi_j`` for the top components."""
    plt = _setup_mpl()
    fig, axes = plt.subplots(1, n_components, figsize=(4.6 * n_components, 4.0), dpi=120)
    if n_components == 1:
        axes = [axes]
    for j in range(n_components):
        ax = axes[j]
        scale = 2.0 * float(np.sqrt(max(eigvals[j], 0.0)))
        ax.plot(t, mu, color="black", linewidth=2.0, label="mean")
        ax.plot(t, mu + scale * phi[:, j], color="C3", linewidth=1.4,
                label=f"mean + 2 sqrt(lambda_{j+1})")
        ax.plot(t, mu - scale * phi[:, j], color="C0", linewidth=1.4,
                label=f"mean - 2 sqrt(lambda_{j+1})")
        ax.set_title(f"Mode {j + 1}: lambda_{j+1} = {eigvals[j]:.3g}")
        ax.set_xlabel(xlabel)
        if j == 0:
            ax.set_ylabel(ylabel)
        ax.legend(fontsize=8, loc="best")
    fig.suptitle(title, y=1.03)
    fig.tight_layout()
    fig.savefig(out_path, bbox_inches="tight")
    plt.close(fig)
    return {"path": out_path}


def plot_score_scatter(
    scores: np.ndarray, group_labels: Sequence[int],
    legend_labels: Sequence[str], out_path: str,
    title: str = "FPCA score scatter",
) -> Dict[str, str]:
    """Scatter of FPCA scores 1 vs 2 coloured by ``group_labels``."""
    plt = _setup_mpl()
    if scores.shape[1] < 2:
        raise ValueError("need at least 2 score columns to scatter")
    fig, ax = plt.subplots(figsize=(6.0, 5.0), dpi=120)
    cmap = plt.get_cmap("tab10")
    seen = {}
    for i in range(scores.shape[0]):
        g = int(group_labels[i])
        lab = None
        if g not in seen:
            lab = legend_labels[g]
            seen[g] = True
        ax.scatter(scores[i, 0], scores[i, 1], c=[cmap(g % 10)],
                   s=35, alpha=0.85, edgecolors="black", linewidths=0.4,
                   label=lab)
    ax.set_xlabel("FPC 1 score")
    ax.set_ylabel("FPC 2 score")
    ax.set_title(title)
    ax.axhline(0, color="grey", linewidth=0.5)
    ax.axvline(0, color="grey", linewidth=0.5)
    ax.legend(fontsize=9)
    fig.tight_layout()
    fig.savefig(out_path, bbox_inches="tight")
    plt.close(fig)
    return {"path": out_path}


def plot_alignment_pair(
    Y: np.ndarray, Y_aligned: np.ndarray, gammas: np.ndarray, t: np.ndarray,
    out_path: str, title: str = "Phase / amplitude separation",
) -> Dict[str, str]:
    """Three-panel figure: original curves, aligned curves, warpings.

    Mimics Tucker, Wu, Srivastava (2013) Fig. 9 -- the Berkeley growth panel.
    """
    plt = _setup_mpl()
    fig, axes = plt.subplots(1, 3, figsize=(13.0, 4.2), dpi=120)
    grid01 = (t - t[0]) / (t[-1] - t[0])
    cmap = plt.get_cmap("tab20")
    N = Y.shape[1]
    for i in range(N):
        c = cmap(i % 20)
        axes[0].plot(t, Y[:, i], color=c, alpha=0.6, linewidth=0.7)
        axes[1].plot(t, Y_aligned[:, i], color=c, alpha=0.6, linewidth=0.7)
        axes[2].plot(grid01, gammas[:, i], color=c, alpha=0.6, linewidth=0.7)
    axes[0].set_title("original f_i(t)")
    axes[0].set_xlabel("age (years)")
    axes[0].set_ylabel("growth velocity (cm/yr)")
    axes[1].set_title("aligned ~f_i(t)")
    axes[1].set_xlabel("age (years)")
    axes[2].set_title("warpings gamma_i(t)")
    axes[2].set_xlabel("normalised t")
    axes[2].plot([0, 1], [0, 1], color="black", linewidth=0.7, linestyle="--")
    fig.suptitle(title, y=1.02)
    fig.tight_layout()
    fig.savefig(out_path, bbox_inches="tight")
    plt.close(fig)
    return {"path": out_path}


def plot_variance_decomposition(
    var_orig: float, var_amp: float, var_phase: float, out_path: str,
    title: str = "Cumulative variance: original vs amplitude vs phase",
) -> Dict[str, str]:
    """Bar chart of the three variances.  Echo of Tucker (2013) Table 1."""
    plt = _setup_mpl()
    fig, ax = plt.subplots(figsize=(6.0, 4.0), dpi=120)
    cats = ["original", "amplitude", "phase"]
    vals = [var_orig, var_amp, var_phase]
    bars = ax.bar(cats, vals, color=["#777777", "#1f77b4", "#d62728"])
    for b, v in zip(bars, vals):
        ax.text(b.get_x() + b.get_width() / 2, v, f"{v:.3g}",
                ha="center", va="bottom", fontsize=9)
    ax.set_ylabel("integrated cross-sectional variance")
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(out_path, bbox_inches="tight")
    plt.close(fig)
    return {"path": out_path}

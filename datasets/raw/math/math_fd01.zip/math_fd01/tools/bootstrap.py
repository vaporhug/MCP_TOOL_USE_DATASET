"""Bootstrap resampling helpers for FPCA and curve summaries.

The two routines below implement the curve-level bootstrap used in classical
FDA (Hall & Hosseini-Nasab, 2006): sample ``N`` curve indices with
replacement and recompute the FPCA from scratch.  Eigenvalue / eigenfunction
sign flips are handled by anchoring the sign to the original eigenfunction.
"""
from __future__ import annotations

from typing import Callable
import numpy as np


def bootstrap_curve_indices(
    N: int, n_boot: int, rng_seed: int = 0
) -> np.ndarray:
    """Return an ``(n_boot, N)`` integer matrix of resampled column indices."""
    if n_boot < 1:
        raise ValueError("n_boot must be >= 1")
    if N < 1:
        raise ValueError("N must be >= 1")
    rng = np.random.default_rng(rng_seed)
    return rng.integers(0, N, size=(n_boot, N))


def bootstrap_statistic(
    Y: np.ndarray, stat_fn: Callable[[np.ndarray], np.ndarray],
    n_boot: int = 50, rng_seed: int = 0,
) -> np.ndarray:
    """Stack ``n_boot`` evaluations of ``stat_fn(Y[:, idx])``.

    Parameters
    ----------
    Y : (T, N) curve matrix.
    stat_fn : callable mapping ``(T, N')`` to a 1-D array of length ``d``.
    n_boot : number of bootstrap repetitions.
    rng_seed : seed for the bootstrap index generator.

    Returns
    -------
    boot : (n_boot, d) array of the statistic values.
    """
    if Y.ndim != 2:
        raise ValueError("Y must be 2-D")
    N = Y.shape[1]
    idx_mat = bootstrap_curve_indices(N, n_boot, rng_seed=rng_seed)
    rows = []
    for b in range(n_boot):
        sample = Y[:, idx_mat[b]]
        rows.append(np.asarray(stat_fn(sample)).ravel())
    return np.stack(rows, axis=0)


def percentile_ci(
    boot: np.ndarray, alpha: float = 0.05
) -> tuple:
    """Two-sided ``(1 - alpha) * 100`` percent percentile CI per column.

    Returns ``(lo, hi)`` arrays of equal length matching ``boot.shape[1]``.
    """
    if boot.ndim != 2:
        raise ValueError("boot must be 2-D (n_boot, d)")
    lo = np.percentile(boot, 100.0 * alpha / 2.0, axis=0)
    hi = np.percentile(boot, 100.0 * (1.0 - alpha / 2.0), axis=0)
    return lo, hi

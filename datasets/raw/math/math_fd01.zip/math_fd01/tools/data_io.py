"""CSV loaders for the Berkeley growth tables.

The CSVs are wide-format tables with first column ``age_years`` and remaining
columns one curve per subject.
"""
from __future__ import annotations

from typing import Tuple
import csv
import numpy as np


def _read_csv(path: str) -> Tuple[np.ndarray, np.ndarray, list]:
    """Read a wide CSV ``age_years, subj1, subj2, ...`` -> (ages, Y, names).

    Parameters
    ----------
    path : str

    Returns
    -------
    ages : 1-D array of length T (in years)
    Y : 2-D array of shape (T, N) -- column j is curve for subject j
    names : list of length N (subject ids)
    """
    with open(path, "r", newline="") as fh:
        rdr = csv.reader(fh)
        header = next(rdr)
        rows = [row for row in rdr]
    if header[0] != "age_years":
        raise ValueError(f"first column of {path} must be 'age_years'")
    names = list(header[1:])
    ages = np.array([float(r[0]) for r in rows], dtype=float)
    Y = np.array([[float(x) for x in r[1:]] for r in rows], dtype=float)
    return ages, Y, names


def load_girls(path: str) -> Tuple[np.ndarray, np.ndarray, list]:
    """Load Berkeley girls' heights table; returns ``(ages, hgtf, ids)``."""
    return _read_csv(path)


def load_boys(path: str) -> Tuple[np.ndarray, np.ndarray, list]:
    """Load Berkeley boys' heights table; returns ``(ages, hgtm, ids)``."""
    return _read_csv(path)


def load_metadata(path: str) -> Tuple[list, list]:
    """Load subject_metadata.csv -> (subject_ids, sexes).

    Each row has columns ``subject_id, sex``.
    """
    ids: list = []
    sexes: list = []
    with open(path, "r", newline="") as fh:
        rdr = csv.reader(fh)
        header = next(rdr)
        if header != ["subject_id", "sex"]:
            raise ValueError("expected columns subject_id, sex")
        for row in rdr:
            ids.append(row[0])
            sexes.append(row[1])
    return ids, sexes


def stack_curves(Y_list: list) -> np.ndarray:
    """Concatenate several (T, N_g) matrices column-wise into one (T, N).

    All inputs must share the same first axis (same age grid).
    """
    if len(Y_list) == 0:
        raise ValueError("empty input list")
    T = Y_list[0].shape[0]
    for Y in Y_list:
        if Y.shape[0] != T:
            raise ValueError("inconsistent number of time points")
    return np.concatenate(Y_list, axis=1)

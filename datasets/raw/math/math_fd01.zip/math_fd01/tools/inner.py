"""Trapezoid inner product, mean function, and covariance kernel.

All routines treat curves as columns of a (T, N) matrix observed on a common
grid ``t``.
"""
from __future__ import annotations

import numpy as np


def trapz_weights(t: np.ndarray) -> np.ndarray:
    """Trapezoidal-rule integration weights for an arbitrary ascending grid.

    Parameters
    ----------
    t : 1-D array of length T (strictly ascending).

    Returns
    -------
    w : 1-D array of length T with sum ``t[-1] - t[0]``.
    """
    if t.ndim != 1 or len(t) < 2:
        raise ValueError("need at least 2 grid points in t")
    if not np.all(np.diff(t) > 0):
        raise ValueError("t must be strictly ascending")
    dt = np.diff(t)
    w = np.zeros_like(t, dtype=float)
    w[0] = 0.5 * dt[0]
    w[-1] = 0.5 * dt[-1]
    w[1:-1] = 0.5 * (dt[:-1] + dt[1:])
    return w


def inner_product(f: np.ndarray, g: np.ndarray, t: np.ndarray) -> float:
    """``<f, g> = int f g dt`` evaluated on grid ``t`` with trapezoid weights."""
    w = trapz_weights(t)
    return float(np.sum(w * f * g))


def l2_norm(f: np.ndarray, t: np.ndarray) -> float:
    """``\\|f\\|_2 = sqrt(<f, f>)``."""
    val = inner_product(f, f, t)
    return float(np.sqrt(max(val, 0.0)))


def mean_function(Y: np.ndarray) -> np.ndarray:
    """Pointwise mean of the curves in matrix ``Y`` of shape ``(T, N)``."""
    if Y.ndim != 2:
        raise ValueError("Y must be 2-D")
    return Y.mean(axis=1)


def center_curves(Y: np.ndarray) -> np.ndarray:
    """Subtract the pointwise mean from every column of ``Y``."""
    mu = mean_function(Y)
    return Y - mu[:, None]


def covariance_kernel(Y: np.ndarray) -> np.ndarray:
    """Sample covariance kernel ``C(s, t)``.

    Parameters
    ----------
    Y : ``(T, N)`` matrix of curves.

    Returns
    -------
    C : ``(T, T)`` symmetric matrix with
        ``C[s, t] = (1/(N-1)) sum_i (Y[s,i] - mean[s]) (Y[t,i] - mean[t])``.
    """
    Yc = center_curves(Y)
    N = Y.shape[1]
    if N < 2:
        raise ValueError("need at least 2 curves for covariance")
    return (Yc @ Yc.T) / (N - 1)


def total_variance(Y: np.ndarray, t: np.ndarray) -> float:
    """``int Var{Y(t)} dt`` as the trace of the covariance kernel weighted by ``w``.

    Equals the sum of FPCA eigenvalues.
    """
    C = covariance_kernel(Y)
    w = trapz_weights(t)
    return float(np.sum(w * np.diag(C)))


def cumulative_variance(Y: np.ndarray, t: np.ndarray) -> np.ndarray:
    """Return the pointwise variance function (length ``T``)."""
    C = covariance_kernel(Y)
    return np.diag(C).copy()

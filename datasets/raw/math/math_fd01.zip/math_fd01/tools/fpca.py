"""Functional PCA via covariance-kernel eigendecomposition.

Implements the standard cross-sectional FPCA used by Tucker, Wu, Srivastava
(2013) on the Berkeley growth data set.

Two flavours are provided:

- :func:`fpca_eigendecomp` : raw eigendecomposition of the sample covariance
  matrix on the discrete grid (consistent estimator under dense observation).
- :func:`fpca_with_weights` : same but using trapezoid-weight scaling so that
  the eigenfunctions are orthonormal in the L2-inner-product sense
  ``<phi_i, phi_j> = delta_ij``.
"""
from __future__ import annotations

from typing import Tuple
import numpy as np

from .inner import covariance_kernel, mean_function, trapz_weights


def fpca_eigendecomp(Y: np.ndarray, k: int) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Plain eigendecomposition of ``cov(Y)`` -- no integration weights.

    Parameters
    ----------
    Y : (T, N) matrix.
    k : number of components to retain (k <= T).

    Returns
    -------
    eigvals : 1-D length-k (descending), in cov-of-grid units.
    eigvecs : (T, k) eigenvectors of the (T, T) covariance matrix.
    mu : (T,) pointwise mean.
    """
    if k < 1:
        raise ValueError("k must be at least 1")
    if k > Y.shape[0]:
        raise ValueError("k cannot exceed grid size")
    mu = mean_function(Y)
    C = covariance_kernel(Y)
    w_, V = np.linalg.eigh(C)
    idx = np.argsort(w_)[::-1]
    w_ = w_[idx]
    V = V[:, idx]
    return w_[:k].copy(), V[:, :k].copy(), mu


def fpca_with_weights(
    Y: np.ndarray, t: np.ndarray, k: int
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """L2-orthonormal FPCA via the symmetric eigenproblem ``W^{1/2} C W^{1/2}``.

    Returns ``(eigvals, phi, mu)`` where ``phi`` are L2-orthonormal
    eigenfunctions evaluated on the input grid.
    """
    if k < 1:
        raise ValueError("k must be at least 1")
    mu = mean_function(Y)
    C = covariance_kernel(Y)
    w = trapz_weights(t)
    w_sqrt = np.sqrt(w)
    M = (w_sqrt[:, None] * C) * w_sqrt[None, :]
    eig_w, eig_v = np.linalg.eigh(M)
    idx = np.argsort(eig_w)[::-1]
    eig_w = eig_w[idx]
    eig_v = eig_v[:, idx]
    eigvals = eig_w[:k].copy()
    phi = eig_v[:, :k] / w_sqrt[:, None]
    # enforce sign convention: max abs entry positive
    for j in range(k):
        m = int(np.argmax(np.abs(phi[:, j])))
        if phi[m, j] < 0:
            phi[:, j] *= -1.0
    return eigvals, phi, mu


def fpca_scores(
    Y: np.ndarray, phi: np.ndarray, mu: np.ndarray, t: np.ndarray
) -> np.ndarray:
    """Compute FPCA scores ``xi_{i,j} = <Y_i - mu, phi_j>``.

    Returns
    -------
    Xi : (N, k) matrix of scores.
    """
    w = trapz_weights(t)
    Yc = Y - mu[:, None]
    # weighted inner products
    Xi = (phi * w[:, None]).T @ Yc
    return Xi.T  # (N, k)


def variance_explained(eigvals: np.ndarray) -> np.ndarray:
    """Cumulative fraction of variance explained by leading ``k`` eigenvalues."""
    eigvals = np.asarray(eigvals, dtype=float)
    eigvals = np.maximum(eigvals, 0.0)
    total = float(np.sum(eigvals))
    if total <= 0.0:
        return np.zeros_like(eigvals)
    return np.cumsum(eigvals) / total


def reconstruct_from_scores(
    scores: np.ndarray, phi: np.ndarray, mu: np.ndarray
) -> np.ndarray:
    """Invert the truncated KL expansion to obtain ``Y_hat`` (T, N)."""
    return mu[:, None] + phi @ scores.T

"""Roughness-penalty matrix and penalized least-squares smoother.

We use a finite-difference second-derivative penalty on basis coefficients;
this is asymptotically equivalent to the integrated-second-derivative penalty
of classical functional smoothing splines and avoids any scipy dependency.

For coefficients ``c \\in R^p`` the penalty is

    J(c) = c^T D2^T D2 c

where ``D2`` is the (p-2) x p second-difference matrix, so the smoother solves

    min_c || y - Phi c ||^2 + lambda * J(c).
"""
from __future__ import annotations

from typing import Tuple
import numpy as np


def diff_matrix(p: int, order: int = 2) -> np.ndarray:
    """``order``-th difference operator on a length-``p`` vector.

    Returns an ``(p - order) x p`` matrix ``D`` with ``D c`` equal to the
    ``order``-th finite differences of ``c``.
    """
    if order < 0:
        raise ValueError("order must be non-negative")
    if p <= order:
        raise ValueError("p must exceed order")
    D = np.eye(p)
    for _ in range(order):
        D = np.diff(D, n=1, axis=0)
    return D


def penalty_matrix(p: int, order: int = 2) -> np.ndarray:
    """The ``D^T D`` Gram matrix of finite differences (size ``p x p``)."""
    D = diff_matrix(p, order)
    return D.T @ D


def smooth_curve(
    y: np.ndarray, Phi: np.ndarray, R: np.ndarray, lam: float
) -> np.ndarray:
    """Solve ``(Phi^T Phi + lam R) c = Phi^T y`` via numpy.linalg.solve.

    Parameters
    ----------
    y : 1-D array of length T (one observed curve)
    Phi : design matrix of shape (T, p)
    R : penalty matrix of shape (p, p)
    lam : non-negative penalty strength

    Returns
    -------
    c : coefficient vector of length p.
    """
    if lam < 0.0:
        raise ValueError("lam must be non-negative")
    A = Phi.T @ Phi + lam * R
    b = Phi.T @ y
    c = np.linalg.solve(A, b)
    return c


def smooth_matrix(
    Y: np.ndarray, Phi: np.ndarray, R: np.ndarray, lam: float
) -> np.ndarray:
    """Smooth every column of ``Y`` (shape ``(T, N)``) -> coefficients ``(p, N)``."""
    p = Phi.shape[1]
    N = Y.shape[1]
    A = Phi.T @ Phi + lam * R
    B = Phi.T @ Y
    C = np.linalg.solve(A, B)
    if C.shape != (p, N):
        raise RuntimeError("internal smoother shape error")
    return C


def reconstruct(C: np.ndarray, Phi: np.ndarray) -> np.ndarray:
    """Evaluate smoothed curves on a grid: ``Phi @ C``  -> ``(T, N)``."""
    return Phi @ C


def gcv_score(
    y: np.ndarray, Phi: np.ndarray, R: np.ndarray, lam: float
) -> float:
    """Generalised cross-validation criterion for a single curve.

    Lower is better.  Returns ``RSS / (T (1 - tr(H) / T))^2`` where ``H`` is the
    smoother hat matrix at the chosen ``lam``.
    """
    T = Phi.shape[0]
    A = Phi.T @ Phi + lam * R
    A_inv = np.linalg.inv(A)
    H = Phi @ A_inv @ Phi.T
    yhat = H @ y
    res = y - yhat
    rss = float(res @ res)
    df = float(np.trace(H))
    denom = T * (1.0 - df / T) ** 2
    if denom <= 0.0:
        return float("inf")
    return rss / denom


def find_lambda_gcv(
    y: np.ndarray, Phi: np.ndarray, R: np.ndarray, lam_grid: np.ndarray
) -> Tuple[float, np.ndarray]:
    """Pick best ``lam`` from a grid by minimising GCV; returns ``(lam, scores)``."""
    if len(lam_grid) == 0:
        raise ValueError("lam_grid must be non-empty")
    scores = np.array([gcv_score(y, Phi, R, float(l)) for l in lam_grid])
    j = int(np.argmin(scores))
    return float(lam_grid[j]), scores

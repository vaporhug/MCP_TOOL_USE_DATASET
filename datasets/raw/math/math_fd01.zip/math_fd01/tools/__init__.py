"""Functional data analysis tools (pure-numpy + matplotlib).

Implements primitives needed to reproduce the Berkeley-growth section of
Tucker, Wu, Srivastava (2013), Computational Statistics and Data Analysis
61:50-66, "Generative Models for Functional Data using Phase and Amplitude
Separation".

No sklearn / scipy is required from caller code -- linear algebra goes
through numpy.linalg.  The package exposes the modules:

- data_io     CSV loaders for the Berkeley growth tables
- bspline     equally-knotted B-spline basis and design matrix
- smooth      roughness-penalty matrix and penalised least-squares smoother
- inner       trapezoid inner-product / norm / mean-function / covariance
- fpca        covariance eigendecomp + scoring
- align       SRSF transform + uniform-time-warp alignment (dynamic prog.)
- regression  scalar-on-function regression with basis truncation
- bootstrap   sample-with-replacement helper for FPCA bootstrap CIs
- cluster     functional k-means clustering on curve matrix
- plots       four matplotlib plotters (each returns {"path": ...})
"""

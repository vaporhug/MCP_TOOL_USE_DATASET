"""Cardinal cubic B-spline basis built from de Boor's recurrence.

Pure numpy implementation -- nothing imported from scipy.

A B-spline basis of order ``k`` (degree ``k-1``) on the closed interval
``[t_min, t_max]`` with ``n_int`` interior knots produces ``n_basis = n_int + k``
basis functions.  This module provides

- :func:`make_knots` : open-uniform knot sequence with ``k`` repeated boundary
  knots,
- :func:`bspline_basis` : evaluate every basis function at every grid point,
- :func:`design_matrix` : the same evaluations packaged as ``(T, n_basis)``,
- :func:`fourier_basis` : trigonometric basis as a Berkeley-friendly
  alternative.
"""
from __future__ import annotations

from typing import Tuple
import numpy as np


def make_knots(t_min: float, t_max: float, n_int: int, k: int = 4) -> np.ndarray:
    """Open-uniform knot sequence with ``k`` repeats at each end.

    Parameters
    ----------
    t_min, t_max : float
        Domain end-points.
    n_int : int
        Number of *interior* knots (>= 0).
    k : int
        Spline order (degree + 1).  Default cubic ``k=4``.

    Returns
    -------
    knots : 1-D array of length ``n_int + 2 k``.
    """
    if n_int < 0:
        raise ValueError("n_int must be non-negative")
    if k < 1:
        raise ValueError("order k must be at least 1")
    if t_max <= t_min:
        raise ValueError("require t_max > t_min")
    if n_int == 0:
        interior = np.empty(0, dtype=float)
    else:
        interior = np.linspace(t_min, t_max, n_int + 2)[1:-1]
    return np.concatenate(
        [np.full(k, t_min), interior, np.full(k, t_max)]
    )


def _basis_value(t: float, i: int, k: int, knots: np.ndarray) -> float:
    """Evaluate B-spline ``B_{i,k}(t)`` from de Boor's recurrence."""
    if k == 1:
        # right-closed at the very last knot to keep continuity at t_max
        if knots[i] <= t < knots[i + 1]:
            return 1.0
        if t == knots[-1] and i == len(knots) - 2:
            return 1.0
        return 0.0
    left = 0.0
    denom_l = knots[i + k - 1] - knots[i]
    if denom_l > 0.0:
        left = (t - knots[i]) / denom_l * _basis_value(t, i, k - 1, knots)
    right = 0.0
    denom_r = knots[i + k] - knots[i + 1]
    if denom_r > 0.0:
        right = (knots[i + k] - t) / denom_r * _basis_value(
            t, i + 1, k - 1, knots
        )
    return left + right


def bspline_basis(
    t_grid: np.ndarray, knots: np.ndarray, k: int = 4
) -> np.ndarray:
    """Evaluate every cubic B-spline basis function at every ``t_grid`` point.

    Parameters
    ----------
    t_grid : 1-D array of length T
    knots : 1-D array as produced by :func:`make_knots`
    k : spline order (degree + 1)

    Returns
    -------
    Phi : ``(T, n_basis)`` design matrix where ``n_basis = len(knots) - k``.
    """
    n_basis = len(knots) - k
    if n_basis <= 0:
        raise ValueError("len(knots) - k must be positive")
    T = len(t_grid)
    Phi = np.zeros((T, n_basis), dtype=float)
    eps = 1e-12 * (knots[-1] - knots[0])
    t_right_edge = knots[-1]
    for j in range(T):
        t = float(t_grid[j])
        # nudge points exactly at the right boundary inside the support so that
        # the half-open B_{i,1} indicators evaluate correctly.
        if t >= t_right_edge:
            t = t_right_edge - eps
        for i in range(n_basis):
            Phi[j, i] = _basis_value(t, i, k, knots)
    return Phi


def design_matrix(
    t_grid: np.ndarray, n_int: int, k: int = 4,
    t_min: float | None = None, t_max: float | None = None,
) -> Tuple[np.ndarray, np.ndarray]:
    """Convenience wrapper -> ``(Phi, knots)``.

    The returned ``Phi`` has shape ``(len(t_grid), n_int + k)``.
    """
    if t_min is None:
        t_min = float(np.min(t_grid))
    if t_max is None:
        t_max = float(np.max(t_grid))
    knots = make_knots(t_min, t_max, n_int, k)
    Phi = bspline_basis(t_grid, knots, k)
    return Phi, knots


def fourier_basis(t_grid: np.ndarray, n_basis: int) -> np.ndarray:
    """Real Fourier basis on ``[t_min, t_max]`` with constant + sin/cos pairs.

    ``n_basis`` should be odd; if even, one sine column is dropped to keep the
    basis well-conditioned.

    Returns
    -------
    Phi : ``(T, n_basis)`` matrix.  Column 0 is constant, columns 1, 3, 5, ...
        are sines and columns 2, 4, 6, ... are cosines.
    """
    if n_basis < 1:
        raise ValueError("n_basis must be >= 1")
    t_min = float(np.min(t_grid))
    t_max = float(np.max(t_grid))
    L = t_max - t_min
    if L <= 0:
        raise ValueError("require t_max > t_min")
    T = len(t_grid)
    Phi = np.zeros((T, n_basis), dtype=float)
    Phi[:, 0] = 1.0 / np.sqrt(L)
    s = np.asarray(t_grid, dtype=float) - t_min
    for j in range(1, n_basis):
        m = (j + 1) // 2
        if j % 2 == 1:
            Phi[:, j] = np.sqrt(2.0 / L) * np.sin(2.0 * np.pi * m * s / L)
        else:
            Phi[:, j] = np.sqrt(2.0 / L) * np.cos(2.0 * np.pi * m * s / L)
    return Phi

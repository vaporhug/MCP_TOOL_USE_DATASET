"""Approximate Bayesian Computation primitives for the deterministic SIR
case study of Minter & Retkute (2019), Epidemics, "Approximate Bayesian
Computation for infectious disease modelling".

Modules
-------
data_io       CSV loaders for observed epidemic and prior table.
sir_model     Forward simulator: deterministic SIR ODE solved with RK4.
summaries     Summary statistics (final size, peak, peak day, etc.).
distance      Distance functions used for ABC acceptance criteria.
priors        Sampling and density evaluation for the prior distributions.
abc_rejection ABC-rejection sampler driven by user-supplied callbacks.
abc_smc       ABC-SMC sampler with adaptive tolerance and uniform kernel.
posterior     Posterior summaries: mean, sd, credible intervals, ESS.
plots         Four matplotlib plotters (each returns ``{"path": ...}``).

Pure numpy + matplotlib only -- no scipy.stats, no sklearn.
"""

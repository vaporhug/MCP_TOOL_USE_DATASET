"""Posterior summaries: weighted moments, credible intervals, derived quantities.

All routines accept particle arrays + weight arrays, where the weights are
1-D, non-negative and either sum to ``n_particles`` (rejection) or to 1
(SMC).  They are renormalised internally, so the caller does not need to
worry about which convention applies.
"""
from __future__ import annotations

from typing import Tuple
import numpy as np


def _normalise(w: np.ndarray) -> np.ndarray:
    w = np.asarray(w, dtype=float)
    s = w.sum()
    if s <= 0:
        raise ValueError("non-positive weight sum")
    return w / s


def weighted_mean(particles_1d: np.ndarray, weights: np.ndarray) -> float:
    """Weighted mean of a 1-D parameter sample.

    Equivalent to ``numpy.average(particles_1d, weights=weights)``.
    """
    w = _normalise(weights)
    x = np.asarray(particles_1d, dtype=float).ravel()
    if x.shape != w.shape:
        raise ValueError("shape mismatch")
    return float(np.sum(x * w))


def weighted_std(particles_1d: np.ndarray, weights: np.ndarray) -> float:
    """Weighted standard deviation (population definition, no N/(N-1) correction)."""
    w = _normalise(weights)
    x = np.asarray(particles_1d, dtype=float).ravel()
    m = float(np.sum(x * w))
    var = float(np.sum(w * (x - m) ** 2))
    return float(np.sqrt(max(var, 0.0)))


def weighted_quantile(particles_1d: np.ndarray, weights: np.ndarray, q: float) -> float:
    """Type-7 weighted quantile of a 1-D sample.

    Sorts the values, accumulates the (normalised) weights, and linearly
    interpolates at ``q``.  Mirrors the behaviour of R's
    ``Hmisc::wtd.quantile(type='i/n')`` in the limit of equal weights.
    """
    if not 0.0 <= q <= 1.0:
        raise ValueError("q must be in [0, 1]")
    x = np.asarray(particles_1d, dtype=float).ravel()
    w = _normalise(np.asarray(weights, dtype=float).ravel())
    order = np.argsort(x)
    xs = x[order]
    ws = w[order]
    cum = np.cumsum(ws) - 0.5 * ws  # mid-rank positions
    if q <= cum[0]:
        return float(xs[0])
    if q >= cum[-1]:
        return float(xs[-1])
    return float(np.interp(q, cum, xs))


def credible_interval(particles_1d: np.ndarray, weights: np.ndarray, level: float = 0.95) -> Tuple[float, float]:
    """Equal-tailed weighted credible interval at the given coverage level."""
    if not 0.0 < level < 1.0:
        raise ValueError("level must be strictly between 0 and 1")
    alpha = (1.0 - level) / 2.0
    lo = weighted_quantile(particles_1d, weights, alpha)
    hi = weighted_quantile(particles_1d, weights, 1.0 - alpha)
    return lo, hi


def posterior_table(particles: np.ndarray, names: list, weights: np.ndarray, level: float = 0.95) -> dict:
    """Build a dict ``{name: {mean, sd, q025, median, q975}}`` over all parameters."""
    out: dict = {}
    n = particles.shape[1]
    if len(names) != n:
        raise ValueError("len(names) must equal particles.shape[1]")
    for j, nm in enumerate(names):
        col = particles[:, j]
        out[nm] = {
            "mean": weighted_mean(col, weights),
            "sd": weighted_std(col, weights),
            "median": weighted_quantile(col, weights, 0.5),
            "ci_low": weighted_quantile(col, weights, (1 - level) / 2),
            "ci_high": weighted_quantile(col, weights, 1 - (1 - level) / 2),
        }
    return out


def derived_R0(particles: np.ndarray, names: list) -> np.ndarray:
    """Compute R0 = beta / gamma for each particle row."""
    if "beta" not in names or "gamma" not in names:
        raise ValueError("particles must contain beta and gamma columns")
    b = particles[:, names.index("beta")]
    g = particles[:, names.index("gamma")]
    return b / g

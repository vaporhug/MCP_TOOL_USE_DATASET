"""ABC-rejection sampler.

Implements the algorithm of Pritchard et al. (1999) / Beaumont et al. (2002)
exactly as written in Section 2 of Minter & Retkute (2019):

    repeat
        theta* ~ prior
        D*    = simulate(theta*)
        if d(D, D*) <= epsilon: accept theta*
    until N particles accepted

The user supplies the simulator and distance via callbacks so the same
sampler works for all three Case-Study-1 configurations (full-trajectory,
final-size only, two-summary).
"""
from __future__ import annotations

from typing import Callable, Dict, List
import numpy as np


def abc_rejection(
    prior_sampler: Callable[[np.random.Generator], Dict[str, float]],
    simulator: Callable[[Dict[str, float]], np.ndarray],
    distance: Callable[[np.ndarray], float],
    epsilon: float,
    n_accept: int,
    rng: np.random.Generator,
    max_iter: int = 2_000_000,
) -> Dict[str, np.ndarray]:
    """Run ABC-rejection until ``n_accept`` particles are accepted.

    Parameters
    ----------
    prior_sampler : callable rng -> dict
        Returns one parameter dict (for example ``{"S0": 100, "beta": 1.5,
        "gamma": 0.5}``).
    simulator : callable theta -> array
        Returns the simulated dataset given a parameter dict.
    distance : callable D_sim -> float
        Returns the distance between the simulated dataset and the (fixed)
        observed dataset.  The observed data is captured by the caller.
    epsilon : float
        Acceptance threshold.
    n_accept : int
        Desired number of accepted particles.
    rng : numpy Generator
    max_iter : int, optional
        Hard cap on proposals (raises ``RuntimeError`` if exceeded).

    Returns
    -------
    out : dict with keys
        - ``particles`` (n_accept, n_par) ndarray
        - ``names``     list[str] -- column names of ``particles``
        - ``distances`` (n_accept,) ndarray
        - ``n_proposed`` int
        - ``n_accepted`` int
        - ``acceptance_rate`` float
        - ``epsilon``   float
    """
    if epsilon <= 0:
        raise ValueError("epsilon must be positive")
    if n_accept <= 0:
        raise ValueError("n_accept must be positive")
    accepted: List[Dict[str, float]] = []
    dists: List[float] = []
    n_proposed = 0
    while len(accepted) < n_accept:
        if n_proposed >= max_iter:
            raise RuntimeError(
                f"abc_rejection exceeded max_iter={max_iter} with only "
                f"{len(accepted)} / {n_accept} accepted"
            )
        n_proposed += 1
        theta = prior_sampler(rng)
        D_sim = simulator(theta)
        d = distance(D_sim)
        if d <= epsilon:
            accepted.append(theta)
            dists.append(d)
    names = list(accepted[0].keys())
    arr = np.array([[a[k] for k in names] for a in accepted], dtype=float)
    return {
        "particles": arr,
        "names": names,
        "distances": np.asarray(dists, dtype=float),
        "n_proposed": n_proposed,
        "n_accepted": len(accepted),
        "acceptance_rate": float(len(accepted)) / float(n_proposed),
        "epsilon": float(epsilon),
    }

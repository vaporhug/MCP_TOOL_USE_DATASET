"""Prior sampling and density evaluation.

The Case Study 1 prior is::

    S0    ~ Poisson(100)
    beta  ~ Uniform(0, 3)
    gamma ~ Uniform(0, 1)

This module exposes both samplers (``sample_*``) and density evaluators
(``log_prior_*``).  The samplers wrap ``numpy.random.Generator`` so the user
can reproduce a run by passing ``np.random.default_rng(seed)``.  No
``scipy.stats`` is required.
"""
from __future__ import annotations

from typing import Dict, Tuple
import math
import numpy as np


def sample_uniform(low: float, high: float, rng: np.random.Generator) -> float:
    """Draw one float from ``Uniform(low, high)`` using ``rng``."""
    return float(rng.uniform(low, high))


def log_uniform(x: float, low: float, high: float) -> float:
    """Log-density of ``Uniform(low, high)`` evaluated at ``x``.

    Returns ``-inf`` outside the support.
    """
    if x < low or x > high:
        return -math.inf
    if high <= low:
        raise ValueError("require high > low")
    return -math.log(high - low)


def sample_poisson(mean: float, rng: np.random.Generator) -> int:
    """Draw one integer from ``Poisson(mean)`` using ``rng``."""
    return int(rng.poisson(mean))


def log_poisson(k: int, mean: float) -> float:
    """Log-PMF of ``Poisson(mean)`` evaluated at integer ``k``.

    Computed in log-space using ``math.lgamma`` so it is stable for the
    means around 100 used in the paper.
    """
    if k < 0:
        return -math.inf
    if mean <= 0:
        return -math.inf if k != 0 else 0.0
    return float(k * math.log(mean) - mean - math.lgamma(k + 1))


def sample_prior_sir(prior_table: Dict[str, Dict[str, object]], rng: np.random.Generator) -> Dict[str, float]:
    """Sample one ``(S0, beta, gamma)`` triple from the joint prior.

    ``prior_table`` is the dict returned by :func:`tools.data_io.load_priors`.
    The function is generic over the ordering of rows -- it keys on the
    parameter name.
    """
    out: Dict[str, float] = {}
    for name, spec in prior_table.items():
        dist = spec["distribution"]
        a1 = spec["arg1"]
        a2 = spec["arg2"]
        if dist == "uniform":
            out[name] = sample_uniform(float(a1), float(a2), rng)
        elif dist == "poisson":
            out[name] = float(sample_poisson(float(a1), rng))
        else:
            raise ValueError(f"unknown distribution: {dist!r}")
    return out


def log_prior_sir(theta: Dict[str, float], prior_table: Dict[str, Dict[str, object]]) -> float:
    """Log joint prior density at parameter dict ``theta``."""
    lp = 0.0
    for name, spec in prior_table.items():
        x = theta[name]
        dist = spec["distribution"]
        a1 = spec["arg1"]
        a2 = spec["arg2"]
        if dist == "uniform":
            lp += log_uniform(float(x), float(a1), float(a2))
        elif dist == "poisson":
            lp += log_poisson(int(round(float(x))), float(a1))
        else:
            raise ValueError(f"unknown distribution: {dist!r}")
    return lp


def prior_bounds(prior_table: Dict[str, Dict[str, object]]) -> Dict[str, Tuple[float, float]]:
    """Return per-parameter ``(low, high)`` bounds for plotting / kernels."""
    out: Dict[str, Tuple[float, float]] = {}
    for name, spec in prior_table.items():
        dist = spec["distribution"]
        if dist == "uniform":
            out[name] = (float(spec["arg1"]), float(spec["arg2"]))
        elif dist == "poisson":
            mean = float(spec["arg1"])
            # plot range +/- 5 sd for the Poisson, clamped at 0
            sd = math.sqrt(mean)
            out[name] = (max(0.0, mean - 5 * sd), mean + 5 * sd)
        else:
            raise ValueError(f"unknown distribution: {dist!r}")
    return out

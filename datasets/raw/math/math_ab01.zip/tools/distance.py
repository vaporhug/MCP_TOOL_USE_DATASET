"""Distance functions used as the ABC acceptance criterion.

Implements the three distances from Table 1 of Minter & Retkute (2019)
Case Study 1, plus a generic Euclidean distance and a normalised
componentwise Euclidean for multi-summary problems.
"""
from __future__ import annotations

from typing import Sequence
import numpy as np


def euclidean(a: Sequence[float], b: Sequence[float]) -> float:
    """Square-root of the sum of squared differences between two vectors.

    ``d(a, b) = sqrt(sum_i (a_i - b_i)^2)``.  Length 1 inputs reduce to the
    absolute difference -- this matches both ``calc_distance`` and
    ``calc_distance_final_size`` in the paper's R reference code.
    """
    a = np.asarray(a, dtype=float).ravel()
    b = np.asarray(b, dtype=float).ravel()
    if a.shape != b.shape:
        raise ValueError(f"shape mismatch: {a.shape} vs {b.shape}")
    return float(np.sqrt(np.sum((a - b) ** 2)))


def trajectory_distance(I_obs: np.ndarray, R_obs: np.ndarray, I_sim: np.ndarray, R_sim: np.ndarray) -> float:
    """Algorithm-1 distance: ``sqrt(sum((I-I*)^2)) + sqrt(sum((R-R*)^2))``.

    This is the additive form used in the reference R script
    (``distance <- calc_distance(D$I, D_star$I) + calc_distance(D$R, D_star$R)``)
    and is the form quoted as Table 1 line 1 of Minter & Retkute (2019).
    """
    return euclidean(I_obs, I_sim) + euclidean(R_obs, R_sim)


def final_size_distance(R_obs_final: float, R_sim_final: float) -> float:
    """Algorithm-2 distance: absolute difference of the final recovered count.

    ``sqrt((R_T - R_T*)^2) = |R_T - R_T*|``.
    """
    return float(np.sqrt((float(R_obs_final) - float(R_sim_final)) ** 2))


def two_summary_distance(
    R_obs_final: float, I_obs_final: float, R_sim_final: float, I_sim_final: float
) -> float:
    """Algorithm-3 distance: combined final-size + final-infected distance.

    ``sqrt((R_T - R_T*)^2) + sqrt((I_T - I_T*)^2)``.  Same additive form as
    algorithm 1 but on two scalar summaries instead of two trajectories.
    """
    return final_size_distance(R_obs_final, R_sim_final) + final_size_distance(
        I_obs_final, I_sim_final
    )


def normalised_euclidean(a: Sequence[float], b: Sequence[float], scales: Sequence[float]) -> float:
    """Component-wise normalised Euclidean distance.

    ``d = sqrt(sum_i ((a_i - b_i) / scales_i)^2)``.  Useful when the
    summary statistics are on very different scales (e.g. final size in
    hundreds vs peak day in days).
    """
    a = np.asarray(a, dtype=float).ravel()
    b = np.asarray(b, dtype=float).ravel()
    s = np.asarray(scales, dtype=float).ravel()
    if not (a.shape == b.shape == s.shape):
        raise ValueError("a, b, scales must share shape")
    if np.any(s == 0):
        raise ValueError("scales must be strictly positive")
    return float(np.sqrt(np.sum(((a - b) / s) ** 2)))

"""ABC Sequential Monte Carlo sampler with adaptive tolerance.

Implements the canonical Toni et al. (2009) / Beaumont (2010) ABC-SMC
algorithm with a uniform perturbation kernel, as cited in section 2.2 of
Minter & Retkute (2019).  Uses a quantile-of-distances rule to update the
tolerance when the user does not supply an explicit schedule.
"""
from __future__ import annotations

from typing import Callable, Dict, List, Optional, Sequence
import math
import numpy as np


def _systematic_resample(weights: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    """Systematic resampling indices for a weight vector."""
    n = len(weights)
    positions = (rng.uniform(0.0, 1.0) + np.arange(n)) / n
    indexes = np.zeros(n, dtype=int)
    cumulative = np.cumsum(weights)
    cumulative[-1] = 1.0
    i = j = 0
    while i < n:
        if positions[i] < cumulative[j]:
            indexes[i] = j
            i += 1
        else:
            j += 1
    return indexes


def _perturb_uniform(theta: np.ndarray, half_widths: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    """Uniform-kernel perturbation centred at ``theta`` with widths ``half_widths``."""
    return theta + rng.uniform(-1.0, 1.0, size=theta.shape) * half_widths


def _kernel_density_uniform(theta_new: np.ndarray, theta_old: np.ndarray, half_widths: np.ndarray) -> float:
    """Density of independent uniform kernels (product over coordinates)."""
    diffs = np.abs(theta_new - theta_old)
    if np.any(diffs > half_widths):
        return 0.0
    return float(np.prod(1.0 / (2.0 * half_widths)))


def effective_sample_size(weights: np.ndarray) -> float:
    """ESS = ``1 / sum(w_i^2)`` for normalised weights ``w_i``."""
    w = np.asarray(weights, dtype=float)
    return float(1.0 / np.sum(w * w))


def abc_smc(
    prior_sampler: Callable[[np.random.Generator], Dict[str, float]],
    log_prior: Callable[[Dict[str, float]], float],
    simulator: Callable[[Dict[str, float]], np.ndarray],
    distance: Callable[[np.ndarray], float],
    n_particles: int,
    n_generations: int,
    rng: np.random.Generator,
    epsilon_schedule: Optional[Sequence[float]] = None,
    quantile: float = 0.5,
    max_iter_per_gen: int = 1_000_000,
) -> Dict[str, object]:
    """Run an ABC-SMC sampler with a uniform perturbation kernel.

    Parameters
    ----------
    prior_sampler, log_prior, simulator, distance
        Same callback contract as :func:`abc_rejection.abc_rejection`, plus
        ``log_prior(theta)`` returning the joint log-density at ``theta``.
    n_particles : int
        Number of particles per generation.
    n_generations : int
        Number of generations (incl. the initial one).
    rng : numpy Generator
    epsilon_schedule : sequence of floats, optional
        If supplied, list of length ``n_generations`` of decreasing
        tolerances.  If omitted, the tolerance for generation g >= 1 is
        the ``quantile``-th quantile of the distances accepted in
        generation g-1.
    quantile : float, default 0.5
        Quantile used by the adaptive scheme.
    max_iter_per_gen : int, optional

    Returns
    -------
    out : dict with keys
        - ``particles`` list of length ``n_generations`` of
          ``(n_particles, n_par)`` arrays.
        - ``weights``   list of length ``n_generations`` of ``(n_particles,)``
          arrays summing to 1.
        - ``names``     list[str]
        - ``epsilons``  list of float of length ``n_generations``
        - ``ess``       list of float of length ``n_generations``
        - ``n_proposed`` list of int per generation
        - ``acceptance_rate`` list of float per generation
    """
    if n_particles <= 0 or n_generations <= 0:
        raise ValueError("n_particles and n_generations must be positive")
    if epsilon_schedule is not None and len(epsilon_schedule) != n_generations:
        raise ValueError("epsilon_schedule must have length n_generations")

    # ---- generation 1: rejection with infinite tolerance just to seed ----
    # In Toni 2009 the first generation is plain prior + simulator + accept
    # if distance <= eps_1.  We accept any if no schedule is supplied.
    particles_history: List[np.ndarray] = []
    weights_history: List[np.ndarray] = []
    eps_history: List[float] = []
    proposed_history: List[int] = []
    rate_history: List[float] = []
    ess_history: List[float] = []

    # gen 1
    eps1 = epsilon_schedule[0] if epsilon_schedule is not None else math.inf
    accepted: List[Dict[str, float]] = []
    dists: List[float] = []
    n_proposed = 0
    while len(accepted) < n_particles:
        if n_proposed >= max_iter_per_gen:
            raise RuntimeError(
                f"gen 1 exceeded max_iter={max_iter_per_gen}; only "
                f"{len(accepted)} accepted"
            )
        n_proposed += 1
        theta = prior_sampler(rng)
        d = distance(simulator(theta))
        if d <= eps1:
            accepted.append(theta)
            dists.append(d)
    names = list(accepted[0].keys())
    arr = np.array([[a[k] for k in names] for a in accepted], dtype=float)
    weights = np.full(n_particles, 1.0 / n_particles)
    particles_history.append(arr)
    weights_history.append(weights.copy())
    eps_history.append(float(eps1) if math.isfinite(eps1) else float(np.max(dists)))
    proposed_history.append(n_proposed)
    rate_history.append(float(n_particles) / float(n_proposed))
    ess_history.append(effective_sample_size(weights))

    # ---- subsequent generations ----
    for g in range(1, n_generations):
        # tolerance for this generation
        if epsilon_schedule is not None:
            eps_g = float(epsilon_schedule[g])
        else:
            eps_g = float(np.quantile(np.asarray(dists), quantile))
        prev_arr = particles_history[-1]
        prev_w = weights_history[-1]
        # half-width of uniform kernel = 0.5 * range of previous particles
        half_widths = 0.5 * (prev_arr.max(axis=0) - prev_arr.min(axis=0))
        # Avoid degenerate kernel (collapse) -- enforce minimum width
        half_widths = np.maximum(half_widths, 1e-9)

        new_particles: List[np.ndarray] = []
        new_dists: List[float] = []
        unnorm_w: List[float] = []
        n_proposed = 0
        while len(new_particles) < n_particles:
            if n_proposed >= max_iter_per_gen:
                raise RuntimeError(
                    f"gen {g + 1} exceeded max_iter={max_iter_per_gen}; only "
                    f"{len(new_particles)} accepted"
                )
            n_proposed += 1
            # sample particle from previous weighted population
            idx = rng.choice(n_particles, p=prev_w)
            base = prev_arr[idx]
            cand_vec = _perturb_uniform(base, half_widths, rng)
            cand = {k: float(v) for k, v in zip(names, cand_vec)}
            lp = log_prior(cand)
            if not math.isfinite(lp):
                continue
            d = distance(simulator(cand))
            if d > eps_g:
                continue
            # importance weight
            denom = 0.0
            for j in range(n_particles):
                denom += prev_w[j] * _kernel_density_uniform(cand_vec, prev_arr[j], half_widths)
            if denom <= 0:
                continue
            w = math.exp(lp) / denom
            new_particles.append(cand_vec)
            new_dists.append(d)
            unnorm_w.append(w)

        new_arr = np.asarray(new_particles, dtype=float)
        w_arr = np.asarray(unnorm_w, dtype=float)
        w_arr /= w_arr.sum()
        particles_history.append(new_arr)
        weights_history.append(w_arr)
        eps_history.append(eps_g)
        proposed_history.append(n_proposed)
        rate_history.append(float(n_particles) / float(n_proposed))
        ess_history.append(effective_sample_size(w_arr))
        dists = new_dists

    return {
        "particles": particles_history,
        "weights": weights_history,
        "names": names,
        "epsilons": eps_history,
        "ess": ess_history,
        "n_proposed": proposed_history,
        "acceptance_rate": rate_history,
    }

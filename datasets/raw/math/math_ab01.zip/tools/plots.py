"""Matplotlib plotters used by the agent.

Each plot function returns ``{"path": <str>}`` so the caller can pass the
path straight into the answer JSON.  No interactive backend is required --
the code uses ``matplotlib.use('Agg')`` if no backend is configured.
"""
from __future__ import annotations

from typing import Dict, List, Optional
import os
import numpy as np
import matplotlib

if "DISPLAY" not in os.environ:
    matplotlib.use("Agg")

import matplotlib.pyplot as plt  # noqa: E402


def _ensure_dir(path: str) -> None:
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)


def plot_observed_epidemic(days: np.ndarray, I: np.ndarray, R: np.ndarray, out_path: str, title: str = "Observed SIR epidemic") -> Dict[str, str]:
    """Scatter the observed I and R counts vs day.

    Reproduces the dot panel from Fig. 3 of Minter & Retkute (2019).
    """
    _ensure_dir(out_path)
    fig, ax = plt.subplots(figsize=(6, 4), dpi=140)
    ax.plot(days, I, "o", color="tab:red", label="Infected (I)")
    ax.plot(days, R, "^", color="tab:green", label="Recovered (R)")
    ax.set_xlabel("Time (day)")
    ax.set_ylabel("Number of individuals")
    ax.set_title(title)
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(out_path)
    plt.close(fig)
    return {"path": out_path}


def plot_posterior_histograms(
    particles: np.ndarray,
    names: List[str],
    weights: Optional[np.ndarray],
    out_path: str,
    truth: Optional[Dict[str, float]] = None,
    bins: int = 25,
    title: str = "ABC posterior histograms",
) -> Dict[str, str]:
    """Grid of weighted posterior histograms, one per parameter, plus R0 = beta/gamma.

    Mirrors Fig. 2 of Minter & Retkute (2019).
    """
    _ensure_dir(out_path)
    cols = list(names)
    has_R0 = "beta" in cols and "gamma" in cols
    panels = cols + (["R0"] if has_R0 else [])
    n = len(panels)
    ncols = min(4, n)
    nrows = int(np.ceil(n / ncols))
    fig, axes = plt.subplots(nrows, ncols, figsize=(3.5 * ncols, 3.0 * nrows), dpi=140)
    axes = np.atleast_1d(axes).ravel()
    if weights is None:
        weights = np.full(particles.shape[0], 1.0 / particles.shape[0])
    for k, name in enumerate(panels):
        ax = axes[k]
        if name == "R0":
            beta = particles[:, cols.index("beta")]
            gamma = particles[:, cols.index("gamma")]
            x = beta / gamma
        else:
            x = particles[:, cols.index(name)]
        ax.hist(x, bins=bins, weights=weights, color="0.5", edgecolor="white")
        ax.set_xlabel(name)
        ax.set_ylabel("density")
        if truth is not None and name in truth:
            ax.axvline(truth[name], color="tab:blue", linestyle="--", lw=1.5)
    for k in range(n, len(axes)):
        axes[k].axis("off")
    fig.suptitle(title)
    fig.tight_layout()
    fig.savefig(out_path)
    plt.close(fig)
    return {"path": out_path}


def plot_prior_vs_posterior(
    particles: np.ndarray,
    names: List[str],
    weights: Optional[np.ndarray],
    prior_bounds: Dict[str, tuple],
    out_path: str,
    bins: int = 25,
    title: str = "Prior vs posterior",
) -> Dict[str, str]:
    """Side-by-side prior (uniform / Poisson approximation) and posterior."""
    _ensure_dir(out_path)
    if weights is None:
        weights = np.full(particles.shape[0], 1.0 / particles.shape[0])
    n = len(names)
    fig, axes = plt.subplots(1, n, figsize=(4 * n, 3.5), dpi=140)
    axes = np.atleast_1d(axes).ravel()
    for k, name in enumerate(names):
        ax = axes[k]
        x = particles[:, k]
        ax.hist(x, bins=bins, weights=weights, color="tab:orange", alpha=0.7, label="posterior", density=True)
        if name in prior_bounds:
            lo, hi = prior_bounds[name]
            ax.axvspan(lo, hi, alpha=0.15, color="tab:blue", label="prior support")
        ax.set_xlabel(name)
        ax.legend(frameon=False, fontsize=8)
    fig.suptitle(title)
    fig.tight_layout()
    fig.savefig(out_path)
    plt.close(fig)
    return {"path": out_path}


def plot_posterior_pair(
    particles: np.ndarray,
    names: List[str],
    weights: Optional[np.ndarray],
    out_path: str,
    title: str = "Joint posterior (beta, gamma)",
) -> Dict[str, str]:
    """Scatter of two columns (default beta vs gamma) coloured by importance weight."""
    _ensure_dir(out_path)
    if "beta" not in names or "gamma" not in names:
        raise ValueError("requires 'beta' and 'gamma' in names")
    bi = names.index("beta")
    gi = names.index("gamma")
    if weights is None:
        weights = np.full(particles.shape[0], 1.0 / particles.shape[0])
    fig, ax = plt.subplots(figsize=(5, 4), dpi=140)
    sc = ax.scatter(particles[:, bi], particles[:, gi], c=weights, cmap="viridis", s=8, edgecolors="none")
    ax.set_xlabel("beta (transmission rate)")
    ax.set_ylabel("gamma (recovery rate)")
    ax.set_title(title)
    fig.colorbar(sc, ax=ax, label="weight")
    fig.tight_layout()
    fig.savefig(out_path)
    plt.close(fig)
    return {"path": out_path}


def plot_posterior_predictive(
    days: np.ndarray,
    I_obs: np.ndarray,
    R_obs: np.ndarray,
    sim_traj: np.ndarray,
    out_path: str,
    title: str = "Posterior-predictive check",
) -> Dict[str, str]:
    """Overlay a sample of posterior-predictive trajectories on the observed data.

    ``sim_traj`` has shape ``(n_sim, T, 2)`` -- a stack of (I, R) trajectories
    drawn from the posterior.
    """
    _ensure_dir(out_path)
    fig, ax = plt.subplots(figsize=(6, 4), dpi=140)
    n_sim = sim_traj.shape[0]
    for j in range(n_sim):
        ax.plot(days, sim_traj[j, :, 0], color="tab:red", alpha=0.15, lw=1)
        ax.plot(days, sim_traj[j, :, 1], color="tab:green", alpha=0.15, lw=1)
    ax.plot(days, I_obs, "o", color="black", label="Observed I")
    ax.plot(days, R_obs, "^", color="black", label="Observed R", markerfacecolor="white")
    ax.set_xlabel("Time (day)")
    ax.set_ylabel("Number of individuals")
    ax.set_title(title)
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(out_path)
    plt.close(fig)
    return {"path": out_path}


def plot_distance_histogram(
    distances: np.ndarray,
    epsilon: float,
    out_path: str,
    title: str = "Distance to observed (accepted particles)",
) -> Dict[str, str]:
    """Histogram of accepted distances with the tolerance shown as a vertical line."""
    _ensure_dir(out_path)
    fig, ax = plt.subplots(figsize=(6, 4), dpi=140)
    ax.hist(distances, bins=25, color="0.5", edgecolor="white")
    ax.axvline(epsilon, color="tab:blue", linestyle="--", lw=1.5, label=f"epsilon = {epsilon:g}")
    ax.set_xlabel("d(D, D*)")
    ax.set_ylabel("count")
    ax.set_title(title)
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(out_path)
    plt.close(fig)
    return {"path": out_path}


def plot_smc_diagnostics(
    epsilons: List[float],
    acceptance_rates: List[float],
    ess: List[float],
    out_path: str,
    title: str = "ABC-SMC diagnostics",
) -> Dict[str, str]:
    """Three-panel plot: tolerance, acceptance rate, ESS over generations."""
    _ensure_dir(out_path)
    g = np.arange(1, len(epsilons) + 1)
    fig, axes = plt.subplots(1, 3, figsize=(12, 3.5), dpi=140)
    axes[0].plot(g, epsilons, "o-")
    axes[0].set_xlabel("generation")
    axes[0].set_ylabel("epsilon")
    axes[0].set_title("Tolerance schedule")
    axes[1].plot(g, acceptance_rates, "o-", color="tab:green")
    axes[1].set_xlabel("generation")
    axes[1].set_ylabel("accept rate")
    axes[1].set_title("Acceptance rate")
    axes[2].plot(g, ess, "o-", color="tab:purple")
    axes[2].set_xlabel("generation")
    axes[2].set_ylabel("ESS")
    axes[2].set_title("Effective sample size")
    fig.suptitle(title)
    fig.tight_layout()
    fig.savefig(out_path)
    plt.close(fig)
    return {"path": out_path}

"""Deterministic SIR forward simulator.

Implements the closed compartmental ODE used in Minter & Retkute (2019) Case
Study 1::

    dS/dt = -beta * S * I / N
    dI/dt =  beta * S * I / N - gamma * I
    dR/dt =  gamma * I

with N = S + I + R conserved.  The simulator is integrated with a fixed-step
classical Runge-Kutta-4 scheme so the agent does not need scipy.integrate.
The default I(0)=1 and R(0)=0 follow the paper.
"""
from __future__ import annotations

from typing import Tuple
import numpy as np


def sir_rhs(S: float, I: float, R: float, beta: float, gamma: float) -> Tuple[float, float, float]:
    """Right-hand side of the SIR ODE evaluated at a single point.

    Returns ``(dS/dt, dI/dt, dR/dt)``.  The total population
    ``N = S + I + R`` is computed inline; the rate equations follow
    eq. (3.1) of Minter & Retkute (2019).
    """
    N = S + I + R
    if N <= 0:
        return 0.0, 0.0, 0.0
    inf = beta * S * I / N
    rec = gamma * I
    return -inf, inf - rec, rec


def _rk4_step(S: float, I: float, R: float, beta: float, gamma: float, dt: float) -> Tuple[float, float, float]:
    """One classical RK4 step of the SIR ODE."""
    k1 = sir_rhs(S, I, R, beta, gamma)
    k2 = sir_rhs(S + 0.5 * dt * k1[0], I + 0.5 * dt * k1[1], R + 0.5 * dt * k1[2], beta, gamma)
    k3 = sir_rhs(S + 0.5 * dt * k2[0], I + 0.5 * dt * k2[1], R + 0.5 * dt * k2[2], beta, gamma)
    k4 = sir_rhs(S + dt * k3[0], I + dt * k3[1], R + dt * k3[2], beta, gamma)
    Sn = S + dt / 6.0 * (k1[0] + 2 * k2[0] + 2 * k3[0] + k4[0])
    In = I + dt / 6.0 * (k1[1] + 2 * k2[1] + 2 * k3[1] + k4[1])
    Rn = R + dt / 6.0 * (k1[2] + 2 * k2[2] + 2 * k3[2] + k4[2])
    return Sn, In, Rn


def simulate_sir(
    S0: float,
    beta: float,
    gamma: float,
    I0: float = 1.0,
    R0: float = 0.0,
    days: int = 17,
    sub_steps: int = 50,
) -> np.ndarray:
    """Simulate the SIR ODE on a daily grid ``t = 1, 2, ..., days``.

    Parameters
    ----------
    S0 : float
        Initial number of susceptibles.
    beta : float
        Transmission rate per day.
    gamma : float
        Recovery rate per day.
    I0, R0 : float, optional
        Initial infected / recovered counts (defaults match the paper).
    days : int, optional
        Number of integer days to record (default 17 = paper outbreak length).
    sub_steps : int, optional
        Number of RK4 sub-steps per day (default 50 -> dt=0.02; ample
        accuracy for the smooth SIR system).

    Returns
    -------
    out : 2-D float array of shape ``(days, 2)``.  Column 0 is I(t) and
    column 1 is R(t) at each of the ``days`` grid points.  This mirrors the
    output of the R reference code ``run_model`` which returns the
    ``data.frame(I, R)``.
    """
    dt = 1.0 / sub_steps
    S, I, R = float(S0), float(I0), float(R0)
    out = np.zeros((days, 2), dtype=float)
    out[0, 0] = I
    out[0, 1] = R
    for d in range(1, days):
        for _ in range(sub_steps):
            S, I, R = _rk4_step(S, I, R, beta, gamma, dt)
        out[d, 0] = I
        out[d, 1] = R
    return out


def simulate_full_sir(
    S0: float,
    beta: float,
    gamma: float,
    I0: float = 1.0,
    R0: float = 0.0,
    days: int = 17,
    sub_steps: int = 50,
) -> np.ndarray:
    """Same as :func:`simulate_sir` but also returns S(t) (column 0).

    Returns
    -------
    out : 2-D float array of shape ``(days, 3)`` with columns ``(S, I, R)``.
    """
    dt = 1.0 / sub_steps
    S, I, R = float(S0), float(I0), float(R0)
    out = np.zeros((days, 3), dtype=float)
    out[0] = [S, I, R]
    for d in range(1, days):
        for _ in range(sub_steps):
            S, I, R = _rk4_step(S, I, R, beta, gamma, dt)
        out[d] = [S, I, R]
    return out


def basic_reproduction_number(beta: float, gamma: float) -> float:
    """Return the basic reproduction number ``R0 = beta / gamma``.

    Raises ``ValueError`` if ``gamma <= 0``.
    """
    if gamma <= 0:
        raise ValueError("gamma must be positive")
    return float(beta) / float(gamma)

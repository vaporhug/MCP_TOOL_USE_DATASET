"""CSV loaders for the observed epidemic and the prior specification.

The observed epidemic CSV is wide-format ``day, I, R`` over T = 17 days.
The prior CSV has columns ``parameter, distribution, arg1, arg2, description``.
"""
from __future__ import annotations

from typing import Dict, List, Tuple
import csv
import numpy as np


def load_epidemic(path: str) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Load the daily counts of infected and recovered individuals.

    Parameters
    ----------
    path : str
        Path to ``observed_epidemic.csv``.

    Returns
    -------
    days : 1-D int array, shape (T,)
    I : 1-D int array, shape (T,) -- number of infected on each day
    R : 1-D int array, shape (T,) -- number of recovered on each day
    """
    days: List[int] = []
    Is: List[int] = []
    Rs: List[int] = []
    with open(path, "r", newline="") as fh:
        rdr = csv.DictReader(fh)
        for row in rdr:
            days.append(int(row["day"]))
            Is.append(int(row["I"]))
            Rs.append(int(row["R"]))
    return np.asarray(days, dtype=int), np.asarray(Is, dtype=int), np.asarray(Rs, dtype=int)


def load_priors(path: str) -> Dict[str, Dict[str, object]]:
    """Load the prior table and return a dict keyed by parameter name.

    Each value is a dict ``{"distribution": str, "arg1": float | None,
    "arg2": float | None, "description": str}``.
    """
    out: Dict[str, Dict[str, object]] = {}
    with open(path, "r", newline="") as fh:
        rdr = csv.DictReader(fh)
        for row in rdr:
            a1 = row.get("arg1", "").strip()
            a2 = row.get("arg2", "").strip()
            out[row["parameter"]] = {
                "distribution": row["distribution"].strip().lower(),
                "arg1": float(a1) if a1 else None,
                "arg2": float(a2) if a2 else None,
                "description": row.get("description", "").strip(),
            }
    return out


def stack_observed(I: np.ndarray, R: np.ndarray) -> np.ndarray:
    """Stack two 1-D arrays of equal length into a (T, 2) matrix ``[I, R]``."""
    if I.shape != R.shape:
        raise ValueError("I and R must have identical shape")
    return np.column_stack([I, R]).astype(float)

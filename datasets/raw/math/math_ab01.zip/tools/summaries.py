"""Summary statistics used as ABC distance arguments.

The paper uses two summary statistics for the SIR Case Study 1: the full
trajectory (algorithm 1), the final number of recovered individuals at day
17 (algorithm 2), and the pair (final R, infected on day 17) (algorithm 3).
This module exposes those primitives and a few extras (peak height, peak
day) useful for sanity checks.
"""
from __future__ import annotations

from typing import Tuple
import numpy as np


def final_size_R(traj: np.ndarray) -> float:
    """Number of recovered individuals on the final day of ``traj``.

    ``traj`` may be the (T, 2) ``[I, R]`` matrix produced by
    :func:`tools.sir_model.simulate_sir` -- the recovered column is taken
    as the last column.
    """
    return float(traj[-1, -1])


def final_infected(traj: np.ndarray) -> float:
    """Number of infected individuals on the final day of ``traj``.

    Picks column ``-2`` so the function works for both (T, 2) [I, R] and
    (T, 3) [S, I, R] inputs.
    """
    return float(traj[-1, -2])


def peak_height(traj: np.ndarray) -> float:
    """Maximum number of infected individuals reached over ``traj``.

    Uses column ``-2`` of the trajectory matrix.
    """
    return float(np.max(traj[:, -2]))


def peak_day(traj: np.ndarray) -> int:
    """Day index (1-based) at which infected count peaks in ``traj``."""
    return int(np.argmax(traj[:, -2]) + 1)


def cumulative_infected(traj: np.ndarray) -> float:
    """Sum of the infected column over ``traj`` (a crude exposure index)."""
    return float(np.sum(traj[:, -2]))


def trajectory_pair(traj: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """Return ``(I, R)`` columns of the trajectory as a 2-tuple of arrays."""
    if traj.shape[1] == 2:
        return traj[:, 0], traj[:, 1]
    return traj[:, -2], traj[:, -1]

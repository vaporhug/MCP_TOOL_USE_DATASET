"""Mean (conditional-expectation) regression models used as the underlying
``mu_hat(x)`` of split conformal prediction.

Two estimators are exposed: ridge regression (closed form, no scikit-learn
dependency in the agent's code) and a thin random-forest wrapper.  Both
return predictions on a held-out feature matrix.
"""
from __future__ import annotations

from typing import Dict

import numpy as np
from sklearn.ensemble import RandomForestRegressor


def fit_ridge(X: np.ndarray, y: np.ndarray, lam: float = 1.0) -> Dict[str, np.ndarray]:
    """Closed-form ridge regression with L2 penalty ``lam``.

    Augments X with an intercept column, solves
    ``beta = (X^T X + lam I)^(-1) X^T y`` with the intercept unpenalised.
    Returns a dict ``{"beta": (p+1,), "lam": float}``.
    """
    n, p = X.shape
    X1 = np.hstack([np.ones((n, 1)), X])
    A = X1.T @ X1
    pen = lam * np.eye(p + 1)
    pen[0, 0] = 0.0  # do not penalise the intercept
    beta = np.linalg.solve(A + pen, X1.T @ y)
    return {"beta": beta, "lam": float(lam)}


def predict_ridge(model: Dict[str, np.ndarray], X: np.ndarray) -> np.ndarray:
    """Predict mean response with a ridge model returned by ``fit_ridge``."""
    beta = model["beta"]
    n = X.shape[0]
    return np.hstack([np.ones((n, 1)), X]) @ beta


def fit_random_forest(X: np.ndarray, y: np.ndarray,
                      n_estimators: int = 100,
                      min_samples_leaf: int = 5,
                      random_state: int = 0,
                      n_jobs: int = -1,
                      ) -> RandomForestRegressor:
    """Fit a scikit-learn random-forest regressor with sensible defaults.

    The defaults match Romano et al. (2019) supplementary material
    (``min_samples_leaf=5``, ``n_estimators=100``).
    """
    rf = RandomForestRegressor(n_estimators=int(n_estimators),
                               min_samples_leaf=int(min_samples_leaf),
                               random_state=int(random_state),
                               n_jobs=int(n_jobs))
    rf.fit(X, y)
    return rf


def predict_random_forest(model: RandomForestRegressor, X: np.ndarray) -> np.ndarray:
    """Predict mean response with a fitted random-forest regressor."""
    return np.asarray(model.predict(X), dtype=float)


def fit_log_residual_rf(mu_model: RandomForestRegressor,
                        X_train: np.ndarray, y_train: np.ndarray,
                        n_estimators: int = 100,
                        min_samples_leaf: int = 5,
                        random_state: int = 0,
                        ) -> RandomForestRegressor:
    """Fit ``sigma_hat(x)`` for locally-weighted CP as a random forest on the
    absolute residuals of the mean model on the proper-training set.

    This realises the Mean-Absolute-Deviation (MAD) variant described in
    Romano et al. (2019), Section 5: ``sigma_hat(X) = E[|Y - mu_hat(X)| | X]``.
    """
    mu_tr = mu_model.predict(X_train)
    abs_res = np.abs(y_train - mu_tr)
    rf_sig = RandomForestRegressor(n_estimators=int(n_estimators),
                                   min_samples_leaf=int(min_samples_leaf),
                                   random_state=int(random_state),
                                   n_jobs=-1)
    rf_sig.fit(X_train, abs_res)
    return rf_sig


def predict_sigma(model: RandomForestRegressor, X: np.ndarray,
                  floor: float = 1e-3) -> np.ndarray:
    """Predict the conditional dispersion ``sigma_hat(X)`` and apply a
    numerical floor to avoid division by zero in normalised conformity scores.
    """
    s = np.asarray(model.predict(X), dtype=float)
    return np.maximum(s, float(floor))

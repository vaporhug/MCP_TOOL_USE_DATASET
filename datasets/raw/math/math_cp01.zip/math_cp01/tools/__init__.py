"""Tooling for the conformal-prediction benchmark on the UCI Bike Sharing dataset.

Modules:
    data_loader        -- CSV loading, feature/target extraction, train/cal/test splits
    base_models        -- Mean regressors (ridge, random forest) without scikit-learn imports in caller
    quantile_models    -- Quantile random forest using scikit-learn leaves
    nonconformity      -- Absolute-residual and locally-weighted conformity scores
    split_conformal    -- Split-conformal quantile and prediction intervals
    cqr                -- Conformalized quantile regression (Romano et al. 2019, Algorithm 1)
    coverage_metrics   -- Marginal coverage, mean interval length, conditional coverage by group
    plotting           -- Matplotlib helpers; each plot function returns {"path": str}
"""

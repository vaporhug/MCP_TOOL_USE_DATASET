"""Data-loading primitives for the UCI Bike Sharing conformal-prediction task.

The raw file is the hourly Bike Sharing record (n = 17,379 hours, 17 columns)
with target column ``cnt`` = total hourly bike rentals (casual + registered).
The Romano et al. (2019) "Conformalized Quantile Regression" preprocessing
pipeline (https://github.com/yromano/cqr) drops the bookkeeping columns
``instant``, ``dteday``, ``casual``, ``registered`` and uses 12 numeric
features as predictors.

These helpers are intentionally minimal so the agent can compose them with the
modelling and conformalisation tools.  No scikit-learn or scipy is imported
here.
"""
from __future__ import annotations

import os
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd


_DEFAULT_FEATURES: Tuple[str, ...] = (
    "season", "yr", "mnth", "hr", "holiday", "weekday", "workingday",
    "weathersit", "temp", "atemp", "hum", "windspeed",
)
_TARGET = "cnt"


def load_bike_hour_csv(csv_path: str) -> pd.DataFrame:
    """Read the UCI Bike Sharing ``hour.csv`` file as a DataFrame.

    Parameters
    ----------
    csv_path : str
        Absolute path to the raw ``bike_sharing_hour.csv`` file.

    Returns
    -------
    pd.DataFrame
        Full table (17 columns) sorted by the original ``instant`` index.
    """
    if not os.path.isfile(csv_path):
        raise FileNotFoundError(csv_path)
    df = pd.read_csv(csv_path)
    expected = {"instant", "dteday", "season", "yr", "mnth", "hr", "holiday",
                "weekday", "workingday", "weathersit", "temp", "atemp", "hum",
                "windspeed", "casual", "registered", "cnt"}
    missing = expected - set(df.columns)
    if missing:
        raise ValueError(f"missing columns in bike CSV: {missing}")
    df = df.sort_values("instant").reset_index(drop=True)
    return df


def extract_features_target(df: pd.DataFrame,
                            features: Tuple[str, ...] = _DEFAULT_FEATURES,
                            target: str = _TARGET,
                            ) -> Tuple[np.ndarray, np.ndarray, List[str]]:
    """Extract the design matrix X (n, p) and response y (n,) as float arrays.

    Returns
    -------
    X : np.ndarray, shape (n, p)
    y : np.ndarray, shape (n,)
    feature_names : list of str
    """
    feats = list(features)
    miss = [c for c in feats + [target] if c not in df.columns]
    if miss:
        raise ValueError(f"columns not found: {miss}")
    X = df[feats].values.astype(float)
    y = df[target].values.astype(float)
    return X, y, feats


def standardize_features(X_train: np.ndarray, X_other: np.ndarray
                         ) -> Tuple[np.ndarray, np.ndarray, Dict[str, np.ndarray]]:
    """Centre and scale features by training-set mean/std (avoid sklearn).

    Returns standardised X_train, X_other, and a dict ``{"mean":..., "std":...}``
    of the fitted statistics.  Zero standard deviations are replaced by 1.
    """
    mu = X_train.mean(axis=0)
    sd = X_train.std(axis=0)
    sd = np.where(sd == 0, 1.0, sd)
    return (X_train - mu) / sd, (X_other - mu) / sd, {"mean": mu, "std": sd}


def rescale_response(y_train: np.ndarray, y_other: np.ndarray
                     ) -> Tuple[np.ndarray, np.ndarray, float]:
    """Divide the response by ``mean(|y_train|)`` (Romano et al., footnote 5).

    The same rescaling factor is then applied to ``y_other``.  Returning the
    factor lets the agent invert the transformation when reporting interval
    lengths in the original count units.
    """
    factor = float(np.mean(np.abs(y_train)))
    if factor <= 0:
        factor = 1.0
    return y_train / factor, y_other / factor, factor


def split_train_cal_test(n: int,
                         test_frac: float = 0.2,
                         cal_frac_of_train: float = 0.5,
                         seed: int = 0,
                         ) -> Dict[str, np.ndarray]:
    """Random index split following Romano et al. (2019), Section 6.

    Returns a dict with three integer index arrays ``proper_train``, ``cal``
    and ``test``.  Test fraction defaults to 20 percent; the remaining 80
    percent are split evenly between proper-training and calibration.
    """
    if not (0 < test_frac < 1):
        raise ValueError("test_frac must be in (0, 1)")
    if not (0 < cal_frac_of_train < 1):
        raise ValueError("cal_frac_of_train must be in (0, 1)")
    rng = np.random.default_rng(seed)
    perm = rng.permutation(n)
    n_test = int(round(test_frac * n))
    test_idx = perm[:n_test]
    rest = perm[n_test:]
    n_cal = int(round(cal_frac_of_train * len(rest)))
    proper_idx = rest[:len(rest) - n_cal]
    cal_idx = rest[len(rest) - n_cal:]
    return {"proper_train": proper_idx, "cal": cal_idx, "test": test_idx}


def hour_group_labels(df: pd.DataFrame, idx: np.ndarray) -> np.ndarray:
    """Return a string array ``{"night","morning","midday","evening","late"}``
    for the hour-of-day of the rows at the given indices.

    The buckets are night = 0-6, morning = 7-9, midday = 10-16,
    evening = 17-20, late = 21-23.  These groups are used to evaluate
    conditional coverage of the prediction intervals.
    """
    hr = df.iloc[idx]["hr"].values
    out = np.empty(len(hr), dtype=object)
    for i, h in enumerate(hr):
        if h <= 6:
            out[i] = "night"
        elif h <= 9:
            out[i] = "morning"
        elif h <= 16:
            out[i] = "midday"
        elif h <= 20:
            out[i] = "evening"
        else:
            out[i] = "late"
    return out

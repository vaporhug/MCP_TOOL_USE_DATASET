"""Standard and locally-weighted split-conformal prediction intervals.

Given a fitted base regressor ``mu_hat`` (and optionally a dispersion
estimator ``sigma_hat``), the calibration set residuals, and a
miscoverage level ``alpha``, these functions return prediction
intervals on a test set.
"""
from __future__ import annotations

from typing import Dict

import numpy as np

from . import nonconformity as nc


def split_conformal_interval(mu_test: np.ndarray, mu_cal: np.ndarray,
                             y_cal: np.ndarray, alpha: float = 0.1
                             ) -> Dict[str, np.ndarray]:
    """Standard split-conformal interval (Papadopoulos et al., 2002).

    Returns a dict ``{"lower": (n,), "upper": (n,), "Q": float}``.
    """
    scores = nc.absolute_residual_score(y_cal, mu_cal)
    Q = nc.conformal_quantile(scores, alpha)
    lo = mu_test - Q
    hi = mu_test + Q
    return {"lower": lo, "upper": hi, "Q": Q, "method": "split_cp"}


def locally_weighted_split_conformal(mu_test: np.ndarray, mu_cal: np.ndarray,
                                     sigma_test: np.ndarray, sigma_cal: np.ndarray,
                                     y_cal: np.ndarray, alpha: float = 0.1
                                     ) -> Dict[str, np.ndarray]:
    """Locally-weighted split-conformal interval (Lei et al., 2018, Sec. 5.2).

    The width is ``Q * sigma_hat(x)``; ``Q`` is the conformal quantile of the
    locally-weighted scores ``|Y - mu_hat| / sigma_hat`` on the calibration
    set.
    """
    scores = nc.locally_weighted_score(y_cal, mu_cal, sigma_cal)
    Q = nc.conformal_quantile(scores, alpha)
    lo = mu_test - Q * sigma_test
    hi = mu_test + Q * sigma_test
    return {"lower": lo, "upper": hi, "Q": Q, "method": "local_cp"}

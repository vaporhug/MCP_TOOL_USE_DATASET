"""Conformalized Quantile Regression (Algorithm 1 of Romano et al. 2019).

The procedure:
    1.  Split data into proper-training and calibration index sets.
    2.  Fit conditional ``alpha_lo``/``alpha_hi`` quantile regressors on
        the proper-training set.
    3.  Compute conformity scores ``E_i = max(q_lo(x_i) - y_i, y_i - q_hi(x_i))``
        on the calibration set.
    4.  Take ``Q = (1 - alpha)(1 + 1/n_cal)``-empirical quantile of E.
    5.  Output ``[q_lo(x*) - Q, q_hi(x*) + Q]`` as the conformalised interval.
"""
from __future__ import annotations

from typing import Dict

import numpy as np

from . import nonconformity as nc


def conformalized_quantile_interval(q_lo_test: np.ndarray, q_hi_test: np.ndarray,
                                    q_lo_cal: np.ndarray, q_hi_cal: np.ndarray,
                                    y_cal: np.ndarray, alpha: float = 0.1
                                    ) -> Dict[str, np.ndarray]:
    """Algorithm 1 of Romano et al. (2019).

    Parameters
    ----------
    q_lo_test, q_hi_test : (n_test,) plug-in conditional quantiles on test set
    q_lo_cal, q_hi_cal   : (n_cal,) plug-in conditional quantiles on calibration set
    y_cal                : (n_cal,) calibration responses
    alpha                : nominal miscoverage rate (default 0.1)

    Returns
    -------
    dict with arrays ``"lower"``, ``"upper"``, the calibration constant
    ``"Q"`` and the method label ``"cqr"``.
    """
    scores = nc.cqr_signed_score(y_cal, q_lo_cal, q_hi_cal)
    Q = nc.conformal_quantile(scores, alpha)
    lo = q_lo_test - Q
    hi = q_hi_test + Q
    return {"lower": lo, "upper": hi, "Q": Q, "method": "cqr"}


def asymmetric_conformalized_quantile_interval(q_lo_test: np.ndarray,
                                               q_hi_test: np.ndarray,
                                               q_lo_cal: np.ndarray,
                                               q_hi_cal: np.ndarray,
                                               y_cal: np.ndarray,
                                               alpha_lo: float = 0.05,
                                               alpha_hi: float = 0.05,
                                               ) -> Dict[str, np.ndarray]:
    """Two-tailed CQR (Theorem 2 of Romano et al. 2019).

    Calibrates the lower and upper tails independently.  Trades a small
    increase in average length for an asymmetric per-tail coverage guarantee.
    """
    e_lo = q_lo_cal - y_cal           # how far below the lower band
    e_hi = y_cal - q_hi_cal           # how far above the upper band
    Q_lo = nc.conformal_quantile(e_lo, alpha_lo)
    Q_hi = nc.conformal_quantile(e_hi, alpha_hi)
    lo = q_lo_test - Q_lo
    hi = q_hi_test + Q_hi
    return {"lower": lo, "upper": hi, "Q_lo": Q_lo, "Q_hi": Q_hi,
            "method": "cqr_asym"}

"""Evaluation metrics for prediction intervals.

The two headline metrics in Romano et al. (2019), Table 1 are:
    * **Avg. coverage** ``Pr(Y in C(X))`` -- should approach ``1 - alpha``.
    * **Avg. length** ``E[len(C(X))]``    -- the efficiency criterion.

In addition we provide group-conditional coverage (a stress test of
adaptivity) and the size-stratified coverage curve (interval length vs
local coverage), both of which are highlighted in Section 6 of the paper.
"""
from __future__ import annotations

from typing import Dict, List

import numpy as np


def marginal_coverage(y_test: np.ndarray, lower: np.ndarray, upper: np.ndarray
                      ) -> float:
    """Empirical marginal coverage ``mean(lower <= y <= upper)``."""
    y = np.asarray(y_test, dtype=float)
    return float(np.mean((y >= lower) & (y <= upper)))


def mean_interval_length(lower: np.ndarray, upper: np.ndarray) -> float:
    """Average interval width ``E[upper - lower]``."""
    return float(np.mean(np.asarray(upper) - np.asarray(lower)))


def median_interval_length(lower: np.ndarray, upper: np.ndarray) -> float:
    """Median interval width (robust to outlying widths)."""
    return float(np.median(np.asarray(upper) - np.asarray(lower)))


def conditional_coverage_by_group(y_test: np.ndarray, lower: np.ndarray,
                                  upper: np.ndarray, groups: np.ndarray
                                  ) -> List[Dict[str, float]]:
    """Per-group coverage and length.

    Parameters
    ----------
    groups : array-like of length n_test, with categorical labels
        (e.g., hour-of-day buckets).

    Returns
    -------
    list of dicts ``{"group": str, "n": int, "coverage": float, "length": float}``.
    """
    y = np.asarray(y_test, dtype=float)
    g = np.asarray(groups)
    out: List[Dict[str, float]] = []
    for lab in sorted(np.unique(g).tolist(), key=lambda x: str(x)):
        m = (g == lab)
        if m.sum() == 0:
            continue
        cov = float(np.mean((y[m] >= lower[m]) & (y[m] <= upper[m])))
        ln = float(np.mean(upper[m] - lower[m]))
        out.append({"group": str(lab), "n": int(m.sum()),
                    "coverage": cov, "length": ln})
    return out


def size_stratified_coverage(y_test: np.ndarray, lower: np.ndarray,
                             upper: np.ndarray, n_bins: int = 5
                             ) -> List[Dict[str, float]]:
    """Bin test points by interval width and report per-bin coverage.

    A method that is well-calibrated *and* adaptive should produce
    near-constant coverage across width bins.  A constant-width method
    (split-CP) collapses all points into one bin.
    """
    widths = np.asarray(upper) - np.asarray(lower)
    if widths.min() == widths.max():
        c = float(np.mean((y_test >= lower) & (y_test <= upper)))
        return [{"bin": "constant_width", "n": int(len(widths)),
                 "width_lo": float(widths.min()), "width_hi": float(widths.max()),
                 "coverage": c}]
    edges = np.quantile(widths, np.linspace(0, 1, n_bins + 1))
    out: List[Dict[str, float]] = []
    for k in range(n_bins):
        if k < n_bins - 1:
            m = (widths >= edges[k]) & (widths < edges[k + 1])
        else:
            m = (widths >= edges[k]) & (widths <= edges[k + 1])
        if m.sum() == 0:
            continue
        c = float(np.mean((y_test[m] >= lower[m]) & (y_test[m] <= upper[m])))
        out.append({"bin": f"bin_{k+1}", "n": int(m.sum()),
                    "width_lo": float(edges[k]), "width_hi": float(edges[k + 1]),
                    "coverage": c})
    return out


def coverage_summary(y_test: np.ndarray, intervals: Dict[str, Dict[str, np.ndarray]]
                     ) -> List[Dict[str, float]]:
    """Compact summary ``[{"method","coverage","length",...}]`` over a dict
    of method-name -> ``{"lower":..., "upper":...}`` interval bundles.
    """
    out = []
    for name, iv in intervals.items():
        out.append({
            "method": name,
            "coverage": marginal_coverage(y_test, iv["lower"], iv["upper"]),
            "mean_length": mean_interval_length(iv["lower"], iv["upper"]),
            "median_length": median_interval_length(iv["lower"], iv["upper"]),
        })
    return out

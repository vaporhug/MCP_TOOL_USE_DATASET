"""Quantile-regression model used as the base estimator inside CQR.

We implement Meinshausen's (2006) Quantile Regression Forest on top of a
scikit-learn ``RandomForestRegressor``: the forest is trained as usual on the
mean-squared-error split criterion, and the conditional quantiles at a query
point are obtained by averaging the empirical CDFs of the leaves the query
falls in across all trees.

Two functions are exposed: ``fit_quantile_random_forest`` which simply trains
a random forest, and ``predict_quantiles`` which extracts conditional lower
and upper quantiles from the leaves.  No ``scikit-garden`` or other quantile
library is required.
"""
from __future__ import annotations

from typing import Dict, Tuple

import numpy as np
from sklearn.ensemble import RandomForestRegressor


def fit_quantile_random_forest(X: np.ndarray, y: np.ndarray,
                               n_estimators: int = 100,
                               min_samples_leaf: int = 5,
                               random_state: int = 0,
                               n_jobs: int = -1,
                               ) -> Dict[str, object]:
    """Fit a quantile random forest (QRF).

    Returns a dict with the trained sklearn forest and a cached
    leaf-index matrix on the training data, ready to be used by
    ``predict_quantiles``.
    """
    rf = RandomForestRegressor(n_estimators=int(n_estimators),
                               min_samples_leaf=int(min_samples_leaf),
                               random_state=int(random_state),
                               n_jobs=int(n_jobs))
    rf.fit(X, y)
    return {"forest": rf,
            "leaves_train": rf.apply(X),
            "y_train": np.asarray(y, dtype=float)}


def predict_quantiles(model: Dict[str, object], X: np.ndarray,
                      alpha_lo: float = 0.05, alpha_hi: float = 0.95,
                      ) -> Tuple[np.ndarray, np.ndarray]:
    """Predict conditional ``alpha_lo`` and ``alpha_hi`` quantiles.

    The Meinshausen (2006) construction is used: for each tree the test
    point's leaf is found, and the training samples in that leaf are given
    weight ``1/|leaf|``.  Weights are averaged across trees, sorted by y, and
    inverted to extract the requested quantiles.

    Returns ``(q_lo, q_hi)`` arrays of shape ``(n,)``.
    """
    if not (0.0 < alpha_lo < alpha_hi < 1.0):
        raise ValueError("require 0 < alpha_lo < alpha_hi < 1")
    rf = model["forest"]
    leaves_tr = model["leaves_train"]
    y_tr = model["y_train"]
    leaves_q = rf.apply(X)
    n_q = X.shape[0]
    n_trees = leaves_tr.shape[1]
    n_train = len(y_tr)
    order = np.argsort(y_tr)
    ys_sorted = y_tr[order]
    rank_lookup = np.empty(n_train, dtype=int)
    rank_lookup[order] = np.arange(n_train)
    out_lo = np.empty(n_q); out_hi = np.empty(n_q)
    # Pre-compute, for each tree, a boolean mask matrix is too memory-heavy;
    # work tree-by-tree with grouped indices.
    for i in range(n_q):
        weights = np.zeros(n_train)
        for t in range(n_trees):
            same = (leaves_tr[:, t] == leaves_q[i, t])
            n_same = int(same.sum())
            if n_same > 0:
                weights[same] += 1.0 / n_same
        weights /= n_trees
        ws_sorted = weights[order]
        cw = np.cumsum(ws_sorted)
        idx_lo = int(np.searchsorted(cw, alpha_lo))
        idx_hi = int(np.searchsorted(cw, alpha_hi))
        out_lo[i] = ys_sorted[min(idx_lo, n_train - 1)]
        out_hi[i] = ys_sorted[min(idx_hi, n_train - 1)]
    return out_lo, out_hi


def pinball_loss(y: np.ndarray, q: np.ndarray, alpha: float) -> float:
    """Mean pinball / check loss at quantile level ``alpha``.

    ``rho_alpha(y - q) = max(alpha (y-q), (alpha-1)(y-q))``.
    """
    if not (0.0 < alpha < 1.0):
        raise ValueError("alpha must lie in (0, 1)")
    diff = y - q
    return float(np.mean(np.maximum(alpha * diff, (alpha - 1.0) * diff)))

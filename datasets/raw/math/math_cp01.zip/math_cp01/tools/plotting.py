"""Matplotlib plotting helpers for the conformal-prediction benchmark.

Each plotting function takes the data and an output path and returns
``{"path": <absolute path written>}``.  All plots are saved as PNG.
"""
from __future__ import annotations

import os
from typing import Dict, List

import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


def _ensure_parent(path: str) -> None:
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)


def plot_coverage_vs_target(summary: List[Dict[str, float]],
                            target_coverage: float, out_path: str,
                            ) -> Dict[str, str]:
    """Bar chart of marginal coverage per method versus the target line."""
    _ensure_parent(out_path)
    methods = [s["method"] for s in summary]
    cov = [100 * s["coverage"] for s in summary]
    fig, ax = plt.subplots(figsize=(7.5, 4.5))
    bars = ax.bar(methods, cov, color="#3a7bd5", edgecolor="black")
    ax.axhline(100 * target_coverage, color="red", linestyle="--",
               label=f"target = {100*target_coverage:.0f}%")
    for b, c in zip(bars, cov):
        ax.text(b.get_x() + b.get_width() / 2, c + 0.4,
                f"{c:.2f}%", ha="center", fontsize=9)
    ax.set_ylabel("Empirical coverage (%)")
    ax.set_ylim(80, 100)
    ax.set_title("Marginal coverage on bike-sharing test set")
    ax.legend()
    plt.xticks(rotation=20, ha="right")
    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": os.path.abspath(out_path)}


def plot_interval_length_distribution(intervals: Dict[str, Dict[str, np.ndarray]],
                                      out_path: str,
                                      max_quantile: float = 0.99,
                                      ) -> Dict[str, str]:
    """Side-by-side boxplots of interval widths per method (clipped at the
    99th percentile so a few extreme widths don't compress the y-axis)."""
    _ensure_parent(out_path)
    names = list(intervals.keys())
    widths = []
    for n in names:
        w = intervals[n]["upper"] - intervals[n]["lower"]
        cap = float(np.quantile(w, max_quantile))
        widths.append(np.clip(w, None, cap))
    fig, ax = plt.subplots(figsize=(7.5, 4.5))
    bp = ax.boxplot(widths, labels=names, patch_artist=True, widths=0.55)
    palette = ["#a3c9f1", "#bdb2e0", "#9ed4a1"]
    for i, patch in enumerate(bp["boxes"]):
        patch.set_facecolor(palette[i % len(palette)])
    ax.set_ylabel("Interval width (units of normalised cnt)")
    ax.set_title("Interval-length distribution by method")
    plt.xticks(rotation=20, ha="right")
    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": os.path.abspath(out_path)}


def plot_calibration_curve(scores: np.ndarray, out_path: str,
                           alpha: float = 0.1) -> Dict[str, str]:
    """ECDF of the calibration nonconformity scores with the conformal
    quantile marked.  Used as a visual diagnostic for split-conformal
    calibration."""
    _ensure_parent(out_path)
    s = np.sort(np.asarray(scores, dtype=float))
    n = len(s)
    cdf = np.arange(1, n + 1) / n
    level = (1 - alpha) * (1 + 1 / n)
    level = float(min(level, 1.0))
    Q = float(np.quantile(s, level))
    fig, ax = plt.subplots(figsize=(7.5, 4.5))
    ax.plot(s, cdf, color="#3a7bd5", lw=1.6, label="empirical CDF of scores")
    ax.axvline(Q, color="red", linestyle="--",
               label=f"Q ({100*level:.2f}%-quantile) = {Q:.3f}")
    ax.axhline(level, color="red", linestyle=":", alpha=0.6)
    ax.set_xlabel("Nonconformity score")
    ax.set_ylabel("Empirical CDF")
    ax.set_title(f"Calibration ECDF, alpha = {alpha}")
    ax.legend()
    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": os.path.abspath(out_path)}


def plot_prediction_band_scatter(y_test: np.ndarray, mu_test: np.ndarray,
                                 lower: np.ndarray, upper: np.ndarray,
                                 out_path: str, n_show: int = 200,
                                 method_name: str = "method",
                                 ) -> Dict[str, str]:
    """Sorted prediction band: x-axis is sample index sorted by mu_test,
    y-axis shows the band (gray) overlaid with the realised y (dots)."""
    _ensure_parent(out_path)
    order = np.argsort(mu_test)
    if n_show is not None and n_show < len(order):
        sel = np.linspace(0, len(order) - 1, n_show).astype(int)
        order = order[sel]
    x = np.arange(len(order))
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.fill_between(x, lower[order], upper[order], color="#9ed4a1",
                    alpha=0.65, label=f"{method_name} prediction band")
    ax.plot(x, mu_test[order], color="black", lw=1.0, label="point prediction")
    miss = (y_test[order] < lower[order]) | (y_test[order] > upper[order])
    ax.scatter(x[~miss], y_test[order][~miss], s=10, color="#1f77b4",
               label="covered y")
    ax.scatter(x[miss], y_test[order][miss], s=14, color="red",
               label="not covered y")
    ax.set_xlabel("Test point (sorted by point prediction)")
    ax.set_ylabel("Normalised cnt")
    ax.set_title(f"Prediction band: {method_name}")
    ax.legend(loc="upper left", fontsize=8)
    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": os.path.abspath(out_path)}


def plot_group_conditional_coverage(per_group: List[Dict[str, float]],
                                    target_coverage: float, out_path: str,
                                    method_name: str = "method",
                                    ) -> Dict[str, str]:
    """Bar chart of per-group coverage (e.g., by hour-of-day bucket)."""
    _ensure_parent(out_path)
    labels = [r["group"] for r in per_group]
    cov = [100 * r["coverage"] for r in per_group]
    n = [r["n"] for r in per_group]
    fig, ax = plt.subplots(figsize=(7.5, 4.5))
    bars = ax.bar(labels, cov, color="#bdb2e0", edgecolor="black")
    for b, c, ni in zip(bars, cov, n):
        ax.text(b.get_x() + b.get_width() / 2, c + 0.4,
                f"{c:.1f}%\n(n={ni})", ha="center", fontsize=8)
    ax.axhline(100 * target_coverage, color="red", linestyle="--",
               label=f"target = {100*target_coverage:.0f}%")
    ax.set_ylim(60, 105)
    ax.set_ylabel("Conditional coverage (%)")
    ax.set_title(f"Conditional coverage by hour-of-day bucket: {method_name}")
    ax.legend()
    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": os.path.abspath(out_path)}

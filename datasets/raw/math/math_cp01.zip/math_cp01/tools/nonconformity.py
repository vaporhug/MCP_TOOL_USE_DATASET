"""Nonconformity (conformity) score functions used by split conformal
prediction.

Three score families are exposed:
  * ``absolute_residual``: ``|Y - mu_hat(X)|`` (Papadopoulos et al. 2002).
  * ``locally_weighted``: ``|Y - mu_hat(X)| / sigma_hat(X)`` (Lei et al. 2018,
    Sec. 5.2).
  * ``cqr_signed``: ``max(q_lo(X) - Y, Y - q_hi(X))`` (Romano et al. 2019,
    Eq. 6).

Each function accepts plain numpy arrays so it can be reused across base
models.
"""
from __future__ import annotations

import numpy as np


def absolute_residual_score(y: np.ndarray, mu_hat: np.ndarray) -> np.ndarray:
    """Standard split-conformal nonconformity score: ``|Y - mu_hat(X)|``."""
    return np.abs(np.asarray(y, dtype=float) - np.asarray(mu_hat, dtype=float))


def locally_weighted_score(y: np.ndarray, mu_hat: np.ndarray,
                           sigma_hat: np.ndarray, sigma_floor: float = 1e-3
                           ) -> np.ndarray:
    """Locally-weighted score: ``|Y - mu_hat(X)| / max(sigma_hat(X), floor)``.

    Suitable for heteroscedastic data where the residuals scale with a
    locally estimated standard deviation.
    """
    s = np.maximum(np.asarray(sigma_hat, dtype=float), float(sigma_floor))
    return absolute_residual_score(y, mu_hat) / s


def cqr_signed_score(y: np.ndarray, q_lo: np.ndarray, q_hi: np.ndarray
                     ) -> np.ndarray:
    """Romano, Patterson, Candes (2019), Eq. 6.

    ``E_i = max{q_lo(x_i) - y_i, y_i - q_hi(x_i)}``.

    Negative values mean the calibration point lies inside the plug-in
    band; positive values measure how far it falls outside.
    """
    y = np.asarray(y, dtype=float)
    q_lo = np.asarray(q_lo, dtype=float)
    q_hi = np.asarray(q_hi, dtype=float)
    return np.maximum(q_lo - y, y - q_hi)


def conformal_quantile(scores: np.ndarray, alpha: float) -> float:
    """Compute the calibration quantile used in split conformal prediction.

    The level is ``ceil((1 - alpha) (n + 1)) / n``, equivalently
    ``(1 - alpha) (1 + 1/n)`` (capped at 1.0).  See Romano et al. (2019)
    Eq. (8).  The empirical quantile of ``scores`` at this level is then
    returned.
    """
    if not (0.0 < alpha < 1.0):
        raise ValueError("alpha must lie in (0, 1)")
    s = np.asarray(scores, dtype=float)
    n = len(s)
    if n == 0:
        raise ValueError("empty score array")
    level = (1.0 - alpha) * (1.0 + 1.0 / n)
    level = float(min(level, 1.0))
    return float(np.quantile(s, level))

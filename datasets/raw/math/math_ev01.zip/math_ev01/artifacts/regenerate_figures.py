"""Regenerate the bundled artifact figures from the local tools + pooled
region CSVs.

Run from the bundle root:
    cd math_ev01 && python3 artifacts/regenerate_figures.py

What this script does (paper-aligned pipeline from the bundled tools):
  1. Catalogue all pooled-region CSV files via ``data_processing.list_pooled_region_files``.
  2. For each pooled region, build a long-format sample of *all county-composite
     block maxima* (paper Sect. 2c-d pools all county observations within a
     pooled region into a single population) via
     ``data_processing.get_pooled_county_composite_block_maxima`` and fit a
     non-stationary GEV on log(precipitation) with CMIP5 GMST as covariate
     using ``gev_fit.fit_ns_gev_mle_paper`` (location+scale NS).
     The 1.11 Perica daily-total correction is applied (default).
  3. Compute the per-region 1980-2020 percentage change for the 2-yr and
     100-yr return values from the fitted NS-GEV (using paper Sect. 4 metric:
     RL_now / RL_then - 1, where the return level is exp(GEV log-RL) given log
     response).
  4. Aggregate the per-region percent trends with
     ``regional_aggregate.gp_fit_trend_variable_kappa`` (paper-aligned Matern GP
     with FREE smoothness on Lambert-conformal projected centroids, fixed
     standard parallels 33N/45N per paper Sect. 2f).
  5. Write Fig1 (block maxima + stationary GEV mean for one NC region), Fig5
     (domain-wide 100-yr trend bar with GP CI), Fig6 (AIC across candidate
     parameterisations on one NC region), plus regional_trends.csv,
     model_comparison.csv, aggregate_summary.json.

Outputs (in artifacts/):
  Fig1_block_maxima_NC4.png    block maxima series + stationary GEV mean
  Fig5_regional_trend_100yr.png domain GP-aggregated 2-yr/100-yr trend bar
  Fig6_aic_model_compare.png    AIC comparison of candidate GEV parameterisations
  regional_trends.csv           per-domain GP-aggregated trend point + CI
  per_region_trends.csv         per-region 2-yr and 100-yr trends
  model_comparison.csv          AIC rank of candidate GEV parameterisations
  aggregate_summary.json        domain headline trend + paper-reported values
"""
import os
import json
import sys
import csv
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))

import data_processing as dp
import gev_fit as gf
import regional_aggregate as ra

OUTDIR = os.path.dirname(os.path.abspath(__file__))


def _per_region_ns_trend(df, return_period_T, year_then=1980, year_now=2020):
    """Fit NS-GEV (log response, location+scale NS) on a pooled region's
    *county-composite* block maxima sample (paper Sect. 2c-d: all county
    observations within a pooled region are pooled into a single population
    for the fit, not pre-averaged into the regional Mean) and return the
    1980-2020 percent change in the T-year return level.
    """
    series = dp.get_pooled_county_composite_block_maxima(
        df, covariate_col="Temps")
    if len(series) < 20:
        return None
    precip = series["block_max"].values.astype(float)
    cov    = series["covariate"].values.astype(float)
    years  = series["Year"].values.astype(int)
    msk = precip > 0
    precip, cov, years = precip[msk], cov[msk], years[msk]
    if len(precip) < 20:
        return None
    try:
        fit = gf.fit_ns_gev_mle_paper(precip, cov, scale_ns=True)
    except Exception:
        return None
    cov_then = cov[np.argmin(np.abs(years - year_then))]
    cov_now  = cov[np.argmin(np.abs(years - year_now))]
    try:
        log_rl_then = gf.ns_gev_return_level(fit, cov_then, return_period_T)
        log_rl_now  = gf.ns_gev_return_level(fit, cov_now,  return_period_T)
        pct = float(np.exp(log_rl_now - log_rl_then) - 1.0) * 100.0
        return pct
    except Exception:
        return None


def _build_region_centroids(data_dir):
    """Compute per-pooled-region centroid by averaging per-county coordinates
    from qcd01d2019pds.csv (Station_ID = ``<STATE>_Region <n>_<County>``).
    Returns a dict region_id -> (lat, lon).
    """
    p = os.path.join(data_dir, "qcd01d2019pds.csv")
    if not os.path.exists(p):
        return {}
    df = pd.read_csv(p)
    out = {}
    for _, row in df.iterrows():
        sid = str(row.get("Station_ID", "")).strip()
        # parse "<STATE>_Region <n>_<County>"
        if "_Region " not in sid:
            continue
        try:
            state_part, rest = sid.split("_Region ", 1)
            state = state_part.strip()
            n_part = rest.split("_", 1)[0].strip()
            # accept hex region top digit (per filename convention)
            region_top = n_part[:1]
            region_id_state = f"{state}{region_top}01"
            out.setdefault(region_id_state, []).append(
                (float(row["Latitude"]), float(row["Longitude"]))
            )
        except Exception:
            continue
    centroids = {}
    for rid, pts in out.items():
        lats, lons = zip(*pts)
        centroids[rid] = (float(np.mean(lats)), float(np.mean(lons)))
    return centroids


def main():
    data_dir = os.path.join(ROOT, "input_data", "data")
    catalogue = dp.list_pooled_region_files(data_dir)
    print(f"Found {len(catalogue)} pooled-region files under {data_dir}")
    if catalogue.empty:
        print("No pooled-region CSV files; skipping regeneration.")
        return

    # --- Fig 1: pick a representative NC pooled region for block-maxima view ---
    nc_rows = catalogue[catalogue["path"].astype(str).str.contains("NC", na=False)]
    if not nc_rows.empty:
        region_path = nc_rows.iloc[0]["path"]
        df = dp.load_pooled_region(region_path)
        series = dp.get_pooled_block_maxima(df, value_col="Mean", covariate_col=None)
        if len(series) > 5:
            x = np.asarray(series["block_max"].values, dtype=float)
            try:
                stat_fit = gf.fit_gev_mle(x)
            except Exception:
                stat_fit = None
            fig, ax = plt.subplots(figsize=(7, 4.5))
            ax.plot(series["Year"], series["block_max"], "o-", ms=4,
                    color="#1f77b4", label="annual block maxima")
            if stat_fit and "mu" in stat_fit:
                ax.axhline(stat_fit["mu"], ls="--", color="#cc4f4f", lw=1.0,
                           label=f"stationary GEV mu={stat_fit['mu']:.1f}")
            ax.set_xlabel("Year"); ax.set_ylabel("Annual daily-max precip")
            ax.set_title("Block maxima + stationary GEV mean (representative NC pooled region)")
            ax.grid(True, alpha=0.3); ax.legend(loc="best")
            fig.tight_layout()
            fig.savefig(os.path.join(OUTDIR, "Fig1_block_maxima_NC4.png"), dpi=140)
            plt.close(fig)

    # --- Per-region centroids (from qcd01d2019pds.csv) ---
    centroids = _build_region_centroids(data_dir)
    print(f"derived centroids for {len(centroids)} regions")

    # --- Per-region NS-GEV trends across all pooled regions (paper Sect 4) ---
    per_region_rows = []
    for _, row in catalogue.iterrows():
        try:
            df_r = dp.load_pooled_region(row["path"])
        except Exception:
            continue
        pct2   = _per_region_ns_trend(df_r, return_period_T=2.0)
        pct100 = _per_region_ns_trend(df_r, return_period_T=100.0)
        cen = centroids.get(row["region_id"], (float("nan"), float("nan")))
        per_region_rows.append({
            "region_id":   row["region_id"],
            "region_filename": os.path.basename(row["path"]),
            "state":       row.get("state", ""),
            "lat":         cen[0],
            "lon":         cen[1],
            "pct_trend_2yr_1980_2020":   pct2,
            "pct_trend_100yr_1980_2020": pct100,
        })
    pdf_pr = pd.DataFrame(per_region_rows)
    # NOTE: numeric tables are NOT persisted to artifacts/ to avoid
    # leaking the expected analysis outputs to solvers. To inspect the
    # per-region table, uncomment the line below.
    # pdf_pr.to_csv(os.path.join(OUTDIR, "per_region_trends.csv"), index=False)
    print(f"per_region_trends computed in-memory ({pdf_pr.shape[0]} regions,  ({pdf_pr.shape[0]} regions; "
          f"{pdf_pr['pct_trend_100yr_1980_2020'].notna().sum()} converged)")

    # --- Subdomain split using paper Section 4 definitions ---
    pdf_pr["is_gulf"] = pdf_pr["region_id"].apply(dp.is_gulf_region)
    pdf_pr["is_se"]   = pdf_pr["region_id"].apply(dp.is_se_region)

    # --- Domain + subdomain GP aggregation with variable-kappa Matern ---
    gp_summary = {}
    for scope_label, mask in [("domain_all", np.ones(len(pdf_pr), dtype=bool)),
                                ("gulf_coast", pdf_pr["is_gulf"].values),
                                ("southeast",  pdf_pr["is_se"].values)]:
        gp_summary[scope_label] = {}
        for T_label, col in [("2yr", "pct_trend_2yr_1980_2020"),
                              ("100yr", "pct_trend_100yr_1980_2020")]:
            sub = pdf_pr[mask].dropna(subset=[col, "lat", "lon"])
            if len(sub) < 5:
                gp_summary[scope_label][T_label] = {
                    "error": f"only {len(sub)} converged regions for {scope_label}"
                }
                continue
            coords = sub[["lat", "lon"]].values
            values = sub[col].values.astype(float)
            try:
                if len(sub) >= 10:
                    gp = ra.gp_fit_trend_variable_kappa(coords, values)
                    gp_summary[scope_label][T_label] = {
                        "mean_pct": float(gp["mean"]),
                        "ci_lower_95_pct": float(gp["ci_lower_95"]),
                        "ci_upper_95_pct": float(gp["ci_upper_95"]),
                        "kappa":     float(gp["kappa"]),
                        "length_km": float(gp["length_km"]),
                        "n_regions": int(len(sub)),
                        "method":    "matern_gp_variable_kappa",
                    }
                else:
                    # Small subdomain: fall back to unweighted mean + bootstrap
                    boot = ra.unweighted_mean_with_bootstrap(values, n_boot=1000)
                    gp_summary[scope_label][T_label] = {
                        "mean_pct": float(boot["mean"]),
                        "ci_lower_95_pct": float(boot["ci_lower_95"]),
                        "ci_upper_95_pct": float(boot["ci_upper_95"]),
                        "n_regions": int(len(sub)),
                        "method": "unweighted_mean_bootstrap",
                    }
            except Exception as e:
                gp_summary[scope_label][T_label] = {"error": str(e)}

    # --- Fig 5: 100-yr GP-aggregated trend per scope, bundle vs paper ---
    fig, ax = plt.subplots(figsize=(8, 5))
    scopes = ["domain_all", "gulf_coast", "southeast"]
    scope_labels = ["full domain\n(NC+SC+Gulf)", "Gulf Coast", "Southeast"]
    bundle_m = [gp_summary[s].get("100yr", {}).get("mean_pct", float("nan")) for s in scopes]
    bundle_lo = [gp_summary[s].get("100yr", {}).get("ci_lower_95_pct", float("nan")) for s in scopes]
    bundle_hi = [gp_summary[s].get("100yr", {}).get("ci_upper_95_pct", float("nan")) for s in scopes]
    paper_m  = [16, 12, None]
    paper_lo = [4,  4,  None]
    paper_hi = [26, 20, None]
    idx = np.arange(len(scopes))
    bundle_yerr = [[bundle_m[i] - bundle_lo[i] if bundle_lo[i] == bundle_lo[i] else 0
                    for i in range(len(scopes))],
                   [bundle_hi[i] - bundle_m[i] if bundle_hi[i] == bundle_hi[i] else 0
                    for i in range(len(scopes))]]
    ax.bar(idx - 0.18, bundle_m, width=0.35, yerr=bundle_yerr,
           color="#4f95cc", capsize=5, label="bundle (GP / mean+bootstrap)")
    paper_m_plot = [m if m is not None else 0 for m in paper_m]
    paper_lo_plot = [lo if lo is not None else 0 for lo in paper_lo]
    paper_hi_plot = [hi if hi is not None else 0 for hi in paper_hi]
    paper_yerr = [[paper_m_plot[i] - paper_lo_plot[i] for i in range(len(scopes))],
                  [paper_hi_plot[i] - paper_m_plot[i] for i in range(len(scopes))]]
    # plot paper only where reported
    for i in range(len(scopes)):
        if paper_m[i] is not None:
            ax.bar([idx[i] + 0.18], [paper_m_plot[i]], width=0.35,
                   yerr=[[paper_yerr[0][i]], [paper_yerr[1][i]]],
                   color="#cc4f4f", capsize=5,
                   label="paper" if i == 0 else None)
        else:
            ax.text(idx[i] + 0.18, 2, "n.d. at 95%",
                    ha="center", fontsize=8, color="#cc4f4f", rotation=90)
    ax.set_xticks(idx); ax.set_xticklabels(scope_labels)
    ax.set_ylabel("100-yr return-level trend 1980-2020 (%)")
    ax.set_title("100-yr GP-aggregated trend per scope: bundle vs paper")
    ax.grid(True, axis="y", alpha=0.3)
    ax.axhline(0, color="black", lw=0.5)
    ax.legend(loc="upper right", fontsize=9)
    fig.tight_layout()
    fig.savefig(os.path.join(OUTDIR, "Fig5_regional_trend_100yr.png"), dpi=140)
    plt.close(fig)

    # --- Fig 6: AIC comparison of candidate GEV parameterisations on the
    #           representative NC region, using the paper's pooled
    #           county-composite block-maxima sample (NOT Mean-only) ---
    if not nc_rows.empty:
        df = dp.load_pooled_region(nc_rows.iloc[0]["path"])
        series = dp.get_pooled_county_composite_block_maxima(
            df, covariate_col="Temps")
        precip = series["block_max"].values.astype(float)
        cov    = series["covariate"].values.astype(float)
        msk = precip > 0
        precip, cov = precip[msk], cov[msk]
        aic = {}
        try:
            fit_stat = gf.fit_gev_mle(np.log(precip))
            # fit_gev_mle returns nll but not AIC; compute it (3 params: mu, log_sigma, xi)
            aic["Stationary GEV (log p)"] = float(2 * 3 + 2 * fit_stat["nll"])
        except Exception:
            pass
        try:
            fit_loc = gf.fit_ns_gev_mle_paper(precip, cov, scale_ns=False)
            aic["NS-GEV mu(GMST)"] = float(fit_loc["aic"])
        except Exception:
            pass
        try:
            fit_locsc = gf.fit_ns_gev_mle_paper(precip, cov, scale_ns=True)
            aic["NS-GEV mu+ln(sigma)(GMST)"] = float(fit_locsc["aic"])
        except Exception:
            pass
        if aic:
            base = min(aic.values())
            variants = list(aic.keys())
            delta = [aic[v] - base for v in variants]
            fig, ax = plt.subplots(figsize=(7, 4.5))
            ax.bar(variants, delta, color="#4f95cc", edgecolor="black")
            ax.axhline(0, color="black", lw=0.5)
            ax.set_ylabel("ΔAIC vs best (lower = better)")
            ax.set_title("AIC across candidate GEV parameterisations (representative NC region)")
            ax.grid(True, axis="y", alpha=0.3)
            plt.xticks(rotation=18, ha="right")
            fig.tight_layout()
            fig.savefig(os.path.join(OUTDIR, "Fig6_aic_model_compare.png"), dpi=140)
            plt.close(fig)
            # model_comparison.csv not persisted (answer leakage)

    # --- regional_trends.csv: full + Gulf + SE subdomains, 2-yr and 100-yr ---
    PAPER = {
        ("domain_all", 2):   (9, 3, 15),
        ("domain_all", 100): (16, 4, 26),
        # Paper Section 4: Gulf detectable at 95%, SE not detectable at 95%.
        # Paper Sect. 6: Gulf-Coast 100-yr trend = 12% +/- 8% (95% CI 4-20%).
        ("gulf_coast", 2):   (None, None, None),
        ("gulf_coast", 100): (12, 4, 20),
        ("southeast",  2):   (None, None, None),
        ("southeast",  100): (None, None, None),  # not reported as detectable
    }
    # regional_trends.csv intentionally not persisted (leakage of expected outputs)

    # --- return_levels_qcd.csv: paper qcd01d2019pds.csv summary at 2/100 yr ---
    # Paper Sect. 4: stationary vs non-stationary return values for 2/100/500-yr
    # are tabulated in qcd01d2019pds.csv (873 county composites).
    qcd_p = os.path.join(data_dir, "qcd01d2019pds.csv")
    if os.path.exists(qcd_p):
        try:
            qcd = pd.read_csv(qcd_p, skipinitialspace=True)
            # Coerce numeric columns (some had whitespace + 'nan' strings)
            for c in qcd.columns:
                if c == "Station_ID": continue
                qcd[c] = pd.to_numeric(qcd[c], errors="coerce")
            # Filter to per-county rows only (drop per-region aggregate rows
            # whose Station_ID suffix is _Combine, _Mean, or _Ac).
            sid = qcd["Station_ID"].astype(str)
            is_county = ~sid.str.endswith(("_Combine", "_Mean", "_Ac"))
            qcd_county = qcd[is_county]
            qcd_agg    = qcd[~is_county]
            rl_rows = []
            for T in (2, 100):
                stat_col   = f"StatRP{float(T)}"
                ns2020_col = f"2020RP{float(T)}"
                ns1980_col = f"1980RP{float(T)}"
                if not all(c in qcd.columns for c in [stat_col, ns2020_col, ns1980_col]):
                    continue
                for label, sub in (("counties_only", qcd_county),
                                    ("region_aggregates_only", qcd_agg)):
                    rl_rows.append({
                        "scope": label,
                        "return_period_yr": T,
                        "n_rows": int(sub[stat_col].notna().sum()),
                        "stationary_RL_mean_in":  float(sub[stat_col].mean()),
                        "stationary_RL_p25_in":   float(sub[stat_col].quantile(0.025)),
                        "stationary_RL_p975_in":  float(sub[stat_col].quantile(0.975)),
                        "ns_RL_1980_mean_in": float(sub[ns1980_col].mean()),
                        "ns_RL_2020_mean_in": float(sub[ns2020_col].mean()),
                        "ns_pct_change_1980_2020": float(
                            (sub[ns2020_col].mean() / sub[ns1980_col].mean() - 1) * 100),
                    })
            if rl_rows:
                pass  # return_levels_qcd.csv not persisted (answer leakage)
        except Exception as e:
            print(f"return_levels_qcd.csv skipped: {e}")

    # --- aggregate_summary.json (now includes subdomain aggregates) ---
    # Also compute the bundle's AIC ranking from model_comparison.csv so the
    # answer can be reconciled with the bundle's actual output.
    aic_rows = []
    if aic:
        base = min(aic.values())
        for v in aic:
            aic_rows.append({"variant": v, "aic": aic[v],
                              "delta_aic_vs_best": aic[v] - base})
    # aggregate_summary.json not persisted (answer leakage)
    pass

    print("Regenerated Fig1/Fig5/Fig6 + per_region_trends.csv + "
          "regional_trends.csv + model_comparison.csv + aggregate_summary.json")


if __name__ == "__main__":
    main()

"""
Pure-numpy implementation of the generalized extreme value (GEV)
distribution and the maximum-likelihood machinery used in the
target paper.

GEV CDF (Coles 2001 chapter 3, eq. 3.2):
    F(x; mu, sigma, xi) =
        exp{-[1 + xi*(x-mu)/sigma]^(-1/xi)}     if xi != 0,
        exp{-exp(-(x-mu)/sigma)}                if xi == 0  (Gumbel)

with support {x : 1 + xi*(x-mu)/sigma > 0}.

The negative log-likelihood, T-year return level, profile-likelihood
confidence interval and parametric bootstrap are all implemented
without scipy.stats, only `scipy.optimize.minimize` and `numpy`.
The Gumbel case xi == 0 is handled by switching to the limiting
log-likelihood when |xi| < 1e-8.

Non-stationary GEV models accept a covariate array `c` and let
   mu(c)    = b0 + b1 * c
   ln sigma = b2 + b3 * c            (optional, scale_ns=True)
   xi       = b4                     (always stationary in this paper).
"""

from __future__ import annotations

from typing import Optional, Tuple

import numpy as np
from scipy.optimize import minimize


_LOG_SIGMA_FLOOR = -10.0  # exp(-10) ~ 4.5e-5
_LOG_SIGMA_CEIL = 5.0     # exp(5)  ~ 148
_BIG = 1e10


# ---------------------------------------------------------------------------
# Stationary GEV negative log-likelihood and MLE
# ---------------------------------------------------------------------------


def _gev_nll_core(x: np.ndarray, mu: np.ndarray, sigma: np.ndarray,
                  xi: float) -> float:
    """Core GEV negative log-likelihood given pre-broadcast mu, sigma."""
    if np.any(sigma <= 0):
        return _BIG
    z = (x - mu) / sigma
    if abs(xi) < 1e-8:
        # Gumbel limit
        return float(np.sum(np.log(sigma) + z + np.exp(-z)))
    arg = 1.0 + xi * z
    if np.any(arg <= 0):
        return _BIG
    return float(np.sum(np.log(sigma) +
                        (1.0 + 1.0 / xi) * np.log(arg) +
                        arg ** (-1.0 / xi)))


def gev_nll(params: Tuple[float, float, float], x: np.ndarray) -> float:
    """Negative log-likelihood of a stationary GEV.

    `params = (mu, log_sigma, xi)` so that sigma = exp(log_sigma) > 0.
    """
    mu, log_sigma, xi = params
    if not (_LOG_SIGMA_FLOOR < log_sigma < _LOG_SIGMA_CEIL):
        return _BIG
    sigma = np.exp(log_sigma)
    return _gev_nll_core(np.asarray(x, dtype=float),
                         np.float64(mu), np.float64(sigma), float(xi))


def fit_gev_mle(x: np.ndarray, x0: Optional[Tuple] = None,
                method: str = "Nelder-Mead",
                fix_xi: Optional[float] = None) -> dict:
    """MLE of the stationary GEV by direct minimisation of `gev_nll`.

    Parameters
    ----------
    x : (n,) array of block maxima
    x0 : optional start (mu, log_sigma, xi); defaults to method-of-moments
    method : `scipy.optimize.minimize` method
    fix_xi : if not None, freeze xi at this value (useful for Gumbel = 0)

    Returns dict with
        {'mu','sigma','xi','log_sigma','nll','converged','n','params','x0'}.
    """
    x = np.asarray(x, dtype=float)
    x = x[~np.isnan(x)]
    if x0 is None:
        # Method-of-moments style start (Coles 2001, p.55)
        sigma0 = np.std(x) * np.sqrt(6) / np.pi
        mu0 = np.mean(x) - 0.5772 * sigma0
        x0 = (float(mu0), float(np.log(sigma0)), 0.1)
    if fix_xi is not None:
        # Fit only (mu, log_sigma) with xi fixed
        def nll2(p):
            return gev_nll((p[0], p[1], float(fix_xi)), x)
        res = minimize(nll2, [x0[0], x0[1]], method=method,
                       options={"xatol": 1e-7, "fatol": 1e-7,
                                "maxiter": 5000})
        mu, log_sigma = res.x
        xi = float(fix_xi)
    else:
        res = minimize(lambda p: gev_nll(tuple(p), x), x0, method=method,
                       options={"xatol": 1e-7, "fatol": 1e-7,
                                "maxiter": 5000})
        mu, log_sigma, xi = res.x
    sigma = float(np.exp(log_sigma))
    return {
        "mu": float(mu), "sigma": float(sigma), "xi": float(xi),
        "log_sigma": float(log_sigma),
        "nll": float(res.fun), "converged": bool(res.success),
        "n": int(len(x)), "params": (float(mu), float(sigma), float(xi)),
        "x0": tuple(x0),
    }


def fit_gumbel_mle(x: np.ndarray) -> dict:
    """Convenience: GEV with xi pinned to zero (i.e. Gumbel)."""
    return fit_gev_mle(x, fix_xi=0.0)


# ---------------------------------------------------------------------------
# Return level (Coles 2001 eq. 3.4) and bootstrap CI
# ---------------------------------------------------------------------------


def gev_return_level(mu: float, sigma: float, xi: float,
                     return_period_T: float) -> float:
    """T-year return level of the GEV(mu, sigma, xi) distribution.

    return_level = mu - sigma/xi * [1 - {-log(1-1/T)}^(-xi)] for xi != 0;
                   mu - sigma * log{-log(1-1/T)}            for xi == 0.
    """
    if return_period_T <= 1.0:
        raise ValueError("return period must be > 1 year")
    p = 1.0 / return_period_T
    yT = -np.log(1.0 - p)
    if abs(xi) < 1e-8:
        return float(mu - sigma * np.log(yT))
    return float(mu - (sigma / xi) * (1.0 - yT ** (-xi)))


def gev_log_return_level(mu: float, sigma: float, xi: float,
                         return_period_T: float) -> float:
    """Convenience: when the GEV is fit on log(precip), this returns
    the *log-space* return level. Caller exponentiates to get inches."""
    return gev_return_level(mu, sigma, xi, return_period_T)


def gev_quantile(mu: float, sigma: float, xi: float,
                 p: float) -> float:
    """Inverse-CDF: F^{-1}(p)."""
    if p <= 0 or p >= 1:
        raise ValueError("p must be in (0,1)")
    yp = -np.log(p)
    if abs(xi) < 1e-8:
        return float(mu - sigma * np.log(yp))
    return float(mu - (sigma / xi) * (1.0 - yp ** (-xi)))


def gev_cdf(x: np.ndarray, mu: float, sigma: float, xi: float
            ) -> np.ndarray:
    """GEV CDF F(x)."""
    z = (np.asarray(x, dtype=float) - mu) / sigma
    if abs(xi) < 1e-8:
        return np.exp(-np.exp(-z))
    arg = 1.0 + xi * z
    out = np.zeros_like(arg, dtype=float)
    msk = arg > 0
    out[msk] = np.exp(-arg[msk] ** (-1.0 / xi))
    # Outside support: F = 0 below lower bound (xi>0), F = 1 above upper bound (xi<0)
    if xi > 0:
        out[~msk] = 0.0
    else:
        out[~msk] = 1.0
    return out


def gev_sample(rng: np.random.Generator, mu: float, sigma: float,
               xi: float, size: int) -> np.ndarray:
    """Draw a sample from GEV by inverse CDF (no scipy.stats)."""
    u = rng.uniform(size=size)
    return np.array([gev_quantile(mu, sigma, xi, ui) for ui in u])


def parametric_bootstrap_return_level(fit: dict, T: float,
                                      n_boot: int = 1000,
                                      seed: int = 0,
                                      log_space: bool = False,
                                      ) -> dict:
    """Parametric bootstrap CI for a T-year return level.

    Repeatedly samples from GEV(`mu`, `sigma`, `xi`) with the same n,
    re-fits and computes the return level. Returns dict with
    point/lower/upper/percentile-95 CI.
    """
    rng = np.random.default_rng(seed)
    mu, sigma, xi = fit["mu"], fit["sigma"], fit["xi"]
    n = fit["n"]
    rl = []
    for _ in range(int(n_boot)):
        xb = gev_sample(rng, mu, sigma, xi, n)
        try:
            fb = fit_gev_mle(xb)
        except Exception:
            continue
        rb = gev_return_level(fb["mu"], fb["sigma"], fb["xi"], T)
        rl.append(rb if not log_space else np.exp(rb))
    rl = np.array(rl)
    point = gev_return_level(mu, sigma, xi, T)
    if log_space:
        point = float(np.exp(point))
    return {
        "T": float(T),
        "point": float(point),
        "lower_95": float(np.percentile(rl, 2.5)),
        "upper_95": float(np.percentile(rl, 97.5)),
        "n_boot": int(len(rl)),
        "samples": rl,
    }


# ---------------------------------------------------------------------------
# Profile-likelihood CI (Coles 2001 eq. 2.6)
# ---------------------------------------------------------------------------


def profile_loglik_return_level(x: np.ndarray, T: float, fit: dict,
                                grid: int = 81, half_width: float = 0.5,
                                ) -> dict:
    """Profile-likelihood for a stationary GEV T-year return level.

    Reparametrises the GEV in terms of the return level z_T (mu can
    be solved for given z_T, sigma, xi) and profiles by maximising the
    likelihood over (sigma, xi) for each fixed z_T. Returns the 95%
    chi-square 1 dof confidence interval.
    """
    chi2_95 = 3.84  # qchisq(0.95, 1)
    mu0 = fit["mu"]
    sigma0 = fit["sigma"]
    xi0 = fit["xi"]
    z0 = gev_return_level(mu0, sigma0, xi0, T)
    z_grid = np.linspace(z0 * (1 - half_width), z0 * (1 + half_width), grid)
    log_lik_max = -fit["nll"]

    def nll_for_zT(z, x):
        # mu = z + (sigma/xi) * (1 - yT^-xi)
        # We optimise over (log_sigma, xi) and recover mu from z.
        yT = -np.log(1.0 - 1.0 / T)
        def f(p):
            ls, xi = p
            sigma = np.exp(ls)
            if abs(xi) < 1e-8:
                mu = z + sigma * np.log(yT)
            else:
                mu = z + (sigma / xi) * (1.0 - yT ** (-xi))
            return gev_nll((mu, ls, xi), x)
        r = minimize(f, [np.log(sigma0), xi0], method="Nelder-Mead",
                     options={"xatol": 1e-6, "fatol": 1e-6, "maxiter": 3000})
        return r.fun

    profile = np.array([nll_for_zT(z, x) for z in z_grid])
    diff = 2 * (profile - (-log_lik_max))
    # Lower CI: smallest z where diff crosses chi2_95 below z0
    below = z_grid < z0
    above = z_grid > z0
    lower_z = z0
    upper_z = z0
    bd = diff[below]; bz = z_grid[below]
    if np.any(bd >= chi2_95) and np.any(bd <= chi2_95):
        # find crossing
        idx = np.argmin(np.abs(bd - chi2_95))
        lower_z = float(bz[idx])
    elif np.any(bd <= chi2_95):
        lower_z = float(bz[np.where(bd <= chi2_95)[0][0]])
    ad = diff[above]; az = z_grid[above]
    if np.any(ad >= chi2_95) and np.any(ad <= chi2_95):
        idx = np.argmin(np.abs(ad - chi2_95))
        upper_z = float(az[idx])
    elif np.any(ad <= chi2_95):
        upper_z = float(az[np.where(ad <= chi2_95)[0][-1]])
    return {
        "z_grid": z_grid, "neg_loglik": profile, "deviance": diff,
        "z_T_point": float(z0), "lower_95": lower_z, "upper_95": upper_z,
    }


# ---------------------------------------------------------------------------
# Non-stationary GEV (location- and scale-covariate models)
# ---------------------------------------------------------------------------


def ns_gev_nll(params: np.ndarray, x: np.ndarray, c: np.ndarray,
               scale_ns: bool = False) -> float:
    """Non-stationary GEV NLL.

    If `scale_ns=False`, params = (b0, b1, b2, xi) with
        mu(c) = b0 + b1 c, ln sigma = b2.
    If `scale_ns=True`,  params = (b0, b1, b2, b3, xi) with
        mu(c) = b0 + b1 c, ln sigma(c) = b2 + b3 c.
    """
    p = list(params)
    b0, b1 = p[0], p[1]
    if not scale_ns:
        b2, xi = p[2], p[3]
        mu = b0 + b1 * c
        sigma = np.exp(b2) * np.ones_like(c)
    else:
        b2, b3, xi = p[2], p[3], p[4]
        mu = b0 + b1 * c
        sigma = np.exp(b2 + b3 * c)
    if np.any(sigma <= 0) or np.any(np.isinf(sigma)):
        return _BIG
    return _gev_nll_core(np.asarray(x, dtype=float), mu, sigma, float(xi))


def fit_ns_gev_mle(x: np.ndarray, c: np.ndarray, scale_ns: bool = False,
                   x0: Optional[Tuple] = None) -> dict:
    """MLE for the non-stationary GEV.

    Returns dict with parameters, fitted nll and AIC/BIC.
    """
    x = np.asarray(x, dtype=float)
    c = np.asarray(c, dtype=float)
    msk = ~(np.isnan(x) | np.isnan(c))
    x, c = x[msk], c[msk]
    if x0 is None:
        sigma0 = np.std(x) * np.sqrt(6) / np.pi
        b0 = float(np.mean(x))
        b2 = float(np.log(max(sigma0, 1e-3)))
        if scale_ns:
            x0 = (b0, 0.0, b2, 0.0, 0.1)
        else:
            x0 = (b0, 0.0, b2, 0.1)
    res = minimize(lambda p: ns_gev_nll(p, x, c, scale_ns=scale_ns),
                   x0, method="Nelder-Mead",
                   options={"xatol": 1e-7, "fatol": 1e-7, "maxiter": 10000})
    k = len(x0)
    n = len(x)
    aic = 2.0 * res.fun + 2.0 * k
    bic = 2.0 * res.fun + k * np.log(n)
    out = {
        "params": tuple(float(v) for v in res.x),
        "scale_ns": bool(scale_ns),
        "nll": float(res.fun),
        "n": int(n),
        "k": int(k),
        "aic": float(aic),
        "bic": float(bic),
        "converged": bool(res.success),
    }
    if scale_ns:
        b0, b1, b2, b3, xi = res.x
        out.update({"b0": float(b0), "b1": float(b1),
                    "b2": float(b2), "b3": float(b3), "xi": float(xi)})
    else:
        b0, b1, b2, xi = res.x
        out.update({"b0": float(b0), "b1": float(b1),
                    "b2": float(b2), "xi": float(xi)})
    return out


def ns_gev_return_level(fit: dict, c_value: float,
                        return_period_T: float) -> float:
    """Return level of a fitted non-stationary GEV evaluated at the
    covariate value `c_value` (e.g. CMIP5 GMST in 1980 or 2020).
    """
    if fit["scale_ns"]:
        mu = fit["b0"] + fit["b1"] * c_value
        sigma = np.exp(fit["b2"] + fit["b3"] * c_value)
    else:
        mu = fit["b0"] + fit["b1"] * c_value
        sigma = np.exp(fit["b2"])
    return gev_return_level(mu, sigma, fit["xi"], return_period_T)


# ---------------------------------------------------------------------------
# Likelihood-ratio test (Gumbel vs GEV, NS vs S, ...)
# ---------------------------------------------------------------------------


def likelihood_ratio_test(nll_null: float, nll_alt: float,
                          df: int) -> dict:
    """One-sided LRT statistic 2*(NLL_null - NLL_alt) ~ chi^2_df.

    Returns dict {'lr_stat', 'df', 'p_value', 'critical_95'}.
    The chi-square upper-tail p-value is computed via the regularised
    incomplete gamma function `gammaincc(df/2, lr/2)` from
    `scipy.special` (no scipy.stats dependency).
    """
    from scipy.special import gammaincc
    lr = 2.0 * (nll_null - nll_alt)
    p = float(gammaincc(df / 2.0, lr / 2.0))
    # 95th percentile chi-square critical values
    crit95 = {1: 3.841, 2: 5.991, 3: 7.815, 4: 9.488, 5: 11.07}.get(df, None)
    return {"lr_stat": float(lr), "df": int(df), "p_value": p,
            "critical_95": crit95,
            "reject_null_at_95": bool(lr > (crit95 or 9e9))}


def aic_bic(nll: float, k: int, n: int) -> dict:
    """Compute Akaike and Bayesian information criteria."""
    return {"aic": float(2.0 * nll + 2.0 * k),
            "bic": float(2.0 * nll + k * np.log(n))}

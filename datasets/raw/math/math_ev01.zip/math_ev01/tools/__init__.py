"""Tools for extreme value analysis (GEV / GPD) of pooled-region 1-day
rainfall block maxima. Pure numpy + scipy.optimize + matplotlib.
No scipy.stats imports — every distribution helper is implemented
from first principles in `gev_fit.py` and `gpd_fit.py`.
"""

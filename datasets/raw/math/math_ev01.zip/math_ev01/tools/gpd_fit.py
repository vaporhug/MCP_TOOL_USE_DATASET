"""
Generalised Pareto distribution (GPD) primitives for peaks-over-
threshold analysis. Pure numpy + scipy.optimize.

GPD CDF (Coles 2001 chapter 4):
    F(y; sigma, xi) = 1 - (1 + xi y/sigma)^(-1/xi)   for xi != 0,
                    1 - exp(-y/sigma)               for xi == 0
where y = x - threshold > 0.

Mean residual life plot (Coles 2001 eq. 4.6) and threshold-stability
plots support threshold selection.
"""

from __future__ import annotations

from typing import Tuple, Optional

import numpy as np
from scipy.optimize import minimize


_BIG = 1e10


def gpd_nll(params: Tuple[float, float], excesses: np.ndarray) -> float:
    """Negative log-likelihood of the GPD.

    `params = (log_sigma, xi)` so that sigma = exp(log_sigma) > 0.
    """
    log_sigma, xi = params
    if not (-10 < log_sigma < 8):
        return _BIG
    sigma = np.exp(log_sigma)
    y = np.asarray(excesses, dtype=float)
    if np.any(y <= 0):
        return _BIG
    if abs(xi) < 1e-8:
        return float(np.sum(np.log(sigma) + y / sigma))
    arg = 1.0 + xi * y / sigma
    if np.any(arg <= 0):
        return _BIG
    return float(np.sum(np.log(sigma) + (1.0 + 1.0 / xi) * np.log(arg)))


def fit_gpd_mle(excesses: np.ndarray) -> dict:
    """MLE of the GPD by minimising `gpd_nll`.

    Returns dict with sigma, xi, nll, n, k, aic.
    """
    y = np.asarray(excesses, dtype=float)
    y = y[~np.isnan(y)]
    if len(y) < 3:
        raise ValueError("need at least 3 exceedances for GPD MLE")
    s0 = float(np.mean(y))
    x0 = (np.log(s0), 0.1)
    res = minimize(lambda p: gpd_nll(tuple(p), y), x0,
                   method="Nelder-Mead",
                   options={"xatol": 1e-7, "fatol": 1e-7, "maxiter": 5000})
    log_sigma, xi = res.x
    sigma = float(np.exp(log_sigma))
    n = len(y)
    return {
        "sigma": sigma, "xi": float(xi), "log_sigma": float(log_sigma),
        "nll": float(res.fun), "n": int(n), "k": 2,
        "aic": float(2 * res.fun + 4.0),
        "bic": float(2 * res.fun + 2 * np.log(n)),
        "converged": bool(res.success),
    }


def mean_residual_life(values: np.ndarray, thresholds: np.ndarray,
                       ) -> dict:
    """Mean residual life of values above each threshold.

    Returns dict with 'thresholds', 'mean_excess', 'n_excess',
    'lower_95', 'upper_95'. Confidence intervals use the normal
    approximation MRL +/- 1.96 * std/sqrt(n).
    """
    x = np.asarray(values, dtype=float)
    out = {"thresholds": np.asarray(thresholds, dtype=float)}
    me, lo, hi, ne = [], [], [], []
    for u in thresholds:
        ex = x[x > u] - u
        if len(ex) < 2:
            me.append(np.nan); lo.append(np.nan); hi.append(np.nan)
            ne.append(0)
            continue
        m = ex.mean()
        s = ex.std(ddof=1)
        n = len(ex)
        me.append(m)
        lo.append(m - 1.96 * s / np.sqrt(n))
        hi.append(m + 1.96 * s / np.sqrt(n))
        ne.append(n)
    out["mean_excess"] = np.array(me)
    out["lower_95"] = np.array(lo)
    out["upper_95"] = np.array(hi)
    out["n_excess"] = np.array(ne)
    return out


def gpd_return_level(threshold: float, sigma: float, xi: float,
                     n_per_year: float, return_period_T: float) -> float:
    """T-year return level from a fitted POT/GPD model.

    return_level = u + (sigma/xi) * [(T * n_per_year * zeta_u)^xi - 1]
    where zeta_u = P(X > u). The simpler form here assumes zeta_u
    is absorbed into n_per_year.

    Parameters
    ----------
    threshold : the exceedance threshold u
    sigma : GPD scale
    xi : GPD shape
    n_per_year : expected exceedances per year (lambda_u)
    return_period_T : in years
    """
    m = float(return_period_T) * float(n_per_year)
    if abs(xi) < 1e-8:
        return float(threshold + sigma * np.log(m))
    return float(threshold + (sigma / xi) * (m ** xi - 1.0))


def gpd_cdf(y: np.ndarray, sigma: float, xi: float) -> np.ndarray:
    y = np.asarray(y, dtype=float)
    if abs(xi) < 1e-8:
        return 1.0 - np.exp(-y / sigma)
    arg = 1.0 + xi * y / sigma
    out = np.zeros_like(arg, dtype=float)
    msk = arg > 0
    out[msk] = 1.0 - arg[msk] ** (-1.0 / xi)
    if xi >= 0:
        out[~msk] = 0.0
    else:
        out[~msk] = 1.0
    return out


def threshold_stability(values: np.ndarray, thresholds: np.ndarray,
                         ) -> dict:
    """Refit GPD at multiple candidate thresholds; record sigma_star
    = sigma_u - xi*u (modified scale, threshold-invariant under GPD)
    and xi.
    """
    x = np.asarray(values, dtype=float)
    rows = []
    for u in thresholds:
        y = x[x > u] - u
        if len(y) < 5:
            rows.append({"threshold": float(u), "n_excess": int(len(y)),
                          "sigma": np.nan, "xi": np.nan, "sigma_star": np.nan})
            continue
        try:
            f = fit_gpd_mle(y)
            rows.append({"threshold": float(u),
                          "n_excess": int(len(y)),
                          "sigma": f["sigma"], "xi": f["xi"],
                          "sigma_star": f["sigma"] - f["xi"] * u})
        except Exception:
            rows.append({"threshold": float(u), "n_excess": int(len(y)),
                          "sigma": np.nan, "xi": np.nan,
                          "sigma_star": np.nan})
    import pandas as pd
    return pd.DataFrame(rows)

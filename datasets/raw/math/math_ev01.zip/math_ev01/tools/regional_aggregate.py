"""
Cross-region aggregation utilities used to obtain the
spatially-averaged trend estimate from per-pooled-region GEV fits.

PAPER ALIGNMENT. The paper (Jorgensen & Nielsen-Gammon 2024, Sect. 4)
applies a Gaussian-process model in R using ``geoR::likfit`` with a
Matern covariance whose smoothness parameter kappa is *fit*, on
region centroids projected to a Lambert-conformal-conic coordinate
system. This module provides three aggregators:
  (a) a simple OLS / unweighted-mean aggregator with bootstrap CI;
  (b) ``gp_fit_trend`` — a fixed Matern-3/2 GP on haversine distance
      (kept as a lightweight baseline);
  (c) ``gp_fit_trend_variable_kappa`` — the paper-aligned GP that
      projects centroids to a Lambert-conformal-conic coordinate
      system and fits a Matern covariance with FREE smoothness
      ``kappa`` by maximum likelihood (analog of geoR::likfit's
      default fit-kappa mode). This is the entry point that
      reproduces the paper's likfit-based Sect. 4 GP aggregation.
The constant-mean GLS estimate plus its 1.96-sigma CI is reported in
both (b) and (c). Use (c) as the default for paper-faithful
domain-wide trend aggregation; (b) is retained for diagnostics.
"""

from __future__ import annotations

from typing import Optional, Tuple

import numpy as np
import pandas as pd
from scipy.linalg import cho_factor, cho_solve
from scipy.optimize import minimize


def per_region_trend(catalogue: pd.DataFrame, fit_one_region_fn,
                     value_col: str = "Mean",
                     covariate_col: str = "Temps",
                     return_period_T: float = 100.0,
                     epoch_year_then: int = 1980,
                     epoch_year_now: int = 2020,
                     scale_ns: bool = True,
                     log_response: bool = True,
                     verbose: bool = False) -> pd.DataFrame:
    """Apply `fit_one_region_fn(df, value_col, covariate_col,
    log_response, scale_ns)` to every region in the catalogue and
    record per-region 1980->2020 percentage trend in the T-year
    return level.

    `fit_one_region_fn` should return a dict with at least a
    `ns_gev_fit` and a function-callable `c_to_rl(c)` returning the
    return level at covariate c. To keep the helpers loosely coupled
    we accept any callable and return a flat dataframe.
    """
    rows = []
    for _, r in catalogue.iterrows():
        try:
            res = fit_one_region_fn(r["path"], value_col, covariate_col,
                                    log_response, scale_ns,
                                    return_period_T,
                                    epoch_year_then, epoch_year_now)
        except Exception as e:
            if verbose:
                print(f"FAIL {r['region_id']}: {e}")
            continue
        rows.append(res)
    return pd.DataFrame(rows)


def unweighted_mean_with_bootstrap(values: np.ndarray, n_boot: int = 5000,
                                    seed: int = 0) -> dict:
    """Unweighted mean of a per-region trend vector with a bootstrap CI.

    Returns dict with mean, ci_lower_95, ci_upper_95, n.
    """
    v = np.asarray(values, dtype=float)
    v = v[~np.isnan(v)]
    rng = np.random.default_rng(seed)
    boot = np.array([rng.choice(v, size=len(v), replace=True).mean()
                     for _ in range(int(n_boot))])
    return {
        "mean": float(v.mean()),
        "ci_lower_95": float(np.percentile(boot, 2.5)),
        "ci_upper_95": float(np.percentile(boot, 97.5)),
        "n": int(len(v)),
        "boot_samples": boot,
    }


# ---------------------------------------------------------------------------
# Spatial Gaussian-process aggregation
# ---------------------------------------------------------------------------


def haversine_distance_km(lat1, lon1, lat2, lon2):
    """Great-circle distance in km between (lat1,lon1) and (lat2,lon2)."""
    R = 6371.0
    lat1, lat2 = np.radians(lat1), np.radians(lat2)
    dlat = lat2 - lat1
    dlon = np.radians(lon2 - lon1)
    a = np.sin(dlat / 2) ** 2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon / 2) ** 2
    return 2 * R * np.arcsin(np.sqrt(a))


def matern_kernel_3_2(d: np.ndarray, sigma2: float, length: float
                      ) -> np.ndarray:
    """Matern 3/2 covariance K(d) = sigma^2 (1+sqrt(3)d/l) exp(-sqrt(3)d/l)."""
    r = np.sqrt(3.0) * d / length
    return sigma2 * (1.0 + r) * np.exp(-r)


def matern_kernel_general(d: np.ndarray, sigma2: float, length: float,
                          kappa: float) -> np.ndarray:
    """General Matern covariance with smoothness ``kappa``.

    Implements the standard parameterisation
        K(d) = sigma^2 * 2^(1-kappa)/Gamma(kappa) * (sqrt(2*kappa)*d/l)^kappa
                * K_kappa(sqrt(2*kappa)*d/l)
    where ``K_kappa`` is the modified Bessel function of the second
    kind. For kappa=0.5 this collapses to exponential; kappa=1.5 to
    Matern-3/2; kappa=2.5 to Matern-5/2; kappa=inf to squared
    exponential. This matches the paper's geoR::likfit
    parameterisation (Jorgensen & Nielsen-Gammon 2024) where kappa is
    a free parameter fit by likelihood.
    """
    from math import gamma as _gamma
    from scipy.special import kv as _kv
    d = np.asarray(d, dtype=float)
    out = np.zeros_like(d, dtype=float)
    mask = d > 1e-12
    arg = np.sqrt(2.0 * kappa) * d[mask] / length
    coef = sigma2 * (2.0 ** (1.0 - kappa)) / _gamma(kappa)
    out[mask] = coef * (arg ** kappa) * _kv(kappa, arg)
    # Diagonal / zero-distance entries
    out[~mask] = sigma2
    return out


def gp_fit_trend_variable_kappa(
    coords: np.ndarray, values: np.ndarray,
    nugget: float = 1e-6, init_length_km: float = 200.0,
    init_kappa: float = 1.5, kappa_bounds: Tuple[float, float] = (0.3, 5.0),
    use_lambert: bool = True,
) -> dict:
    """Paper-aligned Matern GP with FREE smoothness parameter (geoR::likfit
    analog) on Lambert-projected centroids.

    This is the paper's Sect. 4 Gaussian-process aggregation method:
    centroids are projected to a Lambert conformal conic coordinate
    system (here: a simple sec-aware Lambert projection centered on
    the centroid mean), pairwise Euclidean distances in km are
    formed, and a Matern covariance with FREE smoothness ``kappa``
    plus length-scale and signal variance is fit by maximum
    likelihood. The constant-mean GLS estimate plus its standard
    error is reported. Compared with :func:`gp_fit_trend` (which
    fixes kappa=1.5 / Matern-3/2 and uses haversine distance), this
    is a faithful reproduction of the paper's likfit-based GP step.
    """
    from math import gamma as _gamma
    from scipy.special import kv as _kv
    coords = np.asarray(coords, dtype=float)
    v = np.asarray(values, dtype=float)
    n = len(v)
    if use_lambert:
        # Lambert conformal conic projection following the paper's Sect. 2f
        # convention: standard parallels at FIXED 33°N and 45°N (matches
        # geoR::likfit setup used in Jorgensen & Nielsen-Gammon 2024).
        # Centered longitude is the centroid mean (Texas - North Carolina
        # span), and the reference latitude is at the centroid mean.
        R_KM = 6371.0088
        lat_ref = np.radians(coords[:, 0].mean())
        lon_ref = np.radians(coords[:, 1].mean())
        phi1 = np.radians(33.0)
        phi2 = np.radians(45.0)
        n_lcc = np.log(np.cos(phi1) / np.cos(phi2)) / \
            np.log(np.tan(np.pi/4 + phi2/2) / np.tan(np.pi/4 + phi1/2))
        F = np.cos(phi1) * (np.tan(np.pi/4 + phi1/2) ** n_lcc) / n_lcc
        lat = np.radians(coords[:, 0]); lon = np.radians(coords[:, 1])
        rho = R_KM * F / (np.tan(np.pi/4 + lat/2) ** n_lcc)
        rho_ref = R_KM * F / (np.tan(np.pi/4 + lat_ref/2) ** n_lcc)
        x = rho * np.sin(n_lcc * (lon - lon_ref))
        y = rho_ref - rho * np.cos(n_lcc * (lon - lon_ref))
        # Pairwise Euclidean distances in km in the Lambert plane
        dx = x[:, None] - x[None, :]
        dy = y[:, None] - y[None, :]
        D = np.sqrt(dx ** 2 + dy ** 2)
    else:
        D = np.zeros((n, n))
        for i in range(n):
            D[i] = haversine_distance_km(coords[i, 0], coords[i, 1],
                                         coords[:, 0], coords[:, 1])

    def nll(p):
        log_s2, log_l, log_k = p
        s2 = np.exp(log_s2); l = np.exp(log_l); k = np.exp(log_k)
        if not (kappa_bounds[0] <= k <= kappa_bounds[1]):
            return 1e9
        K = matern_kernel_general(D, s2, l, k) + nugget * np.eye(n)
        try:
            L, low = cho_factor(K, lower=True)
        except np.linalg.LinAlgError:
            return 1e9
        ones = np.ones(n)
        Kinv_y = cho_solve((L, low), v)
        Kinv_1 = cho_solve((L, low), ones)
        mu = (ones @ Kinv_y) / (ones @ Kinv_1)
        r = v - mu
        Kinv_r = cho_solve((L, low), r)
        log_det = 2 * np.sum(np.log(np.diag(L)))
        return 0.5 * (r @ Kinv_r) + 0.5 * log_det + 0.5 * n * np.log(2 * np.pi)

    res = minimize(nll, [np.log(max(np.var(v), 1e-6)), np.log(init_length_km),
                          np.log(init_kappa)],
                   method="Nelder-Mead",
                   options={"xatol": 1e-6, "fatol": 1e-6, "maxiter": 8000,
                            "adaptive": True})
    log_s2, log_l, log_k = res.x
    s2 = float(np.exp(log_s2)); l = float(np.exp(log_l)); k = float(np.exp(log_k))
    K = matern_kernel_general(D, s2, l, k) + nugget * np.eye(n)
    L, low = cho_factor(K, lower=True)
    ones = np.ones(n)
    Kinv_y = cho_solve((L, low), v)
    Kinv_1 = cho_solve((L, low), ones)
    mean_var_inv = ones @ Kinv_1
    mu_hat = float((ones @ Kinv_y) / mean_var_inv)
    se_mu = float(1.0 / np.sqrt(mean_var_inv))
    return {
        "sigma2": s2, "length_km": l, "kappa": k, "nugget": float(nugget),
        "mean": mu_hat, "se_mean": se_mu,
        "ci_lower_95": float(mu_hat - 1.96 * se_mu),
        "ci_upper_95": float(mu_hat + 1.96 * se_mu),
        "nll": float(res.fun), "n": int(n),
        "projection": "lambert_conformal_conic" if use_lambert else "haversine",
        "kappa_bounds": kappa_bounds,
    }


def gp_fit_trend(coords: np.ndarray, values: np.ndarray,
                  nugget: float = 1e-6, init_length_km: float = 200.0
                  ) -> dict:
    """Fit a constant-mean Matern-3/2 GP to the (coords, values) using
    MLE for (sigma2, length) and report the GLS estimate of the mean
    plus its standard error.

    `coords` is (n,2) [lat, lon]; distances computed in km via haversine.
    """
    coords = np.asarray(coords, dtype=float)
    v = np.asarray(values, dtype=float)
    n = len(v)
    # Pairwise distance matrix
    D = np.zeros((n, n))
    for i in range(n):
        D[i] = haversine_distance_km(coords[i, 0], coords[i, 1],
                                     coords[:, 0], coords[:, 1])

    def nll(p):
        log_s2, log_l = p
        s2 = np.exp(log_s2); l = np.exp(log_l)
        K = matern_kernel_3_2(D, s2, l) + nugget * np.eye(n)
        try:
            L, low = cho_factor(K, lower=True)
        except np.linalg.LinAlgError:
            return 1e9
        ones = np.ones(n)
        Kinv_y = cho_solve((L, low), v)
        Kinv_1 = cho_solve((L, low), ones)
        mu = (ones @ Kinv_y) / (ones @ Kinv_1)
        r = v - mu
        Kinv_r = cho_solve((L, low), r)
        log_det = 2 * np.sum(np.log(np.diag(L)))
        return 0.5 * (r @ Kinv_r) + 0.5 * log_det + 0.5 * n * np.log(2 * np.pi)

    res = minimize(nll, [np.log(np.var(v)), np.log(init_length_km)],
                   method="Nelder-Mead",
                   options={"xatol": 1e-6, "fatol": 1e-6, "maxiter": 5000})
    log_s2, log_l = res.x
    s2 = float(np.exp(log_s2)); l = float(np.exp(log_l))
    K = matern_kernel_3_2(D, s2, l) + nugget * np.eye(n)
    L, low = cho_factor(K, lower=True)
    ones = np.ones(n)
    Kinv_y = cho_solve((L, low), v)
    Kinv_1 = cho_solve((L, low), ones)
    mean_var_inv = ones @ Kinv_1
    mu_hat = float((ones @ Kinv_y) / mean_var_inv)
    se_mu = float(1.0 / np.sqrt(mean_var_inv))
    return {
        "sigma2": s2, "length_km": l, "nugget": float(nugget),
        "mean": mu_hat, "se_mean": se_mu,
        "ci_lower_95": float(mu_hat - 1.96 * se_mu),
        "ci_upper_95": float(mu_hat + 1.96 * se_mu),
        "nll": float(res.fun), "n": int(n),
    }

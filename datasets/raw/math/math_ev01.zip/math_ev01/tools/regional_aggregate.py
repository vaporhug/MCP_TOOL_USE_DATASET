"""
Cross-region aggregation utilities used to obtain the
spatially-averaged trend estimate from per-pooled-region GEV fits.

The original paper applies a Gaussian-process model to per-region
trend estimates assigned to region centroids. Here we provide both
(a) a simple OLS / unweighted-mean aggregator with bootstrap CI,
and (b) a Matern-kernel GP regression over a Lambert-projection of
the centroids that mirrors the paper's methodology while staying
in pure numpy + scipy.optimize.
"""

from __future__ import annotations

from typing import Optional, Tuple

import numpy as np
import pandas as pd
from scipy.linalg import cho_factor, cho_solve
from scipy.optimize import minimize


def per_region_trend(catalogue: pd.DataFrame, fit_one_region_fn,
                     value_col: str = "Mean",
                     covariate_col: str = "Temps",
                     return_period_T: float = 100.0,
                     epoch_year_then: int = 1980,
                     epoch_year_now: int = 2020,
                     scale_ns: bool = True,
                     log_response: bool = True,
                     verbose: bool = False) -> pd.DataFrame:
    """Apply `fit_one_region_fn(df, value_col, covariate_col,
    log_response, scale_ns)` to every region in the catalogue and
    record per-region 1980->2020 percentage trend in the T-year
    return level.

    `fit_one_region_fn` should return a dict with at least a
    `ns_gev_fit` and a function-callable `c_to_rl(c)` returning the
    return level at covariate c. To keep the helpers loosely coupled
    we accept any callable and return a flat dataframe.
    """
    rows = []
    for _, r in catalogue.iterrows():
        try:
            res = fit_one_region_fn(r["path"], value_col, covariate_col,
                                    log_response, scale_ns,
                                    return_period_T,
                                    epoch_year_then, epoch_year_now)
        except Exception as e:
            if verbose:
                print(f"FAIL {r['region_id']}: {e}")
            continue
        rows.append(res)
    return pd.DataFrame(rows)


def unweighted_mean_with_bootstrap(values: np.ndarray, n_boot: int = 5000,
                                    seed: int = 0) -> dict:
    """Unweighted mean of a per-region trend vector with a bootstrap CI.

    Returns dict with mean, ci_lower_95, ci_upper_95, n.
    """
    v = np.asarray(values, dtype=float)
    v = v[~np.isnan(v)]
    rng = np.random.default_rng(seed)
    boot = np.array([rng.choice(v, size=len(v), replace=True).mean()
                     for _ in range(int(n_boot))])
    return {
        "mean": float(v.mean()),
        "ci_lower_95": float(np.percentile(boot, 2.5)),
        "ci_upper_95": float(np.percentile(boot, 97.5)),
        "n": int(len(v)),
        "boot_samples": boot,
    }


# ---------------------------------------------------------------------------
# Spatial Gaussian-process aggregation
# ---------------------------------------------------------------------------


def haversine_distance_km(lat1, lon1, lat2, lon2):
    """Great-circle distance in km between (lat1,lon1) and (lat2,lon2)."""
    R = 6371.0
    lat1, lat2 = np.radians(lat1), np.radians(lat2)
    dlat = lat2 - lat1
    dlon = np.radians(lon2 - lon1)
    a = np.sin(dlat / 2) ** 2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon / 2) ** 2
    return 2 * R * np.arcsin(np.sqrt(a))


def matern_kernel_3_2(d: np.ndarray, sigma2: float, length: float
                      ) -> np.ndarray:
    """Matern 3/2 covariance K(d) = sigma^2 (1+sqrt(3)d/l) exp(-sqrt(3)d/l)."""
    r = np.sqrt(3.0) * d / length
    return sigma2 * (1.0 + r) * np.exp(-r)


def gp_fit_trend(coords: np.ndarray, values: np.ndarray,
                  nugget: float = 1e-6, init_length_km: float = 200.0
                  ) -> dict:
    """Fit a constant-mean Matern-3/2 GP to the (coords, values) using
    MLE for (sigma2, length) and report the GLS estimate of the mean
    plus its standard error.

    `coords` is (n,2) [lat, lon]; distances computed in km via haversine.
    """
    coords = np.asarray(coords, dtype=float)
    v = np.asarray(values, dtype=float)
    n = len(v)
    # Pairwise distance matrix
    D = np.zeros((n, n))
    for i in range(n):
        D[i] = haversine_distance_km(coords[i, 0], coords[i, 1],
                                     coords[:, 0], coords[:, 1])

    def nll(p):
        log_s2, log_l = p
        s2 = np.exp(log_s2); l = np.exp(log_l)
        K = matern_kernel_3_2(D, s2, l) + nugget * np.eye(n)
        try:
            L, low = cho_factor(K, lower=True)
        except np.linalg.LinAlgError:
            return 1e9
        ones = np.ones(n)
        Kinv_y = cho_solve((L, low), v)
        Kinv_1 = cho_solve((L, low), ones)
        mu = (ones @ Kinv_y) / (ones @ Kinv_1)
        r = v - mu
        Kinv_r = cho_solve((L, low), r)
        log_det = 2 * np.sum(np.log(np.diag(L)))
        return 0.5 * (r @ Kinv_r) + 0.5 * log_det + 0.5 * n * np.log(2 * np.pi)

    res = minimize(nll, [np.log(np.var(v)), np.log(init_length_km)],
                   method="Nelder-Mead",
                   options={"xatol": 1e-6, "fatol": 1e-6, "maxiter": 5000})
    log_s2, log_l = res.x
    s2 = float(np.exp(log_s2)); l = float(np.exp(log_l))
    K = matern_kernel_3_2(D, s2, l) + nugget * np.eye(n)
    L, low = cho_factor(K, lower=True)
    ones = np.ones(n)
    Kinv_y = cho_solve((L, low), v)
    Kinv_1 = cho_solve((L, low), ones)
    mean_var_inv = ones @ Kinv_1
    mu_hat = float((ones @ Kinv_y) / mean_var_inv)
    se_mu = float(1.0 / np.sqrt(mean_var_inv))
    return {
        "sigma2": s2, "length_km": l, "nugget": float(nugget),
        "mean": mu_hat, "se_mean": se_mu,
        "ci_lower_95": float(mu_hat - 1.96 * se_mu),
        "ci_upper_95": float(mu_hat + 1.96 * se_mu),
        "nll": float(res.fun), "n": int(n),
    }

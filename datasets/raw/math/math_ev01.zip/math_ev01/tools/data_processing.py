"""
Data loading and pre-processing primitives for the pooled-region
1-day rainfall block-maxima dataset.

Each pooled-region CSV (named `<STATE><REGION>dBad1-12.csv`, e.g.
`AL101dBad1-12.csv`) holds one row per calendar year 1890-2019 with:

  * Year                  : int
  * <County>Date          : per-county date of annual 1-day max
  * <County>              : per-county annual 1-day maximum (inches)
  * Mean                  : pooled-region annual block max (mean of
                            simultaneously-recording counties), inches
  * Events                : number of distinct dates contributing
  * Stns                  : number of stations contributing
  * AcDate / Ac           : areal composite date / value
  * lnCO2                 : ln(CO2) in ppm
  * nino34, SOI           : ENSO indices
  * Temps                 : CMIP5 multi-model-mean annual GMST (K)

Source: Jorgensen 2022 Texas Data Repository,
DOI 10.18738/T8/GP4SPQ.
"""

from __future__ import annotations

import os
import re
from typing import Optional

import numpy as np
import pandas as pd


# Paper Section 4 / page 11 defines the Gulf Coast subdomain as Texas,
# Arkansas, Louisiana, Mississippi, Alabama and *western* Florida (FL
# panhandle counties), not the full FL state. The bundle's pooled
# regions are state-level files; to match the paper exactly,
# Gulf-Coast aggregation should drop peninsular FL pooled regions
# (FL001/FL101/FL201 panhandle ids vs FL3xx/FL4xx peninsula ids in
# the upstream Texas Data Repository convention). GULF_STATES below
# is the *state-set* (Florida appears in both subdomains); use
# GULF_FL_REGIONS / SE_FL_REGIONS to split FL pooled regions, or
# call helper ``is_gulf_region(region_id)`` which encodes the
# state+region split rather than state alone.
GULF_STATES = ("TX", "AR", "LA", "MS", "AL", "FL")
SE_STATES = ("GA", "SC", "NC", "FL")  # FL peninsula joins SE subdomain
# FL pooled-region ids that belong to the western/panhandle Gulf
# subdomain (paper Section 4: "Texas, Arkansas, Louisiana, Mississippi,
# Alabama, and western Florida"). Other FL ids (peninsula) belong to
# the southeastern subdomain. The pooled-region catalogue ships
# FL101..FL701; FL101 and FL201 are the panhandle/western pooled
# regions per pooled_regions_index.csv state geography.
GULF_FL_REGIONS = ("FL101", "FL201")
SE_FL_REGIONS  = ("FL301", "FL401", "FL501", "FL601", "FL701")


def is_gulf_region(region_id: str) -> bool:
    """True if a pooled-region id is in the paper-defined Gulf-Coast
    subdomain (TX/AR/LA/MS/AL + western FL panhandle).
    """
    state = region_id[:2]
    if state == "FL":
        return region_id[:5] in GULF_FL_REGIONS
    return state in ("TX", "AR", "LA", "MS", "AL")


def is_se_region(region_id: str) -> bool:
    """True if a pooled-region id is in the paper-defined southeastern
    subdomain (GA/SC/NC + peninsular FL).
    """
    state = region_id[:2]
    if state == "FL":
        return region_id[:5] in SE_FL_REGIONS
    return state in ("GA", "SC", "NC")


def list_pooled_region_files(data_dir: str) -> pd.DataFrame:
    """Discover all pooled-region CSVs in `data_dir` and return a
    catalogue with one row per region.
    """
    out = []
    for fn in sorted(os.listdir(data_dir)):
        m = re.match(r"^([A-Z]{2})([0-9A-F])(\d\d)dBad1-12\.csv$", fn)
        if not m:
            continue
        state, region_top, region_sub = m.group(1), m.group(2), m.group(3)
        region_id = f"{state}{region_top}{region_sub}"
        path = os.path.join(data_dir, fn)
        out.append({
            "region_id": region_id,
            "state": state,
            "filename": fn,
            "path": path,
        })
    return pd.DataFrame(out)


def load_pooled_region(path: str) -> pd.DataFrame:
    """Read a single pooled-region CSV and return a tidy dataframe.

    Drops the unnamed leading index column.
    """
    df = pd.read_csv(path)
    if df.columns[0].startswith("Unnamed") or df.columns[0] == "":
        df = df.drop(columns=df.columns[0])
    return df


def get_pooled_block_maxima(df: pd.DataFrame,
                            value_col: str = "Mean",
                            covariate_col: Optional[str] = "Temps",
                            apply_perica_correction: bool = True,
                            ) -> pd.DataFrame:
    """Extract the (Year, value, covariate) block-maxima series from
    a pooled-region dataframe; rows with NaN in either field are
    dropped.

    Paper Methods (Jorgensen & Nielsen-Gammon 2024, following Perica
    et al. 2018): daily totals are multiplied by 1.11 prior to
    return-period analysis to correct for fixed observation windows
    under-sampling true daily maxima. ``apply_perica_correction`` now
    defaults to ``True`` to match the paper's headline pipeline; pass
    ``False`` to retain raw block-maxima values for diagnostic /
    pre-correction analyses.
    """
    cols = ["Year", value_col]
    if covariate_col is not None:
        cols.append(covariate_col)
    sub = df[cols].dropna().copy()
    sub = sub.rename(columns={value_col: "block_max"})
    if covariate_col is not None:
        sub = sub.rename(columns={covariate_col: "covariate"})
    if apply_perica_correction:
        # Paper / Perica et al. 2018: multiply daily totals by 1.11 to
        # correct for fixed-observation-window under-sampling.
        sub["block_max"] = sub["block_max"] * 1.11
    sub = sub.sort_values("Year").reset_index(drop=True)
    return sub


def get_county_block_maxima(df: pd.DataFrame, county: str) -> pd.DataFrame:
    """Extract the (Year, block_max, date) series for one county.
    """
    if county not in df.columns:
        raise KeyError(f"county column {county} not in dataframe")
    sub = df[["Year", county, f"{county}Date"]].copy()
    sub = sub.rename(columns={county: "block_max",
                              f"{county}Date": "date"})
    sub = sub.dropna(subset=["block_max"]).reset_index(drop=True)
    return sub


def get_pooled_county_composite_block_maxima(
    df: pd.DataFrame,
    covariate_col: Optional[str] = "Temps",
    apply_perica_correction: bool = True,
) -> pd.DataFrame:
    """Paper-aligned pooled-region block-maxima sample.

    The reference paper (Jorgensen & Nielsen-Gammon 2024, Sect. 2c-d)
    performs the pooled-region GEV fit on *all county-composite block
    maxima within a pooled region as a single population* — i.e. each
    (county, year) is one observation in the fit, NOT the pre-averaged
    `Mean` column. This helper returns the long-format dataframe with
    columns ``Year``, ``County``, ``block_max`` and (optionally) the
    annual covariate replicated per county-year row.

    Use this entry point — together with :func:`fit_ns_gev_mle_paper` —
    to reproduce the paper's pooled NS-GEV likelihood; use
    :func:`get_pooled_block_maxima` only for diagnostic per-region-Mean
    series (which is NOT the paper's main fit).
    """
    counties = list_counties(df)
    rows = []
    for _, r in df.iterrows():
        year = int(r["Year"])
        cov = r[covariate_col] if covariate_col is not None else None
        for c in counties:
            v = r.get(c)
            if pd.isna(v):
                continue
            row = {"Year": year, "County": c, "block_max": float(v)}
            if covariate_col is not None:
                row["covariate"] = cov
            rows.append(row)
    sub = pd.DataFrame(rows)
    if apply_perica_correction and "block_max" in sub.columns and len(sub) > 0:
        sub["block_max"] = sub["block_max"] * 1.11
    if len(sub) > 0:
        sub = sub.sort_values(["Year", "County"]).reset_index(drop=True)
    return sub


def list_counties(df: pd.DataFrame) -> list:
    """Return the list of county names available in a pooled-region df.
    """
    counties = []
    for c in df.columns:
        if c.endswith("Date") and c not in ("AcDate",):
            base = c[:-4]
            if base in df.columns:
                counties.append(base)
    return counties


# ---------------------------------------------------------------------------
# Pooling for cross-region analysis
# ---------------------------------------------------------------------------

def stack_pooled_series(catalogue: pd.DataFrame,
                        value_col: str = "Mean",
                        covariate_col: Optional[str] = "Temps",
                        states: Optional[tuple] = None,
                        ) -> pd.DataFrame:
    """Stack pooled-region series across multiple regions into one
    long dataframe with columns
       region_id, state, year, block_max[, covariate].

    If `states` is given, restrict to those state codes.
    """
    rows = []
    for _, r in catalogue.iterrows():
        if states is not None and r["state"] not in states:
            continue
        df = load_pooled_region(r["path"])
        sub = get_pooled_block_maxima(df, value_col, covariate_col)
        sub.insert(0, "region_id", r["region_id"])
        sub.insert(1, "state", r["state"])
        rows.append(sub)
    if not rows:
        return pd.DataFrame()
    return pd.concat(rows, ignore_index=True)


# ---------------------------------------------------------------------------
# Threshold-exceedance pre-processing for POT / GPD analysis
# ---------------------------------------------------------------------------

def daily_county_threshold_exceedances(df: pd.DataFrame, county: str,
                                       threshold: float) -> pd.DataFrame:
    """Return county annual block-maxima exceedances above a threshold.

    The pooled CSV stores **annual** maxima only (one observation per
    year per county) — call this 'annual peaks-over-threshold' or AMS
    + threshold. Returns the rows where the annual max exceeded the
    threshold, with an `excess = block_max - threshold` column.
    """
    cm = get_county_block_maxima(df, county)
    out = cm[cm["block_max"] > threshold].copy()
    out["excess"] = out["block_max"] - threshold
    return out


def pooled_threshold_exceedances(catalogue: pd.DataFrame, threshold: float,
                                  states: Optional[tuple] = None,
                                  value_col: str = "Mean",
                                  ) -> pd.DataFrame:
    """Threshold exceedances on the pooled-region series across regions.
    """
    long = stack_pooled_series(catalogue, value_col=value_col,
                               covariate_col=None, states=states)
    out = long[long["block_max"] > threshold].copy()
    out["excess"] = out["block_max"] - threshold
    return out


# ---------------------------------------------------------------------------
# Empirical helpers
# ---------------------------------------------------------------------------

def empirical_return_period(values: np.ndarray) -> tuple:
    """Compute Weibull-plotting-position empirical return periods.

    Returns (sorted_values, return_periods) for an annual series.
    return_period_i = (n+1) / (n+1-rank_i)  using the largest = highest period.
    """
    x = np.asarray(values, dtype=float)
    x = x[~np.isnan(x)]
    n = len(x)
    sorted_x = np.sort(x)
    ranks = np.arange(1, n + 1)
    # Weibull plotting position p_i = i/(n+1); return period 1/(1-p_i)
    p = ranks / (n + 1.0)
    rp = 1.0 / (1.0 - p)
    return sorted_x, rp


def log_transform(values: np.ndarray) -> np.ndarray:
    """Element-wise natural log; raises if any non-positive."""
    x = np.asarray(values, dtype=float)
    if np.any(x <= 0):
        raise ValueError("non-positive values cannot be log-transformed")
    return np.log(x)


def percent_change(value_then: float, value_now: float) -> float:
    """Percentage change in a return level between two epochs."""
    return (value_now - value_then) / value_then * 100.0


def temp_for_year(df: pd.DataFrame, year: int,
                   col: str = "Temps") -> float:
    """Look up the CMIP5 GMST covariate for a given calendar year.
    Falls back to nearest available year if the requested year is missing.
    """
    sub = df.dropna(subset=[col])
    if year in sub["Year"].values:
        return float(sub.loc[sub["Year"] == year, col].iloc[0])
    diffs = (sub["Year"] - year).abs()
    return float(sub.loc[diffs.idxmin(), col])


def gulf_subregion_states() -> tuple:
    """Return the six Gulf-Coast state codes used in the paper."""
    return GULF_STATES


def southeast_subregion_states() -> tuple:
    """Return the three southeast-coast state codes used in the paper."""
    return SE_STATES

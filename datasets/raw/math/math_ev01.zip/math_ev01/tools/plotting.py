"""
Matplotlib plotting helpers for extreme-value analyses. Each
function writes a PNG and returns {"path": <out_path>}.

No interactive display, headless backend.
"""

from __future__ import annotations

from typing import Optional, Sequence, Tuple

import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


def plot_block_maxima(years: np.ndarray, values: np.ndarray,
                      title: str, out_path: str,
                      ylabel: str = "1-day rainfall (in)",
                      xlabel: str = "Year",
                      mark_years: Optional[Sequence[int]] = None,
                      figsize=(8, 4)) -> dict:
    """Time-series scatter / step plot of annual block maxima."""
    fig, ax = plt.subplots(figsize=figsize)
    ax.plot(years, values, "o-", color="#264653", lw=1, markersize=4,
            label="annual block max")
    if mark_years is not None:
        for y in mark_years:
            ax.axvline(y, color="#e76f51", ls="--", alpha=0.7)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return {"path": out_path}


def plot_return_level(empirical_levels: np.ndarray,
                      empirical_periods: np.ndarray,
                      curve_periods: np.ndarray,
                      curve_levels: np.ndarray,
                      lower_levels: Optional[np.ndarray],
                      upper_levels: Optional[np.ndarray],
                      title: str, out_path: str,
                      ylabel: str = "Return level (in)",
                      figsize=(7, 5)) -> dict:
    """GEV return level plot.

    Empirical points are placed at Weibull plotting positions; the
    fitted curve is overlaid on a logarithmic return-period axis.
    """
    fig, ax = plt.subplots(figsize=figsize)
    ax.semilogx(empirical_periods, empirical_levels, "o", color="#264653",
                markersize=4, label="empirical")
    ax.semilogx(curve_periods, curve_levels, "-", color="#e76f51",
                lw=2, label="GEV MLE fit")
    if lower_levels is not None and upper_levels is not None:
        ax.fill_between(curve_periods, lower_levels, upper_levels,
                        alpha=0.2, color="#e76f51", label="95% CI")
    ax.set_xlabel("Return period (yr)")
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.grid(alpha=0.3, which="both")
    ax.legend()
    fig.tight_layout()
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return {"path": out_path}


def plot_qq_gev(values: np.ndarray, mu: float, sigma: float, xi: float,
                title: str, out_path: str, log_space: bool = False,
                figsize=(5.5, 5.5)) -> dict:
    """GEV QQ plot using the Weibull plotting position."""
    from .gev_fit import gev_quantile
    x = np.asarray(values, dtype=float)
    x = np.sort(x[~np.isnan(x)])
    n = len(x)
    p = (np.arange(1, n + 1) - 0.5) / n
    theo = np.array([gev_quantile(mu, sigma, xi, pi) for pi in p])
    fig, ax = plt.subplots(figsize=figsize)
    ax.plot(theo, x, "o", color="#264653", markersize=4)
    lo = min(np.min(theo), np.min(x))
    hi = max(np.max(theo), np.max(x))
    ax.plot([lo, hi], [lo, hi], "--", color="#e76f51")
    suffix = " (log space)" if log_space else ""
    ax.set_xlabel("Theoretical GEV quantile" + suffix)
    ax.set_ylabel("Empirical quantile" + suffix)
    ax.set_title(title)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return {"path": out_path}


def plot_qq_gpd(excesses: np.ndarray, sigma: float, xi: float,
                title: str, out_path: str, figsize=(5.5, 5.5)) -> dict:
    """GPD QQ plot."""
    y = np.sort(np.asarray(excesses, dtype=float))
    n = len(y)
    p = (np.arange(1, n + 1) - 0.5) / n
    if abs(xi) < 1e-8:
        theo = -sigma * np.log(1 - p)
    else:
        theo = sigma / xi * ((1 - p) ** (-xi) - 1)
    fig, ax = plt.subplots(figsize=figsize)
    ax.plot(theo, y, "o", color="#264653", markersize=4)
    lo = min(np.min(theo), np.min(y)); hi = max(np.max(theo), np.max(y))
    ax.plot([lo, hi], [lo, hi], "--", color="#e76f51")
    ax.set_xlabel("Theoretical GPD quantile")
    ax.set_ylabel("Empirical excess quantile")
    ax.set_title(title)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return {"path": out_path}


def plot_mean_residual_life(mrl: dict, title: str, out_path: str,
                            figsize=(7, 4)) -> dict:
    """Mean residual life plot with 95% normal-approx CI."""
    fig, ax = plt.subplots(figsize=figsize)
    ax.plot(mrl["thresholds"], mrl["mean_excess"], "-", color="#264653")
    ax.fill_between(mrl["thresholds"], mrl["lower_95"], mrl["upper_95"],
                    alpha=0.2, color="#264653", label="95% CI")
    ax.set_xlabel("Threshold u (in)")
    ax.set_ylabel("Mean excess  E[X-u | X>u]")
    ax.set_title(title)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return {"path": out_path}


def plot_ns_return_levels(years: np.ndarray, rl_2yr: np.ndarray,
                          rl_100yr: np.ndarray,
                          ci_2yr: Optional[Tuple[np.ndarray, np.ndarray]] = None,
                          ci_100yr: Optional[Tuple[np.ndarray, np.ndarray]] = None,
                          obs_years: Optional[np.ndarray] = None,
                          obs_values: Optional[np.ndarray] = None,
                          title: str = "Non-stationary return levels",
                          out_path: str = "ns_rl.png",
                          ylabel: str = "Return level (in)",
                          figsize=(8, 5)) -> dict:
    """Time-trace of 2-yr and 100-yr return levels under a non-stationary
    GEV with covariate evolving in time."""
    fig, ax = plt.subplots(figsize=figsize)
    if obs_years is not None and obs_values is not None:
        ax.plot(obs_years, obs_values, "o", color="#bbbbbb", markersize=3,
                label="annual block max")
    ax.plot(years, rl_2yr, "-", color="#2a9d8f", lw=2, label="2-yr return level")
    if ci_2yr is not None:
        ax.fill_between(years, ci_2yr[0], ci_2yr[1], alpha=0.2,
                        color="#2a9d8f")
    ax.plot(years, rl_100yr, "-", color="#e76f51", lw=2,
            label="100-yr return level")
    if ci_100yr is not None:
        ax.fill_between(years, ci_100yr[0], ci_100yr[1], alpha=0.2,
                        color="#e76f51")
    ax.set_xlabel("Year")
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.grid(alpha=0.3)
    ax.legend()
    fig.tight_layout()
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return {"path": out_path}


def plot_regional_trend_map(regions: pd.DataFrame, value_col: str,
                            title: str, out_path: str,
                            cmap: str = "RdBu_r",
                            vlim: Optional[Tuple[float, float]] = None,
                            figsize=(8, 5)) -> dict:
    """Scatter map of per-region trend at region centroids."""
    fig, ax = plt.subplots(figsize=figsize)
    if vlim is None:
        v = float(np.nanmax(np.abs(regions[value_col])))
        vlim = (-v, v)
    sc = ax.scatter(regions["lon"], regions["lat"], c=regions[value_col],
                    s=80, cmap=cmap, vmin=vlim[0], vmax=vlim[1],
                    edgecolor="k", linewidth=0.4)
    cbar = fig.colorbar(sc, ax=ax, fraction=0.04, pad=0.03)
    cbar.set_label(value_col)
    ax.set_xlabel("Longitude (deg)")
    ax.set_ylabel("Latitude (deg)")
    ax.set_title(title)
    ax.grid(alpha=0.2)
    fig.tight_layout()
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return {"path": out_path}


def plot_aic_bar(model_table: pd.DataFrame, value_col: str,
                 title: str, out_path: str,
                 figsize=(7, 4)) -> dict:
    """Horizontal bar plot of AIC / BIC across competing models."""
    fig, ax = plt.subplots(figsize=figsize)
    ax.barh(model_table["model"], model_table[value_col],
            color="#264653")
    for i, v in enumerate(model_table[value_col]):
        ax.text(v, i, f"  {v:.2f}", va="center")
    ax.set_xlabel(value_col.upper())
    ax.set_title(title)
    ax.grid(alpha=0.3, axis="x")
    fig.tight_layout()
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return {"path": out_path}

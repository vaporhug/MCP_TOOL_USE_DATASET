"""
Stubs for external database lookups referenced in the task.

The pooled-region 1-day rainfall dataset and the NOAA-Atlas-14
benchmark return values are bundled in `input_data/data/`; the
helpers below merely document the canonical online location for
record-keeping.
"""

from __future__ import annotations

from typing import Optional


JORGENSEN_BLOCK_MAXIMA_DOI = "10.18738/T8/GP4SPQ"
JORGENSEN_RETURN_VALUES_DOI = "10.18738/T8/0ESMAS"
NOAA_ATLAS14_VOL2 = "https://hdsc.nws.noaa.gov/hdsc/pfds/pfds_map_cont.html"


def dataverse_file_url(file_id: int) -> str:
    """Construct a Texas Data Repository download URL for a numeric file id.
    """
    return f"https://dataverse.tdl.org/api/access/datafile/{int(file_id)}"


def cite_block_maxima_dataset() -> dict:
    """Return citation metadata for the bundled pooled-region CSVs."""
    return {
        "title": "1-day Rainfall Block Maxima Data",
        "authors": ["Jorgensen, Savannah"],
        "doi": JORGENSEN_BLOCK_MAXIMA_DOI,
        "publisher": "Texas Data Repository",
        "url": ("https://dataverse.tdl.org/dataset.xhtml?"
                f"persistentId=doi:{JORGENSEN_BLOCK_MAXIMA_DOI}"),
        "license": "CC0 1.0",
    }


def cite_return_values_dataset() -> dict:
    """Return citation metadata for the bundled qcd01d2019pds.csv."""
    return {
        "title": "Stationary and nonstationary return values",
        "authors": ["Jorgensen, Savannah"],
        "doi": JORGENSEN_RETURN_VALUES_DOI,
        "publisher": "Texas Data Repository",
        "url": ("https://dataverse.tdl.org/dataset.xhtml?"
                f"persistentId=doi:{JORGENSEN_RETURN_VALUES_DOI}"),
        "license": "CC0 1.0",
    }


def cite_noaa_atlas14() -> dict:
    return {
        "title": "NOAA Atlas 14 Precipitation-Frequency Atlas",
        "authors": ["Bonnin et al. (2006)", "Perica et al. (2013, 2018)"],
        "url": NOAA_ATLAS14_VOL2,
    }

"""Time series decomposition and seasonal analysis utilities."""

import numpy as np
import pandas as pd
from typing import Dict, Optional, Tuple


def seasonal_decompose(
    series: np.ndarray,
    period: int = 52,
    model: str = "additive",
) -> Dict[str, np.ndarray]:
    """Decompose time series into trend, seasonal, and residual components.

    Parameters
    ----------
    series : np.ndarray
        Time series values.
    period : int
        Seasonal period (52 for weekly data with annual cycle).
    model : str
        'additive' or 'multiplicative'.

    Returns
    -------
    dict
        'trend': trend component,
        'seasonal': seasonal component,
        'residual': residual component.
    """
    from statsmodels.tsa.seasonal import seasonal_decompose as sd

    result = sd(series, model=model, period=period, extrapolate_trend="freq")
    return {
        "trend": result.trend,
        "seasonal": result.seasonal,
        "residual": result.resid,
    }


def stl_decompose(
    series: np.ndarray,
    period: int = 52,
    seasonal_deg: int = 1,
    robust: bool = True,
) -> Dict[str, np.ndarray]:
    """STL (Seasonal and Trend decomposition using LOESS) decomposition.

    Parameters
    ----------
    series : np.ndarray
    period : int
    seasonal_deg : int
        Degree of seasonal smoothing.
    robust : bool
        Whether to use robust fitting.

    Returns
    -------
    dict
        'trend', 'seasonal', 'residual' components.
    """
    from statsmodels.tsa.seasonal import STL

    stl = STL(series, period=period, seasonal_deg=seasonal_deg, robust=robust)
    result = stl.fit()
    return {
        "trend": result.trend,
        "seasonal": result.seasonal,
        "residual": result.resid,
    }


def compute_seasonal_pattern(
    df: pd.DataFrame,
    target_col: str = "rate",
    weekid_col: str = "weekid",
) -> pd.DataFrame:
    """Compute average seasonal pattern across years.

    Parameters
    ----------
    df : pd.DataFrame
    target_col : str
    weekid_col : str

    Returns
    -------
    pd.DataFrame
        Columns: 'weekid', 'mean_rate', 'std_rate', 'median_rate'.
    """
    grouped = df.groupby(weekid_col)[target_col].agg(
        ["mean", "std", "median"]
    ).reset_index()
    grouped.columns = [weekid_col, "mean_rate", "std_rate", "median_rate"]
    return grouped


def compute_autocorrelation(
    series: np.ndarray,
    max_lag: int = 52,
) -> np.ndarray:
    """Compute autocorrelation function up to max_lag.

    Parameters
    ----------
    series : np.ndarray
    max_lag : int

    Returns
    -------
    np.ndarray
        ACF values for lags 0 to max_lag.
    """
    from statsmodels.tsa.stattools import acf

    clean = series[~np.isnan(series)]
    return acf(clean, nlags=max_lag, fft=True)


def compute_partial_autocorrelation(
    series: np.ndarray,
    max_lag: int = 20,
) -> np.ndarray:
    """Compute partial autocorrelation function.

    Parameters
    ----------
    series : np.ndarray
    max_lag : int

    Returns
    -------
    np.ndarray
        PACF values.
    """
    from statsmodels.tsa.stattools import pacf

    clean = series[~np.isnan(series)]
    return pacf(clean, nlags=max_lag)


def adf_stationarity_test(
    series: np.ndarray,
) -> Dict[str, float]:
    """Perform Augmented Dickey-Fuller test for stationarity.

    Parameters
    ----------
    series : np.ndarray

    Returns
    -------
    dict
        'adf_statistic', 'p_value', 'n_lags', 'n_obs'.
    """
    from statsmodels.tsa.stattools import adfuller

    clean = series[~np.isnan(series)]
    result = adfuller(clean, autolag="AIC")
    return {
        "adf_statistic": result[0],
        "p_value": result[1],
        "n_lags": result[2],
        "n_obs": result[3],
    }

"""Forecast evaluation metrics: RMSE, SMAPE, MAE, MAPE, WIS, coverage."""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple


def compute_rmse(
    observed: np.ndarray,
    predicted: np.ndarray,
) -> float:
    """Compute Root Mean Square Error.

    Parameters
    ----------
    observed : np.ndarray
    predicted : np.ndarray

    Returns
    -------
    float
        RMSE value.
    """
    valid = ~np.isnan(observed) & ~np.isnan(predicted)
    if valid.sum() == 0:
        return np.nan
    return float(np.sqrt(np.mean((observed[valid] - predicted[valid]) ** 2)))


def compute_mae(
    observed: np.ndarray,
    predicted: np.ndarray,
) -> float:
    """Compute Mean Absolute Error.

    Parameters
    ----------
    observed : np.ndarray
    predicted : np.ndarray

    Returns
    -------
    float
    """
    valid = ~np.isnan(observed) & ~np.isnan(predicted)
    if valid.sum() == 0:
        return np.nan
    return float(np.mean(np.abs(observed[valid] - predicted[valid])))


def compute_smape(
    observed: np.ndarray,
    predicted: np.ndarray,
) -> float:
    """Compute Symmetric Mean Absolute Percentage Error.

    SMAPE = mean(|y - yhat| / (|y| + |yhat|))

    This variant handles zero values gracefully and adds symmetry
    to eliminate skewness.

    Parameters
    ----------
    observed : np.ndarray
    predicted : np.ndarray

    Returns
    -------
    float
    """
    valid = ~np.isnan(observed) & ~np.isnan(predicted)
    o, p = observed[valid], predicted[valid]
    denom = np.abs(o) + np.abs(p)
    denom[denom == 0] = 1.0
    return float(np.mean(np.abs(o - p) / denom))


def compute_mape(
    observed: np.ndarray,
    predicted: np.ndarray,
) -> float:
    """Compute Mean Absolute Percentage Error.

    Parameters
    ----------
    observed : np.ndarray
    predicted : np.ndarray

    Returns
    -------
    float
    """
    valid = ~np.isnan(observed) & ~np.isnan(predicted) & (observed != 0)
    if valid.sum() == 0:
        return np.nan
    return float(np.mean(np.abs((observed[valid] - predicted[valid]) / observed[valid])))


def compute_wis(
    observed: np.ndarray,
    predicted_median: np.ndarray,
    lower_bounds: Dict[float, np.ndarray],
    upper_bounds: Dict[float, np.ndarray],
) -> float:
    """Compute Weighted Interval Score (WIS).

    WIS combines interval coverage and sharpness into a single
    proper scoring rule for probabilistic forecasts.

    Parameters
    ----------
    observed : np.ndarray
    predicted_median : np.ndarray
        Point forecast (median).
    lower_bounds : dict
        {alpha: lower_bound_array} for each prediction interval level.
        alpha is the nominal coverage, e.g. 0.5, 0.9, 0.95.
    upper_bounds : dict
        {alpha: upper_bound_array} for each prediction interval level.

    Returns
    -------
    float
        Mean WIS across all observations.
    """
    n = len(observed)
    alphas = sorted(lower_bounds.keys())
    K = len(alphas)

    wis_values = np.zeros(n)
    for i in range(n):
        if np.isnan(observed[i]) or np.isnan(predicted_median[i]):
            wis_values[i] = np.nan
            continue
        # Absolute error component
        ae = np.abs(observed[i] - predicted_median[i])
        # Interval score components
        is_sum = 0.0
        for alpha in alphas:
            a = 1 - alpha  # significance level
            l_i = lower_bounds[alpha][i]
            u_i = upper_bounds[alpha][i]
            width = u_i - l_i
            penalty_lower = (2.0 / a) * (l_i - observed[i]) * (observed[i] < l_i)
            penalty_upper = (2.0 / a) * (observed[i] - u_i) * (observed[i] > u_i)
            is_sum += (a / 2.0) * (width + penalty_lower + penalty_upper)

        wis_values[i] = (1.0 / (K + 0.5)) * (0.5 * ae + is_sum)

    valid = ~np.isnan(wis_values)
    return float(np.mean(wis_values[valid])) if valid.sum() > 0 else np.nan


def compute_coverage(
    observed: np.ndarray,
    lower: np.ndarray,
    upper: np.ndarray,
) -> float:
    """Compute empirical coverage of a prediction interval.

    Parameters
    ----------
    observed : np.ndarray
    lower : np.ndarray
    upper : np.ndarray

    Returns
    -------
    float
        Fraction of observations within [lower, upper].
    """
    valid = ~np.isnan(observed) & ~np.isnan(lower) & ~np.isnan(upper)
    if valid.sum() == 0:
        return np.nan
    covered = (observed[valid] >= lower[valid]) & (observed[valid] <= upper[valid])
    return float(covered.mean())


def evaluate_by_horizon(
    forecast_df: pd.DataFrame,
    horizons: Optional[List[int]] = None,
) -> pd.DataFrame:
    """Compute RMSE, MAE, SMAPE for each forecast horizon.

    Parameters
    ----------
    forecast_df : pd.DataFrame
        Must have columns: 'horizon', 'forecast', 'observed'.
    horizons : list of int or None
        Horizons to evaluate. If None, uses all unique horizons.

    Returns
    -------
    pd.DataFrame
        Columns: 'horizon', 'rmse', 'mae', 'smape', 'n_obs'.
    """
    if horizons is None:
        horizons = sorted(forecast_df["horizon"].unique())

    results = []
    for h in horizons:
        sub = forecast_df[forecast_df["horizon"] == h]
        obs = sub["observed"].values
        pred = sub["forecast"].values
        results.append(
            {
                "horizon": h,
                "rmse": compute_rmse(obs, pred),
                "mae": compute_mae(obs, pred),
                "smape": compute_smape(obs, pred),
                "n_obs": len(sub),
            }
        )
    return pd.DataFrame(results)


def relative_performance(
    model_metric: float,
    baseline_metric: float,
) -> float:
    """Compute performance relative to baseline.

    Parameters
    ----------
    model_metric : float
        Model's metric value (e.g. RMSE).
    baseline_metric : float
        Baseline model's metric value.

    Returns
    -------
    float
        Ratio model/baseline. Values < 1 indicate improvement.
    """
    if baseline_metric == 0 or np.isnan(baseline_metric):
        return np.nan
    return model_metric / baseline_metric


def compare_models(
    forecast_dict: Dict[str, pd.DataFrame],
    metric: str = "rmse",
) -> pd.DataFrame:
    """Compare multiple models' performance across all horizons.

    Parameters
    ----------
    forecast_dict : dict
        {model_name: forecast_df}. Each df has 'horizon', 'forecast', 'observed'.
    metric : str
        'rmse', 'mae', or 'smape'.

    Returns
    -------
    pd.DataFrame
        Rows = models, columns = horizons + 'overall'.
    """
    all_results = {}
    for name, df in forecast_dict.items():
        by_h = evaluate_by_horizon(df)
        row = {}
        for _, r in by_h.iterrows():
            row[f"h{int(r['horizon'])}"] = r[metric]
        # Overall
        obs = df["observed"].values
        pred = df["forecast"].values
        if metric == "rmse":
            row["overall"] = compute_rmse(obs, pred)
        elif metric == "mae":
            row["overall"] = compute_mae(obs, pred)
        else:
            row["overall"] = compute_smape(obs, pred)
        all_results[name] = row

    return pd.DataFrame(all_results).T

"""Ensemble forecasting methods: SAE, NBE, AWAE, AWBE."""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple


def simple_average_ensemble(
    forecasts: Dict[str, np.ndarray],
    observed: np.ndarray,
    n_top: int = 2,
    min_history: int = 5,
) -> np.ndarray:
    """Simple Average Ensemble (SAE): rolling average of the top-N models.

    INPUT-SHAPE REQUIREMENT: ``forecasts[model]`` and ``observed`` MUST be
    1-D arrays of length n_origins, aligned chronologically by forecast
    origin (one row per forecast origin per horizon if you pivot the
    flattened rolling-forecast table; this function CANNOT accept a flat
    (origin, horizon) interleaved table because then ``observed[:t]`` at
    row t inside a same-origin block would include future-target
    observations from the same origin). Build a per-horizon wide table
    (one column per model, one row per origin) BEFORE calling this
    function — the rolling_ml_forecast / rolling_statistical_forecast
    outputs need to be pivoted into per-(origin, horizon) wide form first.
    A defensive assertion below checks that the inputs are 1-D, but it
    cannot detect the (origin, horizon) flattening mistake — read the
    EXPECTED_METRICS.md note.

    Strictly rolling / out-of-sample: at each forecast origin ``t`` the top-N
    models are selected using ONLY the realised errors from origins strictly
    before ``t`` (an expanding window of past observations), then their
    unweighted mean is taken for ``t``. No information from week ``t`` or later
    is used to choose the models, so the full test-period ``observed`` is never
    consulted when producing the forecast at ``t``.

    Parameters
    ----------
    forecasts : dict
        {model_name: array of forecasts}. All arrays must be the same length,
        ordered chronologically.
    observed : np.ndarray
        Observed values aligned with forecasts (chronological).
    n_top : int
        Number of top models to average.
    min_history : int
        Minimum number of past observations required before model selection
        kicks in; before that, all models are averaged.

    Returns
    -------
    np.ndarray
        Ensemble forecast array (same length as the inputs).
    """
    for _name, _fc in forecasts.items():
        assert np.asarray(_fc).ndim == 1, f"SAE/NBE expect 1-D forecast arrays (one row per origin per horizon, pivoted); got shape {np.asarray(_fc).shape} for model {_name!r}"
    model_names = list(forecasts.keys())
    fc_matrix = np.column_stack([forecasts[m] for m in model_names])
    n = fc_matrix.shape[0]
    ensemble = np.full(n, np.nan)

    for t in range(n):
        if t < min_history:
            # Not enough history to rank: average all available models.
            ensemble[t] = np.nanmean(fc_matrix[t, :])
            continue
        # Rank models on PAST errors only (origins 0 .. t-1).
        rmses = {}
        for i, name in enumerate(model_names):
            past_fc = fc_matrix[:t, i]
            past_obs = observed[:t]
            valid = ~np.isnan(past_fc) & ~np.isnan(past_obs)
            if valid.sum() > 0:
                rmses[name] = np.sqrt(np.mean((past_fc[valid] - past_obs[valid]) ** 2))
            else:
                rmses[name] = np.inf
        top_models = sorted(rmses, key=rmses.get)[:n_top]
        top_idx = [model_names.index(m) for m in top_models]
        ensemble[t] = np.nanmean(fc_matrix[t, top_idx])

    return ensemble


def normal_blending_ensemble(
    forecasts: Dict[str, np.ndarray],
    observed: np.ndarray,
    min_history: int = 10,
) -> np.ndarray:
    """Normal Blending Ensemble (NBE): rolling LASSO blend of model forecasts.

    INPUT-SHAPE REQUIREMENT (identical to simple_average_ensemble): the
    inputs MUST be 1-D arrays of length n_origins per horizon, pivoted
    from the rolling-forecast table BEFORE calling. Do NOT feed a flat
    (origin x horizon) interleaved table — observed[:t] inside a
    same-origin block would otherwise leak future-target observations
    from the same origin.

    Strictly rolling / out-of-sample: at each forecast origin ``t`` a LASSO
    regression of observed ILI+ on the individual model forecasts is fit using
    ONLY pairs from origins strictly before ``t`` (an expanding window), and
    the fitted weights are then applied to the forecasts at ``t``. The weights
    are not constrained to sum to one and may be negative. The full test-period
    ``observed`` is never used to fit the weights for week ``t``.

    Parameters
    ----------
    forecasts : dict
        {model_name: array of forecasts}, chronological.
    observed : np.ndarray
        Observed values aligned with forecasts (chronological).
    min_history : int
        Minimum number of past pairs required before fitting the LASSO; before
        that, all models are averaged equally.

    Returns
    -------
    np.ndarray
        Ensemble forecast array (same length as the inputs).
    """
    from sklearn.linear_model import Lasso

    model_names = list(forecasts.keys())
    X = np.column_stack([forecasts[m] for m in model_names])
    n = X.shape[0]
    ensemble = np.full(n, np.nan)

    for t in range(n):
        past_valid = ~np.isnan(X[:t]).any(axis=1) & ~np.isnan(observed[:t])
        if past_valid.sum() < min_history or np.isnan(X[t]).any():
            ensemble[t] = np.nanmean(X[t, :])
            continue
        X_v, y_v = X[:t][past_valid], observed[:t][past_valid]
        lasso = Lasso(alpha=0.1, max_iter=5000)
        lasso.fit(X_v, y_v)
        ensemble[t] = float(lasso.predict(X[t : t + 1])[0])

    return ensemble


def exponential_decay_weights(
    n_past: int,
    decay_rate: float = 0.384,
) -> np.ndarray:
    """Compute exponential time-decay weights for past observations.

    The returned weights are aligned with a CHRONOLOGICALLY ORDERED history
    (index 0 = oldest observation, index ``n_past-1`` = most recent, i.e.
    week ``t-1``). The most recent observation receives the highest weight,
    decaying exponentially into the past:

        w_{t-1-k} = exp(-lambda * k),   k = 0 (most recent) .. n_past-1 (oldest)

    so that ``weights[-1]`` (most recent) is the largest and ``weights[0]``
    (oldest) is the smallest. This matches the paper's scheme of "assigning
    the highest weight to the most recent (t-1)" used by the AWAE/AWBE models.

    Parameters
    ----------
    n_past : int
        Number of past time points (ordered oldest-first).
    decay_rate : float
        Lambda parameter for exponential decay.

    Returns
    -------
    np.ndarray
        Array of weights aligned oldest-first, most recent = highest weight.
    """
    # arange reversed so k=0 (highest weight) lands on the most recent (last)
    # element of an oldest-first history.
    k = np.arange(n_past)[::-1]
    weights = np.exp(-decay_rate * k)
    return weights / weights.sum()


def adaptive_weighted_average_ensemble(
    forecast_history: Dict[str, List[np.ndarray]],
    observed_history: List[float],
    current_forecasts: Dict[str, float],
    decay_rate: float = 0.384,
    n_top: int = 3,
) -> float:
    """Adaptive Weighted Average Ensemble (AWAE).

    Select top-N models based on exponentially-weighted RMSE,
    then average their forecasts with equal weight.

    Parameters
    ----------
    forecast_history : dict
        {model_name: list of past forecast values}.
    observed_history : list of float
        Past observed values.
    current_forecasts : dict
        {model_name: current forecast value}.
    decay_rate : float
        Exponential decay parameter.
    n_top : int
        Number of top models to select.

    Returns
    -------
    float
        Ensemble forecast for the current time step.
    """
    n = len(observed_history)
    if n == 0:
        return np.mean(list(current_forecasts.values()))

    weights = exponential_decay_weights(n, decay_rate)
    model_wrmse = {}

    for name in forecast_history:
        # Keep weights aligned with the chronological position i (so the most
        # recent valid observation keeps the highest weight after the fix).
        sq_err = []
        w_sel = []
        for i in range(n):
            fi = forecast_history[name][i]
            oi = observed_history[i]
            if not (np.isnan(fi) or np.isnan(oi)):
                sq_err.append((fi - oi) ** 2)
                w_sel.append(weights[i])
        errors = np.array(sq_err)
        w = np.array(w_sel)
        if len(errors) > 0 and w.sum() > 0:
            model_wrmse[name] = np.sqrt(np.sum(w * errors) / np.sum(w))
        else:
            model_wrmse[name] = np.inf

    top_models = sorted(model_wrmse, key=model_wrmse.get)[:n_top]
    return np.mean([current_forecasts[m] for m in top_models])


def adaptive_weighted_blending_ensemble(
    forecast_history: Dict[str, List[np.ndarray]],
    observed_history: List[float],
    current_forecasts: Dict[str, float],
    decay_rate: float = 0.384,
) -> float:
    """Adaptive Weighted Blending Ensemble (AWBE).

    Fit weighted LASSO regression using exponential time-decay
    on historical forecast-observation pairs, then apply to
    current forecasts.

    Parameters
    ----------
    forecast_history : dict
        {model_name: list of past forecast values}.
    observed_history : list of float
    current_forecasts : dict
        {model_name: current forecast value}.
    decay_rate : float

    Returns
    -------
    float
        Ensemble forecast for the current time step.
    """
    from sklearn.linear_model import Lasso

    model_names = list(forecast_history.keys())
    n = len(observed_history)
    if n < 5:
        return np.mean(list(current_forecasts.values()))

    X = np.column_stack([forecast_history[m] for m in model_names])
    y = np.array(observed_history)
    weights = exponential_decay_weights(n, decay_rate)

    valid = ~np.isnan(X).any(axis=1) & ~np.isnan(y)
    X_v, y_v, w_v = X[valid], y[valid], weights[valid]

    lasso = Lasso(alpha=0.1, max_iter=5000)
    lasso.fit(X_v, y_v, sample_weight=w_v)

    x_curr = np.array([[current_forecasts[m] for m in model_names]])
    return float(lasso.predict(x_curr)[0])


def grid_search_decay_rate(
    forecast_history: Dict[str, List[np.ndarray]],
    observed_history: List[float],
    method: str = "awae",
    decay_candidates: Optional[List[float]] = None,
    n_top: int = 3,
) -> float:
    """Grid search over decay rate lambda on training data.

    Parameters
    ----------
    forecast_history : dict
    observed_history : list of float
    method : str
        'awae' or 'awbe'.
    decay_candidates : list of float or None
        Candidate decay rates. Defaults to np.arange(0.05, 1.0, 0.05).
    n_top : int
        Number of top models (for AWAE).

    Returns
    -------
    float
        Best decay rate.
    """
    if decay_candidates is None:
        decay_candidates = list(np.arange(0.05, 1.0, 0.05))

    best_rate = 0.384
    best_rmse = np.inf
    n = len(observed_history)

    for rate in decay_candidates:
        errors = []
        for t in range(max(5, n // 2), n):
            fh = {m: forecast_history[m][:t] for m in forecast_history}
            oh = observed_history[:t]
            cf = {m: forecast_history[m][t] for m in forecast_history}

            if method == "awae":
                pred = adaptive_weighted_average_ensemble(fh, oh, cf, rate, n_top)
            else:
                pred = adaptive_weighted_blending_ensemble(fh, oh, cf, rate)

            if not np.isnan(pred) and not np.isnan(observed_history[t]):
                errors.append((pred - observed_history[t]) ** 2)

        if errors:
            rmse = np.sqrt(np.mean(errors))
            if rmse < best_rmse:
                best_rmse = rmse
                best_rate = rate

    return best_rate

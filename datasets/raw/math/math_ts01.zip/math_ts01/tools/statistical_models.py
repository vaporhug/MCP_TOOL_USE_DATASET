"""Statistical forecasting models: ARIMA and GARCH."""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple


def fit_arima_forecast(
    train_series: np.ndarray,
    exog_train: Optional[np.ndarray] = None,
    exog_future: Optional[np.ndarray] = None,
    horizon: int = 9,
    order: Tuple[int, int, int] = (2, 0, 2),
    seasonal_order: Optional[Tuple[int, int, int, int]] = None,
) -> Dict[str, np.ndarray]:
    """Fit ARIMA model and produce multi-step ahead forecasts.

    Parameters
    ----------
    train_series : np.ndarray
        Historical ILI+ values for fitting.
    exog_train : np.ndarray or None
        Exogenous predictors for training period.
    exog_future : np.ndarray or None
        Exogenous predictors for forecast period.
    horizon : int
        Number of steps ahead to forecast (0 to horizon-1).
    order : tuple
        (p, d, q) ARIMA order.
    seasonal_order : tuple or None
        (P, D, Q, s) seasonal order. If None, no seasonal component.

    Returns
    -------
    dict
        'forecast': array of point forecasts,
        'aic': model AIC,
        'bic': model BIC.
    """
    from statsmodels.tsa.arima.model import ARIMA

    model = ARIMA(
        train_series,
        order=order,
        seasonal_order=seasonal_order,
        exog=exog_train,
    )
    fitted = model.fit()
    fcast = fitted.forecast(steps=horizon, exog=exog_future)
    return {
        "forecast": np.array(fcast),
        "aic": fitted.aic,
        "bic": fitted.bic,
    }


def fit_garch_forecast(
    train_series: np.ndarray,
    horizon: int = 9,
    p: int = 1,
    q: int = 1,
    mean_model: str = "ARX",
    ar_order: int = 2,
    exog_train: Optional[np.ndarray] = None,
    exog_future: Optional[np.ndarray] = None,
) -> Dict[str, np.ndarray]:
    """Fit GARCH model for conditional heteroskedasticity and forecast.

    Parameters
    ----------
    train_series : np.ndarray
        Historical ILI+ values.
    horizon : int
        Forecast horizon.
    p : int
        GARCH p order.
    q : int
        GARCH q order.
    mean_model : str
        Mean model type ('ARX', 'AR', 'Constant').
    ar_order : int
        AR order for the mean model.
    exog_train : np.ndarray or None
        Exogenous variables for training.
    exog_future : np.ndarray or None
        Exogenous variables for forecasting.

    Returns
    -------
    dict
        'mean_forecast': conditional mean forecasts,
        'variance_forecast': conditional variance forecasts.
    """
    from arch import arch_model

    am = arch_model(
        train_series,
        vol="Garch",
        p=p,
        q=q,
        mean=mean_model,
        lags=ar_order,
        x=exog_train,
    )
    res = am.fit(disp="off")
    fcast = res.forecast(horizon=horizon, x=exog_future)
    mean_fc = fcast.mean.iloc[-1].values
    var_fc = fcast.variance.iloc[-1].values
    return {
        "mean_forecast": mean_fc,
        "variance_forecast": var_fc,
    }


def auto_arima_select(
    train_series: np.ndarray,
    exog: Optional[np.ndarray] = None,
    max_p: int = 5,
    max_q: int = 5,
    d: int = 0,
    criterion: str = "aic",
) -> Tuple[int, int, int]:
    """Select best ARIMA(p,d,q) order by information criterion.

    Parameters
    ----------
    train_series : np.ndarray
    exog : np.ndarray or None
    max_p, max_q : int
        Maximum AR and MA orders to search.
    d : int
        Differencing order.
    criterion : str
        'aic' or 'bic'.

    Returns
    -------
    tuple
        Best (p, d, q) order.
    """
    from statsmodels.tsa.arima.model import ARIMA

    best_score = np.inf
    best_order = (1, d, 1)
    for p in range(max_p + 1):
        for q in range(max_q + 1):
            if p == 0 and q == 0:
                continue
            try:
                model = ARIMA(train_series, order=(p, d, q), exog=exog)
                res = model.fit()
                score = res.aic if criterion == "aic" else res.bic
                if score < best_score:
                    best_score = score
                    best_order = (p, d, q)
            except Exception:
                continue
    return best_order


def rolling_statistical_forecast(
    df: pd.DataFrame,
    target_col: str,
    predictor_cols: List[str],
    train_start_idx: int,
    train_end_idx: int,
    test_end_idx: int,
    horizon: int = 9,
    model_type: str = "arima",
    refit_weekly: bool = True,
) -> pd.DataFrame:
    """Generate rolling forecasts using ARIMA or GARCH over the test period.

    At each week t in the test period, fit the model on ILI+ data up to week
    t-1 and forecast weeks t to t+horizon-1.

    Leakage policy. Only information available at the forecast origin is used.
    ILI+ is reported with a one-week delay, so the endogenous series is fit on
    ``target[train_start_idx:t]`` (i.e. up to week t-1). Meteorological
    predictors for the FUTURE weeks t .. t+horizon-1 are NOT available at the
    forecast origin and are therefore NOT supplied to the multi-step forecast
    (no future-weather leakage). When ``predictor_cols`` is non-empty the
    exogenous block is still used for FITTING (training rows up to t-1); for
    the out-of-sample horizon the future exogenous values are persisted at the
    last observed value (week t-1) rather than read from the future, so the
    forecast never consumes unseen weather.

    Parameters
    ----------
    df : pd.DataFrame
    target_col : str
    predictor_cols : list of str
    train_start_idx : int
        Index of first training observation.
    train_end_idx : int
        Index of last training observation.
    test_end_idx : int
        Index of last test observation.
    horizon : int
        Number of steps to forecast (including nowcast at t).
    model_type : str
        'arima' or 'garch'.
    refit_weekly : bool
        If True, refit model each week.

    Returns
    -------
    pd.DataFrame
        Columns: 'forecast_origin', 'horizon', 'forecast', 'observed'.
    """
    results = []
    target = df[target_col].values

    for t in range(train_end_idx + 1, test_end_idx + 1):
        train_y = target[train_start_idx:t]
        exog_tr = df[predictor_cols].values[train_start_idx:t] if predictor_cols else None

        max_h = min(horizon, test_end_idx - t + 1)
        if max_h <= 0:
            continue

        # Future weather is unavailable at the forecast origin: persist the
        # last observed predictor row (week t-1) across the horizon instead of
        # reading df[...][t : t+max_h], which would leak future weather.
        if predictor_cols and exog_tr is not None and len(exog_tr) > 0:
            last_known = exog_tr[-1]
            exog_fu = np.tile(last_known, (max_h, 1))
        else:
            exog_fu = None

        try:
            if model_type == "arima":
                out = fit_arima_forecast(
                    train_y, exog_train=exog_tr, exog_future=exog_fu, horizon=max_h
                )
                fc = out["forecast"]
            else:
                out = fit_garch_forecast(
                    train_y, horizon=max_h, exog_train=exog_tr, exog_future=exog_fu
                )
                fc = out["mean_forecast"]
        except Exception:
            fc = np.full(max_h, np.nan)

        for h in range(max_h):
            if t + h <= test_end_idx:
                results.append(
                    {
                        "forecast_origin": t,
                        "horizon": h,
                        "forecast": fc[h],
                        "observed": target[t + h] if t + h < len(target) else np.nan,
                    }
                )

    return pd.DataFrame(results)

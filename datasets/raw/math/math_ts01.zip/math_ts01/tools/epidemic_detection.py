"""Epidemic detection and classification utilities."""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple


def detect_epidemic_onset(
    series: np.ndarray,
    threshold: float = 5.0,
    min_duration: int = 3,
) -> List[Dict]:
    """Detect epidemic onset points in the ILI+ time series.

    An epidemic is defined as a period where ILI+ exceeds the
    threshold for at least min_duration consecutive weeks.

    Parameters
    ----------
    series : np.ndarray
        ILI+ values.
    threshold : float
        ILI+ threshold for epidemic definition.
    min_duration : int
        Minimum consecutive weeks above threshold.

    Returns
    -------
    List[dict]
        List of {'start': idx, 'end': idx, 'peak': idx, 'peak_value': float}
    """
    above = series > threshold
    epidemics = []
    i = 0
    while i < len(series):
        if above[i]:
            start = i
            while i < len(series) and above[i]:
                i += 1
            end = i - 1
            if end - start + 1 >= min_duration:
                peak_idx = start + np.argmax(series[start : end + 1])
                epidemics.append(
                    {
                        "start": start,
                        "end": end,
                        "peak": peak_idx,
                        "peak_value": series[peak_idx],
                    }
                )
        else:
            i += 1
    return epidemics


def classify_epidemic_season(
    start_month: int,
) -> str:
    """Classify an epidemic as winter or summer based on onset month.

    Winter: November to April.
    Summer: May to October.

    Parameters
    ----------
    start_month : int
        Month of epidemic onset.

    Returns
    -------
    str
        'winter' or 'summer'.
    """
    return "winter" if start_month in {11, 12, 1, 2, 3, 4} else "summer"


def predict_epidemic_occurrence(
    forecast: np.ndarray,
    threshold: float = 5.0,
    min_weeks: int = 3,
) -> bool:
    """Predict whether an epidemic will occur within the forecast window.

    Parameters
    ----------
    forecast : np.ndarray
        Forecasted ILI+ values.
    threshold : float
    min_weeks : int
        Minimum consecutive weeks above threshold.

    Returns
    -------
    bool
        True if an epidemic is predicted.
    """
    above = forecast > threshold
    max_run = 0
    current_run = 0
    for val in above:
        if val:
            current_run += 1
            max_run = max(max_run, current_run)
        else:
            current_run = 0
    return max_run >= min_weeks


def evaluate_peak_prediction(
    observed: np.ndarray,
    predicted: np.ndarray,
    strict: bool = True,
) -> Dict[str, float]:
    """Evaluate accuracy of peak timing and magnitude prediction.

    Strict criterion: predicted peak week matches observed exactly,
    and predicted peak amplitude is within +/-20% of observed.

    Looser criterion: predicted peak within +/-1 week, amplitude
    within +/-50%.

    Parameters
    ----------
    observed : np.ndarray
        Observed ILI+ values for an epidemic period.
    predicted : np.ndarray
        Predicted ILI+ values for the same period.
    strict : bool
        If True, use strict criteria.

    Returns
    -------
    dict
        'timing_correct': bool, 'magnitude_correct': bool,
        'timing_error': int (weeks), 'magnitude_error': float (fraction).
    """
    obs_peak = int(np.argmax(observed))
    pred_peak = int(np.argmax(predicted))
    timing_error = abs(obs_peak - pred_peak)
    obs_mag = observed[obs_peak]
    pred_mag = predicted[pred_peak]
    mag_error = abs(pred_mag - obs_mag) / obs_mag if obs_mag > 0 else np.inf

    if strict:
        timing_ok = timing_error == 0
        mag_ok = mag_error <= 0.20
    else:
        timing_ok = timing_error <= 1
        mag_ok = mag_error <= 0.50

    return {
        "timing_correct": timing_ok,
        "magnitude_correct": mag_ok,
        "timing_error": timing_error,
        "magnitude_error": mag_error,
    }


def epidemic_classification_metrics(
    true_labels: np.ndarray,
    pred_labels: np.ndarray,
) -> Dict[str, float]:
    """Compute TPR, SPC, PPV, NPV for epidemic occurrence prediction.

    Parameters
    ----------
    true_labels : np.ndarray
        Binary array (1 = epidemic, 0 = no epidemic).
    pred_labels : np.ndarray
        Binary predictions.

    Returns
    -------
    dict
        'TPR', 'SPC' (specificity), 'PPV', 'NPV', 'accuracy'.
    """
    tp = np.sum((true_labels == 1) & (pred_labels == 1))
    tn = np.sum((true_labels == 0) & (pred_labels == 0))
    fp = np.sum((true_labels == 0) & (pred_labels == 1))
    fn = np.sum((true_labels == 1) & (pred_labels == 0))

    tpr = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    spc = tn / (tn + fp) if (tn + fp) > 0 else 0.0
    ppv = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    npv = tn / (tn + fn) if (tn + fn) > 0 else 0.0
    acc = (tp + tn) / (tp + tn + fp + fn) if (tp + tn + fp + fn) > 0 else 0.0

    return {
        "TPR": tpr,
        "SPC": spc,
        "PPV": ppv,
        "NPV": npv,
        "accuracy": acc,
    }

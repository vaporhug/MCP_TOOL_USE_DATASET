"""
Data input/output and basic preprocessing primitives for the leukemia
gene-expression analysis.

All functions operate on numpy arrays and pandas DataFrames. No sklearn,
no specialised bio packages.
"""
from __future__ import annotations

from typing import Dict, List, Optional, Tuple
import os
import numpy as np
import pandas as pd


def load_expression_matrix(path: str) -> pd.DataFrame:
    """Load a gene-by-sample expression CSV.

    The CSV has gene_id as the row index (first column) and one column
    per sample identifier. Returns a DataFrame with shape
    (n_genes, n_samples) preserving original ordering.

    Parameters
    ----------
    path : str
        Path to CSV. The file is read with index_col=0.

    Returns
    -------
    pandas.DataFrame
        Rows are gene_ids, columns are sample identifiers.
    """
    df = pd.read_csv(path, index_col=0)
    return df


def load_sample_metadata(path: str) -> pd.DataFrame:
    """Load sample-level metadata CSV with one row per sample.

    Expected columns include sample_id and subtype (allB/allT/aml).

    Parameters
    ----------
    path : str

    Returns
    -------
    pandas.DataFrame
    """
    return pd.read_csv(path)


def threshold_and_log(matrix: np.ndarray, low: float = 20.0,
                     high: float = 16000.0) -> np.ndarray:
    """Floor values at `low`, ceil at `high`, then take log10.

    This is the standard preprocessing for Affymetrix microarrays with
    background-subtracted intensities, where many entries can be
    negative or saturated. After clipping the matrix is strictly
    positive, so taking log makes sense and produces values in the
    range [log10(low), log10(high)].

    Parameters
    ----------
    matrix : array-like, shape (n_genes, n_samples)
        Raw expression values, may contain negatives and saturated
        positives.
    low : float
        Minimum allowed value before log. Defaults to 20.
    high : float
        Maximum allowed value before log. Defaults to 16000.

    Returns
    -------
    numpy.ndarray
        Same shape as input, with strictly positive log10 entries.
    """
    arr = np.asarray(matrix, dtype=float)
    clipped = np.clip(arr, low, high)
    return np.log10(clipped)


def coefficient_of_variation(matrix: np.ndarray, axis: int = 1,
                             eps: float = 1e-12) -> np.ndarray:
    """Compute coefficient of variation (std / |mean|) along an axis.

    For axis=1 with a (n_genes, n_samples) matrix this returns a length
    n_genes vector giving each gene's CV across samples.

    Parameters
    ----------
    matrix : array-like
    axis : int
        Axis to reduce.
    eps : float
        Small additive constant to avoid division by zero.

    Returns
    -------
    numpy.ndarray
    """
    arr = np.asarray(matrix, dtype=float)
    mu = arr.mean(axis=axis)
    sd = arr.std(axis=axis, ddof=0)
    return sd / (np.abs(mu) + eps)


def select_top_cv_genes(expression: pd.DataFrame, k: int = 5000,
                       eps: float = 1e-12) -> pd.DataFrame:
    """Return the top-k genes ranked by coefficient of variation across samples.

    The expression matrix is assumed to have shape (n_genes, n_samples)
    with gene_id as the row index. The output is a DataFrame with the
    same columns and at most `k` rows, ordered by descending CV.

    Parameters
    ----------
    expression : pandas.DataFrame
        Rows = genes, columns = samples.
    k : int
        Number of genes to keep.
    eps : float

    Returns
    -------
    pandas.DataFrame
        Sub-DataFrame with k rows.
    """
    cv = coefficient_of_variation(expression.values, axis=1, eps=eps)
    idx = np.argsort(-cv)[:k]
    return expression.iloc[idx].copy()


def standardize_columns_unit_norm(matrix: np.ndarray) -> np.ndarray:
    """Scale each column so it has unit L2 norm.

    Used as an optional pre-NMF normalisation step that puts samples on
    the same scale without breaking non-negativity.

    Parameters
    ----------
    matrix : array-like, shape (n_genes, n_samples), non-negative.

    Returns
    -------
    numpy.ndarray
    """
    arr = np.asarray(matrix, dtype=float)
    norms = np.linalg.norm(arr, axis=0)
    norms = np.where(norms < 1e-12, 1.0, norms)
    return arr / norms


def split_train_test_by_sample(expression: pd.DataFrame, metadata: pd.DataFrame,
                               train_ids: List[str]) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split (expression, metadata) into train and test halves by sample id.

    Parameters
    ----------
    expression : pandas.DataFrame
        Rows = genes, columns = sample ids.
    metadata : pandas.DataFrame
        Must contain a sample_id column matching expression columns.
    train_ids : list of str
        Sample ids to assign to training. The remaining columns become
        test.

    Returns
    -------
    (train_expr, train_meta, test_expr, test_meta) : DataFrames
    """
    train_set = set(train_ids)
    test_ids = [c for c in expression.columns if c not in train_set]
    train_expr = expression[train_ids].copy()
    test_expr = expression[test_ids].copy()
    train_meta = metadata.set_index('sample_id').loc[train_ids].reset_index()
    test_meta = metadata.set_index('sample_id').loc[test_ids].reset_index()
    return train_expr, train_meta, test_expr, test_meta

def preprocess_expression(matrix, lower: float = 20.0, upper: float = 16000.0,
                          top_n_cv: int = 5000):
    """Threshold + log + top-CV-gene preprocessing in one call, preserving DataFrame labels.

    Wraps `threshold_and_log` + `select_top_cv_genes` and returns a DataFrame with
    gene_id (index) and sample_id (columns) preserved through every step.

    Args:
        matrix: pandas.DataFrame from load_expression_matrix (genes x samples).
        lower: threshold clipping floor (default 20).
        upper: threshold clipping ceiling (default 16000).
        top_n_cv: number of highest-coefficient-of-variation genes to keep (default 5000).

    Returns:
        pandas.DataFrame of shape (top_n_cv, n_samples) with gene_id row labels
        and sample_id column labels, log-transformed.
    """
    import pandas as pd
    import numpy as np
    arr = np.asarray(matrix, dtype=float)
    arr = np.clip(arr, lower, upper)
    arr_log = np.log10(arr)
    df_log = pd.DataFrame(arr_log, index=matrix.index, columns=matrix.columns)
    return select_top_cv_genes(df_log, k=top_n_cv)

"""
Factor-interpretation helpers and a PCA baseline for comparison.

These tools take fitted (W, H) NMF factors plus the gene/sample names
and return tables of top features per metagene, sample loading
profiles, and PCA reconstructions for benchmarking.

Pure numpy / pandas only.
"""
from __future__ import annotations

from typing import Dict, List, Optional
import numpy as np
import pandas as pd


def top_genes_per_factor(W: np.ndarray, gene_ids: List[str],
                         top_n: int = 25) -> pd.DataFrame:
    """Return the top-`top_n` genes for each metagene (column of W).

    For each column j of W (a metagene), the genes with the largest
    W[:, j] values are reported in descending order.

    Parameters
    ----------
    W : array, shape (n_genes, k)
    gene_ids : list of str, length n_genes
    top_n : int

    Returns
    -------
    pandas.DataFrame
        Long-format frame with columns
            metagene : int factor index
            rank     : 1-based rank within that factor
            gene_id  : str
            weight   : W[gene, metagene] value
    """
    W = np.asarray(W, dtype=float)
    n_genes, k = W.shape
    rows = []
    for j in range(k):
        col = W[:, j]
        idx = np.argsort(-col)[:top_n]
        for r, i in enumerate(idx, start=1):
            rows.append({'metagene': j, 'rank': r, 'gene_id': gene_ids[int(i)],
                         'weight': float(col[i])})
    return pd.DataFrame(rows)


def basis_specificity(W: np.ndarray) -> np.ndarray:
    """Compute a simple per-gene specificity score: max(W) / sum(W).

    A score of 1 means the gene loads exclusively on a single
    metagene; a score of 1/k means uniform loading across all
    metagenes. Useful for ranking marker-like genes.

    Parameters
    ----------
    W : (n_genes, k) array.

    Returns
    -------
    numpy.ndarray of length n_genes.
    """
    W = np.asarray(W, dtype=float)
    s = W.sum(axis=1) + 1e-12
    return W.max(axis=1) / s


def sample_loading_profile(H: np.ndarray, sample_ids: List[str]) -> pd.DataFrame:
    """Format H as a tidy DataFrame of metagene-by-sample loadings.

    Parameters
    ----------
    H : array (k, n_samples)
    sample_ids : list of str, length n_samples

    Returns
    -------
    pandas.DataFrame
        Indexed by metagene_0...metagene_{k-1}, columns = sample_ids.
    """
    H = np.asarray(H, dtype=float)
    k, m = H.shape
    return pd.DataFrame(H, index=[f'metagene_{i}' for i in range(k)],
                       columns=list(sample_ids))


def pca_baseline(A: np.ndarray, k: int, center: bool = True) -> Dict:
    """Compute a rank-k PCA reconstruction of A by truncated SVD.

    The reconstruction is X_hat = U_k S_k V_k^T (after centring rows
    if `center=True`). Returns the reconstruction error in both
    Frobenius and relative-Frobenius units, and the explained variance
    ratio.

    Parameters
    ----------
    A : array (n_features, n_samples).
    k : int
        Number of components.
    center : bool
        If True the per-feature mean is subtracted before SVD and added
        back to the reconstruction.

    Returns
    -------
    dict with keys
        reconstruction : (n_features, n_samples) array
        components : (n_features, k) array (left singular vectors,
            scaled by sqrt singular values)
        loadings   : (k, n_samples) array (right singular vectors,
            scaled by sqrt singular values)
        singular_values : length-k array
        explained_variance_ratio : length-k array (each component's
            share of total Frobenius energy)
        rss : sum of squared residuals
        rel_frob : ||A - X_hat||_F / ||A||_F
    """
    A = np.asarray(A, dtype=float)
    if center:
        mu = A.mean(axis=1, keepdims=True)
        Ac = A - mu
    else:
        mu = np.zeros((A.shape[0], 1))
        Ac = A
    U, S, Vt = np.linalg.svd(Ac, full_matrices=False)
    Uk = U[:, :k]
    Sk = S[:k]
    Vk = Vt[:k]
    recon_centered = Uk @ np.diag(Sk) @ Vk
    recon = recon_centered + mu
    R = A - recon
    rss = float(np.sum(R * R))
    a_norm = float(np.sqrt(np.sum(A * A))) + 1e-12
    total = float(np.sum(S * S)) + 1e-12
    return {
        'reconstruction': recon,
        'components': Uk * np.sqrt(Sk),
        'loadings': (Vk.T * np.sqrt(Sk)).T,
        'singular_values': Sk,
        'explained_variance_ratio': (Sk * Sk) / total,
        'rss': rss,
        'rel_frob': float(np.sqrt(rss)) / a_norm,
    }


def compare_nmf_pca_reconstruction(A: np.ndarray, W: np.ndarray, H: np.ndarray,
                                  k: int) -> pd.DataFrame:
    """Side-by-side reconstruction-error comparison of fitted NMF and
    rank-matched PCA.

    Parameters
    ----------
    A : (n_features, n_samples) original matrix.
    W, H : fitted NMF factors at rank k.
    k : int (must equal H.shape[0]).

    Returns
    -------
    pandas.DataFrame
        Columns: method, rss, frob, rel_frob.
    """
    A = np.asarray(A, dtype=float)
    R = A - W @ H
    nmf_rss = float(np.sum(R * R))
    nmf_frob = float(np.sqrt(nmf_rss))
    a_norm = float(np.sqrt(np.sum(A * A))) + 1e-12
    pca = pca_baseline(A, k, center=True)
    return pd.DataFrame([
        {'method': f'NMF (k={k})', 'rss': nmf_rss, 'frob': nmf_frob,
         'rel_frob': nmf_frob / a_norm},
        {'method': f'PCA (k={k})', 'rss': pca['rss'],
         'frob': float(np.sqrt(pca['rss'])),
         'rel_frob': pca['rel_frob']},
    ])


def silhouette_score_from_consensus(C: np.ndarray, labels: np.ndarray) -> float:
    """Compute a simple consensus-based silhouette: for each sample i,
    let a_i = mean(1 - C[i, j]) over j != i in the same cluster, and
    b_i = min over other clusters of mean(1 - C[i, j]). The score is
    mean((b_i - a_i) / max(a_i, b_i)).

    Returns nan if there is only one cluster.
    """
    C = np.asarray(C, dtype=float)
    D = 1.0 - C
    labels = np.asarray(labels)
    unique = np.unique(labels)
    if len(unique) < 2:
        return float('nan')
    s = []
    for i in range(len(labels)):
        own = labels[i]
        same = (labels == own) & (np.arange(len(labels)) != i)
        if not np.any(same):
            continue
        a_i = float(D[i, same].mean())
        b_i = np.inf
        for u in unique:
            if u == own:
                continue
            mask = labels == u
            if np.any(mask):
                b_i = min(b_i, float(D[i, mask].mean()))
        denom = max(a_i, b_i)
        if denom < 1e-12:
            continue
        s.append((b_i - a_i) / denom)
    return float(np.mean(s)) if s else float('nan')

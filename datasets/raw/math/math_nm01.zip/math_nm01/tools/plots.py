"""
Plotting primitives. Each function writes a PNG to the requested
output path and returns ``{"path": output_path}``.

Uses matplotlib only; does not depend on seaborn.
"""
from __future__ import annotations

from typing import Dict, List, Optional, Sequence
import os
import numpy as np
import matplotlib

matplotlib.use('Agg')  # noqa: E402
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap


def _ensure_dir(path: str) -> None:
    d = os.path.dirname(os.path.abspath(path))
    if d and not os.path.isdir(d):
        os.makedirs(d, exist_ok=True)


def plot_consensus_heatmap(C: np.ndarray, output_path: str,
                          row_order: Optional[Sequence[int]] = None,
                          subtype_labels: Optional[Sequence[str]] = None,
                          subtype_palette: Optional[Dict[str, str]] = None,
                          title: str = 'Consensus matrix') -> Dict:
    """Plot a reordered consensus matrix as a heatmap with a side bar
    showing the true subtype labels.

    Parameters
    ----------
    C : (m, m) consensus matrix.
    output_path : str
    row_order : optional permutation; if None C is plotted as-is.
    subtype_labels : optional, length m, used to draw a coloured side
        bar with the (reordered) subtype.
    subtype_palette : dict subtype -> hex colour.
    title : str

    Returns
    -------
    {"path": output_path}
    """
    _ensure_dir(output_path)
    C = np.asarray(C, dtype=float)
    if row_order is not None:
        order = np.asarray(row_order, dtype=int)
        Cp = C[np.ix_(order, order)]
        labels_re = (np.asarray(subtype_labels)[order]
                     if subtype_labels is not None else None)
    else:
        Cp = C
        labels_re = (np.asarray(subtype_labels)
                     if subtype_labels is not None else None)

    if labels_re is not None:
        fig, axes = plt.subplots(1, 2, figsize=(8, 7),
                                gridspec_kw={'width_ratios': [0.05, 1.0]})
        ax_bar, ax = axes[0], axes[1]
    else:
        fig, ax = plt.subplots(figsize=(7, 7))
        ax_bar = None

    im = ax.imshow(Cp, cmap='RdBu_r', vmin=0.0, vmax=1.0,
                  interpolation='nearest', aspect='auto')
    ax.set_title(title)
    ax.set_xlabel('sample (reordered)')
    ax.set_ylabel('sample (reordered)')
    cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    cb.set_label('consensus probability')

    if ax_bar is not None and labels_re is not None:
        if subtype_palette is None:
            uniq = list(dict.fromkeys(labels_re.tolist()))
            cmap = plt.get_cmap('tab10')
            subtype_palette = {u: cmap(i) for i, u in enumerate(uniq)}
        bar_colors = np.array([
            matplotlib.colors.to_rgba(subtype_palette.get(l, '#888888'))
            for l in labels_re
        ]).reshape(-1, 1, 4)
        ax_bar.imshow(bar_colors, aspect='auto')
        ax_bar.set_xticks([])
        ax_bar.set_yticks([])
        ax_bar.set_title('subtype', fontsize=8)
    plt.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {'path': output_path}


def plot_cophenetic_curve(k_values: Sequence[int],
                          cophenetic: Sequence[float],
                          dispersion: Optional[Sequence[float]] = None,
                          output_path: str = 'artifacts/cophenetic_curve.png',
                          title: str = 'Cophenetic correlation vs rank') -> Dict:
    """Plot rho_k (cophenetic) and optional dispersion curve vs rank k.

    The optimal rank is conventionally the largest k just before the
    cophenetic curve drops, so we draw a vertical reference line at
    the argmax of cophenetic.
    """
    _ensure_dir(output_path)
    fig, ax = plt.subplots(figsize=(7, 5))
    ks = np.asarray(k_values)
    rho = np.asarray(cophenetic)
    ax.plot(ks, rho, marker='o', color='#3060a0', linewidth=2,
           label='cophenetic ' + r'$\rho_k$')
    ax.set_ylim(min(0.5, rho.min() - 0.05), 1.02)
    ax.set_xlabel('rank k')
    ax.set_ylabel(r'$\rho_k$ (cophenetic)')
    if dispersion is not None:
        ax2 = ax.twinx()
        ax2.plot(ks, dispersion, marker='s', color='#c04040', linewidth=1.5,
                linestyle='--', label='dispersion')
        ax2.set_ylabel('dispersion')
        ax2.set_ylim(0, 1.02)
    # Mark first noticeable drop
    drops = np.diff(rho)
    if len(drops) > 0:
        idx = int(np.argmin(drops))
        ax.axvline(ks[idx], color='black', linestyle=':',
                  alpha=0.5, label=f'largest drop at k={ks[idx]}->k={ks[idx+1]}')
    ax.legend(loc='lower left')
    ax.set_title(title)
    ax.set_xticks(ks)
    plt.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {'path': output_path}


def plot_top_genes_bars(top_genes_df, output_path: str,
                       max_per_factor: int = 15,
                       title: str = 'Top genes per metagene') -> Dict:
    """Horizontal bar chart of the top genes per metagene (one subplot
    per factor).

    Parameters
    ----------
    top_genes_df : pandas.DataFrame from `top_genes_per_factor`.
    output_path : str
    max_per_factor : int
    title : str
    """
    _ensure_dir(output_path)
    df = top_genes_df.copy()
    factors = sorted(df['metagene'].unique())
    nf = len(factors)
    fig, axes = plt.subplots(1, nf, figsize=(4 * nf, 6), sharex=False)
    if nf == 1:
        axes = [axes]
    palette = plt.get_cmap('tab10')
    for i, f in enumerate(factors):
        ax = axes[i]
        sub = df[df['metagene'] == f].sort_values('rank').head(max_per_factor)
        ax.barh(sub['gene_id'][::-1], sub['weight'][::-1], color=palette(i))
        ax.set_title(f'metagene {f}')
        ax.set_xlabel('W weight')
        ax.tick_params(axis='y', labelsize=7)
    fig.suptitle(title)
    plt.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {'path': output_path}


def plot_sample_loadings(H: np.ndarray, sample_ids: Sequence[str],
                        subtypes: Optional[Sequence[str]] = None,
                        output_path: str = 'artifacts/sample_loadings.png',
                        title: str = 'Metagene loadings per sample') -> Dict:
    """Heatmap of H (metagenes x samples) with optional subtype side bar.
    """
    _ensure_dir(output_path)
    H = np.asarray(H)
    k, m = H.shape
    H_norm = H / (H.sum(axis=0, keepdims=True) + 1e-12)
    if subtypes is not None:
        sub_arr = np.asarray(subtypes)
        order = np.argsort(sub_arr)
        H_p = H_norm[:, order]
        ids = [sample_ids[i] for i in order]
        sub_p = sub_arr[order]
    else:
        H_p = H_norm
        ids = list(sample_ids)
        sub_p = None

    if sub_p is not None:
        fig, axes = plt.subplots(2, 1, figsize=(max(8, m * 0.25), 4),
                                 gridspec_kw={'height_ratios': [0.06, 1.0]},
                                 sharex=True)
        ax_bar, ax = axes
        uniq = list(dict.fromkeys(sub_p.tolist()))
        cmap_q = plt.get_cmap('tab10')
        palette = {u: cmap_q(i) for i, u in enumerate(uniq)}
        bar = np.array([matplotlib.colors.to_rgba(palette[l])
                        for l in sub_p]).reshape(1, -1, 4)
        ax_bar.imshow(bar, aspect='auto')
        ax_bar.set_yticks([])
        ax_bar.set_xticks(np.arange(m))
        ax_bar.set_xticklabels([])
    else:
        fig, ax = plt.subplots(figsize=(max(8, m * 0.25), 3.5))

    im = ax.imshow(H_p, cmap='Blues', aspect='auto', vmin=0.0, vmax=1.0)
    ax.set_yticks(np.arange(k))
    ax.set_yticklabels([f'metagene_{i}' for i in range(k)])
    ax.set_xticks(np.arange(m))
    ax.set_xticklabels(ids, rotation=90, fontsize=6)
    ax.set_title(title)
    cb = fig.colorbar(im, ax=ax, fraction=0.02, pad=0.01)
    cb.set_label('column-normalised H')
    plt.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {'path': output_path}


def plot_reconstruction_comparison(error_df, output_path: str,
                                  title: str = 'Reconstruction error') -> Dict:
    """Bar chart of reconstruction error for several methods (e.g.
    NMF-Frobenius, NMF-KL, PCA at the same rank).

    `error_df` must have columns 'method' and 'rel_frob'.
    """
    _ensure_dir(output_path)
    df = error_df.copy()
    fig, ax = plt.subplots(figsize=(6, 4))
    colors = plt.get_cmap('tab10')(np.arange(len(df)))
    ax.bar(df['method'], df['rel_frob'], color=colors)
    ax.set_ylabel('relative Frobenius error')
    ax.set_title(title)
    for x, v in zip(df['method'], df['rel_frob']):
        ax.text(x, v + 0.005, f'{v:.3f}', ha='center', va='bottom',
                fontsize=9)
    ax.set_ylim(0, max(df['rel_frob'].max() * 1.18, 0.05))
    plt.setp(ax.get_xticklabels(), rotation=15, ha='right')
    plt.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {'path': output_path}


def plot_objective_traces(traces: Dict[str, list], output_path: str,
                          title: str = 'NMF objective vs iteration') -> Dict:
    """Plot the objective trace for one or more NMF runs on a log y-axis.

    `traces` is a dict mapping label -> list of (iteration, objective).
    """
    _ensure_dir(output_path)
    fig, ax = plt.subplots(figsize=(6, 4))
    for label, trace in traces.items():
        if not trace:
            continue
        its = [t[0] for t in trace]
        objs = [t[1] for t in trace]
        ax.plot(its, objs, marker='.', linewidth=1.2, label=label)
    ax.set_xlabel('iteration')
    ax.set_ylabel('objective')
    ax.set_yscale('log')
    ax.legend()
    ax.set_title(title)
    plt.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {'path': output_path}

"""
Consensus clustering and cophenetic correlation primitives for NMF
rank selection (Brunet et al. 2004).

The core idea is to repeatedly run NMF with different random seeds,
record per-run sample-cluster assignments via connectivity matrices,
and average them to obtain a consensus matrix C in [0, 1]^{m x m}.
The cophenetic correlation of C summarises how stable the clustering
is at a given rank k. As k grows past the structure in the data the
consensus matrix becomes diffuse and the cophenetic correlation drops.

This module performs the multi-run averaging, hierarchical reordering
of the consensus matrix (average linkage on 1 - C), and the cophenetic
correlation calculation. It uses primitives from `tools/nmf.py`.

Pure numpy / scipy.cluster.hierarchy only - no sklearn.
"""
from __future__ import annotations

from typing import Dict, List, Optional, Tuple
import numpy as np
import scipy.cluster.hierarchy as sch
import scipy.spatial.distance as ssd

from .nmf import (
    nmf_kl_mu, nmf_frobenius_mu, assign_clusters_from_H, connectivity_matrix,
)


def consensus_matrix(A: np.ndarray, k: int, n_runs: int = 50,
                    method: str = 'kl', max_iter: int = 500,
                    tol: float = 1e-5, base_seed: int = 0) -> Dict:
    """Run NMF `n_runs` times with different seeds and average the
    per-run connectivity matrices.

    Parameters
    ----------
    A : non-negative array, shape (n_features, n_samples).
    k : int
        Rank to factorise at.
    n_runs : int
        Number of independent random restarts. Brunet uses 20-50; the
        default 50 matches Figure 4.
    method : str
        'kl' for divergence updates, 'frob' for Frobenius updates.
    max_iter, tol : NMF convergence parameters per run.
    base_seed : int
        Seed for the i-th run is base_seed + i.

    Returns
    -------
    dict with keys
        consensus : (n_samples, n_samples) average connectivity in
            [0, 1]
        cluster_labels_per_run : list of length n_runs, each a
            (n_samples,) integer array
        objectives : list of n_runs final-objective values
        method, k, n_runs : echoed metadata
    """
    A = np.asarray(A, dtype=float)
    m = A.shape[1]
    accum = np.zeros((m, m), dtype=float)
    labels_runs: List[np.ndarray] = []
    objectives: List[float] = []
    for r in range(n_runs):
        seed = base_seed + r
        if method == 'kl':
            res = nmf_kl_mu(A, k, max_iter=max_iter, tol=tol, seed=seed)
        else:
            res = nmf_frobenius_mu(A, k, max_iter=max_iter, tol=tol, seed=seed)
        labels = assign_clusters_from_H(res['H'])
        accum += connectivity_matrix(labels)
        labels_runs.append(labels)
        objectives.append(res['objective'])
    C = accum / float(n_runs)
    return {
        'consensus': C,
        'cluster_labels_per_run': labels_runs,
        'objectives': objectives,
        'method': method,
        'k': k,
        'n_runs': n_runs,
    }


def reorder_by_average_linkage(C: np.ndarray) -> Dict:
    """Reorder the consensus matrix using average-linkage hierarchical
    clustering on the distance matrix 1 - C.

    Parameters
    ----------
    C : (m, m) array with values in [0, 1] and unit diagonal.

    Returns
    -------
    dict with keys
        order : (m,) integer permutation
        C_reordered : reordered consensus matrix
        linkage : the linkage matrix from `scipy.cluster.hierarchy.linkage`
        condensed_distance : the condensed distance vector (input to
            `cophenet`)
    """
    C = np.asarray(C, dtype=float)
    D = 1.0 - C
    np.fill_diagonal(D, 0.0)
    # Symmetrise to absorb numerical asymmetries
    D = 0.5 * (D + D.T)
    cond = ssd.squareform(D, checks=False)
    Z = sch.linkage(cond, method='average')
    order = sch.leaves_list(Z)
    C_re = C[np.ix_(order, order)]
    return {
        'order': order,
        'C_reordered': C_re,
        'linkage': Z,
        'condensed_distance': cond,
    }


def cophenetic_correlation(C: np.ndarray) -> float:
    """Compute the cophenetic correlation coefficient of a consensus
    matrix.

    Following Brunet et al. (2004), this is the Pearson correlation
    between the upper-triangular entries of the distance matrix
    `1 - C` and the cophenetic distances induced by the average-linkage
    dendrogram on `1 - C`.

    A consensus matrix that is a perfect block-diagonal of zeros and
    ones has rho = 1.0; a diffuse consensus has rho substantially
    below 1.

    Parameters
    ----------
    C : (m, m) consensus matrix.

    Returns
    -------
    float
    """
    reorder = reorder_by_average_linkage(C)
    Z = reorder['linkage']
    cond = reorder['condensed_distance']
    coph_dists = sch.cophenet(Z)
    # Pearson correlation of cond and coph_dists (both length m*(m-1)/2)
    a = cond - cond.mean()
    b = coph_dists - coph_dists.mean()
    denom = np.sqrt(np.sum(a * a) * np.sum(b * b))
    if denom < 1e-15:
        return 1.0
    return float(np.sum(a * b) / denom)


def cophenetic_curve(A: np.ndarray, k_values: List[int], n_runs: int = 50,
                     method: str = 'kl', max_iter: int = 500,
                     tol: float = 1e-5, base_seed: int = 0) -> Dict:
    """Compute (rho_k, dispersion_k, mean_objective_k) over a set of ranks.

    Parameters
    ----------
    A : non-negative matrix.
    k_values : list of int
        Ranks to scan, e.g. [2, 3, 4, 5, 6].
    n_runs : int
    method : 'kl' or 'frob'
    max_iter, tol : NMF parameters per run.
    base_seed : int

    Returns
    -------
    dict with keys
        k_values : list
        cophenetic : list of floats
        dispersion : list of floats - matrix dispersion of consensus,
            sum_{ij} 4 (C_{ij} - 0.5)^2 / m^2 (1 if C is binary,
            below 1 if diffuse).
        mean_objective : list of floats
        consensus_matrices : list of arrays
    """
    cophs: List[float] = []
    disps: List[float] = []
    mean_obj: List[float] = []
    matrices: List[np.ndarray] = []
    for k in k_values:
        out = consensus_matrix(A, k, n_runs=n_runs, method=method,
                               max_iter=max_iter, tol=tol,
                               base_seed=base_seed)
        C = out['consensus']
        rho = cophenetic_correlation(C)
        m = C.shape[0]
        disp = float(np.sum(4.0 * (C - 0.5) ** 2) / (m * m))
        cophs.append(rho)
        disps.append(disp)
        mean_obj.append(float(np.mean(out['objectives'])))
        matrices.append(C)
    return {
        'k_values': list(k_values),
        'cophenetic': cophs,
        'dispersion': disps,
        'mean_objective': mean_obj,
        'consensus_matrices': matrices,
    }


def hard_cluster_from_consensus(C: np.ndarray, k: int) -> np.ndarray:
    """Cut the average-linkage dendrogram of `1 - C` at k clusters.

    Returns a length-m integer label vector with values in {0,...,k-1}.
    Used to compare the NMF consensus partition with the true biological
    labels.
    """
    reorder = reorder_by_average_linkage(C)
    Z = reorder['linkage']
    labels = sch.fcluster(Z, t=k, criterion='maxclust')
    # Re-map to 0..k-1 in order of first appearance
    out = np.zeros_like(labels)
    seen = {}
    next_id = 0
    for i, lbl in enumerate(labels):
        if lbl not in seen:
            seen[lbl] = next_id
            next_id += 1
        out[i] = seen[lbl]
    return out


def confusion_against_truth(predicted: np.ndarray,
                            truth: np.ndarray,
                            class_order: Optional[List[str]] = None) -> Dict:
    """Build a contingency table and best-match cluster->class mapping.

    Greedy max-row-assignment is used to align predicted clusters with
    truth classes.

    Parameters
    ----------
    predicted : array of int, shape (m,)
    truth : array-like of str or int, shape (m,)
    class_order : list, optional
        Fixed ordering of truth labels for the table columns.

    Returns
    -------
    dict with keys
        confusion : DataFrame rows=cluster id, cols=truth class
        best_mapping : dict cluster_id -> best-match truth class
        accuracy : fraction correctly classified under that mapping
        n_misclassified : int
    """
    import pandas as pd
    pred = np.asarray(predicted)
    truth_arr = np.asarray(truth)
    if class_order is None:
        class_order = sorted(set(truth_arr.tolist()))
    cluster_ids = sorted(set(pred.tolist()))
    table = np.zeros((len(cluster_ids), len(class_order)), dtype=int)
    for ci, cid in enumerate(cluster_ids):
        for ti, t in enumerate(class_order):
            table[ci, ti] = int(np.sum((pred == cid) & (truth_arr == t)))
    df = pd.DataFrame(table, index=[f'cluster_{c}' for c in cluster_ids],
                      columns=class_order)
    # Greedy mapping: each cluster -> argmax row, no constraint that
    # mapping is bijective (more clusters than classes is allowed but
    # handled directly).
    mapping: Dict[int, str] = {}
    for ci, cid in enumerate(cluster_ids):
        mapping[int(cid)] = class_order[int(np.argmax(table[ci]))]
    correct = 0
    for cid in cluster_ids:
        mask = pred == cid
        correct += int(np.sum(truth_arr[mask] == mapping[int(cid)]))
    total = int(len(pred))
    return {
        'confusion': df,
        'best_mapping': mapping,
        'accuracy': float(correct / total) if total else 0.0,
        'n_misclassified': total - correct,
    }

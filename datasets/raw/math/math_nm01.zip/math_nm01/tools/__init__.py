"""Task tools for NMF-based class discovery on the leukemia
gene-expression dataset. Exports primitives for data IO, NMF
optimisation, consensus clustering, factor interpretation, and
plotting.
"""

from . import data_io  # noqa: F401
from . import nmf  # noqa: F401
from . import consensus  # noqa: F401
from . import interpret  # noqa: F401
from . import plots  # noqa: F401

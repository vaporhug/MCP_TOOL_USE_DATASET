"""
Non-negative matrix factorisation primitives.

Pure-numpy implementation of:
- Frobenius-norm multiplicative update rules (Lee & Seung 2001 eq. 4),
- Kullback-Leibler divergence multiplicative update rules
  (Lee & Seung 2001 eq. 5),
- Random non-negative initialisation,
- Reconstruction error tracking,
- Sample-cluster assignment from H,
- Connectivity matrix from a single run.

The two objective functions implemented are

    F_frob(A, W, H) = || A - W H ||_F^2 / 2

and the (generalised) KL divergence

    F_kl(A, W, H) = sum_{i,j} A_{ij} log(A_{ij} / (W H)_{ij})
                    - A_{ij} + (W H)_{ij}.

Inputs A are expected to be non-negative arrays of shape (n_features,
n_samples). W has shape (n_features, k); H has shape (k, n_samples).

No sklearn imports anywhere.
"""
from __future__ import annotations

from typing import Dict, Optional, Tuple
import numpy as np


def _eps_clip(x: np.ndarray, eps: float = 1e-12) -> np.ndarray:
    return np.maximum(x, eps)


def random_nonneg_init(n_features: int, n_samples: int, k: int,
                       rng: Optional[np.random.Generator] = None,
                       scale: float = 1.0) -> Tuple[np.ndarray, np.ndarray]:
    """Sample initial (W, H) uniformly on [0, scale).

    Parameters
    ----------
    n_features : int
    n_samples : int
    k : int
        Inner dimension / rank.
    rng : numpy.random.Generator, optional
    scale : float
        Upper bound of the uniform initialisation.

    Returns
    -------
    (W, H) : tuple of arrays
        W has shape (n_features, k); H has shape (k, n_samples).
    """
    if rng is None:
        rng = np.random.default_rng()
    W = rng.uniform(0.0, scale, size=(n_features, k))
    H = rng.uniform(0.0, scale, size=(k, n_samples))
    return W, H


def frobenius_objective(A: np.ndarray, W: np.ndarray, H: np.ndarray) -> float:
    """Return 0.5 * || A - W H ||_F^2."""
    diff = A - W @ H
    return 0.5 * float(np.sum(diff * diff))


def kl_objective(A: np.ndarray, W: np.ndarray, H: np.ndarray,
                 eps: float = 1e-12) -> float:
    """Return generalised KL divergence between A and W H.

    Following Lee & Seung (2001) the objective is
        sum [ A * log(A / WH) - A + WH ]
    where the convention 0 * log 0 = 0 is enforced via masking.
    """
    WH = _eps_clip(W @ H, eps)
    A_safe = np.asarray(A, dtype=float)
    mask = A_safe > 0
    term1 = np.zeros_like(A_safe)
    term1[mask] = A_safe[mask] * np.log(A_safe[mask] / WH[mask])
    return float(np.sum(term1 - A_safe + WH))


def nmf_frobenius_mu(A: np.ndarray, k: int,
                     max_iter: int = 500,
                     tol: float = 1e-5,
                     seed: Optional[int] = None,
                     W_init: Optional[np.ndarray] = None,
                     H_init: Optional[np.ndarray] = None,
                     track_every: int = 10) -> Dict:
    """Solve A approx W H by Frobenius-norm multiplicative updates.

    Updates (Lee & Seung 2001, eq. 4):
        H <- H * (W^T A) / (W^T W H + eps)
        W <- W * (A H^T) / (W H H^T + eps)

    Convergence is declared when the relative change in objective
    between two successive logged checkpoints is below `tol` or when
    `max_iter` is reached.

    Parameters
    ----------
    A : array-like, shape (n_features, n_samples), non-negative.
    k : int
        Inner rank.
    max_iter : int
    tol : float
    seed : int, optional
        Seed for `numpy.random.default_rng` if W_init/H_init not
        supplied.
    W_init, H_init : arrays, optional
        Pre-computed initialisations to support warm starts (e.g. for
        consensus clustering).
    track_every : int
        Iteration interval at which objective is logged.

    Returns
    -------
    dict with keys
        W, H : factor matrices
        objective : final Frobenius objective
        objective_trace : list of (iteration, objective)
        n_iter : iterations actually run
        converged : bool
    """
    A = np.asarray(A, dtype=float)
    n, m = A.shape
    rng = np.random.default_rng(seed)
    if W_init is None or H_init is None:
        W, H = random_nonneg_init(n, m, k, rng=rng, scale=float(A.mean()))
    else:
        W = np.array(W_init, dtype=float, copy=True)
        H = np.array(H_init, dtype=float, copy=True)

    trace = []
    prev = None
    converged = False
    n_iter = 0
    for it in range(1, max_iter + 1):
        n_iter = it
        # Update H
        numH = W.T @ A
        denH = W.T @ W @ H + 1e-12
        H *= numH / denH
        # Update W
        numW = A @ H.T
        denW = W @ (H @ H.T) + 1e-12
        W *= numW / denW
        if it % track_every == 0 or it == 1:
            obj = frobenius_objective(A, W, H)
            trace.append((it, obj))
            if prev is not None and abs(prev - obj) <= tol * max(prev, 1e-12):
                converged = True
                break
            prev = obj
    final = frobenius_objective(A, W, H)
    if not trace or trace[-1][0] != n_iter:
        trace.append((n_iter, final))
    return {
        'W': W,
        'H': H,
        'objective': final,
        'objective_trace': trace,
        'n_iter': n_iter,
        'converged': converged,
    }


def nmf_kl_mu(A: np.ndarray, k: int,
              max_iter: int = 500,
              tol: float = 1e-5,
              seed: Optional[int] = None,
              W_init: Optional[np.ndarray] = None,
              H_init: Optional[np.ndarray] = None,
              track_every: int = 10) -> Dict:
    """Solve A approx W H by KL-divergence multiplicative updates.

    Updates (Lee & Seung 2001, eq. 5):
        H_{aj} <- H_{aj} * (sum_i W_{ia} A_{ij} / (WH)_{ij}) / sum_i W_{ia}
        W_{ia} <- W_{ia} * (sum_j H_{aj} A_{ij} / (WH)_{ij}) / sum_j H_{aj}

    This is the divergence variant Brunet et al. (2004) report works
    best for the leukemia data; it tolerates Poisson-like noise rather
    than Gaussian noise.

    Parameters and outputs are analogous to `nmf_frobenius_mu`.
    """
    A = np.asarray(A, dtype=float)
    n, m = A.shape
    rng = np.random.default_rng(seed)
    if W_init is None or H_init is None:
        W, H = random_nonneg_init(n, m, k, rng=rng, scale=float(A.mean()))
    else:
        W = np.array(W_init, dtype=float, copy=True)
        H = np.array(H_init, dtype=float, copy=True)

    trace = []
    prev = None
    converged = False
    n_iter = 0
    for it in range(1, max_iter + 1):
        n_iter = it
        WH = _eps_clip(W @ H)
        # H update
        ratio = A / WH
        numH = W.T @ ratio
        sumW = W.sum(axis=0).reshape(-1, 1) + 1e-12
        H *= numH / sumW
        # Recompute WH
        WH = _eps_clip(W @ H)
        ratio = A / WH
        # W update
        numW = ratio @ H.T
        sumH = H.sum(axis=1).reshape(1, -1) + 1e-12
        W *= numW / sumH

        if it % track_every == 0 or it == 1:
            obj = kl_objective(A, W, H)
            trace.append((it, obj))
            if prev is not None and abs(prev - obj) <= tol * max(abs(prev), 1e-12):
                converged = True
                break
            prev = obj
    final = kl_objective(A, W, H)
    if not trace or trace[-1][0] != n_iter:
        trace.append((n_iter, final))
    return {
        'W': W,
        'H': H,
        'objective': final,
        'objective_trace': trace,
        'n_iter': n_iter,
        'converged': converged,
    }


def assign_clusters_from_H(H: np.ndarray) -> np.ndarray:
    """Assign each sample to the metagene with the largest loading.

    Parameters
    ----------
    H : array, shape (k, n_samples)

    Returns
    -------
    numpy.ndarray of int, shape (n_samples,)
        Each entry in {0, ..., k-1}.
    """
    return np.argmax(np.asarray(H), axis=0)


def connectivity_matrix(cluster_labels: np.ndarray) -> np.ndarray:
    """Return the symmetric (m, m) 0/1 matrix C where C_{ij} = 1 iff
    samples i and j receive the same cluster label.

    Used as the per-run building block of the consensus matrix.
    """
    labels = np.asarray(cluster_labels).reshape(-1)
    # Outer equality
    return (labels[:, None] == labels[None, :]).astype(float)


def reconstruction_error(A: np.ndarray, W: np.ndarray, H: np.ndarray) -> Dict:
    """Compute Frobenius reconstruction error and a normalised version.

    Returns dict with keys
        rss : sum of squared residuals
        frob : sqrt(rss)
        rel_frob : frob / ||A||_F
    """
    A = np.asarray(A, dtype=float)
    R = A - W @ H
    rss = float(np.sum(R * R))
    frob = float(np.sqrt(rss))
    a_frob = float(np.sqrt(np.sum(A * A))) + 1e-12
    return {'rss': rss, 'frob': frob, 'rel_frob': frob / a_frob}

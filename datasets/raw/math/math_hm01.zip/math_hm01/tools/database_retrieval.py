"""
External database retrieval helpers (DISABLED for this offline benchmark).

This task is fully self-contained: the hourly wave-height series, the
chromosome-1 G+C content series, the FTSE-100 returns and all reference papers
ship with the task under ``input_data/``. To keep the benchmark deterministic
and reproducible, the live network helpers below are DISABLED and no longer
perform any HTTP request; each raises ``RuntimeError`` directing the solver to
the bundled local files. The signatures are retained only so that any code
referencing them fails loudly rather than silently contacting a remote service.
"""

from __future__ import annotations

_OFFLINE_MSG = (
    "Network retrieval is disabled for this offline benchmark. The wave-height, "
    "G+C-content and FTSE-100 series and all reference papers are bundled under "
    "input_data/. Use those local files instead of querying external services."
)


def fetch_url(url: str, timeout: int = 30) -> str:
    """DISABLED. Network access is not allowed in this offline benchmark."""
    raise RuntimeError(_OFFLINE_MSG)


def query_doi(doi: str) -> dict:
    """DISABLED. Citation metadata for the source papers is in input_data/reference_paper/."""
    raise RuntimeError(_OFFLINE_MSG)


def query_openalex(work_id: str) -> dict:
    """DISABLED. Use the bundled reference PDFs under input_data/reference_paper/."""
    raise RuntimeError(_OFFLINE_MSG)


def websearch(query: str, n_results: int = 5) -> list:
    """DISABLED. This is a self-contained benchmark; no external search is needed."""
    raise RuntimeError(_OFFLINE_MSG)

"""
Generic external database retrieval helpers (web, DOI, OpenAlex).

These tools are kept for cross-referencing the source paper. The
hourly wave-height series and the chromosome-1 G+C content series ship
with the task in `input_data/data/`.
"""

from __future__ import annotations

import json
import urllib.parse
import urllib.request


def fetch_url(url: str, timeout: int = 30) -> str:
    """Fetch a URL and return its body as a string.

    Parameters
    ----------
    url : str
        Fully-qualified URL.
    timeout : int
        Network timeout in seconds.

    Returns
    -------
    str
        Decoded UTF-8 response body.
    """
    req = urllib.request.Request(url, headers={"User-Agent": "scp-task/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read().decode("utf-8", errors="replace")


def query_doi(doi: str) -> dict:
    """Query the doi.org content negotiation API for citation metadata.

    Parameters
    ----------
    doi : str
        Digital Object Identifier, e.g. "10.1080/01621459.2012.737745".

    Returns
    -------
    dict
        JSON payload from CrossRef (citeproc-json).
    """
    url = "https://doi.org/" + urllib.parse.quote(doi, safe="/")
    req = urllib.request.Request(
        url, headers={
            "Accept": "application/vnd.citationstyles.csl+json",
            "User-Agent": "scp-task/1.0",
        }
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read().decode("utf-8"))


def query_openalex(work_id: str) -> dict:
    """Query OpenAlex for publication metadata.

    Parameters
    ----------
    work_id : str
        Either an OpenAlex W... id or a DOI prefixed with "doi:".

    Returns
    -------
    dict
        OpenAlex JSON.
    """
    base = "https://api.openalex.org/works/"
    if work_id.startswith("doi:"):
        ident = "https://doi.org/" + work_id[4:]
        url = base + ident
    else:
        url = base + work_id
    req = urllib.request.Request(url, headers={"User-Agent": "scp-task/1.0"})
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read().decode("utf-8"))


def websearch(query: str, n_results: int = 5) -> list:
    """Stub for web-search providers; returns a list of placeholder dicts.

    The task's data ships locally; this helper is here for parity with
    other SCP tasks that interrogate the literature.

    Parameters
    ----------
    query : str
    n_results : int

    Returns
    -------
    list of dict
        Each entry has 'title', 'url', 'snippet'.
    """
    return [
        {"title": f"Result {i+1} for '{query}'",
         "url": "", "snippet": ""}
        for i in range(n_results)
    ]

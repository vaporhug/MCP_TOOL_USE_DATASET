"""
Plotting helpers for change-point detection and HMM segmentation
diagnostics. Each function writes a PNG file and returns the path.
No interactive display is performed.
"""

from __future__ import annotations

from typing import Optional, Sequence

import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch


def plot_time_series(time, values, title: str, ylabel: str,
                     out_path: str, figsize=(11, 4)) -> str:
    """Plot a single time series and save to PNG.

    Returns the output path.
    """
    fig, ax = plt.subplots(figsize=figsize)
    ax.plot(time, values, lw=0.4, color="steelblue")
    ax.set_title(title)
    ax.set_ylabel(ylabel)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=130)
    plt.close(fig)
    return out_path


def plot_changepoints_overlay(time, values, breakpoints,
                              title: str, ylabel: str,
                              out_path: str,
                              comparison_breakpoints: Optional[Sequence[int]] = None,
                              comparison_label: str = "BinSeg",
                              primary_label: str = "PELT",
                              figsize=(12, 5)) -> str:
    """Plot the time series with change-point dividers overlaid.

    Parameters
    ----------
    time : array
    values : array
    breakpoints : sequence of int
        Indices in `values` where new segments begin (primary algorithm).
    comparison_breakpoints : sequence of int, optional
        Second set of break-points (e.g. from BinSeg) drawn in dashed
        red below.
    """
    fig, ax = plt.subplots(figsize=figsize)
    ax.plot(time, values, lw=0.4, color="steelblue")
    for cp in breakpoints:
        if cp < len(time):
            ax.axvline(time[cp], color="red", lw=1.0, alpha=0.85)
    if comparison_breakpoints is not None:
        for cp in comparison_breakpoints:
            if cp < len(time):
                ax.axvline(time[cp], color="darkorange", lw=1.0,
                           ls="--", alpha=0.7)
        from matplotlib.lines import Line2D
        ax.legend(handles=[
            Line2D([0], [0], color="red", lw=1.5,
                   label=f"{primary_label} ({len(breakpoints)} cps)"),
            Line2D([0], [0], color="darkorange", lw=1.5, ls="--",
                   label=f"{comparison_label} ({len(comparison_breakpoints)} cps)"),
        ], loc="upper right")
    else:
        from matplotlib.lines import Line2D
        ax.legend(handles=[
            Line2D([0], [0], color="red", lw=1.5,
                   label=f"{primary_label} ({len(breakpoints)} cps)"),
        ], loc="upper right")
    ax.set_title(title)
    ax.set_ylabel(ylabel)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=130)
    plt.close(fig)
    return out_path


def plot_segment_variance(time, values, breakpoints,
                          title: str, ylabel: str,
                          out_path: str, figsize=(12, 4.5)) -> str:
    """Plot the differenced series colored by segment, with the per-segment
    standard deviation overlaid as a step line.
    """
    arr = np.asarray(values, dtype=float)
    bps = list(breakpoints)
    if not bps or bps[-1] != len(arr):
        bps_full = list(bps) + [len(arr)]
    else:
        bps_full = list(bps)
    starts = [0] + bps_full[:-1]
    fig, ax = plt.subplots(figsize=figsize)
    ax.plot(time, arr, lw=0.3, color="grey", alpha=0.7)
    cmap = plt.get_cmap("tab20")
    for i, (s, e) in enumerate(zip(starts, bps_full)):
        seg = arr[s:e]
        sd = seg.std(ddof=1) if len(seg) > 1 else 0.0
        ax.plot([time[s], time[min(e - 1, len(arr) - 1)]],
                [sd, sd], color=cmap(i % 20), lw=2.5)
        ax.plot([time[s], time[min(e - 1, len(arr) - 1)]],
                [-sd, -sd], color=cmap(i % 20), lw=2.5)
    ax.set_title(title)
    ax.set_ylabel(ylabel)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=130)
    plt.close(fig)
    return out_path


def plot_hmm_states_overlay(time, values, states, state_means,
                            title: str, ylabel: str,
                            out_path: str, figsize=(12, 5)) -> str:
    """Plot the time series colored by Viterbi state.

    The state legend is sorted by ascending mean.
    """
    arr = np.asarray(values, dtype=float)
    s = np.asarray(states, dtype=int)
    means = np.asarray(state_means, dtype=float)
    order = np.argsort(means)
    rank = {orig: r for r, orig in enumerate(order)}
    cmap = plt.get_cmap("viridis")
    K = len(means)
    colors = [cmap(i / max(K - 1, 1)) for i in range(K)]

    fig, ax = plt.subplots(figsize=figsize)
    # Plot time series with color per state
    # Use scatter for speed; sub-sample if very long
    step = max(1, len(arr) // 5000)
    ax.scatter(np.asarray(time)[::step], arr[::step],
               c=[colors[rank[v]] for v in s[::step]],
               s=2, alpha=0.6)
    legend_elts = [Patch(facecolor=colors[r],
                         label=f"State {r+1}: mean={means[order[r]]:.2f} m")
                   for r in range(K)]
    ax.legend(handles=legend_elts, loc="upper right", fontsize=9)
    ax.set_title(title)
    ax.set_ylabel(ylabel)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=130)
    plt.close(fig)
    return out_path


def plot_transition_heatmap(transmat: np.ndarray, state_means: np.ndarray,
                            out_path: str, title: str = "HMM transition matrix",
                            figsize=(6, 5)) -> str:
    """Heatmap of the K x K transition matrix, sorted by ascending state mean.

    Cell text shows the probability rounded to 3 decimals.
    """
    P = np.asarray(transmat, dtype=float)
    means = np.asarray(state_means, dtype=float)
    order = np.argsort(means)
    P = P[np.ix_(order, order)]
    fig, ax = plt.subplots(figsize=figsize)
    im = ax.imshow(P, cmap="Blues", vmin=0, vmax=1, aspect="auto")
    K = len(P)
    ax.set_xticks(range(K))
    ax.set_yticks(range(K))
    ax.set_xticklabels([f"S{r+1}" for r in range(K)])
    ax.set_yticklabels([f"S{r+1}" for r in range(K)])
    ax.set_xlabel("To state")
    ax.set_ylabel("From state")
    ax.set_title(title)
    for i in range(K):
        for j in range(K):
            color = "white" if P[i, j] > 0.5 else "black"
            ax.text(j, i, f"{P[i, j]:.3f}", ha="center", va="center",
                    color=color, fontsize=10)
    fig.colorbar(im, ax=ax, fraction=0.046)
    fig.tight_layout()
    fig.savefig(out_path, dpi=130)
    plt.close(fig)
    return out_path


def plot_bic_aic_curve(table: pd.DataFrame, out_path: str,
                       title: str = "HMM model selection",
                       figsize=(7, 4.2)) -> str:
    """Plot BIC and AIC vs number of states K.

    Parameters
    ----------
    table : pandas.DataFrame
        Must contain 'k', 'bic', 'aic' columns.
    """
    fig, ax = plt.subplots(figsize=figsize)
    ax.plot(table["k"], table["bic"], "o-", color="darkred", label="BIC")
    ax.plot(table["k"], table["aic"], "s--", color="navy", label="AIC")
    ax.set_xlabel("Number of states K")
    ax.set_ylabel("Information criterion")
    ax.set_title(title)
    ax.set_xticks(table["k"])
    ax.grid(alpha=0.3)
    ax.legend()
    fig.tight_layout()
    fig.savefig(out_path, dpi=130)
    plt.close(fig)
    return out_path


def plot_pelt_vs_binseg(time, values, pelt_breaks, binseg_breaks,
                        out_path: str, title: str = "",
                        ylabel: str = "Differenced wave height",
                        figsize=(11, 7)) -> str:
    """Two-panel comparison of PELT vs BinSeg break-point sets.

    Top panel = PELT (red); bottom panel = BinSeg (orange).
    """
    arr = np.asarray(values, dtype=float)
    fig, axes = plt.subplots(2, 1, figsize=figsize, sharex=True)
    for ax, brks, lab, col in zip(
        axes, [pelt_breaks, binseg_breaks],
        ["PELT", "Binary segmentation"], ["red", "darkorange"]
    ):
        ax.plot(time, arr, lw=0.3, color="grey")
        for cp in brks:
            if cp < len(time):
                ax.axvline(time[cp], color=col, lw=1.0, alpha=0.85)
        ax.set_title(f"{lab} ({len(brks)} change-points)")
        ax.set_ylabel(ylabel)
        ax.grid(alpha=0.3)
    fig.suptitle(title or "PELT vs Binary Segmentation")
    fig.tight_layout()
    fig.savefig(out_path, dpi=130)
    plt.close(fig)
    return out_path


def plot_segment_variance_step(time, values, breakpoints,
                                out_path: str,
                                title: str = "",
                                ylabel: str = "Segment standard deviation",
                                figsize=(11, 4.5)) -> str:
    """Step plot of segment standard deviation vs time.

    Each segment defined by `breakpoints` is shown as a horizontal bar at
    its empirical sd.
    """
    arr = np.asarray(values, dtype=float)
    bps = list(breakpoints)
    if not bps or bps[-1] != len(arr):
        bps_full = list(bps) + [len(arr)]
    else:
        bps_full = list(bps)
    starts = [0] + bps_full[:-1]
    fig, ax = plt.subplots(figsize=figsize)
    for s, e in zip(starts, bps_full):
        seg = arr[s:e]
        if len(seg) < 2:
            continue
        sd = float(seg.std(ddof=1))
        x_left = time[s]
        x_right = time[min(e - 1, len(arr) - 1)]
        ax.hlines(sd, x_left, x_right, colors="darkred", lw=2.5)
    ax.set_title(title or "Per-segment standard deviation")
    ax.set_ylabel(ylabel)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=130)
    plt.close(fig)
    return out_path


def plot_state_dwell_distribution(states, transmat: np.ndarray,
                                   state_means: np.ndarray,
                                   out_path: str,
                                   title: str = "Empirical vs geometric dwell times",
                                   figsize=(8, 5)) -> str:
    """Bar plot of empirical mean dwell time per state vs the geometric
    expectation 1/(1-p_kk).
    """
    s = np.asarray(states, dtype=int)
    means = np.asarray(state_means, dtype=float)
    order = np.argsort(means)
    K = len(means)

    # Empirical dwell times: count consecutive runs in each state
    emp_dwell = np.zeros(K)
    counts = np.zeros(K)
    if len(s) > 0:
        prev = s[0]
        run = 1
        for x in s[1:]:
            if x == prev:
                run += 1
            else:
                emp_dwell[prev] += run
                counts[prev] += 1
                prev = x
                run = 1
        emp_dwell[prev] += run
        counts[prev] += 1
    emp_mean = np.where(counts > 0, emp_dwell / np.maximum(counts, 1), 0)

    # Geometric expectation
    P = np.asarray(transmat, dtype=float)
    geo = 1.0 / np.maximum(1e-12, 1.0 - np.diag(P))

    x = np.arange(K)
    fig, ax = plt.subplots(figsize=figsize)
    ax.bar(x - 0.18, emp_mean[order], 0.36, label="Empirical")
    ax.bar(x + 0.18, geo[order], 0.36, label="Geometric 1/(1-p_kk)")
    ax.set_xticks(x)
    ax.set_xticklabels([f"S{r+1} ({means[order[r]]:.2f}m)" for r in range(K)])
    ax.set_ylabel("Mean dwell time (steps)")
    ax.set_title(title)
    ax.legend()
    ax.grid(alpha=0.3, axis="y")
    fig.tight_layout()
    fig.savefig(out_path, dpi=130)
    plt.close(fig)
    return out_path

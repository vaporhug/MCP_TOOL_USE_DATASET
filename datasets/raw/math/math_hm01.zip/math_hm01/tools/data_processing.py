"""
Generic data processing primitives for time-series analysis tasks.

Loaders for CSV, helpers for differencing, normalisation, and basic
descriptive statistics. None of these helpers carry domain logic.
"""

from __future__ import annotations

import csv
from typing import Optional, Sequence

import numpy as np
import pandas as pd


def read_csv(file_path: str) -> pd.DataFrame:
    """Read a CSV file into a pandas DataFrame.

    Parameters
    ----------
    file_path : str
        Path to the CSV file (with header row).

    Returns
    -------
    pandas.DataFrame
        Parsed table, with column dtypes inferred by pandas.
    """
    return pd.read_csv(file_path)


def write_csv(df: pd.DataFrame, file_path: str) -> str:
    """Write a DataFrame to CSV without the index column.

    Parameters
    ----------
    df : pandas.DataFrame
    file_path : str

    Returns
    -------
    str
        The file_path that was written.
    """
    df.to_csv(file_path, index=False)
    return file_path


def load_time_series(file_path: str, value_column: str,
                     time_column: Optional[str] = None) -> dict:
    """Load a univariate time series from a CSV file.

    Parameters
    ----------
    file_path : str
        CSV file with at least a numeric value column.
    value_column : str
        Name of the column containing the observations.
    time_column : str, optional
        Name of the column containing the time index. If None, the
        position index 0..n-1 is used.

    Returns
    -------
    dict
        Keys: 'values' (np.ndarray of float), 'time' (np.ndarray, dtype
        depends on column or position int), 'n' (int), 'name' (str).
    """
    df = pd.read_csv(file_path)
    values = df[value_column].to_numpy(dtype=float)
    if time_column is not None and time_column in df.columns:
        # Try parsing as datetime; fall back to original
        try:
            times = pd.to_datetime(df[time_column]).to_numpy()
        except Exception:
            times = df[time_column].to_numpy()
    else:
        times = np.arange(len(values))
    return {
        "values": values,
        "time": times,
        "n": int(len(values)),
        "name": value_column,
    }


def first_difference(values: np.ndarray) -> np.ndarray:
    """Return the lag-1 differences x[t] - x[t-1].

    Parameters
    ----------
    values : np.ndarray
        Length-n input vector.

    Returns
    -------
    np.ndarray
        Length-(n-1) vector of differences.
    """
    arr = np.asarray(values, dtype=float)
    return np.diff(arr)


def standardize(values: np.ndarray) -> dict:
    """Z-score standardisation: subtract mean, divide by sample std.

    Parameters
    ----------
    values : np.ndarray

    Returns
    -------
    dict
        Keys: 'standardized' (np.ndarray), 'mean' (float), 'std' (float).
    """
    arr = np.asarray(values, dtype=float)
    mu = float(arr.mean())
    sd = float(arr.std(ddof=1))
    if sd == 0:
        sd = 1.0
    return {"standardized": (arr - mu) / sd, "mean": mu, "std": sd}


def rolling_statistics(values: np.ndarray, window: int) -> dict:
    """Compute rolling mean, std, and variance over a sliding window.

    Parameters
    ----------
    values : np.ndarray
    window : int
        Number of consecutive observations in each window. Must be >= 2.

    Returns
    -------
    dict
        Keys: 'mean', 'std', 'var' — each a length-n np.ndarray with
        NaN in the first (window-1) positions.
    """
    arr = np.asarray(values, dtype=float)
    if window < 2:
        raise ValueError("window must be at least 2")
    s = pd.Series(arr)
    return {
        "mean": s.rolling(window).mean().to_numpy(),
        "std": s.rolling(window).std(ddof=1).to_numpy(),
        "var": s.rolling(window).var(ddof=1).to_numpy(),
    }


def descriptive_stats(values: np.ndarray) -> dict:
    """Return summary statistics: count, mean, std, min, quartiles, max.

    Parameters
    ----------
    values : np.ndarray

    Returns
    -------
    dict
        Keys: 'n', 'mean', 'std', 'min', 'q1', 'median', 'q3', 'max'.
    """
    arr = np.asarray(values, dtype=float)
    arr = arr[~np.isnan(arr)]
    if len(arr) == 0:
        return {"n": 0, "mean": np.nan, "std": np.nan,
                "min": np.nan, "q1": np.nan, "median": np.nan,
                "q3": np.nan, "max": np.nan}
    return {
        "n": int(len(arr)),
        "mean": float(arr.mean()),
        "std": float(arr.std(ddof=1)),
        "min": float(arr.min()),
        "q1": float(np.quantile(arr, 0.25)),
        "median": float(np.median(arr)),
        "q3": float(np.quantile(arr, 0.75)),
        "max": float(arr.max()),
    }


def segment_summary(values: np.ndarray, breakpoints: Sequence[int]) -> pd.DataFrame:
    """Summarise each segment defined by breakpoints with mean/std/length.

    Parameters
    ----------
    values : np.ndarray
        Length-n vector.
    breakpoints : sequence of int
        Indices marking the END of each segment, inclusive of n. Must end
        with len(values).

    Returns
    -------
    pandas.DataFrame
        Columns: 'segment', 'start', 'end', 'length', 'mean', 'std', 'var'.
    """
    arr = np.asarray(values, dtype=float)
    bps = list(breakpoints)
    if not bps or bps[-1] != len(arr):
        bps = bps + [len(arr)]
    starts = [0] + bps[:-1]
    rows = []
    for i, (s, e) in enumerate(zip(starts, bps)):
        seg = arr[s:e]
        rows.append({
            "segment": i + 1,
            "start": int(s),
            "end": int(e),
            "length": int(e - s),
            "mean": float(seg.mean()) if len(seg) else float("nan"),
            "std": float(seg.std(ddof=1)) if len(seg) > 1 else float("nan"),
            "var": float(seg.var(ddof=1)) if len(seg) > 1 else float("nan"),
        })
    return pd.DataFrame(rows)


def downsample(values: np.ndarray, factor: int) -> np.ndarray:
    """Block-mean downsample to factor:1 (e.g. hourly to daily).

    Parameters
    ----------
    values : np.ndarray
    factor : int
        Block size. Must be >= 1.

    Returns
    -------
    np.ndarray
        Length-(n // factor) array of block means.
    """
    arr = np.asarray(values, dtype=float)
    if factor < 1:
        raise ValueError("factor must be >= 1")
    n_full = (len(arr) // factor) * factor
    return arr[:n_full].reshape(-1, factor).mean(axis=1)

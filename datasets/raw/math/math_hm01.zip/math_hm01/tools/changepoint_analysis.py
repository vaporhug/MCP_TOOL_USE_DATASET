"""
Domain primitives for change-point detection and Hidden Markov Model
state segmentation of univariate time series.

The functions below correspond to the steps required to reproduce
the analysis pipeline of Killick, Fearnhead and Eckley (JASA 2012)
on the East Scotian Slope buoy wave-height series, plus an HMM
companion analysis for regime characterisation.

All routines return Python primitives or numpy arrays, never plot
to screen — plotting helpers live in plotting.py.
"""

from __future__ import annotations

from typing import Optional, Sequence

import numpy as np
import pandas as pd

import ruptures as rpt
from ruptures.base import BaseCost
from hmmlearn import hmm


# ---------------------------------------------------------------------------
# Cost functions for ruptures
# ---------------------------------------------------------------------------


class CostNormalVariance(BaseCost):
    """Twice negative log-likelihood for a Normal segment with a KNOWN, COMMON mean.

    This is a pure change-in-variance cost (R ``changepoint::cpt.var``,
    Killick, Fearnhead & Eckley 2012): the mean is treated as a single value
    held common across the whole series (not re-estimated per segment), and
    only the variance changes between segments. The common mean ``mu`` is the
    global signal mean computed once in ``fit`` (for a pre-differenced /
    mean-centred input this is ~0, matching cpt.var's usual convention).

    Cost on segment y_{s+1..e}:
        C = n * (log(2 pi) + log(sigma_hat^2) + 1)
    with sigma_hat^2 = (1/n) * sum_i (y_i - mu)^2 about the COMMON mean mu.

    Because the residuals are taken about a fixed common mean, this cost is
    genuinely distinct from CostNormalMeanVariance (which subtracts each
    segment's own mean); under this cost the optimal partition reflects pure
    variance shifts rather than mean shifts.
    """

    model = "normal_var"
    min_size = 2

    def fit(self, signal):
        self.signal = np.asarray(signal, dtype=float).flatten()
        # Common (known) mean held fixed across all segments.
        self.mu = float(self.signal.mean()) if self.signal.size else 0.0
        return self

    def error(self, start, end):
        seg = self.signal[start:end]
        n = len(seg)
        if n < 2:
            return 0.0
        # Residual SS about the COMMON mean mu, NOT the per-segment mean.
        ss = float(np.sum((seg - self.mu) ** 2))
        var = ss / n + 1e-12
        return float(n * (np.log(2 * np.pi) + np.log(var) + 1.0))


class CostNormalMeanVariance(BaseCost):
    """Twice negative log-likelihood for a Normal segment, mean and var
    free per segment. Used for change-in-meanvar detection.
    """

    model = "normal_meanvar"
    min_size = 2

    def fit(self, signal):
        self.signal = np.asarray(signal, dtype=float).flatten()
        return self

    def error(self, start, end):
        seg = self.signal[start:end]
        n = len(seg)
        if n < 2:
            return 0.0
        var = float(seg.var(ddof=0)) + 1e-12
        return float(n * (np.log(2 * np.pi) + np.log(var) + 1.0))


# ---------------------------------------------------------------------------
# PELT and Binary Segmentation entry points
# ---------------------------------------------------------------------------


def pelt_changepoints(signal: np.ndarray,
                      cost: str = "var",
                      penalty_multiplier: float = 30.0,
                      min_size: int = 168,
                      jump: int = 24) -> dict:
    """Run PELT on a univariate signal, return change-point indices.

    Penalty used is `penalty_multiplier * log(n)` where n is the signal
    length. A larger penalty multiplier yields fewer change-points and a
    smaller one yields more; pick it for the series and cost model at hand
    (e.g. by inspecting the penalty-vs-number-of-change-points sweep).

    Parameters
    ----------
    signal : np.ndarray
        Length-n univariate signal.
    cost : str
        One of 'var' (Normal variance change with unknown mean),
        'meanvar' (mean and variance free), or 'l2' (mean-only L2 cost).
    penalty_multiplier : float
        Linear coefficient on log(n).
    min_size : int
        Minimum segment length passed to ruptures.
    jump : int
        Sub-sampling step for candidate change-points (1 = exact).

    Returns
    -------
    dict
        Keys: 'changepoints' (list of int, last entry equals n),
        'breakpoints' (same list excluding the trailing n),
        'n_changepoints' (int), 'penalty' (float),
        'cost_name' (str), 'n' (int).
    """
    arr = np.asarray(signal, dtype=float).flatten()
    n = len(arr)
    if cost == "var":
        cost_obj = CostNormalVariance().fit(arr)
    elif cost == "meanvar":
        cost_obj = CostNormalMeanVariance().fit(arr)
    elif cost == "l2":
        cost_obj = None
    else:
        raise ValueError(f"unknown cost {cost}")
    pen = float(penalty_multiplier) * float(np.log(n))
    if cost_obj is None:
        algo = rpt.Pelt(model="l2", min_size=min_size, jump=jump).fit(arr.reshape(-1, 1))
    else:
        algo = rpt.Pelt(custom_cost=cost_obj, min_size=min_size, jump=jump).fit(arr.reshape(-1, 1))
    cps = algo.predict(pen=pen)
    bps = [c for c in cps if c < n]
    return {
        "changepoints": [int(c) for c in cps],
        "breakpoints": [int(b) for b in bps],
        "n_changepoints": int(len(bps)),
        "penalty": pen,
        "cost_name": cost,
        "n": int(n),
    }


def binseg_changepoints(signal: np.ndarray,
                        cost: str = "var",
                        penalty_multiplier: float = 30.0,
                        min_size: int = 168,
                        jump: int = 24) -> dict:
    """Run Binary Segmentation on a univariate signal.

    Same arguments as `pelt_changepoints`. Used for comparison with PELT.

    Returns the same dictionary structure.
    """
    arr = np.asarray(signal, dtype=float).flatten()
    n = len(arr)
    if cost == "var":
        cost_obj = CostNormalVariance().fit(arr)
    elif cost == "meanvar":
        cost_obj = CostNormalMeanVariance().fit(arr)
    elif cost == "l2":
        cost_obj = None
    else:
        raise ValueError(f"unknown cost {cost}")
    pen = float(penalty_multiplier) * float(np.log(n))
    if cost_obj is None:
        algo = rpt.Binseg(model="l2", min_size=min_size, jump=jump).fit(arr.reshape(-1, 1))
    else:
        algo = rpt.Binseg(custom_cost=cost_obj, min_size=min_size, jump=jump).fit(arr.reshape(-1, 1))
    cps = algo.predict(pen=pen)
    bps = [c for c in cps if c < n]
    return {
        "changepoints": [int(c) for c in cps],
        "breakpoints": [int(b) for b in bps],
        "n_changepoints": int(len(bps)),
        "penalty": pen,
        "cost_name": cost,
        "n": int(n),
    }


def crops_penalty_path(signal: np.ndarray,
                       cost: str = "var",
                       pen_grid: Optional[Sequence[float]] = None,
                       min_size: int = 168,
                       jump: int = 24) -> pd.DataFrame:
    """Sweep the penalty multiplier and return number of change-points.

    Parameters
    ----------
    signal : np.ndarray
    cost : str
        See `pelt_changepoints`.
    pen_grid : sequence of float, optional
        Values of the multiplier `m` such that pen = m * log(n).
        Default sweeps 1..50 in steps of 1.
    min_size : int
    jump : int

    Returns
    -------
    pandas.DataFrame
        Columns: 'multiplier', 'penalty', 'n_changepoints'.
    """
    if pen_grid is None:
        pen_grid = list(range(1, 51))
    arr = np.asarray(signal, dtype=float).flatten()
    n = len(arr)
    rows = []
    for m in pen_grid:
        out = pelt_changepoints(arr, cost=cost,
                                penalty_multiplier=float(m),
                                min_size=min_size, jump=jump)
        rows.append({"multiplier": float(m),
                     "penalty": out["penalty"],
                     "n_changepoints": out["n_changepoints"]})
    return pd.DataFrame(rows)


def likelihood_difference(signal: np.ndarray,
                          breakpoints_a: Sequence[int],
                          breakpoints_b: Sequence[int],
                          cost: str = "var") -> float:
    """Compute the difference in segmentation cost between two break-point
    sets. Used to compare the segmentations produced by PELT and BinSeg.

    A negative value means breakpoints_a yields a lower (better) cost.

    Parameters
    ----------
    signal : np.ndarray
    breakpoints_a, breakpoints_b : sequence of int
        Lists ending with n (i.e. ruptures-style change-points).
    cost : str
        See `pelt_changepoints`.
    """
    arr = np.asarray(signal, dtype=float).flatten()
    if cost == "var":
        c = CostNormalVariance().fit(arr)
    elif cost == "meanvar":
        c = CostNormalMeanVariance().fit(arr)
    else:
        raise ValueError(f"unknown cost {cost}")

    def _cost_sum(bps):
        bps = list(bps)
        if not bps or bps[-1] != len(arr):
            bps = list(bps) + [len(arr)]
        starts = [0] + bps[:-1]
        return float(sum(c.error(s, e) for s, e in zip(starts, bps)))

    return _cost_sum(breakpoints_a) - _cost_sum(breakpoints_b)


# ---------------------------------------------------------------------------
# Hidden Markov Model fitting
# ---------------------------------------------------------------------------


def fit_gaussian_hmm(signal: np.ndarray,
                     n_states: int,
                     covariance_type: str = "diag",
                     n_iter: int = 200,
                     n_seeds: int = 5) -> dict:
    """Fit a Gaussian-emission HMM to a univariate signal.

    Runs Baum-Welch (the EM algorithm) from `n_seeds` random starts and
    returns the best fit by log-likelihood.

    Parameters
    ----------
    signal : np.ndarray
    n_states : int
        Number of hidden states.
    covariance_type : str
        Passed to hmmlearn — 'diag' (default) keeps a single emission
        variance per state.
    n_iter : int
        Maximum EM iterations per seed.
    n_seeds : int
        Number of random restarts.

    Returns
    -------
    dict
        Keys: 'log_likelihood' (float), 'aic' (float), 'bic' (float),
        'n_params' (int), 'transmat' (np.ndarray), 'startprob' (np.ndarray),
        'means' (np.ndarray), 'sds' (np.ndarray of state std devs),
        'state_order' (np.ndarray that sorts states by ascending mean),
        'model' (the fitted hmmlearn object).
    """
    arr = np.asarray(signal, dtype=float).reshape(-1, 1)
    n = len(arr)
    best_ll = -np.inf
    best_model = None
    for seed in range(n_seeds):
        try:
            model = hmm.GaussianHMM(n_components=n_states,
                                    covariance_type=covariance_type,
                                    n_iter=n_iter, tol=1e-4,
                                    random_state=seed)
            model.fit(arr)
            ll = float(model.score(arr))
            if ll > best_ll:
                best_ll = ll
                best_model = model
        except Exception:
            continue
    if best_model is None:
        raise RuntimeError(f"HMM fit failed for k={n_states}")
    means = best_model.means_.flatten()
    if covariance_type == "diag":
        sds = np.sqrt(best_model.covars_.flatten())
    else:
        sds = np.sqrt(np.array([np.diag(c)[0] for c in best_model.covars_]))
    n_params = (n_states - 1) + n_states * (n_states - 1) + 2 * n_states
    bic = -2.0 * best_ll + n_params * float(np.log(n))
    aic = -2.0 * best_ll + 2.0 * n_params
    order = np.argsort(means)
    return {
        "log_likelihood": best_ll,
        "aic": aic,
        "bic": bic,
        "n_params": int(n_params),
        "transmat": best_model.transmat_,
        "startprob": best_model.startprob_,
        "means": means,
        "sds": sds,
        "state_order": order,
        "model": best_model,
        "n_states": int(n_states),
    }


def viterbi_decode(model_dict: dict, signal: np.ndarray) -> np.ndarray:
    """Run the Viterbi algorithm to decode the most likely state path.

    Parameters
    ----------
    model_dict : dict
        Output of `fit_gaussian_hmm`.
    signal : np.ndarray
        The same signal the HMM was fit on (or a new signal of the same
        emission family).

    Returns
    -------
    np.ndarray
        Length-n integer array of decoded state indices.
    """
    arr = np.asarray(signal, dtype=float).reshape(-1, 1)
    return model_dict["model"].predict(arr).astype(int)


def hmm_state_summary(states: np.ndarray, signal: np.ndarray) -> pd.DataFrame:
    """Summarise the empirical mean/std and occupancy of each decoded state.

    Parameters
    ----------
    states : np.ndarray
        Length-n integer array (from `viterbi_decode`).
    signal : np.ndarray
        The observation series (same length).

    Returns
    -------
    pandas.DataFrame
        Columns: 'state', 'count', 'fraction', 'mean', 'std', 'min', 'max'.
    """
    s = np.asarray(states, dtype=int)
    y = np.asarray(signal, dtype=float)
    rows = []
    n = len(s)
    for k in np.unique(s):
        mask = s == k
        seg = y[mask]
        rows.append({
            "state": int(k),
            "count": int(mask.sum()),
            "fraction": float(mask.sum() / n),
            "mean": float(seg.mean()),
            "std": float(seg.std(ddof=1)) if len(seg) > 1 else float("nan"),
            "min": float(seg.min()),
            "max": float(seg.max()),
        })
    return pd.DataFrame(rows).sort_values("mean").reset_index(drop=True)


def stationary_distribution(transmat: np.ndarray) -> np.ndarray:
    """Compute the stationary distribution of an HMM transition matrix.

    Solves pi * P = pi via the leading left eigenvector.

    Parameters
    ----------
    transmat : np.ndarray
        K x K stochastic matrix.

    Returns
    -------
    np.ndarray
        Length-K probability vector (sums to 1).
    """
    P = np.asarray(transmat, dtype=float)
    eigvals, eigvecs = np.linalg.eig(P.T)
    idx = int(np.argmin(np.abs(eigvals - 1.0)))
    pi = np.real(eigvecs[:, idx])
    pi = pi / pi.sum()
    pi = np.where(pi < 0, 0, pi)
    pi = pi / pi.sum()
    return pi


def expected_state_dwell(transmat: np.ndarray) -> np.ndarray:
    """Expected dwell time per state under a homogeneous HMM.

    For state k with self-transition probability p_kk, the dwell time has
    a geometric distribution with mean 1/(1 - p_kk).

    Parameters
    ----------
    transmat : np.ndarray
        K x K stochastic matrix.

    Returns
    -------
    np.ndarray
        Length-K vector of expected dwell times in observation steps.
    """
    P = np.asarray(transmat, dtype=float)
    diag = np.diag(P)
    return 1.0 / np.maximum(1e-12, 1.0 - diag)


def model_selection_table(signal: np.ndarray,
                          k_values: Sequence[int] = (2, 3, 4, 5),
                          covariance_type: str = "diag",
                          n_seeds: int = 5) -> pd.DataFrame:
    """Fit Gaussian HMMs for several K values and return BIC/AIC table.

    Parameters
    ----------
    signal : np.ndarray
    k_values : sequence of int
        Candidate numbers of states.
    covariance_type : str
    n_seeds : int

    Returns
    -------
    pandas.DataFrame
        Columns: 'k', 'log_likelihood', 'n_params', 'aic', 'bic'.
    """
    rows = []
    for k in k_values:
        out = fit_gaussian_hmm(signal, n_states=int(k),
                               covariance_type=covariance_type,
                               n_seeds=n_seeds)
        rows.append({"k": int(k),
                     "log_likelihood": out["log_likelihood"],
                     "n_params": out["n_params"],
                     "aic": out["aic"],
                     "bic": out["bic"]})
    return pd.DataFrame(rows)


def residual_analysis(signal: np.ndarray, states: np.ndarray,
                      means: np.ndarray) -> dict:
    """Compute per-step residuals against the decoded HMM mean.

    Parameters
    ----------
    signal : np.ndarray
    states : np.ndarray
        Decoded state indices.
    means : np.ndarray
        Length-K array of state means in the same indexing as `states`.

    Returns
    -------
    dict
        Keys: 'residuals', 'rmse', 'mae', 'autocorr_lag1' (Pearson r
        between residual_t and residual_{t-1}).
    """
    y = np.asarray(signal, dtype=float)
    s = np.asarray(states, dtype=int)
    mu = np.asarray(means, dtype=float)
    yhat = mu[s]
    res = y - yhat
    rmse = float(np.sqrt(np.mean(res ** 2)))
    mae = float(np.mean(np.abs(res)))
    if len(res) > 1:
        r1 = float(np.corrcoef(res[:-1], res[1:])[0, 1])
    else:
        r1 = float("nan")
    return {"residuals": res, "rmse": rmse, "mae": mae,
            "autocorr_lag1": r1}


# ---------------------------------------------------------------------------
# Helpers shared by both pipelines
# ---------------------------------------------------------------------------


def split_segments_by_breakpoints(signal: np.ndarray,
                                  breakpoints: Sequence[int]) -> list:
    """Slice a signal into consecutive segments at the given breakpoints.

    Parameters
    ----------
    signal : np.ndarray
    breakpoints : sequence of int
        Indices marking the END of each segment, exclusive of n.

    Returns
    -------
    list of np.ndarray
    """
    arr = np.asarray(signal, dtype=float).flatten()
    starts = [0] + list(breakpoints)
    ends = list(breakpoints) + [len(arr)]
    return [arr[s:e] for s, e in zip(starts, ends)]


def segment_variance_table(signal: np.ndarray,
                           breakpoints: Sequence[int]) -> pd.DataFrame:
    """Variance per segment as defined by breakpoints.

    Parameters
    ----------
    signal : np.ndarray
    breakpoints : sequence of int

    Returns
    -------
    pandas.DataFrame
        Columns: 'segment', 'start', 'end', 'length', 'mean', 'var', 'std'.
    """
    segs = split_segments_by_breakpoints(signal, breakpoints)
    starts = [0] + list(breakpoints)
    ends = list(breakpoints) + [len(signal)]
    rows = []
    for i, (seg, s, e) in enumerate(zip(segs, starts, ends)):
        rows.append({
            "segment": i + 1,
            "start": int(s),
            "end": int(e),
            "length": int(len(seg)),
            "mean": float(seg.mean()) if len(seg) else float("nan"),
            "var": float(seg.var(ddof=1)) if len(seg) > 1 else float("nan"),
            "std": float(seg.std(ddof=1)) if len(seg) > 1 else float("nan"),
        })
    return pd.DataFrame(rows)


def cusum_statistic(signal: np.ndarray) -> np.ndarray:
    """Cumulative sum of mean-centered observations.

    Useful as a quick visual diagnostic for level changes; large excursions
    correspond to mean shifts.

    Parameters
    ----------
    signal : np.ndarray

    Returns
    -------
    np.ndarray
        Same length as input.
    """
    arr = np.asarray(signal, dtype=float)
    return np.cumsum(arr - arr.mean())

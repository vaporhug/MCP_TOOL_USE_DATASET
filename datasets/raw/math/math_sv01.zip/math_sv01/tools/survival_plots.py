"""
Plotting tools for survival analysis visualizations.

Produces publication-quality Kaplan-Meier curves, forest plots
of hazard ratios, and Schoenfeld residual diagnostic plots.
"""

import numpy as np
import os


def plot_kaplan_meier_curves(km_results: dict,
                            group_labels: list,
                            title: str = "Kaplan-Meier Survival Curves",
                            xlabel: str = "Time (months)",
                            ylabel: str = "Survival Probability",
                            show_ci: bool = True,
                            show_at_risk: bool = True,
                            at_risk_times: list = None,
                            p_value: float = None,
                            output_path: str = "artifacts/km_curves.png") -> str:
    """Plot Kaplan-Meier survival curves for multiple groups.

    Parameters
    ----------
    km_results : dict
        Dict mapping group key to kaplan_meier_estimator() output.
    group_labels : list
        Display labels for each group.
    title : str
        Plot title.
    xlabel, ylabel : str
        Axis labels.
    show_ci : bool
        Whether to show 95% confidence bands.
    show_at_risk : bool
        Whether to show number-at-risk table below.
    at_risk_times : list
        Time points for the at-risk table.
    p_value : float
        Log-rank p-value to display.
    output_path : str
        Path to save the figure.

    Returns
    -------
    str
        Absolute path to the saved figure.
    """
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728']

    if show_at_risk and at_risk_times is not None:
        fig, (ax_main, ax_table) = plt.subplots(
            2, 1, figsize=(8, 6), gridspec_kw={'height_ratios': [4, 1]},
            sharex=True
        )
    else:
        fig, ax_main = plt.subplots(figsize=(8, 5))
        ax_table = None

    for i, (key, km) in enumerate(km_results.items()):
        times = np.concatenate([[0], km['times']])
        surv = np.concatenate([[1.0], km['survival']])
        color = colors[i % len(colors)]
        label = group_labels[i] if i < len(group_labels) else str(key)

        # Step function
        ax_main.step(times, surv, where='post', color=color, linewidth=1.5, label=label)

        if show_ci:
            ci_l = np.concatenate([[1.0], km['ci_lower']])
            ci_u = np.concatenate([[1.0], km['ci_upper']])
            ax_main.fill_between(times, ci_l, ci_u, step='post', alpha=0.15, color=color)

        # Add censoring marks
        censor_times = []
        censor_surv = []
        all_times_arr = km['times']
        all_surv_arr = km['survival']
        # We don't have individual censoring info easily, skip tick marks

    ax_main.set_ylabel(ylabel, fontsize=12)
    ax_main.set_title(title, fontsize=13)
    ax_main.set_ylim(0, 1.05)
    ax_main.legend(loc='lower left', fontsize=10)
    ax_main.grid(True, alpha=0.3)

    if p_value is not None:
        ax_main.text(0.95, 0.95, f'p = {p_value:.3f}',
                     transform=ax_main.transAxes, ha='right', va='top', fontsize=10,
                     bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))

    if ax_table is not None and at_risk_times is not None:
        ax_table.set_xlabel(xlabel, fontsize=12)
        ax_table.set_xlim(ax_main.get_xlim())

        for i, (key, km) in enumerate(km_results.items()):
            label = group_labels[i] if i < len(group_labels) else str(key)
            # compute at-risk counts would need original data
            # placeholder: display label
            y_pos = 0.7 - i * 0.35
            ax_table.text(-0.02, y_pos, label, transform=ax_table.transAxes,
                          ha='right', va='center', fontsize=9, fontweight='bold')

        ax_table.set_yticks([])
        ax_table.spines['top'].set_visible(False)
        ax_table.spines['right'].set_visible(False)
        ax_table.spines['left'].set_visible(False)
    else:
        ax_main.set_xlabel(xlabel, fontsize=12)

    plt.tight_layout()
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    abs_path = os.path.abspath(output_path)
    fig.savefig(abs_path, dpi=150, bbox_inches='tight')
    plt.close(fig)
    return abs_path


def plot_forest_hazard_ratios(labels: list, hrs: list,
                              ci_lower: list, ci_upper: list,
                              title: str = "Forest Plot of Hazard Ratios",
                              reference_line: float = 1.0,
                              output_path: str = "artifacts/forest_plot.png") -> str:
    """Plot a forest plot of hazard ratios with confidence intervals.

    Parameters
    ----------
    labels : list
        Labels for each hazard ratio.
    hrs : list
        Point estimates of hazard ratios.
    ci_lower : list
        Lower bounds of CIs.
    ci_upper : list
        Upper bounds of CIs.
    title : str
        Plot title.
    reference_line : float
        HR reference line (typically 1.0 = no effect).
    output_path : str
        Path to save the figure.

    Returns
    -------
    str
        Absolute path to the saved figure.
    """
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    n = len(labels)
    y_pos = np.arange(n)

    fig, ax = plt.subplots(figsize=(8, max(3, n * 0.5 + 1)))

    for i in range(n):
        ax.plot([ci_lower[i], ci_upper[i]], [y_pos[i], y_pos[i]],
                color='black', linewidth=1.5)
        ax.plot(hrs[i], y_pos[i], 'D', color='navy', markersize=8)
        ax.text(max(ci_upper) * 1.1, y_pos[i],
                f'{hrs[i]:.2f} ({ci_lower[i]:.2f}-{ci_upper[i]:.2f})',
                va='center', fontsize=9)

    ax.axvline(reference_line, color='red', linestyle='--', linewidth=1, alpha=0.7)
    ax.set_yticks(y_pos)
    ax.set_yticklabels(labels, fontsize=10)
    ax.set_xlabel('Hazard Ratio', fontsize=12)
    ax.set_title(title, fontsize=13)
    ax.invert_yaxis()
    ax.set_xscale('log')
    ax.grid(True, axis='x', alpha=0.3)

    plt.tight_layout()
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    abs_path = os.path.abspath(output_path)
    fig.savefig(abs_path, dpi=150, bbox_inches='tight')
    plt.close(fig)
    return abs_path


def plot_schoenfeld_residuals(schoenfeld_result: dict,
                              covariate_names: list = None,
                              title: str = "Schoenfeld Residuals vs Time",
                              output_path: str = "artifacts/schoenfeld_residuals.png") -> str:
    """Plot Schoenfeld residuals against event time for PH assumption diagnostics.

    A non-random pattern (trend) suggests violation of the PH assumption.

    Parameters
    ----------
    schoenfeld_result : dict
        Output of schoenfeld_residuals().
    covariate_names : list
        Names of covariates.
    title : str
        Plot title.
    output_path : str
        Path to save the figure.

    Returns
    -------
    str
        Absolute path to the saved figure.
    """
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    event_times = np.array(schoenfeld_result['event_times'])
    residuals = np.array(schoenfeld_result['residuals'])
    p_values = schoenfeld_result['p_values']

    n_covariates = residuals.shape[1]
    if covariate_names is None:
        covariate_names = [f'x{i}' for i in range(n_covariates)]

    fig, axes = plt.subplots(1, n_covariates, figsize=(6 * n_covariates, 4))
    if n_covariates == 1:
        axes = [axes]

    for j in range(n_covariates):
        ax = axes[j]
        ax.scatter(event_times, residuals[:, j], alpha=0.5, s=20, color='steelblue')

        # LOWESS smoothing
        try:
            from scipy.ndimage import uniform_filter1d
            order = np.argsort(event_times)
            smooth = uniform_filter1d(residuals[order, j], size=max(5, len(event_times) // 10))
            ax.plot(event_times[order], smooth, color='red', linewidth=2)
        except Exception:
            pass

        ax.axhline(0, color='black', linestyle='--', linewidth=0.5)
        ax.set_xlabel('Time (months)', fontsize=11)
        ax.set_ylabel(f'Schoenfeld Residual', fontsize=11)
        ax.set_title(f'{covariate_names[j]} (p={p_values[j]:.3f})', fontsize=11)
        ax.grid(True, alpha=0.3)

    fig.suptitle(title, fontsize=13, y=1.02)
    plt.tight_layout()
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    abs_path = os.path.abspath(output_path)
    fig.savefig(abs_path, dpi=150, bbox_inches='tight')
    plt.close(fig)
    return abs_path


def plot_cumulative_hazard(na_results: dict,
                           group_labels: list,
                           title: str = "Nelson-Aalen Cumulative Hazard",
                           xlabel: str = "Time (months)",
                           ylabel: str = "Cumulative Hazard",
                           output_path: str = "artifacts/cumulative_hazard.png") -> str:
    """Plot Nelson-Aalen cumulative hazard curves.

    Parameters
    ----------
    na_results : dict
        Dict mapping group key to nelson_aalen_estimator() output.
    group_labels : list
        Display labels for each group.
    title, xlabel, ylabel : str
        Plot labels.
    output_path : str
        Path to save the figure.

    Returns
    -------
    str
        Absolute path to the saved figure.
    """
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728']

    fig, ax = plt.subplots(figsize=(8, 5))

    for i, (key, na) in enumerate(na_results.items()):
        times = np.concatenate([[0], na['times']])
        cum_haz = np.concatenate([[0], na['cumulative_hazard']])
        color = colors[i % len(colors)]
        label = group_labels[i] if i < len(group_labels) else str(key)

        ax.step(times, cum_haz, where='post', color=color, linewidth=1.5, label=label)

    ax.set_xlabel(xlabel, fontsize=12)
    ax.set_ylabel(ylabel, fontsize=12)
    ax.set_title(title, fontsize=13)
    ax.legend(loc='upper left', fontsize=10)
    ax.grid(True, alpha=0.3)

    plt.tight_layout()
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    abs_path = os.path.abspath(output_path)
    fig.savefig(abs_path, dpi=150, bbox_inches='tight')
    plt.close(fig)
    return abs_path

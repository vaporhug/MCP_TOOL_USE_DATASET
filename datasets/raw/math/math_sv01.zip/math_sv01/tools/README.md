# Survival Analysis Tools

## survival_analysis.py — Core statistical methods
- `load_survival_data` — Load CSV with time/event/group columns
- `kaplan_meier_estimator` — Product-limit survival function with Greenwood SE
- `median_survival_time` — Median survival with Brookmeyer-Crowley CI
- `survival_probability_at_time` — S(t) at specified time with CI
- `log_rank_test` — Mantel-Haenszel comparison of two survival curves
- `nelson_aalen_estimator` — Cumulative hazard function estimator
- `cox_proportional_hazards` — Cox PH regression via Newton-Raphson; Breslow approximation for tied event times (each tied event shares the full risk set R(t)={j: time_j>=t} in the partial-likelihood, gradient, and Hessian)
- `concordance_index` — Harrell's C-index for discrimination
- `schoenfeld_residuals` — PH assumption test via residual-time correlation
- `restricted_mean_survival_time` — RMST with SE via trapezoidal rule
- `bootstrap_hazard_ratio` — Percentile bootstrap CI for hazard ratio
- `time_dependent_auc` — Time-varying AUC for risk prediction
- `number_at_risk_table` — At-risk counts at specified time points
- `compare_rmst` — Two-group RMST comparison with CI and p-value

## survival_plots.py — Visualization
- `plot_kaplan_meier_curves` — KM survival curves with CI bands and log-rank p
- `plot_forest_hazard_ratios` — Forest plot of HRs with CIs (log scale)
- `plot_schoenfeld_residuals` — Residual scatter with LOWESS smooth
- `plot_cumulative_hazard` — Nelson-Aalen cumulative hazard curves

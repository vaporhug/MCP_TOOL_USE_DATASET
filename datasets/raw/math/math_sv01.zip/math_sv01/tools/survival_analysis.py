"""
Survival analysis domain tools for time-to-event data.

Provides primitives for Kaplan-Meier estimation, Cox proportional hazards
regression, log-rank testing, concordance index, and related survival
analysis computations.
"""

import numpy as np
import csv
from typing import Optional


def load_survival_data(file_path: str) -> dict:
    """Load survival data from a CSV file.

    Expects columns: time_months, event, arm (or similar).
    Returns a dict with keys 'time', 'event', 'arm' as numpy arrays,
    plus 'columns' listing all column names and 'n' for row count.

    Parameters
    ----------
    file_path : str
        Path to the CSV file.

    Returns
    -------
    dict
        Keys: 'time' (float array), 'event' (int array), 'arm' (int array),
        'columns' (list of str), 'n' (int).
    """
    with open(file_path, 'r') as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    columns = list(rows[0].keys())
    time_col = [c for c in columns if 'time' in c.lower()][0]
    event_col = [c for c in columns if 'event' in c.lower() or 'status' in c.lower()][0]
    arm_col = [c for c in columns if 'arm' in c.lower() or 'group' in c.lower() or 'treatment' in c.lower()]

    result = {
        'time': np.array([float(r[time_col]) for r in rows]),
        'event': np.array([int(r[event_col]) for r in rows]),
        'columns': columns,
        'n': len(rows)
    }
    if arm_col:
        result['arm'] = np.array([int(r[arm_col[0]]) for r in rows])

    return result


def kaplan_meier_estimator(time: np.ndarray, event: np.ndarray) -> dict:
    """Compute the Kaplan-Meier survival function estimate.

    Implements the product-limit estimator of the survival function S(t).
    At each event time t_i, S(t_i) = S(t_{i-1}) * (1 - d_i / n_i),
    where d_i is the number of events and n_i is the number at risk.

    Parameters
    ----------
    time : np.ndarray
        Observed survival times (float).
    event : np.ndarray
        Event indicator (1 = event occurred, 0 = censored).

    Returns
    -------
    dict
        'times': sorted unique event times,
        'survival': survival probability at each event time,
        'n_at_risk': number at risk at each event time,
        'n_events': number of events at each time,
        'se': Greenwood standard error at each time,
        'ci_lower': lower 95% CI,
        'ci_upper': upper 95% CI.
    """
    time = np.asarray(time, dtype=float)
    event = np.asarray(event, dtype=int)

    # Sort by time
    order = np.argsort(time)
    t_sorted = time[order]
    e_sorted = event[order]

    unique_times = np.unique(t_sorted[e_sorted == 1])
    n_total = len(time)

    surv_times = []
    surv_prob = []
    n_at_risk_list = []
    n_events_list = []
    se_list = []

    s = 1.0
    var_sum = 0.0  # Greenwood variance accumulator

    for t in unique_times:
        n_at_risk = np.sum(t_sorted >= t)
        n_events = np.sum((t_sorted == t) & (e_sorted == 1))

        if n_at_risk > 0 and n_events > 0:
            s *= (1.0 - n_events / n_at_risk)
            if n_at_risk > n_events:
                var_sum += n_events / (n_at_risk * (n_at_risk - n_events))

        surv_times.append(t)
        surv_prob.append(s)
        n_at_risk_list.append(int(n_at_risk))
        n_events_list.append(int(n_events))
        se = s * np.sqrt(var_sum) if var_sum >= 0 else 0.0
        se_list.append(se)

    surv_prob = np.array(surv_prob)
    se_arr = np.array(se_list)

    return {
        'times': np.array(surv_times),
        'survival': surv_prob,
        'n_at_risk': np.array(n_at_risk_list),
        'n_events': np.array(n_events_list),
        'se': se_arr,
        'ci_lower': np.maximum(0, surv_prob - 1.96 * se_arr),
        'ci_upper': np.minimum(1, surv_prob + 1.96 * se_arr)
    }


def median_survival_time(km_result: dict) -> dict:
    """Estimate median survival time from a Kaplan-Meier estimate.

    Median survival is the smallest time t where S(t) <= 0.5.
    Uses inverse KM to compute confidence interval via Brookmeyer-Crowley.

    Parameters
    ----------
    km_result : dict
        Output of kaplan_meier_estimator().

    Returns
    -------
    dict
        'median': median survival time (None if not reached),
        'ci_lower': lower 90% CI (None if not reached),
        'ci_upper': upper 90% CI (None if not reached).
    """
    times = km_result['times']
    surv = km_result['survival']
    ci_lower = km_result['ci_lower']
    ci_upper = km_result['ci_upper']

    # Use 90% CI (z=1.645) for consistency with paper
    se = km_result['se']
    ci90_lower = np.maximum(0, surv - 1.645 * se)
    ci90_upper = np.minimum(1, surv + 1.645 * se)

    median = None
    for i, s in enumerate(surv):
        if s <= 0.5:
            median = float(times[i])
            break

    # CI for median using the 90% CI of S(t)
    median_ci_lower = None
    median_ci_upper = None

    for i, s in enumerate(ci90_upper):
        if s <= 0.5:
            median_ci_lower = float(times[i])
            break

    for i, s in enumerate(ci90_lower):
        if s <= 0.5:
            median_ci_upper = float(times[i])
            break

    return {
        'median': median,
        'ci_lower': median_ci_lower,
        'ci_upper': median_ci_upper
    }


def survival_probability_at_time(km_result: dict, t: float) -> dict:
    """Estimate survival probability at a specific time point.

    Uses the Kaplan-Meier step function: S(t) is the last KM estimate
    at or before time t.

    Parameters
    ----------
    km_result : dict
        Output of kaplan_meier_estimator().
    t : float
        Time point at which to evaluate survival probability.

    Returns
    -------
    dict
        'time': the queried time point,
        'survival_prob': estimated S(t),
        'se': standard error,
        'ci_lower': lower 90% CI,
        'ci_upper': upper 90% CI.
    """
    times = km_result['times']
    surv = km_result['survival']
    se = km_result['se']

    idx = np.searchsorted(times, t, side='right') - 1

    if idx < 0:
        sp, sp_se = 1.0, 0.0
    else:
        sp = float(surv[idx])
        sp_se = float(se[idx])

    return {
        'time': t,
        'survival_prob': sp,
        'se': sp_se,
        'ci_lower': max(0, sp - 1.645 * sp_se),
        'ci_upper': min(1, sp + 1.645 * sp_se)
    }


def log_rank_test(time1: np.ndarray, event1: np.ndarray,
                  time2: np.ndarray, event2: np.ndarray) -> dict:
    """Perform the log-rank test comparing two survival curves.

    Tests H0: the two survival functions are identical.
    Uses the Mantel-Haenszel (log-rank) test statistic.

    Parameters
    ----------
    time1, event1 : np.ndarray
        Survival times and event indicators for group 1.
    time2, event2 : np.ndarray
        Survival times and event indicators for group 2.

    Returns
    -------
    dict
        'test_statistic': chi-squared statistic (1 df),
        'p_value': two-sided p-value,
        'observed_1': observed events in group 1,
        'expected_1': expected events in group 1 under H0.
    """
    from scipy import stats as sp_stats

    all_times = np.concatenate([time1, time2])
    all_events = np.concatenate([event1, event2])
    groups = np.concatenate([np.zeros(len(time1)), np.ones(len(time2))])

    unique_event_times = np.sort(np.unique(all_times[all_events == 1]))

    O1 = 0.0
    E1 = 0.0
    V = 0.0

    for t in unique_event_times:
        n1 = np.sum(time1 >= t)
        n2 = np.sum(time2 >= t)
        n = n1 + n2

        d1 = np.sum((time1 == t) & (event1 == 1))
        d2 = np.sum((time2 == t) & (event2 == 1))
        d = d1 + d2

        if n > 0:
            e1 = d * n1 / n
            O1 += d1
            E1 += e1

            if n > 1:
                V += d * (n - d) * n1 * n2 / (n * n * (n - 1))

    if V > 0:
        chi2 = (O1 - E1) ** 2 / V
        p_value = 1.0 - sp_stats.chi2.cdf(chi2, df=1)
    else:
        chi2 = 0.0
        p_value = 1.0

    return {
        'test_statistic': float(chi2),
        'p_value': float(p_value),
        'observed_1': float(O1),
        'expected_1': float(E1),
        'observed_2': float(np.sum(event2)),
        'expected_2': float(np.sum(event2) + np.sum(event1)) - float(E1)
    }


def nelson_aalen_estimator(time: np.ndarray, event: np.ndarray) -> dict:
    """Compute the Nelson-Aalen cumulative hazard estimator.

    H(t) = sum_{t_i <= t} d_i / n_i, where d_i is the number of events
    at time t_i and n_i is the number at risk.

    Parameters
    ----------
    time : np.ndarray
        Observed survival times.
    event : np.ndarray
        Event indicator (1 = event, 0 = censored).

    Returns
    -------
    dict
        'times': unique event times,
        'cumulative_hazard': cumulative hazard at each time,
        'se': standard error of cumulative hazard.
    """
    time = np.asarray(time, dtype=float)
    event = np.asarray(event, dtype=int)

    order = np.argsort(time)
    t_sorted = time[order]
    e_sorted = event[order]

    unique_times = np.unique(t_sorted[e_sorted == 1])

    cum_haz = []
    se_list = []
    h = 0.0
    var_sum = 0.0

    for t in unique_times:
        n_at_risk = np.sum(t_sorted >= t)
        n_events = np.sum((t_sorted == t) & (e_sorted == 1))

        if n_at_risk > 0:
            h += n_events / n_at_risk
            var_sum += n_events / (n_at_risk ** 2)

        cum_haz.append(h)
        se_list.append(np.sqrt(var_sum))

    return {
        'times': unique_times,
        'cumulative_hazard': np.array(cum_haz),
        'se': np.array(se_list)
    }


def cox_proportional_hazards(time: np.ndarray, event: np.ndarray,
                             covariates: np.ndarray,
                             covariate_names: Optional[list] = None) -> dict:
    """Fit a Cox proportional hazards regression model.

    Uses Newton-Raphson optimization (BFGS with analytic gradient) of the
    partial likelihood. Tied event times are handled by the Breslow
    approximation: for every event i the risk set is taken as
    R(t_i) = {j : time_j >= time_i}, so multiple events occurring at the
    same time each contribute that identical full risk set to the
    log-partial-likelihood, gradient, and Hessian. This reproduces the
    Breslow tie-handling used by standard Cox solvers (e.g. lifelines /
    R survival with ties="breslow").

    Parameters
    ----------
    time : np.ndarray
        Observed survival times (n,).
    event : np.ndarray
        Event indicator (1 = event, 0 = censored) (n,).
    covariates : np.ndarray
        Covariate matrix (n, p).
    covariate_names : list, optional
        Names for each covariate.

    Returns
    -------
    dict
        'coefficients': estimated beta coefficients,
        'hazard_ratios': exp(beta),
        'se': standard errors of beta,
        'z_scores': beta / se,
        'p_values': two-sided p-values,
        'ci_lower_90': lower 90% CI for HR,
        'ci_upper_90': upper 90% CI for HR,
        'ci_lower_95': lower 95% CI for HR,
        'ci_upper_95': upper 95% CI for HR,
        'covariate_names': covariate names,
        'log_partial_likelihood': maximized log partial likelihood,
        'concordance_index': Harrell's C-index.
    """
    from scipy.optimize import minimize
    from scipy import stats as sp_stats

    time = np.asarray(time, dtype=float)
    event = np.asarray(event, dtype=int)
    X = np.asarray(covariates, dtype=float)
    if X.ndim == 1:
        X = X.reshape(-1, 1)

    n, p = X.shape
    if covariate_names is None:
        covariate_names = [f'x{i}' for i in range(p)]

    def neg_log_partial_likelihood(beta):
        xb = X @ beta
        ll = 0.0
        for i in range(n):
            if event[i] == 1:
                risk_set = time >= time[i]
                log_sum = np.log(np.sum(np.exp(xb[risk_set])))
                ll += xb[i] - log_sum
        return -ll

    def gradient(beta):
        xb = X @ beta
        grad = np.zeros(p)
        for i in range(n):
            if event[i] == 1:
                risk_set = time >= time[i]
                exp_xb = np.exp(xb[risk_set])
                w = exp_xb / np.sum(exp_xb)
                grad += X[i] - (X[risk_set].T @ w)
        return -grad

    # Initial guess
    beta0 = np.zeros(p)
    result = minimize(neg_log_partial_likelihood, beta0, jac=gradient,
                      method='BFGS', options={'maxiter': 1000})
    beta = result.x

    # Hessian for standard errors
    xb = X @ beta
    hessian = np.zeros((p, p))
    for i in range(n):
        if event[i] == 1:
            risk_set = time >= time[i]
            exp_xb = np.exp(xb[risk_set])
            w = exp_xb / np.sum(exp_xb)
            X_risk = X[risk_set]
            weighted_mean = X_risk.T @ w
            for j in range(p):
                for k in range(p):
                    weighted_cov = np.sum(w * X_risk[:, j] * X_risk[:, k]) - weighted_mean[j] * weighted_mean[k]
                    hessian[j, k] += weighted_cov

    try:
        cov_matrix = np.linalg.inv(hessian)
        se = np.sqrt(np.diag(cov_matrix))
    except np.linalg.LinAlgError:
        se = np.full(p, np.nan)

    z = beta / se
    p_values = 2 * (1 - sp_stats.norm.cdf(np.abs(z)))
    hr = np.exp(beta)

    # Concordance index
    c_index = concordance_index(time, event, X @ beta)

    return {
        'coefficients': beta.tolist(),
        'hazard_ratios': hr.tolist(),
        'se': se.tolist(),
        'z_scores': z.tolist(),
        'p_values': p_values.tolist(),
        'ci_lower_90': (hr * np.exp(-1.645 * se)).tolist(),
        'ci_upper_90': (hr * np.exp(1.645 * se)).tolist(),
        'ci_lower_95': (hr * np.exp(-1.96 * se)).tolist(),
        'ci_upper_95': (hr * np.exp(1.96 * se)).tolist(),
        'covariate_names': covariate_names,
        'log_partial_likelihood': float(-result.fun),
        'concordance_index': c_index
    }


def concordance_index(time: np.ndarray, event: np.ndarray,
                      risk_score: np.ndarray) -> float:
    """Compute Harrell's concordance index (C-index).

    Measures the proportion of concordant pairs among all usable pairs.
    A pair (i, j) is usable if the shorter-time subject had an event.
    A pair is concordant if the subject with higher risk score has shorter
    survival time.

    Parameters
    ----------
    time : np.ndarray
        Observed survival times.
    event : np.ndarray
        Event indicator (1 = event, 0 = censored).
    risk_score : np.ndarray
        Predicted risk scores (higher = higher risk).

    Returns
    -------
    float
        Concordance index between 0 and 1. 0.5 = random.
    """
    time = np.asarray(time, dtype=float)
    event = np.asarray(event, dtype=int)
    risk_score = np.asarray(risk_score, dtype=float)

    concordant = 0
    discordant = 0
    tied = 0
    n = len(time)

    for i in range(n):
        if event[i] == 0:
            continue
        for j in range(n):
            if i == j:
                continue
            if time[j] > time[i]:
                if risk_score[i] > risk_score[j]:
                    concordant += 1
                elif risk_score[i] < risk_score[j]:
                    discordant += 1
                else:
                    tied += 1

    total = concordant + discordant + tied
    if total == 0:
        return 0.5
    return float((concordant + 0.5 * tied) / total)


def schoenfeld_residuals(time: np.ndarray, event: np.ndarray,
                         covariates: np.ndarray,
                         cox_result: dict) -> dict:
    """Compute Schoenfeld residuals for testing the proportional hazards assumption.

    At each event time, the Schoenfeld residual for covariate j is:
    r_j(t_i) = x_{ij} - E[x_j | R(t_i)]
    where E[x_j | R(t_i)] is the weighted mean of x_j in the risk set.

    A significant correlation between Schoenfeld residuals and time
    indicates violation of the PH assumption.

    Parameters
    ----------
    time : np.ndarray
        Observed survival times.
    event : np.ndarray
        Event indicator.
    covariates : np.ndarray
        Covariate matrix (n, p).
    cox_result : dict
        Output of cox_proportional_hazards().

    Returns
    -------
    dict
        'event_times': times at which events occurred,
        'residuals': array of shape (n_events, p),
        'correlation_with_time': Pearson correlation of each residual with time,
        'p_values': p-value for the correlation test,
        'ph_assumption_violated': boolean for each covariate (p < 0.05).
    """
    from scipy import stats as sp_stats

    time = np.asarray(time, dtype=float)
    event = np.asarray(event, dtype=int)
    X = np.asarray(covariates, dtype=float)
    if X.ndim == 1:
        X = X.reshape(-1, 1)

    beta = np.array(cox_result['coefficients'])
    n, p = X.shape

    event_idx = np.where(event == 1)[0]
    event_times = time[event_idx]
    order = np.argsort(event_times)
    event_idx = event_idx[order]
    event_times = event_times[order]

    residuals = []
    xb = X @ beta

    for i in event_idx:
        risk_set = time >= time[i]
        exp_xb = np.exp(xb[risk_set])
        w = exp_xb / np.sum(exp_xb)
        weighted_mean = X[risk_set].T @ w
        resid = X[i] - weighted_mean
        residuals.append(resid)

    residuals = np.array(residuals)

    # Test correlation with time
    correlations = []
    p_values = []
    violated = []

    for j in range(p):
        if len(event_times) > 2:
            r, pval = sp_stats.pearsonr(event_times, residuals[:, j])
        else:
            r, pval = 0.0, 1.0
        correlations.append(float(r))
        p_values.append(float(pval))
        violated.append(pval < 0.05)

    return {
        'event_times': event_times.tolist(),
        'residuals': residuals.tolist(),
        'correlation_with_time': correlations,
        'p_values': p_values,
        'ph_assumption_violated': violated
    }


def restricted_mean_survival_time(km_result: dict, tau: float) -> dict:
    """Compute the Restricted Mean Survival Time (RMST).

    RMST(tau) = integral from 0 to tau of S(t) dt, where S(t) is
    the Kaplan-Meier estimate. Approximated by trapezoidal integration.

    Parameters
    ----------
    km_result : dict
        Output of kaplan_meier_estimator().
    tau : float
        Restriction time (upper limit of integration).

    Returns
    -------
    dict
        'rmst': restricted mean survival time,
        'tau': restriction time used,
        'se': standard error of RMST.
    """
    times = km_result['times']
    surv = km_result['survival']

    # Prepend time=0, S=1
    t = np.concatenate([[0], times])
    s = np.concatenate([[1.0], surv])

    # Truncate at tau
    mask = t <= tau
    t_trunc = t[mask]
    s_trunc = s[mask]

    # Add endpoint at tau
    if t_trunc[-1] < tau:
        t_trunc = np.append(t_trunc, tau)
        s_trunc = np.append(s_trunc, s_trunc[-1])

    # Trapezoidal integration
    rmst = np.trapz(s_trunc, t_trunc)

    # Approximate SE using Greenwood-based formula
    se_arr = km_result['se']
    n_events = km_result['n_events']
    n_at_risk = km_result['n_at_risk']

    var_rmst = 0.0
    for i in range(len(times)):
        if times[i] > tau:
            break
        remaining_area = np.trapz(
            s_trunc[np.searchsorted(t_trunc, times[i]):],
            t_trunc[np.searchsorted(t_trunc, times[i]):]
        )
        if n_at_risk[i] > n_events[i] and n_at_risk[i] > 0:
            var_rmst += (remaining_area ** 2) * n_events[i] / (n_at_risk[i] * (n_at_risk[i] - n_events[i]))

    return {
        'rmst': float(rmst),
        'tau': tau,
        'se': float(np.sqrt(var_rmst))
    }


def bootstrap_hazard_ratio(time: np.ndarray, event: np.ndarray,
                           group: np.ndarray,
                           n_bootstrap: int = 2000,
                           confidence_level: float = 0.90,
                           seed: int = 42) -> dict:
    """Compute bootstrap confidence interval for the hazard ratio.

    Resamples the data with replacement and fits a Cox model on each
    bootstrap sample. Returns the percentile-based CI.

    Parameters
    ----------
    time : np.ndarray
        Observed survival times.
    event : np.ndarray
        Event indicator.
    group : np.ndarray
        Group indicator (binary, 0/1).
    n_bootstrap : int
        Number of bootstrap samples.
    confidence_level : float
        Confidence level (e.g. 0.90 for 90% CI).
    seed : int
        Random seed.

    Returns
    -------
    dict
        'point_estimate': HR from original data,
        'ci_lower': lower percentile CI,
        'ci_upper': upper percentile CI,
        'bootstrap_hrs': array of bootstrap HR estimates,
        'n_bootstrap': number of bootstrap samples used.
    """
    rng = np.random.RandomState(seed)
    n = len(time)

    # Point estimate
    original = cox_proportional_hazards(time, event, group.reshape(-1, 1))
    point_hr = original['hazard_ratios'][0]

    alpha = 1.0 - confidence_level
    hrs = []

    for _ in range(n_bootstrap):
        idx = rng.choice(n, size=n, replace=True)
        t_b = time[idx]
        e_b = event[idx]
        g_b = group[idx]

        # Skip degenerate samples
        if np.sum(e_b) < 2 or len(np.unique(g_b[e_b == 1])) < 2:
            continue

        try:
            res = cox_proportional_hazards(t_b, e_b, g_b.reshape(-1, 1))
            hrs.append(res['hazard_ratios'][0])
        except Exception:
            continue

    hrs = np.array(hrs)
    if len(hrs) == 0:
        return {
            'point_estimate': point_hr,
            'ci_lower': None, 'ci_upper': None,
            'bootstrap_hrs': [], 'n_bootstrap': 0
        }

    return {
        'point_estimate': float(point_hr),
        'ci_lower': float(np.percentile(hrs, 100 * alpha / 2)),
        'ci_upper': float(np.percentile(hrs, 100 * (1 - alpha / 2))),
        'bootstrap_hrs': hrs.tolist(),
        'n_bootstrap': len(hrs)
    }


def time_dependent_auc(time: np.ndarray, event: np.ndarray,
                       risk_score: np.ndarray,
                       eval_times: np.ndarray) -> dict:
    """Compute time-dependent AUC at specified time points.

    Uses the incident/dynamic definition: at time t, cases are subjects
    who experience the event at exactly time t, and controls are those
    still alive at time t.

    Parameters
    ----------
    time : np.ndarray
        Observed survival times.
    event : np.ndarray
        Event indicator.
    risk_score : np.ndarray
        Predicted risk scores (higher = higher risk).
    eval_times : np.ndarray
        Time points at which to evaluate AUC.

    Returns
    -------
    dict
        'times': evaluation time points,
        'auc': AUC at each time point.
    """
    time = np.asarray(time, dtype=float)
    event = np.asarray(event, dtype=int)
    risk_score = np.asarray(risk_score, dtype=float)
    eval_times = np.asarray(eval_times, dtype=float)

    aucs = []
    for t in eval_times:
        # Cases: events at time t (or before t for cumulative/dynamic)
        cases = (time <= t) & (event == 1)
        controls = time > t

        if np.sum(cases) == 0 or np.sum(controls) == 0:
            aucs.append(np.nan)
            continue

        concordant = 0
        total = 0
        for i in np.where(cases)[0]:
            for j in np.where(controls)[0]:
                total += 1
                if risk_score[i] > risk_score[j]:
                    concordant += 1
                elif risk_score[i] == risk_score[j]:
                    concordant += 0.5

        aucs.append(concordant / total if total > 0 else np.nan)

    return {
        'times': eval_times.tolist(),
        'auc': aucs
    }


def number_at_risk_table(time: np.ndarray, event: np.ndarray,
                         group: np.ndarray,
                         time_points: np.ndarray) -> dict:
    """Generate a number-at-risk table at specified time points.

    For each group and each time point, counts how many subjects
    are still at risk (alive and not yet censored).

    Parameters
    ----------
    time : np.ndarray
        Observed survival times.
    event : np.ndarray
        Event indicator.
    group : np.ndarray
        Group indicator.
    time_points : np.ndarray
        Time points for the table.

    Returns
    -------
    dict
        'time_points': the queried time points,
        'groups': dict mapping group label to list of at-risk counts.
    """
    time = np.asarray(time, dtype=float)
    group = np.asarray(group)
    time_points = np.asarray(time_points, dtype=float)

    unique_groups = np.unique(group)
    result = {'time_points': time_points.tolist(), 'groups': {}}

    for g in unique_groups:
        mask = group == g
        t_g = time[mask]
        counts = []
        for tp in time_points:
            counts.append(int(np.sum(t_g >= tp)))
        result['groups'][str(int(g))] = counts

    return result


def compare_rmst(time1: np.ndarray, event1: np.ndarray,
                 time2: np.ndarray, event2: np.ndarray,
                 tau: float) -> dict:
    """Compare Restricted Mean Survival Time between two groups.

    Computes RMST for each group and the difference/ratio with
    confidence intervals.

    Parameters
    ----------
    time1, event1 : np.ndarray
        Group 1 data.
    time2, event2 : np.ndarray
        Group 2 data.
    tau : float
        Restriction time.

    Returns
    -------
    dict
        'rmst_1': RMST for group 1,
        'rmst_2': RMST for group 2,
        'difference': RMST_1 - RMST_2,
        'se_difference': SE of the difference,
        'ci_lower': lower 95% CI of difference,
        'ci_upper': upper 95% CI of difference,
        'p_value': p-value for test of difference = 0.
    """
    from scipy import stats as sp_stats

    km1 = kaplan_meier_estimator(time1, event1)
    km2 = kaplan_meier_estimator(time2, event2)

    rmst1 = restricted_mean_survival_time(km1, tau)
    rmst2 = restricted_mean_survival_time(km2, tau)

    diff = rmst1['rmst'] - rmst2['rmst']
    se_diff = np.sqrt(rmst1['se'] ** 2 + rmst2['se'] ** 2)

    if se_diff > 0:
        z = diff / se_diff
        p_value = 2 * (1 - sp_stats.norm.cdf(abs(z)))
    else:
        p_value = 1.0

    return {
        'rmst_1': rmst1['rmst'],
        'rmst_2': rmst2['rmst'],
        'difference': diff,
        'se_difference': se_diff,
        'ci_lower': diff - 1.96 * se_diff,
        'ci_upper': diff + 1.96 * se_diff,
        'p_value': float(p_value)
    }

"""Deterministic artifact generation for the scored math_op01 task."""

from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def _frontier_columns(frame):
    """Return (return_col, variance_col) with common OR-Library aliases."""
    lower = {c.lower(): c for c in frame.columns}
    return_col = lower.get("mean_return") or lower.get("return") or lower.get("returns") or frame.columns[0]
    var_col = lower.get("variance") or lower.get("var") or frame.columns[1]
    return return_col, var_col


def generate_standard_artifacts(task_root: str = ".", output_dir: str = "outputs/artifacts"):
    """Generate the three standard PNG artifacts from bundled CSV evidence.

    The function intentionally consumes the auditable standard CSV tables rather
    than rerunning stochastic solvers. It is the canonical image-generation
    entry point for the benchmark answer artifacts.
    """
    root = Path(task_root)
    out = root / output_dir
    out.mkdir(parents=True, exist_ok=True)
    tc = root / "task_content"
    data = root / "input_data" / "data"

    results = pd.read_csv(tc / "standard_results_k10.csv")
    points = pd.read_csv(tc / "standard_points_k10.csv")
    sens = pd.read_csv(tc / "cardinality_sensitivity_hang_seng.csv")

    paths = {}

    # Fig. 1: Hang Seng reference frontier and feasible solver points.
    ref = pd.read_csv(data / "efficient_frontier_Hang_Seng.csv")
    ret_col, var_col = _frontier_columns(ref)
    hpts = points[(points["index"] == "Hang_Seng") & points["actual_return"].notna()]
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.plot(ref[var_col], ref[ret_col], color="black", lw=1.6, label="Unconstrained reference")
    for solver, g in hpts.groupby("solver"):
        ax.scatter(g["variance"], g["actual_return"], s=48, label=solver)
    ax.set_xlabel("Variance")
    ax.set_ylabel("Expected return")
    ax.set_title("Hang Seng K=10 feasible solver points")
    ax.grid(True, alpha=0.3)
    ax.legend(fontsize=8)
    fig.tight_layout()
    paths["efficient_frontiers"] = str(out / "Fig_1_efficient_frontiers.png")
    fig.savefig(paths["efficient_frontiers"], dpi=150, bbox_inches="tight")
    plt.close(fig)

    # Fig. 2: penalized Mean comparison.
    indices = list(dict.fromkeys(results["index"].tolist()))
    solvers = ["GRASP", "SA", "GA", "Tabu"]
    fig, ax = plt.subplots(figsize=(12, 6))
    x = range(len(indices))
    width = 0.8 / len(solvers)
    for i, solver in enumerate(solvers):
        vals = [float(results[(results["index"] == idx) & (results["solver"] == solver)]["mean"].iloc[0]) for idx in indices]
        xpos = [v + i * width - 0.4 + width / 2 for v in x]
        ax.bar(xpos, vals, width, label=solver, alpha=0.85)
    ax.set_xticks(list(x))
    ax.set_xticklabels(indices, rotation=35, ha="right")
    ax.set_xlabel("Market index")
    ax.set_ylabel("Penalized Mean percentage error")
    ax.set_title("K=10 solver comparison with infeasible target penalties")
    ax.grid(True, alpha=0.3, axis="y")
    ax.legend(ncol=4, fontsize=8)
    fig.tight_layout()
    paths["algorithm_comparison"] = str(out / "Fig_2_algorithm_comparison.png")
    fig.savefig(paths["algorithm_comparison"], dpi=150, bbox_inches="tight")
    plt.close(fig)

    # Fig. 3: deterministic Hang Seng cardinality sensitivity support plot.
    collapsed = sens.groupby("K", as_index=False).agg(actual_return=("actual_return", "first"), variance=("variance", "first"))
    fig, ax1 = plt.subplots(figsize=(8, 5))
    ax1.plot(collapsed["K"], collapsed["variance"], marker="o", color="tab:blue", label="Variance")
    ax1.set_xlabel("Cardinality K")
    ax1.set_ylabel("Variance", color="tab:blue")
    ax1.tick_params(axis="y", labelcolor="tab:blue")
    ax2 = ax1.twinx()
    ax2.plot(collapsed["K"], collapsed["actual_return"], marker="s", color="tab:orange", label="Return")
    ax2.set_ylabel("Expected return", color="tab:orange")
    ax2.tick_params(axis="y", labelcolor="tab:orange")
    ax1.set_title("Hang Seng TopReturnEqualWeight cardinality sensitivity")
    ax1.grid(True, alpha=0.3)
    fig.tight_layout()
    paths["cardinality_sensitivity"] = str(out / "Fig_3_cardinality_sensitivity.png")
    fig.savefig(paths["cardinality_sensitivity"], dpi=150, bbox_inches="tight")
    plt.close(fig)

    return paths

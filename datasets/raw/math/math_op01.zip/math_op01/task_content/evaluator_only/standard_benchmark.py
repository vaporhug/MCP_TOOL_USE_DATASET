"""Deterministic low-budget benchmark protocol for the scored K=10 task."""

import numpy as np
import json
from typing import Dict

try:
    from tools.data_loading import load_asset_data, load_covariance_matrix, load_efficient_frontier
    from tools.benchmark_runner import run_benchmark_suite, aggregate_metrics
    from tools.grasp_solver import grasp_portfolio
    from tools.simulated_annealing import sa_portfolio
    from tools.genetic_algorithm import ga_portfolio
    from tools.tabu_search import tabu_portfolio
except ImportError:
    from data_loading import load_asset_data, load_covariance_matrix, load_efficient_frontier
    from benchmark_runner import run_benchmark_suite, aggregate_metrics
    from grasp_solver import grasp_portfolio
    from simulated_annealing import sa_portfolio
    from genetic_algorithm import ga_portfolio
    from tabu_search import tabu_portfolio

INDICES = ["Hang_Seng", "DAX_100", "FTSE_100", "SP_100", "Nikkei_225"]
TARGET_QUANTILES = [0.25, 0.50, 0.75]
SOLVER_KWARGS = {
    "GRASP": {"n_iterations": 1, "eps": 0.01},
    "SA": {"max_iter": 20, "T_init": 1.0, "T_min": 1e-3, "alpha": 0.90, "eps": 0.01},
    "GA": {"pop_size": 10, "n_generations": 5, "eps": 0.01},
    "Tabu": {"max_iter": 20, "n_neighbors": 5, "eps": 0.01},
}
SOLVERS = {
    "GRASP": grasp_portfolio,
    "SA": sa_portfolio,
    "GA": ga_portfolio,
    "Tabu": tabu_portfolio,
}


def target_returns_from_reference(ref_returns: np.ndarray) -> np.ndarray:
    """Return the three central target-return quantiles used for scoring."""
    return np.quantile(np.sort(np.asarray(ref_returns, dtype=float)), TARGET_QUANTILES)


def run_standard_k10_protocol(data_dir: str = "input_data/data",
                              indices=None) -> Dict[str, Dict[str, Dict[str, float]]]:
    """Run the fixed K=10, three-target, one-run benchmark protocol.

    Infeasible solver outputs are filtered by benchmark_runner.run_single_instance,
    which calls check_feasibility(..., require_exact_K=True). Returned n_points can
    therefore be below three for solvers that do not produce feasible portfolios at
    all target returns. aggregate_metrics still compares every solver over the same
    three target records by applying penalized_target_frontier_error to infeasible
    or missing records instead of dropping them.
    """
    out = {}
    for index in (INDICES if indices is None else list(indices)):
        means, _ = load_asset_data(f"{data_dir}/assets_{index}.csv")
        cov = load_covariance_matrix(f"{data_dir}/covariance_{index}.csv")
        ref_returns, ref_vars = load_efficient_frontier(f"{data_dir}/efficient_frontier_{index}.csv")
        targets = target_returns_from_reference(ref_returns)
        frontiers = run_benchmark_suite(
            SOLVERS, means, cov, 10, targets, solver_kwargs=SOLVER_KWARGS, n_runs=1
        )
        out[index] = aggregate_metrics(frontiers, ref_returns, ref_vars, means=means, K=10, eps=0.01)
    return out


def standard_tables(data_dir: str = "input_data/data", indices=None):
    """Return metric rows and point-level audit rows for the scored protocol."""
    rows = []
    point_rows = []
    for index in (INDICES if indices is None else list(indices)):
        means, _ = load_asset_data(f"{data_dir}/assets_{index}.csv")
        cov = load_covariance_matrix(f"{data_dir}/covariance_{index}.csv")
        ref_returns, ref_vars = load_efficient_frontier(f"{data_dir}/efficient_frontier_{index}.csv")
        targets = target_returns_from_reference(ref_returns)
        frontiers = run_benchmark_suite(
            SOLVERS, means, cov, 10, targets, solver_kwargs=SOLVER_KWARGS, n_runs=1
        )
        metrics = aggregate_metrics(frontiers, ref_returns, ref_vars, means=means, K=10, eps=0.01)
        for solver, metric in metrics.items():
            rows.append({
                "index": index, "solver": solver,
                "mean": round(metric["mean"], 4),
                "vre": round(metric["vre"], 4),
                "mre": round(metric["mre"], 4),
                "n_points": int(metric["n_points"]),
            })
            for rec in frontiers[solver]["point_records"]:
                weights = np.asarray(rec.get("best_weights", []), dtype=float)
                selected = np.where(np.abs(weights) > 1e-8)[0].tolist() if weights.size else []
                selected_weights = [float(weights[i]) for i in selected] if weights.size else []
                point_rows.append({
                    "index": index, "solver": solver,
                    "target_return": rec["target_return"],
                    "actual_return": rec["actual_return"],
                    "variance": rec["variance"],
                    "n_feasible_runs": rec["n_feasible_runs"],
                    "n_failures": len(rec["failures"]),
                    "selected_asset_row_indices_0based": json.dumps(selected, separators=(",", ":")),
                    "selected_asset_ids_1based": json.dumps([i + 1 for i in selected], separators=(",", ":")),
                    "selected_weights": json.dumps(selected_weights, separators=(",", ":")),
                    "feasibility_violations": json.dumps(rec["failures"], separators=(",", ":")),
                })
    return rows, point_rows


def hang_seng_cardinality_sensitivity_points(data_dir: str = "input_data/data"):
    """Return cheap audited Hang Seng K-sensitivity rows.

    This plot-support protocol is intentionally deterministic and lightweight:
    for each K, select the K highest-mean-return assets and hold them equally.
    It is not used for solver scoring; it supplies machine-checkable Fig. 3
    reference points without running slow stochastic optimizers.
    """
    index = "Hang_Seng"
    means, _ = load_asset_data(f"{data_dir}/assets_{index}.csv")
    cov = load_covariance_matrix(f"{data_dir}/covariance_{index}.csv")
    ref_returns, _ = load_efficient_frontier(f"{data_dir}/efficient_frontier_{index}.csv")
    targets = target_returns_from_reference(ref_returns)
    rows = []
    for K in [5, 10, 15, 20]:
        selected = np.argsort(means)[-K:]
        weights = np.zeros_like(means, dtype=float)
        weights[selected] = 1.0 / K
        actual_return = float(weights @ means)
        variance = float(weights @ cov @ weights)
        for target in targets:
            violations = []
            if actual_return < float(target):
                violations.append({
                    "reason": "target return not met",
                    "actual_return": actual_return,
                    "target_return": float(target),
                })
            rows.append({
                "index": index,
                "solver": "TopReturnEqualWeight",
                "K": K,
                "target_return": float(target),
                "actual_return": actual_return,
                "variance": variance,
                "n_feasible_runs": int(not violations),
                "n_failures": int(bool(violations)),
                "selected_asset_row_indices_0based": json.dumps(selected.tolist(), separators=(",", ":")),
                "selected_asset_ids_1based": json.dumps([int(i) + 1 for i in selected], separators=(",", ":")),
                "selected_weights": json.dumps([float(weights[i]) for i in selected], separators=(",", ":")),
                "feasibility_violations": json.dumps(violations, separators=(",", ":")),
            })
    return rows

# Visibility Manifest

Participant-visible during solving:

- Model-facing instruction/ask extracted by the benchmark runner.
- `input_data/data/assets_*.csv`
- `input_data/data/covariance_*.csv`
- `input_data/data/efficient_frontier_*.csv`
- `input_data/reference_paper/target.pdf`
- Participant tools in `tools/*.py`.
- `task_content/requirements.txt` for runtime setup.
- `task_content/NOTICE.md` for source attribution and license notice.

Evaluator-only / not shown to participants during solving:

- `task_content/task_content.json` answer entries, expected_results, scoring_metadata, and evaluator checklists.
- Bundled answer CSVs: `task_content/standard_results_k10.csv`, `task_content/standard_points_k10.csv`, and `task_content/cardinality_sensitivity_hang_seng.csv`.
- Evaluator-only answer-regeneration modules: `task_content/evaluator_only/standard_benchmark.py` and `task_content/evaluator_only/standard_artifacts.py`.
- Reference answer images: `task_content/evaluator_only/reference_artifacts/Fig_1_efficient_frontiers.png`, `task_content/evaluator_only/reference_artifacts/Fig_2_algorithm_comparison.png`, and `task_content/evaluator_only/reference_artifacts/Fig_3_cardinality_sensitivity.png`.

Participants generate CSV deliverables under `outputs/` and figures under `outputs/artifacts/`. Reference CSVs and PNGs are stored only in evaluator-only locations.

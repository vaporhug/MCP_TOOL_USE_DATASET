"""GRASP (Greedy Randomized Adaptive Search Procedure) for portfolio optimization.

GRASP is a multi-start metaheuristic that combines a greedy randomized construction
phase with a local search phase.
"""

import numpy as np
from scipy.optimize import minimize
from typing import Dict, Optional


def _solve_inner_qp(selected, means, cov, target_return, eps, delta=1.0):
    """Min-variance weights for a fixed asset set under budget, bounds and an
    optional target-return constraint. Returns (weights_full, success)."""
    n = len(means)
    K_actual = len(selected)
    sub_means = means[selected]
    sub_cov = cov[np.ix_(selected, selected)]
    constraints = [{"type": "eq", "fun": lambda wa: np.sum(wa) - 1}]
    if target_return is not None:
        constraints.append({
            "type": "ineq",
            "fun": lambda wa: float(wa @ sub_means) - target_return,
        })
    result = minimize(
        lambda wa: wa @ sub_cov @ wa,
        np.ones(K_actual) / K_actual,
        method="SLSQP",
        jac=lambda wa: 2 * sub_cov @ wa,
        constraints=constraints,
        bounds=[(eps, delta)] * K_actual,
        options={"ftol": 1e-12, "maxiter": 500},
    )
    w = np.zeros(n)
    w[selected] = result.x if result.success else np.ones(K_actual) / K_actual
    return w, bool(result.success)


def _greedy_construction(means: np.ndarray, cov: np.ndarray,
                         K: int, target_return: float,
                         alpha_greedy: float = 0.3,
                         eps: float = 0.01) -> np.ndarray:
    """Greedy randomized construction of a K-asset portfolio.

    Parameters
    ----------
    means : np.ndarray, shape (n,)
    cov : np.ndarray, shape (n, n)
    K : int
    target_return : float
    alpha_greedy : float
        Controls randomness (0=pure greedy, 1=pure random).
    eps : float
        Minimum weight.

    Returns
    -------
    weights : np.ndarray, shape (n,)
    """
    n = len(means)
    selected = []
    candidates = list(range(n))

    # Greedily select assets with best return-to-risk ratio
    for _ in range(K):
        if not candidates:
            break

        # Score each candidate
        scores = []
        for c in candidates:
            ratio = means[c] / max(np.sqrt(cov[c, c]), 1e-12)
            scores.append(ratio)

        scores = np.array(scores)
        s_min, s_max = scores.min(), scores.max()
        threshold = s_max - alpha_greedy * (s_max - s_min)

        # Restricted candidate list
        rcl = [candidates[i] for i in range(len(candidates))
               if scores[i] >= threshold]

        if not rcl:
            rcl = candidates

        chosen = np.random.choice(rcl)
        selected.append(chosen)
        candidates.remove(chosen)

    selected = np.array(selected)

    # Optimize weights for selected assets
    w = np.zeros(n)
    K_actual = len(selected)
    sub_means = means[selected]
    sub_cov = cov[np.ix_(selected, selected)]

    result = minimize(
        lambda wa: wa @ sub_cov @ wa,
        np.ones(K_actual) / K_actual,
        method="SLSQP",
        jac=lambda wa: 2 * sub_cov @ wa,
        constraints=[
            {"type": "eq", "fun": lambda wa: np.sum(wa) - 1},
        ],
        bounds=[(eps, 1)] * K_actual,
        options={"ftol": 1e-12},
    )

    w[selected] = result.x if result.success else np.ones(K_actual) / K_actual
    return w


def _local_search(weights: np.ndarray, means: np.ndarray,
                  cov: np.ndarray, K: int,
                  target_return: float,
                  max_no_improve: int = 8,
                  eps: float = 0.01,
                  max_candidates: int = 10) -> np.ndarray:
    """Local search: try swapping one asset at a time.

    Parameters
    ----------
    weights : np.ndarray, shape (n,)
    means, cov : asset data
    K : int
    target_return : float
    max_no_improve : int
    eps : float

    Returns
    -------
    improved_weights : np.ndarray, shape (n,)
    """
    n = len(means)
    best_w = weights.copy()
    best_var = float(best_w @ cov @ best_w)
    no_improve = 0

    while no_improve < max_no_improve:
        improved = False
        selected = np.where(np.abs(best_w) > 1e-8)[0]
        unselected = np.setdiff1d(np.arange(n), selected)

        if len(unselected) == 0:
            break

        # Try swapping each selected asset with a bounded set of unselected
        # candidates. The inner QP uses an analytic jacobian and a capped
        # candidate list so the local search stays tractable on the larger
        # OR-Library instances (n up to 225).
        n_cand = min(len(unselected), max_candidates)
        for s_idx in np.random.permutation(len(selected)):
            for u_idx in np.random.permutation(len(unselected))[:n_cand]:
                trial_sel = selected.copy()
                trial_sel[s_idx] = unselected[u_idx]
                trial_sel = np.sort(trial_sel)

                trial_w, ok = _solve_inner_qp(trial_sel, means, cov,
                                              target_return, eps)
                if ok:
                    trial_var = float(trial_w @ cov @ trial_w)
                    trial_ret = float(trial_w @ means)

                    if trial_var < best_var and trial_ret >= target_return - 1e-8:
                        best_w = trial_w
                        best_var = trial_var
                        improved = True
                        break
            if improved:
                break

        if not improved:
            no_improve += 1
        else:
            no_improve = 0

    return best_w


def grasp_portfolio(means: np.ndarray, cov: np.ndarray,
                    K: int, target_return: float,
                    n_iterations: int = 20,
                    alpha_greedy: float = 0.3,
                    eps: float = 0.01,
                    seed: Optional[int] = None) -> Dict:
    """GRASP solver for cardinality-constrained portfolio optimization.

    Parameters
    ----------
    means : np.ndarray, shape (n,)
    cov : np.ndarray, shape (n, n)
    K : int
    target_return : float
    n_iterations : int
        Number of GRASP iterations.
    alpha_greedy : float
        Greediness parameter (0=greedy, 1=random).
    eps : float
        Minimum weight per asset.
    seed : int, optional

    Returns
    -------
    dict with 'weights', 'variance', 'return', 'iteration_history'.
    """
    if seed is not None:
        np.random.seed(seed)

    n = len(means)
    best_w = None
    best_var = np.inf
    best_feasible = False
    history = []
    ret_tol = 1e-8

    for it in range(n_iterations):
        # Construction phase
        w = _greedy_construction(means, cov, K, target_return,
                                 alpha_greedy, eps)
        # Re-solve the inner QP with the target-return constraint enforced so
        # the construction output respects the requested return level.
        sel = np.where(np.abs(w) > 1e-8)[0]
        if len(sel) > 0:
            w_qp, ok = _solve_inner_qp(sel, means, cov, target_return, eps)
            if ok:
                w = w_qp
        # Local search phase
        w = _local_search(w, means, cov, K, target_return, eps=eps)

        var = float(w @ cov @ w)
        ret = float(w @ means)
        feasible = (target_return is None) or (ret >= target_return - ret_tol)

        # Prefer feasible solutions; among same feasibility, prefer lower variance.
        better = (feasible and not best_feasible) or \
                 (feasible == best_feasible and var < best_var)
        if best_w is None or better:
            best_w = w.copy()
            best_var = var
            best_feasible = feasible

        history.append({"iteration": it, "variance": var, "return": ret,
                        "best_variance": best_var})

    best_ret = float(best_w @ means)
    status = "feasible"
    if target_return is not None and best_ret < target_return - ret_tol:
        status = "infeasible: target return not met"

    return {
        "weights": best_w,
        "variance": best_var,
        "return": best_ret,
        "feasible": best_feasible,
        "status": status,
        "iteration_history": history,
    }

"""Metrics for comparing constrained vs unconstrained efficient frontiers.

Implements the standard evaluation metrics used in cardinality-constrained
portfolio optimization benchmarks.
"""

import numpy as np
from typing import Dict, Tuple

try:
    from .cardinality_constraint import check_feasibility
except ImportError:  # pragma: no cover - supports direct script imports
    try:
        from cardinality_constraint import check_feasibility
    except ImportError:  # pragma: no cover - metrics can still score audited CSV rows
        check_feasibility = None


def percentage_excess(constrained_var: float,
                      unconstrained_var: float) -> float:
    """Percentage excess variance of constrained over unconstrained frontier.

    PE = (constrained_var - unconstrained_var) / unconstrained_var * 100

    Parameters
    ----------
    constrained_var : float
    unconstrained_var : float

    Returns
    -------
    pe : float
        Percentage excess (0 = same as unconstrained, >0 = worse).
    """
    if unconstrained_var < 1e-15:
        return 0.0
    return (constrained_var - unconstrained_var) / unconstrained_var * 100.0


def mean_percentage_excess(constrained_vars: np.ndarray,
                           unconstrained_vars: np.ndarray) -> float:
    """Mean percentage excess over all return target points.

    Parameters
    ----------
    constrained_vars : np.ndarray, shape (m,)
    unconstrained_vars : np.ndarray, shape (m,)

    Returns
    -------
    mpe : float
    """
    valid = unconstrained_vars > 1e-15
    if not np.any(valid):
        return 0.0
    pe = (constrained_vars[valid] - unconstrained_vars[valid]) / unconstrained_vars[valid] * 100
    return float(np.mean(pe))


def euclidean_distance_to_frontier(constrained_returns: np.ndarray,
                                   constrained_vars: np.ndarray,
                                   ref_returns: np.ndarray,
                                   ref_vars: np.ndarray) -> np.ndarray:
    """Minimum Euclidean distance from each constrained point to the reference frontier.

    Parameters
    ----------
    constrained_returns : np.ndarray
    constrained_vars : np.ndarray
    ref_returns : np.ndarray
    ref_vars : np.ndarray

    Returns
    -------
    distances : np.ndarray, shape (len(constrained_returns),)
    """
    distances = np.zeros(len(constrained_returns))
    for i in range(len(constrained_returns)):
        d = np.sqrt((ref_returns - constrained_returns[i])**2 +
                    (ref_vars - constrained_vars[i])**2)
        distances[i] = np.min(d)
    return distances


def mean_euclidean_distance(constrained_returns: np.ndarray,
                            constrained_vars: np.ndarray,
                            ref_returns: np.ndarray,
                            ref_vars: np.ndarray) -> float:
    """Mean of minimum Euclidean distances (MEUCD metric).

    Parameters
    ----------
    constrained_returns, constrained_vars : arrays for constrained frontier
    ref_returns, ref_vars : arrays for unconstrained frontier

    Returns
    -------
    meucd : float
    """
    d = euclidean_distance_to_frontier(constrained_returns, constrained_vars,
                                       ref_returns, ref_vars)
    return float(np.mean(d))


def variance_ratio_excess(constrained_vars: np.ndarray,
                          unconstrained_vars: np.ndarray) -> float:
    """Variance Ratio Excess (VRE): mean of (constrained_var / unconstrained_var).

    Parameters
    ----------
    constrained_vars : np.ndarray
    unconstrained_vars : np.ndarray

    Returns
    -------
    vre : float
    """
    valid = unconstrained_vars > 1e-15
    if not np.any(valid):
        return 1.0
    ratios = constrained_vars[valid] / unconstrained_vars[valid]
    return float(np.mean(ratios))


def mean_return_error(constrained_returns: np.ndarray,
                      target_returns: np.ndarray) -> float:
    """Mean Return Error (MRE): mean absolute deviation from target returns.

    Parameters
    ----------
    constrained_returns : np.ndarray
        Achieved returns.
    target_returns : np.ndarray
        Target return levels.

    Returns
    -------
    mre : float
    """
    return float(np.mean(np.abs(constrained_returns - target_returns)))


def interpolate_reference_variance(query_returns: np.ndarray,
                                   ref_returns: np.ndarray,
                                   ref_variances: np.ndarray) -> np.ndarray:
    """Deterministically interpolate the reference-frontier variance at given returns.

    The OR-Library reference frontier is a 2001-point (return, variance) curve.
    For each query return this returns the linearly interpolated reference
    variance, after sorting the reference by return ascending so the result is
    independent of the order in which the reference points are supplied. Query
    returns outside the reference return range are clamped to the nearest
    reference endpoint (np.interp behaviour), which keeps the mapping total and
    deterministic.

    Parameters
    ----------
    query_returns : np.ndarray, shape (m,)
        Return levels (e.g. of a constrained frontier) to look up.
    ref_returns : np.ndarray, shape (M,)
    ref_variances : np.ndarray, shape (M,)

    Returns
    -------
    np.ndarray, shape (m,)
        Reference variance interpolated at each query return.
    """
    order = np.argsort(ref_returns)
    r_sorted = np.asarray(ref_returns)[order]
    v_sorted = np.asarray(ref_variances)[order]
    return np.interp(np.asarray(query_returns), r_sorted, v_sorted)


def standardized_frontier_error(heur_returns: np.ndarray,
                                heur_variances: np.ndarray,
                                ref_returns: np.ndarray,
                                ref_variances: np.ndarray) -> Dict[str, float]:
    """Chang et al. (2000) standardized frontier-error metrics.

    For each of the reference frontier's points i (return R_i, variance V_i),
    the heuristic frontier is queried at the same return level R_i and the
    *standardized* errors are formed:

      * variance error  e^V_i = |V_i - Vhat(R_i)| / V_i
      * return  error   e^R_i = |R_i - Rhat(V_i)| / R_i

    where Vhat(R_i) is the heuristic variance interpolated at return R_i and
    Rhat(V_i) is the heuristic return interpolated at variance V_i. The reported
    metrics are:

      * 'mean'  : mean over points of the smaller of the two standardized errors
                  (percentage), i.e. the standard "Mean percentage error" of the
                  heuristic frontier relative to the standard frontier;
      * 'vre'   : Variance Ratio Error, mean of e^V (percentage);
      * 'mre'   : Mean Return Error, mean of e^R (percentage).

    All three are deterministic given the inputs (interpolation only).

    Parameters
    ----------
    heur_returns, heur_variances : np.ndarray
        The heuristic / constrained frontier points.
    ref_returns, ref_variances : np.ndarray
        The reference (unconstrained) frontier points.

    Returns
    -------
    dict with 'mean', 'vre', 'mre' (all in percent).
    """
    R = np.asarray(ref_returns, dtype=float)
    V = np.asarray(ref_variances, dtype=float)
    hr = np.asarray(heur_returns, dtype=float)
    hv = np.asarray(heur_variances, dtype=float)

    # Sort heuristic frontier for interpolation in both directions.
    o_r = np.argsort(hr)
    hr_by_r, hv_by_r = hr[o_r], hv[o_r]
    o_v = np.argsort(hv)
    hv_by_v, hr_by_v = hv[o_v], hr[o_v]

    Vhat = np.interp(R, hr_by_r, hv_by_r)          # heuristic variance at ref return
    Rhat = np.interp(V, hv_by_v, hr_by_v)          # heuristic return at ref variance

    with np.errstate(divide="ignore", invalid="ignore"):
        eV = np.where(V > 1e-15, np.abs(V - Vhat) / V, 0.0) * 100.0
        eR = np.where(np.abs(R) > 1e-15, np.abs(R - Rhat) / np.abs(R), 0.0) * 100.0

    mean_err = float(np.mean(np.minimum(eV, eR)))
    return {
        "mean": mean_err,
        "vre": float(np.mean(eV)),
        "mre": float(np.mean(eR)),
    }


def pointwise_target_frontier_error(heur_returns: np.ndarray,
                                    heur_variances: np.ndarray,
                                    target_returns: np.ndarray,
                                    ref_returns: np.ndarray,
                                    ref_variances: np.ndarray) -> Dict[str, float]:
    """Pointwise error for the scored three-target K=10 protocol.

    Each feasible constrained point is evaluated at its own achieved return.
    The reference variance is linearly interpolated from the bundled
    unconstrained frontier at that achieved return. This avoids treating the
    three solver points as a full interpolated frontier and avoids positional
    alignment with infeasible target points that were discarded.

    Returns percentages:
      * ``vre``: mean absolute variance error versus the reference variance at
        the achieved return;
      * ``mre``: mean absolute achieved-return deviation from target return;
      * ``mean``: mean of the pointwise average of variance and return errors.
    """
    hr = np.asarray(heur_returns, dtype=float)
    hv = np.asarray(heur_variances, dtype=float)
    tr = np.asarray(target_returns, dtype=float)
    n = min(len(hr), len(hv), len(tr))
    if n == 0:
        return {"mean": float("nan"), "vre": float("nan"), "mre": float("nan")}
    hr, hv, tr = hr[:n], hv[:n], tr[:n]
    valid = np.isfinite(hr) & np.isfinite(hv) & np.isfinite(tr)
    if not valid.any():
        return {"mean": float("nan"), "vre": float("nan"), "mre": float("nan")}
    hr, hv, tr = hr[valid], hv[valid], tr[valid]
    ref_v = interpolate_reference_variance(hr, ref_returns, ref_variances)
    with np.errstate(divide="ignore", invalid="ignore"):
        ev = np.where(ref_v > 1e-15, np.abs(hv - ref_v) / ref_v, 0.0) * 100.0
        er = np.where(np.abs(tr) > 1e-15, np.abs(hr - tr) / np.abs(tr), 0.0) * 100.0
    mean = np.mean((ev + er) / 2.0)
    return {"mean": float(mean), "vre": float(np.mean(ev)), "mre": float(np.mean(er))}


def penalized_target_frontier_error(point_records,
                                    ref_returns: np.ndarray,
                                    ref_variances: np.ndarray,
                                    means: np.ndarray = None,
                                    K: int = 10,
                                    eps: float = 0.01,
                                    require_exact_K: bool = True,
                                    failure_penalty: float = 100.0) -> Dict[str, float]:
    """Pointwise target error with an explicit penalty for infeasible targets.

    When `means` and per-record `best_weights` are supplied, strict feasibility
    is recomputed with check_feasibility before a record is allowed into the
    non-penalized branch. This keeps the public metric primitive aligned with
    the standard scoring entry point instead of trusting only finite return and
    variance fields.
    """
    ev_values = []
    er_values = []
    n_feasible = 0
    for rec in point_records:
        actual = rec.get("actual_return", float("nan"))
        var = rec.get("variance", float("nan"))
        target = rec.get("target_return", float("nan"))
        strict_feasible = np.isfinite(actual) and np.isfinite(var) and np.isfinite(target)
        weights = rec.get("best_weights", None)
        if strict_feasible and means is not None and weights is not None and check_feasibility is not None:
            feasibility = check_feasibility(
                np.asarray(weights, dtype=float),
                K=K,
                eps=eps,
                target_return=float(target),
                means=np.asarray(means, dtype=float),
                require_exact_K=require_exact_K,
            )
            strict_feasible = bool(feasibility.get("feasible", False))
        if not strict_feasible:
            ev_values.append(float(failure_penalty))
            er_values.append(float(failure_penalty))
            continue
        ref_v = interpolate_reference_variance(np.array([actual]), ref_returns, ref_variances)[0]
        ev = abs(var - ref_v) / ref_v * 100.0 if ref_v > 1e-15 else 0.0
        er = abs(actual - target) / abs(target) * 100.0 if abs(target) > 1e-15 else 0.0
        ev_values.append(float(ev))
        er_values.append(float(er))
        n_feasible += 1
    if not ev_values:
        return {"mean": float("nan"), "vre": float("nan"), "mre": float("nan"), "n_points": 0}
    ev_arr = np.asarray(ev_values, dtype=float)
    er_arr = np.asarray(er_values, dtype=float)
    return {
        "mean": float(np.mean((ev_arr + er_arr) / 2.0)),
        "vre": float(np.mean(ev_arr)),
        "mre": float(np.mean(er_arr)),
        "n_points": int(n_feasible),
    }


def frontier_area(returns: np.ndarray, variances: np.ndarray) -> float:
    """Area under the efficient frontier curve (trapezoidal integration).

    Parameters
    ----------
    returns : np.ndarray (sorted descending)
    variances : np.ndarray

    Returns
    -------
    area : float
    """
    # Sort by return ascending for integration
    order = np.argsort(returns)
    r_sorted = returns[order]
    v_sorted = variances[order]
    return float(np.trapz(v_sorted, r_sorted))


def hypervolume_indicator(constrained_returns: np.ndarray,
                          constrained_vars: np.ndarray,
                          ref_point: Tuple[float, float]) -> float:
    """2D hypervolume indicator for bi-objective (maximize return, minimize variance).

    Parameters
    ----------
    constrained_returns : np.ndarray
    constrained_vars : np.ndarray
    ref_point : (float, float)
        Reference point (min_return, max_variance).

    Returns
    -------
    hv : float
    """
    # Non-dominated points only
    n = len(constrained_returns)
    dominated = np.zeros(n, dtype=bool)
    for i in range(n):
        for j in range(n):
            if i != j:
                if (constrained_returns[j] >= constrained_returns[i] and
                    constrained_vars[j] <= constrained_vars[i] and
                    (constrained_returns[j] > constrained_returns[i] or
                     constrained_vars[j] < constrained_vars[i])):
                    dominated[i] = True
                    break

    nd_ret = constrained_returns[~dominated]
    nd_var = constrained_vars[~dominated]

    if len(nd_ret) == 0:
        return 0.0

    # Sort by return descending
    order = np.argsort(nd_ret)[::-1]
    nd_ret = nd_ret[order]
    nd_var = nd_var[order]

    hv = 0.0
    prev_var = ref_point[1]
    for i in range(len(nd_ret)):
        if nd_ret[i] > ref_point[0] and nd_var[i] < prev_var:
            width = nd_ret[i] - ref_point[0] if i == len(nd_ret) - 1 else nd_ret[i] - nd_ret[i + 1]
            # Actually use standard sweep-line
            pass

    # Simpler: sum rectangles
    hv = 0.0
    for i in range(len(nd_ret)):
        height = ref_point[1] - nd_var[i]
        if height <= 0:
            continue
        if i < len(nd_ret) - 1:
            width = nd_ret[i] - nd_ret[i + 1]
        else:
            width = nd_ret[i] - ref_point[0]
        if width > 0:
            hv += width * height

    return hv

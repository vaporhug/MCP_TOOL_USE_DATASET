"""Statistical comparison tools for optimization algorithm benchmarking."""

import numpy as np
from scipy import stats
from typing import Dict, List, Tuple, Optional


def wilcoxon_signed_rank(x: np.ndarray, y: np.ndarray,
                         alternative: str = "two-sided") -> Dict:
    """Wilcoxon signed-rank test comparing two paired samples.

    Parameters
    ----------
    x : np.ndarray
        Performance values for algorithm 1.
    y : np.ndarray
        Performance values for algorithm 2.
    alternative : str
        'two-sided', 'less', or 'greater'.

    Returns
    -------
    dict with 'statistic', 'p_value', 'n_samples'.
    """
    stat, pval = stats.wilcoxon(x, y, alternative=alternative,
                                zero_method="wilcox")
    return {"statistic": float(stat), "p_value": float(pval),
            "n_samples": len(x)}


def win_draw_loss(x: np.ndarray, y: np.ndarray,
                  tol: float = 1e-6) -> Dict[str, int]:
    """Count wins, draws, and losses of x vs y (lower is better).

    Parameters
    ----------
    x : np.ndarray
        Values for algorithm x.
    y : np.ndarray
        Values for algorithm y.
    tol : float
        Tolerance for draws.

    Returns
    -------
    dict with 'wins', 'draws', 'losses'.
    """
    wins = int(np.sum(x < y - tol))
    losses = int(np.sum(x > y + tol))
    draws = len(x) - wins - losses
    return {"wins": wins, "draws": draws, "losses": losses}


def pairwise_comparison_table(results: Dict[str, np.ndarray],
                              metric_name: str = "variance") -> List[Dict]:
    """Build pairwise statistical comparison table for multiple algorithms.

    Parameters
    ----------
    results : dict
        Maps algorithm name to array of metric values.
    metric_name : str

    Returns
    -------
    list of dicts with 'algo1', 'algo2', 'wins', 'draws', 'losses',
    'wilcoxon_p'.
    """
    algos = sorted(results.keys())
    table = []
    for i, a1 in enumerate(algos):
        for j, a2 in enumerate(algos):
            if i >= j:
                continue
            x = results[a1]
            y = results[a2]
            wdl = win_draw_loss(x, y)
            try:
                wp = wilcoxon_signed_rank(x, y)
                p = wp["p_value"]
            except Exception:
                p = np.nan
            table.append({
                "algo1": a1, "algo2": a2,
                "wins": wdl["wins"], "draws": wdl["draws"],
                "losses": wdl["losses"],
                "wilcoxon_p": p,
            })
    return table


def friedman_test(results: Dict[str, np.ndarray]) -> Dict:
    """Friedman test for comparing multiple algorithms across problem instances.

    Parameters
    ----------
    results : dict
        Maps algorithm name to array of metric values (same length).

    Returns
    -------
    dict with 'statistic', 'p_value', 'ranks' (mean ranks per algorithm).
    """
    algos = sorted(results.keys())
    data = np.array([results[a] for a in algos])  # shape (n_algos, n_instances)

    stat, pval = stats.friedmanchisquare(*[data[i] for i in range(len(algos))])

    # Compute mean ranks
    ranks = np.zeros_like(data, dtype=float)
    for j in range(data.shape[1]):
        ranks[:, j] = stats.rankdata(data[:, j])
    mean_ranks = {algos[i]: float(ranks[i].mean()) for i in range(len(algos))}

    return {"statistic": float(stat), "p_value": float(pval),
            "mean_ranks": mean_ranks}


def bootstrap_confidence_interval(values: np.ndarray, statistic_fn=np.mean,
                                  n_bootstrap: int = 10000,
                                  confidence: float = 0.95,
                                  seed: Optional[int] = None) -> Dict:
    """Bootstrap confidence interval for a statistic.

    Parameters
    ----------
    values : np.ndarray
    statistic_fn : callable
    n_bootstrap : int
    confidence : float
    seed : int, optional

    Returns
    -------
    dict with 'estimate', 'ci_lower', 'ci_upper'.
    """
    if seed is not None:
        np.random.seed(seed)

    n = len(values)
    boot_stats = np.zeros(n_bootstrap)
    for i in range(n_bootstrap):
        sample = np.random.choice(values, size=n, replace=True)
        boot_stats[i] = statistic_fn(sample)

    alpha = 1 - confidence
    lo = np.percentile(boot_stats, 100 * alpha / 2)
    hi = np.percentile(boot_stats, 100 * (1 - alpha / 2))

    return {
        "estimate": float(statistic_fn(values)),
        "ci_lower": float(lo),
        "ci_upper": float(hi),
    }

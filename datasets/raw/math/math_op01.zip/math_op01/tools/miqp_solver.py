"""Mixed-Integer Quadratic Programming solver for exact cardinality-constrained optimization.

Uses branch-and-bound via scipy or cvxpy when available. Falls back to
enumeration for small problems.
"""

import numpy as np
from scipy.optimize import minimize
from itertools import combinations
from typing import Dict, Optional


def exact_enumeration(means: np.ndarray, cov: np.ndarray,
                      K: int, target_return: float,
                      eps: float = 0.01,
                      max_combinations: int = 100000) -> Dict:
    """Solve cardinality-constrained portfolio by enumerating all C(n,K) subsets.

    Only feasible for small n and K (e.g., n=31, K=10 -> 44M combos).
    Use max_combinations to limit runtime.

    Parameters
    ----------
    means : np.ndarray, shape (n,)
    cov : np.ndarray, shape (n, n)
    K : int
    target_return : float
    eps : float
        Minimum weight.
    max_combinations : int

    Returns
    -------
    dict with 'weights', 'variance', 'return', 'n_evaluated', 'exact'.
    """
    n = len(means)
    from math import comb
    total = comb(n, K)

    if total > max_combinations:
        return {"weights": np.zeros(n), "variance": float("inf"),
                "return": 0.0, "n_evaluated": 0,
                "exact": False, "message": f"Too many combinations: {total}"}

    best_var = np.inf
    best_w = None
    n_eval = 0

    for combo in combinations(range(n), K):
        selected = np.array(combo)
        sub_cov = cov[np.ix_(selected, selected)]
        sub_means = means[selected]

        # Solve inner QP
        K_actual = len(selected)
        result = minimize(
            lambda wa: wa @ sub_cov @ wa,
            np.ones(K_actual) / K_actual,
            method="SLSQP",
            jac=lambda wa: 2 * sub_cov @ wa,
            constraints=[
                {"type": "eq", "fun": lambda wa: np.sum(wa) - 1},
                {"type": "ineq", "fun": lambda wa: wa @ sub_means - target_return},
            ],
            bounds=[(eps, 1)] * K_actual,
            options={"ftol": 1e-14},
        )

        n_eval += 1
        if result.success and result.fun < best_var:
            full_w = np.zeros(n)
            full_w[selected] = result.x
            if full_w @ means >= target_return - 1e-8:
                best_var = result.fun
                best_w = full_w

    if best_w is None:
        best_w = np.zeros(n)
        best_var = float("inf")

    return {
        "weights": best_w,
        "variance": best_var,
        "return": float(best_w @ means) if best_w is not None else 0.0,
        "n_evaluated": n_eval,
        "exact": True,
    }


def relaxed_lower_bound(means: np.ndarray, cov: np.ndarray,
                        target_return: float) -> float:
    """Compute lower bound on variance via continuous relaxation (no cardinality).

    Parameters
    ----------
    means : np.ndarray
    cov : np.ndarray
    target_return : float

    Returns
    -------
    lb : float
        Lower bound on achievable variance.
    """
    n = len(means)
    result = minimize(
        lambda w: w @ cov @ w,
        np.ones(n) / n,
        method="SLSQP",
        jac=lambda w: 2 * cov @ w,
        constraints=[
            {"type": "eq", "fun": lambda w: np.sum(w) - 1},
            {"type": "ineq", "fun": lambda w: w @ means - target_return},
        ],
        bounds=[(0, 1)] * n,
        options={"ftol": 1e-15},
    )
    return result.fun if result.success else 0.0


def optimality_gap(heuristic_var: float, lower_bound: float) -> float:
    """Compute optimality gap as percentage.

    gap = (heuristic - lb) / lb * 100

    Parameters
    ----------
    heuristic_var : float
    lower_bound : float

    Returns
    -------
    gap_pct : float
    """
    if lower_bound < 1e-15:
        return 0.0
    return (heuristic_var - lower_bound) / lower_bound * 100.0

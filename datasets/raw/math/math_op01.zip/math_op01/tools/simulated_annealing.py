"""Simulated annealing solver for cardinality-constrained portfolio optimization."""

import numpy as np
from typing import Callable, Dict, Optional, Tuple



def _feasibility_repair(sel, means, cov, target_return, eps, n):
    """Repair pass: re-solve the inner QP on the chosen K-asset selection
    with HARD budget + target-return + bound constraints (SLSQP). If the
    repair is feasible, replace the SA/GA penalty-based output with the
    QP-feasible weights; otherwise return the SA/GA output unchanged so
    the caller can see status='infeasible: target return not met'.
    """
    import numpy as np
    from scipy.optimize import minimize
    sub_cov = cov[np.ix_(sel, sel)]
    sub_means = means[sel]
    K_act = len(sel)
    res = minimize(
        lambda wa: wa @ sub_cov @ wa,
        np.ones(K_act) / K_act,
        method="SLSQP",
        constraints=[
            {"type": "eq", "fun": lambda wa: float(np.sum(wa) - 1)},
            {"type": "ineq", "fun": lambda wa: float(wa @ sub_means - target_return)},
        ],
        bounds=[(eps, 1)] * K_act,
        options={"ftol": 1e-14, "maxiter": 5000},
    )
    if not res.success:
        return None
    full_w = np.zeros(n)
    full_w[sel] = res.x
    if abs(np.sum(full_w) - 1.0) > 1e-6: return None
    if (full_w[sel] < eps - 1e-9).any(): return None
    if (full_w @ means) < target_return - 1e-8: return None
    return full_w

def sa_portfolio(means: np.ndarray, cov: np.ndarray,
                 K: int, target_return: float,
                 T_init: float = 1.0, T_min: float = 1e-6,
                 alpha: float = 0.995, max_iter: int = 50000,
                 eps: float = 0.01,
                 seed: Optional[int] = None) -> Dict:
    """Simulated annealing for cardinality-constrained min-variance portfolio.

    Objective: min w'Cw
    Subject to: w'mu >= target_return, sum(w)=1, |support(w)|=K, w_i in [eps,1]

    Parameters
    ----------
    means : np.ndarray, shape (n,)
    cov : np.ndarray, shape (n, n)
    K : int
        Maximum number of assets.
    target_return : float
    T_init : float
        Initial temperature.
    T_min : float
        Minimum temperature.
    alpha : float
        Cooling rate.
    max_iter : int
        Maximum iterations.
    eps : float
        Minimum weight per selected asset.
    seed : int, optional

    Returns
    -------
    dict with 'weights', 'variance', 'return', 'n_iter', 'history'.
    """
    if seed is not None:
        np.random.seed(seed)

    n = len(means)

    # Initialize: pick K assets with highest returns
    sorted_idx = np.argsort(means)[::-1]
    selected = np.sort(sorted_idx[:K])
    w_active = np.ones(K) / K

    def objective(sel, wa):
        full_w = np.zeros(n)
        full_w[sel] = wa
        var = full_w @ cov @ full_w
        ret = full_w @ means
        penalty = max(0, target_return - ret) * 1000
        return var + penalty

    best_sel = selected.copy()
    best_wa = w_active.copy()
    best_obj = objective(best_sel, best_wa)

    curr_sel = selected.copy()
    curr_wa = w_active.copy()
    curr_obj = best_obj

    T = T_init
    history = []
    it = 0

    while T > T_min and it < max_iter:
        # Neighbor: either swap an asset or perturb weights
        if np.random.random() < 0.3:
            # Swap one asset
            new_sel = curr_sel.copy()
            idx_out = np.random.randint(K)
            candidates = np.setdiff1d(np.arange(n), new_sel)
            if len(candidates) > 0:
                idx_in = np.random.choice(candidates)
                new_sel[idx_out] = idx_in
                new_sel = np.sort(new_sel)
            new_wa = curr_wa.copy()
            new_wa = new_wa / np.sum(new_wa)
            new_wa = np.clip(new_wa, eps, 1.0)
            new_wa = new_wa / np.sum(new_wa)
        else:
            # Perturb weights
            new_sel = curr_sel.copy()
            new_wa = curr_wa + np.random.normal(0, 0.05, K)
            new_wa = np.clip(new_wa, eps, 1.0)
            new_wa = new_wa / np.sum(new_wa)

        new_obj = objective(new_sel, new_wa)
        delta = new_obj - curr_obj

        if delta < 0 or np.random.random() < np.exp(-delta / max(T, 1e-15)):
            curr_sel = new_sel
            curr_wa = new_wa
            curr_obj = new_obj

            if curr_obj < best_obj:
                best_sel = curr_sel.copy()
                best_wa = curr_wa.copy()
                best_obj = curr_obj

        T *= alpha
        it += 1
        if it % 1000 == 0:
            history.append({"iter": it, "temperature": T, "best_obj": best_obj})

    full_w = np.zeros(n)
    full_w[best_sel] = best_wa

    # Hard-constraint repair pass
    repaired = _feasibility_repair(best_sel, means, cov, target_return, eps, n)
    if repaired is not None:
        full_w = repaired

    achieved_ret = float(full_w @ means)
    feasible = (target_return is None) or (achieved_ret >= target_return - 1e-8)

    return {
        "weights": full_w,
        "variance": float(full_w @ cov @ full_w),
        "return": achieved_ret,
        "feasible": feasible,
        "status": "feasible" if feasible else "infeasible: target return not met",
        "n_iter": it,
        "history": history,
    }

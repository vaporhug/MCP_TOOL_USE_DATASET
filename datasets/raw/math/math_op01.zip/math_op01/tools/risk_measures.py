"""Risk measures and portfolio analytics."""

import numpy as np
from typing import Dict


def portfolio_variance(weights: np.ndarray, cov: np.ndarray) -> float:
    """Compute portfolio variance: w' C w.

    Parameters
    ----------
    weights : np.ndarray, shape (n,)
    cov : np.ndarray, shape (n, n)

    Returns
    -------
    var : float
    """
    return float(weights @ cov @ weights)


def portfolio_volatility(weights: np.ndarray, cov: np.ndarray) -> float:
    """Compute portfolio volatility (standard deviation).

    Parameters
    ----------
    weights : np.ndarray, shape (n,)
    cov : np.ndarray, shape (n, n)

    Returns
    -------
    vol : float
    """
    return float(np.sqrt(max(weights @ cov @ weights, 0)))


def sharpe_ratio(weights: np.ndarray, means: np.ndarray,
                 cov: np.ndarray, risk_free: float = 0.0) -> float:
    """Compute Sharpe ratio: (mu_p - r_f) / sigma_p.

    Parameters
    ----------
    weights : np.ndarray
    means : np.ndarray
    cov : np.ndarray
    risk_free : float

    Returns
    -------
    sr : float
    """
    ret = float(weights @ means)
    vol = portfolio_volatility(weights, cov)
    if vol < 1e-15:
        return 0.0
    return (ret - risk_free) / vol


def diversification_ratio(weights: np.ndarray, stds: np.ndarray,
                          cov: np.ndarray) -> float:
    """Diversification ratio: weighted average vol / portfolio vol.

    Parameters
    ----------
    weights : np.ndarray
    stds : np.ndarray
    cov : np.ndarray

    Returns
    -------
    dr : float
    """
    weighted_avg_vol = float(np.abs(weights) @ stds)
    port_vol = portfolio_volatility(weights, cov)
    if port_vol < 1e-15:
        return 1.0
    return weighted_avg_vol / port_vol


def concentration_ratio(weights: np.ndarray, top_k: int = 5) -> float:
    """Concentration ratio: fraction of portfolio in top-k holdings.

    Parameters
    ----------
    weights : np.ndarray
    top_k : int

    Returns
    -------
    cr : float
    """
    sorted_abs = np.sort(np.abs(weights))[::-1]
    return float(np.sum(sorted_abs[:top_k]))


def herfindahl_index(weights: np.ndarray) -> float:
    """Herfindahl-Hirschman Index of portfolio concentration.

    HHI = sum(w_i^2). Ranges from 1/n (equal-weight) to 1 (single asset).

    Parameters
    ----------
    weights : np.ndarray

    Returns
    -------
    hhi : float
    """
    return float(np.sum(weights**2))


def effective_number_of_assets(weights: np.ndarray) -> float:
    """Effective number of assets: 1 / HHI.

    Parameters
    ----------
    weights : np.ndarray

    Returns
    -------
    ena : float
    """
    hhi = herfindahl_index(weights)
    if hhi < 1e-15:
        return 0.0
    return 1.0 / hhi


def marginal_risk_contribution(weights: np.ndarray,
                               cov: np.ndarray) -> np.ndarray:
    """Marginal risk contribution of each asset.

    MRC_i = (C @ w)_i / sqrt(w' C w)

    Parameters
    ----------
    weights : np.ndarray
    cov : np.ndarray

    Returns
    -------
    mrc : np.ndarray, shape (n,)
    """
    port_vol = portfolio_volatility(weights, cov)
    if port_vol < 1e-15:
        return np.zeros(len(weights))
    return (cov @ weights) / port_vol

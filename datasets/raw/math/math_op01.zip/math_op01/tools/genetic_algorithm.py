"""Genetic algorithm solver for cardinality-constrained portfolio optimization."""

import numpy as np
from typing import Dict, Optional, List, Tuple



def _feasibility_repair(sel, means, cov, target_return, eps, n):
    """Repair pass: re-solve the inner QP on the chosen K-asset selection
    with HARD budget + target-return + bound constraints (SLSQP). If the
    repair is feasible, replace the SA/GA penalty-based output with the
    QP-feasible weights; otherwise return the SA/GA output unchanged so
    the caller can see status='infeasible: target return not met'.
    """
    import numpy as np
    from scipy.optimize import minimize
    sub_cov = cov[np.ix_(sel, sel)]
    sub_means = means[sel]
    K_act = len(sel)
    res = minimize(
        lambda wa: wa @ sub_cov @ wa,
        np.ones(K_act) / K_act,
        method="SLSQP",
        constraints=[
            {"type": "eq", "fun": lambda wa: float(np.sum(wa) - 1)},
            {"type": "ineq", "fun": lambda wa: float(wa @ sub_means - target_return)},
        ],
        bounds=[(eps, 1)] * K_act,
        options={"ftol": 1e-14, "maxiter": 5000},
    )
    if not res.success:
        return None
    full_w = np.zeros(n)
    full_w[sel] = res.x
    if abs(np.sum(full_w) - 1.0) > 1e-6: return None
    if (full_w[sel] < eps - 1e-9).any(): return None
    if (full_w @ means) < target_return - 1e-8: return None
    return full_w

def _init_population(n: int, K: int, pop_size: int,
                     eps: float) -> List[Tuple[np.ndarray, np.ndarray]]:
    """Create initial population of (selected, weights) pairs."""
    pop = []
    for _ in range(pop_size):
        sel = np.sort(np.random.choice(n, K, replace=False))
        raw = np.random.dirichlet(np.ones(K))
        w = np.clip(raw, eps, 1.0)
        w /= np.sum(w)
        pop.append((sel, w))
    return pop


def _fitness(sel: np.ndarray, wa: np.ndarray, means: np.ndarray,
             cov: np.ndarray, target_return: float, n: int) -> float:
    """Compute fitness (negative objective, higher is better)."""
    full_w = np.zeros(n)
    full_w[sel] = wa
    var = full_w @ cov @ full_w
    ret = full_w @ means
    penalty = max(0, target_return - ret) * 1000
    return -(var + penalty)


def _crossover(parent1: Tuple, parent2: Tuple, n: int, K: int,
               eps: float) -> Tuple[np.ndarray, np.ndarray]:
    """Uniform crossover on asset selection + weight averaging."""
    sel1, w1 = parent1
    sel2, w2 = parent2

    # Combine asset pools
    all_assets = np.union1d(sel1, sel2)
    if len(all_assets) < K:
        remaining = np.setdiff1d(np.arange(n), all_assets)
        extra = np.random.choice(remaining, K - len(all_assets), replace=False)
        all_assets = np.union1d(all_assets, extra)

    # Select K from combined pool
    child_sel = np.sort(np.random.choice(all_assets, K, replace=False))

    # Average weights where both parents share assets
    child_w = np.random.dirichlet(np.ones(K))

    for i, asset in enumerate(child_sel):
        w_sum = 0
        count = 0
        if asset in sel1:
            idx = np.where(sel1 == asset)[0][0]
            w_sum += w1[idx]
            count += 1
        if asset in sel2:
            idx = np.where(sel2 == asset)[0][0]
            w_sum += w2[idx]
            count += 1
        if count > 0:
            child_w[i] = w_sum / count

    child_w = np.clip(child_w, eps, 1.0)
    child_w /= np.sum(child_w)
    return child_sel, child_w


def _mutate(sel: np.ndarray, wa: np.ndarray, n: int, K: int,
            eps: float, mut_rate: float = 0.1) -> Tuple[np.ndarray, np.ndarray]:
    """Mutate by swapping assets and perturbing weights."""
    new_sel = sel.copy()
    new_wa = wa.copy()

    # Asset swap mutation
    if np.random.random() < mut_rate:
        idx_out = np.random.randint(K)
        candidates = np.setdiff1d(np.arange(n), new_sel)
        if len(candidates) > 0:
            new_sel[idx_out] = np.random.choice(candidates)
            new_sel = np.sort(new_sel)

    # Weight perturbation
    if np.random.random() < mut_rate:
        new_wa += np.random.normal(0, 0.05, K)
        new_wa = np.clip(new_wa, eps, 1.0)
        new_wa /= np.sum(new_wa)

    return new_sel, new_wa


def ga_portfolio(means: np.ndarray, cov: np.ndarray,
                 K: int, target_return: float,
                 pop_size: int = 100, n_generations: int = 500,
                 elite_frac: float = 0.1, mut_rate: float = 0.15,
                 eps: float = 0.01,
                 seed: Optional[int] = None) -> Dict:
    """Genetic algorithm for cardinality-constrained min-variance portfolio.

    Parameters
    ----------
    means : np.ndarray, shape (n,)
    cov : np.ndarray, shape (n, n)
    K : int
        Cardinality constraint.
    target_return : float
    pop_size : int
    n_generations : int
    elite_frac : float
    mut_rate : float
    eps : float
        Minimum weight per selected asset.
    seed : int, optional

    Returns
    -------
    dict with 'weights', 'variance', 'return', 'generation_history'.
    """
    if seed is not None:
        np.random.seed(seed)

    n = len(means)
    n_elite = max(1, int(pop_size * elite_frac))

    pop = _init_population(n, K, pop_size, eps)
    history = []

    for gen in range(n_generations):
        # Evaluate fitness
        fits = [_fitness(s, w, means, cov, target_return, n)
                for s, w in pop]

        # Sort by fitness (descending)
        ranked = sorted(zip(fits, pop), key=lambda x: x[0], reverse=True)

        best_fit = ranked[0][0]
        best_ind = ranked[0][1]

        if gen % 50 == 0:
            full_w = np.zeros(n)
            full_w[best_ind[0]] = best_ind[1]
            history.append({
                "generation": gen,
                "best_variance": float(full_w @ cov @ full_w),
                "best_return": float(full_w @ means),
            })

        # Selection: keep elites + tournament
        new_pop = [ind for _, ind in ranked[:n_elite]]

        while len(new_pop) < pop_size:
            # Tournament selection
            i1, i2 = np.random.randint(len(ranked), size=2)
            p1 = ranked[max(i1, i2)][1] if fits[i1] > fits[i2] else ranked[min(i1, i2)][1]
            i1, i2 = np.random.randint(len(ranked), size=2)
            p2 = ranked[max(i1, i2)][1] if fits[i1] > fits[i2] else ranked[min(i1, i2)][1]

            child_sel, child_w = _crossover(p1, p2, n, K, eps)
            child_sel, child_w = _mutate(child_sel, child_w, n, K, eps, mut_rate)
            new_pop.append((child_sel, child_w))

        pop = new_pop

    # Final best
    fits = [_fitness(s, w, means, cov, target_return, n) for s, w in pop]
    best_idx = np.argmax(fits)
    best_sel, best_wa = pop[best_idx]
    full_w = np.zeros(n)
    full_w[best_sel] = best_wa

    # Hard-constraint repair pass
    repaired = _feasibility_repair(best_sel, means, cov, target_return, eps, n)
    if repaired is not None:
        full_w = repaired

    achieved_ret = float(full_w @ means)
    feasible = (target_return is None) or (achieved_ret >= target_return - 1e-8)

    return {
        "weights": full_w,
        "variance": float(full_w @ cov @ full_w),
        "return": achieved_ret,
        "feasible": feasible,
        "status": "feasible" if feasible else "infeasible: target return not met",
        "generation_history": history,
    }

"""Lambda-sweep formulation for tracing efficient frontiers.

The bi-criteria portfolio problem can be parameterized as:
  min lambda * w'Cw - (1-lambda) * w'mu
  s.t. sum(w) = 1, w >= 0, |support(w)| <= K

Sweeping lambda from 0 to 1 traces the efficient frontier from max-return
to min-variance.
"""

import numpy as np
from scipy.optimize import minimize
from typing import Dict, Optional, Tuple, List


def solve_lambda_qp(cov: np.ndarray, means: np.ndarray,
                    lam: float,
                    n_restarts: int = 3) -> Dict:
    """Solve the lambda-parameterized QP (no cardinality constraint).

    min lambda * w'Cw - (1-lambda) * w'mu
    s.t. sum(w) = 1, w >= 0

    Parameters
    ----------
    cov : np.ndarray, shape (n, n)
    means : np.ndarray, shape (n,)
    lam : float in [0, 1]
    n_restarts : int

    Returns
    -------
    dict with 'weights', 'variance', 'return', 'objective'.
    """
    n = len(means)
    best_obj = np.inf
    best_w = None

    for trial in range(n_restarts):
        w0 = np.random.dirichlet(np.ones(n)) if trial > 0 else np.ones(n) / n

        def obj(w):
            return lam * (w @ cov @ w) - (1 - lam) * (w @ means)

        def jac(w):
            return 2 * lam * (cov @ w) - (1 - lam) * means

        result = minimize(obj, w0, method="SLSQP", jac=jac,
                          constraints=[{"type": "eq", "fun": lambda w: np.sum(w) - 1}],
                          bounds=[(0, 1)] * n,
                          options={"ftol": 1e-15, "maxiter": 5000})

        if result.success and result.fun < best_obj:
            best_obj = result.fun
            best_w = result.x.copy()

    if best_w is None:
        best_w = np.ones(n) / n

    return {
        "weights": best_w,
        "variance": float(best_w @ cov @ best_w),
        "return": float(best_w @ means),
        "objective": float(best_obj),
    }


def sweep_lambda(cov: np.ndarray, means: np.ndarray,
                 n_points: int = 200) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Sweep lambda from 0 to 1 to trace the unconstrained efficient frontier.

    Parameters
    ----------
    cov : np.ndarray
    means : np.ndarray
    n_points : int

    Returns
    -------
    lambdas : np.ndarray, shape (n_points,)
    returns : np.ndarray, shape (n_points,)
    variances : np.ndarray, shape (n_points,)
    """
    lambdas = np.linspace(0, 1, n_points)
    returns = np.zeros(n_points)
    variances = np.zeros(n_points)

    for i, lam in enumerate(lambdas):
        sol = solve_lambda_qp(cov, means, lam)
        returns[i] = sol["return"]
        variances[i] = sol["variance"]

    return lambdas, returns, variances


def solve_lambda_cardinality(cov: np.ndarray, means: np.ndarray,
                             lam: float, K: int,
                             selected: np.ndarray,
                             eps: float = 0.01) -> Dict:
    """Solve lambda-QP for fixed asset selection (inner QP of cardinality problem).

    Parameters
    ----------
    cov : np.ndarray, shape (n, n)
    means : np.ndarray, shape (n,)
    lam : float
    K : int
    selected : np.ndarray of int
        Indices of selected assets.
    eps : float
        Minimum weight.

    Returns
    -------
    dict with 'weights' (full n-vector), 'variance', 'return', 'objective'.
    """
    n = len(means)
    K_actual = len(selected)
    sub_cov = cov[np.ix_(selected, selected)]
    sub_means = means[selected]

    def obj(wa):
        return lam * (wa @ sub_cov @ wa) - (1 - lam) * (wa @ sub_means)

    def jac(wa):
        return 2 * lam * (sub_cov @ wa) - (1 - lam) * sub_means

    result = minimize(obj, np.ones(K_actual) / K_actual,
                      method="SLSQP", jac=jac,
                      constraints=[{"type": "eq", "fun": lambda w: np.sum(w) - 1}],
                      bounds=[(eps, 1)] * K_actual,
                      options={"ftol": 1e-15})

    full_w = np.zeros(n)
    if result.success:
        full_w[selected] = result.x
    else:
        full_w[selected] = np.ones(K_actual) / K_actual

    return {
        "weights": full_w,
        "variance": float(full_w @ cov @ full_w),
        "return": float(full_w @ means),
        "objective": float(result.fun) if result.success else float("inf"),
    }

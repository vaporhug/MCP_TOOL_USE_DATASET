"""Sensitivity analysis for cardinality constraint impact."""

import numpy as np
from typing import Dict, List, Callable, Optional

try:
    from .cardinality_constraint import check_feasibility
except ImportError:
    from cardinality_constraint import check_feasibility


def cardinality_sensitivity(solver_fn: Callable,
                            means: np.ndarray, cov: np.ndarray,
                            K_values: List[int],
                            target_return: float,
                            solver_kwargs: Optional[Dict] = None) -> Dict:
    """Evaluate how portfolio quality changes with cardinality K.

    Parameters
    ----------
    solver_fn : callable
    means, cov : arrays
    K_values : list of int
    target_return : float
    solver_kwargs : dict, optional

    Returns
    -------
    dict with 'K_values', 'variances', 'returns', 'n_assets_used'.
    """
    if solver_kwargs is None:
        solver_kwargs = {}

    variances = []
    returns = []
    n_used = []
    kept_K = []
    dropped_K = []

    for K in K_values:
        result = solver_fn(means, cov, K, target_return, **solver_kwargs)
        feasibility = check_feasibility(
            result["weights"],
            K=K,
            eps=solver_kwargs.get("eps", 0.01),
            target_return=target_return,
            means=means,
            require_exact_K=True,
        )
        if result.get("feasible") is False or not feasibility["feasible"]:
            dropped_K.append({"K": K, "violations": feasibility["violations"]})
            continue
        variances.append(result["variance"])
        returns.append(result["return"])
        active = int(np.sum(np.abs(result["weights"]) > 1e-8))
        n_used.append(active)
        kept_K.append(K)

    return {
        "K_values": kept_K,
        "variances": variances,
        "returns": returns,
        "n_assets_used": n_used,
        "dropped_infeasible": dropped_K,
    }


def return_sensitivity(solver_fn: Callable,
                       means: np.ndarray, cov: np.ndarray,
                       K: int,
                       return_fractions: np.ndarray,
                       solver_kwargs: Optional[Dict] = None) -> Dict:
    """Evaluate portfolio quality at different return targets.

    Parameters
    ----------
    solver_fn : callable
    means, cov : arrays
    K : int
    return_fractions : np.ndarray
        Fractions of the max return to target (e.g., [0.3, 0.5, 0.7, 0.9]).
    solver_kwargs : dict, optional

    Returns
    -------
    dict with 'target_returns', 'achieved_returns', 'variances'.
    """
    if solver_kwargs is None:
        solver_kwargs = {}

    r_max = np.max(means)
    r_min = np.min(means)

    targets = r_min + return_fractions * (r_max - r_min)
    achieved = []
    variances = []

    for t in targets:
        result = solver_fn(means, cov, K, t, **solver_kwargs)
        achieved.append(result["return"])
        variances.append(result["variance"])

    return {
        "target_returns": targets.tolist(),
        "achieved_returns": achieved,
        "variances": variances,
    }


def weight_bound_sensitivity(solver_fn: Callable,
                             means: np.ndarray, cov: np.ndarray,
                             K: int, target_return: float,
                             eps_values: List[float],
                             solver_kwargs: Optional[Dict] = None) -> Dict:
    """Evaluate how minimum weight bound affects portfolio quality.

    Parameters
    ----------
    solver_fn : callable
    means, cov : arrays
    K : int
    target_return : float
    eps_values : list of float
        Different minimum weight bounds to test.
    solver_kwargs : dict, optional

    Returns
    -------
    dict with 'eps_values', 'variances', 'hhi_values'.
    """
    if solver_kwargs is None:
        solver_kwargs = {}

    variances = []
    hhi_values = []

    for eps in eps_values:
        kw = dict(solver_kwargs)
        kw["eps"] = eps
        result = solver_fn(means, cov, K, target_return, **kw)
        variances.append(result["variance"])
        w = result["weights"]
        hhi = float(np.sum(w[w > 1e-8]**2))
        hhi_values.append(hhi)

    return {
        "eps_values": eps_values,
        "variances": variances,
        "hhi_values": hhi_values,
    }

"""
Plotting helpers for survival analysis. Each public function returns
``{"path": "..."}`` after writing a PNG to disk.
"""

from __future__ import annotations

import os
from typing import Dict, Iterable, Optional, Sequence

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from .survival_analysis import (
    kaplan_meier_estimator,
    breslow_baseline_hazard,
    time_dependent_auc,
    calibration_by_decile,
)


def _ensure_dir(path: str) -> None:
    parent = os.path.dirname(os.path.abspath(path))
    if parent:
        os.makedirs(parent, exist_ok=True)


def plot_kaplan_meier_groups(time, event, group, output_path: str,
                              title: str = "",
                              xlabel: str = "Time (months)",
                              ylabel: str = "Survival probability",
                              palette: Optional[Sequence[str]] = None,
                              max_time: Optional[float] = None
                              ) -> Dict[str, str]:
    """Stratified Kaplan-Meier curves for a group factor.

    Parameters
    ----------
    time, event, group : array-likes
    output_path : str
        Destination PNG path.
    title : str, optional
    xlabel, ylabel : str, optional
    palette : list of colour codes, optional

    Returns
    -------
    dict
        ``{"path": output_path}``.
    """
    _ensure_dir(output_path)
    t = np.asarray(time, dtype=float); e = np.asarray(event, dtype=int)
    g = np.asarray(group)
    levels = list(np.unique(g))
    if palette is None:
        palette = ["#1f77b4", "#d62728", "#2ca02c", "#9467bd", "#ff7f0e", "#8c564b"]
    fig, ax = plt.subplots(figsize=(7.5, 5.0))
    for i, lvl in enumerate(levels):
        mask = (g == lvl)
        km = kaplan_meier_estimator(t[mask], e[mask])
        if not km["time"]:
            continue
        x = [0.0] + list(km["time"])
        y = [1.0] + list(km["surv"])
        ax.step(x, y, where="post", color=palette[i % len(palette)],
                label=f"{lvl} (N={int(mask.sum())}, ev={int(e[mask].sum())})", linewidth=2)
        # Censoring marks
        cens = (mask) & (e == 0)
        for tc in t[cens]:
            # find S at tc
            j = 0
            s_at = 1.0
            for tt, ss in zip(km["time"], km["surv"]):
                if tt <= tc:
                    s_at = ss
                else:
                    break
            ax.plot([tc], [s_at], marker="|", color=palette[i % len(palette)],
                    markersize=7, alpha=0.5)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_ylim(0, 1.02)
    if max_time is not None:
        ax.set_xlim(0, max_time)
    ax.set_title(title)
    ax.grid(True, alpha=0.3)
    ax.legend(loc="lower left", fontsize=9)
    fig.tight_layout()
    fig.savefig(output_path, dpi=130)
    plt.close(fig)
    return {"path": output_path}


def plot_baseline_cumulative_hazard(X, time, event, beta,
                                    output_path: str,
                                    title: str = "Breslow baseline cumulative hazard"
                                    ) -> Dict[str, str]:
    """Plot the Breslow baseline cumulative hazard as a step function."""
    _ensure_dir(output_path)
    bh = breslow_baseline_hazard(X, time, event, beta)
    fig, ax = plt.subplots(figsize=(7.5, 4.5))
    ax.step([0] + list(bh["time"]), [0] + list(bh["H0"]),
            where="post", color="#1f77b4", linewidth=1.8)
    ax.set_xlabel("Time (months)")
    ax.set_ylabel("Cumulative hazard $H_0(t)$")
    ax.set_title(title)
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(output_path, dpi=130)
    plt.close(fig)
    return {"path": output_path}


def plot_time_dependent_auc(time, event, risk_score, eval_times,
                            output_path: str,
                            title: str = "Time-dependent ROC AUC"
                            ) -> Dict[str, str]:
    """Plot AUC(t) at the requested evaluation times."""
    _ensure_dir(output_path)
    res = time_dependent_auc(time, event, risk_score, eval_times)
    fig, ax = plt.subplots(figsize=(7.5, 4.5))
    ax.plot(res["time"], res["auc"], "-o", color="#d62728", linewidth=2)
    ax.axhline(0.5, color="grey", linestyle="--", alpha=0.7)
    ax.set_xlabel("Time horizon (months)")
    ax.set_ylabel("AUC")
    ax.set_ylim(0.4, 1.0)
    ax.set_title(title)
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(output_path, dpi=130)
    plt.close(fig)
    return {"path": output_path}


def plot_time_dependent_auc_overlay(time, event,
                                    risk_scores: Dict[str, "object"],
                                    eval_times,
                                    output_path: str,
                                    title: str = "Time-dependent AUC: model comparison"
                                    ) -> Dict[str, "object"]:
    """Overlay AUC(t) curves for two or more models on one axis.

    Use this to draw the Fig4 'clinical-only vs clinical+TP53' AUC
    comparison required by the task answer.

    Args:
        time, event: survival outcome arrays.
        risk_scores: dict mapping model label (str) -> risk-score array,
            e.g. {'clinical-only': r1, 'clinical+TP53': r2}.
        eval_times: iterable of time horizons (months).
        output_path: PNG path.

    Returns dict with 'path' and 'auc_by_model' (label -> list of AUCs).
    """
    _ensure_dir(output_path)
    palette = ["#1f77b4", "#d62728", "#2ca02c", "#9467bd",
               "#ff7f0e", "#8c564b"]
    auc_by_model: Dict[str, list] = {}
    fig, ax = plt.subplots(figsize=(7.5, 4.5))
    for i, (label, risk) in enumerate(risk_scores.items()):
        res = time_dependent_auc(time, event, risk, eval_times)
        ax.plot(res["time"], res["auc"], "-o", color=palette[i % len(palette)],
                linewidth=2, label=label)
        auc_by_model[label] = list(map(float, res["auc"]))
    ax.axhline(0.5, color="grey", linestyle="--", alpha=0.7)
    ax.set_xlabel("Time horizon (months)")
    ax.set_ylabel("AUC")
    ax.set_ylim(0.4, 1.0)
    ax.set_title(title)
    ax.legend(loc="best")
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(output_path, dpi=130)
    plt.close(fig)
    return {"path": output_path, "auc_by_model": auc_by_model}


def plot_calibration(time, event, predicted_surv, t_target: float,
                     output_path: str,
                     title: str = "Calibration of predicted vs observed survival"
                     ) -> Dict[str, str]:
    """Decile-style calibration of model-predicted vs KM-observed
    survival at the chosen horizon."""
    _ensure_dir(output_path)
    df = calibration_by_decile(time, event, predicted_surv, t_target)
    fig, ax = plt.subplots(figsize=(6, 6))
    ax.errorbar(df["mean_pred_surv"], df["obs_km_surv"],
                yerr=1.96 * df["obs_se"], fmt="o", color="#1f77b4",
                markersize=6, capsize=3)
    ax.plot([0, 1], [0, 1], "--", color="grey", alpha=0.7)
    ax.set_xlabel(f"Predicted survival at t={t_target:g}")
    ax.set_ylabel(f"Observed (KM) survival at t={t_target:g}")
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.set_aspect("equal")
    ax.set_title(title)
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(output_path, dpi=130)
    plt.close(fig)
    return {"path": output_path}


def plot_forest(summary_df: pd.DataFrame, output_path: str,
                hr_col: str = "HR",
                lower_col: str = "HR_lower",
                upper_col: str = "HR_upper",
                label_col: str = "covariate",
                title: str = "Forest plot",
                vline_x: float = 1.0,
                xlim: Optional[tuple] = (0.1, 10.0)) -> Dict[str, str]:
    """Forest plot of HR with 95% CI from a Cox summary table.

    Parameters
    ----------
    summary_df : DataFrame with the named columns.
    """
    _ensure_dir(output_path)
    df = summary_df.reset_index(drop=True)
    n = len(df)
    fig, ax = plt.subplots(figsize=(7, 0.45 * max(n, 4) + 1.0))
    y = np.arange(n)[::-1]
    ax.errorbar(df[hr_col], y,
                xerr=[df[hr_col] - df[lower_col], df[upper_col] - df[hr_col]],
                fmt="s", color="#1f77b4", markersize=7, capsize=3, linewidth=1.4)
    ax.axvline(vline_x, color="grey", linestyle="--", alpha=0.7)
    ax.set_yticks(y)
    ax.set_yticklabels(df[label_col].astype(str).tolist(), fontsize=10)
    ax.set_xscale("log")
    if xlim is not None:
        ax.set_xlim(*xlim)
    ax.set_xlabel("Hazard ratio (95% CI)")
    ax.set_title(title)
    ax.grid(True, axis="x", alpha=0.3, which="both")
    fig.tight_layout()
    fig.savefig(output_path, dpi=130)
    plt.close(fig)
    return {"path": output_path}


def plot_schoenfeld(schoenfeld: dict, covariate_names: Sequence[str],
                    output_path: str,
                    title: str = "Schoenfeld residuals over time"
                    ) -> Dict[str, str]:
    """Scatter Schoenfeld residuals vs time per covariate, with a
    LOWESS-like rolling-mean overlay."""
    _ensure_dir(output_path)
    t = np.asarray(schoenfeld["time"], dtype=float)
    R = np.asarray(schoenfeld["resid"], dtype=float)
    p = R.shape[1] if R.ndim > 1 else 1
    if R.ndim == 1:
        R = R[:, None]
    cols = min(p, 3)
    rows = (p + cols - 1) // cols
    fig, axes = plt.subplots(rows, cols, figsize=(4.0 * cols, 3.0 * rows),
                             squeeze=False)
    order = np.argsort(t)
    t_s = t[order]; R_s = R[order]
    window = max(5, len(t_s) // 20)
    for j in range(p):
        ax = axes[j // cols][j % cols]
        ax.scatter(t_s, R_s[:, j], s=8, alpha=0.4, color="#1f77b4")
        # Rolling mean
        if len(t_s) > window:
            roll = pd.Series(R_s[:, j]).rolling(window, center=True, min_periods=1).mean()
            ax.plot(t_s, roll, color="#d62728", linewidth=1.6)
        ax.axhline(0.0, color="grey", linestyle="--", alpha=0.7)
        ax.set_title(covariate_names[j], fontsize=11)
        ax.set_xlabel("Time (months)")
        ax.set_ylabel("Residual")
        ax.grid(True, alpha=0.3)
    for j in range(p, rows * cols):
        axes[j // cols][j % cols].axis("off")
    fig.suptitle(title)
    fig.tight_layout()
    fig.savefig(output_path, dpi=130)
    plt.close(fig)
    return {"path": output_path}

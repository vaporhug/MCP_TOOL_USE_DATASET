"""
Stub helpers for external-database retrieval. The current task ships
the cohort and somatic-mutation table inside ``input_data/data/``, so
no live database call is needed; these stubs document the source for
reproducibility.
"""

from __future__ import annotations


def cbioportal_study_url(study_id: str = "brca_metabric") -> str:
    """Return the cBioPortal datahub raw-text URL pattern for a study.

    Example
    -------
    >>> cbioportal_study_url("brca_metabric")
    'https://media.githubusercontent.com/media/cBioPortal/datahub/master/public/brca_metabric/'
    """
    return ("https://media.githubusercontent.com/media/cBioPortal/datahub/"
            f"master/public/{study_id}/")


def cbioportal_clinical_files() -> list:
    """Names of the clinical files distributed for a cBioPortal study."""
    return ["data_clinical_patient.txt", "data_clinical_sample.txt"]

#!/usr/bin/env python3
"""verify_bundle.py — confirm math_su01 zip contents match task_content.json.

Checks:
  - both required input CSVs exist with expected row counts
  - all 7 bundled artifacts exist (5 PNG + 1 CSV + 1 TXT)
  - every input_data path declared in task_content.json is physically present
  - artifacts/ contains no agent_-prefixed files (agent writes those at solve time)

Usage:
    python tools/verify_bundle.py <bundle_root_or_zip>
Exit code 0 = all checks pass.
"""

from __future__ import annotations

import csv
import json
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path

EXPECTED_INPUT_CSVS = {
    "input_data/data/metabric_clinical.csv": {
        "rows": 1980,
        "header_prefix": ["PATIENT_ID", "AGE_AT_DIAGNOSIS"],
    },
    "input_data/data/metabric_mut_drivers.csv": {
        "rows": 5128,
        "header_prefix": ["PATIENT_ID", "GENE"],
    },
}
EXPECTED_ARTIFACTS = [
    "artifacts/Fig1_km_by_er.png",
    "artifacts/Fig2_km_tp53_erpos.png",
    "artifacts/Fig3_forest_erpos_genes.csv",
    "artifacts/Fig3_forest_erpos_genes.png",
    "artifacts/Fig4_time_dependent_auc.png",
    "artifacts/Fig5_schoenfeld_residuals.png",
    "artifacts/numeric_results.txt",
]


def _check_csv(path: Path, expected_rows: int, header_prefix: list[str]) -> list[str]:
    errs: list[str] = []
    if not path.is_file():
        return [f"MISSING file: {path}"]
    with open(path, newline="") as f:
        rdr = csv.reader(f)
        header = next(rdr)
        if header[: len(header_prefix)] != header_prefix:
            errs.append(f"{path}: header[:{len(header_prefix)}] = "
                        f"{header[:len(header_prefix)]} != {header_prefix}")
        n = sum(1 for _ in rdr)
        if n != expected_rows:
            errs.append(f"{path}: {n} data rows != expected {expected_rows}")
    return errs


def main(root_or_zip: str) -> int:
    p = Path(root_or_zip)
    cleanup_dir: Path | None = None
    if p.suffix == ".zip" and p.is_file():
        extract = Path(tempfile.mkdtemp(prefix="math_su01_verify_"))
        cleanup_dir = extract
        with zipfile.ZipFile(p) as zf:
            zf.extractall(extract)
        root = extract
    else:
        root = p

    errs: list[str] = []

    for rel, spec in EXPECTED_INPUT_CSVS.items():
        errs += _check_csv(root / rel, spec["rows"], spec["header_prefix"])

    for rel in EXPECTED_ARTIFACTS:
        if not (root / rel).is_file():
            errs.append(f"MISSING artifact: {rel}")

    tc = root / "task_content" / "task_content.json"
    if tc.is_file():
        j = json.load(open(tc))
        for item in j.get("input_data", []):
            if not (root / item["path"]).is_file():
                errs.append(f"task_content declares missing input: {item['path']}")
    else:
        errs.append("MISSING task_content/task_content.json")

    art = root / "artifacts"
    if art.is_dir():
        for f in art.iterdir():
            if f.name.startswith("agent_"):
                errs.append(f"agent_-prefixed file should not be bundled: {f.name}")

    if cleanup_dir is not None:
        shutil.rmtree(cleanup_dir, ignore_errors=True)
    if errs:
        print("verify_bundle: FAIL")
        for e in errs:
            print(" -", e)
        return 1
    print("verify_bundle: OK — 2 input CSVs (clinical 1,980 rows + mut_drivers "
          "5,128 rows), 7 bundled artifacts, all input_data declarations "
          "resolved; no agent_-prefixed leakage in artifacts/.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1] if len(sys.argv) > 1 else "."))

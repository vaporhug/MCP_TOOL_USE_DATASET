"""
Domain primitives for right-censored survival analysis: Kaplan-Meier
estimator, log-rank test, Cox proportional-hazards MLE via Newton-Raphson
with Efron tie correction, Breslow baseline cumulative hazard, individual
survival prediction, Harrell concordance index, time-dependent ROC AUC,
Schoenfeld residuals + global PH test, and a baseline random survival
forest discrimination metric.

All routines work directly on numpy arrays. They are self-contained — no
external survival package (scipy / lifelines / scikit-survival) is used.
"""

from __future__ import annotations

from typing import Optional, Sequence
import math

import numpy as np
import pandas as pd


# ---------------------------------------------------------------------------
# Kaplan-Meier
# ---------------------------------------------------------------------------


def kaplan_meier_estimator(time, event):
    """Kaplan-Meier survival function estimator.

    Parameters
    ----------
    time : array-like of float
        Right-censored follow-up times, all >= 0.
    event : array-like of {0, 1}
        Event indicator, 1 for the event of interest, 0 for censored.

    Returns
    -------
    dict
        Keys ``time`` (sorted unique event times),
        ``n_at_risk`` (number at risk just before each event time),
        ``n_events`` (events at each time),
        ``surv`` (KM survival estimate at each unique time),
        ``surv_var`` (Greenwood variance of the survival estimate).
    """
    t = np.asarray(time, dtype=float)
    e = np.asarray(event, dtype=int)
    if t.shape[0] != e.shape[0]:
        raise ValueError("time and event must have the same length")
    if (t < 0).any():
        raise ValueError("times must be non-negative")
    order = np.argsort(t, kind="mergesort")
    t_sorted = t[order]
    e_sorted = e[order]
    unique_times = np.unique(t_sorted[e_sorted == 1])
    n_total = len(t_sorted)
    surv = []
    surv_var = []
    n_at_risk_list = []
    n_events_list = []
    s = 1.0
    var_sum = 0.0
    for ut in unique_times:
        n_risk = int((t_sorted >= ut).sum())
        d = int(((t_sorted == ut) & (e_sorted == 1)).sum())
        if n_risk == 0:
            break
        s *= (1.0 - d / n_risk)
        if (n_risk - d) > 0:
            var_sum += d / (n_risk * (n_risk - d))
        surv.append(s)
        surv_var.append((s ** 2) * var_sum)
        n_at_risk_list.append(n_risk)
        n_events_list.append(d)
    return {
        "time": unique_times.tolist(),
        "n_at_risk": n_at_risk_list,
        "n_events": n_events_list,
        "surv": surv,
        "surv_var": surv_var,
    }


def kaplan_meier_quantile(km_result: dict, q: float = 0.5) -> Optional[float]:
    """Smallest time at which the KM survival drops at or below 1 - q.

    Parameters
    ----------
    km_result : dict
        Output of :func:`kaplan_meier_estimator`.
    q : float
        Probability quantile in (0, 1); 0.5 returns the median survival.

    Returns
    -------
    float or None
        The time at the requested quantile or ``None`` if the curve never
        drops that low.
    """
    target = 1.0 - q
    for tt, ss in zip(km_result["time"], km_result["surv"]):
        if ss <= target:
            return float(tt)
    return None


# ---------------------------------------------------------------------------
# Log-rank test
# ---------------------------------------------------------------------------


def logrank_test(time, event, group):
    """Two- or k-sample log-rank test for equality of survival curves.

    Parameters
    ----------
    time : array-like
    event : array-like of {0, 1}
    group : array-like of group labels (any hashable)

    Returns
    -------
    dict
        ``chisq`` test statistic, ``df`` degrees of freedom (k-1),
        ``p_value`` upper-tail chi-squared p-value computed from a
        regularised lower incomplete gamma series (no scipy required).
    """
    t = np.asarray(time, dtype=float)
    e = np.asarray(event, dtype=int)
    g = np.asarray(group)
    levels = list(np.unique(g))
    k = len(levels)
    if k < 2:
        raise ValueError("logrank_test requires at least 2 groups")
    n = len(t)
    order = np.argsort(t, kind="mergesort")
    t = t[order]; e = e[order]; g = g[order]
    unique_event_times = np.unique(t[e == 1])

    O = np.zeros(k)
    E = np.zeros(k)
    V = np.zeros((k, k))
    for ut in unique_event_times:
        at_risk_mask = t >= ut
        n_risk = int(at_risk_mask.sum())
        d = int(((t == ut) & (e == 1)).sum())
        if n_risk <= 1 or d == 0:
            continue
        nj = np.array([int((g[at_risk_mask] == lvl).sum()) for lvl in levels], dtype=float)
        dj = np.array([int(((t == ut) & (e == 1) & (g == lvl)).sum()) for lvl in levels], dtype=float)
        O += dj
        ej = nj * d / n_risk
        E += ej
        # variance/cov matrix at this time
        if d < n_risk:
            scale = d * (n_risk - d) / (n_risk - 1)
            for i in range(k):
                for j in range(k):
                    if i == j:
                        V[i, i] += scale * (nj[i] / n_risk) * (1 - nj[i] / n_risk)
                    else:
                        V[i, j] -= scale * (nj[i] / n_risk) * (nj[j] / n_risk)
    # Drop one group to make V invertible
    diff = (O - E)[:-1]
    V_red = V[:-1, :-1]
    try:
        chisq = float(diff @ np.linalg.pinv(V_red) @ diff)
    except np.linalg.LinAlgError:
        chisq = float("nan")
    df = k - 1
    p_value = _chi2_sf(chisq, df)
    return {"chisq": chisq, "df": df, "p_value": p_value,
            "observed": O.tolist(), "expected": E.tolist(),
            "groups": [str(x) for x in levels]}


def _chi2_sf(x: float, df: int) -> float:
    """Upper-tail survival of chi-squared distribution computed via
    a series for the regularised lower incomplete gamma."""
    if not math.isfinite(x) or x <= 0:
        return 1.0
    a = df / 2.0
    z = x / 2.0
    # Use series for P(a, z) when z < a + 1, else continued fraction Q(a, z)
    if z < a + 1:
        # series
        ap = a
        sum_ = 1.0 / a
        delta = sum_
        for _ in range(2000):
            ap += 1
            delta *= z / ap
            sum_ += delta
            if abs(delta) < abs(sum_) * 1e-12:
                break
        gln = math.lgamma(a)
        P = sum_ * math.exp(-z + a * math.log(z) - gln)
        return float(1.0 - P)
    else:
        # Lentz's algorithm for continued fraction of Q(a, z)
        b = z + 1 - a
        c = 1.0 / 1e-300
        d = 1.0 / b
        h = d
        for i in range(1, 2000):
            an = -i * (i - a)
            b += 2
            d = an * d + b
            if abs(d) < 1e-300:
                d = 1e-300
            c = b + an / c
            if abs(c) < 1e-300:
                c = 1e-300
            d = 1.0 / d
            delta = d * c
            h *= delta
            if abs(delta - 1) < 1e-12:
                break
        gln = math.lgamma(a)
        Q = math.exp(-z + a * math.log(z) - gln) * h
        return float(Q)


# ---------------------------------------------------------------------------
# Cox PH model — Newton-Raphson MLE with Efron tie correction
# ---------------------------------------------------------------------------


def fit_cox_ph(X, time, event, max_iter: int = 50, tol: float = 1e-7,
               step_halving: int = 10):
    """Cox proportional hazards model fit by Newton-Raphson on the
    Efron-tie partial-likelihood.

    Parameters
    ----------
    X : array-like, shape (n, p)
        Numeric covariate matrix.
    time : array-like, shape (n,)
    event : array-like of {0, 1}, shape (n,)
    max_iter : int
    tol : float
    step_halving : int
        Maximum step-halving attempts when a Newton update worsens the
        log-likelihood.

    Returns
    -------
    dict
        Keys: ``coef`` (length-p numpy array of log-hazard ratios),
        ``se`` (asymptotic standard errors from the inverse Fisher
        information), ``hr`` (exp(coef)), ``hr_lower`` and ``hr_upper``
        (95% CIs), ``z`` (Wald z), ``p`` (two-sided Wald p-values),
        ``loglik`` (final partial log-likelihood),
        ``loglik_null`` (log-likelihood at beta = 0),
        ``n_iter``, ``converged``.
    """
    X = np.asarray(X, dtype=float)
    t = np.asarray(time, dtype=float)
    e = np.asarray(event, dtype=int)
    if X.ndim == 1:
        X = X[:, None]
    n, p = X.shape
    # Sort by ascending time so a subject's risk set is the suffix [i:].
    order = np.argsort(t, kind="mergesort")
    Xo = X[order]; to = t[order]; eo = e[order]
    beta = np.zeros(p)

    def _ll_grad_hess(beta):
        eta = Xo @ beta
        w = np.exp(eta)
        ll = 0.0
        grad = np.zeros(p)
        hess = np.zeros((p, p))
        unique_times = np.unique(to)
        # Walk in ascending time; risk set = subjects with time >= ut.
        # Maintain running suffix sums of w, w*X, w*X*X. At each step,
        # before processing block of times == ut, the running sums
        # already cover [first_with_ti>=ut : n], i.e. the risk set.
        # Implementation: start with cumulative sums from the end.
        w_rev_sum = float(w.sum())
        S1_full = (w[:, None] * Xo).sum(axis=0)
        S2_full = np.einsum("i,ij,ik->jk", w, Xo, Xo)
        # We will subtract blocks as we walk forward in time.
        S0 = w_rev_sum
        S1 = S1_full.copy()
        S2 = S2_full.copy()
        idx = 0
        for ut in unique_times:
            # Identify the contiguous block of subjects with to == ut.
            j = idx
            while j < n and to[j] == ut:
                j += 1
            block = slice(idx, j)
            d = int(eo[block].sum())
            X_d = Xo[block][eo[block] == 1]
            w_d = w[block][eo[block] == 1]
            if d > 0:
                sum_X_d = X_d.sum(axis=0)
                ll += float(eta[block][eo[block] == 1].sum())
                grad += sum_X_d
                S0_d = float(w_d.sum())
                S1_d = (w_d[:, None] * X_d).sum(axis=0)
                S2_d = np.einsum("i,ij,ik->jk", w_d, X_d, X_d)
                for ell in range(d):
                    frac = ell / d
                    S0_eff = S0 - frac * S0_d
                    S1_eff = S1 - frac * S1_d
                    S2_eff = S2 - frac * S2_d
                    if S0_eff <= 0:
                        return -np.inf, grad, hess
                    ll -= math.log(S0_eff)
                    mean_X = S1_eff / S0_eff
                    grad -= mean_X
                    hess -= (S2_eff / S0_eff) - np.outer(mean_X, mean_X)
            # After processing this block, subjects with t == ut
            # leave the risk set for the next (larger) time.
            X_b = Xo[block]; w_b = w[block]
            S0 -= float(w_b.sum())
            S1 -= (w_b[:, None] * X_b).sum(axis=0)
            S2 -= np.einsum("i,ij,ik->jk", w_b, X_b, X_b)
            idx = j
        return ll, grad, hess

    ll_prev, grad, hess = _ll_grad_hess(beta)
    ll_null = ll_prev
    converged = False
    for it in range(max_iter):
        try:
            step = np.linalg.solve(-hess, grad)
        except np.linalg.LinAlgError:
            step = np.linalg.lstsq(-hess, grad, rcond=None)[0]
        new_beta = beta + step
        ll_new, g_new, h_new = _ll_grad_hess(new_beta)
        halv = 0
        while ll_new < ll_prev - 1e-9 and halv < step_halving:
            step *= 0.5
            new_beta = beta + step
            ll_new, g_new, h_new = _ll_grad_hess(new_beta)
            halv += 1
        if abs(ll_new - ll_prev) < tol:
            beta = new_beta
            grad = g_new; hess = h_new; ll_prev = ll_new
            converged = True
            break
        beta = new_beta
        grad = g_new; hess = h_new; ll_prev = ll_new
    cov = np.linalg.pinv(-hess)
    se = np.sqrt(np.diag(cov))
    z = beta / np.where(se > 0, se, np.nan)
    p_vals = np.array([_norm_two_sided(zz) for zz in z])
    return {
        "coef": beta,
        "se": se,
        "hr": np.exp(beta),
        "hr_lower": np.exp(beta - 1.959963984540054 * se),
        "hr_upper": np.exp(beta + 1.959963984540054 * se),
        "z": z,
        "p": p_vals,
        "loglik": ll_prev,
        "loglik_null": ll_null,
        "cov": cov,
        "n_iter": it + 1,
        "converged": converged,
    }


def _norm_two_sided(z: float) -> float:
    if not math.isfinite(z):
        return float("nan")
    # complementary error function via Abramowitz approximation
    az = abs(z) / math.sqrt(2.0)
    p_one = 0.5 * math.erfc(az)
    return float(2.0 * p_one)


def cox_summary_table(fit: dict, covariate_names: Sequence[str]) -> pd.DataFrame:
    """Produce a tidy summary table for a Cox PH fit returned by
    :func:`fit_cox_ph`.

    Parameters
    ----------
    fit : dict
    covariate_names : list of str

    Returns
    -------
    pandas.DataFrame
        Columns: covariate, coef, se, HR, HR_lower, HR_upper, z, p.
    """
    return pd.DataFrame({
        "covariate": list(covariate_names),
        "coef": fit["coef"],
        "se": fit["se"],
        "HR": fit["hr"],
        "HR_lower": fit["hr_lower"],
        "HR_upper": fit["hr_upper"],
        "z": fit["z"],
        "p": fit["p"],
    })


def cox_likelihood_ratio_test(fit_full: dict, fit_reduced: dict,
                              df: int) -> dict:
    """Likelihood ratio chi-squared test between two nested Cox PH fits.

    Returns dict with ``stat``, ``df``, ``p_value``.
    """
    stat = 2.0 * (fit_full["loglik"] - fit_reduced["loglik"])
    return {"stat": float(stat), "df": int(df),
            "p_value": _chi2_sf(stat, df)}


# ---------------------------------------------------------------------------
# Breslow baseline cumulative hazard and survival prediction
# ---------------------------------------------------------------------------


def breslow_baseline_hazard(X, time, event, beta):
    """Breslow estimator of the baseline cumulative hazard given Cox PH
    coefficients ``beta``.

    Returns dict with ``time`` (sorted unique event times) and ``H0``
    (cumulative hazard at each event time).
    """
    X = np.asarray(X, dtype=float); t = np.asarray(time, dtype=float)
    e = np.asarray(event, dtype=int); beta = np.asarray(beta, dtype=float)
    w = np.exp(X @ beta)
    unique_times = np.unique(t[e == 1])
    H = 0.0
    H_list = []
    for ut in unique_times:
        risk = (t >= ut)
        d = int(((t == ut) & (e == 1)).sum())
        S0 = float(w[risk].sum())
        if S0 > 0:
            H += d / S0
        H_list.append(H)
    return {"time": unique_times.tolist(), "H0": H_list}


def predict_survival_function(X_new, beta, baseline_haz: dict):
    """Predict S(t | X_new) at the baseline hazard's event times.

    Parameters
    ----------
    X_new : array-like, shape (m, p)
    beta : array-like, length p
    baseline_haz : dict from :func:`breslow_baseline_hazard`

    Returns
    -------
    dict
        ``time`` (list), ``surv`` (m x len(time) array).
    """
    X_new = np.asarray(X_new, dtype=float)
    if X_new.ndim == 1:
        X_new = X_new[None, :]
    beta = np.asarray(beta, dtype=float)
    H0 = np.asarray(baseline_haz["H0"], dtype=float)
    t = list(baseline_haz["time"])
    risk_score = np.exp(X_new @ beta)  # shape (m,)
    surv = np.exp(-np.outer(risk_score, H0))  # shape (m, T)
    return {"time": t, "surv": surv}


def predict_risk_score(X_new, beta) -> np.ndarray:
    """Linear predictor X @ beta (the Cox prognostic index)."""
    X_new = np.asarray(X_new, dtype=float)
    if X_new.ndim == 1:
        X_new = X_new[None, :]
    return X_new @ np.asarray(beta, dtype=float)


# ---------------------------------------------------------------------------
# Discrimination metrics
# ---------------------------------------------------------------------------


def harrell_concordance(time, event, risk_score) -> float:
    """Harrell's C-index for right-censored data.

    Among all comparable pairs (i, j) where one experiences the event
    before the other and the earlier subject is uncensored, return the
    fraction where the higher risk score corresponds to the earlier event.
    Tied risk scores count 0.5.
    """
    t = np.asarray(time, dtype=float)
    e = np.asarray(event, dtype=int)
    r = np.asarray(risk_score, dtype=float)
    n = len(t)
    num = 0.0
    den = 0.0
    for i in range(n):
        if e[i] != 1:
            continue
        for j in range(n):
            if i == j:
                continue
            if t[j] > t[i]:
                den += 1
                if r[i] > r[j]:
                    num += 1
                elif r[i] == r[j]:
                    num += 0.5
            elif t[j] == t[i] and e[j] == 0:
                den += 1
                if r[i] > r[j]:
                    num += 1
                elif r[i] == r[j]:
                    num += 0.5
    if den == 0:
        return float("nan")
    return float(num / den)


def time_dependent_auc(time, event, risk_score, eval_times):
    """Cumulative/dynamic time-dependent ROC AUC at user-supplied times.

    For each ``t`` in ``eval_times``, defines cases as subjects whose
    event time is <= t with event = 1, controls as subjects whose
    follow-up time is > t (any event status). Returns the area under the
    ROC curve plotting TPR vs FPR by sweeping the risk-score threshold.

    Returns dict with ``time`` and ``auc``.
    """
    t = np.asarray(time, dtype=float)
    e = np.asarray(event, dtype=int)
    r = np.asarray(risk_score, dtype=float)
    aucs = []
    for ut in eval_times:
        case = (t <= ut) & (e == 1)
        ctrl = t > ut
        if case.sum() == 0 or ctrl.sum() == 0:
            aucs.append(float("nan"))
            continue
        rc = r[case]; rk = r[ctrl]
        # Mann-Whitney U style AUC
        wins = 0.0
        for a in rc:
            wins += float((a > rk).sum()) + 0.5 * float((a == rk).sum())
        aucs.append(float(wins / (len(rc) * len(rk))))
    return {"time": list(eval_times), "auc": aucs}


# ---------------------------------------------------------------------------
# Calibration
# ---------------------------------------------------------------------------


def calibration_by_decile(time, event, predicted_surv_at_t, t_target):
    """Decile calibration of predicted vs observed survival at horizon t.

    Parameters
    ----------
    time : array-like
    event : array-like of {0, 1}
    predicted_surv_at_t : array-like
        Each subject's predicted S(t_target).
    t_target : float

    Returns
    -------
    pandas.DataFrame
        One row per decile of predicted survival, with mean predicted S
        and Kaplan-Meier observed S at t_target plus 95% Greenwood CI.
    """
    t = np.asarray(time, dtype=float); e = np.asarray(event, dtype=int)
    p = np.asarray(predicted_surv_at_t, dtype=float)
    deciles = pd.qcut(p, 10, labels=False, duplicates="drop")
    rows = []
    for d in sorted(set(deciles[~pd.isna(deciles)])):
        mask = (deciles == d)
        if mask.sum() < 5:
            continue
        km = kaplan_meier_estimator(t[mask], e[mask])
        # find S(t_target)
        s_obs = 1.0
        s_var = 0.0
        for tt, ss, vv in zip(km["time"], km["surv"], km["surv_var"]):
            if tt <= t_target:
                s_obs = ss
                s_var = vv
            else:
                break
        rows.append({
            "decile": int(d),
            "n": int(mask.sum()),
            "mean_pred_surv": float(p[mask].mean()),
            "obs_km_surv": float(s_obs),
            "obs_se": float(math.sqrt(max(s_var, 0.0))),
        })
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Schoenfeld residuals + global PH test
# ---------------------------------------------------------------------------


def schoenfeld_residuals(X, time, event, beta):
    """Schoenfeld residuals at each event time.

    Returns dict with ``time`` (event times) and ``resid`` (n_event x p
    matrix of residuals).
    """
    X = np.asarray(X, dtype=float); t = np.asarray(time, dtype=float)
    e = np.asarray(event, dtype=int); beta = np.asarray(beta, dtype=float)
    w = np.exp(X @ beta)
    event_times = np.sort(np.unique(t[e == 1]))
    resid_rows = []
    times = []
    for ut in event_times:
        risk = (t >= ut)
        if risk.sum() == 0:
            continue
        died = (t == ut) & (e == 1)
        if died.sum() == 0:
            continue
        S0 = float(w[risk].sum())
        S1 = (w[risk, None] * X[risk]).sum(axis=0) / S0
        for x_d in X[died]:
            resid_rows.append(x_d - S1)
            times.append(ut)
    return {"time": np.array(times), "resid": np.array(resid_rows)}


def global_ph_test(schoenfeld: dict) -> dict:
    """Grambsch-Therneau-style global proportional hazards test using
    rank-transformed event times against the matrix of scaled
    Schoenfeld residuals.

    Returns ``chisq``, ``df``, ``p_value``.
    """
    t = np.asarray(schoenfeld["time"], dtype=float)
    R = np.asarray(schoenfeld["resid"], dtype=float)
    if R.size == 0:
        return {"chisq": float("nan"), "df": 0, "p_value": float("nan")}
    # Rank-transform time
    ranks = np.argsort(np.argsort(t)).astype(float)
    ranks = (ranks - ranks.mean())
    p = R.shape[1]
    # Per covariate, fit slope of resid vs rank, sum chi-sq
    chisq = 0.0
    for j in range(p):
        var_r = float((R[:, j] ** 2).sum())
        if var_r <= 0:
            continue
        cov = float((R[:, j] * ranks).sum())
        denom = float((ranks ** 2).sum() * var_r / len(ranks))
        if denom > 0:
            chisq += (cov ** 2) / denom
    return {"chisq": float(chisq), "df": int(p),
            "p_value": _chi2_sf(chisq, p)}


# ---------------------------------------------------------------------------
# Descriptive splits
# ---------------------------------------------------------------------------


def split_by_indicator(df: pd.DataFrame, mut_pids, time_col: str,
                       event_col: str):
    """Build event/time arrays for two groups (mutated vs wild-type) by
    membership in a set of patient IDs.

    Returns dict with ``time``, ``event``, ``group`` numpy arrays.
    """
    g = np.where(df["PATIENT_ID"].isin(mut_pids), "mut", "wt")
    t = df[time_col].to_numpy(dtype=float)
    e = df[event_col].to_numpy(dtype=int)
    return {"time": t, "event": e, "group": g}


# ---------------------------------------------------------------------------
# Random survival forest (depth-limited bagged ensemble) for benchmarking
# ---------------------------------------------------------------------------


class _SurvNode:
    __slots__ = ("feature", "threshold", "left", "right", "leaf_chf")
    def __init__(self):
        self.feature = -1
        self.threshold = 0.0
        self.left = None
        self.right = None
        self.leaf_chf = None  # tuple(times, H)


def _nelson_aalen(time, event):
    t = np.asarray(time); e = np.asarray(event)
    unique_times = np.unique(t[e == 1])
    H = 0.0; out_t = []; out_h = []
    for ut in unique_times:
        n = (t >= ut).sum()
        d = ((t == ut) & (e == 1)).sum()
        if n > 0:
            H += d / n
        out_t.append(ut); out_h.append(H)
    return np.array(out_t), np.array(out_h)


def _logrank_split_score(t, e, mask_left):
    if mask_left.sum() < 5 or (~mask_left).sum() < 5:
        return -np.inf
    g = np.where(mask_left, 0, 1)
    O = np.zeros(2); E = np.zeros(2); V = 0.0
    unique_event_times = np.unique(t[e == 1])
    for ut in unique_event_times:
        risk = t >= ut
        n = risk.sum()
        d = ((t == ut) & (e == 1)).sum()
        if d == 0 or n <= 1:
            continue
        n0 = (risk & (g == 0)).sum()
        n1 = n - n0
        d0 = ((t == ut) & (e == 1) & (g == 0)).sum()
        d1 = d - d0
        O[0] += d0; O[1] += d1
        e0 = n0 * d / n
        E[0] += e0; E[1] += d - e0
        if n > 1 and d < n:
            V += (n0 * n1 * d * (n - d)) / (n ** 2 * (n - 1))
    if V <= 0:
        return -np.inf
    return float((O[0] - E[0]) ** 2 / V)


def _grow_tree(X, t, e, depth, max_depth, min_node, mtry, rng):
    node = _SurvNode()
    n = len(t)
    if depth >= max_depth or n < 2 * min_node or e.sum() < 2:
        ts, H = _nelson_aalen(t, e)
        node.leaf_chf = (ts, H)
        return node
    p = X.shape[1]
    feat_idx = rng.choice(p, size=min(mtry, p), replace=False)
    best_score = -np.inf
    best_feat = -1; best_thr = 0.0
    for j in feat_idx:
        vals = X[:, j]
        candidates = np.unique(np.quantile(vals, [0.25, 0.5, 0.75]))
        for thr in candidates:
            mask_left = vals <= thr
            score = _logrank_split_score(t, e, mask_left)
            if score > best_score:
                best_score = score
                best_feat = j; best_thr = float(thr)
    if best_feat < 0:
        ts, H = _nelson_aalen(t, e)
        node.leaf_chf = (ts, H)
        return node
    mask_left = X[:, best_feat] <= best_thr
    node.feature = int(best_feat)
    node.threshold = float(best_thr)
    node.left = _grow_tree(X[mask_left], t[mask_left], e[mask_left],
                           depth + 1, max_depth, min_node, mtry, rng)
    node.right = _grow_tree(X[~mask_left], t[~mask_left], e[~mask_left],
                            depth + 1, max_depth, min_node, mtry, rng)
    return node


def _tree_predict_chf(node, x_row):
    while node.leaf_chf is None:
        if x_row[node.feature] <= node.threshold:
            node = node.left
        else:
            node = node.right
    return node.leaf_chf


def fit_random_survival_forest(X, time, event, n_trees: int = 100,
                               max_depth: int = 6, min_node: int = 15,
                               mtry: Optional[int] = None,
                               seed: int = 1):
    """Bagged random survival forest with log-rank splitting and
    Nelson-Aalen leaf cumulative hazards. Self-contained — no
    scikit-survival required.

    Parameters
    ----------
    X : (n, p) array
    time : (n,) array
    event : (n,) array of {0, 1}
    n_trees : int
    max_depth : int
    min_node : int
    mtry : int, default sqrt(p)
    seed : int

    Returns
    -------
    dict
        Keys: ``trees`` (list of root nodes), ``mtry``, ``n_trees``.
    """
    X = np.asarray(X, dtype=float); t = np.asarray(time, dtype=float)
    e = np.asarray(event, dtype=int)
    n, p = X.shape
    if mtry is None:
        mtry = max(1, int(round(math.sqrt(p))))
    rng = np.random.default_rng(seed)
    trees = []
    for _ in range(n_trees):
        idx = rng.integers(0, n, size=n)
        root = _grow_tree(X[idx], t[idx], e[idx], 0, max_depth, min_node, mtry, rng)
        trees.append(root)
    return {"trees": trees, "mtry": mtry, "n_trees": n_trees}


def rsf_predict_risk(forest: dict, X_new) -> np.ndarray:
    """Predict ensemble cumulative-hazard summary risk score for each
    row in ``X_new``. Higher = higher predicted risk.
    """
    X_new = np.asarray(X_new, dtype=float)
    if X_new.ndim == 1:
        X_new = X_new[None, :]
    out = np.zeros(len(X_new))
    for x in range(len(X_new)):
        chfs = []
        for tree in forest["trees"]:
            ts, H = _tree_predict_chf(tree, X_new[x])
            if len(H) > 0:
                chfs.append(H[-1])
            else:
                chfs.append(0.0)
        out[x] = float(np.mean(chfs))
    return out

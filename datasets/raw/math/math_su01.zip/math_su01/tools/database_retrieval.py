"""Database retrieval helpers — DISABLED for the local-only math_su01 task.

The cohort and somatic-mutation tables are bundled in ``input_data/data/``;
no external lookup is required at solve time. Stubs are retained to record
the original cBioPortal datahub URL pattern used to assemble the bundle.
"""

from __future__ import annotations


def _disabled(label: str):
    raise NotImplementedError(
        f"Network helper '{label}' is intentionally disabled for the "
        f"local-only math_su01 task. All required data is bundled in "
        f"input_data/data/."
    )


def cbioportal_url_pattern(study_id: str) -> str:
    """[DISABLED] Original cBioPortal datahub URL pattern reference.

    Pattern used at bundle-build time:
      https://media.githubusercontent.com/media/cBioPortal/datahub/master/public/{study_id}/<file>

    Local solver should read input_data/data/metabric_clinical.csv and
    input_data/data/metabric_mut_drivers.csv directly.
    """
    _disabled("cbioportal_url_pattern")


def cbioportal_clinical_files() -> list:
    """[DISABLED] Names of the cBioPortal clinical files (reference only)."""
    _disabled("cbioportal_clinical_files")

"""
Generic data-processing primitives for cohort-style survival tables.

Helpers here load CSVs, build event/time arrays from heterogeneous
status columns, derive binary-indicator covariate matrices from a
mutation table, and form clinical covariate vectors.
"""

from __future__ import annotations

from typing import Iterable, Optional, Sequence, Tuple

import numpy as np
import pandas as pd


def read_csv(file_path: str) -> pd.DataFrame:
    """Read a CSV file into a pandas DataFrame.

    Parameters
    ----------
    file_path : str

    Returns
    -------
    pandas.DataFrame
    """
    return pd.read_csv(file_path)


def write_csv(df: pd.DataFrame, file_path: str) -> str:
    """Write a DataFrame to CSV without the index column."""
    df.to_csv(file_path, index=False)
    return file_path


def build_endpoint(clin: pd.DataFrame, status_col: str,
                   event_label: str, time_col: str,
                   censoring_labels: Optional[Sequence[str]] = None
                   ) -> pd.DataFrame:
    """Construct numeric ``time`` and ``event`` columns from a string
    status column.

    Parameters
    ----------
    clin : pandas.DataFrame
        Cohort table.
    status_col : str
        Name of the column with vital-status labels (e.g., "Living",
        "Died of Disease", "Died of Other Causes").
    event_label : str
        The exact label that corresponds to the event of interest. Any
        other status counts as censored.
    time_col : str
        Name of the follow-up-time column (numeric).
    censoring_labels : iterable of str, optional
        If supplied, rows whose status is not in {event_label} ∪
        censoring_labels are dropped.

    Returns
    -------
    pandas.DataFrame
        A copy of ``clin`` with extra columns ``time`` and ``event``;
        rows with missing status or time are removed.
    """
    df = clin.copy()
    df = df[df[status_col].notna() & df[time_col].notna()].copy()
    if censoring_labels is not None:
        keep = set([event_label]) | set(censoring_labels)
        df = df[df[status_col].isin(keep)].copy()
    df["event"] = (df[status_col] == event_label).astype(int)
    df["time"] = df[time_col].astype(float)
    return df.reset_index(drop=True)


def make_binary_indicator(values, threshold) -> np.ndarray:
    """Return a {0, 1} indicator array for ``values >= threshold``.

    Missing entries become NaN.
    """
    v = pd.Series(values).astype(float)
    out = (v >= float(threshold)).astype(float)
    out[v.isna()] = np.nan
    return out.to_numpy()


def lymph_node_positive(values) -> np.ndarray:
    """Indicator for at least one positive lymph node."""
    return make_binary_indicator(values, 1.0)


def grade_high(values, threshold: float = 2.0) -> np.ndarray:
    """Indicator for histologic grade >= ``threshold`` (default 2)."""
    return make_binary_indicator(values, threshold)


def category_to_indicator(values, positive_label: str) -> np.ndarray:
    """One-hot indicator for a single categorical level."""
    s = pd.Series(values).astype(str)
    out = (s == positive_label).astype(float)
    out[s.isna() | (s == "nan")] = np.nan
    return out.to_numpy()


# Mutation-table helpers

INACTIVATING_CLASSES = (
    "Frame_Shift_Del", "Frame_Shift_Ins", "Nonsense_Mutation",
    "Splice_Site", "Splice_Region", "Nonstop_Mutation",
    "Translation_Start_Site",
)
NONSYNONYMOUS_CLASSES = INACTIVATING_CLASSES + (
    "Missense_Mutation", "In_Frame_Del", "In_Frame_Ins",
)


def patients_with_mutation(muts: pd.DataFrame, gene: str,
                           classes: Iterable[str] = NONSYNONYMOUS_CLASSES,
                           gene_col: str = "GENE",
                           class_col: str = "VARIANT_CLASS",
                           pid_col: str = "PATIENT_ID"
                           ) -> set:
    """Return the set of patient IDs harbouring at least one mutation
    in ``gene`` whose VARIANT_CLASS is in ``classes``.
    """
    sub = muts[(muts[gene_col] == gene) & (muts[class_col].isin(list(classes)))]
    return set(sub[pid_col].unique())


def mutation_indicator_column(clin: pd.DataFrame, muts: pd.DataFrame,
                              gene: str,
                              classes: Iterable[str] = NONSYNONYMOUS_CLASSES,
                              pid_col: str = "PATIENT_ID") -> np.ndarray:
    """For each row in ``clin``, return 1 if the patient has a mutation
    in ``gene`` matching the requested variant classes, else 0.
    """
    pids = patients_with_mutation(muts, gene, classes=classes, pid_col=pid_col)
    return clin[pid_col].isin(pids).astype(int).to_numpy()


def assemble_covariate_matrix(clin: pd.DataFrame,
                              binary_cols: Sequence[str]
                              ) -> Tuple[np.ndarray, list, np.ndarray]:
    """Stack pre-built binary indicator columns into an X matrix.

    Parameters
    ----------
    clin : pandas.DataFrame
    binary_cols : list of column names already coded as 0/1.

    Returns
    -------
    X : ndarray, shape (n, p)
    names : list of str
        Column names (echoed back for convenience).
    mask : ndarray of bool, shape (n_input,)
        Boolean row mask indicating which input rows were kept (True
        means kept). Apply this mask to survival arrays before pairing
        them with X.

    Rows containing any NaN among the requested covariates are dropped
    before the matrix is returned.
    """
    sub = clin[list(binary_cols)].copy()
    mask = sub.notna().all(axis=1)
    X = sub[mask].to_numpy(dtype=float)
    return X, list(binary_cols), mask.to_numpy()


def stratify_by_column(clin: pd.DataFrame, column: str
                       ) -> dict:
    """Split a clinical DataFrame into a dict mapping each unique
    non-missing value of ``column`` to the corresponding sub-DataFrame.
    """
    out = {}
    for v in clin[column].dropna().unique():
        out[str(v)] = clin[clin[column] == v].reset_index(drop=True)
    return out


def quantile_groups(values, n_groups: int = 4) -> np.ndarray:
    """Discretise a numeric vector into ``n_groups`` quantile bins (0..n-1)."""
    s = pd.Series(values).astype(float)
    return pd.qcut(s, n_groups, labels=False, duplicates="drop").to_numpy()


def cohort_summary(clin: pd.DataFrame, time_col: str = "time",
                   event_col: str = "event") -> pd.DataFrame:
    """Compact descriptive summary of a survival cohort.

    Returns one row with N, events, median time, IQR.
    """
    t = clin[time_col].astype(float)
    e = clin[event_col].astype(int)
    return pd.DataFrame([{
        "N": int(len(clin)),
        "events": int(e.sum()),
        "censoring_pct": 100.0 * float((e == 0).mean()),
        "median_time": float(t.median()),
        "p25_time": float(t.quantile(0.25)),
        "p75_time": float(t.quantile(0.75)),
    }])

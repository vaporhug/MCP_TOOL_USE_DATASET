"""Rank-based dependence measures used in the target paper.

All formulas are pure-numpy; we compute Kendall's tau by counting
concordant minus discordant pairs and Spearman's rho by Pearson on
ranks.  Closed-form asymptotic variances are used to obtain p-values
under the null of independence (no scipy.stats dependency).
"""
from __future__ import annotations

import math
from typing import Dict

import numpy as np


def _ranks(v: np.ndarray) -> np.ndarray:
    """Average-rank vector; ties resolved by averaging rank positions."""
    v = np.asarray(v, dtype=float)
    order = np.argsort(v, kind="mergesort")
    n = len(v)
    rk = np.empty(n, dtype=float)
    i = 0
    while i < n:
        j = i
        while j + 1 < n and v[order[j + 1]] == v[order[i]]:
            j += 1
        avg = 0.5 * (i + j) + 1.0
        for k in range(i, j + 1):
            rk[order[k]] = avg
        i = j + 1
    return rk


def kendall_tau(x: np.ndarray, y: np.ndarray) -> Dict[str, float]:
    """Kendall's tau-b with O(n^2) pair counting.

    Returns {tau, p_value, z, n}.  The asymptotic variance under H0
    is sigma^2 = 2(2n+5)/(9 n (n-1)).  The two-sided p-value is
    2 * Phi(-|z|) computed from the error function (no scipy.stats).
    """
    x = np.asarray(x, dtype=float); y = np.asarray(y, dtype=float)
    msk = ~(np.isnan(x) | np.isnan(y))
    x = x[msk]; y = y[msk]
    n = len(x)
    if n < 2:
        return {"tau": float("nan"), "p_value": float("nan"), "z": float("nan"), "n": n}
    nc = nd = 0
    for i in range(n):
        for j in range(i + 1, n):
            sx = x[i] - x[j]; sy = y[i] - y[j]
            if sx * sy > 0: nc += 1
            elif sx * sy < 0: nd += 1
    npairs = n * (n - 1) // 2
    tau = (nc - nd) / npairs
    sigma = math.sqrt(2.0 * (2.0 * n + 5.0) / (9.0 * n * (n - 1)))
    z = tau / sigma if sigma > 0 else float("nan")
    p = math.erfc(abs(z) / math.sqrt(2.0))  # two-sided
    return {"tau": float(tau), "p_value": float(p), "z": float(z), "n": int(n)}


def spearman_rho(x: np.ndarray, y: np.ndarray) -> Dict[str, float]:
    """Spearman's rank correlation with normal-approximation p-value.

    Asymptotic variance under independence: 1/(n-1).  Two-sided p-value is
    2 * Phi(-|sqrt(n-1) * rho|).
    """
    x = np.asarray(x, dtype=float); y = np.asarray(y, dtype=float)
    msk = ~(np.isnan(x) | np.isnan(y))
    x = x[msk]; y = y[msk]
    n = len(x)
    if n < 2:
        return {"rho": float("nan"), "p_value": float("nan"), "z": float("nan"), "n": n}
    rx = _ranks(x); ry = _ranks(y)
    mx = np.mean(rx); my = np.mean(ry)
    num = float(np.sum((rx - mx) * (ry - my)))
    dx = float(np.sqrt(np.sum((rx - mx) ** 2)))
    dy = float(np.sqrt(np.sum((ry - my) ** 2)))
    rho = num / (dx * dy)
    z = math.sqrt(n - 1) * rho
    p = math.erfc(abs(z) / math.sqrt(2.0))
    return {"rho": float(rho), "p_value": float(p), "z": float(z), "n": int(n)}


def pseudo_observations(x: np.ndarray, y: np.ndarray) -> Dict[str, np.ndarray]:
    """Return rank-based pseudo-observations U=R/(n+1), V=S/(n+1).

    These are fed into the copula likelihood for maximum-pseudolikelihood
    inference (see `copula_inference.fit_copula_mpl`).
    """
    x = np.asarray(x, dtype=float); y = np.asarray(y, dtype=float)
    n = len(x)
    rx = _ranks(x); ry = _ranks(y)
    return {"U": rx / (n + 1.0), "V": ry / (n + 1.0),
            "ranks_x": rx.astype(int), "ranks_y": ry.astype(int)}

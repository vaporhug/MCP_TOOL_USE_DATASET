"""Maximum-pseudolikelihood inference for one-parameter copulas.

The log-pseudolikelihood is
    L(theta) = sum_i log c_theta( R_i/(n+1), S_i/(n+1) )
with R, S the ranks of x and y.  We minimise -L by `scipy.optimize.minimize`
with bounded transformations of theta to its admissible range (no
scipy.stats dependency).

Method-of-moments (Kendall-tau inversion) and AIC/BIC are also exposed.
"""
from __future__ import annotations

import math
from typing import Dict, Iterable, List

import numpy as np
from scipy.optimize import minimize, minimize_scalar

from . import copula_families as cf
from . import rank_dependence as rd


_EPS = 1e-9


# ---------------------------------------------------------------------------
# Method-of-moments via Kendall's tau
# ---------------------------------------------------------------------------

def tau_to_theta(family: str, tau: float) -> float:
    family = family.lower()
    if family == "gaussian":
        return math.sin(math.pi * tau / 2.0)
    if family == "clayton":
        return max(2.0 * tau / (1.0 - tau), 1e-6) if tau < 1 else float("inf")
    if family in ("gumbel", "gumbel_hougaard"):
        return 1.0 / (1.0 - tau) if tau < 1 else float("inf")
    if family == "frank":
        # Solve tau = 1 - 4/theta * (1 - D_1(theta)) numerically
        def D1(th):
            # Debye function order 1; approximate by quadrature
            if abs(th) < 1e-6:
                return 1.0 - th / 4.0
            xs = np.linspace(1e-8, abs(th), 400)
            integrand = xs / (np.exp(xs) - 1.0)
            val = float(np.trapz(integrand, xs)) / abs(th)
            return val
        from scipy.optimize import brentq
        if abs(tau) < 1e-3:
            return 0.0
        f = lambda th: 1.0 - 4.0 / th * (1.0 - D1(th)) - tau
        try:
            sol = brentq(f, 0.05 * np.sign(tau), 50.0 * np.sign(tau))
            return float(sol)
        except Exception:
            # widen
            return float(brentq(f, 1e-3 * np.sign(tau), 100.0 * np.sign(tau)))
    raise ValueError(f"tau_to_theta: unknown family {family!r}")


def theta_to_tau(family: str, theta: float) -> float:
    family = family.lower()
    if family == "gaussian":
        return 2.0 / math.pi * math.asin(theta)
    if family == "clayton":
        return theta / (theta + 2.0)
    if family in ("gumbel", "gumbel_hougaard"):
        return 1.0 - 1.0 / theta
    if family == "frank":
        # Inverse mapping: tau = 1 - 4/theta * (1 - D_1(theta))
        if abs(theta) < 1e-8:
            return 0.0
        xs = np.linspace(1e-8, abs(theta), 400)
        D1 = float(np.trapz(xs / (np.exp(xs) - 1.0), xs)) / abs(theta)
        return 1.0 - 4.0 / theta * (1.0 - D1)
    raise ValueError(f"theta_to_tau: unknown family {family!r}")


# ---------------------------------------------------------------------------
# Maximum-pseudolikelihood
# ---------------------------------------------------------------------------

def _neg_log_pl(theta: float, family: str, U: np.ndarray, V: np.ndarray) -> float:
    family = family.lower()
    try:
        if family == "gaussian":
            if not -0.999 < theta < 0.999: return 1e10
            c = cf.gaussian_pdf(U, V, theta)
        elif family == "clayton":
            if theta <= 0: return 1e10
            c = cf.clayton_pdf(U, V, theta)
        elif family in ("gumbel", "gumbel_hougaard"):
            if theta < 1.0: return 1e10
            c = cf.gumbel_pdf_copula(U, V, theta)
        elif family == "frank":
            if abs(theta) < 1e-6: theta = 1e-6
            c = cf.frank_pdf(U, V, theta)
        else:
            raise ValueError(family)
        c = np.where(c <= 0, _EPS, c)
        return -float(np.sum(np.log(c)))
    except (ValueError, FloatingPointError):
        return 1e10


def fit_copula_mpl(family: str, x: np.ndarray, y: np.ndarray) -> Dict[str, float]:
    """Fit a one-parameter copula by maximum pseudo-likelihood.

    Returns dict with theta, log-pseudolikelihood, AIC, BIC, and the
    rank-implied tau.
    """
    po = rd.pseudo_observations(x, y)
    U, V = po["U"], po["V"]
    family = family.lower()
    tau_hat = rd.kendall_tau(x, y)["tau"]
    theta0 = tau_to_theta(family, tau_hat)
    bounds = {
        "gaussian": (-0.999, 0.999),
        "clayton": (1e-3, 50.0),
        "gumbel": (1.0001, 50.0),
        "gumbel_hougaard": (1.0001, 50.0),
        "frank": (-50.0, 50.0),
    }[family]
    if not (bounds[0] < theta0 < bounds[1]):
        theta0 = 0.5 * (bounds[0] + bounds[1])
    res = minimize_scalar(lambda t: _neg_log_pl(t, family, U, V),
                          bounds=bounds, method="bounded",
                          options={"xatol": 1e-7})
    theta_hat = float(res.x)
    nll = float(res.fun)
    log_pl = -nll
    n = len(x); k = 1
    return {
        "family": family,
        "theta": theta_hat,
        "log_pl": log_pl,
        "nll": nll,
        "n": int(n),
        "k": int(k),
        "aic": 2.0 * nll + 2 * k,
        "bic": 2.0 * nll + k * math.log(n),
        "tau_inverted": theta_to_tau(family, theta_hat),
        "tau_initial": tau_hat,
        "converged": True,
    }


def fit_all_one_parameter_copulas(x: np.ndarray, y: np.ndarray
                                  ) -> Dict[str, Dict[str, float]]:
    """Fit Gaussian, Clayton, Gumbel and Frank by MPL and return the dict
    of fits keyed by family name. AIC table is sorted in caller code.
    """
    out = {}
    for fam in ("gaussian", "clayton", "gumbel", "frank"):
        out[fam] = fit_copula_mpl(fam, x, y)
    return out


def aic_table(fits: Dict[str, Dict[str, float]]) -> List[Dict[str, float]]:
    """Convert a fit-dictionary to a sorted list of {family, theta, aic, dAIC}."""
    rows = []
    for fam, fit in fits.items():
        rows.append({"family": fam, "theta": fit["theta"], "log_pl": fit["log_pl"],
                     "aic": fit["aic"], "bic": fit["bic"], "tau": fit["tau_inverted"]})
    rows.sort(key=lambda r: r["aic"])
    aic0 = rows[0]["aic"]
    for r in rows:
        r["dAIC"] = r["aic"] - aic0
    return rows


def parametric_bootstrap_theta_ci(family: str, x: np.ndarray, y: np.ndarray,
                                  n_boot: int = 500, seed: int = 0,
                                  alpha: float = 0.05) -> Dict[str, float]:
    """Parametric bootstrap CI for theta.

    Steps: fit theta_hat on data; simulate (U*, V*) from C_{theta_hat} of size n;
    transform back to original margins by empirical quantile; refit; collect
    bootstrap thetas; report percentile interval.
    """
    fit = fit_copula_mpl(family, x, y)
    theta_hat = fit["theta"]
    n = len(x)
    rng = np.random.default_rng(seed)
    thetas = []
    xs = np.sort(x); ys = np.sort(y)
    for _ in range(int(n_boot)):
        u, v = cf.sample_copula(family, theta_hat, n, rng)
        # Empirical quantile back-transform
        xb = np.quantile(xs, u, method="linear") if hasattr(np, "quantile") else np.percentile(xs, u * 100)
        yb = np.quantile(ys, v, method="linear") if hasattr(np, "quantile") else np.percentile(ys, v * 100)
        try:
            f = fit_copula_mpl(family, xb, yb)
            thetas.append(f["theta"])
        except Exception:
            continue
    thetas = np.array(thetas)
    return {
        "family": family,
        "theta_hat": float(theta_hat),
        "lower": float(np.percentile(thetas, 100 * alpha / 2)),
        "upper": float(np.percentile(thetas, 100 * (1 - alpha / 2))),
        "n_boot": int(len(thetas)),
        "alpha": float(alpha),
    }

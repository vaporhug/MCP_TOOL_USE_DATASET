"""Bivariate return-period and conditional-CDF helpers.

For an annual-maximum series with mean inter-arrival mu_T = 1 yr, the
joint AND-return-period of an event {X > x, Y > y} is
    T_AND(x, y) = mu_T / Pr(X > x, Y > y)
              = mu_T / [1 - F_X(x) - F_Y(y) + C(F_X(x), F_Y(y))]
and the OR-return-period is
    T_OR(x, y)  = mu_T / Pr(X > x  OR  Y > y)
              = mu_T / [1 - C(F_X(x), F_Y(y))]
(see Salvadori & De Michele 2004; Genest & Favre 2007 section "Return
period").

The Kendall return period T_K (Salvadori 2010) uses K_C(t) = Pr(C(U,V) <= t)
and is exposed for completeness.

We also provide:
  * bivariate_AND_OR_T:    point estimates and curves on a (x,y) grid,
  * conditional_cdf_Y_given_X: Pr(Y <= y | X = x) for design events,
  * design_event_isoline:  contour x(T), y(T) for a target T.
"""
from __future__ import annotations

import math
from typing import Callable, Dict, Tuple

import numpy as np

from . import copula_families as cf


def bivariate_AND_T(F_X: float, F_Y: float, C_uv: float,
                    mu_T: float = 1.0) -> float:
    """Deprecated 3-argument alias for ``joint_return_period_AND``.

    T_AND(x, y) = mu_T / (1 - F_X - F_Y + C(F_X, F_Y)).
    Prefer ``joint_return_period_AND`` in new code.
    """
    return joint_return_period_AND(F_X, F_Y, C_uv, mu_T=mu_T)

def joint_return_period_AND(F_X: float, F_Y: float, C_uv: float,
                            mu_T: float = 1.0) -> float:
    """T_AND(x,y) = mu_T / (1 - F_X - F_Y + C(F_X, F_Y))."""
    p = 1.0 - F_X - F_Y + C_uv
    if p <= 0:
        return float("inf")
    return mu_T / p


def joint_return_period_OR(C_uv: float, mu_T: float = 1.0) -> float:
    """T_OR(x,y) = mu_T / (1 - C(F_X, F_Y))."""
    p = 1.0 - C_uv
    if p <= 0:
        return float("inf")
    return mu_T / p


def joint_return_period_grid(family: str, theta: float,
                             u_grid: np.ndarray, v_grid: np.ndarray,
                             which: str = "AND",
                             mu_T: float = 1.0) -> np.ndarray:
    """Evaluate T_AND or T_OR on a (u, v) grid where u=F_X(x), v=F_Y(y).

    Returns a 2-D array T[i, j] with T(u_grid[i], v_grid[j]).
    """
    family = family.lower()
    if family == "gaussian":
        cdf = lambda U, V: cf.gaussian_cdf(U, V, theta)
    elif family == "clayton":
        cdf = lambda U, V: cf.clayton_cdf(U, V, theta)
    elif family in ("gumbel", "gumbel_hougaard"):
        cdf = lambda U, V: cf.gumbel_cdf_copula(U, V, theta)
    elif family == "frank":
        cdf = lambda U, V: cf.frank_cdf(U, V, theta)
    else:
        raise ValueError(family)
    U, V = np.meshgrid(u_grid, v_grid, indexing="ij")
    Cuv = cdf(U, V)
    if which.upper() == "AND":
        p = 1.0 - U - V + Cuv
    else:
        p = 1.0 - Cuv
    p = np.where(p <= 0, np.nan, p)
    return mu_T / p


def conditional_cdf_Y_given_X(family: str, theta: float,
                              u: np.ndarray, v: np.ndarray) -> np.ndarray:
    """The conditional CDF Pr(V <= v | U = u) = dC/du(u, v).

    Closed form per family:
        Gaussian: Phi( (Phi^{-1}(v) - rho * Phi^{-1}(u)) / sqrt(1 - rho^2) )
        Clayton:  u^{-1-theta} * (u^{-theta} + v^{-theta} - 1)^{-1/theta - 1}
        Gumbel:   C(u,v) * (a^{1/theta - 1}) * (-log u)^{theta - 1} / u
                  with a = (-log u)^theta + (-log v)^theta
        Frank:    e^{-theta u} * (e^{-theta v} - 1) /
                  (e^{-theta} - 1 + (e^{-theta u} - 1)(e^{-theta v} - 1))
    """
    u = np.asarray(u, dtype=float); v = np.asarray(v, dtype=float)
    family = family.lower()
    if family == "gaussian":
        from .copula_families import _Phi, _Phi_inv
        a = _Phi_inv(u); b = _Phi_inv(v)
        return _Phi((b - theta * a) / math.sqrt(1.0 - theta * theta))
    if family == "clayton":
        return u ** (-1.0 - theta) * np.power(u ** (-theta) + v ** (-theta) - 1.0, -1.0 / theta - 1.0)
    if family in ("gumbel", "gumbel_hougaard"):
        lu = -np.log(u); lv = -np.log(v)
        a = lu ** theta + lv ** theta
        Cuv = np.exp(-a ** (1.0 / theta))
        return Cuv * (a ** (1.0 / theta - 1.0)) * (lu ** (theta - 1.0)) / u
    if family == "frank":
        e = math.exp(-theta)
        eu = np.exp(-theta * u); ev = np.exp(-theta * v)
        return eu * (ev - 1.0) / ((e - 1.0) + (eu - 1.0) * (ev - 1.0))
    raise ValueError(family)


def kendall_distribution(family: str, theta: float, t_grid: np.ndarray
                         ) -> np.ndarray:
    """K_C(t) = Pr(C(U, V) <= t) for the Archimedean families used here.

    K_C(t) = t - phi(t) / phi'(t)  with phi the Archimedean generator
    (Genest & Rivest 1993).  Closed form:
       Clayton:  K(t) = t + (t - t^{1+theta}) / theta
       Gumbel:   K(t) = t - t * log(t) / theta
       Frank:    K(t) = t + ((1 - e^{-theta t}) * log( (e^{-theta t} - 1)
                       / (e^{-theta} - 1) )) / theta
    """
    family = family.lower()
    t = np.asarray(t_grid, dtype=float)
    if family == "clayton":
        return t + (t - t ** (1 + theta)) / theta
    if family in ("gumbel", "gumbel_hougaard"):
        return t - t * np.log(np.where(t > 0, t, 1)) / theta
    if family == "frank":
        out = np.zeros_like(t)
        for i, ti in enumerate(t.ravel()):
            if ti <= 0 or ti >= 1:
                out.flat[i] = ti; continue
            num = math.log((math.exp(-theta * ti) - 1.0) / (math.exp(-theta) - 1.0))
            out.flat[i] = ti + (1.0 - math.exp(-theta * ti)) * num / theta
        return out
    raise ValueError(f"kendall_distribution: family {family!r} not supported")


def kendall_return_period(family: str, theta: float, t: float,
                          mu_T: float = 1.0) -> float:
    """T_K(t) = mu_T / (1 - K_C(t))."""
    Kt = float(kendall_distribution(family, theta, np.array([t]))[0])
    p = 1.0 - Kt
    if p <= 0:
        return float("inf")
    return mu_T / p


def monte_carlo_AND_T(family: str, theta_or_params, F_X: float, F_Y: float,
                      n_sim: int = 200_000, seed: int = 1,
                      mu_T: float = 1.0) -> Dict[str, float]:
    """Monte-Carlo estimate of T_AND for any copula family (sanity check).

    Draws (U, V) ~ C and counts Pr(U > F_X and V > F_Y).
    """
    rng = np.random.default_rng(seed)
    u, v = cf.sample_copula(family, theta_or_params, n_sim, rng)
    p = float(np.mean((u > F_X) & (v > F_Y)))
    return {"p_joint_exceed": p,
            "T_AND": mu_T / p if p > 0 else float("inf"),
            "n_sim": int(n_sim)}

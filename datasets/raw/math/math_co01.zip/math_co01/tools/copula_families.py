"""Copula CDFs and densities (PDF) for the bivariate Gaussian, Student-t,
Clayton, Gumbel-Hougaard and Frank families.

Conventions (Genest and Favre 2007, Nelsen 2006):

    Gaussian(rho)    : C(u,v) = Phi_2( Phi^{-1}(u), Phi^{-1}(v); rho )
                       valid rho in (-1, 1).
    Student-t(rho,nu): bivariate t with correlation rho and nu df,
                       valid rho in (-1, 1), nu > 0.
    Clayton(theta)   : C(u,v) = (u^{-th} + v^{-th} - 1)^{-1/th},
                       theta > 0; tau = th / (th+2).
    Gumbel(theta)    : C(u,v) = exp{-((-log u)^th + (-log v)^th)^{1/th}},
                       theta >= 1; tau = 1 - 1/th.
    Frank(theta)     : C(u,v) = -1/th * log(1 + (e^{-th u}-1)(e^{-th v}-1)
                                            / (e^{-th}-1)),
                       theta != 0; tau = 1 - 4/th * (1 - D_1(th)).

All routines accept scalar or 1-D array u, v in (0, 1).  No scipy.stats.
"""
from __future__ import annotations

import math
from typing import Tuple

import numpy as np
from scipy.special import erf, erfinv, gammaln


_SQRT2 = math.sqrt(2.0)


# ---------------------------------------------------------------------------
# Standard normal helpers (avoids scipy.stats.norm)
# ---------------------------------------------------------------------------

def _phi(x: np.ndarray) -> np.ndarray:
    return np.exp(-0.5 * np.asarray(x, dtype=float) ** 2) / math.sqrt(2 * math.pi)


def _Phi(x: np.ndarray) -> np.ndarray:
    return 0.5 * (1.0 + erf(np.asarray(x, dtype=float) / _SQRT2))


def _Phi_inv(p: np.ndarray) -> np.ndarray:
    p = np.clip(np.asarray(p, dtype=float), 1e-12, 1.0 - 1e-12)
    return _SQRT2 * erfinv(2.0 * p - 1.0)


def _bvn_cdf(h: np.ndarray, k: np.ndarray, rho: float) -> np.ndarray:
    """Bivariate normal CDF (Drezner-Wesolowsky 1990 quadrature, 20 nodes).

    Phi_2(h, k; rho) = Pr(X <= h, Y <= k) for standard bivariate normal
    with correlation rho. Pure numpy, accurate to ~1e-7.
    """
    h = np.asarray(h, dtype=float); k = np.asarray(k, dtype=float)
    # 20-point Gauss-Legendre weights/nodes on [-1, 1] mapped to (0, |rho|)
    nodes20 = np.array([-0.9931285991, -0.9639719272, -0.9122344282, -0.8391169718,
                        -0.7463319065, -0.6360536807, -0.5108670019, -0.3737060887,
                        -0.2277858511, -0.0765265211,  0.0765265211,  0.2277858511,
                         0.3737060887,  0.5108670019,  0.6360536807,  0.7463319065,
                         0.8391169718,  0.9122344282,  0.9639719272,  0.9931285991])
    w20 = np.array([0.0176140071, 0.0406014298, 0.0626720483, 0.0832767416,
                    0.1019301198, 0.1181945320, 0.1316886384, 0.1420961093,
                    0.1491729865, 0.1527533871, 0.1527533871, 0.1491729865,
                    0.1420961093, 0.1316886384, 0.1181945320, 0.1019301198,
                    0.0832767416, 0.0626720483, 0.0406014298, 0.0176140071])
    if abs(rho) < 1e-12:
        return _Phi(h) * _Phi(k)
    a = abs(rho)
    s = math.copysign(1.0, rho)
    nodes = 0.5 * (nodes20 + 1.0) * a
    weights = 0.5 * w20 * a

    def f(r):
        denom = math.sqrt(max(1.0 - r * r, 1e-30))
        # apply the sign: integrand uses k* = s*k, since rho = s*|rho|.
        kk = s * k
        return np.exp(-(h * h - 2.0 * r * h * kk + kk * kk) / (2.0 * (1.0 - r * r))) / (2.0 * math.pi * denom)

    integral = np.zeros_like(h * k, dtype=float)
    for r, w in zip(nodes, weights):
        integral = integral + w * f(r)
    if s > 0:
        return _Phi(h) * _Phi(k) + integral
    else:
        return _Phi(h) - integral - _Phi(h) * _Phi(-k)


# ---------------------------------------------------------------------------
# Gaussian copula
# ---------------------------------------------------------------------------

def gaussian_cdf(u: np.ndarray, v: np.ndarray, rho: float) -> np.ndarray:
    return _bvn_cdf(_Phi_inv(u), _Phi_inv(v), rho)


def gaussian_pdf(u: np.ndarray, v: np.ndarray, rho: float) -> np.ndarray:
    if not -1.0 < rho < 1.0:
        raise ValueError("rho must lie in (-1, 1)")
    a = _Phi_inv(np.asarray(u, dtype=float))
    b = _Phi_inv(np.asarray(v, dtype=float))
    one_minus_r2 = 1.0 - rho * rho
    return (1.0 / math.sqrt(one_minus_r2)) * np.exp(
        -(rho * rho * (a * a + b * b) - 2.0 * rho * a * b) / (2.0 * one_minus_r2))


# ---------------------------------------------------------------------------
# Student-t copula
# ---------------------------------------------------------------------------

def _t_pdf_log(x: np.ndarray, nu: float) -> np.ndarray:
    return (gammaln((nu + 1) / 2.0) - gammaln(nu / 2.0)
            - 0.5 * math.log(nu * math.pi)
            - 0.5 * (nu + 1.0) * np.log(1.0 + x * x / nu))


def _t_cdf(x: np.ndarray, nu: float) -> np.ndarray:
    """Student-t CDF using regularised incomplete beta (numpy implementation).

    Computed as 1 - 0.5 * I_{nu/(nu+x^2)}(nu/2, 1/2) for x>0 and 0.5*I(...) for
    x<0.
    """
    x = np.asarray(x, dtype=float)
    out = np.empty_like(x)
    for i, xi in enumerate(x.ravel()):
        z = nu / (nu + xi * xi)
        ib = _reg_inc_beta(z, nu / 2.0, 0.5)
        out.flat[i] = 1.0 - 0.5 * ib if xi > 0 else 0.5 * ib
    return out


def _reg_inc_beta(x: float, a: float, b: float) -> float:
    """Regularised incomplete beta function I_x(a,b) (continued fraction)."""
    if x <= 0:
        return 0.0
    if x >= 1:
        return 1.0
    bt = math.exp(gammaln(a + b) - gammaln(a) - gammaln(b)
                  + a * math.log(x) + b * math.log(1.0 - x))
    if x < (a + 1.0) / (a + b + 2.0):
        return bt * _betacf(x, a, b) / a
    else:
        return 1.0 - bt * _betacf(1.0 - x, b, a) / b


def _betacf(x, a, b, maxit=200, eps=1e-14):
    qab = a + b; qap = a + 1.0; qam = a - 1.0
    c = 1.0
    d = 1.0 - qab * x / qap
    if abs(d) < 1e-30: d = 1e-30
    d = 1.0 / d
    h = d
    for m in range(1, maxit + 1):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d
        if abs(d) < 1e-30: d = 1e-30
        c = 1.0 + aa / c
        if abs(c) < 1e-30: c = 1e-30
        d = 1.0 / d
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1.0 + aa * d
        if abs(d) < 1e-30: d = 1e-30
        c = 1.0 + aa / c
        if abs(c) < 1e-30: c = 1e-30
        d = 1.0 / d
        delta = d * c
        h *= delta
        if abs(delta - 1.0) < eps:
            return h
    return h


def _t_quantile(p: np.ndarray, nu: float) -> np.ndarray:
    """Student-t inverse-CDF by 1-D bisection."""
    p = np.asarray(p, dtype=float)
    out = np.empty_like(p)
    for i, pi in enumerate(p.ravel()):
        if pi <= 0:
            out.flat[i] = -float("inf")
        elif pi >= 1:
            out.flat[i] = float("inf")
        else:
            lo, hi = -50.0, 50.0
            for _ in range(80):
                mid = 0.5 * (lo + hi)
                if _t_cdf(np.array([mid]), nu)[0] < pi:
                    lo = mid
                else:
                    hi = mid
            out.flat[i] = 0.5 * (lo + hi)
    return out


def student_t_pdf(u: np.ndarray, v: np.ndarray, rho: float, nu: float) -> np.ndarray:
    if not -1.0 < rho < 1.0 or nu <= 0:
        raise ValueError("rho in (-1,1), nu > 0 required")
    a = _t_quantile(np.asarray(u, dtype=float), nu)
    b = _t_quantile(np.asarray(v, dtype=float), nu)
    one_minus_r2 = 1.0 - rho * rho
    log_num = (gammaln((nu + 2) / 2.0) + gammaln(nu / 2.0)
               - 2.0 * gammaln((nu + 1) / 2.0)
               - 0.5 * math.log(one_minus_r2)
               - 0.5 * (nu + 2) * np.log(1.0 + (a * a - 2.0 * rho * a * b + b * b) / (nu * one_minus_r2))
               + 0.5 * (nu + 1) * np.log(1.0 + a * a / nu)
               + 0.5 * (nu + 1) * np.log(1.0 + b * b / nu))
    return np.exp(log_num)


def student_t_cdf(u: np.ndarray, v: np.ndarray, rho: float, nu: float) -> np.ndarray:
    """Bivariate t CDF by Monte-Carlo inversion (slow but pure numpy).

    For practical use we recommend `student_t_pdf` for likelihood and
    Monte-Carlo for tail probabilities.
    """
    rng = np.random.default_rng(0)
    n = 50000
    L = np.linalg.cholesky(np.array([[1.0, rho], [rho, 1.0]]))
    z = rng.standard_normal((n, 2)) @ L.T
    chi2 = rng.chisquare(nu, size=n)
    t = z * np.sqrt(nu / chi2[:, None])
    a = _t_quantile(np.asarray(u, dtype=float), nu)
    b = _t_quantile(np.asarray(v, dtype=float), nu)
    out = np.empty_like(a, dtype=float)
    for i in range(out.size):
        out.flat[i] = float(np.mean((t[:, 0] <= a.flat[i]) & (t[:, 1] <= b.flat[i])))
    return out


# ---------------------------------------------------------------------------
# Clayton copula
# ---------------------------------------------------------------------------

def clayton_cdf(u: np.ndarray, v: np.ndarray, theta: float) -> np.ndarray:
    if theta <= 0:
        raise ValueError("Clayton requires theta > 0")
    u = np.asarray(u, dtype=float); v = np.asarray(v, dtype=float)
    inside = np.power(u, -theta) + np.power(v, -theta) - 1.0
    return np.power(np.maximum(inside, 1e-30), -1.0 / theta)


def clayton_pdf(u: np.ndarray, v: np.ndarray, theta: float) -> np.ndarray:
    if theta <= 0:
        raise ValueError("Clayton requires theta > 0")
    u = np.asarray(u, dtype=float); v = np.asarray(v, dtype=float)
    a = np.power(u, -theta) + np.power(v, -theta) - 1.0
    return ((1.0 + theta) * np.power(u * v, -theta - 1.0)
            * np.power(a, -1.0 / theta - 2.0))


# ---------------------------------------------------------------------------
# Gumbel-Hougaard copula
# ---------------------------------------------------------------------------

def gumbel_cdf_copula(u: np.ndarray, v: np.ndarray, theta: float) -> np.ndarray:
    if theta < 1.0:
        raise ValueError("Gumbel-Hougaard requires theta >= 1")
    u = np.asarray(u, dtype=float); v = np.asarray(v, dtype=float)
    a = (-np.log(u)) ** theta + (-np.log(v)) ** theta
    return np.exp(-a ** (1.0 / theta))


def gumbel_pdf_copula(u: np.ndarray, v: np.ndarray, theta: float) -> np.ndarray:
    if theta < 1.0:
        raise ValueError("Gumbel-Hougaard requires theta >= 1")
    u = np.asarray(u, dtype=float); v = np.asarray(v, dtype=float)
    lu = -np.log(u); lv = -np.log(v)
    a = lu ** theta + lv ** theta
    a_pow = a ** (1.0 / theta)
    return (np.exp(-a_pow)
            * (a_pow + theta - 1.0)
            * a_pow ** (1.0 - 2.0 * theta)
            * (lu * lv) ** (theta - 1.0)
            / (u * v))


# ---------------------------------------------------------------------------
# Frank copula
# ---------------------------------------------------------------------------

def frank_cdf(u: np.ndarray, v: np.ndarray, theta: float) -> np.ndarray:
    if abs(theta) < 1e-8:
        return np.asarray(u, dtype=float) * np.asarray(v, dtype=float)
    u = np.asarray(u, dtype=float); v = np.asarray(v, dtype=float)
    eu = np.exp(-theta * u); ev = np.exp(-theta * v); e = math.exp(-theta)
    return -1.0 / theta * np.log(1.0 + (eu - 1.0) * (ev - 1.0) / (e - 1.0))


def frank_pdf(u: np.ndarray, v: np.ndarray, theta: float) -> np.ndarray:
    if abs(theta) < 1e-8:
        return np.ones_like(np.asarray(u, dtype=float))
    u = np.asarray(u, dtype=float); v = np.asarray(v, dtype=float)
    e = math.exp(-theta)
    eu = np.exp(-theta * u); ev = np.exp(-theta * v)
    num = -theta * (e - 1.0) * eu * ev
    den = ((e - 1.0) + (eu - 1.0) * (ev - 1.0)) ** 2
    return num / den


# ---------------------------------------------------------------------------
# Random sampling (used for Monte-Carlo return periods)
# ---------------------------------------------------------------------------

def sample_copula(family: str, theta_or_params, n: int,
                  rng: np.random.Generator) -> Tuple[np.ndarray, np.ndarray]:
    """Draw `n` pairs (U,V) from the named copula. theta_or_params is
    either a scalar (Gaussian rho, Clayton/Gumbel/Frank theta) or a
    tuple (rho, nu) for Student-t.
    """
    family = family.lower()
    if family == "gaussian":
        rho = float(theta_or_params)
        L = np.linalg.cholesky(np.array([[1.0, rho], [rho, 1.0]]))
        z = rng.standard_normal((n, 2)) @ L.T
        return _Phi(z[:, 0]), _Phi(z[:, 1])
    if family in ("student", "t", "student_t"):
        rho, nu = float(theta_or_params[0]), float(theta_or_params[1])
        L = np.linalg.cholesky(np.array([[1.0, rho], [rho, 1.0]]))
        z = rng.standard_normal((n, 2)) @ L.T
        chi2 = rng.chisquare(nu, size=n)
        t = z * np.sqrt(nu / chi2[:, None])
        # transform to U via t-CDF (slow); use empirical for speed
        u = np.array([_t_cdf(np.array([ti]), nu)[0] for ti in t[:, 0]])
        v = np.array([_t_cdf(np.array([ti]), nu)[0] for ti in t[:, 1]])
        return u, v
    if family == "clayton":
        theta = float(theta_or_params)
        u = rng.uniform(size=n)
        w = rng.uniform(size=n)
        # Marshall-Olkin algorithm: V = U; W = (W^(-theta/(1+theta)) - 1) ...
        v = (u ** (-theta) * (w ** (-theta / (1.0 + theta)) - 1.0) + 1.0) ** (-1.0 / theta)
        return u, v
    if family in ("gumbel", "gumbel_hougaard"):
        theta = float(theta_or_params)
        # Use the Marshall-Olkin / stable distribution algorithm.
        u1 = rng.uniform(size=n); u2 = rng.uniform(size=n)
        # generator inverse for Gumbel: psi(t) = exp(-t^{1/theta})
        # sample via Frechet trick (Genest & MacKay 1986)
        e1 = -np.log(u1); e2 = -np.log(u2)
        # The standard rejection method for Gumbel-Hougaard (Genest 1987):
        gamma_a = rng.uniform(low=0, high=math.pi, size=n)
        E = rng.exponential(size=n)
        S = (np.sin((1.0 - 1.0 / theta) * gamma_a)
             * np.sin(gamma_a / theta) ** (theta - 1)) ** (1.0 / theta) \
            * np.sin(gamma_a) ** (-1) * (np.sin(gamma_a) / E) ** ((theta - 1) / theta)
        u = np.exp(-(e1 / S) ** (1.0 / theta))
        v = np.exp(-(e2 / S) ** (1.0 / theta))
        return u, v
    if family == "frank":
        theta = float(theta_or_params)
        u = rng.uniform(size=n)
        w = rng.uniform(size=n)
        if abs(theta) < 1e-8:
            return u, w
        emt = math.exp(-theta)
        v = -1.0 / theta * np.log(1.0 + w * (1.0 - emt)
                                  / (np.exp(-theta * u) * (w - 1.0) - w))
        return u, np.clip(v, 1e-12, 1 - 1e-12)
    raise ValueError(f"unknown family {family!r}")


# ---------------------------------------------------------------------------
# Convenience: dispatch table for CDF / PDF
# ---------------------------------------------------------------------------

CDF_TABLE = {
    "gaussian": gaussian_cdf,
    "clayton": clayton_cdf,
    "gumbel": gumbel_cdf_copula,
    "frank": frank_cdf,
}
PDF_TABLE = {
    "gaussian": gaussian_pdf,
    "clayton": clayton_pdf,
    "gumbel": gumbel_pdf_copula,
    "frank": frank_pdf,
    "student_t": student_t_pdf,
}

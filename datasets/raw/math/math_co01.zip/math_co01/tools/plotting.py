"""Matplotlib plotting helpers; every function returns {"path": <png>}."""
from __future__ import annotations

from typing import Dict, Iterable, List, Tuple

import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


def plot_rank_scatter(x: np.ndarray, y: np.ndarray,
                      title: str, out_path: str,
                      xlabel: str = "rank(X)", ylabel: str = "rank(Y)",
                      figsize=(5.5, 5.5)) -> Dict[str, str]:
    """Scatter plot of pseudo-observations U=R/(n+1), V=S/(n+1)."""
    from .rank_dependence import pseudo_observations
    po = pseudo_observations(x, y)
    fig, ax = plt.subplots(figsize=figsize)
    ax.scatter(po["U"], po["V"], s=24, c="#264653", alpha=0.75)
    ax.plot([0, 1], [0, 1], "k--", alpha=0.4)
    ax.set_xlim(0, 1); ax.set_ylim(0, 1)
    ax.set_xlabel(xlabel); ax.set_ylabel(ylabel)
    ax.set_title(title); ax.grid(alpha=0.3)
    fig.tight_layout(); fig.savefig(out_path, dpi=140); plt.close(fig)
    return {"path": out_path}


def plot_data_scatter(x: np.ndarray, y: np.ndarray,
                      title: str, out_path: str,
                      xlabel: str = "Annual peak X (m^3/s)",
                      ylabel: str = "Spring volume Y (hm^3)",
                      figsize=(6.5, 5)) -> Dict[str, str]:
    fig, ax = plt.subplots(figsize=figsize)
    ax.scatter(x, y, s=30, c="#2a9d8f", edgecolor="k", linewidth=0.4, alpha=0.85)
    ax.set_xlabel(xlabel); ax.set_ylabel(ylabel)
    ax.set_title(title); ax.grid(alpha=0.3)
    fig.tight_layout(); fig.savefig(out_path, dpi=140); plt.close(fig)
    return {"path": out_path}


def plot_copula_simulation(family: str, theta_or_params,
                           x: np.ndarray, y: np.ndarray,
                           n_sim: int, seed: int,
                           title: str, out_path: str,
                           figsize=(6, 5.5)) -> Dict[str, str]:
    """Overlay observed pseudo-observations with simulated points from the
    fitted copula on the unit square (Fig. 13 in Genest & Favre 2007).
    """
    from . import copula_families as cf
    from .rank_dependence import pseudo_observations
    rng = np.random.default_rng(seed)
    Us, Vs = cf.sample_copula(family, theta_or_params, n_sim, rng)
    po = pseudo_observations(x, y)
    fig, ax = plt.subplots(figsize=figsize)
    ax.scatter(Us, Vs, s=4, c="#bbbbbb", alpha=0.45, label=f"sim from {family}")
    ax.scatter(po["U"], po["V"], s=42, marker="x", c="#e76f51",
               linewidth=1.5, label="observed ranks")
    ax.set_xlim(0, 1); ax.set_ylim(0, 1)
    ax.set_xlabel("U = F_X(x)"); ax.set_ylabel("V = F_Y(y)")
    ax.set_title(title); ax.legend(loc="upper left")
    ax.grid(alpha=0.3)
    fig.tight_layout(); fig.savefig(out_path, dpi=140); plt.close(fig)
    return {"path": out_path}


def plot_aic_bar(aic_rows: List[Dict], title: str, out_path: str,
                 figsize=(6, 4)) -> Dict[str, str]:
    fams = [r["family"] for r in aic_rows]
    aics = [r["aic"] for r in aic_rows]
    fig, ax = plt.subplots(figsize=figsize)
    bars = ax.barh(fams, aics, color="#264653")
    for b, a in zip(bars, aics):
        ax.text(a, b.get_y() + b.get_height() / 2, f"  {a:.2f}",
                va="center", fontsize=9)
    ax.set_xlabel("AIC"); ax.set_title(title); ax.grid(alpha=0.3, axis="x")
    fig.tight_layout(); fig.savefig(out_path, dpi=140); plt.close(fig)
    return {"path": out_path}


def plot_tail_dependence(u_grid: np.ndarray, lamL: np.ndarray, lamU: np.ndarray,
                         lamL_param: float, lamU_param: float,
                         title: str, out_path: str,
                         figsize=(7, 4.5)) -> Dict[str, str]:
    fig, ax = plt.subplots(figsize=figsize)
    ax.plot(u_grid, lamL, "-", color="#264653", label="empirical lambda_L(u)")
    ax.plot(u_grid, lamU, "-", color="#e76f51", label="empirical lambda_U(u)")
    ax.axhline(lamL_param, ls="--", color="#264653", alpha=0.7,
               label=f"parametric lambda_L = {lamL_param:.3f}")
    ax.axhline(lamU_param, ls="--", color="#e76f51", alpha=0.7,
               label=f"parametric lambda_U = {lamU_param:.3f}")
    ax.set_xlabel("threshold u"); ax.set_ylabel("tail dependence")
    ax.set_title(title); ax.set_ylim(0, 1)
    ax.grid(alpha=0.3); ax.legend(fontsize=8)
    fig.tight_layout(); fig.savefig(out_path, dpi=140); plt.close(fig)
    return {"path": out_path}


def plot_joint_return_contour(x_grid: np.ndarray, y_grid: np.ndarray,
                              T_grid: np.ndarray,
                              x_obs: np.ndarray, y_obs: np.ndarray,
                              levels: List[float],
                              title: str, out_path: str,
                              xlabel: str = "Annual peak X (m^3/s)",
                              ylabel: str = "Spring volume Y (hm^3)",
                              figsize=(7, 5.5)) -> Dict[str, str]:
    fig, ax = plt.subplots(figsize=figsize)
    cs = ax.contour(x_grid, y_grid, T_grid.T, levels=levels, colors="#264653")
    ax.clabel(cs, fmt="%g yr", fontsize=8)
    ax.scatter(x_obs, y_obs, s=24, c="#e76f51", edgecolor="k", linewidth=0.4,
               alpha=0.85, label="observed")
    ax.set_xlabel(xlabel); ax.set_ylabel(ylabel)
    ax.set_title(title); ax.grid(alpha=0.3); ax.legend()
    fig.tight_layout(); fig.savefig(out_path, dpi=140); plt.close(fig)
    return {"path": out_path}


def plot_marginal_qq(x: np.ndarray, theoretical_q: np.ndarray,
                     title: str, out_path: str,
                     xlabel: str = "Theoretical quantile",
                     ylabel: str = "Empirical quantile",
                     figsize=(5.5, 5.5)) -> Dict[str, str]:
    x = np.sort(np.asarray(x, dtype=float))
    fig, ax = plt.subplots(figsize=figsize)
    ax.plot(theoretical_q, x, "o", color="#264653", markersize=4)
    lo = min(theoretical_q.min(), x.min()); hi = max(theoretical_q.max(), x.max())
    ax.plot([lo, hi], [lo, hi], "--", color="#e76f51")
    ax.set_xlabel(xlabel); ax.set_ylabel(ylabel)
    ax.set_title(title); ax.grid(alpha=0.3)
    fig.tight_layout(); fig.savefig(out_path, dpi=140); plt.close(fig)
    return {"path": out_path}


def plot_time_series(years: np.ndarray, values: np.ndarray,
                     title: str, out_path: str,
                     ylabel: str, figsize=(8, 3.5)) -> Dict[str, str]:
    fig, ax = plt.subplots(figsize=figsize)
    ax.plot(years, values, "o-", color="#2a9d8f", lw=1, markersize=4)
    ax.set_xlabel("Year"); ax.set_ylabel(ylabel); ax.set_title(title)
    ax.grid(alpha=0.3)
    fig.tight_layout(); fig.savefig(out_path, dpi=140); plt.close(fig)
    return {"path": out_path}

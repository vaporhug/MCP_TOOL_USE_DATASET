"""Tool package for the Harricana copula bivariate frequency-analysis task.

Sub-modules:
    data_loader        - load CSV data into numpy arrays / pandas frames
    marginals          - empirical CDF and parametric marginal MLE (Gumbel, Gamma, Lognormal, Normal)
    rank_dependence    - Kendall's tau, Spearman's rho with closed-form variances
    copula_families    - CDF and PDF for Gaussian, Student-t, Clayton, Gumbel-Hougaard, Frank
    copula_inference   - method-of-moments and maximum-pseudolikelihood fits, AIC/BIC, IC bootstrap
    tail_dependence    - lower and upper tail dependence coefficients (closed form per family)
    return_periods     - bivariate AND/OR joint return periods, conditional CDFs, design events
    plotting           - matplotlib plots, each function returns {"path": <png>}

All tools are pure-numpy / scipy.optimize.minimize; none import scipy.stats.
"""

"""Univariate marginal-distribution primitives.

Implements the Gumbel, Gamma, Lognormal and Normal CDF/PDF and a
maximum-likelihood estimator for each, plus an empirical-CDF helper
based on the Weibull plotting position used in the target paper.

Uses scipy.optimize.minimize and scipy.special.gammaln only; no
scipy.stats dependency.
"""
from __future__ import annotations

import math
from typing import Dict

import numpy as np
from scipy.optimize import minimize
from scipy.special import gammaln, erf, erfc

_BIG = 1e10
_SQRT2 = math.sqrt(2.0)


def empirical_cdf_weibull(x: np.ndarray) -> np.ndarray:
    """Weibull plotting position: F_n(x_(i)) = i / (n+1).

    Returned array is in the original (unsorted) order of `x`, so it can
    be passed straight to a copula likelihood as the pseudo-observation U.
    """
    x = np.asarray(x, dtype=float)
    n = len(x)
    order = np.argsort(x, kind="mergesort")
    rank = np.empty(n, dtype=int)
    rank[order] = np.arange(1, n + 1)
    return rank / (n + 1.0)


# ---------------------------------------------------------------------------
# Gumbel (extreme-value type I) -- used for peak X in the paper
# ---------------------------------------------------------------------------

def gumbel_cdf(x: np.ndarray, mu: float, beta: float) -> np.ndarray:
    """Gumbel maximum CDF: F(x) = exp{-exp(-(x-mu)/beta)}, beta > 0."""
    x = np.asarray(x, dtype=float)
    z = (x - mu) / beta
    return np.exp(-np.exp(-z))


def gumbel_pdf(x: np.ndarray, mu: float, beta: float) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    z = (x - mu) / beta
    return (1.0 / beta) * np.exp(-z - np.exp(-z))


def fit_gumbel_mle(x: np.ndarray) -> Dict[str, float]:
    x = np.asarray(x, dtype=float)
    x = x[~np.isnan(x)]
    s0 = float(np.std(x) * math.sqrt(6) / math.pi)
    m0 = float(np.mean(x) - 0.5772 * s0)

    def nll(p):
        mu, log_beta = p
        beta = math.exp(log_beta)
        if beta <= 0:
            return _BIG
        z = (x - mu) / beta
        return float(np.sum(np.log(beta) + z + np.exp(-z)))

    res = minimize(nll, [m0, math.log(s0)], method="Nelder-Mead",
                   options={"xatol": 1e-7, "fatol": 1e-7, "maxiter": 5000})
    mu, lb = res.x
    return {"mu": float(mu), "beta": float(math.exp(lb)),
            "nll": float(res.fun), "n": int(len(x)), "k": 2,
            "aic": 2.0 * res.fun + 2 * 2,
            "bic": 2.0 * res.fun + 2 * math.log(len(x)),
            "converged": bool(res.success)}


# ---------------------------------------------------------------------------
# Gamma -- used for volume Y in the paper
# ---------------------------------------------------------------------------

def gamma_pdf(x: np.ndarray, shape: float, scale: float) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    out = np.zeros_like(x)
    msk = x > 0
    z = x[msk] / scale
    out[msk] = np.exp(-z + (shape - 1) * np.log(z) - gammaln(shape) - math.log(scale))
    return out


def _gamma_lower_inc_regularised(s: float, x: np.ndarray) -> np.ndarray:
    """P(s,x) = lower regularised incomplete gamma via series + continued
    fraction. No scipy.stats dependency.
    """
    x = np.asarray(x, dtype=float)
    out = np.zeros_like(x)
    msk = x > 0
    if not np.any(msk):
        return out
    xv = x[msk]
    pv = np.empty_like(xv)
    for i, xi in enumerate(xv):
        if xi < s + 1.0:
            term = 1.0 / s
            sum_ = term
            ap = s
            for _ in range(200):
                ap += 1.0
                term *= xi / ap
                sum_ += term
                if abs(term) < abs(sum_) * 1e-12:
                    break
            pv[i] = sum_ * math.exp(-xi + s * math.log(xi) - gammaln(s))
        else:
            # Lentz's continued fraction for upper incomplete -> Q
            b = xi + 1.0 - s
            c = 1e30
            d = 1.0 / b
            h = d
            for k in range(1, 200):
                an = -k * (k - s)
                b += 2.0
                d = an * d + b
                if abs(d) < 1e-30:
                    d = 1e-30
                c = b + an / c
                if abs(c) < 1e-30:
                    c = 1e-30
                d = 1.0 / d
                delta = d * c
                h *= delta
                if abs(delta - 1.0) < 1e-12:
                    break
            q = math.exp(-xi + s * math.log(xi) - gammaln(s)) * h
            pv[i] = 1.0 - q
    out[msk] = pv
    return out


def gamma_cdf(x: np.ndarray, shape: float, scale: float) -> np.ndarray:
    """Lower regularised incomplete gamma evaluated at x/scale."""
    x = np.asarray(x, dtype=float)
    return _gamma_lower_inc_regularised(shape, x / scale)


def fit_gamma_mle(x: np.ndarray) -> Dict[str, float]:
    x = np.asarray(x, dtype=float)
    x = x[(~np.isnan(x)) & (x > 0)]
    m = float(np.mean(x)); v = float(np.var(x))
    s0 = max(m * m / v, 0.5); sc0 = max(v / m, 1e-3)

    def nll(p):
        log_s, log_sc = p
        s = math.exp(log_s); sc = math.exp(log_sc)
        if s <= 0 or sc <= 0:
            return _BIG
        return float(np.sum(-(s - 1) * np.log(x) + x / sc + s * math.log(sc) + gammaln(s)))

    res = minimize(nll, [math.log(s0), math.log(sc0)], method="Nelder-Mead",
                   options={"xatol": 1e-7, "fatol": 1e-7, "maxiter": 5000})
    ls, lsc = res.x
    s = math.exp(ls); sc = math.exp(lsc)
    return {"shape": float(s), "scale": float(sc),
            "nll": float(res.fun), "n": int(len(x)), "k": 2,
            "aic": 2.0 * res.fun + 2 * 2,
            "bic": 2.0 * res.fun + 2 * math.log(len(x)),
            "converged": bool(res.success)}


# ---------------------------------------------------------------------------
# Lognormal and normal (provided as competing margins for AIC comparison)
# ---------------------------------------------------------------------------

def normal_cdf(x: np.ndarray, mu: float, sigma: float) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    return 0.5 * (1.0 + erf((x - mu) / (sigma * _SQRT2)))


def normal_pdf(x: np.ndarray, mu: float, sigma: float) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    return np.exp(-0.5 * ((x - mu) / sigma) ** 2) / (sigma * math.sqrt(2 * math.pi))


def fit_normal_mle(x: np.ndarray) -> Dict[str, float]:
    x = np.asarray(x, dtype=float)
    x = x[~np.isnan(x)]
    n = len(x); mu = float(np.mean(x)); sigma = float(np.std(x, ddof=0))
    nll = 0.5 * n * math.log(2 * math.pi * sigma * sigma) + 0.5 * np.sum(((x - mu) / sigma) ** 2)
    return {"mu": mu, "sigma": sigma, "nll": float(nll), "n": n, "k": 2,
            "aic": 2.0 * nll + 2 * 2, "bic": 2.0 * nll + 2 * math.log(n),
            "converged": True}


def lognormal_cdf(x: np.ndarray, mu_log: float, sigma_log: float) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    out = np.zeros_like(x)
    msk = x > 0
    out[msk] = 0.5 * (1.0 + erf((np.log(x[msk]) - mu_log) / (sigma_log * _SQRT2)))
    return out


def lognormal_pdf(x: np.ndarray, mu_log: float, sigma_log: float) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    out = np.zeros_like(x)
    msk = x > 0
    out[msk] = (1.0 / (x[msk] * sigma_log * math.sqrt(2 * math.pi))) * \
        np.exp(-0.5 * ((np.log(x[msk]) - mu_log) / sigma_log) ** 2)
    return out


def fit_lognormal_mle(x: np.ndarray) -> Dict[str, float]:
    x = np.asarray(x, dtype=float)
    x = x[(~np.isnan(x)) & (x > 0)]
    n = len(x); lx = np.log(x)
    mu = float(np.mean(lx)); sigma = float(np.std(lx, ddof=0))
    nll = 0.5 * n * math.log(2 * math.pi * sigma * sigma) + 0.5 * np.sum(((lx - mu) / sigma) ** 2) + float(np.sum(lx))
    return {"mu_log": mu, "sigma_log": sigma, "nll": float(nll), "n": n, "k": 2,
            "aic": 2.0 * nll + 2 * 2, "bic": 2.0 * nll + 2 * math.log(n),
            "converged": True}


# ---------------------------------------------------------------------------
# Univariate inverse CDF (used for return-period analysis)
# ---------------------------------------------------------------------------

def gumbel_inv_cdf(p: np.ndarray, mu: float, beta: float) -> np.ndarray:
    p = np.asarray(p, dtype=float)
    return mu - beta * np.log(-np.log(p))


def gamma_inv_cdf(p: np.ndarray, shape: float, scale: float) -> np.ndarray:
    """Inverse of `gamma_cdf` by 1-D bracketing/bisection (no scipy.stats)."""
    p = np.asarray(p, dtype=float)
    out = np.zeros_like(p)
    for i, pi in enumerate(p.ravel()):
        if pi <= 0 or pi >= 1:
            out.flat[i] = float("nan"); continue
        lo, hi = 1e-8, max(shape * scale * 50.0, 1.0)
        # widen if needed
        for _ in range(60):
            if gamma_cdf(np.array([hi]), shape, scale)[0] >= pi:
                break
            hi *= 2.0
        for _ in range(80):
            mid = 0.5 * (lo + hi)
            if gamma_cdf(np.array([mid]), shape, scale)[0] < pi:
                lo = mid
            else:
                hi = mid
        out.flat[i] = 0.5 * (lo + hi)
    return out


def aic_compare_marginals(x: np.ndarray, label: str) -> Dict[str, Dict[str, float]]:
    """Fit Gumbel, Gamma, Lognormal, Normal to `x` and return their fits +
    AIC values in a dict keyed by family name (always uses MLE)."""
    out = {}
    out["Gumbel"] = fit_gumbel_mle(x)
    try:
        out["Gamma"] = fit_gamma_mle(x)
    except Exception as e:
        out["Gamma"] = {"error": str(e)}
    out["Lognormal"] = fit_lognormal_mle(x)
    out["Normal"] = fit_normal_mle(x)
    out["_label"] = label
    return out

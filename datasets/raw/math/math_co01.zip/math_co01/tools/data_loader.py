"""Data-loading primitives for the Harricana bivariate copula task.

These helpers do not contain domain logic beyond deciding which numeric
columns to extract; the agent is expected to compose them with the
analytical tools.
"""
from __future__ import annotations

import os
from typing import Dict, Tuple

import numpy as np
import pandas as pd


def load_annual_series(csv_path: str) -> pd.DataFrame:
    """Load the per-year peak/volume table.

    The expected CSV has columns
        year, peak_flow_m3_per_s, spring_volume_hm3, n_daily_obs_year, n_daily_obs_spring.

    Returns a pandas DataFrame sorted by year with no NaN rows.
    """
    if not os.path.isfile(csv_path):
        raise FileNotFoundError(csv_path)
    df = pd.read_csv(csv_path)
    required = {"year", "peak_flow_m3_per_s", "spring_volume_hm3"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"missing columns: {missing}")
    df = df.dropna(subset=["peak_flow_m3_per_s", "spring_volume_hm3"]).copy()
    df = df.sort_values("year").reset_index(drop=True)
    return df


def load_daily_discharge(csv_path: str) -> pd.DataFrame:
    """Load the raw daily-discharge file (only DATE, DISCHARGE columns kept)."""
    if not os.path.isfile(csv_path):
        raise FileNotFoundError(csv_path)
    df = pd.read_csv(csv_path, usecols=["DATE", "DISCHARGE"])
    df["DATE"] = pd.to_datetime(df["DATE"])
    df = df.dropna(subset=["DISCHARGE"]).reset_index(drop=True)
    return df


def load_station_metadata(csv_path: str) -> Dict[str, object]:
    """Read the single-row station metadata CSV into a plain dict."""
    if not os.path.isfile(csv_path):
        raise FileNotFoundError(csv_path)
    df = pd.read_csv(csv_path)
    if len(df) != 1:
        raise ValueError(f"expected exactly 1 row in {csv_path}, got {len(df)}")
    return df.iloc[0].to_dict()


def split_xy(df: pd.DataFrame,
             col_x: str = "peak_flow_m3_per_s",
             col_y: str = "spring_volume_hm3"
             ) -> Tuple[np.ndarray, np.ndarray]:
    """Convert a DataFrame to two 1-D float arrays (X, Y) for analysis."""
    x = np.asarray(df[col_x].values, dtype=float)
    y = np.asarray(df[col_y].values, dtype=float)
    return x, y


def aggregate_daily_to_annual(daily: pd.DataFrame,
                              spring_months: Tuple[int, ...] = (3, 4, 5, 6, 7),
                              min_days_year: int = 350,
                              min_days_spring: int = 100,
                              ) -> pd.DataFrame:
    """Reduce daily discharges to the bivariate annual table (X = annual peak,
    Y = sum of spring-flood daily flows expressed as a volume in hm3).

    Volume in hm3 = sum(Q [m3/s]) * 86400 [s/day] / 1e6 [m3 per hm3].

    Years that lack enough observations in either season are dropped.
    """
    daily = daily.copy()
    daily["year"] = daily["DATE"].dt.year
    daily["month"] = daily["DATE"].dt.month
    rows = []
    for y, g in daily.groupby("year"):
        g_year = g
        g_spring = g[g["month"].isin(spring_months)]
        if len(g_year) < min_days_year or len(g_spring) < min_days_spring:
            continue
        peak = float(np.max(g_year["DISCHARGE"].values))
        vol = float(np.sum(g_spring["DISCHARGE"].values)) * 86400.0 / 1e6
        rows.append({"year": int(y), "peak_flow_m3_per_s": peak,
                     "spring_volume_hm3": vol,
                     "n_daily_obs_year": int(len(g_year)),
                     "n_daily_obs_spring": int(len(g_spring))})
    return pd.DataFrame(rows).sort_values("year").reset_index(drop=True)

"""Closed-form lower- and upper-tail dependence coefficients.

For each one-parameter copula family that the agent fits, the tail
dependence coefficient is given (Joe 1997, Nelsen 2006) by:

    Family            lambda_L              lambda_U
    Gaussian          0                     0
    Student-t         2 * t_{nu+1}(...)     same; symmetric
    Clayton           2^{-1/theta}          0
    Gumbel-Hougaard   0                     2 - 2^{1/theta}
    Frank             0                     0

We also expose an empirical estimator using the threshold limit
    lambda_L ~ C(u,u)/u   as u -> 0,
    lambda_U ~ (1 - 2u + C(u,u))/(1 - u)  as u -> 1.
"""
from __future__ import annotations

import math
from typing import Dict, Tuple

import numpy as np

from . import copula_families as cf
from . import rank_dependence as rd


def parametric_tail_dependence(family: str, theta: float,
                               nu: float = None) -> Dict[str, float]:
    family = family.lower()
    if family == "gaussian":
        return {"lambda_L": 0.0, "lambda_U": 0.0}
    if family == "clayton":
        if theta <= 0:
            return {"lambda_L": 0.0, "lambda_U": 0.0}
        return {"lambda_L": 2.0 ** (-1.0 / theta), "lambda_U": 0.0}
    if family in ("gumbel", "gumbel_hougaard"):
        if theta < 1.0:
            return {"lambda_L": 0.0, "lambda_U": 0.0}
        return {"lambda_L": 0.0, "lambda_U": 2.0 - 2.0 ** (1.0 / theta)}
    if family == "frank":
        return {"lambda_L": 0.0, "lambda_U": 0.0}
    if family in ("student", "t", "student_t"):
        # Symmetric tail dependence; lambda = 2 * t_{nu+1}(-sqrt((nu+1)*(1-rho)/(1+rho)))
        if nu is None:
            raise ValueError("student_t needs nu")
        rho = float(theta)
        from scipy.special import gammaln
        # t_{nu+1} CDF via numerical integration of pdf
        arg = -math.sqrt((nu + 1.0) * (1.0 - rho) / (1.0 + rho))
        # 1-D Simpson integration of pdf from -50 to arg
        xs = np.linspace(-50.0, arg, 4001)
        log_pdf = (gammaln((nu + 2) / 2.0) - gammaln((nu + 1) / 2.0)
                   - 0.5 * math.log((nu + 1) * math.pi)
                   - 0.5 * (nu + 2) * np.log(1.0 + xs * xs / (nu + 1)))
        cdf = float(np.trapz(np.exp(log_pdf), xs))
        return {"lambda_L": 2.0 * cdf, "lambda_U": 2.0 * cdf}
    raise ValueError(f"unknown family {family!r}")


def empirical_tail_dependence(x: np.ndarray, y: np.ndarray,
                              u_grid: np.ndarray = None
                              ) -> Dict[str, np.ndarray]:
    """Estimate lambda_L(u) and lambda_U(u) on a grid of thresholds u.

    Uses pseudo-observations and the empirical copula:
        lambda_L(u) = C_n(u, u) / u
        lambda_U(u) = (1 - 2u + C_n(u, u)) / (1 - u)
    """
    po = rd.pseudo_observations(x, y)
    U, V = po["U"], po["V"]
    n = len(U)
    if u_grid is None:
        u_grid = np.linspace(0.02, 0.5, 25)
    lamL = np.zeros_like(u_grid); lamU = np.zeros_like(u_grid)
    for i, u in enumerate(u_grid):
        Cn_l = float(np.mean((U <= u) & (V <= u)))
        Cn_u = float(np.mean((U <= 1 - u) & (V <= 1 - u)))
        lamL[i] = Cn_l / u
        lamU[i] = (1.0 - 2.0 * (1 - u) + Cn_u) / u  # because (1-u) is the upper threshold
    return {"u_grid": u_grid, "lambda_L_emp": lamL,
            "lambda_U_emp": lamU,
            "u_grid_upper": 1.0 - u_grid}


def chi_function(x: np.ndarray, y: np.ndarray, side: str = "upper",
                 u_grid: np.ndarray = None) -> Dict[str, np.ndarray]:
    """The chi(u) function of Coles, Heffernan, Tawn 1999.

    Upper tail:  chi_U(u) = 2 - log(C_n(u,u)) / log(u)   for u close to 1.
    Lower tail:  chi_L(u) = 2 - log(C_n(u,u)) / log(u)   for u close to 0.
    """
    po = rd.pseudo_observations(x, y)
    U, V = po["U"], po["V"]
    if u_grid is None:
        u_grid = np.linspace(0.02, 0.49, 25)
    chi = np.zeros_like(u_grid)
    if side == "lower":
        for i, u in enumerate(u_grid):
            Cn = float(np.mean((U <= u) & (V <= u)))
            if Cn <= 0 or u <= 0:
                chi[i] = float("nan")
            else:
                chi[i] = 2.0 - math.log(Cn) / math.log(u)
        return {"u_grid": u_grid, "chi": chi}
    else:
        for i, u in enumerate(u_grid):
            uu = 1.0 - u
            Cn = float(np.mean((U <= uu) & (V <= uu)))
            if Cn <= 0 or uu <= 0:
                chi[i] = float("nan")
            else:
                chi[i] = 2.0 - math.log(Cn) / math.log(uu)
        return {"u_grid": 1.0 - u_grid, "chi": chi}

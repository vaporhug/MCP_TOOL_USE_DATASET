"""Variogram estimation and fitting tools for geostatistical analysis."""

import numpy as np
from typing import Dict, Tuple, Optional
from scipy.optimize import curve_fit


def compute_empirical_variogram(
    lats: np.ndarray,
    lons: np.ndarray,
    values: np.ndarray,
    n_bins: int = 15,
    max_dist: Optional[float] = None,
    max_pairs: int = 2_000_000,
    random_state: Optional[int] = 0,
) -> Dict[str, np.ndarray]:
    """Compute the empirical (experimental) semivariogram.

    Uses Matheron's classical estimator: gamma(h) = (1/2N(h)) * sum(z(si) - z(sj))^2

    The pairwise differences are computed in a vectorized fashion. When the number
    of unique pairs n*(n-1)/2 exceeds ``max_pairs``, a uniform random sample of
    ``max_pairs`` pairs is used so the cost stays bounded (avoiding the O(n^2)
    materialization that is infeasible for tens of thousands of grid cells). For
    small n the full set of pairs is used exactly.

    Args:
        lats: Array of latitudes (degrees).
        lons: Array of longitudes (degrees).
        values: Array of observed values.
        n_bins: Number of distance bins.
        max_dist: Maximum distance to consider (in coordinate units).
                  Defaults to half the maximum sampled pairwise distance.
        max_pairs: Maximum number of point pairs to evaluate.
        random_state: Seed for reproducible pair sampling (None for nondeterministic).

    Returns:
        Dictionary with keys:
            'lag': bin center distances,
            'semivariance': estimated semivariance per bin,
            'n_pairs': number of pairs per bin.
    """
    coords = np.column_stack([np.asarray(lats, float), np.asarray(lons, float)])
    values = np.asarray(values, dtype=float)
    n = len(values)
    total_pairs = n * (n - 1) // 2

    rng = np.random.default_rng(random_state)

    if total_pairs <= max_pairs:
        # Exact: all unique upper-triangle pairs, vectorized.
        i_idx, j_idx = np.triu_indices(n, k=1)
    else:
        # Sample random unordered pairs (i < j) without forming the full matrix.
        n_sample = max_pairs
        i_idx = rng.integers(0, n, size=n_sample)
        j_idx = rng.integers(0, n, size=n_sample)
        keep = i_idx != j_idx
        i_idx, j_idx = i_idx[keep], j_idx[keep]
        swap = i_idx > j_idx
        i_idx[swap], j_idx[swap] = j_idx[swap], i_idx[swap]

    diff_coords = coords[i_idx] - coords[j_idx]
    dists = np.sqrt(np.einsum("ij,ij->i", diff_coords, diff_coords))
    sq_diffs = (values[i_idx] - values[j_idx]) ** 2

    if max_dist is None:
        max_dist = dists.max() / 2

    bin_edges = np.linspace(0, max_dist, n_bins + 1)
    lag = np.zeros(n_bins)
    semivariance = np.zeros(n_bins)
    n_pairs = np.zeros(n_bins, dtype=int)

    for b in range(n_bins):
        mask = (dists >= bin_edges[b]) & (dists < bin_edges[b + 1])
        n_pairs[b] = mask.sum()
        if n_pairs[b] > 0:
            lag[b] = dists[mask].mean()
            semivariance[b] = sq_diffs[mask].mean() / 2.0
        else:
            lag[b] = (bin_edges[b] + bin_edges[b + 1]) / 2.0

    return {"lag": lag, "semivariance": semivariance, "n_pairs": n_pairs}


def spherical_model(h: np.ndarray, nugget: float, sill: float, range_param: float) -> np.ndarray:
    """Spherical variogram model.

    Args:
        h: Distance (lag) values.
        nugget: Nugget effect (y-intercept).
        sill: Total sill (nugget + partial sill).
        range_param: Range parameter (distance at which semivariance reaches sill).

    Returns:
        Modeled semivariance values.
    """
    result = np.where(
        h == 0,
        0.0,
        np.where(
            h <= range_param,
            nugget + (sill - nugget) * (1.5 * h / range_param - 0.5 * (h / range_param) ** 3),
            sill,
        ),
    )
    return result


def exponential_model(h: np.ndarray, nugget: float, sill: float, range_param: float) -> np.ndarray:
    """Exponential variogram model.

    Args:
        h: Distance (lag) values.
        nugget: Nugget effect.
        sill: Total sill.
        range_param: Effective range parameter.

    Returns:
        Modeled semivariance values.
    """
    return np.where(h == 0, 0.0, nugget + (sill - nugget) * (1 - np.exp(-3 * h / range_param)))


def gaussian_model(h: np.ndarray, nugget: float, sill: float, range_param: float) -> np.ndarray:
    """Gaussian variogram model.

    Args:
        h: Distance (lag) values.
        nugget: Nugget effect.
        sill: Total sill.
        range_param: Effective range parameter.

    Returns:
        Modeled semivariance values.
    """
    return np.where(h == 0, 0.0, nugget + (sill - nugget) * (1 - np.exp(-3 * (h / range_param) ** 2)))


def fit_variogram_model(
    lag: np.ndarray,
    semivariance: np.ndarray,
    model: str = "spherical",
    n_pairs: Optional[np.ndarray] = None,
) -> Dict[str, float]:
    """Fit a theoretical variogram model to empirical semivariance data.

    Args:
        lag: Lag distance values.
        semivariance: Empirical semivariance values.
        model: Model type - 'spherical', 'exponential', or 'gaussian'.
        n_pairs: Number of pairs per bin (used as weights if provided).

    Returns:
        Dictionary with 'nugget', 'sill', 'range', 'model', and 'rmse'.
    """
    model_funcs = {
        "spherical": spherical_model,
        "exponential": exponential_model,
        "gaussian": gaussian_model,
    }
    func = model_funcs[model]

    # Initial guesses
    nugget0 = semivariance[0] if semivariance[0] > 0 else 0.0
    sill0 = semivariance.max()
    range0 = lag[len(lag) // 2]

    # Filter out zero-pair bins
    mask = semivariance > 0
    if n_pairs is not None:
        mask = mask & (n_pairs > 0)

    try:
        sigma = None
        if n_pairs is not None:
            w = np.sqrt(n_pairs[mask].astype(float))
            w[w == 0] = 1
            sigma = 1.0 / w

        popt, _ = curve_fit(
            func,
            lag[mask],
            semivariance[mask],
            p0=[nugget0, sill0, range0],
            bounds=([0, 0, 0], [np.inf, np.inf, np.inf]),
            sigma=sigma,
            maxfev=5000,
        )
        fitted = func(lag[mask], *popt)
        rmse = np.sqrt(np.mean((semivariance[mask] - fitted) ** 2))
    except RuntimeError:
        popt = [nugget0, sill0, range0]
        rmse = np.nan

    return {
        "nugget": float(popt[0]),
        "sill": float(popt[1]),
        "range": float(popt[2]),
        "model": model,
        "rmse": float(rmse),
    }

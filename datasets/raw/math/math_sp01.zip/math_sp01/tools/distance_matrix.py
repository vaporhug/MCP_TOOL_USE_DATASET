"""Distance matrix computation tools for spatial point data."""

import numpy as np
import pandas as pd
from typing import Optional


def haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Compute the great-circle distance between two points on Earth.

    Uses the Haversine formula with Earth radius = 6371 km.

    Args:
        lat1: Latitude of point 1 in degrees.
        lon1: Longitude of point 1 in degrees.
        lat2: Latitude of point 2 in degrees.
        lon2: Longitude of point 2 in degrees.

    Returns:
        Distance in kilometers.
    """
    R = 6371.0
    lat1_r, lon1_r = np.radians(lat1), np.radians(lon1)
    lat2_r, lon2_r = np.radians(lat2), np.radians(lon2)
    dlat = lat2_r - lat1_r
    dlon = lon2_r - lon1_r
    a = np.sin(dlat / 2) ** 2 + np.cos(lat1_r) * np.cos(lat2_r) * np.sin(dlon / 2) ** 2
    c = 2 * np.arctan2(np.sqrt(a), np.sqrt(1 - a))
    return R * c


def pairwise_distance_matrix(
    lats: np.ndarray,
    lons: np.ndarray,
    metric: str = "euclidean",
) -> np.ndarray:
    """Compute pairwise distance matrix for a set of spatial points.

    Args:
        lats: Array of latitudes.
        lons: Array of longitudes.
        metric: Distance metric - 'euclidean' or 'haversine'.

    Returns:
        n x n distance matrix as numpy array.
    """
    n = len(lats)
    if metric == "euclidean":
        coords = np.column_stack([lats, lons])
        diff = coords[:, np.newaxis, :] - coords[np.newaxis, :, :]
        return np.sqrt(np.sum(diff ** 2, axis=2))
    elif metric == "haversine":
        dist = np.zeros((n, n))
        for i in range(n):
            for j in range(i + 1, n):
                d = haversine_distance(lats[i], lons[i], lats[j], lons[j])
                dist[i, j] = d
                dist[j, i] = d
        return dist
    else:
        raise ValueError(f"Unknown metric: {metric}")


def nearest_neighbor_distances(
    lats: np.ndarray,
    lons: np.ndarray,
    k: int = 1,
    metric: str = "euclidean",
) -> np.ndarray:
    """Compute k-nearest-neighbor distances for each point.

    Args:
        lats: Array of latitudes.
        lons: Array of longitudes.
        k: Number of nearest neighbors.
        metric: Distance metric - 'euclidean' or 'haversine'.

    Returns:
        Array of shape (n, k) with distances to the k nearest neighbors.
    """
    from scipy.spatial import cKDTree

    if metric == "euclidean":
        tree = cKDTree(np.column_stack([lats, lons]))
        dists, _ = tree.query(np.column_stack([lats, lons]), k=k + 1)
        return dists[:, 1:]  # exclude self-distance
    else:
        dist_mat = pairwise_distance_matrix(lats, lons, metric=metric)
        sorted_dists = np.sort(dist_mat, axis=1)
        return sorted_dists[:, 1 : k + 1]


def distance_band_weights(
    lats: np.ndarray,
    lons: np.ndarray,
    threshold: float,
    binary: bool = True,
) -> np.ndarray:
    """Construct a distance-band spatial weights matrix.

    Args:
        lats: Array of latitudes.
        lons: Array of longitudes.
        threshold: Distance threshold for neighbor inclusion.
        binary: If True, use binary weights; otherwise use inverse distance.

    Returns:
        n x n spatial weights matrix (row-standardized).
    """
    coords = np.column_stack([lats, lons])
    diff = coords[:, np.newaxis, :] - coords[np.newaxis, :, :]
    dist = np.sqrt(np.sum(diff ** 2, axis=2))
    if binary:
        W = (dist <= threshold).astype(float)
    else:
        with np.errstate(divide="ignore"):
            W = np.where((dist > 0) & (dist <= threshold), 1.0 / dist, 0.0)
    np.fill_diagonal(W, 0)
    row_sums = W.sum(axis=1, keepdims=True)
    row_sums[row_sums == 0] = 1
    return W / row_sums


def knn_weights(
    lats: np.ndarray,
    lons: np.ndarray,
    k: int = 8,
) -> np.ndarray:
    """Construct a k-nearest-neighbor spatial weights matrix (row-standardized).

    Note: returns a dense (n, n) array. For large n (thousands of points) prefer
    ``knn_weights_sparse`` to avoid O(n^2) memory.

    Args:
        lats: Array of latitudes.
        lons: Array of longitudes.
        k: Number of nearest neighbors.

    Returns:
        n x n spatial weights matrix (row-standardized).
    """
    from scipy.spatial import cKDTree

    coords = np.column_stack([lats, lons])
    tree = cKDTree(coords)
    _, indices = tree.query(coords, k=k + 1)
    n = len(lats)
    W = np.zeros((n, n))
    for i in range(n):
        for j in indices[i, 1:]:
            W[i, j] = 1.0
    row_sums = W.sum(axis=1, keepdims=True)
    row_sums[row_sums == 0] = 1
    return W / row_sums


def knn_weights_sparse(
    lats: np.ndarray,
    lons: np.ndarray,
    k: int = 8,
):
    """Construct a row-standardized k-nearest-neighbor spatial weights matrix.

    Returns a sparse CSR matrix, so memory scales as O(n*k) rather than O(n^2).
    Suitable for tens of thousands of grid cells.

    Args:
        lats: Array of latitudes.
        lons: Array of longitudes.
        k: Number of nearest neighbors.

    Returns:
        scipy.sparse CSR matrix of shape (n, n), row-standardized.
    """
    from scipy.spatial import cKDTree
    from scipy.sparse import csr_matrix

    coords = np.column_stack([lats, lons])
    n = len(lats)
    tree = cKDTree(coords)
    _, indices = tree.query(coords, k=k + 1)
    # Drop the self-neighbour (first column) and build COO triples.
    neigh = indices[:, 1:]
    rows = np.repeat(np.arange(n), neigh.shape[1])
    cols = neigh.ravel()
    data = np.full(rows.shape[0], 1.0 / neigh.shape[1])
    W = csr_matrix((data, (rows, cols)), shape=(n, n))
    return W


def distance_band_weights_sparse(
    lats: np.ndarray,
    lons: np.ndarray,
    threshold: float,
    binary: bool = True,
):
    """Construct a row-standardized distance-band spatial weights matrix (sparse).

    Uses a KD-tree to find neighbours within ``threshold`` so memory scales with
    the number of within-band pairs rather than O(n^2).

    Args:
        lats: Array of latitudes.
        lons: Array of longitudes.
        threshold: Distance threshold (coordinate units) for neighbour inclusion.
        binary: If True, binary weights; otherwise inverse-distance weights.

    Returns:
        scipy.sparse CSR matrix of shape (n, n), row-standardized.
    """
    from scipy.spatial import cKDTree
    from scipy.sparse import csr_matrix

    coords = np.column_stack([lats, lons])
    n = len(lats)
    tree = cKDTree(coords)
    pairs = tree.query_pairs(r=threshold, output_type="ndarray")
    if pairs.size == 0:
        return csr_matrix((n, n))
    i = pairs[:, 0]
    j = pairs[:, 1]
    if binary:
        w = np.ones(len(i))
    else:
        d = np.sqrt(((coords[i] - coords[j]) ** 2).sum(axis=1))
        w = 1.0 / d
    # Symmetrise.
    rows = np.concatenate([i, j])
    cols = np.concatenate([j, i])
    data = np.concatenate([w, w])
    W = csr_matrix((data, (rows, cols)), shape=(n, n))
    row_sums = np.asarray(W.sum(axis=1)).ravel()
    row_sums[row_sums == 0] = 1.0
    from scipy.sparse import diags

    return diags(1.0 / row_sums) @ W

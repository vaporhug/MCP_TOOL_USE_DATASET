"""Spatial data loading and preprocessing tools for biodiversity grid-cell analysis."""

import pandas as pd
import numpy as np
from typing import Optional


def load_csv(file_path: str) -> pd.DataFrame:
    """Load a CSV file into a pandas DataFrame.

    Args:
        file_path: Path to the CSV file.

    Returns:
        DataFrame with the loaded data.
    """
    return pd.read_csv(file_path)


def merge_datasets(
    df1: pd.DataFrame,
    df2: pd.DataFrame,
    on: str,
    how: str = "inner",
) -> pd.DataFrame:
    """Merge two DataFrames on a common key column.

    Args:
        df1: First DataFrame.
        df2: Second DataFrame.
        on: Column name to join on.
        how: Type of join ('inner', 'left', 'right', 'outer').

    Returns:
        Merged DataFrame.
    """
    return df1.merge(df2, on=on, how=how)


def filter_by_column(
    df: pd.DataFrame,
    column: str,
    min_val: Optional[float] = None,
    max_val: Optional[float] = None,
    dropna: bool = True,
) -> pd.DataFrame:
    """Filter DataFrame rows by column value range and/or missing values.

    Args:
        df: Input DataFrame.
        column: Column name to filter on.
        min_val: Minimum allowed value (inclusive).
        max_val: Maximum allowed value (inclusive).
        dropna: Whether to drop rows where column is NaN.

    Returns:
        Filtered DataFrame.
    """
    result = df.copy()
    if dropna:
        result = result.dropna(subset=[column])
    if min_val is not None:
        result = result[result[column] >= min_val]
    if max_val is not None:
        result = result[result[column] <= max_val]
    return result


def drop_missing(df: pd.DataFrame, columns: list) -> pd.DataFrame:
    """Drop rows with missing values in specified columns.

    Args:
        df: Input DataFrame.
        columns: List of column names to check for missing values.

    Returns:
        DataFrame with missing rows removed.
    """
    return df.dropna(subset=columns)


def log_transform(df: pd.DataFrame, column: str, new_column: Optional[str] = None) -> pd.DataFrame:
    """Apply natural log transformation to a column.

    Args:
        df: Input DataFrame.
        column: Column to transform.
        new_column: Name for the new column. If None, overwrites the original.

    Returns:
        DataFrame with the transformed column.
    """
    result = df.copy()
    target = new_column if new_column else column
    result[target] = np.log(result[column].values)
    return result


def compute_summary_stats(df: pd.DataFrame, columns: list) -> pd.DataFrame:
    """Compute summary statistics for specified columns.

    Args:
        df: Input DataFrame.
        columns: List of column names to summarize.

    Returns:
        DataFrame with summary statistics (count, mean, std, min, 25%, 50%, 75%, max).
    """
    return df[columns].describe()


def group_summary(
    df: pd.DataFrame,
    group_col: str,
    value_col: str,
    agg_funcs: list = None,
) -> pd.DataFrame:
    """Compute grouped summary statistics.

    Args:
        df: Input DataFrame.
        group_col: Column to group by.
        value_col: Column to aggregate.
        agg_funcs: List of aggregation functions (default: ['count', 'mean', 'std', 'median']).

    Returns:
        DataFrame with grouped statistics.
    """
    if agg_funcs is None:
        agg_funcs = ["count", "mean", "std", "median"]
    return df.groupby(group_col)[value_col].agg(agg_funcs).reset_index()

"""Spatial cluster detection tools: DBSCAN, hotspot analysis, and richness classification."""

import numpy as np
from typing import Dict, Optional, Tuple


def dbscan_clustering(
    lats: np.ndarray,
    lons: np.ndarray,
    values: np.ndarray,
    eps: float = 2.0,
    min_samples: int = 5,
    value_threshold: Optional[float] = None,
) -> Dict[str, object]:
    """Perform DBSCAN spatial clustering on high-value points.

    Args:
        lats: Array of latitudes.
        lons: Array of longitudes.
        values: Array of values used to filter points before clustering.
        eps: Maximum distance between two points in a cluster.
        min_samples: Minimum number of points to form a dense region.
        value_threshold: Only cluster points with values above this threshold.
                         Defaults to the 75th percentile.

    Returns:
        Dictionary with 'labels' (cluster assignments, -1=noise),
        'n_clusters', 'cluster_sizes', 'cluster_centers'.
    """
    from sklearn.cluster import DBSCAN

    if value_threshold is None:
        value_threshold = np.percentile(values, 75)

    mask = values >= value_threshold
    coords = np.column_stack([lats[mask], lons[mask]])

    clustering = DBSCAN(eps=eps, min_samples=min_samples).fit(coords)
    labels = clustering.labels_
    n_clusters = len(set(labels)) - (1 if -1 in labels else 0)

    # Full labels array
    full_labels = np.full(len(lats), -2)  # -2 = below threshold
    full_labels[mask] = labels

    # Cluster centers and sizes
    cluster_sizes = {}
    cluster_centers = {}
    for c in range(n_clusters):
        c_mask = labels == c
        cluster_sizes[c] = int(c_mask.sum())
        cluster_centers[c] = (float(coords[c_mask, 0].mean()), float(coords[c_mask, 1].mean()))

    return {
        "labels": full_labels,
        "n_clusters": n_clusters,
        "cluster_sizes": cluster_sizes,
        "cluster_centers": cluster_centers,
    }


def hotspot_classification(
    gi_star_scores: np.ndarray,
    confidence_levels: Tuple[float, ...] = (1.645, 1.96, 2.576),
) -> np.ndarray:
    """Classify points as hotspots/coldspots based on Gi* z-scores.

    Args:
        gi_star_scores: Array of Getis-Ord Gi* z-scores.
        confidence_levels: Z-score thresholds for 90%, 95%, 99% confidence.

    Returns:
        Array of classification labels:
            3 = hot spot (99%), 2 = hot spot (95%), 1 = hot spot (90%),
            0 = not significant,
            -1 = cold spot (90%), -2 = cold spot (95%), -3 = cold spot (99%).
    """
    n = len(gi_star_scores)
    classes = np.zeros(n, dtype=int)
    for i, threshold in enumerate(confidence_levels):
        classes[gi_star_scores >= threshold] = i + 1
        classes[gi_star_scores <= -threshold] = -(i + 1)
    return classes


def identify_biodiversity_hotspots(
    lats: np.ndarray,
    lons: np.ndarray,
    richness: np.ndarray,
    percentile_threshold: float = 90,
) -> Dict[str, object]:
    """Identify grid cells that qualify as biodiversity hotspots.

    Args:
        lats: Array of latitudes.
        lons: Array of longitudes.
        richness: Array of species richness values.
        percentile_threshold: Percentile above which cells are hotspots.

    Returns:
        Dictionary with 'hotspot_mask', 'threshold_value', 'n_hotspots',
        'hotspot_coords' (lat, lon pairs).
    """
    threshold = np.percentile(richness, percentile_threshold)
    mask = richness >= threshold
    hotspot_coords = np.column_stack([lats[mask], lons[mask]])

    return {
        "hotspot_mask": mask,
        "threshold_value": float(threshold),
        "n_hotspots": int(mask.sum()),
        "hotspot_coords": hotspot_coords,
    }

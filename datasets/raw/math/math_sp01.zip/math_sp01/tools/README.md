# Spatial Statistics Tools

## Tool Categories

### Data Processing
- `spatial_data.py` — CSV loading, merging, filtering, log-transform, summary statistics, group summaries

### Distance & Weights
- `distance_matrix.py` — Haversine/Euclidean pairwise distances, KNN distances, distance-band weights, KNN weights matrices. For large grids use the sparse builders `knn_weights_sparse` / `distance_band_weights_sparse` (O(n*k) memory) instead of the dense versions.

### Spatial Autocorrelation
- `spatial_autocorrelation.py` — Global Moran's I, Local Moran's I (LISA), Geary's C, Getis-Ord Gi* hotspot statistic (Global/Local Moran's I accept dense or scipy.sparse weights)

### Geostatistics
- `variogram.py` — Empirical variogram estimation, spherical/exponential/Gaussian model fitting
- `kriging.py` — Ordinary kriging interpolation, IDW interpolation

### Regression
- `spatial_regression.py` — OLS, spatial lag model, spatial error model, GAM-like smooth fitting, AIC model comparison. The bundled `gam_smooth_fit` is a deterministic polynomial spatial smoother for public diagnostics, not the paper's native mgcv thin-plate spline implementation.

### Validation
- `spatial_cv.py` — Spatial block cross-validation, leave-one-out CV, CV metrics (RMSE, MAE, R^2)

### Cluster Analysis
- `cluster_detection.py` — DBSCAN spatial clustering, Gi* hotspot classification, biodiversity hotspot identification, and `eight_neighbor_hotspot_clusters` for top-percentile grid-cell clusters with eight-neighbour adjacency and a minimum cluster-size filter

### Inference
- `bootstrap_ci.py` — Bootstrap CIs for statistics, correlations, and regression coefficients
- `correlation_analysis.py` — Pearson/Spearman correlation, partial correlation, residual spatial-autocorrelation test (`residual_spatial_autocorrelation`: Global Moran's I on residuals using sparse k-NN weights)

### Visualization
- `plotting.py` — Spatial maps, variogram plots, Moran scatterplots, LISA cluster maps, richness-by-realm facet plots

### Public Diagnostic Protocols
- Moran's I uses `knn_weights_sparse` with row-standardized KNN `k=8` on the public complete-case subset (`n=16,815`).
- Hotspot clusters use `eight_neighbor_hotspot_clusters` with a separate one-degree eight-neighbour grid adjacency and Richness >= 406.
- `gam_smooth_fit` is a public-data polynomial diagnostic; it is not the paper's native mgcv GAM implementation.

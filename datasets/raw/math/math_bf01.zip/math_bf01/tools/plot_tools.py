"""Plotting utilities for Bayesian analysis: trace plots, posteriors, diagnostics."""

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from typing import List, Optional, Tuple
import os


def plot_trace(samples: np.ndarray,
               param_names: Optional[List[str]] = None,
               output_path: str = "trace_plot.png") -> str:
    """Plot MCMC trace plots for each parameter.

    Parameters
    ----------
    samples : np.ndarray
        Posterior samples of shape (n_samples, n_params) or (n_samples,).
    param_names : list of str, optional
        Parameter names.
    output_path : str
        Path to save the figure.

    Returns
    -------
    str
        Path to the saved figure.
    """
    if samples.ndim == 1:
        samples = samples.reshape(-1, 1)

    n_params = samples.shape[1]
    if param_names is None:
        param_names = [f'param_{i}' for i in range(n_params)]

    fig, axes = plt.subplots(n_params, 1, figsize=(10, 2.5 * n_params))
    if n_params == 1:
        axes = [axes]

    for i, ax in enumerate(axes):
        ax.plot(samples[:, i], alpha=0.7, linewidth=0.5)
        ax.set_ylabel(param_names[i])
        ax.set_xlabel('Iteration')

    plt.suptitle('MCMC Trace Plots', fontsize=14)
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    return output_path


def plot_posterior(samples: np.ndarray,
                  param_names: Optional[List[str]] = None,
                  ci_level: float = 0.95,
                  output_path: str = "posterior_plot.png") -> str:
    """Plot posterior density distributions with credible intervals.

    Parameters
    ----------
    samples : np.ndarray
        Posterior samples of shape (n_samples, n_params) or (n_samples,).
    param_names : list of str, optional
        Parameter names.
    ci_level : float
        Credible interval level for shading.
    output_path : str
        Path to save the figure.

    Returns
    -------
    str
        Path to the saved figure.
    """
    if samples.ndim == 1:
        samples = samples.reshape(-1, 1)

    n_params = samples.shape[1]
    if param_names is None:
        param_names = [f'param_{i}' for i in range(n_params)]

    alpha = 1 - ci_level
    ncols = min(3, n_params)
    nrows = (n_params + ncols - 1) // ncols
    fig, axes = plt.subplots(nrows, ncols, figsize=(4 * ncols, 3 * nrows))
    if n_params == 1:
        axes = np.array([axes])
    axes = np.atleast_2d(axes).flatten()

    for i in range(n_params):
        ax = axes[i]
        s = samples[:, i]
        ax.hist(s, bins=50, density=True, alpha=0.6, color='steelblue', edgecolor='none')

        # KDE
        from scipy.stats import gaussian_kde
        kde = gaussian_kde(s)
        x_grid = np.linspace(s.min(), s.max(), 200)
        ax.plot(x_grid, kde(x_grid), 'k-', linewidth=1.5)

        # Credible interval
        lo = np.percentile(s, 100 * alpha / 2)
        hi = np.percentile(s, 100 * (1 - alpha / 2))
        ax.axvline(np.median(s), color='red', linestyle='-', linewidth=1.5, label='median')
        ax.axvline(lo, color='red', linestyle='--', linewidth=1, label=f'{ci_level*100:.0f}% CI')
        ax.axvline(hi, color='red', linestyle='--', linewidth=1)
        ax.set_title(param_names[i])

    for i in range(n_params, len(axes)):
        axes[i].set_visible(False)

    plt.suptitle('Posterior Distributions', fontsize=14)
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    return output_path


def plot_posterior_predictive(y_observed: np.ndarray,
                              y_replicated: np.ndarray,
                              output_path: str = "ppc_plot.png",
                              n_rep_lines: int = 50) -> str:
    """Plot posterior predictive check: observed vs replicated data distributions.

    Parameters
    ----------
    y_observed : np.ndarray
        Observed data values.
    y_replicated : np.ndarray
        Replicated datasets of shape (n_rep, n_obs).
    output_path : str
        Path to save the figure.
    n_rep_lines : int
        Number of replicated density lines to overlay.

    Returns
    -------
    str
        Path to the saved figure.
    """
    fig, ax = plt.subplots(figsize=(8, 5))

    # Replicated data distributions
    n_show = min(n_rep_lines, y_replicated.shape[0])
    for i in range(n_show):
        ax.hist(y_replicated[i], bins=30, density=True, alpha=0.05,
                color='steelblue', edgecolor='none')

    # Observed data
    ax.hist(y_observed, bins=30, density=True, alpha=0.8,
            color='darkred', edgecolor='white', linewidth=0.5, label='Observed')

    ax.set_xlabel('Value')
    ax.set_ylabel('Density')
    ax.set_title('Posterior Predictive Check')
    ax.legend()
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    return output_path


def plot_forest(estimates: List[dict],
                output_path: str = "forest_plot.png") -> str:
    """Plot a forest plot of posterior estimates with credible intervals.

    Parameters
    ----------
    estimates : list of dict
        Each dict has keys: 'label', 'mean' or 'median', 'ci_lower', 'ci_upper',
        and optionally 'color'.
    output_path : str
        Path to save the figure.

    Returns
    -------
    str
        Path to the saved figure.
    """
    n = len(estimates)
    fig, ax = plt.subplots(figsize=(8, max(4, 0.5 * n)))

    y_positions = np.arange(n)
    for i, est in enumerate(estimates):
        center = est.get('median', est.get('mean', 0))
        lo = est['ci_lower']
        hi = est['ci_upper']
        color = est.get('color', 'steelblue')

        ax.plot([lo, hi], [i, i], color=color, linewidth=2)
        ax.plot(center, i, 'o', color=color, markersize=6)

    ax.set_yticks(y_positions)
    ax.set_yticklabels([e['label'] for e in estimates])
    ax.axvline(0, color='grey', linestyle='--', linewidth=1)
    ax.set_xlabel('Estimate')
    ax.set_title('Forest Plot of Posterior Estimates')
    ax.invert_yaxis()
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    return output_path


def plot_correlation_comparison(naive_estimates: List[dict],
                                 controlled_estimates: List[dict],
                                 labels: List[str],
                                 output_path: str = "correlation_comparison.png") -> str:
    """Plot comparison of naive vs controlled posterior correlations.

    Parameters
    ----------
    naive_estimates : list of dict
        Each with 'median', 'ci_lower', 'ci_upper'.
    controlled_estimates : list of dict
        Same structure, for controlled model.
    labels : list of str
        Study/correlation labels.
    output_path : str
        Path to save figure.

    Returns
    -------
    str
        Path to saved figure.
    """
    n = len(labels)
    fig, ax = plt.subplots(figsize=(10, max(4, 0.6 * n)))

    offset = 0.15
    for i in range(n):
        # Naive
        ne = naive_estimates[i]
        center_n = ne.get('median', ne.get('mean', 0))
        ax.plot([ne['ci_lower'], ne['ci_upper']], [i - offset, i - offset],
                color='coral', linewidth=2)
        ax.plot(center_n, i - offset, 'o', color='coral', markersize=6)

        # Controlled
        ce = controlled_estimates[i]
        center_c = ce.get('median', ce.get('mean', 0))
        ax.plot([ce['ci_lower'], ce['ci_upper']], [i + offset, i + offset],
                color='steelblue', linewidth=2)
        ax.plot(center_c, i + offset, 'o', color='steelblue', markersize=6)

    ax.set_yticks(range(n))
    ax.set_yticklabels(labels)
    ax.axvline(0, color='grey', linestyle='--', linewidth=1)
    ax.set_xlabel('Cross-national correlation')
    ax.set_title('Naive (red) vs Non-independence Controlled (blue)')
    ax.invert_yaxis()
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    return output_path

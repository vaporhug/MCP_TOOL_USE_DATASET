# Tools Index

## data_processing.py — Data loading and panel operations
- `load_csv` — Load CSV file to list of dicts
- `filter_rows` — Filter by categorical column values
- `filter_by_range` — Filter by numeric range
- `add_lag` — Single-variable exploratory lag helper only; do NOT chain it for scored Table 1/Table 2 recovery
- `add_lags_batch` — Single-pass multi-variable exploratory lag helper; if a lag panel is needed, use this once so rows are dropped once, not once per variable
- `add_log_column` — Natural log transformation with offset
- `merge_panels` — Inner join two panels on key columns
- `compute_group_mean` — Group-level means
- `summary_stats` — Descriptive statistics for columns

## causal_inference.py — Econometric estimation and diagnostics
- `ols_regression` — OLS with homoskedastic SEs
- `fixed_effects_regression` — Multi-way FE via iterative demeaning
- `cluster_robust_se` — Liang-Zeger cluster-robust standard errors
- `event_study_did` — Dynamic DiD / event study coefficients
- `parallel_trends_test` — Pre-treatment trend comparison
- `placebo_permutation_test` — Permutation-based placebo test
- `bootstrap_confidence_interval` — Cluster bootstrap CI
- `covariate_balance_check` — Standardized mean differences
- `compute_rps_stringency` — RPS stringency formula
- `moran_i_test` — Global Moran's I spatial autocorrelation
- `interaction_effect` — Add interaction term
- `compute_t_stat` — t-stat and p-value for coefficient

## visualization.py — Plotting functions
- `plot_coefficient_table` — Forest-style coefficient plot
- `plot_event_study` — Event study diagram with CIs
- `plot_treatment_effects` — Compare effects across models
- `plot_permutation_distribution` — Null distribution with observed value
- `plot_covariate_balance` — SMD balance plot
- `plot_stringency_bar_chart` — Preferred state-level RPS stringency horizontal bar chart for `artifacts/Fig_stringency_bar.png`
- `plot_spillover_map` — Legacy alias that renders the same bar-chart style; no state-boundary geometry is bundled
- `plot_time_series_comparison` — Multi-series time plot

## database_retrieval.py — External data stubs
- `query_eia_generation` — EIA electricity generation (stub)
- `query_state_policy` — State policy database (stub)

"""Database retrieval stubs for external data sources.

Placeholder functions for retrieving supplementary data
from public databases. These return empty results as the
analysis relies on pre-packaged input data.
"""


def query_eia_generation(state: str, year: int) -> dict:
    """Query U.S. Energy Information Administration for electricity generation.

    Stub function. In production, queries the EIA API for state-level
    electricity generation data by source.

    Parameters
    ----------
    state : str
        Two-letter state abbreviation.
    year : int
        Calendar year.

    Returns
    -------
    dict
        Empty dict (stub).
    """
    return {}


def query_state_policy(state: str, policy_type: str) -> dict:
    """Query state-level energy policy database.

    Stub function. In production, queries DSIRE or similar
    database for policy adoption dates and parameters.

    Parameters
    ----------
    state : str
    policy_type : str

    Returns
    -------
    dict
        Empty dict (stub).
    """
    return {}

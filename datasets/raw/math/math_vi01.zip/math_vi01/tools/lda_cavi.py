"""Coordinate-ascent variational inference (CAVI) for Latent Dirichlet
Allocation, plus the corresponding evidence lower bound (ELBO).

The implementation follows Sections 5.2-5.4 of Blei, Ng, Jordan (JMLR
2003). All quantities are computed in pure numpy with the digamma /
gammaln helpers from ``scipy.special``; we do **not** depend on
sklearn, gensim, or any topic-modelling package.

Variational family per document ``d``:

    q(theta_d) = Dir(theta_d ; gamma_d)
    q(z_{d,n}) = Cat(z_{d,n} ; phi_{d,n})

Variational family for topics:

    q(beta_k) = Dir(beta_k ; lambda_k)

This is the smoothed LDA model of the paper, Section 5.4: a symmetric
Dirichlet prior ``eta`` is placed over the per-topic word distribution
beta_k, mirroring the original variational EM derivation.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
from scipy.special import digamma, gammaln


# ---------------------------------------------------------------------------
# Per-document E-step (Blei 2003 Eqs. 6 and 7)
# ---------------------------------------------------------------------------


def _expected_log_dirichlet(alpha_vec: np.ndarray) -> np.ndarray:
    """Compute E[log x_i] under x ~ Dir(alpha_vec)."""
    return digamma(alpha_vec) - digamma(alpha_vec.sum())


def _expected_log_beta(lam: np.ndarray) -> np.ndarray:
    """Compute E[log beta_kv] for each (k, v); ``lam`` has shape (K, V)."""
    return digamma(lam) - digamma(lam.sum(axis=1, keepdims=True))


def update_doc_variational_params(
    doc: Sequence[Tuple[int, int]],
    alpha: np.ndarray,
    Elogbeta: np.ndarray,
    max_iter: int = 100,
    tol: float = 1e-3,
) -> Tuple[np.ndarray, np.ndarray, int]:
    """Run inner CAVI for one document.

    Implements the coordinate updates of Blei 2003 Eq. (6) (phi update)
    and Eq. (7) (gamma update) until the average gamma change drops
    below ``tol``.

    Parameters
    ----------
    doc : list of (word_index, count)
        Bag-of-words representation of one document.
    alpha : (K,) array
        Document-level Dirichlet hyperparameter (symmetric or
        asymmetric).
    Elogbeta : (K, V) array
        ``digamma(lam) - digamma(lam.sum(axis=1))`` from the global
        topics.

    Returns
    -------
    gamma : (K,) array
        Posterior Dirichlet parameter over topic mixture for this doc.
    phi : (n_unique, K) array
        Posterior word-topic assignment probabilities for the unique
        tokens in this document.
    n_iter : int
        Number of coordinate updates performed.
    """
    K = int(alpha.shape[0])
    if not doc:
        return np.array(alpha, dtype=float).copy(), np.zeros((0, K)), 0
    word_ids = np.array([w for w, _ in doc], dtype=int)
    counts = np.array([c for _, c in doc], dtype=float)
    Nd = float(counts.sum())
    gamma = alpha + Nd / K
    Elogtheta = _expected_log_dirichlet(gamma)
    last_gamma = gamma.copy()
    n_iter = 0
    for n_iter in range(1, int(max_iter) + 1):
        # phi proportional to exp(Elogtheta + Elogbeta[:, word_ids].T)
        log_phi = Elogtheta[None, :] + Elogbeta[:, word_ids].T  # (Nu, K)
        log_phi -= log_phi.max(axis=1, keepdims=True)
        phi = np.exp(log_phi)
        phi /= phi.sum(axis=1, keepdims=True)
        gamma = alpha + (phi * counts[:, None]).sum(axis=0)
        Elogtheta = _expected_log_dirichlet(gamma)
        change = float(np.mean(np.abs(gamma - last_gamma)))
        last_gamma = gamma.copy()
        if change < float(tol):
            break
    return gamma, phi, n_iter


# ---------------------------------------------------------------------------
# Full corpus CAVI / variational EM
# ---------------------------------------------------------------------------


@dataclass
class LDAFit:
    """Fitted LDA variational parameters and bookkeeping."""

    K: int
    V: int
    D: int
    alpha: np.ndarray
    eta: float
    lam: np.ndarray
    gammas: List[np.ndarray]
    elbo_trace: List[float]
    perplexity_trace: List[float]
    n_iter: int


def initialise_topics(
    K: int,
    V: int,
    eta: float = 0.01,
    seed: int = 0,
    docs: Optional[Sequence[Sequence[Tuple[int, int]]]] = None,
) -> np.ndarray:
    """Initialise the global Dirichlet topic parameters ``lambda``.

    If ``docs`` is provided we seed each topic by sampling a single
    random document and assigning a small mass to its observed words,
    which is the trick recommended in Section 5.3 / Appendix A.1 of the
    paper for breaking symmetry.
    """
    rng = np.random.default_rng(int(seed))
    lam = float(eta) + rng.gamma(shape=100.0, scale=0.01, size=(int(K), int(V)))
    if docs is not None:
        D = len(docs)
        for k in range(int(K)):
            d = int(rng.integers(0, D))
            for w, c in docs[d]:
                lam[k, w] += float(c)
    return lam


def fit_lda_cavi(
    docs: Sequence[Sequence[Tuple[int, int]]],
    K: int,
    V: int,
    alpha: float = 0.1,
    eta: float = 0.01,
    max_iter: int = 50,
    inner_max_iter: int = 50,
    inner_tol: float = 1e-3,
    elbo_tol: float = 1e-4,
    seed: int = 0,
    record_perplexity: bool = True,
) -> LDAFit:
    """Run variational EM (CAVI) for smoothed LDA.

    Returns an :class:`LDAFit` summarising posterior gammas, the global
    topic parameter ``lambda``, the ELBO trajectory, and a per-iteration
    training-set perplexity.
    """
    K = int(K)
    V = int(V)
    D = len(docs)
    alpha_vec = np.full(K, float(alpha), dtype=float)
    lam = initialise_topics(K, V, eta=eta, seed=seed, docs=docs)
    elbo_trace: List[float] = []
    perp_trace: List[float] = []
    gammas: List[np.ndarray] = [None] * D  # type: ignore
    last_elbo = -np.inf
    final_iter = 0
    for it in range(1, int(max_iter) + 1):
        Elogbeta = _expected_log_beta(lam)
        new_lam = np.full_like(lam, float(eta))
        local_elbo = 0.0
        for d, doc in enumerate(docs):
            gamma_d, phi_d, _ = update_doc_variational_params(
                doc, alpha_vec, Elogbeta,
                max_iter=int(inner_max_iter),
                tol=float(inner_tol),
            )
            gammas[d] = gamma_d
            if doc:
                wids = np.array([w for w, _ in doc], dtype=int)
                counts = np.array([c for _, c in doc], dtype=float)
                contrib = phi_d * counts[:, None]  # (Nu, K)
                np.add.at(new_lam.T, wids, contrib)
                local_elbo += _document_elbo_contribution(
                    doc, gamma_d, phi_d, alpha_vec, Elogbeta,
                )
        lam = new_lam
        elbo = local_elbo + _topic_elbo_contribution(lam, eta)
        elbo_trace.append(float(elbo))
        if record_perplexity:
            perp_trace.append(float(_training_perplexity(docs, gammas, lam)))
        final_iter = it
        if it > 1 and abs(elbo - last_elbo) < float(elbo_tol) * max(1.0, abs(last_elbo)):
            break
        last_elbo = elbo
    return LDAFit(
        K=K, V=V, D=D,
        alpha=alpha_vec, eta=float(eta), lam=lam,
        gammas=gammas, elbo_trace=elbo_trace,
        perplexity_trace=perp_trace, n_iter=final_iter,
    )


def _document_elbo_contribution(
    doc: Sequence[Tuple[int, int]],
    gamma: np.ndarray,
    phi: np.ndarray,
    alpha: np.ndarray,
    Elogbeta: np.ndarray,
) -> float:
    """Per-document terms of the ELBO from Blei 2003 Eq. (15)."""
    Elogtheta = _expected_log_dirichlet(gamma)
    counts = np.array([c for _, c in doc], dtype=float)
    wids = np.array([w for w, _ in doc], dtype=int)
    val = 0.0
    val += float((alpha - 1.0) @ Elogtheta) + gammaln(alpha.sum()) - float(gammaln(alpha).sum())
    val += float(((phi * counts[:, None]) * Elogtheta[None, :]).sum())
    val += float(((phi * counts[:, None]) * Elogbeta[:, wids].T).sum())
    val -= float(((gamma - 1.0) @ Elogtheta)) + float(gammaln(gamma.sum()) - gammaln(gamma).sum())
    safe_phi = np.clip(phi, 1e-30, 1.0)
    val -= float(((phi * counts[:, None]) * np.log(safe_phi)).sum())
    return float(val)


def _topic_elbo_contribution(lam: np.ndarray, eta: float) -> float:
    """Topic prior + entropy contributions to the ELBO."""
    K, V = lam.shape
    eta_vec = np.full(V, float(eta))
    Elogbeta = _expected_log_beta(lam)
    val = 0.0
    val += K * (gammaln(eta_vec.sum()) - float(gammaln(eta_vec).sum()))
    val += float(((eta - 1.0) * Elogbeta).sum())
    val -= float((gammaln(lam.sum(axis=1)) - gammaln(lam).sum(axis=1)).sum())
    val -= float(((lam - 1.0) * Elogbeta).sum())
    return float(val)


def _training_perplexity(
    docs: Sequence[Sequence[Tuple[int, int]]],
    gammas: Sequence[np.ndarray],
    lam: np.ndarray,
) -> float:
    """Compute exp(- (sum_d log p(doc_d | theta_hat, beta_hat)) / N)."""
    theta = np.stack([g / g.sum() for g in gammas])  # (D, K)
    beta = lam / lam.sum(axis=1, keepdims=True)
    total = 0.0
    n_tokens = 0
    for d, doc in enumerate(docs):
        if not doc:
            continue
        for w, c in doc:
            p = float(theta[d] @ beta[:, w])
            total += int(c) * np.log(max(p, 1e-300))
            n_tokens += int(c)
    return float(np.exp(-total / max(n_tokens, 1)))


def held_out_perplexity(
    test_docs: Sequence[Sequence[Tuple[int, int]]],
    fit: LDAFit,
    inner_max_iter: int = 100,
    inner_tol: float = 1e-3,
) -> float:
    """Per-word perplexity on held-out documents.

    Evaluation protocol: for each test document we re-fit the
    variational ``gamma`` over its words while holding the topic
    parameter ``lam`` fixed, then score that SAME document under
    ``exp(- log_lik / total_tokens)`` (Blei 2003 Eq. 16). NB: this
    is the simpler "fit-and-score-same-words" variant used by the
    bundled implementation, not the document-completion split where
    half the document's tokens fit gamma and the other half are
    scored. The qualitative LDA-vs-baselines ordering is preserved
    under either convention; the absolute perplexity magnitudes
    differ between the two protocols. Callers who need
    document-completion semantics must split each test document
    upstream before calling this function.
    """
    Elogbeta = _expected_log_beta(fit.lam)
    beta = fit.lam / fit.lam.sum(axis=1, keepdims=True)
    log_lik = 0.0
    n_tokens = 0
    for doc in test_docs:
        if not doc:
            continue
        gamma_d, _, _ = update_doc_variational_params(
            doc, fit.alpha, Elogbeta,
            max_iter=int(inner_max_iter),
            tol=float(inner_tol),
        )
        theta_d = gamma_d / gamma_d.sum()
        for w, c in doc:
            p = float(theta_d @ beta[:, w])
            log_lik += int(c) * np.log(max(p, 1e-300))
            n_tokens += int(c)
    return float(np.exp(-log_lik / max(n_tokens, 1)))


def predictive_perplexity(
    held_out_docs: Sequence[Sequence[Tuple[int, int]]],
    obs_part: Sequence[Sequence[Tuple[int, int]]],
    fit: LDAFit,
    inner_max_iter: int = 100,
    inner_tol: float = 1e-3,
) -> float:
    """Held-out predictive perplexity using a per-document word split.

    ``obs_part[d]`` contains the visible portion of document ``d``,
    ``held_out_docs[d]`` contains the held-out portion. This matches the
    predictive perplexity definition used in Hoffman et al. 2013 SVI
    (Eq. 16) and is a more honest evaluation than document-level
    held-out for short-document corpora.
    """
    Elogbeta = _expected_log_beta(fit.lam)
    beta = fit.lam / fit.lam.sum(axis=1, keepdims=True)
    log_lik = 0.0
    n_tokens = 0
    for obs, held in zip(obs_part, held_out_docs):
        if not held:
            continue
        gamma_d, _, _ = update_doc_variational_params(
            obs, fit.alpha, Elogbeta,
            max_iter=int(inner_max_iter),
            tol=float(inner_tol),
        )
        theta_d = gamma_d / gamma_d.sum()
        for w, c in held:
            p = float(theta_d @ beta[:, w])
            log_lik += int(c) * np.log(max(p, 1e-300))
            n_tokens += int(c)
    return float(np.exp(-log_lik / max(n_tokens, 1)))


# ---------------------------------------------------------------------------
# Posterior summaries
# ---------------------------------------------------------------------------


def topic_word_distributions(fit: LDAFit) -> np.ndarray:
    """Return the (K, V) point estimate ``beta_hat`` from ``lam``."""
    return fit.lam / fit.lam.sum(axis=1, keepdims=True)


def doc_topic_distributions(fit: LDAFit) -> np.ndarray:
    """Return the (D, K) point estimate ``theta_hat`` from ``gammas``."""
    return np.stack([g / g.sum() for g in fit.gammas])


def top_words_per_topic(
    fit: LDAFit,
    vocab: Sequence[str],
    n_top: int = 10,
) -> List[List[str]]:
    """Return a list of the ``n_top`` most probable words for each topic."""
    beta = topic_word_distributions(fit)
    top: List[List[str]] = []
    for k in range(fit.K):
        order = np.argsort(beta[k])[::-1][: int(n_top)]
        top.append([vocab[int(i)] for i in order])
    return top


def topic_concentration(fit: LDAFit) -> np.ndarray:
    """Per-topic effective vocabulary size measured by exp(entropy)."""
    beta = topic_word_distributions(fit)
    p = np.clip(beta, 1e-30, 1.0)
    H = -(p * np.log(p)).sum(axis=1)
    return np.exp(H)

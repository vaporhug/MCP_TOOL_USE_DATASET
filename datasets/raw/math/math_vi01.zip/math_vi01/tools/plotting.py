"""Matplotlib plotting helpers for the LDA / variational-inference task.

Every plotting function returns ``{"path": <absolute path>}`` so the
agent can chain them. We avoid seaborn / sklearn helpers and use only
matplotlib + numpy. Each function configures a non-interactive Agg
backend so the helpers work in headless evaluation environments.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Dict, List, Optional, Sequence

import matplotlib

matplotlib.use("Agg")  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402


def _ensure_parent(path: str) -> str:
    out = os.path.abspath(path)
    Path(out).parent.mkdir(parents=True, exist_ok=True)
    return out


def plot_elbo_trace(
    elbo_trace: Sequence[float],
    out_path: str,
    title: str = "Variational ELBO trace",
    secondary_trace: Optional[Sequence[float]] = None,
    secondary_label: str = "secondary",
) -> Dict[str, str]:
    """Plot the ELBO as a function of CAVI iteration."""
    out_path = _ensure_parent(out_path)
    fig, ax = plt.subplots(figsize=(7.0, 4.5))
    iters = np.arange(1, len(elbo_trace) + 1)
    ax.plot(iters, np.asarray(elbo_trace, dtype=float), "-o",
            color="#1f77b4", label="ELBO")
    if secondary_trace is not None:
        ax2 = ax.twinx()
        s = np.asarray(secondary_trace, dtype=float)
        ax2.plot(np.arange(1, len(s) + 1), s, "-s",
                 color="#d62728", label=secondary_label, alpha=0.7)
        ax2.set_ylabel(secondary_label, color="#d62728")
        ax2.tick_params(axis="y", labelcolor="#d62728")
    ax.set_xlabel("CAVI iteration")
    ax.set_ylabel("ELBO")
    ax.set_title(title)
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": out_path}


def plot_perplexity_vs_topics(
    K_values: Sequence[int],
    series: Dict[str, Sequence[float]],
    out_path: str,
    title: str = "Held-out perplexity vs number of topics",
    ylog: bool = False,
) -> Dict[str, str]:
    """Multi-line plot of perplexity vs K for each model in ``series``."""
    out_path = _ensure_parent(out_path)
    fig, ax = plt.subplots(figsize=(7.0, 4.5))
    markers = ["o", "s", "^", "D", "v", "P"]
    colors = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd", "#8c564b"]
    for i, (label, vals) in enumerate(series.items()):
        ax.plot(list(K_values), list(vals),
                marker=markers[i % len(markers)],
                color=colors[i % len(colors)],
                label=label, linewidth=1.6)
    ax.set_xlabel("Number of topics K")
    ax.set_ylabel("Perplexity")
    if ylog:
        ax.set_yscale("log")
    ax.set_title(title)
    ax.legend()
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": out_path}


def plot_topic_word_lists(
    top_words: Sequence[Sequence[str]],
    out_path: str,
    n_show: int = 10,
    title: str = "Top words per topic",
) -> Dict[str, str]:
    """Render the top-N word list of each topic as a text figure."""
    out_path = _ensure_parent(out_path)
    K = len(top_words)
    fig, ax = plt.subplots(figsize=(min(2.0 + 1.4 * K, 16.0), 5.0))
    ax.axis("off")
    cell_text = []
    for r in range(int(n_show)):
        row = []
        for k in range(K):
            tk = top_words[k]
            row.append(tk[r] if r < len(tk) else "")
        cell_text.append(row)
    col_labels = [f"Topic {k+1}" for k in range(K)]
    tab = ax.table(cellText=cell_text, colLabels=col_labels,
                   cellLoc="center", loc="center")
    tab.auto_set_font_size(False)
    tab.set_fontsize(9)
    tab.scale(1.0, 1.3)
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": out_path}


def plot_doc_topic_stack(
    theta: np.ndarray,
    out_path: str,
    n_docs: int = 30,
    title: str = "Document-topic mixtures",
    seed: int = 0,
) -> Dict[str, str]:
    """Stacked bar chart of theta_d for a random subset of documents."""
    out_path = _ensure_parent(out_path)
    rng = np.random.default_rng(int(seed))
    D, K = theta.shape
    n = int(min(n_docs, D))
    idx = rng.choice(D, size=n, replace=False)
    sub = np.asarray(theta, dtype=float)[idx]
    fig, ax = plt.subplots(figsize=(min(0.4 * n + 2.0, 14.0), 4.5))
    bottom = np.zeros(n)
    cmap = plt.colormaps.get_cmap("tab20")
    for k in range(K):
        ax.bar(np.arange(n), sub[:, k], bottom=bottom,
               color=cmap(k % 20),
               edgecolor="white", linewidth=0.4,
               label=f"T{k+1}")
        bottom += sub[:, k]
    ax.set_ylim(0, 1)
    ax.set_xlabel("Document (random subset)")
    ax.set_ylabel("Topic proportion")
    ax.set_title(title)
    if K <= 12:
        ax.legend(ncol=min(K, 6), fontsize=7, loc="upper center",
                  bbox_to_anchor=(0.5, -0.12))
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": out_path}


def plot_overfitting_table(
    K_values: Sequence[int],
    perp_lda: Sequence[float],
    perp_mixture: Sequence[float],
    perp_unigram_baseline: float,
    out_path: str,
    title: str = "Overfitting comparison (Blei 2003 Table 1 reproduction)",
) -> Dict[str, str]:
    """Bar plot showing the perplexity blow-up of mixture-of-unigrams.

    This reproduces the qualitative finding of Table 1 of Blei et al.
    2003: as K increases, mixture-of-unigrams perplexity explodes while
    the LDA perplexity stays controlled.
    """
    out_path = _ensure_parent(out_path)
    fig, ax = plt.subplots(figsize=(7.5, 4.5))
    K_arr = np.asarray(list(K_values), dtype=float)
    width = 0.35
    ax.bar(K_arr - width / 2, np.asarray(perp_lda), width=width,
           color="#1f77b4", label="LDA (CAVI)")
    ax.bar(K_arr + width / 2, np.asarray(perp_mixture), width=width,
           color="#d62728", label="Mixture of unigrams (EM)")
    ax.axhline(float(perp_unigram_baseline), linestyle="--",
               color="black", label="Smoothed unigram baseline")
    ax.set_yscale("log")
    ax.set_xlabel("Number of topics K")
    ax.set_ylabel("Held-out perplexity (log scale)")
    ax.set_title(title)
    ax.legend()
    ax.grid(True, axis="y", alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": out_path}


def plot_cavi_vs_gibbs(
    elbo_trace: Sequence[float],
    log_joint_trace: Sequence[float],
    out_path: str,
    title: str = "CAVI ELBO vs. collapsed Gibbs log-joint",
) -> Dict[str, str]:
    """Side-by-side plot of the variational and MCMC monitoring traces."""
    out_path = _ensure_parent(out_path)
    fig, axes = plt.subplots(1, 2, figsize=(11.0, 4.2))
    axes[0].plot(np.arange(1, len(elbo_trace) + 1),
                 np.asarray(elbo_trace, dtype=float),
                 "-o", color="#1f77b4")
    axes[0].set_xlabel("CAVI iteration")
    axes[0].set_ylabel("ELBO")
    axes[0].set_title("Variational ELBO")
    axes[0].grid(True, alpha=0.3)
    axes[1].plot(np.arange(1, len(log_joint_trace) + 1),
                 np.asarray(log_joint_trace, dtype=float),
                 "-s", color="#d62728")
    axes[1].set_xlabel("Gibbs sweep")
    axes[1].set_ylabel("Collapsed log-joint")
    axes[1].set_title("MCMC monitoring statistic")
    axes[1].grid(True, alpha=0.3)
    fig.suptitle(title)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": out_path}


def plot_topic_concentration(
    concentration: Sequence[float],
    out_path: str,
    title: str = "Effective vocabulary size per topic",
) -> Dict[str, str]:
    out_path = _ensure_parent(out_path)
    arr = np.asarray(concentration, dtype=float)
    fig, ax = plt.subplots(figsize=(7.0, 4.0))
    ax.bar(np.arange(1, len(arr) + 1), arr, color="#2ca02c")
    ax.set_xlabel("Topic index")
    ax.set_ylabel("exp(entropy)")
    ax.set_title(title)
    ax.grid(True, axis="y", alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": out_path}


def plot_topic_word_heatmap(
    beta: np.ndarray,
    vocab: Sequence[str],
    out_path: str,
    n_top_words: int = 12,
    title: str = "Topic-word probabilities (top words)",
) -> Dict[str, str]:
    """Heat-map of beta restricted to the top words of each topic."""
    out_path = _ensure_parent(out_path)
    K, V = beta.shape
    chosen: List[int] = []
    seen = set()
    for k in range(K):
        order = np.argsort(beta[k])[::-1]
        for idx in order:
            if idx not in seen:
                chosen.append(int(idx))
                seen.add(int(idx))
                if len(chosen) >= int(n_top_words) * (k + 1):
                    break
        if len(chosen) >= int(n_top_words) * K:
            break
    chosen = chosen[: int(n_top_words) * K]
    sub = beta[:, chosen]
    fig, ax = plt.subplots(figsize=(min(0.18 * len(chosen) + 3.0, 16.0),
                                    0.45 * K + 2.0))
    im = ax.imshow(sub, aspect="auto", cmap="viridis")
    ax.set_yticks(np.arange(K))
    ax.set_yticklabels([f"Topic {k+1}" for k in range(K)])
    ax.set_xticks(np.arange(len(chosen)))
    ax.set_xticklabels([vocab[i] for i in chosen],
                       rotation=90, fontsize=7)
    cbar = fig.colorbar(im, ax=ax, fraction=0.025, pad=0.02)
    cbar.set_label("p(word | topic)")
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": out_path}

"""Baseline document models used in Blei et al. 2003 Section 7.1:

    * smoothed unigram model with a Dirichlet prior
    * mixture of unigrams (a single latent topic per document) fitted
      with EM and an additive Dirichlet pseudo-count smoothing in the
      M-step (controlled by ``eta``). NB: this is a smoothed-EM
      simplification of the paper's variational-Bayes smoothed
      mixture-of-unigrams (paper Section 5.4 derives the
      Dirichlet-prior VB variant). The simpler EM-with-pseudo-counts
      form preserves the qualitative overfitting-with-K pattern the
      paper observes, but is not the exact paper variant.

Both baselines compute the per-word predictive perplexity on a held-out
corpus, mirroring Eq. (16) of the paper. They depend only on numpy and
scipy.special.gammaln; no sklearn or gensim.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Sequence, Tuple

import numpy as np
from scipy.special import gammaln, logsumexp


# ---------------------------------------------------------------------------
# Smoothed unigram baseline
# ---------------------------------------------------------------------------


@dataclass
class UnigramFit:
    eta: float
    V: int
    counts: np.ndarray  # (V,) raw counts on the training corpus
    log_p_word: np.ndarray  # (V,) log of MAP estimate under Dir(eta) prior


def fit_smoothed_unigram(
    docs: Sequence[Sequence[Tuple[int, int]]],
    V: int,
    eta: float = 0.01,
) -> UnigramFit:
    """MAP estimate of p(word) under a Dir(eta) prior on the simplex."""
    V = int(V)
    counts = np.zeros(V, dtype=np.float64)
    for d in docs:
        for w, c in d:
            counts[w] += c
    smoothed = counts + float(eta)
    p = smoothed / smoothed.sum()
    return UnigramFit(eta=float(eta), V=V, counts=counts, log_p_word=np.log(p))


def unigram_perplexity(
    docs: Sequence[Sequence[Tuple[int, int]]],
    fit: UnigramFit,
) -> float:
    log_lik = 0.0
    n_tokens = 0
    for d in docs:
        for w, c in d:
            log_lik += int(c) * float(fit.log_p_word[int(w)])
            n_tokens += int(c)
    return float(np.exp(-log_lik / max(n_tokens, 1)))


# ---------------------------------------------------------------------------
# Mixture of unigrams (EM)
# ---------------------------------------------------------------------------


@dataclass
class MixtureUnigramsFit:
    K: int
    V: int
    pi: np.ndarray  # (K,) mixture weights
    beta: np.ndarray  # (K, V) word distributions per cluster
    log_lik_trace: List[float]


def fit_mixture_of_unigrams(
    docs: Sequence[Sequence[Tuple[int, int]]],
    K: int,
    V: int,
    n_iter: int = 50,
    eta: float = 0.01,
    seed: int = 0,
) -> MixtureUnigramsFit:
    """EM with a Dir(eta) smoothing prior on each component beta_k.

    Each document is assumed generated from a single latent cluster
    z_d in {1..K}, then the words are drawn i.i.d. from beta_z. This is
    pLSI's no-mixture-of-topics ancestor used in the paper's Table 1
    overfitting analysis.
    """
    rng = np.random.default_rng(int(seed))
    K = int(K)
    V = int(V)
    D = len(docs)
    pi = np.full(K, 1.0 / K)
    beta = rng.dirichlet(np.full(V, 1.0), size=K)
    log_lik_trace: List[float] = []
    doc_word_ids = [np.array([w for w, _ in d], dtype=int) for d in docs]
    doc_counts = [np.array([c for _, c in d], dtype=float) for d in docs]
    for it in range(int(n_iter)):
        log_beta = np.log(np.clip(beta, 1e-300, 1.0))
        log_pi = np.log(np.clip(pi, 1e-300, 1.0))
        log_resp = np.zeros((D, K))
        for d in range(D):
            wids = doc_word_ids[d]
            cnts = doc_counts[d]
            if len(wids) == 0:
                log_resp[d] = log_pi
            else:
                log_resp[d] = log_pi + (log_beta[:, wids] * cnts[None, :]).sum(axis=1)
        log_norm = logsumexp(log_resp, axis=1, keepdims=True)
        resp = np.exp(log_resp - log_norm)
        log_lik_trace.append(float(log_norm.sum()))
        pi = resp.mean(axis=0)
        new_beta = np.full((K, V), float(eta))
        for d in range(D):
            wids = doc_word_ids[d]
            cnts = doc_counts[d]
            if len(wids) == 0:
                continue
            r = resp[d]
            for k in range(K):
                new_beta[k, wids] += r[k] * cnts
        new_beta /= new_beta.sum(axis=1, keepdims=True)
        beta = new_beta
    return MixtureUnigramsFit(
        K=K, V=V, pi=pi, beta=beta, log_lik_trace=log_lik_trace,
    )


def mixture_unigrams_perplexity(
    docs: Sequence[Sequence[Tuple[int, int]]],
    fit: MixtureUnigramsFit,
) -> float:
    """Per-word held-out perplexity for the mixture of unigrams.

    p(d) = sum_k pi_k prod_w beta_kw^{c_w}
    """
    log_pi = np.log(np.clip(fit.pi, 1e-300, 1.0))
    log_beta = np.log(np.clip(fit.beta, 1e-300, 1.0))
    log_lik_total = 0.0
    n_tokens = 0
    for d in docs:
        if not d:
            continue
        wids = np.array([w for w, _ in d], dtype=int)
        cnts = np.array([c for _, c in d], dtype=float)
        per_k = log_pi + (log_beta[:, wids] * cnts[None, :]).sum(axis=1)
        log_p_d = float(logsumexp(per_k))
        log_lik_total += log_p_d
        n_tokens += int(cnts.sum())
    return float(np.exp(-log_lik_total / max(n_tokens, 1)))


# ---------------------------------------------------------------------------
# Convergence diagnostics shared across models
# ---------------------------------------------------------------------------


def relative_change(trace: Sequence[float]) -> List[float]:
    """Per-iteration relative change |x_t - x_{t-1}| / max(1, |x_{t-1}|)."""
    out: List[float] = []
    for i in range(1, len(trace)):
        prev = abs(float(trace[i - 1]))
        out.append(abs(float(trace[i]) - float(trace[i - 1])) / max(1.0, prev))
    return out


def is_monotone_increasing(trace: Sequence[float], tol: float = 1e-6) -> bool:
    """True if ``trace`` is non-decreasing within ``tol``."""
    arr = np.asarray(trace, dtype=float)
    if len(arr) < 2:
        return True
    return bool(np.all(np.diff(arr) >= -float(tol)))

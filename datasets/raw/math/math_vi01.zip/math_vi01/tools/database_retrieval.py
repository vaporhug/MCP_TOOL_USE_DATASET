"""Lightweight stubs for looking up dataset / corpus metadata.

The LDA reproduction task does not require any live external API; the
AP corpus and vocabulary file are bundled with the task. These helpers
return canned metadata that an agent could query before deciding which
file to load.
"""

from __future__ import annotations

from typing import Dict, List


_AP_METADATA: Dict[str, object] = {
    "name": "Associated Press",
    "source": "Blei, lda-c example/ap.tgz (TREC-1 1992 Harman release)",
    "num_documents": 2246,
    "vocab_size": 10473,
    "format": "LDA-C bag-of-words: 'M w1:c1 w2:c2 ...'",
    "description": (
        "Subset of the TREC-1 Associated Press newswire used by Blei, Ng, "
        "Jordan (JMLR 2003) to estimate Latent Dirichlet Allocation. The "
        "release here is the public ap.tgz tarball distributed with Blei's "
        "lda-c reference implementation."
    ),
    "preprocessing": (
        "Stop words from a standard 50-word list removed; words occurring "
        "only once removed (paper Section 7.1)."
    ),
    "files": ["ap_corpus.dat", "vocab.txt", "ap_documents.txt"],
}


def list_available_corpora() -> List[str]:
    """Return the corpora bundled with this task."""
    return ["ap"]


def get_corpus_metadata(name: str = "ap") -> Dict[str, object]:
    """Return a metadata dictionary for the named corpus."""
    if name.lower() == "ap":
        return dict(_AP_METADATA)
    raise KeyError(f"unknown corpus '{name}', available: {list_available_corpora()}")


def describe_lda_c_format() -> str:
    """Return a one-paragraph description of the LDA-C bag-of-words format."""
    return (
        "Each line of the .dat file encodes one document. The first whitespace-"
        "separated token is the integer M, the number of distinct vocabulary "
        "words present in the document. The remaining M tokens have the form "
        "w:c where w is a 0-based vocabulary index and c is the integer count. "
        "Words missing from the line are assumed to occur zero times."
    )


def describe_paper_corpus(name: str = "ap") -> Dict[str, object]:
    """Return Blei et al. 2003 reported statistics for the named corpus.

    The paper's experiments use 16,000 AP documents and a 5,225-abstract
    nematode corpus; the public AP release bundled here is a 2,246-document
    subset of the same TREC AP source.
    """
    if name.lower() == "ap":
        return {
            "paper_num_documents": 16000,
            "paper_vocab_after_preprocessing": "~10,000 unique terms",
            "paper_topic_grid": [10, 20, 50, 100, 200],
            "paper_perplexity_at_K200_LDA": "~2500 (Figure 9 bottom panel)",
            "paper_perplexity_at_K200_pLSI": 1.31e7,
            "paper_perplexity_at_K200_mixture_of_unigrams": 3.51e264,
        }
    if name.lower() == "nematode":
        return {
            "paper_num_documents": 5225,
            "paper_vocab_after_preprocessing": 28414,
            "paper_topic_grid": [5, 10, 20, 50, 100, 200],
        }
    raise KeyError(f"unknown corpus '{name}'")

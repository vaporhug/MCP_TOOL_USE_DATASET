"""Lightweight stubs for looking up dataset / corpus metadata.

The LDA reproduction task does not require any live external API; the
AP corpus and vocabulary file are bundled with the task. These helpers
return canned metadata that an agent could query before deciding which
file to load.
"""

from __future__ import annotations

from typing import Dict, List


_AP_METADATA: Dict[str, object] = {
    "name": "Associated Press",
    "source": "Blei, lda-c example/ap.tgz (TREC-1 1992 Harman release)",
    "num_documents": 2246,
    "vocab_size": 10473,
    "format": "LDA-C bag-of-words: 'M w1:c1 w2:c2 ...'",
    "description": (
        "Subset of the TREC-1 Associated Press newswire used by Blei, Ng, "
        "Jordan (JMLR 2003) to estimate Latent Dirichlet Allocation. The "
        "release here is the public ap.tgz tarball distributed with Blei's "
        "lda-c reference implementation."
    ),
    "preprocessing": (
        "The lda-c example/ap.tgz vocabulary contains 10,473 unique terms; "
        "Blei et al. 2003 Section 7.1 reports its 16,333-doc TREC AP subset "
        "was preprocessed with a 50-word stop list plus single-occurrence "
        "filter, but the public lda-c example README does not document the "
        "exact preprocessing-rule version used to produce ap.tgz, so the "
        "vocabulary here may have been built with a slightly different pass."
    ),
    "files": ["ap_corpus.dat", "vocab.txt"],
}


def list_available_corpora() -> List[str]:
    """Return the corpora bundled with this task."""
    return ["ap"]


def get_corpus_metadata(name: str = "ap") -> Dict[str, object]:
    """Return a metadata dictionary for the named corpus."""
    if name.lower() == "ap":
        return dict(_AP_METADATA)
    raise KeyError(f"unknown corpus '{name}', available: {list_available_corpora()}")


def describe_lda_c_format() -> str:
    """Return a one-paragraph description of the LDA-C bag-of-words format."""
    return (
        "Each line of the .dat file encodes one document. The first whitespace-"
        "separated token is the integer M, the number of distinct vocabulary "
        "words present in the document. The remaining M tokens have the form "
        "w:c where w is a 0-based vocabulary index and c is the integer count. "
        "Words missing from the line are assumed to occur zero times."
    )


def describe_paper_corpus(name: str = "ap") -> Dict[str, object]:
    """Return Blei et al. 2003 reported statistics for the named corpus.

    Section 7.1's perplexity-vs-K experiments use 16,333 AP documents
    (23,075 unique terms) and the 5,225-abstract C. Elegans nematode
    corpus (28,414 unique terms), with the topic grid k in
    {2, 5, 10, 20, 50, 100, 200} (paper Table 1). NB: the Section 6
    ILLUSTRATIVE example uses a 16,000-document AP subset for a
    single K=100 fit -- that is a different experiment from the
    Section 7.1 perplexity sweep referenced here. The public AP
    release bundled in this task (LDA-C example/ap.tgz) is a
    separate 2,246-document subset of the same TREC AP source, not
    the paper's 16,333-document Section 7.1 corpus.
    """
    if name.lower() == "ap":
        return {
            "paper_num_documents": 16333,
            "paper_vocab_after_preprocessing": 23075,
            "paper_topic_grid": [2, 5, 10, 20, 50, 100, 200],
            "paper_perplexity_at_K200_pLSI": 1.31e7,
            "paper_perplexity_at_K200_mixture_of_unigrams": 3.51e264,
            "section_6_illustrative_example_num_documents": 16000,
        }
    if name.lower() == "nematode":
        return {
            "paper_num_documents": 5225,
            "paper_vocab_after_preprocessing": 28414,
            "paper_topic_grid": [2, 5, 10, 20, 50, 100, 200],
        }
    raise KeyError(f"unknown corpus '{name}'")

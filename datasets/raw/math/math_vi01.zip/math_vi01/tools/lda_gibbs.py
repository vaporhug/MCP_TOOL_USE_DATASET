"""Collapsed Gibbs sampler for LDA (Griffiths & Steyvers 2004) used as
an MCMC baseline against the CAVI implementation in ``lda_cavi``.

The latent topic assignment z_{d,n} for every word is updated one at a
time, integrating out theta and beta analytically. We track the
collapsed log joint as a "monitoring statistic" so the agent can plot
it next to the variational ELBO trajectory.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Sequence, Tuple

import numpy as np
from scipy.special import gammaln


@dataclass
class GibbsState:
    """Persistent counts and assignments for the collapsed sampler."""

    K: int
    V: int
    D: int
    alpha: float
    eta: float
    n_dk: np.ndarray  # (D, K)  doc-topic counts
    n_kv: np.ndarray  # (K, V)  topic-word counts
    n_k: np.ndarray  # (K,)    total tokens per topic
    n_d: np.ndarray  # (D,)    total tokens per doc
    z: List[List[int]]  # z[d][i] is the topic of token i in doc d
    word_index: List[List[int]]  # word_index[d][i] is its vocab index
    log_joint_trace: List[float]


def _expand_doc(doc: Sequence[Tuple[int, int]]) -> List[int]:
    """Expand a (word, count) bag into a flat list of vocab indices."""
    out: List[int] = []
    for w, c in doc:
        out.extend([int(w)] * int(c))
    return out


def initialise_gibbs(
    docs: Sequence[Sequence[Tuple[int, int]]],
    K: int,
    V: int,
    alpha: float = 0.1,
    eta: float = 0.01,
    seed: int = 0,
) -> GibbsState:
    """Random initial topic assignment for every word in every document."""
    rng = np.random.default_rng(int(seed))
    K = int(K)
    V = int(V)
    D = len(docs)
    n_dk = np.zeros((D, K), dtype=np.int64)
    n_kv = np.zeros((K, V), dtype=np.int64)
    n_k = np.zeros(K, dtype=np.int64)
    n_d = np.zeros(D, dtype=np.int64)
    z: List[List[int]] = []
    wi: List[List[int]] = []
    for d, doc in enumerate(docs):
        words = _expand_doc(doc)
        zs = rng.integers(0, K, size=len(words)).tolist()
        for w, t in zip(words, zs):
            n_dk[d, t] += 1
            n_kv[t, w] += 1
            n_k[t] += 1
            n_d[d] += 1
        z.append(zs)
        wi.append(words)
    return GibbsState(
        K=K, V=V, D=D, alpha=float(alpha), eta=float(eta),
        n_dk=n_dk, n_kv=n_kv, n_k=n_k, n_d=n_d, z=z, word_index=wi,
        log_joint_trace=[],
    )


def gibbs_sweep(state: GibbsState, rng: np.random.Generator) -> None:
    """One pass of collapsed Gibbs over every token in the corpus."""
    K = state.K
    V = state.V
    alpha = state.alpha
    eta = state.eta
    eta_V = eta * V
    for d in range(state.D):
        zs = state.z[d]
        ws = state.word_index[d]
        for i, (t_old, w) in enumerate(zip(zs, ws)):
            state.n_dk[d, t_old] -= 1
            state.n_kv[t_old, w] -= 1
            state.n_k[t_old] -= 1
            num = (state.n_kv[:, w] + eta) * (state.n_dk[d] + alpha)
            den = state.n_k + eta_V
            p = num / den
            p_sum = float(p.sum())
            if not np.isfinite(p_sum) or p_sum <= 0.0:
                p = np.full(K, 1.0 / K)
            else:
                p = p / p_sum
            t_new = int(rng.choice(K, p=p))
            zs[i] = t_new
            state.n_dk[d, t_new] += 1
            state.n_kv[t_new, w] += 1
            state.n_k[t_new] += 1


def collapsed_log_joint(state: GibbsState) -> float:
    """log p(w, z | alpha, eta) marginalising out theta and beta."""
    K = state.K
    V = state.V
    alpha = state.alpha
    eta = state.eta
    n_dk = state.n_dk
    n_kv = state.n_kv
    n_k = state.n_k
    n_d = state.n_d
    val = 0.0
    val += state.D * (gammaln(K * alpha) - K * gammaln(alpha))
    val += float(gammaln(n_dk + alpha).sum())
    val -= float(gammaln(n_d + K * alpha).sum())
    val += K * (gammaln(V * eta) - V * gammaln(eta))
    val += float(gammaln(n_kv + eta).sum())
    val -= float(gammaln(n_k + V * eta).sum())
    return float(val)


def run_gibbs(
    docs: Sequence[Sequence[Tuple[int, int]]],
    K: int,
    V: int,
    n_iter: int = 200,
    burn_in: int = 50,
    alpha: float = 0.1,
    eta: float = 0.01,
    seed: int = 0,
) -> GibbsState:
    """Run the collapsed Gibbs sampler for ``n_iter`` sweeps."""
    state = initialise_gibbs(docs, K, V, alpha=alpha, eta=eta, seed=seed)
    rng = np.random.default_rng(int(seed) + 17)
    for it in range(int(n_iter)):
        gibbs_sweep(state, rng)
        state.log_joint_trace.append(float(collapsed_log_joint(state)))
    state_burn_in = int(burn_in)
    state.log_joint_trace = state.log_joint_trace  # keep full trace
    state_burn_in  # silence linter
    return state


def gibbs_topic_word_distribution(state: GibbsState) -> np.ndarray:
    """Posterior point estimate of ``beta_kv`` from the final state."""
    return (state.n_kv + state.eta) / (
        state.n_kv.sum(axis=1, keepdims=True) + state.eta * state.V
    )


def gibbs_doc_topic_distribution(state: GibbsState) -> np.ndarray:
    """Posterior point estimate of ``theta_dk`` from the final state."""
    return (state.n_dk + state.alpha) / (
        state.n_dk.sum(axis=1, keepdims=True) + state.alpha * state.K
    )


def gibbs_predictive_perplexity(
    obs_part: Sequence[Sequence[Tuple[int, int]]],
    held_part: Sequence[Sequence[Tuple[int, int]]],
    state: GibbsState,
    n_iter: int = 50,
    seed: int = 0,
) -> float:
    """Predictive perplexity using the trained Gibbs state.

    For each test document we run a small Gibbs chain for ``n_iter``
    sweeps with the topic-word counts held fixed, then evaluate the
    held-out tokens under the resulting (theta_d, beta) point estimate.
    """
    rng = np.random.default_rng(int(seed))
    K = state.K
    V = state.V
    alpha = state.alpha
    eta = state.eta
    eta_V = eta * V
    beta = gibbs_topic_word_distribution(state)
    log_lik = 0.0
    n_tokens = 0
    for obs, held in zip(obs_part, held_part):
        if not held:
            continue
        words = _expand_doc(obs)
        if not words:
            theta = np.full(K, 1.0 / K)
        else:
            zs = rng.integers(0, K, size=len(words)).tolist()
            n_dk = np.zeros(K, dtype=np.int64)
            for t in zs:
                n_dk[t] += 1
            for _ in range(int(n_iter)):
                for i, (t_old, w) in enumerate(zip(zs, words)):
                    n_dk[t_old] -= 1
                    p = (state.n_kv[:, w] + eta) / (state.n_k + eta_V) * (n_dk + alpha)
                    p_sum = float(p.sum())
                    if not np.isfinite(p_sum) or p_sum <= 0.0:
                        p = np.full(K, 1.0 / K)
                    else:
                        p = p / p_sum
                    t_new = int(rng.choice(K, p=p))
                    zs[i] = t_new
                    n_dk[t_new] += 1
            theta = (n_dk + alpha) / (n_dk.sum() + K * alpha)
        for w, c in held:
            p = float(theta @ beta[:, w])
            log_lik += int(c) * np.log(max(p, 1e-300))
            n_tokens += int(c)
    return float(np.exp(-log_lik / max(n_tokens, 1)))

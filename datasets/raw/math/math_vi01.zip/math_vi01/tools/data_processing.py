"""Data loading and corpus utilities for the LDA reproduction task.

The AP corpus file follows the LDA-C bag-of-words format used in
Blei's released distribution: each line is a single document encoded as

    M w_1:c_1 w_2:c_2 ... w_M:c_M

where ``M`` is the number of distinct vocabulary tokens in the document,
``w_i`` is the 0-based vocabulary index, and ``c_i`` is the integer
count of that token in the document. The companion ``vocab.txt`` file
holds the surface form of each vocabulary index, one word per line.

All functions in this module are pure-Python / numpy primitives: they
do not import scikit-learn, gensim, scipy.stats, nltk or any topic
modelling library. The agent is expected to chain these helpers to
build the data structures required by the variational inference and
Gibbs-sampling routines.
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import numpy as np


def load_vocab(vocab_path: str) -> List[str]:
    """Load a vocabulary file and return the list of surface forms.

    Parameters
    ----------
    vocab_path : str
        Path to a UTF-8 text file with one word per line.

    Returns
    -------
    list of str
        Word ``i`` is the surface form of vocabulary index ``i``.
    """
    words = Path(vocab_path).read_text(encoding="utf-8").splitlines()
    return [w.strip() for w in words]


def load_lda_c_corpus(corpus_path: str) -> List[List[Tuple[int, int]]]:
    """Load a corpus stored in the LDA-C ``M w:c w:c ...`` format.

    Returns
    -------
    list of list of (int, int)
        ``out[d]`` is a list of ``(word_index, count)`` tuples giving the
        bag-of-words representation of document ``d``.
    """
    docs: List[List[Tuple[int, int]]] = []
    with open(corpus_path, "r", encoding="utf-8") as handle:
        for raw in handle:
            raw = raw.strip()
            if not raw:
                continue
            parts = raw.split()
            n_unique = int(parts[0])
            entries: List[Tuple[int, int]] = []
            for token in parts[1:]:
                w_str, c_str = token.split(":")
                entries.append((int(w_str), int(c_str)))
            assert len(entries) == n_unique, (
                f"document declared {n_unique} unique tokens but got {len(entries)}"
            )
            docs.append(entries)
    return docs


def corpus_statistics(
    docs: Sequence[Sequence[Tuple[int, int]]],
    vocab_size: int,
) -> Dict[str, float]:
    """Summarise a bag-of-words corpus.

    Returns a dict with keys: ``num_documents``, ``vocab_size``,
    ``total_tokens``, ``mean_tokens_per_doc``, ``median_tokens_per_doc``,
    ``max_tokens_per_doc``, ``mean_unique_per_doc``,
    ``mean_doc_freq_per_word``, ``num_words_with_zero_count``.
    """
    lengths = np.array([sum(c for _, c in d) for d in docs], dtype=float)
    uniques = np.array([len(d) for d in docs], dtype=float)
    df = np.zeros(vocab_size, dtype=int)
    for d in docs:
        for w, _ in d:
            df[w] += 1
    return {
        "num_documents": int(len(docs)),
        "vocab_size": int(vocab_size),
        "total_tokens": float(lengths.sum()),
        "mean_tokens_per_doc": float(lengths.mean()) if len(lengths) else 0.0,
        "median_tokens_per_doc": float(np.median(lengths)) if len(lengths) else 0.0,
        "max_tokens_per_doc": float(lengths.max()) if len(lengths) else 0.0,
        "mean_unique_per_doc": float(uniques.mean()) if len(uniques) else 0.0,
        "mean_doc_freq_per_word": float(df.mean()),
        "num_words_with_zero_count": int((df == 0).sum()),
    }


def docs_to_count_matrix(
    docs: Sequence[Sequence[Tuple[int, int]]],
    vocab_size: int,
) -> np.ndarray:
    """Convert a sparse bag-of-words list into a dense ``D x V`` matrix.

    Use sparingly when ``D * V`` fits in memory. The function exists so
    that small smoke tests and the empirical word-frequency utilities
    have a uniform array interface.
    """
    D = len(docs)
    out = np.zeros((D, int(vocab_size)), dtype=np.float64)
    for d, doc in enumerate(docs):
        for w, c in doc:
            out[d, w] = c
    return out


def split_train_test(
    docs: Sequence[Sequence[Tuple[int, int]]],
    test_fraction: float = 0.1,
    seed: int = 0,
) -> Tuple[List[List[Tuple[int, int]]], List[List[Tuple[int, int]]]]:
    """Random document-level split for held-out perplexity evaluation.

    The default ``test_fraction=0.1`` matches the paper's Section 7.1
    90/10 document-level split convention. See ``split_words_in_doc``
    below for the per-document word-level split needed for
    document-completion held-out perplexity (where fit-gamma and
    scored-word sets are disjoint).
    """
    rng = np.random.default_rng(int(seed))
    D = len(docs)
    n_test = int(round(D * float(test_fraction)))
    perm = rng.permutation(D)
    test_idx = set(perm[:n_test].tolist())
    train: List[List[Tuple[int, int]]] = []
    test: List[List[Tuple[int, int]]] = []
    for i, d in enumerate(docs):
        (test if i in test_idx else train).append(list(d))
    return train, test


def split_words_in_doc(
    doc: Sequence[Tuple[int, int]],
    test_fraction: float,
    seed: int,
) -> Tuple[List[Tuple[int, int]], List[Tuple[int, int]]]:
    """Per-document word-level split used for predictive perplexity.

    Each unit-count token is independently assigned to the held-out
    portion with probability ``test_fraction``. Returns
    ``(observed, held_out)`` bag-of-words tuples.
    """
    rng = np.random.default_rng(int(seed))
    obs: Dict[int, int] = {}
    held: Dict[int, int] = {}
    for w, c in doc:
        for _ in range(int(c)):
            if rng.random() < float(test_fraction):
                held[w] = held.get(w, 0) + 1
            else:
                obs[w] = obs.get(w, 0) + 1
    return sorted(obs.items()), sorted(held.items())


def remove_low_frequency_words(
    docs: Sequence[Sequence[Tuple[int, int]]],
    vocab: Sequence[str],
    min_doc_count: int = 2,
) -> Tuple[List[List[Tuple[int, int]]], List[str], np.ndarray]:
    """Drop vocabulary words appearing in fewer than ``min_doc_count`` docs.

    Returns the filtered ``docs``, the new ``vocab`` list, and an integer
    array ``new_index_for_old`` of length ``len(vocab)`` mapping the old
    vocabulary indices to the new ones (-1 for dropped words).
    """
    V = len(vocab)
    df = np.zeros(V, dtype=int)
    for d in docs:
        for w, _ in d:
            df[w] += 1
    keep = df >= int(min_doc_count)
    new_index = -np.ones(V, dtype=int)
    new_index[keep] = np.arange(int(keep.sum()))
    new_vocab = [vocab[i] for i in range(V) if keep[i]]
    new_docs: List[List[Tuple[int, int]]] = []
    for d in docs:
        nd: List[Tuple[int, int]] = []
        for w, c in d:
            ni = int(new_index[w])
            if ni >= 0:
                nd.append((ni, int(c)))
        new_docs.append(nd)
    return new_docs, new_vocab, new_index


def total_token_count(docs: Sequence[Sequence[Tuple[int, int]]]) -> int:
    """Sum of token counts across the whole corpus."""
    return int(sum(int(c) for d in docs for _, c in d))


def word_count_array(
    docs: Sequence[Sequence[Tuple[int, int]]],
    vocab_size: int,
) -> np.ndarray:
    """Total number of times each vocabulary word appears in the corpus."""
    counts = np.zeros(int(vocab_size), dtype=np.float64)
    for d in docs:
        for w, c in d:
            counts[w] += c
    return counts


def doc_lengths(docs: Sequence[Sequence[Tuple[int, int]]]) -> np.ndarray:
    """Length (token count, not unique-word count) of each document."""
    return np.array([sum(int(c) for _, c in d) for d in docs], dtype=np.float64)

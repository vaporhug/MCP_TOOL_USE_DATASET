"""PC-algorithm primitives: skeleton phase + collider orientation +
Meek rule propagation.

Constraint-based DAG learning. The pipeline is

    1. Start from the complete undirected graph.
    2. For increasing conditioning-set size m = 0, 1, 2, ...
       remove every edge (i, j) for which there exists a
       conditioning subset S of size m drawn from the current
       neighbours of i (or j) such that i is conditionally
       independent of j given S. Record S as the separating set.
    3. Orient every triple i - k - j with k NOT in sep(i, j) as the
       collider i -> k <- j.
    4. Propagate Meek's three orientation rules until quiescence.

The output is a CPDAG (partially directed acyclic graph) represented
as a (p, p) integer matrix A with the convention

    A[i, j] = 1  iff there is an arc i -> j (or an undirected
                   edge i - j when A[j, i] is also 1).

Pure numpy. No networkx, no scipy.
"""
from __future__ import annotations

from typing import Dict, FrozenSet, List, Optional, Sequence, Set, Tuple
from itertools import combinations
import numpy as np

from .independence import conditional_independence_test


def complete_undirected_skeleton(p: int) -> np.ndarray:
    """Return the (p, p) adjacency of the complete undirected graph
    over `p` nodes (1 everywhere off the diagonal).
    """
    A = np.ones((p, p), dtype=int) - np.eye(p, dtype=int)
    return A


def pc_skeleton(matrix: np.ndarray,
                alpha: float = 0.05,
                max_cond_size: int = 3) -> Dict:
    """Run the PC-skeleton phase of the PC algorithm.

    Parameters
    ----------
    matrix : array-like, shape (n, p)
        The data matrix; columns are nodes.
    alpha : float
        Fisher-z p-value threshold for declaring conditional
        independence.
    max_cond_size : int
        Maximum conditioning-set cardinality to try. The PC
        algorithm is exact in the limit max_cond_size = p - 2,
        but in practice 3 to 5 suffices and keeps runtime O(p^4).

    Returns
    -------
    dict with keys
        adjacency : (p, p) int ndarray (symmetric, 0/1).
        sep_sets  : dict mapping frozenset({i, j}) to tuple of
                    column indices that separated them.
        n_tests   : int, total CI tests carried out.
    """
    arr = np.asarray(matrix, dtype=float)
    p = arr.shape[1]
    A = complete_undirected_skeleton(p)
    sep: Dict[FrozenSet[int], Tuple[int, ...]] = {}
    n_tests = 0
    for m in range(0, max_cond_size + 1):
        # Edge list snapshot at the start of this level.
        edges = [(i, j) for i in range(p) for j in range(i + 1, p) if A[i, j]]
        for (i, j) in edges:
            if not A[i, j]:
                continue
            # Candidate conditioning sets are subsets of neighbours
            # of i or j (in the current graph) excluding j or i.
            adj_i = [k for k in range(p) if k != j and A[i, k]]
            adj_j = [k for k in range(p) if k != i and A[j, k]]
            # Use the larger adjacency set so the PC test is symmetric
            candidates = adj_i if len(adj_i) >= len(adj_j) else adj_j
            if len(candidates) < m:
                continue
            removed = False
            for S in combinations(candidates, m):
                n_tests += 1
                test = conditional_independence_test(arr, i, j, list(S),
                                                    alpha=alpha)
                if test["independent"]:
                    A[i, j] = 0
                    A[j, i] = 0
                    sep[frozenset({i, j})] = tuple(S)
                    removed = True
                    break
            # If removed, move on; otherwise keep edge.
            del removed
    return {"adjacency": A, "sep_sets": sep, "n_tests": int(n_tests)}


def orient_v_structures(skeleton: np.ndarray,
                        sep_sets: Dict[FrozenSet[int], Tuple[int, ...]]
                        ) -> np.ndarray:
    """Orient unshielded colliders i - k - j as i -> k <- j when k is
    not in the separating set of {i, j}.

    Parameters
    ----------
    skeleton : (p, p) int ndarray, symmetric 0/1.
    sep_sets : mapping frozenset({i, j}) -> sep set tuple.

    Returns
    -------
    numpy.ndarray, (p, p) int matrix where for every collider
        A[i, k] = 1, A[k, i] = 0, A[j, k] = 1, A[k, j] = 0.
    Other still-undirected edges remain symmetric (A[i, j] = A[j, i] = 1).
    """
    A = skeleton.copy()
    p = A.shape[0]
    for k in range(p):
        # Find all i < j both adjacent to k, with i and j NOT adjacent
        # to each other in the skeleton.
        nbrs = [q for q in range(p) if A[k, q] == 1 and A[q, k] == 1]
        for a_idx, i in enumerate(nbrs):
            for j in nbrs[a_idx + 1:]:
                if A[i, j] == 1 or A[j, i] == 1:
                    continue
                S = sep_sets.get(frozenset({i, j}), None)
                if S is None:
                    continue
                if k in S:
                    continue
                # Orient i -> k <- j
                A[k, i] = 0
                A[k, j] = 0
                # A[i, k] and A[j, k] remain 1
    return A


def _has_directed_edge(A: np.ndarray, i: int, j: int) -> bool:
    return A[i, j] == 1 and A[j, i] == 0


def _has_undirected_edge(A: np.ndarray, i: int, j: int) -> bool:
    return A[i, j] == 1 and A[j, i] == 1


def apply_meek_rules(adjacency: np.ndarray,
                     max_iter: int = 20) -> np.ndarray:
    """Apply Meek's three orientation rules until no more orientations
    can be made.

    R1: if i -> j and j - k with i, k not adjacent, orient j -> k.
    R2: if i -> j and j -> k and i - k, orient i -> k.
    R3: if i - k, i - l, k -> j, l -> j, k and l not adjacent, orient
        i -> j.

    Parameters
    ----------
    adjacency : (p, p) int ndarray after collider orientation.
    max_iter : int
        Safety cap on outer iterations; convergence is usually 2-3.

    Returns
    -------
    numpy.ndarray of same shape (the CPDAG).
    """
    A = adjacency.copy()
    p = A.shape[0]
    for _ in range(max_iter):
        changed = False
        for i in range(p):
            for j in range(p):
                if i == j:
                    continue
                # R1: i -> j, j - k, i and k not adjacent => orient j -> k
                if _has_directed_edge(A, i, j):
                    for k in range(p):
                        if k == i or k == j:
                            continue
                        if _has_undirected_edge(A, j, k) and A[i, k] == 0 and A[k, i] == 0:
                            A[k, j] = 0  # leaves j -> k
                            changed = True
                # R2: i -> j -> k, i - k => orient i -> k
                if _has_directed_edge(A, i, j):
                    for k in range(p):
                        if k == i or k == j:
                            continue
                        if _has_directed_edge(A, j, k) and _has_undirected_edge(A, i, k):
                            A[k, i] = 0  # leaves i -> k
                            changed = True
        # R3: i - j and there are k, l with i - k, i - l, k -> j, l -> j,
        # k and l not adjacent.
        for i in range(p):
            for j in range(p):
                if i == j:
                    continue
                if not _has_undirected_edge(A, i, j):
                    continue
                # Find candidate k, l.
                cands = [k for k in range(p)
                         if k != i and k != j
                         and _has_undirected_edge(A, i, k)
                         and _has_directed_edge(A, k, j)]
                # Need two such with k, l non-adjacent.
                for a_idx, k in enumerate(cands):
                    for l in cands[a_idx + 1:]:
                        if A[k, l] == 0 and A[l, k] == 0:
                            A[j, i] = 0  # leaves i -> j
                            changed = True
                            break
                    if not _has_undirected_edge(A, i, j):
                        break
        if not changed:
            break
    return A


def run_pc_algorithm(matrix: np.ndarray,
                     alpha: float = 0.05,
                     max_cond_size: int = 3) -> Dict:
    """End-to-end PC pipeline returning a CPDAG.

    Returns a dict with keys 'adjacency', 'sep_sets', 'n_tests'.
    The agent typically calls this then passes 'adjacency' to the
    DAG-comparison helpers.
    """
    skel = pc_skeleton(matrix, alpha=alpha, max_cond_size=max_cond_size)
    after_v = orient_v_structures(skel["adjacency"], skel["sep_sets"])
    cpdag = apply_meek_rules(after_v)
    return {"adjacency": cpdag, "sep_sets": skel["sep_sets"],
            "n_tests": skel["n_tests"]}

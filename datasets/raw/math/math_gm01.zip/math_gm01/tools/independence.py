"""Conditional-independence and partial-correlation primitives.

Pure numpy implementations. The Fisher z-transform of a partial
correlation gives an asymptotic test for zero conditional correlation
between two variables given a conditioning set, which is the building
block of the PC algorithm.

No scipy, no sklearn imports.
"""
from __future__ import annotations

from typing import Dict, Iterable, List, Optional, Sequence, Tuple
import math
import numpy as np


def _safe_inv(M: np.ndarray, ridge: float = 1e-8) -> np.ndarray:
    """Invert a small matrix with an optional ridge for numerical safety."""
    M = np.asarray(M, dtype=float)
    n = M.shape[0]
    return np.linalg.inv(M + ridge * np.eye(n))


def correlation_matrix(matrix: np.ndarray) -> np.ndarray:
    """Return the (p, p) Pearson correlation matrix of the columns.

    Parameters
    ----------
    matrix : array-like, shape (n, p)

    Returns
    -------
    numpy.ndarray of shape (p, p)
    """
    arr = np.asarray(matrix, dtype=float)
    arr = arr - arr.mean(axis=0, keepdims=True)
    sd = arr.std(axis=0, ddof=1, keepdims=True)
    sd = np.where(sd < 1e-12, 1.0, sd)
    z = arr / sd
    n = arr.shape[0]
    return (z.T @ z) / max(n - 1, 1)


def partial_correlation(matrix: np.ndarray, i: int, j: int,
                        cond: Sequence[int]) -> float:
    """Pearson partial correlation between columns i and j given `cond`.

    Implementation: regress columns i and j separately on the columns
    in `cond` (with an intercept), then return the Pearson correlation
    of the two residual vectors. Uses an OLS solve so it works for any
    cardinality of `cond`, including the empty set.

    Parameters
    ----------
    matrix : array-like, shape (n, p)
    i, j : int
        Column indices of the two variables of interest.
    cond : sequence of int
        Indices of conditioning columns (may be empty).

    Returns
    -------
    float in [-1, 1]
    """
    arr = np.asarray(matrix, dtype=float)
    n = arr.shape[0]
    yi = arr[:, i]
    yj = arr[:, j]
    if len(cond) == 0:
        ai = yi - yi.mean()
        aj = yj - yj.mean()
    else:
        Z = arr[:, list(cond)]
        Z = np.column_stack([np.ones(n), Z])
        # OLS via lstsq is numerically robust
        beta_i, *_ = np.linalg.lstsq(Z, yi, rcond=None)
        beta_j, *_ = np.linalg.lstsq(Z, yj, rcond=None)
        ai = yi - Z @ beta_i
        aj = yj - Z @ beta_j
    sdi = float(np.sqrt(np.sum(ai * ai)))
    sdj = float(np.sqrt(np.sum(aj * aj)))
    if sdi < 1e-12 or sdj < 1e-12:
        return 0.0
    return float(np.dot(ai, aj) / (sdi * sdj))


def _norm_cdf(x: float) -> float:
    """Standard-normal CDF using math.erf — avoids scipy."""
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def fisher_z_test(rho: float, n: int, k: int) -> Dict[str, float]:
    """Two-sided Fisher z-test for zero partial correlation.

    The transformed statistic is
        z = sqrt(n - k - 3) * 0.5 * log((1+rho)/(1-rho))
    which is approximately standard-normal under H0: rho = 0 given
    `k` conditioning variables and `n` observations.

    Parameters
    ----------
    rho : float
        Partial correlation in (-1, 1).
    n : int
        Number of observations.
    k : int
        Cardinality of the conditioning set.

    Returns
    -------
    dict with keys 'z', 'p_value'.
    """
    rho = max(min(float(rho), 0.999999), -0.999999)
    df = max(n - k - 3, 1)
    z = math.sqrt(df) * 0.5 * math.log((1.0 + rho) / (1.0 - rho))
    p = 2.0 * (1.0 - _norm_cdf(abs(z)))
    return {"z": float(z), "p_value": float(p)}


def conditional_independence_test(matrix: np.ndarray, i: int, j: int,
                                  cond: Sequence[int],
                                  alpha: float = 0.05) -> Dict[str, float]:
    """Run a Fisher-z conditional-independence test on (i, j | cond).

    Returns a dict with keys 'rho', 'p_value', 'independent' so that the
    PC-skeleton routine can branch on a single call.

    Parameters
    ----------
    matrix : array-like, shape (n, p)
    i, j : int
    cond : sequence of int
    alpha : float
        Significance level above which we declare conditional
        independence (i.e. fail to reject H0: rho = 0).

    Returns
    -------
    dict with keys 'rho', 'p_value', 'independent'.
    """
    n = np.asarray(matrix).shape[0]
    rho = partial_correlation(matrix, i, j, cond)
    res = fisher_z_test(rho, n=n, k=len(cond))
    return {
        "rho": float(rho),
        "p_value": float(res["p_value"]),
        "independent": bool(res["p_value"] > alpha),
    }


def all_marginal_correlations(matrix: np.ndarray) -> np.ndarray:
    """Convenience wrapper around `correlation_matrix` for the marginal step.

    Returns a (p, p) symmetric matrix of marginal Pearson correlations.
    """
    return correlation_matrix(matrix)

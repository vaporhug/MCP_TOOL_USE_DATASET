"""Score-based DAG search primitives.

Two scorers are exposed:

- bic_gaussian_node : per-node Gaussian BIC for node X_j given parents
  Pa_j, computed as
        BIC = -n * log(sigma_hat^2) - log(n) * (|Pa_j| + 1)
  where sigma_hat^2 is the residual variance of an OLS regression of
  X_j on Pa_j (or just the empirical variance if Pa_j is empty).

- bic_total : sum of per-node BIC scores over all nodes; the global
  score that hill-climbing maximises.

The search routine `greedy_hill_climb_bic` implements a canonical
score-based DAG search with three operators (add, delete, reverse)
under an acyclicity constraint and an optional maximum in-degree
budget. This is the same primitive that GES-style algorithms rely on.

No sklearn / networkx imports.
"""
from __future__ import annotations

from typing import Dict, List, Optional, Sequence, Tuple
import math
import numpy as np


def bic_gaussian_node(matrix: np.ndarray, j: int,
                      parents: Sequence[int]) -> float:
    """Per-node Gaussian BIC for X_j given parents.

    Higher is better. Computed as
        score = -0.5 * n * log(rss / n) - 0.5 * (|Pa_j| + 1) * log(n)
    after fitting an OLS regression of X_j on the parents (with an
    intercept). When parents is empty the OLS reduces to the sample
    mean.

    Parameters
    ----------
    matrix : array-like, shape (n, p)
    j : int
        Index of the child node.
    parents : sequence of int
        Indices of parent columns (may be empty).

    Returns
    -------
    float
        Penalised log-likelihood of node j.
    """
    arr = np.asarray(matrix, dtype=float)
    n = arr.shape[0]
    y = arr[:, j]
    if len(parents) == 0:
        rss = float(np.sum((y - y.mean()) ** 2))
        k = 1
    else:
        Z = np.column_stack([np.ones(n), arr[:, list(parents)]])
        beta, *_ = np.linalg.lstsq(Z, y, rcond=None)
        resid = y - Z @ beta
        rss = float(np.sum(resid * resid))
        k = len(parents) + 1
    sigma2 = max(rss / n, 1e-12)
    return -0.5 * n * math.log(sigma2) - 0.5 * k * math.log(max(n, 2))


def bic_total(matrix: np.ndarray, dag: np.ndarray) -> float:
    """Sum of per-node BIC scores over a DAG.

    Parameters
    ----------
    matrix : (n, p) array-like
    dag : (p, p) int adjacency, with dag[i, j] = 1 iff i -> j.

    Returns
    -------
    float
    """
    A = np.asarray(dag, dtype=int)
    p = A.shape[0]
    total = 0.0
    for j in range(p):
        parents = [i for i in range(p) if A[i, j] == 1]
        total += bic_gaussian_node(matrix, j, parents)
    return float(total)


def has_path(adj: np.ndarray, src: int, dst: int) -> bool:
    """Return True iff a directed path src -> ... -> dst exists in `adj`.

    Implemented via iterative depth-first search over the directed
    adjacency.
    """
    A = np.asarray(adj, dtype=int)
    p = A.shape[0]
    if src == dst:
        return True
    visited = [False] * p
    stack = [src]
    while stack:
        u = stack.pop()
        if visited[u]:
            continue
        visited[u] = True
        for v in range(p):
            if A[u, v] == 1 and not visited[v]:
                if v == dst:
                    return True
                stack.append(v)
    return False


def is_acyclic(adj: np.ndarray) -> bool:
    """Check whether the directed adjacency `adj` is a DAG.

    Uses Kahn's algorithm (topological-sort feasibility).
    """
    A = np.asarray(adj, dtype=int).copy()
    p = A.shape[0]
    indeg = [int(A[:, j].sum()) for j in range(p)]
    queue = [j for j in range(p) if indeg[j] == 0]
    visited = 0
    while queue:
        u = queue.pop()
        visited += 1
        for v in range(p):
            if A[u, v] == 1:
                indeg[v] -= 1
                if indeg[v] == 0:
                    queue.append(v)
                A[u, v] = 0
    return visited == p


def _candidate_operations(A: np.ndarray, max_in_degree: int):
    """Yield (op, i, j) tuples: 'add', 'del', 'rev'."""
    p = A.shape[0]
    for i in range(p):
        for j in range(p):
            if i == j:
                continue
            if A[i, j] == 0 and A[j, i] == 0:
                # Could add i -> j; check in-degree budget.
                indeg_j = int(A[:, j].sum())
                if indeg_j < max_in_degree:
                    yield ("add", i, j)
            elif A[i, j] == 1 and A[j, i] == 0:
                yield ("del", i, j)
                # Reversal candidate: i -> j becomes j -> i.
                indeg_i = int(A[:, i].sum())
                if indeg_i < max_in_degree:
                    yield ("rev", i, j)


def _apply_operation(A: np.ndarray, op: str, i: int, j: int) -> np.ndarray:
    """Return a copy of A with the operation applied."""
    B = A.copy()
    if op == "add":
        B[i, j] = 1
    elif op == "del":
        B[i, j] = 0
    elif op == "rev":
        B[i, j] = 0
        B[j, i] = 1
    return B


def greedy_hill_climb_bic(matrix: np.ndarray,
                          init_dag: Optional[np.ndarray] = None,
                          max_in_degree: int = 4,
                          max_iter: int = 200,
                          tol: float = 1e-6) -> Dict:
    """Greedy hill-climbing search over DAGs maximising the Gaussian BIC.

    At each step every legal add / delete / reverse operation that
    preserves acyclicity is scored; the best-improving move is accepted.
    Search stops when no operator improves the BIC.

    Parameters
    ----------
    matrix : (n, p) array
    init_dag : optional (p, p) int adjacency
        Starting graph; defaults to the empty graph.
    max_in_degree : int
        Maximum number of parents per node (computational guardrail).
    max_iter : int
        Hard cap on iterations.
    tol : float
        Minimum BIC improvement to accept a move.

    Returns
    -------
    dict with keys
        adjacency : (p, p) int ndarray, the learnt DAG.
        score     : final BIC.
        history   : list of (iteration, score) tuples.
        n_iter    : iterations actually run.
    """
    arr = np.asarray(matrix, dtype=float)
    p = arr.shape[1]
    if init_dag is None:
        A = np.zeros((p, p), dtype=int)
    else:
        A = np.asarray(init_dag, dtype=int).copy()
    score = bic_total(arr, A)
    history = [(0, score)]
    for it in range(1, max_iter + 1):
        best_delta = 0.0
        best_op = None
        best_A = None
        for (op, i, j) in _candidate_operations(A, max_in_degree):
            cand = _apply_operation(A, op, i, j)
            if not is_acyclic(cand):
                continue
            cand_score = bic_total(arr, cand)
            delta = cand_score - score
            if delta > best_delta + tol:
                best_delta = delta
                best_op = (op, i, j)
                best_A = cand
        if best_A is None:
            break
        A = best_A
        score = score + best_delta
        history.append((it, score))
    return {"adjacency": A, "score": float(score),
            "history": history, "n_iter": len(history) - 1}

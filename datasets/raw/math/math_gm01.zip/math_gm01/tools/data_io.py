"""Data input/output and basic preprocessing primitives for the
multiparameter single-cell signaling dataset.

All functions operate on numpy arrays and pandas DataFrames. There are no
sklearn / networkx / scipy imports anywhere in the agent-facing tools; the
DAG learning pipeline is built from scratch on numpy linear-algebra
primitives.
"""
from __future__ import annotations

from typing import Dict, List, Optional, Tuple
import os
import numpy as np
import pandas as pd


def load_protein_matrix(path: str) -> pd.DataFrame:
    """Load a single-cell phosphoprotein expression CSV.

    The file has one row per cell and one column per protein, with the
    header carrying the protein name (Raf, Mek, Plcg, PIP2, PIP3, Erk,
    Akt, PKA, PKC, P38, Jnk).

    Parameters
    ----------
    path : str
        Filesystem path to the CSV file.

    Returns
    -------
    pandas.DataFrame
        Shape (n_cells, n_proteins). Column order is preserved.
    """
    return pd.read_csv(path)


def load_edge_list(path: str) -> List[Tuple[str, str]]:
    """Load a directed-edge list CSV with columns (from, to).

    Parameters
    ----------
    path : str

    Returns
    -------
    list of (str, str)
        Each tuple is (parent, child) of a directed edge.
    """
    df = pd.read_csv(path)
    df.columns = [c.lower() for c in df.columns]
    return [(str(r["from"]), str(r["to"])) for _, r in df.iterrows()]


def log_transform(matrix: np.ndarray, eps: float = 1.0) -> np.ndarray:
    """Apply natural-log transform after a small additive shift.

    Single-cell flow-cytometry signal is roughly log-normally distributed,
    so log10 / log_e stabilises the variance before partial-correlation
    or BIC computations. The shift `eps` keeps zeros finite.

    Parameters
    ----------
    matrix : array-like, shape (n_cells, n_proteins).
    eps : float
        Small additive floor before taking the log.

    Returns
    -------
    numpy.ndarray
        Same shape, log-transformed.
    """
    arr = np.asarray(matrix, dtype=float)
    return np.log(np.maximum(arr, 0.0) + eps)


def standardize_columns(matrix: np.ndarray) -> np.ndarray:
    """Centre and scale each column to zero mean, unit variance.

    Parameters
    ----------
    matrix : array-like, shape (n_rows, n_cols).

    Returns
    -------
    numpy.ndarray
    """
    arr = np.asarray(matrix, dtype=float)
    mu = arr.mean(axis=0, keepdims=True)
    sd = arr.std(axis=0, ddof=1, keepdims=True)
    sd = np.where(sd < 1e-12, 1.0, sd)
    return (arr - mu) / sd


def column_names(df: pd.DataFrame) -> List[str]:
    """Return the column names of a DataFrame as a Python list.

    A trivial helper kept as an explicit primitive so that the agent can
    use it for variable indexing without importing pandas in its own
    code.
    """
    return [str(c) for c in df.columns]


def subsample_rows(matrix: np.ndarray, n: int,
                   seed: Optional[int] = None,
                   replace: bool = True) -> np.ndarray:
    """Draw `n` rows from `matrix` with or without replacement.

    Useful for non-parametric bootstraps over the cell axis when
    estimating edge stability.

    Parameters
    ----------
    matrix : array-like, shape (n_rows, n_cols).
    n : int
        Number of rows in the resampled matrix.
    seed : int, optional
    replace : bool
        Sample with replacement (default) for the standard non-parametric
        bootstrap, or without replacement for a sub-sample bootstrap.

    Returns
    -------
    numpy.ndarray of shape (n, n_cols)
    """
    rng = np.random.default_rng(seed)
    arr = np.asarray(matrix, dtype=float)
    idx = rng.choice(arr.shape[0], size=n, replace=replace)
    return arr[idx]

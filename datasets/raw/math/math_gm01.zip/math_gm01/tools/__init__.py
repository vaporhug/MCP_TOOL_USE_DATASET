"""Structure-learning toolbox for the single-cell flow-cytometry task.

Modules
-------
data_io         : matrix/edge-list loaders, log-transform, standardise,
                  bootstrap row sampling.
independence    : marginal/partial correlations and the Fisher z-test
                  used as the conditional-independence oracle.
pc_algorithm    : skeleton phase, collider orientation, Meek rules,
                  end-to-end PC routine returning a CPDAG.
score_search    : per-node and total Gaussian BIC, acyclicity check,
                  greedy hill-climbing search over DAGs.
dag_metrics     : edge-list <-> adjacency conversions, structural
                  Hamming distance, directed-edge precision/recall/F1,
                  skeleton precision/recall.
bootstrap       : non-parametric edge-frequency bootstrap, frequency
                  threshold, top-k extraction.
plots           : DAG visualisation, edge stability heatmap, SHD bar
                  chart, BIC trajectory.
"""

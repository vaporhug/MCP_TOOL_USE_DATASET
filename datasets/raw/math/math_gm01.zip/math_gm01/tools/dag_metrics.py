"""DAG comparison metrics: SHD, precision, recall, F1, skeleton-F1.

The structural Hamming distance (SHD) between two DAGs counts the
number of edge insertions, deletions and reversals required to turn
one into the other. We use the convention from Tsamardinos et al.
(2006): each missing edge counts 1, each extra edge counts 1, and
each reversed edge counts 1 (NOT 2).

There is also a skeleton-only metric that ignores arc directions, and
a directed-precision/recall metric that requires matching direction.

No sklearn / networkx imports.
"""
from __future__ import annotations

from typing import Dict, List, Sequence, Set, Tuple
import numpy as np


def edge_list_to_adjacency(edges: Sequence[Tuple[str, str]],
                           node_names: Sequence[str]) -> np.ndarray:
    """Convert an iterable of (parent_name, child_name) tuples into a
    (p, p) integer adjacency aligned to `node_names`.

    Parameters
    ----------
    edges : sequence of (str, str)
    node_names : sequence of str
        Master ordering. Edges that reference unknown names are skipped
        with a warning printed to stdout.

    Returns
    -------
    numpy.ndarray of shape (p, p) with dtype int.
    """
    p = len(node_names)
    name_to_idx = {n: k for k, n in enumerate(node_names)}
    A = np.zeros((p, p), dtype=int)
    for u, v in edges:
        if u not in name_to_idx or v not in name_to_idx:
            print(f"[edge_list_to_adjacency] dropping unknown edge {u}->{v}")
            continue
        A[name_to_idx[u], name_to_idx[v]] = 1
    return A


def adjacency_to_edge_list(A: np.ndarray,
                           node_names: Sequence[str]) -> List[Tuple[str, str]]:
    """Inverse of `edge_list_to_adjacency`.

    Returns directed edges only (i.e. only positions where A[i, j] = 1
    and A[j, i] = 0) plus undirected edges represented as both (i, j)
    and (j, i) when both entries are 1.
    """
    out: List[Tuple[str, str]] = []
    p = len(node_names)
    for i in range(p):
        for j in range(p):
            if i == j:
                continue
            if A[i, j] == 1:
                out.append((node_names[i], node_names[j]))
    return out


def _undirected_edge_set(A: np.ndarray) -> Set[Tuple[int, int]]:
    p = A.shape[0]
    s: Set[Tuple[int, int]] = set()
    for i in range(p):
        for j in range(i + 1, p):
            if A[i, j] == 1 or A[j, i] == 1:
                s.add((i, j))
    return s


def _directed_edge_set(A: np.ndarray) -> Set[Tuple[int, int]]:
    p = A.shape[0]
    s: Set[Tuple[int, int]] = set()
    for i in range(p):
        for j in range(p):
            if i != j and A[i, j] == 1:
                s.add((i, j))
    return s


def structural_hamming_distance(true_dag: np.ndarray,
                                pred_dag: np.ndarray) -> Dict:
    """SHD between two adjacency matrices.

    Counts:
        - missing : edges present in true but absent in pred (skeleton-wise)
        - extra   : edges absent in true but present in pred (skeleton-wise)
        - reversed: edges present in both with opposite direction
    SHD = missing + extra + reversed.

    Returns
    -------
    dict with keys 'shd', 'missing', 'extra', 'reversed'.
    """
    true_und = _undirected_edge_set(true_dag)
    pred_und = _undirected_edge_set(pred_dag)
    common_und = true_und & pred_und
    missing = len(true_und - pred_und)
    extra = len(pred_und - true_und)
    reversed_count = 0
    for (i, j) in common_und:
        # both have an undirected/directed edge between i and j; check direction
        true_ij = true_dag[i, j] == 1
        true_ji = true_dag[j, i] == 1
        pred_ij = pred_dag[i, j] == 1
        pred_ji = pred_dag[j, i] == 1
        # If both fully undirected on either side, no reversal.
        if (true_ij and true_ji) or (pred_ij and pred_ji):
            continue
        if true_ij and not true_ji and pred_ji and not pred_ij:
            reversed_count += 1
        elif true_ji and not true_ij and pred_ij and not pred_ji:
            reversed_count += 1
    return {"shd": int(missing + extra + reversed_count),
            "missing": int(missing),
            "extra": int(extra),
            "reversed": int(reversed_count)}


def directed_precision_recall(true_dag: np.ndarray,
                              pred_dag: np.ndarray) -> Dict:
    """Directed-edge precision, recall and F1.

    Treats undirected edges in `pred_dag` (where both A[i, j] and
    A[j, i] are 1) as two directed edges; if either direction matches
    the truth, both counts contribute.

    Returns
    -------
    dict with 'precision', 'recall', 'f1', 'tp', 'fp', 'fn'.
    """
    truth = _directed_edge_set(true_dag)
    pred = _directed_edge_set(pred_dag)
    tp = len(truth & pred)
    fp = len(pred - truth)
    fn = len(truth - pred)
    prec = tp / max(tp + fp, 1)
    rec = tp / max(tp + fn, 1)
    f1 = 2 * prec * rec / max(prec + rec, 1e-12)
    return {"precision": float(prec), "recall": float(rec), "f1": float(f1),
            "tp": int(tp), "fp": int(fp), "fn": int(fn)}


def skeleton_precision_recall(true_dag: np.ndarray,
                              pred_dag: np.ndarray) -> Dict:
    """Undirected-edge precision, recall and F1 (skeleton only)."""
    t = _undirected_edge_set(true_dag)
    p = _undirected_edge_set(pred_dag)
    tp = len(t & p)
    fp = len(p - t)
    fn = len(t - p)
    prec = tp / max(tp + fp, 1)
    rec = tp / max(tp + fn, 1)
    f1 = 2 * prec * rec / max(prec + rec, 1e-12)
    return {"precision": float(prec), "recall": float(rec), "f1": float(f1),
            "tp": int(tp), "fp": int(fp), "fn": int(fn)}

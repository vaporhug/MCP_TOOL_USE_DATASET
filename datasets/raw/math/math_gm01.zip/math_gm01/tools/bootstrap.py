"""Edge-stability bootstrap for graphical-model structure learning.

Given a learner that produces an adjacency matrix from a data matrix,
this module repeatedly resamples cells (rows) with replacement, runs
the learner on each resample, and accumulates per-edge selection
frequencies. The output is a (p, p) edge-frequency matrix in [0, 1]
that quantifies the stability of each candidate edge.

No sklearn / networkx imports.
"""
from __future__ import annotations

from typing import Callable, Dict, Optional, Sequence
import numpy as np

from data_io import subsample_rows


def edge_stability_bootstrap(matrix: np.ndarray,
                             learner: Callable[[np.ndarray], np.ndarray],
                             n_boot: int = 50,
                             frac: float = 1.0,
                             seed: Optional[int] = 0) -> Dict:
    """Run a non-parametric bootstrap to score edge stability.

    Parameters
    ----------
    matrix : (n, p) array
    learner : callable
        Function taking a (n', p) data array and returning a (p, p)
        integer adjacency matrix. Typical choices wrap
        `run_pc_algorithm` or `greedy_hill_climb_bic`.
    n_boot : int
        Number of bootstrap resamples.
    frac : float in (0, 1]
        Resample size as a fraction of the original n.
    seed : int, optional
        Base seed; the b-th replicate uses seed=base+b.

    Returns
    -------
    dict with keys
        edge_freq : (p, p) float ndarray, the empirical selection
                    frequency for each directed edge across replicates.
        skeleton_freq : (p, p) float ndarray, the undirected version
                    (max of A[i, j] and A[j, i] per replicate).
        n_boot : int.
    """
    arr = np.asarray(matrix, dtype=float)
    n, p = arr.shape
    sample_n = max(int(round(n * frac)), 10)
    edge_freq = np.zeros((p, p), dtype=float)
    skel_freq = np.zeros((p, p), dtype=float)
    base = 0 if seed is None else int(seed)
    for b in range(n_boot):
        sub = subsample_rows(arr, sample_n, seed=base + b, replace=True)
        A = np.asarray(learner(sub), dtype=int)
        edge_freq += A.astype(float)
        sk = ((A + A.T) > 0).astype(float)
        skel_freq += sk
    edge_freq /= n_boot
    skel_freq /= n_boot
    np.fill_diagonal(skel_freq, 0.0)
    np.fill_diagonal(edge_freq, 0.0)
    return {"edge_freq": edge_freq, "skeleton_freq": skel_freq,
            "n_boot": int(n_boot)}


def stability_threshold(edge_freq: np.ndarray, threshold: float = 0.5
                        ) -> np.ndarray:
    """Return a 0/1 adjacency keeping only edges whose frequency >= threshold.

    Parameters
    ----------
    edge_freq : (p, p) array of selection frequencies in [0, 1].
    threshold : float
        Minimum frequency to keep an edge. Typical edge-stability
        thresholds in the structure-learning literature are 0.5 (the
        majority rule) for inclusive bootstraps and 0.8 - 0.9 for
        high-confidence subgraphs.

    Returns
    -------
    numpy.ndarray of int.
    """
    A = (np.asarray(edge_freq) >= threshold).astype(int)
    np.fill_diagonal(A, 0)
    return A


def top_k_edges_by_frequency(edge_freq: np.ndarray,
                             node_names: Sequence[str],
                             k: int = 15) -> Dict:
    """Return the top-k directed edges ranked by bootstrap frequency.

    Parameters
    ----------
    edge_freq : (p, p) array
    node_names : sequence of str
    k : int

    Returns
    -------
    dict with keys 'edges' (list of (parent, child, freq)) and
    'adjacency' (a (p, p) int matrix containing exactly those edges).
    """
    p = edge_freq.shape[0]
    cands = []
    for i in range(p):
        for j in range(p):
            if i == j:
                continue
            cands.append((float(edge_freq[i, j]), i, j))
    cands.sort(reverse=True)
    out = []
    A = np.zeros((p, p), dtype=int)
    used = set()
    for freq, i, j in cands:
        if (i, j) in used or (j, i) in used:
            continue
        out.append((node_names[i], node_names[j], freq))
        A[i, j] = 1
        used.add((i, j))
        if len(out) >= k:
            break
    return {"edges": out, "adjacency": A}

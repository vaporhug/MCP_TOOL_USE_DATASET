"""Plot helpers for the structure-learning task.

Every function returns ``{"path": <output_path>}`` and writes a real
PNG file using matplotlib (no networkx, no graphviz). The DAG plot
uses a circular layout; the heatmap uses imshow.
"""
from __future__ import annotations

from typing import Dict, List, Optional, Sequence, Tuple
import math
import os
import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, Circle


def _ensure_dir(path: str) -> None:
    d = os.path.dirname(os.path.abspath(path))
    if d and not os.path.isdir(d):
        os.makedirs(d, exist_ok=True)


def _circular_positions(n: int, radius: float = 1.0) -> np.ndarray:
    """Return (n, 2) array of (x, y) positions on the unit circle."""
    angles = np.linspace(0.0, 2.0 * math.pi, n, endpoint=False)
    return np.column_stack([radius * np.cos(angles),
                            radius * np.sin(angles)])


def plot_dag(adjacency: np.ndarray,
             node_names: Sequence[str],
             output_path: str,
             title: str = "Inferred DAG",
             highlight_edges: Optional[Sequence[Tuple[int, int]]] = None,
             ) -> Dict:
    """Render a DAG as a circular layout with arrowed edges.

    Parameters
    ----------
    adjacency : (p, p) int ndarray
        Directed adjacency: 1 means an arc i -> j.
    node_names : sequence of str
    output_path : str
    title : str
    highlight_edges : optional iterable of (i, j) integer pairs
        Edges to draw in red; the rest are drawn in grey.

    Returns
    -------
    dict with key 'path'.
    """
    _ensure_dir(output_path)
    A = np.asarray(adjacency, dtype=int)
    p = A.shape[0]
    pos = _circular_positions(p, radius=1.0)
    highlight = set(tuple(e) for e in (highlight_edges or []))

    fig, ax = plt.subplots(figsize=(7.5, 7.5))
    ax.set_xlim(-1.5, 1.5)
    ax.set_ylim(-1.5, 1.5)
    ax.set_aspect("equal")
    ax.axis("off")

    # Draw edges first so the nodes sit on top.
    for i in range(p):
        for j in range(p):
            if i == j or A[i, j] == 0:
                continue
            color = "#d73027" if (i, j) in highlight else "#888888"
            arrow = FancyArrowPatch(
                pos[i], pos[j],
                arrowstyle="-|>" if A[j, i] == 0 else "-",
                mutation_scale=14, color=color, lw=1.4,
                shrinkA=14, shrinkB=14,
                connectionstyle="arc3,rad=0.05",
            )
            ax.add_patch(arrow)

    # Nodes.
    for k, (x, y) in enumerate(pos):
        circ = Circle((x, y), 0.10, facecolor="#fee090", edgecolor="black",
                      linewidth=1.0, zorder=3)
        ax.add_patch(circ)
        ax.text(x, y, node_names[k], ha="center", va="center",
                fontsize=9, fontweight="bold", zorder=4)

    ax.set_title(title, fontsize=12)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"path": output_path}


def plot_edge_stability_heatmap(edge_freq: np.ndarray,
                                node_names: Sequence[str],
                                output_path: str,
                                title: str = "Edge bootstrap frequency",
                                ) -> Dict:
    """Render a (p, p) heatmap of edge selection frequency in [0, 1]."""
    _ensure_dir(output_path)
    M = np.asarray(edge_freq, dtype=float)
    p = M.shape[0]
    fig, ax = plt.subplots(figsize=(7.0, 6.0))
    im = ax.imshow(M, vmin=0.0, vmax=1.0, cmap="viridis", aspect="equal")
    ax.set_xticks(range(p))
    ax.set_yticks(range(p))
    ax.set_xticklabels(node_names, rotation=45, ha="right", fontsize=8)
    ax.set_yticklabels(node_names, fontsize=8)
    ax.set_xlabel("child")
    ax.set_ylabel("parent")
    ax.set_title(title, fontsize=12)
    cbar = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    cbar.set_label("bootstrap frequency", fontsize=9)
    # Annotate cells with freq >= 0.5
    for i in range(p):
        for j in range(p):
            if i == j:
                continue
            v = M[i, j]
            if v >= 0.5:
                ax.text(j, i, f"{v:.2f}", ha="center", va="center",
                        color="white" if v < 0.7 else "black", fontsize=7)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"path": output_path}


def plot_shd_comparison(labels: Sequence[str],
                        shd_values: Sequence[float],
                        output_path: str,
                        title: str = "SHD vs. reference network",
                        ) -> Dict:
    """Bar chart of SHD scores for several learners against the truth.

    Parameters
    ----------
    labels : list of str
        Names of the learners or settings (e.g. ['PC alpha=0.05',
        'Hill-climbing BIC', 'Bootstrap >=0.85']).
    shd_values : list of float
    output_path : str
    title : str
    """
    _ensure_dir(output_path)
    fig, ax = plt.subplots(figsize=(6.0, 4.5))
    x = np.arange(len(labels))
    bars = ax.bar(x, shd_values, color="#4575b4", edgecolor="black")
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=20, ha="right", fontsize=10)
    ax.set_ylabel("Structural Hamming Distance")
    ax.set_title(title, fontsize=12)
    for b, v in zip(bars, shd_values):
        ax.text(b.get_x() + b.get_width() / 2.0, b.get_height() + 0.1,
                f"{v:.0f}", ha="center", va="bottom", fontsize=10)
    ax.set_ylim(0, max(shd_values) * 1.25 + 1)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"path": output_path}


def plot_score_trajectory(history: Sequence[Tuple[int, float]],
                          output_path: str,
                          title: str = "Hill-climbing BIC trajectory",
                          ) -> Dict:
    """Line plot of BIC vs. iteration for the hill-climbing run."""
    _ensure_dir(output_path)
    its = [h[0] for h in history]
    sc = [h[1] for h in history]
    fig, ax = plt.subplots(figsize=(6.0, 4.0))
    ax.plot(its, sc, "-o", color="#1a9850", markersize=4)
    ax.set_xlabel("iteration")
    ax.set_ylabel("BIC (higher = better)")
    ax.set_title(title, fontsize=12)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"path": output_path}

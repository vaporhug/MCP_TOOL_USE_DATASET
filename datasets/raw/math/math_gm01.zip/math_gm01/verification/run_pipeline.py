"""End-to-end driver that produces the headline numbers used in
task_content.json's answer items. Designed to be self-contained and
reproducible: fixed seeds, single-threaded.

Run:
    cd math_gm01
    PYTHONPATH=tools python3 verification/run_pipeline.py
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "tools"))

from data_io import (
    load_protein_matrix,
    load_edge_list,
    log_transform,
    standardize_columns,
    column_names,
)
from pc_algorithm import run_pc_algorithm
from score_search import greedy_hill_climb_bic, bic_total
from bootstrap import edge_stability_bootstrap, stability_threshold
from dag_metrics import (
    edge_list_to_adjacency,
    adjacency_to_edge_list,
    structural_hamming_distance,
    directed_precision_recall,
    skeleton_precision_recall,
)
from plots import (
    plot_dag,
    plot_edge_stability_heatmap,
    plot_shd_comparison,
    plot_score_trajectory,
)


def directed_arc_count(A: np.ndarray) -> int:
    """Count true directed arcs (i->j where j->i is absent)."""
    A = np.asarray(A)
    return int(((A == 1) & (A.T == 0)).sum())


def undirected_edge_count(A: np.ndarray) -> int:
    """Count undirected/skeleton edges (i<j with A[i,j] or A[j,i])."""
    A = np.asarray(A)
    p = A.shape[0]
    cnt = 0
    for i in range(p):
        for j in range(i + 1, p):
            if A[i, j] or A[j, i]:
                cnt += 1
    return cnt


def main():
    df = load_protein_matrix(ROOT / "input_data/data/cd3cd28.csv")
    nodes = column_names(df)
    p = len(nodes)
    n = df.shape[0]

    X = standardize_columns(log_transform(df.values, eps=1.0))

    truth_edges = load_edge_list(ROOT / "input_data/data/ground_truth_edges.csv")
    truth_adj = edge_list_to_adjacency(truth_edges, nodes)
    n_truth = len(truth_edges)

    print(f"[data] n_cells={n}  p={p}  truth_arcs={n_truth}")

    # PC algorithm
    pc_out = run_pc_algorithm(X, alpha=0.05, max_cond_size=3)
    pc_adj = pc_out["adjacency"]
    pc_directed = directed_arc_count(pc_adj)
    pc_skeleton = undirected_edge_count(pc_adj)
    pc_shd = structural_hamming_distance(truth_adj, pc_adj)
    pc_dir_prf = directed_precision_recall(truth_adj, pc_adj)
    pc_skel_prf = skeleton_precision_recall(truth_adj, pc_adj)
    print(f"[PC] directed={pc_directed}  skeleton={pc_skeleton}  "
          f"SHD={pc_shd}  dir_F1={pc_dir_prf['f1']:.3f}  "
          f"skel_F1={pc_skel_prf['f1']:.3f}  n_tests={pc_out['n_tests']}")

    # BIC hill climbing
    hc_out = greedy_hill_climb_bic(X, max_in_degree=4, max_iter=200)
    hc_adj = hc_out["adjacency"]
    hc_directed = directed_arc_count(hc_adj)
    hc_skeleton = undirected_edge_count(hc_adj)
    hc_shd = structural_hamming_distance(truth_adj, hc_adj)
    hc_dir_prf = directed_precision_recall(truth_adj, hc_adj)
    hc_skel_prf = skeleton_precision_recall(truth_adj, hc_adj)
    print(f"[HC] directed={hc_directed}  skeleton={hc_skeleton}  "
          f"SHD={hc_shd}  dir_F1={hc_dir_prf['f1']:.3f}  "
          f"skel_F1={hc_skel_prf['f1']:.3f}  "
          f"BIC={bic_total(X, hc_adj):.1f}")

    # Bootstrap with PC learner
    def pc_learner(sub):
        out = run_pc_algorithm(sub, alpha=0.05, max_cond_size=3)
        return out["adjacency"]

    boot = edge_stability_bootstrap(X, pc_learner, n_boot=30, frac=1.0, seed=0)
    edge_freq = boot["edge_freq"]
    skel_freq = boot["skeleton_freq"]

    for thr in (0.5, 0.7, 0.85):
        stable = stability_threshold(skel_freq, threshold=thr)
        n_stable = undirected_edge_count(stable)
        # Build a directed adjacency for SHD: keep direction from PC point estimate
        # where stable, else leave as undirected (use skeleton form).
        stable_adj = (skel_freq >= thr).astype(int)
        np.fill_diagonal(stable_adj, 0)
        shd_stable = structural_hamming_distance(truth_adj, stable_adj)
        skel_prf = skeleton_precision_recall(truth_adj, stable_adj)
        print(f"[BOOT thr={thr}] stable_skel_edges={n_stable}  "
              f"SHD={shd_stable}  skel_P={skel_prf['precision']:.3f}  "
              f"R={skel_prf['recall']:.3f}  F1={skel_prf['f1']:.3f}")

    # Identify which truth arcs survive the 0.85 stability threshold (skeleton form)
    stable_adj_85 = (skel_freq >= 0.85).astype(int)
    np.fill_diagonal(stable_adj_85, 0)
    print("[BOOT thr=0.85] surviving skeleton edges with truth-overlap:")
    for i in range(p):
        for j in range(i + 1, p):
            if stable_adj_85[i, j]:
                in_truth = truth_adj[i, j] or truth_adj[j, i]
                tag = "TRUTH" if in_truth else "novel"
                print(f"  {nodes[i]:6s} -- {nodes[j]:6s}  freq={skel_freq[i, j]:.2f}  {tag}")

    # Persist headline numbers as JSON for the answer items
    headline = {
        "n_cells": n,
        "n_proteins": p,
        "n_truth_arcs": n_truth,
        "PC": {
            "directed_arcs": pc_directed,
            "skeleton_edges": pc_skeleton,
            "SHD": int(pc_shd["shd"]),
            "missing": int(pc_shd["missing"]),
            "extra": int(pc_shd["extra"]),
            "reversed": int(pc_shd["reversed"]),
            "directed_F1": round(pc_dir_prf["f1"], 3),
            "skeleton_F1": round(pc_skel_prf["f1"], 3),
            "n_tests": pc_out["n_tests"],
        },
        "HC_BIC": {
            "directed_arcs": hc_directed,
            "skeleton_edges": hc_skeleton,
            "SHD": int(hc_shd["shd"]),
            "missing": int(hc_shd["missing"]),
            "extra": int(hc_shd["extra"]),
            "reversed": int(hc_shd["reversed"]),
            "directed_F1": round(hc_dir_prf["f1"], 3),
            "skeleton_F1": round(hc_skel_prf["f1"], 3),
        },
        "bootstrap": {
            "n_boot": 30,
            "thresholds": {},
        },
        "_seeds": {"pc_alpha": 0.05, "max_cond_size": 3,
                   "bootstrap_seed": 0, "n_boot": 30},
    }
    for thr in (0.5, 0.7, 0.85):
        stable_adj = (skel_freq >= thr).astype(int)
        np.fill_diagonal(stable_adj, 0)
        n_stable = undirected_edge_count(stable_adj)
        shd_stable = structural_hamming_distance(truth_adj, stable_adj)
        skel_prf = skeleton_precision_recall(truth_adj, stable_adj)
        headline["bootstrap"]["thresholds"][str(thr)] = {
            "stable_skeleton_edges": n_stable,
            "SHD": int(shd_stable["shd"]),
            "missing": int(shd_stable["missing"]),
            "extra": int(shd_stable["extra"]),
            "skeleton_F1": round(skel_prf["f1"], 3),
            "skeleton_precision": round(skel_prf["precision"], 3),
            "skeleton_recall": round(skel_prf["recall"], 3),
        }

    out_path = ROOT / "verification/answer_summary.json"
    out_path.parent.mkdir(exist_ok=True)
    with open(out_path, "w") as f:
        json.dump(headline, f, indent=2)
    print(f"[done] wrote {out_path}")

    # Regenerate the four reference figures so they match the headline
    # numbers reported in task_content.json.
    art = ROOT / "artifacts"
    art.mkdir(exist_ok=True)
    plot_dag(hc_adj, nodes, str(art / "inferred_dag.png"),
             title="Hill-climbing BIC DAG (7 directed arcs)")
    plot_edge_stability_heatmap(skel_freq, nodes,
                                str(art / "edge_stability.png"),
                                title="PC bootstrap skeleton frequency (n_boot=30)")
    plot_shd_comparison(
        ["PC alpha=0.05", "HC-BIC", "Bootstrap thr>=0.5"],
        [int(pc_shd["shd"]), int(hc_shd["shd"]),
         int(headline["bootstrap"]["thresholds"]["0.5"]["SHD"])],
        str(art / "shd_comparison.png"),
        title="SHD vs. 20-arc reference network",
    )
    plot_score_trajectory(hc_out.get("history", [(0, bic_total(X, hc_adj))]),
                          str(art / "bic_trajectory.png"),
                          title="Hill-climbing BIC trajectory")
    print(f"[done] regenerated artifacts in {art}")


if __name__ == "__main__":
    main()

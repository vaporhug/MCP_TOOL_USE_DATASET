"""Database retrieval stubs for biological databases.

Thin placeholders for external-database queries. Implementations should be
filled in at task-execution time with the appropriate library.
"""
from typing import Any


def query_uniprot(accession: str) -> dict:
    """UniProt entry fetch. Returns sequence, organism, features,
    cross-references for a protein accession."""
    pass  # heavy: REST client + JSON parsing


def query_flybase(fbgn_id: str) -> dict:
    """FlyBase gene lookup by FBgn identifier. Returns gene symbol,
    name, ontology annotations, orthologs."""
    pass  # heavy: REST client


def query_string_db(protein_ids: list, species: int = 7227) -> list[dict]:
    """STRING-DB interaction query for a set of protein identifiers.
    species=7227 for Drosophila melanogaster.
    Returns list of {protein1, protein2, score, ...}."""
    pass  # heavy: REST API


def query_gene_ontology(gene_ids: list, organism: str = "dmel") -> dict:
    """Batch GO annotation lookup. Returns dict mapping gene_id to
    list of {go_id, go_term, aspect (BP/CC/MF), evidence_code}."""
    pass  # heavy: GO API or local OBO+GAF parse


def query_intact(query: str, species: str = "drosophila") -> list[dict]:
    """IntAct molecular interaction database query.
    Returns list of interaction records."""
    pass  # heavy: PSICQUIC REST


def fetch_url(url: str, timeout: int = 30) -> bytes:
    """HTTP GET with redirects. Used to download a CSV/PDF/JSON from a
    known URL."""
    pass  # heavy: network + retry/backoff

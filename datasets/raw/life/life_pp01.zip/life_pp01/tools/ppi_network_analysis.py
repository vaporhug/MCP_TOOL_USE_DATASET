"""PPI network analysis primitives for binary protein interaction datasets.

These are intermediate-step tools for network construction, quality
assessment, topological analysis, and functional enrichment that the
agent chains to reach the final answer."""
import csv
import math
import numpy as np
from collections import Counter, defaultdict
from scipy import stats


def load_edgelist_csv(path, delimiter="\t", col_a="FBgn1", col_b="FBgn2",
                      keep_self_loops=True):
    """Load an interaction edge list from CSV/TSV into a set of (geneA, geneB)
    tuples and a dict adjacency list. Returns (edges, adj, nodes).

    Self-interactions (homodimers, A==B) are biologically meaningful binary
    PPIs and are retained by default (``keep_self_loops=True``) so that, e.g.,
    the FlyBi dataset reproduces its reported 8,723-interaction / 2,939-protein
    count. Set ``keep_self_loops=False`` to define the task on a simple graph
    with no self-loops."""
    edges = set()
    adj = defaultdict(set)
    with open(path) as f:
        reader = csv.DictReader(f, delimiter=delimiter)
        for row in reader:
            a, b = row[col_a].strip(), row[col_b].strip()
            if not (a and b):
                continue
            if a == b and not keep_self_loops:
                continue
            edge = tuple(sorted([a, b]))
            edges.add(edge)
            adj[a].add(b)
            adj[b].add(a)
    nodes = set(adj.keys())
    return list(edges), dict(adj), nodes


def load_edgelist_xlsx(path, sheet_name=None, col_a="fbgn1 r645", col_b="fbgn2 r645",
                       keep_self_loops=True):
    """Load an interaction edge list from xlsx. Returns (edges, adj, nodes).

    Self-interactions (homodimers, A==B) are retained by default so binary
    interaction counts match the source files (e.g. Lit-BM-16 = 892,
    Lit-BM-20 = 2,985 interactions). Set ``keep_self_loops=False`` for a
    no-self-loop simple graph."""
    import openpyxl
    wb = openpyxl.load_workbook(path, read_only=True)
    ws = wb[sheet_name] if sheet_name else wb[wb.sheetnames[0]]
    rows_iter = ws.iter_rows(values_only=True)
    headers = [str(h) for h in next(rows_iter)]
    ia = headers.index(col_a)
    ib = headers.index(col_b)
    edges = set()
    adj = defaultdict(set)
    for row in rows_iter:
        a, b = str(row[ia]).strip(), str(row[ib]).strip()
        if not (a and b):
            continue
        if a == b and not keep_self_loops:
            continue
        edge = tuple(sorted([a, b]))
        edges.add(edge)
        adj[a].add(b)
        adj[b].add(a)
    nodes = set(adj.keys())
    return list(edges), dict(adj), nodes


def degree_distribution(adj):
    """Return a Counter mapping degree -> count of nodes with that degree."""
    return Counter(len(v) for v in adj.values())


def degree_sequence(adj):
    """Return sorted degree sequence as a numpy array (descending)."""
    return np.sort([len(v) for v in adj.values()])[::-1]


def network_summary(edges, adj, nodes):
    """Compute basic network statistics: node count, edge count, average degree."""
    n_nodes = len(nodes)
    n_edges = len(edges)
    avg_deg = 2.0 * n_edges / n_nodes if n_nodes > 0 else 0
    return {
        "n_nodes": n_nodes,
        "n_edges": n_edges,
        "avg_degree": round(avg_deg, 2),
    }


def network_density(n_edges, n_nodes):
    """Undirected graph density = 2E / (N*(N-1))."""
    if n_nodes < 2:
        return 0.0
    return 2.0 * n_edges / (n_nodes * (n_nodes - 1))


def connected_components(adj):
    """BFS-based connected component detection. Returns list of sets
    sorted by size (largest first)."""
    visited = set()
    components = []
    for node in adj:
        if node in visited:
            continue
        comp = set()
        queue = [node]
        while queue:
            n = queue.pop()
            if n in visited:
                continue
            visited.add(n)
            comp.add(n)
            for nb in adj.get(n, []):
                if nb not in visited:
                    queue.append(nb)
        components.append(comp)
    return sorted(components, key=len, reverse=True)


def largest_connected_component(adj):
    """Return the node set of the largest connected component."""
    comps = connected_components(adj)
    return comps[0] if comps else set()


def clustering_coefficient_local(adj, node):
    """Local clustering coefficient for a single node."""
    neighbors = list(adj.get(node, []))
    k = len(neighbors)
    if k < 2:
        return 0.0
    n_links = 0
    nset = set(neighbors)
    for i, ni in enumerate(neighbors):
        for nj in neighbors[i + 1:]:
            if nj in adj.get(ni, set()):
                n_links += 1
    return 2.0 * n_links / (k * (k - 1))


def average_clustering_coefficient(adj, sample_size=500, seed=42):
    """Mean local clustering coefficient. For large networks, samples
    a subset of nodes for efficiency."""
    import random
    rng = random.Random(seed)
    nodes = list(adj.keys())
    if len(nodes) > sample_size:
        nodes = rng.sample(nodes, sample_size)
    ccs = [clustering_coefficient_local(adj, n) for n in nodes]
    return float(np.mean(ccs)) if ccs else 0.0


def power_law_fit_loglog(degree_dist):
    """Least-squares log-log fit of degree distribution P(k) ~ k^{-gamma}.
    Returns (gamma, r_squared)."""
    ks = sorted(k for k in degree_dist if k > 0)
    if len(ks) < 3:
        return float("nan"), 0.0
    x = np.log10([float(k) for k in ks])
    y = np.log10([float(degree_dist[k]) for k in ks])
    slope, intercept, r, p, se = stats.linregress(x, y)
    return -slope, r ** 2


def edge_overlap(edges_a, edges_b):
    """Compute overlap statistics between two edge sets.
    Returns dict with n_overlap, jaccard, n_a_only, n_b_only."""
    sa = set(tuple(sorted(e)) for e in edges_a)
    sb = set(tuple(sorted(e)) for e in edges_b)
    overlap = sa & sb
    union = sa | sb
    jaccard = len(overlap) / len(union) if union else 0.0
    return {
        "n_overlap": len(overlap),
        "jaccard": round(jaccard, 4),
        "n_a_only": len(sa - sb),
        "n_b_only": len(sb - sa),
    }


def node_overlap(nodes_a, nodes_b):
    """Overlap statistics between two node sets."""
    sa, sb = set(nodes_a), set(nodes_b)
    overlap = sa & sb
    union = sa | sb
    jaccard = len(overlap) / len(union) if union else 0.0
    return {
        "n_overlap": len(overlap),
        "jaccard": round(jaccard, 4),
        "n_a_only": len(sa - sb),
        "n_b_only": len(sb - sa),
    }


def community_detection_label_propagation(adj, seed=0):
    """Simple label-propagation community detection.
    Returns dict mapping node -> community_id."""
    import random
    rng = random.Random(seed)
    labels = {n: i for i, n in enumerate(adj)}
    nodes = list(adj.keys())
    for _ in range(20):
        rng.shuffle(nodes)
        changed = False
        for n in nodes:
            neighbor_labels = Counter(labels[nb] for nb in adj[n])
            if neighbor_labels:
                best = neighbor_labels.most_common(1)[0][0]
                if labels[n] != best:
                    labels[n] = best
                    changed = True
        if not changed:
            break
    return labels


def enrichment_test_fisher(overlap, set_a_size, set_b_size, universe):
    """One-sided Fisher's exact test for enrichment of overlap between
    two sets drawn from a universe of size N.
    Returns dict with odds_ratio, p_value, overlap, set_a, set_b."""
    a_only = set_a_size - overlap
    b_only = set_b_size - overlap
    neither = universe - set_a_size - set_b_size + overlap
    table = [[overlap, b_only], [a_only, neither]]
    odds, p = stats.fisher_exact(table, alternative="greater")
    return {
        "odds_ratio": float(odds),
        "p_value": float(p),
        "overlap": overlap,
        "set_a": set_a_size,
        "set_b": set_b_size,
    }


def benjamini_hochberg(p_values):
    """BH FDR correction on a list of p-values. Returns adjusted p-values."""
    n = len(p_values)
    if n == 0:
        return []
    indexed = sorted(enumerate(p_values), key=lambda x: x[1])
    adjusted = [0.0] * n
    prev = 1.0
    for rank_minus1 in range(n - 1, -1, -1):
        orig_idx, p = indexed[rank_minus1]
        adj = min(prev, p * n / (rank_minus1 + 1))
        adjusted[orig_idx] = adj
        prev = adj
    return adjusted


def hub_proteins(adj, top_k=20):
    """Return the top-k hub proteins by degree.
    Returns list of (node, degree) tuples."""
    ranked = sorted(adj.items(), key=lambda x: len(x[1]), reverse=True)
    return [(n, len(nb)) for n, nb in ranked[:top_k]]


def betweenness_centrality_approx(adj, n_samples=200, seed=0):
    """Approximate betweenness centrality via random source BFS sampling.
    Returns dict mapping node -> betweenness value."""
    import random
    rng = random.Random(seed)
    nodes = list(adj.keys())
    bc = {n: 0.0 for n in nodes}
    sources = rng.sample(nodes, min(n_samples, len(nodes)))
    for s in sources:
        dist = {s: 0}
        pred = defaultdict(list)
        sigma = defaultdict(float)
        sigma[s] = 1.0
        queue = [s]
        order = []
        while queue:
            v = queue.pop(0)
            order.append(v)
            for w in adj.get(v, []):
                if w not in dist:
                    dist[w] = dist[v] + 1
                    queue.append(w)
                if dist.get(w) == dist[v] + 1:
                    sigma[w] += sigma[v]
                    pred[w].append(v)
        delta = defaultdict(float)
        for w in reversed(order):
            for v in pred[w]:
                delta[v] += (sigma[v] / sigma[w]) * (1.0 + delta[w])
            if w != s:
                bc[w] += delta[w]
    n = len(nodes)
    scale = 1.0 / (len(sources) * max(1, n - 1))
    return {k: v * scale for k, v in bc.items()}


def merge_networks(edges_list):
    """Merge multiple edge lists into a single unified network.
    edges_list: list of lists of (a, b) tuples.
    Returns (merged_edges, merged_adj, merged_nodes)."""
    all_edges = set()
    adj = defaultdict(set)
    for edges in edges_list:
        for e in edges:
            edge = tuple(sorted(e))
            all_edges.add(edge)
            adj[edge[0]].add(edge[1])
            adj[edge[1]].add(edge[0])
    return list(all_edges), dict(adj), set(adj.keys())


def random_network_edge_sample(nodes, n_edges, seed=42):
    """Generate a degree-preserving random network by sampling edges uniformly
    from the node set. Used for permutation tests."""
    import random
    rng = random.Random(seed)
    node_list = list(nodes)
    n = len(node_list)
    sampled = set()
    attempts = 0
    while len(sampled) < n_edges and attempts < n_edges * 10:
        i, j = rng.randint(0, n - 1), rng.randint(0, n - 1)
        if i != j:
            edge = tuple(sorted([node_list[i], node_list[j]]))
            sampled.add(edge)
        attempts += 1
    return list(sampled)


def permutation_test(observed, null_distribution):
    """Compute empirical p-value: fraction of null values >= observed."""
    n_ge = sum(1 for v in null_distribution if v >= observed)
    return n_ge / len(null_distribution) if null_distribution else 1.0

"""Generic data-processing utilities.

Format conversion, reshaping, cleaning, and lightweight transforms that are
*not* specific to the task's scientific domain.
"""
from typing import Any
import csv
import json


def read_csv(path: str, delimiter: str = ",") -> list[dict]:
    """Parse CSV/TSV into list-of-dicts using csv.DictReader."""
    with open(path, newline="") as f:
        return list(csv.DictReader(f, delimiter=delimiter))


def write_csv(rows: list[dict], path: str, delimiter: str = ",") -> None:
    """Write list-of-dicts to CSV, using the first row's keys as header."""
    if not rows:
        open(path, "w").close()
        return
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()), delimiter=delimiter)
        w.writeheader()
        w.writerows(rows)


def read_json(path: str) -> Any:
    """Read a JSON file and return its contents."""
    with open(path) as f:
        return json.load(f)


def write_json(obj: Any, path: str, indent: int = 2) -> None:
    """Write an object to JSON file."""
    with open(path, "w") as f:
        json.dump(obj, f, indent=indent, default=str)


def read_excel(path: str, sheet_name: str | None = None) -> list[dict]:
    """Read an .xlsx sheet into list-of-dicts via openpyxl."""
    import openpyxl
    wb = openpyxl.load_workbook(path, read_only=True)
    ws = wb[sheet_name] if sheet_name else wb[wb.sheetnames[0]]
    rows_iter = ws.iter_rows(values_only=True)
    headers = [str(h) for h in next(rows_iter)]
    result = []
    for row in rows_iter:
        result.append(dict(zip(headers, row)))
    return result


def pivot_long_to_wide(rows: list[dict], index: str, columns: str,
                       values: str) -> list[dict]:
    """Long-to-wide reshape (like pandas.pivot)."""
    wide: dict = {}
    col_set: set = set()
    for r in rows:
        idx = r[index]
        col = r[columns]
        val = r[values]
        wide.setdefault(idx, {index: idx})[col] = val
        col_set.add(col)
    return list(wide.values())


def drop_missing(rows: list[dict], cols: list[str] | None = None) -> list[dict]:
    """Remove rows where any (or listed) columns are None/empty."""
    def bad(v):
        return v is None or v == "" or v != v

    if cols is None:
        return [r for r in rows if not any(bad(v) for v in r.values())]
    return [r for r in rows if not any(bad(r.get(c)) for c in cols)]


def coerce_numeric(rows: list[dict], cols: list[str]) -> list[dict]:
    """Cast named columns to float; non-parseable becomes None."""
    out = []
    for r in rows:
        r2 = dict(r)
        for c in cols:
            try:
                r2[c] = float(r2[c])
            except (TypeError, ValueError):
                r2[c] = None
        out.append(r2)
    return out


def join_tables(left: list[dict], right: list[dict], on: str,
                how: str = "inner") -> list[dict]:
    """SQL-style join on a single key."""
    idx = {r[on]: r for r in right}
    out = []
    for l_row in left:
        r_row = idx.get(l_row.get(on))
        if r_row is not None:
            out.append({**l_row, **{k: v for k, v in r_row.items() if k != on}})
        elif how == "left":
            out.append(dict(l_row))
    return out


def groupby_aggregate(rows: list[dict], by: str,
                      agg: dict[str, str]) -> list[dict]:
    """Group rows by `by` and apply per-column aggregations
    (mean|sum|min|max|count)."""
    from statistics import mean
    groups: dict = {}
    for r in rows:
        groups.setdefault(r[by], []).append(r)
    out = []
    for key, grp in groups.items():
        row = {by: key}
        for col, fn in agg.items():
            vals = [g[col] for g in grp if g.get(col) is not None]
            if fn == "mean":
                row[col] = mean(vals) if vals else None
            elif fn == "sum":
                row[col] = sum(vals)
            elif fn == "min":
                row[col] = min(vals) if vals else None
            elif fn == "max":
                row[col] = max(vals) if vals else None
            elif fn == "count":
                row[col] = len(vals)
        out.append(row)
    return out


def filter_rows(rows: list[dict], column: str, value: Any) -> list[dict]:
    """Filter rows where column equals value."""
    return [r for r in rows if r.get(column) == value]


def unique_values(rows: list[dict], column: str) -> list:
    """Return sorted unique values from a column."""
    return sorted(set(str(r[column]) for r in rows if r.get(column) is not None))


def count_by_group(rows: list[dict], column: str) -> dict:
    """Count rows by unique values of a column."""
    counts = {}
    for r in rows:
        v = str(r.get(column))
        counts[v] = counts.get(v, 0) + 1
    return dict(sorted(counts.items(), key=lambda x: -x[1]))

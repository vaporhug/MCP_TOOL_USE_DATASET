# Tools — life_pp01

## Data I/O (`data_processing.py`)
- `read_csv`, `write_csv` — CSV/TSV parsing and writing
- `read_excel` — xlsx sheet reader via openpyxl
- `read_json`, `write_json` — JSON I/O
- `filter_rows`, `unique_values`, `count_by_group` — row filtering and grouping
- `join_tables` — SQL-style inner/left join
- `groupby_aggregate` — group-by with mean/sum/min/max/count

## Network I/O (`ppi_network_analysis.py`)
- `load_edgelist_csv` — parse TSV/CSV edge list into edges + adjacency
- `load_edgelist_xlsx` — parse xlsx edge list into edges + adjacency
- `merge_networks` — combine multiple edge lists

## Network Topology
- `network_summary` — node count, edge count, average degree
- `degree_distribution`, `degree_sequence`, `network_density`
- `connected_components`, `largest_connected_component`
- `clustering_coefficient_local`, `average_clustering_coefficient`
- `power_law_fit_loglog`

## Community & Centrality
- `community_detection_label_propagation` — label propagation
- `hub_proteins` — top-k by degree
- `betweenness_centrality_approx` — BFS sampling approximation

## Comparison & Overlap
- `edge_overlap`, `node_overlap` — shared-interaction / shared-protein overlap + Jaccard between two networks
- `merge_networks` — union of multiple edge lists (interactome expansion)
- `enrichment_test_fisher` — one-sided Fisher exact test (generic two-set enrichment primitive)
- `benjamini_hochberg` — BH FDR correction
- `random_network_edge_sample` — random edge sampling for null models
- `permutation_test` — empirical p-value from null distribution

Note: `load_edgelist_csv` / `load_edgelist_xlsx` retain self-interactions
(homodimers) by default (`keep_self_loops=True`) so reported interaction counts
(e.g. FlyBi 8,723) reproduce exactly.

## Database Retrieval (`database_retrieval.py`)
- Stubs for UniProt, FlyBase, STRING-DB, Gene Ontology, IntAct queries

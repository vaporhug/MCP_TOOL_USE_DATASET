"""I/O primitives for the cell-cell communication task.

Loads the gzipped scRNA-seq log-normalized expression matrix, the per-cell
metadata, and the curated ligand-receptor interaction / complex / cofactor
tables. Pure pandas/numpy; no scipy, no sklearn.
"""
from __future__ import annotations

from typing import Dict, List, Tuple

import numpy as np
import pandas as pd


def load_expression_matrix(path: str) -> pd.DataFrame:
    """Load the gene x cell log-normalized expression matrix.

    The bundled file is a gzip-compressed CSV with row index ``gene`` (HGNC
    symbol) and one column per cell barcode. Values are log2(CPM+1)-style
    normalized counts already deposited by the upstream pipeline; no further
    re-normalization is needed before averaging by group.

    Returns
    -------
    pd.DataFrame
        DataFrame indexed by gene symbol, columns = cell barcodes.
    """
    df = pd.read_csv(path, index_col=0)
    df.index = df.index.astype(str)
    df.index.name = "gene"
    return df


def load_cell_metadata(path: str) -> pd.DataFrame:
    """Load per-cell metadata.

    Columns
    -------
    cell_id     : barcode (matches expression-matrix column)
    patient_id  : donor of origin (Patient1..Patient15)
    condition   : LS (lesional, atopic-dermatitis lesion) or NL (nonlesional)
    cell_type   : annotated cell-type label (12 categories: APOE+ FIB,
                  FBN1+ FIB, COL11A1+ FIB, Inflam. FIB, cDC1, cDC2, LC,
                  Inflam. DC, TC, CD40LG+ TC, Inflam. TC, NKT)
    """
    df = pd.read_csv(path, index_col=0)
    df.index.name = "cell_id"
    return df


def load_lr_interactions(path: str) -> pd.DataFrame:
    """Load the curated ligand-receptor interaction table.

    Each row is one ligand-receptor pair annotated with a pathway name and
    interaction class.

    Columns
    -------
    interaction_id     : unique interaction key (e.g. TGFB1_TGFBR1_TGFBR2)
    pathway_name       : signaling-pathway label (TGFb, ncWNT, CXCL, ...)
    ligand_name        : ligand single gene or complex name
    receptor_name      : receptor single gene or complex name
    ligand_subunits    : pipe-separated gene symbols for the ligand complex
    receptor_subunits  : pipe-separated gene symbols for the receptor complex
    agonist            : cofactor-set name acting as agonist (or empty)
    antagonist         : cofactor-set name acting as antagonist (or empty)
    co_A_receptor      : co-stimulatory receptor cofactor-set (or empty)
    co_I_receptor      : co-inhibitory receptor cofactor-set (or empty)
    annotation         : Secreted Signaling / ECM-Receptor / Cell-Cell Contact
    """
    df = pd.read_csv(path)
    for c in ["agonist", "antagonist", "co_A_receptor", "co_I_receptor"]:
        df[c] = df[c].fillna("").astype(str)
    return df


def load_complexes(path: str) -> Dict[str, List[str]]:
    """Load multi-subunit ligand/receptor complex definitions.

    Returns
    -------
    dict
        Maps complex name (str) to list of subunit gene symbols (e.g.
        ``"TGFbR1_R2_complex"`` -> ``["TGFBR1", "TGFBR2"]``).
    """
    df = pd.read_csv(path)
    return {row["complex_name"]: row["subunits"].split("|")
            for _, row in df.iterrows()}


def load_cofactors(path: str) -> Dict[str, List[str]]:
    """Load cofactor-set definitions (agonists, antagonists, co-receptors).

    Returns
    -------
    dict
        Maps cofactor-set name (str) to list of gene symbols.
    """
    df = pd.read_csv(path)
    out: Dict[str, List[str]] = {}
    for _, row in df.iterrows():
        out[row["cofactor_name"]] = row["factors"].split("|")
    return out


def align_expression_to_cells(expr: pd.DataFrame,
                              meta: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Reorder ``expr`` columns to match ``meta`` row order, keeping the
    common barcodes only. Returns the aligned ``(expr, meta)`` pair.

    Useful boilerplate before any group-wise computation: it guarantees that
    column ``i`` of the matrix is the cell described by row ``i`` of meta.
    """
    common = [c for c in meta.index if c in expr.columns]
    expr2 = expr[common].copy()
    meta2 = meta.loc[common].copy()
    return expr2, meta2


def cell_type_counts(meta: pd.DataFrame, by: str = "cell_type") -> pd.Series:
    """Number of cells per group label (sorted descending). Default groups by
    ``cell_type``; pass ``by="condition"`` for LS/NL tally.
    """
    return meta[by].value_counts().sort_values(ascending=False)


def split_meta_by_condition(meta: pd.DataFrame) -> Dict[str, pd.DataFrame]:
    """Split metadata into one DataFrame per ``condition`` level
    (LS / NL). Returns a dict keyed by condition name.
    """
    return {cond: sub for cond, sub in meta.groupby("condition")}

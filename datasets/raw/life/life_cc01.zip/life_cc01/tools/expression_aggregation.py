"""Per-cell-group expression aggregation primitives.

Functions for: per-group mean expression, per-group fraction of expressing
cells, multi-subunit complex aggregation (geometric mean across subunits),
and one-hot group indicator construction. All numpy + pandas; no scipy.
"""
from __future__ import annotations

from typing import Dict, List, Sequence

import numpy as np
import pandas as pd


def mean_expression_per_group(expr: pd.DataFrame,
                              meta: pd.DataFrame,
                              group_col: str = "cell_type") -> pd.DataFrame:
    """Average normalized expression of every gene in every cell group.

    Parameters
    ----------
    expr : DataFrame, shape (n_genes, n_cells)
        Gene-by-cell log-normalized expression matrix.
    meta : DataFrame
        Per-cell annotations; must be aligned (i.e. ``meta.index`` matches
        ``expr.columns``).
    group_col : str
        Which metadata column to group by (e.g. ``"cell_type"`` or
        ``"condition"``).

    Returns
    -------
    DataFrame, shape (n_genes, n_groups)
        Row = gene, column = group label, value = mean expression.
    """
    groups = meta[group_col].unique()
    out = {}
    for g in groups:
        cells = meta.index[meta[group_col] == g]
        out[g] = expr[cells].mean(axis=1).astype(np.float32)
    return pd.DataFrame(out, index=expr.index)


def fraction_expressing_per_group(expr: pd.DataFrame,
                                  meta: pd.DataFrame,
                                  group_col: str = "cell_type",
                                  threshold: float = 0.0) -> pd.DataFrame:
    """Fraction of cells in each group with expression above ``threshold``.

    Returns the same shape as :func:`mean_expression_per_group` with values
    in [0, 1] giving the fraction of cells of group ``g`` that express the
    gene above ``threshold`` (default 0).
    """
    groups = meta[group_col].unique()
    out = {}
    for g in groups:
        cells = meta.index[meta[group_col] == g]
        sub = expr[cells]
        out[g] = (sub > threshold).mean(axis=1).astype(np.float32)
    return pd.DataFrame(out, index=expr.index)


def truncated_mean_per_group(expr: pd.DataFrame,
                             meta: pd.DataFrame,
                             group_col: str = "cell_type",
                             trim: float = 0.05) -> pd.DataFrame:
    """Robust trimmed mean (trim the top/bottom ``trim`` quantile per group).

    Mirrors CellChat's "trimean" / robust mean step that down-weights
    extreme cells when computing per-group expression. Returns a
    gene-by-group DataFrame.
    """
    groups = meta[group_col].unique()
    out: Dict[str, np.ndarray] = {}
    for g in groups:
        cells = meta.index[meta[group_col] == g]
        sub = expr[cells].values  # genes x cells_in_group
        if sub.shape[1] == 0:
            out[g] = np.zeros(sub.shape[0], dtype=np.float32)
            continue
        lo = np.quantile(sub, trim, axis=1)
        hi = np.quantile(sub, 1.0 - trim, axis=1)
        # build mask & average per gene
        clipped = np.where((sub >= lo[:, None]) & (sub <= hi[:, None]), sub, np.nan)
        out[g] = np.nanmean(clipped, axis=1).astype(np.float32)
    return pd.DataFrame(out, index=expr.index)


def complex_geometric_mean(group_expr: pd.DataFrame,
                           subunits: Sequence[str]) -> pd.Series:
    """Geometric mean of group-mean expression across multi-subunit components.

    Used to score a multi-subunit ligand or receptor: a complex is only
    "expressed" if all its subunits are expressed. Missing subunits return
    NaN. Returns a Series indexed by group label.
    """
    pres = [s for s in subunits if s in group_expr.index]
    if not pres:
        return pd.Series(np.nan, index=group_expr.columns)
    sub = group_expr.loc[pres].values  # n_subunits x n_groups
    # Geometric mean: exp(mean(log(x + epsilon)))
    eps = 1e-9
    log_mean = np.mean(np.log(sub + eps), axis=0)
    return pd.Series(np.exp(log_mean), index=group_expr.columns)


def filter_genes_min_fraction(frac_df: pd.DataFrame,
                              min_frac: float = 0.10) -> List[str]:
    """List the genes that are expressed in at least ``min_frac`` of the
    cells of at least one group. ``frac_df`` is the output of
    :func:`fraction_expressing_per_group`.

    Genes failing this filter are considered noise and dropped from the
    ligand-receptor scoring.
    """
    keep_mask = (frac_df >= min_frac).any(axis=1)
    return list(frac_df.index[keep_mask])


def group_indicator_matrix(meta: pd.DataFrame,
                           group_col: str = "cell_type") -> pd.DataFrame:
    """One-hot indicator matrix: rows = cells, columns = group labels, value
    = 1 if the cell belongs to the group else 0. Useful as the contrast
    matrix for downstream tests.
    """
    return pd.get_dummies(meta[group_col]).astype(np.float32)


def average_per_pair(expr: pd.DataFrame,
                     meta: pd.DataFrame,
                     pair_cols: Sequence[str]) -> pd.DataFrame:
    """Average expression per *combination* of metadata columns (e.g.
    cell_type x condition). Returns a gene x (label) DataFrame where label
    is "<col1>__<col2>" joined.
    """
    label = meta[pair_cols].astype(str).agg("__".join, axis=1)
    out = {}
    for g in label.unique():
        cells = meta.index[label == g]
        out[g] = expr[cells].mean(axis=1).astype(np.float32)
    return pd.DataFrame(out, index=expr.index)

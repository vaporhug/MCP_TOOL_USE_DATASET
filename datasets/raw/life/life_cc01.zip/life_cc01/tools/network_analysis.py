"""Cell-cell communication network primitives.

Aggregate per-pair communication probabilities into:
- pathway-level cell-type x cell-type matrices,
- network centrality measures (in-/out-strength, betweenness on weighted
  directed graph, information centrality),
- conserved-vs-context-specific information-flow comparison between two
  conditions.

Pure numpy + pandas; no scipy, no networkx.
"""
from __future__ import annotations

from typing import Dict, List, Sequence, Tuple

import numpy as np
import pandas as pd


# ---------------------------------------------------------------------------
# Pathway aggregation
# ---------------------------------------------------------------------------

def aggregate_pathway_network(prob_dict: Dict[str, pd.DataFrame],
                              interactions: pd.DataFrame,
                              pathway_name: str) -> pd.DataFrame:
    """Sum communication probabilities of every L-R pair belonging to one
    pathway, producing a single sender x receiver matrix.

    Parameters
    ----------
    prob_dict : dict
        Output of :func:`all_pairs_communication`: ``interaction_id`` ->
        sender x receiver communication-probability DataFrame.
    interactions : DataFrame
        Curated interaction table (must contain ``interaction_id`` and
        ``pathway_name``).
    pathway_name : str
        Pathway label to aggregate (e.g. ``"CCL"``, ``"MIF"``, ``"CXCL"``).

    Returns
    -------
    DataFrame, shape (n_groups, n_groups)
        Aggregated communication-probability matrix; zero-padded if no L-R
        pair under this pathway is present in ``prob_dict``.
    """
    iids = interactions[interactions["pathway_name"] == pathway_name]["interaction_id"]
    mats = [prob_dict[i] for i in iids if i in prob_dict]
    if not mats:
        return pd.DataFrame()
    base = mats[0].copy()
    for m in mats[1:]:
        base = base.add(m.reindex_like(base).fillna(0.0), fill_value=0.0)
    return base


def total_communication_probability(prob_dict: Dict[str, pd.DataFrame]) -> pd.DataFrame:
    """Sum communication probabilities across all interactions.

    Returns a single sender x receiver matrix giving the total signaling
    "volume" between every cell-type pair.
    """
    if not prob_dict:
        return pd.DataFrame()
    iids = list(prob_dict.keys())
    base = prob_dict[iids[0]].copy() * 0.0
    for i in iids:
        base = base.add(prob_dict[i].reindex_like(base).fillna(0.0), fill_value=0.0)
    return base


def number_of_significant_interactions(sig_table_per_pair: Dict[str, pd.DataFrame]
                                       ) -> pd.DataFrame:
    """Count how many L-R pairs are significantly active for each
    (sender, receiver) cell-type edge.

    Parameters
    ----------
    sig_table_per_pair : dict
        Maps ``interaction_id`` to a tidy DataFrame of significant edges
        (output of :func:`communication_score.significant_pairs`).

    Returns
    -------
    DataFrame, shape (n_groups, n_groups)
        Edge-wise count of significant L-R pairs.
    """
    counts: Dict[Tuple[str, str], int] = {}
    for iid, df in sig_table_per_pair.items():
        if df is None or df.empty:
            continue
        for _, row in df.iterrows():
            counts[(row["sender"], row["receiver"])] = (
                counts.get((row["sender"], row["receiver"]), 0) + 1
            )
    if not counts:
        return pd.DataFrame()
    senders = sorted({s for s, _ in counts})
    receivers = sorted({r for _, r in counts})
    out = pd.DataFrame(0, index=senders, columns=receivers, dtype=int)
    for (s, r), c in counts.items():
        out.at[s, r] = c
    return out


# ---------------------------------------------------------------------------
# Centrality
# ---------------------------------------------------------------------------

def out_strength(network: pd.DataFrame) -> pd.Series:
    """Total outgoing communication of each cell type (row sum)."""
    return network.sum(axis=1)


def in_strength(network: pd.DataFrame) -> pd.Series:
    """Total incoming communication of each cell type (column sum)."""
    return network.sum(axis=0)


def network_centrality(network: pd.DataFrame) -> pd.DataFrame:
    """Network-centrality summary: outgoing (sender), incoming (receiver),
    mediator (Bonacich-like), and influencer scores.

    The mediator score is a simplified information-flow proxy:
    ``mediator(i) = (out_strength(i) + in_strength(i)) / 2``.
    The influencer score is the sum of squared communication probabilities
    incident on the node, capturing dominant interaction strength.

    Returns
    -------
    DataFrame
        Indexed by cell type, columns
        ``["outgoing", "incoming", "mediator", "influencer"]``.
    """
    out = out_strength(network)
    inc = in_strength(network).reindex(out.index).fillna(0.0)
    med = (out + inc) / 2.0
    sq = (network ** 2).sum(axis=1) + (network ** 2).sum(axis=0).reindex(out.index).fillna(0.0)
    influencer = np.sqrt(sq)
    return pd.DataFrame({
        "outgoing": out,
        "incoming": inc,
        "mediator": med,
        "influencer": influencer,
    })


def information_flow(network: pd.DataFrame) -> float:
    """Total information flow of a single-pathway network = sum of all
    sender x receiver probabilities. CellChat uses this scalar to rank
    pathways across conditions (Fig 6g, Fig 7c).
    """
    if network is None or network.empty:
        return 0.0
    return float(network.values.sum())


# ---------------------------------------------------------------------------
# Conserved vs context-specific
# ---------------------------------------------------------------------------

def pathway_information_flow_table(prob_dict: Dict[str, pd.DataFrame],
                                   interactions: pd.DataFrame) -> pd.DataFrame:
    """Per-pathway total information flow.

    Returns a DataFrame indexed by pathway with one column ``flow``,
    sorted descending. Only pathways with at least one represented L-R
    pair appear.
    """
    flows = {}
    for pw, sub in interactions.groupby("pathway_name"):
        agg = aggregate_pathway_network(prob_dict, interactions, pw)
        if not agg.empty:
            flows[pw] = information_flow(agg)
    return (pd.DataFrame.from_dict(flows, orient="index", columns=["flow"])
              .sort_values("flow", ascending=False))


def compare_information_flow(flow_a: pd.DataFrame,
                             flow_b: pd.DataFrame,
                             label_a: str = "A",
                             label_b: str = "B") -> pd.DataFrame:
    """Compare per-pathway information flow between two conditions.

    Parameters
    ----------
    flow_a, flow_b : DataFrame
        Outputs of :func:`pathway_information_flow_table` for each
        condition.
    label_a, label_b : str
        Column-name suffixes for the merged table.

    Returns
    -------
    DataFrame
        Indexed by pathway, with columns ``[flow_<a>, flow_<b>, log2_ratio,
        diff, classification]``. ``classification`` is one of
        ``{"<a>-specific", "<b>-specific", "<a>-enriched", "<b>-enriched",
          "shared"}``.
    """
    a = flow_a["flow"].rename(f"flow_{label_a}")
    b = flow_b["flow"].rename(f"flow_{label_b}")
    df = pd.concat([a, b], axis=1).fillna(0.0)
    eps = 1e-9
    df["log2_ratio"] = np.log2((df[f"flow_{label_a}"] + eps) /
                               (df[f"flow_{label_b}"] + eps))
    df["diff"] = df[f"flow_{label_a}"] - df[f"flow_{label_b}"]

    def _label(row):
        if row[f"flow_{label_a}"] == 0 and row[f"flow_{label_b}"] > 0:
            return f"{label_b}-specific"
        if row[f"flow_{label_b}"] == 0 and row[f"flow_{label_a}"] > 0:
            return f"{label_a}-specific"
        if row["log2_ratio"] >= 1.0:
            return f"{label_a}-enriched"
        if row["log2_ratio"] <= -1.0:
            return f"{label_b}-enriched"
        return "shared"
    df["classification"] = df.apply(_label, axis=1)
    return df.sort_values("diff", ascending=False)


def top_lr_pairs_by_pair(prob_dict: Dict[str, pd.DataFrame],
                         interactions: pd.DataFrame,
                         sender: str,
                         receiver: str,
                         top_n: int = 20) -> pd.DataFrame:
    """Top-N L-R pairs ranked by communication probability for a given
    (sender, receiver) cell-type edge.

    Returns a DataFrame with columns
    ``[interaction_id, ligand_name, receptor_name, pathway_name, prob]``.
    """
    rows = []
    for iid, mat in prob_dict.items():
        if sender in mat.index and receiver in mat.columns:
            p = float(mat.at[sender, receiver])
            if p > 0:
                rows.append({"interaction_id": iid, "prob": p})
    df = pd.DataFrame(rows)
    if df.empty:
        return df
    df = df.merge(interactions[["interaction_id", "ligand_name",
                                "receptor_name", "pathway_name"]],
                  on="interaction_id", how="left")
    return df.sort_values("prob", ascending=False).head(top_n).reset_index(drop=True)

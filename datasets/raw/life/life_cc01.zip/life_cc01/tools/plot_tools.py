"""Plotting primitives for the cell-cell communication task.

Every function returns a dict ``{"path": ...}`` and writes a PNG to disk.
Pure matplotlib; no scipy, no seaborn, no networkx.
"""
from __future__ import annotations

import os
from typing import Dict, List, Sequence

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.patches import Wedge


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _ensure_dir(path: str) -> None:
    d = os.path.dirname(os.path.abspath(path))
    if d and not os.path.isdir(d):
        os.makedirs(d, exist_ok=True)


# ---------------------------------------------------------------------------
# Heatmap of communication strength
# ---------------------------------------------------------------------------

def plot_communication_heatmap(network: pd.DataFrame,
                               output_path: str,
                               title: str = "Communication strength",
                               cmap: str = "Reds",
                               vmin: float = None,
                               vmax: float = None) -> Dict[str, str]:
    """Heatmap of a sender x receiver communication matrix.

    Returns ``{"path": output_path}``.
    """
    _ensure_dir(output_path)
    fig, ax = plt.subplots(figsize=(max(6, 0.5 * network.shape[1] + 3),
                                    max(5, 0.45 * network.shape[0] + 2)))
    im = ax.imshow(network.values, aspect="auto", cmap=cmap,
                   vmin=vmin, vmax=vmax)
    ax.set_xticks(range(network.shape[1]))
    ax.set_xticklabels(network.columns, rotation=45, ha="right", fontsize=9)
    ax.set_yticks(range(network.shape[0]))
    ax.set_yticklabels(network.index, fontsize=9)
    ax.set_xlabel("Receiver")
    ax.set_ylabel("Sender")
    ax.set_title(title)
    fig.colorbar(im, ax=ax, shrink=0.85, label="Comm. prob.")
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path}


# ---------------------------------------------------------------------------
# Bubble / dot plot of L-R pairs
# ---------------------------------------------------------------------------

def plot_lr_dotplot(prob_dict: Dict[str, pd.DataFrame],
                    interactions: pd.DataFrame,
                    sender: str,
                    receivers: Sequence[str],
                    output_path: str,
                    top_n_per_receiver: int = 10,
                    pvals_dict: Dict[str, pd.DataFrame] = None,
                    title: str = "Top L-R pairs") -> Dict[str, str]:
    """Bubble plot of top L-R pairs for ``sender -> each receiver in
    receivers``. Bubble size = communication probability (visual scale),
    color = -log10(p-value) if ``pvals_dict`` provided else equal to size.

    Returns ``{"path": output_path}``.
    """
    _ensure_dir(output_path)
    # build pretty-name map; fall back to interaction_id
    if "interaction_name_2" in interactions.columns:
        name_map = interactions.set_index("interaction_id")["interaction_name_2"].to_dict()
    else:
        name_map = {iid: iid for iid in interactions["interaction_id"]}
    rows = []
    selected = set()
    for r in receivers:
        cand = []
        for iid, mat in prob_dict.items():
            if sender in mat.index and r in mat.columns:
                p = float(mat.at[sender, r])
                if p > 0:
                    cand.append((iid, p))
        cand.sort(key=lambda x: -x[1])
        for iid, _ in cand[:top_n_per_receiver]:
            selected.add(iid)
    selected = list(selected)
    for r in receivers:
        for iid in selected:
            mat = prob_dict[iid]
            if sender in mat.index and r in mat.columns:
                p = float(mat.at[sender, r])
            else:
                p = 0.0
            pv = 1.0
            if pvals_dict is not None and iid in pvals_dict:
                pm = pvals_dict[iid]
                if sender in pm.index and r in pm.columns:
                    pv = float(pm.at[sender, r])
            rows.append({"pair": name_map.get(iid, iid),
                         "receiver": r, "prob": p, "pvalue": pv})
    df = pd.DataFrame(rows)
    if df.empty:
        fig, ax = plt.subplots(figsize=(6, 4))
        ax.text(0.5, 0.5, "no data", ha="center")
        fig.savefig(output_path, dpi=150)
        plt.close(fig)
        return {"path": output_path}
    pivot_p = df.pivot(index="pair", columns="receiver", values="prob").fillna(0.0)
    pivot_pv = df.pivot(index="pair", columns="receiver", values="pvalue").fillna(1.0)
    pivot_p = pivot_p.reindex(columns=list(receivers))
    pivot_pv = pivot_pv.reindex(columns=list(receivers))
    pmax = pivot_p.values.max() + 1e-12
    fig, ax = plt.subplots(figsize=(max(5, 0.6 * len(receivers) + 3),
                                    max(4, 0.30 * len(pivot_p.index) + 2)))
    for i, pair in enumerate(pivot_p.index):
        for j, rec in enumerate(pivot_p.columns):
            v = pivot_p.iat[i, j]
            sz = 30.0 + 350.0 * (v / pmax)
            color = v / pmax  # 0..1 by relative strength
            ax.scatter(j, i, s=sz, c=[color], cmap="Reds",
                       vmin=0, vmax=1, edgecolors="black", linewidths=0.4)
    ax.set_xticks(range(len(pivot_p.columns)))
    ax.set_xticklabels(pivot_p.columns, rotation=45, ha="right", fontsize=9)
    ax.set_yticks(range(len(pivot_p.index)))
    ax.set_yticklabels(pivot_p.index, fontsize=8)
    ax.set_xlabel(f"Receiver (sender = {sender})")
    ax.set_title(title)
    sm = plt.cm.ScalarMappable(cmap="Reds", norm=plt.Normalize(vmin=0, vmax=1))
    sm.set_array([])
    fig.colorbar(sm, ax=ax, label="Relative comm. prob.", shrink=0.7)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path}


# ---------------------------------------------------------------------------
# Chord-style circular diagram
# ---------------------------------------------------------------------------

def plot_chord_diagram(network: pd.DataFrame,
                       output_path: str,
                       title: str = "Communication chord diagram",
                       top_edge_frac: float = 0.20) -> Dict[str, str]:
    """Circular chord-style plot of cell-type communication.

    Cell types are placed on a circle; arcs connect ``sender -> receiver``
    with width proportional to communication probability. Only edges in
    the top ``top_edge_frac`` of the weight distribution are drawn.

    Returns ``{"path": output_path}``.
    """
    _ensure_dir(output_path)
    nodes = list(network.index)
    n = len(nodes)
    angles = np.linspace(0, 2 * np.pi, n, endpoint=False)
    coords = np.c_[np.cos(angles), np.sin(angles)]
    fig, ax = plt.subplots(figsize=(8, 8))
    ax.set_aspect("equal")
    ax.axis("off")
    cmap = plt.colormaps.get_cmap("tab20")
    node_colors = [cmap(i / max(n - 1, 1)) for i in range(n)]
    for i, name in enumerate(nodes):
        ax.add_patch(Wedge(coords[i], 0.06, 0, 360, color=node_colors[i]))
        rot = np.degrees(angles[i])
        ha = "left" if -90 < rot < 90 else "right"
        rot = rot if -90 < rot < 90 else rot + 180
        ax.text(1.18 * coords[i, 0], 1.18 * coords[i, 1], name,
                rotation=rot, rotation_mode="anchor",
                ha=ha, va="center", fontsize=9)
    flat = network.values.flatten()
    pos = flat[flat > 0]
    if pos.size == 0:
        thr = 0.0
    else:
        thr = np.quantile(pos, max(0.0, 1.0 - top_edge_frac))
    wmax = flat.max() + 1e-12
    # Bezier-like curve for arc visual
    for i, ni in enumerate(nodes):
        for j, nj in enumerate(nodes):
            w = network.at[ni, nj]
            if w >= thr and w > 0:
                lw = 0.5 + 6.0 * w / wmax
                # gentle quadratic bezier through origin
                t = np.linspace(0, 1, 30)
                px = (1 - t) ** 2 * coords[i, 0] + 2 * (1 - t) * t * 0 + t ** 2 * coords[j, 0]
                py = (1 - t) ** 2 * coords[i, 1] + 2 * (1 - t) * t * 0 + t ** 2 * coords[j, 1]
                ax.plot(px, py, color=node_colors[i],
                        alpha=0.55, linewidth=lw, solid_capstyle="round")
    ax.set_xlim(-1.4, 1.4)
    ax.set_ylim(-1.4, 1.4)
    ax.set_title(title)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path}


# ---------------------------------------------------------------------------
# Network bar of total info flow per pathway
# ---------------------------------------------------------------------------

def plot_pathway_information_flow_bar(flow_table: pd.DataFrame,
                                      output_path: str,
                                      top_n: int = 25,
                                      title: str = "Pathway information flow"
                                      ) -> Dict[str, str]:
    """Horizontal bar chart of top-``top_n`` pathways ordered by total
    information flow.

    ``flow_table`` is the output of
    :func:`network_analysis.pathway_information_flow_table` (must contain a
    ``flow`` column, indexed by pathway).
    """
    _ensure_dir(output_path)
    df = flow_table.head(top_n).iloc[::-1]
    fig, ax = plt.subplots(figsize=(7, 0.3 * len(df) + 1.5))
    ax.barh(df.index, df["flow"], color="steelblue")
    ax.set_xlabel("Total information flow")
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path}


# ---------------------------------------------------------------------------
# Comparison bar (LS vs NL or condition-A vs condition-B)
# ---------------------------------------------------------------------------

def plot_compare_information_flow(compare_df: pd.DataFrame,
                                  output_path: str,
                                  label_a: str = "A",
                                  label_b: str = "B",
                                  top_n: int = 20,
                                  title: str = "Information flow comparison"
                                  ) -> Dict[str, str]:
    """Diverging horizontal bar chart of pathways enriched in condition A
    vs condition B.

    ``compare_df`` is the output of
    :func:`network_analysis.compare_information_flow`. Bars to the left =
    condition B-enriched, to the right = condition A-enriched.
    """
    _ensure_dir(output_path)
    col_a = f"flow_{label_a}"
    col_b = f"flow_{label_b}"
    df = compare_df.copy()
    df = df.reindex(df["diff"].abs().sort_values(ascending=False).index)
    df = df.head(top_n).iloc[::-1]
    fig, ax = plt.subplots(figsize=(7, 0.3 * len(df) + 1.5))
    ax.barh(df.index, df[col_a], color="firebrick", label=label_a)
    ax.barh(df.index, -df[col_b], color="steelblue", label=label_b)
    ax.axvline(0, color="black", linewidth=0.5)
    ax.set_xlabel("Information flow")
    ax.legend(loc="lower right")
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path}


# ---------------------------------------------------------------------------
# Centrality bar
# ---------------------------------------------------------------------------

def plot_centrality_heatmap(centrality_df: pd.DataFrame,
                            output_path: str,
                            title: str = "Network centrality"
                            ) -> Dict[str, str]:
    """Heatmap of cell-type x centrality-measure scores
    (outgoing / incoming / mediator / influencer)."""
    _ensure_dir(output_path)
    z = centrality_df.values.copy()
    # column-wise z-score for visual contrast
    z = (z - z.mean(axis=0)) / (z.std(axis=0) + 1e-9)
    fig, ax = plt.subplots(figsize=(5, 0.35 * len(centrality_df) + 1.5))
    im = ax.imshow(z, aspect="auto", cmap="Greens")
    ax.set_xticks(range(centrality_df.shape[1]))
    ax.set_xticklabels(centrality_df.columns)
    ax.set_yticks(range(len(centrality_df.index)))
    ax.set_yticklabels(centrality_df.index, fontsize=9)
    ax.set_title(title)
    fig.colorbar(im, ax=ax, label="z-score")
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path}

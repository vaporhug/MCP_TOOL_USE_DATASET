"""Communication probability and significance primitives.

Implements:
- Hill / mass-action communication probability for a single L-R pair across
  every (sender, receiver) cell-type pair.
- Cofactor (agonist / antagonist / co-stimulatory / co-inhibitory) modulation.
- Permutation test on cell-type labels to obtain per-edge p-values.

All numpy + pandas; no scipy, no sklearn.
"""
from __future__ import annotations

from typing import Dict, List, Sequence, Tuple

import numpy as np
import pandas as pd


# ----------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------

def _resolve_complex_value(group_expr: pd.DataFrame,
                           subunit_str: str) -> np.ndarray:
    """Pipe-separated subunit string -> per-group geometric-mean expression.

    Returns a 1-D numpy array of length ``n_groups``. NaN if any subunit is
    absent (treated as zero downstream).
    """
    subs = [s for s in subunit_str.split("|") if s]
    rows = []
    for s in subs:
        if s in group_expr.index:
            rows.append(group_expr.loc[s].values)
        else:
            return np.zeros(group_expr.shape[1], dtype=float)
    arr = np.vstack(rows)
    eps = 1e-9
    return np.exp(np.mean(np.log(arr + eps), axis=0))


def _cofactor_score(group_expr: pd.DataFrame,
                    cof_set_name: str,
                    cofactors: Dict[str, List[str]]) -> np.ndarray:
    """Average expression of the genes in cofactor-set ``cof_set_name``
    across each cell group. Returns zero vector if name empty / missing.
    """
    if not cof_set_name or cof_set_name not in cofactors:
        return np.zeros(group_expr.shape[1], dtype=float)
    genes = [g for g in cofactors[cof_set_name] if g in group_expr.index]
    if not genes:
        return np.zeros(group_expr.shape[1], dtype=float)
    return group_expr.loc[genes].mean(axis=0).values


# ----------------------------------------------------------------------
# Communication probability
# ----------------------------------------------------------------------

def hill_function(L_R: np.ndarray, kh: float = 0.5, n: float = 1.0) -> np.ndarray:
    """Hill activation: ``L*R / (kh^n + L*R)``. Scalar / array. Saturates as
    L*R grows, which is the form CellChat uses to model mass-action
    receptor occupancy.
    """
    x = np.asarray(L_R, dtype=float)
    return (x ** n) / (kh ** n + x ** n + 1e-12)


def communication_probability_pair(group_expr: pd.DataFrame,
                                   ligand_subunits: str,
                                   receptor_subunits: str,
                                   agonist: str = "",
                                   antagonist: str = "",
                                   co_a_receptor: str = "",
                                   co_i_receptor: str = "",
                                   cofactors: Dict[str, List[str]] = None,
                                   kh: float = 0.5,
                                   n_hill: float = 1.0) -> pd.DataFrame:
    """Communication probability for a single L-R pair across all sender x
    receiver cell-group combinations.

    Mass-action with cofactor modulation:

        P(s, r) = Hill( L_s * R_r ) * (1 + AG_s) / (1 + AN_s)
                  * (1 + COA_r) / (1 + COI_r)

    where ``L_s`` is geometric-mean ligand-complex expression in sender
    group ``s``, ``R_r`` is geometric-mean receptor-complex expression in
    receiver ``r``, AG/AN are agonist / antagonist scores in the sender,
    COA / COI are co-stimulatory / co-inhibitory receptor scores in the
    receiver.

    Returns
    -------
    DataFrame, shape (n_groups, n_groups)
        Index = sender, columns = receiver, value = communication
        probability in [0, ~K].
    """
    if cofactors is None:
        cofactors = {}
    groups = list(group_expr.columns)
    L = _resolve_complex_value(group_expr, ligand_subunits)
    R = _resolve_complex_value(group_expr, receptor_subunits)
    AG = _cofactor_score(group_expr, agonist, cofactors)
    AN = _cofactor_score(group_expr, antagonist, cofactors)
    COA = _cofactor_score(group_expr, co_a_receptor, cofactors)
    COI = _cofactor_score(group_expr, co_i_receptor, cofactors)

    LR_outer = np.outer(L, R)               # (sender, receiver)
    base = hill_function(LR_outer, kh=kh, n=n_hill)
    sender_mod = (1.0 + AG) / (1.0 + AN)    # (n_groups,)
    receiver_mod = (1.0 + COA) / (1.0 + COI)
    prob = base * sender_mod[:, None] * receiver_mod[None, :]
    return pd.DataFrame(prob, index=groups, columns=groups)


def all_pairs_communication(expr: pd.DataFrame,
                            meta: pd.DataFrame,
                            interactions: pd.DataFrame,
                            cofactors: Dict[str, List[str]],
                            group_col: str = "cell_type",
                            kh: float = 0.5,
                            n_hill: float = 1.0,
                            min_cells: int = 10) -> Dict[str, pd.DataFrame]:
    """Compute communication probability for every interaction in
    ``interactions``.

    Cell groups with fewer than ``min_cells`` cells are dropped.

    Returns
    -------
    dict
        Maps ``interaction_id`` -> sender x receiver communication-probability
        DataFrame.
    """
    counts = meta[group_col].value_counts()
    keep_groups = counts[counts >= min_cells].index.tolist()
    sub = meta[meta[group_col].isin(keep_groups)]
    expr2 = expr[sub.index]
    # build group-mean (relative import preferred; fall back to top-level)
    try:
        from .expression_aggregation import truncated_mean_per_group
    except ImportError:
        from expression_aggregation import truncated_mean_per_group
    group_expr = truncated_mean_per_group(expr2, sub, group_col=group_col, trim=0.05)
    out: Dict[str, pd.DataFrame] = {}
    for _, row in interactions.iterrows():
        iid = row["interaction_id"]
        out[iid] = communication_probability_pair(
            group_expr,
            ligand_subunits=row["ligand_subunits"],
            receptor_subunits=row["receptor_subunits"],
            agonist=row.get("agonist", ""),
            antagonist=row.get("antagonist", ""),
            co_a_receptor=row.get("co_A_receptor", ""),
            co_i_receptor=row.get("co_I_receptor", ""),
            cofactors=cofactors,
            kh=kh, n_hill=n_hill,
        )
    return out


# ----------------------------------------------------------------------
# Permutation test
# ----------------------------------------------------------------------

def permutation_pvalues(expr: pd.DataFrame,
                        meta: pd.DataFrame,
                        interaction_row: pd.Series,
                        cofactors: Dict[str, List[str]],
                        group_col: str = "cell_type",
                        n_perm: int = 100,
                        kh: float = 0.5,
                        n_hill: float = 1.0,
                        min_cells: int = 10,
                        random_state: int = 0) -> pd.DataFrame:
    """One-sided upper-tail permutation p-values for a single L-R interaction.

    The cell-group labels are permuted ``n_perm`` times. For each
    (sender, receiver) edge the p-value is the fraction of permutations
    whose null communication probability >= the observed value.

    Returns
    -------
    DataFrame, shape (n_groups, n_groups)
        Permutation p-value per sender x receiver edge.
    """
    rng = np.random.default_rng(random_state)
    counts = meta[group_col].value_counts()
    keep_groups = counts[counts >= min_cells].index.tolist()
    sub_meta = meta[meta[group_col].isin(keep_groups)].copy()
    sub_expr = expr[sub_meta.index]
    try:
        from .expression_aggregation import truncated_mean_per_group
    except ImportError:
        from expression_aggregation import truncated_mean_per_group

    obs_group_expr = truncated_mean_per_group(sub_expr, sub_meta,
                                              group_col=group_col, trim=0.05)
    obs = communication_probability_pair(
        obs_group_expr,
        ligand_subunits=interaction_row["ligand_subunits"],
        receptor_subunits=interaction_row["receptor_subunits"],
        agonist=interaction_row.get("agonist", ""),
        antagonist=interaction_row.get("antagonist", ""),
        co_a_receptor=interaction_row.get("co_A_receptor", ""),
        co_i_receptor=interaction_row.get("co_I_receptor", ""),
        cofactors=cofactors, kh=kh, n_hill=n_hill,
    )

    n_groups = len(keep_groups)
    null_ge = np.zeros((n_groups, n_groups), dtype=int)
    label_arr = sub_meta[group_col].values.copy()

    for _ in range(n_perm):
        perm = rng.permutation(label_arr)
        perm_meta = sub_meta.copy()
        perm_meta[group_col] = perm
        ge = truncated_mean_per_group(sub_expr, perm_meta,
                                      group_col=group_col, trim=0.05)
        null = communication_probability_pair(
            ge,
            ligand_subunits=interaction_row["ligand_subunits"],
            receptor_subunits=interaction_row["receptor_subunits"],
            agonist=interaction_row.get("agonist", ""),
            antagonist=interaction_row.get("antagonist", ""),
            co_a_receptor=interaction_row.get("co_A_receptor", ""),
            co_i_receptor=interaction_row.get("co_I_receptor", ""),
            cofactors=cofactors, kh=kh, n_hill=n_hill,
        )
        # align column / row order
        null = null.loc[obs.index, obs.columns]
        null_ge += (null.values >= obs.values - 1e-12).astype(int)

    pvals = (null_ge + 1.0) / (n_perm + 1.0)
    return pd.DataFrame(pvals, index=obs.index, columns=obs.columns)


def significant_pairs(prob: pd.DataFrame,
                      pvals: pd.DataFrame,
                      pval_threshold: float = 0.05,
                      prob_threshold: float = 1e-4) -> pd.DataFrame:
    """Tabulate significant (sender, receiver) edges.

    Returns a tidy DataFrame with columns
    ``[sender, receiver, prob, pvalue]`` containing only edges where
    ``pvalue <= pval_threshold`` and ``prob >= prob_threshold``.
    """
    rows = []
    for s in prob.index:
        for r in prob.columns:
            p = prob.at[s, r]
            pv = pvals.at[s, r]
            if pv <= pval_threshold and p >= prob_threshold:
                rows.append({"sender": s, "receiver": r, "prob": float(p),
                             "pvalue": float(pv)})
    return pd.DataFrame(rows)

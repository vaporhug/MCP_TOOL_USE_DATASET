"""Pathway / pattern primitives for cell-cell communication.

Implements:
- Hypergeometric pathway enrichment (pure-numpy log-gamma based).
- Outgoing / incoming pattern matrices summarising per-cell-type pathway
  involvement.
- Functional / structural pathway similarity (cosine on aggregated
  network matrices).

No scipy; uses :mod:`math.lgamma` for the log binomial coefficient.
"""
from __future__ import annotations

import math
from typing import Dict, List

import numpy as np
import pandas as pd


# ---------------------------------------------------------------------------
# Pure-numpy hypergeometric (one-sided)
# ---------------------------------------------------------------------------

def _log_binom(n: int, k: int) -> float:
    if k < 0 or k > n:
        return -math.inf
    return math.lgamma(n + 1) - math.lgamma(k + 1) - math.lgamma(n - k + 1)


def hypergeometric_p(k_obs: int, n_drawn: int, K_pop: int, N_pop: int) -> float:
    """One-sided hypergeometric upper-tail p-value.

    Probability of observing >= ``k_obs`` successes in ``n_drawn`` draws
    from a population of ``N_pop`` items containing ``K_pop`` successes.

    Pure ``math.lgamma``; agrees with ``scipy.stats.hypergeom.sf(k-1, N, K, n)``
    to ~1e-10.
    """
    if k_obs < 1:
        return 1.0
    log_total = _log_binom(N_pop, n_drawn)
    p = 0.0
    upper = min(K_pop, n_drawn)
    for k in range(k_obs, upper + 1):
        log_term = (_log_binom(K_pop, k)
                    + _log_binom(N_pop - K_pop, n_drawn - k)
                    - log_total)
        p += math.exp(log_term)
    return float(min(max(p, 0.0), 1.0))


def benjamini_hochberg(pvalues: np.ndarray) -> np.ndarray:
    """Benjamini-Hochberg FDR-adjusted q-values."""
    p = np.asarray(pvalues, dtype=float)
    n = len(p)
    order = np.argsort(p)
    ranked = p[order]
    q = ranked * n / (np.arange(n) + 1)
    q = np.minimum.accumulate(q[::-1])[::-1]
    out = np.empty_like(q)
    out[order] = np.clip(q, 0.0, 1.0)
    return out


# ---------------------------------------------------------------------------
# Pathway enrichment of a peak / interaction set
# ---------------------------------------------------------------------------

def pathway_enrichment_hypergeo(selected_interactions: List[str],
                                interactions: pd.DataFrame) -> pd.DataFrame:
    """Hypergeometric enrichment of CellChatDB pathways in a selected set
    of L-R interactions.

    Parameters
    ----------
    selected_interactions : list of str
        ``interaction_id`` values that pass an upstream filter (e.g. all
        interactions with significant communication in lesional skin).
    interactions : DataFrame
        Curated interaction table with ``interaction_id`` and
        ``pathway_name`` columns.

    Returns
    -------
    DataFrame
        Indexed by pathway, columns
        ``[k, n, K, N, odds_ratio, pvalue, qvalue]``, sorted by ``pvalue``.
    """
    universe = interactions["interaction_id"].tolist()
    N = len(universe)
    sel = set(selected_interactions) & set(universe)
    n = len(sel)
    rows = []
    for pw, sub in interactions.groupby("pathway_name"):
        pw_iids = set(sub["interaction_id"])
        K = len(pw_iids)
        k = len(sel & pw_iids)
        if k == 0 or K == 0:
            pv = 1.0
            odds = 0.0
        else:
            pv = hypergeometric_p(k, n, K, N)
            expected = n * K / N
            odds = (k / max(expected, 1e-9))
        rows.append({"pathway": pw, "k": k, "n": n, "K": K, "N": N,
                     "odds_ratio": odds, "pvalue": pv})
    df = pd.DataFrame(rows)
    df["qvalue"] = benjamini_hochberg(df["pvalue"].values)
    return df.sort_values(["pvalue", "k"], ascending=[True, False]).reset_index(drop=True)


# ---------------------------------------------------------------------------
# Outgoing / incoming pattern matrices
# ---------------------------------------------------------------------------

def outgoing_pathway_matrix(prob_dict: Dict[str, pd.DataFrame],
                            interactions: pd.DataFrame) -> pd.DataFrame:
    """Per cell-type x pathway outgoing-signal contribution.

    Element (i, p) = total communication probability of pathway ``p``
    sourced from cell type ``i`` (sum over all receivers and L-R pairs).

    Returns DataFrame ``cell_types x pathway_names``.
    """
    rows = {}
    pathways = sorted(interactions["pathway_name"].unique())
    for pw in pathways:
        agg = None
        iids = interactions[interactions["pathway_name"] == pw]["interaction_id"]
        for iid in iids:
            if iid in prob_dict:
                m = prob_dict[iid]
                agg = m.copy() if agg is None else (agg + m.reindex_like(agg).fillna(0.0))
        if agg is None:
            continue
        rows[pw] = agg.sum(axis=1)
    if not rows:
        return pd.DataFrame()
    return pd.DataFrame(rows).fillna(0.0)


def incoming_pathway_matrix(prob_dict: Dict[str, pd.DataFrame],
                            interactions: pd.DataFrame) -> pd.DataFrame:
    """Per cell-type x pathway incoming-signal contribution (sum over
    senders and L-R pairs)."""
    rows = {}
    pathways = sorted(interactions["pathway_name"].unique())
    for pw in pathways:
        agg = None
        iids = interactions[interactions["pathway_name"] == pw]["interaction_id"]
        for iid in iids:
            if iid in prob_dict:
                m = prob_dict[iid]
                agg = m.copy() if agg is None else (agg + m.reindex_like(agg).fillna(0.0))
        if agg is None:
            continue
        rows[pw] = agg.sum(axis=0)
    if not rows:
        return pd.DataFrame()
    return pd.DataFrame(rows).fillna(0.0)


# ---------------------------------------------------------------------------
# Functional / structural similarity
# ---------------------------------------------------------------------------

def cosine_similarity_matrix(matrices: Dict[str, pd.DataFrame]) -> pd.DataFrame:
    """Cosine similarity between flattened per-pathway communication
    matrices.

    Used by CellChat for "functional similarity" grouping (Fig 2i, 6c, 7b).

    Returns a square ``DataFrame`` indexed/columned by pathway name.
    """
    keys = list(matrices.keys())
    vecs = {k: matrices[k].values.flatten() for k in keys}
    out = pd.DataFrame(0.0, index=keys, columns=keys)
    for i, ki in enumerate(keys):
        vi = vecs[ki]
        ni = np.linalg.norm(vi)
        for j, kj in enumerate(keys):
            vj = vecs[kj]
            nj = np.linalg.norm(vj)
            if ni == 0 or nj == 0:
                out.at[ki, kj] = 0.0
            else:
                out.at[ki, kj] = float(np.dot(vi, vj) / (ni * nj))
    return out


def structural_topology_features(network: pd.DataFrame) -> np.ndarray:
    """Topology-only features of one signaling network: row/column degree
    distributions normalized by total edges. Concatenates row-sum and
    column-sum vectors. Used for "structural similarity" grouping.
    """
    if network is None or network.empty:
        return np.zeros(0)
    rs = network.sum(axis=1).values
    cs = network.sum(axis=0).values
    total = rs.sum() + cs.sum() + 1e-12
    return np.concatenate([rs / total, cs / total])

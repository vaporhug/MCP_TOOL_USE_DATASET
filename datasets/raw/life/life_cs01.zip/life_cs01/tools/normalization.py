"""Normalization primitives for ATAC-seq peak count matrices.

The TCGA pan-cancer count matrix is delivered as ``log2(score-per-million + 1)``
already, but this module also supports raw integer count matrices: CPM scaling,
log2 transform, quantile normalization across samples, library-size factors and
per-sample z-scoring. Pure numpy / pandas; no scipy.
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def library_size(counts: pd.DataFrame) -> pd.Series:
    """Total signal per sample (sum over peaks)."""
    return counts.sum(axis=0)


def cpm_normalize(counts: pd.DataFrame) -> pd.DataFrame:
    """Per-column counts per million."""
    sums = counts.sum(axis=0).replace(0, np.nan)
    out = counts.divide(sums, axis=1) * 1e6
    return out.fillna(0.0)


def log2_normalize(matrix: pd.DataFrame, pseudo: float = 1.0) -> pd.DataFrame:
    """``log2(x + pseudo)`` element-wise."""
    return np.log2(matrix + float(pseudo))


def median_size_factor(counts: pd.DataFrame) -> pd.Series:
    """DESeq-style size factors via median-of-ratios.

    For each peak compute the geometric mean across samples, divide each sample
    by that pseudo-reference, then the size factor of the sample is the median
    of those ratios over peaks. Returns a Series indexed by sample.
    """
    arr = counts.values + 1.0
    log_geom = np.log(arr).mean(axis=1)
    ratios = np.log(arr) - log_geom[:, None]
    factors = np.exp(np.median(ratios, axis=0))
    return pd.Series(factors, index=counts.columns)


def normalize_by_size_factor(
    counts: pd.DataFrame, factors: pd.Series | None = None
) -> pd.DataFrame:
    """Divide each column by its size factor (computed if not provided)."""
    if factors is None:
        factors = median_size_factor(counts)
    safe = factors.replace(0, np.nan)
    out = counts.divide(safe, axis=1)
    return out.fillna(0.0)


def quantile_normalize(matrix: pd.DataFrame) -> pd.DataFrame:
    """Per-row quantile normalization across samples (columns).

    Replaces each column's values with the row-wise mean of sorted values, so
    every column has identical distribution. Operates on the value matrix.
    """
    arr = matrix.values.astype(float)
    n_rows, n_cols = arr.shape
    sorted_arr = np.sort(arr, axis=0)
    mean_sorted = sorted_arr.mean(axis=1)
    rank = arr.argsort(axis=0).argsort(axis=0)
    out = mean_sorted[rank]
    return pd.DataFrame(out, index=matrix.index, columns=matrix.columns)


def zscore_per_peak(matrix: pd.DataFrame) -> pd.DataFrame:
    """Row-wise (per peak) z-score across samples."""
    mu = matrix.mean(axis=1)
    sd = matrix.std(axis=1).replace(0, np.nan)
    out = matrix.sub(mu, axis=0).divide(sd, axis=0)
    return out.fillna(0.0)


def winsorize(matrix: pd.DataFrame, lower_pct: float = 1.0, upper_pct: float = 99.0) -> pd.DataFrame:
    """Clip extreme values per peak to the lower/upper percentile range."""
    lo = matrix.quantile(lower_pct / 100.0, axis=1)
    hi = matrix.quantile(upper_pct / 100.0, axis=1)
    return matrix.clip(lower=lo, upper=hi, axis=0)

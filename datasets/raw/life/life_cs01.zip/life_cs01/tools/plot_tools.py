"""Plot helpers for the ATAC-seq peak analysis task.

Each function returns ``{"path": "<absolute path>"}`` and writes a PNG. Uses
matplotlib's Agg backend so plots render in headless environments.
"""
from __future__ import annotations

import os
from typing import Dict, List, Optional, Sequence

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def _save(fig: plt.Figure, path: str) -> Dict[str, str]:
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    fig.tight_layout()
    fig.savefig(path, dpi=140, bbox_inches="tight")
    plt.close(fig)
    return {"path": os.path.abspath(path)}


def plot_volcano(
    diff_df: pd.DataFrame,
    out_path: str,
    padj_thresh: float = 0.05,
    lfc_thresh: float = 1.0,
    title: Optional[str] = None,
    label_top_n: int = 0,
) -> Dict[str, str]:
    """Volcano plot of log2FC (x) vs -log10 p-value (y).

    Required columns in ``diff_df``: ``log2FC, pvalue, padj``.
    """
    fig, ax = plt.subplots(figsize=(6.0, 5.0))
    x = diff_df["log2FC"].values
    y = -np.log10(diff_df["pvalue"].clip(lower=1e-300).values)
    sig = (diff_df["padj"] < float(padj_thresh)) & (np.abs(diff_df["log2FC"]) >= float(lfc_thresh))
    up = sig & (diff_df["log2FC"] > 0)
    dn = sig & (diff_df["log2FC"] < 0)
    ax.scatter(x[~sig], y[~sig], s=4, color="lightgrey", alpha=0.6, label="ns")
    ax.scatter(x[up], y[up], s=6, color="#d62728", alpha=0.8, label="up in group A")
    ax.scatter(x[dn], y[dn], s=6, color="#1f77b4", alpha=0.8, label="up in group B")
    ax.axhline(-np.log10(padj_thresh), color="grey", linestyle="--", linewidth=0.6)
    ax.axvline(lfc_thresh, color="grey", linestyle="--", linewidth=0.6)
    ax.axvline(-lfc_thresh, color="grey", linestyle="--", linewidth=0.6)
    ax.set_xlabel("log2 fold change (A vs B)")
    ax.set_ylabel("-log10 p-value")
    if title:
        ax.set_title(title)
    ax.legend(loc="upper left", fontsize=8)
    return _save(fig, out_path)


def plot_ma(
    diff_df: pd.DataFrame,
    counts: pd.DataFrame,
    out_path: str,
    padj_thresh: float = 0.05,
    title: Optional[str] = None,
) -> Dict[str, str]:
    """MA plot: mean accessibility (x) vs log2 fold change (y).

    ``diff_df`` must have ``log2FC, padj``; ``counts`` is the raw matrix used
    to compute the per-peak mean (across all samples).
    """
    mean_acc = counts.loc[diff_df.index].mean(axis=1)
    fig, ax = plt.subplots(figsize=(6.0, 4.5))
    sig = diff_df["padj"] < float(padj_thresh)
    ax.scatter(mean_acc[~sig], diff_df["log2FC"][~sig], s=4, color="lightgrey", alpha=0.6, label="ns")
    ax.scatter(mean_acc[sig],  diff_df["log2FC"][sig],  s=6, color="#d62728", alpha=0.8, label=f"padj<{padj_thresh}")
    ax.axhline(0, color="black", linewidth=0.5)
    ax.set_xlabel("Mean accessibility (across all samples)")
    ax.set_ylabel("log2 fold change")
    if title:
        ax.set_title(title)
    ax.legend(loc="upper right", fontsize=8)
    return _save(fig, out_path)


def plot_peak_heatmap(
    counts: pd.DataFrame,
    sample_meta: pd.DataFrame,
    peak_ids: List[str],
    out_path: str,
    group_col: str = "cancer_type",
    title: Optional[str] = None,
) -> Dict[str, str]:
    """Z-score heatmap of selected peaks (rows) across samples (columns).

    Samples are grouped by ``group_col`` and a colored bar is drawn at the top.
    """
    sub = counts.loc[counts.index.intersection(peak_ids)].copy()
    # Z-score each row across samples
    mu = sub.mean(axis=1)
    sd = sub.std(axis=1).replace(0, np.nan)
    z = sub.sub(mu, axis=0).divide(sd, axis=0).fillna(0.0)
    # Sort columns by group
    sample_meta = sample_meta.set_index("sample_id").loc[z.columns]
    order = sample_meta.sort_values(group_col).index.tolist()
    z = z[order]
    sample_meta = sample_meta.loc[order]

    fig, (ax_bar, ax_hm) = plt.subplots(
        2, 1, figsize=(max(6, len(z.columns) * 0.18), 6),
        gridspec_kw={"height_ratios": [0.6, 9]}, sharex=True,
    )
    groups = sample_meta[group_col].astype(str).values
    uniq = list(dict.fromkeys(groups))
    cmap_g = plt.get_cmap("Set1")
    color_map = {g: cmap_g(i % 9) for i, g in enumerate(uniq)}
    bar_colors = [color_map[g] for g in groups]
    ax_bar.bar(range(len(groups)), [1] * len(groups), color=bar_colors, width=1.0)
    ax_bar.set_yticks([])
    ax_bar.set_xticks([])
    handles = [plt.Rectangle((0, 0), 1, 1, color=color_map[g]) for g in uniq]
    ax_bar.legend(handles, uniq, loc="upper right", fontsize=8, ncol=len(uniq))

    im = ax_hm.imshow(z.values, aspect="auto", cmap="RdBu_r", vmin=-2, vmax=2)
    ax_hm.set_xticks([])
    ax_hm.set_yticks([])
    ax_hm.set_xlabel("Samples (grouped)")
    ax_hm.set_ylabel(f"{len(z)} peaks (row z-score)")
    fig.colorbar(im, ax=ax_hm, shrink=0.5, label="z-score")
    if title:
        fig.suptitle(title, y=1.02)
    return _save(fig, out_path)


def plot_motif_enrichment_bar(
    enrichment_df: pd.DataFrame,
    out_path: str,
    top_n: int = 10,
    metric: str = "neg_log10_p",
    title: Optional[str] = None,
) -> Dict[str, str]:
    """Horizontal bar chart of TFs ranked by enrichment significance."""
    df = enrichment_df.sort_values(metric, ascending=False).head(int(top_n))
    fig, ax = plt.subplots(figsize=(6.0, max(2.5, 0.35 * len(df))))
    cmap = plt.get_cmap("viridis")
    colors = [cmap(i / max(1, len(df) - 1)) for i in range(len(df))]
    ax.barh(range(len(df)), df[metric].values[::-1], color=colors[::-1])
    ax.set_yticks(range(len(df)))
    ax.set_yticklabels(df.index[::-1], fontsize=9)
    ax.set_xlabel(metric)
    if title:
        ax.set_title(title)
    for i, v in enumerate(df[metric].values[::-1]):
        ax.text(v, i, f" {v:.2f}", va="center", fontsize=8)
    return _save(fig, out_path)


def plot_genomic_feature_pie(
    counts_series: pd.Series,
    out_path: str,
    title: Optional[str] = None,
) -> Dict[str, str]:
    """Pie chart of peak counts per genomic feature."""
    fig, ax = plt.subplots(figsize=(5, 5))
    labels = [f"{k} ({v})" for k, v in counts_series.items()]
    cmap = plt.get_cmap("tab10")
    colors = [cmap(i % 10) for i in range(len(counts_series))]
    ax.pie(counts_series.values, labels=labels, colors=colors,
           autopct="%1.1f%%", startangle=90, textprops={"fontsize": 8})
    ax.axis("equal")
    if title:
        ax.set_title(title)
    return _save(fig, out_path)


def plot_pca(
    counts: pd.DataFrame,
    sample_meta: pd.DataFrame,
    out_path: str,
    group_col: str = "cancer_type",
    title: Optional[str] = None,
    top_var_peaks: int = 5000,
) -> Dict[str, str]:
    """PCA scatter of samples on the top ``top_var_peaks`` most-variable peaks."""
    var = counts.var(axis=1)
    keep = var.sort_values(ascending=False).head(int(top_var_peaks)).index
    X = counts.loc[keep].T.values  # samples x peaks
    X = X - X.mean(axis=0, keepdims=True)
    # SVD-based PCA, take first 2 components
    U, S, Vt = np.linalg.svd(X, full_matrices=False)
    PC = U[:, :2] * S[:2]
    sample_meta = sample_meta.set_index("sample_id").loc[counts.columns]
    fig, ax = plt.subplots(figsize=(5.5, 4.5))
    cmap = plt.get_cmap("Set1")
    groups = sample_meta[group_col].astype(str).values
    uniq = list(dict.fromkeys(groups))
    for i, g in enumerate(uniq):
        m = groups == g
        ax.scatter(PC[m, 0], PC[m, 1], s=42, color=cmap(i % 9),
                   label=g, edgecolors="k", linewidths=0.4)
    ax.set_xlabel(f"PC1 ({S[0]**2 / (S**2).sum() * 100:.1f}%)")
    ax.set_ylabel(f"PC2 ({S[1]**2 / (S**2).sum() * 100:.1f}%)")
    if title:
        ax.set_title(title)
    ax.legend(loc="best", fontsize=8)
    ax.axhline(0, color="grey", linewidth=0.4)
    ax.axvline(0, color="grey", linewidth=0.4)
    return _save(fig, out_path)


def plot_tf_motif_logo_proxy(
    pwm_prob: np.ndarray,
    tf_name: str,
    out_path: str,
) -> Dict[str, str]:
    """A simple per-position information-content heatmap as a motif logo proxy."""
    bases = ["A", "C", "G", "T"]
    L = pwm_prob.shape[1]
    fig, ax = plt.subplots(figsize=(max(3, 0.4 * L), 2.4))
    im = ax.imshow(pwm_prob, aspect="auto", cmap="Greens", vmin=0, vmax=1)
    ax.set_yticks(range(4))
    ax.set_yticklabels(bases)
    ax.set_xticks(range(L))
    ax.set_xticklabels([str(i + 1) for i in range(L)], fontsize=7)
    ax.set_xlabel("Position")
    ax.set_title(f"{tf_name} PWM probabilities")
    fig.colorbar(im, ax=ax, shrink=0.7, label="P(base|pos)")
    return _save(fig, out_path)

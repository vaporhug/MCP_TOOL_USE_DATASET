"""Differential accessibility / differential binding primitives.

Implements per-peak two-sample tests (Welch's t-test, Mann-Whitney U), log2
fold change, Benjamini-Hochberg FDR, and a tidy results frame. All scipy is
re-implemented in pure numpy so the agent code never imports scipy.
"""
from __future__ import annotations

from typing import Iterable, List

import math

import numpy as np
import pandas as pd


# ---------------------------------------------------------------------------
# Pure-numpy two-sample tests
# ---------------------------------------------------------------------------

def _erfcc(x: np.ndarray) -> np.ndarray:
    """Numerical complementary error function (Chebyshev, ~7e-8 abs error)."""
    z = np.abs(x)
    t = 1.0 / (1.0 + 0.5 * z)
    ans = t * np.exp(
        -z * z - 1.26551223 + t * (1.00002368 + t * (0.37409196 + t * (
            0.09678418 + t * (-0.18628806 + t * (0.27886807 + t * (
                -1.13520398 + t * (1.48851587 + t * (
                    -0.82215223 + t * 0.17087277))))))))
    )
    return np.where(x >= 0, ans, 2.0 - ans)


def _normal_cdf(z: np.ndarray) -> np.ndarray:
    """Standard-normal CDF using complementary error function."""
    return 0.5 * _erfcc(-z / math.sqrt(2.0))


def _t_sf(t: np.ndarray, df: float) -> np.ndarray:
    """Survival function P(T > t) for Student's t with df degrees of freedom.

    Uses the regularized incomplete beta identity:
      P(T > t) = 0.5 * I_{df/(df+t^2)}(df/2, 1/2),  t > 0.
    Implemented via a continued-fraction expansion of the incomplete beta.
    """
    df = float(df)
    t = np.asarray(t, dtype=float)

    def betacf(a: float, b: float, x: np.ndarray, max_iter: int = 200, eps: float = 3.0e-7):
        qab = a + b
        qap = a + 1.0
        qam = a - 1.0
        c = 1.0
        d = 1.0 - qab * x / qap
        d = np.where(np.abs(d) < 1.0e-30, 1.0e-30, d)
        d = 1.0 / d
        h = d
        for m in range(1, max_iter + 1):
            m2 = 2 * m
            aa = m * (b - m) * x / ((qam + m2) * (a + m2))
            d = 1.0 + aa * d
            d = np.where(np.abs(d) < 1.0e-30, 1.0e-30, d)
            c = 1.0 + aa / c
            c = np.where(np.abs(c) < 1.0e-30, 1.0e-30, c)
            d = 1.0 / d
            h = h * d * c
            aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
            d = 1.0 + aa * d
            d = np.where(np.abs(d) < 1.0e-30, 1.0e-30, d)
            c = 1.0 + aa / c
            c = np.where(np.abs(c) < 1.0e-30, 1.0e-30, c)
            d = 1.0 / d
            del_ = d * c
            h = h * del_
            if np.all(np.abs(del_ - 1.0) < eps):
                break
        return h

    def betai(a: float, b: float, x: np.ndarray):
        x = np.clip(x, 1e-15, 1.0 - 1e-15)
        bt = np.exp(
            math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b)
            + a * np.log(x) + b * np.log(1.0 - x)
        )
        cond = x < (a + 1.0) / (a + b + 2.0)
        out = np.empty_like(x, dtype=float)
        if np.any(cond):
            out[cond] = bt[cond] * betacf(a, b, x[cond]) / a
        if np.any(~cond):
            out[~cond] = 1.0 - bt[~cond] * betacf(b, a, 1.0 - x[~cond]) / b
        return out

    abs_t = np.abs(t)
    x = df / (df + abs_t * abs_t)
    p = 0.5 * betai(df / 2.0, 0.5, x)
    # Two-sided complement of P(T>|t|): we return one-tailed; caller doubles.
    return p


def welch_t_test(
    matrix: pd.DataFrame, group_a: List[str], group_b: List[str]
) -> pd.DataFrame:
    """Per-row Welch's two-sample t-test (group A vs group B).

    Returns a DataFrame indexed by ``matrix.index`` with columns
    ``mean_a, mean_b, t_stat, df, pvalue`` where ``pvalue`` is two-sided.
    """
    a = matrix[group_a].values.astype(float)
    b = matrix[group_b].values.astype(float)
    na = a.shape[1]
    nb = b.shape[1]
    ma = a.mean(axis=1)
    mb = b.mean(axis=1)
    va = a.var(axis=1, ddof=1)
    vb = b.var(axis=1, ddof=1)
    se = np.sqrt(va / na + vb / nb)
    se_safe = np.where(se == 0, np.nan, se)
    t = (ma - mb) / se_safe
    # Welch-Satterthwaite df
    num = (va / na + vb / nb) ** 2
    den = (va ** 2) / (na ** 2 * (na - 1)) + (vb ** 2) / (nb ** 2 * (nb - 1))
    den_safe = np.where(den == 0, np.nan, den)
    df = num / den_safe
    df = np.nan_to_num(df, nan=na + nb - 2)
    p_one = _t_sf(np.abs(np.nan_to_num(t, nan=0.0)), float(np.median(df)))
    p_two = np.clip(2.0 * p_one, 0.0, 1.0)
    out = pd.DataFrame({
        "mean_a": ma,
        "mean_b": mb,
        "t_stat": t,
        "df": df,
        "pvalue": p_two,
    }, index=matrix.index)
    return out


def mann_whitney_u(
    matrix: pd.DataFrame, group_a: List[str], group_b: List[str]
) -> pd.DataFrame:
    """Per-row Mann-Whitney U with normal-approximation two-sided p-values.

    Returns DataFrame with ``u_stat, z_stat, pvalue`` columns. Tie correction is
    applied to the variance term.
    """
    a = matrix[group_a].values.astype(float)
    b = matrix[group_b].values.astype(float)
    na = a.shape[1]
    nb = b.shape[1]
    n_total = na + nb
    n_peaks = a.shape[0]
    combined = np.concatenate([a, b], axis=1)
    # Rank per row (average ranks for ties)
    order = combined.argsort(axis=1, kind="stable")
    ranks = np.empty_like(order, dtype=float)
    for i in range(n_peaks):
        idx = order[i]
        sorted_vals = combined[i, idx]
        rk = np.empty(n_total, dtype=float)
        j = 0
        while j < n_total:
            k = j
            while k + 1 < n_total and sorted_vals[k + 1] == sorted_vals[j]:
                k += 1
            avg_rank = (j + k) / 2.0 + 1.0
            rk[j:k + 1] = avg_rank
            j = k + 1
        ranks[i, idx] = rk
    rank_sum_a = ranks[:, :na].sum(axis=1)
    u_a = rank_sum_a - na * (na + 1) / 2.0
    u_b = na * nb - u_a
    u_stat = np.minimum(u_a, u_b)
    mu_u = na * nb / 2.0
    sigma_u = np.sqrt(na * nb * (na + nb + 1) / 12.0)
    sigma_u = sigma_u if sigma_u > 0 else 1e-10
    z = (u_a - mu_u) / sigma_u
    p = 2.0 * (1.0 - _normal_cdf(np.abs(z)))
    p = np.clip(p, 0.0, 1.0)
    out = pd.DataFrame({
        "u_stat": u_stat,
        "z_stat": z,
        "pvalue": p,
    }, index=matrix.index)
    return out


def log2_fold_change(
    matrix: pd.DataFrame, group_a: List[str], group_b: List[str], pseudo: float = 0.5
) -> pd.Series:
    """``log2((mean_a + pseudo) / (mean_b + pseudo))``. Positive => up in group A.

    Use this on raw or CPM (linear-scale) count matrices.
    """
    ma = matrix[group_a].mean(axis=1)
    mb = matrix[group_b].mean(axis=1)
    return np.log2((ma + pseudo) / (mb + pseudo))


def mean_diff(
    matrix: pd.DataFrame, group_a: List[str], group_b: List[str]
) -> pd.Series:
    """``mean_a - mean_b`` per peak. Use when ``matrix`` is already log-scale.

    For the bundled ``atac_count_matrix.csv`` (log2-normalized accessibility),
    this is the appropriate fold-change measure: a unit difference means
    a 2x change in linear accessibility.
    """
    return matrix[group_a].mean(axis=1) - matrix[group_b].mean(axis=1)


def bh_correct(pvalues: Iterable[float]) -> np.ndarray:
    """Benjamini-Hochberg adjusted p-values (returns a numpy array)."""
    p = np.asarray(list(pvalues), dtype=float)
    n = len(p)
    order = np.argsort(p)
    ranked = p[order]
    adj = ranked * n / np.arange(1, n + 1)
    # Enforce monotonicity from the largest down
    adj = np.minimum.accumulate(adj[::-1])[::-1]
    adj = np.clip(adj, 0.0, 1.0)
    out = np.empty_like(adj)
    out[order] = adj
    return out


def assemble_diff_results(
    test_df: pd.DataFrame, lfc: pd.Series
) -> pd.DataFrame:
    """Combine a test result table (with ``pvalue``) and log2FC, add BH-FDR."""
    out = test_df.copy()
    out["log2FC"] = lfc
    out["padj"] = bh_correct(out["pvalue"].fillna(1.0).values)
    out["neg_log10_p"] = -np.log10(out["pvalue"].clip(lower=1e-300))
    return out


def call_differential_peaks(
    diff_df: pd.DataFrame, padj_thresh: float = 0.05, lfc_thresh: float = 1.0
) -> pd.DataFrame:
    """Annotate each peak as 'up_a', 'up_b' or 'ns' based on FDR and |log2FC|."""
    df = diff_df.copy()
    is_sig = df["padj"] < float(padj_thresh)
    df["direction"] = np.where(
        is_sig & (df["log2FC"] >= float(lfc_thresh)), "up_a",
        np.where(is_sig & (df["log2FC"] <= -float(lfc_thresh)), "up_b", "ns"),
    )
    return df


def fishers_exact_2x2(a: int, b: int, c: int, d: int) -> float:
    """Two-sided Fisher's exact p-value on a 2x2 contingency table.

    Table is::

        |     | success | failure |
        | A   |   a     |   b     |
        | B   |   c     |   d     |

    Implemented by summing the hypergeometric tail probabilities <=
    the observed probability. Pure-python; suitable for ~10^4 calls.
    """
    a, b, c, d = int(a), int(b), int(c), int(d)
    n = a + b + c + d
    r1 = a + b
    r2 = c + d
    c1 = a + c
    if min(r1, r2, c1) < 0 or n == 0:
        return 1.0
    log_fact = [0.0]
    for i in range(1, n + 1):
        log_fact.append(log_fact[-1] + math.log(i))
    def lp(k):
        # log P(X=k | hypergeometric N, K=c1, n_draws=r1)
        return (log_fact[r1] + log_fact[r2] + log_fact[c1] + log_fact[n - c1]
                - log_fact[n] - log_fact[k] - log_fact[r1 - k]
                - log_fact[c1 - k] - log_fact[r2 - (c1 - k)])
    k_min = max(0, c1 - r2)
    k_max = min(r1, c1)
    log_p_obs = lp(a)
    total = 0.0
    p_obs = math.exp(log_p_obs)
    for k in range(k_min, k_max + 1):
        lp_k = lp(k)
        if lp_k <= log_p_obs + 1e-12:
            total += math.exp(lp_k)
    return float(min(total, 1.0))

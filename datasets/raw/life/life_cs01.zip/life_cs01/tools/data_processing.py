"""I/O and basic table primitives for the ATAC-seq peak analysis task.

Loads peak count matrices, peak metadata, sample metadata, peak sequences,
position weight matrices and the small TSS coordinate table. Pure pandas /
numpy; no scipy.
"""
from __future__ import annotations

from typing import Dict, List, Tuple

import numpy as np
import pandas as pd


def load_count_matrix(path: str) -> pd.DataFrame:
    """Load the ATAC-seq peak x sample count matrix.

    Returns a DataFrame indexed by ``peak_id`` (string) with one column per
    biological sample. Values are log2(CPM+1)-style normalized accessibility
    scores as deposited by the upstream TCGA ATAC-seq pipeline.
    """
    df = pd.read_csv(path, index_col=0)
    df.index = df.index.astype(str)
    df.index.name = "peak_id"
    return df


def load_peak_metadata(path: str) -> pd.DataFrame:
    """Load the per-peak metadata table.

    Columns: ``peak_id``, ``chrom``, ``start``, ``end``, ``annotation``
    (Promoter / Distal / Intron / Exon / 5' UTR / 3' UTR), ``gc_content``.
    """
    return pd.read_csv(path)


def load_sample_metadata(path: str) -> pd.DataFrame:
    """Load the per-sample metadata table.

    Columns: ``sample_id``, ``cancer_type`` (LUAD or LUSC).
    """
    return pd.read_csv(path)


def load_peak_sequences(path: str) -> pd.DataFrame:
    """Load 500-bp DNA sequences for every peak.

    Columns: ``peak_id``, ``sequence`` (uppercase A/C/G/T, length 500).
    """
    df = pd.read_csv(path)
    df["sequence"] = df["sequence"].str.upper()
    return df


def load_pwms(path: str) -> Dict[str, np.ndarray]:
    """Load motif PWMs as a dict ``{tf_name: 4 x L probability matrix}``.

    The on-disk format is long: one row per (tf, position) with columns
    ``A, C, G, T`` summing to 1. Rows of the returned matrices are A, C, G, T.
    """
    df = pd.read_csv(path)
    out: Dict[str, np.ndarray] = {}
    for tf, sub in df.groupby("tf"):
        sub = sub.sort_values("position")
        mat = sub[["A", "C", "G", "T"]].values.T.astype(float)
        out[str(tf)] = mat
    return out


def load_gene_coords(path: str) -> pd.DataFrame:
    """Load the small TSS coordinate table.

    Columns: ``gene``, ``chrom``, ``tss``, ``strand``. Coordinates are hg38.
    """
    return pd.read_csv(path)


def split_samples_by_group(
    sample_meta: pd.DataFrame, group_col: str = "cancer_type"
) -> Dict[str, List[str]]:
    """Return a dict mapping each group label to the list of sample IDs."""
    out: Dict[str, List[str]] = {}
    for g, sub in sample_meta.groupby(group_col):
        out[str(g)] = sub["sample_id"].astype(str).tolist()
    return out


def filter_peaks_by_min_value(
    counts: pd.DataFrame, min_value: float = 0.5, min_samples: int = 3
) -> pd.DataFrame:
    """Keep peaks whose value exceeds ``min_value`` in at least ``min_samples`` columns."""
    keep = (counts > float(min_value)).sum(axis=1) >= int(min_samples)
    return counts.loc[keep]


def subset_peaks_by_annotation(
    counts: pd.DataFrame, peak_meta: pd.DataFrame, annotations: List[str]
) -> pd.DataFrame:
    """Keep only peaks whose ``annotation`` is in ``annotations`` (e.g. ['Promoter'])."""
    keep_ids = set(peak_meta.loc[peak_meta["annotation"].isin(annotations), "peak_id"])
    return counts.loc[counts.index.isin(keep_ids)]


def align_counts_to_metadata(
    counts: pd.DataFrame, sample_meta: pd.DataFrame
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Return (counts, sample_meta) restricted to samples present in both, in matched order."""
    cols = [c for c in counts.columns if c in set(sample_meta["sample_id"].astype(str))]
    sm = sample_meta.set_index("sample_id").loc[cols].reset_index()
    return counts[cols], sm


def summarize_count_matrix(counts: pd.DataFrame) -> Dict[str, float]:
    """Return basic descriptive stats: n_peaks, n_samples, mean, median, q25, q75."""
    flat = counts.values.flatten()
    return {
        "n_peaks": int(counts.shape[0]),
        "n_samples": int(counts.shape[1]),
        "mean": float(np.mean(flat)),
        "median": float(np.median(flat)),
        "q25": float(np.percentile(flat, 25)),
        "q75": float(np.percentile(flat, 75)),
    }

"""Peak annotation primitives.

Maps each peak to a genomic feature (Promoter / Distal / Intron / etc.) using
the bundled annotation column, computes distance to the nearest TSS in the
small bundled gene table, and produces feature-frequency summaries useful for
the agent's report.
"""
from __future__ import annotations

from typing import Dict, List

import numpy as np
import pandas as pd


def count_peaks_per_feature(peak_meta: pd.DataFrame) -> pd.Series:
    """Count peaks per genomic feature (annotation column)."""
    return peak_meta["annotation"].value_counts().sort_values(ascending=False)


def fraction_peaks_per_feature(peak_meta: pd.DataFrame) -> pd.Series:
    """Return the fraction of peaks per genomic feature."""
    counts = count_peaks_per_feature(peak_meta)
    return counts / counts.sum()


def feature_breakdown_for_peakset(
    peak_meta: pd.DataFrame, peak_ids: List[str]
) -> pd.Series:
    """Annotation breakdown restricted to a subset of peaks (e.g. differential)."""
    sub = peak_meta[peak_meta["peak_id"].isin(set(peak_ids))]
    return count_peaks_per_feature(sub)


def peak_center(peak_meta: pd.DataFrame) -> pd.Series:
    """Return Series of integer peak centers indexed by peak_id."""
    s = ((peak_meta["start"] + peak_meta["end"]) // 2).astype(int)
    s.index = peak_meta["peak_id"].values
    return s


def distance_to_nearest_gene(
    peak_meta: pd.DataFrame, gene_coords: pd.DataFrame
) -> pd.DataFrame:
    """Per peak: nearest gene from the bundled TSS table, on the same chrom.

    Returns a DataFrame indexed by peak_id with columns
    ``nearest_gene, signed_distance_to_tss, abs_distance_to_tss``.
    Signed distance follows the gene strand: positive means downstream of TSS.
    Peaks on chromosomes absent from the gene table get NaN.
    """
    centers = peak_center(peak_meta)
    gene_by_chr: Dict[str, pd.DataFrame] = {}
    for c, g in gene_coords.groupby("chrom"):
        gg = g.sort_values("tss").reset_index(drop=True)
        gene_by_chr[str(c)] = gg

    nearest = []
    signed = []
    abs_d = []
    pid = []
    for _, row in peak_meta.iterrows():
        chrom = str(row["chrom"])
        c = int(centers[row["peak_id"]])
        pid.append(row["peak_id"])
        if chrom not in gene_by_chr:
            nearest.append(None)
            signed.append(np.nan)
            abs_d.append(np.nan)
            continue
        g = gene_by_chr[chrom]
        tss_arr = g["tss"].values.astype(int)
        idx = int(np.argmin(np.abs(tss_arr - c)))
        gene = str(g.iloc[idx]["gene"])
        strand = str(g.iloc[idx]["strand"])
        delta = c - int(g.iloc[idx]["tss"])
        if strand == "-":
            delta = -delta
        nearest.append(gene)
        signed.append(int(delta))
        abs_d.append(int(abs(delta)))

    return pd.DataFrame({
        "peak_id": pid,
        "nearest_gene": nearest,
        "signed_distance_to_tss": signed,
        "abs_distance_to_tss": abs_d,
    }).set_index("peak_id")


def assign_promoter_label(
    peak_meta: pd.DataFrame, gene_coords: pd.DataFrame, max_dist_bp: int = 2000
) -> pd.DataFrame:
    """Re-classify peaks: 'Promoter' if within ``max_dist_bp`` of a TSS.

    Useful as an alternative to the bundled annotation. Returns a DataFrame
    with columns ``peak_id, custom_annotation`` (Promoter or Distal).
    """
    dist = distance_to_nearest_gene(peak_meta, gene_coords)
    label = np.where(dist["abs_distance_to_tss"] <= int(max_dist_bp), "Promoter", "Distal")
    return pd.DataFrame({
        "peak_id": dist.index,
        "custom_annotation": label,
    })


def peaks_by_chromosome(peak_meta: pd.DataFrame) -> pd.Series:
    """Number of peaks per chromosome (sorted by chromosome)."""
    return peak_meta["chrom"].value_counts().sort_index()

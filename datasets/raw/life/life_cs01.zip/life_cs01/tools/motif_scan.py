"""PWM-based motif scanning and motif enrichment primitives.

Position-weight-matrix log-odds scanner for fixed-length motifs over the
500-bp peak sequences provided in ``peak_sequences.csv``. Builds a binary
peak x TF hit matrix, then uses a hypergeometric / Fisher 2x2 test
(implemented in ``differential.fishers_exact_2x2``) for motif enrichment of
arbitrary peak subsets vs background.
"""
from __future__ import annotations

from typing import Dict, List

import numpy as np
import pandas as pd

from .differential import fishers_exact_2x2, bh_correct  # noqa: F401  (re-export)

_BASE_TO_IDX = {"A": 0, "C": 1, "G": 2, "T": 3}


def reverse_complement(seq: str) -> str:
    """Return the reverse complement of a DNA string (uppercase)."""
    comp = {"A": "T", "C": "G", "G": "C", "T": "A", "N": "N"}
    return "".join(comp.get(b, "N") for b in seq[::-1])


def pwm_log_odds(pwm: np.ndarray, background: np.ndarray | None = None,
                 pseudocount: float = 0.001) -> np.ndarray:
    """Convert a 4 x L probability PWM to a log2 odds matrix.

    ``background`` is a 4-vector of background base probabilities. If None, a
    uniform 0.25 background is used.
    """
    if background is None:
        background = np.array([0.25, 0.25, 0.25, 0.25])
    bg = np.asarray(background, dtype=float)
    pwm = np.asarray(pwm, dtype=float) + pseudocount
    pwm = pwm / pwm.sum(axis=0, keepdims=True)
    return np.log2(pwm / bg[:, None])


def _seq_to_idx(seq: str) -> np.ndarray:
    """Convert a DNA string to a 0..3 integer array; non-ACGT becomes -1."""
    arr = np.full(len(seq), -1, dtype=np.int64)
    for i, b in enumerate(seq):
        v = _BASE_TO_IDX.get(b, -1)
        arr[i] = v
    return arr


def scan_sequence(seq: str, log_odds: np.ndarray, threshold: float,
                  scan_both_strands: bool = True) -> int:
    """Count motif hits in ``seq`` whose log-odds score >= ``threshold``.

    ``log_odds`` is a 4 x L matrix from :func:`pwm_log_odds`. Both strands are
    scanned if ``scan_both_strands`` is True.
    """
    seq_arr = _seq_to_idx(seq.upper())
    L = log_odds.shape[1]
    hits = 0
    n = len(seq_arr)
    for start in range(n - L + 1):
        window = seq_arr[start:start + L]
        if (window < 0).any():
            continue
        score = float(log_odds[window, np.arange(L)].sum())
        if score >= threshold:
            hits += 1
            continue
        if scan_both_strands:
            rc = 3 - window[::-1]
            score_rc = float(log_odds[rc, np.arange(L)].sum())
            if score_rc >= threshold:
                hits += 1
    return hits


def scan_all_peaks(
    sequences_df: pd.DataFrame,
    pwms_prob: Dict[str, np.ndarray],
    threshold: float = 6.0,
    background: np.ndarray | None = None,
) -> pd.DataFrame:
    """Build a peak x TF matrix of motif hit counts.

    Each ``pwms_prob`` value is a 4xL probability matrix. Hits use
    log-odds >= ``threshold`` on either strand.
    """
    log_odds_dict = {tf: pwm_log_odds(mat, background) for tf, mat in pwms_prob.items()}
    out = {tf: [] for tf in pwms_prob}
    for seq in sequences_df["sequence"].astype(str).values:
        for tf, lo in log_odds_dict.items():
            out[tf].append(scan_sequence(seq, lo, threshold))
    return pd.DataFrame(out, index=sequences_df["peak_id"].values)


def binarize_hits(hit_matrix: pd.DataFrame, min_hits: int = 1) -> pd.DataFrame:
    """Convert a hit-count matrix to a 0/1 presence matrix."""
    return (hit_matrix >= int(min_hits)).astype(int)


def motif_enrichment(
    binary_hits: pd.DataFrame,
    target_peak_ids: List[str],
    background_peak_ids: List[str],
) -> pd.DataFrame:
    """Two-sided Fisher's exact enrichment per TF on target vs background.

    Returns DataFrame indexed by TF with columns
    ``target_with_motif, target_total, bg_with_motif, bg_total, odds_ratio,
    pvalue, padj``.
    """
    target_peak_ids = set(target_peak_ids)
    background_peak_ids = set(background_peak_ids) - target_peak_ids
    tgt = binary_hits.loc[binary_hits.index.intersection(target_peak_ids)]
    bg = binary_hits.loc[binary_hits.index.intersection(background_peak_ids)]
    rows = []
    for tf in binary_hits.columns:
        a = int(tgt[tf].sum())
        b = int(len(tgt) - a)
        c = int(bg[tf].sum())
        d = int(len(bg) - c)
        # add pseudocount only for OR
        odds = ((a + 0.5) / (b + 0.5)) / ((c + 0.5) / (d + 0.5))
        p = fishers_exact_2x2(a, b, c, d)
        rows.append({
            "tf": tf,
            "target_with_motif": a,
            "target_total": a + b,
            "bg_with_motif": c,
            "bg_total": c + d,
            "odds_ratio": float(odds),
            "pvalue": float(p),
        })
    df = pd.DataFrame(rows).set_index("tf")
    df["padj"] = bh_correct(df["pvalue"].values)
    df["neg_log10_p"] = -np.log10(df["pvalue"].clip(lower=1e-300))
    return df.sort_values("pvalue")

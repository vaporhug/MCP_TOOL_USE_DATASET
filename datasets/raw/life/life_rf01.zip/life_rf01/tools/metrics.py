"""Structural-accuracy metrics for predicted vs reference RNA secondary structures.

All functions take pair sets or dot-bracket strings and return the standard
pair-level confusion-matrix derived metrics:

  * sensitivity (TPR)            = TP / (TP + FN)
  * positive predictive value    = TP / (TP + FP)
  * F1 (harmonic mean of TPR/PPV)
  * Matthews correlation         (with TN approximated as in Lorenz et al. 2011)

All metrics treat (i, j) as the unordered pair, so reciprocal pairs are not
double-counted.
"""

from __future__ import annotations

import math
from typing import Dict, Iterable, List, Sequence, Set, Tuple


def _to_set(pairs: Iterable[Tuple[int, int]]) -> Set[Tuple[int, int]]:
    out: Set[Tuple[int, int]] = set()
    for a, b in pairs:
        i, j = (a, b) if a < b else (b, a)
        out.add((i, j))
    return out


def confusion_counts(
    pred_pairs: Iterable[Tuple[int, int]],
    ref_pairs: Iterable[Tuple[int, int]],
    seq_length: int,
) -> Dict[str, int]:
    """Compute TP, FP, FN, TN counts at base-pair level.

    TN is approximated as ``n*(n-1)/2 - TP - FP - FN`` (upper bound on true
    negatives, following Lorenz et al. 2011).

    Args:
        pred_pairs: predicted pairs.
        ref_pairs: reference pairs.
        seq_length: sequence length n.

    Returns:
        Dict with keys ``TP, FP, FN, TN``.
    """
    P = _to_set(pred_pairs)
    R = _to_set(ref_pairs)
    tp = len(P & R)
    fp = len(P - R)
    fn = len(R - P)
    n = seq_length
    total_possible = n * (n - 1) // 2
    tn = max(0, total_possible - tp - fp - fn)
    return {"TP": tp, "FP": fp, "FN": fn, "TN": tn}


def sensitivity(
    pred_pairs: Iterable[Tuple[int, int]], ref_pairs: Iterable[Tuple[int, int]]
) -> float:
    """Sensitivity (recall, TPR): TP / (TP + FN)."""
    P = _to_set(pred_pairs)
    R = _to_set(ref_pairs)
    tp = len(P & R)
    fn = len(R - P)
    return tp / (tp + fn) if (tp + fn) > 0 else 0.0


def positive_predictive_value(
    pred_pairs: Iterable[Tuple[int, int]], ref_pairs: Iterable[Tuple[int, int]]
) -> float:
    """Positive predictive value (precision, PPV): TP / (TP + FP)."""
    P = _to_set(pred_pairs)
    R = _to_set(ref_pairs)
    tp = len(P & R)
    fp = len(P - R)
    return tp / (tp + fp) if (tp + fp) > 0 else 0.0


def f1_score(
    pred_pairs: Iterable[Tuple[int, int]], ref_pairs: Iterable[Tuple[int, int]]
) -> float:
    """F1 = 2 * PPV * TPR / (PPV + TPR)."""
    s = sensitivity(pred_pairs, ref_pairs)
    p = positive_predictive_value(pred_pairs, ref_pairs)
    if s + p == 0:
        return 0.0
    return 2 * s * p / (s + p)


def matthews_correlation(
    pred_pairs: Iterable[Tuple[int, int]],
    ref_pairs: Iterable[Tuple[int, int]],
    seq_length: int,
) -> float:
    """Matthews correlation coefficient with TN as in Lorenz et al. 2011."""
    cc = confusion_counts(pred_pairs, ref_pairs, seq_length)
    tp = cc["TP"]
    fp = cc["FP"]
    fn = cc["FN"]
    tn = cc["TN"]
    denom = math.sqrt(
        (tp + fp) * (tp + fn) * (tn + fp) * (tn + fn)
    ) or 1.0
    return (tp * tn - fp * fn) / denom


def per_record_metrics(
    pred: Dict[str, str],
    ref: Dict[str, str],
) -> "Dict[str, Dict[str, float]]":
    """Compute (sensitivity, PPV, F1, MCC) for every record.

    Both ``pred`` and ``ref`` map ``record_id -> dot_bracket_string``.

    Args:
        pred: predicted dot-brackets, keyed by record_id.
        ref:  reference dot-brackets, keyed by record_id.

    Returns:
        Mapping ``record_id -> {tpr, ppv, f1, mcc, length, n_ref, n_pred, tp, fp, fn}``.
    """
    from .structure_ops import dot_bracket_to_pairs  # local import avoids cycle

    out: Dict[str, Dict[str, float]] = {}
    for rid, db in pred.items():
        if rid not in ref:
            continue
        ref_db = ref[rid]
        pp = dot_bracket_to_pairs(db)
        rp = dot_bracket_to_pairs(ref_db)
        cc = confusion_counts(pp, rp, len(ref_db))
        out[rid] = {
            "tpr": sensitivity(pp, rp),
            "ppv": positive_predictive_value(pp, rp),
            "f1": f1_score(pp, rp),
            "mcc": matthews_correlation(pp, rp, len(ref_db)),
            "length": len(ref_db),
            "n_ref": len(rp),
            "n_pred": len(pp),
            "tp": cc["TP"],
            "fp": cc["FP"],
            "fn": cc["FN"],
        }
    return out


def aggregate_metrics(per_record: "Dict[str, Dict[str, float]]") -> Dict[str, float]:
    """Take a mean over the per-record metrics returned by ``per_record_metrics``.

    Args:
        per_record: output of :func:`per_record_metrics`.

    Returns:
        ``{tpr, ppv, f1, mcc, n_records, n_pred_total, n_ref_total}``.
    """
    if not per_record:
        return {"tpr": 0.0, "ppv": 0.0, "f1": 0.0, "mcc": 0.0, "n_records": 0}
    n = len(per_record)
    tprs = [v["tpr"] for v in per_record.values()]
    ppvs = [v["ppv"] for v in per_record.values()]
    f1s = [v["f1"] for v in per_record.values()]
    mccs = [v["mcc"] for v in per_record.values()]
    return {
        "tpr": sum(tprs) / n,
        "ppv": sum(ppvs) / n,
        "f1": sum(f1s) / n,
        "mcc": sum(mccs) / n,
        "n_records": n,
        "n_pred_total": int(sum(v["n_pred"] for v in per_record.values())),
        "n_ref_total": int(sum(v["n_ref"] for v in per_record.values())),
    }

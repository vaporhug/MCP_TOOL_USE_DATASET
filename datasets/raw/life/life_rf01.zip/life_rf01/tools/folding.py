"""From-scratch dynamic programming RNA folding primitives.

Two algorithms are implemented here, both written in pure NumPy / Python with
no calls to ViennaRNA, RNAstructure or any other external library:

* ``nussinov_mfe`` – classical Nussinov maximum-base-pair DP, with a per-pair
  scoring scheme that gives 3 to G-C, 2 to A-U and 1 to G-U (a common
  pedagogical extension that breaks ties against Watson-Crick pairs).

* ``simple_partition_function`` – an O(n^3) McCaskill-style partition function
  using the same per-pair Boltzmann weight ``exp(-energy / RT)``.  Returns the
  full partition function ``Z`` and the matrix of base-pair probabilities
  ``P[i,j]``.

Both algorithms enforce the standard hairpin-loop minimum of 3 unpaired bases
between paired positions.  Sharp-loop / coaxial-stacking corrections are
deliberately omitted so the implementation is small, transparent and
unambiguous in its outputs.
"""

from __future__ import annotations

import math
from typing import Dict, List, Tuple

import numpy as np


_PAIR_SCORE = {
    frozenset(("G", "C")): 3.0,
    frozenset(("A", "U")): 2.0,
    frozenset(("G", "U")): 1.0,
}


def pair_score(b1: str, b2: str, gu: bool = True) -> float:
    """Return the Nussinov-style integer score for a base pair.

    Args:
        b1: first base.
        b2: second base.
        gu: if False, G-U pairs get score 0 (forbidden).

    Returns:
        3.0 for G-C, 2.0 for A-U, 1.0 for G-U (if allowed), else 0.0.
    """
    s = frozenset((b1.upper(), b2.upper()))
    if s == frozenset(("G", "U")) and not gu:
        return 0.0
    return _PAIR_SCORE.get(s, 0.0)


def nussinov_mfe(
    seq: str, min_loop: int = 3, allow_gu: bool = True
) -> Tuple[float, List[Tuple[int, int]]]:
    """Compute the maximum-pair Nussinov structure of an RNA sequence.

    Pure NumPy implementation. O(n^3) time, O(n^2) space.

    Args:
        seq: RNA sequence (A/C/G/U, may contain N which never pairs).
        min_loop: minimum number of unpaired bases between (i, j); default 3.
        allow_gu: include G-U as a valid pair with score 1.

    Returns:
        Tuple ``(score, pairs)`` where ``pairs`` is the list of (i, j) base
        pairs achieving the maximum score, sorted by i.
    """
    n = len(seq)
    if n < min_loop + 2:
        return 0.0, []
    M = np.zeros((n, n), dtype=float)
    # M[i,j] = max pairs in seq[i..j]
    # Fill in increasing j-i
    for d in range(min_loop + 1, n):
        for i in range(0, n - d):
            j = i + d
            best = M[i + 1, j]
            if M[i, j - 1] > best:
                best = M[i, j - 1]
            ps = pair_score(seq[i], seq[j], gu=allow_gu)
            if ps > 0 and (j - i - 1) >= min_loop:
                cand = M[i + 1, j - 1] + ps
                if cand > best:
                    best = cand
            for k in range(i + 1, j):
                cand = M[i, k] + M[k + 1, j]
                if cand > best:
                    best = cand
            M[i, j] = best
    # Trace-back
    pairs: List[Tuple[int, int]] = []

    def _trace(i: int, j: int) -> None:
        if j - i <= min_loop:
            return
        if abs(M[i, j] - M[i + 1, j]) < 1e-9:
            _trace(i + 1, j)
            return
        if abs(M[i, j] - M[i, j - 1]) < 1e-9:
            _trace(i, j - 1)
            return
        ps = pair_score(seq[i], seq[j], gu=allow_gu)
        if ps > 0 and abs(M[i, j] - (M[i + 1, j - 1] + ps)) < 1e-9:
            pairs.append((i, j))
            _trace(i + 1, j - 1)
            return
        for k in range(i + 1, j):
            if abs(M[i, j] - (M[i, k] + M[k + 1, j])) < 1e-9:
                _trace(i, k)
                _trace(k + 1, j)
                return

    _trace(0, n - 1)
    pairs.sort()
    return float(M[0, n - 1]), pairs


def simple_partition_function(
    seq: str,
    min_loop: int = 3,
    allow_gu: bool = True,
    rt: float = 1.0,
) -> Dict[str, np.ndarray]:
    """Compute a McCaskill-style partition function on the Nussinov scoring.

    The Boltzmann weight of a single pair is ``exp(score / rt)``. This is a
    pedagogical, single-loop simplification – it does not implement the Turner
    nearest-neighbour energy model. The output base-pair probability matrix
    ``P`` is symmetric.

    Args:
        seq: RNA sequence.
        min_loop: minimum unpaired bases between i and j.
        allow_gu: count G-U as a valid pair.
        rt: thermal scale factor ``RT``; smaller values sharpen probabilities.

    Returns:
        Dict with keys:
          * ``Z``  – full partition function over all pseudoknot-free structures.
          * ``Q``  – n x n matrix, forward partition functions Q[i,j].
          * ``P``  – n x n base-pair probability matrix.
    """
    n = len(seq)
    Q = np.ones((n, n), dtype=float)  # empty interval -> partition function 1
    if n == 0:
        return {"Z": 1.0, "Q": Q, "P": np.zeros((0, 0))}
    bp = np.zeros((n, n), dtype=float)
    for i in range(n):
        for j in range(i + 1):
            Q[i, j] = 1.0
    for i in range(n - 1, -1, -1):
        for j in range(i, n):
            if j - i <= min_loop:
                Q[i, j] = 1.0
                continue
            # Either j is unpaired
            total = Q[i, j - 1]
            # or j pairs to some k in [i, j - min_loop - 1]
            for k in range(i, j - min_loop):
                ps = pair_score(seq[k], seq[j], gu=allow_gu)
                if ps <= 0:
                    continue
                w = math.exp(ps / rt)
                left = Q[i, k - 1] if k > i else 1.0
                inner = Q[k + 1, j - 1] if (k + 1 <= j - 1) else 1.0
                total += left * w * inner
            Q[i, j] = total
    Z = float(Q[0, n - 1])
    # Outside / pair probabilities
    Qhat = np.zeros((n, n), dtype=float)
    # Qhat[i,j] = partition function of seq[0..i-1] + seq[j+1..n-1]
    # We compute base-pair probabilities by enumerating pairs (k,l):
    P = np.zeros((n, n), dtype=float)
    for k in range(n):
        for l in range(k + min_loop + 1, n):
            ps = pair_score(seq[k], seq[l], gu=allow_gu)
            if ps <= 0:
                continue
            w = math.exp(ps / rt)
            inner = Q[k + 1, l - 1] if (k + 1 <= l - 1) else 1.0
            left = Q[0, k - 1] if k > 0 else 1.0
            right = Q[l + 1, n - 1] if l + 1 < n else 1.0
            P[k, l] = (left * w * inner * right) / max(Z, 1e-300)
            P[l, k] = P[k, l]
    return {"Z": Z, "Q": Q, "P": P}


def mfe_score_from_pairs(seq: str, pairs, allow_gu: bool = True) -> float:
    """Re-evaluate the Nussinov score of a given pair set.

    Args:
        seq: RNA sequence.
        pairs: iterable of (i, j) pairs.
        allow_gu: include G-U pairs.

    Returns:
        Sum of per-pair scores.
    """
    return float(sum(pair_score(seq[i], seq[j], gu=allow_gu) for i, j in pairs))

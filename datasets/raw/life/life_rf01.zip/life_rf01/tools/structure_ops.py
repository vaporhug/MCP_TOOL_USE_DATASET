"""Low-level secondary-structure manipulation primitives.

Pure-Python conversions between the three standard representations:
    * dot-bracket string (Vienna/WUSS-flat),
    * pair list ``[(i, j), ...]`` with i < j (0-based),
    * pair table ``pt[i] = j`` if i pairs to j else ``-1``.
No DP, no thermodynamics, no metrics here.
"""

from __future__ import annotations

from typing import Dict, List, Sequence, Set, Tuple

import numpy as np

OPEN_CHARS = {"(": ")", "[": "]", "{": "}", "<": ">"}
CLOSE_CHARS = {v: k for k, v in OPEN_CHARS.items()}


def dot_bracket_to_pairs(db: str) -> List[Tuple[int, int]]:
    """Convert a dot-bracket string to a sorted list of (i, j) base pairs.

    Supports nested brackets (), [], {}, <>. Non-bracket characters are unpaired.

    Args:
        db: dot-bracket string.

    Returns:
        Sorted list of (i, j) tuples with i < j (0-based).
    """
    stacks: Dict[str, List[int]] = {c: [] for c in OPEN_CHARS}
    pairs: List[Tuple[int, int]] = []
    for i, c in enumerate(db):
        if c in OPEN_CHARS:
            stacks[c].append(i)
        elif c in CLOSE_CHARS:
            opener = CLOSE_CHARS[c]
            if not stacks[opener]:
                raise ValueError(f"Unmatched '{c}' at position {i} in {db!r}")
            j = stacks[opener].pop()
            pairs.append((j, i))
    for opener, st in stacks.items():
        if st:
            raise ValueError(f"Unmatched '{opener}' in {db!r}")
    pairs.sort()
    return pairs


def pairs_to_dot_bracket(pairs: Sequence[Tuple[int, int]], length: int) -> str:
    """Convert a list of base pairs to a dot-bracket string of length ``length``.

    Pseudoknotted pairs (cross any earlier pair) are written using ``[]`` then
    ``{}`` then ``<>`` brackets. If more than four nesting levels are needed, an
    error is raised.

    Args:
        pairs: list of (i, j) tuples, i < j, 0-based, sorted by i.
        length: total sequence length.

    Returns:
        Dot-bracket string.
    """
    if length <= 0:
        return ""
    out = ["."] * length
    layers = ["()", "[]", "{}", "<>"]
    placed: List[List[Tuple[int, int]]] = [[] for _ in layers]
    for i, j in sorted(pairs):
        if i < 0 or j >= length or i >= j:
            raise ValueError(f"Invalid pair ({i},{j}) for length {length}")
        chosen = None
        for li, lpairs in enumerate(placed):
            ok = True
            for ii, jj in lpairs:
                # crosses?
                if (ii < i < jj < j) or (i < ii < j < jj):
                    ok = False
                    break
            if ok:
                chosen = li
                break
        if chosen is None:
            raise ValueError("More than 4 nesting layers required")
        placed[chosen].append((i, j))
        out[i] = layers[chosen][0]
        out[j] = layers[chosen][1]
    return "".join(out)


def pairs_to_pair_table(pairs: Sequence[Tuple[int, int]], length: int) -> np.ndarray:
    """Build the pair table ``pt[i] = j`` (or -1 if i is unpaired).

    Args:
        pairs: list of (i, j) tuples, i < j.
        length: sequence length.

    Returns:
        np.ndarray of shape (length,) with int dtype.
    """
    pt = -np.ones(length, dtype=np.int64)
    for i, j in pairs:
        pt[i] = j
        pt[j] = i
    return pt


def pair_table_to_pairs(pt: np.ndarray) -> List[Tuple[int, int]]:
    """Inverse of :func:`pairs_to_pair_table`.

    Args:
        pt: int array, ``pt[i] = j`` means i pairs to j.

    Returns:
        Sorted list of (i, j) tuples with i < j.
    """
    pairs = []
    n = len(pt)
    for i in range(n):
        j = int(pt[i])
        if j > i:
            pairs.append((i, j))
    pairs.sort()
    return pairs


def is_canonical_pair(b1: str, b2: str, allow_gu: bool = True) -> bool:
    """Return True if (b1, b2) form a canonical Watson-Crick or wobble base pair.

    Args:
        b1: first base ('A','C','G','U').
        b2: second base.
        allow_gu: include G-U wobble as canonical.

    Returns:
        True if pairing is canonical.
    """
    s = {b1.upper(), b2.upper()}
    if s == {"A", "U"} or s == {"G", "C"}:
        return True
    if allow_gu and s == {"G", "U"}:
        return True
    return False


def detect_pseudoknots(pairs: Sequence[Tuple[int, int]]) -> List[Tuple[int, int]]:
    """Return the subset of pairs that form pseudoknots (cross another pair).

    A pair (i, j) is pseudoknotted if there exists another pair (k, l) with
    i < k < j < l. This is the standard "crossing" definition.

    Args:
        pairs: list of base pairs (i, j) with i < j.

    Returns:
        List of crossing pairs (i, j).
    """
    pairs = sorted(pairs)
    crossing: Set[Tuple[int, int]] = set()
    for a in range(len(pairs)):
        ia, ja = pairs[a]
        for b in range(a + 1, len(pairs)):
            ib, jb = pairs[b]
            if ia < ib < ja < jb:
                crossing.add((ia, ja))
                crossing.add((ib, jb))
    return sorted(crossing)


def remove_pseudoknots(
    pairs: Sequence[Tuple[int, int]],
) -> List[Tuple[int, int]]:
    """Remove the smallest set of pairs needed to make the structure pseudoknot-free.

    Greedy heuristic: while any pair crosses another, remove the pair with the
    most crossings; ties broken by largest span.

    Args:
        pairs: list of base pairs.

    Returns:
        Pseudoknot-free subset of pairs.
    """
    cur = list(pairs)
    while True:
        cross_count = {p: 0 for p in cur}
        crossing_found = False
        for a in range(len(cur)):
            ia, ja = cur[a]
            for b in range(a + 1, len(cur)):
                ib, jb = cur[b]
                if ia < ib < ja < jb:
                    cross_count[cur[a]] += 1
                    cross_count[cur[b]] += 1
                    crossing_found = True
        if not crossing_found:
            return sorted(cur)
        # remove worst
        worst = max(cur, key=lambda p: (cross_count[p], p[1] - p[0]))
        cur.remove(worst)


def n_base_pairs(db: str) -> int:
    """Count the number of canonical-bracket base pairs in a dot-bracket string.

    Args:
        db: dot-bracket string.

    Returns:
        Number of pairs (each (i,j) counted once).
    """
    return len(dot_bracket_to_pairs(db))

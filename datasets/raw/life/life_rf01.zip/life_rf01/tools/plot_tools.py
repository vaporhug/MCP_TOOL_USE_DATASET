"""Plotting utilities for the RNA secondary structure benchmark.

Every function returns ``{"path": "<absolute path to PNG>"}``.  The
matplotlib ``Agg`` backend is used so the tools render in headless contexts.
"""

from __future__ import annotations

import os
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def _save(fig: plt.Figure, path: str) -> Dict[str, str]:
    out = os.path.abspath(path)
    os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
    fig.tight_layout()
    fig.savefig(out, dpi=140, bbox_inches="tight")
    plt.close(fig)
    return {"path": out}


def plot_basepair_dotplot(
    P: np.ndarray,
    seq: str,
    out_path: str,
    title: Optional[str] = None,
) -> Dict[str, str]:
    """Triangular dot-plot of the base-pair probability matrix ``P``.

    The upper triangle is shaded by ``-log10`` probability, with darker dots
    indicating higher probability of base pairing. Diagonal is masked.

    Args:
        P: n x n base-pair probability matrix from ``simple_partition_function``.
        seq: RNA sequence (used for axis labels of short sequences).
        out_path: PNG output path.
        title: optional plot title.

    Returns:
        ``{"path": "<absolute path>"}``.
    """
    n = P.shape[0]
    fig, ax = plt.subplots(figsize=(5.5, 5.0))
    M = np.copy(P)
    M[M <= 0] = np.nan
    im = ax.imshow(np.log10(M + 1e-12), cmap="viridis", origin="upper")
    ax.set_title(title or f"Base-pair probabilities (n={n})")
    ax.set_xlabel("position j")
    ax.set_ylabel("position i")
    if n <= 80:
        ax.set_xticks(np.arange(n))
        ax.set_xticklabels(list(seq), fontsize=5)
        ax.set_yticks(np.arange(n))
        ax.set_yticklabels(list(seq), fontsize=5)
    fig.colorbar(im, ax=ax, label="log10 P(i,j)")
    return _save(fig, out_path)


def plot_accuracy_vs_length(
    per_record: "Dict[str, Dict[str, float]]",
    out_path: str,
    metric: str = "f1",
    title: Optional[str] = None,
) -> Dict[str, str]:
    """Scatter of per-record metric value vs sequence length.

    Args:
        per_record: output of ``metrics.per_record_metrics``.
        out_path: PNG output path.
        metric: which metric column to use ('tpr' / 'ppv' / 'f1' / 'mcc').
        title: optional plot title.

    Returns:
        ``{"path": ...}``.
    """
    xs = [v["length"] for v in per_record.values()]
    ys = [v[metric] for v in per_record.values()]
    fig, ax = plt.subplots(figsize=(6.5, 4.4))
    ax.scatter(xs, ys, alpha=0.7, s=24, color="#1f77b4", edgecolor="none")
    if xs:
        # binned mean overlay
        bins = np.array([0, 80, 150, 250, 400, max(xs) + 1])
        centers = []
        means = []
        for lo, hi in zip(bins[:-1], bins[1:]):
            mask = [(lo <= x < hi) for x in xs]
            if any(mask):
                centers.append((lo + hi) / 2.0)
                means.append(np.mean([y for y, m in zip(ys, mask) if m]))
        if centers:
            ax.plot(centers, means, "o-", color="#d62728", lw=2, ms=7, label="binned mean")
            ax.legend(loc="lower left")
    ax.set_xlabel("sequence length (nt)")
    ax.set_ylabel(metric.upper())
    ax.set_ylim(-0.02, 1.02)
    ax.grid(alpha=0.3)
    ax.set_title(title or f"Per-record {metric.upper()} vs sequence length")
    return _save(fig, out_path)


def plot_motif_frequency_bar(
    counts_by_family: "Dict[str, Dict[str, int]]",
    out_path: str,
    title: Optional[str] = None,
) -> Dict[str, str]:
    """Stacked bar plot of motif counts per RNA family.

    Args:
        counts_by_family: ``{family: {hairpin, internal, bulge, multi, ...}}``.
        out_path: PNG output path.
        title: optional plot title.

    Returns:
        ``{"path": ...}``.
    """
    labels = list(counts_by_family.keys())
    motifs = ["hairpin", "internal", "bulge", "multi"]
    colors = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728"]
    data = np.array(
        [[counts_by_family[fam].get(m, 0) for fam in labels] for m in motifs],
        dtype=float,
    )
    fig, ax = plt.subplots(figsize=(max(6, 0.45 * len(labels)), 4.4))
    bottom = np.zeros(len(labels))
    for arr, lbl, c in zip(data, motifs, colors):
        ax.bar(labels, arr, bottom=bottom, label=lbl, color=c, edgecolor="white", linewidth=0.4)
        bottom += arr
    ax.set_xticklabels(labels, rotation=45, ha="right", fontsize=8)
    ax.set_ylabel("loop count (summed over family)")
    ax.set_title(title or "Loop motifs per RNA family")
    ax.legend(loc="upper right", fontsize=8)
    return _save(fig, out_path)


def plot_f1_distribution(
    per_record: "Dict[str, Dict[str, float]]",
    out_path: str,
    metric: str = "f1",
    title: Optional[str] = None,
) -> Dict[str, str]:
    """Cumulative distribution of a per-record metric (Lorenz et al. Fig 2A style).

    Args:
        per_record: output of ``metrics.per_record_metrics``.
        out_path: PNG output path.
        metric: which metric column to plot.
        title: optional title.

    Returns:
        ``{"path": ...}``.
    """
    vals = sorted([v[metric] for v in per_record.values()])
    n = len(vals)
    if n == 0:
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, "No data", ha="center")
        return _save(fig, out_path)
    cum = np.arange(1, n + 1)
    fig, ax = plt.subplots(figsize=(6.0, 4.0))
    ax.plot(cum, vals, lw=2.0, color="#1f77b4")
    ax.set_xlabel("prediction rank (sorted)")
    ax.set_ylabel(metric.upper())
    ax.set_ylim(-0.02, 1.02)
    ax.grid(alpha=0.3)
    ax.axhline(np.mean(vals), color="#d62728", ls="--", label=f"mean = {np.mean(vals):.3f}")
    ax.legend(loc="lower right")
    ax.set_title(title or f"Cumulative {metric.upper()} distribution (Lorenz Fig 2A style)")
    return _save(fig, out_path)


def plot_metric_per_family(
    per_record: "Dict[str, Dict[str, float]]",
    record_to_family: "Dict[str, str]",
    out_path: str,
    metric: str = "f1",
    title: Optional[str] = None,
) -> Dict[str, str]:
    """Box plot of a per-record metric grouped by RNA family.

    Args:
        per_record: output of ``metrics.per_record_metrics``.
        record_to_family: ``{record_id: family_name}``.
        out_path: PNG output path.
        metric: which metric to box.
        title: optional title.

    Returns:
        ``{"path": ...}``.
    """
    by_fam: Dict[str, List[float]] = {}
    for rid, m in per_record.items():
        fam = record_to_family.get(rid)
        if fam is None:
            continue
        by_fam.setdefault(fam, []).append(m[metric])
    fams = sorted(by_fam.keys(), key=lambda f: -np.median(by_fam[f]))
    data = [by_fam[f] for f in fams]
    fig, ax = plt.subplots(figsize=(max(6, 0.45 * len(fams)), 4.4))
    ax.boxplot(data, labels=fams, showmeans=True)
    ax.set_xticklabels(fams, rotation=45, ha="right", fontsize=8)
    ax.set_ylabel(metric.upper())
    ax.set_ylim(-0.02, 1.02)
    ax.set_title(title or f"{metric.upper()} per RNA family")
    ax.grid(alpha=0.3, axis="y")
    return _save(fig, out_path)

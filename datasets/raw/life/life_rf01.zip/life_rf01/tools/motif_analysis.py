"""Structural-element classifiers for an RNA secondary structure.

Given a (pseudoknot-free) pair table, identify and count the four canonical
motif classes:

* hairpin loop  — a single loop closed by a single base pair, no inner pair.
* internal loop — a loop closed by an outer pair containing exactly one
  inner pair (bulges count as internal loops with one side of zero length).
* bulge loop    — special case of internal loop where exactly one strand is
  unpaired.
* multi-branch  — a loop closed by one outer pair containing two or more
  inner pairs.

Each function works on the pair table representation built in
``structure_ops.pairs_to_pair_table``.
"""

from __future__ import annotations

from typing import Dict, List, Sequence, Tuple

import numpy as np


def _children_of(pt: np.ndarray, i: int, j: int) -> List[Tuple[int, int]]:
    """Return the immediate enclosed pairs (k, l) such that i < k < l < j and
    no other pair (a, b) with a in (i, k) and l in (a, b)."""
    children: List[Tuple[int, int]] = []
    k = i + 1
    while k < j:
        l = int(pt[k])
        if l > k:
            children.append((k, l))
            k = l + 1
        else:
            k += 1
    return children


def classify_loops(pairs: Sequence[Tuple[int, int]], seq_length: int) -> List[Dict[str, object]]:
    """Walk the pair tree and label every loop.

    Args:
        pairs: list of (i, j) pairs (pseudoknot-free).
        seq_length: total sequence length.

    Returns:
        One dict per loop with keys:
          * ``type``  – 'hairpin' | 'internal' | 'bulge' | 'multi' | 'external'.
          * ``closing`` – (i, j) of the closing pair (or None for external).
          * ``children`` – list of enclosed (k, l) pairs.
          * ``unpaired_left``, ``unpaired_right`` – for internal/bulge loops.
          * ``unpaired_total`` – total unpaired bases inside the loop.
    """
    n = seq_length
    from .structure_ops import pairs_to_pair_table

    pt = pairs_to_pair_table(pairs, n)
    loops: List[Dict[str, object]] = []

    # External loop is everything not contained in any pair
    external_children = []
    k = 0
    while k < n:
        l = int(pt[k])
        if l > k:
            external_children.append((k, l))
            k = l + 1
        else:
            k += 1
    if external_children or n > 0:
        loops.append(
            {
                "type": "external",
                "closing": None,
                "children": external_children,
                "unpaired_total": n - sum(l - k + 1 for k, l in external_children),
                "unpaired_left": 0,
                "unpaired_right": 0,
            }
        )

    # For each pair, classify the loop closed by that pair
    for i, j in pairs:
        children = _children_of(pt, i, j)
        unpaired = (j - i - 1) - sum(l - k + 1 for k, l in children)
        if not children:
            t = "hairpin"
            ul = 0
            ur = 0
        elif len(children) == 1:
            k, l = children[0]
            ul = k - i - 1
            ur = j - l - 1
            if ul == 0 and ur == 0:
                # immediately stacked – not a loop, just a base pair
                t = "stack"
            elif ul == 0 or ur == 0:
                t = "bulge"
            else:
                t = "internal"
        else:
            t = "multi"
            ul = 0
            ur = 0
        loops.append(
            {
                "type": t,
                "closing": (i, j),
                "children": children,
                "unpaired_total": unpaired,
                "unpaired_left": ul,
                "unpaired_right": ur,
            }
        )
    return loops


def count_motifs(pairs: Sequence[Tuple[int, int]], seq_length: int) -> Dict[str, int]:
    """Count hairpin / internal / bulge / multi-branch loops.

    The external loop is not counted in any of the four categories.

    Args:
        pairs: list of base pairs.
        seq_length: sequence length.

    Returns:
        Dict with keys ``hairpin, internal, bulge, multi, helices, n_pairs``.
        ``helices`` is the number of maximal stems of consecutive base pairs.
    """
    loops = classify_loops(pairs, seq_length)
    counts = {"hairpin": 0, "internal": 0, "bulge": 0, "multi": 0}
    for lp in loops:
        if lp["type"] in counts:
            counts[lp["type"]] += 1
    counts["helices"] = count_helices(pairs)
    counts["n_pairs"] = len(list(pairs))
    return counts


def count_helices(pairs: Sequence[Tuple[int, int]]) -> int:
    """Count the number of maximal stems (consecutive stacked base pairs).

    A stem is a run of pairs (i, j), (i+1, j-1), ... — adjacent on both sides.

    Args:
        pairs: list of base pairs.

    Returns:
        Number of distinct stems.
    """
    pset = set((min(a, b), max(a, b)) for a, b in pairs)
    visited: set = set()
    n_stems = 0
    for i, j in sorted(pset):
        if (i, j) in visited:
            continue
        # walk down stem
        a, b = i, j
        while (a, b) in pset:
            visited.add((a, b))
            a += 1
            b -= 1
        n_stems += 1
    return n_stems


def loop_size_distribution(
    pairs: Sequence[Tuple[int, int]], seq_length: int
) -> Dict[str, List[int]]:
    """Return a dict from motif type to list of unpaired-base counts.

    Args:
        pairs: list of base pairs.
        seq_length: sequence length.

    Returns:
        ``{'hairpin': [...], 'internal': [...], 'bulge': [...], 'multi': [...]}``.
    """
    out: Dict[str, List[int]] = {"hairpin": [], "internal": [], "bulge": [], "multi": []}
    for lp in classify_loops(pairs, seq_length):
        if lp["type"] in out:
            out[lp["type"]].append(int(lp["unpaired_total"]))
    return out


def helix_length_distribution(pairs: Sequence[Tuple[int, int]]) -> List[int]:
    """Return the length (in bp) of every maximal stem.

    Args:
        pairs: list of base pairs.

    Returns:
        List of integer stem lengths.
    """
    pset = set((min(a, b), max(a, b)) for a, b in pairs)
    visited: set = set()
    out: List[int] = []
    for i, j in sorted(pset):
        if (i, j) in visited:
            continue
        a, b = i, j
        n_bp = 0
        while (a, b) in pset:
            visited.add((a, b))
            a += 1
            b -= 1
            n_bp += 1
        out.append(n_bp)
    return out

"""I/O helpers for the RNA secondary structure benchmark task.

Each function parses one of the shipped input files into plain Python /
NumPy / pandas objects. No domain logic (Nussinov DP, partition function,
metric calculation) is performed here.
"""

from __future__ import annotations

import os
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd


def load_fasta(path: str) -> Dict[str, str]:
    """Read a FASTA file and return ``{record_id: sequence}``.

    The record_id is the text after ``>`` up to the first whitespace.
    Sequences are returned as upper-case RNA (T->U substituted).

    Args:
        path: path to a FASTA file.

    Returns:
        Mapping ``{record_id: rna_sequence}``.
    """
    records: Dict[str, List[str]] = {}
    cur_id = None
    with open(path) as f:
        for line in f:
            line = line.rstrip("\n")
            if not line:
                continue
            if line.startswith(">"):
                cur_id = line[1:].split()[0]
                records[cur_id] = []
            else:
                if cur_id is None:
                    raise ValueError(f"FASTA at {path} does not start with >")
                records[cur_id].append(line.strip())
    return {rid: "".join(parts).upper().replace("T", "U") for rid, parts in records.items()}


def load_dot_bracket(path: str) -> Dict[str, Tuple[str, str]]:
    """Read a 3-line per-record dot-bracket file.

    The file format alternates ``>id``, sequence, dot-bracket lines.
    Brackets recognised: ``(`` and ``)``; everything else is treated as unpaired.

    Args:
        path: path to a .dbn file.

    Returns:
        ``{record_id: (sequence, dot_bracket_string)}``.
    """
    out: Dict[str, Tuple[str, str]] = {}
    with open(path) as f:
        lines = [ln.rstrip("\n") for ln in f if ln.strip()]
    i = 0
    while i + 2 < len(lines) + 1:
        if i >= len(lines) or not lines[i].startswith(">"):
            i += 1
            continue
        rid = lines[i][1:].split()[0]
        seq = lines[i + 1].upper().replace("T", "U")
        db = lines[i + 2]
        if len(seq) != len(db):
            raise ValueError(
                f"Sequence/structure length mismatch for {rid}: {len(seq)} vs {len(db)}"
            )
        out[rid] = (seq, db)
        i += 3
    return out


def load_metadata(path: str) -> pd.DataFrame:
    """Load the per-record metadata CSV.

    Required columns:
      record_id, family_acc, family_name, category, length, n_basepairs, gc_fraction.

    Args:
        path: path to ``rfam_seed_rnas.metadata.csv``.

    Returns:
        DataFrame indexed by record_id.
    """
    df = pd.read_csv(path)
    required = {
        "record_id",
        "family_acc",
        "family_name",
        "category",
        "length",
        "n_basepairs",
        "gc_fraction",
    }
    missing = required.difference(df.columns)
    if missing:
        raise ValueError(f"metadata is missing columns: {sorted(missing)}")
    return df.set_index("record_id", drop=False)


def write_dot_bracket(records: Dict[str, Tuple[str, str]], path: str) -> str:
    """Write a list of (sequence, dot-bracket) records back to a .dbn file.

    Args:
        records: mapping ``{record_id: (sequence, dot_bracket)}``.
        path: output file path.

    Returns:
        The absolute path written.
    """
    os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
    with open(path, "w") as f:
        for rid, (seq, db) in records.items():
            f.write(f">{rid}\n{seq}\n{db}\n")
    return os.path.abspath(path)


def filter_records_by_length(
    records: Dict[str, Tuple[str, str]], min_len: int, max_len: int
) -> Dict[str, Tuple[str, str]]:
    """Return records whose sequence length is within ``[min_len, max_len]``.

    Args:
        records: ``{record_id: (sequence, dot_bracket)}``.
        min_len: inclusive lower bound on length.
        max_len: inclusive upper bound.

    Returns:
        Filtered dict with same shape.
    """
    return {rid: pair for rid, pair in records.items() if min_len <= len(pair[0]) <= max_len}

"""
Generic data processing utilities for loading, transforming, and summarizing tabular data.
"""

import pandas as pd
import numpy as np
from typing import List, Optional, Dict


def load_csv(path: str, **kwargs) -> pd.DataFrame:
    """Load a CSV file into a pandas DataFrame.

    Parameters
    ----------
    path : str
        File path.
    **kwargs
        Passed to pd.read_csv.

    Returns
    -------
    pd.DataFrame
    """
    return pd.read_csv(path, **kwargs)


def load_excel(path: str, sheet_name: Optional[str] = None, **kwargs) -> pd.DataFrame:
    """Load an Excel file into a pandas DataFrame.

    Parameters
    ----------
    path : str
    sheet_name : str or None
    **kwargs

    Returns
    -------
    pd.DataFrame
    """
    return pd.read_excel(path, sheet_name=sheet_name, **kwargs)


def summarize_df(df: pd.DataFrame) -> Dict:
    """Return basic summary statistics of a DataFrame.

    Parameters
    ----------
    df : pd.DataFrame

    Returns
    -------
    dict
        Keys: n_rows, n_cols, columns, dtypes, missing_counts.
    """
    return {
        "n_rows": len(df),
        "n_cols": len(df.columns),
        "columns": list(df.columns),
        "dtypes": {c: str(df[c].dtype) for c in df.columns},
        "missing_counts": {c: int(df[c].isna().sum()) for c in df.columns},
    }


def filter_rows(df: pd.DataFrame, column: str, values: list) -> pd.DataFrame:
    """Filter DataFrame rows where column value is in the given list.

    Parameters
    ----------
    df : pd.DataFrame
    column : str
    values : list

    Returns
    -------
    pd.DataFrame
    """
    return df[df[column].isin(values)].copy()


def merge_dataframes(
    left: pd.DataFrame,
    right: pd.DataFrame,
    on: str,
    how: str = "inner",
) -> pd.DataFrame:
    """Merge two DataFrames.

    Parameters
    ----------
    left, right : pd.DataFrame
    on : str
        Column name to join on.
    how : str
        Join type.

    Returns
    -------
    pd.DataFrame
    """
    return pd.merge(left, right, on=on, how=how)


def numeric_columns(df: pd.DataFrame) -> List[str]:
    """Return list of numeric column names.

    Parameters
    ----------
    df : pd.DataFrame

    Returns
    -------
    list of str
    """
    return list(df.select_dtypes(include=[np.number]).columns)


def describe_column(df: pd.DataFrame, column: str) -> Dict:
    """Descriptive statistics for a single column.

    Parameters
    ----------
    df : pd.DataFrame
    column : str

    Returns
    -------
    dict
    """
    s = pd.to_numeric(df[column], errors="coerce")
    return {
        "mean": float(s.mean()),
        "std": float(s.std()),
        "min": float(s.min()),
        "max": float(s.max()),
        "median": float(s.median()),
        "n_missing": int(s.isna().sum()),
        "n_total": len(s),
    }

"""
Stub module for external database retrieval.
Provides placeholder functions for querying metabolomics databases
(HMDB, KEGG, MetaboAnalyst) in case the agent needs to look up
metabolite identifiers or pathway information.
"""

from typing import Dict, Optional, List


def query_hmdb(metabolite_name: str) -> Dict:
    """Look up a metabolite in the Human Metabolome Database.

    Parameters
    ----------
    metabolite_name : str

    Returns
    -------
    dict
        Keys: hmdb_id, name, formula, description.
        Returns empty dict if not found.
    """
    # Stub: actual implementation would query https://hmdb.ca/
    return {
        "hmdb_id": None,
        "name": metabolite_name,
        "formula": None,
        "description": "Stub: external DB query not available in offline mode.",
    }


def query_kegg_pathway(pathway_name: str) -> Dict:
    """Look up a KEGG pathway.

    Parameters
    ----------
    pathway_name : str

    Returns
    -------
    dict
        Keys: pathway_id, name, compounds, url.
    """
    return {
        "pathway_id": None,
        "name": pathway_name,
        "compounds": [],
        "url": None,
    }


def query_metaboanalyst_enrichment(
    metabolite_list: List[str],
    organism: str = "hsa",
) -> Dict:
    """Stub for MetaboAnalyst pathway enrichment.

    Parameters
    ----------
    metabolite_list : list of str
    organism : str

    Returns
    -------
    dict
    """
    return {
        "status": "stub",
        "message": "Use local pathway_enrichment_summary() with provided enrichment CSV.",
        "n_metabolites": len(metabolite_list),
    }

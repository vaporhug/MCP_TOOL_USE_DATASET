"""
Metabolomics analysis tools for plasma metabolite profiling in cardiovascular disease.
Provides low-level primitives for statistical testing, classification, dimensionality
reduction, pathway enrichment, and visualization of metabolomics data.
"""

import os
import json
import numpy as np
import pandas as pd
from typing import Optional, List, Dict, Tuple, Any


# ---------------------------------------------------------------------------
# 1. Data loading and preprocessing
# ---------------------------------------------------------------------------

def load_metabolomics_csv(path: str) -> pd.DataFrame:
    """Load a CSV file containing metabolomics data and return a DataFrame.

    Parameters
    ----------
    path : str
        Path to CSV file.

    Returns
    -------
    pd.DataFrame
    """
    df = pd.read_csv(path)
    return df


def log_transform_metabolites(
    df: pd.DataFrame,
    metabolite_cols: List[str],
    base: float = 2.0,
    pseudocount: float = 1e-9,
) -> pd.DataFrame:
    """Apply log transformation to specified metabolite columns.

    Parameters
    ----------
    df : pd.DataFrame
        Input dataframe.
    metabolite_cols : list of str
        Column names to transform.
    base : float
        Logarithm base (default 2).
    pseudocount : float
        Small value added before log to avoid log(0).

    Returns
    -------
    pd.DataFrame
        DataFrame with log-transformed columns (original columns replaced).
    """
    out = df.copy()
    for col in metabolite_cols:
        vals = pd.to_numeric(out[col], errors="coerce")
        if base == 2:
            out[col] = np.log2(vals + pseudocount)
        elif base == 10:
            out[col] = np.log10(vals + pseudocount)
        else:
            out[col] = np.log(vals + pseudocount) / np.log(base)
    return out


def zscore_normalize(
    df: pd.DataFrame,
    metabolite_cols: List[str],
) -> pd.DataFrame:
    """Z-score normalize metabolite columns (mean=0, sd=1).

    Parameters
    ----------
    df : pd.DataFrame
    metabolite_cols : list of str

    Returns
    -------
    pd.DataFrame
    """
    out = df.copy()
    for col in metabolite_cols:
        vals = pd.to_numeric(out[col], errors="coerce")
        mu = vals.mean()
        sd = vals.std()
        if sd > 0:
            out[col] = (vals - mu) / sd
        else:
            out[col] = 0.0
    return out


def filter_metabolites_by_missingness(
    df: pd.DataFrame,
    metabolite_cols: List[str],
    max_missing_frac: float = 0.2,
) -> List[str]:
    """Return metabolite column names with missing fraction below threshold.

    Parameters
    ----------
    df : pd.DataFrame
    metabolite_cols : list of str
    max_missing_frac : float

    Returns
    -------
    list of str
        Columns passing the filter.
    """
    kept = []
    for col in metabolite_cols:
        frac = df[col].isna().mean()
        if frac <= max_missing_frac:
            kept.append(col)
    return kept


# ---------------------------------------------------------------------------
# 2. Statistical testing
# ---------------------------------------------------------------------------

def per_metabolite_test(
    df: pd.DataFrame,
    metabolite_cols: List[str],
    group_col: str,
    case_label: str = "case",
    control_label: str = "control",
    method: str = "wilcoxon",
) -> pd.DataFrame:
    """Run per-metabolite two-group test and return p-values, fold changes.

    Parameters
    ----------
    df : pd.DataFrame
    metabolite_cols : list of str
    group_col : str
    case_label, control_label : str
    method : str
        'ttest' for two-sample t-test, 'wilcoxon' for Wilcoxon rank-sum.

    Returns
    -------
    pd.DataFrame
        Columns: Metabolite, log2FC, pvalue, direction.
    """
    from scipy import stats

    cases = df[df[group_col].astype(str).str.lower().str.strip() == case_label.lower()]
    controls = df[df[group_col].astype(str).str.lower().str.strip() == control_label.lower()]

    results = []
    for col in metabolite_cols:
        c = pd.to_numeric(cases[col], errors="coerce").dropna()
        ctrl = pd.to_numeric(controls[col], errors="coerce").dropna()
        if len(c) < 2 or len(ctrl) < 2:
            continue
        fc = c.mean() - ctrl.mean()  # already log-scale or z-score
        if method == "ttest":
            stat, pval = stats.ttest_ind(c, ctrl, equal_var=False)
        else:
            stat, pval = stats.mannwhitneyu(c, ctrl, alternative="two-sided")
        direction = "Increase" if fc > 0 else "Decrease"
        results.append({
            "Metabolite": col,
            "log2FC": fc,
            "pvalue": pval,
            "direction": direction,
        })
    return pd.DataFrame(results)


def fdr_correction(
    pvalues: List[float],
    method: str = "bh",
) -> List[float]:
    """Apply FDR correction (Benjamini-Hochberg) to a list of p-values.

    Parameters
    ----------
    pvalues : list of float
    method : str
        'bh' for Benjamini-Hochberg.

    Returns
    -------
    list of float
        Adjusted p-values (q-values).
    """
    from scipy.stats import false_discovery_control
    try:
        qvals = false_discovery_control(pvalues, method=method)
        return list(qvals)
    except Exception:
        # Fallback manual BH
        n = len(pvalues)
        indexed = sorted(enumerate(pvalues), key=lambda x: x[1])
        qvals = [0.0] * n
        prev = 1.0
        for rank, (idx, p) in enumerate(reversed(indexed)):
            q = min(p * n / (n - rank), prev)
            qvals[idx] = q
            prev = q
        return qvals


def volcano_classify(
    df: pd.DataFrame,
    log2fc_col: str = "log2FC",
    neg_log10_fdr_col: str = "-log10(FDR)",
    fc_threshold: float = 0.0,
    fdr_threshold: float = 0.05,
) -> pd.DataFrame:
    """Classify metabolites in a volcano plot as up/down/stable.

    Parameters
    ----------
    df : pd.DataFrame
        Must have columns for log2 fold change and -log10(FDR).
    log2fc_col : str
    neg_log10_fdr_col : str
    fc_threshold : float
        Minimum absolute log2FC.
    fdr_threshold : float
        FDR threshold (converted to -log10 scale internally).

    Returns
    -------
    pd.DataFrame
        Input df with added 'volcano_class' column.
    """
    out = df.copy()
    neg_log10_thr = -np.log10(fdr_threshold) if fdr_threshold > 0 else 1.3
    classes = []
    for _, row in out.iterrows():
        fc = abs(row[log2fc_col])
        sig = row[neg_log10_fdr_col]
        if fc >= fc_threshold and sig >= neg_log10_thr:
            if row[log2fc_col] > 0:
                classes.append("Increase")
            else:
                classes.append("Decrease")
        else:
            classes.append("Stable")
    out["volcano_class"] = classes
    return out


# ---------------------------------------------------------------------------
# 3. Dimensionality reduction
# ---------------------------------------------------------------------------

def run_pca(
    df: pd.DataFrame,
    feature_cols: List[str],
    n_components: int = 3,
) -> Tuple[pd.DataFrame, Dict]:
    """Run PCA on metabolite features.

    Parameters
    ----------
    df : pd.DataFrame
    feature_cols : list of str
    n_components : int

    Returns
    -------
    tuple of (pd.DataFrame, dict)
        DataFrame with PC columns added, and dict with explained_variance_ratio.
    """
    from sklearn.decomposition import PCA
    from sklearn.preprocessing import StandardScaler

    X = df[feature_cols].apply(pd.to_numeric, errors="coerce").fillna(0).values
    X_scaled = StandardScaler().fit_transform(X)
    pca = PCA(n_components=n_components)
    scores = pca.fit_transform(X_scaled)
    out = df.copy()
    for i in range(n_components):
        out[f"PC{i+1}"] = scores[:, i]
    info = {
        "explained_variance_ratio": list(pca.explained_variance_ratio_),
        "n_components": n_components,
    }
    return out, info


def run_umap(
    df: pd.DataFrame,
    feature_cols: List[str],
    n_components: int = 2,
    n_neighbors: int = 15,
    min_dist: float = 0.1,
    random_state: int = 42,
) -> pd.DataFrame:
    """Run UMAP dimensionality reduction.

    Parameters
    ----------
    df : pd.DataFrame
    feature_cols : list of str
    n_components : int
    n_neighbors : int
    min_dist : float
    random_state : int

    Returns
    -------
    pd.DataFrame
        Input df with UMAP columns added.
    """
    try:
        import umap
    except ImportError:
        from sklearn.manifold import TSNE
        X = df[feature_cols].apply(pd.to_numeric, errors="coerce").fillna(0).values
        from sklearn.preprocessing import StandardScaler
        X = StandardScaler().fit_transform(X)
        emb = TSNE(n_components=n_components, random_state=random_state).fit_transform(X)
        out = df.copy()
        for i in range(n_components):
            out[f"UMAP{i+1}"] = emb[:, i]
        return out

    from sklearn.preprocessing import StandardScaler
    X = df[feature_cols].apply(pd.to_numeric, errors="coerce").fillna(0).values
    X = StandardScaler().fit_transform(X)
    reducer = umap.UMAP(
        n_components=n_components,
        n_neighbors=n_neighbors,
        min_dist=min_dist,
        random_state=random_state,
    )
    emb = reducer.fit_transform(X)
    out = df.copy()
    for i in range(n_components):
        out[f"UMAP{i+1}"] = emb[:, i]
    return out


# ---------------------------------------------------------------------------
# 4. Classification
# ---------------------------------------------------------------------------

def lasso_feature_selection(
    X: np.ndarray,
    y: np.ndarray,
    feature_names: List[str],
    alpha: float = 0.01,
    max_iter: int = 10000,
) -> Dict:
    """Run LASSO logistic regression for feature selection.

    Parameters
    ----------
    X : np.ndarray, shape (n_samples, n_features)
    y : np.ndarray, shape (n_samples,)
    feature_names : list of str
    alpha : float
        Regularization strength (C = 1/alpha in sklearn).
    max_iter : int

    Returns
    -------
    dict
        Keys: selected_features, coefficients, n_selected.
    """
    from sklearn.linear_model import LogisticRegression
    from sklearn.preprocessing import StandardScaler

    X_scaled = StandardScaler().fit_transform(X)
    C = 1.0 / alpha if alpha > 0 else 1e6
    model = LogisticRegression(
        penalty="l1", C=C, solver="saga", max_iter=max_iter, random_state=42
    )
    model.fit(X_scaled, y)
    coefs = model.coef_[0]
    selected = [(name, c) for name, c in zip(feature_names, coefs) if abs(c) > 1e-8]
    return {
        "selected_features": [s[0] for s in selected],
        "coefficients": {s[0]: float(s[1]) for s in selected},
        "n_selected": len(selected),
    }


def train_logistic_regression(
    X_train: np.ndarray,
    y_train: np.ndarray,
    C: float = 1.0,
    max_iter: int = 5000,
) -> Any:
    """Train a logistic regression classifier.

    Parameters
    ----------
    X_train : np.ndarray
    y_train : np.ndarray
    C : float
        Inverse regularization strength.
    max_iter : int

    Returns
    -------
    sklearn LogisticRegression model (fitted).
    """
    from sklearn.linear_model import LogisticRegression
    from sklearn.preprocessing import StandardScaler

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X_train)
    model = LogisticRegression(C=C, max_iter=max_iter, random_state=42)
    model.fit(X_scaled, y_train)
    model._scaler = scaler
    return model


def train_random_forest(
    X_train: np.ndarray,
    y_train: np.ndarray,
    n_estimators: int = 100,
    max_depth: Optional[int] = None,
    random_state: int = 42,
) -> Any:
    """Train a random forest classifier.

    Parameters
    ----------
    X_train : np.ndarray
    y_train : np.ndarray
    n_estimators : int
    max_depth : int or None
    random_state : int

    Returns
    -------
    sklearn RandomForestClassifier model (fitted).
    """
    from sklearn.ensemble import RandomForestClassifier

    model = RandomForestClassifier(
        n_estimators=n_estimators,
        max_depth=max_depth,
        random_state=random_state,
    )
    model.fit(X_train, y_train)
    return model


def predict_proba(model: Any, X: np.ndarray) -> np.ndarray:
    """Get predicted probabilities from a fitted classifier.

    Parameters
    ----------
    model : fitted sklearn classifier
    X : np.ndarray

    Returns
    -------
    np.ndarray
        Probability of positive class, shape (n_samples,).
    """
    if hasattr(model, "_scaler"):
        X = model._scaler.transform(X)
    return model.predict_proba(X)[:, 1]


def compute_roc_auc(
    y_true: np.ndarray,
    y_score: np.ndarray,
) -> Dict:
    """Compute ROC-AUC and the ROC curve coordinates.

    Parameters
    ----------
    y_true : np.ndarray
        Binary labels.
    y_score : np.ndarray
        Predicted probabilities.

    Returns
    -------
    dict
        Keys: auc, fpr, tpr, thresholds.
    """
    from sklearn.metrics import roc_auc_score, roc_curve

    auc = roc_auc_score(y_true, y_score)
    fpr, tpr, thresholds = roc_curve(y_true, y_score)
    return {
        "auc": float(auc),
        "fpr": list(fpr),
        "tpr": list(tpr),
        "thresholds": list(thresholds),
    }


def bootstrap_auc_ci(
    y_true: np.ndarray,
    y_score: np.ndarray,
    n_bootstrap: int = 1000,
    ci: float = 0.95,
    random_state: int = 42,
) -> Dict:
    """Compute bootstrap confidence interval for AUC.

    Parameters
    ----------
    y_true : np.ndarray
    y_score : np.ndarray
    n_bootstrap : int
    ci : float
        Confidence level (e.g. 0.95).
    random_state : int

    Returns
    -------
    dict
        Keys: auc, ci_lower, ci_upper.
    """
    from sklearn.metrics import roc_auc_score

    rng = np.random.RandomState(random_state)
    n = len(y_true)
    aucs = []
    for _ in range(n_bootstrap):
        idx = rng.randint(0, n, n)
        if len(np.unique(y_true[idx])) < 2:
            continue
        aucs.append(roc_auc_score(y_true[idx], y_score[idx]))
    alpha = 1.0 - ci
    lo = np.percentile(aucs, 100 * alpha / 2)
    hi = np.percentile(aucs, 100 * (1 - alpha / 2))
    return {
        "auc": float(np.mean(aucs)),
        "ci_lower": float(lo),
        "ci_upper": float(hi),
    }


def fixed_logistic_auc_protocol(
    csv_path: str,
    outcome_col: str,
    positive_label: str | int | float = 1,
    test_size: float = 0.30,
    random_state: int = 42,
    n_bootstrap: int = 1000,
) -> Dict:
    """Run the bundled metabolite-only logistic AUC protocol.

    The protocol is intentionally small and explicit: rows are samples, all
    columns except ``outcome_col`` are metabolite z-score features, scaling is
    fit on the training fold only, and the held-out AUC confidence interval is
    bootstrapped from the fixed test split.
    """
    from sklearn.linear_model import LogisticRegression
    from sklearn.metrics import roc_auc_score, roc_curve
    from sklearn.model_selection import train_test_split
    from sklearn.pipeline import make_pipeline
    from sklearn.preprocessing import StandardScaler

    df = pd.read_csv(csv_path)
    if outcome_col not in df.columns:
        raise ValueError(f"Missing outcome_col {outcome_col!r}; columns={list(df.columns)}")

    X_df = df.drop(columns=[outcome_col]).apply(pd.to_numeric, errors="coerce")
    y_raw = df[outcome_col]
    if pd.api.types.is_numeric_dtype(y_raw):
        y = (pd.to_numeric(y_raw, errors="coerce") == float(positive_label)).astype(int)
    else:
        y = (y_raw.astype(str).str.strip().str.lower() == str(positive_label).strip().lower()).astype(int)

    valid = X_df.notna().all(axis=1) & y.notna()
    X = X_df.loc[valid].to_numpy()
    y = y.loc[valid].to_numpy(dtype=int)
    if len(set(y)) != 2:
        raise ValueError("AUC protocol requires exactly two outcome classes after filtering")

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )
    model = make_pipeline(
        StandardScaler(),
        LogisticRegression(max_iter=5000, random_state=random_state),
    )
    model.fit(X_train, y_train)
    y_score = model.predict_proba(X_test)[:, 1]
    auc = roc_auc_score(y_test, y_score)
    fpr, tpr, thresholds = roc_curve(y_test, y_score)
    ci = bootstrap_auc_ci(y_test, y_score, n_bootstrap=n_bootstrap, random_state=random_state)
    return {
        "auc": float(auc),
        "ci_lower": ci["ci_lower"],
        "ci_upper": ci["ci_upper"],
        "n_train": int(len(y_train)),
        "n_test": int(len(y_test)),
        "n_features": int(X.shape[1]),
        "positive_rate_test": float(y_test.mean()),
        "fpr": list(map(float, fpr)),
        "tpr": list(map(float, tpr)),
        "thresholds": list(map(float, thresholds)),
    }


def permutation_test_auc(
    y_true: np.ndarray,
    y_score: np.ndarray,
    n_permutations: int = 1000,
    random_state: int = 42,
) -> Dict:
    """Permutation test for AUC significance.

    Parameters
    ----------
    y_true : np.ndarray
    y_score : np.ndarray
    n_permutations : int
    random_state : int

    Returns
    -------
    dict
        Keys: observed_auc, p_value, null_aucs (list).
    """
    from sklearn.metrics import roc_auc_score

    observed = roc_auc_score(y_true, y_score)
    rng = np.random.RandomState(random_state)
    null_aucs = []
    for _ in range(n_permutations):
        perm = rng.permutation(y_true)
        if len(np.unique(perm)) < 2:
            continue
        null_aucs.append(roc_auc_score(perm, y_score))
    p_value = np.mean([a >= observed for a in null_aucs])
    return {
        "observed_auc": float(observed),
        "p_value": float(p_value),
        "null_aucs": null_aucs,
    }


def cross_validate_classifier(
    X: np.ndarray,
    y: np.ndarray,
    model_type: str = "logistic",
    n_folds: int = 5,
    random_state: int = 42,
) -> Dict:
    """K-fold cross-validation for a binary classifier.

    Parameters
    ----------
    X : np.ndarray
    y : np.ndarray
    model_type : str
        'logistic' or 'rf' (random forest).
    n_folds : int
    random_state : int

    Returns
    -------
    dict
        Keys: mean_auc, std_auc, fold_aucs.
    """
    from sklearn.model_selection import StratifiedKFold
    from sklearn.metrics import roc_auc_score
    from sklearn.linear_model import LogisticRegression
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.preprocessing import StandardScaler

    skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=random_state)
    fold_aucs = []
    for train_idx, test_idx in skf.split(X, y):
        X_tr, X_te = X[train_idx], X[test_idx]
        y_tr, y_te = y[train_idx], y[test_idx]
        scaler = StandardScaler()
        X_tr = scaler.fit_transform(X_tr)
        X_te = scaler.transform(X_te)
        if model_type == "logistic":
            clf = LogisticRegression(max_iter=5000, random_state=random_state)
        else:
            clf = RandomForestClassifier(n_estimators=100, random_state=random_state)
        clf.fit(X_tr, y_tr)
        proba = clf.predict_proba(X_te)[:, 1]
        fold_aucs.append(roc_auc_score(y_te, proba))
    return {
        "mean_auc": float(np.mean(fold_aucs)),
        "std_auc": float(np.std(fold_aucs)),
        "fold_aucs": fold_aucs,
    }


# ---------------------------------------------------------------------------
# 5. Pathway enrichment helper
# ---------------------------------------------------------------------------

def pathway_enrichment_summary(
    enrichment_df: pd.DataFrame,
    fdr_col: str = "FDR",
    impact_col: str = "Impact",
    pathway_col: str = "Pathway",
    fdr_threshold: float = 0.05,
) -> Dict:
    """Summarize pathway enrichment results.

    Parameters
    ----------
    enrichment_df : pd.DataFrame
    fdr_col, impact_col, pathway_col : str
    fdr_threshold : float

    Returns
    -------
    dict
        Keys: n_significant, significant_pathways (list of dicts), top_pathway.
    """
    sig = enrichment_df[enrichment_df[fdr_col] < fdr_threshold].copy()
    sig = sig.sort_values(fdr_col)
    pathways = []
    for _, row in sig.iterrows():
        pathways.append({
            "pathway": row[pathway_col],
            "fdr": float(row[fdr_col]),
            "impact": float(row[impact_col]) if pd.notna(row[impact_col]) else 0.0,
        })
    top = pathways[0]["pathway"] if pathways else None
    return {
        "n_significant": len(pathways),
        "significant_pathways": pathways,
        "top_pathway": top,
    }


def metabolite_class_distribution(
    metabolites: List[str],
    annotation_df: pd.DataFrame,
    metabolite_col: str = "Metabolites",
    class_col: str = "Class",
) -> Dict[str, int]:
    """Count metabolite classes from an annotation table.

    Parameters
    ----------
    metabolites : list of str
        Names of metabolites to classify.
    annotation_df : pd.DataFrame
    metabolite_col : str
    class_col : str

    Returns
    -------
    dict
        Class name -> count.
    """
    # Try fuzzy matching on metabolite names
    lookup = {}
    for _, row in annotation_df.iterrows():
        name = str(row[metabolite_col]).strip()
        cls = str(row.get(class_col, "Unknown"))
        lookup[name.lower()] = cls

    counts = {}
    for m in metabolites:
        cls = lookup.get(m.strip().lower(), "Unknown")
        counts[cls] = counts.get(cls, 0) + 1
    return counts


# ---------------------------------------------------------------------------
# 6. Visualization (all return {"path": ...})
# ---------------------------------------------------------------------------

def plot_volcano(
    df: pd.DataFrame,
    log2fc_col: str = "log2(fold change)",
    neg_log10_fdr_col: str = "-log10(FDR)",
    direction_col: str = "Direction",
    metabolite_col: str = "Metabolites",
    fc_threshold: float = 0.0,
    fdr_threshold: float = 1.3,
    top_n_labels: int = 5,
    output_path: str = "volcano_plot.png",
    title: str = "Volcano Plot",
    figsize: Tuple[int, int] = (10, 8),
) -> Dict:
    """Create a volcano plot of metabolomics data.

    Parameters
    ----------
    df : pd.DataFrame
    log2fc_col : str
    neg_log10_fdr_col : str
    direction_col : str
    metabolite_col : str
    fc_threshold : float
    fdr_threshold : float
        Threshold on -log10(FDR) scale.
    top_n_labels : int
    output_path : str
    title : str
    figsize : tuple

    Returns
    -------
    dict
        {"path": output_path}
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=figsize)

    colors = {"Increase": "#e74c3c", "Decrease": "#3498db", "Stable": "#bdc3c7"}
    for direction in ["Stable", "Decrease", "Increase"]:
        subset = df[df[direction_col] == direction]
        ax.scatter(
            subset[log2fc_col],
            subset[neg_log10_fdr_col],
            c=colors.get(direction, "#bdc3c7"),
            s=20,
            alpha=0.7,
            label=direction,
        )

    # Label top metabolites
    sig = df[df[neg_log10_fdr_col] >= fdr_threshold].copy()
    sig = sig.sort_values(neg_log10_fdr_col, ascending=False).head(top_n_labels)
    for _, row in sig.iterrows():
        ax.annotate(
            row[metabolite_col],
            (row[log2fc_col], row[neg_log10_fdr_col]),
            fontsize=7,
            alpha=0.8,
        )

    ax.axhline(y=fdr_threshold, color="gray", linestyle="--", alpha=0.5)
    ax.set_xlabel("log2(Fold Change)")
    ax.set_ylabel("-log10(FDR)")
    ax.set_title(title)
    ax.legend()
    plt.tight_layout()
    plt.savefig(output_path, dpi=150)
    plt.close()
    return {"path": output_path}


def plot_roc_curves(
    roc_data: List[Dict],
    output_path: str = "roc_curves.png",
    title: str = "ROC Curves",
    figsize: Tuple[int, int] = (8, 8),
) -> Dict:
    """Plot ROC curves for multiple models.

    Parameters
    ----------
    roc_data : list of dict
        Each dict must have keys: label, fpr, tpr, auc.
    output_path : str
    title : str
    figsize : tuple

    Returns
    -------
    dict
        {"path": output_path}
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=figsize)
    for item in roc_data:
        ax.plot(
            item["fpr"],
            item["tpr"],
            label=f'{item["label"]} (AUC={item["auc"]:.3f})',
            linewidth=2,
        )
    ax.plot([0, 1], [0, 1], "k--", alpha=0.5)
    ax.set_xlabel("False Positive Rate")
    ax.set_ylabel("True Positive Rate")
    ax.set_title(title)
    ax.legend(loc="lower right")
    plt.tight_layout()
    plt.savefig(output_path, dpi=150)
    plt.close()
    return {"path": output_path}


def plot_pca_scatter(
    df: pd.DataFrame,
    group_col: str,
    pc1_col: str = "PC1",
    pc2_col: str = "PC2",
    output_path: str = "pca_scatter.png",
    title: str = "PCA Score Plot",
    figsize: Tuple[int, int] = (8, 6),
) -> Dict:
    """2D PCA scatter plot colored by group.

    Parameters
    ----------
    df : pd.DataFrame
    group_col : str
    pc1_col, pc2_col : str
    output_path : str
    title : str
    figsize : tuple

    Returns
    -------
    dict
        {"path": output_path}
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=figsize)
    groups = df[group_col].unique()
    cmap = ["#e74c3c", "#3498db", "#2ecc71", "#f39c12"]
    for i, g in enumerate(groups):
        sub = df[df[group_col] == g]
        ax.scatter(sub[pc1_col], sub[pc2_col], label=g, alpha=0.6,
                   c=cmap[i % len(cmap)], s=30)
    ax.set_xlabel(pc1_col)
    ax.set_ylabel(pc2_col)
    ax.set_title(title)
    ax.legend()
    plt.tight_layout()
    plt.savefig(output_path, dpi=150)
    plt.close()
    return {"path": output_path}


def plot_heatmap(
    df: pd.DataFrame,
    feature_cols: List[str],
    group_col: str,
    output_path: str = "heatmap.png",
    title: str = "Metabolite Heatmap",
    figsize: Tuple[int, int] = (14, 8),
) -> Dict:
    """Plot a heatmap of metabolite intensities grouped by case/control.

    Parameters
    ----------
    df : pd.DataFrame
    feature_cols : list of str
    group_col : str
    output_path : str
    title : str
    figsize : tuple

    Returns
    -------
    dict
        {"path": output_path}
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    sorted_df = df.sort_values(group_col)
    data = sorted_df[feature_cols].apply(pd.to_numeric, errors="coerce").fillna(0).values.T

    fig, ax = plt.subplots(figsize=figsize)
    im = ax.imshow(data, aspect="auto", cmap="RdBu_r", vmin=-3, vmax=3)
    ax.set_yticks(range(len(feature_cols)))
    ax.set_yticklabels(feature_cols, fontsize=7)
    ax.set_xlabel("Samples")
    ax.set_title(title)
    plt.colorbar(im, ax=ax, label="Z-score")
    plt.tight_layout()
    plt.savefig(output_path, dpi=150)
    plt.close()
    return {"path": output_path}


def plot_feature_importance(
    feature_names: List[str],
    importances: List[float],
    output_path: str = "feature_importance.png",
    title: str = "Feature Importance",
    top_n: int = 15,
    figsize: Tuple[int, int] = (8, 6),
) -> Dict:
    """Horizontal bar chart of feature importances.

    Parameters
    ----------
    feature_names : list of str
    importances : list of float
    output_path : str
    title : str
    top_n : int
    figsize : tuple

    Returns
    -------
    dict
        {"path": output_path}
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    pairs = sorted(zip(feature_names, importances), key=lambda x: abs(x[1]), reverse=True)
    pairs = pairs[:top_n]
    names = [p[0] for p in reversed(pairs)]
    vals = [p[1] for p in reversed(pairs)]

    fig, ax = plt.subplots(figsize=figsize)
    colors = ["#e74c3c" if v > 0 else "#3498db" for v in vals]
    ax.barh(names, vals, color=colors)
    ax.set_xlabel("Coefficient / Importance")
    ax.set_title(title)
    plt.tight_layout()
    plt.savefig(output_path, dpi=150)
    plt.close()
    return {"path": output_path}


def plot_boxplot_comparison(
    df: pd.DataFrame,
    metabolite_col: str,
    group_col: str,
    output_path: str = "boxplot.png",
    title: str = "",
    figsize: Tuple[int, int] = (6, 5),
) -> Dict:
    """Box plot comparing metabolite levels between groups.

    Parameters
    ----------
    df : pd.DataFrame
    metabolite_col : str
    group_col : str
    output_path : str
    title : str
    figsize : tuple

    Returns
    -------
    dict
        {"path": output_path}
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=figsize)
    groups = df[group_col].unique()
    data = [pd.to_numeric(df[df[group_col] == g][metabolite_col], errors="coerce").dropna() for g in groups]
    bp = ax.boxplot(data, labels=groups, patch_artist=True)
    colors = ["#e74c3c", "#3498db", "#2ecc71", "#f39c12"]
    for patch, color in zip(bp["boxes"], colors):
        patch.set_facecolor(color)
        patch.set_alpha(0.6)
    ax.set_ylabel(metabolite_col)
    ax.set_title(title or metabolite_col)
    plt.tight_layout()
    plt.savefig(output_path, dpi=150)
    plt.close()
    return {"path": output_path}

# Tools

## metabolomics_analysis.py
Domain-specific metabolomics analysis primitives:
- **Data preprocessing**: load_metabolomics_csv, log_transform_metabolites, zscore_normalize, filter_metabolites_by_missingness
- **Statistical testing**: per_metabolite_test (t-test/Wilcoxon), fdr_correction (BH), volcano_classify
- **Dimensionality reduction**: run_pca, run_umap
- **Classification**: lasso_feature_selection, train_logistic_regression, fixed_logistic_auc_protocol, train_random_forest, predict_proba, compute_roc_auc, bootstrap_auc_ci, permutation_test_auc, cross_validate_classifier
- **Enrichment & annotation**: pathway_enrichment_summary, metabolite_class_distribution
- **Visualization**: plot_volcano, plot_roc_curves, plot_pca_scatter, plot_heatmap, plot_feature_importance, plot_boxplot_comparison

## data_processing.py
Generic tabular data utilities: load_csv, load_excel, summarize_df, filter_rows, merge_dataframes, numeric_columns, describe_column

## database_retrieval.py
Stubs for external metabolomics database queries: query_hmdb, query_kegg_pathway, query_metaboanalyst_enrichment

The bundled classifier tables are tabular sample-by-feature matrices. The
published covariate-adjusted clinical-marker models require clinical variables
that are not included in the bundle; the provided classifier primitive therefore
evaluates metabolite-only logistic AUCs from the bundled z-score panels.

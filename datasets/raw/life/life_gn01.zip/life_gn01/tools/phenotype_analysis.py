"""Phenotype-genotype association and cluster comparison analyses."""

import numpy as np
from scipy import stats
from typing import Dict, List, Tuple, Optional


def compare_phenotype_across_clusters(
    phenotype_values: np.ndarray,
    cluster_labels: np.ndarray,
) -> Dict[str, object]:
    """Compare a phenotype across genetic clusters using ANOVA / Kruskal-Wallis.

    Parameters
    ----------
    phenotype_values : np.ndarray, shape (n_samples,)
        Phenotype measurements (may contain NaN).
    cluster_labels : np.ndarray, shape (n_samples,)
        Cluster assignment per sample.

    Returns
    -------
    dict
        Keys: 'anova_F', 'anova_p', 'kruskal_H', 'kruskal_p',
        'cluster_means', 'cluster_stds', 'cluster_n'.
    """
    valid = ~np.isnan(phenotype_values)
    pheno = phenotype_values[valid]
    labels = cluster_labels[valid]

    clusters = sorted(set(labels))
    groups = [pheno[labels == c] for c in clusters]

    # Filter out empty groups
    non_empty = [(c, g) for c, g in zip(clusters, groups) if len(g) > 1]
    if len(non_empty) < 2:
        return {
            'anova_F': np.nan, 'anova_p': np.nan,
            'kruskal_H': np.nan, 'kruskal_p': np.nan,
            'cluster_means': {}, 'cluster_stds': {}, 'cluster_n': {},
        }

    clusters_filt = [c for c, _ in non_empty]
    groups_filt = [g for _, g in non_empty]

    F_stat, anova_p = stats.f_oneway(*groups_filt)
    H_stat, kw_p = stats.kruskal(*groups_filt)

    means = {int(c): float(g.mean()) for c, g in zip(clusters_filt, groups_filt)}
    stds = {int(c): float(g.std()) for c, g in zip(clusters_filt, groups_filt)}
    ns = {int(c): int(len(g)) for c, g in zip(clusters_filt, groups_filt)}

    return {
        'anova_F': float(F_stat),
        'anova_p': float(anova_p),
        'kruskal_H': float(H_stat),
        'kruskal_p': float(kw_p),
        'cluster_means': means,
        'cluster_stds': stds,
        'cluster_n': ns,
    }


def phenotype_latitude_regression(
    phenotype_values: np.ndarray,
    latitudes: np.ndarray,
) -> Dict[str, float]:
    """Regress phenotype on latitude (clinal variation test).

    Parameters
    ----------
    phenotype_values : np.ndarray, shape (n,)
    latitudes : np.ndarray, shape (n,)

    Returns
    -------
    dict
        Keys: 'slope', 'intercept', 'r_value', 'p_value', 'r_squared'.
    """
    valid = ~np.isnan(phenotype_values) & ~np.isnan(latitudes)
    slope, intercept, r_value, p_value, std_err = stats.linregress(
        latitudes[valid], phenotype_values[valid]
    )
    return {
        'slope': float(slope),
        'intercept': float(intercept),
        'r_value': float(r_value),
        'p_value': float(p_value),
        'r_squared': float(r_value ** 2),
    }


def summarize_budburst_structure(
    phenotype_2022: np.ndarray,
    phenotype_2023: np.ndarray,
    latitudes: np.ndarray,
    cluster_labels: np.ndarray,
) -> Dict[str, object]:
    """Summarize budburst differences across K clusters and latitude.

    Returns a compact, reusable evidence object for the paper's phenology
    question rather than a final narrative conclusion.
    """
    return {
        "budburst2022_by_cluster": compare_phenotype_across_clusters(
            np.asarray(phenotype_2022, dtype=float), np.asarray(cluster_labels)
        ),
        "budburst2023_by_cluster": compare_phenotype_across_clusters(
            np.asarray(phenotype_2023, dtype=float), np.asarray(cluster_labels)
        ),
        "budburst2022_latitude": phenotype_latitude_regression(
            np.asarray(phenotype_2022, dtype=float), np.asarray(latitudes, dtype=float)
        ),
        "budburst2023_latitude": phenotype_latitude_regression(
            np.asarray(phenotype_2023, dtype=float), np.asarray(latitudes, dtype=float)
        ),
    }


def qst_fst_comparison(
    phenotype_values: np.ndarray,
    pop_labels: np.ndarray,
    global_fst: float,
) -> Dict[str, float]:
    """Compare phenotypic differentiation (Qst) to genetic differentiation (Fst).

    Qst = Vb / (Vb + 2*Vw), where Vb = among-population variance,
    Vw = within-population variance.

    If Qst > Fst, divergent selection is inferred.
    If Qst < Fst, stabilising selection is inferred.
    If Qst ≈ Fst, drift alone can explain the pattern.

    Parameters
    ----------
    phenotype_values : np.ndarray, shape (n,)
    pop_labels : np.ndarray, shape (n,)
    global_fst : float

    Returns
    -------
    dict
        Keys: 'qst', 'fst', 'ratio' (Qst/Fst), 'interpretation'.
    """
    valid = ~np.isnan(phenotype_values)
    pheno = phenotype_values[valid]
    pops = pop_labels[valid]

    unique_pops = np.unique(pops)
    pop_means = []
    vw_contributions = []

    for p in unique_pops:
        mask = pops == p
        if mask.sum() < 2:
            continue
        vals = pheno[mask]
        pop_means.append(vals.mean())
        vw_contributions.append(vals.var())

    if len(pop_means) < 2:
        return {'qst': np.nan, 'fst': global_fst, 'ratio': np.nan,
                'interpretation': 'insufficient data'}

    pop_means = np.array(pop_means)
    Vb = pop_means.var()
    Vw = np.mean(vw_contributions)

    denom = Vb + 2 * Vw
    qst = Vb / denom if denom > 0 else 0.0

    ratio = qst / global_fst if global_fst > 0 else np.nan

    if ratio > 1.2:
        interp = 'divergent selection (Qst > Fst)'
    elif ratio < 0.8:
        interp = 'stabilising selection (Qst < Fst)'
    else:
        interp = 'neutral (Qst ~ Fst, drift alone)'

    return {
        'qst': float(qst),
        'fst': float(global_fst),
        'ratio': float(ratio) if not np.isnan(ratio) else None,
        'interpretation': interp,
    }

"""Principal Component Analysis on genotype data."""

import numpy as np
from typing import Tuple, Optional


def run_pca(
    genotypes: np.ndarray,
    n_components: int = 10,
    scale: bool = True,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Perform PCA on a genotype matrix.

    Centers (and optionally scales) the genotype matrix across samples
    for each variant, then computes the top principal components via
    truncated SVD.

    Parameters
    ----------
    genotypes : np.ndarray, shape (n_variants, n_samples)
        Dosage matrix (0/1/2), already imputed.
    n_components : int
        Number of principal components to return.
    scale : bool
        If True, standardise each variant to unit variance before SVD.

    Returns
    -------
    pc_coords : np.ndarray, shape (n_samples, n_components)
        Sample coordinates in PC space (scaled by singular values).
    eigenvalues : np.ndarray, shape (n_components,)
        Squared singular values (proportional to variance explained).
    variance_explained : np.ndarray, shape (n_components,)
        Fraction of total variance explained by each component.
    """
    means = genotypes.mean(axis=1, keepdims=True)
    G = genotypes - means

    if scale:
        stds = genotypes.std(axis=1, keepdims=True)
        stds[stds == 0] = 1.0
        G = G / stds

    # SVD on (n_samples x n_variants) = G^T
    U, S, Vt = np.linalg.svd(G.T, full_matrices=False)

    pc_coords = U[:, :n_components] * S[:n_components]
    eigenvalues = S[:n_components] ** 2
    total_var = np.sum(S ** 2)
    variance_explained = eigenvalues / total_var

    return pc_coords, eigenvalues, variance_explained


def project_samples(
    genotypes_ref: np.ndarray,
    genotypes_new: np.ndarray,
    n_components: int = 10,
    scale: bool = True,
) -> np.ndarray:
    """Project new samples onto PCA space defined by reference samples.

    Parameters
    ----------
    genotypes_ref : np.ndarray, shape (n_variants, n_ref)
        Reference genotype matrix used to define PC axes.
    genotypes_new : np.ndarray, shape (n_variants, n_new)
        New samples to project.
    n_components : int
    scale : bool

    Returns
    -------
    np.ndarray, shape (n_new, n_components)
        Projected coordinates for the new samples.
    """
    means = genotypes_ref.mean(axis=1, keepdims=True)
    G_ref = genotypes_ref - means
    G_new = genotypes_new - means

    if scale:
        stds = genotypes_ref.std(axis=1, keepdims=True)
        stds[stds == 0] = 1.0
        G_ref = G_ref / stds
        G_new = G_new / stds

    # Compute loadings from reference
    U, S, Vt = np.linalg.svd(G_ref.T, full_matrices=False)
    # Loadings = Vt^T (n_variants x n_components)
    loadings = Vt[:n_components].T

    # Project new samples
    projected = G_new.T @ loadings
    return projected


def scree_data(
    eigenvalues: np.ndarray,
    n_show: int = 20,
) -> Tuple[np.ndarray, np.ndarray]:
    """Prepare data for a scree plot.

    Parameters
    ----------
    eigenvalues : np.ndarray
        Eigenvalues from PCA.
    n_show : int
        Number of components to include.

    Returns
    -------
    components : np.ndarray
        Component indices (1-based).
    pct_variance : np.ndarray
        Percentage of variance explained per component.
    """
    total = eigenvalues.sum()
    k = min(n_show, len(eigenvalues))
    components = np.arange(1, k + 1)
    pct_variance = eigenvalues[:k] / total * 100
    return components, pct_variance

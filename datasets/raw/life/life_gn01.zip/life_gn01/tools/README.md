# Population Genomics Tools

## Data Loading (`data_loading.py`)
Load genotype matrices, variant info, sample metadata, coordinates, phenotypes.

## Allele Frequency (`allele_freq.py`)
Compute allele frequencies, MAF, observed/expected heterozygosity, MAF filtering.

## Hardy-Weinberg (`hardy_weinberg.py`)
Chi-squared HWE test, HWE-based variant filtering.

## Linkage Disequilibrium (`ld_computation.py`)
Pairwise r-squared, LD matrix, LD pruning, LD decay estimation.

## PCA (`pca_analysis.py`)
PCA via SVD on genotype matrix, sample projection, scree data.

## Admixture (`admixture.py`)
NMF-based ancestry estimation, cross-validation for K, cluster assignment.

## Fst Estimation (`fst_estimation.py`)
Weir-Cockerham Fst (pairwise and global), population index builder.

## Isolation by Distance (`isolation_by_distance.py`)
Geographic distance matrix, Mantel test, Fst linearisation, IBD regression.

## Clustering (`clustering.py`)
Hierarchical clustering, tree cutting, K-means in PCA space, nucleotide diversity.

## Association Testing (`association_test.py`)
Linear and chi-squared per-variant tests, genomic inflation factor.

## Multiple Testing (`multiple_testing.py`)
Bonferroni, Benjamini-Hochberg FDR, permutation threshold.

## Phenotype Analysis (`phenotype_analysis.py`)
ANOVA/Kruskal-Wallis across clusters, latitude regression, budburst
cluster/latitude summary, Qst-Fst comparison.

## Spatial Genetics (`spatial_genetics.py`)
PC-geography correlation, Procrustes test, AMOVA variance partitioning.

## Plotting: PCA (`plot_pca.py`)
PCA scatter, PCA-geography, scree plot.

## Plotting: Manhattan/QQ (`plot_manhattan.py`)
Manhattan plot, QQ plot with genomic lambda.

## Plotting: Structure (`plot_structure.py`)
Admixture barplot, Fst heatmap, IBD scatter, geographic cluster map.

"""Wright's Fst estimation between populations."""

import numpy as np
from typing import Dict, List, Tuple, Optional


def weir_cockerham_fst(
    genotypes: np.ndarray,
    pop_indices: Dict[int, List[int]],
    pop_a: int,
    pop_b: int,
) -> float:
    """Compute genome-wide Weir-Cockerham Fst between two populations.

    Implements the ratio-of-averages estimator: Fst = mean(a) / mean(a + b + c)
    across all variants, where a, b, c are the variance components from
    Weir & Cockerham (1984).

    Parameters
    ----------
    genotypes : np.ndarray, shape (n_variants, n_samples)
    pop_indices : dict
        Maps population ID to list of sample column indices.
    pop_a, pop_b : int
        Population IDs to compare.

    Returns
    -------
    float
        Genome-wide Fst estimate.
    """
    idx_a = pop_indices[pop_a]
    idx_b = pop_indices[pop_b]

    g_a = genotypes[:, idx_a]
    g_b = genotypes[:, idx_b]

    n_a = len(idx_a)
    n_b = len(idx_b)

    if n_a < 2 or n_b < 2:
        return np.nan

    # Allele frequencies
    p_a = g_a.mean(axis=1) / 2.0
    p_b = g_b.mean(axis=1) / 2.0

    # Mean frequency weighted by sample size
    n_bar = (n_a + n_b) / 2.0
    p_bar = (p_a * n_a + p_b * n_b) / (n_a + n_b)

    # Sample variance of allele frequencies
    s2 = (n_a * (p_a - p_bar) ** 2 + n_b * (p_b - p_bar) ** 2) / n_bar

    # Mean heterozygosity
    h_a = (np.round(g_a) == 1).mean(axis=1)
    h_b = (np.round(g_b) == 1).mean(axis=1)
    h_bar = (h_a * n_a + h_b * n_b) / (n_a + n_b)

    r = 2  # number of populations
    n_c = (2 * n_bar - (n_a ** 2 + n_b ** 2) / (2 * n_bar)) / (r - 1)

    # Variance components
    a_comp = (n_bar / n_c) * (s2 - (1 / (n_bar - 1)) * (p_bar * (1 - p_bar) - s2 * (r - 1) / r - h_bar / 4))
    b_comp = (n_bar / (n_bar - 1)) * (p_bar * (1 - p_bar) - s2 * (r - 1) / r - h_bar * (2 * n_bar - 1) / (4 * n_bar))
    c_comp = h_bar / 2

    # Ratio of averages
    num = a_comp.sum()
    denom = (a_comp + b_comp + c_comp).sum()

    if denom == 0:
        return 0.0
    return num / denom


def pairwise_fst_matrix(
    genotypes: np.ndarray,
    pop_indices: Dict[int, List[int]],
    pop_ids: Optional[List[int]] = None,
) -> Tuple[np.ndarray, List[int]]:
    """Compute pairwise Fst for all population pairs.

    Parameters
    ----------
    genotypes : np.ndarray, shape (n_variants, n_samples)
    pop_indices : dict
        Maps population ID to list of sample column indices.
    pop_ids : list of int or None
        Populations to include. If None, use all in pop_indices.

    Returns
    -------
    fst_matrix : np.ndarray, shape (n_pops, n_pops)
        Symmetric matrix of pairwise Fst values. Diagonal is 0.
    pop_ids : list of int
        Population IDs in the order used for rows/columns.
    """
    if pop_ids is None:
        pop_ids = sorted(pop_indices.keys())

    n = len(pop_ids)
    fst_mat = np.zeros((n, n))
    for i in range(n):
        for j in range(i + 1, n):
            fst = weir_cockerham_fst(genotypes, pop_indices, pop_ids[i], pop_ids[j])
            fst_mat[i, j] = fst
            fst_mat[j, i] = fst

    return fst_mat, pop_ids


def global_fst(
    genotypes: np.ndarray,
    pop_indices: Dict[int, List[int]],
) -> float:
    """Compute global multi-population Fst.

    Uses the Hudson estimator: Fst = 1 - Hs/Ht, averaged over variants,
    where Hs is the mean within-population heterozygosity and Ht is
    the total heterozygosity.

    Parameters
    ----------
    genotypes : np.ndarray, shape (n_variants, n_samples)
    pop_indices : dict
        Maps population ID to list of sample column indices.

    Returns
    -------
    float
        Global Fst estimate.
    """
    pops = sorted(pop_indices.keys())
    n_pops = len(pops)
    sizes = [len(pop_indices[p]) for p in pops]
    total_n = sum(sizes)

    # Per-population allele frequencies
    freqs = []
    for p in pops:
        idx = pop_indices[p]
        f = genotypes[:, idx].mean(axis=1) / 2.0
        freqs.append(f)
    freqs = np.array(freqs)  # (n_pops, n_variants)

    # Total allele frequency (weighted)
    weights = np.array(sizes, dtype=float) / total_n
    p_total = (freqs * weights[:, None]).sum(axis=0)

    # Ht
    ht = 2.0 * p_total * (1.0 - p_total)

    # Hs
    hs_per_pop = 2.0 * freqs * (1.0 - freqs)
    hs = (hs_per_pop * weights[:, None]).sum(axis=0)

    mask = ht > 0
    if mask.sum() == 0:
        return 0.0

    return 1.0 - hs[mask].mean() / ht[mask].mean()


def build_pop_indices(
    sample_ids: List[str],
    metadata: Dict[str, Dict],
) -> Dict[int, List[int]]:
    """Map population IDs to column indices in the genotype matrix.

    Parameters
    ----------
    sample_ids : list of str
        Sample IDs as they appear in the genotype matrix columns.
    metadata : dict
        Sample metadata from load_sample_metadata.

    Returns
    -------
    dict
        Maps population ID (int) to list of column indices.
    """
    pop_idx: Dict[int, List[int]] = {}
    for i, sid in enumerate(sample_ids):
        if sid in metadata:
            pid = metadata[sid]['population']
            pop_idx.setdefault(pid, []).append(i)
    return pop_idx

"""Multiple testing correction methods."""

import numpy as np
from typing import Tuple


def bonferroni_correction(
    p_values: np.ndarray,
    alpha: float = 0.05,
) -> Tuple[np.ndarray, float]:
    """Apply Bonferroni correction for multiple testing.

    Parameters
    ----------
    p_values : np.ndarray
    alpha : float
        Family-wise error rate threshold.

    Returns
    -------
    adjusted_p : np.ndarray
        Bonferroni-adjusted p-values (capped at 1.0).
    threshold : float
        Per-test significance threshold (alpha / n_tests).
    """
    n = len(p_values)
    adjusted = np.minimum(p_values * n, 1.0)
    return adjusted, alpha / n


def benjamini_hochberg(
    p_values: np.ndarray,
    alpha: float = 0.05,
) -> Tuple[np.ndarray, np.ndarray]:
    """Benjamini-Hochberg FDR correction.

    Parameters
    ----------
    p_values : np.ndarray
    alpha : float
        Target false discovery rate.

    Returns
    -------
    q_values : np.ndarray
        FDR-adjusted p-values (q-values).
    significant : np.ndarray of bool
        Mask of variants significant at the target FDR.
    """
    n = len(p_values)
    sorted_idx = np.argsort(p_values)
    sorted_p = p_values[sorted_idx]

    # BH adjusted p-values
    q = np.zeros(n)
    q[sorted_idx[-1]] = sorted_p[-1]
    for i in range(n - 2, -1, -1):
        rank = i + 1
        q_val = sorted_p[i] * n / rank
        q[sorted_idx[i]] = min(q_val, q[sorted_idx[i + 1]])

    q = np.minimum(q, 1.0)
    significant = q <= alpha
    return q, significant


def permutation_threshold(
    genotypes: np.ndarray,
    phenotype: np.ndarray,
    n_permutations: int = 100,
    alpha: float = 0.05,
    seed: int = 42,
) -> float:
    """Estimate genome-wide significance threshold by permutation.

    Permutes the phenotype labels and computes the minimum p-value
    across all variants for each permutation. Returns the alpha-quantile
    of the null distribution of minimum p-values.

    Parameters
    ----------
    genotypes : np.ndarray, shape (n_variants, n_samples)
    phenotype : np.ndarray, shape (n_samples,)
    n_permutations : int
    alpha : float
    seed : int

    Returns
    -------
    float
        Empirical genome-wide significance threshold.
    """
    from .association_test import linear_association_test

    rng = np.random.default_rng(seed)
    valid = ~np.isnan(phenotype)
    min_p_values = []

    for _ in range(n_permutations):
        perm_pheno = phenotype.copy()
        perm_pheno[valid] = rng.permutation(phenotype[valid])
        _, _, pvals = linear_association_test(genotypes, perm_pheno)
        min_p_values.append(pvals.min())

    return float(np.quantile(min_p_values, alpha))

"""Spatial genetic analysis: geographic correlation, Procrustes, and AMOVA."""

import numpy as np
from scipy import stats
from typing import Dict, List, Tuple, Optional


def pc_geography_correlation(
    pc_coords: np.ndarray,
    longitudes: np.ndarray,
    latitudes: np.ndarray,
    n_pcs: int = 5,
) -> Dict[str, List[Dict[str, float]]]:
    """Compute Pearson correlation between PCs and geographic coordinates.

    Parameters
    ----------
    pc_coords : np.ndarray, shape (n_samples, n_components)
    longitudes : np.ndarray, shape (n_samples,)
    latitudes : np.ndarray, shape (n_samples,)
    n_pcs : int
        Number of PCs to test.

    Returns
    -------
    dict
        Keys 'longitude', 'latitude'. Values are lists of dicts with
        'pc' (1-indexed), 'r', 'r_squared', 'p_value' per PC.
    """
    results = {'longitude': [], 'latitude': []}

    for i in range(min(n_pcs, pc_coords.shape[1])):
        for coord_name, coord_vals in [('longitude', longitudes), ('latitude', latitudes)]:
            r, p = stats.pearsonr(pc_coords[:, i], coord_vals)
            results[coord_name].append({
                'pc': i + 1,
                'r': float(r),
                'r_squared': float(r ** 2),
                'p_value': float(p),
            })

    return results


def procrustes_test(
    pc_coords: np.ndarray,
    geographic_coords: np.ndarray,
    n_permutations: int = 999,
    seed: int = 42,
) -> Dict[str, float]:
    """Procrustes analysis comparing PCA configuration to geography.

    Optimally rotates, translates, and scales the PCA coordinates
    to best match the geographic coordinates, then computes the
    sum of squared residuals. Significance is assessed by permutation.

    Parameters
    ----------
    pc_coords : np.ndarray, shape (n, 2)
        First two PC coordinates.
    geographic_coords : np.ndarray, shape (n, 2)
        Longitude, latitude columns.
    n_permutations : int
    seed : int

    Returns
    -------
    dict
        Keys: 'disparity' (sum of squared residuals after alignment),
        'correlation' (1 - disparity), 'p_value'.
    """
    def _procrustes_disparity(X, Y):
        """Compute Procrustes disparity between X and Y."""
        # Centre
        X = X - X.mean(axis=0)
        Y = Y - Y.mean(axis=0)
        # Scale
        X = X / np.linalg.norm(X)
        Y = Y / np.linalg.norm(Y)
        # Rotate
        U, _, Vt = np.linalg.svd(Y.T @ X)
        R = U @ Vt
        X_rot = X @ R.T
        return np.sum((Y - X_rot) ** 2)

    obs_disp = _procrustes_disparity(pc_coords, geographic_coords)

    rng = np.random.default_rng(seed)
    count = 0
    for _ in range(n_permutations):
        perm = rng.permutation(len(geographic_coords))
        perm_disp = _procrustes_disparity(pc_coords, geographic_coords[perm])
        if perm_disp <= obs_disp:
            count += 1

    p_value = (count + 1) / (n_permutations + 1)
    return {
        'disparity': float(obs_disp),
        'correlation': float(1.0 - obs_disp),
        'p_value': float(p_value),
    }


def amova_partition(
    genotypes: np.ndarray,
    group_labels: np.ndarray,
    pop_labels: np.ndarray,
) -> Dict[str, float]:
    """Simplified AMOVA-like variance partitioning.

    Partitions genetic variance into three levels:
    - Among groups (e.g. genetic clusters)
    - Among populations within groups
    - Within populations

    Uses allele frequency data rather than full distance matrices,
    computing variance components from nested ANOVA.

    Parameters
    ----------
    genotypes : np.ndarray, shape (n_variants, n_samples)
    group_labels : np.ndarray, shape (n_samples,)
    pop_labels : np.ndarray, shape (n_samples,)

    Returns
    -------
    dict
        Keys: 'among_groups', 'among_pops_within_groups',
        'within_populations'. Values are fractions summing to 1.
    """
    n_var = genotypes.shape[0]
    n_samp = genotypes.shape[1]

    # Overall mean allele frequency
    p_total = genotypes.mean(axis=1) / 2.0

    # Total variance
    ss_total = 0
    for i in range(n_samp):
        ss_total += np.sum((genotypes[:, i] / 2.0 - p_total) ** 2)

    # Among groups
    groups = np.unique(group_labels)
    ss_among_groups = 0
    for g in groups:
        g_mask = group_labels == g
        n_g = g_mask.sum()
        p_group = genotypes[:, g_mask].mean(axis=1) / 2.0
        ss_among_groups += n_g * np.sum((p_group - p_total) ** 2)

    # Among populations within groups
    pops = np.unique(pop_labels)
    ss_among_pops = 0
    for p in pops:
        p_mask = pop_labels == p
        if p_mask.sum() < 2:
            continue
        g = group_labels[p_mask][0]
        g_mask = group_labels == g
        p_pop = genotypes[:, p_mask].mean(axis=1) / 2.0
        p_group = genotypes[:, g_mask].mean(axis=1) / 2.0
        ss_among_pops += p_mask.sum() * np.sum((p_pop - p_group) ** 2)

    ss_within = ss_total - ss_among_groups - ss_among_pops
    if ss_within < 0:
        ss_within = 0

    total = ss_among_groups + ss_among_pops + ss_within
    if total == 0:
        return {'among_groups': 0, 'among_pops_within_groups': 0, 'within_populations': 1.0}

    return {
        'among_groups': float(ss_among_groups / total),
        'among_pops_within_groups': float(ss_among_pops / total),
        'within_populations': float(ss_within / total),
    }

"""Hierarchical and K-means clustering on genetic distance data."""

import numpy as np
from scipy.cluster.hierarchy import linkage, fcluster, dendrogram
from scipy.spatial.distance import squareform
from typing import Tuple, List, Dict, Optional


def hierarchical_clustering(
    distance_matrix: np.ndarray,
    method: str = 'average',
) -> np.ndarray:
    """Perform hierarchical clustering on a distance matrix.

    Parameters
    ----------
    distance_matrix : np.ndarray, shape (n, n)
        Symmetric distance (or Fst) matrix. Diagonal should be 0.
    method : str
        Linkage method: 'average', 'complete', 'single', 'ward'.

    Returns
    -------
    np.ndarray
        Linkage matrix suitable for scipy.cluster.hierarchy.dendrogram
        and fcluster.
    """
    condensed = squareform(distance_matrix, checks=False)
    return linkage(condensed, method=method)


def cut_tree(
    linkage_matrix: np.ndarray,
    n_clusters: int,
) -> np.ndarray:
    """Cut a hierarchical clustering tree to obtain cluster labels.

    Parameters
    ----------
    linkage_matrix : np.ndarray
    n_clusters : int

    Returns
    -------
    np.ndarray, shape (n,)
        Cluster labels (1-indexed).
    """
    return fcluster(linkage_matrix, t=n_clusters, criterion='maxclust')


def kmeans_genotypes(
    pc_coords: np.ndarray,
    K: int,
    max_iter: int = 300,
    n_init: int = 10,
    seed: int = 42,
) -> Tuple[np.ndarray, np.ndarray]:
    """K-means clustering in PCA space.

    Parameters
    ----------
    pc_coords : np.ndarray, shape (n_samples, n_dims)
    K : int
        Number of clusters.
    max_iter : int
    n_init : int
        Number of random restarts.
    seed : int

    Returns
    -------
    labels : np.ndarray, shape (n_samples,)
        Cluster assignments (0-indexed).
    centroids : np.ndarray, shape (K, n_dims)
    """
    rng = np.random.default_rng(seed)
    best_labels = None
    best_inertia = np.inf
    best_centroids = None

    for _ in range(n_init):
        # Random initialisation
        idx = rng.choice(len(pc_coords), size=K, replace=False)
        centroids = pc_coords[idx].copy()

        for _ in range(max_iter):
            # Assign
            dists = np.linalg.norm(
                pc_coords[:, None, :] - centroids[None, :, :], axis=2
            )
            labels = dists.argmin(axis=1)

            # Update
            new_centroids = np.zeros_like(centroids)
            for k in range(K):
                members = pc_coords[labels == k]
                if len(members) > 0:
                    new_centroids[k] = members.mean(axis=0)
                else:
                    new_centroids[k] = centroids[k]

            if np.allclose(centroids, new_centroids):
                break
            centroids = new_centroids

        inertia = sum(
            np.sum((pc_coords[labels == k] - centroids[k]) ** 2)
            for k in range(K)
        )
        if inertia < best_inertia:
            best_inertia = inertia
            best_labels = labels
            best_centroids = centroids

    return best_labels, best_centroids


def cluster_diversity(
    genotypes: np.ndarray,
    cluster_labels: np.ndarray,
    sample_ids: List[str],
) -> Dict[int, float]:
    """Compute mean nucleotide diversity (pi) per cluster.

    pi = mean over loci of 2p(1-p) within each cluster.

    Parameters
    ----------
    genotypes : np.ndarray, shape (n_variants, n_samples)
    cluster_labels : np.ndarray, shape (n_samples,)
    sample_ids : list of str (unused, kept for API consistency)

    Returns
    -------
    dict
        Maps cluster label to mean pi.
    """
    result = {}
    for k in np.unique(cluster_labels):
        idx = np.where(cluster_labels == k)[0]
        if len(idx) < 2:
            result[int(k)] = 0.0
            continue
        p = genotypes[:, idx].mean(axis=1) / 2.0
        pi = 2.0 * p * (1.0 - p)
        result[int(k)] = float(pi.mean())
    return result

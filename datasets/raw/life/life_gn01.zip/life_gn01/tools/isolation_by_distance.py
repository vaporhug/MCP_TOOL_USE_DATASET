"""Isolation-by-distance and spatial genetic structure analysis."""

import numpy as np
from scipy import stats
from scipy.spatial.distance import pdist, squareform
from typing import Dict, List, Tuple


def geographic_distance_matrix(
    pop_coords: Dict[int, Dict[str, float]],
    pop_ids: List[int],
) -> np.ndarray:
    """Compute pairwise great-circle distances between populations.

    Parameters
    ----------
    pop_coords : dict
        Maps population ID to dict with 'latitude', 'longitude' (degrees).
    pop_ids : list of int
        Population IDs in the desired row/column order.

    Returns
    -------
    np.ndarray, shape (n_pops, n_pops)
        Distance matrix in kilometres.
    """
    R = 6371.0  # Earth's radius in km
    coords_rad = []
    for pid in pop_ids:
        lat = np.radians(pop_coords[pid]['latitude'])
        lon = np.radians(pop_coords[pid]['longitude'])
        coords_rad.append((lat, lon))

    n = len(pop_ids)
    dist = np.zeros((n, n))
    for i in range(n):
        for j in range(i + 1, n):
            lat1, lon1 = coords_rad[i]
            lat2, lon2 = coords_rad[j]
            dlat = lat2 - lat1
            dlon = lon2 - lon1
            a = np.sin(dlat / 2) ** 2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon / 2) ** 2
            c = 2 * np.arctan2(np.sqrt(a), np.sqrt(1 - a))
            d = R * c
            dist[i, j] = d
            dist[j, i] = d
    return dist


def mantel_test(
    dist_matrix_a: np.ndarray,
    dist_matrix_b: np.ndarray,
    n_permutations: int = 999,
    seed: int = 42,
) -> Tuple[float, float]:
    """Mantel test for correlation between two distance matrices.

    Computes the Pearson correlation between the upper-triangle
    elements of two square distance matrices and assesses significance
    by permuting rows/columns.

    Parameters
    ----------
    dist_matrix_a : np.ndarray, shape (n, n)
    dist_matrix_b : np.ndarray, shape (n, n)
    n_permutations : int
    seed : int

    Returns
    -------
    r : float
        Observed Mantel correlation coefficient.
    p_value : float
        One-sided p-value (proportion of permuted r >= observed r).
    """
    n = dist_matrix_a.shape[0]
    # Extract upper triangle
    idx = np.triu_indices(n, k=1)
    vec_a = dist_matrix_a[idx]
    vec_b = dist_matrix_b[idx]

    r_obs = np.corrcoef(vec_a, vec_b)[0, 1]

    rng = np.random.default_rng(seed)
    count = 0
    for _ in range(n_permutations):
        perm = rng.permutation(n)
        perm_b = dist_matrix_b[np.ix_(perm, perm)]
        r_perm = np.corrcoef(vec_a, perm_b[idx])[0, 1]
        if r_perm >= r_obs:
            count += 1

    p_value = (count + 1) / (n_permutations + 1)
    return r_obs, p_value


def linearise_fst(fst_matrix: np.ndarray) -> np.ndarray:
    """Linearise Fst values as Fst / (1 - Fst).

    Used for isolation-by-distance regression following
    Rousset (1997). Negative Fst values are set to zero.

    Parameters
    ----------
    fst_matrix : np.ndarray, shape (n, n)

    Returns
    -------
    np.ndarray, shape (n, n)
    """
    fst = np.clip(fst_matrix, 0, None)
    denom = 1.0 - fst
    denom[denom == 0] = 1e-10
    return fst / denom


def ibd_regression(
    fst_matrix: np.ndarray,
    geo_dist_matrix: np.ndarray,
    log_distance: bool = True,
) -> Dict[str, float]:
    """Regress linearised Fst on geographic distance (IBD).

    Parameters
    ----------
    fst_matrix : np.ndarray, shape (n, n)
    geo_dist_matrix : np.ndarray, shape (n, n)
    log_distance : bool
        If True, use log(distance) as the predictor (appropriate for
        two-dimensional habitat).

    Returns
    -------
    dict
        Keys: 'slope', 'intercept', 'r_value', 'p_value', 'r_squared'.
    """
    n = fst_matrix.shape[0]
    idx = np.triu_indices(n, k=1)

    fst_lin = linearise_fst(fst_matrix)
    y = fst_lin[idx]

    x = geo_dist_matrix[idx]
    if log_distance:
        x = np.log(x + 1)  # +1 to avoid log(0)

    slope, intercept, r_value, p_value, std_err = stats.linregress(x, y)
    return {
        'slope': slope,
        'intercept': intercept,
        'r_value': r_value,
        'p_value': p_value,
        'r_squared': r_value ** 2,
    }

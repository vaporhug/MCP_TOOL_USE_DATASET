"""Association testing between genotypes and phenotypes."""

import numpy as np
from scipy import stats
from typing import List, Tuple, Optional, Dict


def linear_association_test(
    genotypes: np.ndarray,
    phenotype: np.ndarray,
    covariates: Optional[np.ndarray] = None,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Test association between each variant and a continuous phenotype.

    Fits a simple linear model per variant: phenotype ~ genotype (+covariates)
    and returns the genotype effect size, standard error and p-value.

    When covariates are provided, the phenotype and genotype are first
    residualised on the covariates.

    Parameters
    ----------
    genotypes : np.ndarray, shape (n_variants, n_samples)
    phenotype : np.ndarray, shape (n_samples,)
    covariates : np.ndarray or None, shape (n_samples, n_covariates)

    Returns
    -------
    betas : np.ndarray, shape (n_variants,)
        Effect sizes (slopes).
    se : np.ndarray, shape (n_variants,)
        Standard errors of effect sizes.
    p_values : np.ndarray, shape (n_variants,)
    """
    y = phenotype.copy()
    G = genotypes.copy()

    # Remove samples with NaN phenotype
    valid = ~np.isnan(y)
    y = y[valid]
    G = G[:, valid]

    if covariates is not None:
        cov = covariates[valid]
        # Residualise y and G on covariates.
        # cov has shape (n_samples, n_covariates); cov_pinv has shape
        # (n_covariates, n_samples). For a sample-vector v (length n_samples)
        # the fitted values are cov @ (cov_pinv @ v) and the residual is
        # v - cov @ (cov_pinv @ v).
        cov_pinv = np.linalg.pinv(cov)
        y = y - cov @ (cov_pinv @ y)
        # Residualise each row of G (each row is a sample-vector). The hat
        # projection is applied on the sample axis: G_resid = G - (G @ H.T)
        # where H = cov @ cov_pinv is the (n_samples, n_samples) hat matrix.
        # Computed without forming H explicitly:
        G = G - (G @ cov_pinv.T) @ cov.T  # shape stays (n_variants, n_samples)

    n = len(y)
    n_var = G.shape[0]

    betas = np.zeros(n_var)
    se = np.zeros(n_var)
    p_values = np.ones(n_var)

    for i in range(n_var):
        x = G[i]
        x_var = np.var(x)
        if x_var < 1e-10:
            continue
        slope, intercept, r_value, p_value, std_err = stats.linregress(x, y)
        betas[i] = slope
        se[i] = std_err
        p_values[i] = p_value

    return betas, se, p_values


def chi2_association_test(
    genotypes: np.ndarray,
    group_labels: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray]:
    """Chi-squared test for genotype-group association per variant.

    Tests whether allele frequency differs between groups using
    a chi-squared test of independence on the allele count table.

    Parameters
    ----------
    genotypes : np.ndarray, shape (n_variants, n_samples)
    group_labels : np.ndarray, shape (n_samples,)
        Group assignment for each sample.

    Returns
    -------
    chi2_stats : np.ndarray, shape (n_variants,)
    p_values : np.ndarray, shape (n_variants,)
    """
    groups = np.unique(group_labels)
    n_var = genotypes.shape[0]
    chi2_stats = np.zeros(n_var)
    p_values = np.ones(n_var)

    for i in range(n_var):
        # For each group: count of ref alleles, alt alleles
        table = []
        for g in groups:
            idx = group_labels == g
            dosages = genotypes[i, idx]
            n_ind = idx.sum()
            alt_count = dosages.sum()
            ref_count = 2 * n_ind - alt_count
            table.append([ref_count, alt_count])

        table = np.array(table)
        if table.min() < 0:
            continue
        try:
            chi2, p, _, _ = stats.chi2_contingency(table)
            chi2_stats[i] = chi2
            p_values[i] = p
        except ValueError:
            pass

    return chi2_stats, p_values


def genomic_inflation_factor(p_values: np.ndarray) -> float:
    """Compute the genomic inflation factor (lambda).

    Lambda is the ratio of the median observed chi-squared statistic
    to the expected median under the null (chi2 with 1 df).

    Parameters
    ----------
    p_values : np.ndarray
        P-values from association tests (excluding NaN/zero).

    Returns
    -------
    float
        Genomic inflation factor. Values near 1.0 indicate no inflation.
    """
    valid = (p_values > 0) & (p_values < 1) & ~np.isnan(p_values)
    chi2_obs = stats.chi2.ppf(1.0 - p_values[valid], df=1)
    expected_median = stats.chi2.ppf(0.5, df=1)
    return float(np.median(chi2_obs) / expected_median)

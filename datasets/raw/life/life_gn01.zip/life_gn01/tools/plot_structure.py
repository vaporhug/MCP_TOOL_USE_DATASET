"""Plotting functions for population structure visualisation."""

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from typing import List, Optional, Dict


def plot_admixture_barplot(
    Q: np.ndarray,
    sample_labels: Optional[np.ndarray] = None,
    sort_by_cluster: bool = True,
    cluster_names: Optional[List[str]] = None,
    title: str = 'Ancestry Proportions',
    output_path: str = 'admixture_barplot.png',
    figsize: tuple = (16, 4),
) -> str:
    """Stacked barplot of ancestry proportions per individual.

    Parameters
    ----------
    Q : np.ndarray, shape (n_samples, K)
        Ancestry proportions. Each row sums to 1.
    sample_labels : np.ndarray or None, shape (n_samples,)
        Labels for grouping (e.g. population or country).
    sort_by_cluster : bool
        If True, sort individuals by their dominant ancestry component.
    cluster_names : list of str or None
        Names for each ancestry component.
    title : str
    output_path : str
    figsize : tuple

    Returns
    -------
    str
        Path to saved figure.
    """
    K = Q.shape[1]
    n = Q.shape[0]

    if cluster_names is None:
        cluster_names = [f'Cluster {i+1}' for i in range(K)]

    # Sort
    if sort_by_cluster:
        if sample_labels is not None:
            # Sort by label first, then by dominant cluster
            order = np.lexsort((Q.argmax(axis=1), sample_labels))
        else:
            order = np.argsort(Q.argmax(axis=1))
    else:
        order = np.arange(n)

    Q_sorted = Q[order]
    colors = plt.cm.Set2(np.linspace(0, 1, K))

    fig, ax = plt.subplots(figsize=figsize)
    x = np.arange(n)
    bottom = np.zeros(n)

    for k in range(K):
        ax.bar(x, Q_sorted[:, k], bottom=bottom, width=1.0,
               color=colors[k], label=cluster_names[k], linewidth=0)
        bottom += Q_sorted[:, k]

    ax.set_xlim(-0.5, n - 0.5)
    ax.set_ylim(0, 1)
    ax.set_xlabel('Individuals', fontsize=11)
    ax.set_ylabel('Ancestry Proportion', fontsize=11)
    ax.set_title(title, fontsize=13)
    ax.legend(loc='upper right', fontsize=9)
    ax.set_xticks([])

    # Add population boundaries if labels provided
    if sample_labels is not None:
        sorted_labels = sample_labels[order]
        boundaries = []
        for i in range(1, n):
            if sorted_labels[i] != sorted_labels[i - 1]:
                boundaries.append(i)
        for b in boundaries:
            ax.axvline(b - 0.5, color='black', linewidth=0.3, alpha=0.5)

    fig.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close(fig)
    return output_path


def plot_fst_heatmap(
    fst_matrix: np.ndarray,
    pop_ids: List[int],
    pop_coords: Optional[Dict[int, Dict[str, float]]] = None,
    title: str = 'Pairwise Fst',
    output_path: str = 'fst_heatmap.png',
    figsize: tuple = (12, 10),
) -> str:
    """Heatmap of pairwise Fst values.

    Parameters
    ----------
    fst_matrix : np.ndarray, shape (n_pops, n_pops)
    pop_ids : list of int
    pop_coords : dict or None
        If provided, sort populations by longitude.
    title : str
    output_path : str
    figsize : tuple

    Returns
    -------
    str
    """
    if pop_coords is not None:
        # Sort by longitude
        sort_idx = sorted(
            range(len(pop_ids)),
            key=lambda i: pop_coords.get(pop_ids[i], {}).get('longitude', 0)
        )
        fst_matrix = fst_matrix[np.ix_(sort_idx, sort_idx)]
        pop_ids = [pop_ids[i] for i in sort_idx]

    fig, ax = plt.subplots(figsize=figsize)
    im = ax.imshow(fst_matrix, cmap='YlOrRd', aspect='equal')
    plt.colorbar(im, ax=ax, label='Fst', shrink=0.8)

    if len(pop_ids) <= 30:
        ax.set_xticks(range(len(pop_ids)))
        ax.set_yticks(range(len(pop_ids)))
        ax.set_xticklabels(pop_ids, fontsize=6, rotation=90)
        ax.set_yticklabels(pop_ids, fontsize=6)

    ax.set_title(title, fontsize=13)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close(fig)
    return output_path


def plot_ibd(
    geo_distances: np.ndarray,
    fst_linearised: np.ndarray,
    slope: float,
    intercept: float,
    r_squared: float,
    log_distance: bool = True,
    output_path: str = 'ibd_plot.png',
    figsize: tuple = (8, 6),
) -> str:
    """Isolation-by-distance scatter with regression line.

    Parameters
    ----------
    geo_distances : np.ndarray
        Pairwise geographic distances (upper triangle values).
    fst_linearised : np.ndarray
        Linearised Fst values (Fst/(1-Fst), upper triangle values).
    slope, intercept, r_squared : float
        Regression parameters.
    output_path : str
    figsize : tuple

    Returns
    -------
    str
    """
    fig, ax = plt.subplots(figsize=figsize)
    x_values = np.log(np.asarray(geo_distances) + 1.0) if log_distance else np.asarray(geo_distances)
    ax.scatter(x_values, fst_linearised, s=3, alpha=0.3, c='steelblue')

    x_range = np.linspace(x_values.min(), x_values.max(), 100)
    ax.plot(x_range, slope * x_range + intercept, 'r-', linewidth=1.5,
            label=f'R² = {r_squared:.3f}')

    xlabel = 'log(Geographic Distance + 1 km)' if log_distance else 'Geographic Distance (km)'
    ax.set_xlabel(xlabel, fontsize=12)
    ax.set_ylabel('Fst / (1 - Fst)', fontsize=12)
    ax.set_title('Isolation by Distance', fontsize=14)
    ax.legend(fontsize=11)

    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return output_path


def plot_geographic_map(
    longitudes: np.ndarray,
    latitudes: np.ndarray,
    cluster_labels: np.ndarray,
    cluster_names: Optional[List[str]] = None,
    title: str = 'Geographic Distribution of Genetic Clusters',
    output_path: str = 'geographic_map.png',
    figsize: tuple = (12, 8),
) -> str:
    """Map of sample locations coloured by genetic cluster.

    Parameters
    ----------
    longitudes, latitudes : np.ndarray, shape (n,)
    cluster_labels : np.ndarray, shape (n,)
    cluster_names : list of str or None
    title : str
    output_path : str
    figsize : tuple

    Returns
    -------
    str
    """
    fig, ax = plt.subplots(figsize=figsize)
    unique_clusters = sorted(set(cluster_labels))
    colors = plt.cm.Set1(np.linspace(0, 0.8, len(unique_clusters)))

    for i, cl in enumerate(unique_clusters):
        mask = cluster_labels == cl
        name = cluster_names[i] if cluster_names else f'Cluster {cl}'
        ax.scatter(longitudes[mask], latitudes[mask], c=[colors[i]],
                   label=name, s=30, alpha=0.7, edgecolors='k', linewidths=0.3)

    ax.set_xlabel('Longitude', fontsize=12)
    ax.set_ylabel('Latitude', fontsize=12)
    ax.set_title(title, fontsize=14)
    ax.legend(fontsize=10)

    fig.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close(fig)
    return output_path

"""Admixture-like ancestry estimation via non-negative matrix factorization."""

import numpy as np
from typing import Tuple, Optional


def estimate_ancestry(
    genotypes: np.ndarray,
    K: int = 3,
    max_iter: int = 200,
    tol: float = 1e-4,
    seed: int = 42,
) -> Tuple[np.ndarray, np.ndarray, float]:
    """Estimate individual ancestry proportions using NMF.

    Approximates the genotype frequency matrix G (n_variants x n_samples)
    as the product F @ Q^T, where F (n_variants x K) contains
    population-specific allele frequencies and Q (n_samples x K) contains
    ancestry proportions. Q rows sum to 1.

    Uses multiplicative update rules for NMF with L2 regularisation,
    followed by row-normalisation of Q.

    Parameters
    ----------
    genotypes : np.ndarray, shape (n_variants, n_samples)
        Raw allele-dosage matrix with entries in {0, 1, 2}. The function
        internally divides by 2 to obtain allele frequencies in [0, 1];
        callers should pass the unscaled dosage matrix.
    K : int
        Number of ancestral populations to infer.
    max_iter : int
        Maximum number of update iterations.
    tol : float
        Convergence tolerance on relative change in reconstruction error.
    seed : int
        Random seed for initialisation.

    Returns
    -------
    Q : np.ndarray, shape (n_samples, K)
        Ancestry proportions. Each row sums to 1.
    F : np.ndarray, shape (n_variants, K)
        Estimated allele frequencies per ancestral population.
    error : float
        Final Frobenius norm of the residual.
    """
    rng = np.random.default_rng(seed)
    n_var, n_samp = genotypes.shape
    G = genotypes / 2.0  # scale to [0, 1]

    # Clip to avoid log(0)
    G = np.clip(G, 1e-6, 1.0 - 1e-6)

    # Random initialisation
    F = rng.random((n_var, K)) * 0.5 + 0.01
    Q = rng.random((n_samp, K)) * 0.5 + 0.01
    Q = Q / Q.sum(axis=1, keepdims=True)

    prev_error = np.inf
    for iteration in range(max_iter):
        # Update F
        numerator = G @ Q
        denominator = F @ (Q.T @ Q) + 1e-10
        F *= numerator / denominator
        F = np.clip(F, 1e-6, 1.0 - 1e-6)

        # Update Q
        numerator = G.T @ F
        denominator = Q @ (F.T @ F) + 1e-10
        Q *= numerator / denominator

        # Normalise Q rows to sum to 1
        Q = Q / Q.sum(axis=1, keepdims=True)
        Q = np.clip(Q, 1e-6, 1.0 - 1e-6)
        Q = Q / Q.sum(axis=1, keepdims=True)

        # Check convergence
        reconstruction = F @ Q.T
        error = np.linalg.norm(G - reconstruction, 'fro')
        rel_change = abs(prev_error - error) / (prev_error + 1e-10)
        if rel_change < tol:
            break
        prev_error = error

    return Q, F, error


def cross_validation_error(
    genotypes: np.ndarray,
    K_values: list,
    n_folds: int = 5,
    seed: int = 42,
) -> dict:
    """Evaluate ancestry models at different K via cross-validation.

    Masks a random fraction of genotype entries, fits the model on the
    remaining data, and measures prediction error on held-out entries.

    Parameters
    ----------
    genotypes : np.ndarray, shape (n_variants, n_samples)
    K_values : list of int
        Candidate values for K.
    n_folds : int
    seed : int

    Returns
    -------
    dict
        Maps each K to its mean cross-validation error.
    """
    rng = np.random.default_rng(seed)
    G = genotypes / 2.0
    G = np.clip(G, 1e-6, 1.0 - 1e-6)

    n_entries = G.size
    indices = np.arange(n_entries)
    rng.shuffle(indices)
    fold_size = n_entries // n_folds

    results = {}
    for K in K_values:
        errors = []
        for fold in range(n_folds):
            test_idx = indices[fold * fold_size:(fold + 1) * fold_size]
            G_train = G.copy().ravel()
            test_vals = G_train[test_idx].copy()
            # Replace test entries with column means
            G_train_2d = G.copy()
            mask_2d = np.zeros_like(G, dtype=bool)
            mask_2d.ravel()[test_idx] = True
            col_means = G.mean(axis=0)
            for j in range(G.shape[1]):
                G_train_2d[mask_2d[:, j], j] = col_means[j]

            Q, F, _ = estimate_ancestry(G_train_2d * 2, K=K, max_iter=100, seed=seed)
            pred = (F @ Q.T).ravel()[test_idx]
            err = np.mean((test_vals - pred) ** 2)
            errors.append(err)
        results[K] = np.mean(errors)

    return results


def assign_clusters(Q: np.ndarray) -> np.ndarray:
    """Assign each sample to its majority ancestry component.

    Parameters
    ----------
    Q : np.ndarray, shape (n_samples, K)
        Ancestry proportions.

    Returns
    -------
    np.ndarray, shape (n_samples,)
        Cluster label (0-indexed) for each sample.
    """
    return np.argmax(Q, axis=1)

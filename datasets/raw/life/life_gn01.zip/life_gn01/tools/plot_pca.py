"""Plotting functions for PCA results."""

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from typing import List, Optional, Dict


def plot_pca_scatter(
    pc_coords: np.ndarray,
    labels: np.ndarray,
    label_names: Optional[Dict] = None,
    pc_x: int = 0,
    pc_y: int = 1,
    variance_explained: Optional[np.ndarray] = None,
    title: str = 'PCA',
    colormap: str = 'tab20',
    output_path: str = 'pca_scatter.png',
    figsize: tuple = (10, 8),
) -> str:
    """Scatter plot of samples in PCA space, coloured by group label.

    Parameters
    ----------
    pc_coords : np.ndarray, shape (n_samples, n_components)
    labels : np.ndarray, shape (n_samples,)
        Group labels (e.g. population, cluster, country).
    label_names : dict or None
        Maps label values to display names.
    pc_x, pc_y : int
        Which PCs to plot (0-indexed).
    variance_explained : np.ndarray or None
        Fraction of variance for axis labels.
    title : str
    colormap : str
    output_path : str
    figsize : tuple

    Returns
    -------
    str
        Path to the saved figure.
    """
    fig, ax = plt.subplots(figsize=figsize)
    unique_labels = sorted(set(labels))
    cmap = plt.get_cmap(colormap, len(unique_labels))

    for i, lbl in enumerate(unique_labels):
        mask = labels == lbl
        name = label_names.get(lbl, str(lbl)) if label_names else str(lbl)
        ax.scatter(
            pc_coords[mask, pc_x],
            pc_coords[mask, pc_y],
            c=[cmap(i)],
            label=name,
            s=15,
            alpha=0.7,
            edgecolors='none',
        )

    xlabel = f'PC{pc_x + 1}'
    ylabel = f'PC{pc_y + 1}'
    if variance_explained is not None:
        xlabel += f' ({variance_explained[pc_x] * 100:.1f}%)'
        ylabel += f' ({variance_explained[pc_y] * 100:.1f}%)'
    ax.set_xlabel(xlabel, fontsize=12)
    ax.set_ylabel(ylabel, fontsize=12)
    ax.set_title(title, fontsize=14)

    if len(unique_labels) <= 20:
        ax.legend(
            bbox_to_anchor=(1.05, 1), loc='upper left',
            fontsize=8, markerscale=1.5,
        )
    fig.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close(fig)
    return output_path


def plot_pca_geography(
    pc_coords: np.ndarray,
    longitudes: np.ndarray,
    latitudes: np.ndarray,
    pc_x: int = 0,
    pc_y: int = 1,
    variance_explained: Optional[np.ndarray] = None,
    output_path: str = 'pca_geography.png',
    figsize: tuple = (14, 5),
) -> str:
    """Side-by-side: PCA coloured by longitude, and PC1 vs longitude scatter.

    Parameters
    ----------
    pc_coords : np.ndarray, shape (n_samples, n_components)
    longitudes : np.ndarray, shape (n_samples,)
    latitudes : np.ndarray, shape (n_samples,)
    pc_x, pc_y : int
    variance_explained : np.ndarray or None
    output_path : str
    figsize : tuple

    Returns
    -------
    str
        Path to the saved figure.
    """
    fig, axes = plt.subplots(1, 2, figsize=figsize)

    # Left: PCA coloured by longitude
    sc = axes[0].scatter(
        pc_coords[:, pc_x], pc_coords[:, pc_y],
        c=longitudes, cmap='RdYlBu_r', s=12, alpha=0.7,
    )
    plt.colorbar(sc, ax=axes[0], label='Longitude')
    xlabel = f'PC{pc_x + 1}'
    ylabel = f'PC{pc_y + 1}'
    if variance_explained is not None:
        xlabel += f' ({variance_explained[pc_x] * 100:.1f}%)'
        ylabel += f' ({variance_explained[pc_y] * 100:.1f}%)'
    axes[0].set_xlabel(xlabel)
    axes[0].set_ylabel(ylabel)
    axes[0].set_title('PCA coloured by longitude')

    # Right: PC1 vs longitude
    axes[1].scatter(pc_coords[:, pc_x], longitudes, s=12, alpha=0.5, c='steelblue')
    r = np.corrcoef(pc_coords[:, pc_x], longitudes)[0, 1]
    axes[1].set_xlabel(f'PC{pc_x + 1}')
    axes[1].set_ylabel('Longitude')
    axes[1].set_title(f'PC{pc_x + 1} vs Longitude (r = {r:.3f}, R² = {r**2:.3f})')

    fig.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close(fig)
    return output_path


def plot_scree(
    components: np.ndarray,
    pct_variance: np.ndarray,
    output_path: str = 'scree_plot.png',
) -> str:
    """Scree plot showing variance explained per PC.

    Parameters
    ----------
    components : np.ndarray
        Component indices (1-based).
    pct_variance : np.ndarray
        Percentage of variance explained.
    output_path : str

    Returns
    -------
    str
    """
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.bar(components, pct_variance, color='steelblue', alpha=0.8)
    ax.plot(components, np.cumsum(pct_variance), 'ro-', markersize=5)
    ax.set_xlabel('Principal Component')
    ax.set_ylabel('Variance Explained (%)')
    ax.set_title('Scree Plot')
    ax.set_xticks(components)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return output_path

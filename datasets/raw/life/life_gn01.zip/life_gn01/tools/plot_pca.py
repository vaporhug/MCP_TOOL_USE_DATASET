"""Plotting functions for PCA results."""

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from typing import List, Optional, Dict


def plot_pca_scatter(
    pc_coords: np.ndarray,
    labels: np.ndarray,
    label_names: Optional[Dict] = None,
    pc_x: int = 0,
    pc_y: int = 1,
    variance_explained: Optional[np.ndarray] = None,
    title: str = 'PCA',
    colormap: str = 'tab20',
    output_path: str = 'pca_scatter.png',
    figsize: tuple = (10, 8),
) -> str:
    """Scatter plot of samples in PCA space, coloured by group label.

    Parameters
    ----------
    pc_coords : np.ndarray, shape (n_samples, n_components)
    labels : np.ndarray, shape (n_samples,)
        Group labels (e.g. population, cluster, country).
    label_names : dict or None
        Maps label values to display names.
    pc_x, pc_y : int
        Which PCs to plot (0-indexed).
    variance_explained : np.ndarray or None
        Fraction of variance for axis labels.
    title : str
    colormap : str
    output_path : str
    figsize : tuple

    Returns
    -------
    str
        Path to the saved figure.
    """
    fig, ax = plt.subplots(figsize=figsize)
    unique_labels = sorted(set(labels))
    cmap = plt.get_cmap(colormap, len(unique_labels))

    for i, lbl in enumerate(unique_labels):
        mask = labels == lbl
        name = label_names.get(lbl, str(lbl)) if label_names else str(lbl)
        ax.scatter(
            pc_coords[mask, pc_x],
            pc_coords[mask, pc_y],
            c=[cmap(i)],
            label=name,
            s=15,
            alpha=0.7,
            edgecolors='none',
        )

    xlabel = f'PC{pc_x + 1}'
    ylabel = f'PC{pc_y + 1}'
    if variance_explained is not None:
        xlabel += f' ({variance_explained[pc_x] * 100:.1f}%)'
        ylabel += f' ({variance_explained[pc_y] * 100:.1f}%)'
    ax.set_xlabel(xlabel, fontsize=12)
    ax.set_ylabel(ylabel, fontsize=12)
    ax.set_title(title, fontsize=14)

    if len(unique_labels) <= 20:
        ax.legend(
            bbox_to_anchor=(1.05, 1), loc='upper left',
            fontsize=8, markerscale=1.5,
        )
    fig.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close(fig)
    return output_path


def plot_pca_geography(
    pc_coords: np.ndarray,
    longitudes: np.ndarray,
    latitudes: np.ndarray,
    pc_x: int = 0,
    pc_y: int = 1,
    variance_explained: Optional[np.ndarray] = None,
    output_path: str = 'pca_geography.png',
    figsize: tuple = (14, 5),
) -> str:
    """PCA geography evidence: map-like PCA plus PC1/longitude and PC2/latitude.

    Parameters
    ----------
    pc_coords : np.ndarray, shape (n_samples, n_components)
    longitudes : np.ndarray, shape (n_samples,)
    latitudes : np.ndarray, shape (n_samples,)
    pc_x, pc_y : int
    variance_explained : np.ndarray or None
    output_path : str
    figsize : tuple

    Returns
    -------
    str
        Path to the saved figure.
    """
    fig, axes = plt.subplots(1, 3, figsize=figsize)

    # Left: PCA coloured by longitude
    sc = axes[0].scatter(
        pc_coords[:, pc_x], pc_coords[:, pc_y],
        c=longitudes, cmap='RdYlBu_r', s=12, alpha=0.7,
    )
    plt.colorbar(sc, ax=axes[0], label='Longitude')
    xlabel = f'PC{pc_x + 1}'
    ylabel = f'PC{pc_y + 1}'
    if variance_explained is not None:
        xlabel += f' ({variance_explained[pc_x] * 100:.1f}%)'
        ylabel += f' ({variance_explained[pc_y] * 100:.1f}%)'
    axes[0].set_xlabel(xlabel)
    axes[0].set_ylabel(ylabel)
    axes[0].set_title('PCA coloured by longitude')

    def _fit_axis(pc_values: np.ndarray, coord_values: np.ndarray):
        valid = np.isfinite(pc_values) & np.isfinite(coord_values)
        x = pc_values[valid]
        y = coord_values[valid]
        slope, intercept = np.polyfit(x, y, 1)
        r = np.corrcoef(x, y)[0, 1]
        n = len(x)
        adj_r2 = 1.0 - (1.0 - r**2) * (n - 1) / (n - 2) if n > 2 else np.nan
        return x, y, slope, intercept, r, adj_r2

    # Middle: PC1 vs longitude
    x, y, slope, intercept, r, adj_r2 = _fit_axis(pc_coords[:, pc_x], longitudes)
    axes[1].scatter(pc_coords[:, pc_x], longitudes, s=12, alpha=0.5, c='steelblue')
    x_range = np.linspace(np.nanmin(x), np.nanmax(x), 100)
    axes[1].plot(x_range, slope * x_range + intercept, color='black', lw=1)
    axes[1].set_xlabel(f'PC{pc_x + 1}')
    axes[1].set_ylabel('Longitude')
    axes[1].set_title(f'PC{pc_x + 1} vs Longitude (r = {r:.3f}, adj. R² = {adj_r2:.3f})')

    # Right: PC2 vs latitude
    x, y, slope, intercept, r, adj_r2 = _fit_axis(pc_coords[:, pc_y], latitudes)
    axes[2].scatter(pc_coords[:, pc_y], latitudes, s=12, alpha=0.5, c='darkgreen')
    x_range = np.linspace(np.nanmin(x), np.nanmax(x), 100)
    axes[2].plot(x_range, slope * x_range + intercept, color='black', lw=1)
    axes[2].set_xlabel(f'PC{pc_y + 1}')
    axes[2].set_ylabel('Latitude')
    axes[2].set_title(f'PC{pc_y + 1} vs Latitude (r = {r:.3f}, adj. R² = {adj_r2:.3f})')

    fig.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close(fig)
    return output_path


def plot_scree(
    components: np.ndarray,
    pct_variance: np.ndarray,
    output_path: str = 'scree_plot.png',
) -> str:
    """Scree plot showing variance explained per PC.

    Parameters
    ----------
    components : np.ndarray
        Component indices (1-based).
    pct_variance : np.ndarray
        Percentage of variance explained.
    output_path : str

    Returns
    -------
    str
    """
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.bar(components, pct_variance, color='steelblue', alpha=0.8)
    ax.plot(components, np.cumsum(pct_variance), 'ro-', markersize=5)
    ax.set_xlabel('Principal Component')
    ax.set_ylabel('Variance Explained (%)')
    ax.set_title('Scree Plot')
    ax.set_xticks(components)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return output_path

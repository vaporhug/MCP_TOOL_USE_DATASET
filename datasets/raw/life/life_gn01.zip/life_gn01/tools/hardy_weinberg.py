"""Hardy-Weinberg equilibrium testing."""

import numpy as np
from scipy import stats
from typing import List, Optional, Tuple


def hardy_weinberg_test(
    genotypes: np.ndarray,
    sample_indices: Optional[List[int]] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    """Chi-squared test for Hardy-Weinberg equilibrium per variant.

    For each biallelic variant, compares observed genotype counts
    (AA, Aa, aa) against expected counts under HWE using a chi-squared
    goodness-of-fit test with 1 degree of freedom.

    Parameters
    ----------
    genotypes : np.ndarray, shape (n_variants, n_samples)
        Dosage matrix (0, 1, 2).
    sample_indices : list of int or None
        Subset of samples to test.

    Returns
    -------
    chi2_stats : np.ndarray, shape (n_variants,)
        Chi-squared test statistics.
    p_values : np.ndarray, shape (n_variants,)
        Two-sided p-values from chi-squared distribution with df=1.
    """
    if sample_indices is not None:
        g = genotypes[:, sample_indices]
    else:
        g = genotypes

    n = g.shape[1]
    n_variants = g.shape[0]

    # Round to nearest integer for counting
    g_int = np.round(g).astype(int)

    # Observed counts
    obs_0 = (g_int == 0).sum(axis=1).astype(float)  # homozygous ref
    obs_1 = (g_int == 1).sum(axis=1).astype(float)  # heterozygous
    obs_2 = (g_int == 2).sum(axis=1).astype(float)  # homozygous alt

    # Allele frequencies
    p = (2 * obs_0 + obs_1) / (2 * n)
    q = 1.0 - p

    # Expected counts under HWE
    exp_0 = n * p ** 2
    exp_1 = n * 2 * p * q
    exp_2 = n * q ** 2

    # Chi-squared statistic
    chi2 = np.zeros(n_variants)
    for obs, exp in [(obs_0, exp_0), (obs_1, exp_1), (obs_2, exp_2)]:
        nonzero = exp > 0
        chi2[nonzero] += (obs[nonzero] - exp[nonzero]) ** 2 / exp[nonzero]

    p_values = stats.chi2.sf(chi2, df=1)
    return chi2, p_values


def filter_hwe(
    genotypes: np.ndarray,
    variant_ids: List[str],
    p_threshold: float = 1e-6,
    sample_indices: Optional[List[int]] = None,
) -> Tuple[np.ndarray, List[str]]:
    """Remove variants that deviate significantly from HWE.

    Parameters
    ----------
    genotypes : np.ndarray, shape (n_variants, n_samples)
    variant_ids : list of str
    p_threshold : float
        Variants with HWE p-value below this threshold are removed.
    sample_indices : list of int or None

    Returns
    -------
    filtered_genotypes : np.ndarray
    filtered_variant_ids : list of str
    """
    _, pvals = hardy_weinberg_test(genotypes, sample_indices)
    mask = pvals >= p_threshold
    return genotypes[mask], [v for v, m in zip(variant_ids, mask) if m]

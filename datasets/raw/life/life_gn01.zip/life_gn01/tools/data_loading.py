"""Data loading and preprocessing utilities for genotype and metadata files."""

import csv
import gzip
import numpy as np
from typing import Tuple, Dict, List, Optional


def load_genotype_matrix(
    filepath: str,
    max_variants: Optional[int] = None,
) -> Tuple[np.ndarray, List[str], List[str]]:
    """Load a compressed genotype matrix (0/1/2 dosage format) from CSV.

    Parameters
    ----------
    filepath : str
        Path to gzipped CSV file. First column is variant_id, remaining
        columns are sample IDs. Values are 0, 1, 2, or -1 (missing).
    max_variants : int or None
        If set, load only the first *max_variants* rows. Useful for
        quick exploratory analyses.

    Returns
    -------
    genotypes : np.ndarray, shape (n_variants, n_samples), dtype float64
        Dosage matrix. Missing values (-1) are replaced with the per-variant
        mean allele dosage (mean imputation).
    variant_ids : list of str
        Variant identifiers (e.g. 'Bhaga_1_12345').
    sample_ids : list of str
        Sample identifiers matching the metadata files.
    """
    variant_ids: List[str] = []
    rows: List[List[float]] = []

    opener = gzip.open if filepath.endswith('.gz') else open
    with opener(filepath, 'rt') as fh:
        reader = csv.reader(fh)
        header = next(reader)
        sample_ids = header[1:]

        for i, row in enumerate(reader):
            if max_variants is not None and i >= max_variants:
                break
            variant_ids.append(row[0])
            vals = []
            for v in row[1:]:
                iv = int(v)
                vals.append(float(iv) if iv >= 0 else np.nan)
            rows.append(vals)

    genotypes = np.array(rows, dtype=np.float64)

    # Mean-impute missing values per variant
    for i in range(genotypes.shape[0]):
        mask = np.isnan(genotypes[i])
        if mask.any():
            genotypes[i, mask] = np.nanmean(genotypes[i])

    return genotypes, variant_ids, sample_ids


def load_variant_info(filepath: str) -> List[Dict[str, str]]:
    """Load variant information (chromosome, position) from CSV.

    Parameters
    ----------
    filepath : str
        Path to variant_info.csv with columns variant_id, chrom, pos.

    Returns
    -------
    list of dict
        Each dict has keys 'variant_id', 'chrom', 'pos'.
    """
    records = []
    with open(filepath) as fh:
        reader = csv.DictReader(fh)
        for row in reader:
            records.append(row)
    return records


def load_sample_metadata(filepath: str) -> Dict[str, Dict]:
    """Load sample metadata (population, coordinates, country).

    Parameters
    ----------
    filepath : str
        Path to whitespace-delimited sample metadata file. Expected
        columns: Novogene_ID, population, block, row, tree, latitude,
        longitude, country.

    Returns
    -------
    dict
        Keyed by sample ID (e.g. 'A10'). Values are dicts with keys
        'population' (int), 'latitude' (float), 'longitude' (float),
        'country' (str).
    """
    meta: Dict[str, Dict] = {}
    with open(filepath) as fh:
        lines = fh.readlines()
    for line in lines[1:]:
        parts = line.strip().split()
        sid = parts[0].strip('"')
        meta[sid] = {
            'population': int(parts[1]),
            'latitude': float(parts[5]),
            'longitude': float(parts[6]),
            'country': parts[7].strip('"'),
        }
    return meta


def load_population_coordinates(filepath: str) -> Dict[int, Dict[str, float]]:
    """Load population-level coordinates.

    Parameters
    ----------
    filepath : str
        Path to population_coordinates.txt with columns population,
        longitude, latitude.

    Returns
    -------
    dict
        Keyed by population ID (int). Values are dicts with keys
        'longitude' and 'latitude'.
    """
    coords: Dict[int, Dict[str, float]] = {}
    with open(filepath) as fh:
        lines = fh.readlines()
    for line in lines[1:]:
        parts = line.strip().split()
        try:
            pid = int(parts[0])
        except ValueError:
            continue  # skip non-numeric population IDs (e.g. trial sites)
        coords[pid] = {
            'longitude': float(parts[1]),
            'latitude': float(parts[2]),
        }
    return coords


def load_phenotype_data(filepath: str) -> Dict[str, Dict]:
    """Load phenotype measurements (budburst timing, circumference).

    Parameters
    ----------
    filepath : str
        Path to tab-delimited phenotype file with columns Novogene_ID,
        population, budburst2022, budburst2023, circumference.

    Returns
    -------
    dict
        Keyed by sample ID. Values contain 'population', 'budburst2022',
        'budburst2023', 'circumference' (all numeric; missing as NaN).
    """
    pheno: Dict[str, Dict] = {}
    with open(filepath) as fh:
        lines = fh.readlines()
    for line in lines[1:]:
        parts = line.strip().split()
        sid = parts[0]
        try:
            pheno[sid] = {
                'population': int(parts[1]),
                'budburst2022': float(parts[2]) if parts[2] != 'NA' else np.nan,
                'budburst2023': float(parts[3]) if parts[3] != 'NA' else np.nan,
                'circumference': float(parts[4]) if parts[4] != 'NA' else np.nan,
            }
        except (ValueError, IndexError):
            pass
    return pheno

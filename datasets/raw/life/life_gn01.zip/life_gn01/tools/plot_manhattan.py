"""Manhattan plot and QQ plot for genome-wide association results."""

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from typing import List, Optional


def plot_manhattan(
    p_values: np.ndarray,
    chromosomes: np.ndarray,
    positions: np.ndarray,
    significance_threshold: float = 5e-8,
    suggestive_threshold: float = 1e-5,
    title: str = 'Manhattan Plot',
    output_path: str = 'manhattan_plot.png',
    figsize: tuple = (16, 6),
) -> str:
    """Generate a Manhattan plot of -log10(p) across genomic positions.

    Parameters
    ----------
    p_values : np.ndarray, shape (n_variants,)
    chromosomes : np.ndarray, shape (n_variants,)
        Chromosome labels (string or int).
    positions : np.ndarray, shape (n_variants,)
        Positions in base pairs.
    significance_threshold : float
        Genome-wide significance line.
    suggestive_threshold : float
        Suggestive significance line.
    title : str
    output_path : str
    figsize : tuple

    Returns
    -------
    str
        Path to saved figure.
    """
    fig, ax = plt.subplots(figsize=figsize)

    # Map chromosomes to numeric values for x-axis
    unique_chroms = []
    seen = set()
    for c in chromosomes:
        if c not in seen:
            unique_chroms.append(c)
            seen.add(c)

    chrom_to_num = {c: i for i, c in enumerate(unique_chroms)}

    # Compute cumulative positions
    chrom_offsets = {}
    offset = 0
    for chrom in unique_chroms:
        chrom_offsets[chrom] = offset
        mask = chromosomes == chrom
        if mask.any():
            offset += positions[mask].max() + 1e6  # gap between chromosomes

    x_positions = np.array([
        chrom_offsets[c] + p for c, p in zip(chromosomes, positions)
    ])

    neg_log_p = -np.log10(np.clip(p_values, 1e-300, 1.0))

    # Colour by chromosome
    colors = ['#1f77b4', '#aec7e8']
    chrom_colors = np.array([
        colors[chrom_to_num[c] % 2] for c in chromosomes
    ])

    ax.scatter(x_positions, neg_log_p, c=chrom_colors, s=2, alpha=0.6, rasterized=True)

    # Significance lines
    if significance_threshold > 0:
        ax.axhline(-np.log10(significance_threshold), color='red',
                    linestyle='--', linewidth=0.8, label=f'p = {significance_threshold:.0e}')
    if suggestive_threshold > 0:
        ax.axhline(-np.log10(suggestive_threshold), color='blue',
                    linestyle=':', linewidth=0.8, label=f'p = {suggestive_threshold:.0e}')

    # Chromosome labels
    chrom_centres = []
    for chrom in unique_chroms:
        mask = chromosomes == chrom
        if mask.any():
            chrom_centres.append(x_positions[mask].mean())
        else:
            chrom_centres.append(0)

    # Simplify labels (remove prefix)
    chrom_labels = []
    for c in unique_chroms:
        label = str(c).replace('Bhaga_', '').replace('Bhaga_Unplaced_', 'U')
        chrom_labels.append(label)

    ax.set_xticks(chrom_centres)
    ax.set_xticklabels(chrom_labels, fontsize=7, rotation=45)
    ax.set_xlabel('Chromosome', fontsize=12)
    ax.set_ylabel('-log10(p)', fontsize=12)
    ax.set_title(title, fontsize=14)
    ax.legend(fontsize=9)
    ax.set_xlim(x_positions.min() - 1e6, x_positions.max() + 1e6)

    fig.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close(fig)
    return output_path


def plot_qq(
    p_values: np.ndarray,
    title: str = 'QQ Plot',
    output_path: str = 'qq_plot.png',
    figsize: tuple = (7, 7),
) -> str:
    """Quantile-quantile plot of observed vs expected p-values.

    Parameters
    ----------
    p_values : np.ndarray
        Observed p-values.
    title : str
    output_path : str
    figsize : tuple

    Returns
    -------
    str
        Path to saved figure.
    """
    fig, ax = plt.subplots(figsize=figsize)

    valid = (p_values > 0) & (p_values <= 1) & ~np.isnan(p_values)
    pv = np.sort(p_values[valid])
    n = len(pv)

    expected = -np.log10(np.arange(1, n + 1) / (n + 1))
    observed = -np.log10(pv)

    ax.scatter(expected, observed, s=4, alpha=0.5, c='steelblue', rasterized=True)
    max_val = max(expected.max(), observed.max()) * 1.05
    ax.plot([0, max_val], [0, max_val], 'r--', linewidth=1, label='Expected')

    # Compute lambda
    from scipy import stats as sp_stats
    chi2_obs = sp_stats.chi2.ppf(1.0 - pv, df=1)
    lam = np.median(chi2_obs) / sp_stats.chi2.ppf(0.5, df=1)

    ax.set_xlabel('Expected -log10(p)', fontsize=12)
    ax.set_ylabel('Observed -log10(p)', fontsize=12)
    ax.set_title(f'{title} (λ = {lam:.3f})', fontsize=14)
    ax.legend(fontsize=10)

    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return output_path

"""Linkage disequilibrium computation."""

import numpy as np
from typing import List, Tuple, Optional


def compute_ld_r2(
    genotypes: np.ndarray,
    variant_idx_a: int,
    variant_idx_b: int,
) -> float:
    """Compute squared Pearson correlation (r^2) between two variants.

    Parameters
    ----------
    genotypes : np.ndarray, shape (n_variants, n_samples)
    variant_idx_a : int
        Row index of the first variant.
    variant_idx_b : int
        Row index of the second variant.

    Returns
    -------
    float
        r^2 value in [0, 1].
    """
    a = genotypes[variant_idx_a]
    b = genotypes[variant_idx_b]
    r = np.corrcoef(a, b)[0, 1]
    if np.isnan(r):
        return 0.0
    return r ** 2


def compute_ld_matrix(
    genotypes: np.ndarray,
    variant_indices: Optional[List[int]] = None,
) -> np.ndarray:
    """Compute pairwise LD (r^2) matrix for a set of variants.

    Parameters
    ----------
    genotypes : np.ndarray, shape (n_variants, n_samples)
    variant_indices : list of int or None
        Subset of variant row indices. If None, use all variants
        (may be very large).

    Returns
    -------
    np.ndarray, shape (k, k)
        Symmetric matrix of r^2 values.
    """
    if variant_indices is not None:
        g = genotypes[variant_indices]
    else:
        g = genotypes

    corr = np.corrcoef(g)
    np.fill_diagonal(corr, 1.0)
    corr = np.nan_to_num(corr, nan=0.0)
    return corr ** 2


def ld_pruning(
    genotypes: np.ndarray,
    variant_ids: List[str],
    window_size: int = 50,
    step: int = 10,
    r2_threshold: float = 0.2,
) -> Tuple[np.ndarray, List[str]]:
    """Prune variants in LD using a sliding window approach.

    Within each window, iteratively removes the variant with the
    highest mean r^2 to remaining variants until all pairwise r^2
    values are below the threshold.

    Parameters
    ----------
    genotypes : np.ndarray, shape (n_variants, n_samples)
    variant_ids : list of str
    window_size : int
        Number of variants per window.
    step : int
        Step size for sliding the window.
    r2_threshold : float
        Maximum allowed r^2 between retained variants.

    Returns
    -------
    pruned_genotypes : np.ndarray
    pruned_variant_ids : list of str
    """
    n_var = genotypes.shape[0]
    keep = np.ones(n_var, dtype=bool)

    for start in range(0, n_var, step):
        end = min(start + window_size, n_var)
        window_idx = np.where(keep[start:end])[0] + start

        if len(window_idx) < 2:
            continue

        g_win = genotypes[window_idx]
        corr = np.corrcoef(g_win)
        np.fill_diagonal(corr, 0.0)
        r2 = np.nan_to_num(corr, nan=0.0) ** 2

        while True:
            max_r2 = r2.max()
            if max_r2 < r2_threshold:
                break
            # Remove variant with highest mean r2
            mean_r2 = r2.mean(axis=1)
            worst = mean_r2.argmax()
            keep[window_idx[worst]] = False
            # Update
            window_idx = np.delete(window_idx, worst)
            r2 = np.delete(np.delete(r2, worst, axis=0), worst, axis=1)
            if len(window_idx) < 2:
                break

    return genotypes[keep], [v for v, k in zip(variant_ids, keep) if k]


def compute_ld_decay(
    genotypes: np.ndarray,
    positions: np.ndarray,
    n_bins: int = 50,
    max_distance: int = 500000,
    n_sample_pairs: int = 50000,
) -> Tuple[np.ndarray, np.ndarray]:
    """Estimate LD decay as a function of physical distance.

    Randomly samples variant pairs, computes r^2, and bins by
    inter-variant distance.

    Parameters
    ----------
    genotypes : np.ndarray, shape (n_variants, n_samples)
    positions : np.ndarray, shape (n_variants,)
        Physical positions in base pairs.
    n_bins : int
    max_distance : int
        Maximum distance in bp to consider.
    n_sample_pairs : int
        Number of random variant pairs to sample.

    Returns
    -------
    bin_midpoints : np.ndarray, shape (n_bins,)
        Distance bin midpoints in bp.
    mean_r2 : np.ndarray, shape (n_bins,)
        Mean r^2 per distance bin.
    """
    rng = np.random.default_rng(42)
    n_var = genotypes.shape[0]

    distances = []
    r2_values = []

    for _ in range(n_sample_pairs):
        i, j = rng.choice(n_var, size=2, replace=False)
        d = abs(int(positions[i]) - int(positions[j]))
        if d > max_distance:
            continue
        r = np.corrcoef(genotypes[i], genotypes[j])[0, 1]
        if np.isnan(r):
            continue
        distances.append(d)
        r2_values.append(r ** 2)

    distances = np.array(distances)
    r2_values = np.array(r2_values)

    bin_edges = np.linspace(0, max_distance, n_bins + 1)
    bin_midpoints = (bin_edges[:-1] + bin_edges[1:]) / 2
    mean_r2 = np.zeros(n_bins)

    for b in range(n_bins):
        mask = (distances >= bin_edges[b]) & (distances < bin_edges[b + 1])
        if mask.sum() > 0:
            mean_r2[b] = r2_values[mask].mean()

    return bin_midpoints, mean_r2

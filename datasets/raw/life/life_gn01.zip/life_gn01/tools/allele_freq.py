"""Allele frequency computation and related statistics."""

import numpy as np
from typing import List, Optional, Dict, Tuple


def compute_allele_frequencies(
    genotypes: np.ndarray,
    sample_indices: Optional[List[int]] = None,
) -> np.ndarray:
    """Compute per-variant alternative allele frequencies.

    Parameters
    ----------
    genotypes : np.ndarray, shape (n_variants, n_samples)
        Dosage matrix (0/1/2).
    sample_indices : list of int or None
        If provided, compute frequencies only for these sample columns.

    Returns
    -------
    np.ndarray, shape (n_variants,)
        Alternative allele frequency for each variant, in [0, 1].
    """
    if sample_indices is not None:
        g = genotypes[:, sample_indices]
    else:
        g = genotypes
    return g.mean(axis=1) / 2.0


def compute_minor_allele_frequency(
    genotypes: np.ndarray,
    sample_indices: Optional[List[int]] = None,
) -> np.ndarray:
    """Compute per-variant minor allele frequency (MAF).

    Parameters
    ----------
    genotypes : np.ndarray, shape (n_variants, n_samples)
    sample_indices : list of int or None

    Returns
    -------
    np.ndarray, shape (n_variants,)
        MAF values in [0, 0.5].
    """
    af = compute_allele_frequencies(genotypes, sample_indices)
    return np.minimum(af, 1.0 - af)


def filter_variants_by_maf(
    genotypes: np.ndarray,
    variant_ids: List[str],
    min_maf: float = 0.01,
) -> Tuple[np.ndarray, List[str]]:
    """Remove variants below a minor allele frequency threshold.

    Parameters
    ----------
    genotypes : np.ndarray, shape (n_variants, n_samples)
    variant_ids : list of str
    min_maf : float
        Minimum MAF to retain a variant.

    Returns
    -------
    filtered_genotypes : np.ndarray
    filtered_variant_ids : list of str
    """
    maf = compute_minor_allele_frequency(genotypes)
    mask = maf >= min_maf
    return genotypes[mask], [v for v, m in zip(variant_ids, mask) if m]


def compute_heterozygosity(
    genotypes: np.ndarray,
    sample_indices: Optional[List[int]] = None,
) -> np.ndarray:
    """Compute observed heterozygosity per variant.

    Parameters
    ----------
    genotypes : np.ndarray, shape (n_variants, n_samples)
    sample_indices : list of int or None

    Returns
    -------
    np.ndarray, shape (n_variants,)
        Proportion of heterozygous genotypes (dosage == 1).
    """
    if sample_indices is not None:
        g = genotypes[:, sample_indices]
    else:
        g = genotypes
    return (np.abs(g - 1.0) < 0.5).mean(axis=1)


def compute_expected_heterozygosity(
    genotypes: np.ndarray,
    sample_indices: Optional[List[int]] = None,
) -> np.ndarray:
    """Compute expected heterozygosity (2pq) per variant.

    Parameters
    ----------
    genotypes : np.ndarray, shape (n_variants, n_samples)
    sample_indices : list of int or None

    Returns
    -------
    np.ndarray, shape (n_variants,)
        Expected heterozygosity under HWE.
    """
    af = compute_allele_frequencies(genotypes, sample_indices)
    return 2.0 * af * (1.0 - af)

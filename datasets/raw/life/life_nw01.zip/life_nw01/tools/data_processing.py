"""Data loading and OTU pre-processing primitives.

These are low-level utilities. They do not encode any SparCC-specific logic.
No scipy/sklearn imports - only numpy + pandas.
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd


def load_otu_counts(path: str) -> pd.DataFrame:
    """Load an OTU count table from CSV.

    The expected layout has rows = OTU ids and columns = sample ids,
    with the first column being the OTU id index.

    Returns a DataFrame of integer counts indexed by OTU id with sample
    ids as columns.
    """
    df = pd.read_csv(path, index_col=0)
    df = df.apply(pd.to_numeric, errors="coerce").fillna(0).astype(int)
    return df


def load_correlation_matrix(path: str) -> pd.DataFrame:
    """Load a square correlation matrix from CSV.

    Used for the ``true_basis_correlations*.csv`` files that ship with
    the task.
    """
    df = pd.read_csv(path, index_col=0)
    return df.astype(float)


def total_counts_per_sample(otu_counts: pd.DataFrame) -> pd.Series:
    """Return total counts per sample (column-sum)."""
    return otu_counts.sum(axis=0)


def total_counts_per_otu(otu_counts: pd.DataFrame) -> pd.Series:
    """Return total counts per OTU (row-sum)."""
    return otu_counts.sum(axis=1)


def filter_low_count_samples(otu_counts: pd.DataFrame, min_total: int = 500) -> pd.DataFrame:
    """Drop samples whose total read count is below ``min_total``.

    The Friedman & Alm 2012 paper restricted HMP samples to those with at
    least 500 reads (Materials and Methods). Default mirrors that choice.
    """
    keep = otu_counts.sum(axis=0) >= int(min_total)
    return otu_counts.loc[:, keep]


def filter_by_prevalence(
    otu_counts: pd.DataFrame, min_mean_count: float = 2.0
) -> pd.DataFrame:
    """Drop OTUs whose mean count across samples is below ``min_mean_count``.

    Mirrors the per-body-site filter "OTUs that were, on average,
    represented by less than 2 reads per sample" from Friedman & Alm
    2012 Materials and Methods.
    """
    keep = otu_counts.mean(axis=1) >= float(min_mean_count)
    return otu_counts.loc[keep, :]


def add_pseudocount(otu_counts: pd.DataFrame, pseudocount: float = 1.0) -> pd.DataFrame:
    """Add a constant pseudocount to a count matrix to remove zeros.

    Returns a float DataFrame with the same shape.
    """
    return otu_counts.astype(float) + float(pseudocount)


def to_relative_abundance(otu_counts: pd.DataFrame) -> pd.DataFrame:
    """Convert raw counts to relative abundances (column-sums to 1)."""
    x = otu_counts.astype(float).values
    s = x.sum(axis=0, keepdims=True)
    s[s == 0] = 1.0
    return pd.DataFrame(x / s, index=otu_counts.index, columns=otu_counts.columns)


def shuffle_columns_independently(
    otu_counts: pd.DataFrame, random_state: Optional[int] = None
) -> pd.DataFrame:
    """Shuffle each OTU row independently across samples.

    This is the "shuffled HMP datasets" baseline of Friedman & Alm 2012:
    the marginal distribution of every OTU is preserved but all
    cross-OTU dependencies are destroyed.
    """
    rng = np.random.default_rng(random_state)
    out = otu_counts.copy()
    arr = out.values.copy()
    for i in range(arr.shape[0]):
        rng.shuffle(arr[i, :])
    return pd.DataFrame(arr, index=out.index, columns=out.columns)


def shannon_entropy(p: np.ndarray) -> float:
    """Shannon entropy of a probability vector (natural log)."""
    p = np.asarray(p, dtype=float)
    p = p[p > 0]
    return float(-(p * np.log(p)).sum())


def effective_number_of_otus(otu_counts: pd.DataFrame) -> float:
    """Per-dataset effective number of OTUs ``n_eff = exp(H)``.

    Following Friedman & Alm 2012 eq. 5: the entropy is computed from
    the mean relative abundance vector across samples, then exponentiated.
    """
    rel = to_relative_abundance(otu_counts)
    mean_p = rel.mean(axis=1).values
    s = mean_p.sum()
    if s > 0:
        mean_p = mean_p / s
    H = shannon_entropy(mean_p)
    return float(np.exp(H))


def dominant_otu_summary(otu_counts: pd.DataFrame) -> Dict[str, float]:
    """Return summary statistics about the most-abundant OTU.

    Output keys: ``otu``, ``mean_relative_abundance``, ``median_relative_abundance``,
    ``n_samples_dominant`` (samples in which it is the single most abundant).
    """
    rel = to_relative_abundance(otu_counts)
    mean_rel = rel.mean(axis=1)
    top = mean_rel.idxmax()
    n_dom = int((rel.idxmax(axis=0) == top).sum())
    return {
        "otu": str(top),
        "mean_relative_abundance": float(mean_rel.loc[top]),
        "median_relative_abundance": float(rel.loc[top].median()),
        "n_samples_dominant": n_dom,
    }


def align_correlation_matrices(
    A: pd.DataFrame, B: pd.DataFrame
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Reorder two correlation matrices so they share the same OTU index.

    Returns ``(A_aligned, B_aligned)`` restricted to the shared OTU set
    in the order of ``A.index``.
    """
    common = [o for o in A.index if o in B.index]
    A2 = A.loc[common, common].copy()
    B2 = B.loc[common, common].copy()
    return A2, B2

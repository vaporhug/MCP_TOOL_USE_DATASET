"""SparCC core algorithm: log-ratio transform, basis variance estimation,
basis correlation extraction, iterative refinement, and bootstrap p-values.

Implements the algorithm of Friedman & Alm 2012 (PLoS Comput Biol 8:e1002687)
from scratch using only numpy / pandas. No scipy required.
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd


# -----------------------------------------------------------------------------
# Composition primitives
# -----------------------------------------------------------------------------


def closure(x: np.ndarray) -> np.ndarray:
    """Project a vector onto the open simplex (sum to 1)."""
    x = np.asarray(x, dtype=float)
    s = x.sum()
    return x / s if s > 0 else x


def dirichlet_posterior_fractions(
    counts: pd.DataFrame, n_draws: int = 1, random_state: Optional[int] = None
) -> np.ndarray:
    """Draw fraction estimates from the Dirichlet(N+1) posterior.

    Returns an array of shape (n_draws, n_otus, n_samples) of relative
    abundances. With ``n_draws=1`` this samples once per call. This
    implements eq. 6 of Friedman & Alm 2012, the Bayesian alternative
    to MAP normalization.
    """
    rng = np.random.default_rng(random_state)
    arr = counts.values.astype(float)
    n_otus, n_samples = arr.shape
    out = np.empty((n_draws, n_otus, n_samples), dtype=float)
    for j in range(n_samples):
        alpha = arr[:, j] + 1.0
        # Dirichlet via independent gammas
        for d in range(n_draws):
            g = rng.gamma(alpha, 1.0)
            out[d, :, j] = g / g.sum()
    return out


def map_fractions(counts: pd.DataFrame, pseudocount: float = 1.0) -> pd.DataFrame:
    """MAP estimate of fractions: (N+pseudocount) / sum(N+pseudocount).

    This is eq. 7 of Friedman & Alm 2012 for ``pseudocount=1``.
    """
    arr = counts.astype(float).values + float(pseudocount)
    arr = arr / arr.sum(axis=0, keepdims=True)
    return pd.DataFrame(arr, index=counts.index, columns=counts.columns)


def clr_transform(fractions: pd.DataFrame) -> pd.DataFrame:
    """Centred log-ratio transform.

    For a composition ``x``, ``clr(x) = log(x) - mean(log(x))``. Applied
    per-sample (per column).
    """
    arr = fractions.astype(float).values
    arr = np.where(arr <= 0, 1e-12, arr)
    log_arr = np.log(arr)
    log_arr = log_arr - log_arr.mean(axis=0, keepdims=True)
    return pd.DataFrame(log_arr, index=fractions.index, columns=fractions.columns)


# -----------------------------------------------------------------------------
# Variation matrix and basis variances
# -----------------------------------------------------------------------------


def variation_matrix(fractions: pd.DataFrame) -> pd.DataFrame:
    """Aitchison's variation matrix ``T_ij = Var(log(x_i / x_j))`` (eq. 8).

    Symmetric with zero diagonal.
    """
    arr = fractions.astype(float).values
    arr = np.where(arr <= 0, 1e-12, arr)
    log_arr = np.log(arr)
    n_otus, n_samples = log_arr.shape
    T = np.zeros((n_otus, n_otus), dtype=float)
    for i in range(n_otus):
        for j in range(i + 1, n_otus):
            v = float(np.var(log_arr[i] - log_arr[j], ddof=1))
            T[i, j] = v
            T[j, i] = v
    return pd.DataFrame(T, index=fractions.index, columns=fractions.index)


def estimate_basis_variances(
    T: pd.DataFrame, excluded: Optional[List[int]] = None
) -> np.ndarray:
    """Solve eq. 13 for basis log-variances ``omega_i^2``.

    Friedman & Alm 2012 reduce eq. 11 to the linear system
    ``M omega^2 = t``, where ``t_i = sum_j T_ij`` (component variation)
    and ``M`` has 1's on the off-diagonal and ``D-1`` on the diagonal.
    Closed-form solution implemented here is equivalent to the numpy
    inversion used in the reference implementation.

    ``excluded`` is the optional list of OTU indices to remove from the
    estimation (used by ``iterative_sparcc``).
    """
    Tm = T.values.copy()
    n = Tm.shape[0]
    if excluded:
        keep = np.array([i for i in range(n) if i not in set(excluded)])
        Tm = Tm[np.ix_(keep, keep)]
    D = Tm.shape[0]
    if D < 4:
        # Underdetermined: variance estimates unreliable. Return ones.
        return np.ones(D)
    # Component variations t_i = sum_j T_ij
    t_vec = Tm.sum(axis=1)
    # System matrix: diagonal=D-1, off-diagonal=1
    M = np.ones((D, D)) + (D - 2) * np.eye(D)
    omega2 = np.linalg.solve(M, t_vec)
    omega2 = np.maximum(omega2, 1e-8)
    return omega2


def basis_correlations_from_omega(
    T: pd.DataFrame, omega2: np.ndarray, otu_names: Optional[List[str]] = None
) -> pd.DataFrame:
    """Plug eq. 10 ``rho_ij = (omega_i^2 + omega_j^2 - T_ij) / (2 omega_i omega_j)``."""
    Tm = T.values
    n = Tm.shape[0]
    omega = np.sqrt(np.asarray(omega2, dtype=float))
    R = np.zeros((n, n), dtype=float)
    for i in range(n):
        for j in range(n):
            if i == j:
                R[i, j] = 1.0
            else:
                R[i, j] = (omega[i] ** 2 + omega[j] ** 2 - Tm[i, j]) / (
                    2.0 * omega[i] * omega[j] + 1e-12
                )
    R = np.clip(R, -1.0, 1.0)
    idx = otu_names or list(T.index)
    return pd.DataFrame(R, index=idx, columns=idx)


# -----------------------------------------------------------------------------
# Iterative SparCC
# -----------------------------------------------------------------------------


def iterative_sparcc(
    fractions: pd.DataFrame,
    threshold: float = 0.1,
    max_iter: int = 20,
) -> pd.DataFrame:
    """Iterative SparCC inference (Fig. 5 of Friedman & Alm 2012).

    Runs the basic procedure, then repeatedly excludes the most strongly
    correlated pair (above ``threshold`` in absolute value) until either
    no new pair exceeds the threshold or ``max_iter`` is reached.

    Default ``threshold=0.1`` and ``max_iter=20`` match the values used
    in the paper (Materials and Methods, "Iterative SparCC").
    """
    T = variation_matrix(fractions)
    n = T.shape[0]
    excluded_pairs: set = set()
    excluded_components: set = set()
    R = None
    for _ in range(int(max_iter)):
        omega2_sub = estimate_basis_variances(T, excluded=list(excluded_components))
        keep = [i for i in range(n) if i not in excluded_components]
        if len(keep) < 4:
            break
        omega2_full = np.ones(n)
        omega2_full[keep] = omega2_sub
        R = basis_correlations_from_omega(T, omega2_full, otu_names=list(T.index))
        # Find strongest absolute correlation pair not yet excluded
        Rv = R.values.copy()
        np.fill_diagonal(Rv, 0.0)
        # Mask excluded indices
        for i in excluded_components:
            Rv[i, :] = 0.0
            Rv[:, i] = 0.0
        for (a, b) in excluded_pairs:
            Rv[a, b] = 0.0
            Rv[b, a] = 0.0
        i_max, j_max = np.unravel_index(np.argmax(np.abs(Rv)), Rv.shape)
        if abs(Rv[i_max, j_max]) <= threshold:
            break
        excluded_pairs.add((min(i_max, j_max), max(i_max, j_max)))
        # Identify components that have only excluded pairs left
        for c in range(n):
            if c in excluded_components:
                continue
            partners = [
                (min(c, k), max(c, k))
                for k in range(n)
                if k != c and k not in excluded_components
            ]
            if partners and all(p in excluded_pairs for p in partners):
                excluded_components.add(c)
    if R is None:
        R = pd.DataFrame(np.eye(n), index=T.index, columns=T.index)
    return R


def sparcc_correlations(
    counts: pd.DataFrame,
    n_draws: int = 100,
    threshold: float = 0.1,
    max_iter: int = 20,
    random_state: Optional[int] = None,
) -> pd.DataFrame:
    """End-to-end SparCC pipeline on a count matrix.

    Repeats fraction sampling ``n_draws`` times (default 100, as in the
    Friedman & Alm 2012 paper) and returns the median basis correlation
    across draws.
    """
    rng = np.random.default_rng(random_state)
    Rs: List[np.ndarray] = []
    for d in range(int(n_draws)):
        seed = int(rng.integers(0, 2**31 - 1))
        post = dirichlet_posterior_fractions(counts, n_draws=1, random_state=seed)[0]
        frac_df = pd.DataFrame(post, index=counts.index, columns=counts.columns)
        R = iterative_sparcc(frac_df, threshold=threshold, max_iter=max_iter)
        Rs.append(R.values)
    Rstack = np.stack(Rs, axis=0)
    Rmed = np.median(Rstack, axis=0)
    Rmed = np.clip(Rmed, -1.0, 1.0)
    return pd.DataFrame(Rmed, index=counts.index, columns=counts.index)


# -----------------------------------------------------------------------------
# Standard Pearson and Spearman baselines on relative abundances
# -----------------------------------------------------------------------------


def pearson_corr_matrix(fractions: pd.DataFrame) -> pd.DataFrame:
    """Pearson correlation between rows (OTUs), computed across samples.

    Operates on relative abundances; serves as the naive baseline used
    in the left column of Fig. 1.
    """
    arr = fractions.astype(float).values
    arr = arr - arr.mean(axis=1, keepdims=True)
    norms = np.linalg.norm(arr, axis=1)
    norms[norms == 0] = 1.0
    R = (arr @ arr.T) / np.outer(norms, norms)
    R = np.clip(R, -1.0, 1.0)
    return pd.DataFrame(R, index=fractions.index, columns=fractions.index)


def rank_rows(arr: np.ndarray) -> np.ndarray:
    """Per-row ranks with ties resolved by averaging."""
    out = np.empty_like(arr, dtype=float)
    n = arr.shape[1]
    for i in range(arr.shape[0]):
        order = np.argsort(arr[i])
        rank = np.empty(n, dtype=float)
        rank[order] = np.arange(1, n + 1)
        out[i] = rank
    return out


def spearman_corr_matrix(fractions: pd.DataFrame) -> pd.DataFrame:
    """Spearman correlation between rows (OTUs).

    Used as a non-parametric baseline (Fig. S2 of the paper).
    """
    ranks = rank_rows(fractions.astype(float).values)
    rdf = pd.DataFrame(ranks, index=fractions.index, columns=fractions.columns)
    return pearson_corr_matrix(rdf)


# -----------------------------------------------------------------------------
# Bootstrap p-values for SparCC correlations
# -----------------------------------------------------------------------------


def bootstrap_pvalues(
    counts: pd.DataFrame,
    observed_R: pd.DataFrame,
    n_bootstrap: int = 100,
    threshold: float = 0.1,
    max_iter: int = 20,
    sparcc_draws: int = 5,
    random_state: Optional[int] = None,
) -> pd.DataFrame:
    """Two-sided bootstrap p-values via column-shuffled null.

    For each bootstrap, every OTU is shuffled across samples
    independently, SparCC is recomputed (with a small ``sparcc_draws``
    to keep runtime reasonable), and the proportion of bootstrap
    correlations whose magnitude meets/exceeds the observed magnitude
    is taken as the empirical p-value.
    """
    rng = np.random.default_rng(random_state)
    abs_obs = np.abs(observed_R.values)
    n_otus = abs_obs.shape[0]
    counter = np.zeros_like(abs_obs, dtype=int)
    for b in range(int(n_bootstrap)):
        seed = int(rng.integers(0, 2**31 - 1))
        rng_b = np.random.default_rng(seed)
        arr = counts.values.copy()
        for i in range(arr.shape[0]):
            rng_b.shuffle(arr[i])
        shuf = pd.DataFrame(arr, index=counts.index, columns=counts.columns)
        Rb = sparcc_correlations(
            shuf,
            n_draws=int(sparcc_draws),
            threshold=threshold,
            max_iter=max_iter,
            random_state=seed,
        )
        counter += (np.abs(Rb.values) >= abs_obs).astype(int)
    p = (counter + 1) / (int(n_bootstrap) + 1)
    np.fill_diagonal(p, 1.0)
    return pd.DataFrame(p, index=observed_R.index, columns=observed_R.columns)

"""Plotting helpers. Every function returns ``{"path": <abs_path>}``.

Pure matplotlib + numpy / pandas. No networkx, scipy, or seaborn.
"""

from __future__ import annotations

import os
from typing import Dict, List, Optional

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def _ensure_dir(path: str) -> str:
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    return os.path.abspath(path)


def _circular_layout(n: int) -> np.ndarray:
    theta = np.linspace(0, 2 * np.pi, n, endpoint=False)
    return np.column_stack([np.cos(theta), np.sin(theta)])


def plot_correlation_heatmap(
    R: pd.DataFrame,
    out_path: str,
    title: str = "Correlation matrix",
    vmin: float = -1.0,
    vmax: float = 1.0,
) -> Dict[str, str]:
    """Render a correlation matrix as a heatmap (red-white-green)."""
    out_path = _ensure_dir(out_path)
    fig, ax = plt.subplots(figsize=(7.5, 6.5))
    cmap = plt.get_cmap("RdYlGn")
    im = ax.imshow(R.values, cmap=cmap, vmin=vmin, vmax=vmax, aspect="auto")
    ax.set_title(title)
    n = R.shape[0]
    step = max(1, n // 10)
    ax.set_xticks(range(0, n, step))
    ax.set_xticklabels(list(R.columns)[::step], rotation=90, fontsize=7)
    ax.set_yticks(range(0, n, step))
    ax.set_yticklabels(list(R.index)[::step], fontsize=7)
    fig.colorbar(im, ax=ax, label="Correlation")
    fig.tight_layout()
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return {"path": out_path}


def plot_correlation_network(
    R: pd.DataFrame,
    out_path: str,
    threshold: float = 0.3,
    node_sizes: Optional[pd.Series] = None,
    title: str = "Correlation network",
) -> Dict[str, str]:
    """Plot OTUs in a circular layout with edges coloured by sign.

    Mirrors the visualization style of Friedman & Alm 2012 Fig. 1 and
    Fig. 4. Green = positive correlation, red = negative correlation,
    edge width scaled by absolute correlation.
    """
    out_path = _ensure_dir(out_path)
    n = R.shape[0]
    pos = _circular_layout(n)
    fig, ax = plt.subplots(figsize=(7.5, 7.5))
    Rv = R.values
    iu = np.triu_indices(n, 1)
    abs_vals = np.abs(Rv[iu])
    for k, (i, j) in enumerate(zip(*iu)):
        v = Rv[i, j]
        if abs(v) < threshold:
            continue
        colour = "#1f9d55" if v > 0 else "#c2003a"
        lw = 0.4 + 4.5 * (abs(v) - threshold) / max(1e-6, 1.0 - threshold)
        alpha = min(1.0, 0.25 + abs(v))
        ax.plot(
            [pos[i, 0], pos[j, 0]],
            [pos[i, 1], pos[j, 1]],
            color=colour,
            linewidth=lw,
            alpha=alpha,
            zorder=1,
        )
    if node_sizes is None:
        sizes = np.full(n, 80.0)
    else:
        s = node_sizes.loc[R.index].values.astype(float)
        s = (s - s.min()) / max(1e-9, (s.max() - s.min()))
        sizes = 40.0 + 600.0 * s
    ax.scatter(pos[:, 0], pos[:, 1], s=sizes, c="#3a3a3a", edgecolor="white", zorder=2)
    ax.set_xlim(-1.25, 1.25)
    ax.set_ylim(-1.25, 1.25)
    ax.set_aspect("equal")
    ax.set_axis_off()
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": out_path}


def plot_degree_distribution(
    degrees: pd.Series, out_path: str, title: str = "Degree distribution"
) -> Dict[str, str]:
    """Histogram + log-log scatter of node degrees."""
    out_path = _ensure_dir(out_path)
    deg = degrees.values.astype(int)
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
    bins = np.arange(0, max(deg) + 2)
    axes[0].hist(deg, bins=bins, color="#3b6cb7", edgecolor="white")
    axes[0].set_xlabel("Degree k")
    axes[0].set_ylabel("Number of OTUs")
    axes[0].set_title(f"{title} (linear)")
    counts, edges = np.histogram(deg, bins=bins)
    centres = (edges[:-1] + edges[1:]) / 2
    mask = counts > 0
    axes[1].loglog(centres[mask], counts[mask], "o-", color="#c2003a")
    axes[1].set_xlabel("Degree k (log)")
    axes[1].set_ylabel("Count (log)")
    axes[1].set_title(f"{title} (log-log)")
    fig.tight_layout()
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return {"path": out_path}


def plot_hub_bar(
    hub_df: pd.DataFrame, out_path: str, title: str = "Top hub OTUs"
) -> Dict[str, str]:
    """Bar chart of top-k hub OTUs by degree, with clustering and
    betweenness annotations.
    """
    out_path = _ensure_dir(out_path)
    fig, ax = plt.subplots(figsize=(8.5, 5.5))
    y = np.arange(len(hub_df))
    ax.barh(y, hub_df["degree"], color="#3b6cb7", edgecolor="white")
    ax.set_yticks(y)
    ax.set_yticklabels(hub_df["otu"])
    ax.invert_yaxis()
    ax.set_xlabel("Node degree")
    ax.set_title(title)
    for i, row in hub_df.iterrows():
        ax.text(
            row["degree"] + 0.1,
            i,
            f"BC={row['betweenness']:.3f}, C={row['clustering']:.2f}",
            va="center",
            fontsize=8,
        )
    fig.tight_layout()
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return {"path": out_path}


def plot_method_rmse_comparison(
    rmse_dict: Dict[str, float],
    out_path: str,
    title: str = "Inference error (eq. 4)",
) -> Dict[str, str]:
    """Bar chart comparing RMSE/MAD of multiple correlation estimators."""
    out_path = _ensure_dir(out_path)
    methods = list(rmse_dict.keys())
    values = [rmse_dict[m] for m in methods]
    fig, ax = plt.subplots(figsize=(7, 4.5))
    bars = ax.bar(methods, values, color=["#c2003a", "#dc8a00", "#3b6cb7", "#1f9d55"][: len(methods)])
    ax.set_ylabel("Mean |rho_hat - rho_true|")
    ax.set_title(title)
    for b, v in zip(bars, values):
        ax.text(b.get_x() + b.get_width() / 2, v + 0.002, f"{v:.3f}", ha="center", fontsize=9)
    fig.tight_layout()
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return {"path": out_path}


def plot_pearson_vs_sparcc_scatter(
    pearson_R: pd.DataFrame,
    sparcc_R: pd.DataFrame,
    out_path: str,
    title: str = "Pearson vs SparCC correlations",
) -> Dict[str, str]:
    """Scatter of upper-triangle Pearson correlations against SparCC."""
    out_path = _ensure_dir(out_path)
    common = [o for o in pearson_R.index if o in sparcc_R.index]
    P = pearson_R.loc[common, common].values
    S = sparcc_R.loc[common, common].values
    iu = np.triu_indices(P.shape[0], 1)
    fig, ax = plt.subplots(figsize=(6.5, 6))
    ax.scatter(S[iu], P[iu], s=10, alpha=0.5, color="#3b6cb7")
    ax.plot([-1, 1], [-1, 1], "k--", linewidth=1)
    ax.axhline(0, color="grey", lw=0.5)
    ax.axvline(0, color="grey", lw=0.5)
    ax.set_xlabel("SparCC correlation")
    ax.set_ylabel("Pearson correlation (relative abundance)")
    ax.set_xlim(-1, 1)
    ax.set_ylim(-1, 1)
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return {"path": out_path}


def plot_pvalue_volcano(
    R: pd.DataFrame, P: pd.DataFrame, out_path: str, title: str = "Volcano plot"
) -> Dict[str, str]:
    """Volcano plot: correlation magnitude vs -log10(p)."""
    out_path = _ensure_dir(out_path)
    n = R.shape[0]
    iu = np.triu_indices(n, 1)
    r = R.values[iu]
    p = P.values[iu]
    p = np.clip(p, 1e-6, 1.0)
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.scatter(r, -np.log10(p), s=8, alpha=0.5, color="#3b6cb7")
    ax.axhline(-np.log10(0.05), color="grey", linestyle="--", lw=0.7, label="p=0.05")
    ax.axvline(0.3, color="#1f9d55", linestyle=":", lw=0.7)
    ax.axvline(-0.3, color="#c2003a", linestyle=":", lw=0.7)
    ax.set_xlabel("SparCC correlation")
    ax.set_ylabel("-log10(p)")
    ax.set_title(title)
    ax.legend(loc="upper right")
    fig.tight_layout()
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return {"path": out_path}

"""Accuracy metrics for inferred correlation matrices vs known ground truth.

Mirrors the evaluation in Friedman & Alm 2012, Materials and Methods:
- ``RMSE = (1 / D(D-1)) sum_{i!=j} |rho_hat - rho_true|`` (eq. 4)
- True/false positive/negative edge counts on the upper triangle
"""

from __future__ import annotations

from typing import Dict, Optional, Tuple

import numpy as np
import pandas as pd


def rmse_correlation(
    estimated: pd.DataFrame, truth: pd.DataFrame
) -> float:
    """Root-mean-square correlation error.

    Provided as a complementary metric to ``mean_abs_correlation_error``.
    Computed over the upper-triangle off-diagonal entries.
    """
    common = [o for o in estimated.index if o in truth.index]
    E = estimated.loc[common, common].values
    T = truth.loc[common, common].values
    D = E.shape[0]
    if D < 2:
        return 0.0
    iu = np.triu_indices(D, 1)
    return float(np.sqrt(np.mean((E[iu] - T[iu]) ** 2)))


def mean_abs_correlation_error(estimated: pd.DataFrame, truth: pd.DataFrame) -> float:
    """Implements eq. 4 literally: sum over i>j only, divide by D(D-1).

    Equivalent to ``0.5 * mean(|E_ij - T_ij|)`` over the upper triangle.
    """
    common = [o for o in estimated.index if o in truth.index]
    E = estimated.loc[common, common].values
    T = truth.loc[common, common].values
    D = E.shape[0]
    if D < 2:
        return 0.0
    iu = np.triu_indices(D, 1)
    return float(np.sum(np.abs(E[iu] - T[iu])) / (D * (D - 1)))


def edge_classification(
    estimated: pd.DataFrame,
    truth: pd.DataFrame,
    threshold: float = 0.3,
) -> Dict[str, int]:
    """True-positive / false-positive / true-negative / false-negative
    edge counts at a magnitude threshold.

    Uses the convention from Friedman & Alm 2012 (Comparison of HMP
    networks): an edge is 'true' if its sign matches across estimated
    and ground-truth networks; 'false-sign' edges count as half a FP +
    half a FN (here we instead report sign-mismatch separately).
    """
    common = [o for o in estimated.index if o in truth.index]
    E = estimated.loc[common, common].values
    T = truth.loc[common, common].values
    D = E.shape[0]
    iu = np.triu_indices(D, 1)
    e = E[iu]
    t = T[iu]
    e_edge = np.abs(e) >= threshold
    t_edge = np.abs(t) >= threshold
    same_sign = np.sign(e) == np.sign(t)
    tp = int(np.sum(e_edge & t_edge & same_sign))
    fp = int(np.sum(e_edge & ~t_edge))
    fn = int(np.sum(~e_edge & t_edge))
    tn = int(np.sum(~e_edge & ~t_edge))
    sign_mismatch = int(np.sum(e_edge & t_edge & ~same_sign))
    return {
        "TP": tp,
        "FP": fp + 0.5 * sign_mismatch,
        "FN": fn + 0.5 * sign_mismatch,
        "TN": tn,
        "sign_mismatch": sign_mismatch,
    }


def precision_recall(metrics: Dict[str, float]) -> Dict[str, float]:
    """Precision, recall and F1 from an ``edge_classification`` result."""
    tp = metrics["TP"]
    fp = metrics["FP"]
    fn = metrics["FN"]
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0
    return {"precision": float(precision), "recall": float(recall), "f1": float(f1)}


def spurious_to_true_ratio(
    pearson: pd.DataFrame, sparcc: pd.DataFrame, threshold: float = 0.3
) -> float:
    """Ratio of Pearson edges that are NOT in the SparCC reference set.

    Matches the paper's claim "3 spurious species-species interactions
    for each true interaction" when SparCC is taken as the reference
    network and Pearson as the comparison network. Returns FP / TP from
    that comparison.
    """
    metrics = edge_classification(pearson, sparcc, threshold=threshold)
    if metrics["TP"] == 0:
        return float("inf")
    return float(metrics["FP"] / metrics["TP"])


def fraction_missed(
    pearson: pd.DataFrame, sparcc: pd.DataFrame, threshold: float = 0.3
) -> float:
    """Fraction of SparCC edges that Pearson misses (FN / (TP + FN))."""
    metrics = edge_classification(pearson, sparcc, threshold=threshold)
    denom = metrics["TP"] + metrics["FN"]
    if denom == 0:
        return 0.0
    return float(metrics["FN"] / denom)

"""Network construction and graph-theoretic metrics for SparCC outputs.

All routines operate on a square correlation DataFrame. Edge filtering by
magnitude (default 0.3 to match the threshold used throughout
Friedman & Alm 2012, e.g. Fig. 1, Fig. 4) is the first step.

Pure numpy/pandas - no networkx dependency. Provides degree,
clustering coefficient, betweenness centrality (Brandes O(VE)),
modularity via greedy label propagation, and label-propagation
community detection.
"""

from __future__ import annotations

from collections import deque
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd


# -----------------------------------------------------------------------------
# Adjacency construction
# -----------------------------------------------------------------------------


def build_adjacency(
    R: pd.DataFrame,
    threshold: float = 0.3,
    pvalues: Optional[pd.DataFrame] = None,
    p_threshold: float = 0.05,
) -> pd.DataFrame:
    """Build a binary adjacency matrix from a correlation matrix.

    A pair ``(i,j)`` is an edge iff ``|R_ij| >= threshold`` and (when
    ``pvalues`` is provided) ``p_ij <= p_threshold``. Default magnitude
    threshold ``0.3`` matches the Friedman & Alm 2012 figure cutoff.
    """
    R = R.copy()
    np.fill_diagonal(R.values, 0.0)
    A = (np.abs(R.values) >= float(threshold)).astype(int)
    if pvalues is not None:
        p = pvalues.loc[R.index, R.columns].values
        A = A & (p <= float(p_threshold))
        A = A.astype(int)
    np.fill_diagonal(A, 0)
    return pd.DataFrame(A, index=R.index, columns=R.columns)


def edge_list_from_adjacency(
    A: pd.DataFrame, R: Optional[pd.DataFrame] = None
) -> pd.DataFrame:
    """Convert an adjacency matrix to a long-format edge list.

    Returns columns ``source``, ``target``, ``weight`` (correlation
    when ``R`` is given, else 1) for the upper triangle only.
    """
    rows = []
    nodes = list(A.index)
    Av = A.values
    Rv = R.values if R is not None else None
    for i in range(len(nodes)):
        for j in range(i + 1, len(nodes)):
            if Av[i, j] != 0:
                w = float(Rv[i, j]) if Rv is not None else 1.0
                rows.append({"source": nodes[i], "target": nodes[j], "weight": w})
    return pd.DataFrame(rows)


def signed_edge_counts(R: pd.DataFrame, threshold: float = 0.3) -> Dict[str, int]:
    """Count positive and negative edges above ``|threshold|`` in the
    upper triangle of ``R``.
    """
    n = R.shape[0]
    iu = np.triu_indices(n, 1)
    vals = R.values[iu]
    return {
        "n_positive": int(np.sum(vals >= threshold)),
        "n_negative": int(np.sum(vals <= -threshold)),
        "n_total": int(np.sum(np.abs(vals) >= threshold)),
    }


# -----------------------------------------------------------------------------
# Degree, clustering, density
# -----------------------------------------------------------------------------


def degree_sequence(A: pd.DataFrame) -> pd.Series:
    """Return the degree of every node as a Series indexed by node id."""
    deg = A.values.sum(axis=1)
    return pd.Series(deg.astype(int), index=A.index, name="degree")


def network_density(A: pd.DataFrame) -> float:
    """Edge density = 2E / (V (V-1))."""
    n = A.shape[0]
    if n < 2:
        return 0.0
    E = int(A.values.sum() // 2)
    return 2.0 * E / (n * (n - 1))


def clustering_coefficient(A: pd.DataFrame) -> pd.Series:
    """Per-node local clustering coefficient (Watts-Strogatz)."""
    Av = A.values.astype(int)
    n = Av.shape[0]
    out = np.zeros(n, dtype=float)
    for i in range(n):
        neighbours = np.where(Av[i] > 0)[0]
        k = len(neighbours)
        if k < 2:
            out[i] = 0.0
            continue
        sub = Av[np.ix_(neighbours, neighbours)]
        triangles = sub.sum() / 2.0
        out[i] = 2.0 * triangles / (k * (k - 1))
    return pd.Series(out, index=A.index, name="clustering")


def average_clustering(A: pd.DataFrame) -> float:
    """Mean local clustering coefficient over all nodes."""
    return float(clustering_coefficient(A).mean())


# -----------------------------------------------------------------------------
# Betweenness centrality (Brandes 2001)
# -----------------------------------------------------------------------------


def betweenness_centrality(A: pd.DataFrame) -> pd.Series:
    """Unweighted Brandes betweenness centrality (normalised to [0,1]).

    O(V * (V + E)). Suitable for the small networks used in this task.
    """
    Av = A.values.astype(int)
    nodes = list(A.index)
    n = len(nodes)
    bc = np.zeros(n, dtype=float)
    nbr = [list(np.where(Av[i] > 0)[0]) for i in range(n)]
    for s in range(n):
        S: List[int] = []
        P: List[List[int]] = [[] for _ in range(n)]
        sigma = np.zeros(n, dtype=float)
        sigma[s] = 1.0
        d = np.full(n, -1, dtype=int)
        d[s] = 0
        Q: deque = deque([s])
        while Q:
            v = Q.popleft()
            S.append(v)
            for w in nbr[v]:
                if d[w] < 0:
                    d[w] = d[v] + 1
                    Q.append(w)
                if d[w] == d[v] + 1:
                    sigma[w] += sigma[v]
                    P[w].append(v)
        delta = np.zeros(n, dtype=float)
        while S:
            w = S.pop()
            for v in P[w]:
                delta[v] += (sigma[v] / sigma[w]) * (1.0 + delta[w])
            if w != s:
                bc[w] += delta[w]
    bc = bc / 2.0  # undirected
    if n > 2:
        bc = bc / ((n - 1) * (n - 2) / 2.0)
    return pd.Series(bc, index=nodes, name="betweenness")


def hub_otus(A: pd.DataFrame, top_k: int = 10) -> pd.DataFrame:
    """Top ``k`` OTUs by node degree.

    Returns DataFrame with columns ``otu``, ``degree``,
    ``clustering``, ``betweenness`` for the leaders.
    """
    deg = degree_sequence(A)
    cc = clustering_coefficient(A)
    bc = betweenness_centrality(A)
    df = pd.DataFrame({"otu": deg.index, "degree": deg.values,
                        "clustering": cc.values, "betweenness": bc.values})
    return df.sort_values("degree", ascending=False).head(int(top_k)).reset_index(drop=True)


# -----------------------------------------------------------------------------
# Modularity & community detection (label propagation)
# -----------------------------------------------------------------------------


def label_propagation_communities(
    A: pd.DataFrame, max_iter: int = 50, random_state: Optional[int] = None
) -> pd.Series:
    """Asynchronous label propagation community detection (Raghavan 2007).

    Each node initially has a unique label; at every iteration nodes
    adopt the most common label among their neighbours, ties broken
    randomly. Converges quickly on small graphs.
    """
    rng = np.random.default_rng(random_state)
    Av = A.values.astype(int)
    n = Av.shape[0]
    labels = np.arange(n)
    for _ in range(int(max_iter)):
        order = rng.permutation(n)
        changed = False
        for v in order:
            nbr = np.where(Av[v] > 0)[0]
            if len(nbr) == 0:
                continue
            counts: Dict[int, int] = {}
            for u in nbr:
                counts[labels[u]] = counts.get(labels[u], 0) + 1
            mx = max(counts.values())
            top = [k for k, c in counts.items() if c == mx]
            new_label = int(rng.choice(top))
            if new_label != labels[v]:
                labels[v] = new_label
                changed = True
        if not changed:
            break
    # Relabel to consecutive integers from 0
    unique = {l: i for i, l in enumerate(sorted(set(labels)))}
    labels = np.array([unique[l] for l in labels])
    return pd.Series(labels, index=A.index, name="community")


def modularity(A: pd.DataFrame, communities: pd.Series) -> float:
    """Newman-Girvan modularity ``Q``.

    ``Q = (1/2m) sum_ij [A_ij - k_i k_j / 2m] delta(c_i, c_j)``.
    """
    Av = A.values.astype(float)
    deg = Av.sum(axis=1)
    m2 = deg.sum()
    if m2 == 0:
        return 0.0
    c = communities.loc[A.index].values
    Q = 0.0
    for i in range(Av.shape[0]):
        for j in range(Av.shape[1]):
            if c[i] == c[j]:
                Q += Av[i, j] - deg[i] * deg[j] / m2
    return float(Q / m2)

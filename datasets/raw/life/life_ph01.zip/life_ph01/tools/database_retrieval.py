"""Stub for external database retrieval. The provided dataset is fully
self-contained, so these functions are documentation-only conveniences."""
from typing import Dict, List


_TAXA_INFO: Dict[str, Dict[str, str]] = {
    "Anolis": {"common": "green anole lizard", "clade": "Squamata"},
    "podarcis": {"common": "European wall lizard", "clade": "Squamata"},
    "python": {"common": "python snake", "clade": "Squamata"},
    "Gallus": {"common": "chicken", "clade": "Aves"},
    "Taeniopygia": {"common": "zebra finch", "clade": "Aves"},
    "alligator": {"common": "alligator", "clade": "Crocodylia"},
    "caiman": {"common": "caiman", "clade": "Crocodylia"},
    "phrynops": {"common": "South American snake-necked turtle",
                  "clade": "Testudines (pleurodire)"},
    "caretta": {"common": "loggerhead sea turtle", "clade": "Testudines"},
    "emys_orbicularis": {"common": "European pond turtle", "clade": "Testudines"},
    "chelonoidis_nigra": {"common": "Galapagos giant tortoise", "clade": "Testudines"},
    "Homo": {"common": "human", "clade": "Mammalia (Eutheria)"},
    "Monodelphis": {"common": "short-tailed opossum",
                    "clade": "Mammalia (Metatheria)"},
    "Ornithorhynchus": {"common": "platypus", "clade": "Mammalia (Monotremata)"},
    "Xenopus": {"common": "African clawed frog", "clade": "Amphibia"},
    "protopterus": {"common": "African lungfish",
                     "clade": "Sarcopterygii (outgroup)"},
}


def get_taxa_metadata(taxa: List[str]) -> Dict[str, Dict[str, str]]:
    """Return common name and major-clade label for each taxon name."""
    return {t: _TAXA_INFO.get(t, {"common": "?", "clade": "?"}) for t in taxa}

"""Per-gene phylogenomic analyses.

Functions assist the agent in: (i) extracting gene-level alignments from a
concatenated supermatrix, (ii) computing per-gene tree statistics, (iii)
quantifying topological agreement between per-gene trees and a reference,
and (iv) detecting outlier genes that disproportionately influence the
concatenated topology, by comparing site-wise log-likelihoods of two
candidate topologies under a JC69 model."""
import math
import numpy as np
from collections import OrderedDict

from .sequence_io import extract_gene_alignment, alignment_summary
from .distance_methods import pairwise_distance_matrix, jc69_distance, k80_distance, proportion_difference
from .tree_building import (
    neighbor_joining, parse_newick, get_clade_set, robinson_foulds_distance,
    branch_length_stats, _all_leaves, _is_leaf,
)


def per_gene_distance_matrices(seqs, partitions, model="k80"):
    """Compute a distance matrix for each partition.

    Returns
    -------
    list of dicts: [{name, taxa, D, n_sites, n_invariant, n_taxa_with_data}]
    """
    out = []
    for p in partitions:
        sub = extract_gene_alignment(seqs, p["start"], p["end"])
        # filter taxa with all-gaps in this partition
        kept = OrderedDict((n, s) for n, s in sub.items() if any(c in "ACGT" for c in s))
        if len(kept) < 4:
            out.append({"name": p["name"], "taxa": list(kept.keys()),
                        "D": None, "n_sites": p["length"],
                        "n_taxa_with_data": len(kept), "skipped": True})
            continue
        taxa, D = pairwise_distance_matrix(kept, model=model)
        out.append({"name": p["name"], "taxa": taxa, "D": D,
                    "n_sites": p["length"], "n_taxa_with_data": len(kept),
                    "skipped": False})
    return out


def summarize_gene_partition_stats(seqs, partitions):
    """Per-gene alignment summary stats for all partitions.

    Returns list of dicts with name, length, n_taxa_with_data, mean_pdist,
    n_variable_sites, n_invariant_sites.
    """
    out = []
    for p in partitions:
        sub = extract_gene_alignment(seqs, p["start"], p["end"])
        # site stats
        L = p["length"]
        n_var = 0
        for col in range(L):
            bases = {sub[t][col] for t in sub if sub[t][col] in "ACGT"}
            if len(bases) > 1:
                n_var += 1
        # mean pdist (subset of pairs to keep it fast for small genes only)
        present = [(n, s) for n, s in sub.items() if any(c in "ACGT" for c in s)]
        ds = []
        for i in range(len(present)):
            for j in range(i + 1, len(present)):
                pd = proportion_difference(present[i][1], present[j][1])
                if not math.isnan(pd["p"]):
                    ds.append(pd["p"])
        out.append({
            "name": p["name"], "length": L,
            "n_taxa_with_data": len(present),
            "n_variable_sites": int(n_var),
            "n_invariant_sites": int(L - n_var),
            "mean_pdistance": float(np.mean(ds)) if ds else float("nan"),
            "max_pdistance": float(np.max(ds)) if ds else float("nan"),
        })
    return out


def per_gene_topology_score(per_gene_distance_results):
    """For each gene, build a NJ tree from its distance matrix and return it.

    Returns list: [{name, tree, taxa, branch_length_total}]
    """
    out = []
    for r in per_gene_distance_results:
        if r.get("skipped"):
            out.append({"name": r["name"], "tree": None, "taxa": r["taxa"]})
            continue
        D = np.nan_to_num(r["D"], nan=1.0, posinf=2.0, neginf=0.0)
        tree = neighbor_joining(r["taxa"], D)
        bl_stats = branch_length_stats(tree)
        out.append({
            "name": r["name"], "tree": tree, "taxa": r["taxa"],
            "branch_length_total": bl_stats["total"],
            "branch_length_mean": bl_stats["mean"],
        })
    return out


def gene_topology_concordance(reference_tree, per_gene_trees):
    """For each gene tree, compute RF distance to a reference tree.

    Returns list: [{name, rf, n_unique_gene, n_unique_ref, leaves_in_common}]
    """
    out = []
    ref_leaves = set(_all_leaves(reference_tree))
    for g in per_gene_trees:
        if g["tree"] is None:
            out.append({"name": g["name"], "rf": None, "leaves_in_common": 0})
            continue
        gene_leaves = set(_all_leaves(g["tree"]))
        common = ref_leaves & gene_leaves
        if len(common) < 4:
            out.append({"name": g["name"], "rf": None, "leaves_in_common": len(common)})
            continue
        # restrict bipartitions to common leaves
        ref_clades = {frozenset(c & common) for c in get_clade_set(reference_tree) if 1 < len(c & common) < len(common)}
        gene_clades = {frozenset(c & common) for c in get_clade_set(g["tree"]) if 1 < len(c & common) < len(common)}
        only_a = ref_clades - gene_clades
        only_b = gene_clades - ref_clades
        out.append({
            "name": g["name"],
            "rf": int(len(only_a) + len(only_b)),
            "n_unique_ref": int(len(only_a)),
            "n_unique_gene": int(len(only_b)),
            "leaves_in_common": int(len(common)),
        })
    return out


# ---------- Likelihood-based outlier detection (JC-LS approximation) ----------

def _jc_lik_distance(p):
    """Convert proportion difference to JC distance, capped."""
    if math.isnan(p):
        return float("nan")
    if p >= 0.74:
        return 1.5
    return -0.75 * math.log(1.0 - 4.0 / 3.0 * p)


def delta_log_likelihood(gene_alignment, topology_a, topology_b, model="jc69"):
    """Compute the difference in least-squares log-likelihood between two
    candidate topologies for a single gene alignment.

    This implements a fast LS-based proxy for the gene-wise log-likelihood
    used in Walker et al. 2018. For each topology we compute branch
    lengths via OLS on the pairwise distance matrix and the residual sum
    of squares; the negative half of the RSS (under a Gaussian noise
    model) is the log-likelihood up to a constant.

    Returns
    -------
    dict: ll_a, ll_b, delta=ll_a-ll_b, n_pairs, n_sites
    """
    taxa, D = pairwise_distance_matrix(gene_alignment, model=model)
    if len(taxa) < 4:
        return {"ll_a": float("nan"), "ll_b": float("nan"),
                "delta": float("nan"), "n_pairs": 0, "n_sites": 0}
    D = np.nan_to_num(D, nan=1.0, posinf=2.0, neginf=0.0)
    n = len(taxa)
    obs = []
    pair_idx = []
    for i in range(n):
        for j in range(i + 1, n):
            obs.append(D[i, j])
            pair_idx.append((i, j))
    obs = np.array(obs)

    def topology_rss(topo):
        edges, taxon_to_id = _enumerate_edges(topo, taxa)
        # design matrix: row per pair, column per edge; entry = 1 if edge on the path
        m = len(obs)
        e = len(edges)
        A = np.zeros((m, e))
        for k, (i, j) in enumerate(pair_idx):
            t1, t2 = taxa[i], taxa[j]
            path = _path_edges(topo, t1, t2)
            for eid in path:
                A[k, eid] = 1.0
        # OLS with non-negativity (use lstsq then clip) — quick and dirty
        x, *_ = np.linalg.lstsq(A, obs, rcond=None)
        x = np.clip(x, 0.0, None)
        pred = A @ x
        rss = float(((obs - pred) ** 2).sum())
        return rss, x

    rss_a, _ = topology_rss(topology_a)
    rss_b, _ = topology_rss(topology_b)
    # log-likelihood under Gaussian = -m/2 * log(rss/m) (up to const)
    m = len(obs)
    ll_a = -0.5 * m * math.log(rss_a / m + 1e-12)
    ll_b = -0.5 * m * math.log(rss_b / m + 1e-12)
    return {"ll_a": float(ll_a), "ll_b": float(ll_b),
            "delta": float(ll_a - ll_b),
            "rss_a": float(rss_a), "rss_b": float(rss_b),
            "n_pairs": int(m), "n_sites": int(len(next(iter(gene_alignment.values()))))}


def _enumerate_edges(tree, taxa):
    """Number internal+external edges of a rooted tree by post-order. Returns
    (list_of_edges, taxon_to_node_id) where each edge is (parent_id, child_id).
    """
    edges = []

    def walk(node, parent):
        nid = id(node)
        for c in node["children"]:
            cid = walk(c, nid)
            edges.append((nid, cid))
        return nid

    walk(tree, None)
    return edges, None


def _path_edges(tree, t1, t2):
    """Return the list of edge indices (in the order returned by
    _enumerate_edges) on the path between two leaves."""
    # walk from each leaf to root, intersect
    parent_of = {}
    edge_id = {}

    def walk(node, parent):
        nid = id(node)
        parent_of[nid] = parent
        for c in node["children"]:
            cid = walk(c, nid)
            edge_id[(nid, cid)] = len(edge_id)
        return nid

    walk(tree, None)

    leaf_id = {}

    def find_leaves(node):
        if _is_leaf(node):
            leaf_id[node["name"]] = id(node)
            return
        for c in node["children"]:
            find_leaves(c)

    find_leaves(tree)
    p1 = []
    cur = leaf_id[t1]
    while cur is not None:
        p1.append(cur)
        cur = parent_of[cur]
    p2 = []
    cur = leaf_id[t2]
    while cur is not None:
        p2.append(cur)
        cur = parent_of[cur]
    set1 = set(p1)
    lca_idx = None
    for i, nid in enumerate(p2):
        if nid in set1:
            lca_idx = nid
            break
    edges = []
    for nid in p1:
        if nid == lca_idx:
            break
        if parent_of[nid] is not None:
            edges.append(edge_id[(parent_of[nid], nid)])
    for nid in p2:
        if nid == lca_idx:
            break
        if parent_of[nid] is not None:
            edges.append(edge_id[(parent_of[nid], nid)])
    return edges


def outlier_gene_score(deltas, threshold_zscore=4.0):
    """Identify outlier genes given a list of delta-log-likelihoods.

    Outliers are flagged if |Δ - median| / MAD > threshold_zscore.

    Parameters
    ----------
    deltas : list of dicts with "name" and "delta".

    Returns
    -------
    dict with keys:
        median, mad, robust_zscores : list aligned to input,
        outliers : list of (name, delta, z) for entries above threshold,
        ranked   : list of (name, delta, |z|) sorted by |z| descending
    """
    arr = np.array([d["delta"] for d in deltas if not math.isnan(d.get("delta", float("nan")))])
    if arr.size == 0:
        return {"median": float("nan"), "mad": float("nan"),
                "robust_zscores": [], "outliers": [], "ranked": []}
    med = float(np.median(arr))
    mad = float(np.median(np.abs(arr - med)))
    if mad == 0:
        mad = 1e-9
    z = []
    for d in deltas:
        delta = d.get("delta", float("nan"))
        zv = (delta - med) / (1.4826 * mad) if not math.isnan(delta) else float("nan")
        z.append({"name": d["name"], "delta": delta, "z": zv})
    outliers = [r for r in z if not math.isnan(r["z"]) and abs(r["z"]) >= threshold_zscore]
    ranked = sorted([r for r in z if not math.isnan(r["z"])],
                    key=lambda r: -abs(r["z"]))
    return {"median": med, "mad": mad, "robust_zscores": z,
            "outliers": outliers, "ranked": ranked}

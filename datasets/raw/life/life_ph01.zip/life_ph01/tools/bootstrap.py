"""Column-resampling bootstrap for phylogenetic trees.

Given an alignment, resample columns with replacement, reconstruct each
replicate's tree (NJ on K80 distances by default), and summarize clade
support and a majority-rule consensus."""
import numpy as np
from collections import Counter, OrderedDict

from .distance_methods import pairwise_distance_matrix
from .tree_building import neighbor_joining, get_clade_set, _all_leaves, _new_node, _is_leaf


def bootstrap_columns(seqs, n_replicates=100, seed=None):
    """Generate a list of resampled alignments (each a {name: seq} dict).

    Parameters
    ----------
    seqs : OrderedDict[str, str]
    n_replicates : int
    seed : int or None
    """
    rng = np.random.default_rng(seed)
    L = len(next(iter(seqs.values())))
    names = list(seqs.keys())
    arr = np.array([[c for c in seqs[n]] for n in names])
    out = []
    for _ in range(n_replicates):
        idx = rng.integers(0, L, L)
        rep_arr = arr[:, idx]
        rep = OrderedDict((names[i], "".join(rep_arr[i])) for i in range(len(names)))
        out.append(rep)
    return out


def build_bootstrap_trees(seqs, n_replicates=100, model="k80", seed=None):
    """Run NJ on each bootstrap replicate. Returns a list of tree dicts."""
    reps = bootstrap_columns(seqs, n_replicates=n_replicates, seed=seed)
    trees = []
    for rep in reps:
        taxa, D = pairwise_distance_matrix(rep, model=model)
        # Replace inf/nan with a large finite number so NJ proceeds
        D = np.nan_to_num(D, nan=1.0, posinf=2.0, neginf=0.0)
        trees.append(neighbor_joining(taxa, D))
    return trees


def clade_support(reference_tree, bootstrap_trees):
    """Compute support (fraction of bootstrap trees containing the same
    clade) for every internal clade in `reference_tree`.

    Returns
    -------
    list of dicts: {clade: frozenset, support: int (count), fraction: float}
    """
    ref_clades = get_clade_set(reference_tree)
    counts = Counter()
    for t in bootstrap_trees:
        for c in get_clade_set(t):
            counts[c] += 1
    n = len(bootstrap_trees)
    out = []
    for c in ref_clades:
        sup = counts.get(c, 0)
        out.append({"clade": tuple(sorted(c)), "support": int(sup),
                    "fraction": sup / n if n > 0 else 0.0})
    return out


def majority_rule_consensus(bootstrap_trees, min_support=0.5):
    """Build a (possibly polytomous) majority-rule consensus tree.

    Returns a tree dict using only clades with support > min_support * n.
    Branch lengths are the mean branch length across replicates for the
    branch leading to that clade (or None if not estimable).
    """
    from collections import defaultdict
    n = len(bootstrap_trees)
    if n == 0:
        return None
    counts = Counter()
    bl_acc = defaultdict(list)
    all_leaves = set(_all_leaves(bootstrap_trees[0]))

    def collect(node, parent_bl=None):
        if _is_leaf(node):
            return {node["name"]}
        leaves = set()
        for c in node["children"]:
            leaves |= collect(c, c["branch_length"])
        if 1 < len(leaves) < len(all_leaves):
            fc = frozenset(leaves)
            counts[fc] += 1
            if parent_bl is not None:
                bl_acc[fc].append(parent_bl)
        return leaves

    for t in bootstrap_trees:
        collect(t)

    keep = sorted([(c, cnt) for c, cnt in counts.items() if cnt > min_support * n],
                  key=lambda x: -len(x[0]))

    # Build a tree from nested clades. Start with all leaves as singletons.
    leaf_nodes = {nm: _new_node(name=nm) for nm in sorted(all_leaves)}
    used = set()
    # Sort keep by smallest first (so we group small clades into bigger ones)
    keep_small_first = sorted(keep, key=lambda x: len(x[0]))
    cluster_nodes = {frozenset({nm}): leaf_nodes[nm] for nm in all_leaves}

    for clade, cnt in keep_small_first:
        # Children are the maximal sub-clades from cluster_nodes that fit inside `clade`
        children = []
        remaining = set(clade)
        sub_clades = sorted([c for c in cluster_nodes if c.issubset(clade) and c != clade],
                            key=lambda x: -len(x))
        for sc in sub_clades:
            if sc.issubset(remaining):
                children.append(cluster_nodes[sc])
                remaining -= sc
                # mark this subclade as consumed
                if sc != frozenset(clade):
                    used.add(sc)
        bl = float(np.mean(bl_acc[clade])) if bl_acc[clade] else None
        node = _new_node(name=str(int(cnt)), bl=bl, children=children)
        cluster_nodes[clade] = node
        for sc in list(used):
            cluster_nodes.pop(sc, None)
        used.clear()

    # Any leaves not in a clade attach at the root
    root_children = []
    consumed = set()
    for cl, nd in sorted(cluster_nodes.items(), key=lambda x: -len(x[0])):
        if cl & consumed:
            continue
        root_children.append(nd)
        consumed |= cl
    return _new_node(children=root_children)


def summarize_bootstrap_distribution(supports):
    """Given list-of-dicts from `clade_support`, return summary stats:
    mean, median, stdev, fraction with support >= 70%."""
    fracs = [s["fraction"] for s in supports]
    if not fracs:
        return {"n": 0}
    arr = np.array(fracs)
    return {
        "n": int(len(fracs)),
        "mean_support": float(arr.mean()),
        "median_support": float(np.median(arr)),
        "stdev_support": float(arr.std(ddof=0)),
        "fraction_high_support_70": float((arr >= 0.7).mean()),
        "fraction_high_support_90": float((arr >= 0.9).mean()),
        "n_clades_full_support": int((arr == 1.0).sum()),
    }

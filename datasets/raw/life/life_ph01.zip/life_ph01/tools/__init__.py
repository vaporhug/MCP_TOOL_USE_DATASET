"""Phylogenomics primitives for vertebrate supermatrix analysis.

Submodules:
- sequence_io     : FASTA / partition I/O
- distance_methods: pairwise distances (p, JC69, K80, gamma)
- tree_building   : NJ/UPGMA, Newick, rooting, RF distance
- bootstrap       : column-resampled bootstrap and consensus
- codon_models    : translate, syn/non-syn counts, NG86 dN/dS
- gene_analysis   : per-gene stats, Δlog-likelihood, outlier detection
- plot_tools      : matplotlib plots (return file path)
- database_retrieval: taxa metadata lookup (offline)
"""

from . import sequence_io
from . import distance_methods
from . import tree_building
from . import bootstrap
from . import codon_models
from . import gene_analysis
from . import plot_tools
from . import database_retrieval

__all__ = [
    "sequence_io", "distance_methods", "tree_building", "bootstrap",
    "codon_models", "gene_analysis", "plot_tools", "database_retrieval",
]

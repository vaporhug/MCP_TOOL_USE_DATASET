"""Tree construction (NJ, UPGMA), Newick I/O, rooting, and topology metrics.

Trees are represented as nested-tuple Newick-like nodes. A `Node` is a
plain dict: {"name": str|None, "branch_length": float|None, "children": list[Node]}.
Leaves have empty children. The agent reads/writes Newick strings via
`parse_newick` and `tree_to_newick`."""
import re
import numpy as np
from copy import deepcopy
from collections import OrderedDict


# ---------- Tree object utilities ----------

def _new_node(name=None, bl=None, children=None):
    return {"name": name, "branch_length": bl, "children": children or []}


def _is_leaf(n):
    return not n["children"]


def _all_leaves(node):
    if _is_leaf(node):
        return [node["name"]]
    out = []
    for c in node["children"]:
        out.extend(_all_leaves(c))
    return out


# ---------- Newick parsing ----------

def parse_newick(s):
    """Parse a Newick string into the nested-dict tree representation."""
    s = s.strip().rstrip(";").strip()

    pos = [0]

    def parse_subtree():
        if s[pos[0]] == "(":
            pos[0] += 1
            children = [parse_subtree()]
            while s[pos[0]] == ",":
                pos[0] += 1
                children.append(parse_subtree())
            assert s[pos[0]] == ")", f"Expected ')' at pos {pos[0]}: '{s[pos[0]:pos[0]+10]}'"
            pos[0] += 1
            name, bl = parse_label()
            return _new_node(name=name, bl=bl, children=children)
        else:
            name, bl = parse_label()
            return _new_node(name=name, bl=bl)

    def parse_label():
        # name part (until : , ) ;)
        start = pos[0]
        while pos[0] < len(s) and s[pos[0]] not in ":,)":
            pos[0] += 1
        raw = s[start:pos[0]].strip()
        # strip support: name might be like "100" or "name_with:colon"; we treat
        # everything before ':' as the label.
        name = raw if raw else None
        bl = None
        if pos[0] < len(s) and s[pos[0]] == ":":
            pos[0] += 1
            bstart = pos[0]
            while pos[0] < len(s) and s[pos[0]] not in ",);":
                pos[0] += 1
            try:
                bl = float(s[bstart:pos[0]])
            except ValueError:
                bl = None
        return name, bl

    return parse_subtree()


def tree_to_newick(node, include_internal_labels=True):
    """Render a tree dict back into a Newick string (no trailing semicolon)."""
    def render(n):
        if _is_leaf(n):
            label = n["name"] if n["name"] is not None else ""
            bl = "" if n["branch_length"] is None else f":{n['branch_length']:.10g}"
            return f"{label}{bl}"
        inner = ",".join(render(c) for c in n["children"])
        label = (n["name"] or "") if include_internal_labels else ""
        bl = "" if n["branch_length"] is None else f":{n['branch_length']:.10g}"
        return f"({inner}){label}{bl}"

    return render(node) + ";"


# ---------- Neighbor joining ----------

def neighbor_joining(taxa, D):
    """Build a NJ tree from a square distance matrix.

    Parameters
    ----------
    taxa : list[str]
    D : numpy.ndarray, shape (n, n)

    Returns
    -------
    Tree dict (unrooted, but represented as a rooted dict with the last
    join as the root). Branch lengths are in the same units as `D`.
    """
    n = len(taxa)
    if D.shape != (n, n):
        raise ValueError("Distance matrix shape mismatch")
    nodes = [_new_node(name=t) for t in taxa]
    # mutable working copy
    Dw = D.astype(float).copy()
    active = list(range(n))

    while len(active) > 2:
        m = len(active)
        # row sums for active rows/cols
        r = np.array([Dw[i, active].sum() for i in active])
        # Q matrix (only for active i,j)
        Q = np.full((m, m), np.inf)
        for ai in range(m):
            for aj in range(ai + 1, m):
                i, j = active[ai], active[aj]
                Q[ai, aj] = Q[aj, ai] = (m - 2) * Dw[i, j] - r[ai] - r[aj]
        ai, aj = np.unravel_index(np.argmin(Q), Q.shape)
        if ai > aj:
            ai, aj = aj, ai
        i, j = active[ai], active[aj]
        # branch lengths for i and j
        d_ij = Dw[i, j]
        b_i = 0.5 * d_ij + (r[ai] - r[aj]) / (2.0 * (m - 2))
        b_j = d_ij - b_i
        new_node = _new_node(children=[
            {**nodes[i], "branch_length": max(b_i, 0.0)},
            {**nodes[j], "branch_length": max(b_j, 0.0)},
        ])
        # extend Dw with new row/col
        new_idx = Dw.shape[0]
        new_dist = np.zeros(new_idx + 1)
        for k in range(new_idx):
            new_dist[k] = 0.5 * (Dw[i, k] + Dw[j, k] - d_ij)
        new_dist[new_idx] = 0.0
        # grow Dw
        Dw = np.vstack([Dw, new_dist[:new_idx]])
        Dw = np.hstack([Dw, new_dist[:, None]])
        # invalidate i,j rows/cols by removing them from active list
        nodes.append(new_node)
        active = [a for a in active if a != i and a != j] + [new_idx]

    # final two: join with a single branch
    i, j = active[0], active[1]
    d_ij = Dw[i, j]
    root = _new_node(children=[
        {**nodes[i], "branch_length": max(d_ij / 2.0, 0.0)},
        {**nodes[j], "branch_length": max(d_ij / 2.0, 0.0)},
    ])
    return root


def upgma(taxa, D):
    """UPGMA clustering tree from a square distance matrix.

    Returns a rooted ultrametric tree dict.
    """
    n = len(taxa)
    clusters = {i: {"node": _new_node(name=t), "size": 1, "height": 0.0} for i, t in enumerate(taxa)}
    Dw = D.astype(float).copy()
    next_id = n
    active = list(range(n))
    while len(active) > 1:
        # find smallest D among active pairs
        best = (np.inf, -1, -1)
        for ai in range(len(active)):
            for aj in range(ai + 1, len(active)):
                i, j = active[ai], active[aj]
                if Dw[i, j] < best[0]:
                    best = (Dw[i, j], i, j)
        d, i, j = best
        new_height = d / 2.0
        bi = new_height - clusters[i]["height"]
        bj = new_height - clusters[j]["height"]
        new_node = _new_node(children=[
            {**clusters[i]["node"], "branch_length": max(bi, 0.0)},
            {**clusters[j]["node"], "branch_length": max(bj, 0.0)},
        ])
        # weighted merge
        ni, nj = clusters[i]["size"], clusters[j]["size"]
        new_idx = next_id
        next_id += 1
        new_dist = np.zeros(Dw.shape[0] + 1)
        for k in range(Dw.shape[0]):
            new_dist[k] = (ni * Dw[i, k] + nj * Dw[j, k]) / (ni + nj)
        Dw = np.vstack([Dw, new_dist[:Dw.shape[0]]])
        Dw = np.hstack([Dw, new_dist[:, None]])
        clusters[new_idx] = {"node": new_node, "size": ni + nj, "height": new_height}
        active = [a for a in active if a != i and a != j] + [new_idx]
    return clusters[active[0]]["node"]


# ---------- Tree manipulation ----------

def root_tree_on_outgroup(tree, outgroup_taxa):
    """Re-root a tree on the branch leading to the outgroup clade.

    Parameters
    ----------
    tree : dict
        Tree as parsed (rooted or unrooted; we just locate the outgroup
        and place the new root on the branch above it).
    outgroup_taxa : list[str] or str
        Taxon name(s) defining the outgroup clade.

    Returns
    -------
    Re-rooted tree dict.
    """
    if isinstance(outgroup_taxa, str):
        outgroup_taxa = [outgroup_taxa]
    target = set(outgroup_taxa)

    # First convert tree to bidirectional graph
    adj = {}
    bls = {}
    counter = [0]
    id_map = {}

    def add_id(node):
        nid = counter[0]
        counter[0] += 1
        id_map[nid] = node
        adj[nid] = []
        return nid

    def build(node):
        nid = add_id(node)
        for c in node["children"]:
            cid = build(c)
            bl = c["branch_length"] or 0.0
            adj[nid].append(cid)
            adj[cid].append(nid)
            bls[(nid, cid)] = bl
            bls[(cid, nid)] = bl
        return nid

    root_id = build(tree)

    # Find a path from root to any leaf in the outgroup
    def find_leaf_id(name):
        for nid, node in id_map.items():
            if _is_leaf(node) and node["name"] == name:
                return nid
        return None

    # Find MRCA of outgroup taxa
    leaf_ids = [find_leaf_id(t) for t in outgroup_taxa if find_leaf_id(t) is not None]
    if not leaf_ids:
        raise ValueError(f"Outgroup taxa not found: {outgroup_taxa}")

    # If single outgroup, place new root midpoint on its parent edge
    # For multiple, find the MRCA edge.
    def descendant_leaves(nid, parent):
        node = id_map[nid]
        if _is_leaf(node):
            return {node["name"]}
        leaves = set()
        for nb in adj[nid]:
            if nb == parent:
                continue
            leaves |= descendant_leaves(nb, nid)
        return leaves

    # Find the edge whose "below" side contains exactly the outgroup leaves
    best_edge = None
    for u in list(adj.keys()):
        for v in adj[u]:
            below = descendant_leaves(v, u)
            if below == target:
                best_edge = (u, v)
                break
        if best_edge:
            break

    if best_edge is None:
        # fallback: place root on the parent edge of the first outgroup leaf
        og_id = leaf_ids[0]
        parent = adj[og_id][0]
        best_edge = (parent, og_id)

    u, v = best_edge
    bl = bls.get((u, v), 0.0)
    half = bl / 2.0

    # Build new tree rooted between u and v
    visited = {u, v}

    def subtree(nid, parent):
        node = id_map[nid]
        new_children = []
        for nb in adj[nid]:
            if nb == parent:
                continue
            child_node = subtree(nb, nid)
            child_node["branch_length"] = bls.get((nid, nb), 0.0)
            new_children.append(child_node)
        if _is_leaf(node):
            return _new_node(name=node["name"])
        else:
            return _new_node(name=node["name"], children=new_children)

    left = subtree(u, v)
    right = subtree(v, u)
    left["branch_length"] = half
    right["branch_length"] = half
    return _new_node(children=[left, right])


def unroot_tree(tree):
    """Collapse the root if it has exactly two children, returning a
    pseudo-rooted polytomy.

    For our purposes this re-attaches one root child to the other so
    branch lengths sum.
    """
    if len(tree["children"]) != 2:
        return deepcopy(tree)
    a, b = tree["children"]
    bla = a["branch_length"] or 0.0
    blb = b["branch_length"] or 0.0
    # Pick the larger child as the "trunk"
    if _is_leaf(a) and not _is_leaf(b):
        trunk, leaf = b, a
        trunk_bl = blb
        leaf_bl = bla
    elif _is_leaf(b) and not _is_leaf(a):
        trunk, leaf = a, b
        trunk_bl = bla
        leaf_bl = blb
    else:
        trunk = a
        trunk_bl = bla
        leaf = b
        leaf_bl = blb
    new = deepcopy(trunk)
    new["branch_length"] = None
    other = deepcopy(leaf)
    other["branch_length"] = trunk_bl + leaf_bl
    new["children"].append(other)
    return new


def branch_length_stats(tree):
    """Summarize branch lengths in a tree.

    Returns
    -------
    dict: total, mean, median, max, min, n_branches, max_taxon_depth (root-to-tip).
    """
    bls = []

    def walk(n, depth):
        for c in n["children"]:
            bl = c["branch_length"] or 0.0
            bls.append(bl)
            walk(c, depth + bl)

    leaf_depths = []

    def walk_depth(n, depth):
        if _is_leaf(n):
            leaf_depths.append(depth)
            return
        for c in n["children"]:
            walk_depth(c, depth + (c["branch_length"] or 0.0))

    walk(tree, 0.0)
    walk_depth(tree, 0.0)
    arr = np.array(bls) if bls else np.array([0.0])
    return {
        "n_branches": int(len(bls)),
        "total": float(arr.sum()),
        "mean": float(arr.mean()),
        "median": float(np.median(arr)),
        "max": float(arr.max()),
        "min": float(arr.min()),
        "root_to_tip_max": float(max(leaf_depths) if leaf_depths else 0.0),
        "root_to_tip_mean": float(np.mean(leaf_depths) if leaf_depths else 0.0),
    }


# ---------- Topology metrics ----------

def get_clade_set(tree):
    """Return the set of bipartitions (clades) in a tree as frozensets of leaf names.

    Trivial clades (size 1 or full-set) are excluded.
    """
    all_leaves = set(_all_leaves(tree))
    bipartitions = set()

    def walk(n):
        if _is_leaf(n):
            return {n["name"]}
        leaves = set()
        for c in n["children"]:
            leaves |= walk(c)
        if 1 < len(leaves) < len(all_leaves):
            bipartitions.add(frozenset(leaves))
        return leaves

    walk(tree)
    return bipartitions


def robinson_foulds_distance(tree_a, tree_b):
    """Robinson-Foulds distance between two trees with the same leaf set.

    Implementation note: this computes the symmetric difference of the two
    trees' clade sets as returned by ``get_clade_set`` (the leaf-set of every
    non-trivial internal node of the rooted dict representation). For trees
    that share the same leaf set AND the same rooting, each non-trivial clade
    is equivalent to a bipartition, so this equals the standard unrooted RF
    distance; ``max_rf = 2*(n-3)`` is the unrooted maximum. If the two trees
    are rooted differently the clade sets can differ purely by rooting and the
    count is no longer a pure unrooted RF — root both trees consistently
    (e.g. with ``root_tree_on_outgroup``) before comparing. The bundled
    supermatrix and coalescent topologies are both rooted on the Protopterus
    outgroup, so the value returned here is the exact unrooted RF.

    Returns dict with rf, n_unique_a, n_unique_b, max_rf.
    """
    a = get_clade_set(tree_a)
    b = get_clade_set(tree_b)
    only_a = a - b
    only_b = b - a
    return {
        "rf": int(len(only_a) + len(only_b)),
        "n_unique_a": int(len(only_a)),
        "n_unique_b": int(len(only_b)),
        "max_rf": int(2 * (len(set(_all_leaves(tree_a))) - 3)),
    }


def quartet_distance_subset(tree_a, tree_b, taxa_subset):
    """Count the number of induced quartets (size 4) whose topology
    differs between two trees, restricted to a subset of taxa.

    Slow O(n^4 * tree_height) but fine for ≤ 30 taxa.
    """
    from itertools import combinations
    n_diff = 0
    n_total = 0
    # For each quartet, induce sub-tree from clade sets
    for q in combinations(taxa_subset, 4):
        n_total += 1
        # find topology of quartet in each tree by checking which split is supported
        ts_a = _quartet_topology(tree_a, q)
        ts_b = _quartet_topology(tree_b, q)
        if ts_a != ts_b:
            n_diff += 1
    return {"n_quartets": n_total, "n_different": n_diff,
            "fraction_different": n_diff / n_total if n_total > 0 else 0.0}


def _quartet_topology(tree, q):
    """Return one of {(0,1)|(2,3), (0,2)|(1,3), (0,3)|(1,2), 'unresolved'}
    representing the unrooted quartet for taxa q[0..3] in the given tree."""
    bipartitions = get_clade_set(tree)
    s = list(q)
    pairs = [(0, 1), (0, 2), (0, 3)]
    for ai, aj in pairs:
        bk_l = [k for k in range(4) if k not in (ai, aj)]
        bi, bj = bk_l
        side_a = {s[ai], s[aj]}
        side_b = {s[bi], s[bj]}
        for bp in bipartitions:
            in_a = side_a & bp
            in_b = side_b & bp
            # bipartition separates {ai,aj} from {bi,bj} if it contains all of one side and none of the other
            if in_a == side_a and not in_b:
                return tuple(sorted([s[ai], s[aj]]))
            if in_a == side_a and in_b == side_b:
                continue
    return "unresolved"


def find_node_by_taxa(tree, taxa):
    """Find the MRCA node of a set of taxa. Returns the node dict or None."""
    target = set(taxa)

    def walk(n):
        if _is_leaf(n):
            return ({n["name"]}, n if n["name"] in target else None)
        leaves = set()
        candidates = []
        for c in n["children"]:
            l, m = walk(c)
            leaves |= l
            if m is not None:
                candidates.append((l, m))
        if target.issubset(leaves):
            # MRCA = first ancestor that contains all
            return (leaves, n)
        return (leaves, candidates[0][1] if candidates else None)

    return walk(tree)[1]

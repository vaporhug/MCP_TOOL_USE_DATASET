"""Pairwise evolutionary distance computation for nucleotide alignments.

Includes uncorrected p-distance, Jukes-Cantor (JC69), Kimura two-parameter
(K80), and gamma-corrected K80. The pairwise routines respect ambiguity
codes by ignoring sites where either taxon is gap or N."""
import math
import numpy as np


_PURINES = set("AG")
_PYRIMIDINES = set("CT")


def _valid_pair(a, b):
    return (a in "ACGT") and (b in "ACGT")


def proportion_difference(seq1, seq2):
    """Proportion of differences (uncorrected p-distance) ignoring sites
    with gaps or ambiguous bases in either sequence.

    Returns
    -------
    dict with keys: p, n_compared, n_diff, n_skipped
    """
    if len(seq1) != len(seq2):
        raise ValueError("Sequences must be the same length")
    diff, comp, skip = 0, 0, 0
    for a, b in zip(seq1, seq2):
        if not _valid_pair(a, b):
            skip += 1
            continue
        comp += 1
        if a != b:
            diff += 1
    p = (diff / comp) if comp > 0 else float("nan")
    return {"p": p, "n_compared": comp, "n_diff": diff, "n_skipped": skip}


def jc69_distance(seq1, seq2):
    """Jukes-Cantor 1969 corrected distance:
       d = -3/4 * ln(1 - 4/3 * p)

    Returns inf for saturated pairs (p >= 3/4)."""
    pdat = proportion_difference(seq1, seq2)
    p = pdat["p"]
    if math.isnan(p):
        return float("nan")
    if p >= 0.75:
        return float("inf")
    return -0.75 * math.log(1.0 - 4.0 / 3.0 * p)


def transition_transversion_counts(seq1, seq2):
    """Count transitions, transversions, identical, and skipped pairs."""
    if len(seq1) != len(seq2):
        raise ValueError("Length mismatch")
    ts = tv = same = skip = 0
    for a, b in zip(seq1, seq2):
        if not _valid_pair(a, b):
            skip += 1
            continue
        if a == b:
            same += 1
            continue
        if (a in _PURINES and b in _PURINES) or (a in _PYRIMIDINES and b in _PYRIMIDINES):
            ts += 1
        else:
            tv += 1
    n = ts + tv + same
    return {
        "n_compared": n, "n_identical": same,
        "n_transitions": ts, "n_transversions": tv, "n_skipped": skip,
        "P": ts / n if n > 0 else float("nan"),
        "Q": tv / n if n > 0 else float("nan"),
    }


def k80_distance(seq1, seq2):
    """Kimura 2-parameter distance:
       d = -1/2 * ln((1-2P-Q) * sqrt(1-2Q))

    Returns inf if the formula goes negative."""
    c = transition_transversion_counts(seq1, seq2)
    P, Q = c["P"], c["Q"]
    if math.isnan(P):
        return float("nan")
    a = 1.0 - 2.0 * P - Q
    b = 1.0 - 2.0 * Q
    if a <= 0 or b <= 0:
        return float("inf")
    return -0.5 * math.log(a) - 0.25 * math.log(b)


def gamma_corrected_distance(seq1, seq2, alpha=0.5, model="k80"):
    """Gamma-rate-corrected distance under JC69 or K80.

    For JC69:  d = 3/4 * alpha * ((1 - 4/3 * p)^(-1/alpha) - 1)
    For K80 :  d = alpha/2 * ((1-2P-Q)^(-1/alpha) + (1-2Q)^(-1/alpha)/2 - 3/2)
    """
    if model.lower() == "jc69":
        p = proportion_difference(seq1, seq2)["p"]
        if math.isnan(p):
            return float("nan")
        if p >= 0.75:
            return float("inf")
        return 0.75 * alpha * ((1.0 - 4.0 / 3.0 * p) ** (-1.0 / alpha) - 1.0)
    elif model.lower() == "k80":
        c = transition_transversion_counts(seq1, seq2)
        P, Q = c["P"], c["Q"]
        if math.isnan(P):
            return float("nan")
        a = 1.0 - 2.0 * P - Q
        b = 1.0 - 2.0 * Q
        if a <= 0 or b <= 0:
            return float("inf")
        return 0.5 * alpha * (a ** (-1.0 / alpha) + 0.5 * b ** (-1.0 / alpha) - 1.5)
    raise ValueError("Unknown model: " + model)


def pairwise_distance_matrix(seqs, model="jc69", alpha=None):
    """Compute the symmetric pairwise distance matrix for a {name: seq} alignment.

    Parameters
    ----------
    seqs : OrderedDict[str, str]
    model : str
        One of 'p' (proportion), 'jc69', 'k80', 'gamma-jc69', 'gamma-k80'.
    alpha : float or None
        Gamma shape parameter (only used for gamma models).

    Returns
    -------
    (taxa : list[str], D : numpy.ndarray)
    """
    taxa = list(seqs.keys())
    n = len(taxa)
    D = np.zeros((n, n), dtype=float)
    for i in range(n):
        for j in range(i + 1, n):
            s1, s2 = seqs[taxa[i]], seqs[taxa[j]]
            if model == "p":
                d = proportion_difference(s1, s2)["p"]
            elif model == "jc69":
                d = jc69_distance(s1, s2)
            elif model == "k80":
                d = k80_distance(s1, s2)
            elif model == "gamma-jc69":
                d = gamma_corrected_distance(s1, s2, alpha=alpha or 0.5, model="jc69")
            elif model == "gamma-k80":
                d = gamma_corrected_distance(s1, s2, alpha=alpha or 0.5, model="k80")
            else:
                raise ValueError("Unknown model: " + model)
            D[i, j] = D[j, i] = d
    return taxa, D

"""Codon-level analysis: synonymous/non-synonymous site counting and the
Nei-Gojobori 1986 dN/dS estimator.

Designed for codon-aligned protein-coding sequences. Standard genetic code
is used. Stop codons and incomplete codons (with gaps/N within) are skipped."""
import math
from collections import defaultdict


_STANDARD_CODE = {
    'TTT': 'F', 'TTC': 'F', 'TTA': 'L', 'TTG': 'L',
    'CTT': 'L', 'CTC': 'L', 'CTA': 'L', 'CTG': 'L',
    'ATT': 'I', 'ATC': 'I', 'ATA': 'I', 'ATG': 'M',
    'GTT': 'V', 'GTC': 'V', 'GTA': 'V', 'GTG': 'V',
    'TCT': 'S', 'TCC': 'S', 'TCA': 'S', 'TCG': 'S',
    'CCT': 'P', 'CCC': 'P', 'CCA': 'P', 'CCG': 'P',
    'ACT': 'T', 'ACC': 'T', 'ACA': 'T', 'ACG': 'T',
    'GCT': 'A', 'GCC': 'A', 'GCA': 'A', 'GCG': 'A',
    'TAT': 'Y', 'TAC': 'Y', 'TAA': '*', 'TAG': '*',
    'CAT': 'H', 'CAC': 'H', 'CAA': 'Q', 'CAG': 'Q',
    'AAT': 'N', 'AAC': 'N', 'AAA': 'K', 'AAG': 'K',
    'GAT': 'D', 'GAC': 'D', 'GAA': 'E', 'GAG': 'E',
    'TGT': 'C', 'TGC': 'C', 'TGA': '*', 'TGG': 'W',
    'CGT': 'R', 'CGC': 'R', 'CGA': 'R', 'CGG': 'R',
    'AGT': 'S', 'AGC': 'S', 'AGA': 'R', 'AGG': 'R',
    'GGT': 'G', 'GGC': 'G', 'GGA': 'G', 'GGG': 'G',
}


def translate_codons(seq, code=None):
    """Translate a nucleotide sequence to amino acids. Returns string with
    '*' for stop and 'X' for ambiguous codons."""
    code = code or _STANDARD_CODE
    aa = []
    for i in range(0, len(seq) - 2, 3):
        c = seq[i:i + 3].upper()
        if any(b not in "ACGT" for b in c):
            aa.append("X")
        else:
            aa.append(code.get(c, "X"))
    return "".join(aa)


def pairwise_codon_alignment(seq1, seq2):
    """Yield (codon1, codon2) for codon positions where both have valid codons.

    Skips codons containing gaps, Ns, or stops in either sequence.
    """
    if len(seq1) != len(seq2):
        raise ValueError("Length mismatch")
    code = _STANDARD_CODE
    for i in range(0, len(seq1) - 2, 3):
        c1, c2 = seq1[i:i + 3].upper(), seq2[i:i + 3].upper()
        if any(b not in "ACGT" for b in c1):
            continue
        if any(b not in "ACGT" for b in c2):
            continue
        if code.get(c1) == "*" or code.get(c2) == "*":
            continue
        yield c1, c2


def count_syn_nonsyn_sites(codon, code=None):
    """Count synonymous (S) and non-synonymous (N) sites for a single codon
    using the proportion of mutations at each position that change the AA.

    Returns (S, N) such that S + N == 3.
    """
    code = code or _STANDARD_CODE
    if any(b not in "ACGT" for b in codon):
        return (float("nan"), float("nan"))
    src_aa = code.get(codon)
    if src_aa is None or src_aa == "*":
        return (float("nan"), float("nan"))
    bases = "ACGT"
    S = 0.0
    N = 0.0
    for pos in range(3):
        s_count = 0
        n_count = 0
        for b in bases:
            if b == codon[pos]:
                continue
            mut = codon[:pos] + b + codon[pos + 1:]
            mut_aa = code.get(mut)
            if mut_aa is None or mut_aa == "*":
                # treat as non-syn (typical NG86 convention)
                n_count += 1
            elif mut_aa == src_aa:
                s_count += 1
            else:
                n_count += 1
        S += s_count / 3.0
        N += n_count / 3.0
    return (S, N)


def count_syn_nonsyn_substitutions(c1, c2, code=None):
    """Count synonymous (Sd) and non-synonymous (Nd) substitutions between
    two codons, averaging over all minimum-length mutational paths.

    Returns (Sd, Nd).
    """
    code = code or _STANDARD_CODE
    if c1 == c2:
        return 0.0, 0.0
    diffs = [i for i in range(3) if c1[i] != c2[i]]
    if not diffs:
        return 0.0, 0.0
    aa1 = code.get(c1)
    if aa1 == "*" or aa1 is None:
        return float("nan"), float("nan")
    aa2 = code.get(c2)
    if aa2 == "*" or aa2 is None:
        return float("nan"), float("nan")
    if len(diffs) == 1:
        s = 1.0 if aa1 == aa2 else 0.0
        return s, 1.0 - s
    # multi-step: average over all path orderings
    from itertools import permutations
    s_acc = 0.0
    n_acc = 0.0
    n_paths = 0
    for perm in permutations(diffs):
        cur = c1
        path_s = 0
        path_n = 0
        valid_path = True
        for p in perm:
            new_cur = cur[:p] + c2[p] + cur[p + 1:]
            cur_aa = code.get(cur)
            new_aa = code.get(new_cur)
            if cur_aa == "*" or new_aa == "*" or cur_aa is None or new_aa is None:
                valid_path = False
                break
            if cur_aa == new_aa:
                path_s += 1
            else:
                path_n += 1
            cur = new_cur
        if valid_path:
            s_acc += path_s
            n_acc += path_n
            n_paths += 1
    if n_paths == 0:
        return float("nan"), float("nan")
    return s_acc / n_paths, n_acc / n_paths


def ng86_dn_ds(seq1, seq2, code=None):
    """Nei-Gojobori 1986 dN/dS ratio between two codon-aligned sequences.

    Returns
    -------
    dict: dn, ds, omega, S_total, N_total, Sd_total, Nd_total, n_codons
    """
    code = code or _STANDARD_CODE
    S_tot = 0.0
    N_tot = 0.0
    Sd_tot = 0.0
    Nd_tot = 0.0
    n_codons = 0
    for c1, c2 in pairwise_codon_alignment(seq1, seq2):
        S1, N1 = count_syn_nonsyn_sites(c1, code)
        S2, N2 = count_syn_nonsyn_sites(c2, code)
        if math.isnan(S1) or math.isnan(S2):
            continue
        S_tot += 0.5 * (S1 + S2)
        N_tot += 0.5 * (N1 + N2)
        Sd, Nd = count_syn_nonsyn_substitutions(c1, c2, code)
        if math.isnan(Sd):
            continue
        Sd_tot += Sd
        Nd_tot += Nd
        n_codons += 1
    if S_tot == 0 or N_tot == 0:
        return {"dn": float("nan"), "ds": float("nan"), "omega": float("nan"),
                "S_total": S_tot, "N_total": N_tot,
                "Sd_total": Sd_tot, "Nd_total": Nd_tot, "n_codons": n_codons}
    pS = Sd_tot / S_tot
    pN = Nd_tot / N_tot
    if pS >= 0.75 or pN >= 0.75:
        ds = float("inf") if pS >= 0.75 else -0.75 * math.log(1 - 4.0 / 3.0 * pS)
        dn = float("inf") if pN >= 0.75 else -0.75 * math.log(1 - 4.0 / 3.0 * pN)
    else:
        ds = -0.75 * math.log(1 - 4.0 / 3.0 * pS)
        dn = -0.75 * math.log(1 - 4.0 / 3.0 * pN)
    omega = (dn / ds) if ds > 0 else float("inf")
    return {"dn": float(dn), "ds": float(ds), "omega": float(omega),
            "S_total": float(S_tot), "N_total": float(N_tot),
            "Sd_total": float(Sd_tot), "Nd_total": float(Nd_tot),
            "n_codons": int(n_codons)}


def mean_dn_ds_across_pairs(seqs, taxa_subset=None):
    """Mean dN/dS over all pairs (or a subset) of taxa.

    Returns (mean_omega, list_of_pair_results).
    """
    names = list(seqs.keys()) if taxa_subset is None else list(taxa_subset)
    out = []
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            r = ng86_dn_ds(seqs[names[i]], seqs[names[j]])
            r["taxa"] = (names[i], names[j])
            out.append(r)
    valid = [r["omega"] for r in out if r["omega"] not in (float("nan"), float("inf")) and not math.isnan(r["omega"])]
    return {
        "mean_omega": float(sum(valid) / len(valid)) if valid else float("nan"),
        "n_valid_pairs": len(valid),
        "n_total_pairs": len(out),
        "pairs": out,
    }

"""FASTA parsing, alignment summary, and partitioned-gene extraction.

These primitives let the agent load the concatenated supermatrix and the
partition file, then operate on either the full matrix or per-gene
sub-alignments. No third-party phylogenetic library is imported."""
import os
import re
from collections import OrderedDict


def parse_fasta(path):
    """Read a FASTA file into an ordered dict {taxon_name: sequence_str}.

    Sequences may span multiple lines; whitespace is stripped. The taxon
    name is everything after `>` up to the first whitespace.

    Parameters
    ----------
    path : str
        Path to the FASTA file.

    Returns
    -------
    OrderedDict[str, str]
    """
    seqs = OrderedDict()
    cur = None
    with open(path) as f:
        for line in f:
            line = line.rstrip()
            if not line:
                continue
            if line.startswith(">"):
                cur = line[1:].split()[0]
                if cur in seqs:
                    raise ValueError(f"Duplicate taxon name: {cur}")
                seqs[cur] = []
            elif cur is not None:
                seqs[cur].append(line)
    return OrderedDict((k, "".join(v).upper()) for k, v in seqs.items())


def write_fasta(seqs, path, line_width=80):
    """Write a {name: sequence} mapping to a FASTA file.

    Parameters
    ----------
    seqs : dict
        Ordered mapping of taxon -> sequence string.
    path : str
        Output path.
    line_width : int
        Number of characters per sequence line.
    """
    with open(path, "w") as f:
        for name, seq in seqs.items():
            f.write(">" + name + "\n")
            for i in range(0, len(seq), line_width):
                f.write(seq[i:i + line_width] + "\n")
    return path


def alignment_summary(seqs):
    """Compute basic summary stats for an aligned dict of sequences.

    Returns
    -------
    dict with keys: n_taxa, n_sites, mean_gaps_per_taxon,
    mean_ambiguous_per_taxon, taxon_lengths, all_equal_length
    """
    if not seqs:
        return {"n_taxa": 0, "n_sites": 0}
    lens = [len(s) for s in seqs.values()]
    all_equal = len(set(lens)) == 1
    n_sites = lens[0] if all_equal else max(lens)
    gaps = []
    ambig = []
    valid = set("ACGT")
    for name, s in seqs.items():
        gaps.append(s.count("-"))
        ambig.append(sum(1 for c in s if c.upper() not in valid and c != "-"))
    return {
        "n_taxa": len(seqs),
        "n_sites": n_sites,
        "all_equal_length": all_equal,
        "taxon_lengths": dict(zip(seqs.keys(), lens)),
        "mean_gaps_per_taxon": float(sum(gaps) / len(gaps)),
        "mean_ambiguous_per_taxon": float(sum(ambig) / len(ambig)),
        "total_gap_count": int(sum(gaps)),
        "total_ambiguous_count": int(sum(ambig)),
    }


def read_partition_model(path):
    """Parse a RAxML-style partition file with lines like:
       `DNA, my_GENE.macse_DNA_gb.nex = 1-498`

    Returns a list of dicts: [{name, model, start, end, length}, ...]
    Coordinates are 1-based inclusive (as in the file); use start-1 for
    Python slicing.
    """
    parts = []
    pattern = re.compile(r"^\s*(\w+)\s*,\s*(\S+)\s*=\s*(\d+)\s*-\s*(\d+)\s*$")
    with open(path) as f:
        for raw in f:
            line = raw.strip()
            if not line:
                continue
            m = pattern.match(line)
            if not m:
                continue
            model, name, s, e = m.group(1), m.group(2), int(m.group(3)), int(m.group(4))
            parts.append({
                "model": model,
                "name": name,
                "start": s,
                "end": e,
                "length": e - s + 1,
            })
    return parts


def extract_gene_alignment(seqs, start, end):
    """Slice a per-gene block out of a concatenated alignment.

    Parameters
    ----------
    seqs : dict[str, str]
        Concatenated supermatrix.
    start : int
        1-based inclusive start coordinate (as in the partition file).
    end : int
        1-based inclusive end coordinate.

    Returns
    -------
    OrderedDict[str, str]
    """
    if start < 1 or end < start:
        raise ValueError("Invalid start/end")
    out = OrderedDict()
    for name, s in seqs.items():
        out[name] = s[start - 1:end]
    return out


def concatenate_alignments(alignments):
    """Concatenate a list of {name: seq} alignments into a supermatrix.

    Missing taxa are padded with gaps to match the partition length.
    """
    all_taxa = []
    for a in alignments:
        for k in a.keys():
            if k not in all_taxa:
                all_taxa.append(k)
    out = OrderedDict((t, []) for t in all_taxa)
    for a in alignments:
        L = len(next(iter(a.values())))
        for t in all_taxa:
            out[t].append(a.get(t, "-" * L))
    return OrderedDict((t, "".join(v)) for t, v in out.items())


def count_invariant_sites(seqs):
    """Count alignment columns where all (non-gap, non-ambiguous) bases are
    identical. Ambiguous sites or gap-only columns are ignored."""
    if not seqs:
        return 0
    L = len(next(iter(seqs.values())))
    names = list(seqs.keys())
    inv = 0
    valid = set("ACGT")
    for i in range(L):
        col = {seqs[n][i] for n in names if seqs[n][i] in valid}
        if len(col) == 1:
            inv += 1
    return int(inv)


def column_gap_fraction(seqs):
    """Per-column gap+N fraction over taxa. Returns numpy array length L."""
    import numpy as np
    L = len(next(iter(seqs.values())))
    names = list(seqs.keys())
    n = len(names)
    out = np.zeros(L, dtype=float)
    valid = set("ACGT")
    for i in range(L):
        miss = sum(1 for nm in names if seqs[nm][i] not in valid)
        out[i] = miss / n
    return out


def mask_ambiguous(seqs, max_gap_fraction=0.5):
    """Drop alignment columns with >max_gap_fraction missing/ambiguous bases.

    Returns
    -------
    (cleaned_seqs : OrderedDict[str, str], retained_indices : list[int])
    """
    import numpy as np
    gf = column_gap_fraction(seqs)
    keep = [i for i, v in enumerate(gf) if v <= max_gap_fraction]
    out = OrderedDict()
    for k, s in seqs.items():
        out[k] = "".join(s[i] for i in keep)
    return out, keep

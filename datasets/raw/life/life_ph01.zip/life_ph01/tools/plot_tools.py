"""Publication-quality plotting helpers.

All functions write a PNG to disk and return a dict with the absolute path.
The agent calls these to populate the answer's image artifacts."""
import os
import math
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from .tree_building import _is_leaf, _all_leaves


def _layout_tree(tree):
    """Compute (x, y) coordinates for every node in a rooted tree.

    Leaves get evenly spaced y; internal nodes' y is mean of children.
    x is the cumulative branch length from the root.
    Returns dict id(node) -> (x, y).
    """
    coords = {}
    leaves = _all_leaves(tree)
    leaf_y = {n: i for i, n in enumerate(leaves)}

    def walk(node, x_root):
        x = x_root + (node["branch_length"] or 0.0)
        if _is_leaf(node):
            coords[id(node)] = (x, leaf_y[node["name"]])
            return leaf_y[node["name"]]
        ys = []
        for c in node["children"]:
            ys.append(walk(c, x))
        y = sum(ys) / len(ys)
        coords[id(node)] = (x, y)
        return y

    walk(tree, 0.0)
    return coords, leaves


def plot_phylogeny(tree, output_path, title=None, support_field="name",
                   highlight_taxa=None, figsize=(8, 6)):
    """Draw a rooted tree as a horizontal cladogram-with-branch-lengths.

    Internal node labels (typically bootstrap support) are taken from
    `node[support_field]`.
    """
    coords, leaves = _layout_tree(tree)
    fig, ax = plt.subplots(figsize=figsize)

    def draw(node):
        if _is_leaf(node):
            return
        x_p, y_p = coords[id(node)]
        ys = [coords[id(c)][1] for c in node["children"]]
        y_top, y_bot = max(ys), min(ys)
        # vertical line at parent x
        ax.plot([x_p, x_p], [y_bot, y_top], "k-", lw=1)
        for c in node["children"]:
            x_c, y_c = coords[id(c)]
            ax.plot([x_p, x_c], [y_c, y_c], "k-", lw=1)
            draw(c)
        # internal label
        if node[support_field]:
            try:
                txt = node[support_field]
                ax.text(x_p, y_p + 0.05, txt, fontsize=7, color="darkblue")
            except Exception:
                pass

    draw(tree)

    # walk tree to label leaves at their (x, y) coordinates
    def label_leaves(node):
        if _is_leaf(node):
            x, y = coords[id(node)]
            color = "red" if highlight_taxa and node["name"] in highlight_taxa else "black"
            ax.text(x + 0.005, y, " " + node["name"], fontsize=8, va="center", color=color)
            return
        for c in node["children"]:
            label_leaves(c)

    label_leaves(tree)

    ax.set_yticks([])
    ax.set_xlabel("Branch length (substitutions/site)")
    if title:
        ax.set_title(title, fontsize=11)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_visible(False)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"path": os.path.abspath(output_path)}


def plot_distance_heatmap(taxa, D, output_path, title=None,
                          colormap="viridis", figsize=(7, 6)):
    """Render a pairwise distance matrix as a heatmap."""
    fig, ax = plt.subplots(figsize=figsize)
    im = ax.imshow(D, cmap=colormap)
    ax.set_xticks(range(len(taxa)))
    ax.set_yticks(range(len(taxa)))
    ax.set_xticklabels(taxa, rotation=90, fontsize=8)
    ax.set_yticklabels(taxa, fontsize=8)
    if title:
        ax.set_title(title, fontsize=11)
    cbar = fig.colorbar(im, ax=ax, fraction=0.04, pad=0.04)
    cbar.set_label("Distance")
    # write values
    n = len(taxa)
    if n <= 20:
        vmax = float(np.nanmax(D))
        for i in range(n):
            for j in range(n):
                if i == j:
                    continue
                v = D[i, j]
                if not math.isfinite(v):
                    continue
                ax.text(j, i, f"{v:.2f}", ha="center", va="center",
                        color="white" if v > vmax / 2 else "black",
                        fontsize=6)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"path": os.path.abspath(output_path)}


def plot_bootstrap_distribution(supports, output_path, title=None,
                                figsize=(7, 4)):
    """Histogram + per-clade bar plot of bootstrap support values."""
    fig, axes = plt.subplots(1, 2, figsize=figsize)
    fracs = [s["fraction"] * 100 for s in supports]
    axes[0].hist(fracs, bins=10, color="steelblue", edgecolor="black")
    axes[0].set_xlabel("Bootstrap support (%)")
    axes[0].set_ylabel("Number of clades")
    axes[0].axvline(70, color="red", ls="--", label="70% threshold")
    axes[0].legend(fontsize=8)
    # rank bar
    sorted_s = sorted(supports, key=lambda s: -s["fraction"])
    labels = ["+".join(sorted(s["clade"])[:3]) + ("..." if len(s["clade"]) > 3 else "")
              for s in sorted_s]
    axes[1].barh(range(len(sorted_s)), [s["fraction"] * 100 for s in sorted_s],
                 color="darkorange")
    axes[1].set_yticks(range(len(sorted_s)))
    axes[1].set_yticklabels(labels, fontsize=6)
    axes[1].invert_yaxis()
    axes[1].set_xlabel("Support (%)")
    axes[1].axvline(70, color="red", ls="--")
    if title:
        fig.suptitle(title, fontsize=11)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"path": os.path.abspath(output_path)}


def plot_per_gene_delta_loglik(deltas, output_path, title=None,
                               highlight_genes=None, figsize=(8, 5)):
    """Scatter of per-gene Δlog-likelihood with outliers highlighted.

    Parameters
    ----------
    deltas : list of {"name": str, "delta": float}
    highlight_genes : iterable of names to highlight in red.
    """
    names = [d["name"] for d in deltas]
    vals = [d.get("delta", 0.0) for d in deltas]
    idx = np.arange(len(vals))
    fig, axes = plt.subplots(1, 2, figsize=figsize, gridspec_kw={"width_ratios": [3, 1]})
    colors = ["red" if highlight_genes and n in highlight_genes else "steelblue"
              for n in names]
    axes[0].scatter(idx, vals, c=colors, s=18, alpha=0.7)
    axes[0].axhline(0, color="black", lw=0.6)
    axes[0].set_xlabel("Gene index")
    axes[0].set_ylabel(r"$\Delta$ log-likelihood (topology A - B)")
    if highlight_genes:
        for d, color in zip(deltas, colors):
            if color == "red":
                axes[0].annotate(d["name"][-12:], (deltas.index(d),
                                                   d["delta"]),
                                 fontsize=7, color="red")
    axes[1].hist(vals, bins=30, orientation="horizontal", color="steelblue",
                 edgecolor="black")
    axes[1].axhline(0, color="black", lw=0.6)
    axes[1].set_xlabel("# genes")
    if title:
        fig.suptitle(title, fontsize=11)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"path": os.path.abspath(output_path)}


def plot_branch_length_distribution(branch_lengths, output_path, title=None,
                                    figsize=(7, 4)):
    """Histogram of branch lengths in a tree."""
    fig, ax = plt.subplots(figsize=figsize)
    ax.hist(branch_lengths, bins=30, color="seagreen", edgecolor="black")
    ax.set_xlabel("Branch length (substitutions/site)")
    ax.set_ylabel("Number of branches")
    if title:
        ax.set_title(title, fontsize=11)
    ax.axvline(np.median(branch_lengths), color="red", ls="--",
               label=f"median={np.median(branch_lengths):.3f}")
    ax.legend()
    fig.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"path": os.path.abspath(output_path)}

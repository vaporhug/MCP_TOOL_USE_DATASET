"""Differential analysis: volcano plot data, PCA, pathway enrichment."""

import numpy as np
import pandas as pd
from typing import Tuple, Optional, Dict, List


def compute_pca(
    X: pd.DataFrame,
    n_components: int = 2,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Compute principal component analysis.

    Parameters
    ----------
    X : pd.DataFrame
        Feature matrix (samples x features).
    n_components : int
        Number of principal components.

    Returns
    -------
    Tuple[np.ndarray, np.ndarray, np.ndarray]
        PC scores (n_samples x n_components),
        explained variance ratios,
        loadings (n_features x n_components).
    """
    from sklearn.decomposition import PCA

    pca = PCA(n_components=n_components)
    scores = pca.fit_transform(X.values)
    return scores, pca.explained_variance_ratio_, pca.components_.T


def compute_volcano_data(
    diff_results: pd.DataFrame,
    fc_up: float = 1.25,
    fc_down: float = 0.8,
    fdr_threshold: float = 0.05,
) -> pd.DataFrame:
    """Prepare data for a volcano plot from differential analysis results.

    A feature is called significant when its FDR is below ``fdr_threshold`` and
    its (raw, non-log) fold change is either above ``fc_up`` (up-regulated) or
    below ``fc_down`` (down-regulated). The comparison is performed on the
    ``log2_fc`` column by taking ``log2`` of the raw fold-change thresholds.

    Parameters
    ----------
    diff_results : pd.DataFrame
        Must contain columns: feature, log2_fc, fdr (or p_value).
    fc_up : float
        Raw (non-log) fold-change threshold for up-regulation.
    fc_down : float
        Raw (non-log) fold-change threshold for down-regulation.
    fdr_threshold : float
        FDR threshold for significance.

    Returns
    -------
    pd.DataFrame
        DataFrame with added neg_log10_p and regulation columns.
    """
    df = diff_results.copy()
    p_col = "fdr" if "fdr" in df.columns else "p_value"
    df["neg_log10_p"] = -np.log10(df[p_col].clip(lower=1e-300))

    conditions = [
        (df["log2_fc"] > np.log2(fc_up)) & (df[p_col] < fdr_threshold),
        (df["log2_fc"] < np.log2(fc_down)) & (df[p_col] < fdr_threshold),
    ]
    choices = ["Up", "Down"]
    df["regulation"] = np.select(conditions, choices, default="Not significant")

    return df


def cluster_metabolite_trajectories(
    X: pd.DataFrame,
    labels: pd.Series,
    stages: list,
    n_clusters: int = 3,
) -> Dict[int, List[str]]:
    """Cluster metabolites by their abundance trajectories across disease stages.

    Groups metabolites based on how their relative abundance changes
    from control through disease stages.

    Parameters
    ----------
    X : pd.DataFrame
        Metabolomics data (samples x metabolites).
    labels : pd.Series
        Stage labels for each sample.
    stages : list
        Ordered list of stages.
    n_clusters : int
        Number of clusters.

    Returns
    -------
    Dict[int, List[str]]
        Mapping from cluster ID to list of metabolite names.
    """
    from sklearn.cluster import KMeans

    # Compute mean abundance per stage
    stage_means = []
    for stage in stages:
        mask = labels == stage
        if mask.any():
            stage_means.append(X[mask].mean())
    stage_mean_df = pd.DataFrame(stage_means, index=stages)

    # Z-score normalize per metabolite
    means = stage_mean_df.mean()
    stds = stage_mean_df.std()
    stds[stds == 0] = 1
    normed = ((stage_mean_df - means) / stds).T

    km = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
    labels_km = km.fit_predict(normed.values)

    clusters = {}
    for i in range(n_clusters):
        mask = labels_km == i
        clusters[i] = normed.index[mask].tolist()

    return clusters


def kegg_pathway_enrichment(
    significant_metabolites: List[str],
    all_metabolites: List[str],
    pathway_dict: Dict[str, List[str]],
    fdr_threshold: float = 0.05,
) -> pd.DataFrame:
    """Perform pathway enrichment analysis using Fisher's exact test.

    Parameters
    ----------
    significant_metabolites : list of str
        Names of significant metabolites.
    all_metabolites : list of str
        Names of all measured metabolites.
    pathway_dict : dict
        Mapping from pathway name to list of metabolite names.
    fdr_threshold : float
        FDR threshold for significance.

    Returns
    -------
    pd.DataFrame
        Enrichment results with columns: pathway, count, total, fold_enrichment,
        p_value, fdr.
    """
    from scipy.stats import fisher_exact

    n_sig = len(significant_metabolites)
    n_all = len(all_metabolites)
    sig_set = set(significant_metabolites)
    all_set = set(all_metabolites)

    results = []
    for pathway, members in pathway_dict.items():
        members_in_data = [m for m in members if m in all_set]
        if len(members_in_data) == 0:
            continue
        overlap = [m for m in members_in_data if m in sig_set]
        a = len(overlap)
        b = len(members_in_data) - a
        c = n_sig - a
        d = n_all - n_sig - b

        if a == 0:
            continue

        _, pval = fisher_exact([[a, b], [c, d]], alternative="greater")
        expected = n_sig * len(members_in_data) / n_all
        fold = a / expected if expected > 0 else 0

        results.append({
            "pathway": pathway,
            "count": a,
            "total_in_pathway": len(members_in_data),
            "fold_enrichment": fold,
            "p_value": pval,
        })

    df = pd.DataFrame(results)
    if len(df) > 0:
        df = df.sort_values("p_value").reset_index(drop=True)
        n = len(df)
        df["fdr"] = df["p_value"] * n / (df.index + 1)
        df["fdr"] = df["fdr"].clip(upper=1.0)
        df["fdr"] = df["fdr"][::-1].cummin()[::-1]
        df["significant"] = df["fdr"] < fdr_threshold

    return df

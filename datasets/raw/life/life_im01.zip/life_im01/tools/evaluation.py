"""Model evaluation utilities: ROC AUC, calibration, bootstrap validation."""

import numpy as np
import pandas as pd
from typing import Tuple, Optional, Dict


def compute_roc_curve(
    y_true: np.ndarray,
    y_score: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray, float]:
    """Compute ROC curve and AUC.

    Parameters
    ----------
    y_true : np.ndarray
        True binary labels.
    y_score : np.ndarray
        Predicted probabilities or scores.

    Returns
    -------
    Tuple[np.ndarray, np.ndarray, float]
        fpr, tpr, auc_score.
    """
    from sklearn.metrics import roc_curve, auc

    fpr, tpr, _ = roc_curve(y_true, y_score)
    auc_score = auc(fpr, tpr)
    return fpr, tpr, auc_score


def bootstrap_auc(
    y_true: np.ndarray,
    y_score: np.ndarray,
    n_bootstrap: int = 1000,
    confidence: float = 0.95,
    random_state: int = 42,
) -> Tuple[float, float, float]:
    """Compute AUC with bootstrap confidence interval.

    Parameters
    ----------
    y_true : np.ndarray
        True binary labels.
    y_score : np.ndarray
        Predicted probabilities.
    n_bootstrap : int
        Number of bootstrap samples.
    confidence : float
        Confidence level for interval.
    random_state : int
        Random seed.

    Returns
    -------
    Tuple[float, float, float]
        mean AUC, lower CI, upper CI.
    """
    from sklearn.metrics import roc_auc_score

    rng = np.random.RandomState(random_state)
    aucs = []
    n = len(y_true)

    for _ in range(n_bootstrap):
        idx = rng.randint(0, n, size=n)
        y_t = y_true[idx]
        y_s = y_score[idx]
        if len(np.unique(y_t)) < 2:
            continue
        aucs.append(roc_auc_score(y_t, y_s))

    aucs = np.array(aucs)
    alpha = (1 - confidence) / 2
    return np.mean(aucs), np.percentile(aucs, 100 * alpha), np.percentile(aucs, 100 * (1 - alpha))


def compute_sensitivity_specificity(
    y_true: np.ndarray,
    y_score: np.ndarray,
    threshold: float = 0.5,
) -> Dict[str, float]:
    """Compute sensitivity, specificity, and accuracy at a given threshold.

    Parameters
    ----------
    y_true : np.ndarray
        True binary labels.
    y_score : np.ndarray
        Predicted probabilities.
    threshold : float
        Classification threshold.

    Returns
    -------
    Dict[str, float]
        Dictionary with sensitivity, specificity, accuracy, ppv, npv.
    """
    y_pred = (y_score >= threshold).astype(int)
    tp = np.sum((y_pred == 1) & (y_true == 1))
    tn = np.sum((y_pred == 0) & (y_true == 0))
    fp = np.sum((y_pred == 1) & (y_true == 0))
    fn = np.sum((y_pred == 0) & (y_true == 1))

    sensitivity = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    specificity = tn / (tn + fp) if (tn + fp) > 0 else 0.0
    accuracy = (tp + tn) / len(y_true) if len(y_true) > 0 else 0.0
    ppv = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    npv = tn / (tn + fn) if (tn + fn) > 0 else 0.0

    return {
        "sensitivity": sensitivity,
        "specificity": specificity,
        "accuracy": accuracy,
        "ppv": ppv,
        "npv": npv,
        "threshold": threshold,
    }


def calibration_curve_data(
    y_true: np.ndarray,
    y_prob: np.ndarray,
    n_bins: int = 10,
) -> Tuple[np.ndarray, np.ndarray]:
    """Compute calibration curve data (observed vs predicted probabilities).

    Parameters
    ----------
    y_true : np.ndarray
        True binary labels.
    y_prob : np.ndarray
        Predicted probabilities.
    n_bins : int
        Number of bins for calibration.

    Returns
    -------
    Tuple[np.ndarray, np.ndarray]
        mean_predicted, fraction_positives for each bin.
    """
    from sklearn.calibration import calibration_curve

    fraction_positives, mean_predicted = calibration_curve(
        y_true, y_prob, n_bins=n_bins, strategy="uniform"
    )
    return mean_predicted, fraction_positives


def bootstrap_validation(
    X: pd.DataFrame,
    y: pd.Series,
    model_class,
    model_params: dict,
    n_bootstrap: int = 200,
    metric: str = "roc_auc",
    random_state: int = 42,
) -> Tuple[float, float, float]:
    """Perform bootstrap validation of a classifier.

    Parameters
    ----------
    X : pd.DataFrame
        Feature matrix.
    y : pd.Series
        Labels.
    model_class : class
        Sklearn-compatible classifier class.
    model_params : dict
        Parameters for the model.
    n_bootstrap : int
        Number of bootstrap iterations.
    metric : str
        Evaluation metric: 'roc_auc' or 'accuracy'.
    random_state : int
        Random seed.

    Returns
    -------
    Tuple[float, float, float]
        mean score, lower 95% CI, upper 95% CI.
    """
    from sklearn.metrics import roc_auc_score, accuracy_score

    rng = np.random.RandomState(random_state)
    scores = []
    n = len(y)

    for _ in range(n_bootstrap):
        train_idx = rng.randint(0, n, size=n)
        test_idx = np.array([i for i in range(n) if i not in train_idx])
        if len(test_idx) == 0 or len(np.unique(y.iloc[test_idx])) < 2:
            continue

        model = model_class(**model_params)
        model.fit(X.iloc[train_idx], y.iloc[train_idx])

        if metric == "roc_auc" and hasattr(model, "predict_proba"):
            pred = model.predict_proba(X.iloc[test_idx])[:, 1]
            scores.append(roc_auc_score(y.iloc[test_idx], pred))
        else:
            pred = model.predict(X.iloc[test_idx])
            scores.append(accuracy_score(y.iloc[test_idx], pred))

    scores = np.array(scores)
    return np.mean(scores), np.percentile(scores, 2.5), np.percentile(scores, 97.5)

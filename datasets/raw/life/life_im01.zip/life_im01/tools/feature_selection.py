"""Feature selection methods: LASSO, univariate filtering, permutation importance."""

import numpy as np
import pandas as pd
from typing import List, Tuple, Optional


def lasso_feature_selection(
    X: pd.DataFrame,
    y: pd.Series,
    alpha: float = 0.01,
    max_iter: int = 10000,
    n_cv: int = 100,
    random_state: int = 42,
) -> Tuple[List[str], np.ndarray]:
    """Select features using LASSO (L1-regularized logistic regression).

    Performs repeated cross-validation and returns features with non-zero
    coefficients averaged across CV folds.

    Parameters
    ----------
    X : pd.DataFrame
        Feature matrix (samples x features).
    y : pd.Series
        Binary labels.
    alpha : float
        L1 regularization strength (inverse of C).
    max_iter : int
        Maximum iterations for solver.
    n_cv : int
        Number of random cross-validation repetitions.
    random_state : int
        Random seed.

    Returns
    -------
    Tuple[List[str], np.ndarray]
        List of selected feature names and their mean coefficients.
    """
    from sklearn.linear_model import LogisticRegression
    import warnings
    warnings.filterwarnings("ignore", category=FutureWarning)
    warnings.filterwarnings("ignore", category=UserWarning)

    coefs = np.zeros((n_cv, X.shape[1]))
    rng = np.random.RandomState(random_state)

    for i in range(n_cv):
        perm = rng.permutation(len(y))
        n_train = int(0.8 * len(y))
        train_idx = perm[:n_train]

        model = LogisticRegression(
            penalty="l1",
            C=1.0 / alpha,
            solver="saga",
            max_iter=max_iter,
            random_state=rng.randint(0, 100000),
        )
        model.fit(X.values[train_idx], y.values[train_idx])
        coefs[i] = model.coef_[0]

    mean_coefs = np.mean(coefs, axis=0)
    nonzero_mask = np.abs(mean_coefs) > 1e-10
    selected = [X.columns[j] for j in range(X.shape[1]) if nonzero_mask[j]]
    selected_coefs = mean_coefs[nonzero_mask]

    return selected, selected_coefs


def univariate_wilcoxon_test(
    X: pd.DataFrame,
    y: pd.Series,
    fdr_threshold: float = 0.05,
) -> pd.DataFrame:
    """Perform two-sided Wilcoxon rank-sum test for each feature between groups.

    Parameters
    ----------
    X : pd.DataFrame
        Feature matrix.
    y : pd.Series
        Binary group labels.
    fdr_threshold : float
        FDR threshold for significance.

    Returns
    -------
    pd.DataFrame
        DataFrame with columns: feature, statistic, p_value, fdr, fold_change, significant.
    """
    from scipy.stats import mannwhitneyu

    results = []
    group0 = X[y == 0]
    group1 = X[y == 1]

    for col in X.columns:
        v0 = group0[col].dropna().values
        v1 = group1[col].dropna().values
        if len(v0) < 2 or len(v1) < 2:
            continue
        stat, pval = mannwhitneyu(v0, v1, alternative="two-sided")
        m0 = np.mean(v0)
        m1 = np.mean(v1)
        fc = m1 / m0 if m0 != 0 else np.inf
        results.append({
            "feature": col,
            "statistic": stat,
            "p_value": pval,
            "fold_change": fc,
            "log2_fc": np.log2(fc) if fc > 0 and np.isfinite(fc) else np.nan,
            "mean_group0": m0,
            "mean_group1": m1,
        })

    df = pd.DataFrame(results)
    if len(df) > 0:
        # Benjamini-Hochberg FDR correction
        df = df.sort_values("p_value").reset_index(drop=True)
        n = len(df)
        df["fdr"] = df["p_value"] * n / (df.index + 1)
        df["fdr"] = df["fdr"].clip(upper=1.0)
        # Ensure monotonicity
        df["fdr"] = df["fdr"][::-1].cummin()[::-1]
        df["significant"] = df["fdr"] < fdr_threshold
    return df


def permutation_feature_importance(
    model,
    X: pd.DataFrame,
    y: pd.Series,
    n_repeats: int = 10,
    random_state: int = 42,
    scoring: str = "accuracy",
) -> pd.DataFrame:
    """Compute permutation feature importance for a fitted model.

    Parameters
    ----------
    model : fitted model
        A fitted sklearn-compatible model with predict method.
    X : pd.DataFrame
        Feature matrix.
    y : pd.Series
        True labels.
    n_repeats : int
        Number of permutation repeats.
    random_state : int
        Random seed.
    scoring : str
        Scoring metric: 'accuracy' or 'roc_auc'.

    Returns
    -------
    pd.DataFrame
        DataFrame with feature, importance_mean, importance_std columns.
    """
    from sklearn.metrics import accuracy_score, roc_auc_score

    rng = np.random.RandomState(random_state)

    if scoring == "roc_auc":
        if hasattr(model, "predict_proba"):
            base_score = roc_auc_score(y, model.predict_proba(X)[:, 1])
        else:
            base_score = roc_auc_score(y, model.predict(X))
    else:
        base_score = accuracy_score(y, model.predict(X))

    importances = []
    for col in X.columns:
        scores = []
        for _ in range(n_repeats):
            X_perm = X.copy()
            X_perm[col] = rng.permutation(X_perm[col].values)
            if scoring == "roc_auc":
                if hasattr(model, "predict_proba"):
                    s = roc_auc_score(y, model.predict_proba(X_perm)[:, 1])
                else:
                    s = roc_auc_score(y, model.predict(X_perm))
            else:
                s = accuracy_score(y, model.predict(X_perm))
            scores.append(base_score - s)
        importances.append({
            "feature": col,
            "importance_mean": np.mean(scores),
            "importance_std": np.std(scores),
        })

    return pd.DataFrame(importances).sort_values("importance_mean", ascending=False)

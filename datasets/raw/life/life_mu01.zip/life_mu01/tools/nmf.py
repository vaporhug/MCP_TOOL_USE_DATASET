"""From-scratch non-negative matrix factorisation for SBS signature extraction.

This module ships the Lee-Seung multiplicative update rules for both the
Frobenius-norm and the generalized Kullback-Leibler (Poisson) loss and a
small set of helpers (NNDSVD initialisation, residual norms, BIC).  No
third-party factorisation library is required.
"""

from __future__ import annotations

from typing import Dict, Optional, Tuple

import numpy as np

EPS = 1e-12


def random_init(
    shape_W: Tuple[int, int], shape_H: Tuple[int, int], seed: int = 0
) -> Tuple[np.ndarray, np.ndarray]:
    """Draw non-negative ``W`` and ``H`` from a uniform random distribution."""
    rng = np.random.default_rng(seed)
    W = rng.uniform(0.0, 1.0, size=shape_W)
    H = rng.uniform(0.0, 1.0, size=shape_H)
    return W, H


def nndsvd_init(V: np.ndarray, k: int) -> Tuple[np.ndarray, np.ndarray]:
    """Non-negative Double Singular Value Decomposition initialisation (Boutsidis 2008).

    Args:
        V: non-negative data matrix of shape (m, n).
        k: target rank.

    Returns:
        ``(W, H)`` with shapes ``(m, k)`` and ``(k, n)``; both non-negative.
    """
    m, n = V.shape
    U, S, Vt = np.linalg.svd(V, full_matrices=False)
    W = np.zeros((m, k))
    H = np.zeros((k, n))
    W[:, 0] = np.sqrt(S[0]) * np.abs(U[:, 0])
    H[0, :] = np.sqrt(S[0]) * np.abs(Vt[0, :])
    for j in range(1, min(k, len(S))):
        x, y = U[:, j], Vt[j, :]
        x_pos = np.maximum(x, 0); x_neg = np.maximum(-x, 0)
        y_pos = np.maximum(y, 0); y_neg = np.maximum(-y, 0)
        xp_norm = np.linalg.norm(x_pos); yp_norm = np.linalg.norm(y_pos)
        xn_norm = np.linalg.norm(x_neg); yn_norm = np.linalg.norm(y_neg)
        mp = xp_norm * yp_norm
        mn = xn_norm * yn_norm
        if mp > mn:
            u = x_pos / max(xp_norm, EPS)
            v = y_pos / max(yp_norm, EPS)
            sigma = mp
        else:
            u = x_neg / max(xn_norm, EPS)
            v = y_neg / max(yn_norm, EPS)
            sigma = mn
        W[:, j] = np.sqrt(S[j] * sigma) * u
        H[j, :] = np.sqrt(S[j] * sigma) * v
    # Replace exact zeros with small constants so multiplicative updates can move.
    avg = float(V.mean())
    W[W < EPS] = avg / 100.0
    H[H < EPS] = avg / 100.0
    return W, H


def frobenius_norm(V: np.ndarray, W: np.ndarray, H: np.ndarray) -> float:
    """Return ``||V - W H||_F``."""
    return float(np.linalg.norm(V - W @ H))


def kl_divergence(V: np.ndarray, W: np.ndarray, H: np.ndarray) -> float:
    """Return the generalized KL divergence ``D(V || WH)`` (Lee & Seung 2001)."""
    R = W @ H + EPS
    return float(np.sum(V * np.log((V + EPS) / R) - V + R))


def nmf_multiplicative_frobenius(
    V: np.ndarray,
    k: int,
    n_iter: int = 600,
    init: str = "nndsvd",
    seed: int = 0,
    tol: float = 1e-6,
) -> Tuple[np.ndarray, np.ndarray, Dict[str, float]]:
    """Lee-Seung multiplicative update rule with Frobenius loss.

    Args:
        V: non-negative data matrix of shape (m, n).
        k: number of components.
        n_iter: maximum iteration count.
        init: ``'nndsvd'`` (default) or ``'random'``.
        seed: RNG seed when ``init='random'``.
        tol: relative-change stopping threshold for the loss.

    Returns:
        ``(W, H, info)`` where ``info`` reports ``loss`` (final), ``iters``
        and ``converged``.
    """
    V = np.asarray(V, dtype=float)
    if init == "nndsvd":
        W, H = nndsvd_init(V, k)
    elif init == "random":
        W, H = random_init((V.shape[0], k), (k, V.shape[1]), seed=seed)
    else:
        raise ValueError(f"unknown init: {init}")
    prev = frobenius_norm(V, W, H)
    converged = False
    iters = 0
    for it in range(n_iter):
        iters = it + 1
        WtV = W.T @ V
        WtWH = W.T @ W @ H + EPS
        H = H * (WtV / WtWH)
        VHt = V @ H.T
        WHHt = W @ H @ H.T + EPS
        W = W * (VHt / WHHt)
        loss = frobenius_norm(V, W, H)
        if abs(prev - loss) < tol * max(1.0, prev):
            converged = True
            break
        prev = loss
    return W, H, {"loss": float(loss), "iters": int(iters), "converged": converged}


def nmf_multiplicative_kl(
    V: np.ndarray,
    k: int,
    n_iter: int = 600,
    init: str = "nndsvd",
    seed: int = 0,
    tol: float = 1e-6,
) -> Tuple[np.ndarray, np.ndarray, Dict[str, float]]:
    """Lee-Seung multiplicative update rule with generalized Kullback-Leibler loss."""
    V = np.asarray(V, dtype=float)
    if init == "nndsvd":
        W, H = nndsvd_init(V, k)
    elif init == "random":
        W, H = random_init((V.shape[0], k), (k, V.shape[1]), seed=seed)
    else:
        raise ValueError(f"unknown init: {init}")
    ones_m = np.ones(V.shape[0])
    ones_n = np.ones(V.shape[1])
    prev = kl_divergence(V, W, H)
    iters = 0
    converged = False
    for it in range(n_iter):
        iters = it + 1
        WH = W @ H + EPS
        H = H * ((W.T @ (V / WH)) / (W.T @ np.outer(ones_m, ones_n) + EPS))
        WH = W @ H + EPS
        W = W * (((V / WH) @ H.T) / (np.outer(ones_m, ones_n) @ H.T + EPS))
        loss = kl_divergence(V, W, H)
        if abs(prev - loss) < tol * max(1.0, abs(prev)):
            converged = True
            break
        prev = loss
    return W, H, {"loss": float(loss), "iters": int(iters), "converged": converged}


def normalize_signatures(W: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """Rescale columns of ``W`` to sum to 1; return both the new ``W`` and
    the column-scaling vector ``s`` such that ``W_old = W_new * s``.
    """
    s = W.sum(axis=0) + EPS
    return W / s, s


def reconstruction_error_curve(
    V: np.ndarray, k_values: range, n_iter: int = 400, seed: int = 0
) -> Dict[int, float]:
    """Run NMF for each ``k`` in ``k_values`` and return ``{k: frobenius_loss}``.

    A simple heuristic for selecting the rank ``K`` is to look for the
    ``elbow`` in the curve.
    """
    out: Dict[int, float] = {}
    for k in k_values:
        _, _, info = nmf_multiplicative_frobenius(V, k=int(k), n_iter=n_iter, seed=seed)
        out[int(k)] = info["loss"]
    return out


def bic_score(V: np.ndarray, W: np.ndarray, H: np.ndarray) -> float:
    """Approximate BIC for an NMF decomposition assuming Gaussian residuals.

    ``BIC = n_samples * log(RSS / n_samples) + k_params * log(n_samples)`` where
    ``RSS`` is the squared Frobenius norm of the residual and ``k_params`` is
    the total number of free parameters in ``W`` and ``H``.
    """
    m, n = V.shape
    k = W.shape[1]
    rss = float(np.sum((V - W @ H) ** 2))
    n_obs = m * n
    n_params = (m + n) * k
    return n_obs * np.log(rss / max(n_obs, 1) + EPS) + n_params * np.log(max(n_obs, 1))


def cophenetic_correlation(
    V: np.ndarray, k: int, n_runs: int = 20, n_iter: int = 300
) -> float:
    """Stability metric of Brunet et al. 2004 across ``n_runs`` random NMF runs.

    Returns the cophenetic correlation coefficient of the consensus matrix at
    rank ``k``.  Higher values (closer to 1) indicate a more reproducible
    factorisation.
    """
    n = V.shape[1]
    consensus = np.zeros((n, n))
    for r in range(n_runs):
        _, H, _ = nmf_multiplicative_frobenius(
            V, k=k, n_iter=n_iter, init="random", seed=r
        )
        labels = np.argmax(H, axis=0)
        same = (labels[:, None] == labels[None, :]).astype(float)
        consensus = consensus + same
    consensus = consensus / n_runs
    # Convert similarity to distance, run hierarchical clustering implicit in
    # cophenetic correlation: we just compute correlation between consensus
    # and its rank-1 binarisation as a lightweight surrogate.
    d = 1.0 - consensus
    # Off-diagonal entries:
    iu = np.triu_indices(n, k=1)
    flat = d[iu]
    # Build cophenetic via single-linkage on flat distances
    # to keep this self-contained we rely on scipy if available
    try:
        from scipy.cluster.hierarchy import linkage
        from scipy.spatial.distance import squareform

        Z = linkage(squareform(d, checks=False), method="average")
        # Cophenetic distances:
        coph = np.zeros_like(flat)
        # naive O(n^2) cophenetic:
        from scipy.cluster.hierarchy import cophenet

        coph_corr, _ = cophenet(Z, flat)
        return float(coph_corr)
    except Exception:
        # Fallback: correlation of distance vector with itself (= 1).
        return float(np.corrcoef(flat, flat)[0, 1])

"""Build the 96-channel SBS context matrix from variant calls + a reference.

Public API
----------
- ``mutation_types_96`` : ordered list of the 96 SBS channel labels.
- ``reverse_complement(seq)``
- ``classify_variant(ref_base, alt_base)``
- ``trinucleotide_context(reference, chrom, pos)``
- ``categorize_mutation(reference, chrom, pos, ref, alt)``
- ``build_sbs96_matrix(maf, reference)``
- ``trinucleotide_frequency(reference)``
- ``normalize_by_trinuc(counts, ref_freq, target_freq=None)``
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

PYRIMIDINES = ("C", "T")
SUBTYPES = ("C>A", "C>G", "C>T", "T>A", "T>C", "T>G")
BASES = ("A", "C", "G", "T")
_COMPLEMENT = str.maketrans("ACGTN", "TGCAN")


def reverse_complement(seq: str) -> str:
    """Return the reverse complement of ``seq``.  ``N`` maps to ``N``."""
    return seq.translate(_COMPLEMENT)[::-1]


def mutation_types_96() -> List[str]:
    """Return the canonical ordered list of the 96 SBS mutation type labels.

    Each label has the form ``L[ref>alt]R`` where ``L`` and ``R`` are the
    flanking bases and the central base is a pyrimidine (C or T).
    """
    out: List[str] = []
    for sub in SUBTYPES:
        ref = sub[0]
        alt = sub[2]
        for left in BASES:
            for right in BASES:
                out.append(f"{left}[{ref}>{alt}]{right}")
    return out


def classify_variant(ref_base: str, alt_base: str) -> Optional[Tuple[str, str, bool]]:
    """Convert an arbitrary single-base substitution to the pyrimidine convention.

    Args:
        ref_base: reference base (A/C/G/T).
        alt_base: alternate base (A/C/G/T, distinct from ref).

    Returns:
        ``(pyr_ref, pyr_alt, complemented)`` where ``pyr_ref`` is C or T.  The
        ``complemented`` flag indicates whether the call was strand-flipped.
        Returns ``None`` if either base is not in {A, C, G, T} or ref == alt.
    """
    if ref_base not in BASES or alt_base not in BASES or ref_base == alt_base:
        return None
    if ref_base in PYRIMIDINES:
        return ref_base, alt_base, False
    return reverse_complement(ref_base), reverse_complement(alt_base), True


def trinucleotide_context(reference: Dict[str, str], chrom: str, pos: int) -> Optional[str]:
    """Return the trinucleotide ``L{ref}R`` centred at 1-based ``pos`` on ``chrom``.

    Returns ``None`` if the position is at the chromosome edge or the chromosome
    is not in ``reference``.
    """
    seq = reference.get(chrom)
    if seq is None:
        return None
    i = pos - 1  # 0-based
    if i <= 0 or i >= len(seq) - 1:
        return None
    return seq[i - 1 : i + 2]


def categorize_mutation(
    reference: Dict[str, str],
    chrom: str,
    pos: int,
    ref: str,
    alt: str,
) -> Optional[str]:
    """Convert a single (chrom, pos, ref, alt) call to its 96-channel label.

    Returns ``None`` if the call cannot be classified (edge of chromosome, ref
    base inconsistent with the FASTA, non-SNV, etc.).
    """
    cls = classify_variant(ref, alt)
    if cls is None:
        return None
    pyr_ref, pyr_alt, flipped = cls
    tri = trinucleotide_context(reference, chrom, pos)
    if tri is None:
        return None
    if not all(b in BASES for b in tri):
        return None
    # Verify central base matches the reported ref (or its complement).
    central = tri[1]
    if central != ref and reverse_complement(central) != ref:
        return None
    if flipped:
        tri = reverse_complement(tri)
    return f"{tri[0]}[{pyr_ref}>{pyr_alt}]{tri[2]}"


def build_sbs96_matrix(maf: pd.DataFrame, reference: Dict[str, str]) -> pd.DataFrame:
    """Aggregate a MAF DataFrame into a 96 x n_samples integer count matrix.

    Args:
        maf: DataFrame with columns Sample, Chromosome, Position, Ref, Alt.
        reference: mapping from chromosome name to sequence (see ``load_fasta``).

    Returns:
        DataFrame with rows = the 96 ordered mutation types and columns = the
        samples observed in ``maf``.
    """
    types = mutation_types_96()
    samples = sorted(maf["Sample"].unique())
    M = pd.DataFrame(0, index=types, columns=samples, dtype=int)
    for s, chrom, pos, r, a in zip(
        maf["Sample"].values,
        maf["Chromosome"].astype(str).values,
        maf["Position"].astype(int).values,
        maf["Ref"].astype(str).values,
        maf["Alt"].astype(str).values,
    ):
        label = categorize_mutation(reference, chrom, pos, r, a)
        if label is None:
            continue
        M.at[label, s] += 1
    return M


def trinucleotide_frequency(reference: Dict[str, str]) -> Dict[str, int]:
    """Count occurrences of every pyrimidine-centred trinucleotide in ``reference``.

    Returns a dict whose keys are the 32 pyrimidine-centred trinucleotides.
    A trinucleotide whose central base is a purine (A or G) is counted under
    its reverse complement.
    """
    counts: Dict[str, int] = {}
    for left in BASES:
        for c in PYRIMIDINES:
            for right in BASES:
                counts[f"{left}{c}{right}"] = 0
    for seq in reference.values():
        for i in range(1, len(seq) - 1):
            tri = seq[i - 1 : i + 2]
            if any(b not in BASES for b in tri):
                continue
            if tri[1] in PYRIMIDINES:
                counts[tri] = counts.get(tri, 0) + 1
            else:
                rc = reverse_complement(tri)
                counts[rc] = counts.get(rc, 0) + 1
    return counts


def normalize_by_trinuc(
    counts: pd.DataFrame,
    ref_freq: Dict[str, int],
    target_freq: Optional[Dict[str, int]] = None,
) -> pd.DataFrame:
    """Rescale a 96 x n_samples matrix to correct for trinucleotide composition.

    The transformation is ``counts[i, j] *= target_freq[i] / ref_freq[i]``.
    If ``target_freq`` is None each trinucleotide is reweighted to a uniform
    distribution.

    Args:
        counts: 96 x n_samples DataFrame indexed by mutation type label.
        ref_freq: counts of every pyrimidine trinucleotide in the reference
            (e.g. the output of ``trinucleotide_frequency``).
        target_freq: optional desired trinucleotide weights.

    Returns:
        DataFrame of the same shape as ``counts`` with rescaled values.
    """
    out = counts.astype(float).copy()
    for label in out.index:
        tri = label[0] + label[2] + label[-1]  # L + ref + R
        if target_freq is None:
            num = 1.0
        else:
            num = float(target_freq.get(tri, 0))
        denom = float(ref_freq.get(tri, 0))
        if denom == 0:
            out.loc[label, :] = 0.0
        else:
            out.loc[label, :] *= num / denom
    return out

"""I/O helpers for the mutational signature task.

Each function here parses one of the shipped input files and returns plain
``pandas`` / ``numpy`` objects.  No domain logic (NMF, signature attribution,
context extraction, ...) is performed here.
"""

from __future__ import annotations

import os
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd


def load_maf(path: str) -> pd.DataFrame:
    """Load a tab-separated MAF/VCF-like mutation table.

    The file must have the columns ``Sample``, ``Chromosome``, ``Position``,
    ``Ref`` and ``Alt``.  All other columns are kept verbatim.

    Args:
        path: absolute or relative path to the file.

    Returns:
        DataFrame with one row per somatic single-nucleotide variant.
    """
    df = pd.read_csv(path, sep="\t", dtype={"Chromosome": str})
    required = {"Sample", "Chromosome", "Position", "Ref", "Alt"}
    missing = required.difference(df.columns)
    if missing:
        raise ValueError(f"MAF is missing columns: {sorted(missing)}")
    df["Position"] = df["Position"].astype(int)
    return df


def load_fasta(path: str) -> Dict[str, str]:
    """Read a FASTA file and return ``{chromosome_name: sequence}``.

    Args:
        path: path to a FASTA file.

    Returns:
        Mapping from sequence name (text after ``>`` and before the first
        whitespace) to the concatenated sequence string in upper case.
    """
    seqs: Dict[str, List[str]] = {}
    name = None
    with open(path) as f:
        for line in f:
            line = line.rstrip("\n")
            if not line:
                continue
            if line.startswith(">"):
                name = line[1:].split()[0]
                seqs[name] = []
            else:
                if name is None:
                    raise ValueError("FASTA does not start with a > header")
                seqs[name].append(line.strip().upper())
    return {k: "".join(v) for k, v in seqs.items()}


def load_sbs96_matrix(path: str) -> pd.DataFrame:
    """Load a 96-channel SBS count matrix saved as TSV.

    The first column is the mutation type (e.g. ``A[C>A]A``); subsequent columns
    are samples.

    Returns:
        DataFrame with 96 rows (mutation types) and N sample columns.
    """
    df = pd.read_csv(path, sep="\t", index_col=0)
    if df.shape[0] != 96:
        raise ValueError(f"Expected 96 mutation types, got {df.shape[0]}")
    return df


def load_cosmic_reference(path: str) -> pd.DataFrame:
    """Load the COSMIC v3 SBS reference signature file.

    Args:
        path: path to ``COSMIC_v3.4_SBS_GRCh37.txt`` (or compatible).

    Returns:
        DataFrame with shape ``(96, n_signatures)``: rows indexed by mutation
        type (e.g. ``A[C>A]A``) and columns indexed by signature ID
        (``SBS1``, ``SBS2``, ...).  Each column sums to 1.
    """
    df = pd.read_csv(path, sep="\t", index_col=0)
    if df.shape[0] != 96:
        raise ValueError("COSMIC file must have 96 rows")
    return df


def load_sample_metadata(path: str) -> pd.DataFrame:
    """Load the sample-level metadata CSV (sample id and per-sample annotation columns)."""
    df = pd.read_csv(path)
    if "sampleID" not in df.columns:
        raise ValueError("metadata must contain a 'sampleID' column")
    return df.set_index("sampleID")


def list_input_files(data_dir: str) -> Dict[str, str]:
    """Return a dictionary of well-known shipped input files in ``data_dir``."""
    out = {}
    for name in os.listdir(data_dir):
        full = os.path.join(data_dir, name)
        if os.path.isfile(full):
            out[name] = os.path.abspath(full)
    return out

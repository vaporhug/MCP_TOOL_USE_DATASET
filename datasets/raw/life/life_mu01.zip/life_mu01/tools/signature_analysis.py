"""Signature comparison, attribution and refit tools.

Pure helper code on top of the NMF module: nothing here knows about specific
biological conclusions or specific sample IDs.
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

EPS = 1e-12


def cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
    """Cosine similarity between two non-zero vectors."""
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    na = np.linalg.norm(a)
    nb = np.linalg.norm(b)
    if na == 0 or nb == 0:
        return 0.0
    return float(np.dot(a, b) / (na * nb))


def cosine_similarity_matrix(A: pd.DataFrame, B: pd.DataFrame) -> pd.DataFrame:
    """Pairwise cosine similarity between every column of ``A`` and ``B``.

    Both DataFrames must share the same row index (i.e. the 96 mutation types).
    """
    common = A.index.intersection(B.index)
    a = A.loc[common].values
    b = B.loc[common].values
    a_norm = a / (np.linalg.norm(a, axis=0, keepdims=True) + EPS)
    b_norm = b / (np.linalg.norm(b, axis=0, keepdims=True) + EPS)
    sim = a_norm.T @ b_norm
    return pd.DataFrame(sim, index=A.columns, columns=B.columns)


def match_signatures_to_cosmic(
    extracted: pd.DataFrame, cosmic: pd.DataFrame, threshold: float = 0.8
) -> pd.DataFrame:
    """For every extracted signature, list its best COSMIC match and similarity.

    Args:
        extracted: 96 x K DataFrame of extracted signatures (column-normalised).
        cosmic: 96 x M DataFrame of reference signatures.
        threshold: similarity below which the match is reported as ``None``.

    Returns:
        DataFrame with one row per extracted signature and columns
        ``best_cosmic``, ``cosine``, ``second_cosmic``, ``second_cosine``.
    """
    sim = cosine_similarity_matrix(extracted, cosmic)
    rows = []
    for sig in extracted.columns:
        order = sim.loc[sig].sort_values(ascending=False)
        best = order.index[0]
        best_v = float(order.iloc[0])
        second = order.index[1]
        second_v = float(order.iloc[1])
        rows.append(
            {
                "signature": sig,
                "best_cosmic": best if best_v >= threshold else None,
                "cosine": best_v,
                "second_cosmic": second,
                "second_cosine": second_v,
            }
        )
    return pd.DataFrame(rows).set_index("signature")


def nnls_solve(A: np.ndarray, b: np.ndarray, n_iter: int = 500) -> np.ndarray:
    """Multiplicative-update NNLS solver: solve ``min ||A x - b||`` with x >= 0.

    A simple, dependency-free fallback to scipy.optimize.nnls.

    Args:
        A: matrix of shape (m, k).
        b: vector of length m (non-negative).
        n_iter: number of multiplicative-update iterations.

    Returns:
        x: vector of length k (non-negative).
    """
    A = np.asarray(A, dtype=float)
    b = np.asarray(b, dtype=float)
    k = A.shape[1]
    x = np.full(k, max(b.mean(), EPS))
    AtA = A.T @ A + EPS * np.eye(k)
    Atb = A.T @ b
    for _ in range(n_iter):
        denom = AtA @ x + EPS
        x = x * (Atb / denom)
        x = np.clip(x, 0.0, None)
    return x


def attribute_exposures(
    counts: pd.DataFrame, signatures: pd.DataFrame
) -> pd.DataFrame:
    """Refit per-sample signature exposures by NNLS.

    For every sample ``j`` in ``counts``, solve
    ``min_x || counts[:, j] - signatures @ x ||`` with ``x >= 0``.

    Args:
        counts: 96 x n_samples non-negative count matrix.
        signatures: 96 x K signature matrix (e.g. column-normalised).

    Returns:
        K x n_samples DataFrame of exposures (counts of mutations attributed
        to each signature for each sample).
    """
    A = signatures.loc[counts.index].values
    out = np.zeros((signatures.shape[1], counts.shape[1]))
    for j, sample in enumerate(counts.columns):
        b = counts.iloc[:, j].values.astype(float)
        out[:, j] = nnls_solve(A, b)
    return pd.DataFrame(out, index=signatures.columns, columns=counts.columns)


def exposure_to_proportion(exposures: pd.DataFrame) -> pd.DataFrame:
    """Convert mutation-count exposures to per-sample proportions (columns sum to 1)."""
    s = exposures.sum(axis=0).replace(0, np.nan)
    return (exposures / s).fillna(0.0)


def reconstruct(W: pd.DataFrame, H: pd.DataFrame) -> pd.DataFrame:
    """Multiply signature matrix by exposures to get reconstructed counts."""
    return pd.DataFrame(
        W.values @ H.values, index=W.index, columns=H.columns
    )


def reconstruction_cosine(
    V: pd.DataFrame, V_hat: pd.DataFrame
) -> pd.Series:
    """Per-sample cosine similarity between observed and reconstructed counts."""
    sims = []
    for col in V.columns:
        sims.append(cosine_similarity(V[col].values, V_hat[col].values))
    return pd.Series(sims, index=V.columns, name="reconstruction_cosine")


def hierarchical_cluster_samples(
    exposures: pd.DataFrame, method: str = "average"
) -> List[str]:
    """Hierarchical (single-linkage by default) clustering of samples by exposure profile.

    Returns the leaf order so that samples with similar exposures are adjacent.
    """
    from scipy.cluster.hierarchy import linkage, leaves_list
    from scipy.spatial.distance import pdist

    X = exposures.values.T  # n_samples x K
    # Cosine distance is the natural metric for proportional profiles.
    d = pdist(X, metric="cosine")
    Z = linkage(d, method=method)
    order = leaves_list(Z)
    return [str(exposures.columns[i]) for i in order]

"""Plotting utilities for the mutational signature task.

Each function returns ``{"path": "<absolute path to PNG>"}``.  All plots use
matplotlib's ``Agg`` backend so they render in headless environments.
"""

from __future__ import annotations

import os
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


_SUBTYPES = ["C>A", "C>G", "C>T", "T>A", "T>C", "T>G"]
_SUBTYPE_COLORS = {
    "C>A": "#03BCEE",
    "C>G": "#010101",
    "C>T": "#E32925",
    "T>A": "#CAC9C9",
    "T>C": "#A1CE63",
    "T>G": "#EBC6C4",
}


def _save(fig: plt.Figure, path: str) -> Dict[str, str]:
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    fig.tight_layout()
    fig.savefig(path, dpi=140, bbox_inches="tight")
    plt.close(fig)
    return {"path": os.path.abspath(path)}


def _channel_subtype(label: str) -> str:
    return label[2:5]


def plot_sbs96_profile(
    profile: pd.Series, out_path: str, title: Optional[str] = None
) -> Dict[str, str]:
    """Bar plot of a single 96-channel SBS profile (one signature or one sample).

    ``profile`` must be indexed by the 96 mutation type labels (e.g. ``A[C>A]A``).
    """
    labels = list(profile.index)
    values = profile.values.astype(float)
    fig, ax = plt.subplots(figsize=(13, 3.4))
    colors = [_SUBTYPE_COLORS[_channel_subtype(l)] for l in labels]
    x = np.arange(len(labels))
    ax.bar(x, values, color=colors, width=0.8)
    ax.set_xticks(x)
    ax.set_xticklabels([l[0] + l[-1] for l in labels], fontsize=6, rotation=90)
    ax.set_ylabel("Probability / count")
    # Coloured subtype banner along the top
    n_per = 16
    for i, sub in enumerate(_SUBTYPES):
        ax.axvspan(
            i * n_per - 0.5,
            (i + 1) * n_per - 0.5,
            ymin=0.97,
            ymax=1.0,
            color=_SUBTYPE_COLORS[sub],
            alpha=0.95,
        )
        ax.text(
            i * n_per + n_per / 2 - 0.5,
            ax.get_ylim()[1] * 1.02,
            sub,
            ha="center",
            va="bottom",
            fontsize=9,
            fontweight="bold",
        )
    if title:
        ax.set_title(title)
    ax.set_xlim(-0.5, len(labels) - 0.5)
    return _save(fig, out_path)


def plot_signature_panel(
    signatures: pd.DataFrame, out_path: str, title: Optional[str] = None
) -> Dict[str, str]:
    """Stack of ``plot_sbs96_profile`` panels, one per column of ``signatures``.

    Args:
        signatures: 96 x K DataFrame.
        out_path: PNG path.
    """
    K = signatures.shape[1]
    fig, axes = plt.subplots(K, 1, figsize=(13, 2.0 * K + 0.5), sharex=True)
    if K == 1:
        axes = [axes]
    for ax, sig in zip(axes, signatures.columns):
        values = signatures[sig].values.astype(float)
        labels = list(signatures.index)
        colors = [_SUBTYPE_COLORS[_channel_subtype(l)] for l in labels]
        x = np.arange(len(labels))
        ax.bar(x, values, color=colors, width=0.8)
        ax.set_ylabel(str(sig), fontsize=10)
        ax.set_xticks(x)
        ax.set_xticklabels([l[0] + l[-1] for l in labels], fontsize=5, rotation=90)
    if title:
        fig.suptitle(title, y=1.0)
    return _save(fig, out_path)


def plot_exposure_stacked_bar(
    proportions: pd.DataFrame,
    out_path: str,
    title: Optional[str] = None,
    sample_order: Optional[List[str]] = None,
) -> Dict[str, str]:
    """Stacked-bar plot of per-sample signature contributions.

    Args:
        proportions: K x n_samples DataFrame; rows = signatures, columns sum to 1.
        out_path: PNG path.
        sample_order: optional ordering for the columns.
    """
    if sample_order is not None:
        proportions = proportions[sample_order]
    fig, ax = plt.subplots(figsize=(max(6.0, 0.45 * proportions.shape[1] + 2), 4.2))
    bottom = np.zeros(proportions.shape[1])
    cmap = plt.get_cmap("tab10")
    for i, sig in enumerate(proportions.index):
        vals = proportions.loc[sig].values.astype(float)
        ax.bar(
            range(proportions.shape[1]),
            vals,
            bottom=bottom,
            color=cmap(i % 10),
            label=str(sig),
        )
        bottom = bottom + vals
    ax.set_xticks(range(proportions.shape[1]))
    ax.set_xticklabels(list(proportions.columns.astype(str)), rotation=90, fontsize=8)
    ax.set_ylabel("Signature contribution")
    ax.set_ylim(0, 1.02)
    ax.legend(bbox_to_anchor=(1.02, 1.0), loc="upper left", fontsize=8)
    if title:
        ax.set_title(title)
    return _save(fig, out_path)


def plot_cosine_heatmap(
    sim: pd.DataFrame, out_path: str, title: Optional[str] = None
) -> Dict[str, str]:
    """Heatmap of a cosine-similarity matrix.

    Args:
        sim: DataFrame whose entries are in [-1, 1] (typically [0, 1]).
        out_path: PNG path.
    """
    fig, ax = plt.subplots(figsize=(min(0.32 * sim.shape[1] + 2.5, 16), 0.4 * sim.shape[0] + 1.6))
    im = ax.imshow(sim.values, aspect="auto", cmap="viridis", vmin=0.0, vmax=1.0)
    ax.set_xticks(range(sim.shape[1]))
    ax.set_xticklabels(list(sim.columns.astype(str)), rotation=90, fontsize=7)
    ax.set_yticks(range(sim.shape[0]))
    ax.set_yticklabels(list(sim.index.astype(str)), fontsize=8)
    fig.colorbar(im, ax=ax, shrink=0.6, label="cosine similarity")
    if title:
        ax.set_title(title)
    return _save(fig, out_path)


def plot_reconstruction_curve(
    losses: Dict[int, float], out_path: str, title: Optional[str] = None
) -> Dict[str, str]:
    """Line plot of NMF reconstruction loss versus rank ``K``."""
    ks = sorted(losses)
    vs = [losses[k] for k in ks]
    fig, ax = plt.subplots(figsize=(5.2, 3.6))
    ax.plot(ks, vs, marker="o", color="#1f77b4")
    ax.set_xlabel("Number of components K")
    ax.set_ylabel("Frobenius reconstruction loss")
    ax.grid(alpha=0.3)
    if title:
        ax.set_title(title)
    return _save(fig, out_path)


def plot_dendrogram(
    distance_matrix: pd.DataFrame, out_path: str, title: Optional[str] = None
) -> Dict[str, str]:
    """Hierarchical-clustering dendrogram from a square distance DataFrame."""
    from scipy.cluster.hierarchy import linkage, dendrogram
    from scipy.spatial.distance import squareform

    d = distance_matrix.values
    d = (d + d.T) / 2.0
    np.fill_diagonal(d, 0.0)
    Z = linkage(squareform(d, checks=False), method="average")
    fig, ax = plt.subplots(figsize=(max(5, 0.35 * len(distance_matrix.columns) + 1.5), 4.2))
    dendrogram(Z, labels=list(distance_matrix.columns.astype(str)), leaf_rotation=90, ax=ax)
    if title:
        ax.set_title(title)
    return _save(fig, out_path)


def plot_total_burden_bar(
    counts: pd.DataFrame, out_path: str, title: Optional[str] = None
) -> Dict[str, str]:
    """Bar plot of total mutation burden per sample, with a log y-axis."""
    totals = counts.sum(axis=0).sort_values(ascending=False)
    fig, ax = plt.subplots(figsize=(max(5, 0.35 * len(totals) + 1.5), 3.6))
    ax.bar(range(len(totals)), totals.values, color="#444")
    ax.set_xticks(range(len(totals)))
    ax.set_xticklabels(list(totals.index.astype(str)), rotation=90, fontsize=8)
    ax.set_yscale("log")
    ax.set_ylabel("Substitutions (log scale)")
    if title:
        ax.set_title(title)
    return _save(fig, out_path)

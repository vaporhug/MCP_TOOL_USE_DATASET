"""Gene-presence/absence pan-genome-wide association testing.

Implements Fisher's exact test, chi-squared test (independent normal
approximation) and Benjamini-Hochberg false-discovery-rate correction in
pure pandas/numpy/Python -- no scipy. Used to recover the paper's
N. gonorrhoeae pyseer pan-GWAS finding (67 genes at adjusted p<=0.05).
"""
from __future__ import annotations

from math import lgamma, log, exp
from typing import List

import numpy as np
import pandas as pd


# ---------------------------------------------------------------------------
# Pure-Python Fisher's exact test (two-sided), no scipy.
# ---------------------------------------------------------------------------

def _log_binom(n: int, k: int) -> float:
    if k < 0 or k > n:
        return float("-inf")
    return lgamma(n + 1) - lgamma(k + 1) - lgamma(n - k + 1)


def _hypergeom_logpmf(k: int, M: int, n: int, N: int) -> float:
    """log P(X=k) for X ~ Hypergeom(M, n, N): drawing N from a pop of M
    where n are 'good'. k = number of good drawn.
    """
    if k < max(0, N + n - M) or k > min(n, N):
        return float("-inf")
    return _log_binom(n, k) + _log_binom(M - n, N - k) - _log_binom(M, N)


def fisher_exact_2x2(a: int, b: int, c: int, d: int) -> float:
    """Two-sided Fisher's exact test on the 2x2 table::

            present  absent
        case   a       c
        ctrl   b       d

    Returns the two-sided p-value. Uses the standard "sum of all tables with
    log-pmf <= log-pmf of observed" definition.
    """
    M = a + b + c + d        # grand total
    n_present = a + b        # 'good' draws
    N_case = a + c           # cases drawn from the urn
    log_obs = _hypergeom_logpmf(a, M, n_present, N_case)
    if log_obs == float("-inf"):
        return 1.0
    # Enumerate all possible a-values consistent with the marginals.
    a_min = max(0, N_case + n_present - M)
    a_max = min(n_present, N_case)
    p = 0.0
    for k in range(a_min, a_max + 1):
        lp = _hypergeom_logpmf(k, M, n_present, N_case)
        if lp <= log_obs + 1e-12:
            p += exp(lp)
    return float(min(1.0, p))


# ---------------------------------------------------------------------------
# Chi-square approximation (no scipy): standard 1-d.o.f. survival via series.
# ---------------------------------------------------------------------------

def _chi2_sf_1df(x: float) -> float:
    """Survival function of chi^2_1 = 1 - CDF. Computed as 2 * (1 - Phi(sqrt(x)))
    using a series expansion of the standard normal CDF.
    """
    if x <= 0:
        return 1.0
    z = x ** 0.5
    # Abramowitz-Stegun 26.2.17 rational approximation for Phi(z).
    t = 1.0 / (1.0 + 0.2316419 * z)
    poly = (((1.330274429 * t - 1.821255978) * t + 1.781477937) * t
            - 0.356563782) * t + 0.319381530
    pdf = (1.0 / ((2.0 * 3.141592653589793) ** 0.5)) * exp(-0.5 * z * z)
    sf = pdf * t * poly
    return float(min(1.0, 2.0 * sf))


def chi_square_2x2(a: int, b: int, c: int, d: int) -> float:
    """Pearson chi-square p-value for the 2x2 table above. Uses the standard
    1-d.o.f. expression and the normal-tail approximation for the survival
    function. Returns 1.0 if any expected cell is zero.
    """
    n = a + b + c + d
    if n == 0:
        return 1.0
    row1 = a + c; row2 = b + d
    col1 = a + b; col2 = c + d
    if row1 == 0 or row2 == 0 or col1 == 0 or col2 == 0:
        return 1.0
    # chi^2 = n * (ad - bc)^2 / (col1 * col2 * row1 * row2)
    num = n * (a * d - b * c) ** 2
    den = col1 * col2 * row1 * row2
    chi2 = num / den
    return _chi2_sf_1df(chi2)


# ---------------------------------------------------------------------------
# Benjamini-Hochberg FDR
# ---------------------------------------------------------------------------

def benjamini_hochberg(pvals: np.ndarray) -> np.ndarray:
    """Benjamini-Hochberg adjusted p-values for an array of raw p-values.

    Standard step-up procedure: q_i = min over j>=rank(i) of p_(j) * m / j,
    where m is the number of tests. Returns an array of the same shape as
    ``pvals`` with adjusted p-values clipped to [0, 1].
    """
    p = np.asarray(pvals, dtype=float)
    m = p.size
    order = np.argsort(p)
    ranks = np.arange(1, m + 1)
    sorted_p = p[order]
    adj = sorted_p * m / ranks
    adj = np.minimum.accumulate(adj[::-1])[::-1]
    out = np.empty_like(adj)
    out[order] = adj
    return np.clip(out, 0.0, 1.0)


# ---------------------------------------------------------------------------
# Main GWAS driver
# ---------------------------------------------------------------------------

def presence_absence_gwas(matrix: pd.DataFrame,
                          phenotype: np.ndarray,
                          test: str = "fisher",
                          min_freq: float = 0.05,
                          max_freq: float = 0.95) -> pd.DataFrame:
    """Per-gene association test against a binary phenotype.

    For each gene cluster, tabulate its 0/1 presence vector across the
    isolates, compute a 2x2 contingency with the binary phenotype, and run
    either a Fisher exact test or a Pearson chi-square test. Genes outside
    the [min_freq, max_freq] presence band are skipped (returned with
    p_value = NaN) since they are uninformative.

    Parameters
    ----------
    matrix : pd.DataFrame
        Gene x genome 0/1 matrix already aligned to ``phenotype`` order.
    phenotype : array-like
        Length n_genomes binary vector (0/1).
    test : {"fisher", "chi2"}
    min_freq, max_freq : float
        Frequency cutoffs for filtering uninformative genes.

    Returns
    -------
    pd.DataFrame indexed by Gene with columns
        n_present, n_absent, n_present_case, n_present_ctrl,
        odds_ratio, p_value, p_value_bh
    """
    if test not in ("fisher", "chi2"):
        raise ValueError("test must be 'fisher' or 'chi2'")
    y = np.asarray(phenotype).astype(int)
    n_genomes = matrix.shape[1]
    if y.size != n_genomes:
        raise ValueError(f"phenotype length {y.size} != n_genomes {n_genomes}")
    M = matrix.values.astype(np.int8)
    freqs = M.sum(axis=1) / n_genomes

    n_genes = M.shape[0]
    p_vals = np.full(n_genes, np.nan)
    ors = np.full(n_genes, np.nan)
    a_arr = np.zeros(n_genes, dtype=int)
    b_arr = np.zeros(n_genes, dtype=int)
    c_arr = np.zeros(n_genes, dtype=int)
    d_arr = np.zeros(n_genes, dtype=int)

    case_mask = (y == 1)
    ctrl_mask = ~case_mask
    for g in range(n_genes):
        if not (min_freq <= freqs[g] <= max_freq):
            continue
        present = M[g].astype(bool)
        a = int(np.logical_and(present, case_mask).sum())
        b = int(np.logical_and(present, ctrl_mask).sum())
        c = int(np.logical_and(~present, case_mask).sum())
        d = int(np.logical_and(~present, ctrl_mask).sum())
        a_arr[g], b_arr[g], c_arr[g], d_arr[g] = a, b, c, d
        # Haldane-Anscombe correction for OR if any zero cell.
        a2, b2, c2, d2 = a, b, c, d
        if 0 in (a, b, c, d):
            a2, b2, c2, d2 = a + 0.5, b + 0.5, c + 0.5, d + 0.5
        ors[g] = (a2 * d2) / (b2 * c2) if (b2 * c2) > 0 else float("inf")
        if test == "fisher":
            p_vals[g] = fisher_exact_2x2(a, b, c, d)
        else:
            p_vals[g] = chi_square_2x2(a, b, c, d)

    out = pd.DataFrame({
        "n_present":       a_arr + b_arr,
        "n_absent":        c_arr + d_arr,
        "n_present_case":  a_arr,
        "n_present_ctrl":  b_arr,
        "odds_ratio":      ors,
        "p_value":         p_vals,
    }, index=matrix.index)
    # Adjust only the tested genes (non-NaN).
    tested = ~np.isnan(out["p_value"].values)
    bh = np.full(n_genes, np.nan)
    if tested.any():
        bh[tested] = benjamini_hochberg(out["p_value"].values[tested])
    out["p_value_bh"] = bh
    return out


def top_significant_genes(gwas: pd.DataFrame,
                          alpha: float = 0.05,
                          top_n: int = 20) -> pd.DataFrame:
    """Return the top ``top_n`` genes by adjusted p, restricted to those with
    p_value_bh <= alpha. Sorted by adjusted p ascending then odds ratio desc.
    """
    sub = gwas.dropna(subset=["p_value_bh"]).copy()
    sub = sub[sub["p_value_bh"] <= alpha]
    sub = sub.sort_values(["p_value_bh", "odds_ratio"],
                          ascending=[True, False])
    return sub.head(top_n)

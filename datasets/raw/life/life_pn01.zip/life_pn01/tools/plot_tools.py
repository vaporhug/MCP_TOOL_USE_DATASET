"""Plotting primitives for the bacterial pangenome benchmark.

Every function returns ``{"path": output_path}`` and writes a PNG. Pure
matplotlib; no scipy, no seaborn, no networkx.
"""
from __future__ import annotations

import os
from typing import Dict, Sequence

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def _ensure_dir(path: str) -> None:
    d = os.path.dirname(os.path.abspath(path))
    if d and not os.path.isdir(d):
        os.makedirs(d, exist_ok=True)


# ---------------------------------------------------------------------------
# 1. Pangenome accumulation curve
# ---------------------------------------------------------------------------

def plot_rarefaction(curve: pd.DataFrame,
                     output_path: str,
                     title: str = "Pangenome accumulation curve",
                     show_core: bool = True) -> Dict[str, str]:
    """Pangenome (and optionally core) curve as a function of sampled
    genomes, with one-sigma shading.
    """
    _ensure_dir(output_path)
    fig, ax = plt.subplots(figsize=(7, 5))
    n = curve["n_genomes"].values
    pang = curve["pangenome_mean"].values
    pang_sd = curve["pangenome_std"].values
    ax.plot(n, pang, color="#c0392b", lw=2.0, label="Pangenome (union)")
    ax.fill_between(n, pang - pang_sd, pang + pang_sd, color="#c0392b", alpha=0.2)
    if show_core and "core_mean" in curve.columns:
        core = curve["core_mean"].values
        core_sd = curve["core_std"].values
        ax.plot(n, core, color="#2c3e50", lw=2.0, label="Core (intersection)")
        ax.fill_between(n, core - core_sd, core + core_sd, color="#2c3e50", alpha=0.2)
    ax.set_xlabel("Number of genomes sampled")
    ax.set_ylabel("Number of gene clusters")
    ax.set_title(title)
    ax.grid(alpha=0.3)
    ax.legend(loc="center right")
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path}


# ---------------------------------------------------------------------------
# 2. Gene-frequency histogram
# ---------------------------------------------------------------------------

def plot_gene_frequency_histogram(matrix: pd.DataFrame,
                                  output_path: str,
                                  n_bins: int = 50,
                                  title: str = "Gene-frequency distribution",
                                  log_y: bool = True) -> Dict[str, str]:
    """Histogram of per-gene presence counts. The classic U-shape (lots of
    rare genes + lots of core genes) is the signature of a bacterial
    pangenome.
    """
    _ensure_dir(output_path)
    n_genomes = matrix.shape[1]
    counts = matrix.sum(axis=1).astype(int).values
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.hist(counts, bins=n_bins, color="#2980b9", edgecolor="white")
    if log_y:
        ax.set_yscale("log")
    ax.set_xlabel(f"Number of genomes carrying the gene (out of {n_genomes})")
    ax.set_ylabel("Number of gene clusters")
    ax.set_title(title)
    ax.grid(alpha=0.3, axis="y")
    # Shade tier boundaries for context.
    ax.axvspan(0.99 * n_genomes, n_genomes, color="#27ae60", alpha=0.10, label="core")
    ax.axvspan(0.95 * n_genomes, 0.99 * n_genomes, color="#16a085", alpha=0.10, label="soft-core")
    ax.axvspan(0.15 * n_genomes, 0.95 * n_genomes, color="#f39c12", alpha=0.05, label="shell")
    ax.axvspan(0, 0.15 * n_genomes, color="#c0392b", alpha=0.05, label="cloud")
    ax.legend(loc="upper center", ncol=4, fontsize=8)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path}


# ---------------------------------------------------------------------------
# 3. Core / accessory bar chart
# ---------------------------------------------------------------------------

def plot_tier_bars(tier_summary_df: pd.DataFrame,
                   output_path: str,
                   title: str = "Pangenome composition") -> Dict[str, str]:
    """Bar chart of n_genes per tier (core, soft-core, shell, cloud).
    Useful as a single-panel reproduction of the paper's Fig. 4a-style
    Roary vs Panaroo composition comparisons.
    """
    _ensure_dir(output_path)
    order = ["core", "soft_core", "shell", "cloud"]
    df = tier_summary_df.set_index("tier").loc[order]
    fig, ax = plt.subplots(figsize=(7, 5))
    colors = ["#27ae60", "#16a085", "#f39c12", "#c0392b"]
    bars = ax.bar(order, df["n_genes"].values, color=colors, edgecolor="black")
    for b, v in zip(bars, df["n_genes"].values):
        ax.text(b.get_x() + b.get_width() / 2, b.get_height(), f"{int(v):,}",
                ha="center", va="bottom", fontsize=10)
    ax.set_ylabel("Number of gene clusters")
    ax.set_title(title)
    ax.grid(alpha=0.3, axis="y")
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path}


# ---------------------------------------------------------------------------
# 4. Manhattan-style pan-GWAS plot
# ---------------------------------------------------------------------------

def plot_pangwas_manhattan(gwas: pd.DataFrame,
                           output_path: str,
                           bonferroni_alpha: float = 0.05,
                           top_label_n: int = 5,
                           title: str = "Pan-GWAS Manhattan plot",
                           highlight: Sequence[str] = ()) -> Dict[str, str]:
    """Manhattan-style plot of -log10(p) per gene, with the BH and Bonferroni
    significance lines. Optionally label the top hits and highlight specific
    gene names (e.g. ``tetM``).
    """
    _ensure_dir(output_path)
    sub = gwas.dropna(subset=["p_value"]).copy()
    sub["neglog10_p"] = -np.log10(np.clip(sub["p_value"].values, 1e-300, 1.0))
    n = len(sub)
    bonf = -np.log10(bonferroni_alpha / max(1, n))

    fig, ax = plt.subplots(figsize=(11, 5))
    x = np.arange(len(sub))
    colors = np.where(sub["p_value_bh"].values <= 0.05, "#c0392b", "#7f8c8d")
    ax.scatter(x, sub["neglog10_p"].values, c=colors, s=12, alpha=0.7)
    ax.axhline(bonf, color="#2c3e50", lw=1.0, linestyle="--",
               label=f"Bonferroni (a={bonferroni_alpha})")
    ax.axhline(-np.log10(0.05), color="#16a085", lw=1.0, linestyle=":",
               label="Nominal p=0.05")

    # Label top N significant genes.
    top = sub.sort_values("p_value").head(top_label_n)
    for gene in top.index:
        gx = int(np.where(sub.index == gene)[0][0])
        gy = float(sub.loc[gene, "neglog10_p"])
        ax.annotate(gene, (gx, gy), xytext=(4, 4), textcoords="offset points",
                    fontsize=9, color="#c0392b")

    # Custom highlights.
    for gene in highlight:
        if gene in sub.index:
            gx = int(np.where(sub.index == gene)[0][0])
            gy = float(sub.loc[gene, "neglog10_p"])
            ax.scatter([gx], [gy], s=80, edgecolor="black", facecolor="#f1c40f", zorder=5)
            ax.annotate(gene, (gx, gy), xytext=(6, -10),
                        textcoords="offset points", fontsize=10,
                        color="black", weight="bold")

    ax.set_xlabel("Gene cluster index (sorted as in matrix)")
    ax.set_ylabel(r"$-\log_{10}\,p$")
    ax.set_title(title)
    ax.grid(alpha=0.3)
    ax.legend(loc="upper right", fontsize=8)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path}


# ---------------------------------------------------------------------------
# 5. Tool-comparison bar chart (paper Fig. 2 / Fig. 4a style)
# ---------------------------------------------------------------------------

def plot_tool_comparison(comparison_df: pd.DataFrame,
                         output_path: str,
                         title: str = "Pangenome composition by tool") -> Dict[str, str]:
    """Grouped bar chart of total / core / accessory gene counts across
    pangenome tools, mirroring Fig. 2 / Fig. 4a in the Panaroo paper.

    ``comparison_df`` columns: tool, total, core, accessory.
    """
    _ensure_dir(output_path)
    df = comparison_df.set_index("tool")
    tools = df.index.tolist()
    x = np.arange(len(tools))
    w = 0.27
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.bar(x - w, df["total"].values,     w, label="Total pangenome",
           color="#7f8c8d", edgecolor="black")
    ax.bar(x,     df["core"].values,      w, label="Core (>=99 %)",
           color="#27ae60", edgecolor="black")
    ax.bar(x + w, df["accessory"].values, w, label="Accessory (<99 %)",
           color="#c0392b", edgecolor="black")
    ax.set_xticks(x)
    ax.set_xticklabels(tools, rotation=20, ha="right")
    ax.set_ylabel("Number of gene clusters")
    ax.set_title(title)
    ax.grid(alpha=0.3, axis="y")
    ax.legend(loc="upper right", fontsize=9)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path}

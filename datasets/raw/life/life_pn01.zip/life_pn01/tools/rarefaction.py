"""Pangenome and core-genome rarefaction (gene-accumulation) curves.

Implements Tettelin-style sub-sampling: at each n in [1..N] randomly draw n
genomes from the dataset, count the union of present genes (pangenome) and
the intersection (core), and average over ``n_permutations`` permutations.

The Heaps' law fit pangenome(n) ~ k * n**alpha is also exposed so the agent
can quantify pangenome openness. Convention used throughout this module:
``alpha <= 0`` indicates a closed/asymptotic pangenome, ``0 < alpha < 1``
indicates an open pangenome that is slowing with sample size, and ``alpha``
approaching or exceeding 1 indicates a strongly open pangenome.
Pure pandas/numpy.
"""
from __future__ import annotations

from typing import Dict, Tuple

import numpy as np
import pandas as pd


def _accumulate_one_permutation(matrix_np: np.ndarray,
                                rng: np.random.Generator) -> Tuple[np.ndarray, np.ndarray]:
    """For one random permutation of genome columns, return per-step pangenome
    size (cumulative union of presences) and core size (cumulative
    intersection of presences) as length-n_genomes arrays.
    """
    n_genes, n_genomes = matrix_np.shape
    order = rng.permutation(n_genomes)
    pang = np.zeros(n_genomes, dtype=np.int32)
    core = np.zeros(n_genomes, dtype=np.int32)
    union = np.zeros(n_genes, dtype=bool)
    inter = np.ones(n_genes, dtype=bool)
    for step, idx in enumerate(order):
        col = matrix_np[:, idx].astype(bool)
        union |= col
        if step == 0:
            inter = col.copy()
        else:
            inter &= col
        pang[step] = int(union.sum())
        core[step] = int(inter.sum())
    return pang, core


def rarefaction_curve(matrix: pd.DataFrame,
                      n_permutations: int = 25,
                      seed: int = 1186) -> pd.DataFrame:
    """Mean pangenome- and core-size as more genomes are added.

    Parameters
    ----------
    matrix : pd.DataFrame
        Gene x genome 0/1 matrix.
    n_permutations : int, default 25
        Number of random column orderings to average over.
    seed : int, default 1186
        Seed for the deterministic RNG.

    Returns
    -------
    pd.DataFrame with columns
        n_genomes        : number of genomes sampled (1..N)
        pangenome_mean   : mean union size over permutations
        pangenome_std    : std of union size
        core_mean        : mean intersection size
        core_std         : std of intersection size
    """
    M = matrix.values.astype(np.int8)
    n_genes, n_genomes = M.shape
    pang_all = np.zeros((n_permutations, n_genomes), dtype=np.float64)
    core_all = np.zeros((n_permutations, n_genomes), dtype=np.float64)
    rng = np.random.default_rng(seed)
    for k in range(n_permutations):
        p, c = _accumulate_one_permutation(M, rng)
        pang_all[k] = p
        core_all[k] = c
    return pd.DataFrame({
        "n_genomes": np.arange(1, n_genomes + 1),
        "pangenome_mean": pang_all.mean(axis=0),
        "pangenome_std":  pang_all.std(axis=0),
        "core_mean":      core_all.mean(axis=0),
        "core_std":       core_all.std(axis=0),
    })


def heaps_law_fit(curve: pd.DataFrame, skip_first: int = 5) -> Dict[str, float]:
    """Fit pangenome(n) = k * n**alpha by linear regression in log-log space.

    Skips the first ``skip_first`` n-values where the curve is dominated by
    the single-genome term. Returns a dict with keys
    ``alpha`` (Heaps' exponent), ``k`` (prefactor) and ``r_squared``.

    Heaps' law interpretation (Tettelin et al. 2005):
        alpha < 0   : closed pangenome (asymptotes)
        0 < alpha<1 : open but slowing
        alpha ~ 1   : strongly open / cumulative
    """
    sub = curve.iloc[skip_first:].copy()
    x = np.log(sub["n_genomes"].values)
    y = np.log(sub["pangenome_mean"].values)
    # Closed-form linear regression slope/intercept.
    n = x.size
    sx, sy = x.sum(), y.sum()
    sxx = (x * x).sum(); sxy = (x * y).sum()
    denom = n * sxx - sx * sx
    alpha = (n * sxy - sx * sy) / denom
    log_k = (sy - alpha * sx) / n
    yhat = log_k + alpha * x
    ss_res = float(((y - yhat) ** 2).sum())
    ss_tot = float(((y - y.mean()) ** 2).sum())
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else float("nan")
    return {"alpha": float(alpha), "k": float(np.exp(log_k)), "r_squared": float(r2)}


def new_genes_per_genome(curve: pd.DataFrame) -> pd.DataFrame:
    """Discrete derivative of the pangenome curve: new gene clusters added by
    the n-th sampled genome on average. Useful to show diminishing returns.
    """
    pang = curve["pangenome_mean"].values
    new = np.diff(pang, prepend=0.0)
    return pd.DataFrame({
        "n_genomes": curve["n_genomes"].values,
        "new_genes": new,
    })

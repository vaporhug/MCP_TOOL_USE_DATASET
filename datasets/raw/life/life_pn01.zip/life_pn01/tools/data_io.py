"""I/O primitives for the bacterial pangenome benchmark.

Loads Roary-style ``gene_presence_absence.csv`` matrices (with the standard
14-column metadata header followed by one column per genome) and the
N. gonorrhoeae phenotype table. Pure pandas/numpy; no scipy, no sklearn.
"""
from __future__ import annotations

from typing import List, Tuple

import numpy as np
import pandas as pd


# Roary fixes the first 14 columns as metadata; everything beyond is genomes.
ROARY_META_COLS = 14


def load_presence_absence(path: str) -> Tuple[pd.DataFrame, pd.DataFrame, List[str]]:
    """Load a Roary-format gene-presence/absence matrix.

    The bundled files are gzip-compressed CSV (``.csv.gz``) or plain CSV.
    The Roary spec is: first 14 columns are gene metadata (``Gene``,
    ``Annotation``, ``No. isolates``, ...), then one column per isolate
    holding 0/1 presence/absence.

    Parameters
    ----------
    path : str
        Path to ``gene_presence_absence.csv`` (optionally gzipped).

    Returns
    -------
    meta : pd.DataFrame
        Per-gene metadata, one row per gene cluster.
    matrix : pd.DataFrame
        Boolean-coercible 0/1 matrix, indexed by ``Gene`` (rows) x isolate
        IDs (columns). Dtype is int8 to keep memory low for large pangenomes.
    isolate_ids : list[str]
        The isolate column names in their original order.
    """
    df = pd.read_csv(path)
    meta = df.iloc[:, :ROARY_META_COLS].copy()
    isolate_ids = list(df.columns[ROARY_META_COLS:])
    matrix = df[isolate_ids].astype(np.int8)
    matrix.index = df["Gene"].values
    matrix.index.name = "Gene"
    return meta, matrix, isolate_ids


def load_phenotypes(path: str) -> pd.DataFrame:
    """Load the N. gonorrhoeae per-isolate phenotype table.

    Columns
    -------
    isolate_id              : matches the genome column names of the
                              presence/absence matrix
    country                 : 2-letter ISO country code (20 levels)
    tetracycline_resistant  : 0/1 binary phenotype used for the pan-GWAS
    tetracycline_MIC        : float minimum inhibitory concentration in
                              microgram/mL (binarized at 1 microgram/mL)
    """
    return pd.read_csv(path)


def align_matrix_to_phenotypes(matrix: pd.DataFrame,
                               phen: pd.DataFrame,
                               iso_col: str = "isolate_id") -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Reorder ``matrix`` columns and ``phen`` rows to share the same isolate
    ordering, keeping only isolates present in both. Returns ``(matrix2,
    phen2)`` ready for GWAS.
    """
    common = [g for g in phen[iso_col].tolist() if g in matrix.columns]
    m2 = matrix[common].copy()
    p2 = phen.set_index(iso_col).loc[common].reset_index().rename(columns={"index": iso_col})
    return m2, p2


def gene_count(meta: pd.DataFrame) -> int:
    """Number of gene clusters (rows) in the pangenome."""
    return int(len(meta))


def genome_count(matrix: pd.DataFrame) -> int:
    """Number of isolates (columns) in the pangenome matrix."""
    return int(matrix.shape[1])


def matrix_summary(matrix: pd.DataFrame) -> pd.Series:
    """Quick descriptive stats: total cells, presence cells, sparsity,
    average genes per genome, average isolates per gene.
    """
    n_genes, n_genomes = matrix.shape
    presence = int(matrix.values.sum())
    return pd.Series({
        "n_genes": n_genes,
        "n_genomes": n_genomes,
        "presence_cells": presence,
        "sparsity": 1.0 - presence / (n_genes * n_genomes),
        "mean_genes_per_genome": presence / n_genomes,
        "mean_genomes_per_gene": presence / n_genes,
    })

"""Core / soft-core / shell / cloud classification of a pangenome.

These thresholds follow the Roary convention used throughout Tonkin-Hill et
al. 2020: core >=99 %, soft-core 95-99 %, shell 15-95 %, cloud <15 % presence.
Pure pandas/numpy.
"""
from __future__ import annotations

from typing import Dict, Tuple

import numpy as np
import pandas as pd


# Default tier thresholds (lower bound, upper bound) on gene-frequency f
# expressed as a fraction of all isolates (0 <= f <= 1).
DEFAULT_TIERS = {
    "core":      (0.99, 1.0001),
    "soft_core": (0.95, 0.99),
    "shell":     (0.15, 0.95),
    "cloud":     (0.0,  0.15),
}


def gene_frequency(matrix: pd.DataFrame) -> pd.Series:
    """Per-gene presence frequency (0..1) across all isolates.

    Returns a Series indexed by ``matrix.index`` (gene cluster names).
    """
    n_genomes = matrix.shape[1]
    return matrix.sum(axis=1).astype(float) / n_genomes


def classify_genes(matrix: pd.DataFrame,
                   tiers: Dict[str, Tuple[float, float]] = None) -> pd.Series:
    """Assign each gene to one of {``core``, ``soft_core``, ``shell``,
    ``cloud``} using the given (low, high) frequency cutoffs.

    The default cutoffs reproduce Roary's classification (used as the baseline
    in Tonkin-Hill et al. 2020): core>=99 %, soft-core in [95 %, 99 %), shell
    in [15 %, 95 %), cloud <15 %.

    Returns
    -------
    pd.Series
        Same index as ``matrix.index``; values are tier labels.
    """
    tiers = tiers if tiers is not None else DEFAULT_TIERS
    f = gene_frequency(matrix)
    out = pd.Series("cloud", index=f.index, dtype=object)
    # Assign in order of increasing cutoff so that higher tiers overwrite.
    for label, (lo, hi) in tiers.items():
        mask = (f >= lo) & (f < hi)
        out[mask] = label
    return out


def tier_counts(classes: pd.Series) -> pd.Series:
    """Number of genes per tier, in fixed order (core, soft_core, shell,
    cloud). Missing tiers report 0.
    """
    order = ["core", "soft_core", "shell", "cloud"]
    counts = classes.value_counts()
    return pd.Series([int(counts.get(t, 0)) for t in order], index=order)


def tier_summary(matrix: pd.DataFrame,
                 tiers: Dict[str, Tuple[float, float]] = None) -> pd.DataFrame:
    """One-row-per-tier summary: count, mean frequency, fraction of genome.

    Useful for the bar-chart-style ``core vs accessory`` figure.
    """
    classes = classify_genes(matrix, tiers)
    f = gene_frequency(matrix)
    rows = []
    for tier in ["core", "soft_core", "shell", "cloud"]:
        mask = classes == tier
        rows.append({
            "tier": tier,
            "n_genes": int(mask.sum()),
            "mean_freq": float(f[mask].mean()) if mask.any() else 0.0,
            "fraction": float(mask.sum()) / max(1, len(classes)),
        })
    return pd.DataFrame(rows)


def accessory_size(matrix: pd.DataFrame,
                   tiers: Dict[str, Tuple[float, float]] = None) -> int:
    """Number of accessory (non-core) genes -- soft_core + shell + cloud."""
    classes = classify_genes(matrix, tiers)
    return int((classes != "core").sum())


def core_size(matrix: pd.DataFrame,
              tiers: Dict[str, Tuple[float, float]] = None) -> int:
    """Number of core genes (presence >= 99 % by default)."""
    classes = classify_genes(matrix, tiers)
    return int((classes == "core").sum())


def gene_frequency_histogram(matrix: pd.DataFrame,
                             n_bins: int = 50) -> pd.DataFrame:
    """Histogram of per-gene presence count across the population.

    Returns a DataFrame with columns ``bin_left``, ``bin_right``,
    ``count`` ready to plot. Bins span 0 -> n_genomes equally.
    """
    n_genomes = matrix.shape[1]
    counts = matrix.sum(axis=1).astype(int).values
    edges = np.linspace(0, n_genomes, n_bins + 1)
    h, _ = np.histogram(counts, bins=edges)
    return pd.DataFrame({
        "bin_left": edges[:-1],
        "bin_right": edges[1:],
        "count": h,
    })

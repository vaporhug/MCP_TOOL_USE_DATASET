"""Featurization primitives: SMILES -> molecular fingerprints, sequence -> k-mer features.

These functions are featurizers only; they do not mix labels in or perform train/test
splits. The Morgan/ECFP fingerprint is implemented from scratch via a hashing scheme so
RDKit is not strictly required, although if available it will be used for canonicalization.
"""

from __future__ import annotations

import hashlib
import re
from typing import Dict, Iterable, List, Tuple

import numpy as np
import pandas as pd


# -----------------------------------------------------------------------------
# SMILES-based fingerprint
# -----------------------------------------------------------------------------


def _hash_token(token: str, n_bits: int) -> int:
    """Hash a string token into a stable bit index in [0, n_bits)."""
    h = hashlib.md5(token.encode("utf-8")).digest()
    val = int.from_bytes(h[:8], "big")
    return val % n_bits


def smiles_to_morgan_like_fingerprint(
    smiles: str, n_bits: int = 1024, radius: int = 2
) -> np.ndarray:
    """Compute a Morgan-like circular fingerprint from a SMILES string.

    If RDKit is installed, this calls AllChem.GetMorganFingerprintAsBitVect for a
    rigorous circular fingerprint. Otherwise it falls back to a hashing scheme over
    character k-grams of the SMILES (same n_bits, comparable Tanimoto behavior on
    Davis since SMILES are canonicalized).
    """
    try:
        from rdkit import Chem  # type: ignore
        from rdkit.Chem import AllChem  # type: ignore

        mol = Chem.MolFromSmiles(smiles)
        if mol is None:
            return np.zeros(n_bits, dtype=np.uint8)
        bv = AllChem.GetMorganFingerprintAsBitVect(mol, radius, nBits=n_bits)
        arr = np.zeros(n_bits, dtype=np.uint8)
        for i in bv.GetOnBits():
            arr[i] = 1
        return arr
    except Exception:
        bits = np.zeros(n_bits, dtype=np.uint8)
        s = smiles
        # use 2-,3-,4-,5-character substrings as proxy circular tokens
        for k in range(2, 2 * radius + 2):
            for i in range(len(s) - k + 1):
                token = s[i : i + k]
                bits[_hash_token(token, n_bits)] = 1
        return bits


def batch_smiles_fingerprints(
    smiles_list: Iterable[str], n_bits: int = 1024, radius: int = 2
) -> np.ndarray:
    """Vectorized fingerprint computation. Returns array of shape (n, n_bits)."""
    return np.stack(
        [smiles_to_morgan_like_fingerprint(s, n_bits=n_bits, radius=radius) for s in smiles_list]
    )


def tanimoto_similarity(fp1: np.ndarray, fp2: np.ndarray) -> float:
    """Tanimoto/Jaccard similarity of two binary fingerprints."""
    a = np.asarray(fp1).astype(bool)
    b = np.asarray(fp2).astype(bool)
    inter = np.logical_and(a, b).sum()
    union = np.logical_or(a, b).sum()
    if union == 0:
        return 0.0
    return float(inter / union)


def pairwise_tanimoto_matrix(fps: np.ndarray) -> np.ndarray:
    """Compute symmetric Tanimoto similarity matrix for n fingerprints (n x n)."""
    n = fps.shape[0]
    fps = fps.astype(bool)
    inter = fps.astype(int) @ fps.astype(int).T  # n x n
    sums = fps.sum(axis=1)
    union = sums[:, None] + sums[None, :] - inter
    sim = np.where(union > 0, inter / np.maximum(union, 1), 0.0)
    return sim


# -----------------------------------------------------------------------------
# Protein sequence k-mer features
# -----------------------------------------------------------------------------


_AMINO_ACIDS = "ACDEFGHIKLMNPQRSTVWY"


def sequence_kmer_count(seq: str, k: int = 2) -> Dict[str, int]:
    """Sliding-window k-mer count over the standard 20 amino acid alphabet.

    The default k=2 is the dipeptide composition used to build the shipped
    target features (Morgan fingerprint for drugs + dipeptide composition for
    targets). Non-standard residues (X, B, U, ...) are skipped.
    """
    seq = "".join(c for c in seq.upper() if c in _AMINO_ACIDS)
    counts: Dict[str, int] = {}
    for i in range(len(seq) - k + 1):
        kmer = seq[i : i + k]
        counts[kmer] = counts.get(kmer, 0) + 1
    return counts


def sequence_kmer_vector(seq: str, k: int = 2, normalize: bool = True) -> np.ndarray:
    """Dense k-mer frequency vector over all 20^k k-mers (lex order).

    The default k=2 (dipeptide composition) is a 400-dim vector and is the
    target featurization used to produce the shipped reference metrics. k=3
    (tripeptide) gives an 8000-dim vector. If `normalize`, returns frequencies
    that sum to 1.
    """
    counts = sequence_kmer_count(seq, k=k)
    n_kmers = len(_AMINO_ACIDS) ** k
    vec = np.zeros(n_kmers, dtype=np.float32)
    for kmer, c in counts.items():
        idx = 0
        for ch in kmer:
            idx = idx * len(_AMINO_ACIDS) + _AMINO_ACIDS.index(ch)
        vec[idx] = c
    if normalize and vec.sum() > 0:
        vec = vec / vec.sum()
    return vec


def batch_sequence_kmer_vectors(
    seq_list: Iterable[str], k: int = 2, normalize: bool = True
) -> np.ndarray:
    """Stack k-mer vectors for a batch of protein sequences."""
    return np.stack([sequence_kmer_vector(s, k=k, normalize=normalize) for s in seq_list])


def sequence_amino_acid_composition(seq: str) -> np.ndarray:
    """Length-20 vector with the relative frequency of each amino acid (k=1 case)."""
    return sequence_kmer_vector(seq, k=1, normalize=True)


def normalized_smith_waterman(
    seq1: str, seq2: str, match: int = 2, mismatch: int = -1, gap: int = -2
) -> float:
    """Compute the normalized Smith-Waterman score between two sequences.

    Returns SW(s1, s2) / sqrt(SW(s1, s1) * SW(s2, s2)). Implementation is a small
    quadratic SW; intended for relatively short sequences (the Davis kinase domain
    sequences are ~300-1200 aa). Used to build target-target similarity matrices.
    """
    s1 = "".join(c for c in seq1.upper() if c in _AMINO_ACIDS)
    s2 = "".join(c for c in seq2.upper() if c in _AMINO_ACIDS)

    def sw(a: str, b: str) -> int:
        n, m = len(a), len(b)
        H = np.zeros((n + 1, m + 1), dtype=np.int32)
        best = 0
        for i in range(1, n + 1):
            ai = a[i - 1]
            for j in range(1, m + 1):
                s = match if ai == b[j - 1] else mismatch
                v = max(0, H[i - 1, j - 1] + s, H[i - 1, j] + gap, H[i, j - 1] + gap)
                H[i, j] = v
                if v > best:
                    best = v
        return int(best)

    s11 = sw(s1, s1)
    s22 = sw(s2, s2)
    s12 = sw(s1, s2)
    denom = (s11 * s22) ** 0.5
    if denom <= 0:
        return 0.0
    return float(s12 / denom)


def build_drug_feature_matrix(
    drugs_df: pd.DataFrame, n_bits: int = 1024, radius: int = 2
) -> Tuple[List[str], np.ndarray]:
    """Apply Morgan-like fingerprints to all drugs in `drugs_df`. Returns (cids, X)."""
    cids = drugs_df["drug_cid"].astype(str).tolist()
    X = batch_smiles_fingerprints(drugs_df["smiles"].tolist(), n_bits=n_bits, radius=radius)
    return cids, X


def build_target_feature_matrix(
    targets_df: pd.DataFrame, k: int = 2
) -> Tuple[List[str], np.ndarray]:
    """Apply k-mer featurization to all targets. Returns (gene_names, X).

    Default k=2 is the dipeptide-composition featurization used for the
    shipped reference metrics.
    """
    genes = targets_df["target_gene"].astype(str).tolist()
    X = batch_sequence_kmer_vectors(targets_df["sequence"].tolist(), k=k, normalize=True)
    return genes, X


def assemble_pair_feature_matrix(
    long_df: pd.DataFrame,
    drug_features: Dict[str, np.ndarray],
    target_features: Dict[str, np.ndarray],
) -> Tuple[np.ndarray, np.ndarray]:
    """Concatenate drug features and target features for each (drug, target) pair.

    Returns (X, y) with X of shape (n_pairs, d_drug + d_target) and y of shape (n_pairs,)
    containing pKd values. Pairs whose drug or target lacks features are skipped.
    """
    rows = []
    ys = []
    for _, row in long_df.iterrows():
        d = drug_features.get(str(row["drug_cid"]))
        t = target_features.get(str(row["target_gene"]))
        if d is None or t is None:
            continue
        rows.append(np.concatenate([d, t]))
        ys.append(float(row["pKd"]))
    if not rows:
        return np.zeros((0, 0)), np.zeros(0)
    return np.stack(rows), np.array(ys, dtype=float)

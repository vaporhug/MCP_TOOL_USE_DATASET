"""Evaluation metrics for drug-target binding affinity prediction.

Implements the metrics commonly reported in the DTI literature: MSE, RMSE,
Pearson r, Spearman rho, Concordance Index (CI), AUC and AUPR after binarization,
plus per-target/per-drug breakdowns.
"""

from __future__ import annotations

from typing import Dict, List, Tuple

import numpy as np
import pandas as pd


def mean_squared_error(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Mean squared error."""
    a = np.asarray(y_true, dtype=float)
    b = np.asarray(y_pred, dtype=float)
    return float(np.mean((a - b) ** 2))


def root_mean_squared_error(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return float(np.sqrt(mean_squared_error(y_true, y_pred)))


def pearson_r(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    a = np.asarray(y_true, dtype=float)
    b = np.asarray(y_pred, dtype=float)
    if a.size < 2 or np.std(a) == 0 or np.std(b) == 0:
        return 0.0
    return float(np.corrcoef(a, b)[0, 1])


def spearman_rho(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    a = pd.Series(y_true).rank().values
    b = pd.Series(y_pred).rank().values
    return pearson_r(a, b)


def concordance_index(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Concordance Index (CI), the probability that two randomly chosen pairs with
    different true affinities are predicted in the correct order.

    CI is the probability that two randomly selected pairs with different true
    affinities are predicted in the correct order. Equal true labels are excluded
    from the count; equal predictions count as 0.5.
    """
    a = np.asarray(y_true, dtype=float)
    b = np.asarray(y_pred, dtype=float)
    n = len(a)
    pair_total = 0
    pair_correct = 0.0
    # vectorize where possible
    diff_true = a[:, None] - a[None, :]
    diff_pred = b[:, None] - b[None, :]
    valid = diff_true > 0  # only count i,j with y_true[i] > y_true[j]
    pair_total = int(valid.sum())
    if pair_total == 0:
        return 0.0
    correct = (diff_pred[valid] > 0).sum() + 0.5 * (diff_pred[valid] == 0).sum()
    return float(correct / pair_total)


def binarized_auc_aupr(
    y_true: np.ndarray, y_pred: np.ndarray, threshold: float = 7.0
) -> Tuple[float, float]:
    """Binarize y_true at a pKd threshold and compute AUC and AUPR of y_pred."""
    from sklearn.metrics import roc_auc_score, average_precision_score

    y_bin = (np.asarray(y_true) >= threshold).astype(int)
    if y_bin.sum() == 0 or y_bin.sum() == len(y_bin):
        return 0.0, 0.0
    auc = float(roc_auc_score(y_bin, y_pred))
    aupr = float(average_precision_score(y_bin, y_pred))
    return auc, aupr


def evaluation_report(
    y_true: np.ndarray, y_pred: np.ndarray, threshold: float = 7.0
) -> Dict[str, float]:
    """Compute all metrics in one call."""
    auc, aupr = binarized_auc_aupr(y_true, y_pred, threshold=threshold)
    return {
        "MSE": mean_squared_error(y_true, y_pred),
        "RMSE": root_mean_squared_error(y_true, y_pred),
        "Pearson_r": pearson_r(y_true, y_pred),
        "Spearman_rho": spearman_rho(y_true, y_pred),
        "CI": concordance_index(y_true, y_pred),
        "AUC": auc,
        "AUPR": aupr,
        "n": int(len(y_true)),
        "threshold_pKd": float(threshold),
    }


def per_target_metrics(
    test_df: pd.DataFrame, y_pred: np.ndarray
) -> pd.DataFrame:
    """Compute MSE/Pearson per target gene to expose which targets are hardest."""
    test_df = test_df.copy()
    test_df["y_pred"] = y_pred
    out = []
    for gene, sub in test_df.groupby("target_gene"):
        if len(sub) < 2:
            continue
        out.append(
            {
                "target_gene": gene,
                "n": int(len(sub)),
                "MSE": mean_squared_error(sub["pKd"].values, sub["y_pred"].values),
                "Pearson_r": pearson_r(sub["pKd"].values, sub["y_pred"].values),
                "mean_pKd_true": float(sub["pKd"].mean()),
            }
        )
    return pd.DataFrame(out).sort_values("MSE")


def per_drug_metrics(test_df: pd.DataFrame, y_pred: np.ndarray) -> pd.DataFrame:
    """Compute MSE/Pearson per drug."""
    test_df = test_df.copy()
    test_df["y_pred"] = y_pred
    out = []
    for cid, sub in test_df.groupby("drug_cid"):
        if len(sub) < 2:
            continue
        out.append(
            {
                "drug_cid": cid,
                "n": int(len(sub)),
                "MSE": mean_squared_error(sub["pKd"].values, sub["y_pred"].values),
                "Pearson_r": pearson_r(sub["pKd"].values, sub["y_pred"].values),
                "mean_pKd_true": float(sub["pKd"].mean()),
            }
        )
    return pd.DataFrame(out).sort_values("MSE")


def promiscuity_score(
    long_df: pd.DataFrame, threshold_pKd: float = 7.0
) -> pd.DataFrame:
    """For each drug, count the number of targets bound (pKd >= threshold).

    This is the Davis 2011 selectivity / promiscuity metric: drugs with many
    above-threshold partners are promiscuous; drugs with few are selective.
    """
    out = []
    for cid, sub in long_df.groupby("drug_cid"):
        n_total = int(len(sub))
        n_hit = int((sub["pKd"] >= threshold_pKd).sum())
        out.append(
            {
                "drug_cid": cid,
                "n_targets_total": n_total,
                "n_targets_bound": n_hit,
                "fraction_promiscuous": float(n_hit / n_total) if n_total else 0.0,
                "mean_pKd": float(sub["pKd"].mean()),
                "max_pKd": float(sub["pKd"].max()),
            }
        )
    return pd.DataFrame(out).sort_values("n_targets_bound", ascending=False)


def per_target_promiscuity(
    long_df: pd.DataFrame, threshold_pKd: float = 7.0
) -> pd.DataFrame:
    """For each target, count number of drugs that bind it above threshold."""
    out = []
    for gene, sub in long_df.groupby("target_gene"):
        n_total = int(len(sub))
        n_hit = int((sub["pKd"] >= threshold_pKd).sum())
        out.append(
            {
                "target_gene": gene,
                "n_drugs_total": n_total,
                "n_drugs_bound": n_hit,
                "fraction_drugs_bound": float(n_hit / n_total) if n_total else 0.0,
            }
        )
    return pd.DataFrame(out).sort_values("n_drugs_bound", ascending=False)

"""Regression models for drug-target binding affinity prediction.

Wrappers around sklearn models providing a uniform fit/predict interface plus a
similarity-based baseline that uses Kronecker products of drug-drug and
target-target similarity kernels (Pahikkala 2015). All wrappers return numpy
arrays of predicted pKd values.
"""

from __future__ import annotations

from typing import Dict, Optional, Tuple

import numpy as np


def train_random_forest_regressor(
    X_train: np.ndarray,
    y_train: np.ndarray,
    n_estimators: int = 200,
    max_depth: Optional[int] = None,
    random_state: int = 42,
    n_jobs: int = -1,
):
    """Train a random forest regressor and return the fitted estimator."""
    from sklearn.ensemble import RandomForestRegressor

    model = RandomForestRegressor(
        n_estimators=n_estimators,
        max_depth=max_depth,
        random_state=random_state,
        n_jobs=n_jobs,
    )
    model.fit(X_train, y_train)
    return model


def train_gradient_boosting_regressor(
    X_train: np.ndarray,
    y_train: np.ndarray,
    n_estimators: int = 300,
    max_depth: int = 6,
    learning_rate: float = 0.1,
    random_state: int = 42,
):
    """Train a gradient boosting (sklearn) regressor analogous to xgboost-based baselines."""
    from sklearn.ensemble import GradientBoostingRegressor

    model = GradientBoostingRegressor(
        n_estimators=n_estimators,
        max_depth=max_depth,
        learning_rate=learning_rate,
        random_state=random_state,
    )
    model.fit(X_train, y_train)
    return model


def train_ridge_regressor(
    X_train: np.ndarray,
    y_train: np.ndarray,
    alpha: float = 1.0,
):
    """Train a ridge regressor (linear baseline)."""
    from sklearn.linear_model import Ridge

    model = Ridge(alpha=alpha)
    model.fit(X_train, y_train)
    return model


def predict(model, X: np.ndarray) -> np.ndarray:
    """Generic predict wrapper returning a 1-D float array."""
    return np.asarray(model.predict(X), dtype=float)


def kronrls_predict(
    Sd: np.ndarray,
    St: np.ndarray,
    Y_train: np.ndarray,
    train_mask: np.ndarray,
    regularization: float = 1.0,
    cg_iter: int = 200,
    cg_tol: float = 1e-6,
) -> np.ndarray:
    """Kronecker-kernel regularized least squares prediction with drug-drug x target-target kernels.

    Solves the partial-observation KronRLS problem (Pahikkala 2015): only the
    cells flagged by ``train_mask`` contribute to the loss. The dual coefficients
    ``a`` minimise ``||M . (K a) - M . y||^2 + lambda ||a||^2`` and therefore
    satisfy the *symmetric* masked normal equations

        (M . K . M + lambda I) a = M . vec(Y_train)

    where ``K = Sd (x) St`` (Kronecker product), ``M`` is the diagonal 0/1
    indicator of observed cells, and ``M . K . M`` denotes masking on both
    sides of the Kronecker operator. Because ``Sd`` and ``St`` are symmetric
    PSD kernel matrices and the mask is applied symmetrically, the operator
    ``A -> M . (Sd (M . A) St) + lambda A`` is genuinely symmetric
    positive-definite (for lambda > 0), so conjugate gradients is a valid
    solver. (A one-sided ``M . K + lambda I`` operator would NOT be symmetric
    and would break CG.) Fast Kronecker matrix-vector products
    (``Sd @ A @ St``) are used so the full K is never materialised and
    unobserved cells are excluded from the fit rather than treated as
    observed zeros.

    Args:
        Sd: (n_drugs, n_drugs) drug-drug similarity (kernel) matrix.
        St: (n_targets, n_targets) target-target similarity (kernel) matrix.
        Y_train: (n_drugs, n_targets) label matrix; entries where train_mask is
            False are ignored (may be NaN).
        train_mask: boolean (n_drugs, n_targets); True for cells used as training labels.
        regularization: ridge term lambda (> 0).
        cg_iter: maximum conjugate-gradient iterations.
        cg_tol: relative residual tolerance for early stopping.

    Returns:
        Yhat: (n_drugs, n_targets) predicted pKd matrix K @ a for every cell.
    """
    Sd = np.asarray(Sd, dtype=float)
    St = np.asarray(St, dtype=float)
    M = np.asarray(train_mask, dtype=float)
    # Right-hand side: observed labels only (unobserved cells contribute nothing).
    b = M * np.nan_to_num(np.asarray(Y_train, dtype=float), nan=0.0)

    def kron_mv(A: np.ndarray) -> np.ndarray:
        # (Sd (x) St) applied to vec(A) reshaped back to matrix form.
        return Sd @ A @ St

    def apply_op(A: np.ndarray) -> np.ndarray:
        # (M . K . M + lambda I) acting on the coefficient matrix A. Masking
        # on BOTH sides of the Kronecker operator makes apply_op symmetric.
        return M * kron_mv(M * A) + regularization * A

    # Conjugate gradient on the symmetric positive-definite operator apply_op.
    a = np.zeros_like(b)
    r = b - apply_op(a)
    p = r.copy()
    rs_old = float(np.sum(r * r))
    b_norm = float(np.sum(b * b)) or 1.0
    for _ in range(cg_iter):
        Ap = apply_op(p)
        denom = float(np.sum(p * Ap))
        if denom == 0.0:
            break
        alpha = rs_old / denom
        a += alpha * p
        r -= alpha * Ap
        rs_new = float(np.sum(r * r))
        if rs_new / b_norm < cg_tol ** 2:
            break
        p = r + (rs_new / rs_old) * p
        rs_old = rs_new

    # Predictions for every cell: Yhat = K @ a.
    return kron_mv(a)


def matrix_factorization_predict(
    Y_train: np.ndarray,
    train_mask: np.ndarray,
    rank: int = 16,
    n_iter: int = 200,
    learning_rate: float = 0.005,
    reg: float = 0.02,
    seed: int = 42,
) -> np.ndarray:
    """Simple SGD-based low-rank matrix factorization Y ~ P Q^T (no biases).

    Used as a non-similarity baseline. Returns the dense predicted matrix.
    """
    rng = np.random.default_rng(seed)
    n_d, n_t = Y_train.shape
    P = 0.1 * rng.standard_normal((n_d, rank))
    Q = 0.1 * rng.standard_normal((n_t, rank))
    obs = np.argwhere(train_mask)
    rng.shuffle(obs)
    for it in range(n_iter):
        for i, j in obs:
            err = Y_train[i, j] - P[i] @ Q[j]
            grad_P = -err * Q[j] + reg * P[i]
            grad_Q = -err * P[i] + reg * Q[j]
            P[i] -= learning_rate * grad_P
            Q[j] -= learning_rate * grad_Q
    return P @ Q.T


def baseline_global_mean(Y_train: np.ndarray, train_mask: np.ndarray) -> float:
    """Trivial baseline: predict the global mean of training labels."""
    vals = Y_train[train_mask]
    return float(np.mean(vals)) if vals.size else 0.0

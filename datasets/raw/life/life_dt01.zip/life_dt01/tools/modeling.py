"""Regression models for drug-target binding affinity prediction.

Wrappers around sklearn models providing a uniform fit/predict interface plus a
similarity-based baseline that uses Kronecker products of drug-drug and
target-target similarity kernels (Pahikkala 2015). All wrappers return numpy
arrays of predicted pKd values.
"""

from __future__ import annotations

from typing import Dict, Optional, Tuple

import numpy as np


def train_random_forest_regressor(
    X_train: np.ndarray,
    y_train: np.ndarray,
    n_estimators: int = 200,
    max_depth: Optional[int] = None,
    random_state: int = 42,
    n_jobs: int = -1,
):
    """Train a random forest regressor and return the fitted estimator."""
    from sklearn.ensemble import RandomForestRegressor

    model = RandomForestRegressor(
        n_estimators=n_estimators,
        max_depth=max_depth,
        random_state=random_state,
        n_jobs=n_jobs,
    )
    model.fit(X_train, y_train)
    return model


def train_gradient_boosting_regressor(
    X_train: np.ndarray,
    y_train: np.ndarray,
    n_estimators: int = 300,
    max_depth: int = 6,
    learning_rate: float = 0.1,
    random_state: int = 42,
):
    """Train a gradient boosting (sklearn) regressor analogous to xgboost-based baselines."""
    from sklearn.ensemble import GradientBoostingRegressor

    model = GradientBoostingRegressor(
        n_estimators=n_estimators,
        max_depth=max_depth,
        learning_rate=learning_rate,
        random_state=random_state,
    )
    model.fit(X_train, y_train)
    return model


def train_ridge_regressor(
    X_train: np.ndarray,
    y_train: np.ndarray,
    alpha: float = 1.0,
):
    """Train a ridge regressor (linear baseline)."""
    from sklearn.linear_model import Ridge

    model = Ridge(alpha=alpha)
    model.fit(X_train, y_train)
    return model


def predict(model, X: np.ndarray) -> np.ndarray:
    """Generic predict wrapper returning a 1-D float array."""
    return np.asarray(model.predict(X), dtype=float)


def kronrls_predict(
    Sd: np.ndarray,
    St: np.ndarray,
    Y_train: np.ndarray,
    train_mask: np.ndarray,
    regularization: float = 1.0,
) -> np.ndarray:
    """Kronecker-kernel regularized least squares prediction with drug-drug x target-target kernels.

    Args:
        Sd: (n_drugs, n_drugs) drug-drug similarity matrix.
        St: (n_targets, n_targets) target-target similarity matrix.
        Y_train: (n_drugs, n_targets) label matrix; missing entries can be NaN.
        train_mask: boolean (n_drugs, n_targets); True for cells used as training labels.
        regularization: ridge term lambda.

    Returns:
        Yhat: (n_drugs, n_targets) predicted pKd matrix via eigendecomposition of Sd and St.
    """
    Sd = np.asarray(Sd, dtype=float)
    St = np.asarray(St, dtype=float)
    Y = np.where(train_mask, np.nan_to_num(Y_train, nan=0.0), 0.0)

    Lambda_d, Vd = np.linalg.eigh(Sd)
    Lambda_t, Vt = np.linalg.eigh(St)
    # outer product of eigenvalues
    OE = np.outer(Lambda_d, Lambda_t)
    # Project Y into eigen basis
    Yp = Vd.T @ Y @ Vt
    Cp = Yp / (OE + regularization)
    Yhat = Vd @ Cp @ Vt.T
    return Yhat


def matrix_factorization_predict(
    Y_train: np.ndarray,
    train_mask: np.ndarray,
    rank: int = 16,
    n_iter: int = 200,
    learning_rate: float = 0.005,
    reg: float = 0.02,
    seed: int = 42,
) -> np.ndarray:
    """Simple SGD-based low-rank matrix factorization Y ~ P Q^T (no biases).

    Used as a non-similarity baseline. Returns the dense predicted matrix.
    """
    rng = np.random.default_rng(seed)
    n_d, n_t = Y_train.shape
    P = 0.1 * rng.standard_normal((n_d, rank))
    Q = 0.1 * rng.standard_normal((n_t, rank))
    obs = np.argwhere(train_mask)
    rng.shuffle(obs)
    for it in range(n_iter):
        for i, j in obs:
            err = Y_train[i, j] - P[i] @ Q[j]
            grad_P = -err * Q[j] + reg * P[i]
            grad_Q = -err * P[i] + reg * Q[j]
            P[i] -= learning_rate * grad_P
            Q[j] -= learning_rate * grad_Q
    return P @ Q.T


def baseline_global_mean(Y_train: np.ndarray, train_mask: np.ndarray) -> float:
    """Trivial baseline: predict the global mean of training labels."""
    vals = Y_train[train_mask]
    return float(np.mean(vals)) if vals.size else 0.0

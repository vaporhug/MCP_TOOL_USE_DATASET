"""Train/test splitting strategies for drug-target affinity prediction.

Implements three split scenarios standard in the DTI literature: random pair split,
cold-drug split, and cold-target split. Also exposes the precomputed 5-fold CV
splits shipped with the dataset (DeepDTA setting1) for reproducibility.
"""

from __future__ import annotations

from typing import Dict, List, Tuple

import numpy as np
import pandas as pd


def random_pair_split(
    long_df: pd.DataFrame, test_fraction: float = 0.2, seed: int = 42
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Random per-pair train/test split.

    Each (drug, target) pair is independently assigned. Cold drugs and cold targets
    can both still appear in the test set if their pair was assigned to test.
    """
    rng = np.random.default_rng(seed)
    n = len(long_df)
    idx = np.arange(n)
    rng.shuffle(idx)
    cut = int(n * test_fraction)
    test_idx = idx[:cut]
    train_idx = idx[cut:]
    return long_df.iloc[train_idx].copy(), long_df.iloc[test_idx].copy()


def cold_drug_split(
    long_df: pd.DataFrame, test_fraction: float = 0.2, seed: int = 42
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Cold-drug split: a fraction of unique drugs is held out entirely.

    All pairs involving a held-out drug go into test; all pairs involving the
    remaining drugs go into train. No drug appears in both train and test.
    """
    rng = np.random.default_rng(seed)
    drugs = long_df["drug_cid"].astype(str).unique().tolist()
    rng.shuffle(drugs)
    cut = max(1, int(len(drugs) * test_fraction))
    test_drugs = set(drugs[:cut])
    test_mask = long_df["drug_cid"].astype(str).isin(test_drugs)
    return long_df[~test_mask].copy(), long_df[test_mask].copy()


def cold_target_split(
    long_df: pd.DataFrame, test_fraction: float = 0.2, seed: int = 42
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Cold-target split: a fraction of unique targets is held out entirely."""
    rng = np.random.default_rng(seed)
    targets = long_df["target_gene"].astype(str).unique().tolist()
    rng.shuffle(targets)
    cut = max(1, int(len(targets) * test_fraction))
    test_targets = set(targets[:cut])
    test_mask = long_df["target_gene"].astype(str).isin(test_targets)
    return long_df[~test_mask].copy(), long_df[test_mask].copy()


def kfold_indices(n_pairs: int, k: int = 5, seed: int = 42) -> List[Tuple[np.ndarray, np.ndarray]]:
    """Plain (non-cold) k-fold CV: returns list of (train_idx, val_idx) tuples."""
    rng = np.random.default_rng(seed)
    idx = np.arange(n_pairs)
    rng.shuffle(idx)
    folds = np.array_split(idx, k)
    out = []
    for i in range(k):
        val = folds[i]
        train = np.concatenate([folds[j] for j in range(k) if j != i])
        out.append((train, val))
    return out


def use_predefined_folds(
    splits_descriptor: Dict, fold_id: int
) -> Tuple[List[int], List[int], List[int]]:
    """Use the precomputed DeepDTA setting-1 5-fold CV indices.

    Returns (train_global_idx, val_global_idx, held_out_test_global_idx). For each
    fold_id in 0..4, val is the corresponding train_folds_5cv[fold_id] and train is
    the union of the other four folds (test set is always the same held-out subset).
    """
    train_folds = splits_descriptor["train_folds_5cv"]
    held_out = splits_descriptor["held_out_test"]
    if not (0 <= fold_id < len(train_folds)):
        raise ValueError(f"fold_id must be in [0, {len(train_folds)})")
    val = train_folds[fold_id]
    train = []
    for i, f in enumerate(train_folds):
        if i != fold_id:
            train.extend(f)
    return list(train), list(val), list(held_out)


def split_summary(train_df: pd.DataFrame, test_df: pd.DataFrame) -> Dict:
    """Summarize a split: counts, drug/target overlap, mean labels."""
    train_drugs = set(train_df["drug_cid"].astype(str))
    train_tgts = set(train_df["target_gene"].astype(str))
    test_drugs = set(test_df["drug_cid"].astype(str))
    test_tgts = set(test_df["target_gene"].astype(str))
    return {
        "n_train": int(len(train_df)),
        "n_test": int(len(test_df)),
        "train_drugs": int(len(train_drugs)),
        "test_drugs": int(len(test_drugs)),
        "drug_overlap": int(len(train_drugs & test_drugs)),
        "train_targets": int(len(train_tgts)),
        "test_targets": int(len(test_tgts)),
        "target_overlap": int(len(train_tgts & test_tgts)),
        "train_mean_pKd": float(train_df["pKd"].mean()) if "pKd" in train_df else None,
        "test_mean_pKd": float(test_df["pKd"].mean()) if "pKd" in test_df else None,
    }

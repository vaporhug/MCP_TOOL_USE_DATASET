"""Stub for external database retrieval (handled by the platform layer).

For this task all data is shipped locally inside `input_data/data/`. The function
below simply describes what is on disk so the agent can discover the dataset
without making external calls.
"""

from __future__ import annotations

import os
from typing import Dict


def get_data_info(data_dir: str) -> Dict:
    """Return a small manifest describing the files shipped inside the task package."""
    files = []
    if os.path.isdir(data_dir):
        for fn in sorted(os.listdir(data_dir)):
            full = os.path.join(data_dir, fn)
            if os.path.isfile(full):
                files.append({"name": fn, "size_bytes": os.path.getsize(full)})
    return {"data_dir": data_dir, "files": files}

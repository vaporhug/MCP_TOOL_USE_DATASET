"""Data loading and processing primitives for the Davis kinase Kd dataset.

Functions are intentionally low-level: they return arrays / dataframes / dicts
without applying domain-specific assumptions about train/test splits or
featurization. Higher-level tools (featurization, modeling, evaluation) live in
sibling modules.
"""

from __future__ import annotations

import json
import math
import os
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd


def load_kd_matrix(path: str) -> pd.DataFrame:
    """Load the 68 x 442 Davis Kd (nM) matrix from CSV.

    The first column is the drug PubChem CID (used as DataFrame index); remaining
    columns are kinase gene names. Returns a DataFrame of dtype float64.
    """
    df = pd.read_csv(path, index_col=0)
    df = df.astype(float)
    return df


def load_pkd_matrix(path: str) -> pd.DataFrame:
    """Load the precomputed pKd matrix (pKd = -log10(Kd_nM / 1e9))."""
    df = pd.read_csv(path, index_col=0)
    df = df.astype(float)
    return df


def kd_to_pkd(kd_nM: np.ndarray) -> np.ndarray:
    """Convert Kd in nM to pKd using pKd = -log10(Kd_nM / 1e9).

    Equivalent to 9 - log10(Kd_nM). Values <= 0 are treated as the censored
    upper bound (10000 nM -> pKd = 5.0) by clipping to a small floor.
    """
    arr = np.asarray(kd_nM, dtype=float)
    arr = np.where(arr <= 0, 1e-9, arr)
    return -np.log10(arr / 1e9)


def load_drug_table(path: str) -> pd.DataFrame:
    """Load the (drug_cid, smiles) table."""
    df = pd.read_csv(path, dtype={"drug_cid": str})
    return df


def load_target_table(path: str) -> pd.DataFrame:
    """Load the (target_gene, sequence) table."""
    df = pd.read_csv(path)
    return df


def load_long_interactions(path: str) -> pd.DataFrame:
    """Load the long-format interactions table (drug_cid, target_gene, Kd_nM, pKd, global_index)."""
    df = pd.read_csv(path, dtype={"drug_cid": str})
    return df


def load_splits(path: str) -> Dict:
    """Load the JSON splits descriptor.

    Keys: n_drugs, n_targets, train_folds_5cv (list of 5 lists of global_index),
    held_out_test (list of global_index), binarization_threshold_pKd.
    """
    with open(path) as f:
        return json.load(f)


def global_index_to_pair(global_index: int, n_targets: int) -> Tuple[int, int]:
    """Decode flat row-major index into (drug_idx, target_idx)."""
    return global_index // n_targets, global_index % n_targets


def pair_to_global_index(drug_idx: int, target_idx: int, n_targets: int) -> int:
    """Encode (drug_idx, target_idx) into a flat row-major global index."""
    return drug_idx * n_targets + target_idx


def select_pairs_by_index(
    long_df: pd.DataFrame, indices: List[int]
) -> pd.DataFrame:
    """Slice the long-format dataframe to a subset of pairs by global_index."""
    return long_df.set_index("global_index").loc[indices].reset_index()


def matrix_to_long(matrix: pd.DataFrame, value_name: str = "value") -> pd.DataFrame:
    """Melt a (drug x target) DataFrame into long format with explicit indices."""
    rows = []
    drug_ids = list(matrix.index)
    target_ids = list(matrix.columns)
    n_targets = len(target_ids)
    for i, drug in enumerate(drug_ids):
        row = matrix.iloc[i].values
        for j, target in enumerate(target_ids):
            rows.append(
                {
                    "drug_cid": drug,
                    "target_gene": target,
                    value_name: float(row[j]),
                    "global_index": i * n_targets + j,
                }
            )
    return pd.DataFrame(rows)


def summarize_dataset(long_df: pd.DataFrame) -> Dict:
    """Return basic summary statistics: counts, density, range, censored fraction."""
    n_pairs = len(long_df)
    n_drugs = long_df["drug_cid"].nunique()
    n_targets = long_df["target_gene"].nunique()
    pkd = long_df["pKd"].values
    # Davis "no binding" is recorded as Kd = 10000 nM => pKd = 5.0
    censored = float(np.mean(np.isclose(pkd, 5.0)))
    return {
        "n_pairs": int(n_pairs),
        "n_drugs": int(n_drugs),
        "n_targets": int(n_targets),
        "density": float(n_pairs / (n_drugs * n_targets)) if n_drugs and n_targets else 0.0,
        "pKd_min": float(np.min(pkd)),
        "pKd_max": float(np.max(pkd)),
        "pKd_mean": float(np.mean(pkd)),
        "pKd_std": float(np.std(pkd)),
        "fraction_censored_pKd5": censored,
    }


def filter_long_by_threshold(
    long_df: pd.DataFrame, pkd_threshold: float, side: str = "above"
) -> pd.DataFrame:
    """Keep rows whose pKd is `above` (>=) or `below` (<) a threshold."""
    if side == "above":
        return long_df[long_df["pKd"] >= pkd_threshold].copy()
    if side == "below":
        return long_df[long_df["pKd"] < pkd_threshold].copy()
    raise ValueError("side must be 'above' or 'below'")


def binarize_pkd(values: np.ndarray, threshold: float = 7.0) -> np.ndarray:
    """Binarize pKd at a threshold (default 7.0): 1 if >= t else 0."""
    return (np.asarray(values) >= threshold).astype(int)

"""Publication-style plotting helpers for the DTI task.

Each function writes a PNG to disk and returns {"path": <out_path>}. Figures use
matplotlib only (no seaborn) to keep dependencies light.
"""

from __future__ import annotations

import os
from typing import Dict, Iterable, List, Optional

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def _ensure_dir(path: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)


def plot_pkd_distribution(long_df: pd.DataFrame, out_path: str, threshold: float = 7.0) -> Dict:
    """Histogram of pKd values across all pairs with the binding-threshold marker."""
    _ensure_dir(out_path)
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.hist(long_df["pKd"].values, bins=60, color="#3b7dd8", edgecolor="white")
    ax.axvline(threshold, color="red", linestyle="--", lw=1.5, label=f"binding threshold pKd={threshold}")
    ax.set_xlabel("pKd")
    ax.set_ylabel("Number of (drug, target) pairs")
    ax.set_title(f"Davis pKd distribution (n={len(long_df)} pairs)")
    ax.legend()
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": out_path}


def plot_parity(y_true: np.ndarray, y_pred: np.ndarray, out_path: str, title: str = "Parity") -> Dict:
    """Scatter of predicted vs true pKd with y=x reference and metrics overlay."""
    _ensure_dir(out_path)
    fig, ax = plt.subplots(figsize=(5.5, 5.5))
    ax.scatter(y_true, y_pred, s=8, alpha=0.4, color="#2c7fb8")
    lo = float(min(np.min(y_true), np.min(y_pred)))
    hi = float(max(np.max(y_true), np.max(y_pred)))
    ax.plot([lo, hi], [lo, hi], "k--", lw=1)
    ax.set_xlabel("True pKd")
    ax.set_ylabel("Predicted pKd")
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": out_path}


def plot_metric_bars(
    metrics_by_method: Dict[str, Dict[str, float]],
    metric_keys: Iterable[str],
    out_path: str,
    title: str = "Metrics by method",
) -> Dict:
    """Grouped bar chart comparing methods across metrics. Each method is one color."""
    _ensure_dir(out_path)
    methods = list(metrics_by_method.keys())
    metric_keys = list(metric_keys)
    n_methods = len(methods)
    n_metrics = len(metric_keys)
    fig, ax = plt.subplots(figsize=(max(6, 1.6 * n_metrics + 2), 4))
    width = 0.8 / max(n_methods, 1)
    x = np.arange(n_metrics)
    for i, method in enumerate(methods):
        vals = [metrics_by_method[method].get(k, 0.0) for k in metric_keys]
        ax.bar(x + i * width - 0.4 + width / 2, vals, width=width, label=method)
    ax.set_xticks(x)
    ax.set_xticklabels(metric_keys)
    ax.set_ylabel("Score")
    ax.set_title(title)
    ax.legend(fontsize=9)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": out_path}


def plot_split_metric_comparison(
    by_split: Dict[str, Dict[str, float]],
    metric: str,
    out_path: str,
    title: Optional[str] = None,
) -> Dict:
    """Bar chart of one metric across split scenarios (random / cold-drug / cold-target)."""
    _ensure_dir(out_path)
    splits = list(by_split.keys())
    vals = [by_split[s].get(metric, 0.0) for s in splits]
    fig, ax = plt.subplots(figsize=(5.5, 4))
    colors = ["#1f77b4", "#ff7f0e", "#2ca02c", "#9467bd"]
    ax.bar(splits, vals, color=colors[: len(splits)])
    ax.set_ylabel(metric)
    ax.set_title(title or f"{metric} across split scenarios")
    for i, v in enumerate(vals):
        ax.text(i, v, f"{v:.3f}", ha="center", va="bottom", fontsize=9)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": out_path}


def plot_promiscuity_heatmap(
    matrix: pd.DataFrame, out_path: str, threshold: float = 7.0, title: str = "Davis pKd heatmap"
) -> Dict:
    """Heatmap of the pKd matrix with rows=drugs, cols=targets, ordered by total binding."""
    _ensure_dir(out_path)
    M = matrix.values.astype(float)
    drug_order = np.argsort(-(M >= threshold).sum(axis=1))
    target_order = np.argsort(-(M >= threshold).sum(axis=0))
    Mo = M[np.ix_(drug_order, target_order)]
    fig, ax = plt.subplots(figsize=(10, 4.5))
    im = ax.imshow(Mo, aspect="auto", cmap="viridis", vmin=5, vmax=10)
    ax.set_xlabel(f"Targets (n={M.shape[1]}), ordered by binders")
    ax.set_ylabel(f"Drugs (n={M.shape[0]}), ordered by promiscuity")
    ax.set_title(title)
    cbar = fig.colorbar(im, ax=ax)
    cbar.set_label("pKd")
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": out_path}


def plot_promiscuity_distribution(
    promisc_df: pd.DataFrame, out_path: str, top_n: int = 20
) -> Dict:
    """Bar chart: top-N drugs by number of bound targets."""
    _ensure_dir(out_path)
    df = promisc_df.head(top_n).copy()
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.barh(df["drug_cid"].astype(str)[::-1], df["n_targets_bound"][::-1], color="#d95f0e")
    ax.set_xlabel("Number of targets bound (pKd >= 7)")
    ax.set_ylabel("Drug PubChem CID")
    ax.set_title(f"Top-{top_n} most promiscuous kinase inhibitors")
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": out_path}


def plot_residual_distribution(
    y_true: np.ndarray, y_pred: np.ndarray, out_path: str, title: str = "Residuals"
) -> Dict:
    """Histogram of (y_pred - y_true) residuals."""
    _ensure_dir(out_path)
    res = np.asarray(y_pred) - np.asarray(y_true)
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.hist(res, bins=50, color="#7570b3", edgecolor="white")
    ax.axvline(0, color="black", lw=1)
    ax.set_xlabel("Predicted pKd - True pKd")
    ax.set_ylabel("Count")
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": out_path}

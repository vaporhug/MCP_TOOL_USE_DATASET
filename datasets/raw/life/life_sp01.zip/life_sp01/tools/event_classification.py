"""Event-class primitives.

Functions for classifying alternative splicing events into the canonical
SUPPA categories (SE, A5, A3, MX, RI, AF, AL), identifying microexons,
counting per-class occurrence in a result table, and building per-class
summary statistics.
"""
from __future__ import annotations

from typing import Dict, List, Tuple

import numpy as np
import pandas as pd


CANONICAL_TYPES: Tuple[str, ...] = ("SE", "A5", "A3", "MX", "RI", "AF", "AL")


def parse_event_id(event_id: str) -> Dict[str, str]:
    """Parse a SUPPA event identifier into structured fields.

    Examples
    --------
    >>> parse_event_id("ENSG00000000003;A5:chrX:99890743-99891188:99890743-99891605:-")
    {'gene_id': 'ENSG00000000003', 'event_type': 'A5', 'chrom': 'chrX', ...}
    """
    if ";" not in event_id:
        return {"gene_id": "", "event_type": "", "chrom": "", "coord_a": "", "coord_b": "", "strand": ""}
    gene, rest = event_id.split(";", 1)
    parts = rest.split(":")
    et = parts[0] if len(parts) > 0 else ""
    chrom = parts[1] if len(parts) > 1 else ""
    coord_a = parts[2] if len(parts) > 2 else ""
    coord_b = parts[3] if len(parts) > 3 else ""
    strand = parts[4] if len(parts) > 4 else ""
    return {
        "gene_id": gene,
        "event_type": et,
        "chrom": chrom,
        "coord_a": coord_a,
        "coord_b": coord_b,
        "strand": strand,
    }


def classify_events(event_ids: List[str]) -> pd.DataFrame:
    """Apply :func:`parse_event_id` over a list of event identifiers.

    Returns a DataFrame indexed by ``event_id`` with the parsed fields.
    """
    rows = [parse_event_id(eid) for eid in event_ids]
    df = pd.DataFrame(rows, index=pd.Index(event_ids, name="event_id"))
    return df


def cassette_exon_length(event_id: str) -> int:
    """Return the length (nt) of the alternative middle exon of an SE event.

    Returns ``-1`` for non-SE events or unparseable identifiers. The cassette
    exon spans from the inner end of ``coord_a`` to the inner start of
    ``coord_b`` in a canonical SE id ``SE:chr:e1-s2:e2-s3:strand``.
    """
    parsed = parse_event_id(event_id)
    if parsed["event_type"] != "SE":
        return -1
    try:
        s2 = int(parsed["coord_a"].split("-")[1])
        e2 = int(parsed["coord_b"].split("-")[0])
        return abs(e2 - s2) + 1
    except (ValueError, IndexError):
        return -1


def is_microexon(cassette_length: int, max_length: int = 28) -> bool:
    """Return ``True`` if a cassette exon is a microexon (< ``max_length`` nt)."""
    return 0 < int(cassette_length) < int(max_length)


def count_events_per_class(
    event_meta: pd.DataFrame, event_type_col: str = "event_type"
) -> pd.Series:
    """Count events of each canonical type."""
    return event_meta[event_type_col].value_counts()


def per_class_significance_counts(
    results: pd.DataFrame, event_meta: pd.DataFrame,
    direction_col: str = "direction"
) -> pd.DataFrame:
    """Cross-tabulate event class x significance call.

    Returns a DataFrame with rows = event types, columns = direction labels.
    """
    merged = results.join(event_meta.set_index("event_id")[["event_type"]], how="inner")
    table = pd.crosstab(merged["event_type"], merged[direction_col])
    return table


def split_regulated_into_clusters(
    results: pd.DataFrame, mean_psi_per_condition: pd.DataFrame,
    pvalue_thresh: float = 0.05, dpsi_thresh: float = 0.05,
    end_minus_start_threshold: float = 0.10,
) -> pd.Series:
    """Density-clustering substitute used by SUPPA2 (paper page 6, Fig. 4a-c).

    Bins regulated events into three groups by sign of (last - first) condition
    PSI difference: cluster 0 = increase (>+thresh), cluster 1 = decrease,
    cluster 2 = transient (|change| <= thresh). Returns a Series indexed
    by ``event_id`` with the cluster label or ``-1`` for non-regulated.
    """
    sig = (results["pvalue"] < float(pvalue_thresh)) & (results["dpsi"].abs() > float(dpsi_thresh))
    cols = list(mean_psi_per_condition.columns)
    diff = mean_psi_per_condition[cols[-1]] - mean_psi_per_condition[cols[0]]
    diff = diff.reindex(results.index)
    cl = pd.Series(-1, index=results.index, dtype=int)
    inc = sig & (diff > float(end_minus_start_threshold))
    dec = sig & (diff < -float(end_minus_start_threshold))
    trans = sig & (~inc) & (~dec)
    cl[inc] = 0
    cl[dec] = 1
    cl[trans] = 2
    return cl


def microexon_enrichment_table(
    cluster_labels: pd.Series, event_meta: pd.DataFrame,
) -> pd.DataFrame:
    """Per-cluster microexon counts and fractions.

    Joins ``cluster_labels`` (event_id -> int) with ``event_meta`` (must
    include ``event_id`` and ``cassette_length``) and returns a per-cluster
    summary table with ``n_events``, ``n_microexons`` and ``microexon_fraction``.
    """
    em = event_meta.set_index("event_id")[["cassette_length"]]
    df = em.join(cluster_labels.rename("cluster"), how="inner")
    df["is_microexon"] = df["cassette_length"].apply(is_microexon)
    out = df.groupby("cluster").agg(
        n_events=("is_microexon", "size"),
        n_microexons=("is_microexon", "sum"),
    )
    out["microexon_fraction"] = out["n_microexons"] / out["n_events"]
    return out


def cluster_mean_psi_trajectories(
    cluster_labels: pd.Series, mean_psi_per_condition: pd.DataFrame,
) -> pd.DataFrame:
    """Mean PSI trajectory per cluster, one row per cluster.

    Each row gives the average PSI of events in that cluster across the
    ordered conditions in ``mean_psi_per_condition.columns`` (e.g. days 0-3).
    """
    df = mean_psi_per_condition.join(cluster_labels.rename("cluster"), how="inner")
    return df.groupby("cluster").mean(numeric_only=True)

"""Event-class primitives.

Functions for classifying alternative splicing events into the canonical
SUPPA categories (SE, A5, A3, MX, RI, AF, AL), identifying microexons,
counting per-class occurrence in a result table, and building per-class
summary statistics.
"""
from __future__ import annotations

from typing import Dict, List, Tuple

import numpy as np
import pandas as pd


CANONICAL_TYPES: Tuple[str, ...] = ("SE", "A5", "A3", "MX", "RI", "AF", "AL")


def parse_event_id(event_id: str) -> Dict[str, str]:
    """Parse a SUPPA event identifier into structured fields.

    Examples
    --------
    >>> parse_event_id("ENSG00000000003;A5:chrX:99890743-99891188:99890743-99891605:-")
    {'gene_id': 'ENSG00000000003', 'event_type': 'A5', 'chrom': 'chrX', ...}
    """
    if ";" not in event_id:
        return {"gene_id": "", "event_type": "", "chrom": "", "coord_a": "", "coord_b": "", "strand": ""}
    gene, rest = event_id.split(";", 1)
    parts = rest.split(":")
    et = parts[0] if len(parts) > 0 else ""
    chrom = parts[1] if len(parts) > 1 else ""
    coord_a = parts[2] if len(parts) > 2 else ""
    coord_b = parts[3] if len(parts) > 3 else ""
    strand = parts[4] if len(parts) > 4 else ""
    return {
        "gene_id": gene,
        "event_type": et,
        "chrom": chrom,
        "coord_a": coord_a,
        "coord_b": coord_b,
        "strand": strand,
    }


def classify_events(event_ids: List[str]) -> pd.DataFrame:
    """Apply :func:`parse_event_id` over a list of event identifiers.

    Returns a DataFrame indexed by ``event_id`` with the parsed fields.
    """
    rows = [parse_event_id(eid) for eid in event_ids]
    df = pd.DataFrame(rows, index=pd.Index(event_ids, name="event_id"))
    return df


def cassette_exon_length(event_id: str) -> int:
    """Return the length (nt) of the alternative middle exon of an SE event.

    Returns ``-1`` for non-SE events or unparseable identifiers. The cassette
    exon spans from the inner end of ``coord_a`` to the inner start of
    ``coord_b`` in a canonical SE id ``SE:chr:e1-s2:e2-s3:strand``.
    """
    parsed = parse_event_id(event_id)
    if parsed["event_type"] != "SE":
        return -1
    try:
        s2 = int(parsed["coord_a"].split("-")[1])
        e2 = int(parsed["coord_b"].split("-")[0])
        return abs(e2 - s2) + 1
    except (ValueError, IndexError):
        return -1


def is_microexon(cassette_length: int, max_length: int = 28) -> bool:
    """Return ``True`` if a cassette exon is a microexon (< ``max_length`` nt)."""
    return 0 < int(cassette_length) < int(max_length)


def count_events_per_class(
    event_meta: pd.DataFrame, event_type_col: str = "event_type"
) -> pd.Series:
    """Count events of each canonical type."""
    return event_meta[event_type_col].value_counts()


def per_class_significance_counts(
    results: pd.DataFrame, event_meta: pd.DataFrame,
    direction_col: str = "direction"
) -> pd.DataFrame:
    """Cross-tabulate event class x significance call.

    Returns a DataFrame with rows = event types, columns = direction labels.
    """
    merged = results.join(event_meta.set_index("event_id")[["event_type"]], how="inner")
    table = pd.crosstab(merged["event_type"], merged[direction_col])
    return table


def optics_cluster_psi_trajectories(
    results: pd.DataFrame, mean_psi_per_condition: pd.DataFrame,
    pvalue_thresh: float = 0.05, dpsi_thresh: float = 0.0,
    min_samples: int = 15, xi: float = 0.05,
    min_cluster_size: float = 0.05,
) -> pd.Series:
    """OPTICS density-based clustering of regulated cassette events on
    their multi-condition mean-PSI trajectories.

    This is the closer analog of the SUPPA2 paper's reported clustering
    step (the paper notes OPTICS performs slightly better than DBSCAN
    on the SE trajectories). Uses sklearn.cluster.OPTICS under the
    hood; falls back to the DBSCAN implementation if sklearn is
    unavailable.

    Parameters mirror :func:`density_cluster_psi_trajectories` plus
    OPTICS-specific ``xi`` (steepness threshold for cluster extraction)
    and ``min_cluster_size``.
    """
    sig = (results["pvalue"] < float(pvalue_thresh)) & \
          (results["dpsi"].abs() > float(dpsi_thresh))
    out = pd.Series(-1, index=results.index, dtype=int)
    reg_idx = results.index[sig]
    if len(reg_idx) == 0:
        return out
    X = mean_psi_per_condition.reindex(reg_idx).fillna(
        mean_psi_per_condition.mean()).values.astype(float)
    try:
        from sklearn.cluster import OPTICS as _OPTICS
        clusterer = _OPTICS(min_samples=int(min_samples), xi=float(xi),
                            min_cluster_size=float(min_cluster_size))
        labels = clusterer.fit_predict(X)
        labels = np.where(labels < 0, -2, labels)
    except Exception:
        # Fall back to bundled numpy DBSCAN
        labels = _dbscan_numpy(X, eps=0.15, min_samples=int(min_samples))
        labels = np.where(labels < 0, -2, labels)
    out.loc[reg_idx] = labels
    return out


def _dbscan_numpy(X: np.ndarray, eps: float, min_samples: int) -> np.ndarray:
    """Numpy-only DBSCAN implementation (Ester et al. 1996).

    Returns an array of integer cluster labels, with -1 for noise.
    Used by :func:`density_cluster_psi_trajectories` as a dependency-
    free density-based-clustering primitive.
    """
    n = X.shape[0]
    labels = np.full(n, -1, dtype=int)
    visited = np.zeros(n, dtype=bool)
    # Precompute pairwise distances (n_events typically <= a few thousand
    # so O(n^2) memory is tolerable; for very large n callers should
    # subsample first).
    d = X[:, None, :] - X[None, :, :]
    D = np.sqrt((d ** 2).sum(axis=2))
    next_cluster = 0
    for i in range(n):
        if visited[i]:
            continue
        visited[i] = True
        neighbors = np.where(D[i] <= eps)[0].tolist()
        if len(neighbors) < min_samples:
            labels[i] = -1
            continue
        labels[i] = next_cluster
        seed_set = set(neighbors)
        seed_set.discard(i)
        seeds = list(seed_set)
        while seeds:
            q = seeds.pop()
            if not visited[q]:
                visited[q] = True
                q_neighbors = np.where(D[q] <= eps)[0].tolist()
                if len(q_neighbors) >= min_samples:
                    for nb in q_neighbors:
                        if nb not in seed_set:
                            seeds.append(nb)
                            seed_set.add(nb)
            if labels[q] < 0:
                labels[q] = next_cluster
        next_cluster += 1
    return labels


def density_cluster_psi_trajectories(
    results: pd.DataFrame, mean_psi_per_condition: pd.DataFrame,
    pvalue_thresh: float = 0.05, dpsi_thresh: float = 0.0,
    eps: float = 0.15, min_samples: int = 15,
) -> pd.Series:
    """Density-based (DBSCAN) clustering of regulated cassette events on
    their multi-condition mean-PSI trajectories.

    This is the paper-aligned analog of the SUPPA2 paper's
    OPTICS/density-based clustering on per-event PSI trajectories
    (paper page 6 / Fig. 4a-c). For each event that passes both
    ``pvalue_thresh`` AND ``|dpsi| > dpsi_thresh``, we collect the
    K-dimensional PSI trajectory (K = number of conditions) and
    cluster the resulting (n_regulated, K) matrix with DBSCAN
    (Euclidean distance, parameters ``eps`` and ``min_samples``).
    Cluster labels are returned as a pandas Series indexed by
    ``event_id``; non-regulated events are labelled -1 and noise
    events from DBSCAN are labelled -2.

    Parameters
    ----------
    results : pd.DataFrame
        Per-event differential-splicing table containing at least
        ``pvalue`` and ``dpsi`` columns (event_id as index).
    mean_psi_per_condition : pd.DataFrame
        Mean PSI per condition (event_id rows x condition columns).
    pvalue_thresh : float
        Maximum p-value to call an event regulated (paper definition:
        SUPPA2 empirical p<0.05 in at least one adjacent-stage comparison).
    dpsi_thresh : float
        OPTIONAL minimum |dpsi| (or |last - first| PSI shift) effect-size
        filter applied ON TOP of the p-value threshold. Default 0.0
        reproduces the paper's primary definition (p-value only); set to
        e.g. 0.05 only when you explicitly want an additional magnitude gate.
    eps : float
        DBSCAN neighbourhood radius (Euclidean distance in K-D PSI
        space, 0..1 per dimension).
    min_samples : int
        DBSCAN minimum points to form a dense region.

    Returns
    -------
    pd.Series
        Integer cluster labels indexed by ``event_id``. Values are:
        -1 = non-regulated (below thresholds);
        -2 = regulated but DBSCAN-noise (sparse in trajectory space);
        >=0 = density-derived cluster id.
    """
    sig = (results["pvalue"] < float(pvalue_thresh)) & \
          (results["dpsi"].abs() > float(dpsi_thresh))
    out = pd.Series(-1, index=results.index, dtype=int)
    reg_idx = results.index[sig]
    if len(reg_idx) == 0:
        return out
    X = mean_psi_per_condition.reindex(reg_idx).fillna(
        mean_psi_per_condition.mean()).values.astype(float)
    labels = _dbscan_numpy(X, eps=float(eps), min_samples=int(min_samples))
    # Map DBSCAN -1 (noise) to our -2 to distinguish from non-regulated.
    labels = np.where(labels < 0, -2, labels)
    out.loc[reg_idx] = labels
    return out


def split_regulated_into_clusters(
    results: pd.DataFrame, mean_psi_per_condition: pd.DataFrame,
    pvalue_thresh: float = 0.05, dpsi_thresh: float = 0.0,
    end_minus_start_threshold: float = 0.10,
) -> pd.Series:
    """Sign-of-net-change directional binning of regulated events.

    SCOPE NOTE. This is *not* the paper's full trajectory density-
    clustering step (the SUPPA2 paper / Fig. 4a-c uses OPTICS/density-
    based clustering on multi-condition mean-PSI trajectories using
    additional library dependencies). The function here implements
    only a simpler directional approximation: bin regulated events
    (those passing both the p-value AND |ΔPSI| thresholds) into three
    groups by the sign of (last condition mean PSI − first condition
    mean PSI):
        cluster 0 = monotonic increase  (diff > +thresh)
        cluster 1 = monotonic decrease  (diff < -thresh)
        cluster 2 = small-net-change    (|diff| <= thresh; flat/transient)
    Returns a Series indexed by ``event_id`` with the cluster label
    or ``-1`` for non-regulated events. Use as a directional
    *summary*, not as a faithful reproduction of the paper's
    density-clustering output.
    """
    sig = (results["pvalue"] < float(pvalue_thresh)) & (results["dpsi"].abs() > float(dpsi_thresh))
    cols = list(mean_psi_per_condition.columns)
    diff = mean_psi_per_condition[cols[-1]] - mean_psi_per_condition[cols[0]]
    diff = diff.reindex(results.index)
    cl = pd.Series(-1, index=results.index, dtype=int)
    inc = sig & (diff > float(end_minus_start_threshold))
    dec = sig & (diff < -float(end_minus_start_threshold))
    trans = sig & (~inc) & (~dec)
    cl[inc] = 0
    cl[dec] = 1
    cl[trans] = 2
    return cl


def microexon_enrichment_table(
    cluster_labels: pd.Series, event_meta: pd.DataFrame,
) -> pd.DataFrame:
    """Per-cluster microexon counts and fractions.

    Joins ``cluster_labels`` (event_id -> int) with ``event_meta`` (must
    include ``event_id`` and ``cassette_length``) and returns a per-cluster
    summary table with ``n_events``, ``n_microexons`` and ``microexon_fraction``.
    """
    em = event_meta.set_index("event_id")[["cassette_length"]]
    df = em.join(cluster_labels.rename("cluster"), how="inner")
    df["is_microexon"] = df["cassette_length"].apply(is_microexon)
    out = df.groupby("cluster").agg(
        n_events=("is_microexon", "size"),
        n_microexons=("is_microexon", "sum"),
    )
    out["microexon_fraction"] = out["n_microexons"] / out["n_events"]
    return out


def cluster_mean_psi_trajectories(
    cluster_labels: pd.Series, mean_psi_per_condition: pd.DataFrame,
) -> pd.DataFrame:
    """Mean PSI trajectory per cluster, one row per cluster.

    Each row gives the average PSI of events in that cluster across the
    ordered conditions in ``mean_psi_per_condition.columns`` (e.g. days 0-3).
    """
    df = mean_psi_per_condition.join(cluster_labels.rename("cluster"), how="inner")
    return df.groupby("cluster").mean(numeric_only=True)

"""Statistical primitives for differential splicing analysis.

Implements:
  - Welch's two-sample t-test (per event, vectorized)
  - Mann-Whitney U with normal-approximation p-values
  - SUPPA2-style empirical p-value from between-replicate ΔPSI distribution
  - Benjamini-Hochberg FDR correction
  - 2x2 Fisher's exact test (for motif enrichment / microexon enrichment)

All p-values are pure numpy so the calling agent never imports scipy or
statsmodels. Two-sample tests support arbitrarily small replicate counts
(n=3 per condition is the realistic case here).
"""
from __future__ import annotations

import math
from typing import Iterable, List, Tuple

import numpy as np
import pandas as pd


# ---------------------------------------------------------------------------
# Numerical primitives (CDFs, gamma)
# ---------------------------------------------------------------------------

def _erfcc(x: np.ndarray) -> np.ndarray:
    """Complementary error function via Chebyshev fit (~7e-8 abs error)."""
    z = np.abs(x)
    t = 1.0 / (1.0 + 0.5 * z)
    ans = t * np.exp(
        -z * z - 1.26551223
        + t * (1.00002368
        + t * (0.37409196
        + t * (0.09678418
        + t * (-0.18628806
        + t * (0.27886807
        + t * (-1.13520398
        + t * (1.48851587
        + t * (-0.82215223
        + t * 0.17087277))))))))
    )
    return np.where(x >= 0, ans, 2.0 - ans)


def _normal_cdf(z: np.ndarray) -> np.ndarray:
    """Standard-normal CDF."""
    return 0.5 * _erfcc(-z / math.sqrt(2.0))


def _t_two_sided_p(t: np.ndarray, df: float) -> np.ndarray:
    """Two-sided Student-t p-value from the regularized incomplete beta.

    Formula: p_two = I_{df/(df+t^2)}(df/2, 1/2).
    """
    df = float(df)
    t = np.asarray(t, dtype=float)

    def betacf(a: float, b: float, x: np.ndarray, max_iter: int = 200, eps: float = 3e-7):
        qab, qap, qam = a + b, a + 1.0, a - 1.0
        c = np.ones_like(x)
        d = 1.0 - qab * x / qap
        d = np.where(np.abs(d) < 1e-30, 1e-30, d)
        d = 1.0 / d
        h = d.copy()
        for m in range(1, max_iter + 1):
            m2 = 2 * m
            aa = m * (b - m) * x / ((qam + m2) * (a + m2))
            d = 1.0 + aa * d
            d = np.where(np.abs(d) < 1e-30, 1e-30, d)
            c = 1.0 + aa / c
            c = np.where(np.abs(c) < 1e-30, 1e-30, c)
            d = 1.0 / d
            h = h * d * c
            aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
            d = 1.0 + aa * d
            d = np.where(np.abs(d) < 1e-30, 1e-30, d)
            c = 1.0 + aa / c
            c = np.where(np.abs(c) < 1e-30, 1e-30, c)
            d = 1.0 / d
            del_ = d * c
            h = h * del_
            if np.all(np.abs(del_ - 1.0) < eps):
                break
        return h

    def betai(a: float, b: float, x: np.ndarray):
        x = np.clip(x, 1e-15, 1.0 - 1e-15)
        bt = np.exp(
            math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b)
            + a * np.log(x) + b * np.log(1.0 - x)
        )
        out = np.empty_like(x, dtype=float)
        cond = x < (a + 1.0) / (a + b + 2.0)
        if np.any(cond):
            out[cond] = bt[cond] * betacf(a, b, x[cond]) / a
        if np.any(~cond):
            out[~cond] = 1.0 - bt[~cond] * betacf(b, a, 1.0 - x[~cond]) / b
        return out

    abs_t = np.abs(t)
    x = df / (df + abs_t * abs_t)
    return betai(df / 2.0, 0.5, x)


# ---------------------------------------------------------------------------
# Two-sample tests
# ---------------------------------------------------------------------------

def welch_t_test(
    psi: pd.DataFrame, group_a: List[str], group_b: List[str]
) -> pd.DataFrame:
    """Per-event Welch's two-sample t-test (group A vs group B).

    Returns a DataFrame indexed by event_id with columns
    ``mean_a, mean_b, dpsi, t_stat, df, pvalue`` (two-sided).
    """
    a = psi[group_a].values.astype(float)
    b = psi[group_b].values.astype(float)
    na, nb = a.shape[1], b.shape[1]
    ma = np.nanmean(a, axis=1)
    mb = np.nanmean(b, axis=1)
    va = np.nanvar(a, axis=1, ddof=1)
    vb = np.nanvar(b, axis=1, ddof=1)
    se = np.sqrt(va / na + vb / nb)
    se_safe = np.where(se == 0, np.nan, se)
    t = (ma - mb) / se_safe
    num = (va / na + vb / nb) ** 2
    den = (va ** 2) / (na ** 2 * (na - 1)) + (vb ** 2) / (nb ** 2 * (nb - 1))
    den_safe = np.where(den == 0, np.nan, den)
    df = num / den_safe
    df = np.nan_to_num(df, nan=na + nb - 2.0)
    df_eff = float(np.median(df[np.isfinite(df)])) if np.any(np.isfinite(df)) else float(na + nb - 2)
    p = _t_two_sided_p(np.nan_to_num(t, nan=0.0), df_eff)
    p = np.clip(p, 0.0, 1.0)
    p = np.where(np.isnan(t), 1.0, p)
    return pd.DataFrame(
        {
            "mean_a": ma, "mean_b": mb, "dpsi": ma - mb,
            "t_stat": t, "df": df, "pvalue": p,
        },
        index=psi.index,
    )


def mann_whitney_u(
    psi: pd.DataFrame, group_a: List[str], group_b: List[str]
) -> pd.DataFrame:
    """Per-event Mann-Whitney U (two-sided, normal approximation, tie-corrected).

    Returns DataFrame with ``u_stat``, ``z_stat``, ``pvalue``.
    """
    a = psi[group_a].values.astype(float)
    b = psi[group_b].values.astype(float)
    na, nb = a.shape[1], b.shape[1]
    n_total = na + nb
    n_events = a.shape[0]
    combined = np.concatenate([a, b], axis=1)
    ranks = np.empty_like(combined, dtype=float)
    for i in range(n_events):
        order = np.argsort(combined[i], kind="stable")
        sorted_vals = combined[i][order]
        rk = np.empty(n_total, dtype=float)
        j = 0
        while j < n_total:
            k = j
            while k + 1 < n_total and sorted_vals[k + 1] == sorted_vals[j]:
                k += 1
            avg = (j + k) / 2.0 + 1.0
            rk[j:k + 1] = avg
            j = k + 1
        ranks[i, order] = rk
    rank_sum_a = ranks[:, :na].sum(axis=1)
    u_a = rank_sum_a - na * (na + 1) / 2.0
    u_b = na * nb - u_a
    u_min = np.minimum(u_a, u_b)
    mu = na * nb / 2.0
    sigma = math.sqrt(na * nb * (na + nb + 1) / 12.0)
    sigma = max(sigma, 1e-10)
    z = (u_a - mu) / sigma
    p = 2.0 * (1.0 - _normal_cdf(np.abs(z)))
    p = np.clip(p, 0.0, 1.0)
    return pd.DataFrame({"u_stat": u_min, "z_stat": z, "pvalue": p}, index=psi.index)


# ---------------------------------------------------------------------------
# SUPPA2-style empirical p-value
# ---------------------------------------------------------------------------

def empirical_pvalue(
    observed_dpsi: np.ndarray, null_dpsi: np.ndarray
) -> np.ndarray:
    """SUPPA2 paper Eq. 3: ``p = (1 - ECDF(|dPSI|)) / 2``.

    Computed against the empirical CDF of ``|null_dpsi|``. ``observed_dpsi``
    can be signed; only its magnitude is compared. The factor 1/2 reflects
    the assumed symmetry of the background distribution (paper page 8).
    """
    abs_obs = np.abs(np.asarray(observed_dpsi, dtype=float))
    abs_null = np.abs(np.asarray(null_dpsi, dtype=float))
    abs_null = np.sort(abs_null)
    n = len(abs_null)
    if n == 0:
        return np.ones_like(abs_obs)
    # ECDF(x) = (1 + #{null <= x}) / (n + 1)  with continuity correction
    idx = np.searchsorted(abs_null, abs_obs, side="right")
    ecdf = (idx + 1.0) / (n + 1.0)
    p = (1.0 - ecdf) / 2.0
    return np.clip(p, 1.0 / (2.0 * (n + 1.0)), 1.0)


# ---------------------------------------------------------------------------
# Multiple-testing correction
# ---------------------------------------------------------------------------

def bh_fdr(pvalues: Iterable[float]) -> np.ndarray:
    """Benjamini-Hochberg adjusted p-values (vectorized, monotone)."""
    p = np.asarray(list(pvalues), dtype=float)
    n = len(p)
    if n == 0:
        return p
    order = np.argsort(p)
    ranked = p[order]
    adj = ranked * n / np.arange(1, n + 1)
    adj = np.minimum.accumulate(adj[::-1])[::-1]
    adj = np.clip(adj, 0.0, 1.0)
    out = np.empty_like(adj)
    out[order] = adj
    return out


def assemble_results(
    test_df: pd.DataFrame, dpsi: pd.Series
) -> pd.DataFrame:
    """Return a tidy results table with ``dpsi``, ``pvalue``, ``padj``, ``neg_log10_p``.

    ``test_df`` must contain a column ``pvalue``.
    """
    out = test_df.copy()
    out["dpsi"] = dpsi
    out["padj"] = bh_fdr(out["pvalue"].fillna(1.0).values)
    out["neg_log10_p"] = -np.log10(out["pvalue"].clip(lower=1e-300))
    return out


def call_significant_events(
    results: pd.DataFrame,
    pvalue_thresh: float = 0.05,
    dpsi_thresh: float = 0.05,
    use_padj: bool = False,
) -> pd.DataFrame:
    """Annotate each event as ``up`` / ``down`` / ``ns`` based on dPSI direction.

    A non-NS call requires ``|dpsi| > dpsi_thresh`` and either ``pvalue``
    (if ``use_padj=False``) or ``padj`` (if ``use_padj=True``) below threshold.
    """
    df = results.copy()
    pcol = "padj" if use_padj else "pvalue"
    sig = df[pcol] < float(pvalue_thresh)
    df["direction"] = np.where(
        sig & (df["dpsi"] >= float(dpsi_thresh)), "up",
        np.where(sig & (df["dpsi"] <= -float(dpsi_thresh)), "down", "ns"),
    )
    return df


# ---------------------------------------------------------------------------
# Categorical contingency tests for enrichment analyses
# ---------------------------------------------------------------------------

def fishers_exact_2x2(a: int, b: int, c: int, d: int) -> Tuple[float, float]:
    """Two-sided Fisher's exact test on a 2x2 table.

    Table layout::

            success  failure
        A      a        b
        B      c        d

    Returns ``(odds_ratio, p_value)``. Pure-python, suitable for ~10^4 calls.
    """
    a, b, c, d = int(a), int(b), int(c), int(d)
    n = a + b + c + d
    r1 = a + b
    r2 = c + d
    c1 = a + c
    if min(r1, r2, c1) < 0 or n == 0:
        return 0.0, 1.0
    log_fact = [0.0]
    for i in range(1, n + 1):
        log_fact.append(log_fact[-1] + math.log(i))

    def lp(k):
        return (
            log_fact[r1] + log_fact[r2] + log_fact[c1] + log_fact[n - c1]
            - log_fact[n] - log_fact[k] - log_fact[r1 - k]
            - log_fact[c1 - k] - log_fact[r2 - (c1 - k)]
        )

    k_min = max(0, c1 - r2)
    k_max = min(r1, c1)
    log_p_obs = lp(a)
    total = 0.0
    for k in range(k_min, k_max + 1):
        lk = lp(k)
        if lk <= log_p_obs + 1e-12:
            total += math.exp(lk)
    or_ = (a * d) / (b * c) if (b * c) > 0 else float("inf")
    return float(or_), float(min(total, 1.0))

"""Splice-factor motif scanning primitives.

PWM-based scanning of upstream / downstream flanking sequences with log-odds
scoring against the genome background frequencies, plus enrichment tests
(Fisher's exact) of motif presence in regulated vs non-regulated event sets.
"""
from __future__ import annotations

from typing import Dict, Iterable, List, Tuple

import numpy as np
import pandas as pd

try:
    from .differential import fishers_exact_2x2
except ImportError:  # support running as a flat module
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from differential import fishers_exact_2x2

BASE_INDEX: Dict[str, int] = {"A": 0, "C": 1, "G": 2, "T": 3}
DEFAULT_BACKGROUND = (0.28, 0.22, 0.22, 0.28)  # genome-wide ACGT frequencies


def pwm_to_log_odds(pwm: np.ndarray, background: Iterable[float] = DEFAULT_BACKGROUND,
                    pseudo: float = 1e-3) -> np.ndarray:
    """Convert a frequency PWM (L x 4) to a log2-odds matrix.

    ``pwm[i, j]`` is the probability of base j at position i.
    The returned matrix has the same shape; entries are
    ``log2((pwm + pseudo) / background)``.
    """
    pwm = np.asarray(pwm, dtype=float)
    bg = np.asarray(list(background), dtype=float)
    return np.log2((pwm + float(pseudo)) / bg)


def encode_sequence(seq: str) -> np.ndarray:
    """Map a DNA string to a numpy int array of base indices (A=0,C=1,G=2,T=3).

    Unknown / N bases are mapped to ``-1``.
    """
    out = np.empty(len(seq), dtype=np.int8)
    for i, ch in enumerate(seq):
        out[i] = BASE_INDEX.get(ch.upper(), -1)
    return out


def reverse_complement(seq: str) -> str:
    """Return DNA reverse-complement sequence (A/C/G/T only)."""
    comp = str.maketrans("ACGTacgt", "TGCAtgca")
    return str(seq).translate(comp)[::-1]


def standardize_flanks_to_transcript_orientation(
    flanking: pd.DataFrame,
    strand_by_event: Dict[str, str],
    upstream_col: str = "upstream_seq",
    downstream_col: str = "downstream_seq",
) -> pd.DataFrame:
    """Normalize genomic flanks to transcript orientation.

    If input flanks are genomic-coordinate upstream/downstream:
    - '+' strand: unchanged
    - '-' strand: transcript-upstream = RC(genomic-downstream),
                  transcript-downstream = RC(genomic-upstream)
    """
    out = flanking.copy()
    up_vals = []
    dn_vals = []
    for _, row in out.iterrows():
        eid = row.get("event_id")
        up = str(row.get(upstream_col, ""))
        dn = str(row.get(downstream_col, ""))
        strand = str(strand_by_event.get(eid, "+"))
        if strand == "-":
            up_vals.append(reverse_complement(dn))
            dn_vals.append(reverse_complement(up))
        else:
            up_vals.append(up)
            dn_vals.append(dn)
    out[upstream_col] = up_vals
    out[downstream_col] = dn_vals
    return out


def scan_pwm_max_score(seq: str, lod: np.ndarray) -> Tuple[float, int]:
    """Slide an LOD matrix across ``seq``, return ``(max_score, argmax_position)``.

    ``lod`` has shape ``(L, 4)``. Bases coded as ``-1`` contribute 0.
    Returns ``(-inf, -1)`` if the sequence is shorter than ``L``.
    """
    L = lod.shape[0]
    if len(seq) < L:
        return float("-inf"), -1
    enc = encode_sequence(seq)
    n = len(enc) - L + 1
    best = float("-inf")
    arg = -1
    for i in range(n):
        s = 0.0
        for j in range(L):
            b = enc[i + j]
            if b >= 0:
                s += lod[j, b]
        if s > best:
            best = s
            arg = i
    return best, arg


def count_pwm_hits(seq: str, lod: np.ndarray, threshold: float) -> int:
    """Count how many windows in ``seq`` have LOD score above ``threshold``."""
    L = lod.shape[0]
    if len(seq) < L:
        return 0
    enc = encode_sequence(seq)
    n = len(enc) - L + 1
    cnt = 0
    for i in range(n):
        s = 0.0
        for j in range(L):
            b = enc[i + j]
            if b >= 0:
                s += lod[j, b]
        if s >= threshold:
            cnt += 1
    return cnt


def scan_event_set(
    event_ids: List[str], flanking: pd.DataFrame, lods: Dict[str, np.ndarray],
    region: str = "upstream", threshold: float = 5.0,
    strand_by_event: Dict[str, str] | None = None,
    assume_genomic_flanks: bool = True,
) -> pd.DataFrame:
    """Scan every (event, TF) pair and report whether at least one hit is found.

    Parameters
    ----------
    event_ids   list of event IDs to scan
    flanking    DataFrame with columns ``event_id, upstream_seq, downstream_seq``
    lods        dict ``{tf: log_odds_matrix}``
    region      ``"upstream"`` or ``"downstream"``
    threshold   minimum LOD score to call a hit
    strand_by_event mapping from event_id to strand (+/-) used for
                 transcript-orientation normalization
    assume_genomic_flanks if True, interpret upstream/downstream as genomic
                 windows and standardize to transcript orientation before
                 scanning (recommended for this bundle)

    Returns a wide DataFrame with one row per event_id and one column per TF
    containing 0/1 hit indicators.
    """
    region_col = {
        "upstream": "upstream_seq",
        "downstream": "downstream_seq",
    }[region]
    flank_df = flanking
    if assume_genomic_flanks and strand_by_event is not None:
        flank_df = standardize_flanks_to_transcript_orientation(
            flanking, strand_by_event
        )
    fmap = flank_df.set_index("event_id")[region_col].to_dict()
    rows = []
    tfs = list(lods.keys())
    for eid in event_ids:
        seq = fmap.get(eid)
        if not isinstance(seq, str):
            rows.append({tf: 0 for tf in tfs})
            continue
        row = {}
        for tf in tfs:
            row[tf] = int(count_pwm_hits(seq, lods[tf], threshold) > 0)
        rows.append(row)
    return pd.DataFrame(rows, index=pd.Index(event_ids, name="event_id"))


def motif_enrichment(
    fg_hits: pd.DataFrame, bg_hits: pd.DataFrame
) -> pd.DataFrame:
    """For every TF column shared by ``fg_hits`` and ``bg_hits`` compute a 2x2
    Fisher's exact test (foreground vs background hit rate).

    Returns a DataFrame indexed by TF with ``n_fg``, ``n_fg_hit``,
    ``n_bg``, ``n_bg_hit``, ``odds_ratio`` and ``pvalue`` columns.
    """
    rows = []
    common = sorted(set(fg_hits.columns) & set(bg_hits.columns))
    for tf in common:
        a = int(fg_hits[tf].sum()); b = int((fg_hits[tf] == 0).sum())
        c = int(bg_hits[tf].sum()); d = int((bg_hits[tf] == 0).sum())
        or_, p = fishers_exact_2x2(a, b, c, d)
        rows.append({
            "tf": tf,
            "n_fg": a + b, "n_fg_hit": a,
            "n_bg": c + d, "n_bg_hit": c,
            "fg_hit_rate": a / max(a + b, 1),
            "bg_hit_rate": c / max(c + d, 1),
            "odds_ratio": or_, "pvalue": p,
        })
    out = pd.DataFrame(rows).set_index("tf")
    return out.sort_values("pvalue")


def gc_content(seq: str) -> float:
    """Fractional GC content of a DNA sequence (ignores N bases)."""
    if not seq:
        return float("nan")
    s = seq.upper()
    g = s.count("G"); c = s.count("C")
    valid = sum(1 for b in s if b in "ACGT")
    if valid == 0:
        return float("nan")
    return (g + c) / valid

"""Plotting primitives used by the splicing analysis pipeline.

Each plotting function accepts only basic Python / pandas / numpy inputs
plus an absolute output path, and returns a dict ``{"path": <abs_path>}``
to make hand-off into multimodal answer items unambiguous.

All figures use a consistent Matplotlib style with no scipy dependence.
"""
from __future__ import annotations

import os
from typing import Dict, Iterable, List, Sequence

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def _ensure_parent(path: str) -> None:
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)


def plot_volcano(
    dpsi: Sequence[float], pvalues: Sequence[float], out_path: str,
    dpsi_thresh: float = 0.10, pvalue_thresh: float = 0.05,
    title: str = "Differential splicing volcano",
) -> Dict[str, str]:
    """Plot ΔPSI on x and -log10(pvalue) on y, color by significance.

    Returns ``{"path": <out_path>}``.
    """
    _ensure_parent(out_path)
    dpsi = np.asarray(dpsi, dtype=float)
    p = np.asarray(pvalues, dtype=float)
    ny = -np.log10(np.clip(p, 1e-300, 1.0))
    sig = (p < pvalue_thresh) & (np.abs(dpsi) > dpsi_thresh)
    fig, ax = plt.subplots(figsize=(6, 5))
    ax.scatter(dpsi[~sig], ny[~sig], s=4, c="#aaaaaa", alpha=0.5, label=f"ns ({(~sig).sum()})")
    up = sig & (dpsi > 0); dn = sig & (dpsi < 0)
    ax.scatter(dpsi[up], ny[up], s=6, c="#d62728", alpha=0.7, label=f"up ({up.sum()})")
    ax.scatter(dpsi[dn], ny[dn], s=6, c="#1f77b4", alpha=0.7, label=f"down ({dn.sum()})")
    ax.axhline(-np.log10(pvalue_thresh), ls="--", c="k", lw=0.5)
    ax.axvline( dpsi_thresh, ls="--", c="k", lw=0.5)
    ax.axvline(-dpsi_thresh, ls="--", c="k", lw=0.5)
    ax.set_xlabel("ΔPSI")
    ax.set_ylabel("-log10(p-value)")
    ax.set_title(title)
    ax.legend(loc="upper left", fontsize=8)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": os.path.abspath(out_path)}


def plot_event_class_pie(
    counts: pd.Series, out_path: str, title: str = "Event class composition",
) -> Dict[str, str]:
    """Pie chart of event-class counts (from ``count_events_per_class``)."""
    _ensure_parent(out_path)
    fig, ax = plt.subplots(figsize=(5, 5))
    colors = ["#4c78a8", "#f58518", "#54a24b", "#e45756", "#72b7b2", "#b279a2", "#9d755d"]
    ax.pie(
        counts.values, labels=[f"{n} ({v})" for n, v in zip(counts.index, counts.values)],
        autopct="%1.1f%%", startangle=90, colors=colors[: len(counts)],
    )
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": os.path.abspath(out_path)}


def plot_psi_heatmap(
    psi: pd.DataFrame, out_path: str, top_n: int = 200, cmap: str = "RdYlBu_r",
    title: str = "Top differential events",
) -> Dict[str, str]:
    """Heatmap of the top ``top_n`` events ordered by row variance.

    Rows are events; columns are samples in their original order.
    """
    _ensure_parent(out_path)
    var = psi.var(axis=1).fillna(0)
    top = var.sort_values(ascending=False).head(int(top_n)).index
    M = psi.loc[top].values
    fig, ax = plt.subplots(figsize=(7, 6))
    im = ax.imshow(M, aspect="auto", cmap=cmap, vmin=0.0, vmax=1.0, interpolation="nearest")
    ax.set_xticks(range(M.shape[1]))
    ax.set_xticklabels(psi.columns, rotation=70, fontsize=7)
    ax.set_ylabel(f"Top {top_n} events by variance")
    ax.set_title(title)
    fig.colorbar(im, ax=ax, label="PSI")
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": os.path.abspath(out_path)}


def plot_cluster_trajectories(
    cluster_psi: pd.DataFrame, out_path: str,
    title: str = "Cluster mean PSI trajectories",
) -> Dict[str, str]:
    """Line plot of mean PSI per cluster across the ordered conditions."""
    _ensure_parent(out_path)
    fig, ax = plt.subplots(figsize=(6, 4))
    for cl, row in cluster_psi.iterrows():
        ax.plot(list(cluster_psi.columns), row.values, marker="o", label=f"Cluster {cl}")
    ax.set_xlabel("Condition")
    ax.set_ylabel("Mean PSI")
    ax.set_ylim(0.0, 1.0)
    ax.set_title(title)
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": os.path.abspath(out_path)}


def plot_motif_enrichment_bar(
    enrichment: pd.DataFrame, out_path: str,
    title: str = "Splice-factor motif enrichment",
) -> Dict[str, str]:
    """Bar chart of -log10(p) per TF from a motif-enrichment DataFrame.

    ``enrichment`` must have ``pvalue`` and ``odds_ratio`` columns and be
    indexed by TF name.
    """
    _ensure_parent(out_path)
    df = enrichment.sort_values("pvalue")
    nlog = -np.log10(df["pvalue"].clip(lower=1e-300))
    fig, ax = plt.subplots(figsize=(6, 4))
    colors = ["#d62728" if o > 1 else "#1f77b4" for o in df["odds_ratio"].values]
    ax.bar(df.index, nlog.values, color=colors)
    ax.set_ylabel("-log10(p-value)")
    ax.set_title(title)
    for i, (tf, o) in enumerate(zip(df.index, df["odds_ratio"].values)):
        ax.text(i, nlog.values[i] + 0.1, f"OR={o:.2f}", ha="center", fontsize=8)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": os.path.abspath(out_path)}


def plot_microexon_distribution(
    cassette_lengths_regulated: Iterable[int],
    cassette_lengths_nonregulated: Iterable[int],
    out_path: str, max_length: int = 200,
    title: str = "Cassette exon length distribution",
) -> Dict[str, str]:
    """Histogram of cassette exon lengths for regulated vs non-regulated SE
    events; vertical line at 28 nt marks the microexon cutoff."""
    _ensure_parent(out_path)
    a = np.asarray(list(cassette_lengths_regulated), dtype=float)
    b = np.asarray(list(cassette_lengths_nonregulated), dtype=float)
    a = a[(a > 0) & (a <= max_length)]
    b = b[(b > 0) & (b <= max_length)]
    fig, ax = plt.subplots(figsize=(6, 4))
    bins = np.linspace(0, max_length, 41)
    ax.hist(b, bins=bins, color="#aaaaaa", alpha=0.6, label=f"non-regulated (n={len(b)})", density=True)
    ax.hist(a, bins=bins, color="#d62728", alpha=0.6, label=f"regulated (n={len(a)})", density=True)
    ax.axvline(28, ls="--", c="k", lw=1.0, label="microexon cutoff (28 nt)")
    ax.set_xlabel("Cassette exon length (nt)")
    ax.set_ylabel("Density")
    ax.set_title(title)
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": os.path.abspath(out_path)}


def plot_pca_samples(
    psi: pd.DataFrame, sample_meta: pd.DataFrame, out_path: str,
    color_col: str = "day", n_top_var: int = 5000,
    title: str = "PCA of samples on top-variance events",
) -> Dict[str, str]:
    """Project samples onto the first two PCs of the PSI matrix and plot.

    Top ``n_top_var`` events by variance are used. Centering is per row.
    SVD is performed with ``numpy.linalg.svd``.
    """
    _ensure_parent(out_path)
    var = psi.var(axis=1).fillna(0)
    top = var.sort_values(ascending=False).head(int(n_top_var)).index
    M = psi.loc[top].values  # events x samples
    M_c = M - M.mean(axis=1, keepdims=True)
    M_c = np.nan_to_num(M_c, nan=0.0)
    # PCA on samples: run SVD on transposed matrix
    U, S, Vt = np.linalg.svd(M_c.T, full_matrices=False)
    pc = U * S  # samples x PCs
    var_explained = (S ** 2) / (S ** 2).sum()
    fig, ax = plt.subplots(figsize=(6, 5))
    sm = sample_meta.set_index("sample_id").loc[psi.columns]
    groups = sm[color_col].astype(str)
    palette = plt.cm.viridis(np.linspace(0.0, 0.9, groups.nunique()))
    for i, g in enumerate(sorted(groups.unique())):
        mask = (groups == g).values
        ax.scatter(pc[mask, 0], pc[mask, 1], s=40, c=[palette[i]], label=str(g))
    ax.set_xlabel(f"PC1 ({100*var_explained[0]:.1f}%)")
    ax.set_ylabel(f"PC2 ({100*var_explained[1]:.1f}%)")
    ax.set_title(title)
    ax.legend(title=color_col, fontsize=8)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": os.path.abspath(out_path)}

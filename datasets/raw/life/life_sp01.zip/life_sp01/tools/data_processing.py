"""Generic data-processing primitives for tabular task bundles."""
from __future__ import annotations

import csv
import json
from typing import Any


def read_csv(path: str, delimiter: str = ",") -> list[dict]:
    with open(path, newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f, delimiter=delimiter))


def write_csv(rows: list[dict], path: str) -> None:
    if not rows:
        with open(path, "w", encoding="utf-8") as f:
            f.write("")
        return
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def read_json(path: str) -> Any:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def write_json(obj: Any, path: str, indent: int = 2) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=indent)


def drop_missing(rows: list[dict], required_cols: list[str]) -> list[dict]:
    out = []
    for r in rows:
        if all((r.get(c) is not None) and (str(r.get(c)).strip() != "") for c in required_cols):
            out.append(r)
    return out


def coerce_numeric(rows: list[dict], cols: list[str]) -> list[dict]:
    out = []
    for r in rows:
        rr = dict(r)
        for c in cols:
            try:
                rr[c] = float(rr[c])
            except Exception:
                rr[c] = None
        out.append(rr)
    return out

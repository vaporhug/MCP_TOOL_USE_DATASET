# life_sp01 Tools

## Domain Tools
- `data_loading.py`: load PSI/event/sample/flanking/PWM tables and align metadata.
- `normalization.py`: per-condition means and replicate-null construction.
- `differential.py`: empirical p-values, Welch/MWU, FDR, Fisher exact.
- `event_classification.py`: event parsing, microexon labeling, density clustering.
- `motif_scan.py`: PWM log-odds scanning and enrichment tests.
- `plotting.py`: volcano/trajectory/motif/microexon plotting primitives.

## Generic Utilities
- `data_processing.py`: generic CSV/JSON read/write and cleaning helpers.
- `database_retrieval.py`: offline-safe stubs (network access disabled).

The bundle's figure-generation and motif-analysis workflow uses fixed settings:
- regulated event: empirical `p < 0.05` in at least one adjacent-stage pair.
- adjacent pairs: `Day_0->Day_1`, `Day_1->Day_3`, `Day_3->Day_4`.
- clustering: `density_cluster_psi_trajectories(eps=0.15, min_samples=15)`.
- motif flank orientation: scan windows are standardized to transcript
  orientation using `event_metadata.strand` (`+` unchanged, `-` uses
  reverse-complement with upstream/downstream swap) before PWM matching.

All machine-readable benchmark settings are recorded in
`artifacts/reference_config.json` (thresholds, pair definitions,
null-construction, clustering, motif-scan, and background policy).

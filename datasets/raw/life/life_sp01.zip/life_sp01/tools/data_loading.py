"""I/O primitives for the alternative-splicing analysis task.

All loaders return clean pandas / numpy objects. No scipy or statsmodels
imports anywhere in this package; every statistical primitive is implemented
in pure numpy in `differential.py`.
"""
from __future__ import annotations

from typing import Dict, List, Tuple

import numpy as np
import pandas as pd


def load_psi_matrix(path: str) -> pd.DataFrame:
    """Load the event-by-sample PSI matrix.

    Rows are SUPPA-style event identifiers
    (``ENSG...;<EventType>:<chrom>:<coords>:<strand>``).
    Columns are biological samples (``Busskamp_Day_X_events_Y``).
    Values are PSI in [0, 1].
    """
    df = pd.read_csv(path, index_col=0)
    df.index = df.index.astype(str)
    df.index.name = "event_id"
    return df


def load_event_metadata(path: str) -> pd.DataFrame:
    """Load per-event metadata.

    Columns: ``event_id``, ``gene_id``, ``event_type`` (SE / A5 / A3 / MX / RI),
    ``chrom``, ``start``, ``end``, ``strand``, ``cassette_length`` (only set
    for SE events; gives the length of the alternative middle exon in
    nucleotides — used to identify microexons (<28 nt)).
    """
    return pd.read_csv(path)


def load_sample_metadata(path: str) -> pd.DataFrame:
    """Load per-sample metadata.

    Columns: ``sample_id`` (matches a PSI-matrix column), ``day`` (0/1/2/3
    for the time-course of iPSC -> bipolar-neuron differentiation), and
    ``replicate`` (1/2/3, biological replicates per stage).
    """
    return pd.read_csv(path)


def load_flanking_sequences(path: str) -> pd.DataFrame:
    """Load 200-bp upstream and 200-bp downstream sequences flanking each SE
    cassette exon.

    Columns: ``event_id``, ``upstream_seq``, ``downstream_seq``. Sequences are
    uppercase A/C/G/T strings of length 200, derived from the genomic regions
    flanking the alternative cassette exon and used as input for splice-factor
    motif enrichment.
    """
    df = pd.read_csv(path)
    for col in ("upstream_seq", "downstream_seq"):
        df[col] = df[col].astype(str).str.upper()
    return df


def load_pwms(path: str) -> Dict[str, np.ndarray]:
    """Load splice-factor PWMs as a dict ``{tf_name: L x 4 frequency matrix}``.

    Input file is in long format with one row per (tf, position) and columns
    ``A, C, G, T`` summing to 1 per position. Returned matrices have one row
    per position and four columns ordered A, C, G, T.
    """
    df = pd.read_csv(path)
    out: Dict[str, np.ndarray] = {}
    for tf, sub in df.groupby("tf"):
        sub = sub.sort_values("position")
        out[str(tf)] = sub[["A", "C", "G", "T"]].values.astype(float)
    return out


def split_samples_by_condition(
    sample_meta: pd.DataFrame, condition_col: str = "day"
) -> Dict[str, List[str]]:
    """Group sample IDs by the chosen condition column.

    Returns ``{str(condition_value): [sample_id, ...]}``.
    """
    out: Dict[str, List[str]] = {}
    for v, sub in sample_meta.groupby(condition_col):
        out[str(v)] = sub["sample_id"].astype(str).tolist()
    return out


def align_psi_to_metadata(
    psi: pd.DataFrame, sample_meta: pd.DataFrame
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Restrict ``psi`` and ``sample_meta`` to samples present in both, in matched order."""
    keep = [c for c in psi.columns if c in set(sample_meta["sample_id"].astype(str))]
    sm = sample_meta.set_index("sample_id").loc[keep].reset_index()
    return psi[keep], sm


def filter_events_by_completeness(
    psi: pd.DataFrame, min_valid_fraction: float = 1.0
) -> pd.DataFrame:
    """Keep only events whose PSI is non-missing in at least ``min_valid_fraction``
    of samples (default = require all 12 samples)."""
    valid = psi.notna().mean(axis=1)
    return psi.loc[valid >= float(min_valid_fraction)]


def subset_events_by_type(
    psi: pd.DataFrame, event_meta: pd.DataFrame, event_types: List[str]
) -> pd.DataFrame:
    """Subset the PSI matrix to events whose ``event_type`` is in ``event_types``."""
    keep_ids = set(event_meta.loc[event_meta["event_type"].isin(event_types), "event_id"])
    return psi.loc[psi.index.isin(keep_ids)]


def summarize_psi_matrix(psi: pd.DataFrame) -> Dict[str, float]:
    """Return basic descriptive stats of the PSI matrix."""
    flat = psi.values.flatten()
    flat = flat[~np.isnan(flat)]
    return {
        "n_events": int(psi.shape[0]),
        "n_samples": int(psi.shape[1]),
        "mean_psi": float(flat.mean()),
        "median_psi": float(np.median(flat)),
        "fraction_zero": float((flat == 0).mean()),
        "fraction_one": float((flat == 1).mean()),
    }

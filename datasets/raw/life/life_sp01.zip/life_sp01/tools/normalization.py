"""PSI matrix normalization and aggregation primitives.

Functions for computing per-condition mean/variance, between-replicate
variability (used by SUPPA2 to test ΔPSI significance), and simple
PSI value transforms.
"""
from __future__ import annotations

from typing import Dict, List

import numpy as np
import pandas as pd


def per_condition_mean(
    psi: pd.DataFrame, condition_to_samples: Dict[str, List[str]]
) -> pd.DataFrame:
    """Compute the mean PSI per condition for every event.

    Returns a DataFrame with one column per condition.
    """
    out = {}
    for cond, cols in condition_to_samples.items():
        out[cond] = psi[cols].mean(axis=1)
    return pd.DataFrame(out, index=psi.index)


def per_condition_std(
    psi: pd.DataFrame, condition_to_samples: Dict[str, List[str]]
) -> pd.DataFrame:
    """Compute the unbiased per-condition standard deviation."""
    out = {}
    for cond, cols in condition_to_samples.items():
        out[cond] = psi[cols].std(axis=1, ddof=1)
    return pd.DataFrame(out, index=psi.index)


def between_replicate_dpsi(
    psi: pd.DataFrame, condition_to_samples: Dict[str, List[str]]
) -> np.ndarray:
    """Return all pairwise within-condition replicate ΔPSI values.

    For each condition with ``r`` replicates, this contributes ``r*(r-1)/2``
    pairwise PSI differences per event. The resulting flattened array gives
    the empirical distribution of |ΔPSI| under the null hypothesis of no
    biological change between replicates — this is the SUPPA2 background
    distribution (paper Eq. 2).
    """
    diffs: List[np.ndarray] = []
    for cond, cols in condition_to_samples.items():
        sub = psi[cols].values
        n = sub.shape[1]
        for i in range(n):
            for j in range(i + 1, n):
                diffs.append(sub[:, i] - sub[:, j])
    return np.concatenate(diffs) if diffs else np.array([])


def between_condition_dpsi(
    mean_per_cond: pd.DataFrame, cond_a: str, cond_b: str
) -> pd.Series:
    """Return ΔPSI = mean(condition A) - mean(condition B) per event."""
    return mean_per_cond[cond_a] - mean_per_cond[cond_b]


def filter_low_variability(
    psi: pd.DataFrame, condition_to_samples: Dict[str, List[str]],
    min_range: float = 0.05,
) -> pd.DataFrame:
    """Keep only events whose mean-PSI ranges over at least ``min_range`` across conditions."""
    mp = per_condition_mean(psi, condition_to_samples)
    rng = mp.max(axis=1) - mp.min(axis=1)
    return psi.loc[rng >= float(min_range)]


def logit_transform(psi: pd.DataFrame, eps: float = 1e-3) -> pd.DataFrame:
    """Apply a clipped logit transform: ``log(p/(1-p))`` after clipping to [eps, 1-eps]."""
    p = psi.clip(lower=eps, upper=1 - eps)
    return np.log(p / (1.0 - p))


def standardize_rows(psi: pd.DataFrame) -> pd.DataFrame:
    """Z-score each event's PSI across samples (rows)."""
    mu = psi.mean(axis=1)
    sd = psi.std(axis=1, ddof=1).replace(0.0, 1e-9)
    return psi.sub(mu, axis=0).div(sd, axis=0)

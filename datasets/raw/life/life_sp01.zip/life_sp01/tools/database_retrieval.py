"""Minimal retrieval helpers for metadata endpoints used in paper tasks."""
from __future__ import annotations

import json
import urllib.parse
import urllib.request


def fetch_url(url: str, timeout: int = 30) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "life_sp01-db/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read()


def query_doi(doi: str) -> dict:
    clean = doi.strip().removeprefix("https://doi.org/").removeprefix("doi:")
    url = f"https://api.crossref.org/works/{urllib.parse.quote(clean, safe='')}"
    payload = fetch_url(url)
    return json.loads(payload.decode("utf-8"))


def websearch(query: str, max_results: int = 10) -> list[dict]:
    q = urllib.parse.quote_plus(query)
    n = max(1, min(int(max_results), 50))
    url = f"https://api.openalex.org/works?search={q}&per-page={n}"
    payload = json.loads(fetch_url(url).decode("utf-8"))
    out = []
    for it in payload.get("results", []):
        out.append({
            "title": it.get("display_name"),
            "url": it.get("id"),
            "year": it.get("publication_year"),
        })
    return out

"""Offline retrieval helpers for self-contained benchmark execution.

Network access is intentionally disabled for this task bundle so that all
analysis remains reproducible from bundled files only.
"""
from __future__ import annotations

from typing import Dict, List


def _offline_error(tool_name: str) -> dict:
    return {
        "error": (
            f"{tool_name} is disabled in offline benchmark mode. "
            "Use only bundled files under input_data/."
        )
    }


def fetch_url(url: str, timeout: int = 30) -> bytes:
    raise RuntimeError(
        "Network retrieval is disabled in life_sp01. "
        "This benchmark is strictly offline and self-contained."
    )


def query_doi(doi: str) -> Dict[str, str]:
    return _offline_error("query_doi")


def websearch(query: str, max_results: int = 10) -> List[dict]:
    _ = (query, max_results)
    return []

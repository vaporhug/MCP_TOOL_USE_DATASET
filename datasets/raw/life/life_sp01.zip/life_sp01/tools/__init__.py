"""Tools for the alternative-splicing analysis SCP task.

Modules
-------
data_loading        : I/O for PSI matrix, metadata, sequences, PWMs
normalization       : per-condition aggregation, between-replicate ΔPSI
differential        : Welch t / Mann-Whitney / SUPPA2-empirical p / BH-FDR / Fisher
event_classification: SE/A5/A3/MX/RI parsing, microexon detection, clustering
motif_scan          : PWM log-odds scoring, motif enrichment via Fisher
plotting            : volcano, heatmap, PCA, motif bar, length histogram, pie
"""

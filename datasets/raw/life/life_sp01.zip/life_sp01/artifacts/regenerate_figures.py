"""Regenerate the bundled artifact figures from the local tools + PSI matrix.

Run from the bundle root:
    cd life_sp01 && python3 artifacts/regenerate_figures.py

Outputs (in artifacts/) — figures only; the script does NOT persist
per-event tables or numeric summaries, so the bundle does not leak the
expected analysis outputs that the model is supposed to compute itself:
  fig1_adjacent_stage_volcanoes.png    Three-panel volcano plots for adjacent
                                       stage comparisons (Day0->1, Day1->3,
                                       Day3->4); points significant in each
                                       panel are highlighted.
  fig5_cluster_trajectories.png       Mean-PSI trajectories per density-cluster
                                       (bundle-side DBSCAN proxy).
  fig6_motif_enrichment_per_cluster.png  Per-cluster motif enrichment
                                       (cluster-by-region heat-map of
                                       log2 Fisher OR vs non-regulated control).
  fig7_microexon_fraction_per_cluster.png  Per-cluster microexon fraction.

Pipeline:
  1. Pairwise empirical p-values between consecutive stages (Day_0->1, 1->3,
     3->4), comparing observed |ΔPSI| to a flattened between-replicate
     within-condition null distribution (a bundle-side proxy for the
     paper's SUPPA2 transcript-abundance-conditioned null, which requires
     TPM input that is NOT in the bundle).
  2. Event is regulated if p<0.05 holds in AT LEAST ONE consecutive pair
     (= the paper's definition). An optional ``min_dpsi`` argument applies
     a magnitude filter on top of p<0.05 (default 0.0 = no magnitude gate).
  3. Density-based clustering on the multi-condition mean-PSI trajectory of
     the regulated events using the bundle-side DBSCAN proxy.
  4. Per-cluster microexon enrichment (Fisher).
  5. Per-cluster motif enrichment in 200-bp upstream and 200-bp downstream
     flanks against the five bundled PWMs; reported as log2 OR + Fisher p.
"""
import os, sys, json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))

import differential as diff
import normalization as norm
import event_classification as ec
import motif_scan as ms

DATA_DIR = os.path.join(ROOT, "input_data", "data")
OUTDIR   = os.path.dirname(os.path.abspath(__file__))


def main():
    psi = pd.read_csv(os.path.join(DATA_DIR, "psi_matrix.csv"), index_col=0)
    meta = pd.read_csv(os.path.join(DATA_DIR, "event_metadata.csv"))
    cols = list(psi.columns)
    conds = {f"Day_{d}": [c for c in cols if f"Day_{d}" in c] for d in (0, 1, 3, 4)}

    # ---- Step 1: pairwise empirical-p across all consecutive stage pairs ----
    # Paper definition of regulated event: SUPPA2 empirical p < 0.05 in at
    # least one comparison between adjacent stages (no |dPSI| gate in the
    # paper's primary definition). MIN_DPSI is an OPTIONAL effect-size
    # filter; default 0.0 reproduces the paper definition.
    MIN_DPSI = 0.0
    null = np.abs(norm.between_replicate_dpsi(psi, conds))
    pairs = [("Day_0", "Day_1"), ("Day_1", "Day_3"), ("Day_3", "Day_4")]
    per_pair_p   = {}
    per_pair_dpsi = {}
    per_pair_reg = {}
    for a, b in pairs:
        obs = (psi[conds[b]].mean(axis=1) - psi[conds[a]].mean(axis=1)).values
        p = diff.empirical_pvalue(obs, null)
        per_pair_p[f"{a}->{b}"]   = p
        per_pair_dpsi[f"{a}->{b}"] = obs
        per_pair_reg[f"{a}->{b}"]  = (p < 0.05) & (np.abs(obs) > MIN_DPSI)
    reg_any = np.zeros(len(psi), dtype=bool)
    for k, m in per_pair_reg.items():
        reg_any |= m
    all_regulated_idx = psi.index[reg_any]
    sig_per_pair = {k: int(m.sum()) for k, m in per_pair_reg.items()}
    n_regulated = int(reg_any.sum())
    # (counts intentionally not printed: those are exactly the analysis
    # outputs the benchmark task expects the model to compute itself)

    # ---- Step 2: density-based clustering of regulated events ----
    mean_psi = norm.per_condition_mean(psi, conds).reindex(psi.index)
    # Force the helper to see exactly the union-defined regulated set as
    # "significant"; mark all others as non-regulated.
    p_clip    = np.ones(len(psi))
    dpsi_clip = np.zeros(len(psi))
    reg_pos = psi.index.get_indexer(all_regulated_idx.tolist())
    reg_pos = reg_pos[reg_pos >= 0]
    p_clip[reg_pos]    = 1e-6
    dpsi_clip[reg_pos] = 0.10
    res = pd.DataFrame({"pvalue": p_clip, "dpsi": dpsi_clip}, index=psi.index)
    # Fixed benchmark clustering config (aligned with reference_config.json).
    cluster_method = "DBSCAN"
    labels = ec.density_cluster_psi_trajectories(
        res, mean_psi, pvalue_thresh=0.05, dpsi_thresh=0.0,
        eps=0.15, min_samples=15)

    # ---- Step 3: per-cluster microexon enrichment ----
    meta_indexed = meta.set_index("event_id")
    cl = pd.to_numeric(meta_indexed["cassette_length"], errors="coerce")
    is_microexon_all = ((cl > 0) & (cl < 28)).astype(bool)
    cluster_table_rows = []
    for cid in sorted([c for c in labels.unique() if c >= 0]):
        events_in = labels[labels == cid].index
        n_events = len(events_in)
        # Fisher's exact for microexon enrichment of this cluster vs other regulated events
        other_regulated = labels[(labels >= 0) & (labels != cid)].index
        a = int(is_microexon_all.reindex(events_in).fillna(False).sum())
        b = int(n_events - a)
        c_ = int(is_microexon_all.reindex(other_regulated).fillna(False).sum())
        d_ = int(len(other_regulated) - c_)
        try:
            odds, pval = diff.fishers_exact_2x2(a, b, c_, d_)
        except Exception:
            odds, pval = float("nan"), float("nan")
        cluster_table_rows.append({
            "cluster_id": int(cid), "n_events": int(n_events),
            "n_microexons": int(a),
            "microexon_fraction": float(a / max(n_events, 1)),
            "microexon_fisher_OR_vs_other_regulated": float(odds) if odds == odds else None,
            "microexon_fisher_p_vs_other_regulated":  float(pval) if pval == pval else None,
        })

    # ---- Step 4: per-cluster, per-region motif enrichment ----
    flank = pd.read_csv(os.path.join(DATA_DIR, "flanking_sequences.csv"))
    pwms  = pd.read_csv(os.path.join(DATA_DIR, "splice_factor_pwms.csv"))
    strand_map = meta_indexed["strand"].astype(str).to_dict()
    lods = {}
    for tf in pwms["tf"].unique():
        pwm_rows = pwms[pwms["tf"] == tf].sort_values("position")
        mat = pwm_rows[["A", "C", "G", "T"]].values
        lods[tf] = ms.pwm_to_log_odds(mat)
    motif_rows = []
    # Background = non-regulated events (sampled to match the largest cluster)
    non_reg_list = [e for e in flank["event_id"].values if e not in all_regulated_idx]
    n_bg_target = max(c["n_events"] for c in cluster_table_rows) if cluster_table_rows else 0
    non_reg_list = non_reg_list[: max(1, int(n_bg_target))]
    for r in cluster_table_rows:
        cid = r["cluster_id"]
        ev = labels[labels == cid].index
        ev_in = [e for e in ev if e in flank["event_id"].values]
        if len(ev_in) < 10:
            continue
        for region in ("upstream", "downstream"):
            fg_hits = ms.scan_event_set(
                ev_in,
                flank,
                lods,
                region=region,
                threshold=5.0,
                strand_by_event=strand_map,
                assume_genomic_flanks=True,
            )
            bg_hits = ms.scan_event_set(
                non_reg_list,
                flank,
                lods,
                region=region,
                threshold=5.0,
                strand_by_event=strand_map,
                assume_genomic_flanks=True,
            )
            for tf in lods.keys():
                a = int(fg_hits[tf].sum())
                b = int(len(fg_hits) - a)
                c_ = int(bg_hits[tf].sum())
                d_ = int(len(bg_hits) - c_)
                try:
                    odds, pval = diff.fishers_exact_2x2(a, b, c_, d_)
                except Exception:
                    odds, pval = float("nan"), float("nan")
                motif_rows.append({
                    "cluster_id": int(cid), "tf": tf, "region": region,
                    "n_hits_cluster": a, "n_hits_background": c_,
                    "n_cluster_events": int(len(fg_hits)),
                    "n_background_events": int(len(bg_hits)),
                    "odds_ratio": float(odds) if odds == odds else None,
                    "fisher_p":   float(pval) if pval == pval else None,
                })

    # ===== FIG 1: adjacent-stage volcanoes =====
    fig, axes = plt.subplots(1, 3, figsize=(13, 4), sharey=True)
    for i, (a, b) in enumerate(pairs):
        key = f"{a}->{b}"
        obs = per_pair_dpsi[key]
        pvals = per_pair_p[key]
        sig = per_pair_reg[key]
        nl10 = -np.log10(np.clip(pvals, 1e-6, 1.0))
        ax = axes[i]
        ax.scatter(obs[~sig], nl10[~sig], s=2, color="#888888", alpha=0.35)
        ax.scatter(obs[sig], nl10[sig], s=3, color="#cc4f4f", alpha=0.65)
        ax.axhline(-np.log10(0.05), ls="--", color="#444444", lw=0.6)
        ax.axvline(0.0, ls=":", color="#444444", lw=0.5)
        ax.set_title(f"{a} -> {b}")
        ax.set_xlabel("ΔPSI")
    axes[0].set_ylabel("-log10 empirical p-value")
    fig.suptitle("Adjacent-stage differential splicing volcano panels")
    fig.tight_layout()
    fig.savefig(os.path.join(OUTDIR, "fig1_adjacent_stage_volcanoes.png"), dpi=140)
    plt.close(fig)

    # ===== FIG 5: density-cluster mean-PSI trajectories =====
    fig, ax = plt.subplots(figsize=(7, 5))
    x = [0, 1, 3, 4]
    for r in cluster_table_rows:
        cid = r["cluster_id"]
        ev = labels[labels == cid].index
        if len(ev) < 3:
            continue
        traj = mean_psi.reindex(ev)[["Day_0", "Day_1", "Day_3", "Day_4"]]
        mean_curve = traj.mean(axis=0)
        ax.plot(x, mean_curve.values, "o-", lw=2,
                label=f"cluster {cid} (n={r['n_events']}, microexons={r['n_microexons']})")
    ax.set_xticks(x)
    ax.set_xticklabels(["Day 0", "Day 1", "Day 3", "Day 4"])
    ax.set_ylabel("Mean PSI")
    ax.set_title(f"{cluster_method} cluster mean-PSI trajectories (bundle reproduction)")
    ax.grid(True, alpha=0.3)
    ax.legend(loc="best", fontsize=8)
    fig.tight_layout()
    fig.savefig(os.path.join(OUTDIR, "fig5_cluster_trajectories.png"), dpi=140)
    plt.close(fig)

    # ===== FIG 6: per-cluster motif enrichment heat-map (log2 OR) =====
    if motif_rows:
        df_motif = pd.DataFrame(motif_rows)
        # Pivot to (cluster, tf+region)
        df_motif["tf_region"] = df_motif["tf"] + "_" + df_motif["region"]
        # Log2 OR (clip extremes for visualisation)
        df_motif["log2_OR"] = np.log2(
            df_motif["odds_ratio"].replace([np.inf, -np.inf], np.nan).fillna(1.0).clip(0.1, 10))
        heat = df_motif.pivot_table(index="cluster_id", columns="tf_region",
                                     values="log2_OR", aggfunc="mean")
        fig, ax = plt.subplots(figsize=(9, max(3, 0.4 * heat.shape[0] + 2)))
        im = ax.imshow(heat.values, aspect="auto", cmap="RdBu_r",
                       vmin=-1.5, vmax=1.5)
        ax.set_xticks(range(heat.shape[1])); ax.set_xticklabels(heat.columns, rotation=45, ha="right")
        ax.set_yticks(range(heat.shape[0])); ax.set_yticklabels([f"cluster {c}" for c in heat.index])
        ax.set_title("Per-cluster motif enrichment (log2 Fisher OR vs non-regulated background)")
        plt.colorbar(im, ax=ax, label="log2 OR")
        fig.tight_layout()
        fig.savefig(os.path.join(OUTDIR, "fig6_motif_enrichment_per_cluster.png"), dpi=140)
        plt.close(fig)

    # ===== FIG 7: per-cluster microexon fraction =====
    if cluster_table_rows:
        fig, ax = plt.subplots(figsize=(7, 4))
        cids = [r["cluster_id"] for r in cluster_table_rows]
        fracs = [r["microexon_fraction"] * 100 for r in cluster_table_rows]
        ax.bar([str(c) for c in cids], fracs,
               color=["#cc4f4f" if f > 5 else "#4f95cc" for f in fracs])
        ax.set_xlabel("Cluster id")
        ax.set_ylabel("Microexon fraction (%)")
        ax.set_title("Per-cluster microexon fraction (red bars = microexon-enriched)")
        ax.grid(True, axis="y", alpha=0.3)
        fig.tight_layout()
        fig.savefig(os.path.join(OUTDIR, "fig7_microexon_fraction_per_cluster.png"), dpi=140)
        plt.close(fig)

    # NOTE: The reproducer intentionally writes ONLY the four PNG figures —
    # it does NOT save per-event tables or JSON summaries to artifacts/. The
    # benchmark task expects the model to compute regulated-event counts,
    # cluster summaries, and motif odds ratios itself from the released
    # data + tools; persisting those numbers as a bundled artifact would
    # leak the expected outputs.
    print("Figures regenerated. (Numeric counts intentionally not printed; "
          "those are the analysis outputs the benchmark task expects the "
          "model to compute from the released data + tools.)")


if __name__ == "__main__":
    main()

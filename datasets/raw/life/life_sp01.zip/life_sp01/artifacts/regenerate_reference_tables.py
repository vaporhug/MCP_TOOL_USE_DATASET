from __future__ import annotations

import json
import os
import sys

import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))

import differential as diff
import event_classification as ec
import motif_scan as ms
import normalization as norm


def main() -> None:
    data_dir = os.path.join(ROOT, "input_data", "data")
    out_dir = os.path.join(ROOT, "artifacts")

    psi = pd.read_csv(os.path.join(data_dir, "psi_matrix.csv"), index_col=0)
    meta = pd.read_csv(os.path.join(data_dir, "event_metadata.csv")).set_index("event_id")
    flank = pd.read_csv(os.path.join(data_dir, "flanking_sequences.csv"))
    pwm = pd.read_csv(os.path.join(data_dir, "splice_factor_pwms.csv"))

    cols = list(psi.columns)
    conds = {f"Day_{d}": [c for c in cols if f"Day_{d}" in c] for d in (0, 1, 3, 4)}
    pairs = [("Day_0", "Day_1"), ("Day_1", "Day_3"), ("Day_3", "Day_4")]

    null = np.abs(norm.between_replicate_dpsi(psi, conds))
    reg_any = np.zeros(len(psi), dtype=bool)
    reg_rows = []

    for a, b in pairs:
        obs = (psi[conds[b]].mean(axis=1) - psi[conds[a]].mean(axis=1)).values
        p = diff.empirical_pvalue(obs, null)
        m = (p < 0.05) & (np.abs(obs) >= 0.0)
        reg_any |= m
        reg_rows.append(
            {
                "comparison": f"{a}->{b}",
                "regulated_count": int(m.sum()),
                "median_abs_dpsi": float(np.median(np.abs(obs[m]))) if m.sum() else None,
            }
        )

    total = len(psi)
    reg_union = int(reg_any.sum())
    reg_rows.append(
        {
            "comparison": "UNION",
            "regulated_count": reg_union,
            "median_abs_dpsi": None,
        }
    )
    pd.DataFrame(reg_rows).to_csv(
        os.path.join(out_dir, "table_regulated_counts.csv"), index=False
    )

    mean_psi = norm.per_condition_mean(psi, conds).reindex(psi.index)
    seed = pd.DataFrame(
        {"pvalue": np.where(reg_any, 1e-6, 1.0), "dpsi": np.where(reg_any, 0.10, 0.0)},
        index=psi.index,
    )
    labels = ec.density_cluster_psi_trajectories(
        seed,
        mean_psi,
        pvalue_thresh=0.05,
        dpsi_thresh=0.0,
        eps=0.15,
        min_samples=15,
    )

    is_micro = (
        (pd.to_numeric(meta["cassette_length"], errors="coerce") > 0)
        & (pd.to_numeric(meta["cassette_length"], errors="coerce") < 28)
    )

    rows = []
    for cid in sorted([c for c in labels.unique() if c >= 0]):
        ev = labels[labels == cid].index
        oth = labels[(labels >= 0) & (labels != cid)].index
        a = int(is_micro.reindex(ev).fillna(False).sum())
        b = int(len(ev) - a)
        c = int(is_micro.reindex(oth).fillna(False).sum())
        d = int(len(oth) - c)
        odds, pval = diff.fishers_exact_2x2(a, b, c, d)
        traj = mean_psi.reindex(ev)[["Day_0", "Day_1", "Day_3", "Day_4"]].mean(axis=0)
        rows.append(
            {
                "cluster_id": int(cid),
                "n_events": int(len(ev)),
                "n_microexons": int(a),
                "microexon_fraction": float(a / max(len(ev), 1)),
                "microexon_fisher_or_vs_other_regulated": float(odds),
                "microexon_fisher_p_vs_other_regulated": float(pval),
                "mean_psi_day0": float(traj["Day_0"]),
                "mean_psi_day1": float(traj["Day_1"]),
                "mean_psi_day3": float(traj["Day_3"]),
                "mean_psi_day4": float(traj["Day_4"]),
            }
        )
    cluster_df = pd.DataFrame(rows).sort_values("cluster_id")
    cluster_df.to_csv(os.path.join(out_dir, "table_cluster_summary.csv"), index=False)

    lods = {}
    for tf in pwm["tf"].unique():
        sub = pwm[pwm["tf"] == tf].sort_values("position")
        lods[tf] = ms.pwm_to_log_odds(sub[["A", "C", "G", "T"]].values)

    flank_set = set(flank["event_id"].values)
    nonreg = [e for e in flank["event_id"].values if e not in set(psi.index[reg_any])]
    nonreg = nonreg[: max(1, int(cluster_df["n_events"].max()))]

    motif_rows = []
    for cid in cluster_df["cluster_id"].tolist():
        ev = [e for e in labels[labels == cid].index if e in flank_set]
        if len(ev) < 10:
            continue
        for region in ("upstream", "downstream"):
            fg = ms.scan_event_set(ev, flank, lods, region=region, threshold=5.0)
            bg = ms.scan_event_set(nonreg, flank, lods, region=region, threshold=5.0)
            enr = ms.motif_enrichment(fg, bg).reset_index()
            if len(enr) == 0:
                continue
            top = enr.iloc[0]
            motif_rows.append(
                {
                    "cluster_id": int(cid),
                    "region": region,
                    "top_tf_by_pvalue": top["tf"],
                    "odds_ratio": float(top["odds_ratio"]),
                    "pvalue": float(top["pvalue"]),
                    "fg_hit_rate": float(top["fg_hit_rate"]),
                    "bg_hit_rate": float(top["bg_hit_rate"]),
                }
            )

    pd.DataFrame(motif_rows).to_csv(
        os.path.join(out_dir, "table_motif_top_hits.csv"), index=False
    )

    with open(os.path.join(out_dir, "reference_config.json"), "w", encoding="utf-8") as f:
        json.dump(
            {
                "analysis_scope": {
                    "event_universe": "Bundled SE-only subset",
                    "total_events": int(total),
                    "timepoints": [0, 1, 3, 4],
                    "replicates_per_timepoint": 3,
                },
                "differential_calling": {
                    "null_model": "between_replicate_dpsi (flattened absolute null from all stages)",
                    "empirical_pvalue_function": "differential.empirical_pvalue",
                    "adjacent_pairs": ["Day_0->Day_1", "Day_1->Day_3", "Day_3->Day_4"],
                    "pvalue_threshold": 0.05,
                    "abs_dpsi_threshold": 0.0,
                    "regulated_union_rule": "event is regulated if significant in at least one adjacent-stage pair",
                },
                "clustering": {
                    "method": "DBSCAN-numpy",
                    "function": "density_cluster_psi_trajectories",
                    "metric": "euclidean",
                    "eps": 0.15,
                    "min_samples": 15,
                    "regulated_events_only": True,
                },
                "microexon_definition": {
                    "cassette_length_lt_nt": 28,
                },
                "motif_enrichment": {
                    "scan_function": "motif_scan.scan_event_set",
                    "test_function": "differential.fishers_exact_2x2",
                    "regions": ["upstream", "downstream"],
                    "hit_threshold_logodds": 5.0,
                    "background": "non-regulated events truncated to largest cluster size",
                },
                "reported_reference_counts": {
                    "regulated_union": int(reg_union),
                },
            },
            f,
            ensure_ascii=False,
            indent=2,
        )


if __name__ == "__main__":
    main()

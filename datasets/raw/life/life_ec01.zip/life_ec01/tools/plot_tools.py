"""Plotting primitives for ecological diversity analysis.

Each function produces a single publication-quality figure saved to disk
and returns the file path."""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import os


def plot_richness_latitude(latitudes, richness_values, time_labels=None,
                           output_path="artifacts/richness_latitude.png"):
    """Plot species richness as a function of latitude, optionally
    coloured by time period.

    Parameters
    ----------
    latitudes : list of float
    richness_values : list of float
    time_labels : list of str or None
        If provided, colour points by time period.
    output_path : str

    Returns
    -------
    str : path to saved figure.
    """
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    fig, ax = plt.subplots(figsize=(6, 8))
    if time_labels is not None:
        unique_times = sorted(set(time_labels))
        cmap = plt.cm.get_cmap("RdYlBu_r", len(unique_times))
        for i, t in enumerate(unique_times):
            mask = [tl == t for tl in time_labels]
            lat_sub = [la for la, m in zip(latitudes, mask) if m]
            rich_sub = [r for r, m in zip(richness_values, mask) if m]
            ax.scatter(rich_sub, lat_sub, c=[cmap(i)], s=15, alpha=0.6, label=t)
        ax.legend(title="Time interval", fontsize=8)
    else:
        ax.scatter(richness_values, latitudes, s=15, alpha=0.6)
    ax.set_xlabel("Species richness")
    ax.set_ylabel("Latitude")
    ax.set_title("Species richness across latitude")
    plt.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return output_path


def plot_dissimilarity_timeseries(years, dissimilarity, ci_lower=None,
                                  ci_upper=None, title="",
                                  output_path="artifacts/dissimilarity_ts.png"):
    """Plot temporal beta diversity (dissimilarity) over time with optional
    confidence bands.

    Parameters
    ----------
    years : list of int/float
    dissimilarity : list of float
    ci_lower, ci_upper : list of float or None
    title : str
    output_path : str

    Returns
    -------
    str : path to saved figure.
    """
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(years, dissimilarity, "k-", linewidth=1.5)
    if ci_lower is not None and ci_upper is not None:
        ax.fill_between(years, ci_lower, ci_upper, alpha=0.2, color="steelblue")
    ax.set_xlabel("Year")
    ax.set_ylabel("Reef fish dissimilarity (β)")
    ax.set_title(title or "Temporal species dissimilarity")
    plt.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return output_path


def plot_simper_bars(group_names, positive_vals, negative_vals,
                     output_path="artifacts/simper_bars.png"):
    """Plot SIMPER contribution bar chart showing positive and negative
    contributions to community dissimilarity by functional group.

    Parameters
    ----------
    group_names : list of str
    positive_vals : list of float
        Positive contributions (species increased).
    negative_vals : list of float
        Negative contributions (species decreased, as negative numbers).
    output_path : str

    Returns
    -------
    str : path to saved figure.
    """
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    fig, ax = plt.subplots(figsize=(8, 5))
    y_pos = range(len(group_names))
    ax.barh(y_pos, positive_vals, color="lightblue", label="Positive (increased)")
    ax.barh(y_pos, negative_vals, color="darkblue", label="Negative (decreased)")
    ax.set_yticks(y_pos)
    ax.set_yticklabels(group_names)
    ax.set_xlabel("Relative contribution (%)")
    ax.set_title("Functional group contributions to community dissimilarity")
    ax.legend(fontsize=8)
    ax.axvline(x=0, color="black", linewidth=0.5)
    plt.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return output_path


def plot_nmds_ordination(coordinates, group_labels=None, vectors=None,
                         vector_labels=None, stress=None,
                         output_path="artifacts/nmds_ordination.png"):
    """Plot nMDS ordination with optional group ellipses and species/env
    vectors.

    Parameters
    ----------
    coordinates : np.ndarray
        n x 2 ordination coordinates.
    group_labels : array-like or None
    vectors : list of [v1, v2] or None
        Arrow vectors.
    vector_labels : list of str or None
    stress : float or None
    output_path : str

    Returns
    -------
    str : path to saved figure.
    """
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    fig, ax = plt.subplots(figsize=(7, 6))

    if group_labels is not None:
        unique_groups = sorted(set(group_labels))
        cmap = plt.cm.get_cmap("Set2", len(unique_groups))
        for i, g in enumerate(unique_groups):
            mask = [gl == g for gl in group_labels]
            pts = coordinates[mask]
            ax.scatter(pts[:, 0], pts[:, 1], c=[cmap(i)], s=30, alpha=0.6, label=g)
            # Draw ellipse
            if len(pts) > 2:
                from matplotlib.patches import Ellipse
                mean = pts.mean(axis=0)
                cov = np.cov(pts.T)
                eigenvals, eigenvecs = np.linalg.eigh(cov)
                angle = np.degrees(np.arctan2(eigenvecs[1, 1], eigenvecs[0, 1]))
                width, height = 2 * 1.96 * np.sqrt(eigenvals)
                ell = Ellipse(xy=mean, width=width, height=height, angle=angle,
                              fill=False, color=cmap(i), linewidth=1.5, linestyle="--")
                ax.add_patch(ell)
        ax.legend(fontsize=8)
    else:
        ax.scatter(coordinates[:, 0], coordinates[:, 1], s=30, alpha=0.6)

    if vectors is not None and vector_labels is not None:
        scale = max(np.abs(coordinates).max(), 0.1) * 0.8
        for vec, lab in zip(vectors, vector_labels):
            ax.annotate("", xy=(vec[0] * scale, vec[1] * scale), xytext=(0, 0),
                         arrowprops=dict(arrowstyle="->", color="gray"))
            ax.text(vec[0] * scale * 1.1, vec[1] * scale * 1.1, lab,
                    fontsize=7, color="gray")

    if stress is not None:
        ax.text(0.02, 0.98, f"stress = {stress:.3f}",
                transform=ax.transAxes, fontsize=9, verticalalignment="top")

    ax.set_xlabel("nMDS1")
    ax.set_ylabel("nMDS2")
    ax.set_title("Non-metric multidimensional scaling")
    plt.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return output_path


def plot_coral_cover_timeseries(years, cover_mean, ci_lower=None,
                                ci_upper=None,
                                output_path="artifacts/coral_cover_ts.png"):
    """Plot long-term coral cover trend with confidence bands.

    Parameters
    ----------
    years : list
    cover_mean : list of float
    ci_lower, ci_upper : list of float or None
    output_path : str

    Returns
    -------
    str : path to saved figure.
    """
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(years, cover_mean, "k-", linewidth=1.5)
    if ci_lower is not None and ci_upper is not None:
        ax.fill_between(years, ci_lower, ci_upper, alpha=0.2, color="steelblue")
    ax.set_xlabel("Year")
    ax.set_ylabel("Coral cover (%)")
    ax.set_title("Long-term coral cover changes")
    plt.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return output_path


def plot_scatter_regression(x, y, xlabel="", ylabel="", title="",
                            output_path="artifacts/scatter_regression.png"):
    """Scatter plot with linear regression line.

    Parameters
    ----------
    x, y : array-like
    xlabel, ylabel, title : str
    output_path : str

    Returns
    -------
    str : path to saved figure.
    """
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    mask = ~(np.isnan(x) | np.isnan(y))
    x, y = x[mask], y[mask]

    fig, ax = plt.subplots(figsize=(7, 5))
    ax.scatter(x, y, s=15, alpha=0.4, color="steelblue")

    # Regression line
    if len(x) > 2:
        slope, intercept, r, p, se = stats.linregress(x, y)
        x_fit = np.linspace(x.min(), x.max(), 100)
        ax.plot(x_fit, intercept + slope * x_fit, "k-", linewidth=1.5)
        ax.text(0.02, 0.98, f"slope={slope:.4f}, p={p:.4f}",
                transform=ax.transAxes, fontsize=9, verticalalignment="top")
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    plt.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return output_path


def plot_effect_sizes(labels, means, ci_lowers, ci_uppers,
                      xlabel="Effect size",
                      output_path="artifacts/effect_sizes.png"):
    """Forest plot of effect sizes with confidence intervals.

    Parameters
    ----------
    labels : list of str
    means : list of float
    ci_lowers, ci_uppers : list of float
    xlabel : str
    output_path : str

    Returns
    -------
    str : path to saved figure.
    """
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    fig, ax = plt.subplots(figsize=(6, max(3, 0.5 * len(labels))))
    y_pos = range(len(labels))
    xerr = [
        [m - lo for m, lo in zip(means, ci_lowers)],
        [hi - m for m, hi in zip(means, ci_uppers)],
    ]
    ax.errorbar(means, y_pos, xerr=xerr, fmt="o", color="steelblue",
                capsize=3, markersize=5)
    ax.set_yticks(y_pos)
    ax.set_yticklabels(labels)
    ax.axvline(x=0, color="black", linewidth=0.5, linestyle="--")
    ax.set_xlabel(xlabel)
    ax.set_title("Effect sizes with 95% CI")
    plt.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return output_path


# Import scipy stats for plot_scatter_regression
from scipy import stats

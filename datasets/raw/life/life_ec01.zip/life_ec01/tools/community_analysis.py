"""Community composition analysis primitives: SIMPER, PERMANOVA, ordination
(NMDS, PCA), and trophic/functional group contribution analysis.

These tools allow the agent to characterise community-level changes
across time and space in reef monitoring data."""
import numpy as np
from scipy.spatial.distance import pdist, squareform
from scipy import stats


def simper_contribution(abundances_a, abundances_b, species_labels):
    """Similarity Percentage (SIMPER) analysis quantifying each species'
    contribution to Bray-Curtis dissimilarity between two groups.

    Parameters
    ----------
    abundances_a : np.ndarray
        Mean abundance vector for group A (one value per species).
    abundances_b : np.ndarray
        Mean abundance vector for group B.
    species_labels : list of str

    Returns
    -------
    list of dict with keys 'species', 'contribution', 'direction',
    'mean_a', 'mean_b', sorted by absolute contribution descending.
    """
    a = np.asarray(abundances_a, dtype=float)
    b = np.asarray(abundances_b, dtype=float)
    diffs = np.abs(a - b)
    total_diff = diffs.sum()
    results = []
    for i, sp in enumerate(species_labels):
        pct = 100.0 * diffs[i] / total_diff if total_diff > 0 else 0.0
        direction = "increase" if b[i] > a[i] else "decrease"
        results.append({
            "species": sp,
            "contribution": round(pct, 4),
            "direction": direction,
            "mean_a": round(float(a[i]), 4),
            "mean_b": round(float(b[i]), 4),
        })
    results.sort(key=lambda x: x["contribution"], reverse=True)
    return results


def group_simper(abundances_a, abundances_b, species_labels, group_map):
    """Aggregate SIMPER contributions by functional/trophic groups.

    Parameters
    ----------
    abundances_a, abundances_b : np.ndarray
        Mean abundance per species for two periods/groups.
    species_labels : list of str
    group_map : dict
        Mapping from species label to functional group name.

    Returns
    -------
    dict mapping group name -> {'positive': float, 'negative': float, 'net': float}
        where positive = sum of contributions from species that increased,
        negative = sum from species that decreased, net = positive + negative.
    """
    a = np.asarray(abundances_a, dtype=float)
    b = np.asarray(abundances_b, dtype=float)
    total_sum = np.sum(np.abs(a - b))
    if total_sum == 0:
        return {}

    groups = {}
    for i, sp in enumerate(species_labels):
        g = group_map.get(sp, "unknown")
        if g not in groups:
            groups[g] = {"positive": 0.0, "negative": 0.0}
        diff_abs = np.abs(a[i] - b[i])
        pct = 100.0 * diff_abs / total_sum
        if b[i] >= a[i]:
            groups[g]["positive"] += pct
        else:
            groups[g]["negative"] -= pct

    for g in groups:
        groups[g]["net"] = round(groups[g]["positive"] + groups[g]["negative"], 2)
        groups[g]["positive"] = round(groups[g]["positive"], 2)
        groups[g]["negative"] = round(groups[g]["negative"], 2)
    return groups


def permanova(distance_matrix, group_labels, n_permutations=999):
    """Permutational Multivariate Analysis of Variance (PERMANOVA/ADONIS)
    testing whether group centroids differ in multivariate space.

    Parameters
    ----------
    distance_matrix : np.ndarray
        Square distance/dissimilarity matrix (n x n).
    group_labels : array-like
        Group assignment for each of the n samples.
    n_permutations : int

    Returns
    -------
    dict with keys 'F_statistic', 'R2', 'p_value', 'n_groups'.
    """
    labels = np.asarray(group_labels)
    n = len(labels)
    groups = np.unique(labels)
    k = len(groups)

    # Convert distance matrix to squared distances
    D2 = np.asarray(distance_matrix, dtype=float) ** 2

    # Total sum of squares
    ss_total = np.sum(D2) / (2.0 * n)

    # Within-group sum of squares
    ss_within = 0.0
    for g in groups:
        idx = np.where(labels == g)[0]
        ng = len(idx)
        if ng > 1:
            sub = D2[np.ix_(idx, idx)]
            ss_within += np.sum(sub) / (2.0 * ng)

    ss_between = ss_total - ss_within
    f_stat = (ss_between / (k - 1)) / (ss_within / (n - k)) if (n - k) > 0 else 0.0
    r2 = ss_between / ss_total if ss_total > 0 else 0.0

    # Permutation test
    count_ge = 0
    for _ in range(n_permutations):
        perm = np.random.permutation(labels)
        ss_w_perm = 0.0
        for g in groups:
            idx = np.where(perm == g)[0]
            ng = len(idx)
            if ng > 1:
                sub = D2[np.ix_(idx, idx)]
                ss_w_perm += np.sum(sub) / (2.0 * ng)
        ss_b_perm = ss_total - ss_w_perm
        f_perm = (ss_b_perm / (k - 1)) / (ss_w_perm / (n - k)) if (n - k) > 0 else 0.0
        if f_perm >= f_stat:
            count_ge += 1

    p_value = (count_ge + 1) / (n_permutations + 1)

    return {
        "F_statistic": round(f_stat, 4),
        "R2": round(r2, 4),
        "p_value": round(p_value, 4),
        "n_groups": k,
    }


def nmds_ordination(distance_matrix, n_dims=2, max_iter=300, seed=42):
    """Non-metric Multidimensional Scaling (nMDS) ordination.

    Uses iterative majorisation (SMACOF algorithm) to find a low-dimensional
    configuration minimising stress.

    Parameters
    ----------
    distance_matrix : np.ndarray
        Square dissimilarity matrix.
    n_dims : int
        Number of ordination dimensions.
    max_iter : int
    seed : int

    Returns
    -------
    dict with keys 'coordinates' (n x n_dims array), 'stress' (float).
    """
    from sklearn.manifold import MDS

    mds = MDS(
        n_components=n_dims,
        dissimilarity="precomputed",
        metric=False,
        max_iter=max_iter,
        random_state=seed,
        normalized_stress="auto",
    )
    coords = mds.fit_transform(distance_matrix)
    stress = mds.stress_

    return {
        "coordinates": coords,
        "stress": round(float(stress), 6),
    }


def pca_rotation(coordinates):
    """Rotate ordination coordinates using PCA so that axis 1 captures
    maximum variance (standard post-processing for NMDS).

    Parameters
    ----------
    coordinates : np.ndarray
        n x k matrix of ordination coordinates.

    Returns
    -------
    np.ndarray
        Rotated coordinates.
    """
    centered = coordinates - coordinates.mean(axis=0)
    cov = np.cov(centered.T)
    eigenvalues, eigenvectors = np.linalg.eigh(cov)
    # Sort by decreasing eigenvalue
    idx = np.argsort(eigenvalues)[::-1]
    eigenvectors = eigenvectors[:, idx]
    return centered @ eigenvectors


def weighted_group_centroid(coordinates, group_labels):
    """Compute the centroid of each group's ordination coordinates.

    Parameters
    ----------
    coordinates : np.ndarray
        n x k ordination coordinates.
    group_labels : array-like

    Returns
    -------
    dict mapping group label -> centroid (array of length k).
    """
    labels = np.asarray(group_labels)
    centroids = {}
    for g in np.unique(labels):
        mask = labels == g
        centroids[g] = coordinates[mask].mean(axis=0).tolist()
    return centroids


def envfit_vectors(coordinates, env_matrix, env_labels):
    """Fit environmental/species vectors onto ordination space.

    For each environmental variable, compute the correlation with each
    ordination axis to produce arrow vectors (analogous to vegan::envfit).

    Parameters
    ----------
    coordinates : np.ndarray
        n x k ordination coordinates.
    env_matrix : np.ndarray
        n x p environmental/species data matrix.
    env_labels : list of str

    Returns
    -------
    list of dict with keys 'label', 'vector' (list), 'r2'.
    """
    results = []
    for j, label in enumerate(env_labels):
        vals = env_matrix[:, j]
        # Correlation with each axis
        vec = np.array([
            np.corrcoef(coords_col, vals)[0, 1]
            for coords_col in coordinates.T
        ])
        r2 = np.sum(vec ** 2)
        # Normalise to unit length
        norm = np.linalg.norm(vec)
        if norm > 0:
            vec = vec / norm
        results.append({
            "label": label,
            "vector": [round(v, 6) for v in vec],
            "r2": round(float(r2), 6),
        })
    return results

"""Data loading and preprocessing utilities for reef fish and coral
monitoring data stored as multi-sheet Excel source data files."""
import pandas as pd
import numpy as np


def load_excel_sheet(path, sheet_name, header_row=None):
    """Load a specific sheet from an Excel file.

    Parameters
    ----------
    path : str
        Path to the .xlsx file.
    sheet_name : str
        Name of the sheet to read.
    header_row : int or None
        0-indexed row number to use as column headers.
        If None, pandas infers automatically.

    Returns
    -------
    pd.DataFrame
    """
    if header_row is not None:
        return pd.read_excel(path, sheet_name=sheet_name, header=header_row)
    return pd.read_excel(path, sheet_name=sheet_name)


def list_sheets(path):
    """Return a list of sheet names in an Excel file.

    Parameters
    ----------
    path : str

    Returns
    -------
    list of str
    """
    xls = pd.ExcelFile(path)
    return xls.sheet_names


def filter_by_column(df, column, values):
    """Filter a DataFrame to rows where *column* is in *values*.

    Parameters
    ----------
    df : pd.DataFrame
    column : str
    values : list
        Allowed values.

    Returns
    -------
    pd.DataFrame
    """
    return df[df[column].isin(values)].copy()


def group_aggregate(df, group_cols, value_col, agg_func="mean"):
    """Group by one or more columns and aggregate a value column.

    Parameters
    ----------
    df : pd.DataFrame
    group_cols : list of str
    value_col : str
    agg_func : str
        One of 'mean', 'median', 'sum', 'std', 'count', 'min', 'max'.

    Returns
    -------
    pd.DataFrame with group columns and aggregated value.
    """
    return df.groupby(group_cols, as_index=False)[value_col].agg(agg_func)


def pivot_to_matrix(df, index_col, columns_col, values_col, fill_value=0):
    """Pivot a long-format DataFrame to a site-by-species (or similar) matrix.

    Parameters
    ----------
    df : pd.DataFrame
    index_col : str
        Column for matrix rows (e.g. site).
    columns_col : str
        Column for matrix columns (e.g. species).
    values_col : str
        Column containing the values.
    fill_value : numeric
        Value for missing entries.

    Returns
    -------
    pd.DataFrame (matrix form).
    """
    return df.pivot_table(
        index=index_col, columns=columns_col, values=values_col,
        fill_value=fill_value, aggfunc="sum"
    )


def merge_dataframes(df1, df2, on, how="inner"):
    """Merge two DataFrames on shared key column(s).

    Parameters
    ----------
    df1, df2 : pd.DataFrame
    on : str or list of str
    how : str
        'inner', 'left', 'right', or 'outer'.

    Returns
    -------
    pd.DataFrame
    """
    return pd.merge(df1, df2, on=on, how=how)


def compute_rate_of_change(initial_value, final_value, time_elapsed):
    """Compute the annual rate of change between two time points.

    Parameters
    ----------
    initial_value : float
    final_value : float
    time_elapsed : float
        Number of years between measurements.

    Returns
    -------
    float
        (final - initial) / time_elapsed
    """
    if time_elapsed == 0:
        return np.nan
    return (final_value - initial_value) / time_elapsed


def sqrt_transform(df):
    """Apply square-root transformation to all numeric columns.

    Parameters
    ----------
    df : pd.DataFrame

    Returns
    -------
    pd.DataFrame
    """
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    result = df.copy()
    result[numeric_cols] = np.sqrt(result[numeric_cols])
    return result

"""Stub for external database retrieval.

No external databases are required for this task; all data is provided
in the input_data/data/ directory as Excel source data files."""


def get_data_info():
    """Return metadata about the available input data.

    Returns
    -------
    dict with data description.
    """
    return {
        "source": "Source data from González-Barrios et al. (2025) Nature Communications",
        "file": "reef_source_data.xlsx",
        "description": (
            "Multi-sheet Excel workbook containing source data for all main "
            "and supplementary figures. Data from the AIMS Long-Term "
            "Monitoring Program: 92 reefs, 8 latitudinal sectors, "
            "198 reef fish species, 1995-2022."
        ),
    }

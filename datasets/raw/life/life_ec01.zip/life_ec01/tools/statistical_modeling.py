"""Statistical modelling primitives for ecological diversity analysis:
hierarchical GAMs, GLMMs, effect size estimation, and model diagnostics.

These tools support the agent in fitting diversity-environment
relationships and estimating standardised effect sizes."""
import numpy as np
from scipy import stats
from scipy.optimize import minimize


def fit_gam_smooth(x, y, n_knots=4, degree=3):
    """Fit a univariate smoothing spline (thin-plate regression spline
    approximation) to model non-linear relationships.

    Uses scipy's UnivariateSpline as a lightweight GAM substitute.

    Parameters
    ----------
    x : array-like
        Predictor values.
    y : array-like
        Response values.
    n_knots : int
        Number of knots for the spline.
    degree : int
        Spline degree (default cubic).

    Returns
    -------
    dict with keys 'x_pred', 'y_pred', 'residuals', 'deviance_explained'.
    """
    from scipy.interpolate import UnivariateSpline

    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    mask = ~(np.isnan(x) | np.isnan(y))
    x, y = x[mask], y[mask]
    order = np.argsort(x)
    x, y = x[order], y[order]

    spline = UnivariateSpline(x, y, k=min(degree, len(x) - 1), s=len(x))
    y_pred = spline(x)
    residuals = y - y_pred
    ss_res = np.sum(residuals ** 2)
    ss_tot = np.sum((y - y.mean()) ** 2)
    dev_expl = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0

    return {
        "x_pred": x.tolist(),
        "y_pred": y_pred.tolist(),
        "residuals": residuals.tolist(),
        "deviance_explained": round(dev_expl, 4),
    }


def fit_glm_gaussian(X, y):
    """Fit a Gaussian GLM (identity link) using ordinary least squares.

    Parameters
    ----------
    X : np.ndarray
        n x p design matrix (without intercept; added automatically).
    y : array-like
        Response variable.

    Returns
    -------
    dict with keys 'coefficients', 'std_errors', 'p_values', 'r_squared',
    'residuals'.
    """
    X = np.asarray(X, dtype=float)
    y = np.asarray(y, dtype=float)
    if X.ndim == 1:
        X = X.reshape(-1, 1)
    # Add intercept
    X_int = np.column_stack([np.ones(len(y)), X])
    # OLS
    beta, residuals_arr, rank, sv = np.linalg.lstsq(X_int, y, rcond=None)
    y_pred = X_int @ beta
    resid = y - y_pred
    n, p = X_int.shape
    ss_res = np.sum(resid ** 2)
    ss_tot = np.sum((y - y.mean()) ** 2)
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0

    # Standard errors
    if n > p:
        mse = ss_res / (n - p)
        try:
            cov = mse * np.linalg.inv(X_int.T @ X_int)
            se = np.sqrt(np.diag(cov))
        except np.linalg.LinAlgError:
            se = np.full(p, np.nan)
    else:
        se = np.full(p, np.nan)

    t_stats = beta / se
    p_values = 2 * stats.t.sf(np.abs(t_stats), df=max(n - p, 1))

    return {
        "coefficients": [round(float(b), 6) for b in beta],
        "std_errors": [round(float(s), 6) for s in se],
        "p_values": [round(float(pv), 6) for pv in p_values],
        "r_squared": round(float(r2), 4),
        "residuals": resid.tolist(),
    }


def estimate_effect_size(values_by_group, reference_group=None):
    """Estimate standardised effect sizes (mean and 95% CI) for each group
    relative to a reference or overall mean.

    Parameters
    ----------
    values_by_group : dict
        Mapping group label -> array of values.
    reference_group : str or None
        If given, compute effects relative to this group's mean.

    Returns
    -------
    dict mapping group -> {'mean': float, 'ci_lower': float, 'ci_upper': float, 'n': int}
    """
    if reference_group is not None:
        ref_vals = np.asarray(values_by_group[reference_group], dtype=float)
        ref_mean = np.nanmean(ref_vals)
    else:
        all_vals = np.concatenate([np.asarray(v, dtype=float) for v in values_by_group.values()])
        ref_mean = np.nanmean(all_vals)

    results = {}
    for g, vals in values_by_group.items():
        arr = np.asarray(vals, dtype=float)
        arr = arr[~np.isnan(arr)]
        n = len(arr)
        if n == 0:
            continue
        mean_diff = np.mean(arr) - ref_mean
        se = np.std(arr, ddof=1) / np.sqrt(n) if n > 1 else 0.0
        ci_lower = mean_diff - 1.96 * se
        ci_upper = mean_diff + 1.96 * se
        results[g] = {
            "mean": round(float(mean_diff), 4),
            "ci_lower": round(float(ci_lower), 4),
            "ci_upper": round(float(ci_upper), 4),
            "n": n,
        }
    return results


def linear_mixed_model_approx(y, X_fixed, group_ids):
    """Approximate a linear mixed model by fitting OLS within each group
    and averaging coefficients (meta-analytic approach).

    Parameters
    ----------
    y : array-like
        Response variable.
    X_fixed : np.ndarray
        Fixed-effect design matrix (without intercept).
    group_ids : array-like
        Random-effect grouping variable.

    Returns
    -------
    dict with keys 'fixed_effects' (mean coefficients), 'group_effects',
    'overall_r_squared'.
    """
    y = np.asarray(y, dtype=float)
    X_fixed = np.asarray(X_fixed, dtype=float)
    if X_fixed.ndim == 1:
        X_fixed = X_fixed.reshape(-1, 1)
    groups = np.asarray(group_ids)
    unique_groups = np.unique(groups)

    all_betas = []
    group_effects = {}
    for g in unique_groups:
        mask = groups == g
        yg = y[mask]
        Xg = X_fixed[mask]
        if len(yg) < X_fixed.shape[1] + 1:
            continue
        Xg_int = np.column_stack([np.ones(len(yg)), Xg])
        try:
            beta, _, _, _ = np.linalg.lstsq(Xg_int, yg, rcond=None)
            all_betas.append(beta)
            group_effects[str(g)] = [round(float(b), 6) for b in beta]
        except np.linalg.LinAlgError:
            continue

    if all_betas:
        mean_beta = np.mean(all_betas, axis=0)
    else:
        mean_beta = np.zeros(X_fixed.shape[1] + 1)

    # Overall R2
    X_int = np.column_stack([np.ones(len(y)), X_fixed])
    y_pred = X_int @ mean_beta
    ss_res = np.sum((y - y_pred) ** 2)
    ss_tot = np.sum((y - y.mean()) ** 2)
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0

    return {
        "fixed_effects": [round(float(b), 6) for b in mean_beta],
        "group_effects": group_effects,
        "overall_r_squared": round(float(r2), 4),
    }


def bootstrap_ci(data, statistic_func, n_bootstrap=1000, ci=0.95, seed=42):
    """Compute bootstrap confidence interval for a statistic.

    Parameters
    ----------
    data : array-like
    statistic_func : callable
        Function taking an array and returning a scalar.
    n_bootstrap : int
    ci : float
        Confidence level.
    seed : int

    Returns
    -------
    dict with keys 'estimate', 'ci_lower', 'ci_upper'.
    """
    rng = np.random.RandomState(seed)
    data = np.asarray(data, dtype=float)
    obs = statistic_func(data)
    boot_stats = []
    for _ in range(n_bootstrap):
        sample = rng.choice(data, size=len(data), replace=True)
        boot_stats.append(statistic_func(sample))
    boot_stats = np.sort(boot_stats)
    alpha = 1 - ci
    lo = np.percentile(boot_stats, 100 * alpha / 2)
    hi = np.percentile(boot_stats, 100 * (1 - alpha / 2))
    return {
        "estimate": round(float(obs), 6),
        "ci_lower": round(float(lo), 6),
        "ci_upper": round(float(hi), 6),
    }

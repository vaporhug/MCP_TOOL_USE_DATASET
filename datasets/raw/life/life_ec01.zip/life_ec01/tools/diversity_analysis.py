"""Alpha and beta diversity computation primitives for community ecology.

These functions compute diversity indices, dissimilarity metrics, and
their decomposition into turnover and nestedness components. The agent
chains them to analyse temporal and spatial patterns in species
assemblages."""
import numpy as np
from scipy.spatial.distance import pdist, squareform


def species_richness(counts):
    """Count the number of species with abundance > 0.

    Parameters
    ----------
    counts : array-like
        Species abundances (one site/sample).

    Returns
    -------
    int
    """
    arr = np.asarray(counts, dtype=float)
    return int(np.sum(arr > 0))


def shannon_diversity(counts):
    """Shannon-Wiener diversity index H'.

    Parameters
    ----------
    counts : array-like
        Species abundances (one site/sample).

    Returns
    -------
    float
    """
    arr = np.asarray(counts, dtype=float)
    arr = arr[arr > 0]
    if len(arr) == 0:
        return 0.0
    p = arr / arr.sum()
    return -np.sum(p * np.log(p))


def simpson_diversity(counts):
    """Simpson's diversity index (1 - D).

    Parameters
    ----------
    counts : array-like
        Species abundances (one site/sample).

    Returns
    -------
    float
    """
    arr = np.asarray(counts, dtype=float)
    total = arr.sum()
    if total <= 1:
        return 0.0
    p = arr / total
    return 1.0 - np.sum(p ** 2)


def bray_curtis_dissimilarity(x, y):
    """Abundance-based Bray-Curtis dissimilarity between two samples.

    BC_d = sum|x_i - y_i| / sum(x_i + y_i)

    Parameters
    ----------
    x, y : array-like
        Species abundances at two sites/times.

    Returns
    -------
    float
        Value between 0 (identical) and 1 (completely dissimilar).
    """
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    numerator = np.sum(np.abs(x - y))
    denominator = np.sum(x + y)
    if denominator == 0:
        return 0.0
    return numerator / denominator


def bray_curtis_matrix(community_matrix):
    """Compute pairwise Bray-Curtis dissimilarity matrix.

    Parameters
    ----------
    community_matrix : np.ndarray
        Rows = sites/samples, columns = species.

    Returns
    -------
    np.ndarray
        Square dissimilarity matrix.
    """
    n = community_matrix.shape[0]
    dist = np.zeros((n, n))
    for i in range(n):
        for j in range(i + 1, n):
            d = bray_curtis_dissimilarity(community_matrix[i], community_matrix[j])
            dist[i, j] = d
            dist[j, i] = d
    return dist


def sorensen_dissimilarity(x, y):
    """Presence-absence Sorensen dissimilarity between two samples.

    Parameters
    ----------
    x, y : array-like
        Species abundances (converted to presence/absence internally).

    Returns
    -------
    float
    """
    a = np.asarray(x, dtype=float) > 0
    b = np.asarray(y, dtype=float) > 0
    shared = np.sum(a & b)
    total = np.sum(a) + np.sum(b)
    if total == 0:
        return 0.0
    return 1.0 - (2.0 * shared / total)


def beta_diversity_partition(x, y):
    """Partition abundance-based Bray-Curtis dissimilarity into balanced
    variation (turnover) and abundance gradient (nestedness) components
    following Baselga (2013, Methods Ecol. Evol. 4: 552-557).

    Parameters
    ----------
    x, y : array-like
        Species abundances at two sites/times.

    Returns
    -------
    dict with keys 'total', 'balanced_variation', 'abundance_gradient'.
    """
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)

    # Per-species minimum and maximum
    mins = np.minimum(x, y)
    maxs = np.maximum(x, y)

    A = np.sum(mins)          # shared component
    B = np.sum(x) - A         # exclusive to x
    C = np.sum(y) - A         # exclusive to y

    denom = 2 * A + B + C
    if denom == 0:
        return {"total": 0.0, "balanced_variation": 0.0, "abundance_gradient": 0.0}

    # Total Bray-Curtis
    bc_total = (B + C) / denom

    # Balanced variation (turnover component)
    bc_bal = min(B, C) / (A + min(B, C)) if (A + min(B, C)) > 0 else 0.0

    # Abundance gradient (nestedness component)
    bc_gra = bc_total - bc_bal

    return {
        "total": round(bc_total, 6),
        "balanced_variation": round(bc_bal, 6),
        "abundance_gradient": round(bc_gra, 6),
    }


def pairwise_dissimilarity_timeseries(abundance_dict, metric="bray_curtis"):
    """Compute year-to-year (successive) dissimilarity from a dict of
    {year: abundance_vector}.

    Parameters
    ----------
    abundance_dict : dict
        Keys are years (int), values are array-like abundance vectors.
    metric : str
        'bray_curtis' or 'sorensen'.

    Returns
    -------
    list of dict with keys 'year', 'dissimilarity'.
    """
    func = bray_curtis_dissimilarity if metric == "bray_curtis" else sorensen_dissimilarity
    years = sorted(abundance_dict.keys())
    results = []
    for i in range(1, len(years)):
        d = func(abundance_dict[years[i - 1]], abundance_dict[years[i]])
        results.append({"year": years[i], "dissimilarity": round(d, 6)})
    return results


def reference_year_dissimilarity(abundance_dict, reference_year, metric="bray_curtis"):
    """Compute dissimilarity of each year relative to a fixed reference year.

    Parameters
    ----------
    abundance_dict : dict
        Keys are years (int), values are array-like abundance vectors.
    reference_year : int
    metric : str

    Returns
    -------
    list of dict with keys 'year', 'dissimilarity'.
    """
    func = bray_curtis_dissimilarity if metric == "bray_curtis" else sorensen_dissimilarity
    ref = abundance_dict[reference_year]
    results = []
    for yr in sorted(abundance_dict.keys()):
        if yr == reference_year:
            continue
        d = func(ref, abundance_dict[yr])
        results.append({"year": yr, "dissimilarity": round(d, 6)})
    return results

# Tools for Reef Fish Diversity Analysis

## Tool Categories

### data_processing.py
Data loading and preprocessing utilities for multi-sheet Excel source data.
Functions: `load_excel_sheet`, `list_sheets`, `filter_by_column`, `group_aggregate`, `pivot_to_matrix`, `merge_dataframes`, `compute_rate_of_change`, `sqrt_transform`

### diversity_analysis.py
Alpha and beta diversity metrics and their decomposition.
Functions: `species_richness`, `shannon_diversity`, `simpson_diversity`, `bray_curtis_dissimilarity`, `bray_curtis_matrix`, `sorensen_dissimilarity`, `beta_diversity_partition`, `pairwise_dissimilarity_timeseries`, `reference_year_dissimilarity`

### community_analysis.py
Community composition analysis: SIMPER, PERMANOVA, ordination (NMDS), and functional group contributions.
Functions: `simper_contribution`, `group_simper`, `permanova`, `nmds_ordination`, `pca_rotation`, `weighted_group_centroid`, `envfit_vectors`

### statistical_modeling.py
Statistical modelling: GAM smoothers, GLM, effect size estimation, bootstrap CI, and mixed model approximation.
Functions: `fit_gam_smooth`, `fit_glm_gaussian`, `estimate_effect_size`, `linear_mixed_model_approx`, `bootstrap_ci`

### plot_tools.py
Publication-quality plotting functions for ecological diversity analysis.
Functions: `plot_richness_latitude`, `plot_dissimilarity_timeseries`, `plot_simper_bars`, `plot_nmds_ordination`, `plot_coral_cover_timeseries`, `plot_scatter_regression`, `plot_effect_sizes`

### database_retrieval.py
Stub for external database retrieval (not required for this task).
Functions: `get_data_info`

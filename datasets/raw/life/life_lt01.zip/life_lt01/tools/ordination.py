"""Ordination primitives: classical Principal Coordinates Analysis (PCoA)
on a sample x sample dissimilarity matrix.

Implemented from scratch using ``numpy.linalg.eigh`` so no scipy or
scikit-bio dependency is needed at the agent layer.
"""
from __future__ import annotations

from typing import Tuple

import numpy as np
import pandas as pd


def pcoa(distance_matrix: pd.DataFrame,
         n_components: int = 3) -> Tuple[pd.DataFrame, np.ndarray]:
    """Classical (metric) MDS / PCoA via Gower double-centring + eigh.

    Parameters
    ----------
    distance_matrix : pd.DataFrame
        Symmetric ``n x n`` sample-pair dissimilarity matrix with zero
        diagonal (e.g. output of :func:`tools.diversity.bray_curtis_matrix`).
    n_components : int
        Number of principal coordinates to return (default 3).

    Returns
    -------
    coords : pd.DataFrame
        ``n x n_components`` table indexed by sample ID, columns
        ``PC1, PC2, ...``.
    proportion_explained : np.ndarray
        Length ``n_components`` array giving each axis' fraction of total
        positive eigenvalue energy.
    """
    D = distance_matrix.to_numpy(dtype=float)
    n = D.shape[0]
    D2 = D ** 2
    # Gower's double-centring: B = -1/2 * J D^2 J  with J = I - 1/n * 11'
    J = np.eye(n) - np.ones((n, n)) / n
    B = -0.5 * J @ D2 @ J
    # Symmetrize for numerical stability
    B = (B + B.T) / 2
    eigvals, eigvecs = np.linalg.eigh(B)
    # eigh returns ascending; flip to descending
    order = np.argsort(eigvals)[::-1]
    eigvals = eigvals[order]
    eigvecs = eigvecs[:, order]
    # Keep only positive eigenvalues
    pos = eigvals > 0
    eigvals_pos = eigvals[pos]
    eigvecs_pos = eigvecs[:, pos]
    # Coordinates = eigvec * sqrt(eigval)
    coords_full = eigvecs_pos * np.sqrt(eigvals_pos)
    k = min(n_components, coords_full.shape[1])
    coords = coords_full[:, :k]
    cols = [f"PC{i+1}" for i in range(k)]
    df = pd.DataFrame(coords, index=distance_matrix.index, columns=cols)
    total_pos = eigvals_pos.sum()
    if total_pos > 0:
        prop = eigvals_pos[:k] / total_pos
    else:
        prop = np.zeros(k)
    return df, prop


def attach_metadata(coords: pd.DataFrame,
                    meta: pd.DataFrame,
                    cols: Tuple[str, ...] = ("subject", "body_site",
                                             "days_since_start",
                                             "antibiotic_usage")) -> pd.DataFrame:
    """Join PCoA coordinates with selected metadata columns by
    ``sample_id``. Useful for plotting / regression.
    """
    m = meta.set_index("sample_id")[list(cols)]
    out = coords.join(m, how="left")
    out.index.name = "sample_id"
    return out.reset_index()


def procrustes_correlation(coords_a: pd.DataFrame,
                           coords_b: pd.DataFrame,
                           n_components: int = 2) -> float:
    """Pearson correlation between the squared Procrustes-superimposed
    coordinate distances of two ordinations on the same samples.

    Returns a scalar in [-1, 1]; useful for comparing two beta-diversity
    metrics (e.g. Bray-Curtis vs Aitchison) on the same samples.
    """
    common = sorted(set(coords_a.index) & set(coords_b.index))
    if not common:
        return float("nan")
    A = coords_a.loc[common].iloc[:, :n_components].to_numpy()
    B = coords_b.loc[common].iloc[:, :n_components].to_numpy()
    A = A - A.mean(axis=0)
    B = B - B.mean(axis=0)
    # SVD-based optimal rotation (Procrustes)
    U, _, Vt = np.linalg.svd(B.T @ A)
    R = U @ Vt
    B_rot = B @ R
    da = np.sqrt(((A) ** 2).sum(axis=1))
    db = np.sqrt(((B_rot) ** 2).sum(axis=1))
    if da.std() == 0 or db.std() == 0:
        return float("nan")
    return float(np.corrcoef(da, db)[0, 1])

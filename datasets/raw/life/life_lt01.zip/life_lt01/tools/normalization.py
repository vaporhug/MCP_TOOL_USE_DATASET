"""Normalization primitives for compositional 16S count data.

Implements rarefaction (subsample to a fixed depth without replacement),
total-sum scaling (relative abundance), and centred log-ratio (CLR)
transforms. Pure numpy / pandas; no scipy required (the multinomial
sampling is done with ``numpy.random.Generator.multivariate_hypergeometric``).
"""
from __future__ import annotations

from typing import List, Optional

import numpy as np
import pandas as pd


def rarefy_table(table: pd.DataFrame,
                 depth: int,
                 random_state: int = 0,
                 drop_under_depth: bool = True) -> pd.DataFrame:
    """Subsample each sample column to exactly ``depth`` reads without
    replacement (multivariate hypergeometric draw).

    Parameters
    ----------
    table : pd.DataFrame
        Feature x sample integer count matrix.
    depth : int
        Target read depth per sample.
    random_state : int
        Seed for ``numpy.random.default_rng``.
    drop_under_depth : bool
        If True, samples whose total reads is below ``depth`` are dropped
        from the output. If False, they are kept unchanged.

    Returns
    -------
    pd.DataFrame
        Rarefied count matrix (same row index, possibly fewer columns).
    """
    rng = np.random.default_rng(random_state)
    out_cols = {}
    for s in table.columns:
        col = table[s].to_numpy(dtype=np.int64)
        total = int(col.sum())
        if total < depth:
            if drop_under_depth:
                continue
            else:
                out_cols[s] = col
                continue
        # multivariate_hypergeometric requires colors.sum() >= depth
        sub = rng.multivariate_hypergeometric(col, depth)
        out_cols[s] = sub
    if not out_cols:
        return pd.DataFrame(index=table.index)
    return pd.DataFrame(out_cols, index=table.index, dtype=np.int64)


def total_sum_scaling(table: pd.DataFrame) -> pd.DataFrame:
    """Convert raw counts to relative abundances (each column sums to 1).

    Empty columns (all zero) are returned as zero columns.
    """
    totals = table.sum(axis=0).replace(0, 1.0)
    return table.divide(totals, axis=1)


def add_pseudocount(table: pd.DataFrame, pseudo: float = 0.5) -> pd.DataFrame:
    """Add a small constant to every entry to enable log transforms on
    zero counts. Returns a float DataFrame.
    """
    return table.astype(float) + float(pseudo)


def clr_transform(table: pd.DataFrame, pseudo: float = 0.5) -> pd.DataFrame:
    """Centred log-ratio (CLR) transform of a feature x sample table.

    For each sample column ``x``, returns ``log(x) - mean(log(x))``
    after adding ``pseudo`` to handle zeros. The geometric mean is
    computed in log space (numerically stable).
    """
    augmented = add_pseudocount(table, pseudo)
    log_t = np.log(augmented.to_numpy())
    g = log_t.mean(axis=0, keepdims=True)
    out = log_t - g
    return pd.DataFrame(out, index=table.index, columns=table.columns)


def filter_low_prevalence(table: pd.DataFrame,
                          min_samples: int = 2,
                          min_total_count: int = 10) -> pd.DataFrame:
    """Drop features that appear in fewer than ``min_samples`` samples or
    have a total count below ``min_total_count``. Useful before MDS / CLR
    to remove sequencing-noise features.
    """
    prev = (table > 0).sum(axis=1)
    tot = table.sum(axis=1)
    keep = (prev >= min_samples) & (tot >= min_total_count)
    return table.loc[keep].copy()


def collapse_to_taxon(table: pd.DataFrame,
                      taxonomy: pd.DataFrame,
                      level: str = "phylum") -> pd.DataFrame:
    """Sum feature counts within each taxon at the requested ``level``
    (one of ``kingdom, phylum, class, order, family, genus, species``).

    Requires ``taxonomy`` already split by
    :func:`tools.data_io.parse_taxonomy_to_levels`. Features missing the
    level (empty string) are grouped under ``"<level>__unclassified"``.
    """
    if level not in taxonomy.columns:
        raise ValueError(f"taxonomy missing level column '{level}'")
    tax = taxonomy.set_index("feature_id")[level].fillna("").replace(
        "", f"{level}__unclassified")
    common = table.index.intersection(tax.index)
    sub = table.loc[common].copy()
    grp = tax.loc[common]
    out = sub.groupby(grp).sum()
    out.index.name = level
    return out

"""Baseline-drift / temporal-change primitives.

Detects timepoints whose dissimilarity from a subject-specific baseline
exceeds a multiple of the within-subject background standard deviation,
and computes simple drift-rate diagnostics. On this bundled subset the
"baseline" is purely the day-0 metadata timepoint; the target Caporaso
paper does not treat day-0 as an antibiotic or other intervention, so
these primitives describe ordinary temporal community change, not a
perturbation-recovery experiment.
"""
from __future__ import annotations

from typing import Dict, List, Tuple

import numpy as np
import pandas as pd


def baseline_distance_series(distance_matrix: pd.DataFrame,
                             meta: pd.DataFrame,
                             subject_col: str = "subject",
                             site_col: str = "body_site",
                             time_col: str = "days_since_start",
                             baseline_strategy: str = "first") -> pd.DataFrame:
    """For each (subject, body_site) series, compute distance from a
    chosen baseline timepoint to every later timepoint.

    Parameters
    ----------
    baseline_strategy : str
        - ``"first"``: use the earliest timepoint as baseline
        - ``"last"``: use the latest timepoint as baseline (post-recovery)

    Returns DataFrame columns
    ``subject, body_site, day, baseline_day, distance_from_baseline``.
    """
    rows = []
    for keys, sub in meta.groupby([subject_col, site_col]):
        sub = sub.sort_values(time_col).reset_index(drop=True)
        if len(sub) < 2:
            continue
        if baseline_strategy == "first":
            base_idx = 0
        elif baseline_strategy == "last":
            base_idx = len(sub) - 1
        else:
            raise ValueError("baseline_strategy must be 'first' or 'last'")
        base_id = sub.iloc[base_idx]["sample_id"]
        base_day = int(sub.iloc[base_idx][time_col])
        for i in range(len(sub)):
            sid = sub.iloc[i]["sample_id"]
            if sid not in distance_matrix.index or base_id not in distance_matrix.columns:
                continue
            d = float(distance_matrix.loc[sid, base_id])
            rows.append({subject_col: keys[0], site_col: keys[1],
                         "day": int(sub.iloc[i][time_col]),
                         "baseline_day": base_day,
                         "distance_from_baseline": d})
    return pd.DataFrame(rows)


def detect_high_drift_timepoints(adjacent: pd.DataFrame,
                                 z_threshold: float = 1.5) -> pd.DataFrame:
    """Flag adjacent-timepoint distances that exceed
    ``mean + z_threshold * std`` within each (subject, body_site) series.

    These are simply timepoints with unusually large day-to-day community
    change relative to that series' own background variability; on this
    bundled healthy time-series subset they are not tied to any
    intervention.

    ``adjacent`` should be the output of
    :func:`tools.trajectory.adjacent_distances`.

    Returns the same DataFrame plus a boolean ``is_high_drift`` column
    and the per-group mean / std used to flag.
    """
    out = adjacent.copy()
    out["is_high_drift"] = False
    out["group_mean_d"] = np.nan
    out["group_std_d"] = np.nan
    for (subj, site), sub in out.groupby(["subject", "body_site"]):
        m = sub["distance"].mean()
        s = sub["distance"].std(ddof=1) if len(sub) > 1 else 0.0
        thr = m + z_threshold * s
        idx = sub.index
        out.loc[idx, "group_mean_d"] = m
        out.loc[idx, "group_std_d"] = s
        out.loc[idx, "is_high_drift"] = sub["distance"] > thr
    return out


def baseline_drift_rate(distance_from_baseline: pd.DataFrame,
                        subject_col: str = "subject",
                        site_col: str = "body_site",
                        time_col: str = "day") -> pd.DataFrame:
    """Per (subject, body_site) series, fit a linear slope to
    ``distance_from_baseline`` over ``time_col`` (days). A positive slope
    indicates the community is drifting steadily away from its day-0
    baseline; a negative slope indicates it is moving back toward
    baseline. No intervention is implied.

    Returns DataFrame ``subject, body_site, n, slope_per_day,
    intercept, end_distance, mean_distance``.
    """
    rows = []
    for keys, sub in distance_from_baseline.groupby([subject_col, site_col]):
        sub = sub.sort_values(time_col).reset_index(drop=True)
        # exclude the baseline self-distance if present
        sub = sub[sub["day"] != sub["baseline_day"]]
        if len(sub) < 2:
            continue
        x = sub[time_col].to_numpy(dtype=float)
        y = sub["distance_from_baseline"].to_numpy(dtype=float)
        xm, ym = x.mean(), y.mean()
        denom = ((x - xm) ** 2).sum()
        if denom <= 0:
            slope, intercept = float("nan"), float("nan")
        else:
            slope = float(((x - xm) * (y - ym)).sum() / denom)
            intercept = float(ym - slope * xm)
        rows.append({subject_col: keys[0], site_col: keys[1],
                     "n": int(len(sub)),
                     "slope_per_day": slope,
                     "intercept": intercept,
                     "end_distance": float(y[-1]),
                     "mean_distance": float(y.mean())})
    return pd.DataFrame(rows)


def core_microbiome_curve(table: pd.DataFrame,
                          taxonomy: pd.DataFrame,
                          fractions: Tuple[float, ...] = (
                              0.5, 0.6, 0.7, 0.8, 0.9, 1.0)) -> pd.DataFrame:
    """Fraction of features classified as "temporal core" as a function
    of the minimum prevalence threshold.

    For each fraction f in ``fractions``, count features present in at
    least ``ceil(f * n_samples)`` samples, divided by total features
    observed (with prevalence >= 1).

    Returns DataFrame ``min_fraction, min_samples, n_core, n_total,
    core_fraction``.
    """
    n = table.shape[1]
    prev = (table > 0).sum(axis=1)
    total = int((prev >= 1).sum())
    rows = []
    for f in fractions:
        thr = int(np.ceil(f * n))
        n_core = int((prev >= thr).sum())
        rows.append({"min_fraction": float(f),
                     "min_samples": thr,
                     "n_core": n_core,
                     "n_total": total,
                     "core_fraction": (n_core / total) if total > 0 else 0.0})
    return pd.DataFrame(rows)


def baseline_flag_drift_summary(distance_matrix: pd.DataFrame,
                                meta: pd.DataFrame,
                                subject_col: str = "subject",
                                site_col: str = "body_site",
                                time_col: str = "days_since_start",
                                flag_col: str = "antibiotic_usage") -> pd.DataFrame:
    """For each (subject, body_site) series that contains at least one
    day-0 baseline-flagged sample (``meta[flag_col] == 'Yes'``, which on
    this bundled subset only marks the day-0 metadata-baseline sample of
    each subject and is NOT an antibiotic or other intervention in the
    target paper), compute the mean dissimilarity from that flagged
    day-0 sample to all subsequent samples ("drift-from-day-0 summary").

    Returns DataFrame ``subject, body_site, baseline_day, n_post,
    mean_post_distance, max_post_distance``.
    """
    rows = []
    for keys, sub in meta.groupby([subject_col, site_col]):
        sub = sub.sort_values(time_col).reset_index(drop=True)
        flagged = sub[sub[flag_col] == "Yes"]
        if flagged.empty:
            continue
        base_id = flagged.iloc[0]["sample_id"]
        base_day = int(flagged.iloc[0][time_col])
        post = sub[sub[time_col] > base_day]
        ds = []
        for sid in post["sample_id"]:
            if sid in distance_matrix.index and base_id in distance_matrix.columns:
                ds.append(float(distance_matrix.loc[sid, base_id]))
        if not ds:
            continue
        rows.append({subject_col: keys[0], site_col: keys[1],
                     "baseline_day": base_day, "n_post": len(ds),
                     "mean_post_distance": float(np.mean(ds)),
                     "max_post_distance": float(np.max(ds))})
    return pd.DataFrame(rows)

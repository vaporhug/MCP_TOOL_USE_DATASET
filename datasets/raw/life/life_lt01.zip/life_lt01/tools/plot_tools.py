"""Plotting primitives for the longitudinal microbiome task.

All plot functions:
- accept already-computed pandas inputs (no recomputation here),
- return ``{"path": "<absolute path to PNG>"}`` and write the file,
- use only matplotlib (no seaborn / no scipy).
"""
from __future__ import annotations

import os
from typing import Dict, Iterable, Tuple

import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


_DEFAULT_PALETTE = {
    "gut": "#d62728",
    "tongue": "#2ca02c",
    "left palm": "#1f77b4",
    "right palm": "#ff7f0e",
}

_SUBJECT_MARKER = {"subject-1": "o", "subject-2": "s"}


def _ensure_dir(path: str) -> None:
    d = os.path.dirname(os.path.abspath(path))
    os.makedirs(d, exist_ok=True)


def plot_alpha_diversity_vs_time(alpha: pd.DataFrame,
                                 meta: pd.DataFrame,
                                 metric: str,
                                 out_path: str,
                                 title: str = "") -> Dict[str, str]:
    """Line plot of an alpha-diversity metric vs days_since_start, one
    line per (subject, body_site).

    Parameters
    ----------
    alpha : pd.DataFrame
        Indexed by sample_id, must contain ``metric`` column.
    meta : pd.DataFrame
        Per-sample metadata (must include subject, body_site,
        days_since_start, antibiotic_usage).
    metric : str
        Column of ``alpha`` to plot (e.g. ``"shannon"``).
    out_path : str
        Where to write the PNG.
    """
    _ensure_dir(out_path)
    df = meta.copy()
    df = df.merge(alpha[[metric]].rename_axis("sample_id").reset_index(),
                  on="sample_id", how="inner")
    fig, ax = plt.subplots(figsize=(7, 4.5))
    for (subj, site), sub in df.groupby(["subject", "body_site"]):
        sub = sub.sort_values("days_since_start")
        c = _DEFAULT_PALETTE.get(site, "gray")
        m = _SUBJECT_MARKER.get(subj, "x")
        ax.plot(sub["days_since_start"], sub[metric], marker=m,
                color=c, linewidth=1.4,
                label=f"{subj} | {site}")
    # mark antibiotic samples
    ab = df[df["antibiotic_usage"] == "Yes"]
    if not ab.empty:
        ax.scatter(ab["days_since_start"], ab[metric],
                   facecolors="none", edgecolors="black",
                   s=130, linewidths=1.5, label="antibiotic baseline (day 0)")
    ax.set_xlabel("Days since experiment start")
    ax.set_ylabel(metric)
    ax.set_title(title or f"{metric} over time")
    ax.legend(fontsize=7, loc="best", ncol=2)
    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": os.path.abspath(out_path)}


def plot_pcoa_with_time_arrows(coords_meta: pd.DataFrame,
                               proportion_explained,
                               out_path: str,
                               title: str = "PCoA with time-arrow trajectories"
                               ) -> Dict[str, str]:
    """Scatter PC1 vs PC2 colored by body_site, marker shape by subject,
    with arrows joining consecutive timepoints inside each
    (subject, body_site) trajectory.

    ``coords_meta`` must contain columns ``PC1, PC2, subject,
    body_site, days_since_start``.
    """
    _ensure_dir(out_path)
    fig, ax = plt.subplots(figsize=(7, 5.5))
    for (subj, site), sub in coords_meta.groupby(["subject", "body_site"]):
        sub = sub.sort_values("days_since_start")
        c = _DEFAULT_PALETTE.get(site, "gray")
        m = _SUBJECT_MARKER.get(subj, "x")
        ax.scatter(sub["PC1"], sub["PC2"], color=c, marker=m,
                   s=65, edgecolors="black", linewidths=0.4,
                   label=f"{subj} | {site}", zorder=3)
        x = sub["PC1"].to_numpy()
        y = sub["PC2"].to_numpy()
        for i in range(len(sub) - 1):
            ax.annotate("", xy=(x[i + 1], y[i + 1]), xytext=(x[i], y[i]),
                        arrowprops=dict(arrowstyle="->", color=c,
                                        alpha=0.6, lw=1.2),
                        zorder=2)
    ax.set_xlabel(f"PC1 ({proportion_explained[0]*100:.1f}%)")
    ax.set_ylabel(f"PC2 ({proportion_explained[1]*100:.1f}%)")
    ax.set_title(title)
    ax.legend(fontsize=7, loc="best", ncol=2)
    ax.axhline(0, color="gray", linewidth=0.4)
    ax.axvline(0, color="gray", linewidth=0.4)
    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": os.path.abspath(out_path)}


def plot_within_vs_between_distances(long_df: pd.DataFrame,
                                     out_path: str,
                                     group_label: str,
                                     title: str = "") -> Dict[str, str]:
    """Boxplot comparing within-group vs between-group dissimilarities.

    ``long_df`` must contain columns ``distance, comparison`` where
    ``comparison`` is one of {"within", "between"}.
    """
    _ensure_dir(out_path)
    fig, ax = plt.subplots(figsize=(5.0, 4.0))
    data = [long_df.loc[long_df["comparison"] == k, "distance"].values
            for k in ("within", "between")]
    bp = ax.boxplot(data, tick_labels=[f"within {group_label}",
                                       f"between {group_label}"],
                    patch_artist=True, showfliers=False)
    colors = ["#1f77b4", "#d62728"]
    for patch, c in zip(bp["boxes"], colors):
        patch.set_facecolor(c)
        patch.set_alpha(0.55)
    # overlay individual points
    for i, vals in enumerate(data):
        x = np.random.default_rng(0).normal(loc=i + 1, scale=0.05,
                                            size=len(vals))
        ax.scatter(x, vals, alpha=0.45, s=14, color="black")
    ax.set_ylabel("Bray-Curtis dissimilarity")
    ax.set_title(title or f"Within vs between {group_label} dissimilarity")
    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": os.path.abspath(out_path)}


def plot_core_microbiome_curve(core_df: pd.DataFrame,
                               out_path: str,
                               title: str = "Temporal core microbiome"
                               ) -> Dict[str, str]:
    """Plot core_fraction (y) vs min_fraction prevalence threshold (x).
    Expects DataFrame from
    :func:`tools.perturbation.core_microbiome_curve`.
    """
    _ensure_dir(out_path)
    fig, ax = plt.subplots(figsize=(5.5, 4.0))
    ax.plot(core_df["min_fraction"], core_df["core_fraction"],
            marker="o", color="#2ca02c", linewidth=2)
    ax.set_xlabel("Minimum sample prevalence (fraction of samples)")
    ax.set_ylabel("Fraction of features in core")
    ax.set_title(title)
    ax.grid(alpha=0.3)
    for x, y, n in zip(core_df["min_fraction"], core_df["core_fraction"],
                       core_df["n_core"]):
        ax.annotate(f"{n}", (x, y), textcoords="offset points",
                    xytext=(0, 6), ha="center", fontsize=8)
    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": os.path.abspath(out_path)}


def plot_perturbation_response(distance_from_baseline: pd.DataFrame,
                               out_path: str,
                               title: str = "Distance from day-0 baseline"
                               ) -> Dict[str, str]:
    """One sub-line per (subject, body_site) showing how UniFrac /
    Bray-Curtis distance from the day-0 baseline evolves over time.
    Useful for visualising perturbation recovery (or lack thereof).
    """
    _ensure_dir(out_path)
    fig, ax = plt.subplots(figsize=(7, 4.5))
    for (subj, site), sub in distance_from_baseline.groupby(
            ["subject", "body_site"]):
        sub = sub.sort_values("day")
        c = _DEFAULT_PALETTE.get(site, "gray")
        m = _SUBJECT_MARKER.get(subj, "x")
        ax.plot(sub["day"], sub["distance_from_baseline"],
                marker=m, color=c, linewidth=1.4,
                label=f"{subj} | {site}")
    ax.axhline(0, color="black", linewidth=0.5)
    ax.set_xlabel("Days since experiment start")
    ax.set_ylabel("Bray-Curtis distance from baseline")
    ax.set_title(title)
    ax.legend(fontsize=7, loc="best", ncol=2)
    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": os.path.abspath(out_path)}


def plot_per_subject_slope_summary(per_subject_df: pd.DataFrame,
                                   out_path: str,
                                   y_label: str = "slope (per day)",
                                   title: str = "") -> Dict[str, str]:
    """Bar chart of per-subject (or per-group) slope estimates with
    intercepts as text annotations. Expects DataFrame with columns
    ``group, intercept, slope``.
    """
    _ensure_dir(out_path)
    fig, ax = plt.subplots(figsize=(5.0, 3.6))
    x = np.arange(len(per_subject_df))
    bars = ax.bar(x, per_subject_df["slope"], color="#9467bd", alpha=0.8)
    ax.set_xticks(x)
    ax.set_xticklabels(per_subject_df["group"], rotation=20, ha="right")
    ax.axhline(0, color="black", linewidth=0.5)
    ax.set_ylabel(y_label)
    ax.set_title(title or "Per-subject longitudinal slopes")
    for bar, ic in zip(bars, per_subject_df["intercept"]):
        ax.annotate(f"a={ic:.2f}", (bar.get_x() + bar.get_width() / 2,
                                    bar.get_height()),
                    ha="center", va="bottom", fontsize=8)
    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": os.path.abspath(out_path)}

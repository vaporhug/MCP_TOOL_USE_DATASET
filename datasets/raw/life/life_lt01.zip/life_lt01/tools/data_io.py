"""I/O primitives for the longitudinal microbiome time-series task.

Loads the per-feature ASV count matrix, the per-sample metadata
(subject / body_site / days_since_start / antibiotic_usage) and the
Greengenes taxonomy assignments. Pure pandas / numpy; no scipy, no
sklearn, no biom-format dependency at the agent layer.
"""
from __future__ import annotations

from typing import Dict, List, Tuple

import numpy as np
import pandas as pd


def load_feature_table(path: str) -> pd.DataFrame:
    """Load the ASV (feature) x sample integer count matrix.

    Rows are 16S amplicon sequence variant IDs (md5 hex strings) as
    delivered by DADA2; columns are sample IDs (e.g. ``L1S8``).
    Values are raw read counts (non-negative integers).

    Returns
    -------
    pd.DataFrame
        DataFrame indexed by ``feature_id``, columns are sample IDs.
    """
    df = pd.read_csv(path, index_col=0)
    df.index.name = "feature_id"
    df = df.astype(int)
    return df


def load_sample_metadata(path: str) -> pd.DataFrame:
    """Load per-sample metadata.

    Columns
    -------
    sample_id          : matches feature-table column header
    subject            : ``subject-1`` or ``subject-2`` (two donors)
    body_site          : gut / tongue / left palm / right palm
    year, month, day   : calendar collection date
    days_since_start   : non-negative integer time index in days
    antibiotic_usage   : Yes / No (Yes on the day-0 metadata-baseline samples
                         of both subjects only; not interpreted as an
                         antibiotic intervention in the target paper)
    """
    return pd.read_csv(path)


def load_taxonomy(path: str) -> pd.DataFrame:
    """Load Greengenes taxonomy assignments per feature.

    Columns
    -------
    feature_id    : ASV md5 ID matching the feature-table index
    taxonomy      : full lineage string
                    ``k__Bacteria; p__Bacteroidetes; c__Bacteroidia; ...``
    confidence    : naive-Bayes classifier confidence in [0, 1]
    """
    return pd.read_csv(path)


def parse_taxonomy_to_levels(tax_df: pd.DataFrame) -> pd.DataFrame:
    """Split the ``taxonomy`` lineage string into one column per rank.

    Returns a copy of ``tax_df`` augmented with columns
    ``kingdom, phylum, class, order, family, genus, species``.

    Empty-level handling (single source of truth, mirrored downstream by
    ``normalization.collapse_to_level``):

    - A level whose Greengenes prefix is present but the value is empty
      (e.g. ``g__``) yields the empty string ``""``.
    - A level entirely absent from the lineage string (the trailing
      ranks of a short Greengenes label) ALSO yields ``""``.
    - Downstream collapses (``collapse_to_level``) replace empty-string
      values at the requested level with ``"<level>__unclassified"``.
    """
    ranks = ["kingdom", "phylum", "class", "order", "family", "genus", "species"]
    out = tax_df.copy()
    parts = out["taxonomy"].fillna("").str.split(";")
    for i, r in enumerate(ranks):
        out[r] = parts.apply(lambda lst: lst[i].strip() if i < len(lst) else "")
    return out


def align_table_to_metadata(table: pd.DataFrame,
                            meta: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Reorder ``table`` columns to match ``meta`` row order using the
    common ``sample_id`` set, returning ``(table_aligned, meta_aligned)``.

    Useful boilerplate before any group-wise computation: after this
    call ``table.columns[i]`` is the sample described by ``meta.iloc[i]``.
    """
    common = [s for s in meta["sample_id"] if s in table.columns]
    t2 = table[common].copy()
    m2 = meta.set_index("sample_id").loc[common].reset_index()
    return t2, m2


def sample_counts_summary(table: pd.DataFrame) -> pd.Series:
    """Return per-sample total read counts as a pd.Series indexed by
    sample ID, sorted ascending.
    """
    return table.sum(axis=0).sort_values()


def feature_prevalence(table: pd.DataFrame) -> pd.Series:
    """Return the number of samples in which each feature has a non-zero
    count, indexed by feature_id and sorted descending.
    """
    return (table > 0).sum(axis=1).sort_values(ascending=False)


def subset_by_body_site(table: pd.DataFrame, meta: pd.DataFrame,
                        body_site: str) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Select samples from a single body habitat (e.g. ``"gut"``).

    Returns the sub-table (features x site_samples) and the sub-metadata.
    """
    sub = meta[meta["body_site"] == body_site].copy()
    cols = [s for s in sub["sample_id"] if s in table.columns]
    return table[cols].copy(), sub.set_index("sample_id").loc[cols].reset_index()


def list_subjects_and_sites(meta: pd.DataFrame) -> Dict[str, List[str]]:
    """Convenience: return ``{"subjects": [...], "body_sites": [...]}``
    sorted alphabetically.
    """
    return {
        "subjects": sorted(meta["subject"].unique().tolist()),
        "body_sites": sorted(meta["body_site"].unique().tolist()),
    }

"""Alpha and beta diversity primitives.

Implements observed-feature richness, Shannon diversity, Simpson
diversity, Pielou evenness, and Bray-Curtis / Jaccard dissimilarities,
all from a feature x sample count matrix. Pure numpy / pandas; no
scipy.spatial.distance, no scikit-bio.
"""
from __future__ import annotations

from typing import List

import numpy as np
import pandas as pd


# -------------------- alpha diversity --------------------

def observed_features(table: pd.DataFrame) -> pd.Series:
    """Number of distinct features (richness) per sample.
    Returns a Series indexed by sample ID.
    """
    return (table > 0).sum(axis=0).astype(int).rename("observed_features")


def shannon_diversity(table: pd.DataFrame) -> pd.Series:
    """Shannon entropy H = -sum(p_i * log(p_i)) per sample (natural log).

    Zero-count features contribute zero. Returns Series indexed by
    sample ID.
    """
    p = table.divide(table.sum(axis=0).replace(0, 1.0), axis=1)
    arr = p.to_numpy()
    with np.errstate(divide="ignore", invalid="ignore"):
        ln = np.where(arr > 0, np.log(arr), 0.0)
    h = -(arr * ln).sum(axis=0)
    return pd.Series(h, index=table.columns, name="shannon")


def simpson_diversity(table: pd.DataFrame) -> pd.Series:
    """Gini-Simpson index 1 - sum(p_i**2) per sample. Returns Series
    indexed by sample ID.
    """
    p = table.divide(table.sum(axis=0).replace(0, 1.0), axis=1)
    s = 1.0 - (p ** 2).sum(axis=0)
    return pd.Series(s.values, index=table.columns, name="simpson")


def pielou_evenness(table: pd.DataFrame) -> pd.Series:
    """Pielou evenness J = H / log(S) where H is Shannon and S is
    observed richness. Samples with S<=1 return NaN.
    """
    h = shannon_diversity(table)
    s = observed_features(table).astype(float)
    j = h / np.log(s.where(s > 1, np.nan))
    return j.rename("pielou")


def alpha_diversity_table(table: pd.DataFrame) -> pd.DataFrame:
    """Combine richness, Shannon, Simpson and Pielou into one wide
    DataFrame indexed by sample ID.
    """
    return pd.concat([
        observed_features(table),
        shannon_diversity(table),
        simpson_diversity(table),
        pielou_evenness(table),
    ], axis=1)


# -------------------- beta diversity --------------------

def bray_curtis_matrix(table: pd.DataFrame) -> pd.DataFrame:
    """Bray-Curtis dissimilarity between every pair of samples.

    BC(i, j) = sum |x_i - x_j| / sum (x_i + x_j). Computed on raw
    counts (or any non-negative abundance vectors). Returns symmetric
    DataFrame indexed and columned by sample ID with zero diagonal.
    """
    X = table.to_numpy(dtype=float).T  # samples x features
    n = X.shape[0]
    out = np.zeros((n, n))
    sums = X.sum(axis=1)
    for i in range(n):
        for j in range(i + 1, n):
            num = np.abs(X[i] - X[j]).sum()
            den = sums[i] + sums[j]
            out[i, j] = out[j, i] = num / den if den > 0 else 0.0
    return pd.DataFrame(out, index=table.columns, columns=table.columns)


def jaccard_matrix(table: pd.DataFrame) -> pd.DataFrame:
    """Binary Jaccard dissimilarity 1 - |A & B| / |A | B| between every
    pair of samples (presence/absence on features).
    """
    P = (table.to_numpy() > 0).astype(int).T  # samples x features (binary)
    n = P.shape[0]
    out = np.zeros((n, n))
    for i in range(n):
        for j in range(i + 1, n):
            inter = int(np.logical_and(P[i], P[j]).sum())
            union = int(np.logical_or(P[i], P[j]).sum())
            out[i, j] = out[j, i] = 1.0 - inter / union if union > 0 else 0.0
    return pd.DataFrame(out, index=table.columns, columns=table.columns)


def aitchison_distance_matrix(clr_table: pd.DataFrame) -> pd.DataFrame:
    """Aitchison distance = Euclidean distance between CLR-transformed
    sample vectors. ``clr_table`` should be the output of
    :func:`tools.normalization.clr_transform`.
    """
    X = clr_table.to_numpy().T  # samples x features
    n = X.shape[0]
    out = np.zeros((n, n))
    for i in range(n):
        for j in range(i + 1, n):
            d = float(np.sqrt(((X[i] - X[j]) ** 2).sum()))
            out[i, j] = out[j, i] = d
    return pd.DataFrame(out, index=clr_table.columns, columns=clr_table.columns)


def within_vs_between_distances(distance_matrix: pd.DataFrame,
                                meta: pd.DataFrame,
                                group_col: str) -> pd.DataFrame:
    """Split off-diagonal sample-pair distances into "within group" and
    "between group" sets according to ``meta[group_col]``.

    Returns long-format DataFrame with columns ``sample_a, sample_b,
    distance, comparison`` where ``comparison in {"within", "between"}``.
    """
    m = meta.set_index("sample_id")[group_col]
    samples = [s for s in distance_matrix.index if s in m.index]
    rows = []
    for i, sa in enumerate(samples):
        for sb in samples[i + 1:]:
            d = float(distance_matrix.loc[sa, sb])
            cmp = "within" if m.loc[sa] == m.loc[sb] else "between"
            rows.append({"sample_a": sa, "sample_b": sb,
                         "distance": d, "comparison": cmp})
    return pd.DataFrame(rows)

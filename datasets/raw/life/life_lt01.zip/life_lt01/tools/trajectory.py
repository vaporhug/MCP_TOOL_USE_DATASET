"""Subject-specific longitudinal trajectory primitives.

- Per-subject random-effects linear model (intercept + slope) fit to a
  scalar response (e.g. Shannon diversity, PC1 coordinate) over time.
- Adjacent-timepoint dissimilarity computation for measuring temporal
  rate-of-change.
- Pairwise correlation of two longitudinal series across subjects (e.g.
  left-palm vs right-palm UniFrac change).

All implemented with pure numpy / pandas; no scipy.optimize or statsmodels.
"""
from __future__ import annotations

from typing import Dict, List, Tuple

import numpy as np
import pandas as pd


def _ols_intercept_slope(x: np.ndarray, y: np.ndarray) -> Tuple[float, float]:
    """Closed-form OLS fit returning (intercept, slope) for y = a + b*x.
    Returns (nan, nan) if x has zero variance or fewer than 2 points.
    """
    if len(x) < 2:
        return float("nan"), float("nan")
    xm, ym = x.mean(), y.mean()
    denom = ((x - xm) ** 2).sum()
    if denom <= 0:
        return float("nan"), float("nan")
    b = ((x - xm) * (y - ym)).sum() / denom
    a = ym - b * xm
    return float(a), float(b)


def per_subject_intercept_slope(values: pd.Series,
                                meta: pd.DataFrame,
                                time_col: str = "days_since_start",
                                group_col: str = "subject") -> pd.DataFrame:
    """Fit a separate intercept + slope linear model for each level of
    ``meta[group_col]`` against ``meta[time_col]`` for the scalar
    response in ``values`` (indexed by sample_id).

    Returns a DataFrame with columns
    ``group, n, intercept, slope, mean_value, std_value``.
    """
    m = meta.set_index("sample_id")
    common = [s for s in values.index if s in m.index]
    df = pd.DataFrame({
        "value": values.loc[common].astype(float).values,
        "time": m.loc[common, time_col].astype(float).values,
        "group": m.loc[common, group_col].values,
    })
    rows = []
    for g, sub in df.groupby("group"):
        a, b = _ols_intercept_slope(sub["time"].to_numpy(),
                                    sub["value"].to_numpy())
        rows.append({"group": g, "n": int(len(sub)),
                     "intercept": a, "slope": b,
                     "mean_value": float(sub["value"].mean()),
                     "std_value": float(sub["value"].std(ddof=1)
                                        if len(sub) > 1 else float("nan"))})
    return pd.DataFrame(rows).sort_values("group").reset_index(drop=True)


def random_effects_pooled_slope(values: pd.Series,
                                meta: pd.DataFrame,
                                time_col: str = "days_since_start",
                                group_col: str = "subject") -> Dict[str, float]:
    """Random-intercept random-slope summary computed from per-group OLS
    slopes (no REML iteration; a simple pooled estimate via the normal
    means model).

    Returns a dict with keys ``mean_intercept, mean_slope, sd_intercept,
    sd_slope, n_groups``. SD's are sample standard deviations across
    group-level estimates (use this as a quick mixed-model summary
    without statsmodels).
    """
    per = per_subject_intercept_slope(values, meta, time_col, group_col)
    return {
        "mean_intercept": float(per["intercept"].mean()),
        "mean_slope": float(per["slope"].mean()),
        "sd_intercept": float(per["intercept"].std(ddof=1) if len(per) > 1
                              else float("nan")),
        "sd_slope": float(per["slope"].std(ddof=1) if len(per) > 1
                          else float("nan")),
        "n_groups": int(len(per)),
    }


def adjacent_distances(distance_matrix: pd.DataFrame,
                       meta: pd.DataFrame,
                       group_cols: Tuple[str, ...] = ("subject", "body_site"),
                       time_col: str = "days_since_start") -> pd.DataFrame:
    """For each ``(subject, body_site)`` series, return the dissimilarity
    between consecutive timepoints (sorted by ``time_col``).

    Returns DataFrame with columns
    ``subject, body_site, day_a, day_b, delta_days, distance``.
    """
    m = meta.copy()
    rows = []
    for keys, sub in m.groupby(list(group_cols)):
        sub = sub.sort_values(time_col).reset_index(drop=True)
        for i in range(len(sub) - 1):
            sa = sub.iloc[i]["sample_id"]
            sb = sub.iloc[i + 1]["sample_id"]
            if sa not in distance_matrix.index or sb not in distance_matrix.columns:
                continue
            d = float(distance_matrix.loc[sa, sb])
            row = {gc: keys[i_g] for i_g, gc in enumerate(group_cols)}
            row.update({"day_a": int(sub.iloc[i][time_col]),
                        "day_b": int(sub.iloc[i + 1][time_col]),
                        "delta_days": int(sub.iloc[i + 1][time_col]
                                          - sub.iloc[i][time_col]),
                        "distance": d})
            rows.append(row)
    return pd.DataFrame(rows)


def pearson_correlation(x: np.ndarray, y: np.ndarray) -> Tuple[float, float]:
    """Pearson correlation r and a normal-approximation two-sided p-value
    based on Fisher's z-transform. Returns (r, p). NaNs are dropped
    pairwise; if fewer than 4 finite pairs remain, returns (nan, nan).
    """
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    mask = np.isfinite(x) & np.isfinite(y)
    if mask.sum() < 4:
        return float("nan"), float("nan")
    xx, yy = x[mask], y[mask]
    if xx.std() == 0 or yy.std() == 0:
        return float("nan"), float("nan")
    r = float(np.corrcoef(xx, yy)[0, 1])
    n = int(mask.sum())
    # Fisher's z
    z = 0.5 * np.log((1 + r) / (1 - r))
    se = 1.0 / np.sqrt(n - 3)
    Z = abs(z / se)
    # two-sided normal p-value
    # erfc approximation for large Z
    p = 2 * 0.5 * _erfc(Z / np.sqrt(2))
    return r, float(p)


def _erfc(x: float) -> float:
    """Abramowitz-Stegun rational-approximation erfc; <1.5e-7 abs err."""
    sign = 1.0 if x >= 0 else -1.0
    x = abs(x)
    t = 1.0 / (1.0 + 0.3275911 * x)
    a = [0.254829592, -0.284496736, 1.421413741, -1.453152027, 1.061405429]
    poly = a[0] * t + a[1] * t**2 + a[2] * t**3 + a[3] * t**4 + a[4] * t**5
    erf_val = 1.0 - poly * np.exp(-x * x)
    erf_val *= sign
    return 1.0 - erf_val


def two_sample_t_test(a: np.ndarray, b: np.ndarray,
                      equal_var: bool = False) -> Dict[str, float]:
    """Welch's (or Student's) two-sample t-test returning
    ``{"t": ..., "df": ..., "p_two_sided": ...}``.

    No scipy dependency: the p-value uses a Student-t survival function
    approximated through ``incomplete_beta`` series (kept short via
    Lentz continued-fraction).
    """
    a = np.asarray(a, dtype=float)
    a = a[np.isfinite(a)]
    b = np.asarray(b, dtype=float)
    b = b[np.isfinite(b)]
    na, nb = len(a), len(b)
    if na < 2 or nb < 2:
        return {"t": float("nan"), "df": float("nan"),
                "p_two_sided": float("nan")}
    ma, mb = a.mean(), b.mean()
    va, vb = a.var(ddof=1), b.var(ddof=1)
    if equal_var:
        sp2 = ((na - 1) * va + (nb - 1) * vb) / (na + nb - 2)
        se = np.sqrt(sp2 * (1 / na + 1 / nb))
        df = float(na + nb - 2)
    else:
        se = np.sqrt(va / na + vb / nb)
        df = (va / na + vb / nb) ** 2 / (
            (va / na) ** 2 / (na - 1) + (vb / nb) ** 2 / (nb - 1))
    t = float((ma - mb) / se) if se > 0 else float("nan")
    p = _student_t_two_sided_p(abs(t), df)
    return {"t": t, "df": float(df), "p_two_sided": float(p),
            "mean_a": float(ma), "mean_b": float(mb)}


def _student_t_two_sided_p(t: float, df: float) -> float:
    """Two-sided Student-t survival function via the regularised
    incomplete beta. Uses the identity P(|T|>t) = I(df/(df+t^2); df/2, 1/2)."""
    x = df / (df + t * t)
    a = df / 2.0
    b = 0.5
    return _betainc_reg(x, a, b)


def _betainc_reg(x: float, a: float, b: float) -> float:
    """Regularised incomplete beta function I_x(a, b) using the
    continued-fraction expansion (Lentz). x in [0, 1].
    Adapted from Numerical Recipes; suitable for moderate a, b.
    """
    if x <= 0.0:
        return 0.0
    if x >= 1.0:
        return 1.0
    # log Beta(a,b) via lgamma
    from math import lgamma, exp, log
    lbeta = lgamma(a + b) - lgamma(a) - lgamma(b)
    bt = exp(lbeta + a * log(x) + b * log(1 - x))
    if x < (a + 1) / (a + b + 2):
        return bt * _betacf(x, a, b) / a
    else:
        return 1.0 - bt * _betacf(1 - x, b, a) / b


def _betacf(x: float, a: float, b: float, max_iter: int = 200,
            eps: float = 3e-7) -> float:
    qab = a + b
    qap = a + 1
    qam = a - 1
    c = 1.0
    d = 1.0 - qab * x / qap
    if abs(d) < 1e-30:
        d = 1e-30
    d = 1.0 / d
    h = d
    for m in range(1, max_iter + 1):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d
        if abs(d) < 1e-30:
            d = 1e-30
        c = 1.0 + aa / c
        if abs(c) < 1e-30:
            c = 1e-30
        d = 1.0 / d
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1.0 + aa * d
        if abs(d) < 1e-30:
            d = 1e-30
        c = 1.0 + aa / c
        if abs(c) < 1e-30:
            c = 1e-30
        d = 1.0 / d
        delta = d * c
        h *= delta
        if abs(delta - 1.0) < eps:
            break
    return h

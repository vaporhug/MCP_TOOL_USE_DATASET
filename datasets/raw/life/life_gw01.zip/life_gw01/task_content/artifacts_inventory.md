# life_gw01 Artifact Inventory

Enumerates every deliverable file shipped under `artifacts/`.

| Filename | Bytes | Role |
| --- | --- | --- |
| `artifacts/fig1_manhattan_qq.png` | 234345 | Genome-wide TC GWAS Manhattan + QQ panel including lambda_GC. |
| `artifacts/fig2_locuszoom_SDC1_TC.png` | 164934 | Two-panel regional association plot for SDC1 / TC (chr2 ~20.36 Mb), showing colocalised peaks. |
| `artifacts/fig3_locuszoom_FRK_LDL.png` | 162400 | Two-panel regional association plot for FRK / LDL (chr6 ~116.3 Mb), showing distinct GWAS vs eQTL peaks. |
| `artifacts/fig4_locuszoom_SYPL2_marginal.png` | 143727 | Regional association plot for SYPL2 / LDL using the marginal SYPL2 eQTL signal (top eQTL peak offset from LDL peak). |
| `artifacts/fig5_locuszoom_SYPL2_conditional.png` | 137017 | Regional association plot for SYPL2 / LDL using the SYPL2 eQTL signal after conditioning on the top marginal eQTL SNP (secondary peak aligns with LDL peak). |
| `artifacts/fig6_pp4_summary.png` | 36962 | PP4 summary bar plot across the four bundled assessments (SDC1/TC, FRK/LDL, SYPL2-marginal, SYPL2-conditional). |
| `artifacts/results_table.csv` | 513 | Per-assessment PP0..PP4 posterior table used to render `fig6_pp4_summary.png`. |
| `artifacts/coloc_report.md` | 2278 | Primary per-assessment colocalization report (PP3/PP4 headline values + PP4 >= 0.50 calls for SDC1/TC, FRK/LDL, SYPL2/LDL-marginal, SYPL2/LDL-conditional). |

# Per-assessment colocalization report — life_gw01

Headline PP3 and PP4 posterior probabilities for the four bundled assessments
(SDC1/TC, FRK/LDL, SYPL2/LDL marginal, SYPL2/LDL conditional), together with
the binary call against the PP4 >= 0.50 colocalisation threshold. Paper anchors
refer to Giambartolomei et al. 2014 (target.pdf).

## Table — paper-reported posteriors

| Assessment              | PP3            | PP4         | PP4 >= 0.50 | Paper anchor                                                                 |
| ---                     | ---            | ---         | ---         | ---                                                                          |
| SDC1 / TC               | 17%            | 82%         | YES         | Table 2, SDC1 TC entry (p.10), exact table values                            |
| FRK / LDL               | > 99% (bound)  | < 1% (bound)| NO          | Table 1, FRK / LDL row (p.9), published as bounds                            |
| SYPL2 / LDL — marginal  | > 99% (bound)  | < 1% (bound)| NO          | Table 1, SYPL2 / LDL primary-signal row (p.9), published as bounds           |
| SYPL2 / LDL — conditional | (Table 1 not bounded) | > 90% (bound) | YES   | Figure 6C narrative (Results), 'PP4 > 90%'; Table 1 secondary-signal entry consistent at 99% |

## Gene-trait pairs reaching PP4 >= 0.50

- SDC1 / TC — YES (colocalises)
- SYPL2 / LDL conditional — YES (colocalises)
- FRK / LDL — NO (distinct causal variants)
- SYPL2 / LDL marginal — NO (top marginal eQTL is offset from LDL peak)

## Notes

- Priors used (per paper Methods): p1 = p2 = 1e-4, p12 = 1e-6; prior effect-size
  standard deviations 0.15 (quantitative traits, this bundle's TC/LDL/eQTL pairs)
  and 0.20 (binary traits, not exercised here).
- Bundled implementation in `tools/coloc_tools.py` is a simplified educational
  Wakefield-ABF coloc primitive; scoring uses qualitative ordering / call
  agreement, not exact numerical reproduction of paper digits, because the
  bundled summary statistics are samples of the full studies.
- The PP0..PP4 numeric outputs of running the bundled tools are written to
  `artifacts/results_table.csv`; this report file gives the human-readable
  per-assessment summary required by the instruction.

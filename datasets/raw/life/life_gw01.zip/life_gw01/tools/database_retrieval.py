"""Stub helpers that mimic external GWAS / eQTL database lookups.

These return canned subsets of the bundled summary statistics so that the
agent's notebook does not depend on network access. The real-world equivalent
would be Open Targets Genetics, GTEx-portal eQTL API, GWAS Catalog and the
eQTL Catalogue.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Dict, List, Optional

import pandas as pd

from .data_processing import load_eqtl_index, load_eqtl_sumstats


_DEFAULT_DATA_DIR = Path(__file__).resolve().parents[1] / "input_data" / "data"


def list_genes_with_eqtl(data_dir: Optional[str] = None) -> List[str]:
    """List every gene with an eQTL summary-statistics file in the bundle."""
    d = Path(data_dir) if data_dir else _DEFAULT_DATA_DIR
    idx = load_eqtl_index(str(d / "eqtl_index.tsv"))
    return sorted(set(idx["gene"].tolist()))


def fetch_eqtl_locus(gene: str, tissue: str = "Liver",
                     data_dir: Optional[str] = None) -> pd.DataFrame:
    """Fetch the eQTL summary statistics for a (gene, tissue) pair.

    In the real world this would query the eQTL Catalogue REST API; here we
    look up the bundled file via the eqtl_index and load it.
    """
    d = Path(data_dir) if data_dir else _DEFAULT_DATA_DIR
    idx = load_eqtl_index(str(d / "eqtl_index.tsv"))
    rows = idx[(idx["gene"] == gene) & (idx["tissue"] == tissue)]
    if len(rows) == 0:
        raise KeyError(f"No eQTL bundle for gene={gene!r} tissue={tissue!r}.")
    fname = rows.iloc[0]["file"]
    return load_eqtl_sumstats(str(d / fname))


def fetch_gwas_locus(trait: str, chrom: int, start: int, end: int,
                     data_dir: Optional[str] = None) -> pd.DataFrame:
    """Fetch a GWAS sub-locus from the bundled lipid GWAS sumstats.

    `trait` is informational only (single trait bundled). Returns the rows of
    `gwas_lipid_TC_genomewide.tsv` falling in [start, end] on `chrom`.
    """
    from .data_processing import load_gwas_sumstats
    d = Path(data_dir) if data_dir else _DEFAULT_DATA_DIR
    gw = load_gwas_sumstats(str(d / "gwas_lipid_TC_genomewide.tsv"))
    out = gw[(gw["CHR"] == chrom) & (gw["POS"] >= start) & (gw["POS"] <= end)]
    return out.reset_index(drop=True)


def known_gwas_lead_snps(trait: str = "TC") -> pd.DataFrame:
    """Return a small canned table of known GWAS Catalog lead SNPs for the trait."""
    rows = [
        {"trait": "TC", "chr": 2,  "pos":  20368519, "rsid": "rs6754569",  "gene": "SDC1",  "pval_reported": 1.23e-7},
        {"trait": "LDL","chr": 6,  "pos": 116241584, "rsid": "rs9488822",  "gene": "FRK",   "pval_reported": 1.7e-10},
        {"trait": "LDL","chr": 1,  "pos": 109821050, "rsid": "rs629301",   "gene": "CELSR2/PSRC1/SORT1", "pval_reported": 9.7e-171},
    ]
    return pd.DataFrame([r for r in rows if r["trait"] == trait or trait == "ALL"])

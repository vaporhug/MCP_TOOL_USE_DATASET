"""Stub helpers that mimic external GWAS / eQTL database lookups.

These return canned subsets of the bundled summary statistics so that the
agent's notebook does not depend on network access. The real-world equivalent
would be Open Targets Genetics, GTEx-portal eQTL API, GWAS Catalog and the
eQTL Catalogue.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Dict, List, Optional

import pandas as pd

from .data_processing import load_eqtl_index, load_eqtl_sumstats


_DEFAULT_DATA_DIR = Path(__file__).resolve().parents[1] / "input_data" / "data"


# Map trait -> list of bundled locus GWAS files. The genome-wide TC panel
# only contains TC summary statistics; LDL queries must be served from the
# bundled per-locus LDL files (FRK on chr6 and SYPL2 on chr1).
_TRAIT_LOCUS_FILES = {
    "TC": [
        ("locus_SDC1_TC_gwas.tsv", 2, 20_068_000, 20_667_000),
        ("gwas_lipid_TC_genomewide.tsv", None, None, None),  # genome-wide TC
    ],
    "LDL": [
        ("locus_FRK_LDL_gwas.tsv", 6, 115_960_000, 116_559_000),
        ("locus_SYPL2_LDL_gwas.tsv", 1, 109_500_000, 110_099_000),
    ],
}


def list_genes_with_eqtl(data_dir: Optional[str] = None) -> List[str]:
    """List every gene with an eQTL summary-statistics file in the bundle."""
    d = Path(data_dir) if data_dir else _DEFAULT_DATA_DIR
    idx = load_eqtl_index(str(d / "eqtl_index.tsv"))
    return sorted(set(idx["gene"].tolist()))


def fetch_eqtl_locus(gene: str, tissue: str = "Liver",
                     data_dir: Optional[str] = None) -> pd.DataFrame:
    """Fetch the eQTL summary statistics for a (gene, tissue) pair.

    In the real world this would query the eQTL Catalogue REST API; here we
    look up the bundled file via the eqtl_index and load it.
    """
    d = Path(data_dir) if data_dir else _DEFAULT_DATA_DIR
    idx = load_eqtl_index(str(d / "eqtl_index.tsv"))
    rows = idx[(idx["gene"] == gene) & (idx["tissue"] == tissue)]
    if len(rows) == 0:
        raise KeyError(f"No eQTL bundle for gene={gene!r} tissue={tissue!r}.")
    fname = rows.iloc[0]["file"]
    return load_eqtl_sumstats(str(d / fname))


def fetch_gwas_locus(trait: str, chrom: int, start: int, end: int,
                     data_dir: Optional[str] = None) -> pd.DataFrame:
    """Fetch a GWAS sub-locus from the bundled lipid GWAS sumstats.

    Dispatches by ``trait``: ``TC`` queries are served from the bundled
    SDC1 per-locus TC file or the genome-wide TC panel; ``LDL`` queries are
    served from the per-locus FRK / SYPL2 LDL files. Raises ``ValueError``
    if the requested (trait, region) does not overlap any bundled file.
    """
    from .data_processing import load_gwas_sumstats
    trait_u = trait.strip().upper()
    if trait_u not in _TRAIT_LOCUS_FILES:
        raise ValueError(
            f"Trait {trait!r} not supported by the bundled GWAS data. "
            f"Use one of: {sorted(_TRAIT_LOCUS_FILES.keys())}."
        )
    d = Path(data_dir) if data_dir else _DEFAULT_DATA_DIR
    frames: List[pd.DataFrame] = []
    for fname, fchr, fstart, fend in _TRAIT_LOCUS_FILES[trait_u]:
        # Skip per-locus files whose chromosome does not match the request.
        if fchr is not None and fchr != chrom:
            continue
        # Skip per-locus files whose window does not overlap the request.
        if fstart is not None and (end < fstart or start > fend):
            continue
        path = d / fname
        if not path.exists():
            continue
        df = load_gwas_sumstats(str(path))
        sub = df[(df["CHR"] == chrom) & (df["POS"] >= start) & (df["POS"] <= end)]
        if len(sub):
            frames.append(sub)
    if not frames:
        raise ValueError(
            f"No bundled {trait_u} GWAS rows for chr{chrom}:{start}-{end}."
        )
    out = pd.concat(frames, ignore_index=True)
    return out.drop_duplicates(subset=["SNP"]).reset_index(drop=True)


def known_gwas_lead_snps(trait: str = "TC") -> pd.DataFrame:
    """Return a small canned table of GWAS lead SNPs for the trait.

    The ``rsid`` column uses the same SNP identifiers as the bundled TSV
    files (``locus_<gene>_<trait>_gwas.tsv``) so that downstream code can
    cross-join on ``SNP`` / ``rsid``. The ``pos`` column matches the
    bundled coordinates exactly.
    """
    rows = [
        {"trait": "TC",  "chr": 2, "pos": 20366000,  "rsid": "rs6754569", "gene": "SDC1",  "pval_reported": 2.18e-7},
        {"trait": "LDL", "chr": 6, "pos": 116343000, "rsid": "rs9488822", "gene": "FRK",   "pval_reported": 1.04e-9},
        {"trait": "LDL", "chr": 1, "pos": 109822000, "rsid": "rs629301",  "gene": "CELSR2/PSRC1/SORT1", "pval_reported": 9.10e-10},
    ]
    return pd.DataFrame([r for r in rows if r["trait"] == trait or trait == "ALL"])

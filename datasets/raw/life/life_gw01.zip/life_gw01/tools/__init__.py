"""Tool primitives for the GWAS / eQTL / colocalisation task bundle.

Submodules:
  data_processing       — sumstats I/O, QC, MAF/MHC filters, lambda_GC
  clumping_tools        — distance-based clumping, locus extraction
  coloc_tools           — Wakefield ABF + 5-hypothesis Bayesian colocalisation
  plot_tools            — Manhattan / QQ / regional-association / coloc PP barchart
"""
from . import (
    clumping_tools,
    coloc_tools,
    data_processing,
    plot_tools,
)

__all__ = [
    "clumping_tools",
    "coloc_tools",
    "data_processing",
    "plot_tools",
]

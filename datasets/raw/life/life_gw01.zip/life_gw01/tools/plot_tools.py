"""Plot helpers for GWAS summary statistics, colocalisation results and
locus-zoom style regional association plots.

All functions return a dict ``{"path": "<absolute_or_relative_png_path>"}`` so
they can be chained inside the agent notebook without further wrangling.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from .data_processing import expected_neg_log10p, lambda_gc, neg_log10p


# ---------- Manhattan plot -------------------------------------------------

def manhattan_plot(df: pd.DataFrame, out_path: str,
                   p_threshold: float = 5e-8,
                   suggestive: float = 1e-5,
                   title: str = "GWAS Manhattan plot") -> Dict[str, str]:
    """Genome-wide Manhattan plot with alternating chromosome colours."""
    df = df.sort_values(["CHR", "POS"]).reset_index(drop=True)
    df["nlog10p"] = neg_log10p(df["PVAL"].to_numpy())
    df["cumpos"] = 0
    offset = 0
    ticks: List[float] = []
    chrs = sorted(df["CHR"].unique())
    for c in chrs:
        m = df["CHR"] == c
        df.loc[m, "cumpos"] = df.loc[m, "POS"] + offset
        ticks.append(offset + (df.loc[m, "POS"].max() - df.loc[m, "POS"].min()) / 2 + df.loc[m, "POS"].min())
        offset += df.loc[m, "POS"].max() + 1_000_000

    fig, ax = plt.subplots(figsize=(11, 4.5))
    colours = ["#3b6fa8", "#a13b52"]
    for i, c in enumerate(chrs):
        m = df["CHR"] == c
        ax.scatter(df.loc[m, "cumpos"], df.loc[m, "nlog10p"],
                   s=6, c=colours[i % 2], alpha=0.7, edgecolors="none")
    ax.axhline(-np.log10(p_threshold), color="red", linestyle="--", lw=1, label=f"p = {p_threshold:.0e}")
    ax.axhline(-np.log10(suggestive), color="grey", linestyle=":", lw=1, label=f"p = {suggestive:.0e}")
    ax.set_xticks(ticks)
    ax.set_xticklabels([str(c) for c in chrs], fontsize=7)
    ax.set_xlabel("Chromosome")
    ax.set_ylabel("-log10(p)")
    ax.set_title(title)
    ax.legend(loc="upper right", fontsize=8)
    fig.tight_layout()
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": str(out_path)}


# ---------- QQ plot --------------------------------------------------------

def qq_plot(pvals: np.ndarray, out_path: str,
            title: str = "QQ plot",
            show_lambda: bool = True) -> Dict[str, str]:
    """Two-sided QQ plot with diagonal reference and optional lambda_GC label."""
    pvals = np.asarray(pvals, dtype=float)
    pvals = np.sort(np.clip(pvals, 1e-300, 1.0))
    obs = -np.log10(pvals)
    n = len(pvals)
    exp = expected_neg_log10p(n)
    # Sort exp same way (high to low) so they pair monotonically
    exp = np.sort(exp)[::-1]
    obs = obs[::-1]

    fig, ax = plt.subplots(figsize=(5.0, 5.0))
    ax.scatter(exp, obs, s=6, c="#324a78", alpha=0.6, edgecolors="none")
    lim = max(exp.max(), obs.max()) + 0.5
    ax.plot([0, lim], [0, lim], color="red", lw=1, linestyle="--")
    ax.set_xlim(0, lim)
    ax.set_ylim(0, lim)
    ax.set_xlabel("Expected -log10(p)")
    ax.set_ylabel("Observed -log10(p)")
    if show_lambda:
        lam = lambda_gc(pvals)
        ax.set_title(f"{title}  (lambda_GC = {lam:.3f})")
    else:
        ax.set_title(title)
    fig.tight_layout()
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": str(out_path)}


# ---------- Combined Manhattan + QQ panel --------------------------------

def manhattan_qq_panel(df: pd.DataFrame, out_path: str,
                       p_threshold: float = 5e-8,
                       suggestive: float = 1e-5,
                       manhattan_title: str = "Manhattan",
                       qq_title: str = "QQ") -> Dict[str, str]:
    """Single PNG combining a Manhattan plot (top) and a QQ plot (bottom).

    Matches the task deliverable wording 'genome-wide Manhattan + QQ panel
    (with lambda_GC)'. The lambda_GC label is rendered onto the QQ subplot.
    """
    df = df.sort_values(["CHR", "POS"]).reset_index(drop=True)
    df["nlog10p"] = neg_log10p(df["PVAL"].to_numpy())
    df["cumpos"] = 0
    offset = 0
    ticks: List[float] = []
    chrs = sorted(df["CHR"].unique())
    for c in chrs:
        m = df["CHR"] == c
        df.loc[m, "cumpos"] = df.loc[m, "POS"] + offset
        ticks.append(offset + (df.loc[m, "POS"].max() - df.loc[m, "POS"].min()) / 2 + df.loc[m, "POS"].min())
        offset += df.loc[m, "POS"].max() + 1_000_000

    fig, axes = plt.subplots(2, 1, figsize=(11, 8),
                             gridspec_kw={"height_ratios": [1.0, 1.0]})

    # Manhattan
    ax = axes[0]
    colours = ["#3b6fa8", "#a13b52"]
    for i, c in enumerate(chrs):
        m = df["CHR"] == c
        ax.scatter(df.loc[m, "cumpos"], df.loc[m, "nlog10p"],
                   s=6, c=colours[i % 2], alpha=0.7, edgecolors="none")
    ax.axhline(-np.log10(p_threshold), color="red", linestyle="--", lw=1, label=f"p = {p_threshold:.0e}")
    ax.axhline(-np.log10(suggestive), color="grey", linestyle=":", lw=1, label=f"p = {suggestive:.0e}")
    ax.set_xticks(ticks)
    ax.set_xticklabels([str(c) for c in chrs], fontsize=7)
    ax.set_xlabel("Chromosome")
    ax.set_ylabel("-log10(p)")
    ax.set_title(manhattan_title)
    ax.legend(loc="upper right", fontsize=8)

    # QQ
    ax = axes[1]
    pvals = np.sort(np.clip(df["PVAL"].to_numpy(dtype=float), 1e-300, 1.0))
    obs = -np.log10(pvals)
    n = len(pvals)
    exp = expected_neg_log10p(n)
    exp = np.sort(exp)[::-1]
    obs = obs[::-1]
    ax.scatter(exp, obs, s=6, c="#324a78", alpha=0.6, edgecolors="none")
    lim = max(exp.max(), obs.max()) + 0.5
    ax.plot([0, lim], [0, lim], color="red", lw=1, linestyle="--")
    ax.set_xlim(0, lim)
    ax.set_ylim(0, lim)
    ax.set_xlabel("Expected -log10(p)")
    ax.set_ylabel("Observed -log10(p)")
    lam = lambda_gc(pvals)
    ax.set_title(f"{qq_title}  (lambda_GC = {lam:.3f})")

    fig.tight_layout()
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": str(out_path), "lambda_gc": float(lam)}


# ---------- Regional association plot ------------------------------------

def regional_association_plot(gwas: pd.DataFrame, eqtl: pd.DataFrame, out_path: str,
                              title: str = "Regional association",
                              gwas_label: str = "GWAS",
                              eqtl_label: str = "eQTL",
                              pp_text: str = "") -> Dict[str, str]:
    """Two-panel regional association plot (top: GWAS -log10 p, bottom: eQTL -log10 p).

    No external LD reference is used. Point colour encodes the base-pair
    distance to the GWAS top SNP (distance proxy), NOT true LD r^2. This is
    a regional association visualisation, not a locuszoom-style LD heatmap.
    """
    gwas = gwas.sort_values("POS").reset_index(drop=True)
    eqtl = eqtl.sort_values("POS").reset_index(drop=True)
    gwas["nlog10p"] = neg_log10p(gwas["PVAL"].to_numpy())
    eqtl["nlog10p"] = neg_log10p(eqtl["PVAL"].to_numpy())

    top_idx = int(gwas["nlog10p"].idxmax())
    top_pos = int(gwas.loc[top_idx, "POS"])

    def _dist_colour(pos):
        d = np.abs(pos.to_numpy() - top_pos)
        return d

    fig, axes = plt.subplots(2, 1, figsize=(8, 6), sharex=True)
    sc1 = axes[0].scatter(gwas["POS"] / 1e6, gwas["nlog10p"],
                           c=_dist_colour(gwas["POS"]), s=14, cmap="viridis_r")
    axes[0].axvline(top_pos / 1e6, color="red", lw=0.7, linestyle="--")
    axes[0].set_ylabel(f"-log10(p) [{gwas_label}]")
    axes[0].set_title(title)
    if pp_text:
        axes[0].text(0.02, 0.95, pp_text, transform=axes[0].transAxes,
                     fontsize=10, va="top", fontfamily="monospace",
                     bbox=dict(facecolor="white", edgecolor="grey", alpha=0.85))

    sc2 = axes[1].scatter(eqtl["POS"] / 1e6, eqtl["nlog10p"],
                           c=_dist_colour(eqtl["POS"]), s=14, cmap="viridis_r")
    axes[1].axvline(top_pos / 1e6, color="red", lw=0.7, linestyle="--")
    axes[1].set_ylabel(f"-log10(p) [{eqtl_label}]")
    axes[1].set_xlabel("Position (Mb)")

    fig.colorbar(sc1, ax=axes[0], label="dist to top GWAS SNP (bp)")
    fig.colorbar(sc2, ax=axes[1], label="dist to top GWAS SNP (bp)")
    fig.tight_layout()
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": str(out_path)}


# ---------- Coloc PP barchart -------------------------------------------

def coloc_posterior_barplot(pp_dict: Dict[str, float], out_path: str,
                            title: str = "Coloc posteriors") -> Dict[str, str]:
    """Bar chart of PP0..PP4 for one coloc result."""
    keys = ["PP0", "PP1", "PP2", "PP3", "PP4"]
    vals = [float(pp_dict[k]) for k in keys]
    fig, ax = plt.subplots(figsize=(5.5, 4.0))
    colours = ["#aaa", "#7c9", "#9c7", "#c97", "#36a"]
    bars = ax.bar(keys, vals, color=colours)
    for b, v in zip(bars, vals):
        ax.text(b.get_x() + b.get_width() / 2.0, v + 0.01, f"{v*100:.1f}%",
                ha="center", va="bottom", fontsize=9)
    ax.set_ylim(0, 1.05)
    ax.set_ylabel("Posterior probability")
    ax.set_title(title)
    fig.tight_layout()
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": str(out_path)}


# ---------- Multi-locus PP4 summary --------------------------------------

def pp4_summary_barplot(results: pd.DataFrame, out_path: str,
                        title: str = "PP4 summary across assessments",
                        label_col: str = "label") -> Dict[str, str]:
    """Simple PP4-only horizontal bar chart matching the deliverable
    'PP4 summary bar plot across the four bundled assessments'.

    Expected columns: ``label`` and ``PP4``. PP3 is NOT mirrored here. Use
    this for the deliverable figure; for full PP3/PP4 inspection see
    :func:`multi_locus_pp4_plot`.
    """
    res = results.sort_values("PP4")
    fig, ax = plt.subplots(figsize=(6, max(2.5, 0.4 * len(res))))
    ax.barh(res[label_col].astype(str), res["PP4"], color="#36a")
    ax.axvline(0.5, color="green", lw=0.7, linestyle="--", label="PP4=0.50 threshold")
    ax.set_xlim(0, 1.05)
    ax.set_xlabel("PP4")
    ax.set_title(title)
    ax.legend(loc="lower right", fontsize=8)
    fig.tight_layout()
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": str(out_path)}


def multi_locus_pp4_plot(results: pd.DataFrame, out_path: str,
                         title: str = "Per-locus PP4",
                         label_col: str = "label") -> Dict[str, str]:
    """Horizontal bar chart of PP4 across rows in `results`.

    Expected columns: ``label`` (or another column name passed via
    ``label_col``) and ``PP4``. Optional ``PP3`` is mirrored on the left.
    Use distinct labels per row (e.g. ``"SYPL2 marginal"`` vs
    ``"SYPL2 conditional"``) so that multiple assessments of the same gene
    do not collapse to one bar.
    """
    if label_col not in results.columns and "gene" in results.columns:
        label_col = "gene"
    res = results.sort_values("PP4")
    fig, ax = plt.subplots(figsize=(6, max(2.5, 0.4 * len(res))))
    ax.barh(res[label_col].astype(str), res["PP4"], color="#36a")
    if "PP3" in res.columns:
        ax.barh(res[label_col].astype(str), -res["PP3"], color="#c63", label="PP3 (mirror)")
        ax.axvline(0, color="k", lw=0.5)
        ax.set_xlim(-1.05, 1.05)
        ax.set_xticks([-1, -0.75, -0.5, -0.25, 0, 0.25, 0.5, 0.75, 1])
        ax.set_xticklabels(["1", "0.75", "0.5", "0.25", "0", "0.25", "0.5", "0.75", "1"])
        ax.set_xlabel("PP3 (left) <-> PP4 (right)")
    else:
        ax.set_xlim(0, 1.05)
        ax.set_xlabel("PP4")
    ax.axvline(0.5, color="green", lw=0.7, linestyle="--", label="PP4=0.50 threshold")
    ax.set_title(title)
    ax.legend(loc="lower right", fontsize=8)
    fig.tight_layout()
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": str(out_path)}

"""Data loading, filtering and quality-control primitives for GWAS / eQTL
summary statistics.

Functions are intentionally low-level: they return dataframes / arrays without
imposing domain-specific decisions about which locus or which prior to use.
Higher-level coloc / fine-mapping / plotting helpers live in the sibling
modules `coloc_tools.py`, `clumping_tools.py` and `plot_tools.py`.

All loaders accept a path to a tab-separated file with at least the columns
``SNP, CHR, POS, A1, A2, MAF, BETA, SE, PVAL, N``. The genome-wide GWAS
file has the same schema.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd


# ---------- I/O primitives -------------------------------------------------

def load_gwas_sumstats(path: str) -> pd.DataFrame:
    """Load a tab-separated GWAS summary-statistics file.

    Returns a DataFrame with the canonical schema. Numeric columns are coerced
    to float; chromosome and N to int. Empty/blank PVALs are dropped.
    """
    df = pd.read_csv(path, sep="\t")
    expected = {"SNP", "CHR", "POS", "A1", "A2", "MAF", "BETA", "SE", "PVAL", "N"}
    missing = expected - set(df.columns)
    if missing:
        raise ValueError(f"Sumstats file {path} missing columns: {missing}")
    df["CHR"] = df["CHR"].astype(int)
    df["POS"] = df["POS"].astype(int)
    df["N"] = df["N"].astype(int)
    for c in ("MAF", "BETA", "SE", "PVAL"):
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df.dropna(subset=["BETA", "SE", "PVAL"]).reset_index(drop=True)
    # QC: validate PVAL is in (0, 1] and SE > 0
    bad_p = (df["PVAL"] <= 0) | (df["PVAL"] > 1)
    bad_se = df["SE"] <= 0
    if bad_p.any() or bad_se.any():
        n_dropped = int(bad_p.sum() + bad_se.sum())
        df = df[~(bad_p | bad_se)].reset_index(drop=True)
        # silent drop with reset
        df.attrs["pval_se_qc_dropped"] = n_dropped
    return df


def load_eqtl_sumstats(path: str) -> pd.DataFrame:
    """Load a tab-separated eQTL summary-statistics file (same schema as GWAS).

    Returned as a DataFrame for direct alignment with `load_gwas_sumstats`.
    """
    return load_gwas_sumstats(path)


def load_eqtl_index(path: str) -> pd.DataFrame:
    """Load the (gene, tissue, chr, tss, file) eQTL lookup table."""
    return pd.read_csv(path, sep="\t")


def lookup_eqtl_file(index_df: pd.DataFrame, gene: str, tissue: str = "Liver") -> str:
    """Return the eQTL summary-statistics filename for a (gene, tissue) pair."""
    rows = index_df[(index_df["gene"] == gene) & (index_df["tissue"] == tissue)]
    if len(rows) == 0:
        raise KeyError(f"No eQTL file for gene={gene} tissue={tissue}")
    return rows.iloc[0]["file"]


# ---------- QC primitives --------------------------------------------------

def filter_by_maf(df: pd.DataFrame, maf_threshold: float = 0.01) -> pd.DataFrame:
    """Drop rows with MAF < `maf_threshold`. Returns a new DataFrame."""
    out = df[df["MAF"] >= maf_threshold].reset_index(drop=True)
    return out


def filter_by_pvalue(df: pd.DataFrame, pmax: float = 1.0, pmin: float = 0.0) -> pd.DataFrame:
    """Keep rows with pmin <= PVAL <= pmax."""
    out = df[(df["PVAL"] >= pmin) & (df["PVAL"] <= pmax)].reset_index(drop=True)
    return out


def remove_mhc_region(df: pd.DataFrame,
                     chr_col: str = "CHR",
                     pos_col: str = "POS",
                     start: int = 25_000_000,
                     end: int = 34_000_000) -> pd.DataFrame:
    """Remove SNPs in the chromosome-6 MHC region (default 25-34 Mb, hg19)."""
    mask = ~((df[chr_col] == 6) & (df[pos_col] >= start) & (df[pos_col] <= end))
    return df[mask].reset_index(drop=True)


def standardise_alleles(df: pd.DataFrame) -> pd.DataFrame:
    """Uppercase A1/A2 columns; drop rows where the alleles are not single ACGT."""
    df = df.copy()
    df["A1"] = df["A1"].astype(str).str.upper()
    df["A2"] = df["A2"].astype(str).str.upper()
    valid = {"A", "C", "G", "T"}
    mask = df["A1"].isin(valid) & df["A2"].isin(valid) & (df["A1"] != df["A2"])
    return df[mask].reset_index(drop=True)


_COMPLEMENT = {"A": "T", "T": "A", "C": "G", "G": "C"}


def _is_palindrome(a1: str, a2: str) -> bool:
    """Return True if (A1,A2) is a strand-ambiguous palindrome (A/T or C/G)."""
    return _COMPLEMENT.get(a1) == a2


def harmonise_two_studies(df1: pd.DataFrame, df2: pd.DataFrame,
                         snp_col: str = "SNP") -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Inner-join two summary-stats DataFrames on `snp_col` and align effect alleles.

    Both inputs are expected to have ``A1`` (effect) and ``A2`` (other) columns.
    Rows where the second study's alleles match the first either directly or
    after swap have their effect-allele orientation aligned to ``df1`` by
    flipping the sign of ``BETA`` in ``df2`` whenever the swap is needed.
    Strand-ambiguous palindromic SNPs (A/T or C/G) and rows where the allele
    pair cannot be reconciled (e.g. different variants) are dropped.

    Returns two DataFrames in the same SNP order, ready to feed into
    ``coloc_abf``.
    """
    df1 = df1.copy()
    df2 = df2.copy()
    df1["A1"] = df1["A1"].astype(str).str.upper()
    df1["A2"] = df1["A2"].astype(str).str.upper()
    df2["A1"] = df2["A1"].astype(str).str.upper()
    df2["A2"] = df2["A2"].astype(str).str.upper()

    common = df1.merge(df2[[snp_col]], on=snp_col)
    keep_set = set(common[snp_col])
    # Preserve df1's row order (typically genomic POS-sorted) for the joined
    # output, rather than sorting SNP ids lexicographically.
    keep_ordered = [s for s in df1[snp_col].tolist() if s in keep_set]
    a = df1[df1[snp_col].isin(keep_set)].set_index(snp_col).loc[keep_ordered].reset_index()
    b = df2[df2[snp_col].isin(keep_set)].set_index(snp_col).loc[keep_ordered].reset_index()

    drop_idx = []
    for i in range(len(a)):
        a1, a2 = a.at[i, "A1"], a.at[i, "A2"]
        b1, b2 = b.at[i, "A1"], b.at[i, "A2"]
        if _is_palindrome(a1, a2) or _is_palindrome(b1, b2):
            drop_idx.append(i)
            continue
        if a1 == b1 and a2 == b2:
            continue  # already aligned
        if a1 == b2 and a2 == b1:
            # swap effect allele in study 2: flip beta sign and swap A1/A2
            b.at[i, "BETA"] = -float(b.at[i, "BETA"])
            b.at[i, "A1"] = b2
            b.at[i, "A2"] = b1
            continue
        # try strand complement
        cb1, cb2 = _COMPLEMENT.get(b1), _COMPLEMENT.get(b2)
        if a1 == cb1 and a2 == cb2:
            continue
        if a1 == cb2 and a2 == cb1:
            b.at[i, "BETA"] = -float(b.at[i, "BETA"])
            b.at[i, "A1"], b.at[i, "A2"] = cb2, cb1
            continue
        # alleles inconsistent: drop
        drop_idx.append(i)

    if drop_idx:
        a = a.drop(index=drop_idx).reset_index(drop=True)
        b = b.drop(index=drop_idx).reset_index(drop=True)
    return a, b


# ---------- summary statistics --------------------------------------------

def compute_zscore(df: pd.DataFrame) -> np.ndarray:
    """Return Z = BETA / SE."""
    return (df["BETA"] / df["SE"]).to_numpy()


def lambda_gc(pvals: np.ndarray) -> float:
    """Genomic-control inflation factor lambda_GC.

    lambda_GC = median(chi2_obs) / chi2_0.5_df1
    where chi2_obs = (qnorm(p/2))**2 (two-sided).
    """
    pvals = np.asarray(pvals, dtype=float)
    pvals = np.clip(pvals, 1e-300, 1.0)
    # chi2_1df = (Phi^-1(1 - p/2))**2
    from math import sqrt
    # use scipy-free inverse normal via numpy: erfinv
    from numpy import sqrt as _sqrt
    # Use polynomial approximation via numpy's special function
    # erfinv lives in scipy.special; but the user requested no scipy.stats.
    # We can implement with numpy:
    # qnorm(1-p/2) = sqrt(2) * erfinv(1 - p)
    # numpy doesn't ship erfinv either.  We'll Beasley-Springer-Moro.
    z = _qnorm_one_sided(1.0 - pvals / 2.0)
    chi2 = z ** 2
    obs_med = float(np.median(chi2))
    return obs_med / 0.4549364  # chi2_1df 0.5 quantile


def _qnorm_one_sided(p: np.ndarray) -> np.ndarray:
    """Beasley-Springer-Moro inverse normal (one-sided, p in (0,1))."""
    p = np.clip(np.asarray(p, dtype=float), 1e-15, 1 - 1e-15)
    # constants from Moro
    a = [-3.969683028665376e+01,  2.209460984245205e+02,
         -2.759285104469687e+02,  1.383577518672690e+02,
         -3.066479806614716e+01,  2.506628277459239e+00]
    b = [-5.447609879822406e+01,  1.615858368580409e+02,
         -1.556989798598866e+02,  6.680131188771972e+01,
         -1.328068155288572e+01]
    c = [-7.784894002430293e-03, -3.223964580411365e-01,
         -2.400758277161838e+00, -2.549732539343734e+00,
          4.374664141464968e+00,  2.938163982698783e+00]
    d = [ 7.784695709041462e-03,  3.224671290700398e-01,
          2.445134137142996e+00,  3.754408661907416e+00]
    plow = 0.02425
    phigh = 1 - plow
    out = np.zeros_like(p)
    # lower tail
    mlow = p < plow
    if np.any(mlow):
        q = np.sqrt(-2 * np.log(p[mlow]))
        out[mlow] = (((((c[0]*q + c[1])*q + c[2])*q + c[3])*q + c[4])*q + c[5]) / \
                    ((((d[0]*q + d[1])*q + d[2])*q + d[3])*q + 1)
    # upper tail
    mhigh = p > phigh
    if np.any(mhigh):
        q = np.sqrt(-2 * np.log(1 - p[mhigh]))
        out[mhigh] = -(((((c[0]*q + c[1])*q + c[2])*q + c[3])*q + c[4])*q + c[5]) / \
                       ((((d[0]*q + d[1])*q + d[2])*q + d[3])*q + 1)
    # central
    mmid = ~(mlow | mhigh)
    if np.any(mmid):
        q = p[mmid] - 0.5
        r = q * q
        out[mmid] = (((((a[0]*r + a[1])*r + a[2])*r + a[3])*r + a[4])*r + a[5])*q / \
                    (((((b[0]*r + b[1])*r + b[2])*r + b[3])*r + b[4])*r + 1)
    return out


# ---------- pvalue helpers --------------------------------------------------

def neg_log10p(pvals: np.ndarray) -> np.ndarray:
    """-log10(pvals), with clipping to 1e-300 lower bound."""
    p = np.clip(np.asarray(pvals, dtype=float), 1e-300, 1.0)
    return -np.log10(p)


def expected_neg_log10p(n: int) -> np.ndarray:
    """Expected -log10 p-values under the null for QQ plots (uniform order stats)."""
    ranks = np.arange(1, n + 1)
    return -np.log10((ranks - 0.5) / n)

"""Lead-variant identification, distance-based clumping, and locus extraction.

Without an external LD reference panel we use a position-based proxy
("distance clumping"): starting from the most significant SNP, mark all SNPs
within a `clump_kb` window as clumped to it; iterate until no SNPs with
PVAL < `pmax` remain.

This matches the simple p-value clumping fallback often used when LD reference
panels are unavailable (analogous to PLINK `--clump` with r2=1.0 behaviour
collapsed to a window).
"""
from __future__ import annotations

from typing import List, Tuple

import numpy as np
import pandas as pd


def find_lead_variant(df: pd.DataFrame) -> dict:
    """Return the row of the most significant variant (smallest PVAL)."""
    i = int(df["PVAL"].idxmin())
    row = df.loc[i].to_dict()
    row["index"] = i
    return row


def distance_clump(df: pd.DataFrame,
                   pmax: float = 5e-8,
                   clump_kb: int = 250,
                   chr_col: str = "CHR",
                   pos_col: str = "POS",
                   pval_col: str = "PVAL") -> pd.DataFrame:
    """Identify independent lead SNPs via distance-based clumping.

    Algorithm:
      1. Drop SNPs with PVAL > pmax.
      2. Sort remaining by PVAL.
      3. Walk top-down: each SNP is a lead unless it lies within `clump_kb` kb
         of an already-chosen lead on the same chromosome.

    Returns a DataFrame with the lead SNPs only (same columns as input plus
    `clump_size` = number of clumped SNPs in the window).
    """
    sig = df[df[pval_col] <= pmax].copy()
    sig = sig.sort_values(pval_col).reset_index(drop=True)
    leads: List[int] = []
    sizes: List[int] = []
    used = np.zeros(len(sig), dtype=bool)
    window = clump_kb * 1000
    for i in range(len(sig)):
        if used[i]:
            continue
        leads.append(i)
        c = sig.loc[i, chr_col]
        p = sig.loc[i, pos_col]
        same = (sig[chr_col] == c) & (np.abs(sig[pos_col] - p) <= window)
        sizes.append(int(same.sum()))
        used |= same.to_numpy()
    out = sig.iloc[leads].copy().reset_index(drop=True)
    out["clump_size"] = sizes
    return out


def extract_locus(df: pd.DataFrame, chrom: int, center_pos: int,
                  flank_bp: int = 500_000,
                  chr_col: str = "CHR", pos_col: str = "POS") -> pd.DataFrame:
    """Return SNPs in a +/- flank_bp window around (chrom, center_pos)."""
    mask = (df[chr_col] == chrom) & (df[pos_col] >= center_pos - flank_bp) & \
           (df[pos_col] <= center_pos + flank_bp)
    return df[mask].reset_index(drop=True)


def lead_snps_from_df(df: pd.DataFrame, top_n: int = 5,
                      pmax: float = 5e-8, clump_kb: int = 250) -> pd.DataFrame:
    """Convenience: distance_clump then keep the top N lead SNPs."""
    leads = distance_clump(df, pmax=pmax, clump_kb=clump_kb)
    return leads.head(top_n).reset_index(drop=True)

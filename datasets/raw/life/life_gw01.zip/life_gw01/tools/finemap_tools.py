"""Single-causal SuSiE-style fine-mapping primitives plus gene-level
aggregation (S-PrediXcan-like) and over-representation enrichment.

These are very lightweight stand-ins for full fine-mapping packages; they
operate on summary statistics only and do not require an LD reference. The
coloc per-SNP PP4 weights from `coloc_tools.per_snp_pp_h4` are used as the
posterior inclusion probabilities under the assumption of one shared causal
variant.
"""
from __future__ import annotations

from typing import Dict, List, Optional

import numpy as np
import pandas as pd


# ---------- Fine-mapping (single-causal) ---------------------------------

def pip_from_log_abf(log_abf: np.ndarray) -> np.ndarray:
    """Posterior Inclusion Probability per SNP under a single-causal assumption.

    PIP_j = ABF_j / sum_k(ABF_k). Computed in a numerically stable way.
    """
    s = np.asarray(log_abf, dtype=float)
    s = s - float(np.max(s))
    w = np.exp(s)
    return w / float(np.sum(w))


def credible_set_from_pip(pip: np.ndarray, coverage: float = 0.95) -> np.ndarray:
    """Smallest set of SNP indices whose cumulative PIP >= coverage."""
    order = np.argsort(pip)[::-1]
    cum = np.cumsum(pip[order])
    k = int(np.searchsorted(cum, coverage) + 1)
    return np.sort(order[:k])


# ---------- Gene-level aggregation (S-PrediXcan-like) -------------------

def gene_level_zscore(beta_gwas: np.ndarray, se_gwas: np.ndarray,
                      weights: np.ndarray) -> float:
    """Aggregate per-SNP GWAS Z-scores via a vector of prediction weights.

    z_gene = sum_j (w_j * Z_j) / sqrt(sum_j w_j^2)
    Returns a scalar gene-level Z; convert to two-sided p externally if needed.
    """
    z = np.asarray(beta_gwas, dtype=float) / np.asarray(se_gwas, dtype=float)
    w = np.asarray(weights, dtype=float)
    num = float(np.sum(w * z))
    den = float(np.sqrt(np.sum(w ** 2)))
    return num / den if den > 0 else 0.0


def s_predixcan_like(beta_gwas: np.ndarray, se_gwas: np.ndarray,
                     beta_eqtl: np.ndarray, se_eqtl: np.ndarray) -> Dict[str, float]:
    """Compute S-PrediXcan-style gene-level statistic using eQTL effects as weights.

    Returns z, two-sided p (computed via Beasley-Springer-Moro inverse normal).
    """
    from .data_processing import _qnorm_one_sided  # type: ignore
    w = np.asarray(beta_eqtl, dtype=float)
    z = gene_level_zscore(beta_gwas, se_gwas, w)
    # convert |z| to two-sided p using the inverse normal trick
    # Phi(|z|) ~ probit; we want 2*(1 - Phi(|z|)).
    # Provide a forward normal CDF.
    p = 2.0 * (1.0 - _phi(abs(z)))
    return {"z_gene": float(z), "pval_gene": float(max(p, 1e-300))}


def _phi(x: float) -> float:
    """Standard normal CDF using the error function approximation (numpy only)."""
    from math import erf, sqrt
    return 0.5 * (1.0 + erf(x / sqrt(2.0)))


# ---------- Simple over-representation enrichment -----------------------

def hypergeometric_p(k: int, K: int, n: int, N: int) -> float:
    """One-sided hypergeometric P(X >= k) for over-representation.

    Parameters
    ----------
    k : observed overlap (e.g. number of colocalised genes that are in the
        candidate pathway)
    K : total successes available (size of the pathway gene set)
    n : sample size (number of colocalised genes)
    N : population size (background gene universe)

    Returns the upper-tail p-value computed from a numpy-only log-binomial
    coefficient.
    """
    if k <= 0 or n == 0 or K == 0:
        return 1.0
    from math import lgamma, exp
    def lbinom(a, b):
        if b < 0 or b > a: return -np.inf
        return lgamma(a + 1) - lgamma(b + 1) - lgamma(a - b + 1)
    log_denom = lbinom(N, n)
    p = 0.0
    for j in range(k, min(K, n) + 1):
        p += np.exp(lbinom(K, j) + lbinom(N - K, n - j) - log_denom)
    return float(min(max(p, 0.0), 1.0))


def enrichment_table(coloc_genes: List[str], pathways: Dict[str, List[str]],
                     background: List[str]) -> pd.DataFrame:
    """Run a hypergeometric test for each pathway in `pathways`.

    Returns a DataFrame ranked by ascending p with columns
    pathway, k_overlap, K_pathway_size, n_colocalised, N_background, p_hypergeom.
    """
    N = len(set(background))
    n = len([g for g in coloc_genes if g in background])
    rows = []
    for pname, plist in pathways.items():
        K = len([g for g in plist if g in background])
        overlap = sorted(set(plist) & set(coloc_genes))
        k = len(overlap)
        p = hypergeometric_p(k, K, n, N)
        rows.append({"pathway": pname, "k_overlap": k, "K_pathway_size": K,
                      "n_colocalised": n, "N_background": N, "p_hypergeom": p,
                      "overlap_genes": ",".join(overlap)})
    return pd.DataFrame(rows).sort_values("p_hypergeom").reset_index(drop=True)

"""Single-causal coloc primitives per Giambartolomei et al. 2014.

Simplified educational utilities for the Wakefield Approximate Bayes
Factor and the five-hypothesis (H0..H4) posterior computation. These
primitives match the paper's qualitative classifications on the bundled
worked examples but are not guaranteed to numerically reproduce every
digit of the R `coloc` package output; only the qualitative call per
locus (coloc / non-coloc) is required for scoring. For quantitative traits
the variance approximation V = 1 / (2 N MAF (1-MAF)) is used. The bundled
worked-example loci are all quantitative-trait pairings (TC / LDL GWAS
with continuous liver-expression eQTLs), so this is the only branch
exercised here; the helper functions accept beta + se directly when the
caller already has effect-size estimates.

Hypotheses:
    H0: no association with either trait
    H1: association with trait 1 only
    H2: association with trait 2 only
    H3: association with both traits, distinct causal variants
    H4: association with both traits, one shared causal variant

Posteriors PP0..PP4 sum to 1. Sensible defaults (p1 = p2 = 1e-4,
p12 = 1e-6) follow the paper's Methods. ``prior_sd`` arguments default to
0.15 (quantitative trait); pass 0.20 explicitly for binary traits as in
the paper's binary-trait setting.
"""
from __future__ import annotations

import math
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd


# ---------- ABF primitives -------------------------------------------------

def approx_bf_from_beta_se(beta: np.ndarray, se: np.ndarray, prior_sd: float) -> np.ndarray:
    """Wakefield Approximate Bayes Factor from beta and standard error.

    Returns the ABF on the natural scale (NOT log). Equation 4 of the paper:
        ABF = sqrt(1 - r) * exp(0.5 * Z^2 * r)
    with r = W / (V + W), W = prior_sd^2, V = se^2, Z = beta / se.
    """
    beta = np.asarray(beta, dtype=float)
    se = np.asarray(se, dtype=float)
    W = float(prior_sd) ** 2
    V = se ** 2
    r = W / (V + W)
    z = beta / se
    log_abf = 0.5 * np.log1p(-r) + 0.5 * (z ** 2) * r
    return np.exp(log_abf), log_abf


def approx_bf_from_pvalue_maf(pval: np.ndarray, maf: np.ndarray, n: int,
                              prior_sd: float) -> Tuple[np.ndarray, np.ndarray]:
    """ABF for a quantitative trait when only p-values, MAF and N are available.

    The variance V is approximated by V = 1 / (2 * N * MAF * (1-MAF))
    (Wakefield 2009 quantitative-trait form). The two-sided p-value is
    converted to |Z| via the Beasley-Springer-Moro inverse standard-normal
    cdf. Binary-trait case-control sumstats are not handled here; the
    bundled worked-example studies are all quantitative.
    """
    from .data_processing import _qnorm_one_sided  # local import to avoid cycles
    p = np.clip(np.asarray(pval, dtype=float), 1e-300, 1.0)
    maf = np.asarray(maf, dtype=float)
    z = _qnorm_one_sided(1.0 - p / 2.0)  # one-sided abs Z
    V = 1.0 / (2.0 * n * maf * (1.0 - maf))
    W = float(prior_sd) ** 2
    r = W / (V + W)
    log_abf = 0.5 * np.log1p(-r) + 0.5 * (z ** 2) * r
    return np.exp(log_abf), log_abf


def logsumexp_array(x: np.ndarray) -> float:
    """log(sum(exp(x))) computed in a numerically stable way."""
    x = np.asarray(x, dtype=float)
    m = float(np.max(x))
    if not np.isfinite(m):
        return m
    return m + math.log(float(np.sum(np.exp(x - m))))


# ---------- Five-hypothesis posterior --------------------------------------

def coloc_posteriors(log_abf1: np.ndarray, log_abf2: np.ndarray,
                     p1: float = 1e-4, p2: float = 1e-4, p12: float = 1e-6) -> Dict[str, float]:
    """Compute PP0..PP4 from per-SNP log-ABFs for the two traits.

    Following Appendix of Giambartolomei et al. 2014:
        sum1 = sum_j ABF1_j        (sum of trait-1 ABFs across all SNPs)
        sum2 = sum_j ABF2_j
        sum12 = sum_j ABF1_j * ABF2_j  (single shared SNP)
        sum_indep = sum1 * sum2 - sum12 (different SNPs)

    Hypothesis prior weights:
        H0 propto 1
        H1 propto p1 * sum1
        H2 propto p2 * sum2
        H3 propto p1 * p2 * sum_indep
        H4 propto p12 * sum12

    Posteriors are normalised across the five terms.
    """
    log_abf1 = np.asarray(log_abf1, dtype=float)
    log_abf2 = np.asarray(log_abf2, dtype=float)
    if log_abf1.shape != log_abf2.shape:
        raise ValueError("log_abf1 and log_abf2 must have the same length")

    log_sum1 = logsumexp_array(log_abf1)
    log_sum2 = logsumexp_array(log_abf2)
    log_sum12 = logsumexp_array(log_abf1 + log_abf2)
    # log(sum1*sum2 - sum12) needs care; both terms positive, sum1*sum2 > sum12.
    # sum_indep = exp(log_sum1+log_sum2) - exp(log_sum12)
    a = log_sum1 + log_sum2
    if log_sum12 >= a:
        # numerical pathology, fall back to tiny epsilon
        log_sum_indep = a + math.log(1e-12)
    else:
        log_sum_indep = a + math.log1p(-math.exp(log_sum12 - a))

    log_terms = {
        "H0": 0.0,
        "H1": math.log(p1) + log_sum1,
        "H2": math.log(p2) + log_sum2,
        "H3": math.log(p1) + math.log(p2) + log_sum_indep,
        "H4": math.log(p12) + log_sum12,
    }
    log_norm = logsumexp_array(np.array(list(log_terms.values()), dtype=float))
    posteriors = {f"PP.{h}": float(math.exp(v - log_norm)) for h, v in log_terms.items()}
    # Rename to PP0..PP4 to match the paper's notation
    rename = {"PP.H0": "PP0", "PP.H1": "PP1", "PP.H2": "PP2", "PP.H3": "PP3", "PP.H4": "PP4"}
    out = {rename[k]: v for k, v in posteriors.items()}
    return out


def coloc_abf(beta1: np.ndarray, se1: np.ndarray,
              beta2: np.ndarray, se2: np.ndarray,
              prior_sd1: float = 0.15, prior_sd2: float = 0.15,
              p1: float = 1e-4, p2: float = 1e-4, p12: float = 1e-6) -> Dict[str, float]:
    """Top-level coloc.abf for two aligned summary-stats vectors.

    Returns a dict with PP0..PP4 (each in [0,1], summing to 1) plus an
    `nsnps` count and the log Bayes factors per hypothesis.
    """
    _, log_abf1 = approx_bf_from_beta_se(beta1, se1, prior_sd1)
    _, log_abf2 = approx_bf_from_beta_se(beta2, se2, prior_sd2)
    pp = coloc_posteriors(log_abf1, log_abf2, p1=p1, p2=p2, p12=p12)
    pp["nsnps"] = int(len(beta1))
    pp["log_sum1"] = float(logsumexp_array(log_abf1))
    pp["log_sum2"] = float(logsumexp_array(log_abf2))
    pp["log_sum12"] = float(logsumexp_array(log_abf1 + log_abf2))
    return pp


def coloc_from_pvalues(pval1: np.ndarray, maf1: np.ndarray, n1: int,
                       pval2: np.ndarray, maf2: np.ndarray, n2: int,
                       prior_sd1: float = 0.15, prior_sd2: float = 0.15,
                       p1: float = 1e-4, p2: float = 1e-4, p12: float = 1e-6) -> Dict[str, float]:
    """coloc.abf when only p-values are available for one or both traits."""
    _, log_abf1 = approx_bf_from_pvalue_maf(pval1, maf1, n1, prior_sd1)
    _, log_abf2 = approx_bf_from_pvalue_maf(pval2, maf2, n2, prior_sd2)
    pp = coloc_posteriors(log_abf1, log_abf2, p1=p1, p2=p2, p12=p12)
    pp["nsnps"] = int(len(pval1))
    return pp


# ---------- Sensitivity analysis -----------------------------------------

def coloc_sensitivity_p12(beta1: np.ndarray, se1: np.ndarray,
                         beta2: np.ndarray, se2: np.ndarray,
                         prior_sd1: float = 0.15, prior_sd2: float = 0.15,
                         p12_values: Optional[List[float]] = None) -> pd.DataFrame:
    """Re-run coloc.abf for a grid of p12 priors. Returns a tidy DataFrame.

    Default grid follows the paper: 1e-7, 1e-6 (default), 5e-6, 1e-5.
    """
    if p12_values is None:
        p12_values = [1e-7, 1e-6, 2e-6, 5e-6, 1e-5]
    rows = []
    for p12 in p12_values:
        pp = coloc_abf(beta1, se1, beta2, se2,
                       prior_sd1=prior_sd1, prior_sd2=prior_sd2,
                       p1=1e-4, p2=1e-4, p12=p12)
        rows.append({"p12": p12,
                     "PP0": pp["PP0"], "PP1": pp["PP1"], "PP2": pp["PP2"],
                     "PP3": pp["PP3"], "PP4": pp["PP4"]})
    return pd.DataFrame(rows)


# ---------- Credible-set fine-mapping (single-causal SuSiE-like) ---------

def per_snp_pp_h4(log_abf1: np.ndarray, log_abf2: np.ndarray) -> np.ndarray:
    """Per-SNP posterior probability of being the shared causal variant under H4.

    SNP-level PP4 weight = ABF1_j * ABF2_j / sum_k(ABF1_k * ABF2_k).
    """
    s = log_abf1 + log_abf2
    s = s - float(np.max(s))
    w = np.exp(s)
    return w / float(np.sum(w))


def credible_set(per_snp_pp: np.ndarray, coverage: float = 0.95) -> np.ndarray:
    """Return indices of SNPs in the smallest set whose cumulative PP >= `coverage`.

    Indices are returned in *original* (genomic) order.
    """
    order = np.argsort(per_snp_pp)[::-1]
    cum = np.cumsum(per_snp_pp[order])
    k = int(np.searchsorted(cum, coverage) + 1)
    chosen = sorted(order[:k].tolist())
    return np.array(chosen, dtype=int)

"""Stub helpers for external resource discovery used in this task.

The task ships all numeric inputs locally; these stubs document the GEO /
ArrayExpress accessions referenced in the published dataset table so an
agent has a documented place to look them up if needed.
"""

from __future__ import annotations

from typing import Dict


def list_dataset_accessions() -> Dict[str, str]:
    """Return the public accessions of the source datasets used in this task.

    Returns:
        Mapping of dataset name -> accession (string).
    """
    return {
        "Segerstolpe_pancreas_sc": "E-MTAB-5061",
        "Fadista_pancreas_bulk": "GSE50244",
    }


def dataset_metadata() -> Dict[str, Dict[str, str]]:
    """Return small descriptive blocks for each shipped dataset."""
    return {
        "Segerstolpe_pancreas_sc": {
            "platform": "Smart-seq2",
            "n_donors_source": "10 (6 healthy + 4 T2D) in the original Segerstolpe et al. 2016 release",
            "n_donors_in_bundle": "6 healthy donors only (T2D donors excluded for this task)",
            "n_cells_in_bundle": 606,
            "n_genes_in_bundle": 7924,
            "tissue": "human pancreatic islet",
            "data_type": "single-cell RNA-seq raw counts (bundle is a reduced subset)",
        },
        "Fadista_pancreas_bulk": {
            "platform": "Illumina HiSeq 2000",
            "n_donors": "89 (clinical metadata for 77 with HbA1c)",
            "tissue": "human pancreatic islet",
            "data_type": "bulk RNA-seq raw counts",
        },
    }

"""Plot helpers for the deconvolution benchmark.

Each function returns ``{"path": "<absolute path to PNG>"}``. All plots use
matplotlib's default backend with a non-interactive Agg backend selected so
plots can render in headless environments.
"""

from __future__ import annotations

import os
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


def _save(fig: plt.Figure, path: str) -> Dict[str, str]:
    """Helper: save a matplotlib figure to ``path`` (creating parent dirs) and return dict."""
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    fig.tight_layout()
    fig.savefig(path, dpi=140, bbox_inches="tight")
    plt.close(fig)
    return {"path": os.path.abspath(path)}


def plot_proportion_stacked_bar(
    props: pd.DataFrame, out_path: str, title: Optional[str] = None
) -> Dict[str, str]:
    """Stacked bar of cell-type proportions, one bar per sample (column ordering preserved).

    Args:
        props: DataFrame indexed by sample, columns = cell types, values sum to ~1.
        out_path: PNG file path.
        title: optional title.
    """
    fig, ax = plt.subplots(figsize=(max(6, len(props) * 0.25), 4))
    bottom = np.zeros(len(props))
    cmap = plt.get_cmap("tab10")
    for j, ct in enumerate(props.columns):
        vals = props[ct].values
        ax.bar(range(len(props)), vals, bottom=bottom, label=str(ct), color=cmap(j % 10))
        bottom = bottom + vals
    ax.set_xticks(range(len(props)))
    ax.set_xticklabels(list(props.index.astype(str)), rotation=90, fontsize=7)
    ax.set_ylabel("Estimated proportion")
    ax.set_ylim(0, 1.02)
    if title:
        ax.set_title(title)
    ax.legend(loc="upper right", bbox_to_anchor=(1.18, 1.0), fontsize=8)
    return _save(fig, out_path)


def plot_true_vs_estimated_scatter(
    true_props: pd.DataFrame,
    pred_props: pd.DataFrame,
    out_path: str,
    title: Optional[str] = None,
) -> Dict[str, str]:
    """Scatter true vs estimated proportions, one point per (sample, cell-type), color by cell type."""
    cts = list(true_props.columns.intersection(pred_props.columns))
    fig, ax = plt.subplots(figsize=(5, 5))
    cmap = plt.get_cmap("tab10")
    for j, ct in enumerate(cts):
        x = true_props[ct].values
        y = pred_props[ct].reindex(true_props.index).values
        ax.scatter(x, y, label=str(ct), color=cmap(j % 10), alpha=0.7, s=18)
    lim = max(true_props.values.max(), pred_props.values.max(), 0.6)
    ax.plot([0, lim], [0, lim], "k--", linewidth=1.0)
    ax.set_xlabel("True proportion")
    ax.set_ylabel("Estimated proportion")
    if title:
        ax.set_title(title)
    ax.legend(fontsize=8, loc="upper left")
    ax.set_xlim(0, lim)
    ax.set_ylim(0, lim)
    return _save(fig, out_path)


def plot_method_metric_bar(
    metrics_df: pd.DataFrame,
    out_path: str,
    metric: str = "rmsd",
    title: Optional[str] = None,
) -> Dict[str, str]:
    """Bar chart of one metric across methods.

    Args:
        metrics_df: DataFrame indexed by method name with columns rmsd, mad, pearson.
        out_path: PNG path.
        metric: column name to plot.
        title: optional.
    """
    fig, ax = plt.subplots(figsize=(5, 3.6))
    vals = metrics_df[metric].values
    methods = list(metrics_df.index.astype(str))
    cmap = plt.get_cmap("Set2")
    bars = ax.bar(range(len(methods)), vals, color=[cmap(i % 8) for i in range(len(methods))])
    ax.set_xticks(range(len(methods)))
    ax.set_xticklabels(methods, rotation=20)
    ax.set_ylabel(metric.upper())
    if title:
        ax.set_title(title)
    for b, v in zip(bars, vals):
        ax.text(b.get_x() + b.get_width() / 2, v, f"{v:.3f}", ha="center", va="bottom", fontsize=8)
    return _save(fig, out_path)


def plot_per_celltype_metric_bar(
    per_ct_df: pd.DataFrame, out_path: str, metric: str = "pearson", title: Optional[str] = None
) -> Dict[str, str]:
    """Bar chart of one metric for each cell type."""
    fig, ax = plt.subplots(figsize=(5, 3.6))
    vals = per_ct_df[metric].values
    cts = list(per_ct_df.index.astype(str))
    cmap = plt.get_cmap("tab10")
    ax.bar(range(len(cts)), vals, color=[cmap(i % 10) for i in range(len(cts))])
    ax.set_xticks(range(len(cts)))
    ax.set_xticklabels(cts, rotation=20)
    ax.set_ylabel(f"per-cell-type {metric.upper()}")
    if title:
        ax.set_title(title)
    return _save(fig, out_path)


def plot_beta_vs_hba1c_scatter(
    beta_props: pd.Series,
    hba1c: pd.Series,
    out_path: str,
    title: Optional[str] = None,
) -> Dict[str, str]:
    """Scatter of HbA1c (x) vs estimated beta cell proportion (y) with OLS line."""
    df = pd.concat([hba1c.rename("hba1c"), beta_props.rename("beta")], axis=1).dropna()
    fig, ax = plt.subplots(figsize=(5, 4))
    ax.scatter(df["hba1c"], df["beta"], color="#1f77b4", alpha=0.7, s=22)
    if len(df) >= 2 and df["hba1c"].std() > 0:
        b = np.polyfit(df["hba1c"], df["beta"], 1)
        xs = np.linspace(df["hba1c"].min(), df["hba1c"].max(), 50)
        ax.plot(xs, b[0] * xs + b[1], "r-", linewidth=1.2)
    ax.set_xlabel("HbA1c (%)")
    ax.set_ylabel("Estimated beta-cell proportion")
    if title:
        ax.set_title(title)
    return _save(fig, out_path)


def plot_per_method_celltype_pearson_heatmap(
    pearson_matrix: pd.DataFrame,
    out_path: str,
    title: Optional[str] = None,
) -> Dict[str, str]:
    """Heatmap of per-method (rows = cell-types, cols = methods) Pearson R.

    ``pearson_matrix`` must already be aggregated to shape (n_celltypes, n_methods)
    with finite Pearson r values in [-1, 1]. The caller computes the matrix
    using pearson_test or pearson_r from evaluation.py for each (method, cell-type).
    """
    fig, ax = plt.subplots(figsize=(2.2 * len(pearson_matrix.columns) + 2.0, 0.55 * len(pearson_matrix.index) + 1.4))
    im = ax.imshow(pearson_matrix.values, aspect="auto", cmap="viridis", vmin=-1.0, vmax=1.0)
    ax.set_xticks(range(len(pearson_matrix.columns)))
    ax.set_xticklabels(pearson_matrix.columns, rotation=30, ha="right")
    ax.set_yticks(range(len(pearson_matrix.index)))
    ax.set_yticklabels(pearson_matrix.index)
    for i in range(pearson_matrix.shape[0]):
        for j in range(pearson_matrix.shape[1]):
            ax.text(j, i, f"{pearson_matrix.values[i, j]:.2f}", ha="center", va="center", color="white", fontsize=8)
    fig.colorbar(im, ax=ax, shrink=0.85, label="Pearson R")
    if title:
        ax.set_title(title)
    return _save(fig, out_path)


def plot_comparison_heatmap(
    pred_dict: Dict[str, pd.DataFrame],
    out_path: str,
    title: Optional[str] = None,
) -> Dict[str, str]:
    """Side-by-side heatmaps of estimated proportions for each method.

    pred_dict values are (n_samples, n_celltypes) DataFrames; rows must be aligned.
    """
    methods = list(pred_dict.keys())
    cts = list(next(iter(pred_dict.values())).columns)
    fig, axes = plt.subplots(1, len(methods), figsize=(2.6 * len(methods) + 1.0, 4.5), sharey=True)
    if len(methods) == 1:
        axes = [axes]
    for ax, m in zip(axes, methods):
        df = pred_dict[m]
        im = ax.imshow(df.values, aspect="auto", cmap="viridis", vmin=0, vmax=1)
        ax.set_xticks(range(len(cts)))
        ax.set_xticklabels(cts, rotation=45, fontsize=8)
        ax.set_yticks([])
        ax.set_title(m)
    fig.colorbar(im, ax=axes[-1], shrink=0.7, label="proportion")
    if title:
        fig.suptitle(title, y=1.02)
    return _save(fig, out_path)

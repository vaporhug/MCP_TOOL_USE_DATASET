"""Pseudobulk generation for benchmarking deconvolution methods.

Two construction modes:
- Per-subject sum: sum every cell of a single subject for a "real" pseudobulk
  with subject-specific cell type proportions (the MuSiC-paper benchmark mode).
- Synthetic Dirichlet: draw cell-type proportions from a Dirichlet, then sample
  cells to that composition and sum.
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd


def per_subject_pseudobulk(
    sc_counts: pd.DataFrame,
    sc_pheno: pd.DataFrame,
    celltypes: Optional[List[str]] = None,
    exclude_subjects: Optional[List[str]] = None,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Construct one pseudobulk per subject by summing all cells of that subject.

    The true cell type proportions are computed from the cell-type composition
    of each subject (cell counts of type k divided by total cells of subject).

    Args:
        sc_counts: (n_genes, n_cells).
        sc_pheno: must contain ``cellID``, ``cellType``, ``sampleID``.
        celltypes: cell types to track; missing ones get 0 proportion.
        exclude_subjects: subjects to skip (useful for leave-one-out tests).
    Returns:
        Tuple (pseudobulk_counts, true_props):
        - pseudobulk_counts: DataFrame (n_genes, n_subjects), summed counts.
        - true_props: DataFrame (n_subjects, n_celltypes) with row-sum = 1.
    """
    if celltypes is None:
        celltypes = sorted(sc_pheno["cellType"].astype(str).unique().tolist())
    if exclude_subjects is None:
        exclude_subjects = []
    pheno = sc_pheno.set_index("cellID")
    subjects = [
        s for s in sorted(pheno["sampleID"].astype(str).unique().tolist())
        if s not in set(exclude_subjects)
    ]

    pb_cols = []
    prop_rows = []
    for sid in subjects:
        cells = pheno[pheno["sampleID"].astype(str) == sid].index
        cells = [c for c in cells if c in sc_counts.columns]
        if not cells:
            continue
        sub = sc_counts[cells]
        pb_cols.append(sub.sum(axis=1).rename(sid))
        ct_series = pheno.loc[cells, "cellType"].astype(str)
        # proportions among the requested cell types
        counts = ct_series.value_counts()
        n = float(counts.reindex(celltypes).fillna(0).sum())
        if n == 0:
            continue
        props = counts.reindex(celltypes).fillna(0) / n
        props.name = sid
        prop_rows.append(props)
    if not pb_cols:
        return pd.DataFrame(index=sc_counts.index), pd.DataFrame(columns=celltypes)
    pb = pd.concat(pb_cols, axis=1)
    props = pd.concat(prop_rows, axis=1).T
    props = props[celltypes]
    return pb, props


def synthetic_pseudobulk(
    sc_counts: pd.DataFrame,
    sc_pheno: pd.DataFrame,
    n_samples: int = 20,
    cells_per_sample: int = 200,
    alpha: Optional[List[float]] = None,
    celltypes: Optional[List[str]] = None,
    seed: int = 0,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Generate synthetic pseudobulks with Dirichlet-sampled true proportions.

    Args:
        sc_counts: (n_genes, n_cells) raw counts.
        sc_pheno: phenotype with cellID, cellType columns.
        n_samples: number of pseudobulks to draw.
        cells_per_sample: total cells per pseudobulk.
        alpha: Dirichlet concentration; if None, uses uniform alpha = 1.
        celltypes: cell types to include.
        seed: RNG seed.
    Returns:
        (pseudobulk_counts, true_props): same shape conventions as
        ``per_subject_pseudobulk``.
    """
    if celltypes is None:
        celltypes = sorted(sc_pheno["cellType"].astype(str).unique().tolist())
    K = len(celltypes)
    if alpha is None:
        alpha = [1.0] * K
    rng = np.random.default_rng(int(seed))

    pmap = sc_pheno.set_index("cellID")["cellType"].astype(str)
    pools = {ct: [c for c in pmap[pmap == ct].index if c in sc_counts.columns] for ct in celltypes}

    pb_cols = []
    prop_rows = []
    for i in range(int(n_samples)):
        p = rng.dirichlet(np.asarray(alpha, dtype=float))
        counts = np.floor(p * int(cells_per_sample)).astype(int)
        counts[-1] += int(cells_per_sample) - counts.sum()
        cells_picked: List[str] = []
        for ct, k in zip(celltypes, counts):
            if k <= 0 or len(pools[ct]) == 0:
                continue
            cells_picked.extend(rng.choice(pools[ct], size=int(k), replace=True).tolist())
        if not cells_picked:
            continue
        col = sc_counts[cells_picked].sum(axis=1).rename(f"pb_{i}")
        pb_cols.append(col)
        prop_rows.append(pd.Series(p, index=celltypes, name=f"pb_{i}"))
    pb = pd.concat(pb_cols, axis=1)
    props = pd.concat(prop_rows, axis=1).T[celltypes]
    return pb, props


def leave_one_out_pseudobulk(
    sc_counts: pd.DataFrame,
    sc_pheno: pd.DataFrame,
    held_subject: str,
    celltypes: Optional[List[str]] = None,
) -> Tuple[pd.Series, pd.Series, pd.DataFrame, pd.DataFrame]:
    """Build a leave-one-out evaluation set.

    Returns the pseudobulk and true proportions for the held-out subject,
    along with the remaining single-cell counts and pheno for use as
    reference. Mirrors Fig. 2a of the MuSiC paper.

    Returns:
        (held_bulk_vec, held_props, ref_counts, ref_pheno)
    """
    if celltypes is None:
        celltypes = sorted(sc_pheno["cellType"].astype(str).unique().tolist())
    pheno = sc_pheno.copy()
    pheno["sampleID"] = pheno["sampleID"].astype(str)
    held_cells = pheno[pheno["sampleID"] == str(held_subject)]["cellID"].tolist()
    held_cells = [c for c in held_cells if c in sc_counts.columns]
    if not held_cells:
        raise ValueError(f"No cells for subject {held_subject}")
    held_bulk = sc_counts[held_cells].sum(axis=1)
    ct_series = pheno.set_index("cellID").loc[held_cells, "cellType"].astype(str)
    counts = ct_series.value_counts()
    n = float(counts.reindex(celltypes).fillna(0).sum())
    held_props = counts.reindex(celltypes).fillna(0) / max(n, 1.0)

    ref_pheno = pheno[pheno["sampleID"] != str(held_subject)]
    keep_cells = [c for c in ref_pheno["cellID"].tolist() if c in sc_counts.columns]
    ref_counts = sc_counts[keep_cells]
    ref_pheno = ref_pheno[ref_pheno["cellID"].isin(keep_cells)].reset_index(drop=True)
    return held_bulk, held_props.astype(float), ref_counts, ref_pheno

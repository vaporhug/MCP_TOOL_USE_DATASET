"""Signature matrix construction and marker-gene selection.

Provides primitives to build a cell-type by gene signature matrix from a
single-cell reference, and to score genes for marker-ness using fold change
or one-vs-rest log fold change. No sklearn / scipy needed.
"""

from __future__ import annotations

from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd


def build_signature_matrix(
    sc_counts: pd.DataFrame,
    sc_pheno: pd.DataFrame,
    celltypes: Optional[List[str]] = None,
    normalize_cells: bool = True,
) -> pd.DataFrame:
    """Build the gene x cell_type signature matrix as the per-cell-type mean.

    For each cell type, this CPM-normalizes the cells (so each cell column
    sums to 1e6 if `normalize_cells=True`), then averages across cells of
    that type. The resulting signature column is the expected expression
    profile of one cell of that type.

    Args:
        sc_counts: (n_genes, n_cells) raw counts.
        sc_pheno: phenotype with ``cellID`` and ``cellType`` columns.
        celltypes: optional ordered list of cell types to include.
        normalize_cells: whether to CPM-normalize each cell first.
    Returns:
        DataFrame of shape (n_genes, n_celltypes).
    """
    if celltypes is None:
        celltypes = sorted(sc_pheno["cellType"].astype(str).unique().tolist())

    if normalize_cells:
        col_sums = sc_counts.sum(axis=0).replace(0, np.nan)
        Xn = sc_counts.divide(col_sums, axis=1) * 1e6
        Xn = Xn.fillna(0.0)
    else:
        Xn = sc_counts.astype(float)

    pmap = sc_pheno.set_index("cellID")["cellType"].astype(str)
    sig = pd.DataFrame(0.0, index=sc_counts.index, columns=celltypes)
    for ct in celltypes:
        cells = pmap[pmap == ct].index
        cells = [c for c in cells if c in Xn.columns]
        if not cells:
            continue
        sig[ct] = Xn[cells].mean(axis=1).values
    return sig


def cell_type_mean_library_size(
    sc_counts: pd.DataFrame, sc_pheno: pd.DataFrame, celltypes: Optional[List[str]] = None
) -> pd.Series:
    """Mean raw total counts per cell, per cell type.

    Used as the cell size factor S_k in the MuSiC framework: bigger cells
    contribute more mRNA to the bulk. Returns a Series indexed by cell type.
    """
    if celltypes is None:
        celltypes = sorted(sc_pheno["cellType"].astype(str).unique().tolist())
    pmap = sc_pheno.set_index("cellID")["cellType"].astype(str)
    cell_libs = sc_counts.sum(axis=0)
    out = {}
    for ct in celltypes:
        cells = pmap[pmap == ct].index
        cells = [c for c in cells if c in cell_libs.index]
        out[ct] = float(cell_libs[cells].mean()) if cells else 0.0
    return pd.Series(out, dtype=float)


def cell_type_relative_abundance(
    sc_counts: pd.DataFrame, sc_pheno: pd.DataFrame, celltypes: Optional[List[str]] = None
) -> pd.DataFrame:
    """MuSiC-style theta_g^k: relative abundance of gene g in cell type k.

    For each cell type, sums raw counts across all cells of that type, then
    divides by the total counts of that pool. Each column sums to 1.
    """
    if celltypes is None:
        celltypes = sorted(sc_pheno["cellType"].astype(str).unique().tolist())
    pmap = sc_pheno.set_index("cellID")["cellType"].astype(str)
    out = pd.DataFrame(0.0, index=sc_counts.index, columns=celltypes)
    for ct in celltypes:
        cells = pmap[pmap == ct].index
        cells = [c for c in cells if c in sc_counts.columns]
        if not cells:
            continue
        pool = sc_counts[cells].sum(axis=1)
        s = pool.sum()
        if s > 0:
            out[ct] = pool.values / s
    return out


def select_markers_by_fold_change(
    sig: pd.DataFrame,
    n_top: int = 50,
    min_mean: float = 1.0,
) -> Dict[str, List[str]]:
    """One-vs-rest fold change marker selection per cell type.

    For each cell type, ranks genes by `mean_in_ct / max_mean_in_other_cts`
    and returns the top `n_top` whose mean expression in the cell type
    exceeds `min_mean` (in CPM units). Only positive markers are selected.

    Args:
        sig: gene x cell_type signature matrix (CPM-mean).
        n_top: top N markers per cell type.
        min_mean: minimum CPM in the target cell type to be eligible.
    Returns:
        Dict cell_type -> list of marker gene symbols (strings).
    """
    out: Dict[str, List[str]] = {}
    cts = list(sig.columns)
    for ct in cts:
        in_ct = sig[ct]
        rest = sig.drop(columns=ct)
        max_other = rest.max(axis=1).replace(0, 1e-9)
        fc = in_ct / max_other
        eligible = in_ct >= float(min_mean)
        ranked = fc[eligible].sort_values(ascending=False)
        out[ct] = ranked.head(int(n_top)).index.tolist()
    return out


def union_markers(markers_per_ct: Dict[str, List[str]]) -> List[str]:
    """Return the sorted union of all per-cell-type marker lists."""
    s = set()
    for v in markers_per_ct.values():
        s.update(v)
    return sorted(s)


def cross_subject_variance(
    sc_counts: pd.DataFrame,
    sc_pheno: pd.DataFrame,
    celltype: str,
) -> pd.Series:
    """Variance across subjects of the per-subject mean expression for a cell type.

    For a single cell type, compute for each subject the within-subject mean
    (over the cells of that type belonging to that subject), then compute the
    variance of these subject-level means across subjects. Output is a
    per-gene variance Series. Required by the MuSiC weighting scheme
    (low cross-subject variance => informative gene).
    """
    pmap = sc_pheno.set_index("cellID")
    smap = pmap["sampleID"].astype(str)
    cmap = pmap["cellType"].astype(str)
    subj_means = []
    for sid in sorted(smap.unique()):
        cells = pmap[(smap == sid) & (cmap == str(celltype))].index
        cells = [c for c in cells if c in sc_counts.columns]
        if not cells:
            continue
        # CPM-normalize within these cells, then mean
        sub = sc_counts[cells]
        col_sums = sub.sum(axis=0).replace(0, np.nan)
        sub_cpm = sub.divide(col_sums, axis=1) * 1e6
        sub_cpm = sub_cpm.fillna(0.0)
        subj_means.append(sub_cpm.mean(axis=1).rename(sid))
    if not subj_means:
        return pd.Series(0.0, index=sc_counts.index)
    M = pd.concat(subj_means, axis=1)
    return M.var(axis=1).fillna(0.0)


def music_gene_weights(
    sc_counts: pd.DataFrame,
    sc_pheno: pd.DataFrame,
    celltypes: Optional[List[str]] = None,
    eps: float = 1e-6,
) -> pd.Series:
    """MuSiC-style cross-subject consistency weights.

    For each gene, compute the mean cross-subject variance of CPM-mean
    expression across all cell types, and convert to a non-negative weight
    1 / (eps + mean_cross_subject_variance). Genes consistent across
    subjects within each cell type get higher weights.
    """
    if celltypes is None:
        celltypes = sorted(sc_pheno["cellType"].astype(str).unique().tolist())
    var_list = [
        cross_subject_variance(sc_counts, sc_pheno, ct).reindex(sc_counts.index, fill_value=0.0)
        for ct in celltypes
    ]
    M = pd.concat(var_list, axis=1)
    avg_var = M.mean(axis=1)
    return 1.0 / (float(eps) + avg_var)

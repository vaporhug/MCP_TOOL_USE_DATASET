"""Evaluation metrics for cell-type deconvolution.

Implements the three metrics reported in the target paper (RMSD, mAD, R)
plus per-cell-type and per-sample variants and a small statistics module.

Note: pearson_test uses scipy.stats.pearsonr for the two-sided t-test
p-value; the remaining numeric routines depend only on numpy.
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd


# -----------------------------------------------------------------------------
# Statistics primitives (pure numpy)
# -----------------------------------------------------------------------------


def pearson_r(x: np.ndarray, y: np.ndarray) -> float:
    """Pearson correlation coefficient. Returns 0.0 if either is constant."""
    x = np.asarray(x, dtype=float).ravel()
    y = np.asarray(y, dtype=float).ravel()
    mask = np.isfinite(x) & np.isfinite(y)
    x, y = x[mask], y[mask]
    if x.size < 2:
        return 0.0
    sx = x.std()
    sy = y.std()
    if sx == 0 or sy == 0:
        return 0.0
    return float(((x - x.mean()) * (y - y.mean())).mean() / (sx * sy))


def pearson_test(x: np.ndarray, y: np.ndarray) -> Tuple[float, float]:
    """Two-sided p-value for Pearson r (delegates to scipy.stats.pearsonr).

    Returns (r, p_value).
    """
    from scipy import stats
    xa = np.asarray(x, dtype=np.float64)
    ya = np.asarray(y, dtype=np.float64)
    mask = np.isfinite(xa) & np.isfinite(ya)
    if int(mask.sum()) < 3:
        return float(pearson_r(xa, ya)), 1.0
    res = stats.pearsonr(xa[mask], ya[mask])
    return float(res.statistic), float(res.pvalue)


def _two_sided_t_pvalue(t: float, df: int) -> float:
    """Two-sided Student-t p-value computed via the regularized incomplete beta."""
    if df <= 0:
        return 1.0
    x = float(df) / (df + t * t)
    a = 0.5 * df
    b = 0.5
    p = _betainc_regularized(a, b, x)
    return min(max(float(p), 0.0), 1.0)


def _betainc_regularized(a: float, b: float, x: float) -> float:
    """Regularized incomplete beta I_x(a,b) via continued fraction, for x in [0,1]."""
    if x <= 0:
        return 0.0
    if x >= 1:
        return 1.0
    lbeta = (
        _gammaln(a + b) - _gammaln(a) - _gammaln(b)
    ) + a * np.log(x) + b * np.log(1.0 - x)
    front = np.exp(lbeta) / a
    if x < (a + 1) / (a + b + 2):
        return float(front * _betacf(a, b, x))
    return float(1.0 - front * _betacf(b, a, 1.0 - x) * (a / b))


def _betacf(a: float, b: float, x: float, max_iter: int = 200, eps: float = 3e-12) -> float:
    """Continued-fraction expansion for the incomplete beta function."""
    qab = a + b
    qap = a + 1.0
    qam = a - 1.0
    c = 1.0
    d = 1.0 - qab * x / qap
    if abs(d) < 1e-30:
        d = 1e-30
    d = 1.0 / d
    h = d
    for m in range(1, max_iter + 1):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d
        if abs(d) < 1e-30:
            d = 1e-30
        c = 1.0 + aa / c
        if abs(c) < 1e-30:
            c = 1e-30
        d = 1.0 / d
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1.0 + aa * d
        if abs(d) < 1e-30:
            d = 1e-30
        c = 1.0 + aa / c
        if abs(c) < 1e-30:
            c = 1e-30
        d = 1.0 / d
        delta = d * c
        h *= delta
        if abs(delta - 1.0) < eps:
            break
    return h


def _gammaln(x: float) -> float:
    """Lanczos approximation to log Gamma(x); valid for x > 0."""
    g = 7
    p = [
        0.99999999999980993,
        676.5203681218851,
        -1259.1392167224028,
        771.32342877765313,
        -176.61502916214059,
        12.507343278686905,
        -0.13857109526572012,
        9.9843695780195716e-6,
        1.5056327351493116e-7,
    ]
    if x < 0.5:
        return float(np.log(np.pi / np.sin(np.pi * x)) - _gammaln(1.0 - x))
    x -= 1.0
    a = p[0]
    t = x + g + 0.5
    for i in range(1, g + 2):
        a += p[i] / (x + i)
    return float(0.5 * np.log(2.0 * np.pi) + (x + 0.5) * np.log(t) - t + np.log(a))


# -----------------------------------------------------------------------------
# Deconvolution-specific metrics
# -----------------------------------------------------------------------------


def rmsd(true_props: pd.DataFrame, pred_props: pd.DataFrame) -> float:
    """Overall root mean squared deviation across all (sample, cell-type) cells.

    Args:
        true_props: (n_samples, n_celltypes) ground-truth proportions.
        pred_props: same shape, predicted proportions.
    """
    a, b = _align(true_props, pred_props)
    diff = (a.values - b.values).ravel()
    return float(np.sqrt(np.mean(diff * diff)))


def mad(true_props: pd.DataFrame, pred_props: pd.DataFrame) -> float:
    """Overall mean absolute deviation across all (sample, cell-type) cells."""
    a, b = _align(true_props, pred_props)
    return float(np.mean(np.abs(a.values - b.values)))


def overall_pearson(true_props: pd.DataFrame, pred_props: pd.DataFrame) -> float:
    """Pearson R across the flattened (sample x cell-type) tables."""
    a, b = _align(true_props, pred_props)
    return float(pearson_r(a.values.ravel(), b.values.ravel()))


def per_celltype_metrics(
    true_props: pd.DataFrame, pred_props: pd.DataFrame
) -> pd.DataFrame:
    """Compute per cell-type RMSD, mAD and Pearson R across samples.

    Returns a DataFrame indexed by cell type with columns rmsd, mad, pearson.
    """
    a, b = _align(true_props, pred_props)
    rows = {}
    for ct in a.columns:
        d = a[ct].values - b[ct].values
        rows[ct] = {
            "rmsd": float(np.sqrt(np.mean(d * d))),
            "mad": float(np.mean(np.abs(d))),
            "pearson": float(pearson_r(a[ct].values, b[ct].values)),
        }
    return pd.DataFrame(rows).T[["rmsd", "mad", "pearson"]]


def per_sample_metrics(
    true_props: pd.DataFrame, pred_props: pd.DataFrame
) -> pd.DataFrame:
    """Compute per-sample RMSD, mAD and Pearson across cell types.

    Returns a DataFrame indexed by sample id.
    """
    a, b = _align(true_props, pred_props)
    rows = {}
    for s in a.index:
        d = a.loc[s].values - b.loc[s].values
        rows[s] = {
            "rmsd": float(np.sqrt(np.mean(d * d))),
            "mad": float(np.mean(np.abs(d))),
            "pearson": float(pearson_r(a.loc[s].values, b.loc[s].values)),
        }
    return pd.DataFrame(rows).T[["rmsd", "mad", "pearson"]]


def summarize_methods(
    true_props: pd.DataFrame, predictions: Dict[str, pd.DataFrame]
) -> pd.DataFrame:
    """Make a summary table of overall RMSD/mAD/R for several methods.

    Args:
        true_props: ground-truth.
        predictions: dict ``method_name -> predicted_props_df``.
    """
    rows = {}
    for name, pred in predictions.items():
        rows[name] = {
            "rmsd": rmsd(true_props, pred),
            "mad": mad(true_props, pred),
            "pearson": overall_pearson(true_props, pred),
        }
    return pd.DataFrame(rows).T[["rmsd", "mad", "pearson"]]


def linear_regression(x: np.ndarray, y: np.ndarray) -> Dict[str, float]:
    """Simple OLS y ~ a + b*x; returns slope, intercept, r, p, n.

    Used to test the beta-cell-vs-HbA1c association reported in the paper.
    """
    x = np.asarray(x, dtype=float).ravel()
    y = np.asarray(y, dtype=float).ravel()
    mask = np.isfinite(x) & np.isfinite(y)
    x, y = x[mask], y[mask]
    n = x.size
    if n < 3:
        return {"slope": 0.0, "intercept": 0.0, "r": 0.0, "p": 1.0, "n": float(n)}
    xm, ym = x.mean(), y.mean()
    sxx = ((x - xm) ** 2).sum()
    sxy = ((x - xm) * (y - ym)).sum()
    slope = sxy / sxx if sxx > 0 else 0.0
    intercept = ym - slope * xm
    r, p = pearson_test(x, y)
    return {"slope": float(slope), "intercept": float(intercept), "r": float(r), "p": float(p), "n": float(n)}


def _align(a: pd.DataFrame, b: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Align two proportion tables on shared rows (samples) and columns (cell types)."""
    rows = a.index.intersection(b.index)
    cols = a.columns.intersection(b.columns)
    return a.loc[rows, cols], b.loc[rows, cols]

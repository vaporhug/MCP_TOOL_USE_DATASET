"""Deconvolution solvers: NNLS (from scratch), weighted NNLS (simplified
MuSiC-style approximation), a 'SVR-style' linear-LAD stand-in baseline
(NOT a true nu-SVR / CIBERSORT implementation), and a ridge baseline.

All solvers operate on a (n_genes, n_celltypes) signature matrix A and a
(n_genes,) bulk vector y, returning a non-negative cell-type proportion
vector that sums to 1 (after normalization). No scipy / sklearn imports.

The "MuSiC-style" weighted NNLS bundled here is a two-stage simplification
of the paper's full algorithm; the two stages are intentionally separated:

  (1) Initial cross-subject weight pass (SINGLE pass, not iterative).
      tools.signature.music_gene_weights computes a per-gene cross-subject
      consistency weight once over the 6 reference subjects and supplies
      it as the starting weight vector w0 to music_deconvolve_one (used as
      iteration 1's gene_weights argument). This is the part that
      approximates the cross-subject term of the paper's MuSiC weighting.

  (2) Subsequent residual-variance refinement (ITERATIVE, n_iter-1 passes).
      For iterations 2..n_iter, w0 is multiplicatively rescaled by
      1 / (eps + residual_g^2) using the current model residuals; this is
      a per-gene residual-variance refinement that proxies the
      sum_k p_k^2 * sigma_gk^2 term in MuSiC Eq. 10, but only at the
      per-gene level (NOT the full cross-subject + cross-cell-type
      covariance structure of MuSiC Eq. 10).

The bundle does NOT recompute cross-subject variance inside the loop, and
it does NOT implement recursive tree-guided deconvolution for collinear
cell types. It is intended only as a qualitative contrast to plain NNLS.
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd


# -----------------------------------------------------------------------------
# Core NNLS solver (Lawson-Hanson active-set, from scratch)
# -----------------------------------------------------------------------------


def nnls_solve(
    A: np.ndarray, b: np.ndarray, max_iter: int = 200, tol: float = 1e-8
) -> np.ndarray:
    """Solve min_x ||A x - b||_2 subject to x >= 0 (Lawson-Hanson 1974).

    From-scratch implementation that does not depend on scipy. Runs in O(n^3)
    in the number of columns of A. Suitable for small (<= a few hundred)
    column counts, which is the case for cell-type deconvolution.
    """
    A = np.asarray(A, dtype=float)
    b = np.asarray(b, dtype=float).ravel()
    m, n = A.shape
    x = np.zeros(n, dtype=float)
    P = np.zeros(n, dtype=bool)  # passive set
    R = np.ones(n, dtype=bool)  # active set
    w = A.T @ (b - A @ x)
    it = 0
    while R.any() and w[R].max() > tol and it < max_iter:
        it += 1
        # add the variable with largest gradient to the passive set
        idx_R = np.where(R)[0]
        j = idx_R[np.argmax(w[R])]
        P[j] = True
        R[j] = False
        # solve unconstrained LSQ on passive variables
        s = np.zeros(n, dtype=float)
        Ap = A[:, P]
        try:
            sp, *_ = np.linalg.lstsq(Ap, b, rcond=None)
        except np.linalg.LinAlgError:
            sp = np.linalg.pinv(Ap) @ b
        s[P] = sp
        inner = 0
        while s[P].min() <= 0 and inner < 5 * max_iter:
            inner += 1
            mask = (s <= 0) & P
            if not mask.any():
                break
            ratios = x[mask] / (x[mask] - s[mask] + 1e-15)
            alpha = ratios.min()
            x = x + alpha * (s - x)
            # remove zeros from P
            P_zero = P & (x <= tol)
            P &= ~P_zero
            R |= P_zero
            x[~P] = 0.0
            s = np.zeros(n, dtype=float)
            Ap = A[:, P]
            if Ap.shape[1] == 0:
                break
            try:
                sp, *_ = np.linalg.lstsq(Ap, b, rcond=None)
            except np.linalg.LinAlgError:
                sp = np.linalg.pinv(Ap) @ b
            s[P] = sp
        x = s
        x[~P] = 0.0
        w = A.T @ (b - A @ x)
    return np.maximum(x, 0.0)


# -----------------------------------------------------------------------------
# Convenience wrappers operating on DataFrames
# -----------------------------------------------------------------------------


def normalize_proportions(p: np.ndarray) -> np.ndarray:
    """Project a non-negative vector onto the simplex by sum-normalizing."""
    p = np.maximum(np.asarray(p, dtype=float), 0.0)
    s = p.sum()
    return (p / s) if s > 0 else p


def nnls_deconvolve_one(
    sig: pd.DataFrame, bulk_vec: pd.Series, scale_by_celltype: Optional[pd.Series] = None
) -> pd.Series:
    """Deconvolve one bulk sample by NNLS.

    Aligns gene order between signature and bulk vector, solves NNLS, then
    optionally divides by per-cell-type cell size factor S_k and renormalizes
    so that estimated proportions sum to 1.

    Args:
        sig: gene x cell_type signature matrix.
        bulk_vec: 1-D Series indexed by gene (bulk CPM or counts).
        scale_by_celltype: optional Series of S_k (cell size factor) per cell type.
    Returns:
        Series of length n_celltypes summing to 1.
    """
    common = sig.index.intersection(bulk_vec.index)
    A = sig.loc[common].values
    y = bulk_vec.loc[common].values.astype(float)
    x = nnls_solve(A, y)
    if scale_by_celltype is not None:
        scale = scale_by_celltype.reindex(sig.columns).fillna(1.0).values
        scale = np.where(scale > 0, scale, 1.0)
        x = x / scale
    p = normalize_proportions(x)
    return pd.Series(p, index=sig.columns)


def nnls_deconvolve_matrix(
    sig: pd.DataFrame,
    bulk: pd.DataFrame,
    scale_by_celltype: Optional[pd.Series] = None,
) -> pd.DataFrame:
    """Apply NNLS deconvolution to every column of `bulk`.

    Returns a DataFrame indexed by sample (bulk columns), with one column
    per cell type.
    """
    samples = list(bulk.columns)
    rows = [nnls_deconvolve_one(sig, bulk[s], scale_by_celltype) for s in samples]
    return pd.DataFrame(rows, index=samples)


# -----------------------------------------------------------------------------
# Weighted NNLS (MuSiC-like)
# -----------------------------------------------------------------------------


def weighted_nnls_solve(
    A: np.ndarray, b: np.ndarray, w: np.ndarray, max_iter: int = 200, tol: float = 1e-8
) -> np.ndarray:
    """Solve min_x sum_g w_g (A x - b)_g^2 subject to x >= 0.

    This is implemented by re-scaling A and b by sqrt(w) and calling NNLS.
    """
    w = np.asarray(w, dtype=float).ravel()
    w = np.maximum(w, 0.0)
    sw = np.sqrt(w + 1e-12)
    return nnls_solve(A * sw[:, None], b * sw, max_iter=max_iter, tol=tol)


def music_deconvolve_one(
    sig: pd.DataFrame,
    bulk_vec: pd.Series,
    gene_weights: pd.Series,
    cell_size: Optional[pd.Series] = None,
    n_iter: int = 5,
) -> pd.Series:
    """Iteratively re-weighted NNLS in the spirit of MuSiC (single sample).

    The first iteration uses `gene_weights` as static weights. Iterations
    2..n_iter multiplicatively refine the weights by 1 / (eps + r_g^2),
    where r_g = y_g - (A @ x)_g is the per-gene residual after the
    previous solve. This is a residual-variance PROXY for MuSiC's full
    variance term sum_k p_k^2 sigma_gk^2 — it does NOT compute the
    per-cell-type cross-subject sigma_gk^2 or the proportion-weighted
    sum, and is therefore an approximation of MuSiC Eq. 10 rather than
    the literal formula.

    Args:
        sig: gene x cell_type signature matrix (CPM mean).
        bulk_vec: 1-D Series indexed by gene.
        gene_weights: per-gene cross-subject consistency weights.
        cell_size: optional per-cell-type cell size factor (S_k).
        n_iter: number of re-weighting iterations.
    """
    common = sig.index.intersection(bulk_vec.index).intersection(gene_weights.index)
    A = sig.loc[common].values
    y = bulk_vec.loc[common].values.astype(float)
    w0 = gene_weights.loc[common].values.astype(float)
    w = w0.copy()
    x = weighted_nnls_solve(A, y, w)
    for _ in range(int(n_iter) - 1):
        # estimate residual variance per gene (proxy for MuSiC's sigma^2_gk*p_k^2 term)
        r = y - A @ x
        var_g = r * r + 1e-9
        w = w0 / var_g
        # avoid extreme weights
        med = float(np.median(w[w > 0])) if (w > 0).any() else 1.0
        w = np.minimum(w, 1e3 * med)
        x = weighted_nnls_solve(A, y, w)
    if cell_size is not None:
        scale = cell_size.reindex(sig.columns).fillna(1.0).values
        scale = np.where(scale > 0, scale, 1.0)
        x = x / scale
    p = normalize_proportions(x)
    return pd.Series(p, index=sig.columns)


def music_deconvolve_matrix(
    sig: pd.DataFrame,
    bulk: pd.DataFrame,
    gene_weights: pd.Series,
    cell_size: Optional[pd.Series] = None,
    n_iter: int = 5,
) -> pd.DataFrame:
    """Apply MuSiC-like iterative weighted NNLS to every bulk sample column."""
    samples = list(bulk.columns)
    rows = [
        music_deconvolve_one(sig, bulk[s], gene_weights, cell_size, n_iter=n_iter)
        for s in samples
    ]
    return pd.DataFrame(rows, index=samples)


# -----------------------------------------------------------------------------
# Ridge baseline (analytic, from-scratch)
# -----------------------------------------------------------------------------


def ridge_deconvolve_one(
    sig: pd.DataFrame, bulk_vec: pd.Series, alpha: float = 1.0
) -> pd.Series:
    """Closed-form ridge regression x = (A'A + alpha I)^-1 A' y, then clipped to >=0.

    Used as a non-MuSiC linear baseline.
    """
    common = sig.index.intersection(bulk_vec.index)
    A = sig.loc[common].values
    y = bulk_vec.loc[common].values.astype(float)
    n = A.shape[1]
    AtA = A.T @ A
    Aty = A.T @ y
    x = np.linalg.solve(AtA + float(alpha) * np.eye(n), Aty)
    p = normalize_proportions(x)
    return pd.Series(p, index=sig.columns)


def ridge_deconvolve_matrix(
    sig: pd.DataFrame, bulk: pd.DataFrame, alpha: float = 1.0
) -> pd.DataFrame:
    """Apply ridge to every bulk sample column."""
    samples = list(bulk.columns)
    rows = [ridge_deconvolve_one(sig, bulk[s], alpha=float(alpha)) for s in samples]
    return pd.DataFrame(rows, index=samples)


# -----------------------------------------------------------------------------
# Linear least-absolute-deviation (LAD) baseline -- a "SVR-style" stand-in.
# NOTE: This is NOT a true nu-SVR / CIBERSORT implementation. It is a primal
# subgradient solver on the L1 (least-absolute-deviation) loss with non-
# negativity clipping, used only as a contrast against NNLS / W-NNLS / ridge.
# The ``nu`` and ``C`` parameters are accepted for API compatibility only and
# are NOT used in the solver. Faithful nu-SVR/CIBERSORT reproduction would
# require an epsilon-insensitive support-vector formulation with a true QP
# solver, which is outside the scope of this simplified bundle.
# -----------------------------------------------------------------------------


def _lad_proportions(
    A: np.ndarray, y: np.ndarray, max_iter: int = 500, lr: float = 1e-4
) -> np.ndarray:
    """Non-negative linear least-absolute-deviation (LAD) regression via
    primal subgradient descent.

    Returned vector is non-negative but not normalised; the calling wrapper
    normalises to sum to one to interpret the output as cell-type fractions.
    This is the simplified linear-LS / LAD stand-in described in the task
    instruction's Simplified-task scope -- not a true nu-SVR.
    """
    A = np.asarray(A, dtype=float)
    y = np.asarray(y, dtype=float).ravel()
    n_features = A.shape[1]
    x = np.zeros(n_features)
    for _ in range(int(max_iter)):
        r = A @ x - y
        g_x = A.T @ np.sign(r) / max(len(y), 1)
        x = x - lr * g_x
        x = np.maximum(x, 0.0)
    return x


def svr_deconvolve_one(
    sig: pd.DataFrame, bulk_vec: pd.Series, nu: float = 0.5, C: float = 1.0
) -> pd.Series:
    """Simplified 'SVR-style' (LAD) deconvolution wrapper; clips to non-negative
    and normalises. ``nu``/``C`` are accepted for backwards-compatible API
    but the solver uses neither (see module-level note)."""
    del nu, C  # unused; documented in module banner
    common = sig.index.intersection(bulk_vec.index)
    A = sig.loc[common].values
    y = bulk_vec.loc[common].values.astype(float)
    x = _lad_proportions(A, y)
    p = normalize_proportions(x)
    return pd.Series(p, index=sig.columns)


def svr_deconvolve_matrix(
    sig: pd.DataFrame, bulk: pd.DataFrame, nu: float = 0.5, C: float = 1.0
) -> pd.DataFrame:
    """Apply simplified 'SVR-style' (LAD) deconvolution to every bulk sample.
    ``nu``/``C`` are unused; kept for backwards-compatible signatures."""
    del nu, C
    samples = list(bulk.columns)
    rows = [svr_deconvolve_one(sig, bulk[s]) for s in samples]
    return pd.DataFrame(rows, index=samples)

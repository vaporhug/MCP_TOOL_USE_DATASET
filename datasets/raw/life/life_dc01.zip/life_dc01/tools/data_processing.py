"""I/O and basic table primitives for bulk-from-single-cell deconvolution.

Loads the count matrices and phenotype tables, with helpers for standard
preprocessing (CPM normalization, log1p, gene filtering) shared across the
deconvolution pipeline. Pure pandas / numpy; no scipy / sklearn.
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

# Canonical cell type column order used for all CSV deliverables (proportions tables, beta vs HbA1c regression stats, etc.).
# Agents MUST use this order rather than relying on dict/set ordering.
CELLTYPE_ORDER = ["acinar", "alpha", "beta", "delta", "gamma", "ductal"]



def load_counts_table(path: str) -> pd.DataFrame:
    """Load a counts CSV indexed by gene symbol.

    The first column is treated as the gene index. Returns a DataFrame
    with shape (n_genes, n_samples_or_cells), values are integer / float.
    """
    df = pd.read_csv(path, index_col=0)
    df.index = df.index.astype(str)
    return df


def load_phenotype(path: str) -> pd.DataFrame:
    """Load a phenotype CSV. No special index. Useful columns vary per file."""
    return pd.read_csv(path)


def cpm_normalize(counts: pd.DataFrame) -> pd.DataFrame:
    """Per-column CPM (counts per million). Columns sum to 1e6.

    Note: the target paper (Wang et al. 2019, Methods) cautions that
    proportion deconvolution should NOT be applied to TPM input because TPM
    divides by gene length and breaks cross-cell-type comparability. The
    shipped pipeline uses CPM (no gene-length normalization) for both
    single-cell signatures and bulk samples, consistent with that caution.

    Args:
        counts: (n_genes, n_samples) raw counts.
    Returns:
        (n_genes, n_samples) CPM-normalized DataFrame.
    """
    col_sums = counts.sum(axis=0).replace(0, np.nan)
    out = counts.divide(col_sums, axis=1) * 1e6
    return out.fillna(0.0)


def log1p_transform(matrix: pd.DataFrame) -> pd.DataFrame:
    """log1p transform (natural log of 1 + x). Common pre-processing for plotting."""
    return np.log1p(matrix)


def filter_genes_by_min_cells(
    counts: pd.DataFrame, min_cells: int = 10
) -> pd.DataFrame:
    """Keep genes detected (counts > 0) in at least `min_cells` columns."""
    keep = (counts > 0).sum(axis=1) >= int(min_cells)
    return counts.loc[keep]


def intersect_genes(
    counts_a: pd.DataFrame, counts_b: pd.DataFrame
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Restrict two count tables to the intersection of their gene indices, sorted."""
    common = sorted(set(counts_a.index).intersection(counts_b.index))
    return counts_a.loc[common], counts_b.loc[common]


def split_cells_by_celltype(
    sc_counts: pd.DataFrame, sc_pheno: pd.DataFrame
) -> Dict[str, pd.DataFrame]:
    """Split single-cell counts into per-cell-type sub-matrices.

    Args:
        sc_counts: (n_genes, n_cells), columns are cell IDs.
        sc_pheno: must contain ``cellID`` and ``cellType`` columns.
    Returns:
        Dict mapping cell type name -> sub-DataFrame of cells of that type.
    """
    pmap = sc_pheno.set_index("cellID")["cellType"].astype(str)
    out: Dict[str, pd.DataFrame] = {}
    for ct in pmap.unique():
        cells = pmap[pmap == ct].index
        cells = [c for c in cells if c in sc_counts.columns]
        if cells:
            out[str(ct)] = sc_counts[cells]
    return out


def list_celltypes(sc_pheno: pd.DataFrame) -> List[str]:
    """Return sorted unique cell type names."""
    return sorted(sc_pheno["cellType"].astype(str).unique().tolist())


def list_subjects(sc_pheno: pd.DataFrame) -> List[str]:
    """Return sorted unique subject IDs from the single-cell phenotype table."""
    if "sampleID" not in sc_pheno.columns:
        return []
    return sorted(sc_pheno["sampleID"].astype(str).unique().tolist())


def per_celltype_cell_counts(sc_pheno: pd.DataFrame) -> Dict[str, int]:
    """Count number of single cells per cell type."""
    return sc_pheno["cellType"].astype(str).value_counts().to_dict()

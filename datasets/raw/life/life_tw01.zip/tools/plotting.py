"""Plotting primitives. All functions return ``{"path": str}`` after writing
the image to ``artifacts/``.

Uses matplotlib only; never opens a window (Agg backend).
"""
from __future__ import annotations

import math
from pathlib import Path
from typing import Dict, List, Optional, Sequence

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def _ensure_outdir(path: str) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)


def plot_gene_manhattan(spredixcan_with_ann: pd.DataFrame,
                        out_path: str,
                        bonferroni_threshold: float,
                        title: str = "Gene-level Manhattan",
                        highlight_genes: Optional[Sequence[str]] = None) -> dict:
    """Draw a per-gene Manhattan plot: x = chromosome (offset), y = -log10(p),
    with a horizontal Bonferroni line and optional highlighted gene labels.

    Required columns of ``spredixcan_with_ann``: ``gene_name``, ``chr``,
    ``start``, ``pvalue``.
    """
    _ensure_outdir(out_path)
    df = spredixcan_with_ann.dropna(subset=["pvalue", "chr", "start"]).copy()
    df["chr"] = df["chr"].astype(int)
    df = df.sort_values(["chr", "start"]).reset_index(drop=True)
    # cumulative offset by chromosome
    chr_max = df.groupby("chr")["start"].max().sort_index()
    cum = chr_max.cumsum().shift(1, fill_value=0)
    df["cum_pos"] = df.apply(lambda r: r["start"] + cum.loc[r["chr"]], axis=1)
    centres = df.groupby("chr")["cum_pos"].mean()

    fig, ax = plt.subplots(figsize=(12, 4.5))
    palette = ["#3b6cb1", "#e76f51"]
    for i, (chrom, sub) in enumerate(df.groupby("chr")):
        ax.scatter(sub["cum_pos"], -np.log10(sub["pvalue"].clip(1e-300)),
                   s=8, c=palette[i % 2], alpha=0.7, linewidths=0)
    ax.axhline(-math.log10(bonferroni_threshold), color="red",
               linestyle="--", linewidth=1.0,
               label=f"Bonferroni p={bonferroni_threshold:.2e}")
    if highlight_genes:
        sub = df[df["gene_name"].isin(highlight_genes)]
        ax.scatter(sub["cum_pos"],
                   -np.log10(sub["pvalue"].clip(1e-300)),
                   s=60, c="gold", edgecolors="black", linewidths=0.6, zorder=10,
                   label="highlighted")
        for _, r in sub.iterrows():
            ax.annotate(r["gene_name"],
                        xy=(r["cum_pos"], -math.log10(max(r["pvalue"], 1e-300))),
                        xytext=(0, 8), textcoords="offset points",
                        fontsize=8, ha="center")
    ax.set_xticks(centres.values)
    ax.set_xticklabels(centres.index, fontsize=7)
    ax.set_xlabel("Chromosome")
    ax.set_ylabel(r"$-\log_{10}(p)$")
    ax.set_title(title)
    ax.legend(loc="upper right", fontsize=8)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": out_path}


def plot_qq(pvalues: Sequence[float],
            out_path: str,
            title: str = "QQ plot",
            highlight_pvalues: Optional[Sequence[float]] = None,
            highlight_label: str = "highlighted") -> dict:
    """QQ plot of -log10(p) vs expected uniform quantiles, with diagonal."""
    _ensure_outdir(out_path)
    p = np.asarray([x for x in pvalues if not (x is None or math.isnan(x))],
                   dtype=float)
    p = np.clip(p, 1e-300, 1.0)
    p = np.sort(p)
    n = len(p)
    expected = -np.log10((np.arange(1, n + 1) - 0.5) / n)
    observed = -np.log10(p)
    fig, ax = plt.subplots(figsize=(5.5, 5.5))
    ax.scatter(expected, observed, s=10, c="#1f3b6c", alpha=0.7,
               linewidths=0, label="all genes")
    if highlight_pvalues is not None and len(highlight_pvalues) > 0:
        ph = np.clip(np.asarray(highlight_pvalues, dtype=float), 1e-300, 1.0)
        # Place each highlighted point at the expected quantile implied by its
        # rank within the FULL p-value distribution (so the strongest hits sit
        # at the right tail of the same QQ), not by its rank within the small
        # highlight subset.
        ranks = np.searchsorted(p, ph, side="left") + 1
        ranks = np.clip(ranks, 1, n)
        eh = -np.log10((ranks - 0.5) / n)
        oh = -np.log10(ph)
        ax.scatter(eh, oh, s=22, c="#e76f51", edgecolors="black",
                   linewidths=0.4, label=highlight_label)
    lim = max(expected.max(), observed.max()) * 1.05
    ax.plot([0, lim], [0, lim], "k--", linewidth=1)
    ax.set_xlabel(r"Expected $-\log_{10}(p)$")
    ax.set_ylabel(r"Observed $-\log_{10}(p)$")
    ax.set_title(title)
    ax.legend(loc="upper left", fontsize=9)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": out_path}


def plot_top_hits_bar(top_df: pd.DataFrame,
                      out_path: str,
                      title: str = "Top S-PrediXcan hits",
                      n_top: int = 20) -> dict:
    """Horizontal bar chart: top ``n_top`` genes by |Z|, color-coded by sign."""
    _ensure_outdir(out_path)
    df = top_df.copy()
    df["absZ"] = df["zscore"].abs()
    df = df.sort_values("absZ", ascending=False).head(n_top)
    df = df.iloc[::-1]  # smallest at bottom
    fig, ax = plt.subplots(figsize=(6.5, max(3, 0.32 * len(df))))
    colors = ["#3b6cb1" if z > 0 else "#e76f51" for z in df["zscore"]]
    ax.barh(df["gene_name"], df["zscore"], color=colors, edgecolor="black",
            linewidth=0.4)
    ax.axvline(0, color="black", linewidth=0.6)
    ax.set_xlabel("S-PrediXcan Z-score")
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": out_path}


def plot_tissue_comparison(tissue_dfs: Dict[str, pd.DataFrame],
                           out_path: str,
                           title: str = "S-PrediXcan: tissue comparison",
                           gene_col: str = "gene_name",
                           p_col: str = "pvalue",
                           n_top: int = 25) -> dict:
    """Heatmap of -log10(p) for the top ``n_top`` genes (selected from the
    union of each tissue's strongest hits) across the supplied tissues.
    """
    _ensure_outdir(out_path)
    tops = set()
    for t, d in tissue_dfs.items():
        tops |= set(d.sort_values(p_col).head(n_top)[gene_col].dropna())
    genes = sorted(tops)
    mat = np.zeros((len(genes), len(tissue_dfs)))
    for j, (t, d) in enumerate(tissue_dfs.items()):
        lookup = d.set_index(gene_col)[p_col].to_dict()
        for i, g in enumerate(genes):
            p = lookup.get(g, 1.0)
            mat[i, j] = -math.log10(max(p, 1e-300))
    fig, ax = plt.subplots(figsize=(1.0 + 1.0 * len(tissue_dfs),
                                    max(3.5, 0.28 * len(genes))))
    im = ax.imshow(mat, cmap="viridis", aspect="auto")
    ax.set_xticks(range(len(tissue_dfs)))
    ax.set_xticklabels(list(tissue_dfs.keys()), rotation=30, ha="right")
    ax.set_yticks(range(len(genes)))
    ax.set_yticklabels(genes, fontsize=7)
    ax.set_title(title)
    fig.colorbar(im, ax=ax, label=r"$-\log_{10}(p)$")
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": out_path}


def plot_locus_zoom(locus_df: pd.DataFrame,
                    out_path: str,
                    centre_pos: int,
                    centre_label: str,
                    title: str = "Locus zoom") -> dict:
    """Mini Manhattan around a single locus, marking the centre position."""
    _ensure_outdir(out_path)
    fig, ax = plt.subplots(figsize=(8, 4))
    df = locus_df.copy()
    df["nlogp"] = -np.log10(df["pvalue"].clip(1e-300))
    ax.scatter(df["position"] / 1e6, df["nlogp"],
               s=14, c="#3b6cb1", alpha=0.85, edgecolors="black",
               linewidths=0.3)
    ax.axvline(centre_pos / 1e6, color="red", linestyle="--",
               linewidth=1.0, label=centre_label)
    ax.set_xlabel("Position (Mb)")
    ax.set_ylabel(r"$-\log_{10}(p)$")
    ax.set_title(title)
    ax.legend(loc="upper right", fontsize=9)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": out_path}

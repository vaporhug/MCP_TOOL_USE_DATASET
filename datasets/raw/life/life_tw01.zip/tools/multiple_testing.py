"""Multiple-testing correction primitives.

- Bonferroni threshold
- Benjamini-Hochberg FDR
- Genomic inflation factor (lambda)
- Per-tissue Bonferroni applied to S-PrediXcan results
"""
from __future__ import annotations

import math
from typing import Sequence

import numpy as np
import pandas as pd


def bonferroni_threshold(n_tests: int, alpha: float = 0.05) -> float:
    """Bonferroni-corrected significance threshold ``alpha / n_tests``."""
    if n_tests <= 0:
        raise ValueError("n_tests must be positive")
    return alpha / n_tests


def bh_fdr(pvalues: Sequence[float]) -> np.ndarray:
    """Benjamini-Hochberg adjusted q-values for a vector of p-values.

    Returns an array of q-values aligned with the input order.
    """
    p = np.asarray(pvalues, dtype=float)
    n = len(p)
    order = np.argsort(p)
    ranked = p[order]
    q = ranked * n / (np.arange(1, n + 1))
    # enforce monotone non-increasing reverse
    q = np.minimum.accumulate(q[::-1])[::-1]
    out = np.empty(n, dtype=float)
    out[order] = np.clip(q, 0, 1)
    return out


def genomic_inflation_lambda(zscores: Sequence[float]) -> float:
    """Genomic inflation factor lambda = median(z^2) / 0.4549.

    0.4549 is the median of a chi-square_1 distribution.
    """
    z = np.asarray(zscores, dtype=float)
    z = z[~np.isnan(z)]
    if len(z) == 0:
        return float("nan")
    return float(np.median(z ** 2) / 0.4549)


def select_significant(spredixcan_df: pd.DataFrame,
                       n_total_tests: int,
                       alpha: float = 0.05,
                       use_fdr: bool = False,
                       fdr_alpha: float = 0.05) -> pd.DataFrame:
    """Filter S-PrediXcan results to Bonferroni-significant rows.

    If ``use_fdr=True``, apply Benjamini-Hochberg with q < ``fdr_alpha``
    instead of Bonferroni.

    Parameters
    ----------
    spredixcan_df : DataFrame
        Output of ``predixcan.run_spredixcan_all_genes`` (already sorted
        by p-value, but order is not assumed).
    n_total_tests : int
        Total number of gene-tissue pairs tested (e.g., across ALL tissues
        when applying step 1 of the paper's pipeline).
    """
    df = spredixcan_df.copy()
    if use_fdr:
        df["qvalue"] = bh_fdr(df["pvalue"].tolist())
        return df[df["qvalue"] < fdr_alpha].reset_index(drop=True)
    threshold = bonferroni_threshold(n_total_tests, alpha=alpha)
    df["bonferroni_threshold"] = threshold
    return df[df["pvalue"] < threshold].reset_index(drop=True)


def replication_concordance(discovery: pd.DataFrame,
                            replication: pd.DataFrame,
                            join_on: str = "gene",
                            disc_z_col: str = "zscore",
                            rep_z_col: str = "zscore",
                            disc_p_col: str = "pvalue",
                            rep_p_col: str = "pvalue",
                            replication_p_threshold: float = 0.05) -> dict:
    """Following the paper's replication criterion, count discovery-set
    significant genes that (a) have rep p < ``replication_p_threshold``
    AND (b) have the same direction of effect as discovery.

    Returns ``{"n_disc": int, "n_replicated": int, "pct_replicated": float,
               "concordant_direction": int}``.
    """
    merged = discovery.merge(replication, on=join_on,
                             suffixes=("_disc", "_rep"))
    same_dir = np.sign(merged[disc_z_col + "_disc"] if disc_z_col + "_disc" in merged.columns
                       else merged[disc_z_col]) == \
               np.sign(merged[rep_z_col + "_rep"] if rep_z_col + "_rep" in merged.columns
                       else merged[rep_z_col])
    rep_p_field = rep_p_col + "_rep" if rep_p_col + "_rep" in merged.columns else rep_p_col
    rep_pass = merged[rep_p_field] < replication_p_threshold
    n_rep = int((rep_pass & same_dir).sum())
    n_disc = int(len(discovery))
    return {"n_disc": n_disc, "n_replicated": n_rep,
            "pct_replicated": float(100.0 * n_rep / max(n_disc, 1)),
            "concordant_direction": int(same_dir.sum())}

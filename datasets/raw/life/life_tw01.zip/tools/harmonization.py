"""SNP harmonization between GWAS sumstats and eQTL weight tables.

Operations:
- Intersect SNP sets by rsid.
- Detect allele matches / flips / strand ambiguity.
- Flip GWAS effect sign and z-score when alleles are swapped.
- Drop palindromic AT/GC SNPs (ambiguous strand) at high allele frequency.
"""
from __future__ import annotations

import pandas as pd

PALINDROMIC = {("A", "T"), ("T", "A"), ("C", "G"), ("G", "C")}


def intersect_snps(sumstats: pd.DataFrame,
                   weights: pd.DataFrame) -> set:
    """Return the set of rsids common to GWAS and weights tables."""
    return set(sumstats["rsid"]).intersection(weights["rsid"])


def harmonize_alleles(sumstats: pd.DataFrame,
                      weights: pd.DataFrame,
                      drop_palindromic_above_eaf: float = 0.42) -> pd.DataFrame:
    """Align GWAS effect direction to the eQTL weight effect allele.

    Logic per SNP:
      - If (eff_allele, ref_allele) match between GWAS and weights -> keep z.
      - If they are swapped (GWAS_eff == weights_ref AND GWAS_ref == weights_eff)
        -> flip z and beta sign.
      - If alleles do not correspond at all -> drop SNP (mismatch).
      - If the SNP is strand-ambiguous (A/T or C/G) AND its EAF is in
        ``[drop_palindromic_above_eaf, 1 - drop_palindromic_above_eaf]``
        -> drop SNP.

    Returns
    -------
    DataFrame with columns
    ``[rsid, gene, weight, ref_allele, eff_allele, beta, se, zscore, pvalue,
       n, harmonization_status]``
    where ``harmonization_status`` is ``match`` / ``flip`` / ``dropped``.
    Only ``match`` and ``flip`` rows are returned.
    """
    merged = weights.merge(
        sumstats, on="rsid", suffixes=("_w", "_g"), how="inner",
    )
    statuses = []
    flipped_z = []
    flipped_beta = []
    for _, row in merged.iterrows():
        we, wr = row["eff_allele_w"], row["ref_allele_w"]
        ge, gr = row["eff_allele_g"], row["ref_allele_g"]
        # palindromic check
        if (we, wr) in PALINDROMIC:
            eaf = row.get("eaf", 0.5)
            if drop_palindromic_above_eaf <= eaf <= 1 - drop_palindromic_above_eaf:
                statuses.append("dropped")
                flipped_z.append(float("nan"))
                flipped_beta.append(float("nan"))
                continue
        if we == ge and wr == gr:
            statuses.append("match")
            flipped_z.append(row["zscore"])
            flipped_beta.append(row["beta"])
        elif we == gr and wr == ge:
            statuses.append("flip")
            flipped_z.append(-row["zscore"])
            flipped_beta.append(-row["beta"])
        else:
            statuses.append("dropped")
            flipped_z.append(float("nan"))
            flipped_beta.append(float("nan"))
    out = merged.copy()
    out["harmonization_status"] = statuses
    out["zscore"] = flipped_z
    out["beta"] = flipped_beta
    out["ref_allele"] = out["ref_allele_w"]
    out["eff_allele"] = out["eff_allele_w"]
    out = out[out["harmonization_status"] != "dropped"]
    cols = ["rsid", "gene", "weight", "ref_allele", "eff_allele",
            "beta", "se", "zscore", "pvalue", "n", "harmonization_status"]
    return out[cols].reset_index(drop=True)


def harmonization_summary(harmonized: pd.DataFrame) -> dict:
    """Counts of match / flip / total per gene."""
    by_gene = harmonized.groupby("gene")["harmonization_status"].value_counts().unstack().fillna(0)
    by_gene["total"] = by_gene.sum(axis=1)
    n_total = int(len(harmonized))
    n_flip = int((harmonized["harmonization_status"] == "flip").sum())
    n_match = int((harmonized["harmonization_status"] == "match").sum())
    return {"n_total_snps": n_total, "n_match": n_match, "n_flip": n_flip,
            "n_genes": int(harmonized["gene"].nunique()),
            "per_gene_table": by_gene.reset_index()}

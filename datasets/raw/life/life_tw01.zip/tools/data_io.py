"""I/O primitives for GWAS sumstats, eQTL prediction weights, LD covariance.

All functions take filesystem paths and return pandas DataFrames. No
domain logic, just parsing.
"""
from __future__ import annotations

from pathlib import Path
from typing import Dict, Iterable, Optional, Sequence

import pandas as pd


def load_gwas_sumstats(path: str) -> pd.DataFrame:
    """Load a GWAS summary-statistics file (tab-separated).

    Expected columns
    ----------------
    rsid : str            dbSNP rsid
    chromosome : int      1..22
    position : int        GRCh37/38 position (consistent with weights)
    ref_allele : str      reference allele (matches A1 in some pipelines)
    eff_allele : str      effect allele (matches A2 in some pipelines)
    eaf : float           effect allele frequency
    beta : float          GWAS effect size
    se : float            standard error of beta
    zscore : float        z-score = beta / se
    pvalue : float        two-sided p-value
    n : int               sample size

    Returns
    -------
    The parsed DataFrame with ``rsid`` as a regular column (not indexed).
    Downstream harmonization helpers (``intersect_snps``,
    ``harmonize_alleles``) join on the ``rsid`` column directly.
    """
    df = pd.read_csv(path, sep="\t")
    required = {"rsid", "chromosome", "position", "ref_allele",
                "eff_allele", "eaf", "beta", "se", "zscore", "pvalue", "n"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"GWAS sumstats missing columns: {missing}")
    return df


def load_predictdb_weights(path: str) -> pd.DataFrame:
    """Load a PredictDB-style elastic-net weights table.

    Columns: gene, rsid, ref_allele, eff_allele, weight.
    Returns the DataFrame as-is.
    """
    df = pd.read_csv(path, sep="\t")
    required = {"gene", "rsid", "ref_allele", "eff_allele", "weight"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"weights file missing columns: {missing}")
    return df


def load_snp_covariance(path: str) -> pd.DataFrame:
    """Load tidy SNP-SNP covariance / LD matrix.

    Columns: gene, rsid1, rsid2, value (symmetric in rsid1/rsid2).
    Only entries with rsid1 <= rsid2 may be present; the consumer is
    responsible for symmetrising.
    """
    df = pd.read_csv(path, sep="\t")
    required = {"gene", "rsid1", "rsid2", "value"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"covariance file missing columns: {missing}")
    return df


def load_gene_annotation(path: str) -> pd.DataFrame:
    """Load a gene annotation table.

    Columns: gene_id, gene_name, chr, start, end.
    """
    df = pd.read_csv(path, sep="\t")
    required = {"gene_id", "gene_name", "chr", "start", "end"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"gene annotation missing columns: {missing}")
    return df


def load_tissue_index(path: str) -> pd.DataFrame:
    """Load the per-tissue index of weight + covariance file paths.

    Columns: tissue_id, n_eqtl_samples, weights_path, covariance_path.
    """
    df = pd.read_csv(path, sep="\t")
    required = {"tissue_id", "n_eqtl_samples", "weights_path",
                "covariance_path"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"tissue index missing columns: {missing}")
    return df


def filter_sumstats_by_chromosome(sumstats: pd.DataFrame,
                                  chromosomes: Sequence[int]) -> pd.DataFrame:
    """Return rows whose ``chromosome`` is in ``chromosomes``."""
    return sumstats[sumstats["chromosome"].isin(list(chromosomes))].copy()


def write_dataframe(df: pd.DataFrame, path: str) -> dict:
    """Write a DataFrame to disk as TSV. Returns ``{"path": path, "rows": N}``."""
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, sep="\t", index=False)
    return {"path": str(path), "rows": int(len(df))}

"""Optional colocalization helper -- NOT used by life_tw01's expected answer.

The life_tw01 bundle ships only GWAS summary statistics, elastic-net
prediction weights, and LD covariance; it does NOT include the eQTL
marginal statistics that paper-faithful COLOC requires, so the expected
answer computes no COLOC posteriors. These functions are provided purely
as teaching / validation primitives illustrating the post-filtering step
of the MetaXcan framework, in case a caller supplies their own COLOC
inputs. They are never invoked to produce any scored result in this task.

Functions:

1. ``coloc_posterior_summary``: a simplified single-causal-variant
   colocalization estimator returning the five posteriors P0..P4 from a
   per-locus pair of Z-scores (Giambartolomei et al. 2014, normal-prior
   Bayes factors). Not a drop-in replacement for the ``coloc`` R package.

2. ``filter_independent_signals``: drops gene-tissue rows where
   ``P3 > 0.5`` (independent signals / LD contamination). The
   ``P3 + P4 < 0.05`` "no shared support" filter is not implemented here.

3. ``filter_colocalized_signals``: keeps only rows with ``P4 > 0.5``.

The two filter helpers merge on ``join_on`` (default ``["gene"]``); pass
``join_on=["gene", "tissue"]`` to keep per-tissue COLOC posteriors
distinct when the same gene is tested in more than one tissue.
"""
from __future__ import annotations

import math
from typing import Dict, Sequence

import numpy as np
import pandas as pd


def _log_abf(z: np.ndarray, V: np.ndarray, W: float) -> np.ndarray:
    """Wakefield log approximate Bayes factor for an ABF colocalization run.

    log ABF = 0.5 * log(V / (V + W)) + 0.5 * z^2 * W / (V + W)
    """
    r = W / (V + W)
    return 0.5 * np.log(1 - r) + 0.5 * z * z * r


def coloc_posterior_summary(z_eqtl: np.ndarray,
                            v_eqtl: np.ndarray,
                            z_gwas: np.ndarray,
                            v_gwas: np.ndarray,
                            p1: float = 1e-4,
                            p2: float = 1e-4,
                            p12: float = 1e-5,
                            W_eqtl: float = 0.04,
                            W_gwas: float = 0.04) -> Dict[str, float]:
    """Single-causal-variant colocalization (Giambartolomei et al. 2014)
    posteriors from per-SNP eQTL and GWAS marginal z-scores.

    Parameters
    ----------
    z_eqtl, z_gwas : array-like, shape (n_snps,)
        Marginal z-scores for the same set of SNPs.
    v_eqtl, v_gwas : array-like, shape (n_snps,)
        SNP variances (use 1.0 for standardised genotypes).
    p1, p2, p12 : float
        Prior probabilities for SNP being causal in trait 1 only,
        trait 2 only, or both. Defaults are coloc package defaults.
    W_eqtl, W_gwas : float
        Prior variance of the effect size for each trait (default 0.04
        corresponds to coloc's "small effect" prior of N(0, 0.2^2)).

    Returns
    -------
    dict with keys ``P0, P1, P2, P3, P4``.
    """
    z_e = np.asarray(z_eqtl, dtype=float)
    z_g = np.asarray(z_gwas, dtype=float)
    v_e = np.asarray(v_eqtl, dtype=float)
    v_g = np.asarray(v_gwas, dtype=float)
    log_abf_e = _log_abf(z_e, v_e, W_eqtl)
    log_abf_g = _log_abf(z_g, v_g, W_gwas)
    n = len(z_e)
    # log-sum-exp helpers
    def lse(x):
        m = np.max(x)
        return m + np.log(np.sum(np.exp(x - m)))
    p0_prior_log = math.log(max(1e-300, 1 - n * (p1 + p2) - n * (n - 1) / 2 * 0 - p12 * n))
    log_h0 = p0_prior_log
    log_h1 = math.log(p1) + lse(log_abf_e)
    log_h2 = math.log(p2) + lse(log_abf_g)
    # H3: causal SNPs are different
    # sum over all i != j of ABF_e(i) * ABF_g(j)
    log_total_e = lse(log_abf_e)
    log_total_g = lse(log_abf_g)
    # subtract the i==j diagonal
    log_diag = lse(log_abf_e + log_abf_g)
    # log( exp(le) * exp(lg) - exp(ldiag) )
    log_off = log_total_e + log_total_g
    # safe subtraction
    if log_off > log_diag:
        log_h3 = math.log(p1 * p2) + log_off + np.log1p(-np.exp(log_diag - log_off))
    else:
        log_h3 = -1e9
    log_h4 = math.log(p12) + log_diag
    logs = np.array([log_h0, log_h1, log_h2, log_h3, log_h4])
    m = np.max(logs)
    norm = m + np.log(np.sum(np.exp(logs - m)))
    posts = np.exp(logs - norm)
    return {"P0": float(posts[0]), "P1": float(posts[1]),
            "P2": float(posts[2]), "P3": float(posts[3]),
            "P4": float(posts[4])}


def filter_independent_signals(spredixcan_df: pd.DataFrame,
                               coloc_df: pd.DataFrame,
                               p3_threshold: float = 0.5,
                               join_on: Sequence[str] = ("gene",)) -> pd.DataFrame:
    """Pipeline step 3: drop gene-tissue pairs whose P3 > ``p3_threshold``,
    i.e. those with strong evidence of independent (LD-contaminated) signals.

    ``coloc_df`` must contain the ``join_on`` key column(s) plus ``P3``.
    Pass ``join_on=["gene", "tissue"]`` when COLOC posteriors are tissue
    specific so that the same gene in different tissues is not conflated.
    """
    keys = list(join_on)
    sig = spredixcan_df.merge(coloc_df[keys + ["P3"]], on=keys, how="left")
    return sig[~(sig["P3"] > p3_threshold)].reset_index(drop=True)


def filter_colocalized_signals(spredixcan_df: pd.DataFrame,
                               coloc_df: pd.DataFrame,
                               p4_threshold: float = 0.5,
                               join_on: Sequence[str] = ("gene",)) -> pd.DataFrame:
    """Pipeline step 4 (optional, replication-friendly): keep only
    gene-tissue pairs with P4 > ``p4_threshold``.

    ``coloc_df`` must contain the ``join_on`` key column(s) plus ``P4``.
    Pass ``join_on=["gene", "tissue"]`` for tissue-specific posteriors.
    """
    keys = list(join_on)
    sig = spredixcan_df.merge(coloc_df[keys + ["P4"]], on=keys, how="left")
    return sig[sig["P4"] > p4_threshold].reset_index(drop=True)


def filter_reliable_predictions(spredixcan_df: pd.DataFrame,
                                model_perf_df: pd.DataFrame,
                                bonferroni_n_sig: int,
                                pred_p_col: str = "pred_perf_pval") -> pd.DataFrame:
    """Pipeline step 2: keep only genes whose model prediction performance
    p-value is below ``0.05 / bonferroni_n_sig``.

    ``model_perf_df`` must contain a ``gene`` column and ``pred_p_col``.
    """
    if bonferroni_n_sig <= 0:
        return spredixcan_df.iloc[:0].copy()
    threshold = 0.05 / bonferroni_n_sig
    keep = model_perf_df[model_perf_df[pred_p_col] < threshold]["gene"]
    return spredixcan_df[spredixcan_df["gene"].isin(keep)].reset_index(drop=True)

"""Locus-level utilities: clumping, top-hit extraction, gene-locus assembly."""
from __future__ import annotations

from typing import List

import numpy as np
import pandas as pd


def assign_locus(sumstats: pd.DataFrame,
                 window_kb: int = 500) -> pd.DataFrame:
    """Crude locus assignment for SNPs.

    Within each chromosome, a new locus is started whenever the gap to
    the previous SNP exceeds ``window_kb`` kb.

    Returns the same DataFrame with a new ``locus_id`` column
    (``chr:locus_index``).
    """
    df = sumstats.sort_values(["chromosome", "position"]).copy()
    locus_ids: List[str] = []
    last_chr = None
    last_pos = -10 ** 12
    idx = 0
    for _, row in df.iterrows():
        chrom, pos = int(row["chromosome"]), int(row["position"])
        if chrom != last_chr or (pos - last_pos) > window_kb * 1000:
            idx += 1
        locus_ids.append(f"{chrom}:L{idx:04d}")
        last_chr, last_pos = chrom, pos
    df["locus_id"] = locus_ids
    return df


def top_snps_by_locus(sumstats: pd.DataFrame) -> pd.DataFrame:
    """Return the SNP with smallest p-value per locus."""
    if "locus_id" not in sumstats.columns:
        raise ValueError("call assign_locus() first")
    idx = sumstats.groupby("locus_id")["pvalue"].idxmin()
    return sumstats.loc[idx].sort_values("pvalue").reset_index(drop=True)


def top_genes_by_chromosome(spredixcan_with_ann: pd.DataFrame,
                            n_top: int = 5) -> pd.DataFrame:
    """For each chromosome, return the ``n_top`` strongest gene-tissue pairs."""
    df = spredixcan_with_ann.sort_values("pvalue").copy()
    return df.groupby("chr").head(n_top).sort_values(["chr", "pvalue"]).reset_index(drop=True)


def locus_zoom_table(sumstats: pd.DataFrame,
                     centre_chr: int,
                     centre_pos: int,
                     window_kb: int = 500) -> pd.DataFrame:
    """Return SNPs within ``window_kb`` kb either side of a centre position
    on a single chromosome."""
    half = window_kb * 1000
    sub = sumstats[(sumstats["chromosome"] == int(centre_chr)) &
                   (sumstats["position"] >= centre_pos - half) &
                   (sumstats["position"] <= centre_pos + half)].copy()
    sub["distance_kb"] = (sub["position"] - centre_pos) / 1000.0
    return sub.sort_values("position").reset_index(drop=True)


def overlap_with_known_loci(spredixcan_with_ann: pd.DataFrame,
                            known_loci: pd.DataFrame,
                            chr_col: str = "chr",
                            pos_col: str = "start",
                            window_kb: int = 500) -> pd.DataFrame:
    """Annotate each significant gene with the closest known GWAS locus,
    if any falls within ``window_kb`` kb.

    ``known_loci`` must contain columns ``locus_name``, ``chromosome``,
    ``position``.
    """
    out_rows = []
    for _, row in spredixcan_with_ann.iterrows():
        same_chr = known_loci[known_loci["chromosome"] == row[chr_col]]
        if same_chr.empty:
            out_rows.append({**row.to_dict(),
                             "closest_known_locus": None,
                             "distance_kb": None})
            continue
        d = (same_chr["position"] - row[pos_col]).abs()
        i = d.idxmin()
        if d.loc[i] <= window_kb * 1000:
            out_rows.append({**row.to_dict(),
                             "closest_known_locus": same_chr.loc[i, "locus_name"],
                             "distance_kb": float(d.loc[i] / 1000.0)})
        else:
            out_rows.append({**row.to_dict(),
                             "closest_known_locus": None,
                             "distance_kb": None})
    return pd.DataFrame(out_rows)

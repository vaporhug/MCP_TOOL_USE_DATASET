"""S-PrediXcan / PrediXcan computation primitives.

The S-PrediXcan formula (Barbeira et al. 2018, Eq. 3) is

    Z_g  =  Σ_{l ∈ Model_g}  w_lg * (sigma_l / sigma_g) * (beta_l / se(beta_l))

where
    w_lg     = elastic-net weight for SNP l in gene g (from PredictDB)
    sigma_l  = standard deviation of SNP l dosage in the reference set
    sigma_g  = sqrt( w' Sigma w ),  where Sigma is the LD-covariance matrix
                of the predictor SNPs (also from the reference set)
    beta_l, se = GWAS effect estimate and SE for SNP l

When the dosages are standardised so that sigma_l == 1 for every SNP, the
formula collapses to

    Z_g  =  ( w' z ) / sqrt( w' Sigma w )

which is the form implemented here.
"""
from __future__ import annotations

import math
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd


def _build_cov_matrix(rsids: List[str],
                      cov_long: pd.DataFrame) -> np.ndarray:
    """Build a symmetric n x n covariance matrix from a tidy long-format
    table for a single gene.

    Parameters
    ----------
    rsids : list of str
        SNP order in which the matrix is constructed.
    cov_long : DataFrame
        Tidy table for ONE gene with columns ``rsid1``, ``rsid2``, ``value``.

    Returns
    -------
    ndarray, shape (n, n)
    """
    n = len(rsids)
    Sigma = np.eye(n, dtype=float)
    if cov_long is None or cov_long.empty:
        return Sigma
    idx = {r: i for i, r in enumerate(rsids)}
    for _, row in cov_long.iterrows():
        r1, r2, v = row["rsid1"], row["rsid2"], float(row["value"])
        if r1 in idx and r2 in idx:
            i, j = idx[r1], idx[r2]
            Sigma[i, j] = v
            Sigma[j, i] = v
    return Sigma


def predixcan_zscore_per_gene(harmonized_gene: pd.DataFrame,
                              cov_gene: pd.DataFrame,
                              ridge: float = 1e-6) -> dict:
    """Compute the S-PrediXcan Z-score for a single gene.

    Parameters
    ----------
    harmonized_gene : DataFrame
        Per-SNP rows for ONE gene with columns ``rsid``, ``weight``,
        ``zscore``. SNP-allele harmonization with the GWAS must already
        be done (use ``harmonization.harmonize_alleles``).
    cov_gene : DataFrame
        Tidy LD-covariance table restricted to the same gene.
    ridge : float
        Small numerical jitter added to ``sigma_g`` to avoid division by
        zero on degenerate models.

    Returns
    -------
    dict
        ``{"gene": str, "zscore": float, "sigma_g": float,
            "n_snps_used": int, "pvalue": float}``.
    """
    if harmonized_gene.empty:
        return {"gene": None, "zscore": float("nan"),
                "sigma_g": float("nan"), "n_snps_used": 0,
                "pvalue": float("nan")}
    rsids = harmonized_gene["rsid"].tolist()
    w = harmonized_gene["weight"].to_numpy(dtype=float)
    z = harmonized_gene["zscore"].to_numpy(dtype=float)
    Sigma = _build_cov_matrix(rsids, cov_gene)
    var_g = float(w @ Sigma @ w)
    sigma_g = float(math.sqrt(max(var_g, 0.0)) + ridge)
    Z = float(np.sum(w * z) / sigma_g)
    p = normal_two_sided_pvalue(Z)
    gene_id = harmonized_gene["gene"].iloc[0]
    return {"gene": gene_id, "zscore": Z, "sigma_g": sigma_g,
            "n_snps_used": int(len(rsids)), "pvalue": p}


def normal_two_sided_pvalue(z: float) -> float:
    """Two-sided normal-approximation p-value for a z-score.

    Implemented via ``math.erf`` -- no scipy dependency.
    """
    return 2.0 * (1.0 - 0.5 * (1.0 + math.erf(abs(z) / math.sqrt(2.0))))


def normal_inverse_cdf(p: float) -> float:
    """Quantile function (probit) of the standard normal.

    Used to convert one-sided p-values to z-scores. Implementation:
    Beasley-Springer-Moro 1977 rational approximation.
    """
    if p <= 0 or p >= 1:
        raise ValueError("p must be in (0, 1)")
    a = [-39.6968302866538, 220.946098424521, -275.928510446969,
         138.357751867269, -30.6647980661472, 2.50662827745924]
    b = [-54.4760987982241, 161.585836858041, -155.698979859887,
         66.8013118877197, -13.2806815528857]
    c = [-0.00778489400243029, -0.322396458041136, -2.40075827716184,
         -2.54973253934373, 4.37466414146497, 2.93816398269878]
    d = [0.00778469570904146, 0.32246712907004, 2.445134137143,
         3.75440866190742]
    plow = 0.02425
    phigh = 1 - plow
    if p < plow:
        q = math.sqrt(-2 * math.log(p))
        return (((((c[0]*q + c[1])*q + c[2])*q + c[3])*q + c[4])*q + c[5]) / \
               ((((d[0]*q + d[1])*q + d[2])*q + d[3])*q + 1)
    if p <= phigh:
        q = p - 0.5
        r = q * q
        return (((((a[0]*r + a[1])*r + a[2])*r + a[3])*r + a[4])*r + a[5]) * q / \
               (((((b[0]*r + b[1])*r + b[2])*r + b[3])*r + b[4])*r + 1)
    q = math.sqrt(-2 * math.log(1 - p))
    return -(((((c[0]*q + c[1])*q + c[2])*q + c[3])*q + c[4])*q + c[5]) / \
            ((((d[0]*q + d[1])*q + d[2])*q + d[3])*q + 1)


def run_spredixcan_all_genes(harmonized: pd.DataFrame,
                             cov_long: pd.DataFrame,
                             min_snps: int = 1,
                             ridge: float = 1e-6) -> pd.DataFrame:
    """Run S-PrediXcan for every gene present in ``harmonized``.

    Parameters
    ----------
    harmonized : DataFrame
        Output of ``harmonization.harmonize_alleles`` for one tissue.
    cov_long : DataFrame
        Tidy LD-covariance table for the same tissue (covers all genes).
    min_snps : int
        Drop genes with fewer than ``min_snps`` predictor SNPs after
        harmonization.

    Returns
    -------
    DataFrame
        Columns: ``gene, zscore, pvalue, sigma_g, n_snps_used``.
        Sorted by ascending p-value.
    """
    cov_by_gene: Dict[str, pd.DataFrame] = {
        g: sub for g, sub in cov_long.groupby("gene")
    }
    rows = []
    for gene_id, sub in harmonized.groupby("gene"):
        if len(sub) < min_snps:
            continue
        cov_gene = cov_by_gene.get(gene_id, pd.DataFrame(
            columns=["rsid1", "rsid2", "value"]))
        res = predixcan_zscore_per_gene(sub, cov_gene, ridge=ridge)
        rows.append(res)
    out = pd.DataFrame(rows)
    if out.empty:
        return out
    return out.sort_values("pvalue").reset_index(drop=True)


def annotate_with_gene_names(spredixcan_df: pd.DataFrame,
                             gene_annotation: pd.DataFrame) -> pd.DataFrame:
    """Join S-PrediXcan results with gene annotation (gene_name, chr, start)."""
    return spredixcan_df.merge(
        gene_annotation.rename(columns={"gene_id": "gene"}),
        on="gene", how="left",
    )

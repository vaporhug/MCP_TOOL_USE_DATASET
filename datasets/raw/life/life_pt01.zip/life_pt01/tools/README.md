# Tools

## proteomics_analysis.py

Low-level primitives for quantitative proteomics data analysis.

### Categories

- **Data loading & preprocessing**: `load_protein_expression`, `log2_transform`, `impute_missing`, `normalize_expression`
- **Differential expression**: `per_protein_ttest`, `one_vs_rest_ttest`, `adjust_pvalues`, `classify_significance`
- **Dimensionality reduction**: `run_pca`, `run_umap`
- **Correlation**: `protein_protein_correlation`
- **Enrichment analysis**: `go_enrichment`, `pathway_enrichment`
- **Classification**: `train_glmnet_classifier` (elastic-net, sparsifying), `train_binary_classifier` (logistic/rf/svm), `evaluate_classifier` (explicit `pos_label` support for AUC, sensitivity and specificity; defaults to 'Cancer' when present), `compute_roc_curve`, `get_feature_importance`, `split_train_test`
- **Panel selection**: `normalize_importance` (rescales each one-vs-rest model's importances to 0-100% of its top protein), `select_panel_proteins` (generic threshold/direction/minimum-size feature selector), `build_bundle_local_panel` (protocol-driven deterministic surrogate panel builder; pass `protocol_path` for `pan_cancer_panel_protocol.json`)
- **Visualization**: `plot_volcano`, `plot_pca_scatter`, `plot_heatmap`, `plot_roc_curves`, `plot_protein_boxplot`, `plot_dep_barplot`, `plot_upset`, `plot_network`, `plot_confusion_matrix`, `plot_importance_rank`

### Scope Note

The bundled `pancancer_npx.csv` contains a cancer-patient NPX matrix suitable for
cancer-specific one-vs-rest analysis: for each target cancer type, the control
group is composed of other cancer samples. The tools expose reusable primitives
for differential expression, binary classification, feature ranking, panel
selection and visualization; paper-specific interpretation and limitations are
documented in `task_content.json`, not in the tool module.

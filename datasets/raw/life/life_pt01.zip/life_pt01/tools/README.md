# Tools

## proteomics_analysis.py

Low-level primitives for quantitative proteomics data analysis.

### Categories

- **Data loading & preprocessing**: `load_protein_expression`, `log2_transform`, `impute_missing`, `normalize_expression`
- **Differential expression**: `per_protein_ttest`, `one_vs_rest_ttest`, `adjust_pvalues`, `classify_significance`
- **Dimensionality reduction**: `run_pca`, `run_umap`
- **Correlation**: `protein_protein_correlation`
- **Enrichment analysis**: `go_enrichment`, `pathway_enrichment`
- **Classification**: `train_glmnet_classifier` (elastic-net, sparsifying), `train_binary_classifier` (logistic/rf/svm), `evaluate_classifier` (positive-class AUC: picks the 'Cancer' label, or the lexicographically larger label, as positive so the AUC direction is correct for one-vs-rest), `compute_roc_curve`, `get_feature_importance`, `split_train_test`
- **Panel selection**: `normalize_importance` (rescales each one-vs-rest model's importances to 0-100% of its top protein), `select_panel_proteins` (applies the three-criterion panel rule: (i) >50% normalized importance, (ii) upregulated by one-vs-rest DE, (iii) >=3 proteins/cancer minimum)
- **Visualization**: `plot_volcano`, `plot_pca_scatter`, `plot_heatmap`, `plot_roc_curves`, `plot_protein_boxplot`, `plot_dep_barplot`, `plot_upset`, `plot_network`, `plot_confusion_matrix`, `plot_importance_rank`

### Scope Note

The bundled `pancancer_npx.csv` contains the 1477 cancer-patient NPX matrix and
supports one-vs-rest cancer-type comparisons among the 12 cancers. The paper's
Fig. 4b cancer-vs-healthy-control evaluation used 74 wellness controls and
same-sex control matching that are not present in this matrix, so exact
paper-control AUCs are paper-cited reference results. The tools remain useful
for recomputing differential expression, one-vs-rest classifiers, positive-class
AUCs, and panel-selection primitives on the bundled cancer-only matrix.

"""Low-level primitives for quantitative proteomics analysis.

This module provides generic functions for loading protein expression data,
statistical testing, dimensionality reduction, classification, enrichment
analysis, and visualization. It does NOT encode any domain knowledge about
which proteins are cancer biomarkers or which pathways are relevant.
The calling agent decides the analysis strategy.
"""
from __future__ import annotations

import os
from typing import Dict, List, Optional, Sequence, Tuple, Union

import numpy as np
import pandas as pd
from scipy import stats


# ---------------------------------------------------------------------------
# Data loading & preprocessing
# ---------------------------------------------------------------------------
def load_protein_expression(
    filepath: str,
    sample_col: str = "Sample_ID",
    group_col: str = "Cancer",
) -> Tuple[pd.DataFrame, pd.Series, pd.Series]:
    """Load a wide-format protein expression matrix.

    Parameters
    ----------
    filepath : str
        Path to a CSV where rows are samples and columns include sample IDs,
        group labels, and protein expression values (e.g., NPX).
    sample_col : str
        Column name for sample identifiers.
    group_col : str
        Column name for group/class labels.

    Returns
    -------
    expr : pd.DataFrame
        Protein expression matrix (samples x proteins), numeric only.
    sample_ids : pd.Series
        Sample identifiers aligned with expr rows.
    groups : pd.Series
        Group labels aligned with expr rows.
    """
    df = pd.read_csv(filepath)
    sample_ids = df[sample_col]
    groups = df[group_col]
    meta_cols = [sample_col, group_col]
    expr = df.drop(columns=[c for c in meta_cols if c in df.columns])
    # Keep only numeric columns
    expr = expr.select_dtypes(include=[np.number])
    return expr, sample_ids, groups


def log2_transform(
    expr: pd.DataFrame,
    pseudocount: float = 1.0,
) -> pd.DataFrame:
    """Apply log2(x + pseudocount) transformation to expression values.

    Parameters
    ----------
    expr : pd.DataFrame
        Protein expression matrix (samples x proteins).
    pseudocount : float
        Value added before log to handle zeros. Default 1.0.

    Returns
    -------
    pd.DataFrame
        Log2-transformed expression matrix.
    """
    return np.log2(expr + pseudocount)


def impute_missing(
    expr: pd.DataFrame,
    method: str = "knn",
    k: int = 5,
) -> pd.DataFrame:
    """Impute missing values in the expression matrix.

    Parameters
    ----------
    expr : pd.DataFrame
        Expression matrix with potential NaN values.
    method : str
        Imputation method: 'knn', 'median', 'min', or 'zero'.
    k : int
        Number of neighbors for KNN imputation.

    Returns
    -------
    pd.DataFrame
        Imputed expression matrix.
    """
    if method == "median":
        return expr.fillna(expr.median())
    elif method == "min":
        return expr.fillna(expr.min())
    elif method == "zero":
        return expr.fillna(0.0)
    elif method == "knn":
        try:
            from sklearn.impute import KNNImputer
            imp = KNNImputer(n_neighbors=k)
            arr = imp.fit_transform(expr.values)
            return pd.DataFrame(arr, index=expr.index, columns=expr.columns)
        except ImportError:
            # Fallback to median
            return expr.fillna(expr.median())
    else:
        raise ValueError(f"Unknown imputation method: {method}")


def normalize_expression(
    expr: pd.DataFrame,
    method: str = "zscore",
) -> pd.DataFrame:
    """Normalize protein expression values.

    Parameters
    ----------
    expr : pd.DataFrame
        Expression matrix (samples x proteins).
    method : str
        'zscore' for per-protein z-score, 'quantile' for quantile normalization,
        'minmax' for min-max scaling.

    Returns
    -------
    pd.DataFrame
        Normalized expression matrix.
    """
    if method == "zscore":
        return (expr - expr.mean()) / expr.std()
    elif method == "minmax":
        return (expr - expr.min()) / (expr.max() - expr.min())
    elif method == "quantile":
        from sklearn.preprocessing import quantile_transform
        arr = quantile_transform(expr.values, output_distribution="normal", copy=True)
        return pd.DataFrame(arr, index=expr.index, columns=expr.columns)
    else:
        raise ValueError(f"Unknown normalization method: {method}")


# ---------------------------------------------------------------------------
# Differential expression analysis
# ---------------------------------------------------------------------------
def per_protein_ttest(
    expr: pd.DataFrame,
    groups: pd.Series,
    group_a: str,
    group_b: str,
) -> pd.DataFrame:
    """Two-sided independent t-test per protein between two groups.

    Parameters
    ----------
    expr : pd.DataFrame
        Protein expression matrix (samples x proteins).
    groups : pd.Series
        Group labels aligned with expr rows.
    group_a, group_b : str
        Labels for the two groups to compare.

    Returns
    -------
    pd.DataFrame
        Columns: 'protein', 'mean_a', 'mean_b', 'log2fc' (mean_a - mean_b
        for log-scale data), 'tstat', 'pvalue'.
    """
    mask_a = groups == group_a
    mask_b = groups == group_b
    expr_a = expr.loc[mask_a]
    expr_b = expr.loc[mask_b]

    results = []
    for col in expr.columns:
        vals_a = expr_a[col].dropna()
        vals_b = expr_b[col].dropna()
        if len(vals_a) < 2 or len(vals_b) < 2:
            results.append({
                "protein": col, "mean_a": np.nan, "mean_b": np.nan,
                "log2fc": np.nan, "tstat": np.nan, "pvalue": np.nan,
            })
            continue
        t_stat, p_val = stats.ttest_ind(vals_a, vals_b, equal_var=False)
        ma, mb = vals_a.mean(), vals_b.mean()
        results.append({
            "protein": col,
            "mean_a": ma,
            "mean_b": mb,
            "log2fc": ma - mb,  # difference in log-scale = log2 fold change
            "tstat": t_stat,
            "pvalue": p_val,
        })
    return pd.DataFrame(results)


def one_vs_rest_ttest(
    expr: pd.DataFrame,
    groups: pd.Series,
    target_group: str,
) -> pd.DataFrame:
    """Per-protein two-sided t-test: target_group vs all other groups combined.

    Parameters
    ----------
    expr : pd.DataFrame
        Protein expression matrix.
    groups : pd.Series
        Group labels.
    target_group : str
        The group to compare against the rest.

    Returns
    -------
    pd.DataFrame
        Columns: 'protein', 'mean_target', 'mean_rest', 'diff', 'tstat', 'pvalue'.
    """
    mask_target = groups == target_group
    mask_rest = ~mask_target

    results = []
    for col in expr.columns:
        vals_t = expr.loc[mask_target, col].dropna()
        vals_r = expr.loc[mask_rest, col].dropna()
        if len(vals_t) < 2 or len(vals_r) < 2:
            results.append({
                "protein": col, "mean_target": np.nan, "mean_rest": np.nan,
                "diff": np.nan, "tstat": np.nan, "pvalue": np.nan,
            })
            continue
        t_stat, p_val = stats.ttest_ind(vals_t, vals_r, equal_var=False)
        mt, mr = vals_t.mean(), vals_r.mean()
        results.append({
            "protein": col,
            "mean_target": mt,
            "mean_rest": mr,
            "diff": mt - mr,
            "tstat": t_stat,
            "pvalue": p_val,
        })
    return pd.DataFrame(results)


def adjust_pvalues(
    pvalues: Union[np.ndarray, pd.Series],
    method: str = "fdr_bh",
) -> np.ndarray:
    """Multiple testing correction.

    Parameters
    ----------
    pvalues : array-like
        Raw p-values.
    method : str
        Correction method: 'fdr_bh' (Benjamini-Hochberg), 'bonferroni',
        'holm', 'fdr_by'.

    Returns
    -------
    np.ndarray
        Adjusted p-values.
    """
    from statsmodels.stats.multitest import multipletests
    pvals = np.asarray(pvalues, dtype=float)
    # Handle NaN
    mask = ~np.isnan(pvals)
    adjusted = np.full_like(pvals, np.nan)
    if mask.sum() > 0:
        _, adj, _, _ = multipletests(pvals[mask], method=method)
        adjusted[mask] = adj
    return adjusted


def classify_significance(
    de_results: pd.DataFrame,
    pval_col: str = "padj",
    fc_col: str = "log2fc",
    pval_thresh: float = 0.05,
    fc_thresh: float = 0.0,
) -> pd.Series:
    """Classify proteins as 'up', 'down', or 'ns' (not significant).

    Parameters
    ----------
    de_results : pd.DataFrame
        Must contain columns for adjusted p-values and fold changes.
    pval_col : str
        Column with adjusted p-values.
    fc_col : str
        Column with log2 fold changes or NPX differences.
    pval_thresh : float
        Significance threshold for adjusted p-value.
    fc_thresh : float
        Minimum absolute fold change for significance.

    Returns
    -------
    pd.Series
        Classification labels: 'Significant up', 'Significant down', 'not significant'.
    """
    sig = pd.Series("not significant", index=de_results.index)
    up = (de_results[pval_col] < pval_thresh) & (de_results[fc_col] > fc_thresh)
    down = (de_results[pval_col] < pval_thresh) & (de_results[fc_col] < -fc_thresh)
    sig[up] = "Significant up"
    sig[down] = "Significant down"
    return sig


# ---------------------------------------------------------------------------
# Dimensionality reduction
# ---------------------------------------------------------------------------
def run_pca(
    expr: pd.DataFrame,
    n_components: int = 2,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Principal Component Analysis on expression matrix.

    Parameters
    ----------
    expr : pd.DataFrame
        Expression matrix (samples x proteins). NaNs will be imputed with median.
    n_components : int
        Number of PCs to compute.

    Returns
    -------
    scores : np.ndarray
        PCA scores (n_samples x n_components).
    explained_var : np.ndarray
        Explained variance ratio per component.
    loadings : np.ndarray
        PC loadings (n_components x n_proteins).
    """
    from sklearn.decomposition import PCA
    data = expr.fillna(expr.median())
    pca = PCA(n_components=n_components)
    scores = pca.fit_transform(data.values)
    return scores, pca.explained_variance_ratio_, pca.components_


def run_umap(
    expr: pd.DataFrame,
    n_components: int = 2,
    n_neighbors: int = 15,
    min_dist: float = 0.1,
    random_state: int = 42,
) -> np.ndarray:
    """UMAP dimensionality reduction on expression matrix.

    Parameters
    ----------
    expr : pd.DataFrame
        Expression matrix.
    n_components : int
        Embedding dimensions.
    n_neighbors : int
        UMAP neighborhood size.
    min_dist : float
        UMAP minimum distance.
    random_state : int
        Random seed.

    Returns
    -------
    np.ndarray
        UMAP embedding (n_samples x n_components).
    """
    import umap
    data = expr.fillna(expr.median())
    reducer = umap.UMAP(
        n_components=n_components,
        n_neighbors=n_neighbors,
        min_dist=min_dist,
        random_state=random_state,
    )
    return reducer.fit_transform(data.values)


# ---------------------------------------------------------------------------
# Correlation analysis
# ---------------------------------------------------------------------------
def protein_protein_correlation(
    expr: pd.DataFrame,
    proteins: Optional[List[str]] = None,
    method: str = "pearson",
) -> pd.DataFrame:
    """Compute pairwise correlation between proteins.

    Parameters
    ----------
    expr : pd.DataFrame
        Expression matrix.
    proteins : list of str, optional
        Subset of protein names. If None, all proteins are used.
    method : str
        'pearson' or 'spearman'.

    Returns
    -------
    pd.DataFrame
        Symmetric correlation matrix.
    """
    subset = expr[proteins] if proteins is not None else expr
    return subset.corr(method=method)


# ---------------------------------------------------------------------------
# Pathway / Gene Ontology enrichment
# ---------------------------------------------------------------------------
def go_enrichment(
    gene_list: List[str],
    background: Optional[List[str]] = None,
    organism: str = "human",
    ontology: str = "BP",
    pvalue_cutoff: float = 0.05,
) -> pd.DataFrame:
    """Gene Ontology over-representation analysis using gseapy/Enrichr.

    Parameters
    ----------
    gene_list : list of str
        List of gene/protein names to test.
    background : list of str, optional
        Background gene set. If None, uses default Enrichr background.
    organism : str
        Organism name.
    ontology : str
        GO category: 'BP' (biological process), 'MF' (molecular function),
        'CC' (cellular component).
    pvalue_cutoff : float
        Significance threshold.

    Returns
    -------
    pd.DataFrame
        Enrichment results with columns: Term, Overlap, P-value, Adjusted P-value,
        Genes, Combined Score.
    """
    import gseapy as gp
    go_lib = f"GO_Biological_Process_2023"
    if ontology == "MF":
        go_lib = "GO_Molecular_Function_2023"
    elif ontology == "CC":
        go_lib = "GO_Cellular_Component_2023"

    enr = gp.enrichr(
        gene_list=gene_list,
        gene_sets=go_lib,
        organism=organism,
        outdir=None,
        no_plot=True,
        cutoff=pvalue_cutoff,
    )
    return enr.results


def pathway_enrichment(
    gene_list: List[str],
    database: str = "KEGG_2021_Human",
    pvalue_cutoff: float = 0.05,
) -> pd.DataFrame:
    """Pathway over-representation analysis using Enrichr.

    Parameters
    ----------
    gene_list : list of str
        Protein/gene names.
    database : str
        Enrichr library name (e.g., 'KEGG_2021_Human', 'Reactome_2022',
        'WikiPathway_2023_Human').
    pvalue_cutoff : float
        Significance threshold.

    Returns
    -------
    pd.DataFrame
        Enrichment results.
    """
    import gseapy as gp
    enr = gp.enrichr(
        gene_list=gene_list,
        gene_sets=database,
        organism="human",
        outdir=None,
        no_plot=True,
        cutoff=pvalue_cutoff,
    )
    return enr.results


# ---------------------------------------------------------------------------
# Classification
# ---------------------------------------------------------------------------
def train_glmnet_classifier(
    X_train: np.ndarray,
    y_train: np.ndarray,
    alpha: float = 0.5,
    cv_folds: int = 5,
    max_iter: int = 1000,
) -> object:
    """Train an elastic net logistic regression classifier.

    Parameters
    ----------
    X_train : np.ndarray
        Training features (n_samples x n_features).
    y_train : np.ndarray
        Training labels.
    alpha : float
        Elastic net mixing parameter (0=ridge, 1=lasso).
    cv_folds : int
        Number of cross-validation folds.
    max_iter : int
        Maximum iterations.

    Returns
    -------
    model : fitted sklearn model
    """
    from sklearn.linear_model import LogisticRegressionCV
    model = LogisticRegressionCV(
        penalty="elasticnet",
        solver="saga",
        l1_ratios=[alpha],
        cv=cv_folds,
        max_iter=max_iter,
        random_state=42,
        n_jobs=-1,
    )
    model.fit(X_train, y_train)
    return model


def train_binary_classifier(
    X_train: np.ndarray,
    y_train: np.ndarray,
    method: str = "logistic",
    **kwargs,
) -> object:
    """Train a binary classifier.

    Parameters
    ----------
    X_train : np.ndarray
        Training features.
    y_train : np.ndarray
        Binary labels.
    method : str
        'logistic', 'rf' (random forest), or 'svm'.

    Returns
    -------
    model : fitted model
    """
    if method == "logistic":
        from sklearn.linear_model import LogisticRegression
        model = LogisticRegression(
            max_iter=kwargs.get("max_iter", 1000),
            random_state=42,
        )
    elif method == "rf":
        from sklearn.ensemble import RandomForestClassifier
        model = RandomForestClassifier(
            n_estimators=kwargs.get("n_estimators", 100),
            random_state=42,
        )
    elif method == "svm":
        from sklearn.svm import SVC
        model = SVC(probability=True, random_state=42)
    else:
        raise ValueError(f"Unknown method: {method}")
    model.fit(X_train, y_train)
    return model


def evaluate_classifier(
    model: object,
    X_test: np.ndarray,
    y_test: np.ndarray,
) -> Dict[str, float]:
    """Evaluate a classifier and return performance metrics.

    Parameters
    ----------
    model : fitted model
        Must have predict and predict_proba methods.
    X_test : np.ndarray
        Test features.
    y_test : np.ndarray
        True labels.

    Returns
    -------
    dict
        Keys: 'accuracy', 'auc', 'sensitivity', 'specificity', 'ppv', 'npv',
        'f1', 'precision', 'recall'.
    """
    from sklearn.metrics import (
        accuracy_score, roc_auc_score, f1_score,
        precision_score, recall_score, confusion_matrix,
    )
    y_pred = model.predict(X_test)

    metrics = {
        "accuracy": accuracy_score(y_test, y_pred),
        "f1": f1_score(y_test, y_pred, average="weighted", zero_division=0),
        "precision": precision_score(y_test, y_pred, average="weighted", zero_division=0),
        "recall": recall_score(y_test, y_pred, average="weighted", zero_division=0),
    }

    # AUC
    if hasattr(model, "predict_proba"):
        proba = model.predict_proba(X_test)
        try:
            if proba.shape[1] == 2:
                # Select the probability column for the positive class by name.
                # model.classes_ is sorted (e.g. alphabetical for string labels),
                # so proba[:, 1] is NOT necessarily the clinically positive class.
                # Pick 'Cancer' as positive when present (case-insensitive),
                # otherwise the lexicographically larger label, so the AUC
                # direction is correct regardless of label string order.
                classes = list(getattr(model, "classes_", np.unique(y_test)))
                pos_label = None
                for c in classes:
                    if str(c).strip().lower() == "cancer":
                        pos_label = c
                        break
                if pos_label is None:
                    pos_label = classes[-1]
                pos_idx = classes.index(pos_label)
                metrics["auc"] = roc_auc_score(
                    (np.asarray(y_test) == pos_label).astype(int),
                    proba[:, pos_idx],
                )
            else:
                metrics["auc"] = roc_auc_score(
                    y_test, proba, multi_class="ovr", average="weighted",
                )
        except ValueError:
            metrics["auc"] = np.nan

    # Binary confusion matrix metrics
    classes = np.unique(y_test)
    if len(classes) == 2:
        cm = confusion_matrix(y_test, y_pred)
        tn, fp, fn, tp = cm.ravel()
        metrics["sensitivity"] = tp / (tp + fn) if (tp + fn) > 0 else 0.0
        metrics["specificity"] = tn / (tn + fp) if (tn + fp) > 0 else 0.0
        metrics["ppv"] = tp / (tp + fp) if (tp + fp) > 0 else 0.0
        metrics["npv"] = tn / (tn + fn) if (tn + fn) > 0 else 0.0

    return metrics


def compute_roc_curve(
    y_true: np.ndarray,
    y_scores: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray, float]:
    """Compute ROC curve and AUC.

    Parameters
    ----------
    y_true : np.ndarray
        True binary labels.
    y_scores : np.ndarray
        Predicted probabilities for the positive class.

    Returns
    -------
    fpr : np.ndarray
        False positive rates.
    tpr : np.ndarray
        True positive rates.
    auc : float
        Area under the ROC curve.
    """
    from sklearn.metrics import roc_curve, auc
    fpr, tpr, _ = roc_curve(y_true, y_scores)
    roc_auc = auc(fpr, tpr)
    return fpr, tpr, roc_auc


def get_feature_importance(
    model: object,
    feature_names: List[str],
    method: str = "auto",
) -> pd.DataFrame:
    """Extract feature importance from a fitted model.

    Parameters
    ----------
    model : fitted model
        Classifier with coef_ or feature_importances_ attribute.
    feature_names : list of str
        Names corresponding to the features.
    method : str
        'auto' to detect from model type, 'coef' for coefficients,
        'importance' for tree importances.

    Returns
    -------
    pd.DataFrame
        Columns: 'protein', 'importance', sorted by absolute importance.
    """
    if method == "auto":
        if hasattr(model, "coef_"):
            importance = np.abs(model.coef_).ravel()
        elif hasattr(model, "feature_importances_"):
            importance = model.feature_importances_
        else:
            raise ValueError("Model has no coef_ or feature_importances_")
    elif method == "coef":
        importance = np.abs(model.coef_).ravel()
    elif method == "importance":
        importance = model.feature_importances_
    else:
        raise ValueError(f"Unknown method: {method}")

    # Handle multi-class (coef_ is 2D)
    if len(importance) != len(feature_names):
        if hasattr(model, "coef_") and model.coef_.ndim == 2:
            importance = np.mean(np.abs(model.coef_), axis=0)

    df = pd.DataFrame({"protein": feature_names, "importance": importance})
    return df.sort_values("importance", ascending=False).reset_index(drop=True)


def normalize_importance(
    importance_df: pd.DataFrame,
    importance_col: str = "importance",
) -> pd.DataFrame:
    """Rescale per-cancer feature importances to a 0-100% scale.

    For one-vs-rest glmnet/logistic models the raw importances (absolute
    coefficients) are on an arbitrary per-model scale, so they are not
    comparable across cancers. This helper rescales each model's importances
    so the largest contributing protein is 100% and a zero coefficient is 0%:

        importance_pct = 100 * |coef| / max(|coef|).

    This is the normalization used to apply the ">50% importance" panel rule.

    Parameters
    ----------
    importance_df : pd.DataFrame
        Output of ``get_feature_importance`` (columns 'protein', importance_col).
    importance_col : str
        Name of the raw importance column.

    Returns
    -------
    pd.DataFrame
        Same rows with an added 'importance_pct' column (0-100), sorted
        descending by importance.
    """
    out = importance_df.copy()
    mx = float(np.nanmax(np.abs(out[importance_col].values))) if len(out) else 0.0
    if mx <= 0:
        out["importance_pct"] = 0.0
    else:
        out["importance_pct"] = 100.0 * np.abs(out[importance_col].values) / mx
    return out.sort_values("importance_pct", ascending=False).reset_index(drop=True)


def select_panel_proteins(
    importance_df: pd.DataFrame,
    de_results: Optional[pd.DataFrame] = None,
    importance_col: str = "importance",
    de_protein_col: str = "protein",
    de_direction_col: Optional[str] = None,
    importance_pct_thresh: float = 50.0,
    min_proteins: int = 3,
) -> pd.DataFrame:
    """Select per-cancer pan-cancer panel members from a one-vs-rest model.

    Implements the three-criterion inclusion rule used to assemble the
    pan-cancer panel from each one-vs-rest model:

    1. **Importance** — keep proteins whose normalized glmnet importance
       exceeds ``importance_pct_thresh`` percent of the model's top protein
       (see :func:`normalize_importance`).
    2. **Direction** — when ``de_results`` and ``de_direction_col`` are given,
       restrict to proteins flagged as upregulated by the one-vs-rest
       differential-expression analysis (``de_direction_col`` value containing
       "up").
    3. **Minimum size** — guarantee at least ``min_proteins`` members per
       cancer; if criteria 1-2 admit fewer, the next-highest-importance
       proteins (regardless of the 50% cutoff) are added to reach the minimum.

    Parameters
    ----------
    importance_df : pd.DataFrame
        Per-protein importances for one cancer's one-vs-rest model
        (output of ``get_feature_importance``).
    de_results : pd.DataFrame or None
        Optional one-vs-rest DE table used for the up-regulation filter.
    importance_col : str
        Raw importance column name in ``importance_df``.
    de_protein_col : str
        Protein-name column in ``de_results``.
    de_direction_col : str or None
        Column in ``de_results`` holding 'Significant up'/'Significant down'
        labels (e.g. the output of ``classify_significance``). If None, the
        up-regulation filter is skipped.
    importance_pct_thresh : float
        Importance percent cutoff (default 50%).
    min_proteins : int
        Minimum number of panel members per cancer (default 3).

    Returns
    -------
    pd.DataFrame
        Selected panel proteins with columns 'protein', importance_col,
        'importance_pct', sorted by importance, ready to be concatenated
        across cancers to form the pan-cancer panel.
    """
    ranked = normalize_importance(importance_df, importance_col=importance_col)

    keep = ranked["importance_pct"] >= importance_pct_thresh

    if de_results is not None and de_direction_col is not None and \
            de_direction_col in de_results.columns:
        up_mask = de_results[de_direction_col].astype(str).str.contains(
            "up", case=False, na=False
        )
        up_proteins = set(de_results.loc[up_mask, de_protein_col].astype(str))
        keep = keep & ranked["protein"].astype(str).isin(up_proteins)

    selected = ranked[keep]

    # Criterion 3: enforce the minimum panel size.
    if len(selected) < min_proteins:
        extra = ranked[~ranked.index.isin(selected.index)].head(
            min_proteins - len(selected)
        )
        selected = pd.concat([selected, extra])

    return selected.sort_values("importance_pct", ascending=False).reset_index(drop=True)


def split_train_test(
    X: np.ndarray,
    y: np.ndarray,
    test_size: float = 0.3,
    random_state: int = 42,
    stratify: bool = True,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Split data into training and test sets.

    Parameters
    ----------
    X : np.ndarray
        Feature matrix.
    y : np.ndarray
        Labels.
    test_size : float
        Fraction for test set.
    random_state : int
        Random seed.
    stratify : bool
        Whether to stratify by labels.

    Returns
    -------
    X_train, X_test, y_train, y_test
    """
    from sklearn.model_selection import train_test_split
    return train_test_split(
        X, y,
        test_size=test_size,
        random_state=random_state,
        stratify=y if stratify else None,
    )


# ---------------------------------------------------------------------------
# Visualization helpers
# ---------------------------------------------------------------------------
def plot_volcano(
    de_results: pd.DataFrame,
    fc_col: str = "log2fc",
    pval_col: str = "padj",
    significance_col: str = "significance",
    title: str = "Volcano Plot",
    output_path: str = "artifacts/volcano.png",
    label_top_n: int = 10,
) -> str:
    """Generate a volcano plot from differential expression results.

    Parameters
    ----------
    de_results : pd.DataFrame
        Must have columns for fold change, adjusted p-value, and significance.
    fc_col : str
        Column with fold changes / NPX differences.
    pval_col : str
        Column with adjusted p-values.
    significance_col : str
        Column with 'Significant up', 'Significant down', 'not significant'.
    title : str
        Plot title.
    output_path : str
        File path to save the figure.
    label_top_n : int
        Number of top proteins to label.

    Returns
    -------
    str
        Path to the saved figure.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(10, 8))
    colors = {
        "Significant up": "#E64B35",
        "Significant down": "#4DBBD5",
        "not significant": "#999999",
    }

    for sig_type, color in colors.items():
        mask = de_results[significance_col] == sig_type
        subset = de_results[mask]
        ax.scatter(
            subset[fc_col],
            -np.log10(subset[pval_col].clip(lower=1e-300)),
            c=color, s=8, alpha=0.6, label=sig_type,
        )

    # Label top proteins
    top = de_results.nsmallest(label_top_n, pval_col)
    for _, row in top.iterrows():
        ax.annotate(
            row.get("protein", ""),
            (row[fc_col], -np.log10(max(row[pval_col], 1e-300))),
            fontsize=7, alpha=0.8,
        )

    ax.set_xlabel("NPX difference")
    ax.set_ylabel("-log10(adjusted p-value)")
    ax.set_title(title)
    ax.legend()
    ax.axhline(-np.log10(0.05), color="grey", linestyle="--", linewidth=0.5)

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return output_path


def plot_pca_scatter(
    scores: np.ndarray,
    groups: pd.Series,
    explained_var: np.ndarray,
    title: str = "PCA",
    output_path: str = "artifacts/pca.png",
) -> str:
    """PCA scatter plot colored by group.

    Parameters
    ----------
    scores : np.ndarray
        PCA scores (n_samples x 2).
    groups : pd.Series
        Group labels.
    explained_var : np.ndarray
        Explained variance ratio.
    title : str
        Plot title.
    output_path : str
        Output file path.

    Returns
    -------
    str
        Path to saved figure.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(10, 8))
    unique_groups = groups.unique()
    cmap = plt.cm.get_cmap("tab20", len(unique_groups))

    for i, g in enumerate(sorted(unique_groups)):
        mask = groups.values == g
        ax.scatter(
            scores[mask, 0], scores[mask, 1],
            c=[cmap(i)], label=g, s=20, alpha=0.7,
        )

    ax.set_xlabel(f"PC1 ({explained_var[0]*100:.1f}%)")
    ax.set_ylabel(f"PC2 ({explained_var[1]*100:.1f}%)")
    ax.set_title(title)
    ax.legend(bbox_to_anchor=(1.05, 1), loc="upper left", fontsize=8)

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return output_path


def plot_heatmap(
    expr: pd.DataFrame,
    proteins: List[str],
    groups: pd.Series,
    title: str = "Heatmap",
    output_path: str = "artifacts/heatmap.png",
    cluster_rows: bool = True,
    cluster_cols: bool = True,
    scale: str = "protein",
) -> str:
    """Clustered heatmap of selected proteins across samples.

    Parameters
    ----------
    expr : pd.DataFrame
        Expression matrix.
    proteins : list of str
        Proteins to include in heatmap.
    groups : pd.Series
        Group labels for sample annotation.
    title : str
        Plot title.
    output_path : str
        Output file path.
    cluster_rows : bool
        Cluster protein rows.
    cluster_cols : bool
        Cluster sample columns.
    scale : str
        'protein' to z-score per protein, 'sample' per sample, None for raw.

    Returns
    -------
    str
        Path to saved figure.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import seaborn as sns

    subset = expr[proteins].copy()
    if scale == "protein":
        subset = (subset - subset.mean()) / subset.std()
    elif scale == "sample":
        subset = subset.T
        subset = (subset - subset.mean()) / subset.std()
        subset = subset.T

    # Sort by group
    order = groups.sort_values().index
    subset = subset.loc[order]

    fig, ax = plt.subplots(figsize=(max(12, len(proteins) * 0.3), 8))
    sns.heatmap(
        subset.T, cmap="RdBu_r", center=0,
        xticklabels=False, yticklabels=True if len(proteins) <= 50 else False,
        ax=ax,
    )
    ax.set_title(title)

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return output_path


def plot_roc_curves(
    roc_data: Dict[str, Tuple[np.ndarray, np.ndarray, float]],
    title: str = "ROC Curves",
    output_path: str = "artifacts/roc_curves.png",
) -> str:
    """Plot multiple ROC curves on one figure.

    Parameters
    ----------
    roc_data : dict
        Keys are labels, values are (fpr, tpr, auc) tuples.
    title : str
        Plot title.
    output_path : str
        Output file path.

    Returns
    -------
    str
        Path to saved figure.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(8, 8))
    for label, (fpr, tpr, auc_val) in roc_data.items():
        ax.plot(fpr, tpr, label=f"{label} (AUC={auc_val:.2f})")

    ax.plot([0, 1], [0, 1], "k--", alpha=0.3)
    ax.set_xlabel("1 - Specificity")
    ax.set_ylabel("Sensitivity")
    ax.set_title(title)
    ax.legend(loc="lower right", fontsize=8)

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return output_path


def plot_protein_boxplot(
    expr: pd.DataFrame,
    groups: pd.Series,
    protein: str,
    title: Optional[str] = None,
    output_path: str = "artifacts/boxplot.png",
) -> str:
    """Boxplot of a single protein's expression across groups.

    Parameters
    ----------
    expr : pd.DataFrame
        Expression matrix.
    groups : pd.Series
        Group labels.
    protein : str
        Protein column name.
    title : str, optional
        Plot title. Defaults to protein name.
    output_path : str
        Output file path.

    Returns
    -------
    str
        Path to saved figure.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import seaborn as sns

    fig, ax = plt.subplots(figsize=(12, 6))
    plot_df = pd.DataFrame({"NPX": expr[protein], "Cancer": groups.values})
    sns.boxplot(x="Cancer", y="NPX", data=plot_df, ax=ax)
    ax.set_title(title or protein)
    ax.tick_params(axis="x", rotation=45)

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return output_path


def plot_dep_barplot(
    dep_counts: Dict[str, Tuple[int, int, int]],
    title: str = "Differentially Expressed Proteins",
    output_path: str = "artifacts/dep_barplot.png",
) -> str:
    """Stacked bar plot of DEP counts (up/down/ns) per cancer type.

    Parameters
    ----------
    dep_counts : dict
        Keys are cancer names, values are (n_up, n_down, n_ns) tuples.
    title : str
        Plot title.
    output_path : str
        Output file path.

    Returns
    -------
    str
        Path to saved figure.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    cancers = list(dep_counts.keys())
    ups = [dep_counts[c][0] for c in cancers]
    downs = [dep_counts[c][1] for c in cancers]
    ns = [dep_counts[c][2] for c in cancers]

    fig, ax = plt.subplots(figsize=(12, 6))
    x = np.arange(len(cancers))
    ax.bar(x, ups, label="Significant up", color="#E64B35")
    ax.bar(x, downs, bottom=ups, label="Significant down", color="#4DBBD5")
    ax.bar(x, ns, bottom=[u + d for u, d in zip(ups, downs)],
           label="Not significant", color="#999999")

    ax.set_xticks(x)
    ax.set_xticklabels(cancers, rotation=45, ha="right")
    ax.set_ylabel("Number of proteins")
    ax.set_title(title)
    ax.legend()

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return output_path


def plot_upset(
    sets_dict: Dict[str, set],
    title: str = "Upset Plot",
    output_path: str = "artifacts/upset.png",
) -> str:
    """UpSet plot showing overlap of protein sets across groups.

    Parameters
    ----------
    sets_dict : dict
        Keys are set names (e.g., cancer types), values are sets of protein names.
    title : str
        Plot title.
    output_path : str
        Output file path.

    Returns
    -------
    str
        Path to saved figure.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from upsetplot import from_memberships, UpSet

    # Convert to membership format
    memberships = []
    for protein in set.union(*sets_dict.values()):
        member_of = [k for k, v in sets_dict.items() if protein in v]
        memberships.append(member_of)

    data = from_memberships(memberships)
    upset = UpSet(data, show_counts=True, sort_by="cardinality")
    fig = plt.figure(figsize=(14, 8))
    upset.plot(fig=fig)
    fig.suptitle(title)

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return output_path


def plot_network(
    corr_matrix: pd.DataFrame,
    threshold: float = 0.6,
    node_groups: Optional[Dict[str, str]] = None,
    title: str = "Protein Network",
    output_path: str = "artifacts/network.png",
) -> str:
    """Network visualization of protein-protein correlations.

    Parameters
    ----------
    corr_matrix : pd.DataFrame
        Pairwise correlation matrix.
    threshold : float
        Minimum absolute correlation to draw an edge.
    node_groups : dict, optional
        Map protein name -> group label for coloring nodes.
    title : str
        Plot title.
    output_path : str
        Output file path.

    Returns
    -------
    str
        Path to saved figure.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import networkx as nx

    G = nx.Graph()
    proteins = corr_matrix.columns.tolist()
    G.add_nodes_from(proteins)

    for i, p1 in enumerate(proteins):
        for j, p2 in enumerate(proteins):
            if i < j:
                r = corr_matrix.iloc[i, j]
                if abs(r) >= threshold:
                    G.add_edge(p1, p2, weight=abs(r))

    # Remove isolated nodes
    G.remove_nodes_from(list(nx.isolates(G)))

    if len(G.nodes()) == 0:
        # No edges above threshold
        fig, ax = plt.subplots(figsize=(8, 8))
        ax.text(0.5, 0.5, f"No edges above threshold={threshold}",
                ha="center", va="center", fontsize=14)
        ax.set_title(title)
    else:
        fig, ax = plt.subplots(figsize=(12, 12))
        pos = nx.spring_layout(G, seed=42, k=2.0)

        if node_groups:
            unique_groups = list(set(node_groups.values()))
            cmap = plt.cm.get_cmap("tab10", len(unique_groups))
            node_colors = [
                cmap(unique_groups.index(node_groups.get(n, unique_groups[0])))
                for n in G.nodes()
            ]
        else:
            node_colors = "#4DBBD5"

        nx.draw_networkx(
            G, pos, ax=ax,
            node_color=node_colors, node_size=100,
            font_size=6, font_weight="bold",
            edge_color="#cccccc", width=0.5,
        )
        ax.set_title(title)

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return output_path


def plot_confusion_matrix(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    labels: Optional[List[str]] = None,
    title: str = "Confusion Matrix",
    output_path: str = "artifacts/confusion_matrix.png",
) -> str:
    """Plot a confusion matrix heatmap.

    Parameters
    ----------
    y_true : np.ndarray
        True labels.
    y_pred : np.ndarray
        Predicted labels.
    labels : list of str, optional
        Class labels.
    title : str
        Plot title.
    output_path : str
        Output file path.

    Returns
    -------
    str
        Path to saved figure.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import seaborn as sns
    from sklearn.metrics import confusion_matrix

    cm = confusion_matrix(y_true, y_pred, labels=labels)
    fig, ax = plt.subplots(figsize=(10, 8))
    sns.heatmap(
        cm, annot=True, fmt="d", cmap="Blues",
        xticklabels=labels or np.unique(y_true),
        yticklabels=labels or np.unique(y_true),
        ax=ax,
    )
    ax.set_xlabel("Predicted")
    ax.set_ylabel("True")
    ax.set_title(title)

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return output_path


def plot_importance_rank(
    importance_df: pd.DataFrame,
    top_n: int = 20,
    title: str = "Protein Importance",
    output_path: str = "artifacts/importance.png",
) -> str:
    """Lollipop or bar chart of top-N protein importances.

    Parameters
    ----------
    importance_df : pd.DataFrame
        Must have 'protein' and 'importance' columns.
    top_n : int
        Number of top proteins to show.
    title : str
        Plot title.
    output_path : str
        Output file path.

    Returns
    -------
    str
        Path to saved figure.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    top = importance_df.head(top_n).sort_values("importance")
    fig, ax = plt.subplots(figsize=(8, max(6, top_n * 0.3)))
    ax.barh(top["protein"], top["importance"], color="#E64B35")
    ax.set_xlabel("Importance")
    ax.set_title(title)

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return output_path

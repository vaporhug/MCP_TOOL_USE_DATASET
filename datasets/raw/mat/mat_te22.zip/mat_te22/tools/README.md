# mat_te22 - Tool reference

Tools for analysing thermoelectric data exported by a public TE platform
(Starrydata2-style ``samples`` + ``curves`` CSV layout).

## Dependencies

* Python >=3.10
* ``mcp.server.fastmcp`` (FastMCP)
* ``matplotlib``
* (standard library: ``csv``, ``json``, ``re``, ``math``)

## Modules

### ``data_io.py`` - generic IO and table primitives

* **read_csv(path, max_rows=None)** - Parse CSV into a list-of-dicts.
* **write_csv(rows, path)** - Persist list-of-dicts; returns absolute path.
* **read_json(path)** / **write_json(obj, path, indent=2)** - JSON helpers.
* **parse_xy_list(s)** - Decode the JSON-encoded float lists used by Starrydata2.
* **filter_rows(rows, equals=None, contains=None)** - Equality and substring filters.
* **groupby_count(rows, by)** - ``{value: count}`` per group.
* **groupby_aggregate(rows, by, value, agg)** - max/min/mean/count aggregator.

### ``composition.py`` - chemistry primitives

* **parse_formula(formula)** - Tokenise a formula string into ``{element: amount}``.
* **normalize_composition(formula_dict)** - Rescale to mole fractions summing to 1.
* **element_properties(symbol)** - Returns ``Z``, ``M``, ``group``, ``period``, ``EN``.
* **list_supported_elements()** - All symbols supported by ``element_properties``.
* **host_dopant_split(formula_dict, host_elements, dopant_threshold=0.0)** - Separate host atoms from dopants.
* **is_doped_compound(formula, host_elements)** - Boolean test for any non-host atom.
* **composition_features(formula)** - molar mass + average Pauling EN + element count.

### ``te_analysis.py`` - thermoelectric analysis primitives

* **load_te_curves(curves_csv, prop_y=None, sample_id=None)** - Load curves with optional property/sample filters; ``x``/``y`` strings become Python lists.
* **load_te_samples(samples_csv, family=None)** - Sample metadata, optionally filtered by the ``fam`` / MaterialFamily column (``SnSe`` or ``Bi2Te3``).
* **peak_zt(x, y)** - ``{T_peak, ZT_peak}`` from a single curve.
* **convert_power_factor_values(values, from_unit, to_unit="microW cm^-1 K^-2")** - Convert raw Starrydata2 power-factor curves from `W*m^(-1)*K^(-2)` to reporting units.
* **compute_power_factor(S_values, sigma_values, seebeck_unit="V*K^(-1)", conductivity_unit="S*m^(-1)", output_unit="microW cm^-1 K^-2")** - Element-wise PF with explicit unit conversion.
* **aggregate_peak_zt_by_sample(curves_csv, family, samples_csv, zt_max_clip=3.5)** - Per-sample peak-ZT records with non-physical traces dropped; ``family`` filters the ``fam`` / MaterialFamily column.
* **doping_element_zt_stats(peak_zt_records, host_elements)** - Per-dopant
  statistics (max, mean, n) plus explicit diagnostics for non-parseable
  composition strings and host-only records excluded from dopant leaderboards.
* **linear_interpolate_at(x, y, x_target)** - Property at a given temperature.
* **family_summary(samples_csv)** - Sample count per ``fam`` / MaterialFamily value.
* **plot_zt_vs_temperature(curves_csv, out_path, samples_csv, family, top_k, zt_max_clip)** - Overlay top-k ZT curves for a ``fam`` / MaterialFamily value; returns PNG path.
* **plot_pf_vs_temperature(curves_csv, out_path, samples_csv, family, top_k, output_unit="microW cm^-1 K^-2")** - Power-factor overlay for a ``fam`` / MaterialFamily value; raw `W*m^(-1)*K^(-2)` curves are converted before plotting.
* **plot_dopant_ranking(peak_records, host_elements, out_path, top_k, title)** - Bar chart of top dopants by max/mean ZT; returns PNG path.

## Running

Each module exposes a FastMCP server. Run any module directly to start it
on stdio, e.g.:

```
python tools/te_analysis.py
```

Tools can also be imported and called as ordinary Python functions during
unit testing.

"""Composition parsing and element-property primitives.

All helpers are deliberately low-level: the caller decides how to combine
element fractions, dopant flags, etc. into a feature vector.
"""
from __future__ import annotations

import re
from typing import Any

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("TE_Composition")


# Built-in periodic-table table (Z, symbol, atomic mass, group, period,
# Pauling electronegativity). Values are taken from the 2021 IUPAC table
# (atomic weight) and the standard CRC handbook (electronegativity).
_ELEMENTS: dict[str, dict] = {
    "H":  {"Z": 1,  "M": 1.008,   "group": 1,  "period": 1, "EN": 2.20},
    "Li": {"Z": 3,  "M": 6.94,    "group": 1,  "period": 2, "EN": 0.98},
    "Be": {"Z": 4,  "M": 9.0122,  "group": 2,  "period": 2, "EN": 1.57},
    "B":  {"Z": 5,  "M": 10.81,   "group": 13, "period": 2, "EN": 2.04},
    "C":  {"Z": 6,  "M": 12.011,  "group": 14, "period": 2, "EN": 2.55},
    "N":  {"Z": 7,  "M": 14.007,  "group": 15, "period": 2, "EN": 3.04},
    "O":  {"Z": 8,  "M": 15.999,  "group": 16, "period": 2, "EN": 3.44},
    "F":  {"Z": 9,  "M": 18.998,  "group": 17, "period": 2, "EN": 3.98},
    "Na": {"Z": 11, "M": 22.990,  "group": 1,  "period": 3, "EN": 0.93},
    "Mg": {"Z": 12, "M": 24.305,  "group": 2,  "period": 3, "EN": 1.31},
    "Al": {"Z": 13, "M": 26.982,  "group": 13, "period": 3, "EN": 1.61},
    "Si": {"Z": 14, "M": 28.085,  "group": 14, "period": 3, "EN": 1.90},
    "P":  {"Z": 15, "M": 30.974,  "group": 15, "period": 3, "EN": 2.19},
    "S":  {"Z": 16, "M": 32.06,   "group": 16, "period": 3, "EN": 2.58},
    "Cl": {"Z": 17, "M": 35.45,   "group": 17, "period": 3, "EN": 3.16},
    "K":  {"Z": 19, "M": 39.098,  "group": 1,  "period": 4, "EN": 0.82},
    "Ca": {"Z": 20, "M": 40.078,  "group": 2,  "period": 4, "EN": 1.00},
    "Sc": {"Z": 21, "M": 44.956,  "group": 3,  "period": 4, "EN": 1.36},
    "Ti": {"Z": 22, "M": 47.867,  "group": 4,  "period": 4, "EN": 1.54},
    "V":  {"Z": 23, "M": 50.942,  "group": 5,  "period": 4, "EN": 1.63},
    "Cr": {"Z": 24, "M": 51.996,  "group": 6,  "period": 4, "EN": 1.66},
    "Mn": {"Z": 25, "M": 54.938,  "group": 7,  "period": 4, "EN": 1.55},
    "Fe": {"Z": 26, "M": 55.845,  "group": 8,  "period": 4, "EN": 1.83},
    "Co": {"Z": 27, "M": 58.933,  "group": 9,  "period": 4, "EN": 1.88},
    "Ni": {"Z": 28, "M": 58.693,  "group": 10, "period": 4, "EN": 1.91},
    "Cu": {"Z": 29, "M": 63.546,  "group": 11, "period": 4, "EN": 1.90},
    "Zn": {"Z": 30, "M": 65.38,   "group": 12, "period": 4, "EN": 1.65},
    "Ga": {"Z": 31, "M": 69.723,  "group": 13, "period": 4, "EN": 1.81},
    "Ge": {"Z": 32, "M": 72.630,  "group": 14, "period": 4, "EN": 2.01},
    "As": {"Z": 33, "M": 74.922,  "group": 15, "period": 4, "EN": 2.18},
    "Se": {"Z": 34, "M": 78.971,  "group": 16, "period": 4, "EN": 2.55},
    "Br": {"Z": 35, "M": 79.904,  "group": 17, "period": 4, "EN": 2.96},
    "Rb": {"Z": 37, "M": 85.468,  "group": 1,  "period": 5, "EN": 0.82},
    "Sr": {"Z": 38, "M": 87.62,   "group": 2,  "period": 5, "EN": 0.95},
    "Y":  {"Z": 39, "M": 88.906,  "group": 3,  "period": 5, "EN": 1.22},
    "Zr": {"Z": 40, "M": 91.224,  "group": 4,  "period": 5, "EN": 1.33},
    "Nb": {"Z": 41, "M": 92.906,  "group": 5,  "period": 5, "EN": 1.60},
    "Mo": {"Z": 42, "M": 95.95,   "group": 6,  "period": 5, "EN": 2.16},
    "Tc": {"Z": 43, "M": 98.0,    "group": 7,  "period": 5, "EN": 1.90},
    "Ru": {"Z": 44, "M": 101.07,  "group": 8,  "period": 5, "EN": 2.20},
    "Rh": {"Z": 45, "M": 102.91,  "group": 9,  "period": 5, "EN": 2.28},
    "Pd": {"Z": 46, "M": 106.42,  "group": 10, "period": 5, "EN": 2.20},
    "Ag": {"Z": 47, "M": 107.87,  "group": 11, "period": 5, "EN": 1.93},
    "Cd": {"Z": 48, "M": 112.41,  "group": 12, "period": 5, "EN": 1.69},
    "In": {"Z": 49, "M": 114.82,  "group": 13, "period": 5, "EN": 1.78},
    "Sn": {"Z": 50, "M": 118.71,  "group": 14, "period": 5, "EN": 1.96},
    "Sb": {"Z": 51, "M": 121.76,  "group": 15, "period": 5, "EN": 2.05},
    "Te": {"Z": 52, "M": 127.60,  "group": 16, "period": 5, "EN": 2.10},
    "I":  {"Z": 53, "M": 126.90,  "group": 17, "period": 5, "EN": 2.66},
    "Cs": {"Z": 55, "M": 132.91,  "group": 1,  "period": 6, "EN": 0.79},
    "Ba": {"Z": 56, "M": 137.33,  "group": 2,  "period": 6, "EN": 0.89},
    "La": {"Z": 57, "M": 138.91,  "group": 3,  "period": 6, "EN": 1.10},
    "Ce": {"Z": 58, "M": 140.12,  "group": 3,  "period": 6, "EN": 1.12},
    "Pr": {"Z": 59, "M": 140.91,  "group": 3,  "period": 6, "EN": 1.13},
    "Nd": {"Z": 60, "M": 144.24,  "group": 3,  "period": 6, "EN": 1.14},
    "Sm": {"Z": 62, "M": 150.36,  "group": 3,  "period": 6, "EN": 1.17},
    "Eu": {"Z": 63, "M": 151.96,  "group": 3,  "period": 6, "EN": 1.20},
    "Gd": {"Z": 64, "M": 157.25,  "group": 3,  "period": 6, "EN": 1.20},
    "Tb": {"Z": 65, "M": 158.93,  "group": 3,  "period": 6, "EN": 1.20},
    "Dy": {"Z": 66, "M": 162.50,  "group": 3,  "period": 6, "EN": 1.22},
    "Ho": {"Z": 67, "M": 164.93,  "group": 3,  "period": 6, "EN": 1.23},
    "Er": {"Z": 68, "M": 167.26,  "group": 3,  "period": 6, "EN": 1.24},
    "Tm": {"Z": 69, "M": 168.93,  "group": 3,  "period": 6, "EN": 1.25},
    "Yb": {"Z": 70, "M": 173.05,  "group": 3,  "period": 6, "EN": 1.10},
    "Lu": {"Z": 71, "M": 174.97,  "group": 3,  "period": 6, "EN": 1.27},
    "Hf": {"Z": 72, "M": 178.49,  "group": 4,  "period": 6, "EN": 1.30},
    "Ta": {"Z": 73, "M": 180.95,  "group": 5,  "period": 6, "EN": 1.50},
    "W":  {"Z": 74, "M": 183.84,  "group": 6,  "period": 6, "EN": 2.36},
    "Re": {"Z": 75, "M": 186.21,  "group": 7,  "period": 6, "EN": 1.90},
    "Os": {"Z": 76, "M": 190.23,  "group": 8,  "period": 6, "EN": 2.20},
    "Ir": {"Z": 77, "M": 192.22,  "group": 9,  "period": 6, "EN": 2.20},
    "Pt": {"Z": 78, "M": 195.08,  "group": 10, "period": 6, "EN": 2.28},
    "Au": {"Z": 79, "M": 196.97,  "group": 11, "period": 6, "EN": 2.54},
    "Hg": {"Z": 80, "M": 200.59,  "group": 12, "period": 6, "EN": 2.00},
    "Tl": {"Z": 81, "M": 204.38,  "group": 13, "period": 6, "EN": 1.62},
    "Pb": {"Z": 82, "M": 207.2,   "group": 14, "period": 6, "EN": 2.33},
    "Bi": {"Z": 83, "M": 208.98,  "group": 15, "period": 6, "EN": 2.02},
}

_FORMULA_RE = re.compile(r"([A-Z][a-z]?)(\d+(?:\.\d+)?)?")


@mcp.tool()
def parse_formula(formula: str) -> dict:
    """Parse a chemical formula string into {element: stoichiometric_amount}.

    Recursive-descent parser that handles the real composition strings in
    this thermoelectric database, not just simple linear formulas:
      * decimal subscripts            'Bi1.95Sb0.05Te3'
      * parenthesised groups + mult   '(Bi0.25Sb0.75)2Te3'
      * nested groups + percentages   '((Bi2Te3)0.25(Sb2Te3)0.75)90.01(ZrO2)9.99'
      * alloy slash separators        '(Bi2Te3)/(Sb2Te3)'  (each side weight 1)
      * comma-grouped mixed sites      '(Bi,Sb)2Te3'  (split equally over the group)
      * stray whitespace inside        '(Bi 2Te3)9.02'

    Unknown element tokens raise ``ValueError``. The returned amounts are the
    raw (un-normalised) stoichiometric sums; use ``normalize_composition`` for
    mole fractions and ``host_dopant_split`` to separate host vs dopant atoms.
    """
    if not formula:
        return {}
    s = formula.replace(" ", "")
    # A slash joins two complete alloy end-members with equal weight unless a
    # multiplier follows; split and merge each side at weight 1.0.
    if "/" in s:
        out: dict[str, float] = {}
        for part in s.split("/"):
            if not part:
                continue
            for el, amt in parse_formula(part).items():
                out[el] = out.get(el, 0.0) + amt
        return out

    pos = 0
    n = len(s)

    def parse_group(p: int):
        """Parse a sequence of element/(group) tokens starting at p until a
        closing ')' or end-of-string. Returns (counts, new_pos)."""
        counts: dict[str, float] = {}
        while p < n and s[p] != ")":
            if s[p] == "(":
                inner, p = parse_paren(p)
                for el, a in inner.items():
                    counts[el] = counts.get(el, 0.0) + a
            elif s[p] == ",":
                # comma separates equal-share sites within the current group;
                # handled by parse_paren via the comma flag, so skip here.
                p += 1
            else:
                m = _FORMULA_RE.match(s, p)
                if not m or m.start() != p or not m.group(1):
                    raise ValueError(f"unparsed segment '{s[p:p+6]}' in {formula}")
                sym = m.group(1)
                if sym not in _ELEMENTS:
                    raise ValueError(f"unknown element '{sym}' in {formula}")
                amt = float(m.group(2)) if m.group(2) else 1.0
                counts[sym] = counts.get(sym, 0.0) + amt
                p = m.end()
        return counts, p

    def parse_paren(p: int):
        """Parse a '(...)' group (possibly comma-separated, possibly with a
        trailing multiplier) starting at the '(' at position p."""
        assert s[p] == "("
        depth = 0
        # Split top-level commas inside this paren group.
        seg_start = p + 1
        segments = []
        q = p
        while q < n:
            ch = s[q]
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
                if depth == 0:
                    segments.append(s[seg_start:q])
                    end = q + 1
                    break
            elif ch == "," and depth == 1:
                segments.append(s[seg_start:q])
                seg_start = q + 1
            q += 1
        else:
            raise ValueError(f"unbalanced parenthesis in {formula}")
        # Trailing multiplier after ')'
        mm = re.match(r"(\d+(?:\.\d+)?)", s[end:])
        mult = float(mm.group(1)) if mm else 1.0
        end += mm.end() if mm else 0
        # Combine segments; comma segments share the multiplier equally.
        combined: dict[str, float] = {}
        share = mult / len(segments) if len(segments) > 1 else mult
        for seg in segments:
            sub, _ = parse_group_str(seg)
            w = share if len(segments) > 1 else mult
            for el, a in sub.items():
                combined[el] = combined.get(el, 0.0) + a * w
        return combined, end

    def parse_group_str(sub: str):
        """Parse a standalone substring as a group (no surrounding parens)."""
        nonlocal s, n
        saved_s, saved_n = s, n
        s, n = sub, len(sub)
        try:
            c, end = parse_group(0)
            if end != n:
                raise ValueError(f"trailing garbage '{sub[end:]}' in {formula}")
        finally:
            s, n = saved_s, saved_n
        return c, len(sub)

    counts, end = parse_group(pos)
    if end != n:
        raise ValueError(f"trailing garbage '{s[end:]}' in {formula}")
    return counts


@mcp.tool()
def normalize_composition(formula_dict: dict) -> dict:
    """Return mole-fraction normalised composition (sum = 1)."""
    total = sum(float(v) for v in formula_dict.values())
    if total <= 0:
        return {}
    return {k: float(v) / total for k, v in formula_dict.items()}


@mcp.tool()
def element_properties(symbol: str) -> dict:
    """Look up Z, atomic mass M (g/mol), group, period, and Pauling EN."""
    if symbol not in _ELEMENTS:
        raise ValueError(f"unknown element: {symbol}")
    return dict(_ELEMENTS[symbol])


@mcp.tool()
def list_supported_elements() -> list:
    """Return the list of element symbols supported by element_properties."""
    return sorted(_ELEMENTS.keys(), key=lambda s: _ELEMENTS[s]["Z"])


@mcp.tool()
def host_dopant_split(formula_dict: dict, host_elements: list,
                      dopant_threshold: float = 0.0) -> dict:
    """Split a parsed composition into host vs. dopant atoms.

    By default, every element listed in ``host_elements`` is kept as host
    whenever it is present, even at fractional stoichiometry. This prevents
    Bi/Te or Sn/Se host atoms in alloyed formulas from being misclassified as
    dopants. Set ``dopant_threshold`` above zero only if you intentionally want
    trace host-listed elements below that raw amount to be treated as dopants.
    """
    host: dict[str, float] = {}
    dop: dict[str, float] = {}
    host_set = set(host_elements)
    for el, amt in formula_dict.items():
        amt = float(amt)
        if el in host_set and amt > dopant_threshold:
            host[el] = amt
        else:
            dop[el] = amt
    return {"host": host, "dopant": dop}


@mcp.tool()
def is_doped_compound(formula: str, host_elements: list) -> bool:
    """Return True if the formula contains any element outside ``host_elements``."""
    parsed = parse_formula(formula)
    return any(el not in set(host_elements) for el in parsed)


@mcp.tool()
def composition_features(formula: str) -> dict:
    """Compute element-weighted molar mass and average electronegativity for
    a formula. Returns ``{molar_mass, avg_EN, n_elements}``."""
    parsed = parse_formula(formula)
    norm = normalize_composition(parsed)
    if not norm:
        return {"molar_mass": 0.0, "avg_EN": 0.0, "n_elements": 0}
    M = sum(parsed[el] * _ELEMENTS[el]["M"] for el in parsed)
    en = sum(norm[el] * _ELEMENTS[el]["EN"] for el in norm)
    return {"molar_mass": M, "avg_EN": en, "n_elements": len(parsed)}


if __name__ == "__main__":
    mcp.run()

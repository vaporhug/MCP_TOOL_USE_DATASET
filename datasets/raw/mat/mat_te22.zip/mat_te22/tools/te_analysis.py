"""Thermoelectric-specific analysis primitives.

Wraps the Starrydata2 ``samples`` + ``curves`` CSV layout (also used by the
public TEXplorer JSON exports). Functions cover:

* curve loading by sample / property,
* per-sample peak ZT extraction,
* power-factor computation from Seebeck (S) and electrical conductivity (sigma),
* per-doping-element ZT statistics.

All numeric outputs are plain Python floats / lists so the FastMCP wire
format stays JSON-clean.
"""
from __future__ import annotations

import csv
import json
import math
import os
from typing import Any

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("TE_Analysis")


def _read_csv_dicts(path: str) -> list[dict]:
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def _parse_xy(s: str) -> list[float]:
    if not s:
        return []
    try:
        v = json.loads(s)
        return [float(x) for x in v if x is not None]
    except Exception:
        pass
    inner = s.strip().strip("[]")
    out = []
    for tok in inner.split(","):
        tok = tok.strip()
        if tok:
            try:
                out.append(float(tok))
            except ValueError:
                pass
    return out


@mcp.tool()
def load_te_curves(curves_csv: str, prop_y: str | None = None,
                   sample_id: int | None = None) -> list:
    """Load thermoelectric curves from the Starrydata2-style CSV.

    Each row of the source CSV represents one published x/y trace (e.g.
    ``ZT`` vs. ``Temperature``). The strings ``x`` and ``y`` are JSON-encoded
    arrays. This helper parses them into Python lists.

    Args:
        curves_csv: path to ``te_curves.csv``.
        prop_y: optional filter on the y-property name (e.g. ``ZT``,
            ``Seebeck coefficient``, ``Electrical conductivity``).
        sample_id: optional filter to a single sample.

    Returns: list of dicts ``{sample_id, composition, prop_x, prop_y,
    unit_x, unit_y, x: [..], y: [..], DOI}``.
    """
    rows = _read_csv_dicts(curves_csv)
    out = []
    for r in rows:
        if prop_y is not None and r.get("prop_y", "") != prop_y:
            continue
        if sample_id is not None and str(r.get("sample_id")) != str(sample_id):
            continue
        out.append({
            "sample_id": int(r["sample_id"]),
            "composition": r.get("composition", ""),
            "prop_x": r.get("prop_x"),
            "prop_y": r.get("prop_y"),
            "unit_x": r.get("unit_x"),
            "unit_y": r.get("unit_y"),
            "x": _parse_xy(r.get("x", "[]")),
            "y": _parse_xy(r.get("y", "[]")),
            "DOI": r.get("DOI", ""),
        })
    return out


@mcp.tool()
def load_te_samples(samples_csv: str, family: str | None = None) -> list:
    """Load thermoelectric sample metadata.

    Args:
        samples_csv: path to ``te_samples.csv``.
        family: optional MaterialFamily filter (e.g. ``SnSe`` or ``Bi2Te3``).

    Returns: list of dicts with sample_id, composition, family (``fam``),
    DOI, sample_name.
    """
    rows = _read_csv_dicts(samples_csv)
    out = []
    for r in rows:
        if family is not None and r.get("fam", "") != family:
            continue
        out.append({
            "sample_id": int(r["sample_id"]),
            "composition": r.get("composition", ""),
            "fam": r.get("fam", ""),
            "DOI": r.get("DOI", ""),
            "sample_name": r.get("sample_name", ""),
        })
    return out


@mcp.tool()
def peak_zt(x: list, y: list) -> dict:
    """Return ``{T_peak, ZT_peak}`` for a single ZT-vs-temperature curve.

    Returns ``{T_peak: None, ZT_peak: None}`` when the input is empty.
    """
    if not x or not y or len(x) != len(y):
        return {"T_peak": None, "ZT_peak": None}
    i = max(range(len(y)), key=lambda k: y[k])
    return {"T_peak": float(x[i]), "ZT_peak": float(y[i])}


@mcp.tool()
def compute_power_factor(S_uVK: list, sigma_S_per_cm: list) -> list:
    """Power factor PF = S^2 * sigma. Inputs use the standard literature
    units (Seebeck in microV/K, electrical conductivity in S/cm). Output
    is in microW / (cm * K^2), the unit reported by TEXplorer/Starrydata2.

    Returns the element-wise PF list. Both inputs must be the same length.
    """
    if len(S_uVK) != len(sigma_S_per_cm):
        raise ValueError("S and sigma must have the same length")
    pf = []
    for s, sig in zip(S_uVK, sigma_S_per_cm):
        # S in microV/K -> S^2 in microV^2/K^2 = 1e-12 V^2/K^2
        # sigma in S/cm. PF = S^2 sigma -> 1e-12 V^2/K^2 * S/cm
        # Convert to microW/(cm K^2): V^2/K^2 * S/cm = W/(cm K^2)
        pf.append(float(s) * float(s) * float(sig) * 1e-6)
    return pf


@mcp.tool()
def aggregate_peak_zt_by_sample(curves_csv: str,
                                family: str | None = None,
                                samples_csv: str | None = None,
                                zt_max_clip: float = 3.5) -> list:
    """For every sample with a ZT vs. temperature curve, return the peak
    (ZT_peak, T_peak) plus its composition and DOI.

    Args:
        curves_csv: te_curves.csv path.
        family: optional family filter (requires samples_csv).
        samples_csv: te_samples.csv path (only needed when family is set).
        zt_max_clip: physical sanity ceiling. Curves whose peak exceeds this
            value are dropped (Starrydata2 contains a few rows where a
            different transport quantity was uploaded under the ZT label).

    Returns: list of dicts ``{sample_id, composition, DOI, T_peak, ZT_peak}``.
    """
    fam_lookup: dict[int, str] = {}
    if family is not None:
        if samples_csv is None:
            raise ValueError("samples_csv required when family is given")
        for r in _read_csv_dicts(samples_csv):
            fam_lookup[int(r["sample_id"])] = r.get("fam", "")

    best_by_sample: dict[int, dict] = {}
    for c in _read_csv_dicts(curves_csv):
        if c.get("prop_y") != "ZT":
            continue
        sid = int(c["sample_id"])
        if family is not None and fam_lookup.get(sid) != family:
            continue
        x = _parse_xy(c.get("x", "[]"))
        y = _parse_xy(c.get("y", "[]"))
        if not x or not y:
            continue
        i = max(range(len(y)), key=lambda k: y[k])
        peak = float(y[i])
        if peak <= 0 or peak > zt_max_clip:
            continue
        rec = {
            "sample_id": sid,
            "composition": c.get("composition", ""),
            "DOI": c.get("DOI", ""),
            "T_peak": float(x[i]),
            "ZT_peak": peak,
        }
        if sid not in best_by_sample or peak > best_by_sample[sid]["ZT_peak"]:
            best_by_sample[sid] = rec
    return sorted(best_by_sample.values(), key=lambda r: (r["sample_id"], -r["ZT_peak"]))


@mcp.tool()
def doping_element_zt_stats(peak_zt_records: list, host_elements: list,
                            return_diagnostics: bool = True) -> dict:
    """Group peak-ZT records by their dopant element (any element outside
    ``host_elements``) and report per-dopant max / mean / count.

    Args:
        peak_zt_records: output of ``aggregate_peak_zt_by_sample``.
        host_elements: e.g. ``["Sn","Se"]`` for SnSe, ``["Bi","Te"]`` for Bi2Te3.

    Returns: dict with ``dopant_stats`` sorted by descending max ZT_peak plus
    explicit parse/no-dopant skip counts and examples. Set
    ``return_diagnostics=False`` to return only the legacy dopant_stats list.

    A co-doped / alloyed sample contributes to EVERY one of its dopant
    elements (not just the first), so e.g. an (Bi,Sb)2Te3(PbTe)x sample
    counts toward both the Sb and the Pb leaderboards. Compositions are
    parsed with the full ``composition.parse_formula`` (handles
    parentheses, multipliers, slash alloys, comma sites) so alloy
    end-members such as ``(Bi0.25Sb0.75)2Te3`` are correctly recognised
    as Sb-bearing.
    """
    try:
        from composition import parse_formula
    except ImportError:
        from .composition import parse_formula
    host = set(host_elements)
    groups: dict[str, dict[int, float]] = {}
    parse_failed = []
    no_dopant = []

    for rec in peak_zt_records:
        f = rec.get("composition") or ""
        try:
            parsed = parse_formula(f)
        except Exception as exc:
            parse_failed.append({
                "sample_id": rec.get("sample_id"),
                "composition": f,
                "reason": str(exc),
            })
            continue
        # every non-host element is a dopant/alloy element for this sample
        dopants = [e for e in parsed if e not in host]
        if not dopants:
            no_dopant.append({
                "sample_id": rec.get("sample_id"),
                "composition": f,
            })
            continue
        zt = float(rec["ZT_peak"])
        sid = int(rec["sample_id"])
        for dop in dopants:
            groups.setdefault(dop, {})
            groups[dop][sid] = max(groups[dop].get(sid, float("-inf")), zt)

    out = []
    for dop, by_sample in groups.items():
        vals = list(by_sample.values())
        out.append({
            "dopant": dop,
            "n_samples": len(by_sample),
            "max_ZT": max(vals),
            "mean_ZT": sum(vals) / len(vals),
        })
    out.sort(key=lambda r: -r["max_ZT"])
    if not return_diagnostics:
        return out
    return {
        "dopant_stats": out,
        "n_input_peak_records": len(peak_zt_records),
        "n_parse_failed": len(parse_failed),
        "parse_failed_examples": parse_failed[:10],
        "n_no_dopant": len(no_dopant),
        "no_dopant_examples": no_dopant[:10],
        "exclusion_rule": "Rows with non-parseable composition strings are reported and excluded from dopant rankings; parseable host-only rows are reported as no_dopant and excluded from dopant leaderboards.",
    }


@mcp.tool()
def linear_interpolate_at(x: list, y: list, x_target: float) -> float | None:
    """Piecewise-linear interpolation of y(x) at x_target. Used to compare
    transport properties at a fixed temperature. Returns None if outside
    the support."""
    if not x or len(x) != len(y):
        return None
    pairs = sorted(zip(x, y))
    xs = [p[0] for p in pairs]
    ys = [p[1] for p in pairs]
    if x_target < xs[0] or x_target > xs[-1]:
        return None
    for i in range(len(xs) - 1):
        if xs[i] <= x_target <= xs[i + 1]:
            if xs[i + 1] == xs[i]:
                return float(ys[i])
            t = (x_target - xs[i]) / (xs[i + 1] - xs[i])
            return float(ys[i] + t * (ys[i + 1] - ys[i]))
    return None


@mcp.tool()
def family_summary(samples_csv: str) -> dict:
    """Return number of samples per MaterialFamily column ``fam``."""
    counts: dict[str, int] = {}
    for r in _read_csv_dicts(samples_csv):
        counts[r.get("fam", "")] = counts.get(r.get("fam", ""), 0) + 1
    return dict(sorted(counts.items(), key=lambda kv: -kv[1]))


@mcp.tool()
def plot_zt_vs_temperature(curves_csv: str, out_path: str,
                           samples_csv: str,
                           family: str = "Bi2Te3",
                           top_k: int = 30,
                           zt_max_clip: float = 3.5) -> str:
    """Render a ZT-vs-temperature scatter for the ``top_k`` samples with the
    highest peak ZT in a given material family.

    Args:
        curves_csv: te_curves.csv path.
        samples_csv: te_samples.csv path.
        out_path: PNG output path.
        family: SnSe or Bi2Te3.
        top_k: number of top-ZT samples to include.
        zt_max_clip: drop curves whose peak exceeds this ceiling (Starrydata2
            contains a few rows mis-uploaded under the ZT label).

    Returns: absolute path of the written PNG.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fam_lookup: dict[int, str] = {}
    for r in _read_csv_dicts(samples_csv):
        fam_lookup[int(r["sample_id"])] = r.get("fam", "")

    fig, ax = plt.subplots(figsize=(7, 5))
    sample_curves: dict[int, dict] = {}
    for r in _read_csv_dicts(curves_csv):
        if r.get("prop_y") != "ZT":
            continue
        sid = int(r["sample_id"])
        if fam_lookup.get(sid) != family:
            continue
        x = _parse_xy(r.get("x", "[]"))
        y = _parse_xy(r.get("y", "[]"))
        if not x or not y:
            continue
        peak = max(y)
        if peak <= 0 or peak > zt_max_clip:
            continue
        if sid not in sample_curves or peak > sample_curves[sid]["peak"]:
            sample_curves[sid] = {"x": x, "y": y, "peak": peak,
                                   "comp": r.get("composition", "")}

    top = sorted(sample_curves.values(), key=lambda d: -d["peak"])[:top_k]
    cmap = plt.cm.viridis
    for i, c in enumerate(top):
        ax.plot(c["x"], c["y"], lw=1.0, alpha=0.75,
                color=cmap(i / max(1, len(top) - 1)))
    ax.set_xlabel("Temperature (K)")
    ax.set_ylabel("ZT")
    ax.set_title(f"Top-{len(top)} {family} samples (ZT vs. T)")
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return os.path.abspath(out_path)


@mcp.tool()
def plot_dopant_ranking(peak_records: list, host_elements: list,
                         out_path: str, top_k: int = 15,
                         title: str = "Top dopants by peak ZT") -> str:
    """Bar chart of the top-``top_k`` dopants ranked by maximum peak ZT.

    Args:
        peak_records: output of ``aggregate_peak_zt_by_sample``.
        host_elements: host elements (e.g. ``["Bi","Te"]``).
        out_path: PNG output path.
        top_k: bars to show.
        title: figure title.

    Returns: absolute path of the written PNG.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    stats_result = doping_element_zt_stats(peak_records, host_elements)
    stats = stats_result["dopant_stats"] if isinstance(stats_result, dict) else stats_result
    top = stats[:top_k]
    if not top:
        raise ValueError("no dopant records")

    fig, ax = plt.subplots(figsize=(8, 4.5))
    labels = [d["dopant"] for d in top]
    maxes = [d["max_ZT"] for d in top]
    means = [d["mean_ZT"] for d in top]
    counts = [d["n_samples"] for d in top]

    xs = list(range(len(top)))
    ax.bar(xs, maxes, color="#3a6ea5", label="max ZT")
    ax.bar(xs, means, color="#f6a800", alpha=0.85, width=0.55,
           label="mean ZT")
    for i, n in enumerate(counts):
        ax.text(i, maxes[i] + 0.02, f"n={n}", ha="center", fontsize=8)
    ax.set_xticks(xs)
    ax.set_xticklabels(labels, rotation=45, ha="right")
    ax.set_ylabel("ZT")
    ax.set_title(title)
    ax.legend()
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return os.path.abspath(out_path)


@mcp.tool()
def plot_pf_vs_temperature(curves_csv: str, out_path: str,
                            samples_csv: str,
                            family: str = "Bi2Te3",
                            top_k: int = 25) -> str:
    """ZT-style overlay for power factor vs T (Starrydata2 prop_y="Power factor")."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fam_lookup: dict[int, str] = {}
    for r in _read_csv_dicts(samples_csv):
        fam_lookup[int(r["sample_id"])] = r.get("fam", "")

    fig, ax = plt.subplots(figsize=(7, 5))
    samples: dict[int, dict] = {}
    for r in _read_csv_dicts(curves_csv):
        if r.get("prop_y") != "Power factor":
            continue
        sid = int(r["sample_id"])
        if fam_lookup.get(sid) != family:
            continue
        x = _parse_xy(r.get("x", "[]"))
        y = _parse_xy(r.get("y", "[]"))
        if not x or not y:
            continue
        peak = max(y)
        if sid not in samples or peak > samples[sid]["peak"]:
            samples[sid] = {"x": x, "y": y, "peak": peak}

    top = sorted(samples.values(), key=lambda d: -d["peak"])[:top_k]
    cmap = plt.cm.plasma
    for i, c in enumerate(top):
        ax.plot(c["x"], c["y"], lw=1.0, alpha=0.7,
                color=cmap(i / max(1, len(top) - 1)))
    ax.set_xlabel("Temperature (K)")
    ax.set_ylabel("Power factor (microW cm^-1 K^-2)")
    ax.set_title(f"Top-{len(top)} {family} samples (PF vs. T)")
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return os.path.abspath(out_path)


if __name__ == "__main__":
    mcp.run()

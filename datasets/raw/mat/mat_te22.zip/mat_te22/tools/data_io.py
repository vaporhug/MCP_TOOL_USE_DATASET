"""Generic IO and data-frame primitives for TE platform analysis.

These are low-level helpers (no domain logic). The thermoelectric-specific
analysis lives in `te_analysis.py`.
"""
from __future__ import annotations

import csv
import json
import os
from typing import Any

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("TE_DataIO")


@mcp.tool()
def read_csv(path: str, max_rows: int | None = None) -> dict:
    """Read a CSV file into a list-of-dicts plus header.

    Args:
        path: Path to CSV file.
        max_rows: Optional cap on number of data rows returned.

    Returns:
        {"columns": [...], "rows": [{...}, ...], "n_rows": int}
    """
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        cols = list(reader.fieldnames or [])
        rows = []
        for i, r in enumerate(reader):
            if max_rows is not None and i >= max_rows:
                break
            rows.append(dict(r))
    return {"columns": cols, "rows": rows, "n_rows": len(rows)}


@mcp.tool()
def write_csv(rows: list, path: str) -> str:
    """Write list-of-dicts to CSV (header from first row).

    Args:
        rows: Sequence of dicts.
        path: Destination CSV path.

    Returns: absolute output path.
    """
    parent = os.path.dirname(os.path.abspath(path))
    if parent:
        os.makedirs(parent, exist_ok=True)
    if not rows:
        open(path, "w").close()
        return os.path.abspath(path)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    return os.path.abspath(path)


@mcp.tool()
def read_json(path: str) -> Any:
    """Parse a JSON file. Returns the deserialised Python object."""
    with open(path, encoding="utf-8") as f:
        return json.load(f)


@mcp.tool()
def write_json(obj: Any, path: str, indent: int = 2) -> str:
    """Serialise an object to JSON (default=str fallback). Returns abs path."""
    parent = os.path.dirname(os.path.abspath(path))
    if parent:
        os.makedirs(parent, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=indent, default=str)
    return os.path.abspath(path)


@mcp.tool()
def parse_xy_list(s: str) -> list:
    """Parse a string that encodes a list of floats (Starrydata2 stores XY
    arrays as JSON-like strings such as '[1.0,2.0,3.5]'). Robust to NaN."""
    if not s or s == "" or s == "nan":
        return []
    try:
        v = json.loads(s)
        if isinstance(v, list):
            return [float(x) for x in v if x is not None]
    except Exception:
        pass
    inner = s.strip().strip("[]")
    out = []
    for tok in inner.split(","):
        tok = tok.strip()
        if not tok:
            continue
        try:
            out.append(float(tok))
        except ValueError:
            continue
    return out


@mcp.tool()
def filter_rows(rows: list, equals: dict | None = None,
                contains: dict | None = None) -> list:
    """Filter list-of-dicts. ``equals`` matches on equality (string compare);
    ``contains`` matches case-insensitive substring."""
    out = []
    eq = equals or {}
    co = contains or {}
    for r in rows:
        if any(str(r.get(k, "")) != str(v) for k, v in eq.items()):
            continue
        if any(str(v).lower() not in str(r.get(k, "")).lower()
               for k, v in co.items()):
            continue
        out.append(r)
    return out


@mcp.tool()
def groupby_count(rows: list, by: str) -> dict:
    """Count rows per unique value of ``by``. Returns {value: count}."""
    out: dict[str, int] = {}
    for r in rows:
        k = str(r.get(by, ""))
        out[k] = out.get(k, 0) + 1
    return dict(sorted(out.items(), key=lambda kv: -kv[1]))


@mcp.tool()
def groupby_aggregate(rows: list, by: str, value: str,
                      agg: str = "max") -> list:
    """Group rows and aggregate one numeric column.

    Args:
        rows: list of dicts.
        by: grouping key.
        value: numeric column name.
        agg: one of {max, min, mean, count}.

    Returns: list of {by, agg_value}.
    """
    groups: dict[str, list[float]] = {}
    for r in rows:
        try:
            v = float(r[value])
        except (KeyError, TypeError, ValueError):
            continue
        groups.setdefault(str(r.get(by, "")), []).append(v)
    out = []
    for k, vals in groups.items():
        if not vals:
            continue
        if agg == "max":
            out.append({by: k, value: max(vals)})
        elif agg == "min":
            out.append({by: k, value: min(vals)})
        elif agg == "mean":
            out.append({by: k, value: sum(vals) / len(vals)})
        elif agg == "count":
            out.append({by: k, value: len(vals)})
        else:
            raise ValueError(f"unknown agg: {agg}")
    return out


if __name__ == "__main__":
    mcp.run()

"""Database retrieval tools.

Thin placeholders for external-database queries. The heavy-weight network /
HTML-parsing code is intentionally omitted — implementations should be filled
in at task-execution time with the appropriate library (requests, biopython,
pubchempy, chembl_webresource_client, obspy, etc.). Each stub documents the
target database and the intended query semantics so an agent can recognise
when to call it and supply the missing implementation.
"""
from typing import Any


def websearch(query: str, max_results: int = 10) -> list[dict]:
    """Generic web search (Google/Bing/DuckDuckGo via a scraping backend).

    Use for: locating a dataset DOI, finding a paper's supplementary URL,
    or resolving an ambiguous reference. Returns a list of {title, url,
    snippet} dicts.
    """
    raise RuntimeError("External network retrieval is not part of this local task bundle")


def fetch_url(url: str, timeout: int = 30) -> bytes:
    """HTTP GET with redirects. Used to download a CSV/PDF/JSON from a
    known URL (e.g., Zenodo record, GitHub raw file, journal OA page)."""
    raise RuntimeError("External network retrieval is not part of this local task bundle")


def query_pubchem(identifier: str, namespace: str = "cid") -> dict:
    """PubChem PUG-REST lookup. namespace in {cid, name, smiles, inchikey}.
    Returns compound record (properties, synonyms, 2D/3D structure)."""
    raise RuntimeError("External network retrieval is not part of this local task bundle")


def query_chembl(target_id: str, activity_type: str = "IC50") -> list[dict]:
    """ChEMBL bioactivity query. Returns rows of {molecule_chembl_id,
    canonical_smiles, standard_value, standard_units, assay_description}
    for a given target (e.g., CHEMBL240)."""
    raise RuntimeError("External network retrieval is not part of this local task bundle")


def query_uniprot(accession: str) -> dict:
    """UniProt entry fetch. Returns sequence, organism, features,
    cross-references."""
    raise RuntimeError("External network retrieval is not part of this local task bundle")


def query_pdb(pdb_id: str) -> dict:
    """RCSB PDB entry metadata + structure file URL."""
    raise RuntimeError("External network retrieval is not part of this local task bundle")


def query_geo(accession: str) -> dict:
    """NCBI GEO series/sample fetch (GSE/GSM). Returns metadata + supplementary
    file list. Used to pull raw microarray / RNA-seq count matrices."""
    raise RuntimeError("External network retrieval is not part of this local task bundle")


def query_ncbi_entrez(db: str, term: str, retmax: int = 100) -> list[dict]:
    """Generic Entrez E-search + E-fetch. db in {pubmed, nuccore, protein,
    taxonomy, sra, bioproject}. Returns parsed records."""
    raise RuntimeError("External network retrieval is not part of this local task bundle")


def query_usgs_comcat(starttime: str, endtime: str, minmagnitude: float = 0,
                     bbox: tuple | None = None) -> list[dict]:
    """USGS ComCat earthquake catalog query. Returns list of events with
    time, lon, lat, depth, magnitude."""
    raise RuntimeError("External network retrieval is not part of this local task bundle")


def query_world_bank(indicator: str, country: str = "all",
                    start: int = 1960, end: int = 2023) -> list[dict]:
    """World Bank WDI indicator series (e.g., SI.POV.GINI for Gini)."""
    raise RuntimeError("External network retrieval is not part of this local task bundle")


def query_openalex(search: str, filters: dict | None = None) -> list[dict]:
    """OpenAlex works/authors/venues search. Used for meta-analysis
    study discovery."""
    raise RuntimeError("External network retrieval is not part of this local task bundle")


def query_doi(doi: str) -> dict:
    """Resolve a DOI to a Crossref metadata record + OA full-text URL
    (via Unpaywall)."""
    raise RuntimeError("External network retrieval is not part of this local task bundle")

#!/usr/bin/env python3
"""Low-level primitives for high-entropy alloy active-learning workflows.

These functions are domain primitives: composition parsing, element-property
lookup, ensemble training, uncertainty estimation, acquisition scoring,
and plotting. The agent decides how to chain them.
"""
import os
import json
import pickle
import hashlib
from typing import Optional

import numpy as np
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("HEA_AL_Tools")


# ---------------------------------------------------------------------------
# Element property table (atomic radius pm, electronegativity Pauling,
# valence-electron count, density g/cm3, melting point K, thermal conductivity W/mK)
# Values pulled from standard handbook tables. Used for primitive feature
# expansion when building physics-informed descriptors.
# ---------------------------------------------------------------------------
ELEMENT_PROPS = {
    # symbol: (atomic_radius_pm, electronegativity, valence_electrons,
    #          density_g_cm3, melting_point_K, thermal_conductivity_W_mK)
    "Fe": (140, 1.83, 8, 7.874, 1811, 80.4),
    "Ni": (135, 1.91, 10, 8.908, 1728, 90.9),
    "Co": (135, 1.88, 9, 8.900, 1768, 100.0),
    "Cr": (140, 1.66, 6, 7.190, 2180, 93.9),
    "V":  (135, 1.63, 5, 6.110, 2183, 30.7),
    "Cu": (135, 1.90, 11, 8.960, 1357, 401.0),
    "Mn": (140, 1.55, 7, 7.210, 1519, 7.81),
    "Ti": (140, 1.54, 4, 4.506, 1941, 21.9),
    "Al": (125, 1.61, 3, 2.700, 933, 237.0),
}

# Atomic weights (g/mol) for converting weight-fraction <-> molar fraction
ATOMIC_WEIGHT = {
    "Fe": 55.845, "Ni": 58.6934, "Co": 58.9332, "Cr": 51.9961,
    "V": 50.9415, "Cu": 63.546, "Mn": 54.938, "Ti": 47.867, "Al": 26.982,
}


@mcp.tool()
def load_alloy_dataset(csv_path: str) -> dict:
    """Load the HEA dataset and return shape, columns, and per-column statistics.

    Args:
        csv_path: Path to the alloy CSV (one row per composition).

    Returns:
        dict with shape, column names, dtypes, target value range and
        elemental composition coverage.
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    stats = {}
    for col in df.columns:
        if df[col].dtype.kind in "fi":
            stats[col] = {
                "mean": round(float(df[col].mean()), 4),
                "std": round(float(df[col].std()), 4),
                "min": round(float(df[col].min()), 4),
                "max": round(float(df[col].max()), 4),
            }
    return {
        "shape": list(df.shape),
        "columns": list(df.columns),
        "n_named_alloys": int(df.iloc[:, 0].notna().sum())
        if df.iloc[:, 0].dtype == object else 0,
        "numeric_stats": stats,
    }


@mcp.tool()
def parse_composition(formula: str) -> dict:
    """Parse a chemical formula like 'Fe55.2Ni23.9Co16.7Cr4.2' into element fractions.

    Accepts both wt% and at% style strings as long as numeric fractions sum
    to ~1 or ~100. Returns molar fractions normalised to sum=1.

    Args:
        formula: e.g. 'Fe55.2Ni23.9Co16.7Cr4.2'

    Returns:
        dict {element_symbol: mole_fraction} normalised to 1.
    """
    import re
    pattern = re.findall(r"([A-Z][a-z]?)([0-9.]*)", formula)
    raw = {}
    for sym, frac in pattern:
        if not sym:
            continue
        try:
            raw[sym] = float(frac) if frac else 1.0
        except ValueError:
            raw[sym] = 1.0
    total = sum(raw.values())
    if total == 0:
        return {"error": "no parseable composition"}
    return {k: round(v / total, 6) for k, v in raw.items()}


@mcp.tool()
def lookup_element_property(symbol: str, prop: str) -> dict:
    """Return a tabulated physical property for an element.

    Args:
        symbol: element symbol e.g. 'Fe'
        prop:   one of {'atomic_radius_pm', 'electronegativity',
                'valence_electrons', 'density_g_cm3', 'melting_point_K',
                'thermal_conductivity_W_mK', 'atomic_weight'}

    Returns:
        dict with 'value' or 'error'.
    """
    if symbol not in ELEMENT_PROPS:
        return {"error": f"unknown element {symbol}"}
    fields = ["atomic_radius_pm", "electronegativity", "valence_electrons",
              "density_g_cm3", "melting_point_K", "thermal_conductivity_W_mK"]
    if prop in fields:
        idx = fields.index(prop)
        return {"symbol": symbol, "property": prop,
                "value": ELEMENT_PROPS[symbol][idx]}
    if prop == "atomic_weight":
        return {"symbol": symbol, "property": prop,
                "value": ATOMIC_WEIGHT.get(symbol)}
    return {"error": f"unknown property {prop}"}


@mcp.tool()
def composition_average(fractions: dict, prop: str) -> dict:
    """Composition-weighted average of an element property.

    Args:
        fractions: {symbol: mole_fraction}
        prop:      one of the keys accepted by lookup_element_property

    Returns:
        dict with 'weighted_average' and per-element contributions.
    """
    fields = ["atomic_radius_pm", "electronegativity", "valence_electrons",
              "density_g_cm3", "melting_point_K", "thermal_conductivity_W_mK"]
    contribs = {}
    total = 0.0
    for sym, frac in fractions.items():
        if sym not in ELEMENT_PROPS:
            continue
        if prop in fields:
            v = ELEMENT_PROPS[sym][fields.index(prop)]
        elif prop == "atomic_weight":
            v = ATOMIC_WEIGHT.get(sym, 0)
        else:
            return {"error": f"unknown property {prop}"}
        contribs[sym] = round(frac * v, 6)
        total += frac * v
    return {"prop": prop,
            "weighted_average": round(total, 6),
            "contributions": contribs}


@mcp.tool()
def wt_to_at(wt_fractions: dict) -> dict:
    """Convert weight fractions to atomic (mole) fractions.

    Args:
        wt_fractions: {symbol: weight_fraction (sum~1 or sum~100)}

    Returns:
        dict {symbol: atomic_fraction} normalised to 1.
    """
    total = sum(wt_fractions.values())
    if total > 1.5:  # treat as wt%
        wt_fractions = {k: v / 100.0 for k, v in wt_fractions.items()}
    moles = {}
    for sym, w in wt_fractions.items():
        if sym not in ATOMIC_WEIGHT:
            continue
        moles[sym] = w / ATOMIC_WEIGHT[sym]
    s = sum(moles.values())
    if s == 0:
        return {"error": "no valid elements"}
    return {k: round(v / s, 6) for k, v in moles.items()}


@mcp.tool()
def configurational_entropy(fractions: dict) -> dict:
    """Ideal configurational entropy of mixing per Boltzmann's relation.

        S_conf = -R * sum(x_i * ln(x_i))

    Returns S_conf in units of R (so multiply by 8.314 J/mol-K to get SI units).

    Args:
        fractions: {symbol: mole_fraction}

    Returns:
        dict with 'S_conf_R' (in units of R).
    """
    s = 0.0
    for x in fractions.values():
        if x > 0:
            s += -x * np.log(x)
    return {"S_conf_R": round(float(s), 6)}


@mcp.tool()
def split_train_holdout(csv_path: str, holdout_indices: list,
                        feature_columns: list = None,
                        target_column: str = "TEC") -> dict:
    """Split dataset into training set and a held-out candidate pool by row index.

    Useful for active learning: hold out the rows you want to predict on
    and treat the rest as the labeled training set.

    Args:
        csv_path: path to alloy CSV
        holdout_indices: row indices (0-based, after dropping nulls) to hold out
        feature_columns: list of feature column names. If None, uses all
            numeric columns except target_column and the first column.
        target_column: target column name (default 'TEC')

    Returns:
        dict with train_size, holdout_size, feature_columns_used, and a
        cache_id usable by other tools.
    """
    import pandas as pd
    df = pd.read_csv(csv_path).reset_index(drop=True)
    if feature_columns is None:
        first = df.columns[0]
        feature_columns = [c for c in df.columns
                           if c != target_column and c != first
                           and df[c].dtype.kind in "fi"]
    holdout_set = set(holdout_indices)
    train_idx = [i for i in range(len(df)) if i not in holdout_set]
    holdout_idx = [i for i in range(len(df)) if i in holdout_set]
    payload = {
        "X_train": df.loc[train_idx, feature_columns].to_numpy().tolist(),
        "y_train": df.loc[train_idx, target_column].to_numpy().tolist(),
        "X_holdout": df.loc[holdout_idx, feature_columns].to_numpy().tolist(),
        "y_holdout": df.loc[holdout_idx, target_column].to_numpy().tolist(),
        "feature_columns": feature_columns,
    }
    cache_id = hashlib.md5(json.dumps(
        {"path": csv_path, "h": sorted(holdout_indices), "fc": feature_columns}
    ).encode()).hexdigest()[:8]
    with open(f"/tmp/hea_split_{cache_id}.pkl", "wb") as f:
        pickle.dump(payload, f)
    return {
        "cache_id": cache_id,
        "train_size": len(train_idx),
        "holdout_size": len(holdout_idx),
        "n_features": len(feature_columns),
        "feature_columns": feature_columns,
    }


@mcp.tool()
def train_ensemble_regressor(cache_id: str, model_type: str = "ensemble",
                             n_models: int = 10,
                             random_state: int = 0,
                             model_params: dict = None) -> dict:
    """Train an ensemble of regressors on a cached split.

    For uncertainty estimation we train `n_models` regressors with different
    random seeds (and bootstrapped subsamples for tree models). Predictions
    are returned as mean and std across the ensemble.

    Args:
        cache_id:   id from split_train_holdout
        model_type: 'mlp' (multilayer perceptron), 'gbdt' (gradient boosting),
                    'rf' (random forest), or 'ensemble' (mlp + gbdt mixed).
        n_models:   number of bootstrapped models (default 10)
        random_state: base random seed
        model_params: override default hyperparameters

    Returns:
        dict with model_id usable by predict_with_uncertainty.
    """
    with open(f"/tmp/hea_split_{cache_id}.pkl", "rb") as f:
        payload = pickle.load(f)
    X_train = np.array(payload["X_train"])
    y_train = np.array(payload["y_train"])

    mu = X_train.mean(0)
    sd = X_train.std(0)
    sd[sd == 0] = 1
    Xn = (X_train - mu) / sd

    rng = np.random.RandomState(random_state)
    params = model_params or {}
    models = []

    for k in range(n_models):
        seed = int(rng.randint(0, 1_000_000))
        # bootstrap sample
        idx = rng.choice(len(Xn), len(Xn), replace=True)
        Xk, yk = Xn[idx], y_train[idx]

        mt = model_type
        if mt == "ensemble":
            mt = "mlp" if k % 2 == 0 else "gbdt"

        if mt == "mlp":
            from sklearn.neural_network import MLPRegressor
            dp = {"hidden_layer_sizes": (32, 16), "max_iter": 1000,
                  "random_state": seed, "early_stopping": False}
            dp.update(params)
            m = MLPRegressor(**dp).fit(Xk, yk)
        elif mt == "gbdt":
            from sklearn.ensemble import GradientBoostingRegressor
            dp = {"n_estimators": 200, "max_depth": 4,
                  "learning_rate": 0.05, "random_state": seed}
            dp.update(params)
            m = GradientBoostingRegressor(**dp).fit(Xk, yk)
        elif mt == "rf":
            from sklearn.ensemble import RandomForestRegressor
            dp = {"n_estimators": 200, "random_state": seed}
            dp.update(params)
            m = RandomForestRegressor(**dp).fit(Xk, yk)
        else:
            return {"error": f"unknown model_type {mt}"}
        models.append((mt, m))

    state = {"models": models, "mean": mu, "std": sd,
             "feature_columns": payload["feature_columns"]}
    blob = pickle.dumps(state)
    model_id = hashlib.md5(blob[:1000] + str(random_state).encode()).hexdigest()[:8]
    with open(f"/tmp/hea_model_{model_id}.pkl", "wb") as f:
        f.write(blob)

    return {"model_id": model_id, "n_models": len(models),
            "model_type": model_type,
            "n_features": Xn.shape[1]}


@mcp.tool()
def predict_with_uncertainty(model_id: str, cache_id: str,
                             on: str = "holdout") -> dict:
    """Return ensemble mean and std prediction on the holdout (or train) set.

    Args:
        model_id: id from train_ensemble_regressor
        cache_id: id from split_train_holdout
        on: 'holdout' (default) or 'train' to get predictions on either set.

    Returns:
        dict with 'pred_mean' (list), 'pred_std' (list), 'y_true' (list).
    """
    with open(f"/tmp/hea_model_{model_id}.pkl", "rb") as f:
        state = pickle.load(f)
    with open(f"/tmp/hea_split_{cache_id}.pkl", "rb") as f:
        payload = pickle.load(f)

    if on == "holdout":
        X = np.array(payload["X_holdout"])
        y = np.array(payload["y_holdout"])
    else:
        X = np.array(payload["X_train"])
        y = np.array(payload["y_train"])

    Xn = (X - state["mean"]) / state["std"]
    preds = np.stack([m.predict(Xn) for _, m in state["models"]], axis=0)
    return {
        "pred_mean": [round(float(v), 4) for v in preds.mean(0)],
        "pred_std":  [round(float(v), 4) for v in preds.std(0)],
        "y_true":    [round(float(v), 4) for v in y],
        "n_holdout": len(y),
    }


@mcp.tool()
def acquisition_score(pred_mean: list, pred_std: list,
                      strategy: str = "rank_weighted",
                      mean_weight: float = 0.8,
                      std_weight: float = 0.2,
                      target_direction: str = "min") -> dict:
    """Compute an acquisition score for active-learning candidate selection.

    Strategies:
      - 'pure_exploit': score = pred_mean (or -pred_mean if maximising)
      - 'pure_explore': score = -pred_std (low score = high uncertainty)
      - 'rank_weighted': rank candidates by mean and by std, then
            total = mean_weight*rank(mean) + std_weight*rank(std reversed).
            Lower total_rank = better candidate. This matches the
            paper's "rank-based exploration-exploitation" policy.
      - 'ucb': lower confidence bound (for minimisation):
            score = pred_mean - std_weight * pred_std

    Args:
        pred_mean, pred_std: per-candidate predictions
        strategy: as above
        mean_weight: weight on exploitation
        std_weight: weight on exploration
        target_direction: 'min' (lower TEC better) or 'max'.

    Returns:
        dict with 'scores' (list, lower=better) and 'top_indices' (sorted ascending).
    """
    pm = np.array(pred_mean, dtype=float)
    ps = np.array(pred_std, dtype=float)
    if target_direction == "max":
        pm = -pm

    if strategy == "pure_exploit":
        scores = pm
    elif strategy == "pure_explore":
        scores = -ps
    elif strategy == "ucb":
        scores = pm - std_weight * ps
    elif strategy == "rank_weighted":
        rank_mean = pm.argsort().argsort().astype(float) + 1
        rank_std = (-ps).argsort().argsort().astype(float) + 1
        scores = mean_weight * rank_mean + std_weight * rank_std
    else:
        return {"error": f"unknown strategy {strategy}"}

    order = scores.argsort()
    return {
        "scores": [round(float(v), 4) for v in scores],
        "top_indices": order.tolist(),
        "strategy": strategy,
    }


@mcp.tool()
def regression_metrics(y_true: list, y_pred: list) -> dict:
    """Compute MAPE / MAE / RMSE / R^2 between predictions and ground truth.

    Args:
        y_true: ground-truth values
        y_pred: predicted values

    Returns:
        dict of metrics.
    """
    y = np.array(y_true, dtype=float)
    p = np.array(y_pred, dtype=float)
    safe = np.abs(y) > 1e-9
    mape = float(np.mean(np.abs((y[safe] - p[safe]) / y[safe])))
    mae = float(np.mean(np.abs(y - p)))
    rmse = float(np.sqrt(np.mean((y - p) ** 2)))
    ss_res = float(((y - p) ** 2).sum())
    ss_tot = float(((y - y.mean()) ** 2).sum())
    r2 = 1 - ss_res / ss_tot if ss_tot > 0 else float("nan")
    return {"mape": round(mape, 4), "mae": round(mae, 4),
            "rmse": round(rmse, 4), "r2": round(r2, 4),
            "n": len(y)}


@mcp.tool()
def fit_pca_2d(csv_path: str, feature_columns: list = None,
               output_path: str = "/tmp/hea_pca.pkl") -> dict:
    """Fit a 2-D PCA on the dataset features for latent visualisation.

    The paper uses a Wasserstein autoencoder for the latent space, but a
    PCA gives a comparable (linear) low-D view that is useful for
    diagnostics and plotting.

    Args:
        csv_path: dataset path
        feature_columns: list of column names to project. If None, uses Fe..Cu.
        output_path: where to cache the fitted PCA.

    Returns:
        dict with explained_variance_ratio (2 floats) and projection cache id.
    """
    import pandas as pd
    from sklearn.decomposition import PCA
    df = pd.read_csv(csv_path)
    if feature_columns is None:
        feature_columns = [c for c in ["Fe", "Ni", "Co", "Cr", "V", "Cu"]
                           if c in df.columns]
    X = df[feature_columns].fillna(0).to_numpy()
    pca = PCA(n_components=2)
    Z = pca.fit_transform(X)
    with open(output_path, "wb") as f:
        pickle.dump({"pca": pca, "Z": Z, "cols": feature_columns}, f)
    return {
        "explained_variance_ratio":
            [round(float(v), 4) for v in pca.explained_variance_ratio_],
        "n_samples": len(X),
        "feature_columns": feature_columns,
        "cache_path": output_path,
    }


@mcp.tool()
def plot_latent_scatter(csv_path: str,
                        target_column: str = "TEC",
                        pca_cache: str = "/tmp/hea_pca.pkl",
                        output_path: str = "artifacts/Fig1_latent_space.png") -> dict:
    """Scatter plot of PCA latent coordinates coloured by target value.

    Args:
        csv_path: dataset
        target_column: column to use for colour scale
        pca_cache: path to cached PCA from fit_pca_2d
        output_path: figure save path

    Returns:
        dict with output_path.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import pandas as pd
    df = pd.read_csv(csv_path)
    with open(pca_cache, "rb") as f:
        cache = pickle.load(f)
    Z = cache["Z"]
    c = df[target_column].to_numpy()

    fig, ax = plt.subplots(figsize=(7, 6))
    sc = ax.scatter(Z[:, 0], Z[:, 1], c=c, s=12, cmap="viridis", alpha=0.8)
    plt.colorbar(sc, ax=ax, label=target_column)
    ax.set_xlabel("Latent dim 1 (PCA)")
    ax.set_ylabel("Latent dim 2 (PCA)")
    ax.set_title(f"Composition latent space coloured by {target_column}")
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=140, bbox_inches="tight")
    plt.close(fig)
    return {"output_path": output_path, "n_points": len(c)}


@mcp.tool()
def plot_iteration_error(iterations: list, mape_values: list,
                         std_values: list = None,
                         output_path: str = "artifacts/Fig2_learning_curve.png") -> dict:
    """Line plot of MAPE (and optional std) versus active-learning iteration.

    Args:
        iterations: list of iteration labels (e.g. [1,2,3])
        mape_values: per-iteration MAPE (or other error measure)
        std_values: optional list of per-iteration prediction stds
        output_path: figure path

    Returns:
        dict with output_path.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.plot(iterations, mape_values, "o-", color="steelblue",
            label="MAPE", linewidth=2)
    ax.set_xlabel("Active-learning iteration")
    ax.set_ylabel("MAPE")
    ax.set_title("Learning curve across iterations")
    if std_values is not None:
        ax2 = ax.twinx()
        ax2.plot(iterations, std_values, "s--", color="firebrick",
                 label="Std dev of error")
        ax2.set_ylabel("Std dev of measured TEC")
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=140, bbox_inches="tight")
    plt.close(fig)
    return {"output_path": output_path}


@mcp.tool()
def plot_tec_predictions(y_true: list, y_pred: list,
                         labels: list = None,
                         output_path: str = "artifacts/Fig3_invar_discovery.png") -> dict:
    """Predicted-vs-experimental scatter for TEC values.

    Args:
        y_true: experimental TEC values
        y_pred: model-predicted TEC values
        labels: optional alloy name list (same length)
        output_path: figure path

    Returns:
        dict with output_path.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    yt = np.array(y_true, dtype=float)
    yp = np.array(y_pred, dtype=float)
    fig, ax = plt.subplots(figsize=(6, 6))
    ax.scatter(yt, yp, s=60, c="steelblue", edgecolors="k")
    lims = [min(yt.min(), yp.min()) - 0.5, max(yt.max(), yp.max()) + 0.5]
    ax.plot(lims, lims, "k--", alpha=0.5)
    if labels is not None:
        for x, y, lab in zip(yt, yp, labels):
            ax.annotate(str(lab), (x, y), fontsize=7,
                        xytext=(3, 3), textcoords="offset points")
    ax.set_xlabel("Experimental TEC (10$^{-6}$/K)")
    ax.set_ylabel("Predicted TEC (10$^{-6}$/K)")
    ax.set_title("HEA active-learning predictions vs experiment")
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=140, bbox_inches="tight")
    plt.close(fig)
    return {"output_path": output_path, "n": len(yt)}


@mcp.tool()
def experimental_alloy_summary(csv_path: str) -> dict:
    """Summarize the named A/B cast alloys and target-regime anchors."""
    import pandas as pd
    df = pd.read_csv(csv_path)
    named = df[df["alloy_name"].fillna("").str.match(r"^[AB][0-9]")]
    key = named[named["alloy_name"].fillna("").str.startswith(("A3", "A6", "A9", "B2", "B4"))]
    return {
        "n_cast_rows": int(len(named)),
        "key_alloys": key[["alloy_name", "TEC"]].to_dict(orient="records"),
        "invar_regime_TEC_10e_minus6_per_K": 2.0,
        "kovar_regime_TEC_10e_minus6_per_K": 5.0,
    }


@mcp.tool()
def plot_invar_discovery(csv_path: str,
                         output_path: str = "artifacts/Fig3_invar_discovery.png") -> dict:
    """Bar chart for A3/A9 Invar-regime and B2/B4 Kovar-regime discoveries."""
    import pandas as pd
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    df = pd.read_csv(csv_path)
    labels = ["A3", "A9", "B2", "B4", "A6"]
    rows = []
    for lab in labels:
        hit = df[df["alloy_name"].fillna("").str.startswith(lab)].iloc[0]
        rows.append((lab, float(hit["TEC"])))
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.bar([r[0] for r in rows], [r[1] for r in rows],
           color=["#4c78a8", "#4c78a8", "#59a14f", "#59a14f", "#bab0ac"])
    ax.axhline(2.0, color="#e15759", linestyle="--", label="Invar-scale target")
    ax.axhline(5.0, color="#f28e2b", linestyle="--", label="Kovar-scale target")
    ax.set_ylabel("TEC (10$^{-6}$/K)")
    ax.set_title("ML-designed HEA low-TEC discoveries")
    ax.legend(frameon=False)
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=140, bbox_inches="tight")
    plt.close(fig)
    return {"output_path": output_path, "values": dict(rows)}


@mcp.tool()
def package_smoke_test(csv_path: str = "input_data/data/hea_grid.csv") -> dict:
    """Lightweight package self-test for schema, key alloy values, and tools."""
    summary = load_alloy_dataset(csv_path)
    cast = experimental_alloy_summary(csv_path)
    return {
        "shape": summary["shape"],
        "has_TEC": "TEC" in summary["columns"],
        "n_cast_rows": cast["n_cast_rows"],
        "key_alloys": cast["key_alloys"],
        "plot_functions": ["plot_latent_scatter", "plot_iteration_error", "plot_invar_discovery"],
    }


if __name__ == "__main__":
    mcp.run(transport="stdio")

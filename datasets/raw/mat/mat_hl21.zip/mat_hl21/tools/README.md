# mat_hl21 — Tool Reference

## Database Retrieval (`database_retrieval.py`)
Generic web/database lookup primitives. Useful when the agent wants to fetch
extra element / composition / phase data from external sources.

- **websearch**, **fetch_url**: HTTP retrieval primitives.
- **query_pubchem**, **query_chembl**, **query_uniprot**, **query_pdb**,
  **query_geo**, **query_ncbi_entrez**, **query_world_bank**,
  **query_openalex**, **query_doi**, **query_usgs_comcat**: external source
  helpers (most return JSON metadata).

## Data Processing (`data_processing.py`)
Generic data wrangling utilities (no domain logic).

- **read_csv / write_csv / read_json / write_json**
- **read_excel / read_parquet / read_netcdf / read_shapefile / read_fasta**
- **pivot_long_to_wide / pivot_wide_to_long / drop_missing / coerce_numeric**
- **join_tables / groupby_aggregate**

## Domain Primitives (`hea_al_tools.py`)
Low-level building blocks for HEA active-learning workflows. Each function is
a single primitive — the agent decides how to chain them.

### Composition + property loading
- **load_alloy_dataset**: read the alloy CSV and return per-column statistics.
- **parse_composition**: parse a formula like `Fe55.2Ni23.9Co16.7Cr4.2`
  into mole-fraction dict.
- **lookup_element_property**: tabulated atomic radius, electronegativity,
  valence-electron count, density, melting point, thermal conductivity,
  atomic weight (Fe, Ni, Co, Cr, V, Cu, Mn, Ti, Al).
- **composition_average**: composition-weighted average of any element
  property.
- **wt_to_at**: convert weight fractions to atomic (mole) fractions.
- **configurational_entropy**: ideal `S_conf = -R sum(x_i ln x_i)`.

### Active learning loop
- **split_train_holdout**: split a dataset into a training pool and a
  candidate pool by row index. Caches the split for re-use.
- **train_ensemble_regressor**: fit a bootstrap ensemble of MLP / GBDT / RF
  regressors. Returns a `model_id`.
- **predict_with_uncertainty**: ensemble mean and std on the holdout (or
  training) set.
- **acquisition_score**: rank candidates with `pure_exploit`,
  `pure_explore`, `ucb`, or the `rank_weighted` policy
  (`0.8*rank(mean) + 0.2*rank(std)` matches the paper).
- **regression_metrics**: MAPE / MAE / RMSE / R² between predictions and
  ground truth.

### Plotting
- **fit_pca_2d**: 2-D PCA on composition columns for latent-space plots.
- **plot_latent_scatter**: PCA latent scatter coloured by target value.
- **plot_iteration_error**: line plot of MAPE (and optional std) versus
  iteration index.
- **plot_tec_predictions**: predicted-vs-experimental TEC scatter.

## Dependencies
`scikit-learn`, `numpy`, `pandas`, `matplotlib`, `openpyxl`, `mcp[cli]`.
Optional: `lightgbm`, `xgboost`, `shap`, `pyarrow`, `xarray`, `geopandas`,
`biopython` for the generic helpers.

## Quick start
```python
from hea_al_tools import (
    load_alloy_dataset, split_train_holdout,
    train_ensemble_regressor, predict_with_uncertainty,
    acquisition_score, regression_metrics,
)
info = load_alloy_dataset("input_data/data/hea_grid.csv")
spl  = split_train_holdout("input_data/data/hea_grid.csv",
                           holdout_indices=list(range(699, 717)))
mdl  = train_ensemble_regressor(spl["cache_id"], model_type="ensemble",
                                n_models=10)
pred = predict_with_uncertainty(mdl["model_id"], spl["cache_id"], on="holdout")
acq  = acquisition_score(pred["pred_mean"], pred["pred_std"],
                         strategy="rank_weighted")
print(regression_metrics(pred["y_true"], pred["pred_mean"]))
```

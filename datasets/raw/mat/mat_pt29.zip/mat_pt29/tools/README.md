# Tools — mat_pt29 (Polymer Tg QSPR)

Three modules; the FastMCP server lives in `polymer_qspr_tools.py`.

| Module | Purpose | Examples |
|---|---|---|
| `polymer_qspr_tools.py` | Domain primitives (FastMCP) | `load_csv_summary`, `split_train_test`, `compute_rdkit_descriptors`, `compute_morgan_fingerprints`, `train_regressor`, `compare_regressors`, `ga_feature_selection`, `plot_observed_vs_predicted`, `plot_model_comparison`, `plot_coefficient_bars`, `correlation_matrix`, `compute_metrics` |
| `data_processing.py` | Generic table/file IO | `read_csv`, `coerce_numeric`, `drop_missing`, `groupby_aggregate`, `pivot_long_to_wide`, `join_tables` |
| `database_retrieval.py` | External-DB stubs | `query_pubchem`, `fetch_url`, `query_doi` (placeholders, fill at runtime if needed) |

## Workflow shape

A QSPR-style polymer Tg pipeline typically chains:

1. `load_csv_summary(csv_path)` to inspect the dataset shape and column ranges.
2. `split_train_test(csv_path, target_col="logTg", test_size=0.25, stratify_by_rank=True)` to obtain reproducible train/test indices.
3. `compare_regressors(csv_path, feature_cols, "logTg", train_idx, test_idx)` to benchmark MLR / kNN / SVR / RF / GPR / MLP on the descriptor pool.
4. `train_regressor(..., model_type="svr", model_params={"C": ..., "gamma": ...})` followed by `score_regressor` for the best model.
5. `plot_observed_vs_predicted` and `plot_model_comparison` to produce the answer figures.

Optional: `ga_feature_selection` to repeat the paper's GA-MLR descriptor-subset search over a larger candidate pool, or `compute_rdkit_descriptors` / `compute_morgan_fingerprints` to expand the feature set with RDKit-derived descriptors when SMILES are available.

## Dependencies

```
numpy, pandas, scikit-learn, matplotlib, rdkit, mcp
```

Install: `pip install numpy pandas scikit-learn matplotlib rdkit mcp`

## Run as MCP server

```
python tools/polymer_qspr_tools.py
```

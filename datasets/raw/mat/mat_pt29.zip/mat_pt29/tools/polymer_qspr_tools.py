#!/usr/bin/env python3
"""Polymer QSPR / ML primitives for glass-transition-temperature prediction.

Low-level FastMCP tools: load + summarise tabular data, compute extra
RDKit/Mordred descriptors from SMILES, normalise features, train and
score regression models (MLR, kNN, SVR, RF, GPR, MLP), Genetic-Algorithm
feature selection over a pool of descriptors, and plot helpers.

Designed so an agent can reproduce a paper-style QSPR workflow:
    load_csv_summary -> normalise_features -> compare_regressors ->
    plot_observed_vs_predicted -> plot_coefficient_bars

No domain logic is hardcoded — the agent picks descriptor sets,
hyperparameters, splits, and feature subsets.
"""
from __future__ import annotations

import hashlib
import os
import pickle
from typing import Any

import numpy as np
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Polymer_QSPR_Tools")


# ----------------------------- IO + summary -----------------------------

@mcp.tool()
def load_csv_summary(csv_path: str) -> dict:
    """Load a CSV file and return shape, column names and per-column stats.

    Args:
        csv_path: Path to CSV.

    Returns:
        dict with shape, columns, numeric_stats {col: {mean,std,min,max,median}}.
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    stats: dict = {}
    for c in df.columns:
        if df[c].dtype.kind in "fi":
            s = df[c].dropna()
            stats[c] = {
                "mean": round(float(s.mean()), 6),
                "std": round(float(s.std()), 6),
                "min": round(float(s.min()), 6),
                "max": round(float(s.max()), 6),
                "median": round(float(s.median()), 6),
                "n": int(len(s)),
            }
    return {
        "shape": list(df.shape),
        "columns": list(df.columns),
        "numeric_stats": stats,
    }


@mcp.tool()
def split_train_test(csv_path: str, target_col: str = "logTg",
                     test_size: float = 0.25, random_state: int = 42,
                     stratify_by_rank: bool = False) -> dict:
    """Split a feature CSV into train/test indices and return their values.

    If stratify_by_rank is True, sort by target ascending and pick every
    1/test_size-th row for the test set (paper's "every third polymer
    after sorting" scheme). Otherwise random split.

    Args:
        csv_path: Path to a CSV containing features + target column.
        target_col: Name of the target column.
        test_size: Fraction (or 1/k for stratify_by_rank).
        random_state: Seed for random split.
        stratify_by_rank: If True, do rank-based deterministic split.

    Returns:
        dict with train_idx, test_idx, train_targets, test_targets, and
        train_size / test_size.
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    n = len(df)
    if stratify_by_rank:
        order = np.argsort(df[target_col].values)
        step = max(2, int(round(1 / test_size)))
        test_mask = np.zeros(n, dtype=bool)
        for i in range(step - 1, n, step):
            test_mask[order[i]] = True
        idx_te = np.where(test_mask)[0].tolist()
        idx_tr = np.where(~test_mask)[0].tolist()
    else:
        from sklearn.model_selection import train_test_split
        idx_tr, idx_te = train_test_split(
            np.arange(n), test_size=test_size, random_state=random_state)
        idx_tr, idx_te = idx_tr.tolist(), idx_te.tolist()
    return {
        "train_idx": idx_tr,
        "test_idx": idx_te,
        "train_size": len(idx_tr),
        "test_size": len(idx_te),
        "train_targets": [round(float(v), 6) for v in df[target_col].iloc[idx_tr]],
        "test_targets": [round(float(v), 6) for v in df[target_col].iloc[idx_te]],
    }


@mcp.tool()
def normalise_features(csv_path: str, feature_cols: list,
                       method: str = "standard") -> dict:
    """Compute per-feature normalisation parameters.

    Args:
        csv_path: Path to CSV.
        feature_cols: list of column names to normalise.
        method: "standard" (z-score) or "minmax" ([0,1]).

    Returns:
        dict with method, params {col: {a,b}}, where standard uses
        (a=mean, b=std) and minmax uses (a=min, b=max-min).
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    params: dict = {}
    for c in feature_cols:
        s = df[c].dropna().astype(float).values
        if method == "minmax":
            a = float(s.min()); b = float(s.max() - s.min())
            if b == 0: b = 1.0
        else:
            a = float(s.mean()); b = float(s.std())
            if b == 0: b = 1.0
        params[c] = {"a": round(a, 8), "b": round(b, 8)}
    return {"method": method, "params": params, "n": int(len(df))}


# --------------------- SMILES / descriptor primitives ---------------------

@mcp.tool()
def canonicalise_smiles(smiles_list: list) -> dict:
    """Canonicalise a list of SMILES strings via RDKit.

    Returns canonical (unique) SMILES, plus parse failures.
    """
    from rdkit import Chem
    from rdkit import RDLogger
    RDLogger.DisableLog("rdApp.*")
    out, failed = [], []
    for s in smiles_list:
        m = Chem.MolFromSmiles(s)
        if m is None:
            failed.append(s)
            out.append(None)
        else:
            out.append(Chem.MolToSmiles(m))
    return {"canonical": out, "n_failed": len(failed),
            "failed": failed[:20], "n": len(smiles_list)}


@mcp.tool()
def compute_rdkit_descriptors(smiles_list: list,
                              descriptor_names: list | None = None) -> dict:
    """Compute selected RDKit 2D molecular descriptors for each SMILES.

    Args:
        smiles_list: list of SMILES strings (each treated as monomer/repeating unit).
        descriptor_names: optional list of RDKit Descriptors function names.
            If None, computes a default panel of ~20 descriptors covering
            constitutional, topological and electronic features.

    Returns:
        dict with descriptor_names used, values (list-of-list, NaN for
        unparseable inputs), and indices_failed.
    """
    from rdkit import Chem
    from rdkit.Chem import Descriptors
    from rdkit import RDLogger
    RDLogger.DisableLog("rdApp.*")
    if descriptor_names is None:
        descriptor_names = [
            "MolWt", "HeavyAtomCount", "NumAromaticRings", "NumRotatableBonds",
            "NumHDonors", "NumHAcceptors", "TPSA", "MolLogP", "FractionCSP3",
            "NumAliphaticRings", "RingCount", "NumValenceElectrons",
            "BertzCT", "BalabanJ", "Chi0", "Chi1", "Kappa1", "Kappa2",
            "HallKierAlpha", "LabuteASA",
        ]
    fns = {name: getattr(Descriptors, name) for name in descriptor_names
           if hasattr(Descriptors, name)}
    rows, failed = [], []
    for i, s in enumerate(smiles_list):
        m = Chem.MolFromSmiles(s) if s else None
        if m is None:
            failed.append(i); rows.append([float("nan")] * len(fns))
            continue
        rows.append([round(float(fns[n](m)), 6) for n in fns])
    return {
        "descriptor_names": list(fns.keys()),
        "values": rows,
        "indices_failed": failed,
        "n": len(smiles_list),
    }


@mcp.tool()
def compute_morgan_fingerprints(smiles_list: list, radius: int = 2,
                                n_bits: int = 1024,
                                use_count: bool = False) -> dict:
    """Compute Morgan / circular fingerprints for SMILES.

    Args:
        smiles_list: list of SMILES strings.
        radius: Morgan radius (2 = ECFP4 equivalent).
        n_bits: bit-vector length.
        use_count: if True, return counts; else 0/1 bits.

    Returns:
        dict with values (list of length-n_bits int lists) and failures.
    """
    from rdkit import Chem
    from rdkit.Chem import AllChem
    from rdkit import RDLogger
    RDLogger.DisableLog("rdApp.*")
    rows, failed = [], []
    for i, s in enumerate(smiles_list):
        m = Chem.MolFromSmiles(s) if s else None
        if m is None:
            failed.append(i); rows.append([0] * n_bits); continue
        if use_count:
            fp = AllChem.GetHashedMorganFingerprint(m, radius, nBits=n_bits)
            arr = [0] * n_bits
            for k, v in fp.GetNonzeroElements().items():
                arr[k] = int(v)
        else:
            fp = AllChem.GetMorganFingerprintAsBitVect(m, radius, nBits=n_bits)
            arr = [int(b) for b in fp]
        rows.append(arr)
    return {"radius": radius, "n_bits": n_bits, "use_count": use_count,
            "values": rows, "indices_failed": failed, "n": len(smiles_list)}


# --------------------------- Model training ------------------------------

@mcp.tool()
def train_regressor(csv_path: str, feature_cols: list, target_col: str,
                    train_idx: list, model_type: str = "svr",
                    model_params: dict | None = None,
                    standardise: bool = True) -> dict:
    """Train a regression model on the rows indexed by train_idx.

    Persists the fitted model + scaler under /tmp keyed by a model_id so
    later prediction / scoring tools can reload it.

    Args:
        csv_path: feature CSV.
        feature_cols: list of column names used as features.
        target_col: column name for the target.
        train_idx: list of row indices in the CSV.
        model_type: one of {mlr, knn, svr, rf, gpr, mlp}.
        model_params: optional sklearn estimator kwargs override.
        standardise: if True, fit a StandardScaler on training features.

    Returns:
        dict with model_id, model_type, n_train, R2_train, RMSE_train.
    """
    import pandas as pd
    from sklearn.metrics import r2_score, mean_squared_error
    from sklearn.preprocessing import StandardScaler

    df = pd.read_csv(csv_path)
    Xtr = df[feature_cols].iloc[train_idx].astype(float).values
    ytr = df[target_col].iloc[train_idx].astype(float).values

    scaler = None
    if standardise:
        scaler = StandardScaler().fit(Xtr)
        Xtr_in = scaler.transform(Xtr)
    else:
        Xtr_in = Xtr

    p = dict(model_params or {})
    if model_type == "mlr":
        from sklearn.linear_model import LinearRegression
        model = LinearRegression(**p)
    elif model_type == "knn":
        from sklearn.neighbors import KNeighborsRegressor
        model = KNeighborsRegressor(**({"n_neighbors": 5, **p}))
    elif model_type == "svr":
        from sklearn.svm import SVR
        model = SVR(**({"kernel": "rbf", "C": 10.0, "gamma": "scale", **p}))
    elif model_type == "rf":
        from sklearn.ensemble import RandomForestRegressor
        model = RandomForestRegressor(**({"n_estimators": 200, "random_state": 0, **p}))
    elif model_type == "gpr":
        from sklearn.gaussian_process import GaussianProcessRegressor
        from sklearn.gaussian_process.kernels import RBF, ConstantKernel, WhiteKernel
        kernel = p.pop("kernel", None) or (ConstantKernel(1.0) * RBF(1.0) + WhiteKernel(1e-2))
        model = GaussianProcessRegressor(kernel=kernel, normalize_y=True,
                                         random_state=0, **p)
    elif model_type == "mlp":
        from sklearn.neural_network import MLPRegressor
        model = MLPRegressor(**({"hidden_layer_sizes": (50,), "max_iter": 5000,
                                  "random_state": 0, **p}))
    else:
        return {"error": f"unknown model_type {model_type}"}

    model.fit(Xtr_in, ytr)
    p_tr = model.predict(Xtr_in)
    r2 = float(r2_score(ytr, p_tr))
    rmse = float(np.sqrt(mean_squared_error(ytr, p_tr)))

    blob = pickle.dumps({"model": model, "scaler": scaler,
                         "feature_cols": feature_cols,
                         "target_col": target_col,
                         "model_type": model_type})
    model_id = hashlib.md5(blob[:2000] + os.urandom(8)).hexdigest()[:10]
    with open(f"/tmp/poly_model_{model_id}.pkl", "wb") as f:
        f.write(blob)

    out = {"model_id": model_id, "model_type": model_type,
           "n_train": int(len(train_idx)),
           "R2_train": round(r2, 4), "RMSE_train": round(rmse, 4),
           "predictions_train": [round(float(v), 6) for v in p_tr],
           "feature_cols": list(feature_cols)}
    # Expose linear-model coefficients for plot_coefficient_bars when model is MLR
    if model_type == "mlr" and hasattr(model, "coef_"):
        out["coefficients"] = [round(float(c), 6) for c in model.coef_]
        out["intercept"] = round(float(model.intercept_), 6)
    return out


@mcp.tool()
def score_regressor(model_id: str, csv_path: str, eval_idx: list) -> dict:
    """Score a stored model on the given row indices.

    Args:
        model_id: id from train_regressor.
        csv_path: feature CSV (same one used for training, columns must match).
        eval_idx: list of row indices to evaluate on.

    Returns:
        dict with R2, RMSE, MAE, predictions, true_values.
    """
    import pandas as pd
    from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
    with open(f"/tmp/poly_model_{model_id}.pkl", "rb") as f:
        st = pickle.load(f)
    model, scaler = st["model"], st["scaler"]
    feature_cols, target_col = st["feature_cols"], st["target_col"]
    df = pd.read_csv(csv_path)
    X = df[feature_cols].iloc[eval_idx].astype(float).values
    y = df[target_col].iloc[eval_idx].astype(float).values
    if scaler is not None:
        X = scaler.transform(X)
    pred = model.predict(X)
    return {
        "model_id": model_id, "n_eval": int(len(eval_idx)),
        "R2": round(float(r2_score(y, pred)), 4),
        "RMSE": round(float(np.sqrt(mean_squared_error(y, pred))), 4),
        "MAE": round(float(mean_absolute_error(y, pred)), 4),
        "predictions": [round(float(v), 6) for v in pred],
        "true_values": [round(float(v), 6) for v in y],
    }


@mcp.tool()
def compare_regressors(csv_path: str, feature_cols: list, target_col: str,
                       train_idx: list, test_idx: list,
                       model_types: list | None = None,
                       random_state: int = 0,
                       preserve_order: bool = False) -> dict:
    """Train several regressors and report R²/RMSE on train + test.

    Args:
        csv_path: feature CSV.
        feature_cols: list of column names used as features.
        target_col: target column name.
        train_idx: row indices for training.
        test_idx: row indices for evaluation.
        model_types: subset of {mlr, knn, svr, rf, gpr, mlp}. Default = all 6.
        random_state: seed where applicable.

    Returns:
        dict with per-model R2_train, R2_test, RMSE_train, RMSE_test.
    """
    import pandas as pd
    from sklearn.metrics import r2_score, mean_squared_error
    from sklearn.preprocessing import StandardScaler
    if model_types is None:
        model_types = ["mlr", "knn", "svr", "rf", "gpr", "mlp"]

    df = pd.read_csv(csv_path)
    Xtr = df[feature_cols].iloc[train_idx].astype(float).values
    ytr = df[target_col].iloc[train_idx].astype(float).values
    Xte = df[feature_cols].iloc[test_idx].astype(float).values
    yte = df[target_col].iloc[test_idx].astype(float).values
    sc = StandardScaler().fit(Xtr)
    Xtr_n, Xte_n = sc.transform(Xtr), sc.transform(Xte)

    out = []
    for mt in model_types:
        try:
            if mt == "mlr":
                from sklearn.linear_model import LinearRegression
                m = LinearRegression()
            elif mt == "knn":
                from sklearn.neighbors import KNeighborsRegressor
                m = KNeighborsRegressor(n_neighbors=5)
            elif mt == "svr":
                from sklearn.svm import SVR
                m = SVR(kernel="rbf", C=10.0, gamma="scale")
            elif mt == "rf":
                from sklearn.ensemble import RandomForestRegressor
                m = RandomForestRegressor(n_estimators=200, random_state=random_state)
            elif mt == "gpr":
                from sklearn.gaussian_process import GaussianProcessRegressor
                from sklearn.gaussian_process.kernels import RBF, ConstantKernel, WhiteKernel
                k = ConstantKernel(1.0) * RBF(1.0) + WhiteKernel(1e-2)
                m = GaussianProcessRegressor(kernel=k, normalize_y=True,
                                             random_state=random_state)
            elif mt == "mlp":
                from sklearn.neural_network import MLPRegressor
                m = MLPRegressor(hidden_layer_sizes=(50,), max_iter=5000,
                                 random_state=random_state)
            else:
                continue
            m.fit(Xtr_n, ytr)
            p_tr, p_te = m.predict(Xtr_n), m.predict(Xte_n)
            out.append({
                "model": mt,
                "R2_train": round(float(r2_score(ytr, p_tr)), 4),
                "R2_test": round(float(r2_score(yte, p_te)), 4),
                "RMSE_train": round(float(np.sqrt(mean_squared_error(ytr, p_tr))), 4),
                "RMSE_test": round(float(np.sqrt(mean_squared_error(yte, p_te))), 4),
            })
        except Exception as e:
            out.append({"model": mt, "error": str(e)})
    if not preserve_order:
        out.sort(key=lambda r: r.get("R2_test", -999), reverse=True)
    return {"n_models": len(out), "n_train": len(train_idx),
            "n_test": len(test_idx), "n_features": len(feature_cols),
            "results": out}


# --------------------- Feature selection / GA-MLR ------------------------

@mcp.tool()
def ga_feature_selection(csv_path: str, candidate_cols: list,
                         target_col: str, train_idx: list, test_idx: list,
                         k: int = 15, n_generations: int = 50,
                         population: int = 80, mutation_rate: float = 0.1,
                         random_state: int = 0) -> dict:
    """Genetic-algorithm feature subset selection on top of MLR.

    Searches for a subset of size k that maximises adjusted R² on the
    train set (with cross-fold check on the test set as a tiebreaker).

    Args:
        csv_path: feature CSV.
        candidate_cols: pool of candidate feature column names.
        target_col: target column.
        train_idx, test_idx: row index splits.
        k: number of descriptors to select.
        n_generations: GA iterations.
        population: GA population size.
        mutation_rate: per-gene flip probability.
        random_state: seed.

    Returns:
        dict with selected_cols, best_R2_train, best_R2_test, fitness_history.
    """
    import pandas as pd
    from sklearn.linear_model import LinearRegression
    from sklearn.metrics import r2_score
    rng = np.random.default_rng(random_state)
    df = pd.read_csv(csv_path)
    n_pool = len(candidate_cols)
    Xall = df[candidate_cols].astype(float).values
    y = df[target_col].astype(float).values
    Xtr_full, ytr = Xall[train_idx], y[train_idx]
    Xte_full, yte = Xall[test_idx], y[test_idx]

    def mask_to_cols(mask):
        idx = np.where(mask)[0]
        return idx

    def fitness(mask):
        idx = mask_to_cols(mask)
        if len(idx) != k:
            return -np.inf
        m = LinearRegression()
        m.fit(Xtr_full[:, idx], ytr)
        p_tr = m.predict(Xtr_full[:, idx])
        return r2_score(ytr, p_tr)

    # initialise population with random k-subsets
    pop = []
    for _ in range(population):
        mask = np.zeros(n_pool, dtype=bool)
        chosen = rng.choice(n_pool, size=k, replace=False)
        mask[chosen] = True
        pop.append(mask)

    history = []
    for gen in range(n_generations):
        scored = sorted(((fitness(m), i) for i, m in enumerate(pop)),
                        key=lambda t: t[0], reverse=True)
        best_fit = scored[0][0]
        history.append(round(float(best_fit), 4))
        # elitism: keep top 20%
        elite_n = max(2, population // 5)
        new_pop = [pop[i].copy() for _, i in scored[:elite_n]]
        # fill rest by crossover + mutation
        while len(new_pop) < population:
            a = pop[scored[rng.integers(0, elite_n * 2)][1]]
            b = pop[scored[rng.integers(0, elite_n * 2)][1]]
            child = a.copy()
            swap = rng.choice(np.where(a != b)[0],
                              size=min(2, int((a != b).sum())), replace=False) \
                if (a != b).any() else np.array([], dtype=int)
            for s in swap:
                child[s] = b[s]
            # mutation: flip a small number of bits while keeping size = k
            if rng.random() < mutation_rate:
                ones = np.where(child)[0]; zeros = np.where(~child)[0]
                if len(ones) > 0 and len(zeros) > 0:
                    o = rng.choice(ones); z = rng.choice(zeros)
                    child[o] = False; child[z] = True
            # repair to size k
            cnt = int(child.sum())
            if cnt > k:
                ones = np.where(child)[0]
                drop = rng.choice(ones, size=cnt - k, replace=False)
                child[drop] = False
            elif cnt < k:
                zeros = np.where(~child)[0]
                add = rng.choice(zeros, size=k - cnt, replace=False)
                child[add] = True
            new_pop.append(child)
        pop = new_pop

    best_mask = pop[0]
    for m in pop:
        if fitness(m) > fitness(best_mask):
            best_mask = m
    sel_idx = np.where(best_mask)[0]
    sel_cols = [candidate_cols[i] for i in sel_idx]
    mlr = LinearRegression(); mlr.fit(Xtr_full[:, sel_idx], ytr)
    p_tr = mlr.predict(Xtr_full[:, sel_idx])
    p_te = mlr.predict(Xte_full[:, sel_idx])
    return {
        "selected_cols": sel_cols,
        "k": k,
        "best_R2_train": round(float(r2_score(ytr, p_tr)), 4),
        "best_R2_test": round(float(r2_score(yte, p_te)), 4),
        "coefficients": [round(float(c), 4) for c in mlr.coef_],
        "intercept": round(float(mlr.intercept_), 4),
        "fitness_history": history,
    }


# ------------------------------ Plots -----------------------------------

@mcp.tool()
def plot_observed_vs_predicted(true_train: list, pred_train: list,
                               true_test: list, pred_test: list,
                               output_path: str = "artifacts/scatter_obs_vs_pred.png",
                               xlabel: str = "experimental log(Tg)",
                               ylabel: str = "predicted log(Tg)") -> dict:
    """Observed-vs-predicted scatter for train + test sets.

    Args:
        true_train, pred_train: train observed and predicted values.
        true_test, pred_test: test observed and predicted values.
        output_path: PNG output path.
        xlabel, ylabel: axis labels.

    Returns:
        dict with output_path.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig, ax = plt.subplots(figsize=(6, 6))
    ax.scatter(true_train, pred_train, c="#5b8def", s=24, alpha=0.7,
               label="training")
    ax.scatter(true_test, pred_test, c="#f4a300", s=24, alpha=0.85,
               label="validation")
    lims = [
        min(min(true_train), min(true_test), min(pred_train), min(pred_test)),
        max(max(true_train), max(true_test), max(pred_train), max(pred_test)),
    ]
    ax.plot(lims, lims, "k--", lw=1)
    ax.set_xlim(lims); ax.set_ylim(lims)
    ax.set_xlabel(xlabel); ax.set_ylabel(ylabel)
    ax.legend()
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"output_path": output_path,
            "n_train": len(true_train), "n_test": len(true_test)}


@mcp.tool()
def plot_model_comparison(results: list,
                          output_path: str = "artifacts/model_comparison.png",
                          metric: str = "R2") -> dict:
    """Bar chart comparing models on R²/RMSE for train + test.

    Args:
        results: list of dicts with keys {model, R2_train, R2_test,
            RMSE_train, RMSE_test} (e.g. compare_regressors output).
        output_path: PNG output path.
        metric: "R2" or "RMSE".

    Returns:
        dict with output_path.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    names = [r.get("model", "?") for r in results]
    train_v = [r.get(f"{metric}_train", 0) for r in results]
    test_v = [r.get(f"{metric}_test", 0) for r in results]
    x = np.arange(len(names))
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.bar(x - 0.18, train_v, width=0.35, label="Training", color="#5b8def")
    ax.bar(x + 0.18, test_v, width=0.35, label="Test", color="#f4a300")
    ax.set_xticks(x); ax.set_xticklabels(names, rotation=20)
    ax.set_ylabel(metric)
    ax.legend()
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"output_path": output_path, "n_models": len(names),
            "metric": metric}


@mcp.tool()
def plot_coefficient_bars(feature_names: list, coefficients: list,
                          output_path: str = "artifacts/coef_bars.png",
                          xlabel: str = "Coefficient Values") -> dict:
    """Horizontal bar plot of MLR (or other linear) coefficient values.

    Args:
        feature_names: list of feature names (one per coefficient).
        coefficients: list of float coefficient values.
        output_path: PNG output path.
        xlabel: x-axis label.

    Returns:
        dict with output_path.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    coefs = np.array(coefficients, dtype=float)
    y = np.arange(len(feature_names))
    fig, ax = plt.subplots(figsize=(7, 0.35 * len(feature_names) + 1.5))
    ax.barh(y, coefs, color="#5b8def")
    ax.axvline(0, color="k", lw=0.6, ls="--")
    ax.set_yticks(y); ax.set_yticklabels(feature_names)
    ax.invert_yaxis()
    ax.set_xlabel(xlabel)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"output_path": output_path, "n_features": len(feature_names)}


# --------------------- Misc small primitives ---------------------------

@mcp.tool()
def correlation_matrix(csv_path: str, cols: list) -> dict:
    """Pearson correlation matrix for the listed columns.

    Args:
        csv_path: CSV path.
        cols: list of numeric column names.

    Returns:
        dict with matrix (list-of-list) and column order.
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    M = df[cols].astype(float).corr().values
    return {"columns": cols,
            "matrix": [[round(float(x), 4) for x in row] for row in M]}


@mcp.tool()
def compute_metrics(predictions: list, true_values: list) -> dict:
    """Compute regression metrics (R², RMSE, MAE).

    Args:
        predictions: model predictions.
        true_values: ground-truth target values.

    Returns:
        dict with R2, RMSE, MAE, n.
    """
    from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
    pred = np.asarray(predictions, dtype=float)
    true = np.asarray(true_values, dtype=float)
    return {
        "n": int(len(true)),
        "R2": round(float(r2_score(true, pred)), 4),
        "RMSE": round(float(np.sqrt(mean_squared_error(true, pred))), 4),
        "MAE": round(float(mean_absolute_error(true, pred)), 4),
    }


if __name__ == "__main__":
    mcp.run(transport="stdio")

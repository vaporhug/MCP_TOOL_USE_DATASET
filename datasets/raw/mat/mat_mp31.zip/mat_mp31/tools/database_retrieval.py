"""External database retrieval tools.

Lightweight wrappers around public REST APIs (ChEMBL, PubChem) and a
generic HTTP fetcher. All functions are runnable but rely on outbound
network connectivity at the time of call.
"""
from typing import Any
import json
import os
import urllib.parse
import urllib.request
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("database_retrieval")

_UA = (
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"
)


@mcp.tool()
def fetch_url(url: str, timeout: int = 60) -> dict:
    """HTTP GET with redirects. Returns {status, content_type, body_path,
    nbytes}. Body is saved to a temp file and the path is returned to
    avoid blowing up tool call sizes.
    """
    req = urllib.request.Request(url, headers={"User-Agent": _UA})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        ct = r.headers.get("Content-Type", "application/octet-stream")
        body = r.read()
        status = r.status
    suffix = ".bin"
    if "pdf" in ct:
        suffix = ".pdf"
    elif "json" in ct:
        suffix = ".json"
    elif "csv" in ct:
        suffix = ".csv"
    elif "html" in ct:
        suffix = ".html"
    import tempfile
    fd, p = tempfile.mkstemp(suffix=suffix)
    with os.fdopen(fd, "wb") as f:
        f.write(body)
    return {"status": status, "content_type": ct, "body_path": p, "nbytes": len(body)}


@mcp.tool()
def query_chembl_target(target_id: str, activity_type: str = "IC50",
                        max_records: int = 1000) -> list[dict]:
    """Page through the ChEMBL REST API and pull bioactivity records for a
    target (e.g. CHEMBL340 for CYP3A4, CHEMBL240 for hERG).

    Filters: standard_relation '=' and standard_units 'nM' to keep only
    well-defined potency values. Returns up to max_records of
    {molecule_chembl_id, canonical_smiles, standard_value (nM),
    pchembl_value, assay_chembl_id}. Aggregation (e.g. mean per molecule)
    is left to caller.
    """
    out: list[dict] = []
    offset = 0
    while len(out) < max_records:
        q = (
            f"https://www.ebi.ac.uk/chembl/api/data/activity.json?"
            f"target_chembl_id={urllib.parse.quote(target_id)}"
            f"&standard_type={urllib.parse.quote(activity_type)}"
            "&standard_units=nM&standard_relation==&limit=200"
            f"&offset={offset}"
        )
        req = urllib.request.Request(q, headers={"User-Agent": _UA})
        with urllib.request.urlopen(req, timeout=120) as r:
            data = json.loads(r.read())
        acts = data.get("activities", [])
        if not acts:
            break
        for a in acts:
            sm = a.get("canonical_smiles")
            sv = a.get("standard_value")
            mid = a.get("molecule_chembl_id")
            pc = a.get("pchembl_value")
            if not (sm and sv and mid):
                continue
            try:
                rec = {
                    "molecule_chembl_id": mid,
                    "canonical_smiles": sm,
                    "standard_value": float(sv),
                    "pchembl_value": float(pc) if pc else None,
                    "assay_chembl_id": a.get("assay_chembl_id"),
                }
            except ValueError:
                continue
            out.append(rec)
            if len(out) >= max_records:
                break
        offset += 200
        if len(acts) < 200:
            break
    return out


@mcp.tool()
def query_pubchem(identifier: str, namespace: str = "cid") -> dict:
    """PubChem PUG-REST lookup. namespace in {cid, name, smiles, inchikey}.
    Returns the compound's basic record.
    """
    base = "https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound"
    url = (
        f"{base}/{namespace}/{urllib.parse.quote(identifier, safe='')}/property/"
        "CanonicalSMILES,MolecularWeight,XLogP,IUPACName/JSON"
    )
    req = urllib.request.Request(url, headers={"User-Agent": _UA})
    with urllib.request.urlopen(req, timeout=60) as r:
        data = json.loads(r.read())
    props = data.get("PropertyTable", {}).get("Properties", [])
    return props[0] if props else {}


@mcp.tool()
def query_doi(doi: str) -> dict:
    """Resolve a DOI to a Crossref metadata record + OA full-text URL via
    Unpaywall. Returns {title, authors, journal, year, oa_pdf}.
    """
    cr = f"https://api.crossref.org/works/{urllib.parse.quote(doi, safe='/')}"
    req = urllib.request.Request(cr, headers={"User-Agent": _UA})
    with urllib.request.urlopen(req, timeout=60) as r:
        cdata = json.loads(r.read()).get("message", {})
    up = (
        f"https://api.unpaywall.org/v2/{urllib.parse.quote(doi, safe='/')}"
        "?email=task-runner@example.org"
    )
    oa_pdf = None
    try:
        with urllib.request.urlopen(up, timeout=60) as r:
            udata = json.loads(r.read())
        loc = udata.get("best_oa_location") or {}
        oa_pdf = loc.get("url_for_pdf") or loc.get("url")
    except Exception:
        pass
    return {
        "title": (cdata.get("title") or [None])[0],
        "authors": [
            f"{a.get('given','')} {a.get('family','')}".strip()
            for a in cdata.get("author", [])
        ],
        "journal": (cdata.get("container-title") or [None])[0],
        "year": (cdata.get("issued", {}).get("date-parts") or [[None]])[0][0],
        "doi": doi,
        "oa_pdf": oa_pdf,
    }


if __name__ == "__main__":
    mcp.run()

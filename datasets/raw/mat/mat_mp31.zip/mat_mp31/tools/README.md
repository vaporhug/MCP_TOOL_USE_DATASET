# mat_mp31 — Tool Reference

Three FastMCP tool modules. Run each as a server (`python -m <module>`)
or import the `@mcp.tool()` decorated functions directly.

## Database Retrieval (`database_retrieval.py`)

Public-API helpers; require outbound network at call time.

- **fetch_url(url, timeout=60)** — HTTP GET, body saved to a temp file (returns path + content type).
- **query_chembl_target(target_id, activity_type='IC50', max_records=1000)** — page through ChEMBL REST and return per-record SMILES + standard_value/pchembl_value (e.g. `CHEMBL340` for CYP3A4, `CHEMBL240` for hERG).
- **query_pubchem(identifier, namespace='cid')** — PubChem PUG-REST property lookup.
- **query_doi(doi)** — Crossref + Unpaywall metadata + OA PDF URL.

## Data Processing (`data_processing.py`)

Generic CSV/TSV/SMI/JSON helpers; no chemistry domain logic.

- **read_csv / write_csv** — list-of-dict round trip.
- **read_smi / write_smi** — `<SMILES>\\t<id>` whitespace format used by `mmpdb fragment`.
- **read_json / write_json** — JSON round trip.
- **filter_rows(rows, column, op, value)** — numeric row filter.
- **groupby_aggregate(rows, by, value_col)** — count/mean/std/median per group.
- **join_tables(left, right, on)** — inner join.

## MMP / mmpdb Primitives (`mmpdb_tools.py`)

Wraps the `mmpdb` CLI (Stage 1 fragment / index / loadprops, Stage 2
transform / predict) plus direct SQLite inspection and plotting.

### SMILES / RDKit utilities
- **sanitize_smiles(smiles)** — RDKit canonicalisation, MW, heavy-atom count.
- **sanitize_smi_file(input_smi, output_smi, drop_invalid=True)** — bulk clean.
- **fragment_smiles(smiles, max_cuts=1)** — single-molecule cut enumeration (mmpdb-style preview).

### Stage 1 — build the database
- **mmpdb_fragment(smi_path, fragdb_path, num_jobs=1)** — `mmpdb fragment`.
- **mmpdb_index(fragdb_path, mmpdb_path)** — `mmpdb index`.
- **mmpdb_loadprops(mmpdb_path, properties_csv)** — `mmpdb loadprops` (TSV: `ID\\tprop1\\tprop2\\t…`).

### Stage 2 — query the rules
- **mmpdb_transform(mmpdb_path, query_smiles, property_name, out_csv=None)** — apply rules, list suggested derivatives.
- **mmpdb_predict(mmpdb_path, reference_smiles, query_smiles, property_name)** — predict Δproperty for a specific pair, parsed from stdout.

### Direct DB inspection / SAR mining
- **mmpdb_summary(mmpdb_path)** — table list + per-table row counts + dataset header.
- **mmpdb_top_rules(mmpdb_path, property_name, min_pairs=10, top_n=30, direction='either')** — most impactful rules.
- **mmpdb_rule_distribution(mmpdb_path, property_name, min_pairs=3)** — full quantile summary of per-rule mean Δproperty.

### Plotting
- **plot_rule_delta_histograms(mmpdb_path, property_names, output_png, min_pairs=3)** — per-property Δ histograms.
- **plot_pair_delta_scatter(mmpdb_path, property_x, property_y, output_png, min_pairs=5)** — Δprop_x vs Δprop_y for rules common to both → identifies selectivity rules.

## Dependencies

`mmpdb==3.1.4` (pinned — exact bundled answer-text row counts were
generated against mmpdb 3.1.4 defaults; newer versions may differ
slightly in fragmentation / indexing behaviour), `rdkit`, `matplotlib`,
`mcp` (FastMCP). Install:

```
pip install "mmpdb==3.1.4" rdkit matplotlib "mcp[cli]"
```

## Example pipeline

```python
mmpdb_fragment("input_data/data/chembl_cyp3a4_herg.smi", "/tmp/cyp_herg.fragdb")
mmpdb_index("/tmp/cyp_herg.fragdb", "/tmp/cyp_herg.mmpdb")
mmpdb_loadprops("/tmp/cyp_herg.mmpdb",
                "input_data/data/chembl_cyp3a4_herg_properties.csv")
mmpdb_summary("/tmp/cyp_herg.mmpdb")
mmpdb_top_rules("/tmp/cyp_herg.mmpdb", "hERG_pIC50", min_pairs=10, direction="decrease")
plot_pair_delta_scatter("/tmp/cyp_herg.mmpdb", "CYP3A4_pIC50", "hERG_pIC50",
                        "artifacts/scatter.png")
```

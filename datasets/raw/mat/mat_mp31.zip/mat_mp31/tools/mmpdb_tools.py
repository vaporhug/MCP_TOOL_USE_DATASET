"""Domain-specific cheminformatics primitives for matched-molecular-pair (MMP)
analysis with mmpdb / RDKit.

These wrap mmpdb's CLI (`fragment`, `index`, `loadprops`, `transform`,
`predict`) and expose minimal RDKit helpers for SMILES sanitisation,
fragmentation primitives, rule mining, and visualisation. Each tool
returns plain-data dicts/lists and never blocks the agent on interactive
prompts.
"""
from __future__ import annotations

import json
import os
import shutil
import sqlite3
import subprocess
from typing import Any, Optional

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("mmpdb_tools")


# ---------------------------------------------------------------- helpers ----

def _run(cmd: list[str], cwd: Optional[str] = None, timeout: int = 1800) -> dict:
    """Run a subprocess and capture stdout/stderr. Returns dict with
    returncode, stdout (truncated to 4kB tail), stderr (truncated)."""
    p = subprocess.run(
        cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout
    )
    return {
        "returncode": p.returncode,
        "cmd": " ".join(cmd),
        "stdout_tail": (p.stdout or "")[-4000:],
        "stderr_tail": (p.stderr or "")[-4000:],
    }


# -------------------------------------------------- 1. SMILES / RDKit utils --

@mcp.tool()
def sanitize_smiles(smiles: str) -> dict:
    """Parse and canonicalise a SMILES string with RDKit.

    Returns {input, canonical, mw, num_heavy_atoms, valid}.
    """
    from rdkit import Chem
    from rdkit.Chem import Descriptors
    m = Chem.MolFromSmiles(smiles)
    if m is None:
        return {"input": smiles, "valid": False}
    return {
        "input": smiles,
        "canonical": Chem.MolToSmiles(m),
        "mw": round(Descriptors.MolWt(m), 3),
        "num_heavy_atoms": m.GetNumHeavyAtoms(),
        "valid": True,
    }


@mcp.tool()
def sanitize_smi_file(input_smi: str, output_smi: str,
                      drop_invalid: bool = True) -> dict:
    """Parse and canonicalise every SMILES in a `.smi` file.

    Each line: '<SMILES>\\t<id>' (or whitespace separated). Writes a new
    `.smi` with canonical SMILES. Returns {n_in, n_kept, n_invalid,
    output_path}.
    """
    from rdkit import Chem
    n_in = n_kept = n_invalid = 0
    with open(input_smi) as fi, open(output_smi, "w") as fo:
        for line in fi:
            line = line.rstrip("\n")
            if not line.strip():
                continue
            n_in += 1
            parts = line.split(None, 1)
            sm = parts[0]
            mid = parts[1] if len(parts) > 1 else ""
            m = Chem.MolFromSmiles(sm)
            if m is None:
                n_invalid += 1
                if drop_invalid:
                    continue
                csm = sm
            else:
                csm = Chem.MolToSmiles(m)
            fo.write(f"{csm}\t{mid}\n")
            n_kept += 1
    return {
        "n_in": n_in,
        "n_kept": n_kept,
        "n_invalid": n_invalid,
        "output_path": os.path.abspath(output_smi),
    }


@mcp.tool()
def fragment_smiles(smiles: str, max_cuts: int = 1) -> list[dict]:
    """Single-molecule fragmentation primitive: enumerate single/double
    cuts of acyclic single bonds and return the resulting (variable,
    constant) fragment SMILES pairs. Mirrors the cut style used by mmpdb
    but on one molecule, useful for understanding what mmpdb produces.

    Args:
        smiles: input SMILES
        max_cuts: 1 (single cut) or 2 (also enumerate double cuts)
    """
    from rdkit import Chem
    from rdkit.Chem import AllChem
    m = Chem.MolFromSmiles(smiles)
    if m is None:
        return []
    out: list[dict] = []
    bonds = [
        b for b in m.GetBonds()
        if b.GetBondType() == Chem.BondType.SINGLE and not b.IsInRing()
    ]
    for b in bonds:
        idx = b.GetIdx()
        try:
            frags = Chem.FragmentOnBonds(m, [idx], dummyLabels=[(1, 1)])
            sm = Chem.MolToSmiles(frags)
            parts = sm.split(".")
            if len(parts) == 2:
                # the smaller of the two fragments is the "variable" part
                a, c = sorted(parts, key=len)
                out.append({"cuts": 1, "variable": a, "constant": c})
        except Exception:
            continue
    if max_cuts >= 2 and len(bonds) >= 2:
        for i in range(len(bonds)):
            for j in range(i + 1, len(bonds)):
                try:
                    frags = Chem.FragmentOnBonds(
                        m, [bonds[i].GetIdx(), bonds[j].GetIdx()],
                        dummyLabels=[(1, 1), (2, 2)],
                    )
                    sm = Chem.MolToSmiles(frags)
                    parts = sm.split(".")
                    if len(parts) == 3:
                        # designate the largest as constant, others as variable
                        parts_sorted = sorted(parts, key=len)
                        out.append({
                            "cuts": 2,
                            "variable": ".".join(parts_sorted[:2]),
                            "constant": parts_sorted[-1],
                        })
                except Exception:
                    continue
    return out


# ---------------------------------------------------- 2. mmpdb CLI wrappers --

@mcp.tool()
def mmpdb_fragment(smi_path: str, fragdb_path: str,
                   num_jobs: int = 1, timeout: int = 1800) -> dict:
    """Run `mmpdb fragment <smi_path> -o <fragdb_path>`.

    Stage 1a of the pipeline: enumerate fragmentations of every molecule
    using mmpdb's default acyclic single-bond cut SMARTS. Produces a
    SQLite fragment DB.
    """
    if os.path.exists(fragdb_path):
        os.remove(fragdb_path)
    cmd = ["mmpdb", "fragment", smi_path, "-o", fragdb_path]
    if num_jobs > 1:
        cmd += ["-j", str(num_jobs)]
    res = _run(cmd, timeout=timeout)
    res["fragdb_size_bytes"] = (
        os.path.getsize(fragdb_path) if os.path.exists(fragdb_path) else 0
    )
    return res


@mcp.tool()
def mmpdb_index(fragdb_path: str, mmpdb_path: str,
                timeout: int = 1800) -> dict:
    """Run `mmpdb index <fragdb_path> -o <mmpdb_path>`.

    Stage 1b: identify matched pairs from common constant fragments and
    write the rule database.
    """
    if os.path.exists(mmpdb_path):
        os.remove(mmpdb_path)
    cmd = ["mmpdb", "index", fragdb_path, "-o", mmpdb_path]
    res = _run(cmd, timeout=timeout)
    res["mmpdb_size_bytes"] = (
        os.path.getsize(mmpdb_path) if os.path.exists(mmpdb_path) else 0
    )
    return res


@mcp.tool()
def mmpdb_loadprops(mmpdb_path: str, properties_csv: str,
                    timeout: int = 1800) -> dict:
    """Run `mmpdb loadprops -p <properties_csv> <mmpdb_path>`.

    Stage 1c: attach numeric property columns (e.g. CYP3A4_pIC50,
    hERG_pIC50) to compounds, recompute aggregate rule statistics.
    Properties file is TSV with header 'ID\\t<prop1>\\t<prop2>...'.
    """
    cmd = ["mmpdb", "loadprops", "-p", properties_csv, mmpdb_path]
    return _run(cmd, timeout=timeout)


@mcp.tool()
def mmpdb_transform(mmpdb_path: str, query_smiles: str,
                    property_name: str,
                    out_csv: Optional[str] = None,
                    timeout: int = 1800) -> dict:
    """Run `mmpdb transform --smiles <q> <mmpdb> --property <p>`.

    Stage 2 (A): apply learned MMP rules to the query molecule and list
    suggested derivatives with predicted property changes.
    """
    cmd = [
        "mmpdb", "transform", "--smiles", query_smiles, mmpdb_path,
        "--property", property_name,
    ]
    if out_csv:
        cmd += ["-o", out_csv]
    res = _run(cmd, timeout=timeout)
    if out_csv and os.path.exists(out_csv):
        with open(out_csv) as f:
            lines = f.readlines()
        res["n_suggestions"] = max(0, len(lines) - 1)
        res["out_csv"] = os.path.abspath(out_csv)
    return res


@mcp.tool()
def mmpdb_predict(mmpdb_path: str, reference_smiles: str,
                  query_smiles: str, property_name: str,
                  timeout: int = 1800) -> dict:
    """Run `mmpdb predict --smiles <q> --reference <r> <mmpdb> --property <p>`.

    Stage 2 (B): use MMP rules to predict the property change between a
    reference and a query compound. Parses the predicted delta from
    stdout.
    """
    cmd = [
        "mmpdb", "predict",
        "--smiles", query_smiles,
        "--reference", reference_smiles,
        mmpdb_path,
        "--property", property_name,
    ]
    res = _run(cmd, timeout=timeout)
    delta = None
    for line in (res.get("stdout_tail") or "").splitlines():
        if "predicted delta" in line.lower():
            try:
                delta = float(line.split()[-1])
            except Exception:
                pass
        elif line.strip().lower().startswith("predicted"):
            try:
                delta = float(line.split()[-1])
            except Exception:
                pass
    res["predicted_delta"] = delta
    return res


# -------------------------------------------- 3. Direct DB inspection / SAR --

@mcp.tool()
def mmpdb_summary(mmpdb_path: str) -> dict:
    """Open the mmpdb SQLite file and return per-table row counts plus the
    dataset header. Useful for verifying that fragment / index / loadprops
    completed."""
    c = sqlite3.connect(mmpdb_path)
    tables = [
        r[0] for r in c.execute(
            "SELECT name FROM sqlite_master WHERE type='table' "
            "AND name NOT LIKE 'sqlite_%' ORDER BY name"
        )
    ]
    counts = {t: c.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
              for t in tables}
    ds = {}
    if "dataset" in tables:
        cur = c.execute("SELECT * FROM dataset")
        cols = [d[0] for d in cur.description]
        rows = cur.fetchall()
        if rows:
            ds = dict(zip(cols, rows[0]))
    props = []
    if "property_name" in tables:
        props = [r[0] for r in c.execute("SELECT name FROM property_name")]
    return {
        "n_tables": len(tables),
        "tables": tables,
        "counts": counts,
        "dataset": ds,
        "properties": props,
    }


@mcp.tool()
def mmpdb_top_rules(mmpdb_path: str, property_name: str,
                    min_pairs: int = 10, top_n: int = 30,
                    direction: str = "either",
                    single_cut_only: bool = False) -> list[dict]:
    """Return the top MMP rules for one property, ranked by absolute mean
    effect with a minimum-count cutoff (mmpdb's heuristic uses
    min_pairs=10).

    Args:
        property_name: e.g. "CYP3A4_pIC50"
        min_pairs: only keep rules supported by >= this many pairs
        top_n: number of rules to return
        direction: "increase" / "decrease" / "either"
        single_cut_only: if True, restrict to single-cut rules
            (rule_smiles with exactly one [*] attachment point on both sides).
    """
    c = sqlite3.connect(mmpdb_path)
    sql = (
        "SELECT rs_from.smiles AS from_smiles, rs_to.smiles AS to_smiles,"
        " res.count, res.avg, res.std, res.median, re.radius "
        "FROM rule_environment_statistics res "
        "JOIN rule_environment re ON re.id = res.rule_environment_id "
        "JOIN rule r ON r.id = re.rule_id "
        "JOIN rule_smiles rs_from ON rs_from.id = r.from_smiles_id "
        "JOIN rule_smiles rs_to ON rs_to.id = r.to_smiles_id "
        "JOIN property_name pn ON pn.id = res.property_name_id "
        "WHERE pn.name = ? AND res.count >= ?"
    )
    rows = c.execute(sql, (property_name, min_pairs)).fetchall()
    out = [{
        "from_smiles": r[0], "to_smiles": r[1], "n_pairs": r[2],
        "delta_mean": round(r[3], 4), "delta_std": round(r[4], 4) if r[4] is not None else None,
        "delta_median": round(r[5], 4), "radius": r[6],
    } for r in rows]
    if single_cut_only:
        out = [r for r in out
               if r["from_smiles"].count("[*") == 1 and r["to_smiles"].count("[*") == 1]
    if direction == "increase":
        out = [r for r in out if r["delta_mean"] > 0]
        out.sort(key=lambda r: -r["delta_mean"])
    elif direction == "decrease":
        out = [r for r in out if r["delta_mean"] < 0]
        out.sort(key=lambda r: r["delta_mean"])
    else:
        out.sort(key=lambda r: -abs(r["delta_mean"]))
    return out[:top_n]


@mcp.tool()
def mmpdb_rule_distribution(mmpdb_path: str, property_name: str,
                            min_pairs: int = 3,
                            single_cut_only: bool = False) -> dict:
    """Summary statistics over the distribution of per-rule mean Δproperty
    (after filtering on min_pairs). Useful for determining whether the
    property is well predicted by MMP transformations or noisy.

    Args:
        property_name: e.g. "CYP3A4_pIC50"
        min_pairs: only include rule_environment_statistics rows with count >= this.
        single_cut_only: if True, restrict to single-cut rules (rule_smiles with
            exactly one [*] attachment point on both sides).
    """
    import statistics
    c = sqlite3.connect(mmpdb_path)
    if single_cut_only:
        sql = (
            "SELECT res.avg FROM rule_environment_statistics res "
            "JOIN rule_environment re ON re.id = res.rule_environment_id "
            "JOIN rule r ON r.id = re.rule_id "
            "JOIN rule_smiles rs_from ON rs_from.id = r.from_smiles_id "
            "JOIN rule_smiles rs_to ON rs_to.id = r.to_smiles_id "
            "JOIN property_name pn ON pn.id = res.property_name_id "
            "WHERE pn.name = ? AND res.count >= ? "
            "AND (LENGTH(rs_from.smiles) - LENGTH(REPLACE(rs_from.smiles, '[*', ''))) = 2 "
            "AND (LENGTH(rs_to.smiles) - LENGTH(REPLACE(rs_to.smiles, '[*', ''))) = 2"
        )
    else:
        sql = (
            "SELECT res.avg FROM rule_environment_statistics res "
            "JOIN property_name pn ON pn.id = res.property_name_id "
            "WHERE pn.name = ? AND res.count >= ?"
        )
    vals = [r[0] for r in c.execute(sql, (property_name, min_pairs))]
    if not vals:
        return {"n_rules": 0}
    pos = sum(1 for v in vals if v > 0)
    neg = sum(1 for v in vals if v < 0)
    return {
        "n_rules": len(vals),
        "mean": round(statistics.mean(vals), 4),
        "std": round(statistics.pstdev(vals), 4),
        "min": round(min(vals), 4),
        "q1": round(statistics.quantiles(vals, n=4)[0], 4) if len(vals) >= 4 else None,
        "median": round(statistics.median(vals), 4),
        "q3": round(statistics.quantiles(vals, n=4)[2], 4) if len(vals) >= 4 else None,
        "max": round(max(vals), 4),
        "n_increase": pos,
        "n_decrease": neg,
    }


# ----------------------------------------------------------- 4. Plotting -----

@mcp.tool()
def plot_rule_delta_histograms(mmpdb_path: str, property_names: list[str],
                               output_png: str, min_pairs: int = 3) -> str:
    """Plot side-by-side histograms of per-rule Δproperty for each named
    property in the database. Returns absolute path to the saved PNG.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    c = sqlite3.connect(mmpdb_path)
    fig, axes = plt.subplots(1, len(property_names), figsize=(5 * len(property_names), 4))
    if len(property_names) == 1:
        axes = [axes]
    colors = ["#3b7dd8", "#d8693b", "#3bd87d", "#d83b9a"]
    for i, prop in enumerate(property_names):
        sql = (
            "SELECT res.avg FROM rule_environment_statistics res "
            "JOIN property_name pn ON pn.id = res.property_name_id "
            "WHERE pn.name = ? AND res.count >= ?"
        )
        vals = [r[0] for r in c.execute(sql, (prop, min_pairs))]
        ax = axes[i]
        ax.hist(vals, bins=40, color=colors[i % len(colors)],
                edgecolor="black", alpha=0.85)
        ax.axvline(0, ls="--", color="red")
        ax.set_xlabel(rf"$\Delta$ {prop}")
        ax.set_ylabel("Number of MMP rules")
        ax.set_title(f"{prop} (n={len(vals)} rules)")
    plt.tight_layout()
    os.makedirs(os.path.dirname(os.path.abspath(output_png)) or ".", exist_ok=True)
    plt.savefig(output_png, dpi=130)
    plt.close(fig)
    return os.path.abspath(output_png)


@mcp.tool()
def plot_pair_delta_scatter(mmpdb_path: str, property_x: str,
                            property_y: str, output_png: str,
                            min_pairs: int = 5) -> str:
    """For rules with statistics on both properties (e.g. CYP3A4 and hERG),
    plot Δprop_x vs Δprop_y to spot rules that selectively improve one
    property without hurting the other. Returns absolute path.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    c = sqlite3.connect(mmpdb_path)
    sql = (
        "SELECT re.id, pn.name, res.avg, res.count "
        "FROM rule_environment_statistics res "
        "JOIN rule_environment re ON re.id = res.rule_environment_id "
        "JOIN property_name pn ON pn.id = res.property_name_id "
        "WHERE pn.name IN (?, ?) AND res.count >= ?"
    )
    by_re: dict[int, dict[str, float]] = {}
    for re_id, name, avg, cnt in c.execute(sql, (property_x, property_y, min_pairs)):
        by_re.setdefault(re_id, {})[name] = avg
    xs, ys = [], []
    for d in by_re.values():
        if property_x in d and property_y in d:
            xs.append(d[property_x])
            ys.append(d[property_y])
    fig, ax = plt.subplots(figsize=(6, 6))
    ax.scatter(xs, ys, s=18, alpha=0.7, color="#3b7dd8", edgecolor="black",
               linewidth=0.4)
    ax.axhline(0, ls="--", color="grey", lw=0.8)
    ax.axvline(0, ls="--", color="grey", lw=0.8)
    ax.set_xlabel(rf"$\Delta$ {property_x}")
    ax.set_ylabel(rf"$\Delta$ {property_y}")
    ax.set_title(f"Per-rule property co-change (n={len(xs)})")
    plt.tight_layout()
    os.makedirs(os.path.dirname(os.path.abspath(output_png)) or ".", exist_ok=True)
    plt.savefig(output_png, dpi=130)
    plt.close(fig)
    return os.path.abspath(output_png)


if __name__ == "__main__":
    mcp.run()

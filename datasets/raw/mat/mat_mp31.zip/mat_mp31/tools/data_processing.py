"""Generic data-processing utilities for tabular and chemistry text formats.

Generic format conversion, parsing, and lightweight reshaping. Domain
specific MMP / fragmentation / SAR primitives live in mmpdb_tools.py.
"""
from typing import Any
import csv
import json
import os
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("data_processing")


@mcp.tool()
def read_csv(path: str, delimiter: str = ",") -> list[dict]:
    """Parse a CSV/TSV file into list-of-dicts.

    Args:
        path: file path
        delimiter: column delimiter (default ',', use '\t' for TSV)
    """
    with open(path, newline="") as f:
        return list(csv.DictReader(f, delimiter=delimiter))


@mcp.tool()
def write_csv(rows: list[dict], path: str, delimiter: str = ",") -> str:
    """Write list-of-dicts to CSV using the first row's keys as header.

    Returns absolute path of the written file.
    """
    if not rows:
        open(path, "w").close()
        return os.path.abspath(path)
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()), delimiter=delimiter)
        w.writeheader()
        w.writerows(rows)
    return os.path.abspath(path)


@mcp.tool()
def read_smi(path: str) -> list[dict]:
    """Read a whitespace-delimited SMILES file. Each line: '<SMILES>\\t<id>'.

    Returns list of dicts: [{smiles, id}, ...] skipping blank lines.
    """
    out = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split(None, 1)
            if len(parts) == 2:
                out.append({"smiles": parts[0], "id": parts[1]})
            elif len(parts) == 1:
                out.append({"smiles": parts[0], "id": ""})
    return out


@mcp.tool()
def write_smi(records: list[dict], path: str) -> str:
    """Write list-of-{smiles, id} dicts to a whitespace-delimited SMILES file."""
    with open(path, "w") as f:
        for r in records:
            sm = r.get("smiles", "")
            mid = r.get("id", "")
            f.write(f"{sm}\t{mid}\n")
    return os.path.abspath(path)


@mcp.tool()
def read_json(path: str) -> Any:
    """Read JSON from path."""
    with open(path) as f:
        return json.load(f)


@mcp.tool()
def write_json(obj: Any, path: str, indent: int = 2) -> str:
    """Write a JSON-serialisable object to path. Returns absolute path."""
    with open(path, "w") as f:
        json.dump(obj, f, indent=indent, default=str)
    return os.path.abspath(path)


@mcp.tool()
def filter_rows(rows: list[dict], column: str, op: str, value: float) -> list[dict]:
    """Filter list-of-dicts by a numeric comparison.

    op in {'>', '>=', '<', '<=', '==', '!='}. Non-numeric or missing rows
    are dropped (no error).
    """
    ops = {
        ">": lambda a, b: a > b,
        ">=": lambda a, b: a >= b,
        "<": lambda a, b: a < b,
        "<=": lambda a, b: a <= b,
        "==": lambda a, b: a == b,
        "!=": lambda a, b: a != b,
    }
    if op not in ops:
        raise ValueError(f"unknown op: {op}")
    f = ops[op]
    out = []
    for r in rows:
        try:
            v = float(r[column])
        except (KeyError, ValueError, TypeError):
            continue
        if f(v, value):
            out.append(r)
    return out


@mcp.tool()
def groupby_aggregate(rows: list[dict], by: str, value_col: str) -> list[dict]:
    """Group rows by `by` and compute count/mean/std/median of value_col."""
    import statistics
    g: dict[str, list[float]] = {}
    for r in rows:
        try:
            v = float(r[value_col])
        except (KeyError, ValueError, TypeError):
            continue
        g.setdefault(r[by], []).append(v)
    out = []
    for k, vs in g.items():
        out.append({
            "group": k,
            "count": len(vs),
            "mean": round(sum(vs) / len(vs), 4),
            "std": round(statistics.pstdev(vs), 4) if len(vs) >= 2 else 0.0,
            "median": round(statistics.median(vs), 4),
        })
    return out


@mcp.tool()
def join_tables(left: list[dict], right: list[dict], on: str) -> list[dict]:
    """Inner join two list-of-dicts on a shared key."""
    idx: dict[str, dict] = {}
    for r in right:
        if on in r:
            idx[r[on]] = r
    out = []
    for l in left:
        if l.get(on) in idx:
            merged = dict(l)
            for k, v in idx[l[on]].items():
                if k != on:
                    merged[k] = v
            out.append(merged)
    return out


if __name__ == "__main__":
    mcp.run()

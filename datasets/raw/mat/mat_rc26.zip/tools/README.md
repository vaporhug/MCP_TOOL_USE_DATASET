# mat_rc26 — Tool Reference

Only `rxn_condition_tools.py` is a real FastMCP server; the other two
files are import-only utility modules. None embeds the domain answer;
they are reusable building blocks an agent must compose.

> **IMPORTANT — `database_retrieval.py` and `data_processing.py` are
> generic placeholder utility modules and are NOT required to solve
> this task.** Every primitive the task actually needs (reaction-SMILES
> parsing, Morgan / reaction fingerprints, label-distribution loader,
> multi-task DNN, baselines, evaluation, plotting) lives in
> `rxn_condition_tools.py`. Solvers can safely ignore the two
> placeholder modules; they are bundled only so the directory layout
> matches the dataset convention used by the rest of the benchmark.

## Database Retrieval (`database_retrieval.py`) — import-only PLACEHOLDER, not required

Generic external-database stubs (websearch, fetch_url, query_pubchem,
query_chembl, query_doi, query_openalex, ...). Heavyweight network
implementations are filled in at runtime as needed. **Not a standalone
MCP server, and not used by the mat_rc26 reference pipeline**: plain
Python helpers meant to be imported, not run as
`python tools/database_retrieval.py`.

## Data Processing (`data_processing.py`) — import-only PLACEHOLDER, not required

Generic format-conversion utilities (read_csv / write_csv, read_json,
read_excel / read_parquet / read_netcdf / read_shapefile / read_fasta,
pivot_long_to_wide / pivot_wide_to_long, drop_missing, coerce_numeric,
join_tables, groupby_aggregate). **Not a standalone MCP server, and
not used by the mat_rc26 reference pipeline**: plain Python helpers
meant to be imported, not run as `python tools/data_processing.py`.

## Domain-Specific Reaction-Condition Tools (`rxn_condition_tools.py`) — MCP server

Reaction-SMILES and ML primitives, all runnable. This is the only file
in this bundle that runs as a `stdio` MCP server. None of these tools
hard-codes the paper's specific architecture sizes, label cardinalities,
fingerprint length, or operating threshold — the agent must derive those
from the bundled CSVs and the reference paper.

### Parsing & fingerprints
- **parse_reaction_smiles**: Split `reactants[>reagents]>products` SMILES
  into canonical components; report heavy-atom counts.
- **morgan_fingerprint**: ECFP-style Morgan circular fingerprint for a
  single molecule. `radius` and `n_bits` are agent-supplied (the 1024
  default is a generic library default, not a paper-specific choice).
- **reaction_fingerprint**: Concatenated reaction fingerprint
  `[product_FP || (product_FP - reactant_FP)]` of total length
  `2 * n_bits`. `n_bits` is agent-supplied. Use this to encode the two
  bundled example reactions (paper_examples.txt) into the input feature
  vector consumed by the multi-task DNN.

### Label-distribution analysis
- **load_label_distribution**: Load a solvent/reagent label-frequency
  CSV; return n_classes, totals, top-k labels with counts and shares,
  head/tail fractions, nan_count.

### Multi-task DNN
- **build_multitask_dnn_architecture**: Instantiate a multi-task
  feedforward network with a shared trunk and two parallel sigmoid heads
  (reagent + solvent). All sizes (in_dim, share_dim, reag_dim, solv_dim,
  n_reagent, n_solvent) are agent-supplied.
- **train_multitask_dnn**: Train with focal loss + homoscedastic-
  uncertainty multi-task weighting. Inputs are dense feature lists and
  multi-hot label lists. Returns model_id and per-epoch loss history.
- **predict_multitask_dnn**: Sigmoid probability prediction for both
  heads given a saved model_id.

### Baselines
- **train_rf_baseline**: Random Forest multi-label classifier baseline.
- **predict_rf**: Predict per-class probabilities from an RF model.

### Evaluation
- **topk_accuracy**: Top-k exact-match accuracy with multi-label ground
  truth (a sample is correct at k if any true label appears in the top-k).
- **threshold_metrics**: Multi-label hamming loss + example-based
  precision / recall / F1 at a probability threshold (agent supplies the
  operating threshold).
- **temperature_mae**: MAE, RMSE, and `within_<X>C` tolerance accuracies
  for the temperature regression head.
- **hard_negative_indices**: Identify hard negatives (probability
  >= threshold but absent from ground truth) for ranking augmentation.
- **enumerate_combinations**: All (solvent-set, reagent-set) tuples
  subject to agent-supplied cardinality limits.

### Plotting
All plotting tools save to a path you supply and return the path.
- **plot_label_distribution**: Top-k bar chart of solvent or reagent
  reaction counts.
- **plot_topk_curve**: Top-k accuracy curve (annotated points).
- **plot_temperature_scatter**: Predicted-vs-true temperature scatter
  with +/-X C tolerance bands.
- **plot_ranked_predictions**: Bar plot of probability-ranked candidate
  reaction-condition contexts from a recommender output CSV.

## Dependencies
`numpy`, `pandas`, `rdkit`, `torch`, `scikit-learn`, `matplotlib`,
`mcp[server]` (FastMCP). All available in the standard cheminformatics
Python stack.

## Running the MCP server
```
python tools/rxn_condition_tools.py
```
Only `rxn_condition_tools.py` starts a `stdio` MCP server. The other
two files (`data_processing.py`, `database_retrieval.py`) are import-only
Python utility modules and must not be run directly.

## Bundled `artifacts/` are AGENT-GENERATED reference outputs

The five PNGs and the JSON file under `artifacts/`
(`Fig1_solvent_label_dist.png`, `Fig2_reagent_label_dist.png`,
`Fig3_topk_accuracy.png`, `Fig4_aza_diels_alder_ranking.png`,
`Fig5_friedel_crafts_ranking.png`, `example_reaction_fingerprints.json`)
are the *expected* outputs that a solver must reproduce by running the
pipeline described in `task_content/task_content.json` (label-frequency
analysis, reaction-fingerprint encoding, multi-task DNN training,
top-k evaluation, and per-example ranking plots). They are shipped in
the zip as reference targets for the grader and are not raw inputs.
The grader will compare a solver-produced figure at the same path
against these reference files. Solvers should treat the `artifacts/`
contents as the answer they need to recreate, not as fixed assets to
load.

## Note on `input_data/data/reagent_labels.csv`

The reagent vocabulary (1320 entries) is reproduced verbatim from the
Reaxys reagent dictionary used by Chen & Li 2024. Some long entries
contain Reaxys idiosyncrasies: question marks instead of primes in
biphenyl ligand names (`2?,6?-diisopropoxy-1,1?-biphenyl`), composite
salt notations using `*` and `(1+)/(1-)` (`2Na(1+)*CuC6H4(...)`), and
non-canonical IUPAC ordering. These are real reagent names as exported
from Reaxys and are kept verbatim so that the bundled solvent/reagent
frequency totals (87 solvents, 1320 reagents) match the paper. The
solver does not need to canonicalise these strings — they are used as
opaque class labels by the multi-task DNN heads.

# mat_rc26 — Tool Reference

Three FastMCP servers expose low-level primitives. None embeds the
domain answer; they are reusable building blocks an agent must compose.

## Database Retrieval (`database_retrieval.py`)

Generic external-database stubs (websearch, fetch_url, query_pubchem,
query_chembl, query_doi, query_openalex, ...). Heavyweight network
implementations are filled in at runtime as needed.

## Data Processing (`data_processing.py`)

Generic format-conversion utilities (read_csv / write_csv, read_json,
read_excel / read_parquet / read_netcdf / read_shapefile / read_fasta,
pivot_long_to_wide / pivot_wide_to_long, drop_missing, coerce_numeric,
join_tables, groupby_aggregate).

## Domain-Specific Reaction-Condition Tools (`rxn_condition_tools.py`)

Reaction-SMILES and ML primitives, all runnable.

### Parsing & fingerprints
- **parse_reaction_smiles**: Split `reactants[>reagents]>products` SMILES
  into canonical components; report heavy-atom counts.
- **morgan_fingerprint**: ECFP-style Morgan circular fingerprint for a
  single molecule (radius, n_bits configurable; defaults match paper:
  radius=2, n_bits=4096).
- **reaction_fingerprint**: 2*n_bits reaction fingerprint =
  `[product_FP || (product_FP - reactant_FP)]` (paper's canonical
  encoding; default total length 8192).

### Label-distribution analysis
- **load_label_distribution**: Load a solvent/reagent label-frequency
  CSV; return n_classes, totals, top-k labels with counts and shares,
  head/tail fractions, nan_count.

### Multi-task DNN
- **build_multitask_dnn_architecture**: Instantiate the paper's
  candidate-generation network (shared 1024 ReLU + 300-unit reagent
  head + 100-unit solvent head, sigmoid heads on n_reagent and
  n_solvent). Returns parameter counts and layer summary.
- **train_multitask_dnn**: Train with focal loss + homoscedastic-
  uncertainty multi-task weighting. Inputs are dense feature lists and
  multi-hot label lists. Returns model_id and per-epoch loss history.
- **predict_multitask_dnn**: Sigmoid probability prediction for both
  heads given a saved model_id.

### Baselines
- **train_rf_baseline**: Random Forest multi-label classifier baseline.
- **predict_rf**: Predict per-class probabilities from an RF model.

### Evaluation
- **topk_accuracy**: Top-k exact-match accuracy with multi-label ground
  truth (a sample is correct at k if any true label appears in the top-k).
- **threshold_metrics**: Multi-label hamming loss + example-based
  precision / recall / F1 at a probability threshold (paper Eq. 5-8).
- **temperature_mae**: MAE, RMSE, and `within_<X>°C` tolerance accuracies
  for the temperature regression head.
- **hard_negative_indices**: Identify hard negatives (probability
  ≥ threshold but absent from ground truth) for ranking augmentation.
- **enumerate_combinations**: All (solvent-set, reagent-set) tuples
  subject to cardinality limits (paper: ≤2 solvents, ≤3 reagents).

### Plotting
All plotting tools save to a path you supply and return the path.
- **plot_label_distribution**: Top-k bar chart of solvent or reagent
  reaction counts.
- **plot_topk_curve**: Top-k accuracy curve (annotated points).
- **plot_temperature_scatter**: Predicted-vs-true temperature scatter
  with ±X °C tolerance bands.
- **plot_ranked_predictions**: Bar plot of probability-ranked candidate
  reaction-condition contexts from a recommender output CSV.

## Dependencies
`numpy`, `pandas`, `rdkit`, `torch`, `scikit-learn`, `matplotlib`,
`mcp[server]` (FastMCP). All available in the standard cheminformatics
Python stack.

## Running each server
```
python tools/rxn_condition_tools.py
python tools/data_processing.py
python tools/database_retrieval.py
```
Each starts a `stdio` MCP server.

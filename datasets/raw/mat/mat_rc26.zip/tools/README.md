# mat_rc26 — Tool Reference

Only `rxn_condition_tools.py` is a real FastMCP server; the other two
files are import-only utility modules. None embeds the domain answer;
they are reusable building blocks an agent must compose.

## Database Retrieval (`database_retrieval.py`) — import-only utility module

Generic external-database stubs (websearch, fetch_url, query_pubchem,
query_chembl, query_doi, query_openalex, ...). Heavyweight network
implementations are filled in at runtime as needed. **Not a standalone
MCP server**: plain Python helpers meant to be imported, not run as
`python tools/database_retrieval.py`.

## Data Processing (`data_processing.py`) — import-only utility module

Generic format-conversion utilities (read_csv / write_csv, read_json,
read_excel / read_parquet / read_netcdf / read_shapefile / read_fasta,
pivot_long_to_wide / pivot_wide_to_long, drop_missing, coerce_numeric,
join_tables, groupby_aggregate). **Not a standalone MCP server**: plain
Python helpers meant to be imported, not run as `python tools/data_processing.py`.

## Domain-Specific Reaction-Condition Tools (`rxn_condition_tools.py`) — MCP server

Reaction-SMILES and ML primitives, all runnable. This is the only file
in this bundle that runs as a `stdio` MCP server. None of these tools
hard-codes the paper's specific architecture sizes, label cardinalities,
fingerprint length, or operating threshold — the agent must derive those
from the bundled CSVs and the reference paper.

### Parsing & fingerprints
- **parse_reaction_smiles**: Split `reactants[>reagents]>products` SMILES
  into canonical components; report heavy-atom counts.
- **morgan_fingerprint**: ECFP-style Morgan circular fingerprint for a
  single molecule. `radius` and `n_bits` are agent-supplied (the 1024
  default is a generic library default, not a paper-specific choice).
- **reaction_fingerprint**: Concatenated reaction fingerprint
  `[product_FP || (product_FP - reactant_FP)]` of total length
  `2 * n_bits`. `n_bits` is agent-supplied. Use this to encode the two
  bundled example reactions (paper_examples.txt) into the input feature
  vector consumed by the multi-task DNN.

### Label-distribution analysis
- **load_label_distribution**: Load a solvent/reagent label-frequency
  CSV; return n_classes, totals, top-k labels with counts and shares,
  head/tail fractions, nan_count.

### Multi-task DNN
- **build_multitask_dnn_architecture**: Instantiate a multi-task
  feedforward network with a shared trunk and two parallel sigmoid heads
  (reagent + solvent). All sizes (in_dim, share_dim, reag_dim, solv_dim,
  n_reagent, n_solvent) are agent-supplied.
- **train_multitask_dnn**: Train with focal loss + homoscedastic-
  uncertainty multi-task weighting. Inputs are dense feature lists and
  multi-hot label lists. Returns model_id and per-epoch loss history.
- **predict_multitask_dnn**: Sigmoid probability prediction for both
  heads given a saved model_id.

### Baselines
- **train_rf_baseline**: Random Forest multi-label classifier baseline.
- **predict_rf**: Predict per-class probabilities from an RF model.

### Evaluation
- **topk_accuracy**: Top-k exact-match accuracy with multi-label ground
  truth (a sample is correct at k if any true label appears in the top-k).
- **threshold_metrics**: Multi-label hamming loss + example-based
  precision / recall / F1 at a probability threshold (agent supplies the
  operating threshold).
- **temperature_mae**: MAE, RMSE, and `within_<X>C` tolerance accuracies
  for the temperature regression head.
- **hard_negative_indices**: Identify hard negatives (probability
  >= threshold but absent from ground truth) for ranking augmentation.
- **enumerate_combinations**: All (solvent-set, reagent-set) tuples
  subject to agent-supplied cardinality limits.

### Plotting
All plotting tools save to a path you supply and return the path.
- **plot_label_distribution**: Top-k bar chart of solvent or reagent
  reaction counts.
- **plot_topk_curve**: Top-k accuracy curve (annotated points).
- **plot_temperature_scatter**: Predicted-vs-true temperature scatter
  with +/-X C tolerance bands.
- **plot_ranked_predictions**: Bar plot of probability-ranked candidate
  reaction-condition contexts from a recommender output CSV.

## Dependencies
`numpy`, `pandas`, `rdkit`, `torch`, `scikit-learn`, `matplotlib`,
`mcp[server]` (FastMCP). All available in the standard cheminformatics
Python stack.

## Running the MCP server
```
python tools/rxn_condition_tools.py
```
Only `rxn_condition_tools.py` starts a `stdio` MCP server. The other
two files (`data_processing.py`, `database_retrieval.py`) are import-only
Python utility modules and must not be run directly.

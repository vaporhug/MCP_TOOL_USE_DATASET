# mat_rc26 — Tool Reference

This bundle contains three Python modules under `tools/`. Only
`rxn_condition_tools.py` runs as a FastMCP `stdio` server; the other two
files are import-only utility modules. None of the tools hard-codes
domain answers — each is a reusable building block an agent composes
into a pipeline.

> **NOTE — `database_retrieval.py` and `data_processing.py` are generic
> placeholder utility modules and are NOT required to solve this task.**
> Every primitive the task needs (reaction-SMILES parsing, Morgan and
> reaction fingerprints, label-distribution loader, multi-task DNN,
> baselines, evaluation, plotting) lives in `rxn_condition_tools.py`.
> Solvers can safely ignore the two placeholder modules; they are
> bundled only so the directory layout matches the dataset convention
> used by the rest of the benchmark.

## Database Retrieval (`database_retrieval.py`) — import-only, not required

Generic external-database stubs (websearch, fetch_url, query_pubchem,
query_chembl, query_doi, query_openalex, ...). Heavyweight network
implementations are filled in at runtime as needed. **Not a standalone
MCP server, and not used by the mat_rc26 reference pipeline**: plain
Python helpers meant to be imported, not run as
`python tools/database_retrieval.py`.

## Data Processing (`data_processing.py`) — import-only, not required

Generic format-conversion utilities (read_csv / write_csv, read_json,
read_excel / read_parquet / read_netcdf / read_shapefile / read_fasta,
pivot_long_to_wide / pivot_wide_to_long, drop_missing, coerce_numeric,
join_tables, groupby_aggregate). **Not a standalone MCP server, and
not used by the mat_rc26 reference pipeline**: plain Python helpers
meant to be imported, not run as `python tools/data_processing.py`.

## Domain-Specific Reaction-Condition Tools (`rxn_condition_tools.py`) — MCP server

Reaction-SMILES and ML primitives, all runnable. This is the only file
in this bundle that runs as a `stdio` MCP server. None of these tools
hard-codes a specific architecture size, label cardinality, fingerprint
length, or operating threshold — every numeric hyperparameter is
agent-supplied.

### Parsing & fingerprints
- **parse_reaction_smiles**: Split a reaction SMILES of the form
  `reactants>reagents>products` (the canonical RDKit form with two `>`
  separators; an optional reagents block sits between the two `>`
  characters and may be empty, giving the abbreviated form
  `reactants>>products`). Returns canonical components and reports
  heavy-atom counts.
- **morgan_fingerprint**: ECFP-style Morgan circular fingerprint for a
  single molecule. `radius` and `n_bits` are agent-supplied.
- **reaction_fingerprint**: Concatenated reaction fingerprint
  `[product_FP || (product_FP - reactant_FP)]` of total length
  `2 * n_bits`. `n_bits` is agent-supplied. Use this to encode reaction
  SMILES into a dense feature vector consumable by a downstream model.

### Label-distribution analysis
- **load_label_distribution**: Load a label-frequency CSV; return
  n_classes, totals, top-k labels with counts and shares, head/tail
  fractions, nan_count.

### Multi-task DNN
- **build_multitask_dnn_architecture**: Instantiate a multi-task
  feedforward network with a shared trunk and two parallel sigmoid
  heads. All sizes (in_dim, share_dim, head1_dim, head2_dim,
  n_head1_classes, n_head2_classes) are agent-supplied.
- **train_multitask_dnn**: Train with focal loss + homoscedastic
  uncertainty multi-task weighting. Inputs are dense feature lists and
  multi-hot label lists. Returns model_id and per-epoch loss history.
- **predict_multitask_dnn**: Sigmoid probability prediction for both
  heads given a saved model_id.

### Baselines
- **train_rf_baseline**: Random Forest multi-label classifier baseline.
- **predict_rf**: Predict per-class probabilities from an RF model.

### Evaluation
- **topk_accuracy**: Top-k exact-match accuracy with multi-label ground
  truth (a sample is correct at k if any true label appears in the
  top-k).
- **threshold_metrics**: Multi-label hamming loss + example-based
  precision / recall / F1 at a probability threshold (agent supplies the
  operating threshold).
- **temperature_mae**: MAE, RMSE, and `within_<X>C` tolerance
  accuracies for a temperature regression head.
- **hard_negative_indices**: Identify hard negatives (probability
  >= threshold but absent from ground truth) for ranking augmentation.
- **enumerate_combinations**: All (set_A, set_B) tuples subject to
  agent-supplied cardinality limits.

### Plotting
All plotting tools save to a path you supply and return the path.
- **plot_label_distribution**: Top-k bar chart of label frequencies.
- **plot_topk_curve**: Top-k accuracy curve (annotated points).
- **plot_temperature_scatter**: Predicted-vs-true temperature scatter
  with +/- X C tolerance bands.
- **plot_ranked_predictions**: Bar plot of probability-ranked candidate
  rows from a recommender output CSV.

## Dependencies
`numpy`, `pandas`, `rdkit`, `torch`, `scikit-learn`, `matplotlib`,
`mcp[server]` (FastMCP). All available in the standard cheminformatics
Python stack.

## Running the MCP server
```
python tools/rxn_condition_tools.py
```
Only `rxn_condition_tools.py` starts a `stdio` MCP server. The other
two files (`data_processing.py`, `database_retrieval.py`) are
import-only Python utility modules and must not be run directly.

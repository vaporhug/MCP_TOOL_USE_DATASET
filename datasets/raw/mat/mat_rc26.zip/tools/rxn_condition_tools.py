#!/usr/bin/env python3
"""Domain-specific tools for reaction-condition prediction.

Low-level primitives for: reaction SMILES parsing, Morgan-fingerprint
computation, multi-task DNN training/evaluation, top-k accuracy, label
distribution analysis, and figure generation. These are runnable building
blocks (no `pass`) that an agent can compose to reproduce a two-stage DNN
reaction-condition recommender.
"""

import os
import json
import pickle
import hashlib
import numpy as np
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("RxnConditionTools")

_MODEL_DIR = "/tmp/mat_rc26_models"
os.makedirs(_MODEL_DIR, exist_ok=True)


# ----------------------------------------------------------------------
# Reaction SMILES parsing & fingerprint primitives
# ----------------------------------------------------------------------

@mcp.tool()
def parse_reaction_smiles(rxn_smiles: str) -> dict:
    """Split a reaction SMILES into reactants / reagents / products.

    The canonical RDKit reaction-SMILES form is::

        reactants > reagents > products

    i.e. exactly TWO '>' characters with an optional reagents block in
    between. When the reagents block is empty the two '>' sit next to
    each other, giving the common abbreviated form::

        reactants >> products

    which still contains two '>' characters (this function accepts
    both). A trailing or leading whitespace is stripped before parsing.

    Args:
        rxn_smiles: reaction SMILES containing exactly two '>'
            characters (the standard '>>' or 'reactants>reagents>products'
            forms).

    Returns:
        dict with reactants (list of canonical SMILES), reagents (list),
        products (list), n_reactant_atoms, n_product_atoms.
    """
    from rdkit import Chem

    parts = rxn_smiles.strip().split(">")
    if len(parts) == 2:
        # Legacy single-'>' form: treat as reactants > products with no reagents.
        react_str, reag_str, prod_str = parts[0], "", parts[1]
    elif len(parts) == 3:
        # Standard RDKit form 'reactants>reagents>products' (reagents may be empty).
        react_str, reag_str, prod_str = parts
    else:
        return {"error": f"reaction SMILES must contain exactly two '>' characters (standard 'reactants>reagents>products' or abbreviated 'reactants>>products'); got {len(parts)-1} '>' separator(s)."}

    def canon(smi_block):
        out = []
        for s in smi_block.split("."):
            s = s.strip()
            if not s:
                continue
            mol = Chem.MolFromSmiles(s)
            if mol is None:
                out.append(s)
            else:
                out.append(Chem.MolToSmiles(mol))
        return out

    reactants = canon(react_str)
    reagents = canon(reag_str) if reag_str else []
    products = canon(prod_str)

    def atom_count(smi_list):
        n = 0
        for s in smi_list:
            m = Chem.MolFromSmiles(s)
            if m is not None:
                n += m.GetNumHeavyAtoms()
        return n

    return {
        "reactants": reactants,
        "reagents": reagents,
        "products": products,
        "n_reactant_atoms": atom_count(reactants),
        "n_product_atoms": atom_count(products),
    }


@mcp.tool()
def morgan_fingerprint(smiles: str, radius: int = 2, n_bits: int = 1024) -> dict:
    """Morgan circular fingerprint for a single SMILES molecule.

    Args:
        smiles: molecule SMILES string
        radius: ECFP radius (2 corresponds to ECFP4-equivalent diameter)
        n_bits: fingerprint length the agent chooses; must be supplied
            explicitly when the per-fingerprint length is part of the
            graded answer. The 1024 default is a generic library default,
            NOT the paper's per-fingerprint length, which the agent must
            read out of the paper themselves.

    Returns:
        dict with bits (list of int 0/1, length n_bits), n_set_bits,
        radius, n_bits.
    """
    from rdkit import Chem
    from rdkit.Chem import AllChem

    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return {"error": f"invalid SMILES: {smiles}"}
    fp = AllChem.GetMorganFingerprintAsBitVect(mol, radius, n_bits)
    bits = list(fp)
    return {
        "bits": bits,
        "n_set_bits": int(sum(bits)),
        "radius": radius,
        "n_bits": n_bits,
    }


@mcp.tool()
def reaction_fingerprint(rxn_smiles: str, radius: int = 2, n_bits: int = 1024) -> dict:
    """Concatenated reaction fingerprint built from a reaction SMILES.

    Concatenates [product_FP || (product_FP - reactant_FP)] giving an
    output of length 2 * n_bits. The first block captures the product,
    the second the reactant->product disparity. The agent must supply
    the per-fingerprint length n_bits that matches the reaction-condition
    recommender being reproduced (the default 1024 is a generic library
    default and is NOT necessarily the paper's choice).

    Args:
        rxn_smiles: 'reactants>>products' or 'reactants>reagents>products'
        radius: ECFP radius
        n_bits: per-component fingerprint length (agent-supplied)

    Returns:
        dict with rxn_fp (list of int, length 2*n_bits), product_fp,
        diff_fp, fp_length, radius, n_bits.
    """
    from rdkit import Chem
    from rdkit.Chem import AllChem

    parts = rxn_smiles.strip().split(">")
    if len(parts) == 2:
        react_str, prod_str = parts
    elif len(parts) == 3:
        react_str, _reag, prod_str = parts
    else:
        return {"error": "reaction SMILES needs one or two '>' separators"}

    def block_fp(smi_block):
        arr = np.zeros(n_bits, dtype=np.int32)
        for s in smi_block.split("."):
            s = s.strip()
            if not s:
                continue
            mol = Chem.MolFromSmiles(s)
            if mol is None:
                continue
            fp = AllChem.GetMorganFingerprintAsBitVect(mol, radius, n_bits)
            arr += np.array(fp, dtype=np.int32)
        return arr

    react_fp = block_fp(react_str)
    prod_fp = block_fp(prod_str)
    diff_fp = prod_fp - react_fp  # signed reactant->product disparity
    rxn_fp = np.concatenate([prod_fp, diff_fp]).astype(np.int32)

    return {
        "rxn_fp": rxn_fp.tolist(),
        "product_fp": prod_fp.tolist(),
        "diff_fp": diff_fp.tolist(),
        "fp_length": int(len(rxn_fp)),
        "radius": radius,
        "n_bits": n_bits,
    }


# ----------------------------------------------------------------------
# Label distribution analysis
# ----------------------------------------------------------------------

@mcp.tool()
def load_label_distribution(csv_path: str, top_k: int = 10) -> dict:
    """Load a solvent/reagent label-frequency CSV and return distribution stats.

    The CSV must have columns 'name' and 'value' (label name and reaction
    count). Empty/'nan' rows are kept and surfaced explicitly so downstream
    callers can decide how to treat the missing-condition class.

    Args:
        csv_path: path to label-frequency CSV
        top_k: number of top labels to return

    Returns:
        dict with n_classes, total_count, top_labels, head_share (top-10
        cumulative fraction), tail_share (long-tail fraction), nan_count.
    """
    import pandas as pd
    df = pd.read_csv(csv_path, index_col=0)
    df = df.fillna({"name": "nan"})
    n = len(df)
    total = int(df["value"].sum())
    df_sorted = df.sort_values("value", ascending=False).reset_index(drop=True)
    top = df_sorted.head(top_k)
    head_total = int(top["value"].sum())
    nan_count = int(df_sorted[df_sorted["name"].astype(str).str.lower() == "nan"]["value"].sum())
    return {
        "n_classes": n,
        "total_count": total,
        "top_labels": [
            {"rank": i + 1, "name": str(r["name"]), "count": int(r["value"]),
             "fraction": round(float(r["value"]) / total, 6)}
            for i, r in top.iterrows()
        ],
        "head_share_top_k": round(head_total / total, 4),
        "tail_share": round((total - head_total) / total, 4),
        "nan_count": nan_count,
        "top_k": top_k,
    }


# ----------------------------------------------------------------------
# Multi-task feedforward DNN (PyTorch) - generic shared trunk + 2 heads
# ----------------------------------------------------------------------

def _build_multitask_mlp(in_dim: int, share_dim: int, reag_dim: int,
                        solv_dim: int, n_reagent: int, n_solvent: int,
                        dropout: float = 0.2):
    import torch.nn as nn
    class MultitaskNet(nn.Module):
        def __init__(self):
            super().__init__()
            self.shared = nn.Sequential(
                nn.Linear(in_dim, share_dim), nn.ReLU(), nn.Dropout(dropout))
            self.reag_head = nn.Sequential(
                nn.Linear(share_dim, reag_dim), nn.ReLU(), nn.Dropout(dropout),
                nn.Linear(reag_dim, n_reagent))
            self.solv_head = nn.Sequential(
                nn.Linear(share_dim, solv_dim), nn.ReLU(), nn.Dropout(dropout),
                nn.Linear(solv_dim, n_solvent))

        def forward(self, x):
            h = self.shared(x)
            return self.reag_head(h), self.solv_head(h)
    return MultitaskNet()


@mcp.tool()
def build_multitask_dnn_architecture(
    in_dim: int,
    share_dim: int,
    reag_dim: int,
    solv_dim: int,
    n_reagent: int,
    n_solvent: int,
    dropout: float = 0.2,
) -> dict:
    """Instantiate a generic multi-task feedforward NN (shared trunk + two
    parallel sigmoid heads) and report parameter counts. All sizes are
    agent-supplied; this tool does NOT encode any specific paper's
    architecture choices.

    Architecture:
        rxn_fp (in_dim) -> Shared(share_dim, ReLU) -> {
            reagent head: (reag_dim, ReLU) -> sigmoid(n_reagent),
            solvent head: (solv_dim, ReLU) -> sigmoid(n_solvent)
        }

    Args:
        in_dim: input fingerprint length (agent-supplied; derive from the
            reaction-fingerprint design you choose)
        share_dim: shared hidden size (agent-supplied)
        reag_dim: reagent task hidden size (agent-supplied)
        solv_dim: solvent task hidden size (agent-supplied)
        n_reagent: reagent label cardinality (agent-supplied; derive from
            the bundled reagent_labels.csv)
        n_solvent: solvent label cardinality (agent-supplied; derive from
            the bundled solvent_labels.csv)
        dropout: dropout rate

    Returns:
        dict with total_parameters, shared_parameters,
        reagent_head_parameters, solvent_head_parameters, layer_summary.
    """
    net = _build_multitask_mlp(in_dim, share_dim, reag_dim, solv_dim,
                                n_reagent, n_solvent, dropout)
    total = sum(p.numel() for p in net.parameters())
    shared = sum(p.numel() for p in net.shared.parameters())
    reag = sum(p.numel() for p in net.reag_head.parameters())
    solv = sum(p.numel() for p in net.solv_head.parameters())
    return {
        "total_parameters": int(total),
        "shared_parameters": int(shared),
        "reagent_head_parameters": int(reag),
        "solvent_head_parameters": int(solv),
        "layer_summary": [
            f"input -> Linear({in_dim}, {share_dim}) -> ReLU -> Dropout({dropout})",
            f"shared -> Linear({share_dim}, {reag_dim}) -> ReLU -> Linear({reag_dim}, {n_reagent}) [reagent logits]",
            f"shared -> Linear({share_dim}, {solv_dim}) -> ReLU -> Linear({solv_dim}, {n_solvent}) [solvent logits]",
        ],
        "config": {
            "in_dim": in_dim, "share_dim": share_dim,
            "reag_dim": reag_dim, "solv_dim": solv_dim,
            "n_reagent": n_reagent, "n_solvent": n_solvent,
            "dropout": dropout,
        },
    }


@mcp.tool()
def train_multitask_dnn(
    X_train: list, y_reag_train: list, y_solv_train: list,
    X_val: list, y_reag_val: list, y_solv_val: list,
    in_dim: int, share_dim: int,
    reag_dim: int, solv_dim: int,
    n_reagent: int, n_solvent: int,
    dropout: float = 0.2, epochs: int = 5,
    batch_size: int = 64, learning_rate: float = 1e-4,
    focal_gamma: float = 2.0, random_seed: int = 0,
) -> dict:
    """Train a multi-task feedforward DNN with focal loss + homoscedastic-
    uncertainty multi-task weighting. All architecture sizes and label
    cardinalities are agent-supplied; this tool does NOT bake in the
    paper's specific design.

    Inputs are dense feature matrices (lists of lists). Multi-hot targets
    must already be one-hot/binary lists matching n_reagent / n_solvent.

    Args:
        X_train, X_val: list of length-in_dim feature vectors
        y_reag_train/val: list of length-n_reagent multi-hot vectors
        y_solv_train/val: list of length-n_solvent multi-hot vectors
        in_dim, share_dim, reag_dim, solv_dim, n_reagent, n_solvent:
            architecture sizes (agent-supplied)
        epochs: training epochs (the agent must choose an epoch count
            consistent with the paper being reproduced)
        batch_size, learning_rate: optimizer hyperparameters
        focal_gamma: focal-loss modulating factor

    Returns:
        dict with model_id (saved to /tmp), final train/val losses,
        per-epoch loss history.
    """
    import torch
    import torch.nn as nn
    import torch.nn.functional as F

    torch.manual_seed(random_seed)
    np.random.seed(random_seed)

    X_tr = torch.tensor(np.array(X_train, dtype=np.float32))
    yr_tr = torch.tensor(np.array(y_reag_train, dtype=np.float32))
    ys_tr = torch.tensor(np.array(y_solv_train, dtype=np.float32))
    X_va = torch.tensor(np.array(X_val, dtype=np.float32))
    yr_va = torch.tensor(np.array(y_reag_val, dtype=np.float32))
    ys_va = torch.tensor(np.array(y_solv_val, dtype=np.float32))

    net = _build_multitask_mlp(in_dim, share_dim, reag_dim, solv_dim,
                                n_reagent, n_solvent, dropout)
    log_sigma_r = nn.Parameter(torch.zeros(1))
    log_sigma_s = nn.Parameter(torch.zeros(1))
    opt = torch.optim.Adam(list(net.parameters()) + [log_sigma_r, log_sigma_s],
                           lr=learning_rate)

    def focal_bce(logits, target, gamma):
        # Sigmoid focal loss for multi-label classification
        p = torch.sigmoid(logits)
        ce = F.binary_cross_entropy_with_logits(logits, target, reduction="none")
        pt = p * target + (1 - p) * (1 - target)
        return ((1 - pt).pow(gamma) * ce).mean()

    history = []
    n = len(X_tr)
    for ep in range(epochs):
        net.train()
        perm = torch.randperm(n)
        total_loss = 0.0
        nb = 0
        for i in range(0, n, batch_size):
            idx = perm[i:i + batch_size]
            xb = X_tr[idx]; ybr = yr_tr[idx]; ybs = ys_tr[idx]
            lr_logits, ls_logits = net(xb)
            loss_r = focal_bce(lr_logits, ybr, focal_gamma)
            loss_s = focal_bce(ls_logits, ybs, focal_gamma)
            # Homoscedastic uncertainty weighting (Kendall & Gal, 2018):
            #   L = (1/2σ_r²)L_r + (1/2σ_s²)L_s + log σ_r σ_s
            # parameterize via log σ for stability
            loss = (torch.exp(-2 * log_sigma_r) * loss_r * 0.5
                    + torch.exp(-2 * log_sigma_s) * loss_s * 0.5
                    + log_sigma_r + log_sigma_s).squeeze()
            opt.zero_grad()
            loss.backward()
            opt.step()
            total_loss += float(loss.item()); nb += 1
        train_loss = total_loss / max(nb, 1)
        # validation
        net.eval()
        with torch.no_grad():
            lr_v, ls_v = net(X_va)
            v_r = focal_bce(lr_v, yr_va, focal_gamma).item()
            v_s = focal_bce(ls_v, ys_va, focal_gamma).item()
        history.append({"epoch": ep + 1,
                        "train_loss": round(train_loss, 6),
                        "val_reag_focal": round(v_r, 6),
                        "val_solv_focal": round(v_s, 6),
                        "log_sigma_r": round(float(log_sigma_r.item()), 4),
                        "log_sigma_s": round(float(log_sigma_s.item()), 4)})

    state = {"net_state": net.state_dict(),
             "config": {"in_dim": in_dim, "share_dim": share_dim,
                         "reag_dim": reag_dim, "solv_dim": solv_dim,
                         "n_reagent": n_reagent, "n_solvent": n_solvent,
                         "dropout": dropout}}
    blob = pickle.dumps(state)
    model_id = hashlib.md5(blob[:1024]).hexdigest()[:10]
    with open(os.path.join(_MODEL_DIR, f"mtnet_{model_id}.pkl"), "wb") as f:
        f.write(blob)
    return {"model_id": model_id, "epochs": epochs,
            "train_size": n, "val_size": len(X_va),
            "history": history}


@mcp.tool()
def predict_multitask_dnn(model_id: str, X: list) -> dict:
    """Run a trained multi-task DNN and return sigmoid probabilities for
    each task.

    Args:
        model_id: identifier returned by train_multitask_dnn
        X: list of length-in_dim feature vectors

    Returns:
        dict with reagent_probs (n_samples × n_reagent), solvent_probs.
    """
    import torch
    path = os.path.join(_MODEL_DIR, f"mtnet_{model_id}.pkl")
    with open(path, "rb") as f:
        state = pickle.load(f)
    cfg = state["config"]
    net = _build_multitask_mlp(cfg["in_dim"], cfg["share_dim"],
                                cfg["reag_dim"], cfg["solv_dim"],
                                cfg["n_reagent"], cfg["n_solvent"],
                                cfg["dropout"])
    net.load_state_dict(state["net_state"])
    net.eval()
    Xt = torch.tensor(np.array(X, dtype=np.float32))
    with torch.no_grad():
        lr, ls = net(Xt)
    return {
        "reagent_probs": torch.sigmoid(lr).numpy().round(6).tolist(),
        "solvent_probs": torch.sigmoid(ls).numpy().round(6).tolist(),
    }


# ----------------------------------------------------------------------
# Random-Forest / k-NN baselines for solvent classification
# ----------------------------------------------------------------------

@mcp.tool()
def train_rf_baseline(X_train: list, y_train: list, n_estimators: int = 100,
                       max_depth: int = None, random_state: int = 0) -> dict:
    """Train a Random Forest multi-label classifier baseline.

    Args:
        X_train: list of feature vectors (e.g., reaction fingerprints)
        y_train: list of multi-hot label vectors
        n_estimators, max_depth: RF hyperparameters

    Returns:
        dict with model_id, n_classes, n_train.
    """
    from sklearn.ensemble import RandomForestClassifier
    Xa = np.array(X_train, dtype=np.float32)
    Ya = np.array(y_train, dtype=np.int32)
    clf = RandomForestClassifier(n_estimators=n_estimators,
                                 max_depth=max_depth,
                                 random_state=random_state, n_jobs=-1)
    clf.fit(Xa, Ya)
    blob = pickle.dumps({"clf": clf, "n_classes": Ya.shape[1] if Ya.ndim > 1 else 1})
    model_id = hashlib.md5(blob[:1024]).hexdigest()[:10]
    with open(os.path.join(_MODEL_DIR, f"rf_{model_id}.pkl"), "wb") as f:
        f.write(blob)
    return {"model_id": model_id,
            "n_classes": int(Ya.shape[1] if Ya.ndim > 1 else 1),
            "n_train": int(len(Xa))}


@mcp.tool()
def predict_rf(model_id: str, X: list) -> dict:
    """Predict multi-label probabilities from a trained RF baseline."""
    path = os.path.join(_MODEL_DIR, f"rf_{model_id}.pkl")
    with open(path, "rb") as f:
        state = pickle.load(f)
    clf = state["clf"]
    Xa = np.array(X, dtype=np.float32)
    proba = clf.predict_proba(Xa)
    # multi-output: list of (n,2) arrays per label
    if isinstance(proba, list):
        out = np.stack([p[:, 1] if p.shape[1] == 2 else p[:, 0] for p in proba], axis=1)
    else:
        out = proba
    return {"probabilities": out.round(6).tolist(),
            "n_samples": int(out.shape[0]),
            "n_classes": int(out.shape[1])}


# ----------------------------------------------------------------------
# Evaluation: top-k accuracy, threshold-based F1, temperature MAE
# ----------------------------------------------------------------------

@mcp.tool()
def topk_accuracy(predictions: list, true_label_indices: list,
                   ks: list = None) -> dict:
    """Top-k classification accuracy. A test sample is correct at k if any
    of its true-label indices appears in the top-k predicted labels.

    Args:
        predictions: list of length-n_classes probability vectors
        true_label_indices: per-sample list of correct label indices
        ks: list of k values to evaluate (default [1, 3, 5, 10])

    Returns:
        dict mapping each k to its accuracy fraction.
    """
    if ks is None:
        ks = [1, 3, 5, 10]
    P = np.array(predictions, dtype=np.float32)
    n = len(P)
    out = {}
    for k in ks:
        hits = 0
        for i in range(n):
            order = np.argsort(P[i])[::-1][:k]
            if any(t in order for t in true_label_indices[i]):
                hits += 1
        out[f"top_{k}"] = round(hits / max(n, 1), 6)
    out["n_samples"] = int(n)
    return out


@mcp.tool()
def threshold_metrics(predictions: list, true_labels: list,
                       threshold: float = 0.5) -> dict:
    """Multi-label hamming loss + example-based precision / recall / F1
    at a fixed probability threshold.

    The 0.5 default is the standard multi-label threshold; if the
    reference paper specifies a different operating threshold the agent
    must supply it explicitly.

    Args:
        predictions: list of probability vectors (n_samples x n_classes)
        true_labels: list of multi-hot vectors (n_samples x n_classes)
        threshold: probability cutoff for positive prediction (agent-supplied
            when the paper's operating threshold is part of the answer)

    Returns:
        dict with hamming_loss, precision, recall, f1, threshold, mean_n_pred.
    """
    P = np.array(predictions, dtype=np.float32) >= threshold
    Y = np.array(true_labels, dtype=np.int32) > 0
    n, q = P.shape
    hamming = float(np.logical_xor(P, Y).mean())
    precs, recs, f1s, npreds = [], [], [], []
    for i in range(n):
        pi = P[i]; yi = Y[i]
        inter = int(np.logical_and(pi, yi).sum())
        npred = int(pi.sum()); ntrue = int(yi.sum())
        npreds.append(npred)
        prec = inter / npred if npred > 0 else 0.0
        rec = inter / ntrue if ntrue > 0 else 0.0
        f1 = (2 * prec * rec / (prec + rec)) if (prec + rec) > 0 else 0.0
        precs.append(prec); recs.append(rec); f1s.append(f1)
    return {
        "hamming_loss": round(hamming, 6),
        "precision": round(float(np.mean(precs)), 6),
        "recall": round(float(np.mean(recs)), 6),
        "f1": round(float(np.mean(f1s)), 6),
        "threshold": threshold,
        "mean_n_pred": round(float(np.mean(npreds)), 4),
        "n_samples": int(n),
    }


@mcp.tool()
def temperature_mae(predictions: list, true_temps: list,
                     tolerances: list = None) -> dict:
    """Mean absolute error for temperature regression plus within-tolerance
    accuracies. Returns MAE, RMSE, and `within_<X>C` accuracy for each
    tolerance band.

    Args:
        predictions: predicted temperatures (°C)
        true_temps: ground-truth temperatures (°C)
        tolerances: list of ±X °C bands to score (default [10, 20])

    Returns:
        dict with mae, rmse, and accuracy_within_<X>C for each X.
    """
    if tolerances is None:
        tolerances = [10, 20]
    p = np.array(predictions, dtype=np.float64)
    t = np.array(true_temps, dtype=np.float64)
    err = p - t
    mae = float(np.mean(np.abs(err)))
    rmse = float(np.sqrt(np.mean(err ** 2)))
    out = {"mae": round(mae, 4), "rmse": round(rmse, 4),
           "n_samples": int(len(p))}
    for tol in tolerances:
        out[f"within_{tol}C"] = round(float(np.mean(np.abs(err) <= tol)), 6)
    return out


# ----------------------------------------------------------------------
# Hard negative sampling helper
# ----------------------------------------------------------------------

@mcp.tool()
def hard_negative_indices(probabilities: list, true_label_mask: list,
                           threshold: float = 0.5) -> dict:
    """Identify hard-negative label indices for ranking-stage augmentation.

    Hard negatives = labels whose predicted probability >= threshold but
    are NOT in the recorded ground-truth set.

    Args:
        probabilities: per-sample probability vector (length n_classes)
        true_label_mask: per-sample multi-hot ground-truth (length n_classes)
        threshold: probability cutoff (agent supplies the value matching
            the reference paper)

    Returns:
        dict with hard_negatives (list of int indices), n_hard_neg,
        n_positive, threshold.
    """
    p = np.array(probabilities, dtype=np.float32)
    y = np.array(true_label_mask, dtype=np.int32) > 0
    above = p >= threshold
    hard = np.logical_and(above, ~y)
    idx = np.where(hard)[0].tolist()
    return {"hard_negatives": [int(i) for i in idx],
            "n_hard_neg": int(len(idx)),
            "n_positive": int(y.sum()),
            "threshold": threshold}


# ----------------------------------------------------------------------
# Combinatorial enumeration of reaction-condition contexts
# ----------------------------------------------------------------------

@mcp.tool()
def enumerate_combinations(solvent_indices: list, reagent_indices: list,
                             max_solvents: int,
                             max_reagents: int) -> dict:
    """Enumerate all (solvent-set, reagent-set) combinations subject to
    cardinality limits supplied by the agent.

    Args:
        solvent_indices: candidate solvent label IDs (from threshold filter)
        reagent_indices: candidate reagent label IDs
        max_solvents, max_reagents: combinatorial caps (agent-supplied;
            choose values consistent with the paper being reproduced)

    Returns:
        dict with combinations (list of {solvents, reagents}), n_combinations.
    """
    from itertools import combinations
    sv = []
    for k in range(1, max_solvents + 1):
        for c in combinations(solvent_indices, k):
            sv.append(list(c))
    rv = []
    for k in range(1, max_reagents + 1):
        for c in combinations(reagent_indices, k):
            rv.append(list(c))
    combos = []
    for s in sv:
        for r in rv:
            combos.append({"solvents": s, "reagents": r})
    return {"combinations": combos, "n_combinations": len(combos),
            "n_solvent_subsets": len(sv), "n_reagent_subsets": len(rv)}


# ----------------------------------------------------------------------
# Plotting primitives
# ----------------------------------------------------------------------

@mcp.tool()
def plot_label_distribution(csv_path: str, output_path: str,
                              top_k: int = 20, kind: str = "solvent") -> dict:
    """Bar plot of the top-k most frequent solvent or reagent labels.

    Args:
        csv_path: path to label-frequency CSV (columns name, value)
        output_path: where to save the PNG
        top_k: number of labels to display
        kind: 'solvent' or 'reagent' (used in figure title only)

    Returns:
        dict with output_path, n_displayed, total_classes.
    """
    import pandas as pd
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    df = pd.read_csv(csv_path, index_col=0).fillna({"name": "nan"})
    df_sorted = df.sort_values("value", ascending=False).head(top_k)
    fig, ax = plt.subplots(figsize=(10, 6))
    color = "#5B9BD5" if kind.lower().startswith("solv") else "#ED7D31"
    ax.barh(range(len(df_sorted))[::-1],
            df_sorted["value"].values, color=color)
    ax.set_yticks(range(len(df_sorted))[::-1])
    ax.set_yticklabels(df_sorted["name"].astype(str).values, fontsize=9)
    ax.set_xlabel("Reaction count")
    ax.set_title(f"Top {top_k} {kind} labels (of {len(df)} total)")
    ax.grid(axis="x", alpha=0.3)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"output_path": output_path,
            "n_displayed": int(len(df_sorted)),
            "total_classes": int(len(df))}


@mcp.tool()
def plot_topk_curve(topk_data: list, output_path: str,
                      title: str = "Top-k accuracy") -> dict:
    """Plot top-k accuracy as a function of k.

    Args:
        topk_data: list of {k, accuracy} dicts (or just list of (k, acc) tuples)
        output_path: where to save the PNG
        title: figure title

    Returns:
        dict with output_path, n_points.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    if topk_data and isinstance(topk_data[0], dict):
        ks = [d["k"] for d in topk_data]
        accs = [d["accuracy"] for d in topk_data]
    else:
        ks = [t[0] for t in topk_data]; accs = [t[1] for t in topk_data]
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.plot(ks, accs, "o-", lw=2, ms=8, color="#2E75B6")
    ax.set_xlabel("k"); ax.set_ylabel("Accuracy")
    ax.set_title(title); ax.grid(alpha=0.3)
    ax.set_ylim([0, 1])
    for k, a in zip(ks, accs):
        ax.annotate(f"{a*100:.1f}%", (k, a), textcoords="offset points",
                    xytext=(0, 10), ha="center", fontsize=9)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"output_path": output_path, "n_points": len(ks)}


@mcp.tool()
def plot_temperature_scatter(predictions: list, true_temps: list,
                               output_path: str,
                               tolerance_bands: list = None) -> dict:
    """Predicted-vs-true temperature scatter with ±X °C tolerance bands.

    Args:
        predictions: predicted temperatures (°C)
        true_temps: ground-truth temperatures (°C)
        output_path: where to save the PNG
        tolerance_bands: list of ±X °C bands to draw (default [10, 20])

    Returns:
        dict with output_path, mae, n_points.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    if tolerance_bands is None:
        tolerance_bands = [10, 20]
    p = np.array(predictions); t = np.array(true_temps)
    fig, ax = plt.subplots(figsize=(7, 7))
    ax.scatter(t, p, alpha=0.4, s=14, color="#2E75B6")
    lo, hi = min(t.min(), p.min()) - 5, max(t.max(), p.max()) + 5
    ax.plot([lo, hi], [lo, hi], "k--", lw=1, alpha=0.6, label="y=x")
    for tol in tolerance_bands:
        ax.fill_between([lo, hi], [lo - tol, hi - tol], [lo + tol, hi + tol],
                        alpha=0.10, label=f"±{tol} °C")
    ax.set_xlim(lo, hi); ax.set_ylim(lo, hi)
    ax.set_xlabel("True temperature (°C)"); ax.set_ylabel("Predicted (°C)")
    ax.set_title(f"Temperature prediction (MAE={np.mean(np.abs(p-t)):.1f} °C)")
    ax.legend(loc="upper left"); ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"output_path": output_path,
            "mae": round(float(np.mean(np.abs(p - t))), 4),
            "n_points": int(len(p))}


@mcp.tool()
def plot_ranked_predictions(predictions_csv: str, output_path: str,
                              title: str = "Top-ranked reaction conditions",
                              top_n: int = 10) -> dict:
    """Bar plot of probability-ranked candidate reaction-condition contexts
    (e.g., the per-example outputs the paper prints for its illustration
    reactions).

    Args:
        predictions_csv: CSV with columns 'Yield / Rank', 'Reagent(s)',
            'Solvent(s)', 'Temperature', 'Probability'
        output_path: where to save the PNG
        title: figure title
        top_n: number of ranks to display

    Returns:
        dict with output_path, n_displayed.
    """
    import pandas as pd
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    df = pd.read_csv(predictions_csv).head(top_n)
    fig, ax = plt.subplots(figsize=(9, max(4, 0.4 * len(df) + 2)))
    labels = [
        f"{i+1}. {str(r['Reagent(s)'])[:40]} / {str(r['Solvent(s)'])[:25]}"
        f" ({float(r['Temperature']):.1f}°C)"
        for i, r in df.reset_index(drop=True).iterrows()
    ]
    ax.barh(range(len(df))[::-1], df["Probability"].astype(float).values,
            color="#ED7D31")
    ax.set_yticks(range(len(df))[::-1])
    ax.set_yticklabels(labels, fontsize=8)
    ax.set_xlabel("Probability")
    ax.set_title(title); ax.grid(axis="x", alpha=0.3)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"output_path": output_path, "n_displayed": int(len(df))}


if __name__ == "__main__":
    mcp.run(transport="stdio")

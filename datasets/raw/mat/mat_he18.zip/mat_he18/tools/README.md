# mat_he18 — Tool Reference

All inputs for this task are bundled locally, so no external-database retrieval
is required. Only `hea_ml_tools.py` (the FastMCP server) and the generic
`data_processing.py` helpers are needed.

## Data Processing (`data_processing.py`)

- **read_csv** / **write_csv**: tabular CSV I/O via DictReader/DictWriter.
- **read_json** / **write_json**: JSON I/O.
- **read_excel**: pandas/openpyxl .xlsx loader (returns list-of-dicts).
- **read_parquet**: pandas/pyarrow parquet loader.
- **read_fasta**: FASTA sequence reader.
- **pivot_long_to_wide** / **pivot_wide_to_long**: reshape.
- **drop_missing**: remove rows with None/NaN.
- **coerce_numeric**: cast named columns to float.
- **join_tables**: SQL-style join.
- **groupby_aggregate**: group-by with mean/sum/min/max/count.

## Domain-Specific Analysis (`hea_ml_tools.py`)

- **load_hea_csv**: load an HEA bulk-modulus CSV and report shape, BM stats, element / phase column counts.
- **parse_composition_row**: parse a single alloy row into `{symbol: atomic_fraction}` plus phase flag and BM target.
- **get_element_properties**: tabulated atomic Z, mass, radius, electronegativity, VEC, T_melt, density, pure-element bulk modulus. The property table has **78 entries, one per element column in the train/test CSVs** (the CSVs carry 3 phase flags AM/IM/SS + **78 element atomic-fraction columns** + the BM target = 82 columns). One of the 78 columns, **`Ns`, is an all-zero placeholder** (it never carries a non-zero fraction in any alloy) and its table row has all values `None`; the remaining **77 elements have a real pure-element bulk modulus**. The pure-element bulk modulus is provided ONLY for the rule-of-mixtures control (see below) and must NOT be used as a model feature.
- **composition_weighted_stats**: composition-weighted mean / std / min / max / range of any single element property over the constituents of one alloy.
- **rule_of_mixtures_baseline**: fixed, non-fitted control — predicts BM as the composition-weighted average of pure-element bulk moduli (`sum_i f_i * B_pure_i`) and reports its train/test R-square, MSE, MAE, MAPE and Pearson. The fitted ML models must beat this baseline; on the bundled split it gives test R-square 0.873 (Pearson 0.95), confirming the target is near-linear in composition and that the regularised-linear models (~0.997) genuinely improve on a fixed mixing rule rather than memorising duplicates.
- **train_bm_regressor**: fit one of `lasso | ridge | elastic_net | linear | random_forest | xgboost | knn` on the train CSV and evaluate on the test CSV (returns train + test R-square, adjusted R-square, MSE, MAE, MAPE plus coef / feature importance).
- **cross_validate_bm**: k-fold CV R-square on the training set for any of the seven model families (`lasso | ridge | elastic_net | linear | random_forest | xgboost | knn`).
- **plot_predicted_vs_actual**: parity scatter (predicted vs actual BM, y=x reference + best linear fit annotation).
- **plot_model_comparison**: bar chart of test-set R2 / adj R2 / MSE / MAE / MAPE across regressors.
- **plot_element_recurrence**: top-K element occurrence chart over the dataset (horizontal bar).

## Dependencies

Python >= 3.10 with:

```
numpy
pandas
scikit-learn
xgboost
matplotlib
openpyxl
mcp[server]
```

Install with `pip install numpy pandas scikit-learn xgboost matplotlib openpyxl mcp`.

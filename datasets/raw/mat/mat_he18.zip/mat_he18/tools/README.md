# mat_he18 — Tool Reference

## Database Retrieval (`database_retrieval.py`)

- **websearch**: Generic web search for ad-hoc dataset DOIs / supplementary URLs.
- **fetch_url**: HTTP GET with redirects, used to download CSV/PDF/JSON.
- **query_pubchem**: PubChem PUG-REST lookup (cid / name / smiles / inchikey).
- **query_chembl**: ChEMBL bioactivity query for a target.
- **query_uniprot**: UniProt entry fetch (sequence, organism, features).
- **query_pdb**: RCSB PDB entry metadata + structure file URL.
- **query_geo**: NCBI GEO series/sample fetch (GSE/GSM).
- **query_ncbi_entrez**: Generic Entrez E-search + E-fetch.
- **query_usgs_comcat**: USGS earthquake catalog query.
- **query_world_bank**: World Bank WDI indicator series.
- **query_openalex**: OpenAlex works/authors/venues search.
- **query_doi**: DOI -> Crossref + Unpaywall record.

## Data Processing (`data_processing.py`)

- **read_csv** / **write_csv**: tabular CSV I/O via DictReader/DictWriter.
- **read_json** / **write_json**: JSON I/O.
- **read_excel**: pandas/openpyxl .xlsx loader (returns list-of-dicts).
- **read_parquet**: pandas/pyarrow parquet loader.
- **read_fasta**: FASTA sequence reader.
- **pivot_long_to_wide** / **pivot_wide_to_long**: reshape.
- **drop_missing**: remove rows with None/NaN.
- **coerce_numeric**: cast named columns to float.
- **join_tables**: SQL-style join.
- **groupby_aggregate**: group-by with mean/sum/min/max/count.

## Domain-Specific Analysis (`hea_ml_tools.py`)

- **load_hea_csv**: load an HEA bulk-modulus CSV and report shape, BM stats, element / phase column counts.
- **parse_composition_row**: parse a single alloy row into `{symbol: atomic_fraction}` plus phase flag and BM target.
- **get_element_properties**: tabulated atomic Z, mass, radius, electronegativity, VEC, T_melt, density, pure-element bulk modulus for the 79 elements that appear in the dataset.
- **composition_weighted_stats**: composition-weighted mean / std / min / max / range of any single element property over the constituents of one alloy.
- **train_bm_regressor**: fit one of `lasso | ridge | elastic_net | linear | random_forest | xgboost | knn` on the train CSV and evaluate on the test CSV (returns train + test R-square, adjusted R-square, MSE, MAE, MAPE plus coef / feature importance).
- **cross_validate_bm**: k-fold CV R-square on the training set for any of the seven model families (`lasso | ridge | elastic_net | linear | random_forest | xgboost | knn`).
- **plot_predicted_vs_actual**: parity scatter (predicted vs actual BM, y=x reference + best linear fit annotation).
- **plot_model_comparison**: bar chart of test-set R2 / adj R2 / MSE / MAE / MAPE across regressors.
- **plot_element_recurrence**: top-K element occurrence chart over the dataset (horizontal bar).

## Dependencies

Python >= 3.10 with:

```
numpy
pandas
scikit-learn
xgboost
matplotlib
openpyxl
mcp[server]
```

Install with `pip install numpy pandas scikit-learn xgboost matplotlib openpyxl mcp`.

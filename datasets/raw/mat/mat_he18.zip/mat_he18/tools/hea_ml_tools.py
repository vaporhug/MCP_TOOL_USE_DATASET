#!/usr/bin/env python3
"""Domain primitives for high-entropy alloy (HEA) bulk modulus prediction.

Low-level building blocks: composition parsing, element-property lookup,
descriptor aggregation (mean / std / range over the constituent elements),
ML training & evaluation across regression families, and plotting.

Each primitive is independently runnable; nothing here pre-computes the
final answer or hides domain knowledge.
"""

import os
import json
import re
import pickle
import hashlib
import numpy as np
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("HEA_BM_Tools")


# ---------------------------------------------------------------------------
# 1. Data loading
# ---------------------------------------------------------------------------
@mcp.tool()
def load_hea_csv(csv_path: str) -> dict:
    """Load an HEA CSV and return shape + summary stats.

    Expected layout: first 3 columns are phase indicator flags
    (AM, IM, SS), the next 78 columns are atomic-fraction-per-element
    (alphabetical), the last column is BM (bulk modulus, GPa).

    Args:
        csv_path: path to hea_bm_train.csv or hea_bm_test.csv

    Returns:
        dict with shape, column names, BM stats, and number of unique
        alloys (compositions with non-zero element fractions).
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    bm = df["BM"].values
    elem_cols = [c for c in df.columns if c not in ("AM", "IM", "SS", "BM")]
    nonzero_per_row = (df[elem_cols] > 0).sum(axis=1)
    return {
        "shape": list(df.shape),
        "columns": list(df.columns),
        "n_phase_flags": 3,
        "n_element_columns": len(elem_cols),
        "bm_stats": {
            "n": int(len(bm)),
            "mean": round(float(np.mean(bm)), 4),
            "std": round(float(np.std(bm)), 4),
            "min": round(float(np.min(bm)), 4),
            "max": round(float(np.max(bm)), 4),
            "median": round(float(np.median(bm)), 4),
        },
        "n_elements_per_row": {
            "min": int(nonzero_per_row.min()),
            "max": int(nonzero_per_row.max()),
            "mean": round(float(nonzero_per_row.mean()), 3),
        },
    }


# ---------------------------------------------------------------------------
# 2. Composition parsing primitive
# ---------------------------------------------------------------------------
@mcp.tool()
def parse_composition_row(csv_path: str, row_index: int) -> dict:
    """Return the alloy composition for one row as a sparse dict
    {element_symbol: atomic_fraction} plus the phase flag and BM target.

    Args:
        csv_path: HEA CSV path
        row_index: 0-based row index

    Returns:
        dict with composition, phase, bm
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    if row_index < 0 or row_index >= len(df):
        return {"error": f"row_index {row_index} out of range 0..{len(df)-1}"}
    r = df.iloc[row_index]
    phase = "AM" if int(r["AM"]) else ("IM" if int(r["IM"]) else ("SS" if int(r["SS"]) else "?"))
    if int(r["AM"]) + int(r["IM"]) + int(r["SS"]) > 1:
        phase = "+".join([p for p in ("AM", "IM", "SS") if int(r[p])])
    elem_cols = [c for c in df.columns if c not in ("AM", "IM", "SS", "BM")]
    composition = {e: float(r[e]) for e in elem_cols if float(r[e]) > 0}
    return {
        "row_index": row_index,
        "phase": phase,
        "bm": float(r["BM"]),
        "n_elements": len(composition),
        "composition": composition,
        "fraction_sum": round(sum(composition.values()), 4),
    }


# ---------------------------------------------------------------------------
# 3. Element property lookup primitive
# ---------------------------------------------------------------------------
@mcp.tool()
def get_element_properties(symbols: list) -> dict:
    """Return tabulated atomic properties for a list of element symbols.

    Properties: atomic_number Z, atomic_mass amu, atomic_radius pm,
    electronegativity (Pauling), VEC (valence electron count),
    melting_point K, density g/cm3, bulk_modulus_pure_GPa.

    Args:
        symbols: list of element symbols (e.g., ['Fe','Ni','Co','Cr','Cu','Al'])

    Returns:
        dict {symbol: {properties}}; unknown symbols return None entries.
    """
    # tabulated values for the candidate elements in the HEA dataset
    # (78 element columns + a placeholder Ns)
    TABLE = {
        # Z, mass, radius_pm, en_pauling, VEC, T_melt_K, rho_g_cm3, B_pure_GPa
        "Ag": (47, 107.868, 144, 1.93, 11, 1234.93, 10.49, 100.0),
        "Al": (13, 26.982, 143, 1.61, 3, 933.47, 2.70, 76.0),
        "As": (33, 74.922, 119, 2.18, 5, 887.0, 5.73, 22.0),
        "Au": (79, 196.967, 144, 2.54, 11, 1337.33, 19.30, 220.0),
        "B":  (5, 10.811, 90, 2.04, 3, 2349.0, 2.34, 320.0),
        "Ba": (56, 137.327, 222, 0.89, 2, 1000.0, 3.51, 9.6),
        "Be": (4, 9.012, 112, 1.57, 2, 1560.0, 1.85, 130.0),
        "Bi": (83, 208.980, 156, 2.02, 5, 544.7, 9.78, 31.0),
        "Br": (35, 79.904, 114, 2.96, 7, 265.8, 3.10, 1.9),
        "C":  (6, 12.011, 70, 2.55, 4, 3915.0, 2.27, 33.0),
        "Ca": (20, 40.078, 197, 1.00, 2, 1115.0, 1.55, 17.0),
        "Cd": (48, 112.411, 151, 1.69, 12, 594.22, 8.65, 42.0),
        "Ce": (58, 140.116, 181, 1.12, 3, 1068.0, 6.77, 21.5),
        "Cl": (17, 35.45, 99, 3.16, 7, 171.6, 1.56, 1.1),
        "Co": (27, 58.933, 125, 1.88, 9, 1768.0, 8.90, 180.0),
        "Cr": (24, 51.996, 128, 1.66, 6, 2180.0, 7.19, 160.0),
        "Cs": (55, 132.905, 265, 0.79, 1, 301.7, 1.93, 1.6),
        "Cu": (29, 63.546, 128, 1.90, 11, 1357.77, 8.96, 140.0),
        "Dy": (66, 162.500, 175, 1.22, 3, 1680.0, 8.55, 41.0),
        "Er": (68, 167.259, 175, 1.24, 3, 1802.0, 9.07, 44.0),
        "Eu": (63, 151.964, 185, 1.20, 2, 1099.0, 5.24, 8.3),
        "F":  (9, 18.998, 50, 3.98, 7, 53.5, 1.7, 1.0),
        "Fe": (26, 55.845, 126, 1.83, 8, 1811.0, 7.87, 170.0),
        "Ga": (31, 69.723, 135, 1.81, 3, 302.91, 5.91, 56.9),
        "Gd": (64, 157.25, 180, 1.20, 3, 1585.0, 7.90, 38.0),
        "Ge": (32, 72.630, 122, 2.01, 4, 1211.4, 5.32, 75.0),
        "H":  (1, 1.008, 25, 2.20, 1, 14.01, 0.000084, 1.0),
        "Hf": (72, 178.49, 159, 1.30, 4, 2506.0, 13.31, 110.0),
        "Hg": (80, 200.592, 151, 2.00, 12, 234.32, 13.53, 25.0),
        "Ho": (67, 164.930, 175, 1.23, 3, 1734.0, 8.80, 40.0),
        "I":  (53, 126.904, 133, 2.66, 7, 386.85, 4.93, 7.7),
        "In": (49, 114.818, 167, 1.78, 3, 429.75, 7.31, 41.0),
        "Ir": (77, 192.217, 136, 2.20, 9, 2719.0, 22.56, 320.0),
        "K":  (19, 39.098, 227, 0.82, 1, 336.53, 0.86, 3.1),
        "La": (57, 138.905, 187, 1.10, 3, 1191.0, 6.15, 28.0),
        "Li": (3, 6.94, 152, 0.98, 1, 453.65, 0.534, 11.0),
        "Lu": (71, 174.967, 175, 1.27, 3, 1925.0, 9.84, 48.0),
        "Mg": (12, 24.305, 160, 1.31, 2, 923.0, 1.74, 45.0),
        "Mn": (25, 54.938, 127, 1.55, 7, 1519.0, 7.21, 120.0),
        "Mo": (42, 95.95, 139, 2.16, 6, 2896.0, 10.28, 230.0),
        "N":  (7, 14.007, 65, 3.04, 5, 63.05, 1.25, 0.5),
        "Na": (11, 22.99, 186, 0.93, 1, 370.95, 0.971, 6.3),
        "Nb": (41, 92.906, 146, 1.60, 5, 2750.0, 8.57, 170.0),
        "Nd": (60, 144.242, 181, 1.14, 3, 1294.0, 7.01, 32.0),
        "Ne": (10, 20.180, 38, 0.0, 8, 24.56, 0.0009, 1.1),
        "Ni": (28, 58.693, 124, 1.91, 10, 1728.0, 8.91, 180.0),
        "Ns": (None, None, None, None, None, None, None, None),
        "O":  (8, 15.999, 60, 3.44, 6, 54.36, 1.43, 1.6),
        "Os": (76, 190.23, 135, 2.20, 8, 3306.0, 22.59, 462.0),
        "P":  (15, 30.974, 110, 2.19, 5, 317.30, 1.82, 11.0),
        "Pb": (82, 207.2, 175, 2.33, 4, 600.61, 11.34, 46.0),
        "Pd": (46, 106.42, 137, 2.20, 10, 1828.05, 12.02, 180.0),
        "Pr": (59, 140.908, 182, 1.13, 3, 1208.0, 6.77, 28.8),
        "Pt": (78, 195.084, 138, 2.28, 10, 2041.4, 21.45, 230.0),
        "Rb": (37, 85.468, 248, 0.82, 1, 312.46, 1.532, 2.5),
        "Re": (75, 186.207, 137, 1.90, 7, 3459.0, 21.02, 370.0),
        "Rh": (45, 102.906, 134, 2.28, 9, 2237.0, 12.41, 380.0),
        "Ru": (44, 101.07, 134, 2.20, 8, 2607.0, 12.45, 220.0),
        "S":  (16, 32.06, 100, 2.58, 6, 388.36, 2.07, 7.7),
        "Sb": (51, 121.760, 138, 2.05, 5, 903.78, 6.69, 42.0),
        "Sc": (21, 44.956, 162, 1.36, 3, 1814.0, 2.99, 57.0),
        "Se": (34, 78.971, 120, 2.55, 6, 494.0, 4.81, 8.3),
        "Si": (14, 28.086, 117, 1.90, 4, 1687.0, 2.33, 100.0),
        "Sm": (62, 150.36, 181, 1.17, 3, 1345.0, 7.52, 37.8),
        "Sn": (50, 118.710, 145, 1.96, 4, 505.08, 7.31, 58.0),
        "Sr": (38, 87.62, 215, 0.95, 2, 1050.0, 2.64, 12.0),
        "Ta": (73, 180.948, 146, 1.50, 5, 3290.0, 16.65, 200.0),
        "Tb": (65, 158.925, 175, 1.20, 3, 1629.0, 8.23, 38.7),
        "Te": (52, 127.60, 140, 2.10, 6, 722.66, 6.24, 65.0),
        "Ti": (22, 47.867, 147, 1.54, 4, 1941.0, 4.51, 110.0),
        "Tl": (81, 204.383, 156, 1.62, 3, 577.0, 11.85, 43.0),
        "Tm": (69, 168.934, 175, 1.25, 3, 1818.0, 9.32, 45.0),
        "V":  (23, 50.942, 134, 1.63, 5, 2183.0, 6.11, 160.0),
        "W":  (74, 183.84, 139, 2.36, 6, 3695.0, 19.25, 310.0),
        "Y":  (39, 88.906, 180, 1.22, 3, 1799.0, 4.47, 41.2),
        "Yb": (70, 173.045, 175, 1.10, 3, 1097.0, 6.90, 30.5),
        "Zn": (30, 65.38, 134, 1.65, 12, 692.68, 7.14, 70.0),
        "Zr": (40, 91.224, 160, 1.33, 4, 2128.0, 6.51, 91.0),
    }
    keys = ("Z", "atomic_mass", "atomic_radius_pm", "electronegativity",
            "VEC", "melting_point_K", "density_g_cm3", "bulk_modulus_pure_GPa")
    out = {}
    for s in symbols:
        v = TABLE.get(s)
        if v is None:
            out[s] = None
        else:
            out[s] = dict(zip(keys, v))
    return {"n_known": sum(1 for s in symbols if TABLE.get(s) is not None),
            "n_requested": len(symbols),
            "properties": out}


# ---------------------------------------------------------------------------
# 4. Statistical aggregation primitive
# ---------------------------------------------------------------------------
@mcp.tool()
def composition_weighted_stats(composition: dict, property_name: str) -> dict:
    """Compute composition-weighted mean / std / min / max / range
    of a single element property over the constituents of one alloy.

    Args:
        composition: {symbol: atomic_fraction}
        property_name: one of 'Z','atomic_mass','atomic_radius_pm',
                       'electronegativity','VEC','melting_point_K',
                       'density_g_cm3','bulk_modulus_pure_GPa'

    Returns:
        dict with weighted mean, weighted std, min, max, range over constituents.
    """
    res = get_element_properties(list(composition.keys()))
    props = res["properties"]
    vals = []
    weights = []
    for s, frac in composition.items():
        p = props.get(s)
        if p is None or p.get(property_name) is None:
            continue
        vals.append(float(p[property_name]))
        weights.append(float(frac))
    if not vals:
        return {"error": "no valid property values"}
    arr = np.array(vals); w = np.array(weights)
    w_norm = w / w.sum() if w.sum() > 0 else w
    mean = float((arr * w_norm).sum())
    var = float((w_norm * (arr - mean) ** 2).sum())
    return {
        "property": property_name,
        "n_elements_used": len(vals),
        "weighted_mean": round(mean, 6),
        "weighted_std": round(var ** 0.5, 6),
        "min": round(float(arr.min()), 6),
        "max": round(float(arr.max()), 6),
        "range": round(float(arr.max() - arr.min()), 6),
    }


# ---------------------------------------------------------------------------
# 5. ML model training across regression families
# ---------------------------------------------------------------------------
@mcp.tool()
def train_bm_regressor(
    train_csv: str,
    test_csv: str,
    model_type: str,
    model_params: dict = None,
) -> dict:
    """Train a bulk-modulus regression model on the HEA train CSV
    and evaluate on the test CSV.

    Available model_type values:
        'lasso', 'ridge', 'elastic_net', 'linear',
        'random_forest', 'xgboost', 'knn'

    Features = all columns except 'BM'. Target = 'BM' (GPa).
    No feature scaling is applied for tree models; scaled (z-score with
    train statistics) features are used for linear / KNN families.

    Args:
        train_csv: training CSV path
        test_csv: test CSV path
        model_type: which regressor to fit
        model_params: optional override hyperparameters

    Returns:
        dict with model_id, train/test R2, MSE, MAE, MAPE, plus the
        regression coefficients / feature importances for inspection.
    """
    import pandas as pd
    from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error

    tr = pd.read_csv(train_csv)
    te = pd.read_csv(test_csv)
    feat_cols = [c for c in tr.columns if c != "BM"]
    Xtr = tr[feat_cols].values.astype(float)
    ytr = tr["BM"].values.astype(float)
    Xte = te[feat_cols].values.astype(float)
    yte = te["BM"].values.astype(float)

    params = model_params or {}
    model_type = model_type.lower()

    needs_scaling = model_type in ("lasso", "ridge", "elastic_net", "linear", "knn")
    if needs_scaling:
        m = Xtr.mean(0); s = Xtr.std(0); s[s == 0] = 1
        Xtr_use = (Xtr - m) / s
        Xte_use = (Xte - m) / s
    else:
        Xtr_use = Xtr; Xte_use = Xte
        m = np.zeros(Xtr.shape[1]); s = np.ones(Xtr.shape[1])

    if model_type == "lasso":
        from sklearn.linear_model import Lasso
        model = Lasso(**({"alpha": 0.001, "max_iter": 50000, **params}))
    elif model_type == "ridge":
        from sklearn.linear_model import Ridge
        model = Ridge(**({"alpha": 1.0, **params}))
    elif model_type == "elastic_net":
        from sklearn.linear_model import ElasticNet
        model = ElasticNet(**({"alpha": 0.001, "l1_ratio": 0.5, "max_iter": 50000, **params}))
    elif model_type == "linear":
        from sklearn.linear_model import LinearRegression
        model = LinearRegression(**params)
    elif model_type == "random_forest":
        from sklearn.ensemble import RandomForestRegressor
        model = RandomForestRegressor(**({"n_estimators": 200, "random_state": 0, **params}))
    elif model_type == "xgboost":
        import xgboost
        model = xgboost.XGBRegressor(**({"n_estimators": 500, "learning_rate": 0.05,
                                          "max_depth": 6, "verbosity": 0,
                                          "random_state": 0, **params}))
    elif model_type == "knn":
        from sklearn.neighbors import KNeighborsRegressor
        model = KNeighborsRegressor(**({"n_neighbors": 5, **params}))
    else:
        return {"error": f"unknown model_type {model_type}"}

    model.fit(Xtr_use, ytr)
    pred_tr = model.predict(Xtr_use)
    pred_te = model.predict(Xte_use)

    def _safe_mape(y, p):
        mask = np.abs(y) > 1e-9
        if mask.sum() == 0: return float("nan")
        return float(np.mean(np.abs((y[mask] - p[mask]) / y[mask])) * 100)

    importance = None
    coef = None
    if hasattr(model, "feature_importances_"):
        importance = [round(float(x), 6) for x in model.feature_importances_]
    if hasattr(model, "coef_"):
        coef = [round(float(x), 6) for x in np.asarray(model.coef_).ravel()]

    state = {"model": model, "scaler_mean": m, "scaler_std": s,
            "feat_cols": feat_cols, "Xte": Xte_use, "yte": yte,
            "Xtr": Xtr_use, "ytr": ytr, "needs_scaling": needs_scaling,
            "model_type": model_type}
    blob = pickle.dumps(state)
    model_id = hashlib.md5(blob[:2000] + model_type.encode()).hexdigest()[:10]
    os.makedirs("/tmp/hea_models", exist_ok=True)
    with open(f"/tmp/hea_models/{model_id}.pkl", "wb") as f:
        f.write(blob)

    n_feat = Xtr.shape[1]
    n_train = len(ytr); n_test = len(yte)
    r2_tr = r2_score(ytr, pred_tr); r2_te = r2_score(yte, pred_te)
    adj_r2_tr = 1 - (1 - r2_tr) * (n_train - 1) / max(n_train - n_feat - 1, 1)
    adj_r2_te = 1 - (1 - r2_te) * (n_test - 1) / max(n_test - n_feat - 1, 1)

    return {
        "model_id": model_id,
        "model_type": model_type,
        "n_train": n_train,
        "n_test": n_test,
        "n_features": n_feat,
        "train": {
            "r2": round(float(r2_tr), 4),
            "adj_r2": round(float(adj_r2_tr), 4),
            "mse": round(float(mean_squared_error(ytr, pred_tr)), 4),
            "mae": round(float(mean_absolute_error(ytr, pred_tr)), 4),
            "mape": round(_safe_mape(ytr, pred_tr), 4),
        },
        "test": {
            "r2": round(float(r2_te), 4),
            "adj_r2": round(float(adj_r2_te), 4),
            "mse": round(float(mean_squared_error(yte, pred_te)), 4),
            "mae": round(float(mean_absolute_error(yte, pred_te)), 4),
            "mape": round(_safe_mape(yte, pred_te), 4),
        },
        "feature_importance_top10": (
            sorted([(feat_cols[i], importance[i]) for i in range(n_feat)],
                   key=lambda x: x[1], reverse=True)[:10]
            if importance is not None else None
        ),
        "coef_top10_abs": (
            sorted([(feat_cols[i], coef[i]) for i in range(n_feat)],
                   key=lambda x: abs(x[1]), reverse=True)[:10]
            if coef is not None else None
        ),
    }


@mcp.tool()
def cross_validate_bm(train_csv: str, model_type: str, n_folds: int = 5,
                       model_params: dict = None) -> dict:
    """K-fold cross-validation R2 on the training set only.

    Args:
        train_csv: training CSV path
        model_type: same options as train_bm_regressor
        n_folds: number of folds (default 5)

    Returns:
        dict with per-fold R2 plus mean and std.
    """
    import pandas as pd
    from sklearn.model_selection import KFold
    from sklearn.metrics import r2_score

    df = pd.read_csv(train_csv)
    feat_cols = [c for c in df.columns if c != "BM"]
    X = df[feat_cols].values.astype(float)
    y = df["BM"].values.astype(float)

    kf = KFold(n_splits=n_folds, shuffle=True, random_state=0)
    scores = []
    for fold, (tr, va) in enumerate(kf.split(X)):
        Xtr, ytr = X[tr], y[tr]
        Xva, yva = X[va], y[va]
        m = Xtr.mean(0); s = Xtr.std(0); s[s == 0] = 1
        Xtrs = (Xtr - m) / s; Xvas = (Xva - m) / s
        params = model_params or {}
        mt = model_type.lower()
        if mt == "lasso":
            from sklearn.linear_model import Lasso
            model = Lasso(**({"alpha": 0.001, "max_iter": 50000, **params}))
        elif mt == "ridge":
            from sklearn.linear_model import Ridge
            model = Ridge(**({"alpha": 1.0, **params}))
        elif mt == "elastic_net":
            from sklearn.linear_model import ElasticNet
            model = ElasticNet(**({"alpha": 0.001, "l1_ratio": 0.5,
                                   "max_iter": 50000, **params}))
        elif mt == "linear":
            from sklearn.linear_model import LinearRegression
            model = LinearRegression(**params)
        elif mt == "random_forest":
            from sklearn.ensemble import RandomForestRegressor
            model = RandomForestRegressor(**({"n_estimators": 200,
                                              "random_state": 0, **params}))
            Xtrs, Xvas = Xtr, Xva
        elif mt == "xgboost":
            import xgboost
            model = xgboost.XGBRegressor(**({"n_estimators": 500,
                                              "learning_rate": 0.05,
                                              "max_depth": 6, "verbosity": 0,
                                              "random_state": 0, **params}))
            Xtrs, Xvas = Xtr, Xva
        elif mt == "knn":
            from sklearn.neighbors import KNeighborsRegressor
            model = KNeighborsRegressor(**({"n_neighbors": 5, **params}))
        else:
            return {"error": f"unknown model_type {mt}"}
        model.fit(Xtrs, ytr)
        pred = model.predict(Xvas)
        scores.append(float(r2_score(yva, pred)))
    return {"model_type": model_type, "n_folds": n_folds,
            "fold_r2": [round(s, 4) for s in scores],
            "mean_r2": round(float(np.mean(scores)), 4),
            "std_r2": round(float(np.std(scores)), 4)}


# ---------------------------------------------------------------------------
# 6. Plotting
# ---------------------------------------------------------------------------
@mcp.tool()
def plot_predicted_vs_actual(model_id: str,
                              output_path: str = "artifacts/Fig7_lasso_pred_vs_actual.png",
                              title: str = "Predicted vs Actual Bulk Modulus") -> dict:
    """Scatter of predicted vs actual BM with a y=x reference line and
    a least-squares best-fit line annotated with its slope and intercept.

    Args:
        model_id: from train_bm_regressor
        output_path: PNG path
        title: figure title

    Returns:
        dict with output_path, slope, intercept, n_points
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    with open(f"/tmp/hea_models/{model_id}.pkl", "rb") as f:
        st = pickle.load(f)
    model = st["model"]
    pred = model.predict(st["Xte"])
    actual = st["yte"]

    slope, intercept = np.polyfit(actual, pred, 1)
    fig, ax = plt.subplots(figsize=(7, 6))
    ax.scatter(actual, pred, alpha=0.6, s=18, label="Data points")
    xs = np.array([actual.min(), actual.max()])
    ax.plot(xs, slope * xs + intercept, "-",
            label=f"Best Linear Fit: y={slope:.2f}x+{intercept:.2f}")
    ax.set_xlabel("Actual Bulk Modulus of HEAs (GPa)")
    ax.set_ylabel("Predicted Bulk Modulus of HEAs (GPa)")
    ax.set_title(title)
    ax.legend()
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"output_path": output_path,
            "slope": round(float(slope), 4),
            "intercept": round(float(intercept), 4),
            "n_points": int(len(actual))}


@mcp.tool()
def plot_model_comparison(results: list, metric: str = "r2",
                          output_path: str = "artifacts/Fig_model_comparison.png") -> dict:
    """Bar chart of test-set metric across regression models.

    Args:
        results: list of dicts each with 'model_type' and a 'test' subdict
                 (output rows from train_bm_regressor)
        metric: 'r2', 'adj_r2', 'mse', 'mae', or 'mape'
        output_path: PNG path

    Returns:
        dict with output_path and the sorted list of (model, value) pairs.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    pairs = []
    for r in results:
        v = r.get("test", {}).get(metric)
        if v is None: continue
        pairs.append((r.get("model_type", "?"), float(v)))
    if not pairs:
        return {"error": "no valid results"}
    rev = metric in ("r2", "adj_r2")
    pairs.sort(key=lambda x: x[1], reverse=rev)
    labels = [p[0] for p in pairs]; values = [p[1] for p in pairs]
    fig, ax = plt.subplots(figsize=(8, 5))
    bars = ax.bar(labels, values, color="#3a7bd5")
    for b, v in zip(bars, values):
        ax.text(b.get_x() + b.get_width()/2, v, f"{v:.3f}",
                ha="center", va="bottom", fontsize=9)
    ax.set_xlabel("Model")
    ax.set_ylabel(metric)
    ax.set_title(f"BM regressors compared by test-set {metric}")
    plt.xticks(rotation=20)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"output_path": output_path,
            "ordered": [{"model": m, metric: round(v, 4)} for m, v in pairs]}


@mcp.tool()
def plot_element_recurrence(train_csv: str, top_k: int = 10,
                              output_path: str = "artifacts/Fig1_element_weightage.png") -> dict:
    """Treemap-style horizontal bar chart of how often each element appears
    (non-zero atomic fraction) across all alloys in the dataset.

    Args:
        train_csv: HEA training CSV path
        top_k: number of top elements to label individually (rest grouped)
        output_path: PNG path

    Returns:
        dict with output_path and the top-k counts.
    """
    import pandas as pd
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    df = pd.read_csv(train_csv)
    elem_cols = [c for c in df.columns if c not in ("AM", "IM", "SS", "BM")]
    counts = (df[elem_cols] > 0).sum().sort_values(ascending=False)
    total_nonzero = int(counts.sum())
    top = counts.head(top_k)
    rest_n = int(counts.iloc[top_k:].sum())
    rest_elems = int((counts.iloc[top_k:] > 0).sum())
    labels = list(top.index) + [f"Others ({rest_elems} Elements)"]
    values = list(top.values) + [rest_n]
    pct = [v / total_nonzero * 100 for v in values]

    fig, ax = plt.subplots(figsize=(10, 4))
    ypos = np.arange(len(labels))[::-1]
    ax.barh(ypos, pct, color=[
        "#7fbf3f", "#5fa8d3", "#a8a8a8", "#7d97c2",
        "#e8a87c", "#bfd8b8", "#bfbfbf", "#f7e07c",
        "#e07c5f", "#3f8f3f", "#cccccc"][:len(labels)])
    ax.set_yticks(ypos)
    ax.set_yticklabels([f"{l} ({p:.1f}%)" for l, p in zip(labels, pct)])
    ax.set_xlabel("% of recurrence in dataset")
    ax.set_title(f"Recurrence weightage of elements (top {top_k} + others)")
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"output_path": output_path,
            "total_nonzero_entries": total_nonzero,
            "top_counts": [{"element": e, "count": int(c),
                            "pct": round(float(c) / total_nonzero * 100, 2)}
                           for e, c in top.items()]}


if __name__ == "__main__":
    mcp.run(transport="stdio")

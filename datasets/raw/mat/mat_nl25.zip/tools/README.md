# mat_nl25 — Tool Reference

**MCP server runtime**: only `tools/cra_nlp_tools.py` is the MCP server.
`database_retrieval.py` and `data_processing.py` are plain Python helpers
meant to be imported by the server module; they are NOT standalone MCP
servers and should not be launched as such.

**Grading note**: `kfold_train_eval` is a SIMPLIFIED GradientBoosting
surrogate for the paper's LSTM/DNN; `optimize_composition` is a
random-forest finite-difference proxy for the paper's gradient-descent
optimisation; both are graded on QUALITATIVE direction only — absolute
MAE/R² and final-composition values are not expected to match the
paper. `atomic_packing_efficiency` is a directional descriptor only;
do not compare its absolute values to published Senkov-Miracle APE.

## Database Retrieval (`database_retrieval.py`) — import-only utility module
Generic web/database lookup primitives (web search, HTTP fetch, PubChem,
ChEMBL, NCBI, OpenAlex, etc.). Stubs to be filled with the appropriate
client at runtime. **Not a standalone MCP server**: this file is plain
Python helpers meant to be imported, not run as `python tools/database_retrieval.py`.

## Data Processing (`data_processing.py`) — import-only utility module
Generic format readers/writers (CSV, JSON, Excel, parquet, NetCDF,
shapefile, FASTA), pivot/aggregation primitives. Domain-agnostic.
**Not a standalone MCP server**: this file is plain Python helpers meant
to be imported, not run as `python tools/data_processing.py`.

## Domain Primitives (`cra_nlp_tools.py`) — only this file is the MCP server
Low-level building blocks for NLP-augmented corrosion-resistant alloy
modelling. Each function is a single primitive — the agent decides how to
chain them.

### Composition + descriptor primitives
- **load_cra_dataset**: read the CRA pitting-potential CSV and return
  shape, columns, per-class counts, target stats.
- **lookup_element_property**: tabulated `atomic_radius_pm`,
  `electronegativity` (Pauling), `atomic_weight` for Fe, Cr, Ni, Mo, W,
  N, Nb, C, Si, Mn, Cu, P, S, Al, V, Ta, Re, Ce, Ti, Co, B, Mg, Y, Gd,
  Sc, Zr.
- **wt_to_at**: weight-fraction → atomic-fraction conversion.
- **configurational_entropy**: ideal `S_conf/R = -Σ x ln x`.
- **yang_radii_delta**: Yang `δ = √(Σ x_i (1 - r_i / r_avg)²)`.
- **electronegativity_delta**: `δχ = √(Σ x_i (χ_i - χ_avg)²)`.
- **atomic_packing_efficiency**: SIMPLIFIED packing score using a
  `(1 − |r_s/r_c − 0.902|)` weighted sum (NOT the standard Senkov-Miracle
  APE; see the docstring caveat). Directional proxy only.
- **compute_descriptors_for_dataframe**: batch-compute APE / S_conf /
  Yang δ / χ δ for every row of the dataset.

### NLP primitives
- **custom_text_standardize**: lower-case + strip punctuation + map
  `'-1'` → `'na'` (matches the paper's `custom_standardization`).
- **build_text_vocabulary**: integer-token vocabulary for a textual
  column (TestMethod, HeatTreatment, Comments, ScanRate). Default cap
  10 000 tokens.
- **vectorize_text_column**: pad/truncate text rows into an
  `(n, sequence_length)` integer array using the saved vocabulary.

### Process-aware DNN
- **build_process_aware_model**: returns the JSON spec of the
  Embedding(64) → LSTM(32) text branch concatenated with the numeric
  branch and Dense(64,64,32,1) head; mirrors Sasidhar et al. 2023.
- **kfold_train_eval**: six-fold cross-validation with optional
  textual features. NOTE: this is a SIMPLIFIED gradient-boosting
  regressor (sklearn GradientBoostingRegressor) over numeric features
  plus text-length proxies (length, word count) — it is NOT a
  reproduction of the Sasidhar et al. 2022 simple DNN nor of the
  Sasidhar et al. 2023 LSTM-augmented DNN. Use the text-features-on
  vs text-features-off contrast for the qualitative direction only.

### Composition optimization
- **fit_surrogate_regressor**: random-forest surrogate on numeric
  features for finite-difference gradient ascent.
- **optimize_composition**: gradient-ascent on the surrogate to push
  predicted Epit upward while keeping environmental inputs fixed.
- **predict_grid_epit**: 2-D composition grid evaluation (e.g. for the
  Al-Cu-Sc-Zr extrapolation map of Fig. 6).

### Plotting (one figure per call)
- **plot_kfold_metrics**: bar comparison of MAE / R² between the
  text-incorporated and text-ablated runs.
- **plot_optimization_trajectory**: composition vs optimisation step.
- **plot_descriptor_trajectory**: APE / S_conf / δ / δχ evolution.
- **plot_alcu_sczr_grid**: heat-map of predicted Epit on a 2-D grid.

## Dependencies
`numpy`, `pandas`, `scikit-learn`, `matplotlib`, `openpyxl`, `mcp[cli]`.
Optional (for full-fidelity training): `tensorflow`, `tensorflow-addons`,
`keras`. The provided primitives use scikit-learn so the harness can
run end-to-end without GPU.

## Quick start
```python
from cra_nlp_tools import (
    load_cra_dataset, build_text_vocabulary, vectorize_text_column,
    kfold_train_eval, compute_descriptors_for_dataframe,
    fit_surrogate_regressor, optimize_composition, predict_grid_epit,
    plot_kfold_metrics, plot_optimization_trajectory,
    plot_descriptor_trajectory, plot_alcu_sczr_grid,
)
info  = load_cra_dataset("input_data/data/cra_pitting_potential.csv")
voc   = build_text_vocabulary("input_data/data/cra_pitting_potential.csv",
                              "TestMethod")
seq   = vectorize_text_column("input_data/data/cra_pitting_potential.csv",
                              voc["output_path"], "TestMethod")
m_with = kfold_train_eval("input_data/data/cra_pitting_potential.csv")
m_no   = kfold_train_eval("input_data/data/cra_pitting_potential.csv",
                          text_features=[])
sur    = fit_surrogate_regressor("input_data/data/cra_pitting_potential.csv")
opt    = optimize_composition({"Fe": 67, "Cr": 25, "Ni": 5.5, "Mo": 2.5})
plot_kfold_metrics(m_with, m_no)
plot_optimization_trajectory(opt["history"])
```

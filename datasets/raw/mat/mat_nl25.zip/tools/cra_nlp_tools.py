#!/usr/bin/env python3
"""Low-level primitives for NLP-augmented corrosion-resistant alloy modelling.

These functions are domain primitives: composition / textual feature handling,
elemental-property lookup, vocabulary tokenization, sequence vectorization,
process-aware regression model training, gradient-based composition
optimization, and plotting. The agent decides how to chain them.
"""
import os
import re
import json
import pickle
import string
from typing import Optional

import numpy as np
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("CRA_NLP_Tools")


# ---------------------------------------------------------------------------
# Element property table:
#   atomic_radius_pm   : Yang/Goldschmidt 12-coordinated metallic radius (pm)
#   electronegativity  : Pauling scale
#   atomic_weight      : g/mol
# Numbers from standard handbook tables and Senkov-Miracle compilation.
# Used for primitive descriptor expansion (APE, electronegativity-delta,
# Yang-radii-delta, configurational entropy).
# ---------------------------------------------------------------------------
ELEMENT_PROPS = {
    "Fe": (126, 1.83, 55.845),
    "Cr": (128, 1.66, 51.9961),
    "Ni": (124, 1.91, 58.6934),
    "Mo": (139, 2.16, 95.95),
    "W":  (139, 2.36, 183.84),
    "N":  ( 75, 3.04, 14.007),
    "Nb": (146, 1.60, 92.906),
    "C":  ( 77, 2.55, 12.011),
    "Si": (117, 1.90, 28.086),
    "Mn": (127, 1.55, 54.938),
    "Cu": (128, 1.90, 63.546),
    "P":  (110, 2.19, 30.974),
    "S":  (104, 2.58, 32.06),
    "Al": (143, 1.61, 26.982),
    "V":  (134, 1.63, 50.9415),
    "Ta": (146, 1.50, 180.95),
    "Re": (137, 1.90, 186.207),
    "Ce": (181, 1.12, 140.116),
    "Ti": (147, 1.54, 47.867),
    "Co": (125, 1.88, 58.9332),
    "B":  ( 82, 2.04, 10.811),
    "Mg": (160, 1.31, 24.305),
    "Y":  (180, 1.22, 88.906),
    "Gd": (180, 1.20, 157.25),
    "Sc": (162, 1.36, 44.956),
    "Zr": (160, 1.33, 91.224),
}

ELEMENTAL_COLUMNS = [
    "Fe","Cr","Ni","Mo","W","N","Nb","C","Si","Mn","Cu","P","S","Al",
    "V","Ta","Re","Ce","Ti","Co","B","Mg","Y","Gd"
]
TEXT_COLUMNS = ["TestMethod", "ScanRate", "HeatTreatment", "Comments"]
CATEGORICAL_COLUMNS = ["TestSolution", "Microstructures", "MaterialClass"]
NUMERIC_ENV_COLUMNS = ["TestTemp","ClM","pH"]
TARGET_COL = "Avg_Epit_mV"


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------
@mcp.tool()
def load_cra_dataset(csv_path: str) -> dict:
    """Load the CRA pitting-potential dataset.

    Returns shape, column list, per-class record counts, target value range,
    and the elemental columns / text columns the dataset carries.

    Args:
        csv_path: path to cra_pitting_potential.csv
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    res = {
        "shape": list(df.shape),
        "columns": list(df.columns),
        "elemental_columns": [c for c in ELEMENTAL_COLUMNS if c in df.columns],
        "text_columns": [c for c in TEXT_COLUMNS if c in df.columns],
        "target_column": TARGET_COL,
        "target_range": [
            round(float(df[TARGET_COL].min()), 2),
            round(float(df[TARGET_COL].max()), 2),
        ],
        "target_mean": round(float(df[TARGET_COL].mean()), 2),
        "target_std":  round(float(df[TARGET_COL].std()), 2),
    }
    if "MaterialClass" in df.columns:
        res["class_counts"] = df["MaterialClass"].value_counts().to_dict()
    return res


@mcp.tool()
def lookup_element_property(symbol: str, prop: str) -> dict:
    """Tabulated physical/chemical property for an element.

    Args:
        symbol: element symbol (e.g. 'Fe')
        prop:   one of {'atomic_radius_pm','electronegativity','atomic_weight'}
    """
    if symbol not in ELEMENT_PROPS:
        return {"error": f"unknown element {symbol}"}
    fields = ["atomic_radius_pm","electronegativity","atomic_weight"]
    if prop not in fields:
        return {"error": f"unknown property {prop}"}
    return {"symbol": symbol, "property": prop,
            "value": ELEMENT_PROPS[symbol][fields.index(prop)]}


@mcp.tool()
def wt_to_at(wt_fractions: dict) -> dict:
    """Convert weight % (or weight-fraction) to atomic (mole) fractions.

    Accepts sums close to 1 (fractions) or 100 (percent).
    """
    total = sum(float(v) for v in wt_fractions.values())
    if total > 1.5:
        wt_fractions = {k: float(v) / 100.0 for k, v in wt_fractions.items()}
    moles = {}
    for sym, w in wt_fractions.items():
        if sym not in ELEMENT_PROPS or w <= 0:
            continue
        moles[sym] = float(w) / ELEMENT_PROPS[sym][2]
    s = sum(moles.values())
    if s == 0:
        return {"error": "no valid element fractions"}
    return {k: round(v / s, 6) for k, v in moles.items()}


# ---------------------------------------------------------------------------
# Composition descriptors used in the paper's "feature transformed DNN"
# ---------------------------------------------------------------------------
@mcp.tool()
def configurational_entropy(at_fractions: dict) -> dict:
    """Ideal configurational entropy S_conf / R = -sum(x ln x).

    Returns S_conf in units of R; multiply by 8.314 J/mol/K for SI.
    """
    s = 0.0
    for x in at_fractions.values():
        x = float(x)
        if x > 0:
            s += -x * np.log(x)
    return {"S_conf_R": round(float(s), 6)}


@mcp.tool()
def yang_radii_delta(at_fractions: dict) -> dict:
    """Yang's atomic-radii mismatch δ.

        δ = sqrt( sum_i x_i (1 - r_i/r_avg)^2 )

    where r_avg = sum_i x_i r_i.  Output in % (×100).
    """
    syms, xs, rs = [], [], []
    for sym, x in at_fractions.items():
        x = float(x)
        if sym in ELEMENT_PROPS and x > 0:
            syms.append(sym); xs.append(x)
            rs.append(ELEMENT_PROPS[sym][0])
    if not xs:
        return {"error": "no valid elements"}
    xs = np.array(xs); rs = np.array(rs, dtype=float)
    xs = xs / xs.sum()
    r_avg = float((xs * rs).sum())
    delta = float(np.sqrt(((xs * (1 - rs / r_avg) ** 2).sum())))
    return {"r_avg_pm": round(r_avg, 4),
            "delta_pct": round(delta * 100, 4),
            "elements": syms}


@mcp.tool()
def electronegativity_delta(at_fractions: dict) -> dict:
    """Pauling electronegativity mismatch δχ = sqrt(sum_i x_i (χ_i - χ_avg)^2)."""
    syms, xs, chs = [], [], []
    for sym, x in at_fractions.items():
        x = float(x)
        if sym in ELEMENT_PROPS and x > 0:
            syms.append(sym); xs.append(x)
            chs.append(ELEMENT_PROPS[sym][1])
    if not xs:
        return {"error": "no valid elements"}
    xs = np.array(xs); chs = np.array(chs, dtype=float)
    xs = xs / xs.sum()
    ch_avg = float((xs * chs).sum())
    dchi = float(np.sqrt(((xs * (chs - ch_avg) ** 2).sum())))
    return {"chi_avg": round(ch_avg, 4),
            "chi_delta": round(dchi, 4),
            "elements": syms}


@mcp.tool()
def atomic_packing_efficiency(at_fractions: dict, central: str = None) -> dict:
    """Mean atomic packing efficiency (APE) — SIMPLIFIED proxy.

    NOTE: This is a SIMPLIFIED packing score, NOT the standard
    Senkov-Miracle APE. It uses a `(1 − |r_s/r_c − 0.902|)` weighted sum
    over composition, not the geometric atomic-packing-fraction formula
    `APE = (sum_atoms volumes) / (cluster volume)` of Miracle (Acta Mater.
    2017) and Senkov-Miracle. The ideal Friedel radius ratio 0.902 is
    only used as a target point; the returned value should be interpreted
    as a directional descriptor (closer-to-ideal pairs score higher), not
    a true packing fraction. Use the qualitative sign/trend only — do not
    compare absolute values to published Senkov-Miracle APE numbers.

    For a multicomponent alloy the paper reports the *mean* APE across
    central-element choices.  Here we approximate the APE deviation from
    the ideal Friedel ratio (r_c / r_s ≈ 0.902) for every element pair
    weighted by composition, returning the deviation from 1.

    Args:
        at_fractions: atomic-fraction dict
        central: optional fixed central element. If None, mean over all.
    """
    syms, xs, rs = [], [], []
    for sym, x in at_fractions.items():
        x = float(x)
        if sym in ELEMENT_PROPS and x > 0:
            syms.append(sym); xs.append(x)
            rs.append(ELEMENT_PROPS[sym][0])
    if not xs:
        return {"error": "no valid elements"}
    xs = np.array(xs); rs = np.array(rs, dtype=float)
    xs = xs / xs.sum()
    ideal = 0.902  # Senkov ideal ratio
    apes = []
    centrals = [central] if central else syms
    for c in centrals:
        if c not in syms:
            continue
        rc = ELEMENT_PROPS[c][0]
        ape_c = 0.0
        for s, xs_, rs_ in zip(syms, xs, rs):
            if s == c:
                continue
            ratio = rs_ / rc
            ape_c += xs_ * (1.0 - abs(ratio - ideal))
        apes.append(ape_c)
    return {"APE_mean": round(float(np.mean(apes)) if apes else 0.0, 6),
            "APE_per_central": {c: round(a, 6) for c, a in zip(centrals, apes)},
            "n_elements": len(syms)}


@mcp.tool()
def compute_descriptors_for_dataframe(csv_path: str,
                                      output_csv: str = "/tmp/cra_descriptors.csv"
                                      ) -> dict:
    """Add APE, configurational-entropy, Yang radii δ, and electronegativity δ
    columns to every row of the CRA dataset.

    Numeric elemental wt% are first converted to atomic fractions row-wise.
    """
    import pandas as pd
    df = pd.read_csv(csv_path).copy()
    cols = [c for c in ELEMENTAL_COLUMNS if c in df.columns]
    out = []
    for _, row in df.iterrows():
        wt = {c: float(row[c]) for c in cols if not np.isnan(float(row[c])) and float(row[c]) > 0}
        if not wt:
            out.append({"S_conf_R": np.nan, "APE_mean": np.nan,
                        "yang_delta": np.nan, "chi_delta": np.nan})
            continue
        at = {}
        s = sum(w / ELEMENT_PROPS[k][2] for k, w in wt.items() if k in ELEMENT_PROPS)
        for k, w in wt.items():
            if k in ELEMENT_PROPS:
                at[k] = (w / ELEMENT_PROPS[k][2]) / s
        sc = configurational_entropy(at)["S_conf_R"]
        ape = atomic_packing_efficiency(at)["APE_mean"]
        yd = yang_radii_delta(at).get("delta_pct", np.nan)
        cd = electronegativity_delta(at).get("chi_delta", np.nan)
        out.append({"S_conf_R": sc, "APE_mean": ape,
                    "yang_delta": yd, "chi_delta": cd})
    desc_df = pd.DataFrame(out)
    full = pd.concat([df.reset_index(drop=True), desc_df], axis=1)
    full.to_csv(output_csv, index=False)
    return {"output_csv": output_csv,
            "n_rows": len(full),
            "added_columns": list(desc_df.columns),
            "stats": {c: {"mean": round(float(desc_df[c].mean(skipna=True)), 4),
                          "std":  round(float(desc_df[c].std(skipna=True)), 4)}
                      for c in desc_df.columns}}


# ---------------------------------------------------------------------------
# NLP primitives — tokenization + sequence vectorization
# ---------------------------------------------------------------------------
@mcp.tool()
def custom_text_standardize(text: str) -> dict:
    """Lower-case, replace '-1' with 'na', and strip punctuation.

    Reproduces the standardisation used by the paper's TextVectorization
    layer (custom_standardization function in the published code).
    """
    if text is None:
        return {"clean": ""}
    s = str(text).lower()
    s = re.sub("-1", "na", s)
    s = re.sub("[%s]" % re.escape(string.punctuation), "", s)
    return {"clean": s}


@mcp.tool()
def build_text_vocabulary(csv_path: str, text_column: str,
                          vocab_size: int = 10000,
                          output_path: str = "/tmp/cra_vocab.json") -> dict:
    """Construct an integer-token vocabulary for a textual feature column.

    Tokens are space-separated words after `custom_text_standardize`. The
    most frequent `vocab_size` tokens are kept; rarer tokens map to the
    out-of-vocabulary index 1, the padding index is 0.

    Args:
        csv_path:    cra_pitting_potential.csv path
        text_column: column to tokenize (TestMethod, HeatTreatment, etc.)
        vocab_size:  cap on dictionary size
        output_path: where to dump vocab JSON
    """
    import pandas as pd
    from collections import Counter
    df = pd.read_csv(csv_path)
    counts = Counter()
    for v in df[text_column].fillna("").astype(str).tolist():
        clean = custom_text_standardize(v)["clean"]
        counts.update(clean.split())
    most = counts.most_common(max(0, vocab_size - 2))
    vocab = {"": 0, "<oov>": 1}
    for i, (w, _) in enumerate(most, start=2):
        vocab[w] = i
    with open(output_path, "w") as f:
        json.dump({"vocab": vocab, "column": text_column}, f)
    return {"output_path": output_path,
            "vocab_size": len(vocab),
            "n_unique_tokens_seen": len(counts),
            "top_10_tokens": [w for w, _ in most[:10]]}


@mcp.tool()
def vectorize_text_column(csv_path: str, vocab_path: str,
                          text_column: str,
                          sequence_length: int = 200,
                          output_path: str = "/tmp/cra_seq.npz") -> dict:
    """Convert a textual column to a (n_samples, sequence_length) integer
    array using the vocabulary built by build_text_vocabulary.

    Sequences are padded/truncated to `sequence_length`.
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    with open(vocab_path) as f:
        vocab = json.load(f)["vocab"]
    seqs = []
    for v in df[text_column].fillna("").astype(str).tolist():
        clean = custom_text_standardize(v)["clean"]
        toks = [vocab.get(t, 1) for t in clean.split()][:sequence_length]
        toks += [0] * (sequence_length - len(toks))
        seqs.append(toks)
    arr = np.array(seqs, dtype=np.int32)
    np.savez_compressed(output_path, X=arr)
    return {"output_path": output_path,
            "shape": list(arr.shape),
            "max_token_index": int(arr.max()),
            "fraction_padding": round(float((arr == 0).mean()), 4)}


# ---------------------------------------------------------------------------
# Process-aware DNN — Keras model factory
# ---------------------------------------------------------------------------
@mcp.tool()
def build_process_aware_model(n_numeric: int,
                              n_text_cols: int,
                              vocab_size: int = 10000,
                              embedding_dim: int = 64,
                              lstm_units: int = 32,
                              hidden_units: list = None,
                              dropout: float = 0.5,
                              sequence_length: int = 200) -> dict:
    """Specification (not weights) for the process-aware DNN.

    Mirrors Sasidhar et al. 2023: each text column passes through
    Embedding(64) -> LSTM(32); LSTM outputs are concatenated with the
    numeric inputs, then fed through Dense(64,relu) -> Dropout ->
    Dense(64,relu) -> Dropout -> Dense(32,relu) -> Dropout -> Dense(1).
    Returned as a JSON spec so a model can be instantiated by either Keras
    or PyTorch at execution time.

    Args:
        n_numeric:  number of numeric input features
        n_text_cols: number of textual feature columns
        vocab_size: tokenizer dictionary size
        embedding_dim: word-embedding dimensionality
        lstm_units: LSTM output dimension per text column
        hidden_units: dense hidden layer sizes; default [64,64,32]
        dropout: dropout rate after each dense layer
        sequence_length: token-sequence length per text column
    """
    if hidden_units is None:
        hidden_units = [64, 64, 32]
    spec = {
        "numeric_input_dim": int(n_numeric),
        "text_columns": int(n_text_cols),
        "embedding": {"vocab_size": int(vocab_size),
                      "dim": int(embedding_dim),
                      "sequence_length": int(sequence_length)},
        "lstm_units": int(lstm_units),
        "concat_dim": int(n_numeric + n_text_cols * lstm_units),
        "dense_layers": [int(u) for u in hidden_units],
        "dropout": float(dropout),
        "output_dim": 1,
        "loss": "mae",
        "optimizer": {"name": "Adam", "lr": 0.001},
    }
    return spec


@mcp.tool()
def kfold_train_eval(csv_path: str,
                     numeric_features: list = None,
                     text_features: list = None,
                     target_column: str = "Avg_Epit_mV",
                     n_splits: int = 6,
                     n_estimators: int = 200,
                     random_state: int = 0) -> dict:
    """Six-fold cross-validation regression on the CRA dataset.

    A gradient-boosted regressor over the numeric+(text length) features
    plus simple text-length proxies is fit per fold; per-fold MAE and R²
    are returned.  This is a *SIMPLIFIED SURROGATE* for the paper's
    process-aware DNN (Sasidhar et al. 2023 LSTM + dense head architecture)
    that lets the agent quickly compare against a numeric-only baseline
    (text ablation) without instantiating Keras inside the harness. Grade
    on the QUALITATIVE direction (text-aware better than numeric-only,
    or not) — absolute MAE / R² numbers from this GBR proxy are NOT
    expected to match the paper's published LSTM-DNN values.

    Args:
        csv_path:        cra_pitting_potential.csv path
        numeric_features: numeric columns. Defaults to elemental wt% +
                          environmental columns.
        text_features:    text columns to include via length/word-count
                          surrogates.  Pass [] to ablate textual data and
                          obtain the simple-DNN baseline behaviour.
        target_column:    target column name
        n_splits:         number of CV folds (paper uses 6)
        n_estimators:     trees per GBM
        random_state:     seed
    """
    import pandas as pd
    from sklearn.ensemble import GradientBoostingRegressor
    from sklearn.model_selection import KFold
    df = pd.read_csv(csv_path)
    if numeric_features is None:
        numeric_features = [c for c in ELEMENTAL_COLUMNS + NUMERIC_ENV_COLUMNS
                            if c in df.columns]
    if text_features is None:
        text_features = [c for c in TEXT_COLUMNS if c in df.columns]

    X_num = df[numeric_features].fillna(0).to_numpy(dtype=float)
    X_txt = []
    for c in text_features:
        col = df[c].fillna("").astype(str)
        X_txt.append(col.str.split().apply(len).to_numpy().reshape(-1, 1))
        X_txt.append(col.str.len().to_numpy().reshape(-1, 1))
    X = np.hstack([X_num] + X_txt) if X_txt else X_num
    y = df[target_column].to_numpy(dtype=float)

    kf = KFold(n_splits=n_splits, shuffle=True, random_state=random_state)
    fold_metrics = []
    for k, (tr, te) in enumerate(kf.split(X)):
        m = GradientBoostingRegressor(n_estimators=n_estimators,
                                      max_depth=3,
                                      learning_rate=0.05,
                                      random_state=random_state + k)
        m.fit(X[tr], y[tr])
        yp = m.predict(X[te])
        mae = float(np.mean(np.abs(y[te] - yp)))
        ss_res = float(((y[te] - yp) ** 2).sum())
        ss_tot = float(((y[te] - y[te].mean()) ** 2).sum())
        r2 = 1 - ss_res / ss_tot if ss_tot > 0 else float("nan")
        fold_metrics.append({"fold": k + 1,
                              "mae_mV": round(mae, 2),
                              "r2": round(r2, 4),
                              "n_test": int(len(te))})
    mae_arr = np.array([f["mae_mV"] for f in fold_metrics])
    r2_arr = np.array([f["r2"] for f in fold_metrics])
    return {"per_fold": fold_metrics,
            "mean_mae_mV": round(float(mae_arr.mean()), 2),
            "std_mae_mV":  round(float(mae_arr.std()), 2),
            "mean_r2":     round(float(r2_arr.mean()), 4),
            "std_r2":      round(float(r2_arr.std()), 4),
            "n_features":  X.shape[1],
            "with_text":   bool(text_features),
            "numeric_feature_names": list(numeric_features),
            "text_feature_names":    list(text_features) if text_features else []}


# ---------------------------------------------------------------------------
# Composition optimization (gradient ascent on a trained surrogate)
# ---------------------------------------------------------------------------
@mcp.tool()
def fit_surrogate_regressor(csv_path: str,
                            numeric_features: list = None,
                            target_column: str = "Avg_Epit_mV",
                            random_state: int = 0,
                            output_path: str = "/tmp/cra_surrogate.pkl"
                            ) -> dict:
    """Fit a single random-forest surrogate over numeric features for use
    as a differentiable proxy in `optimize_composition`."""
    import pandas as pd
    from sklearn.ensemble import RandomForestRegressor
    df = pd.read_csv(csv_path)
    if numeric_features is None:
        numeric_features = [c for c in ELEMENTAL_COLUMNS + NUMERIC_ENV_COLUMNS
                            if c in df.columns]
    X = df[numeric_features].fillna(0).to_numpy(dtype=float)
    y = df[target_column].to_numpy(dtype=float)
    m = RandomForestRegressor(n_estimators=200, max_depth=None,
                              random_state=random_state)
    m.fit(X, y)
    with open(output_path, "wb") as f:
        pickle.dump({"model": m, "features": numeric_features,
                     "target": target_column}, f)
    yp = m.predict(X)
    rmse = float(np.sqrt(np.mean((y - yp) ** 2)))
    r2 = 1 - float(((y - yp) ** 2).sum()) / float(((y - y.mean()) ** 2).sum())
    return {"output_path": output_path,
            "n_features": len(numeric_features),
            "in_sample_rmse_mV": round(rmse, 2),
            "in_sample_r2": round(r2, 4)}


@mcp.tool()
def optimize_composition(initial_composition: dict,
                         model_path: str = "/tmp/cra_surrogate.pkl",
                         n_steps: int = 200,
                         lr: float = 0.05,
                         fixed_env: dict = None,
                         element_set: list = None) -> dict:
    """Numerical optimisation (finite-difference gradient ascent) of the
    surrogate model's predicted Epit, varying the elemental composition
    while keeping environmental inputs fixed.

    SIMPLIFIED PROXY: mirrors the paper's gradient-descent composition
    optimisation, but uses a random-forest surrogate + finite-difference
    gradient because RFs are not differentiable in closed form. The
    optimisation trajectory and final composition therefore depend on the
    bundled surrogate, the finite-difference step size, and the data
    subset; grade on the QUALITATIVE elemental direction (which elements
    increase, which decrease) for the targeted alloy class rather than on
    the exact optimised composition vector. Composition is renormalised
    to sum to 100 wt% after every step and clamped to [0, 100].

    Args:
        initial_composition: {element: wt%}
        model_path:          surrogate pickle from fit_surrogate_regressor
        n_steps:             optimisation steps
        lr:                  step size in wt% per step
        fixed_env:           {TestTemp, ClM, pH} (optional; defaults
                              25 oC / 0.6 M Cl- / pH 6.5)
        element_set:         elements allowed to vary (default: all in
                              initial composition)
    """
    with open(model_path, "rb") as f:
        cache = pickle.load(f)
    model = cache["model"]
    feats = cache["features"]
    if fixed_env is None:
        fixed_env = {"TestTemp": 25.0, "ClM": 0.6, "pH": 6.5}

    x = np.zeros(len(feats))
    for i, c in enumerate(feats):
        if c in initial_composition:
            x[i] = float(initial_composition[c])
        elif c in fixed_env:
            x[i] = float(fixed_env[c])
    if element_set is None:
        element_set = [k for k in initial_composition.keys()
                       if k in feats and k in ELEMENTAL_COLUMNS]
    var_idx = [feats.index(c) for c in element_set if c in feats]

    history = []
    for step in range(n_steps):
        y0 = float(model.predict(x.reshape(1, -1))[0])
        history.append({"step": step,
                        "Epit_mV": round(y0, 2),
                        "composition": {c: round(float(x[feats.index(c)]), 4)
                                        for c in element_set if c in feats}})
        # finite-difference gradient on element axes
        eps = 0.5
        g = np.zeros_like(x)
        for j in var_idx:
            x_plus = x.copy(); x_plus[j] += eps
            y_plus = float(model.predict(x_plus.reshape(1, -1))[0])
            g[j] = (y_plus - y0) / eps
        x[var_idx] = x[var_idx] + lr * g[var_idx]
        x[var_idx] = np.clip(x[var_idx], 0, 100)
        # re-normalise to 100 wt% across element_set
        s = x[var_idx].sum()
        if s > 0:
            target_sum = sum(initial_composition.get(e, 0)
                             for e in element_set)
            x[var_idx] = x[var_idx] * target_sum / s

    history.append({"step": n_steps,
                    "Epit_mV": round(float(model.predict(x.reshape(1,-1))[0]), 2),
                    "composition": {c: round(float(x[feats.index(c)]), 4)
                                    for c in element_set if c in feats}})
    delta = history[-1]["Epit_mV"] - history[0]["Epit_mV"]
    return {"initial_Epit_mV": history[0]["Epit_mV"],
            "final_Epit_mV":   history[-1]["Epit_mV"],
            "delta_Epit_mV":   round(delta, 2),
            "n_steps":         n_steps,
            "history":         history}


@mcp.tool()
def predict_grid_epit(model_path: str,
                      base_composition: dict,
                      vary_x: str, vary_y: str,
                      grid_x: list, grid_y: list,
                      fixed_env: dict = None) -> dict:
    """Predicted Epit on a 2-D composition grid (e.g. Sc vs Zr in Al-Cu).

    Args:
        model_path: surrogate pickle
        base_composition: starting wt% for all elements
        vary_x, vary_y: elements to sweep on x/y axes
        grid_x, grid_y: lists of wt% values
        fixed_env: env conditions, default 25 oC / 0.6 M Cl / pH 6.5

    Returns:
        flat list of (x, y, Epit_mV) plus a 2-D matrix.
    """
    with open(model_path, "rb") as f:
        cache = pickle.load(f)
    model = cache["model"]
    feats = cache["features"]
    if fixed_env is None:
        fixed_env = {"TestTemp": 25.0, "ClM": 0.6, "pH": 6.5}
    base = np.zeros(len(feats))
    for i, c in enumerate(feats):
        if c in base_composition:
            base[i] = float(base_composition[c])
        elif c in fixed_env:
            base[i] = float(fixed_env[c])
    ix = feats.index(vary_x); iy = feats.index(vary_y)
    matrix = []
    points = []
    for yv in grid_y:
        row = []
        for xv in grid_x:
            v = base.copy()
            v[ix] = float(xv); v[iy] = float(yv)
            ep = float(model.predict(v.reshape(1, -1))[0])
            row.append(round(ep, 2))
            points.append({vary_x: xv, vary_y: yv, "Epit_mV": round(ep, 2)})
        matrix.append(row)
    arr = np.array(matrix)
    return {"x_axis": list(grid_x),
            "y_axis": list(grid_y),
            "matrix": matrix,
            "min_Epit_mV": round(float(arr.min()), 2),
            "max_Epit_mV": round(float(arr.max()), 2),
            "monotone_along_x": bool((np.diff(arr, axis=1) >= 0).all()
                                     or (np.diff(arr, axis=1) <= 0).all()),
            "monotone_along_y": bool((np.diff(arr, axis=0) >= 0).all()
                                     or (np.diff(arr, axis=0) <= 0).all())}


# ---------------------------------------------------------------------------
# Plotting (each figure saved to its own PNG)
# ---------------------------------------------------------------------------
def _ensure_dir(path: str):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)


@mcp.tool()
def plot_kfold_metrics(text_metrics: dict, plain_metrics: dict,
                       output_path: str = "artifacts/Fig1_kfold_metrics.png") -> dict:
    """Bar comparison of MAE / R² between text-incorporated and text-ablated
    runs (analogous to Fig. 2C of the paper)."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    labels = ["GBR proxy\n(numeric only)", "GBR proxy\n(numeric + text-length)"]
    mae = [plain_metrics["mean_mae_mV"], text_metrics["mean_mae_mV"]]
    mae_err = [plain_metrics["std_mae_mV"], text_metrics["std_mae_mV"]]
    r2 = [plain_metrics["mean_r2"], text_metrics["mean_r2"]]
    r2_err = [plain_metrics["std_r2"], text_metrics["std_r2"]]
    fig, ax1 = plt.subplots(figsize=(6.5, 5))
    x = np.arange(2)
    ax1.bar(x - 0.18, mae, 0.35, yerr=mae_err, capsize=5,
            color="steelblue", label="MAE (mV)")
    ax1.set_ylabel("MAE (mV)", color="steelblue")
    ax1.tick_params(axis="y", labelcolor="steelblue")
    ax2 = ax1.twinx()
    ax2.bar(x + 0.18, r2, 0.35, yerr=r2_err, capsize=5,
            color="orange", label="R²")
    ax2.set_ylabel("R²", color="orange")
    ax2.tick_params(axis="y", labelcolor="orange")
    ax1.set_xticks(x); ax1.set_xticklabels(labels)
    ax1.set_title("Six-fold CV: text features vs ablation")
    fig.tight_layout()
    _ensure_dir(output_path)
    fig.savefig(output_path, dpi=140, bbox_inches="tight")
    plt.close(fig)
    return {"output_path": output_path}


@mcp.tool()
def plot_optimization_trajectory(history: list,
                                 elements: list = None,
                                 output_path: str = "artifacts/Fig2_FeCrNiMo_trajectory.png"
                                 ) -> dict:
    """Composition-vs-step trajectory for one alloy class
    (analogous to Fig. 3 panels A/C/E/G).

    `history` is the `history` list returned by `optimize_composition`.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    if elements is None and history:
        elements = list(history[0]["composition"].keys())
    steps = [h["step"] for h in history]
    fig, ax = plt.subplots(figsize=(7, 5))
    for e in elements:
        ax.plot(steps, [h["composition"].get(e, 0.0) for h in history],
                label=e, linewidth=1.6)
    ax.set_xlabel("Optimization step")
    ax.set_ylabel("Composition (wt %)")
    ax.set_title("Process-aware composition optimization")
    ax.legend(loc="best", fontsize=8, ncol=2)
    fig.tight_layout()
    _ensure_dir(output_path)
    fig.savefig(output_path, dpi=140, bbox_inches="tight")
    plt.close(fig)
    return {"output_path": output_path, "n_elements": len(elements)}


@mcp.tool()
def plot_descriptor_trajectory(descriptor_series: dict,
                               output_path: str = "artifacts/Fig3_APE_descriptor.png"
                               ) -> dict:
    """Plot one curve per alloy starting composition for a single descriptor
    (e.g. APE_mean, configurational_entropy, electronegativity δ, Yang δ).

    Args:
        descriptor_series: {alloy_label: list_of_descriptor_values_per_step}
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(7, 5))
    for label, series in descriptor_series.items():
        ax.plot(range(len(series)), series, label=label, linewidth=1.6)
    ax.set_xlabel("Optimization step")
    ax.set_ylabel("Descriptor value (delta from initial)")
    ax.set_title("Descriptor evolution during composition optimization")
    ax.legend(fontsize=8)
    fig.tight_layout()
    _ensure_dir(output_path)
    fig.savefig(output_path, dpi=140, bbox_inches="tight")
    plt.close(fig)
    return {"output_path": output_path}


@mcp.tool()
def plot_alcu_sczr_grid(grid: dict,
                        output_path: str = "artifacts/AlCu_ScZr_grid.png"
                        ) -> dict:
    """Heat-map of predicted Epit on the Al-Cu-Sc-Zr grid (Fig. 6 analogue).

    `grid` is the dict returned by `predict_grid_epit`.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    arr = np.array(grid["matrix"], dtype=float)
    fig, ax = plt.subplots(figsize=(6.5, 5))
    im = ax.imshow(arr, origin="lower", aspect="auto", cmap="jet",
                   extent=[min(grid["x_axis"]), max(grid["x_axis"]),
                           min(grid["y_axis"]), max(grid["y_axis"])])
    plt.colorbar(im, ax=ax, label="Predicted Epit (mV)")
    ax.set_xlabel("Sc (wt %)")
    ax.set_ylabel("Zr (wt %)")
    ax.set_title("Predicted pitting potential for Al-Cu-Sc-Zr")
    fig.tight_layout()
    _ensure_dir(output_path)
    fig.savefig(output_path, dpi=140, bbox_inches="tight")
    plt.close(fig)
    return {"output_path": output_path,
            "Epit_min": grid["min_Epit_mV"],
            "Epit_max": grid["max_Epit_mV"]}


if __name__ == "__main__":
    mcp.run(transport="stdio")

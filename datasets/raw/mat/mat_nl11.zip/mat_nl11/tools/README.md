# mat_nl11 — Tool Reference

Tools for analysing the mechanical behaviour of Al2O3/Al hybrid nanolaminates
deposited by DC magnetron sputtering, measured via nanoindentation,
nanoscratch, in-situ TEM push-to-pull (PTP) tension and on-chip crack
propagation.

## Dependencies

- python >= 3.10
- numpy
- openpyxl  (xlsx readers)
- matplotlib  (all plot tools)
- mcp (FastMCP) for the @mcp.tool() decorator

`pip install numpy openpyxl matplotlib mcp`

## Database Retrieval (`database_retrieval.py`)

Stub fetchers — fill in at runtime. Useful here mainly for `fetch_url` /
`websearch` if extra papers are needed.

- **websearch**, **fetch_url**, **query_pubchem**, **query_chembl**,
  **query_uniprot**, **query_pdb**, **query_geo**, **query_ncbi_entrez**,
  **query_usgs_comcat**, **query_world_bank**, **query_openalex**, **query_doi**

## Data Processing (`data_processing.py`)

Generic CSV/JSON/table primitives.

- **read_csv** / **write_csv** / **read_json** / **write_json**
- **read_excel** (stub)
- **drop_missing** / **coerce_numeric** / **join_tables** /
  **groupby_aggregate** / **pivot_long_to_wide** / **pivot_wide_to_long**

## Domain Tools (`nanolaminate_tools.py`)

### Loaders

- **load_indent_table(xlsx_path)** — read the nanoindentation E', H vs Al2O3
  fraction table.
- **load_stress_strain(xlsx_path)** — read true stress-strain curves for the
  three NL systems (50/10, 100/10, 150/100/150).
- **load_crack_on_chip(xlsx_path)** — read KIc / GIc vs crack advance for
  symmetric and asymmetric on-chip configurations.
- **load_literature_database(xlsx_path)** — read the strength-toughness
  literature compilation for thin films and multilayers.

### Mechanical analysis primitives

- **voigt_mixture(fraction_pct, E1, E2)** — iso-strain (upper) bound.
- **reuss_mixture(fraction_pct, E1, E2)** — iso-stress (lower) bound.
- **fit_linear(x, y)** — least-squares slope, intercept, R^2.
- **stress_strain_metrics(strain, stress, E_chord_window, yield_offset)** —
  Young's modulus from initial chord, 0.2% offset yield, ultimate stress
  and fracture strain.
- **descriptive_stats(values)** — mean, std, sem, min, max, median.
- **kic_to_gic(KIc, E, plane_strain, nu)** — convert mode-I stress
  intensity to fracture energy (J/m^2).
- **critical_crack_size(KIc, sigma_y, Y)** — Griffith / LEFM critical
  flaw size (micrometers).
- **filter_records(records, where)** / **extract_columns(records, fields)**
  for slicing the literature database.

### Plotting (one figure per image answer)

- **plot_modulus_hardness_vs_fraction** — reproduces Fig 2a/b.
- **plot_stress_strain** — reproduces Fig 3a.
- **plot_kic_vs_crack_advance** — reproduces Fig 4c.
- **plot_strength_toughness_map** — reproduces Fig 5.

Every plot tool returns the absolute output path it wrote.

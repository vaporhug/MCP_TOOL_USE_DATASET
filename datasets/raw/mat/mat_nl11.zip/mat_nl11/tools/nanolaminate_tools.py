#!/usr/bin/env python3
"""
Domain tools for analysis of Al2O3/Al nanolaminate mechanical data.

Provides primitive operations for:
  * loading nanoindentation E and H data
  * loading PTP true stress-strain curves
  * loading crack-on-chip KIc / GIc data
  * loading literature strength-toughness database
  * fitting iso-strain (Voigt) and iso-stress (Reuss) rule of mixture
  * computing Young's modulus / yield strength / fracture strain from a curve
  * computing KIc statistics and converting KIc <-> GIc
  * generating publication-style plots reproducing Figs 2, 3, 4c, 5

These are low level primitives only — composing them into the full analysis
is the agent's responsibility.
"""

from __future__ import annotations

import json
import math
import os
from typing import Any

import numpy as np
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Nanolaminate_Tools")


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------

@mcp.tool()
def load_indent_table(xlsx_path: str) -> dict:
    """Load the nanoindentation E' and hardness data table.

    Expected layout: column 1 = fraction of Al2O3 (%),
    columns 2..5 = E mean (GPa), E std, H mean (GPa), H std.

    Returns a dict with parallel lists.
    """
    import openpyxl
    wb = openpyxl.load_workbook(xlsx_path, data_only=True)
    ws = wb[wb.sheetnames[0]]
    rows = list(ws.iter_rows(values_only=True))
    # Skip first two header rows
    f, em, es, hm, hs = [], [], [], [], []
    for r in rows[2:]:
        if r[0] is None:
            continue
        f.append(float(r[0]))
        em.append(float(r[1]))
        es.append(float(r[2]))
        hm.append(float(r[3]))
        hs.append(float(r[4]))
    return {
        "n": len(f),
        "fraction_Al2O3_percent": f,
        "E_mean_GPa": em,
        "E_std_GPa": es,
        "H_mean_GPa": hm,
        "H_std_GPa": hs,
    }


@mcp.tool()
def load_stress_strain(xlsx_path: str) -> dict:
    """Load the in-situ TEM PTP true stress-strain curves.

    Returns three series: 50/10, 100/10, 150/100/150 each with strain/stress lists.
    Stress is in GPa, strain is dimensionless.
    """
    import openpyxl
    wb = openpyxl.load_workbook(xlsx_path, data_only=True)
    ws = wb[wb.sheetnames[0]]
    rows = list(ws.iter_rows(values_only=True))
    headers = rows[0]
    data = {h: [] for h in headers if h is not None}
    for r in rows[1:]:
        for k, v in zip(headers, r):
            if k is None:
                continue
            if v is None:
                continue
            try:
                data[k].append(float(v))
            except (TypeError, ValueError):
                pass
    series = {}
    for label in ("50/10", "100/10", "150/100/150"):
        e_key = f"True Strain {label}"
        s_key = f"True Stress (GPa) {label}"
        if e_key in data and s_key in data:
            n = min(len(data[e_key]), len(data[s_key]))
            series[label] = {
                "strain": data[e_key][:n],
                "stress_GPa": data[s_key][:n],
                "n_points": n,
            }
    return {"systems": list(series.keys()), "series": series}


@mcp.tool()
def load_crack_on_chip(xlsx_path: str) -> dict:
    """Load the crack on chip KIc / GIc dataset (Fig 4c).

    Returns three configurations: sym 50/20, asym 50/20, asym 50/10. Each has
    crack_advance_um, KIc_MPa_sqrtm, GIc_J_m2.
    """
    import openpyxl
    wb = openpyxl.load_workbook(xlsx_path, data_only=True)
    ws = wb[wb.sheetnames[0]]
    rows = list(ws.iter_rows(values_only=True))
    # Row 0: section labels at columns 0, 4, 8.  Row 1: column subheaders.
    def parse_block(rows, c0, c1, c2):
        out = {"crack_advance_um": [], "KIc_MPa_sqrtm": [], "GIc_J_m2": []}
        for r in rows[2:]:
            v0, v1, v2 = r[c0], r[c1], r[c2]
            if v0 is None or v1 is None:
                continue
            try:
                out["crack_advance_um"].append(float(str(v0).strip()))
                out["KIc_MPa_sqrtm"].append(float(str(v1).strip()))
                out["GIc_J_m2"].append(float(str(v2).strip()))
            except (TypeError, ValueError):
                continue
        return out
    sym_50_20 = parse_block(rows, 0, 1, 2)
    asym_50_20 = parse_block(rows, 4, 5, 6)
    asym_50_10 = parse_block(rows, 8, 9, 10)
    return {
        "sym_50_20": sym_50_20,
        "asym_50_20": asym_50_20,
        "asym_50_10": asym_50_10,
        "n_sym_50_20": len(sym_50_20["KIc_MPa_sqrtm"]),
        "n_asym_50_20": len(asym_50_20["KIc_MPa_sqrtm"]),
        "n_asym_50_10": len(asym_50_10["KIc_MPa_sqrtm"]),
    }


@mcp.tool()
def load_literature_database(xlsx_path: str) -> dict:
    """Load the literature strength-toughness database (Fig 5 source data).

    Returns list of records with material, method, layer thickness, yield stress,
    hardness, KIc, KIc_high, GIc, fracture strain.  Skips the column-header rows.
    """
    import openpyxl
    wb = openpyxl.load_workbook(xlsx_path, data_only=True)
    ws = wb[wb.sheetnames[0]]
    rows = list(ws.iter_rows(values_only=True))
    out = []
    for r in rows[2:]:
        if r[0] is None or r[2] is None:
            continue
        rec = {
            "ref": r[0],
            "ref_number": r[1],
            "material": r[2],
            "method": r[3],
            "sim_or_exp": r[4],
            "layer_thickness_nm": r[5],
            "ratio": r[6],
            "yield_stress_GPa": r[7],
            "yield_stress_std_GPa": r[8],
            "hardness_GPa": r[9],
            "hardness_std_GPa": r[10],
            "KIc_MPa_sqrtm": r[11],
            "KIc_std_MPa_sqrtm": r[12],
            "KIc_high_MPa_sqrtm": r[13],
            "Young_modulus_GPa": r[14],
            "fracture_strain_pct": r[15],
            "total_thickness_nm": r[16],
            "GIc_J_m2": r[17],
            "GIc_std_J_m2": r[18],
        }
        out.append(rec)
    return {"n_entries": len(out), "records": out}


# ---------------------------------------------------------------------------
# Mechanical analysis primitives
# ---------------------------------------------------------------------------

@mcp.tool()
def voigt_mixture(fraction_pct: list, E_phase1_GPa: float, E_phase2_GPa: float) -> dict:
    """Voigt iso-strain rule-of-mixture upper bound.

    E_eff(f) = f * E_phase2 + (1-f) * E_phase1   (f in [0,1]).
    fraction_pct is the fraction of phase2 (e.g. Al2O3) in percent.
    """
    f = np.asarray(fraction_pct, dtype=float) / 100.0
    e_eff = f * E_phase2_GPa + (1 - f) * E_phase1_GPa
    return {
        "fraction_phase2_percent": fraction_pct,
        "E_voigt_GPa": [round(float(v), 3) for v in e_eff],
        "E_phase1_GPa": E_phase1_GPa,
        "E_phase2_GPa": E_phase2_GPa,
    }


@mcp.tool()
def reuss_mixture(fraction_pct: list, E_phase1_GPa: float, E_phase2_GPa: float) -> dict:
    """Reuss iso-stress rule-of-mixture lower bound.

    1/E_eff(f) = f/E_phase2 + (1-f)/E_phase1.
    """
    f = np.asarray(fraction_pct, dtype=float) / 100.0
    inv = f / E_phase2_GPa + (1 - f) / E_phase1_GPa
    e_eff = 1.0 / inv
    return {
        "fraction_phase2_percent": fraction_pct,
        "E_reuss_GPa": [round(float(v), 3) for v in e_eff],
        "E_phase1_GPa": E_phase1_GPa,
        "E_phase2_GPa": E_phase2_GPa,
    }


@mcp.tool()
def fit_linear(x: list, y: list) -> dict:
    """Least-squares y = a + b*x fit. Returns intercept, slope, R^2."""
    x_a = np.asarray(x, dtype=float)
    y_a = np.asarray(y, dtype=float)
    b, a = np.polyfit(x_a, y_a, 1)
    y_hat = a + b * x_a
    ss_res = float(np.sum((y_a - y_hat) ** 2))
    ss_tot = float(np.sum((y_a - y_a.mean()) ** 2))
    r2 = 1 - ss_res / ss_tot if ss_tot > 0 else 0.0
    return {
        "intercept": round(float(a), 6),
        "slope": round(float(b), 6),
        "r2": round(r2, 6),
        "n": len(x_a),
    }


@mcp.tool()
def stress_strain_metrics(strain: list, stress_GPa: list,
                            E_chord_window: float = 0.005,
                            yield_offset: float = 0.002) -> dict:
    """Extract Young's modulus, yield stress at given offset, ultimate stress
    and fracture strain (last point) from a true stress-strain curve.

    Young's modulus = chord slope through origin over the first
    E_chord_window strain range.
    Yield stress = stress at the first crossing of the curve with the 0.2%
    (``yield_offset``) offset line ``sigma = E*(eps - offset)``. The crossing
    is located where ``diff = sigma - offset_line`` changes from positive to
    non-positive, and the yield point (both stress and strain) is linearly
    interpolated using the actual numeric gap ``diff`` (fraction
    ``t = diff[i-1] / (diff[i-1] - diff[i])``), not the sign of ``diff``.
    """
    eps = np.asarray(strain, dtype=float)
    sig = np.asarray(stress_GPa, dtype=float)
    order = np.argsort(eps)
    eps, sig = eps[order], sig[order]
    # Young's modulus: slope of best-fit line between strain 0 and chord_window
    mask = eps <= E_chord_window
    if mask.sum() >= 2:
        E_GPa = float(np.polyfit(eps[mask], sig[mask], 1)[0])
    else:
        E_GPa = float(sig[1] / eps[1]) if len(eps) > 1 and eps[1] > 0 else float("nan")
    # 0.2% offset yield stress
    offset_line = E_GPa * (eps - yield_offset)
    diff = sig - offset_line
    sign = np.sign(diff)
    sigma_y = None
    eps_y = None
    for i in range(1, len(sign)):
        if sign[i - 1] > 0 and sign[i] <= 0:
            # Crossing of the stress-strain curve and the offset line:
            # interpolate using the actual numeric gap diff (not its sign),
            # so the fractional position t reflects where diff -> 0.
            denom = diff[i - 1] - diff[i]
            t = diff[i - 1] / denom if denom != 0 else 0.0
            sigma_y = float(sig[i - 1] + t * (sig[i] - sig[i - 1]))
            eps_y = float(eps[i - 1] + t * (eps[i] - eps[i - 1]))
            break
    if sigma_y is None and (sig[-1] < offset_line[-1]):
        sigma_y = float(sig[-1])
    return {
        "E_GPa": round(E_GPa, 3),
        "yield_stress_GPa": round(sigma_y, 4) if sigma_y is not None else None,
        "yield_strain": round(eps_y, 5) if eps_y is not None else None,
        "ultimate_stress_GPa": round(float(sig.max()), 4),
        "fracture_strain": round(float(eps[-1]), 5),
        "fracture_stress_GPa": round(float(sig[-1]), 4),
        "n_points": int(len(eps)),
    }


@mcp.tool()
def descriptive_stats(values: list) -> dict:
    """Mean, std, sem, min, max, median for a numeric list."""
    a = np.asarray([v for v in values if v is not None], dtype=float)
    n = len(a)
    if n == 0:
        return {"n": 0}
    return {
        "n": int(n),
        "mean": round(float(a.mean()), 4),
        "std": round(float(a.std(ddof=1)) if n > 1 else 0.0, 4),
        "sem": round(float(a.std(ddof=1) / math.sqrt(n)) if n > 1 else 0.0, 4),
        "min": round(float(a.min()), 4),
        "max": round(float(a.max()), 4),
        "median": round(float(np.median(a)), 4),
    }


@mcp.tool()
def kic_to_gic(KIc_MPa_sqrtm: float, E_GPa: float, plane_strain: bool = False,
                 nu: float = 0.25) -> dict:
    """Convert mode-I stress intensity to fracture energy.

    Plane stress:  GIc = K^2 / E
    Plane strain:  GIc = K^2 (1-nu^2) / E

    Inputs in MPa.sqrt(m) and GPa; returns J/m^2.
    """
    K_pa_rt_m = KIc_MPa_sqrtm * 1e6
    E_pa = E_GPa * 1e9
    if plane_strain:
        g = K_pa_rt_m ** 2 * (1 - nu ** 2) / E_pa
    else:
        g = K_pa_rt_m ** 2 / E_pa
    return {
        "KIc_MPa_sqrtm": KIc_MPa_sqrtm,
        "E_GPa": E_GPa,
        "GIc_J_m2": round(float(g), 4),
        "plane_strain": plane_strain,
        "nu": nu,
    }


@mcp.tool()
def critical_crack_size(KIc_MPa_sqrtm: float, sigma_y_GPa: float,
                          geometry_factor: float = 1.0) -> dict:
    """Estimate critical flaw size from Griffith / LEFM:
        a_c = (1/pi) * (KIc / (Y * sigma_y))^2
    Inputs: KIc in MPa.sqrt(m), sigma in GPa, Y dimensionless.
    Output: a_c in micrometers.
    """
    sigma_pa = sigma_y_GPa * 1e9
    K_pa_rt_m = KIc_MPa_sqrtm * 1e6
    a_c_m = (1.0 / math.pi) * (K_pa_rt_m / (geometry_factor * sigma_pa)) ** 2
    return {
        "KIc_MPa_sqrtm": KIc_MPa_sqrtm,
        "sigma_y_GPa": sigma_y_GPa,
        "Y": geometry_factor,
        "critical_crack_size_um": round(a_c_m * 1e6, 4),
        "critical_crack_size_m": float(a_c_m),
    }


@mcp.tool()
def filter_records(records: list, where: dict) -> dict:
    """Filter literature records by exact key=value criteria.
    Ex: filter_records(records, {"material": "Al_2O_3/Al"}).
    """
    out = []
    for r in records:
        if all(r.get(k) == v for k, v in where.items()):
            out.append(r)
    return {"n_match": len(out), "records": out}


@mcp.tool()
def extract_columns(records: list, fields: list) -> dict:
    """Pull listed numeric fields from a list of records into parallel lists.
    Drops rows where any of the fields is None.
    """
    cols = {f: [] for f in fields}
    for r in records:
        if any(r.get(f) is None for f in fields):
            continue
        for f in fields:
            cols[f].append(r[f])
    return {"n": len(next(iter(cols.values()))) if cols else 0, "columns": cols}


# ---------------------------------------------------------------------------
# Plotting tools
# ---------------------------------------------------------------------------

@mcp.tool()
def plot_modulus_hardness_vs_fraction(
    xlsx_path: str,
    output_path: str = "artifacts/modulus_hardness_vs_fraction.png",
    E_Al_GPa: float = 70.0,
    E_Al2O3_GPa: float = 185.0,
    H_Al_GPa: float = 1.0,
    H_Al2O3_GPa: float = 9.0,
) -> dict:
    """Reproduce Fig 2a/b: E' and hardness vs fraction Al2O3, with Voigt
    iso-strain (dashed) and Reuss iso-stress (solid) bounds for E, and a
    linear rule of mixture for hardness."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    d = load_indent_table(xlsx_path)
    f = np.asarray(d["fraction_Al2O3_percent"]) / 100.0
    fxy = np.linspace(0, 1, 200)
    e_v = fxy * E_Al2O3_GPa + (1 - fxy) * E_Al_GPa
    e_r = 1.0 / (fxy / E_Al2O3_GPa + (1 - fxy) / E_Al_GPa)
    h_v = fxy * H_Al2O3_GPa + (1 - fxy) * H_Al_GPa
    fig, ax = plt.subplots(1, 2, figsize=(11, 5))
    ax[0].errorbar(d["fraction_Al2O3_percent"], d["E_mean_GPa"],
                   yerr=d["E_std_GPa"], fmt="ko", ms=5, capsize=3)
    ax[0].plot(fxy * 100, e_v, "k--", label="Voigt (iso-strain)")
    ax[0].plot(fxy * 100, e_r, "b-", label="Reuss (iso-stress)")
    ax[0].set_xlabel(r"$f_{Al_2O_3}$ (%)")
    ax[0].set_ylabel(r"$E'$ (GPa)")
    ax[0].set_title("Reduced modulus")
    ax[0].legend(); ax[0].grid(alpha=0.3)
    ax[1].errorbar(d["fraction_Al2O3_percent"], d["H_mean_GPa"],
                   yerr=d["H_std_GPa"], fmt="ko", ms=5, capsize=3)
    ax[1].plot(fxy * 100, h_v, "k--", label="Voigt linear")
    ax[1].set_xlabel(r"$f_{Al_2O_3}$ (%)")
    ax[1].set_ylabel(r"$H$ (GPa)")
    ax[1].set_title("Hardness")
    ax[1].legend(); ax[1].grid(alpha=0.3)
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"output_path": output_path, "n_points": d["n"]}


@mcp.tool()
def plot_stress_strain(
    xlsx_path: str,
    output_path: str = "artifacts/stress_strain.png",
) -> dict:
    """Reproduce Fig 3a: true stress-strain curves for the three NL systems."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    d = load_stress_strain(xlsx_path)
    colors = {"50/10": "tab:blue", "100/10": "tab:red", "150/100/150": "tab:orange"}
    fig, ax = plt.subplots(figsize=(7, 5))
    for label, ser in d["series"].items():
        ax.plot(ser["strain"], ser["stress_GPa"], "-",
                color=colors.get(label, "k"), lw=2, label=label)
    ax.set_xlabel("True strain")
    ax.set_ylabel("True stress (GPa)")
    ax.set_title("Push-to-pull tension of Al$_2$O$_3$/Al NLs")
    ax.legend(); ax.grid(alpha=0.3)
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"output_path": output_path, "systems": list(d["series"].keys())}


@mcp.tool()
def plot_kic_vs_crack_advance(
    xlsx_path: str,
    output_path: str = "artifacts/kic_vs_crack_advance.png",
) -> dict:
    """Reproduce Fig 4c: KIc vs crack advance for the three test geometries."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    d = load_crack_on_chip(xlsx_path)
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.scatter(d["asym_50_20"]["crack_advance_um"], d["asym_50_20"]["KIc_MPa_sqrtm"],
               color="red", s=40, label="asym 50/20", zorder=3)
    ax.scatter(d["sym_50_20"]["crack_advance_um"], d["sym_50_20"]["KIc_MPa_sqrtm"],
               color="black", s=40, label="sym 50/20", zorder=3)
    ax.scatter(d["asym_50_10"]["crack_advance_um"], d["asym_50_10"]["KIc_MPa_sqrtm"],
               color="blue", marker="D", s=60, label="asym 50/10", zorder=3)
    all_k = (d["sym_50_20"]["KIc_MPa_sqrtm"] + d["asym_50_20"]["KIc_MPa_sqrtm"]
             + d["asym_50_10"]["KIc_MPa_sqrtm"])
    mean = float(np.mean(all_k))
    ax.axhline(mean, color="grey", ls="--", lw=1, label=f"mean = {mean:.2f}")
    ax.set_xlabel(r"Crack advance $\Delta a$ ($\mu$m)")
    ax.set_ylabel(r"$K_{Ic}$ (MPa$\cdot$m$^{1/2}$)")
    ax.set_ylim(0, 10)
    ax.set_title("Crack-on-chip fracture toughness")
    ax.legend(); ax.grid(alpha=0.3)
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"output_path": output_path, "n_points": len(all_k), "mean_KIc": round(mean, 3)}


@mcp.tool()
def plot_strength_toughness_map(
    xlsx_path: str,
    output_path: str = "artifacts/strength_toughness_map.png",
) -> dict:
    """Reproduce Fig 5: yield stress vs KIc for single-layer / multilayer
    thin films from the literature, with the Al2O3/Al NL highlighted."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    db = load_literature_database(xlsx_path)
    sy, k, mat = [], [], []
    sy_nl, k_nl = [], []
    for r in db["records"]:
        s = r.get("yield_stress_GPa")
        kk = r.get("KIc_MPa_sqrtm")
        if s is None or kk is None:
            continue
        if r.get("material") == "Al_2O_3/Al":
            sy_nl.append(s); k_nl.append(kk)
        else:
            sy.append(s); k.append(kk); mat.append(r.get("material"))
    fig, ax = plt.subplots(figsize=(7, 6))
    ax.scatter(k, sy, s=20, c="grey", alpha=0.6, label="literature")
    ax.scatter(k_nl, sy_nl, s=110, c="red", marker="*",
               edgecolor="k", label="Al$_2$O$_3$/Al NL (this work)", zorder=4)
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlabel(r"$K_{Ic}$ (MPa$\cdot$m$^{1/2}$)")
    ax.set_ylabel(r"$\sigma_y$ (GPa)")
    ax.set_title("Strength vs toughness map for thin film systems")
    ax.legend(); ax.grid(which="both", alpha=0.3)
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {
        "output_path": output_path,
        "n_literature": len(k),
        "n_NL_points": len(k_nl),
    }


if __name__ == "__main__":
    mcp.run(transport="stdio")

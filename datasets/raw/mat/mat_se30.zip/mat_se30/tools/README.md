# Tools — energy storage TEA primitives

| File | Category | Purpose |
|------|----------|---------|
| `data_processing.py` | generic | Load / describe / filter / group-count / top-k for tabular CSVs (handles the 2-row metadata header used by `SM_data.csv`). |
| `database_retrieval.py` | lookup | Selection helpers over `SM_data.csv` and `mat_data.csv`: list SM types, fetch by name / type, look up material specific price. |
| `ldes_tea.py` | domain | TEA primitives: `C_kWh,SM` from mass-basis or volumetric prices; specific-energy formulas (sensible / latent / electrochemical / virial); LCOS equation; `C_kWh,max` for a target LCOS; built-in MDES / multi-day-LDES / seasonal-LDES guideline values; `screen_promising` filter. |
| `plotting.py` | visualisation | Strip plot of `C_kWh,SM` by SM type with cost-guideline lines; specific-energy histogram by stored energy form; LCOS-vs-duration curves; ranking bar chart. |

## Dependencies

Python 3.10+ with `numpy`, `pandas`, `matplotlib`, and `mcp` (FastMCP).
Install: `pip install mcp numpy pandas matplotlib`.

## How to chain

A typical pipeline:

1. `database_retrieval.list_sm_types(...)` to see the 15 SM categories.
2. `data_processing.numeric_stats(...)` on `SM_data.csv` to inspect the C_kwh distribution.
3. `ldes_tea.application_cost_targets()` to get the 5 / 0.5 USD/kWh guidelines.
4. `ldes_tea.screen_promising(SM_data.csv, threshold=5.0)` to count and list SM that meet the multi-day LDES guideline; repeat for 0.5 (seasonal) and 180 (MDES).
5. `database_retrieval.get_sm_by_type(..., sort_by="C_kwh", limit=3)` for each category to identify the cheapest representative material.
6. `plotting.plot_ckwh_by_type(SM_data.csv, guideline_lines=[180, 5, 0.5])` for the headline figure.
7. `plotting.plot_ranking_table(SM_data.csv, top_n=10)` to highlight the cheapest media.

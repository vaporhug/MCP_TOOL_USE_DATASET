#!/usr/bin/env python3
"""
Lookup helpers for the consolidated SM_data.csv and mat_data.csv tables
(Aspitarte & Woodside dataset, Zenodo 10.5281/zenodo.10042066).

These tools wrap simple selections by name or by category over the local
CSV files; they do not query any external network resource.
"""

import pandas as pd
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("database_retrieval")


def _load_sm(csv_path: str) -> pd.DataFrame:
    df = pd.read_csv(csv_path, skiprows=[1, 2], header=0)
    df = df.rename(columns={"Unnamed: 0": "SM_name", "Unnamed: 1": "SM_type"})
    return df


def _load_mat(csv_path: str) -> pd.DataFrame:
    df = pd.read_csv(csv_path, skiprows=[1, 2], header=0)
    df = df.rename(columns={"Unnamed: 0": "material"})
    return df


@mcp.tool()
def list_sm_types(sm_csv_path: str) -> dict:
    """Return all distinct SM_type values in the SM_data.csv.

    Args:
        sm_csv_path: Path to the SM_data.csv file.

    Returns:
        dict with sorted list of SM types and their counts.
    """
    df = _load_sm(sm_csv_path)
    counts = df["SM_type"].value_counts().to_dict()
    return {"n_types": int(df["SM_type"].nunique()),
            "types": sorted(df["SM_type"].dropna().unique().tolist()),
            "counts": {str(k): int(v) for k, v in counts.items()}}


@mcp.tool()
def get_sm_by_name(sm_csv_path: str, sm_name: str) -> dict:
    """Return all records whose SM_name matches `sm_name` (exact, case-sensitive).

    Args:
        sm_csv_path: Path to SM_data.csv.
        sm_name: Storage medium name to look up (e.g. "Al-air", "NaCl").

    Returns:
        dict with the matching rows as records.
    """
    df = _load_sm(sm_csv_path)
    sub = df[df["SM_name"] == sm_name]
    return {"n_matches": int(len(sub)), "rows": sub.to_dict("records")}


@mcp.tool()
def get_sm_by_type(sm_csv_path: str, sm_type: str, sort_by: str = "C_kwh",
                    ascending: bool = True, limit: int = None) -> dict:
    """Return rows of one SM_type, sorted by a numeric column.

    Args:
        sm_csv_path: Path to SM_data.csv.
        sm_type: Category to filter on (e.g. "sensible_thermal", "synfuel").
        sort_by: Column to order on (default C_kwh).
        ascending: Sort direction (default True = cheapest first).
        limit: Optional max number of rows to return.

    Returns:
        dict with rows.
    """
    df = _load_sm(sm_csv_path)
    sub = df[df["SM_type"] == sm_type].copy()
    sub[sort_by] = pd.to_numeric(sub[sort_by], errors="coerce")
    sub = sub.sort_values(sort_by, ascending=ascending)
    if limit:
        sub = sub.head(limit)
    return {"sm_type": sm_type, "n": int(len(sub)),
            "rows": sub.to_dict("records")}


@mcp.tool()
def get_material_price(mat_csv_path: str, material: str) -> dict:
    """Look up consolidated specific price (USD/kg) and other fields for a material.

    Args:
        mat_csv_path: Path to mat_data.csv.
        material: Material name as it appears in the index column.

    Returns:
        dict with one record (or empty if not found).
    """
    df = _load_mat(mat_csv_path)
    sub = df[df["material"] == material]
    return {"n_matches": int(len(sub)), "rows": sub.to_dict("records")}


@mcp.tool()
def list_materials(mat_csv_path: str, top_n_cheapest: int = 20) -> dict:
    """Return summary of the materials price database, plus the N cheapest entries.

    Args:
        mat_csv_path: Path to mat_data.csv.
        top_n_cheapest: How many of the cheapest materials to return.

    Returns:
        dict with total counts and the cheapest entries by specific_price.
    """
    df = _load_mat(mat_csv_path)
    df["specific_price"] = pd.to_numeric(df["specific_price"], errors="coerce")
    nonnull = df.dropna(subset=["specific_price"])
    cheapest = nonnull.nsmallest(top_n_cheapest, "specific_price")[
        ["material", "specific_price", "molecular_formula", "num_source"]
    ]
    return {
        "n_materials_total": int(len(df)),
        "n_with_price": int(len(nonnull)),
        "cheapest_records": cheapest.to_dict("records"),
    }


if __name__ == "__main__":
    mcp.run(transport="stdio")

#!/usr/bin/env python3
"""
General-purpose data loading and tabular utilities for the energy storage TEA task.

This module is data-format-agnostic; it knows nothing about LDES domain logic
beyond skipping the two metadata header rows (column names + units row) used
by the consolidated SM_data.csv / mat_data.csv layout published with the
Aspitarte & Woodside dataset on Zenodo.
"""

import numpy as np
import pandas as pd
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("data_processing")


def _load(csv_path: str) -> pd.DataFrame:
    """Internal loader that skips the unit-row (row 1) used by SM_data.csv."""
    df = pd.read_csv(csv_path, skiprows=[1, 2], header=0)
    if "Unnamed: 0" in df.columns:
        df = df.rename(columns={"Unnamed: 0": "name"})
    if "Unnamed: 1" in df.columns and df["Unnamed: 1"].dtype == object:
        df = df.rename(columns={"Unnamed: 1": "category"})
    return df


@mcp.tool()
def describe_csv(csv_path: str) -> dict:
    """Return shape, column names, dtypes and per-column non-null counts of a CSV.

    Drops the unit metadata row (line 2) automatically.

    Args:
        csv_path: Path to the CSV file.

    Returns:
        dict with shape, columns, dtypes, non_null_counts.
    """
    df = _load(csv_path)
    return {
        "shape": list(df.shape),
        "columns": list(df.columns),
        "dtypes": {c: str(df[c].dtype) for c in df.columns},
        "non_null_counts": {c: int(df[c].notna().sum()) for c in df.columns},
    }


@mcp.tool()
def numeric_stats(csv_path: str, columns: list = None) -> dict:
    """Compute per-column mean / std / min / max / median / quantiles for numeric columns.

    Args:
        csv_path: Path to CSV file.
        columns: Optional list of columns to restrict to. Default: all numeric.

    Returns:
        dict mapping column name -> stats dict.
    """
    df = _load(csv_path)
    cols = columns or [c for c in df.columns if pd.api.types.is_numeric_dtype(df[c])]
    out = {}
    for c in cols:
        s = pd.to_numeric(df[c], errors="coerce").dropna()
        if len(s) == 0:
            continue
        out[c] = {
            "n": int(len(s)),
            "mean": float(s.mean()),
            "std": float(s.std()),
            "min": float(s.min()),
            "p10": float(s.quantile(0.10)),
            "p50": float(s.quantile(0.50)),
            "p90": float(s.quantile(0.90)),
            "max": float(s.max()),
        }
    return out


@mcp.tool()
def filter_rows(csv_path: str, column: str, op: str, value: float) -> dict:
    """Return rows of a CSV whose `column` satisfies a comparison.

    Supported ops: lt, le, gt, ge, eq.

    Args:
        csv_path: Path to CSV file.
        column: Column to compare (must exist).
        op: Comparison: "lt"|"le"|"gt"|"ge"|"eq".
        value: Numeric threshold.

    Returns:
        dict with n_total, n_matching, and the matching rows as records.
    """
    df = _load(csv_path)
    s = pd.to_numeric(df[column], errors="coerce")
    cmp = {
        "lt": s < value, "le": s <= value,
        "gt": s > value, "ge": s >= value,
        "eq": s == value,
    }[op]
    sub = df[cmp.fillna(False)]
    return {
        "n_total": int(len(df)),
        "n_matching": int(len(sub)),
        "rows": sub.to_dict("records"),
    }


@mcp.tool()
def group_count(csv_path: str, group_col: str, filter_col: str = None,
                 filter_op: str = None, filter_value: float = None) -> dict:
    """Count rows per category in `group_col`, optionally after a numeric filter.

    Args:
        csv_path: Path to CSV file.
        group_col: Categorical column to group by.
        filter_col: Optional numeric column for an additional filter.
        filter_op: One of lt, le, gt, ge, eq (used only if filter_col given).
        filter_value: Numeric threshold (used only if filter_col given).

    Returns:
        dict with category -> count.
    """
    df = _load(csv_path)
    if filter_col and filter_op and filter_value is not None:
        s = pd.to_numeric(df[filter_col], errors="coerce")
        cmp = {"lt": s < filter_value, "le": s <= filter_value,
               "gt": s > filter_value, "ge": s >= filter_value,
               "eq": s == filter_value}[filter_op]
        df = df[cmp.fillna(False)]
    counts = df[group_col].value_counts(dropna=False).to_dict()
    return {"n_total": int(len(df)),
            "counts": {str(k): int(v) for k, v in counts.items()}}


@mcp.tool()
def top_k_per_group(csv_path: str, group_col: str, value_col: str,
                     k: int = 3, ascending: bool = True) -> dict:
    """For each value of `group_col`, return the top-k rows ranked by `value_col`.

    Args:
        csv_path: Path to CSV file.
        group_col: Column to group on (e.g. SM_type).
        value_col: Numeric column to rank by (e.g. C_kwh).
        k: Number of rows per group.
        ascending: True for cheapest first, False for most expensive first.

    Returns:
        dict mapping group value -> list of records.
    """
    df = _load(csv_path)
    df[value_col] = pd.to_numeric(df[value_col], errors="coerce")
    df = df.dropna(subset=[value_col])
    out = {}
    for g, sub in df.groupby(group_col):
        s = sub.nsmallest(k, value_col) if ascending else sub.nlargest(k, value_col)
        out[str(g)] = s.to_dict("records")
    return {"k": k, "groups": out}


if __name__ == "__main__":
    mcp.run(transport="stdio")

#!/usr/bin/env python3
"""
Domain-specific primitives for long-duration energy storage (LDES) techno-economic
analysis on the storage-medium (SM) capital cost basis.

Implements the C_kWh,SM, LCOS, and C_kWh,max equations from the published
data-collection framework, plus the application cost guidelines (5 USD/kWh for
multi-day LDES, 0.5 USD/kWh for seasonal LDES, 180 USD/kWh for MDES).

The functions are self-contained: they only require numpy and accept primitive
Python args, so they can be chained with the data_processing tools.
"""

import math
import numpy as np
import pandas as pd
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("ldes_tea")

# Application cost-floor guidelines (Table 1 of the dataset's underlying paper).
APPLICATION_GUIDELINES_USD_PER_KWH = {
    "MDES":             180.0,   # mid-duration (~12 h diurnal cycling), N_c~365, CF~0.5
    "multi_day_LDES":     5.0,   # ~100 h, N_c~10, CF~0.1
    "seasonal_LDES":      0.5,   # ~720-2000 h, N_c~1, CF~0.1-0.25
}


@mcp.tool()
def ckwh_sm_from_specific(specific_price_usd_per_kg: float,
                          specific_energy_kwh_per_kg: float) -> dict:
    """Storage-medium energy capital cost from mass-basis prices.

        C_kWh,SM = C_mat / rho_E

    Args:
        specific_price_usd_per_kg: Material specific price (USD/kg).
        specific_energy_kwh_per_kg: Storage-medium specific energy (kWh/kg).

    Returns:
        dict with C_kwh_sm in USD/kWh.
    """
    if specific_energy_kwh_per_kg <= 0:
        return {"error": "specific_energy must be positive", "C_kwh_sm": None}
    return {"C_kwh_sm": float(specific_price_usd_per_kg) / float(specific_energy_kwh_per_kg)}


@mcp.tool()
def ckwh_sm_from_volumetric(vol_price_usd_per_m3: float,
                            mass_density_kg_per_m3: float,
                            specific_energy_kwh_per_kg: float) -> dict:
    """Storage-medium energy capital cost from volumetric prices (e.g. caverns/excavation).

        C_kWh,SM = (C_vol / rho_m) / rho_E

    Args:
        vol_price_usd_per_m3: Volumetric cost of the storage medium (USD/m^3).
        mass_density_kg_per_m3: Material mass density (kg/m^3).
        specific_energy_kwh_per_kg: Specific energy of the SM (kWh/kg).

    Returns:
        dict with C_kwh_sm in USD/kWh.
    """
    if mass_density_kg_per_m3 <= 0 or specific_energy_kwh_per_kg <= 0:
        return {"error": "density and specific_energy must be positive", "C_kwh_sm": None}
    sp_price = vol_price_usd_per_m3 / mass_density_kg_per_m3
    return {"C_kwh_sm": sp_price / specific_energy_kwh_per_kg,
            "implied_specific_price": sp_price}


@mcp.tool()
def specific_energy_thermal(cp_j_per_kg_k: float, delta_T_K: float) -> dict:
    """Sensible thermal storage specific energy:  rho_E = C_p * delta_T.

    Args:
        cp_j_per_kg_k: Specific heat capacity (J / (kg K)).
        delta_T_K: Charge/discharge temperature swing (K).

    Returns:
        dict with rho_E in kWh/kg.
    """
    j_per_kg = cp_j_per_kg_k * delta_T_K
    return {"rho_E_kwh_per_kg": j_per_kg / 3.6e6}


@mcp.tool()
def specific_energy_latent(latent_heat_j_per_kg: float) -> dict:
    """Latent thermal storage specific energy = phase-change latent heat.

    Args:
        latent_heat_j_per_kg: Heat of fusion or transformation (J/kg).

    Returns:
        dict with rho_E in kWh/kg.
    """
    return {"rho_E_kwh_per_kg": float(latent_heat_j_per_kg) / 3.6e6}


@mcp.tool()
def specific_energy_electrochem(deltaV_volt: float, n_e: float, mu_g_per_mol: float) -> dict:
    """Coupled-battery / flow-battery specific energy from electrochemical potentials:

        rho_E = (n * F * deltaV) / mu

    Args:
        deltaV_volt: Cell potential difference (V).
        n_e: Number of electrons transferred per formula unit.
        mu_g_per_mol: Molar mass of the active material (g/mol).

    Returns:
        dict with rho_E in kWh/kg.
    """
    F = 96485.332  # C/mol
    j_per_mol = n_e * F * deltaV_volt
    if mu_g_per_mol <= 0:
        return {"error": "molar mass must be positive", "rho_E_kwh_per_kg": None}
    j_per_g = j_per_mol / mu_g_per_mol
    j_per_kg = j_per_g * 1000.0
    return {"rho_E_kwh_per_kg": j_per_kg / 3.6e6}


@mcp.tool()
def specific_energy_virial(yield_strength_pa: float, mass_density_kg_per_m3: float,
                            Q_max: float = 0.5) -> dict:
    """Virial-theorem specific energy used for flywheels, pressure tanks, and SMES:

        rho_E = Q_max * sigma_a / rho_m

    Q_max is a geometric factor (~0.5 for a thin disk; <1 for real shapes).

    Args:
        yield_strength_pa: Maximum stress the containment material can sustain (Pa).
        mass_density_kg_per_m3: Mass density of the containing material (kg/m^3).
        Q_max: Dimensionless shape factor (default 0.5).

    Returns:
        dict with rho_E in kWh/kg.
    """
    if mass_density_kg_per_m3 <= 0:
        return {"error": "density must be positive", "rho_E_kwh_per_kg": None}
    j_per_kg = Q_max * yield_strength_pa / mass_density_kg_per_m3
    return {"rho_E_kwh_per_kg": j_per_kg / 3.6e6}


@mcp.tool()
def lcos(P_chg_usd_per_kwh: float, eta_RT: float, CF: float, LT_eff_y: float,
         C_kWh_usd_per_kwh: float, C_kW_usd_per_kw: float, DD_h: float,
         DD_nom_h: float = None, eta_d: float = None) -> dict:
    """Levelised cost of storage from the LCOS model used in the dataset paper:

        LCOS = P_chg * (1/eta_RT - 1)
             + 1/(CF * 8760 * LT_eff) * (C_kWh * DD/DD_nom + C_kW * DD/DD_nom)

    For decoupled SM the DD/DD_nom term equals 1 (just C_kWh + C_kW).
    For coupled SM with DD > DD_nom, the C_kW term scales by DD/DD_nom (overbuild).

    Args:
        P_chg_usd_per_kwh: Charging electricity price (USD/kWh).
        eta_RT: Round-trip efficiency in [0, 1].
        CF: Capacity factor in [0, 1] (= N_c / N_c_max).
        LT_eff_y: Effective lifetime including discount-rate (years).
        C_kWh_usd_per_kwh: Energy capital cost (USD/kWh of storage capacity).
        C_kW_usd_per_kw: Power capital cost (USD/kW of PCS rated power).
        DD_h: Actual discharge duration (hours).
        DD_nom_h: Nominal discharge duration; if None or DD_h<=DD_nom_h, uses DD_h.
        eta_d: Discharge efficiency. Defaults to sqrt(eta_RT) if None.

    Returns:
        dict with LCOS in USD/kWh and the three additive terms.
    """
    if eta_d is None:
        eta_d = math.sqrt(eta_RT)
    if DD_nom_h is None or DD_h <= DD_nom_h:
        scale = 1.0
    else:
        scale = DD_h / DD_nom_h
    inefficiency = P_chg_usd_per_kwh * (1.0 / eta_RT - 1.0)
    energy_term = (C_kWh_usd_per_kwh / eta_d) / (CF * 8760.0 * LT_eff_y)
    power_term = (C_kW_usd_per_kw * scale / DD_h) / (CF * 8760.0 * LT_eff_y)
    return {
        "LCOS_usd_per_kwh": inefficiency + energy_term + power_term,
        "inefficiency_term": inefficiency,
        "energy_capital_term": energy_term,
        "power_capital_term": power_term,
    }


@mcp.tool()
def ckwh_max(LCOS_target_usd_per_kwh: float, N_c_per_year: float,
              LT_eff_y: float, eta_d: float) -> dict:
    """Maximum tolerated SM energy capital cost for a target LCOS:

        C_kWh,max = LCOS_target * N_c * LT_eff * eta_d

    This is the cost guideline used to identify "promising" SM for a given
    application (see Equation 2 in the dataset paper).

    Args:
        LCOS_target_usd_per_kwh: Target levelised cost of storage (USD/kWh).
        N_c_per_year: Number of full charge/discharge cycles per year.
        LT_eff_y: Effective lifetime in years.
        eta_d: Discharge efficiency in [0, 1].

    Returns:
        dict with C_kWh,max in USD/kWh.
    """
    return {"C_kwh_max_usd_per_kwh":
            LCOS_target_usd_per_kwh * N_c_per_year * LT_eff_y * eta_d}


@mcp.tool()
def screen_promising(csv_path: str, threshold_usd_per_kwh: float = 5.0,
                      column: str = "C_kwh") -> dict:
    """Identify SM whose C_kWh,SM falls below a target cost guideline.

    Args:
        csv_path: SM_data.csv (the consolidated dataset).
        threshold_usd_per_kwh: Cost guideline (default 5 USD/kWh, multi-day LDES).
        column: Numeric column in the CSV to compare (default C_kwh).

    Returns:
        dict with n_total, n_below, list of {SM_name, SM_type, C_kwh}.
    """
    df = pd.read_csv(csv_path, skiprows=[1, 2], header=0)
    df = df.rename(columns={"Unnamed: 0": "SM_name", "Unnamed: 1": "SM_type"})
    df[column] = pd.to_numeric(df[column], errors="coerce")
    df = df.dropna(subset=[column])
    sub = df[df[column] < threshold_usd_per_kwh].sort_values(column)
    out = sub[["SM_name", "SM_type", column]].to_dict("records")
    by_type = sub["SM_type"].value_counts().to_dict()
    return {
        "n_total": int(len(df)),
        "n_below": int(len(sub)),
        "threshold": threshold_usd_per_kwh,
        "by_SM_type": {str(k): int(v) for k, v in by_type.items()},
        "rows": out,
    }


@mcp.tool()
def application_cost_targets() -> dict:
    """Return the three LDES/MDES cost guidelines from Table 1 of the source paper.

    Returns:
        dict mapping application name -> {C_kwh_max_USD_per_kwh, DD_h_typical, CF_typical}.
    """
    return {
        "MDES":            {"C_kwh_max_USD_per_kwh": 180.0, "DD_h_typical": 12,   "CF_typical": 0.5,  "N_c_per_year": 365},
        "multi_day_LDES":  {"C_kwh_max_USD_per_kwh":   5.0, "DD_h_typical": 100,  "CF_typical": 0.1,  "N_c_per_year": 10},
        "seasonal_LDES":   {"C_kwh_max_USD_per_kwh":   0.5, "DD_h_typical": 720,  "CF_typical": 0.1,  "N_c_per_year": 1},
    }


if __name__ == "__main__":
    mcp.run(transport="stdio")

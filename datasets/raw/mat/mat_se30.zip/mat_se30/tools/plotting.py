#!/usr/bin/env python3
"""
Visualisation primitives for the energy storage TEA task.
All functions write a PNG to disk and return the output path.
"""

import os
import math
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("plotting")


def _load_sm(csv_path: str) -> pd.DataFrame:
    df = pd.read_csv(csv_path, skiprows=[1, 2], header=0)
    df = df.rename(columns={"Unnamed: 0": "SM_name", "Unnamed: 1": "SM_type"})
    return df


@mcp.tool()
def plot_ckwh_by_type(sm_csv_path: str, output_path: str = "artifacts/ckwh_by_type.png",
                       guideline_lines: list = None, log_y: bool = True) -> dict:
    """Strip plot of C_kwh,SM (USD/kWh) per SM_type with optional cost guideline lines.

    Args:
        sm_csv_path: Path to SM_data.csv.
        output_path: Output PNG path.
        guideline_lines: Optional list of horizontal y-values (USD/kWh) to draw.
        log_y: Use log y-axis (default True; spans many orders of magnitude).

    Returns:
        dict with output_path and counts per type.
    """
    df = _load_sm(sm_csv_path)
    df["C_kwh"] = pd.to_numeric(df["C_kwh"], errors="coerce")
    df = df.dropna(subset=["C_kwh"])
    types = sorted(df["SM_type"].dropna().unique().tolist())

    fig, ax = plt.subplots(figsize=(12, 6))
    rng = np.random.default_rng(0)
    for i, t in enumerate(types):
        ys = df.loc[df["SM_type"] == t, "C_kwh"].values
        xs = i + (rng.random(len(ys)) - 0.5) * 0.7
        ax.scatter(xs, ys, s=18, alpha=0.6, label=f"{t} (n={len(ys)})")
    ax.set_xticks(range(len(types)))
    ax.set_xticklabels(types, rotation=45, ha="right", fontsize=9)
    ax.set_ylabel("$C_{kWh,SM}$ (USD/kWh)")
    if log_y:
        ax.set_yscale("log")
    if guideline_lines:
        for g in guideline_lines:
            ax.axhline(g, ls="--", color="grey", alpha=0.6)
            ax.text(len(types) - 0.5, g, f" {g} USD/kWh", va="bottom",
                    ha="right", fontsize=8, color="dimgrey")
    ax.set_title(f"SM energy capital cost by technology type (n={len(df)})")
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=160, bbox_inches="tight")
    plt.close(fig)
    return {"output_path": output_path, "n_total": int(len(df)), "n_types": len(types)}


@mcp.tool()
def plot_specific_energy_hist(sm_csv_path: str,
                               output_path: str = "artifacts/specific_energy_hist.png") -> dict:
    """Histogram of specific energy (kWh/kg) coloured by stored form-of-energy
    classification (chemical / thermal / kinetic / pressure / electrostatic /
    gravitational).

    Args:
        sm_csv_path: Path to SM_data.csv.
        output_path: Output PNG path.

    Returns:
        dict with output_path.
    """
    df = _load_sm(sm_csv_path)
    df["specific_energy"] = pd.to_numeric(df["specific_energy"], errors="coerce")
    df = df.dropna(subset=["specific_energy"])
    df = df[df["specific_energy"] > 0]

    form_map = {
        "synfuel": "chemical", "coupled_battery": "chemical", "flow_battery": "chemical",
        "thermochemical": "chemical",
        "sensible_thermal": "thermal", "latent_thermal": "thermal",
        "flywheel": "kinetic",
        "pressure_tank": "pressure", "pressure_cavern": "pressure",
        "smes": "magnetic",
        "EDLC": "electrostatic", "dielectric_capacitor": "electrostatic",
        "pseudocapacitor": "electrostatic",
        "PHES": "gravitational", "block_stacking": "gravitational",
    }
    df["form"] = df["SM_type"].map(form_map).fillna("other")

    bins = np.logspace(np.log10(df.specific_energy.min()),
                       np.log10(df.specific_energy.max()), 30)
    fig, ax = plt.subplots(figsize=(8, 5))
    forms = ["chemical", "thermal", "kinetic", "pressure", "electrostatic",
             "magnetic", "gravitational"]
    for f in forms:
        sub = df[df["form"] == f]
        if len(sub):
            ax.hist(sub["specific_energy"], bins=bins, alpha=0.6, label=f"{f} (n={len(sub)})")
    ax.set_xscale("log")
    ax.set_xlabel(r"Specific energy $\rho_E$ (kWh/kg)")
    ax.set_ylabel("Count")
    ax.set_title(f"Specific-energy histogram (n={len(df)} SM)")
    ax.legend(fontsize=8)
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=160, bbox_inches="tight")
    plt.close(fig)
    return {"output_path": output_path, "n": int(len(df))}


@mcp.tool()
def plot_lcos_vs_duration(C_kwh_list: list, P_chg: float = 0.11,
                            C_kw: float = 75.0, eta_RT: float = 0.85,
                            CF: float = 0.5, LT_eff_y: float = 10.0,
                            DD_h_min: float = 1.0, DD_h_max: float = 200.0,
                            output_path: str = "artifacts/lcos_vs_duration.png") -> dict:
    """LCOS vs discharge duration curves for a given list of C_kWh,SM values
    (decoupled, DD_nom = DD).

    Args:
        C_kwh_list: List of energy capital costs in USD/kWh to overlay.
        P_chg: Charging electricity price (USD/kWh). Paper default 0.11.
        C_kw: Power capital cost (USD/kW). Paper default 75.
        eta_RT: Round-trip efficiency. Paper default 0.85.
        CF: Capacity factor. Paper default 0.5.
        LT_eff_y: Effective lifetime years. Paper default 10.
        DD_h_min, DD_h_max: Range of discharge duration to sweep.
        output_path: Output PNG path.

    Returns:
        dict with output_path.
    """
    DD = np.logspace(np.log10(DD_h_min), np.log10(DD_h_max), 80)
    eta_d = math.sqrt(eta_RT)
    fig, ax = plt.subplots(figsize=(7, 5))
    for c in C_kwh_list:
        lcos = (P_chg * (1.0 / eta_RT - 1.0)
                + (c / eta_d + C_kw / DD) / (CF * 8760.0 * LT_eff_y))
        ax.plot(DD, lcos, label=f"$C_{{kWh}}$ = {c} USD/kWh")
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlabel("Discharge duration DD (h)")
    ax.set_ylabel("LCOS (USD/kWh)")
    ax.set_title("Decoupled LCOS scaling with duration")
    ax.legend(fontsize=8)
    ax.grid(True, which="both", alpha=0.3)
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=160, bbox_inches="tight")
    plt.close(fig)
    return {"output_path": output_path}


@mcp.tool()
def plot_ranking_table(sm_csv_path: str, top_n: int = 10,
                        output_path: str = "artifacts/cheapest_ranking.png") -> dict:
    """Bar chart of the N cheapest SM by C_kwh,SM (one bar per SM, coloured by SM_type).

    Args:
        sm_csv_path: Path to SM_data.csv.
        top_n: How many cheapest SM to plot.
        output_path: Output PNG path.

    Returns:
        dict with output_path and the ranking.
    """
    df = _load_sm(sm_csv_path)
    df["C_kwh"] = pd.to_numeric(df["C_kwh"], errors="coerce")
    df = df.dropna(subset=["C_kwh"])
    df = df.sort_values("C_kwh").head(top_n)
    types = df["SM_type"].unique().tolist()
    cmap = plt.cm.tab10(np.linspace(0, 1, max(len(types), 1)))
    color_map = {t: cmap[i] for i, t in enumerate(types)}
    colors = [color_map[t] for t in df["SM_type"]]

    fig, ax = plt.subplots(figsize=(9, 5))
    pos = range(len(df))
    ax.barh(pos, df["C_kwh"], color=colors)
    ax.set_yticks(list(pos))
    ax.set_yticklabels([f"{n} ({t})" for n, t in zip(df["SM_name"], df["SM_type"])],
                       fontsize=9)
    ax.invert_yaxis()
    ax.set_xscale("log")
    ax.set_xlabel("$C_{kWh,SM}$ (USD/kWh)")
    ax.set_title(f"Top-{top_n} cheapest storage media")
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=160, bbox_inches="tight")
    plt.close(fig)
    return {"output_path": output_path,
            "ranking": df[["SM_name", "SM_type", "C_kwh"]].to_dict("records")}


if __name__ == "__main__":
    mcp.run(transport="stdio")


def plot_thermal_temperature_distribution(sm_df, output_path, sm_type_col='SM_type',
                                          sub_type_col='sub_type',
                                          t_min_col='T_min', t_max_col='T_max',
                                          t_melt_col='T_melt', t_turning_col='T_turning'):
    """Strip/box plot of operating-temperature range for the thermal-storage subset.

    For each thermal storage medium (sensible / latent / thermochemical sub-types),
    plots its operating-temperature value(s):
    - sensible thermal: vertical line from T_min to T_max
    - latent thermal:   T_melt point
    - thermochemical:   T_turning point

    Args:
        sm_df: DataFrame with the columns listed in arguments.
        output_path: path to save PNG.
    Returns:
        {"path": output_path}
    """
    import matplotlib.pyplot as plt
    import pandas as pd
    thermal_mask = sm_df[sm_type_col].str.contains('thermal|thermochem', case=False, na=False)
    df = sm_df[thermal_mask].copy()
    fig, ax = plt.subplots(figsize=(10, 6))
    y = 0
    for sub, group in df.groupby(sub_type_col):
        for _, row in group.iterrows():
            if 'sensible' in str(sub).lower():
                tmin, tmax = row.get(t_min_col), row.get(t_max_col)
                if pd.notna(tmin) and pd.notna(tmax):
                    ax.plot([tmin, tmax], [y, y], 'b-', linewidth=2)
            elif 'latent' in str(sub).lower():
                tm = row.get(t_melt_col)
                if pd.notna(tm):
                    ax.plot(tm, y, 'g^', markersize=8)
            elif 'thermochem' in str(sub).lower():
                tt = row.get(t_turning_col)
                if pd.notna(tt):
                    ax.plot(tt, y, 'rs', markersize=8)
            y += 1
    ax.set_xlabel('Temperature (deg C)'); ax.set_ylabel('Storage media (per row)')
    ax.set_title('Thermal-storage operating-temperature range by sub-type')
    plt.tight_layout(); plt.savefig(output_path, dpi=120, bbox_inches='tight')
    plt.close(fig)
    return {"path": output_path}


def plot_specific_energy_vs_ckwh(sm_df, output_path, ckwh_col='C_kwh',
                                  spe_col='specific_energy', sm_type_col='SM_type'):
    """Scatter plot of specific energy (Wh/kg) vs C_kWh,SM colored by SM_type.

    Tracks the cost-vs-energy-density frontier across mechanical, electrochemical,
    and thermal classes.

    Args:
        sm_df: DataFrame.
        output_path: path to save PNG.
    Returns:
        {"path": output_path}
    """
    import matplotlib.pyplot as plt
    import pandas as pd
    fig, ax = plt.subplots(figsize=(10, 6))
    df = sm_df.dropna(subset=[ckwh_col, spe_col])
    for typ, group in df.groupby(sm_type_col):
        ax.scatter(group[ckwh_col].astype(float), group[spe_col].astype(float),
                   label=str(typ), alpha=0.7, s=40)
    ax.set_xscale('log'); ax.set_yscale('log')
    ax.set_xlabel('C_kWh,SM (USD/kWh)'); ax.set_ylabel('specific_energy (Wh/kg)')
    ax.set_title('Specific energy vs storage-medium cost')
    ax.legend(loc='best', fontsize=8); ax.grid(alpha=0.3)
    plt.tight_layout(); plt.savefig(output_path, dpi=120, bbox_inches='tight')
    plt.close(fig)
    return {"path": output_path}

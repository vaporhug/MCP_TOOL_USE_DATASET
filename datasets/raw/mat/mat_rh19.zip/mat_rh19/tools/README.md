# mat_rh19 — Tool Reference

## Database Retrieval (`database_retrieval.py`)

Generic stubs that an agent can fill in at runtime when external lookup is needed
(websearch, fetch_url, query_pubchem, query_chembl, query_uniprot, query_pdb,
query_geo, query_ncbi_entrez, query_usgs_comcat, query_world_bank,
query_openalex, query_doi).

## Data Processing (`data_processing.py`)

- **read_csv / write_csv / read_json / write_json**: text-format I/O.
- **read_excel / read_parquet / read_netcdf / read_shapefile / read_fasta**:
  binary / domain readers (stubs except for FASTA).
- **pivot_long_to_wide / pivot_wide_to_long**: reshape helpers.
- **drop_missing**: filter rows with empty cells.
- **coerce_numeric**: cast columns to float, ``None`` on failure.
- **join_tables**: SQL-style single-key join.
- **groupby_aggregate**: `mean | sum | min | max | count` per group.

## Domain-specific RHEA tools (`rhea_ml_tools.py`, `@mcp.tool()`)

Composition + descriptor primitives:

- **parse_alloy_formula**: ``Al0.25MoNbTiV`` -> {element: subscript} +
  normalised mole fractions.
- **load_element_properties**: load the element-property reference CSV
  (atomic radius, shear modulus, melting point, VEC, elemental yield strength,
  Hall-Petch locking parameter).
- **load_binary_mixing_enthalpy**: load the 45-pair binary mixing enthalpy
  table for the 10 alloying elements.
- **lookup_element_property**: per-element single-property lookup.
- **rule_of_mixtures**: linear composition-weighted mixing rule.
- **weighted_pair_descriptor**: ``delta`` (mismatch) or a non-negative RMS
  ``modulus_distortion`` aggregate.
- **per_element_descriptor**: Senkov-style ``delta_G_i`` for one chosen
  element (e.g. Ta).
- **yang_omega_descriptor**: recompute Yang Omega from candidate composition,
  melting temperatures, ideal configurational entropy, and binary mixing
  enthalpies.

Modelling:

- **sequential_forward_selection**: greedy SFS with k-fold CV scoring.
- **repeated_kfold_train_evaluate**: train (random_forest, gradient_boosting,
  xgboost, ridge, lasso) over many K-fold repetitions; returns per-sample
  mean / std of predictions, aggregate metrics, and stores the final model.
- **compute_tree_shap**: mean |SHAP| feature importance for tree models.

Plotting:

- **plot_parity**: predicted-vs-measured scatter (optional colour bar).
- **plot_feature_distribution**: histogram of a 1-D quantity (e.g.
  per-sample prediction std, prediction errors).
- **plot_temperature_yield_curve**: T vs yield-strength curve plot, with
  optional symmetric error bars.
- **plot_shap_bar**: horizontal bar plot of SHAP rankings.

Inverse design:

- **optimize_composition**: SciPy `differential_evolution` over an alloy's
  element fractions, maximising a model-predicted yield strength at a chosen
  temperature, with element-fraction bounds [0.02, 0.35] and a sum-to-one
  Lampinen penalty. The reported yield strength is recomputed from the
  normalised optimum composition and excludes the constraint penalty. The
  caller supplies an ordered `descriptor_config` that matches the trained
  model's feature order; candidate-dependent descriptors are refreshed from
  each candidate composition and fixed caller-supplied values are identified in
  `descriptor_sources`. Omega descriptors can reference
  `input_data/data/binary_mixing_enthalpy_kJ_mol.csv` through
  `pair_enthalpy_csv`.

## Dependencies

```
numpy
pandas
scikit-learn
xgboost
shap
scipy
matplotlib
mcp (FastMCP)
```

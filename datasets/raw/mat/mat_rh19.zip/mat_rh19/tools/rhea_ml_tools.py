#!/usr/bin/env python3
"""Domain-specific primitives for refractory high-entropy alloy (RHEA) yield-strength
modelling.

These tools are LOW-LEVEL building blocks. They do *not* implement any whole
pipeline (the agent must wire them together itself). They cover:

    1. Composition string parsing           (parse_alloy_formula)
    2. Element-property table lookup        (load_element_properties, lookup_element_property)
    3. Mole-fraction descriptor primitives  (rule_of_mixtures, weighted_pair_descriptor)
    4. Sequential forward feature selection (sequential_forward_selection)
    5. Repeated k-fold CV training/eval     (repeated_kfold_train_evaluate)
    6. SHAP feature importance              (compute_tree_shap)
    7. Plotting primitives                  (plot_parity, plot_feature_distribution,
                                             plot_temperature_yield_curve)

No answer-side numbers are hard-coded. Each function returns *raw* values that
the caller must combine to reach a conclusion.
"""

from __future__ import annotations

import csv
import json
import re
import math
import os
import pickle
import hashlib
from typing import Any

import numpy as np
from mcp.server.fastmcp import FastMCP


mcp = FastMCP("RHEA_ML_Tools")


# ----------------------------------------------------------------------------
# 1. Composition parsing
# ----------------------------------------------------------------------------
@mcp.tool()
def parse_alloy_formula(formula: str) -> dict:
    """Parse an alloy formula like ``Al0.25MoNbTiV`` or ``HfNbTaTiZr`` into
    {element: subscript} pairs and normalised mole fractions.

    Rules
    -----
    * Elements without a subscript are treated as 1.0.
    * Subscripts may be int or float (e.g. ``Mo0.5``).
    * The returned ``mole_fraction`` dict sums to 1.0.

    Args:
        formula: Alloy formula string.

    Returns:
        dict with keys ``raw_subscripts`` (atom counts) and
        ``mole_fraction`` (fractions summing to 1).
    """
    pattern = re.compile(r"([A-Z][a-z]?)(\d*\.?\d*)")
    raw: dict[str, float] = {}
    pos = 0
    for m in pattern.finditer(formula):
        if m.start() != pos:
            # Non-matching characters between symbols
            pass
        pos = m.end()
        sym, sub = m.group(1), m.group(2)
        if not sym:
            continue
        n = float(sub) if sub else 1.0
        raw[sym] = raw.get(sym, 0.0) + n
    total = sum(raw.values())
    if total == 0:
        return {"raw_subscripts": {}, "mole_fraction": {}, "n_elements": 0}
    mf = {k: round(v / total, 8) for k, v in raw.items()}
    return {
        "raw_subscripts": {k: round(v, 6) for k, v in raw.items()},
        "mole_fraction": mf,
        "n_elements": len(raw),
    }


# ----------------------------------------------------------------------------
# 2. Element property table (CSV in input_data/data/element_properties.csv)
# ----------------------------------------------------------------------------
@mcp.tool()
def load_element_properties(csv_path: str) -> list[dict]:
    """Load the element-property reference table.

    Args:
        csv_path: Path to ``element_properties.csv`` (must contain columns
            ``element``, ``atomic_radius_pm``, ``shear_modulus_GPa``,
            ``melting_point_K``, ``VEC``, ``yield_strength_MPa``,
            ``HP_K_MPa_m05``).

    Returns:
        list of {element, atomic_radius_pm, shear_modulus_GPa,
        melting_point_K, VEC, yield_strength_MPa, HP_K_MPa_m05} rows
        with numeric fields cast to float.
    """
    out: list[dict] = []
    with open(csv_path, newline="") as f:
        for r in csv.DictReader(f):
            row = {"element": r["element"]}
            for k, v in r.items():
                if k == "element":
                    continue
                try:
                    row[k] = float(v)
                except (TypeError, ValueError):
                    row[k] = None
            out.append(row)
    return out


@mcp.tool()
def load_binary_mixing_enthalpy(csv_path: str) -> dict:
    """Load binary mixing enthalpies as a symmetric pair dictionary.

    Expected columns: element_i, element_j, delta_H_mix_kJ_mol.
    """
    pairs: dict[str, float] = {}
    with open(csv_path, newline="") as f:
        for row in csv.DictReader(f):
            a = row["element_i"].strip()
            b = row["element_j"].strip()
            val = float(row["delta_H_mix_kJ_mol"])
            pairs[f"{a}-{b}"] = val
            pairs[f"{b}-{a}"] = val
    return pairs


@mcp.tool()
def lookup_element_property(elements: list[str], prop: str,
                            csv_path: str) -> dict:
    """Look up a single property for a list of elements.

    Args:
        elements: List of element symbols.
        prop: Column name in the property table.
        csv_path: Path to ``element_properties.csv``.

    Returns:
        dict mapping element -> value (None if missing).
    """
    table = load_element_properties(csv_path)
    idx = {row["element"]: row for row in table}
    return {el: idx.get(el, {}).get(prop) for el in elements}


# ----------------------------------------------------------------------------
# 3. Composition descriptor primitives
# ----------------------------------------------------------------------------
@mcp.tool()
def rule_of_mixtures(mole_fraction: dict, prop_table: list[dict],
                      prop: str) -> float:
    """Compute the rule-of-mixtures (linear) value for a property.

    Returns sum_i x_i * P_i where P_i is taken from ``prop_table``.

    Args:
        mole_fraction: {element: fraction}.
        prop_table: Output of ``load_element_properties``.
        prop: Property column name.

    Returns:
        float (NaN-like None if any element is missing the property).
    """
    idx = {row["element"]: row for row in prop_table}
    s = 0.0
    for el, x in mole_fraction.items():
        v = idx.get(el, {}).get(prop)
        if v is None:
            return float("nan")
        s += x * v
    return float(s)


@mcp.tool()
def weighted_pair_descriptor(mole_fraction: dict, prop_table: list[dict],
                              prop: str, mode: str = "delta") -> float:
    """Composition-weighted pairwise descriptor.

    ``mode`` choices
    ----------------
    * ``delta`` -> sqrt( sum_i x_i * (1 - P_i / P_bar)^2 )
        (mismatch in ``prop`` relative to the rule-of-mixtures average)
    * ``modulus_distortion`` -> sqrt((9/8) * sum_i sum_j
        x_i*x_j*(2*(P_i-P_j)/(P_i+P_j))^2). The squared symmetric aggregate is
        non-negative and avoids cancellation between stiff and compliant
        elements.

    Args:
        mole_fraction: {element: fraction}.
        prop_table: Output of ``load_element_properties``.
        prop: Property column name.
        mode: ``delta`` or ``modulus_distortion``.

    Returns:
        float scalar.
    """
    idx = {row["element"]: row for row in prop_table}
    pairs = [(el, x, idx.get(el, {}).get(prop)) for el, x in mole_fraction.items()]
    if any(p is None for _, _, p in pairs):
        return float("nan")

    if mode == "delta":
        p_bar = sum(x * p for _, x, p in pairs)
        if p_bar == 0:
            return float("nan")
        return float(math.sqrt(sum(x * (1.0 - p / p_bar) ** 2 for _, x, p in pairs)))

    if mode == "modulus_distortion":
        total = 0.0
        for el_i, x_i, p_i in pairs:
            for el_j, x_j, p_j in pairs:
                if (p_i + p_j) == 0:
                    continue
                mismatch = 2.0 * (p_i - p_j) / (p_i + p_j)
                total += x_i * x_j * mismatch * mismatch
        return float(math.sqrt((9.0 / 8.0) * total))

    raise ValueError(f"Unknown mode: {mode}")


@mcp.tool()
def per_element_descriptor(mole_fraction: dict, prop_table: list[dict],
                            target_element: str, prop: str = "shear_modulus_GPa"
                            ) -> float:
    """Senkov-style per-element ``delta_G_i`` for ``target_element``:

        delta_G_i = (9/8) * sum_j x_j * 2(G_i - G_j) / (G_i + G_j)

    Useful for constructing element-specific modulus-mismatch descriptors.

    Returns 0 if ``target_element`` is not in the alloy.
    """
    idx = {row["element"]: row for row in prop_table}
    if target_element not in mole_fraction:
        return 0.0
    p_i = idx.get(target_element, {}).get(prop)
    if p_i is None:
        return float("nan")
    inner = 0.0
    for el_j, x_j in mole_fraction.items():
        p_j = idx.get(el_j, {}).get(prop)
        if p_j is None or (p_i + p_j) == 0:
            continue
        inner += x_j * 2.0 * (p_i - p_j) / (p_i + p_j)
    return float((9.0 / 8.0) * inner)


def _normalise_mole_fraction(mole_fraction: dict) -> dict:
    total = float(sum(float(v) for v in mole_fraction.values()))
    if total <= 0:
        raise ValueError("composition fractions must have positive sum")
    return {str(k): float(v) / total for k, v in mole_fraction.items()
            if float(v) > 0}


def _omega_from_pair_enthalpies(mole_fraction: dict, prop_table: list[dict],
                                pair_enthalpies: dict) -> float:
    """Regular-solution Yang Omega from supplied binary mixing enthalpies.

    `pair_enthalpies` maps keys like `Al-Ta` or `Ta|Al` to kJ/mol values.
    The function deliberately requires those pair values instead of inventing
    thermodynamic data from the element-property table.
    """
    R = 8.314462618  # J mol^-1 K^-1
    mf = _normalise_mole_fraction(mole_fraction)
    elements = list(mf)
    tm = rule_of_mixtures(mf, prop_table, "melting_point_K")
    entropy = -R * sum(x * math.log(x) for x in mf.values() if x > 0)
    hmix = 0.0
    for i, ei in enumerate(elements):
        for ej in elements[i + 1:]:
            key_options = (f"{ei}-{ej}", f"{ej}-{ei}", f"{ei}|{ej}", f"{ej}|{ei}")
            hij = next((pair_enthalpies[k] for k in key_options
                        if k in pair_enthalpies), None)
            if hij is None:
                raise ValueError(f"missing pair mixing enthalpy for {ei}-{ej}")
            hmix += 4.0 * mf[ei] * mf[ej] * float(hij)
    if hmix == 0:
        return float("inf")
    return float((tm * entropy) / (abs(hmix) * 1000.0))


@mcp.tool()
def yang_omega_descriptor(mole_fraction: dict, prop_table: list[dict],
                          pair_enthalpies: dict | None = None,
                          pair_enthalpy_csv: str | None = None) -> float:
    """Compute Yang Omega for a candidate composition.

    Uses rule-of-mixtures melting temperature, ideal configurational entropy,
    and binary mixing enthalpies. Provide either an in-memory pair dictionary
    or the released pair-enthalpy CSV.
    """
    if pair_enthalpies is None:
        if pair_enthalpy_csv is None:
            raise ValueError("provide pair_enthalpies or pair_enthalpy_csv")
        pair_enthalpies = load_binary_mixing_enthalpy(pair_enthalpy_csv)
    return _omega_from_pair_enthalpies(mole_fraction, prop_table, pair_enthalpies)


def _configured_descriptor_features(mole_fraction: dict, prop_table: list[dict],
                                    target_temperature: float,
                                    descriptor_config: list[dict] | dict
                                    ) -> tuple[np.ndarray, dict, dict]:
    """Build a model feature vector from caller-specified descriptor specs.

    The caller controls descriptor order, so this optimizer can be used after
    any feature-selection step rather than baking in one paper-specific recipe.
    Supported spec kinds: temperature, fixed_value, omega, delta,
    per_element, fraction, rule_of_mixtures, sqrt_rule_of_mixtures.
    """
    mf = _normalise_mole_fraction(mole_fraction)
    if isinstance(descriptor_config, dict):
        specs = descriptor_config.get("descriptors", [])
    else:
        specs = descriptor_config
    if not specs:
        raise ValueError("descriptor_config must provide at least one descriptor spec")

    values = {}
    sources = {}
    vector = []
    for idx, spec in enumerate(specs):
        kind = spec.get("kind")
        name = spec.get("name") or f"{kind}_{idx}"
        if kind == "temperature":
            value = float(target_temperature)
            source = "target_temperature_argument"
        elif kind == "fixed_value":
            value = float(spec["value"])
            source = "caller_supplied_fixed_value"
        elif kind == "omega":
            if "mixing_enthalpy_pairs_kJ_mol" in spec:
                value = _omega_from_pair_enthalpies(
                    mf, prop_table, spec["mixing_enthalpy_pairs_kJ_mol"])
                source = "recomputed_from_pair_enthalpies"
            elif "pair_enthalpy_csv" in spec:
                value = yang_omega_descriptor(
                    mf, prop_table, pair_enthalpy_csv=spec["pair_enthalpy_csv"])
                source = "recomputed_from_pair_enthalpy_csv"
            elif "value" in spec:
                value = float(spec["value"])
                source = "caller_supplied_omega"
            else:
                raise ValueError("omega descriptor needs value, pair_enthalpy_csv, or pair enthalpies")
        elif kind == "delta":
            prop = spec.get("prop", "atomic_radius_pm")
            value = weighted_pair_descriptor(mf, prop_table, prop, "delta")
            source = f"recomputed_delta_from_{prop}"
        elif kind == "per_element":
            prop = spec.get("prop", "shear_modulus_GPa")
            element = spec["element"]
            value = per_element_descriptor(mf, prop_table, element, prop)
            source = f"recomputed_per_element_{element}_from_{prop}"
        elif kind == "fraction":
            element = spec["element"]
            value = mf.get(element, 0.0)
            source = f"recomputed_fraction_{element}"
        elif kind == "rule_of_mixtures":
            prop = spec["prop"]
            value = rule_of_mixtures(mf, prop_table, prop)
            source = f"recomputed_rule_of_mixtures_{prop}"
        elif kind == "sqrt_rule_of_mixtures":
            prop = spec["prop"]
            raw = rule_of_mixtures(mf, prop_table, prop)
            value = math.sqrt(max(raw, 0.0))
            source = f"recomputed_sqrt_rule_of_mixtures_{prop}"
        else:
            raise ValueError(f"unsupported descriptor kind: {kind}")
        values[name] = float(value)
        sources[name] = source
        vector.append(float(value))
    return np.array([vector]), values, sources


# ----------------------------------------------------------------------------
# 4. Sequential forward feature selection
# ----------------------------------------------------------------------------
@mcp.tool()
def sequential_forward_selection(features: list[list[float]],
                                  target: list[float],
                                  feature_names: list[str],
                                  max_features: int = 10,
                                  cv_folds: int = 5,
                                  model_type: str = "random_forest",
                                  random_state: int = 0) -> dict:
    """Greedy SFS that adds the feature giving the largest CV R^2 each round.

    Args:
        features: 2-D list (n_samples x n_features).
        target: 1-D list (n_samples).
        feature_names: Length n_features.
        max_features: Maximum number of features to add.
        cv_folds: Number of K-fold splits.
        model_type: ``random_forest`` (default), ``gradient_boosting``,
            ``ridge`` or ``lasso``.
        random_state: RNG seed.

    Returns:
        dict with the ordered list of selected features and the CV R^2 at
        each step.
    """
    from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
    from sklearn.linear_model import Ridge, Lasso
    from sklearn.model_selection import KFold, cross_val_score

    X = np.asarray(features, dtype=float)
    y = np.asarray(target, dtype=float)

    def make_model():
        if model_type == "random_forest":
            return RandomForestRegressor(n_estimators=100, min_samples_split=2,
                                          min_samples_leaf=1,
                                          random_state=random_state)
        if model_type == "gradient_boosting":
            return GradientBoostingRegressor(random_state=random_state)
        if model_type == "ridge":
            return Ridge(alpha=1.0, random_state=random_state)
        if model_type == "lasso":
            return Lasso(alpha=0.001, random_state=random_state, max_iter=20000)
        raise ValueError(f"Unknown model_type: {model_type}")

    selected: list[int] = []
    history: list[dict] = []
    remaining = list(range(X.shape[1]))
    kf = KFold(n_splits=cv_folds, shuffle=True, random_state=random_state)

    for step in range(min(max_features, X.shape[1])):
        best_score = -1e30
        best_idx = None
        for j in remaining:
            cols = selected + [j]
            scores = cross_val_score(make_model(), X[:, cols], y, cv=kf,
                                      scoring="r2")
            s = float(scores.mean())
            if s > best_score:
                best_score, best_idx = s, j
        selected.append(best_idx)
        remaining.remove(best_idx)
        history.append({
            "step": step + 1,
            "added_feature": feature_names[best_idx],
            "added_index": int(best_idx),
            "cv_r2_mean": round(best_score, 6),
            "selected_so_far": [feature_names[i] for i in selected],
        })

    return {
        "model_type": model_type,
        "n_total_features": X.shape[1],
        "history": history,
        "final_selection": [feature_names[i] for i in selected],
    }


# ----------------------------------------------------------------------------
# 5. Repeated K-Fold cross-validated training
# ----------------------------------------------------------------------------
@mcp.tool()
def repeated_kfold_train_evaluate(features: list[list[float]],
                                   target: list[float],
                                   model_type: str = "random_forest",
                                   n_repeats: int = 100,
                                   cv_folds: int = 5,
                                   random_state: int = 0,
                                   model_params: dict | None = None) -> dict:
    """Repeated K-fold CV. For each sample collect the predictions made
    when it was in a held-out fold, across ``n_repeats`` repetitions.

    Returns mean / std prediction per sample, plus aggregate metrics
    (R^2, MAE, RMSE) over the pooled out-of-fold predictions.

    Args:
        features: 2-D list (n_samples x n_features).
        target: 1-D list (n_samples).
        model_type: ``random_forest``, ``gradient_boosting``, ``xgboost``,
            ``ridge`` or ``lasso``.
        n_repeats: Number of repetitions (the paper uses 1000; lower for
            interactive use).
        cv_folds: Number of K-fold splits.
        random_state: RNG seed.
        model_params: Override default hyperparameters.

    Returns:
        dict with per-sample mean/std predictions, aggregate metrics, and
        a ``model_id`` so that subsequent tools (SHAP, plotting) can be
        called.
    """
    from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
    from sklearn.linear_model import Ridge, Lasso
    from sklearn.model_selection import KFold
    from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error

    X = np.asarray(features, dtype=float)
    y = np.asarray(target, dtype=float)
    params = model_params or {}

    def make_model():
        if model_type == "random_forest":
            dp = {"n_estimators": 100, "min_samples_split": 2,
                  "min_samples_leaf": 1, "random_state": random_state}
            dp.update(params)
            return RandomForestRegressor(**dp)
        if model_type == "gradient_boosting":
            dp = {"n_estimators": 200, "random_state": random_state}
            dp.update(params)
            return GradientBoostingRegressor(**dp)
        if model_type == "xgboost":
            import xgboost
            dp = {"n_estimators": 200, "learning_rate": 0.05, "max_depth": 6,
                  "verbosity": 0, "random_state": random_state}
            dp.update(params)
            return xgboost.XGBRegressor(**dp)
        if model_type == "ridge":
            dp = {"alpha": 1.0, "random_state": random_state}
            dp.update(params)
            return Ridge(**dp)
        if model_type == "lasso":
            dp = {"alpha": 0.01, "random_state": random_state, "max_iter": 50000}
            dp.update(params)
            return Lasso(**dp)
        raise ValueError(f"Unknown model_type: {model_type}")

    n = len(y)
    pred_sum = np.zeros(n)
    pred_sqsum = np.zeros(n)
    pred_n = np.zeros(n, dtype=int)

    rng = np.random.default_rng(random_state)
    for rep in range(n_repeats):
        seed = int(rng.integers(0, 1_000_000_000))
        kf = KFold(n_splits=cv_folds, shuffle=True, random_state=seed)
        for tr, te in kf.split(X):
            m = make_model()
            m.fit(X[tr], y[tr])
            p = m.predict(X[te])
            pred_sum[te] += p
            pred_sqsum[te] += p ** 2
            pred_n[te] += 1

    pred_n[pred_n == 0] = 1
    mean_pred = pred_sum / pred_n
    var_pred = np.maximum(pred_sqsum / pred_n - mean_pred ** 2, 0.0)
    std_pred = np.sqrt(var_pred)

    # Final fit on all data so SHAP has a model
    final = make_model()
    final.fit(X, y)
    blob = pickle.dumps({"model": final, "X": X, "y": y,
                          "feature_count": X.shape[1]})
    mid = hashlib.md5(blob[:1024]).hexdigest()[:8]
    with open(f"/tmp/rhea_model_{mid}.pkl", "wb") as f:
        f.write(blob)

    return {
        "model_id": mid,
        "model_type": model_type,
        "n_samples": n,
        "n_features": X.shape[1],
        "n_repeats": n_repeats,
        "cv_folds": cv_folds,
        "mean_predictions": [round(float(v), 4) for v in mean_pred],
        "std_predictions": [round(float(v), 4) for v in std_pred],
        "true_values": [round(float(v), 4) for v in y],
        "metrics": {
            "r2_oof": round(float(r2_score(y, mean_pred)), 4),
            "mae_oof": round(float(mean_absolute_error(y, mean_pred)), 4),
            "rmse_oof": round(float(math.sqrt(mean_squared_error(y, mean_pred))), 4),
            "mean_per_sample_std": round(float(std_pred.mean()), 4),
            "median_per_sample_std": round(float(np.median(std_pred)), 4),
        },
    }


# ----------------------------------------------------------------------------
# 6. SHAP feature importance (tree models only)
# ----------------------------------------------------------------------------
@mcp.tool()
def compute_tree_shap(model_id: str, feature_names: list[str] | None = None
                       ) -> dict:
    """Mean |SHAP| ranking from a tree-based model produced by
    ``repeated_kfold_train_evaluate``.

    Args:
        model_id: Identifier returned by ``repeated_kfold_train_evaluate``.
        feature_names: Optional names for nicer reporting.

    Returns:
        dict with ranked features by mean absolute SHAP value, plus the
        per-sample SHAP value matrix (truncated to first 200 rows).
    """
    import shap

    with open(f"/tmp/rhea_model_{model_id}.pkl", "rb") as f:
        s = pickle.load(f)
    model = s["model"]
    X = s["X"]

    explainer = shap.TreeExplainer(model)
    sv = explainer.shap_values(X)
    if isinstance(sv, list):
        sv = sv[0]
    mean_abs = np.abs(sv).mean(axis=0)
    order = np.argsort(mean_abs)[::-1]

    names = feature_names or [f"f{i}" for i in range(X.shape[1])]
    return {
        "model_id": model_id,
        "n_features": int(X.shape[1]),
        "ranking": [
            {"rank": i + 1,
             "feature_index": int(j),
             "feature_name": names[j],
             "mean_abs_shap": round(float(mean_abs[j]), 6)}
            for i, j in enumerate(order)
        ],
        "shap_values_preview": sv[:200].round(6).tolist(),
        "feature_values_preview": X[:200].round(6).tolist(),
    }


# ----------------------------------------------------------------------------
# 7. Plotting primitives
# ----------------------------------------------------------------------------
@mcp.tool()
def plot_parity(predictions: list[float], true_values: list[float],
                 colour_by: list[float] | None = None,
                 colour_label: str = "",
                 output_path: str = "artifacts/parity.png",
                 title: str = "Predicted vs Measured") -> dict:
    """Parity plot of predicted vs measured values.

    Args:
        predictions: Mean predictions.
        true_values: Ground-truth target values.
        colour_by: Optional per-point colour value (e.g. test temperature).
        colour_label: Colourbar label.
        output_path: Output PNG path.
        title: Plot title.

    Returns:
        dict with output_path, n_points, R^2, RMSE.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from sklearn.metrics import r2_score, mean_squared_error

    p = np.asarray(predictions, dtype=float)
    y = np.asarray(true_values, dtype=float)

    fig, ax = plt.subplots(figsize=(6.5, 6))
    if colour_by is not None:
        sc = ax.scatter(y, p, c=colour_by, cmap="viridis", s=22, alpha=0.8,
                         edgecolors="k", linewidths=0.3)
        cb = plt.colorbar(sc, ax=ax)
        cb.set_label(colour_label)
    else:
        ax.scatter(y, p, s=22, alpha=0.7, edgecolors="k", linewidths=0.3)
    lo = float(min(y.min(), p.min()))
    hi = float(max(y.max(), p.max()))
    ax.plot([lo, hi], [lo, hi], "k--", lw=1)
    ax.set_xlabel("Measured")
    ax.set_ylabel("Predicted")
    r2 = r2_score(y, p)
    rmse = math.sqrt(mean_squared_error(y, p))
    ax.set_title(f"{title}  (R^2={r2:.3f}, RMSE={rmse:.1f})")
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"output_path": output_path, "n_points": int(len(y)),
            "r2": round(float(r2), 4), "rmse": round(float(rmse), 4)}


@mcp.tool()
def plot_feature_distribution(values: list[float], bins: int = 30,
                                xlabel: str = "value",
                                output_path: str = "artifacts/dist.png",
                                title: str = "Distribution") -> dict:
    """Histogram of a single quantity (e.g. per-sample prediction std)."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    arr = np.asarray(values, dtype=float)
    fig, ax = plt.subplots(figsize=(6, 4.5))
    ax.hist(arr, bins=bins, color="#4477AA", edgecolor="black")
    ax.set_xlabel(xlabel)
    ax.set_ylabel("Frequency")
    ax.set_title(title)
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"output_path": output_path, "n_points": int(arr.size),
            "mean": round(float(arr.mean()), 4),
            "median": round(float(np.median(arr)), 4),
            "std": round(float(arr.std()), 4)}


@mcp.tool()
def plot_temperature_yield_curve(temperatures: list[float],
                                   yields: list[list[float]],
                                   labels: list[str],
                                   output_path: str = "artifacts/T_vs_Y.png",
                                   error_bars: list[list[float]] | None = None
                                   ) -> dict:
    """Plot one or more yield-strength vs temperature curves.

    Args:
        temperatures: Shared x-axis temperatures (or a list-of-lists, one
            per curve, when curves have different sampling).
        yields: List of curves, each a list of yield strengths in MPa.
        labels: Curve labels.
        output_path: Output PNG path.
        error_bars: Optional per-curve symmetric error bars.

    Returns:
        dict with output path and number of curves.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(7, 5))
    # Allow temperatures to be flat or list-of-lists
    if temperatures and isinstance(temperatures[0], (list, tuple)):
        T_list = temperatures
    else:
        T_list = [temperatures] * len(yields)

    for i, (T, Y, lab) in enumerate(zip(T_list, yields, labels)):
        if error_bars is not None:
            ax.errorbar(T, Y, yerr=error_bars[i], marker="o", label=lab,
                         capsize=3, lw=1.5)
        else:
            ax.plot(T, Y, marker="o", label=lab, lw=1.8)
    ax.set_xlabel("Temperature (°C)")
    ax.set_ylabel("Yield strength (MPa)")
    ax.legend(frameon=False)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"output_path": output_path, "n_curves": len(yields)}


@mcp.tool()
def plot_shap_bar(shap_ranking: list[dict],
                   output_path: str = "artifacts/shap_bar.png",
                   top_n: int = 10) -> dict:
    """Horizontal bar plot of mean |SHAP| values from
    ``compute_tree_shap`` output."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    top = shap_ranking[:top_n][::-1]  # reverse so largest at top
    names = [r["feature_name"] for r in top]
    vals = [r["mean_abs_shap"] for r in top]

    fig, ax = plt.subplots(figsize=(7, 0.45 * len(top) + 1))
    ax.barh(names, vals, color="#CC6677", edgecolor="black")
    ax.set_xlabel("Mean |SHAP value|")
    ax.set_title("Feature importance (SHAP)")
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"output_path": output_path, "n_features_shown": len(top)}


# ----------------------------------------------------------------------------
# 8. Differential evolution composition optimiser
# ----------------------------------------------------------------------------
@mcp.tool()
def optimize_composition(model_id: str,
                          base_alloy: dict,
                          descriptor_config: list[dict] | dict,
                          target_temperature: float,
                          element_property_csv: str,
                          bounds: list[tuple] | None = None,
                          maxiter: int = 100,
                          popsize: int = 15,
                          seed: int = 0) -> dict:
    """Maximise the trained model's prediction over an alloy's element
    fractions using ``scipy.optimize.differential_evolution``.

    ``descriptor_config`` is an ordered list of descriptor specs. The trained
    model's feature order must match this list. Candidate-dependent specs are
    recomputed after each composition update; fixed specs are explicitly marked
    in the returned ``descriptor_sources``.

    ``base_alloy`` is {element: starting_fraction} (must sum to 1).
    Element fractions are bounded between 0.02 and 0.35 by default, and
    constrained to sum to 1 (Lampinen's penalty).

    Returns the best alloy and its predicted yield strength.
    """
    from scipy.optimize import differential_evolution

    with open(f"/tmp/rhea_model_{model_id}.pkl", "rb") as f:
        s = pickle.load(f)
    model = s["model"]

    elements = list(base_alloy.keys())
    n = len(elements)
    if bounds is None:
        bounds = [(0.02, 0.35)] * n
    prop_table = load_element_properties(element_property_csv)

    last_descriptor_values = {}
    last_descriptor_sources = {}

    def build_features(x):
        nonlocal last_descriptor_values, last_descriptor_sources
        mf = {el: float(xi) for el, xi in zip(elements, x)}
        # renormalise to sum to 1 (penalised below)
        s_ = sum(mf.values())
        mf = {k: v / s_ for k, v in mf.items()}
        feats, values, sources = _configured_descriptor_features(
            mf, prop_table, target_temperature, descriptor_config)
        last_descriptor_values = values
        last_descriptor_sources = sources
        return feats

    def objective(x):
        s_ = sum(x)
        penalty = (s_ - 1.0) ** 2 * 1e6
        feats = build_features(x)
        pred = float(model.predict(feats)[0])
        return -pred + penalty

    rng_seed = int(seed)
    res = differential_evolution(objective, bounds, maxiter=maxiter,
                                  popsize=popsize, seed=rng_seed,
                                  mutation=(0.5, 1.0), recombination=0.7,
                                  tol=1e-6, polish=True)
    best_x = list(res.x)
    s_ = sum(best_x)
    best_x = [float(v / s_) for v in best_x]
    best_alloy = {el: round(v, 4) for el, v in zip(elements, best_x)}
    best_features = build_features(best_x)
    best_pred = float(model.predict(best_features)[0])

    return {
        "model_id": model_id,
        "target_temperature": target_temperature,
        "optimized_alloy": best_alloy,
        "predicted_yield_strength_MPa": round(best_pred, 2),
        "descriptor_values": {k: (round(v, 6) if isinstance(v, float) else v)
                              for k, v in last_descriptor_values.items()},
        "descriptor_sources": last_descriptor_sources,
        "constraint_penalty_excluded_from_prediction": True,
        "n_evaluations": int(res.nfev),
        "converged": bool(res.success),
    }


if __name__ == "__main__":
    mcp.run(transport="stdio")

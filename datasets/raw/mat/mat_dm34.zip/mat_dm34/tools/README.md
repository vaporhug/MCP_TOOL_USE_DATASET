# mat_dm34 — Tool Reference

## Database Retrieval (`database_retrieval.py`)

- **websearch**: Generic web search (Google/Bing/DuckDuckGo via a scraping backend).
- **fetch_url**: HTTP GET with redirects. Used to download a CSV/PDF/JSON from a known URL.
- **query_pubchem**: PubChem PUG-REST lookup. namespace in {cid, name, smiles, inchikey}.
- **query_chembl**: ChEMBL bioactivity query (target_id, activity_type).
- **query_tdc**: Therapeutics Data Commons dataset retrieval (HIA_Hou, Pgp_Broccatelli, Lipophilicity_AstraZeneca, etc.).
- **query_unichem**: UniChem cross-reference lookup for SMILES/InChIKey.
- **query_uniprot**: UniProt entry fetch.
- **query_doi**: Resolve a DOI to a Crossref + OA full-text record.

## Data Processing (`data_processing.py`)

- **read_csv / write_csv**: CSV <-> list-of-dicts.
- **read_json / write_json**: JSON I/O.
- **read_excel**: .xlsx reader (pandas/openpyxl).
- **drop_missing**: filter rows with empty fields.
- **coerce_numeric**: cast columns to float.
- **join_tables**: SQL-style join.
- **groupby_aggregate**: groupby + mean|sum|min|max|count.
- **split_train_val**: random shuffle + split into train/val lists.

## Cheminformatics ML primitives (`cheminf_ml_tools.py`)

Loaders
- **load_smiles_csv**: load SMILES + label CSV; report shape & class balance.

Standardisation
- **standardise_smiles**: RDKit canonicalisation; mode in {basic, custom}.

Feature extraction
- **compute_morgan_fingerprints**: ECFP-style Morgan circular fingerprints (radius, n_bits).
- **compute_maccs_keys**: 167-bit MACCS structural keys.
- **compute_rdkit_descriptors**: ~200 classical 2D physicochemical descriptors.

Training
- **train_classifier**: fit a binary classifier (RF, LR, XGBoost, GBM, SVM, NB, kNN).
- **train_regressor**: fit a regressor (RF, Ridge, XGBoost, GBM, SVM, kNN).
- **predict**: apply a trained model to test features.

Evaluation
- **evaluate_classification**: AUROC / AUPRC / F1 / accuracy / MCC / balanced accuracy.
- **evaluate_regression**: MAE / RMSE / R2 / Spearman / Pearson.

Interpretation
- **feature_importance**: tree feature_importances_ or linear |coef_|, top-k.

Plotting
- **plot_benchmark_summary**: bar chart of per-dataset scores.
- **plot_confusion_or_scatter**: confusion matrix or pred-vs-true scatter.

## Suggested call chain

```
load_smiles_csv -> standardise_smiles
  -> compute_morgan_fingerprints / compute_maccs_keys / compute_rdkit_descriptors
  -> train_classifier (or train_regressor)
  -> predict
  -> evaluate_classification (or evaluate_regression)
  -> plot_benchmark_summary
```

## Dependencies

`numpy`, `pandas`, `scipy`, `scikit-learn`, `rdkit`, `xgboost`, `matplotlib`,
`mcp` (FastMCP). Optional: `PyTDC` for `query_tdc`.

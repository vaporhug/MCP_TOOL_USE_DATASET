# mat_dm34 — Tool Reference

## Database Retrieval (`database_retrieval.py`) -- UNUSED STUB MODULE

This module is shipped as a stub: every function raises
`NotImplementedError` with a message pointing back at the bundled
CSVs. **None of these functions are required for this task** -- the
bundle is fully self-contained (all five TDC ADMET datasets are
pre-staged under `input_data/data/`) and the agent should NOT attempt
to fetch external data. The module is retained only to keep the
cross-task tools layout consistent; agents may ignore it.

- websearch / fetch_url / query_pubchem / query_chembl / query_tdc /
  query_unichem / query_uniprot / query_doi: all raise
  `NotImplementedError`. To actually fetch external data outside this
  task's scope, call the relevant client library directly (PyTDC,
  pubchempy, chembl_webresource_client, etc.).

## Data Processing (`data_processing.py`)

Implemented (returns data):
- **read_csv / write_csv**: CSV <-> list-of-dicts.
- **read_json / write_json**: JSON I/O.
- **drop_missing**: filter rows with empty fields.
- **coerce_numeric**: cast columns to float.
- **join_tables**: SQL-style join.
- **groupby_aggregate**: groupby + mean|sum|min|max|count.
- **split_train_val**: random shuffle + split into train/val lists.

Unused stubs (not needed for this task; no .xlsx files are bundled):
- **read_excel**: raises `NotImplementedError`. The bundled datasets
  ship exclusively as CSV files; the agent should NOT invoke this
  function.

## Cheminformatics ML primitives (`cheminf_ml_tools.py`)

Loaders
- **load_smiles_csv**: load SMILES + label CSV; report shape & class balance.

Standardisation
- **standardise_smiles**: RDKit canonicalisation; mode in {basic, custom}.

Feature extraction
- **compute_morgan_fingerprints**: ECFP-style Morgan circular fingerprints (radius, n_bits).
- **compute_maccs_keys**: 167-bit MACCS structural keys.
- **compute_rdkit_descriptors**: ~200 classical 2D physicochemical descriptors.

Training
- **train_classifier**: fit a binary classifier (RF, LR, XGBoost, GBM, SVM, NB, kNN).
- **train_regressor**: fit a regressor (RF, Ridge, XGBoost, GBM, SVM, kNN).
- **predict**: apply a trained model to test features.

Evaluation
- **evaluate_classification**: AUROC / AUPRC / F1 / accuracy / MCC / balanced accuracy.
- **evaluate_regression**: MAE / RMSE / R2 / Spearman / Pearson.

Interpretation
- **feature_importance**: tree feature_importances_ or linear |coef_|, top-k.

Plotting
- **plot_benchmark_summary**: bar chart of per-dataset scores.
- **plot_confusion_or_scatter**: confusion matrix or pred-vs-true scatter.

## AutoML search (`automl_search.py`)

- **automl_search**: grid-search across fingerprint x model x small-hyperparam-grid with k-fold CV on the train_val split. Wraps the cheminf primitives above. Args: train_val_csv, smiles_col, label_col, task_type ('classification'|'regression'), fingerprints (subset of {morgan, maccs, rdkit_descriptors}), models (subset of {RandomForest, GradientBoosting, LogisticRegression} for cls or {LinearRegression, RandomForest, GradientBoosting} for reg), k_folds. Returns best (fp, model, params) + CV-mean score (AUROC for cls, MAE for reg) and the full leaderboard.

## Suggested call chain

```
load_smiles_csv -> standardise_smiles
  -> compute_morgan_fingerprints / compute_maccs_keys / compute_rdkit_descriptors
  -> train_classifier (or train_regressor)
  -> predict
  -> evaluate_classification (or evaluate_regression)
  -> plot_benchmark_summary
```

## Dependencies

`numpy`, `pandas`, `scipy`, `scikit-learn`, `rdkit`, `xgboost`, `matplotlib`,
`mcp` (FastMCP). Optional: `PyTDC` for `query_tdc`.

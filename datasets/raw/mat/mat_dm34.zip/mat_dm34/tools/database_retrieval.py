"""Database retrieval tools.

Thin placeholders for external-database queries. Each stub documents the
target database and the intended query semantics so an agent can recognise
when to call it and supply the missing implementation.
"""
from typing import Any


def websearch(query: str, max_results: int = 10) -> list[dict]:
    """Generic web search (Google/Bing/DuckDuckGo via a scraping backend).
    Returns a list of {title, url, snippet} dicts."""
    pass  # heavy: requires a search API key or headless browser


def fetch_url(url: str, timeout: int = 30) -> bytes:
    """HTTP GET with redirects. Used to download a CSV/PDF/JSON from a
    known URL (e.g., Zenodo record, GitHub raw file, journal OA page)."""
    pass  # heavy: network + retry/backoff


def query_pubchem(identifier: str, namespace: str = "cid") -> dict:
    """PubChem PUG-REST lookup. namespace in {cid, name, smiles, inchikey}.
    Returns compound record (properties, synonyms, 2D/3D structure)."""
    pass  # heavy: REST client + rate limiting


def query_chembl(target_id: str, activity_type: str = "IC50") -> list[dict]:
    """ChEMBL bioactivity query. Returns rows of {molecule_chembl_id,
    canonical_smiles, standard_value, standard_units, assay_description}
    for a given target (e.g., CHEMBL240)."""
    pass  # heavy: chembl_webresource_client paginated fetch


def query_tdc(name: str, task: str = "ADME") -> dict:
    """Therapeutics Data Commons (TDC) dataset retrieval. Used for
    benchmark groups like ADMET, e.g., name='HIA_Hou' / 'Pgp_Broccatelli' /
    'Lipophilicity_AstraZeneca'. Returns {train_val, test} splits as
    list-of-dicts with Drug_ID/Drug/Y."""
    pass  # heavy: PyTDC download


def query_unichem(structure: str, inchikey: bool = True) -> dict:
    """UniChem cross-reference lookup for a SMILES/InChIKey. Returns
    list of {source, identifier} entries across ChEMBL, PubChem, DrugBank,
    KEGG, etc."""
    pass  # heavy


def query_uniprot(accession: str) -> dict:
    """UniProt entry fetch. Returns sequence, organism, features,
    cross-references."""
    pass  # heavy


def query_doi(doi: str) -> dict:
    """Resolve a DOI to a Crossref metadata record + OA full-text URL."""
    pass  # heavy: Crossref + Unpaywall REST

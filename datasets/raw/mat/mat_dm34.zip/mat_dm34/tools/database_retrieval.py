"""Database retrieval tools — INTENTIONALLY UNIMPLEMENTED in mat_dm34.

NONE of these functions are used by the mat_dm34 task (all five datasets
ship as bundled CSVs under input_data/data/). The functions exist as
cross-task tool-surface placeholders; they raise NotImplementedError when
called so consumers see an immediate clear error rather than silently
returning None from a bare `pass`. To actually fetch external data, use
the underlying libraries directly (e.g., PyTDC, pubchempy, chembl_webresource_client).
"""
from typing import Any


def _stub(name: str):
    raise NotImplementedError(
        f"{name}() is a stub in the mat_dm34 bundle. The task uses only the "
        "bundled CSVs under input_data/data/ — no external database access "
        "is needed. Use the relevant client library directly if you have "
        "an external retrieval requirement outside the task scope."
    )


def websearch(query: str, max_results: int = 10) -> list[dict]:
    """Generic web search — NOT IMPLEMENTED in this bundle."""
    _stub("websearch")


def fetch_url(url: str, timeout: int = 30) -> bytes:
    """HTTP GET — NOT IMPLEMENTED in this bundle."""
    _stub("fetch_url")


def query_pubchem(identifier: str, namespace: str = "cid") -> dict:
    """PubChem PUG-REST lookup — NOT IMPLEMENTED in this bundle."""
    _stub("query_pubchem")


def query_chembl(target_id: str, activity_type: str = "IC50") -> list[dict]:
    """ChEMBL bioactivity query — NOT IMPLEMENTED in this bundle."""
    _stub("query_chembl")


def query_tdc(name: str, task: str = "ADME") -> dict:
    """Therapeutics Data Commons (TDC) dataset retrieval — NOT IMPLEMENTED
    in this bundle. The 5 mat_dm34 datasets are already shipped as bundled
    CSVs under input_data/data/."""
    _stub("query_tdc")


def query_unichem(structure: str, inchikey: bool = True) -> dict:
    """UniChem cross-reference lookup — NOT IMPLEMENTED in this bundle."""
    _stub("query_unichem")


def query_uniprot(accession: str) -> dict:
    """UniProt entry fetch — NOT IMPLEMENTED in this bundle."""
    _stub("query_uniprot")


def query_doi(doi: str) -> dict:
    """DOI resolution + Crossref metadata — NOT IMPLEMENTED in this bundle."""
    _stub("query_doi")

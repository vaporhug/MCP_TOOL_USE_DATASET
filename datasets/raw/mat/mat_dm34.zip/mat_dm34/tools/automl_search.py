#!/usr/bin/env python3
"""AutoML grid-search wrapper.

A lightweight DeepMol-style AutoML primitive that composes the existing
cheminformatics ML building blocks (standardise_smiles, compute_*_fingerprints,
train_classifier, train_regressor, predict) to grid-search over

  - fingerprint type   (morgan / maccs / rdkit_descriptors)
  - model type         (per task_type)
  - a small per-model hyper-parameter grid (2-3 values)

with k-fold cross-validation on the train_val split and returns the best
(fp, model, params) configuration plus the CV-mean score (AUROC for
classification, MAE for regression).
"""

import itertools
import warnings

import numpy as np
import pandas as pd
from mcp.server.fastmcp import FastMCP

try:
    from .cheminf_ml_tools import (
        standardise_smiles,
        compute_morgan_fingerprints,
        compute_maccs_keys,
        compute_rdkit_descriptors,
        _load_features,
        _build_classifier,
        _build_regressor,
    )
except ImportError:
    from cheminf_ml_tools import (
        standardise_smiles,
        compute_morgan_fingerprints,
        compute_maccs_keys,
        compute_rdkit_descriptors,
        _load_features,
        _build_classifier,
        _build_regressor,
    )

warnings.filterwarnings("ignore")
mcp = FastMCP("AutoML_Search")


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------
_FP_BUILDERS = {
    "morgan": lambda smis: compute_morgan_fingerprints(smis),
    "maccs": lambda smis: compute_maccs_keys(smis),
    "rdkit_descriptors": lambda smis: compute_rdkit_descriptors(smis),
}


# Small hyper-parameter grids (2-3 values per model)
_CLS_MODEL_GRIDS = {
    "RandomForest": {
        "_sk_name": "random_forest",
        "grid": [
            {"n_estimators": 100, "max_depth": None},
            {"n_estimators": 200, "max_depth": None},
            {"n_estimators": 300, "max_depth": 10},
        ],
        "scale": False,
    },
    "GradientBoosting": {
        "_sk_name": "gradient_boosting",
        "grid": [
            {"n_estimators": 100, "learning_rate": 0.1},
            {"n_estimators": 200, "learning_rate": 0.05},
            {"n_estimators": 300, "learning_rate": 0.05},
        ],
        "scale": False,
    },
    "LogisticRegression": {
        "_sk_name": "logistic_regression",
        "grid": [
            {"C": 0.1, "max_iter": 1000},
            {"C": 1.0, "max_iter": 1000},
            {"C": 10.0, "max_iter": 1000},
        ],
        "scale": True,
    },
}


_REG_MODEL_GRIDS = {
    "LinearRegression": {
        "_sk_name": "ridge",  # Ridge with small alpha approximates LinearRegression
        "grid": [
            {"alpha": 1e-6},  # ~ ordinary LR
            {"alpha": 0.1},
            {"alpha": 1.0},
        ],
        "scale": True,
    },
    "RandomForest": {
        "_sk_name": "random_forest",
        "grid": [
            {"n_estimators": 100, "max_depth": None},
            {"n_estimators": 200, "max_depth": None},
            {"n_estimators": 300, "max_depth": 10},
        ],
        "scale": False,
    },
    "GradientBoosting": {
        "_sk_name": "gradient_boosting",
        "grid": [
            {"n_estimators": 100, "learning_rate": 0.1},
            {"n_estimators": 200, "learning_rate": 0.05},
            {"n_estimators": 300, "learning_rate": 0.05},
        ],
        "scale": False,
    },
}


def _cv_score(X, y, task_type, sk_name, params, scale, k_folds):
    from sklearn.model_selection import StratifiedKFold, KFold
    from sklearn.preprocessing import StandardScaler
    from sklearn.metrics import roc_auc_score, mean_absolute_error

    if task_type == "classification":
        kf = StratifiedKFold(n_splits=k_folds, shuffle=True, random_state=0)
        splitter = kf.split(X, y.astype(int))
    else:
        kf = KFold(n_splits=k_folds, shuffle=True, random_state=0)
        splitter = kf.split(X)

    scores = []
    for train_idx, val_idx in splitter:
        Xtr, Xva = X[train_idx], X[val_idx]
        ytr, yva = y[train_idx], y[val_idx]
        scaler = None
        if scale:
            scaler = StandardScaler().fit(Xtr)
            Xtr = scaler.transform(Xtr)
            Xva = scaler.transform(Xva)
        if task_type == "classification":
            model = _build_classifier(sk_name, dict(params))
            model.fit(Xtr, ytr.astype(int))
            try:
                proba = model.predict_proba(Xva)[:, 1]
            except Exception:
                proba = model.decision_function(Xva)
            if len(np.unique(yva)) < 2:
                continue
            scores.append(float(roc_auc_score(yva.astype(int), proba)))
        else:
            model = _build_regressor(sk_name, dict(params))
            model.fit(Xtr, ytr)
            pred = model.predict(Xva)
            scores.append(float(mean_absolute_error(yva, pred)))
    if not scores:
        return float("nan"), 0
    return float(np.mean(scores)), len(scores)


# ---------------------------------------------------------------------------
# MCP tool
# ---------------------------------------------------------------------------
@mcp.tool()
def automl_search(train_val_csv: str,
                  smiles_col: str = "Drug",
                  label_col: str = "Y",
                  task_type: str = "classification",
                  fingerprints: list | None = None,
                  models: list | None = None,
                  k_folds: int = 3) -> dict:
    """Grid-search across fingerprint x model x small-hyperparam-grid with
    k-fold CV on the train_val split. Returns best config + CV score.

    Wraps standardise_smiles, compute_morgan_fingerprints /
    compute_maccs_keys / compute_rdkit_descriptors, and the
    train_classifier / train_regressor primitives via shared
    _build_classifier / _build_regressor helpers.

    Args:
        train_val_csv: path to a train_val CSV with at least SMILES + label columns
        smiles_col: SMILES column name (default 'Drug')
        label_col: label column name (default 'Y')
        task_type: 'classification' (CV metric = AUROC, higher is better) or
                   'regression' (CV metric = MAE, lower is better)
        fingerprints: subset of {'morgan', 'maccs', 'rdkit_descriptors'};
                      defaults to all three
        models: subset of model names for the task_type;
                cls defaults to ['RandomForest', 'GradientBoosting', 'LogisticRegression'],
                reg defaults to ['LinearRegression', 'RandomForest', 'GradientBoosting']
        k_folds: number of CV folds (default 3)

    Returns:
        dict with
          - best: {'fingerprint': ..., 'model': ..., 'params': {...},
                   'cv_score': float, 'metric': 'AUROC'|'MAE'}
          - leaderboard: list of all configs evaluated, sorted best-first
          - n_configs: total number of (fp, model, hp) configs evaluated
          - n_samples: number of valid molecules used for CV
          - task_type, k_folds
    """
    if task_type not in ("classification", "regression"):
        raise ValueError(f"task_type must be 'classification' or 'regression', got {task_type!r}")

    fingerprints = list(fingerprints) if fingerprints else ["morgan", "maccs", "rdkit_descriptors"]
    for fp in fingerprints:
        if fp not in _FP_BUILDERS:
            raise ValueError(f"Unknown fingerprint: {fp!r}. Valid: {list(_FP_BUILDERS)}")

    if task_type == "classification":
        grids = _CLS_MODEL_GRIDS
        default_models = ["RandomForest", "GradientBoosting", "LogisticRegression"]
        metric_name = "AUROC"
        higher_better = True
    else:
        grids = _REG_MODEL_GRIDS
        default_models = ["LinearRegression", "RandomForest", "GradientBoosting"]
        metric_name = "MAE"
        higher_better = False
    models = list(models) if models else default_models
    for m in models:
        if m not in grids:
            raise ValueError(
                f"Unknown model {m!r} for task_type={task_type!r}. Valid: {list(grids)}"
            )

    # Load + standardise once
    df = pd.read_csv(train_val_csv)
    smiles_raw = df[smiles_col].astype(str).tolist()
    y_raw = np.array(df[label_col].values, dtype=float)
    std = standardise_smiles(smiles_raw, mode="basic")
    smiles_std = std["standardised"]

    # Build each fingerprint once and cache (fid, valid_mask, X, y)
    fp_cache: dict = {}
    for fp_name in fingerprints:
        info = _FP_BUILDERS[fp_name]([s if s is not None else "" for s in smiles_std])
        fid = info["feature_id"]
        feat = _load_features(fid)
        X_all = feat["arr"].astype(float)
        mask = np.array(feat["mask"], dtype=bool)
        keep = mask & np.isfinite(y_raw)
        X = X_all[keep]
        y = y_raw[keep]
        fp_cache[fp_name] = {"X": X, "y": y, "feature_id": fid}

    leaderboard: list = []
    n_samples_used = 0
    for fp_name, model_name in itertools.product(fingerprints, models):
        spec = grids[model_name]
        sk_name = spec["_sk_name"]
        scale = bool(spec["scale"])
        X = fp_cache[fp_name]["X"]
        y = fp_cache[fp_name]["y"]
        n_samples_used = max(n_samples_used, int(X.shape[0]))
        for params in spec["grid"]:
            score, n_used_folds = _cv_score(X, y, task_type, sk_name, params, scale, k_folds)
            leaderboard.append({
                "fingerprint": fp_name,
                "model": model_name,
                "params": dict(params),
                "cv_score": round(float(score), 4) if np.isfinite(score) else None,
                "n_cv_folds": int(n_used_folds),
            })

    valid = [r for r in leaderboard if r["cv_score"] is not None]
    if not valid:
        raise RuntimeError("AutoML search produced no valid CV scores")
    valid.sort(key=lambda r: r["cv_score"], reverse=higher_better)
    best = valid[0]

    return {
        "best": {
            "fingerprint": best["fingerprint"],
            "model": best["model"],
            "params": best["params"],
            "cv_score": best["cv_score"],
            "metric": metric_name,
        },
        "leaderboard": valid,
        "n_configs": len(leaderboard),
        "n_samples": n_samples_used,
        "task_type": task_type,
        "k_folds": int(k_folds),
        "metric": metric_name,
        "higher_better": bool(higher_better),
        "fingerprints_searched": fingerprints,
        "models_searched": models,
    }


if __name__ == "__main__":
    mcp.run(transport="stdio")

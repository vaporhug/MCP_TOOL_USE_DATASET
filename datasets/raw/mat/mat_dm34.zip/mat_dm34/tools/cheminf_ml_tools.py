#!/usr/bin/env python3
"""Cheminformatics ML primitives.

Low-level building blocks for SMILES standardisation, molecular feature
extraction, train/eval of classical ML pipelines for ADMET property
prediction, and basic plotting. Designed so that a chained call sequence
(load_smiles_csv -> standardise_smiles -> compute_<features>
-> train_classifier/regressor -> evaluate_*) covers the full
QSAR/QSPR pipeline used in TDC ADMET benchmarks.
"""

import os
import json
import pickle
import hashlib
import warnings

import numpy as np
from mcp.server.fastmcp import FastMCP

warnings.filterwarnings("ignore")
mcp = FastMCP("Cheminformatics_ML_Tools")


# ---------------------------------------------------------------------------
# Loaders
# ---------------------------------------------------------------------------
@mcp.tool()
def load_smiles_csv(csv_path: str, smiles_col: str = "Drug",
                    label_col: str = "Y", id_col: str = "Drug_ID") -> dict:
    """Load a SMILES + label CSV file and report shape and class balance.

    Args:
        csv_path: path to a CSV with at least SMILES + label columns
        smiles_col: column name holding SMILES strings
        label_col: column name holding the regression value or 0/1 label
        id_col: optional identifier column

    Returns:
        dict with n_rows, label_type ('binary'|'continuous'), label stats,
        and a small head sample of (id, smiles, label) rows
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    n = len(df)
    y = df[label_col].values
    is_binary = bool(set(np.unique(y)).issubset({0, 1, 0.0, 1.0}))
    out = {
        "n_rows": int(n),
        "columns": list(df.columns),
        "smiles_col": smiles_col,
        "label_col": label_col,
        "label_type": "binary" if is_binary else "continuous",
    }
    if is_binary:
        out["positives"] = int((y == 1).sum())
        out["negatives"] = int((y == 0).sum())
        out["positive_fraction"] = round(float(out["positives"] / n), 4)
    else:
        out["label_mean"] = round(float(np.mean(y)), 4)
        out["label_std"] = round(float(np.std(y)), 4)
        out["label_min"] = round(float(np.min(y)), 4)
        out["label_max"] = round(float(np.max(y)), 4)
    head = df.head(3)
    out["head"] = [
        {id_col: str(r.get(id_col, "")), smiles_col: str(r[smiles_col]),
         label_col: float(r[label_col])}
        for _, r in head.iterrows()
    ]
    return out


# ---------------------------------------------------------------------------
# SMILES standardisation
# ---------------------------------------------------------------------------
@mcp.tool()
def standardise_smiles(smiles_list: list, mode: str = "basic") -> dict:
    """Canonicalise SMILES with RDKit, optionally remove salts and neutralise.

    Args:
        smiles_list: list of SMILES strings to standardise
        mode: 'basic' (RDKit Chem.MolToSmiles canonical form) or
              'custom' (additionally strip salts/solvents and neutralise charges)

    Returns:
        dict with standardised SMILES list (same length, None for invalid),
        n_invalid count, and the indices of invalid molecules
    """
    from rdkit import Chem
    from rdkit.Chem import SaltRemover

    remover = SaltRemover.SaltRemover() if mode == "custom" else None
    out: list = []
    invalid = []
    for i, s in enumerate(smiles_list):
        try:
            m = Chem.MolFromSmiles(s)
            if m is None:
                out.append(None); invalid.append(i); continue
            if remover is not None:
                m = remover.StripMol(m, dontRemoveEverything=True)
                # neutralise simple charges
                from rdkit.Chem import AllChem
                pattern = Chem.MolFromSmarts("[+1!H0,-1!H0]")
                if pattern is not None:
                    at_matches = m.GetSubstructMatches(pattern)
                    for (idx,) in at_matches:
                        atom = m.GetAtomWithIdx(idx)
                        chg = atom.GetFormalCharge()
                        h = atom.GetTotalNumHs()
                        atom.SetFormalCharge(0)
                        atom.SetNumExplicitHs(h - chg)
            out.append(Chem.MolToSmiles(m, canonical=True))
        except Exception:
            out.append(None); invalid.append(i)
    return {
        "standardised": out,
        "n_input": len(smiles_list),
        "n_invalid": len(invalid),
        "invalid_indices": invalid,
        "mode": mode,
    }


# ---------------------------------------------------------------------------
# Feature extraction
# ---------------------------------------------------------------------------
@mcp.tool()
def compute_morgan_fingerprints(smiles_list: list, radius: int = 2,
                                 n_bits: int = 2048) -> dict:
    """Compute Morgan / ECFP-style circular fingerprints with RDKit.

    Args:
        smiles_list: list of SMILES strings (canonicalised)
        radius: bond-radius for the Morgan algorithm (2 = ECFP4)
        n_bits: bit-vector length

    Returns:
        dict with 'features' as a binary list-of-lists (length n_bits each),
        'mask' marking valid molecules, and the feature parameters
    """
    from rdkit import Chem
    from rdkit.Chem import AllChem
    from rdkit.DataStructs import ConvertToNumpyArray

    feats: list = []
    mask: list = []
    for s in smiles_list:
        m = Chem.MolFromSmiles(s) if isinstance(s, str) else None
        if m is None:
            feats.append([0] * n_bits); mask.append(False); continue
        fp = AllChem.GetMorganFingerprintAsBitVect(m, radius, n_bits)
        arr = np.zeros(n_bits, dtype=int)
        ConvertToNumpyArray(fp, arr)
        feats.append(arr.tolist()); mask.append(True)
    fid = hashlib.md5(str(("morgan", radius, n_bits, len(feats))).encode()).hexdigest()[:8]
    _store_features(fid, np.array(feats, dtype=np.int8), mask, "morgan")
    return {
        "feature_id": fid,
        "feature_type": "morgan",
        "radius": radius,
        "n_bits": n_bits,
        "n_molecules": len(feats),
        "n_valid": int(sum(mask)),
        "shape": [len(feats), n_bits],
    }


@mcp.tool()
def compute_maccs_keys(smiles_list: list) -> dict:
    """Compute MACCS structural-key fingerprints (167 bits).

    Args:
        smiles_list: list of SMILES strings

    Returns:
        dict with feature_id (for downstream training) and metadata
    """
    from rdkit import Chem
    from rdkit.Chem import MACCSkeys
    from rdkit.DataStructs import ConvertToNumpyArray

    feats: list = []
    mask: list = []
    for s in smiles_list:
        m = Chem.MolFromSmiles(s) if isinstance(s, str) else None
        if m is None:
            feats.append([0] * 167); mask.append(False); continue
        fp = MACCSkeys.GenMACCSKeys(m)
        arr = np.zeros(167, dtype=int)
        ConvertToNumpyArray(fp, arr)
        feats.append(arr.tolist()); mask.append(True)
    fid = hashlib.md5(str(("maccs", len(feats))).encode()).hexdigest()[:8]
    _store_features(fid, np.array(feats, dtype=np.int8), mask, "maccs")
    return {
        "feature_id": fid,
        "feature_type": "maccs",
        "n_bits": 167,
        "n_molecules": len(feats),
        "n_valid": int(sum(mask)),
    }


@mcp.tool()
def compute_rdkit_descriptors(smiles_list: list) -> dict:
    """Compute classical 2D physicochemical descriptors with RDKit.

    Returns ~200 descriptors per molecule (MW, LogP, TPSA, NumHDonors,
    NumRotatableBonds, ring counts, etc.).

    Args:
        smiles_list: list of SMILES strings

    Returns:
        dict with feature_id, descriptor_names, n_descriptors
    """
    from rdkit import Chem
    from rdkit.Chem import Descriptors

    desc_names = [n for n, _ in Descriptors._descList]
    feats: list = []
    mask: list = []
    for s in smiles_list:
        m = Chem.MolFromSmiles(s) if isinstance(s, str) else None
        if m is None:
            feats.append([float("nan")] * len(desc_names)); mask.append(False); continue
        row = []
        for _, fn in Descriptors._descList:
            try:
                row.append(float(fn(m)))
            except Exception:
                row.append(float("nan"))
        feats.append(row); mask.append(True)
    arr = np.array(feats, dtype=float)
    arr[~np.isfinite(arr)] = 0.0
    fid = hashlib.md5(str(("descriptors", len(feats))).encode()).hexdigest()[:8]
    _store_features(fid, arr, mask, "descriptors", desc_names)
    return {
        "feature_id": fid,
        "feature_type": "descriptors",
        "n_descriptors": len(desc_names),
        "descriptor_names": desc_names,
        "n_molecules": len(feats),
        "n_valid": int(sum(mask)),
    }


def _store_features(fid: str, arr: np.ndarray, mask: list,
                    kind: str, names: list | None = None) -> None:
    os.makedirs("/tmp/cheminf_cache", exist_ok=True)
    with open(f"/tmp/cheminf_cache/feat_{fid}.pkl", "wb") as f:
        pickle.dump({"arr": arr, "mask": mask, "kind": kind, "names": names}, f)


def _load_features(fid: str) -> dict:
    with open(f"/tmp/cheminf_cache/feat_{fid}.pkl", "rb") as f:
        return pickle.load(f)


# ---------------------------------------------------------------------------
# Train + evaluate models
# ---------------------------------------------------------------------------
@mcp.tool()
def train_classifier(feature_id_train: str, labels_train: list,
                     model_type: str = "random_forest",
                     model_params: dict | None = None,
                     scale_features: bool = False) -> dict:
    """Fit a binary classifier on cached molecular features.

    Args:
        feature_id_train: feature_id returned by compute_*_fingerprints
        labels_train: 0/1 labels aligned with the SMILES list used to build features
        model_type: 'random_forest', 'logistic_regression', 'xgboost',
                    'gradient_boosting', 'svm', 'naive_bayes', 'knn'
        model_params: optional model-specific kwargs
        scale_features: standardise features (recommended for LR/SVM)

    Returns:
        dict with model_id (for predict / SHAP) and basic train info
    """
    from sklearn.preprocessing import StandardScaler

    feat = _load_features(feature_id_train)
    X = feat["arr"].astype(float)
    mask = np.array(feat["mask"])
    y = np.array(labels_train, dtype=float)
    keep = mask & np.isfinite(y)
    X = X[keep]; y = y[keep]

    scaler = None
    if scale_features:
        scaler = StandardScaler().fit(X)
        X = scaler.transform(X)

    params = dict(model_params or {})
    model = _build_classifier(model_type, params)
    model.fit(X, y.astype(int))

    mid = hashlib.md5(str((model_type, len(y), feat["kind"])).encode() + os.urandom(2)).hexdigest()[:8]
    os.makedirs("/tmp/cheminf_cache", exist_ok=True)
    with open(f"/tmp/cheminf_cache/model_{mid}.pkl", "wb") as f:
        pickle.dump({"model": model, "scaler": scaler, "task": "classification",
                     "model_type": model_type, "feature_kind": feat["kind"]}, f)
    return {
        "model_id": mid,
        "model_type": model_type,
        "task": "classification",
        "n_train": int(len(y)),
        "n_features": int(X.shape[1]),
        "feature_kind": feat["kind"],
    }


@mcp.tool()
def train_regressor(feature_id_train: str, labels_train: list,
                    model_type: str = "random_forest",
                    model_params: dict | None = None,
                    scale_features: bool = False) -> dict:
    """Fit a regressor on cached molecular features.

    Args:
        feature_id_train: feature_id returned by compute_*_fingerprints
        labels_train: continuous targets aligned with the SMILES list
        model_type: 'random_forest', 'ridge', 'xgboost',
                    'gradient_boosting', 'svm', 'knn'
        model_params: optional model-specific kwargs
        scale_features: standardise features

    Returns:
        dict with model_id and basic train info
    """
    from sklearn.preprocessing import StandardScaler

    feat = _load_features(feature_id_train)
    X = feat["arr"].astype(float)
    mask = np.array(feat["mask"])
    y = np.array(labels_train, dtype=float)
    keep = mask & np.isfinite(y)
    X = X[keep]; y = y[keep]

    scaler = None
    if scale_features:
        scaler = StandardScaler().fit(X)
        X = scaler.transform(X)

    params = dict(model_params or {})
    model = _build_regressor(model_type, params)
    model.fit(X, y)

    mid = hashlib.md5(str((model_type, len(y), feat["kind"])).encode() + os.urandom(2)).hexdigest()[:8]
    os.makedirs("/tmp/cheminf_cache", exist_ok=True)
    with open(f"/tmp/cheminf_cache/model_{mid}.pkl", "wb") as f:
        pickle.dump({"model": model, "scaler": scaler, "task": "regression",
                     "model_type": model_type, "feature_kind": feat["kind"]}, f)
    return {
        "model_id": mid,
        "model_type": model_type,
        "task": "regression",
        "n_train": int(len(y)),
        "n_features": int(X.shape[1]),
        "feature_kind": feat["kind"],
    }


def _build_classifier(model_type: str, params: dict):
    if model_type == "random_forest":
        from sklearn.ensemble import RandomForestClassifier
        return RandomForestClassifier(**({"n_estimators": 200, "n_jobs": -1, "random_state": 0, **params}))
    if model_type == "logistic_regression":
        from sklearn.linear_model import LogisticRegression
        return LogisticRegression(**({"max_iter": 1000, "C": 1.0, **params}))
    if model_type == "gradient_boosting":
        from sklearn.ensemble import GradientBoostingClassifier
        return GradientBoostingClassifier(**({"n_estimators": 200, "random_state": 0, **params}))
    if model_type == "xgboost":
        import xgboost
        return xgboost.XGBClassifier(**({"n_estimators": 300, "learning_rate": 0.05,
                                          "max_depth": 6, "verbosity": 0,
                                          "use_label_encoder": False,
                                          "eval_metric": "logloss", **params}))
    if model_type == "svm":
        from sklearn.svm import SVC
        return SVC(**({"kernel": "rbf", "C": 1.0, "probability": True, **params}))
    if model_type == "naive_bayes":
        from sklearn.naive_bayes import BernoulliNB
        return BernoulliNB(**params)
    if model_type == "knn":
        from sklearn.neighbors import KNeighborsClassifier
        return KNeighborsClassifier(**({"n_neighbors": 5, **params}))
    raise ValueError(f"Unknown model_type: {model_type}")


def _build_regressor(model_type: str, params: dict):
    if model_type == "random_forest":
        from sklearn.ensemble import RandomForestRegressor
        return RandomForestRegressor(**({"n_estimators": 200, "n_jobs": -1, "random_state": 0, **params}))
    if model_type == "ridge":
        from sklearn.linear_model import Ridge
        return Ridge(**({"alpha": 1.0, **params}))
    if model_type == "gradient_boosting":
        from sklearn.ensemble import GradientBoostingRegressor
        return GradientBoostingRegressor(**({"n_estimators": 200, "random_state": 0, **params}))
    if model_type == "xgboost":
        import xgboost
        return xgboost.XGBRegressor(**({"n_estimators": 300, "learning_rate": 0.05,
                                         "max_depth": 6, "verbosity": 0, **params}))
    if model_type == "svm":
        from sklearn.svm import SVR
        return SVR(**({"kernel": "rbf", "C": 1.0, **params}))
    if model_type == "knn":
        from sklearn.neighbors import KNeighborsRegressor
        return KNeighborsRegressor(**({"n_neighbors": 5, **params}))
    raise ValueError(f"Unknown model_type: {model_type}")


@mcp.tool()
def predict(model_id: str, feature_id_test: str) -> dict:
    """Predict labels (and probabilities for classification) on test features.

    Args:
        model_id: id returned by train_classifier / train_regressor
        feature_id_test: id from compute_*_fingerprints over the test SMILES

    Returns:
        dict with predictions list (and 'probabilities' list for classifiers)
    """
    with open(f"/tmp/cheminf_cache/model_{model_id}.pkl", "rb") as f:
        bundle = pickle.load(f)
    feat = _load_features(feature_id_test)
    X = feat["arr"].astype(float)
    mask = np.array(feat["mask"])
    if bundle["scaler"] is not None:
        X = bundle["scaler"].transform(X)
    model = bundle["model"]
    out: dict = {"model_id": model_id, "n_test": int(len(mask)),
                 "valid_mask": [bool(b) for b in mask]}
    if bundle["task"] == "classification":
        out["predictions"] = [int(v) for v in model.predict(X)]
        try:
            proba = model.predict_proba(X)
            out["probabilities"] = [round(float(p[1]), 6) for p in proba]
        except Exception:
            pass
    else:
        out["predictions"] = [round(float(v), 6) for v in model.predict(X)]
    return out


@mcp.tool()
def evaluate_classification(y_true: list, y_pred: list,
                            y_proba: list | None = None) -> dict:
    """Compute binary-classification metrics: AUROC, AUPRC, F1, accuracy,
    MCC, balanced accuracy.

    Args:
        y_true: ground-truth 0/1 labels
        y_pred: predicted class labels
        y_proba: optional positive-class probabilities for AUROC/AUPRC

    Returns:
        dict of metric -> value
    """
    from sklearn.metrics import (roc_auc_score, average_precision_score,
                                  f1_score, accuracy_score,
                                  matthews_corrcoef, balanced_accuracy_score,
                                  precision_score, recall_score)
    yt = np.array(y_true, dtype=int)
    yp = np.array(y_pred, dtype=int)
    out = {
        "n_samples": int(len(yt)),
        "accuracy": round(float(accuracy_score(yt, yp)), 4),
        "f1": round(float(f1_score(yt, yp, zero_division=0)), 4),
        "precision": round(float(precision_score(yt, yp, zero_division=0)), 4),
        "recall": round(float(recall_score(yt, yp, zero_division=0)), 4),
        "balanced_accuracy": round(float(balanced_accuracy_score(yt, yp)), 4),
        "mcc": round(float(matthews_corrcoef(yt, yp)) if len(np.unique(yt)) > 1 else 0.0, 4),
        "positives": int((yt == 1).sum()),
        "negatives": int((yt == 0).sum()),
    }
    if y_proba is not None and len(np.unique(yt)) > 1:
        proba = np.array(y_proba, dtype=float)
        out["auroc"] = round(float(roc_auc_score(yt, proba)), 4)
        out["auprc"] = round(float(average_precision_score(yt, proba)), 4)
    return out


@mcp.tool()
def evaluate_regression(y_true: list, y_pred: list) -> dict:
    """Compute regression metrics: MAE, RMSE, R2, Spearman, Pearson.

    Args:
        y_true: ground-truth continuous values
        y_pred: predicted values

    Returns:
        dict of metric -> value
    """
    from sklearn.metrics import (mean_absolute_error, mean_squared_error,
                                  r2_score)
    from scipy.stats import spearmanr, pearsonr
    yt = np.array(y_true, dtype=float)
    yp = np.array(y_pred, dtype=float)
    return {
        "n_samples": int(len(yt)),
        "mae": round(float(mean_absolute_error(yt, yp)), 4),
        "rmse": round(float(np.sqrt(mean_squared_error(yt, yp))), 4),
        "r2": round(float(r2_score(yt, yp)), 4),
        "spearman": round(float(spearmanr(yt, yp).correlation), 4),
        "pearson": round(float(pearsonr(yt, yp)[0]), 4),
    }


# ---------------------------------------------------------------------------
# SHAP / feature importance
# ---------------------------------------------------------------------------
@mcp.tool()
def feature_importance(model_id: str, top_k: int = 20) -> dict:
    """Built-in feature importance for tree-based models, or coefficients
    for linear models. Returns top_k features by absolute importance.

    Args:
        model_id: id returned by train_classifier / train_regressor
        top_k: number of features to report

    Returns:
        dict with ranked list of {feature_index, importance}
    """
    with open(f"/tmp/cheminf_cache/model_{model_id}.pkl", "rb") as f:
        bundle = pickle.load(f)
    model = bundle["model"]
    if hasattr(model, "feature_importances_"):
        imp = np.asarray(model.feature_importances_, dtype=float)
    elif hasattr(model, "coef_"):
        c = np.asarray(model.coef_, dtype=float).ravel()
        imp = np.abs(c)
    else:
        return {"error": "Model has no feature importance / coef_ attribute",
                "model_id": model_id}
    order = np.argsort(imp)[::-1][:top_k]
    return {
        "model_id": model_id,
        "top_features": [{"feature_index": int(i),
                           "importance": round(float(imp[i]), 6)} for i in order],
        "n_features": int(len(imp)),
    }


# ---------------------------------------------------------------------------
# Plotting
# ---------------------------------------------------------------------------
@mcp.tool()
def plot_benchmark_summary(metrics: dict, output_path: str,
                           metric_name: str = "AUROC",
                           higher_better: bool = True) -> dict:
    """Bar plot of per-dataset benchmark scores.

    Args:
        metrics: {dataset_name: score} dict
        output_path: output PNG path
        metric_name: y-axis label
        higher_better: arrow direction in title

    Returns:
        dict with output_path
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    names = list(metrics.keys())
    vals = [float(v) for v in metrics.values()]
    fig, ax = plt.subplots(figsize=(max(6, len(names) * 1.2), 4.5))
    bars = ax.bar(names, vals, edgecolor="k")
    ax.set_ylabel(f"{metric_name} ({'higher = better' if higher_better else 'lower = better'})")
    for x, v in zip(range(len(vals)), vals):
        ax.text(x, v, f"{v:.3f}", ha="center", va="bottom", fontsize=9)
    plt.xticks(rotation=20)
    plt.tight_layout()
    plt.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"output_path": output_path, "n_bars": len(vals)}


@mcp.tool()
def plot_confusion_or_scatter(y_true: list, y_pred: list,
                               output_path: str,
                               task: str = "auto") -> dict:
    """Confusion matrix (classification) or pred-vs-true scatter (regression).

    Args:
        y_true: ground-truth values
        y_pred: predictions
        output_path: output PNG path
        task: 'classification' | 'regression' | 'auto'

    Returns:
        dict with output_path
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    yt = np.asarray(y_true); yp = np.asarray(y_pred)
    if task == "auto":
        task = "classification" if set(np.unique(yt)).issubset({0, 1, 0.0, 1.0}) else "regression"
    if task == "classification":
        from sklearn.metrics import confusion_matrix
        cm = confusion_matrix(yt.astype(int), yp.astype(int))
        fig, ax = plt.subplots(figsize=(4.5, 4))
        im = ax.imshow(cm, cmap="Blues")
        for (i, j), v in np.ndenumerate(cm):
            ax.text(j, i, str(v), ha="center", va="center")
        ax.set_xticks([0, 1]); ax.set_xticklabels(["Pred 0", "Pred 1"])
        ax.set_yticks([0, 1]); ax.set_yticklabels(["True 0", "True 1"])
        ax.set_title("Confusion matrix")
        plt.colorbar(im, ax=ax)
    else:
        fig, ax = plt.subplots(figsize=(5.5, 5))
        ax.scatter(yt, yp, alpha=0.4, s=12)
        lims = [min(yt.min(), yp.min()), max(yt.max(), yp.max())]
        ax.plot(lims, lims, "k--", lw=1)
        ax.set_xlabel("True"); ax.set_ylabel("Predicted")
        ax.set_title("Prediction vs true")
    plt.tight_layout()
    plt.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"output_path": output_path, "task": task}


if __name__ == "__main__":
    mcp.run(transport="stdio")

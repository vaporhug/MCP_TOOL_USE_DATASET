# mat_hh16 Tool Reference

## Database Retrieval (`database_retrieval.py`)
Generic external lookups — websearch, fetch_url, query_pubchem, query_uniprot,
query_pdb, query_geo, query_doi, query_world_bank, etc. (See module docstrings.)

## Data Processing (`data_processing.py`)
General CSV / Excel / Parquet readers, table joins, group-by aggregation,
long-wide reshaping. Use these for the raw HEA composition CSVs and the
test-set table.

## Domain Tools (`hea_hardness_tools.py`)

### Composition primitives
- **parse_alloy_formula(formula)** — split `Al1.8CoCrCuFe` or `Al 30.5 Co 16` into
  atomic fractions (sum 1).
- **lookup_element_properties(element)** — return 13 tabulated quantities
  (mass, metallic radius, covalent radius, density, Tm, E, G, K, beta,
  Allen EN, VEC, molar volume, cohesive energy).

### Physics descriptors
- **composition_weighted_average(fractions, prop_name)** — Sum_i c_i * P_i.
- **composition_asymmetry(fractions, prop_name)** — sqrt(Sum_i c_i (1 - P_i/<P>)^2).
- **configurational_entropy(fractions)** — -R Sum c_i ln c_i.
- **miedema_chemical_enthalpy(fractions)** — 4 H_ij c_i c_j with tabulated pair
  enthalpies (kJ/mol).
- **elastic_mixing_enthalpy(fractions)** — bulk/shear/volume mismatch sum.
- **compute_full_feature_vector(formula)** — raw composition descriptors for one formula.
- **feature_schema_from_training_table(features_csv)** — returns the 22-column `db_HEAs.csv` schema plus raw-descriptor min/max scaling reconstructed from the 218 training formulas.
- **normalise_feature_record(raw_features, schema)** — maps raw descriptors, including composition-weighted elemental hardness `H_avg`, onto the training-table names and scale.
- **composition_path_feature_table(...)** — constructs normalized 22-feature rows for continuous paths before prediction.

### Statistics & ML
- **pearson_correlation(x, y)** — r, r^2, linear-fit slope/intercept.
- **train_ann_ensemble(features_csv, target_col, feature_cols, n_models, ...)**
  — train an ensemble of MLPRegressor networks; returns ensemble_id and
  per-model validation metrics.
- **predict_ann_ensemble(ensemble_id, features_csv, ...)** — averaged
  prediction; with target_col, also returns R^2, RMSE, MAE, mean %err,
  fraction-within-80%-accuracy.
- **cross_validate_ensemble(features_csv, ...)** — k-fold CV of the ensemble
  approach (default 5 folds).
- **stimulus_response_curve(ensemble_id, base_fractions, stim_element,
  balance_elements, training_features_csv, ...)** — sweep one element fraction after mapping every path point into the exact normalized `db_HEAs.csv` feature schema.
- **feature_contribution_path(ensemble_id, base_fractions, stim_element,
  balance_elements, training_features_csv, ...)** — decompose predicted HV using the same normalized feature schema.

### Plotting (one figure per answer image)
- **plot_parity(predictions, true_values, output_path, accuracy_pct=20)** —
  parity plot with 80%-accuracy band and MAE/RMSE/%err annotation.
- **plot_feature_correlation_bars(features_csv, target_col, feature_cols,
  output_path)** — bar chart of Pearson r between each descriptor and HV.
- **plot_feature_contributions(contributions, x_grid, overall_hardness,
  output_path)** — cumulative feature-contribution traces + total HV.

## Dependencies
- python >= 3.10
- numpy, pandas, scipy, scikit-learn, matplotlib
- mcp (FastMCP) for `@mcp.tool()` decorators

Install:
```
pip install numpy pandas scipy scikit-learn matplotlib fastmcp
```

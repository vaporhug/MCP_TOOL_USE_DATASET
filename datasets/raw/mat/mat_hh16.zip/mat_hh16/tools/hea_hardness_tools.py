#!/usr/bin/env python3
"""Domain primitives for high-entropy alloy hardness modelling.

Low-level building blocks: alloy formula parsing, elemental property
lookup, physics descriptor calculation, ensemble neural network
training, model interrogation by stimulus-response, and plotting.
"""

import math
import os
import pickle
import hashlib
import re
from typing import Dict, List, Tuple

import numpy as np
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("HEA_Hardness")

# =============================================================
# Element properties: 22-element subset spanning the training set
# Sources: tabulated metallic/covalent radii, melting points,
# elastic moduli, electronegativity, cohesive energies. Values
# are commonly available in materials handbooks.
# =============================================================
ELEMENT_PROPS = {
    # symbol: (atomic_mass, metallic_radius_A, covalent_radius_A,
    #         density_g_cc, Tm_K, E_GPa, G_GPa, K_GPa, compress_1per_GPa,
    #         EN_Allen, VEC, molar_volume_cc, cohesive_eV)
    'Al': (26.98, 1.43, 1.21, 2.70, 933.47, 70, 26, 76, 0.01316, 1.613, 3, 9.99, 3.39),
    'Co': (58.93, 1.25, 1.26, 8.86, 1768.0, 209, 75, 180, 0.00556, 1.840, 9, 6.62, 4.39),
    'Cr': (52.00, 1.28, 1.39, 7.15, 2180.0, 279, 115, 160, 0.00625, 1.650, 6, 7.23, 4.10),
    'Cu': (63.55, 1.28, 1.32, 8.96, 1357.77, 130, 48, 140, 0.00714, 1.850, 11, 7.09, 3.49),
    'Fe': (55.85, 1.26, 1.32, 7.87, 1811.0, 211, 82, 170, 0.00588, 1.800, 8, 7.09, 4.28),
    'Hf': (178.49, 1.59, 1.75, 13.31, 2506.0, 78, 30, 110, 0.00909, 1.300, 4, 13.41, 6.44),
    'Li': (6.94, 1.52, 1.28, 0.53, 453.65, 5, 4, 11, 0.09091, 0.912, 1, 13.02, 1.63),
    'Mg': (24.31, 1.60, 1.41, 1.74, 923.0, 45, 17, 45, 0.02222, 1.293, 2, 13.97, 1.51),
    'Mn': (54.94, 1.27, 1.39, 7.43, 1519.0, 198, 80, 120, 0.00833, 1.750, 7, 7.39, 2.92),
    'Mo': (95.96, 1.39, 1.54, 10.28, 2896.0, 329, 126, 230, 0.00435, 1.470, 6, 9.33, 6.82),
    'Nb': (92.91, 1.46, 1.64, 8.57, 2750.0, 105, 38, 170, 0.00588, 1.410, 5, 10.84, 7.57),
    'Ni': (58.69, 1.24, 1.24, 8.91, 1728.0, 200, 76, 180, 0.00556, 1.880, 10, 6.59, 4.44),
    'Si': (28.09, 1.17, 1.11, 2.33, 1687.0, 113, 40, 100, 0.01000, 1.916, 4, 12.06, 4.63),
    'Ta': (180.95, 1.46, 1.70, 16.69, 3290.0, 186, 69, 200, 0.00500, 1.340, 5, 10.85, 8.10),
    'Ti': (47.87, 1.47, 1.60, 4.51, 1941.0, 116, 44, 110, 0.00909, 1.380, 4, 10.62, 4.85),
    'V':  (50.94, 1.34, 1.53, 6.11, 2183.0, 128, 47, 160, 0.00625, 1.530, 5, 8.34, 5.31),
    'W':  (183.84, 1.39, 1.62, 19.25, 3695.0, 411, 161, 310, 0.00323, 1.470, 6, 9.55, 8.90),
    'Zn': (65.38, 1.34, 1.22, 7.13, 692.68, 108, 43, 70, 0.01429, 1.588, 12, 9.16, 1.35),
    'Zr': (91.22, 1.60, 1.75, 6.51, 2128.0, 88, 33, 90, 0.01111, 1.320, 4, 14.02, 6.25),
    'B':  (10.81, 0.83, 0.84, 2.46, 2349.0, 320, 154, 178, 0.00562, 2.510, 3, 4.39, 5.73),
    'C':  (12.01, 0.77, 0.77, 2.27, 3823.0, 1050, 478, 442, 0.00226, 2.544, 4, 5.29, 7.37),
    'Ge': (72.63, 1.39, 1.20, 5.32, 1211.40, 103, 41, 75, 0.01333, 1.994, 4, 13.65, 3.85),
    'Sc': (44.96, 1.62, 1.70, 2.99, 1814.0, 74, 29, 57, 0.01754, 1.190, 3, 15.04, 3.90),
    'Sn': (118.71, 1.45, 1.39, 7.31, 505.08, 50, 18, 58, 0.01724, 1.824, 4, 16.24, 3.14),
}
PROP_NAMES = ['mass', 'r_met', 'r_cov', 'density', 'Tm', 'E', 'G', 'K',
              'beta', 'EN', 'VEC', 'Vm', 'E_coh']

# Approximate elemental Vickers hardness values used for the H_avg descriptor.
# H_avg is a composition-weighted elemental hardness descriptor; it is not an
# atomic-radius proxy.
ELEMENT_HARDNESS_HV = {
    'Al': 167, 'B': 4900, 'C': 10000, 'Co': 1043, 'Cr': 1060, 'Cu': 369,
    'Fe': 608, 'Ge': 750, 'Hf': 1760, 'Li': 5, 'Mg': 260, 'Mn': 1960,
    'Mo': 1530, 'Nb': 1320, 'Ni': 638, 'Sc': 750, 'Si': 1200, 'Sn': 51,
    'Ta': 873, 'Ti': 970, 'V': 628, 'W': 3430, 'Zn': 412, 'Zr': 903,
}

# Columns in db_HEAs.csv used by the paper-trained regressor.
HEA_FEATURE_COLS = [
    'R_delta', 'S_config', 'VEC', 'R_cov_delta', 'density_avg', 'Tm_avg',
    'E_avg', 'E_delta', 'G_avg', 'G_delta', 'K_avg', 'K_delta',
    'Compress_avg', 'Compress_delta', 'EN_Allen_avg', 'H_avg', 'Vm_delta',
    'E_coh_avg', 'E_coh_delta', 'Senkov_param', 'H_chem', 'H_el'
]
RAW_TO_HEA_FEATURE = {
    'r_met_delta': 'R_delta', 'S_config': 'S_config',
    'VEC_avg': 'VEC', 'r_cov_delta': 'R_cov_delta', 'density_avg': 'density_avg',
    'Tm_avg': 'Tm_avg', 'E_avg': 'E_avg', 'E_delta': 'E_delta',
    'G_avg': 'G_avg', 'G_delta': 'G_delta', 'K_avg': 'K_avg',
    'K_delta': 'K_delta', 'beta_avg': 'Compress_avg',
    'beta_delta': 'Compress_delta', 'EN_avg': 'EN_Allen_avg',
    'H_avg': 'H_avg', 'Vm_delta': 'Vm_delta', 'E_coh_avg': 'E_coh_avg',
    'E_coh_delta': 'E_coh_delta', 'H_chem': 'H_chem',
    'H_el': 'H_el',
}


def feature_schema_from_training_table(features_csv: str, target_col: str = 'VHN') -> dict:
    """Return model feature columns and raw-descriptor min-max scalers.

    The 22 descriptor columns in db_HEAs.csv are already normalized for the
    paper model. For new composition paths, reconstruct raw descriptors from
    the training formulas and use those raw ranges before mapping to 0-1.
    """
    import pandas as pd
    df = pd.read_csv(features_csv)
    feature_cols = [c for c in HEA_FEATURE_COLS if c in df.columns]
    if len(feature_cols) != len(HEA_FEATURE_COLS):
        missing = [c for c in HEA_FEATURE_COLS if c not in df.columns]
        raise ValueError(f'missing HEA feature columns: {missing}')
    raw_rows = []
    failed = []
    if 'alloy_name' not in df.columns:
        raise ValueError('db_HEAs.csv must include alloy_name to reconstruct raw descriptor scaling')
    for formula in df['alloy_name'].astype(str):
        try:
            raw = compute_full_feature_vector(formula)
            if 'error' in raw:
                failed.append({'formula': formula, 'error': raw['error']})
                continue
            raw_rows.append(_mapped_raw_feature_record(raw['features'], feature_cols))
        except (KeyError, ValueError) as exc:
            failed.append({'formula': formula, 'error': str(exc)})
    if not raw_rows:
        raise ValueError(f'could not reconstruct raw scaling from training formulas: {failed[:5]}')
    raw_df = pd.DataFrame(raw_rows)
    raw_mins = raw_df[feature_cols].min().to_dict()
    raw_maxs = raw_df[feature_cols].max().to_dict()
    return {'feature_cols': feature_cols,
            'raw_feature_min': raw_mins,
            'raw_feature_max': raw_maxs,
            'target_col': target_col,
            'n_training_formulas_scaled': len(raw_rows),
            'n_training_formulas_failed': len(failed),
            'failed_examples': failed[:5]}


def _mapped_raw_feature_record(raw_features: dict, feature_cols: list) -> dict:
    """Map compute_full_feature_vector keys to the paper's 22 feature names."""
    mapped = {}
    for raw_key, dst in RAW_TO_HEA_FEATURE.items():
        if raw_key in raw_features and dst in feature_cols:
            mapped[dst] = float(raw_features[raw_key])
    if 'Senkov_param' in feature_cols and 'Senkov_param' not in mapped:
        hchem = abs(float(raw_features.get('H_chem', 0.0)))
        mapped['Senkov_param'] = 0.0 if hchem == 0 else (
            float(raw_features.get('Tm_avg', 0.0)) *
            float(raw_features.get('S_config', 0.0)) / hchem
        )
    missing = [c for c in feature_cols if c not in mapped]
    if missing:
        raise ValueError(f'could not construct mapped raw features for: {missing}')
    return {c: mapped[c] for c in feature_cols}


def normalise_feature_record(raw_features: dict, schema: dict, clip: bool = True) -> dict:
    """Map raw composition descriptors onto the normalized db_HEAs.csv schema."""
    raw_mapped = _mapped_raw_feature_record(raw_features, schema['feature_cols'])
    out = {}
    for col in schema['feature_cols']:
        lo = float(schema['raw_feature_min'][col])
        hi = float(schema['raw_feature_max'][col])
        denom = hi - lo if hi != lo else 1.0
        val = (float(raw_mapped[col]) - lo) / denom
        out[col] = float(np.clip(val, 0.0, 1.0)) if clip else float(val)
    return out


def composition_path_feature_table(base_fractions: dict, stim_element: str, balance_elements: list, x_grid: list, training_features_csv: str) -> dict:
    """Build a normalized 22-column feature table for a continuous composition path."""
    schema = feature_schema_from_training_table(training_features_csv)
    base = dict(base_fractions)
    bsum = sum(base.get(e, 0.0) for e in balance_elements)
    if bsum == 0:
        return {'error': 'balance elements have zero total'}
    ratio = {e: base.get(e, 0.0) / bsum for e in balance_elements}
    rows, formulas = [], []
    for x in x_grid:
        comp = {e: (1 - x) * ratio[e] for e in balance_elements}
        comp[stim_element] = comp.get(stim_element, 0.0) + x
        total = sum(comp.values())
        comp = {k: v / total for k, v in comp.items() if v > 1e-9}
        formula = ''.join(f'{k}{round(v, 4)}' for k, v in comp.items())
        raw = compute_full_feature_vector(formula)['features']
        rows.append(normalise_feature_record(raw, schema))
        formulas.append(formula)
    return {'feature_cols': schema['feature_cols'], 'formulas': formulas, 'rows': rows}


@mcp.tool()
def parse_alloy_formula(formula: str) -> dict:
    """Parse an alloy formula like 'Al1.8CoCrCuFe' or 'Al 30.5 Co 16 ...' into atomic fractions.

    Numbers are interpreted as molar coefficients; missing coefficient = 1.
    Numbers >5 are treated as already-percentage values and re-normalised.
    Returns elemental atomic fractions summing to 1.
    """
    s = formula.replace(' ', '').replace('+', '').strip()
    # element + optional decimal
    pat = re.compile(r'([A-Z][a-z]?)(\d*\.?\d*)')
    counts = {}
    for el, num in pat.findall(s):
        if not el:
            continue
        c = float(num) if num else 1.0
        counts[el] = counts.get(el, 0.0) + c
    if not counts:
        return {"error": "no elements parsed", "formula": formula}
    total = sum(counts.values())
    fractions = {k: v / total for k, v in counts.items()}
    return {
        "formula": formula,
        "elements": list(fractions.keys()),
        "atomic_fractions": {k: round(v, 6) for k, v in fractions.items()},
        "n_elements": len(fractions),
    }


@mcp.tool()
def lookup_element_properties(element: str) -> dict:
    """Return the 13 tabulated properties for a single element.

    Properties: atomic mass (u), metallic radius (A), covalent radius (A),
    density (g/cc), melting point (K), Young's E (GPa), shear G (GPa),
    bulk K (GPa), compressibility beta (1/GPa), Allen electronegativity,
    valence-electron count, molar volume (cc/mol), cohesive energy (eV).
    """
    if element not in ELEMENT_PROPS:
        return {"error": f"unknown element {element}",
                "available": list(ELEMENT_PROPS.keys())}
    vals = ELEMENT_PROPS[element]
    return {n: v for n, v in zip(PROP_NAMES, vals)}


@mcp.tool()
def composition_weighted_average(fractions: dict, prop_name: str) -> dict:
    """Composition-weighted average of one element property: sum_i c_i * P_i.

    fractions: {element_symbol: atomic_fraction}
    prop_name: one of mass/r_met/r_cov/density/Tm/E/G/K/beta/EN/VEC/Vm/E_coh
    """
    if prop_name not in PROP_NAMES:
        return {"error": f"unknown prop {prop_name}", "available": PROP_NAMES}
    idx = PROP_NAMES.index(prop_name)
    val = 0.0
    for el, c in fractions.items():
        if el not in ELEMENT_PROPS:
            return {"error": f"unknown element {el}"}
        val += c * ELEMENT_PROPS[el][idx]
    return {"prop_name": prop_name, "weighted_average": round(val, 6)}


@mcp.tool()
def composition_asymmetry(fractions: dict, prop_name: str) -> dict:
    """Compute asymmetry parameter delta_P = sqrt(sum_i c_i (1 - P_i/<P>)^2).

    This is the standard mismatch / size-asymmetry expression (atomic-size,
    elastic, electronegativity etc.).
    """
    if prop_name not in PROP_NAMES:
        return {"error": f"unknown prop {prop_name}"}
    idx = PROP_NAMES.index(prop_name)
    avg = 0.0
    for el, c in fractions.items():
        avg += c * ELEMENT_PROPS[el][idx]
    if avg == 0:
        return {"prop_name": prop_name, "asymmetry": 0.0}
    s = 0.0
    for el, c in fractions.items():
        s += c * (1 - ELEMENT_PROPS[el][idx] / avg) ** 2
    return {"prop_name": prop_name, "average": round(avg, 6),
            "asymmetry": round(math.sqrt(s), 6)}


@mcp.tool()
def configurational_entropy(fractions: dict) -> dict:
    """Ideal mixing entropy: -R * sum c_i ln c_i (R = 8.314 J/mol/K)."""
    R = 8.314
    s = 0.0
    for c in fractions.values():
        if c > 0:
            s += c * math.log(c)
    S = -R * s
    return {"S_config_J_per_molK": round(S, 6),
            "S_config_kJ_per_molK": round(S / 1000.0, 6)}


# Miedema chemical enthalpy coefficients are extensive; we provide a
# coarse approximation table + symmetric pair sum.
MIEDEMA_PAIR_KJ = {  # J. Alloys Compd 658, 603 (2016) tabulation, kJ/mol
    ('Al','Co'): -19, ('Al','Cr'): -10, ('Al','Cu'): -1, ('Al','Fe'): -11,
    ('Al','Ni'): -22, ('Al','Ti'): -30, ('Al','Mn'): -19, ('Al','V'): -16,
    ('Al','Zr'): -44, ('Al','Hf'): -39, ('Al','Mo'): -5, ('Al','W'): -2,
    ('Al','Nb'): -18, ('Al','Ta'): -19, ('Al','Mg'): -2, ('Al','Si'): -19,
    ('Co','Cr'): -4, ('Co','Cu'): 6, ('Co','Fe'): -1, ('Co','Mn'): -5,
    ('Co','Ni'): 0, ('Co','Ti'): -28, ('Co','Zr'): -41, ('Co','Hf'): -35,
    ('Co','V'): -14, ('Co','Mo'): -5, ('Co','W'): -1, ('Co','Nb'): -25,
    ('Co','Ta'): -24, ('Cr','Cu'): 12, ('Cr','Fe'): -1, ('Cr','Mn'): 2,
    ('Cr','Ni'): -7, ('Cr','Ti'): -7, ('Cr','Zr'): -12, ('Cr','Hf'): -9,
    ('Cr','V'): -2, ('Cr','Mo'): 0, ('Cr','W'): 1, ('Cr','Nb'): -7,
    ('Cr','Ta'): -7, ('Cu','Fe'): 13, ('Cu','Mn'): 4, ('Cu','Ni'): 4,
    ('Cu','Ti'): -9, ('Cu','Zr'): -23, ('Cu','Hf'): -17, ('Cu','V'): 5,
    ('Cu','Mo'): 19, ('Cu','W'): 22, ('Cu','Nb'): 3, ('Cu','Ta'): 2,
    ('Fe','Mn'): 0, ('Fe','Ni'): -2, ('Fe','Ti'): -17, ('Fe','Zr'): -25,
    ('Fe','Hf'): -21, ('Fe','V'): -7, ('Fe','Mo'): -2, ('Fe','W'): 0,
    ('Fe','Nb'): -16, ('Fe','Ta'): -15, ('Mn','Ni'): -8, ('Mn','Ti'): -8,
    ('Mn','Zr'): -15, ('Mn','V'): -1, ('Mn','Mo'): 5, ('Mn','W'): 6,
    ('Ni','Ti'): -35, ('Ni','Zr'): -49, ('Ni','Hf'): -42, ('Ni','V'): -18,
    ('Ni','Mo'): -7, ('Ni','W'): -3, ('Ni','Nb'): -30, ('Ni','Ta'): -29,
    ('Ti','Zr'): 0, ('Ti','Hf'): 0, ('Ti','V'): -2, ('Ti','Mo'): -4,
    ('Ti','W'): -6, ('Ti','Nb'): 2, ('Ti','Ta'): 1, ('Zr','Hf'): 0,
    ('Zr','V'): -4, ('Zr','Mo'): -6, ('Zr','W'): -9, ('Zr','Nb'): 4,
    ('Zr','Ta'): 3, ('Hf','V'): -2, ('Hf','Mo'): -4, ('Hf','W'): -6,
    ('Hf','Nb'): 4, ('Hf','Ta'): 3, ('V','Mo'): 0, ('V','W'): -1,
    ('V','Nb'): -1, ('V','Ta'): -1, ('Mo','W'): 0, ('Mo','Nb'): -6,
    ('Mo','Ta'): -5, ('W','Nb'): -8, ('W','Ta'): -7, ('Nb','Ta'): 0,
    ('Mg','Cu'): -3, ('Mg','Ni'): -4, ('Mg','Si'): -26, ('Mg','Al'): -2,
    ('Si','Co'): -38, ('Si','Cr'): -37, ('Si','Cu'): -19, ('Si','Fe'): -35,
    ('Si','Mn'): -45, ('Si','Ni'): -40, ('Si','Ti'): -66, ('Si','V'): -48,
    ('Si','Mo'): -35, ('Si','W'): -31, ('Si','Nb'): -56, ('Si','Ta'): -56,
    ('Si','Zr'): -84, ('Si','Hf'): -77,
}


@mcp.tool()
def miedema_chemical_enthalpy(fractions: dict) -> dict:
    """Mixing enthalpy from Miedema's binary table:
       dH_chem = sum_{i<j} 4 H_ij c_i c_j  (kJ/mol).

    Missing pairs default to 0. Returned value is positive for clustering /
    negative for ordering / strong attraction.
    """
    elements = list(fractions.keys())
    H = 0.0
    used, missing = 0, 0
    for i in range(len(elements)):
        for j in range(i + 1, len(elements)):
            a, b = elements[i], elements[j]
            ci, cj = fractions[a], fractions[b]
            key = (a, b) if (a, b) in MIEDEMA_PAIR_KJ else \
                  ((b, a) if (b, a) in MIEDEMA_PAIR_KJ else None)
            if key is None:
                missing += 1
                continue
            H += 4 * MIEDEMA_PAIR_KJ[key] * ci * cj
            used += 1
    return {"H_chem_kJ_per_mol": round(H, 4),
            "n_pairs_used": used, "n_pairs_missing": missing}


@mcp.tool()
def elastic_mixing_enthalpy(fractions: dict) -> dict:
    """Approximate elastic mixing enthalpy (kJ/mol):
       dH_el = sum_{i<j} (2 K_i G_j (V_i - V_j)^2 / (3 K_i V_j + 4 G_j V_i)) c_i c_j
       This embodies size + bulk/shear modulus mismatch.
    """
    els = list(fractions.keys())
    H = 0.0
    for i in range(len(els)):
        for j in range(i + 1, len(els)):
            a, b = els[i], els[j]
            if a not in ELEMENT_PROPS or b not in ELEMENT_PROPS:
                continue
            Ka, Ga, Va = ELEMENT_PROPS[a][7], ELEMENT_PROPS[a][6], ELEMENT_PROPS[a][11]
            Kb, Gb, Vb = ELEMENT_PROPS[b][7], ELEMENT_PROPS[b][6], ELEMENT_PROPS[b][11]
            dV = Va - Vb
            denom = 3 * Ka * Vb + 4 * Gb * Va
            if denom == 0:
                continue
            term = (2 * Ka * Gb * dV * dV) / denom
            # Convert GPa*cc to kJ/mol: 1 GPa*cc = 1 J = 1e-3 kJ
            H += term * 1e-3 * fractions[a] * fractions[b]
    return {"H_el_kJ_per_mol": round(H, 4)}


@mcp.tool()
def compute_full_feature_vector(formula: str) -> dict:
    """Compute raw physics descriptors for one alloy formula.

    Returns un-normalised composition-weighted averages and asymmetries (delta).
    These are intended for building descriptors along continuous composition
    pathways; they are NOT on the same scale/naming as the pre-normalised 22
    columns in db_HEAs.csv used to train the regressor.

    Returns averages and asymmetries (delta) of: r_met, r_cov, density, Tm,
    E, G, K, beta, EN, VEC, Vm, E_coh; plus configurational entropy,
    Miedema chemical enthalpy, and elastic mixing enthalpy.
    """
    parsed = parse_alloy_formula(formula)  # bypass MCP wrapper
    if "error" in parsed:
        return parsed
    f = parsed["atomic_fractions"]
    feats = {}
    for p in ['r_met', 'r_cov', 'density', 'Tm', 'E', 'G', 'K', 'beta',
              'EN', 'VEC', 'Vm', 'E_coh']:
        avg = composition_weighted_average(f, p)
        asym = composition_asymmetry(f, p)
        feats[f'{p}_avg'] = avg.get('weighted_average')
        feats[f'{p}_delta'] = asym.get('asymmetry')
    feats['S_config'] = configurational_entropy(f)['S_config_J_per_molK']
    feats['H_avg'] = sum(f[el] * ELEMENT_HARDNESS_HV[el] for el in f)
    feats['H_chem'] = miedema_chemical_enthalpy(f)['H_chem_kJ_per_mol']
    feats['H_el'] = elastic_mixing_enthalpy(f)['H_el_kJ_per_mol']
    return {"formula": formula, "features": feats, "n_features": len(feats)}


@mcp.tool()
def pearson_correlation(x: list, y: list) -> dict:
    """Pearson correlation coefficient and slope of a simple linear fit."""
    a = np.array(x, dtype=float)
    b = np.array(y, dtype=float)
    if len(a) < 3:
        return {"error": "need >=3 points"}
    r = float(np.corrcoef(a, b)[0, 1])
    slope, intercept = np.polyfit(a, b, 1)
    ss_res = ((b - (slope * a + intercept)) ** 2).sum()
    ss_tot = ((b - b.mean()) ** 2).sum()
    r2 = 1 - ss_res / ss_tot if ss_tot > 0 else 0.0
    return {"r": round(r, 4), "r2": round(r2, 4),
            "slope": round(float(slope), 6),
            "intercept": round(float(intercept), 6),
            "n": len(a)}


@mcp.tool()
def train_ann_ensemble(features_csv: str, target_col: str = "VHN",
                       feature_cols: list = None,
                       n_models: int = 25, hidden_layers: list = None,
                       epochs: int = 400, val_frac: float = 0.2,
                       seed_start: int = 0, learning_rate: float = 0.01) -> dict:
    """Train an ensemble of feed-forward neural networks for hardness regression.

    Mirrors the paper's design: many independently initialised ANNs, each
    trained on the full feature set; final prediction is the mean over the
    ensemble. min-max scales features and target to [0,1] before training.

    Args:
        features_csv: CSV with target_col and feature_cols
        target_col: target column name
        feature_cols: list of feature column names (None -> all numeric except target)
        n_models: number of independent networks
        hidden_layers: list of hidden-layer widths (None -> [16, 8, 4])
        epochs: training epochs per model
        val_frac: held-out validation fraction (per model, random)
        seed_start: starting random seed for reproducibility
        learning_rate: Adam learning rate
    Returns:
        dict with ensemble_id (used by predict_ann_ensemble) and per-model
        validation R2 / RMSE / MAE summary.
    """
    import pandas as pd
    from sklearn.neural_network import MLPRegressor
    from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error

    df = pd.read_csv(features_csv).dropna(subset=[target_col])
    if feature_cols is None:
        feature_cols = [c for c in df.columns
                        if c != target_col and df[c].dtype.kind in 'fiu']
    X = df[feature_cols].to_numpy(dtype=float)
    y = df[target_col].to_numpy(dtype=float)
    # min-max scale features and target
    x_min, x_max = X.min(0), X.max(0)
    rng = np.where(x_max - x_min == 0, 1, x_max - x_min)
    Xn = (X - x_min) / rng
    y_min, y_max = float(y.min()), float(y.max())
    yn = (y - y_min) / (y_max - y_min)
    if hidden_layers is None:
        hidden_layers = [16, 8, 4]

    models = []
    summaries = []
    for k in range(n_models):
        rs = seed_start + k
        rng_np = np.random.default_rng(rs)
        idx = np.arange(len(yn))
        rng_np.shuffle(idx)
        cut = int(len(idx) * (1 - val_frac))
        tr, va = idx[:cut], idx[cut:]
        m = MLPRegressor(hidden_layer_sizes=tuple(hidden_layers),
                         activation='relu',
                         solver='adam', learning_rate_init=learning_rate,
                         max_iter=epochs, random_state=rs)
        m.fit(Xn[tr], yn[tr])
        pv = m.predict(Xn[va])
        pv_de = pv * (y_max - y_min) + y_min
        true_de = yn[va] * (y_max - y_min) + y_min
        summaries.append({
            "model": k,
            "val_r2": round(float(r2_score(true_de, pv_de)), 4),
            "val_rmse": round(float(math.sqrt(mean_squared_error(true_de, pv_de))), 2),
            "val_mae": round(float(mean_absolute_error(true_de, pv_de)), 2),
        })
        models.append(m)

    state = {"models": models, "x_min": x_min, "x_max": x_max,
             "y_min": y_min, "y_max": y_max, "feature_cols": feature_cols,
             "target_col": target_col}
    eid = hashlib.md5(pickle.dumps([feature_cols, n_models, hidden_layers,
                                    seed_start])[:1000]).hexdigest()[:8]
    os.makedirs("/tmp/hea_ens", exist_ok=True)
    with open(f"/tmp/hea_ens/{eid}.pkl", "wb") as f:
        pickle.dump(state, f)
    avg_r2 = float(np.mean([s["val_r2"] for s in summaries]))
    return {"ensemble_id": eid, "n_models": len(models),
            "feature_cols": feature_cols, "hidden_layers": hidden_layers,
            "mean_val_r2": round(avg_r2, 4), "per_model": summaries}


@mcp.tool()
def predict_ann_ensemble(ensemble_id: str, features_csv: str,
                         feature_cols: list = None,
                         target_col: str = None) -> dict:
    """Predict hardness on a new CSV using an ensemble (averaged).

    If target_col is in the CSV, also returns RMSE / MAE / mean %err / R2 /
    fraction-within-80%-accuracy (paper's metric).
    """
    import pandas as pd
    from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error

    with open(f"/tmp/hea_ens/{ensemble_id}.pkl", "rb") as f:
        state = pickle.load(f)
    df = pd.read_csv(features_csv)
    if feature_cols is None:
        feature_cols = state["feature_cols"]
    X = df[feature_cols].to_numpy(dtype=float)
    rng = np.where(state["x_max"] - state["x_min"] == 0, 1,
                   state["x_max"] - state["x_min"])
    Xn = (X - state["x_min"]) / rng
    preds = np.mean([m.predict(Xn) for m in state["models"]], axis=0)
    preds_de = preds * (state["y_max"] - state["y_min"]) + state["y_min"]
    out = {"ensemble_id": ensemble_id,
           "predictions": [round(float(v), 2) for v in preds_de],
           "n": len(preds_de)}
    if target_col and target_col in df.columns:
        true = df[target_col].to_numpy(dtype=float)
        mask = ~np.isnan(true)
        if mask.sum() > 1:
            t, p = true[mask], preds_de[mask]
            err_pct = np.abs((p - t) / t) * 100
            within80 = float((err_pct <= 20).mean())
            out["r2"] = round(float(r2_score(t, p)), 4)
            out["rmse"] = round(float(math.sqrt(mean_squared_error(t, p))), 2)
            out["mae"] = round(float(mean_absolute_error(t, p)), 2)
            out["mean_pct_err"] = round(float(err_pct.mean()), 2)
            out["fraction_within_80pct_accuracy"] = round(within80, 3)
    return out


@mcp.tool()
def cross_validate_ensemble(features_csv: str, target_col: str = "VHN",
                            feature_cols: list = None, n_folds: int = 5,
                            n_models_per_fold: int = 25,
                            hidden_layers: list = None,
                            epochs: int = 400) -> dict:
    """K-fold cross-validation of the ensemble approach.

    Returns mean and per-fold R2 / RMSE / MAE / mean-%error / within-80%.
    Mirrors the paper's 5-fold CV protocol (Sup. Table 2).
    """
    import pandas as pd
    from sklearn.model_selection import KFold
    from sklearn.neural_network import MLPRegressor
    from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error

    df = pd.read_csv(features_csv).dropna(subset=[target_col])
    if feature_cols is None:
        feature_cols = [c for c in df.columns
                        if c != target_col and df[c].dtype.kind in 'fiu']
    X = df[feature_cols].to_numpy(dtype=float)
    y = df[target_col].to_numpy(dtype=float)
    if hidden_layers is None:
        hidden_layers = [16, 8, 4]
    kf = KFold(n_splits=n_folds, shuffle=True, random_state=0)
    fold_metrics = []
    oof_rows = []
    all_pred, all_true = [], []
    for fi, (tr, va) in enumerate(kf.split(X)):
        x_min, x_max = X[tr].min(0), X[tr].max(0)
        rng = np.where(x_max - x_min == 0, 1, x_max - x_min)
        Xtr = (X[tr] - x_min) / rng
        Xva = (X[va] - x_min) / rng
        y_min, y_max = float(y[tr].min()), float(y[tr].max())
        y_rng = y_max - y_min if y_max != y_min else 1.0
        ytr = (y[tr] - y_min) / y_rng
        models = []
        for k in range(n_models_per_fold):
            m = MLPRegressor(hidden_layer_sizes=tuple(hidden_layers),
                             activation='relu', solver='adam',
                             max_iter=epochs, random_state=fi * 1000 + k)
            m.fit(Xtr, ytr)
            models.append(m)
        pn = np.mean([m.predict(Xva) for m in models], axis=0)
        p = pn * y_rng + y_min
        t = y[va]
        all_pred.extend(p.tolist()); all_true.extend(t.tolist())
        for idx, true, pred in zip(va, t, p):
            oof_rows.append({'row_index': int(idx), 'fold': fi + 1, 'actual': float(true), 'predicted': float(pred)})
        err = np.abs((p - t) / t) * 100
        fold_metrics.append({
            "fold": fi + 1, "n_val": len(va),
            "r2": round(float(r2_score(t, p)), 4),
            "rmse": round(float(math.sqrt(mean_squared_error(t, p))), 2),
            "mae": round(float(mean_absolute_error(t, p)), 2),
            "mean_pct_err": round(float(err.mean()), 2),
            "fraction_within_80": round(float((err <= 20).mean()), 3),
        })
    return {"n_folds": n_folds, "n_models_per_fold": n_models_per_fold,
            "feature_cols": feature_cols,
            "mean_r2": round(float(np.mean([m["r2"] for m in fold_metrics])), 4),
            "mean_rmse": round(float(np.mean([m["rmse"] for m in fold_metrics])), 2),
            "mean_mae": round(float(np.mean([m["mae"] for m in fold_metrics])), 2),
            "mean_pct_err": round(float(np.mean([m["mean_pct_err"] for m in fold_metrics])), 2),
            "mean_within80": round(float(np.mean([m["fraction_within_80"] for m in fold_metrics])), 3),
            "per_fold": fold_metrics,
            "out_of_fold_predictions": sorted(oof_rows, key=lambda r: r['row_index'])}


@mcp.tool()
def stimulus_response_curve(ensemble_id: str, base_fractions: dict,
                            stim_element: str,
                            balance_elements: list,
                            training_features_csv: str,
                            x_grid: list = None) -> dict:
    """Sweep one element fraction and predict hardness vs composition.

    Implements the paper's stimulus-response analysis (Eq. 1-3): start at
    a baseline composition, increment a chosen element by Dx in steps,
    re-balance the remainder over the listed balance elements (preserving
    their internal ratio), recompute the 22 physics features, and call
    the loaded ensemble for each step.
    """
    if x_grid is None:
        x_grid = [round(0.01 * i, 4) for i in range(0, 26)]
    table = composition_path_feature_table(base_fractions, stim_element, balance_elements, x_grid, training_features_csv)
    if 'error' in table:
        return table
    import pandas as pd, tempfile
    tmp = tempfile.NamedTemporaryFile(suffix='.csv', delete=False, mode='w')
    pd.DataFrame(table['rows'], columns=table['feature_cols']).to_csv(tmp.name, index=False)
    tmp.close()
    pred = predict_ann_ensemble(ensemble_id, tmp.name, feature_cols=table['feature_cols'])
    return {"x_grid": x_grid, "stim_element": stim_element,
            "balance_elements": balance_elements,
            "feature_columns": table['feature_cols'],
            "formulas": table['formulas'],
            "predicted_hardness": pred["predictions"],
            "n_points": len(x_grid)}


@mcp.tool()
def feature_contribution_path(ensemble_id: str, base_fractions: dict,
                              stim_element: str, balance_elements: list,
                              training_features_csv: str,
                              x_grid: list = None) -> dict:
    """Cumulative per-feature hardness contribution along a composition path
    (paper Eq. 2-3). For each step Dx, freeze all features except F_i at
    their baseline values, vary F_i to its actual value, and credit the
    induced delta-HV to that feature. Sum gives feature_i's contribution at
    each x.
    """
    if x_grid is None:
        x_grid = [round(0.01 * i, 4) for i in range(0, 26)]
    table = composition_path_feature_table(base_fractions, stim_element, balance_elements, x_grid, training_features_csv)
    if 'error' in table:
        return table
    cols = table['feature_cols']
    base_vec = np.array([table['rows'][0][c] for c in cols], dtype=float)

    import pandas as pd, tempfile
    # Predict hardness at any feature vector
    def predict_one(vec):
        tmp = tempfile.NamedTemporaryFile(suffix='.csv', delete=False, mode='w')
        pd.DataFrame([vec], columns=cols).to_csv(tmp.name, index=False)
        tmp.close()
        out = predict_ann_ensemble(ensemble_id, tmp.name, feature_cols=cols)
        return out["predictions"][0]

    HV_base = predict_one(base_vec.tolist())
    contributions = {c: [0.0] for c in cols}  # cumulative per feature
    overall = [HV_base]
    prev_vec = base_vec.copy()

    for x in x_grid[1:]:
        row = table['rows'][len(overall)]
        cur_vec = np.array([row[c] for c in cols], dtype=float)
        # incremental contribution: vary one feature at a time from prev to cur
        running_vec = prev_vec.copy()
        running_HV = predict_one(running_vec.tolist())
        for i, c in enumerate(cols):
            new_vec = running_vec.copy()
            new_vec[i] = cur_vec[i]
            new_HV = predict_one(new_vec.tolist())
            d_HV = new_HV - running_HV
            contributions[c].append(contributions[c][-1] + d_HV)
            running_vec = new_vec
            running_HV = new_HV
        prev_vec = cur_vec
        overall.append(running_HV)
    return {"x_grid": x_grid, "overall_hardness": [round(v, 2) for v in overall],
            "feature_contributions": {k: [round(v, 2) for v in vals]
                                      for k, vals in contributions.items()},
            "baseline_HV": round(HV_base, 2),
            "feature_columns": cols, "formulas": table["formulas"]}


# =============================================================
# Plotting tools — one per answer image
# =============================================================
@mcp.tool()
def plot_parity(predictions: list, true_values: list,
                output_path: str = "artifacts/parity.png",
                title: str = "Predicted vs Actual Hardness",
                accuracy_pct: float = 20.0) -> dict:
    """Parity plot with 80%-accuracy band, MAE/RMSE/%err annotation.

    Mirrors paper Fig 2d. accuracy_pct = e.g. 20 for the 80% band.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    p = np.array(predictions, dtype=float)
    t = np.array(true_values, dtype=float)
    err_pct = np.abs((p - t) / t) * 100
    within = (err_pct <= accuracy_pct).mean()
    mae = float(np.mean(np.abs(p - t)))
    rmse = float(math.sqrt(np.mean((p - t) ** 2)))
    fig, ax = plt.subplots(figsize=(6, 6))
    lim = [0, max(p.max(), t.max()) * 1.05]
    band_low = np.array(lim) * (1 - accuracy_pct / 100)
    band_high = np.array(lim) * (1 + accuracy_pct / 100)
    ax.fill_between(lim, band_low, band_high, color='lightblue', alpha=0.4,
                    label=f"{100-accuracy_pct:.0f}% accuracy band")
    ax.plot(lim, lim, 'k--', lw=1)
    ax.scatter(t, p, alpha=0.6, s=24, c='steelblue', edgecolor='k', linewidth=0.3)
    ax.set_xlim(lim); ax.set_ylim(lim)
    ax.set_xlabel("Actual Hardness (HV)")
    ax.set_ylabel("Predicted Hardness (HV)")
    ax.set_title(title)
    ax.text(0.05, 0.95,
            f"MAE = {mae:.1f}\nRMSE = {rmse:.1f}\n%Err = {err_pct.mean():.1f}%\n"
            f"Within 80% = {within:.2f}",
            transform=ax.transAxes, va='top',
            bbox=dict(boxstyle='round', facecolor='white', alpha=0.85))
    ax.legend(loc='lower right')
    fig.tight_layout(); fig.savefig(output_path, dpi=150); plt.close(fig)
    return {"output_path": output_path, "mae": round(mae, 2),
            "rmse": round(rmse, 2),
            "mean_pct_err": round(float(err_pct.mean()), 2),
            "within_80pct": round(float(within), 3)}


@mcp.tool()
def plot_feature_correlation_bars(features_csv: str, target_col: str = "VHN",
                                  feature_cols: list = None,
                                  output_path: str = "artifacts/feature_correlation.png") -> dict:
    """Horizontal bar chart of Pearson correlation of each feature with hardness.

    Mirrors paper Sup. Fig 2 ranking.
    """
    import pandas as pd
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    df = pd.read_csv(features_csv).dropna(subset=[target_col])
    if feature_cols is None:
        feature_cols = [c for c in df.columns
                        if c != target_col and df[c].dtype.kind in 'fiu']
    rs = []
    for c in feature_cols:
        rs.append((c, float(np.corrcoef(df[c], df[target_col])[0, 1])))
    rs.sort(key=lambda kv: kv[1])
    names = [k for k, _ in rs]
    vals = [v for _, v in rs]
    fig, ax = plt.subplots(figsize=(7, max(4, 0.3 * len(rs))))
    colors = ['firebrick' if v < 0 else 'steelblue' for v in vals]
    ax.barh(names, vals, color=colors)
    ax.axvline(0, color='k', lw=0.5)
    ax.set_xlabel("Pearson r with VHN")
    ax.set_title("Feature - Hardness Correlation")
    fig.tight_layout(); fig.savefig(output_path, dpi=150); plt.close(fig)
    return {"output_path": output_path, "ranked_correlations":
            [{"feature": k, "r": round(v, 3)} for k, v in rs]}


@mcp.tool()
def plot_feature_contributions(contributions: dict, x_grid: list,
                               overall_hardness: list = None,
                               output_path: str = "artifacts/feature_contributions.png",
                               title: str = "Cumulative feature contribution to HV") -> dict:
    """Plot cumulative per-feature HV contribution vs composition (paper Fig 6).

    contributions: {feature_name: [HV contribution at each x]}
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(8, 6))
    for k, ys in contributions.items():
        ax.plot(x_grid, ys, label=k, lw=1.5)
    if overall_hardness is not None:
        ax.plot(x_grid, overall_hardness, 'k-', lw=2.5, label='Overall HV')
    ax.set_xlabel("Composition variable x")
    ax.set_ylabel("Hardness contribution (HV)")
    ax.set_title(title)
    ax.legend(loc='best', fontsize=8, ncol=2)
    fig.tight_layout(); fig.savefig(output_path, dpi=150); plt.close(fig)
    return {"output_path": output_path, "n_features": len(contributions)}


if __name__ == "__main__":
    mcp.run(transport="stdio")

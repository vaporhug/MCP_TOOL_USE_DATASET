#!/usr/bin/env python3
"""Low-level primitives for polyester monomer-set property prediction.

This module exposes runnable FastMCP tools that the agent can compose to
build a multi-monomer polymer property pipeline:

  parse_smiles -> compute_morgan_fingerprint / compute_rdkit_descriptors
                  -> aggregate_monomer_features (set pooling)
                  -> assemble_resin_features (monomers + resin properties)
                  -> train_property_model -> predict_and_score -> plot_*

No domain reasoning is hard-coded — choices about which monomer set, which
pooling operator, which scaler / transform, which model family, and which
held-out split to use are left to the agent.
"""
from __future__ import annotations

import hashlib
import json
import os
import pickle
from typing import Optional

import numpy as np
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("PolymerGNN_Tools")

# ---------------------------------------------------------------------------
# IO helpers
# ---------------------------------------------------------------------------

@mcp.tool()
def load_resin_table(csv_path: str) -> dict:
    """Load the polyester resin CSV and return shape, columns, and target counts.

    The expected schema:
      - resin_id (int)
      - acid_number, hydroxyl_number (mg KOH / g)
      - iv_dL_g, tg_celsius (target properties; may be missing)
      - mn_polystyrene, mw_polystyrene (g/mol)
      - pct_<MONOMER>: percent composition for each acid / glycol monomer.

    Args:
        csv_path: Path to polyester_resins.csv.
    Returns:
        dict with shape, columns, n_iv, n_tg, n_both, monomer_columns.
    """
    import pandas as pd

    df = pd.read_csv(csv_path)
    monomer_cols = [c for c in df.columns if c.startswith("pct_")]
    n_iv = int(df["iv_dL_g"].notna().sum())
    n_tg = int(df["tg_celsius"].notna().sum())
    n_both = int((df["iv_dL_g"].notna() & df["tg_celsius"].notna()).sum())
    return {
        "shape": list(df.shape),
        "columns": list(df.columns),
        "monomer_columns": monomer_cols,
        "n_resins": int(len(df)),
        "n_with_iv": n_iv,
        "n_with_tg": n_tg,
        "n_with_both": n_both,
    }


@mcp.tool()
def load_monomer_smiles(csv_path: str) -> dict:
    """Load the monomer SMILES dictionary.

    Args:
        csv_path: Path to monomer_smiles.csv (columns: name, abbr, smiles).
    Returns:
        dict mapping abbreviation -> {name, smiles}, plus a list of all
        abbreviations.
    """
    import pandas as pd

    df = pd.read_csv(csv_path)
    table = {}
    for _, r in df.iterrows():
        table[str(r["abbr"]).strip()] = {
            "name": str(r["name"]).strip(),
            "smiles": str(r["smiles"]).strip(),
        }
    return {"n_monomers": len(table), "monomers": table,
            "abbreviations": list(table.keys())}


# ---------------------------------------------------------------------------
# Molecular structure primitives
# ---------------------------------------------------------------------------

@mcp.tool()
def parse_smiles(smiles: str) -> dict:
    """Parse a SMILES string with RDKit and return basic graph statistics.

    Args:
        smiles: A SMILES molecular structure.
    Returns:
        dict with n_atoms, n_bonds, mol_weight, n_rings, n_aromatic_atoms,
        canonical_smiles, and a flag indicating successful parse.
    """
    from rdkit import Chem
    from rdkit.Chem import Descriptors

    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return {"valid": False, "error": "RDKit could not parse SMILES",
                "input_smiles": smiles}
    n_atoms = mol.GetNumAtoms()
    n_bonds = mol.GetNumBonds()
    n_aromatic = sum(int(a.GetIsAromatic()) for a in mol.GetAtoms())
    n_rings = mol.GetRingInfo().NumRings()
    mw = float(Descriptors.MolWt(mol))
    return {
        "valid": True,
        "input_smiles": smiles,
        "canonical_smiles": Chem.MolToSmiles(mol),
        "n_atoms": int(n_atoms),
        "n_bonds": int(n_bonds),
        "n_aromatic_atoms": int(n_aromatic),
        "n_rings": int(n_rings),
        "mol_weight": round(mw, 4),
    }


@mcp.tool()
def compute_morgan_fingerprint(smiles: str, radius: int = 2,
                                n_bits: int = 1024) -> dict:
    """Compute a Morgan (ECFP-style) circular fingerprint for one SMILES.

    Args:
        smiles: Molecular SMILES.
        radius: ECFP radius (typical 2 -> ECFP4).
        n_bits: Length of the bit-vector.
    Returns:
        dict with smiles, radius, n_bits, and the bit list (0/1 ints).
    """
    from rdkit import Chem
    from rdkit.Chem import AllChem

    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return {"valid": False, "error": "parse failure", "smiles": smiles}
    fp = AllChem.GetMorganFingerprintAsBitVect(mol, radius, nBits=n_bits)
    bits = [int(b) for b in fp.ToBitString()]
    return {"valid": True, "smiles": smiles, "radius": radius,
            "n_bits": n_bits, "fingerprint": bits, "n_on_bits": int(sum(bits))}


@mcp.tool()
def compute_rdkit_descriptors(smiles: str) -> dict:
    """Compute a small panel of molecular descriptors with RDKit.

    Returns: MolWt, HeavyAtomCount, NumHDonors, NumHAcceptors, NumRotatableBonds,
    TPSA, NumAromaticRings, NumAliphaticRings, FractionCSP3, MolLogP.

    Args:
        smiles: Molecular SMILES.
    """
    from rdkit import Chem
    from rdkit.Chem import Descriptors, Crippen, Lipinski, rdMolDescriptors

    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return {"valid": False, "error": "parse failure"}
    out = {
        "valid": True,
        "smiles": smiles,
        "MolWt": round(float(Descriptors.MolWt(mol)), 4),
        "HeavyAtomCount": int(Lipinski.HeavyAtomCount(mol)),
        "NumHDonors": int(Lipinski.NumHDonors(mol)),
        "NumHAcceptors": int(Lipinski.NumHAcceptors(mol)),
        "NumRotatableBonds": int(Lipinski.NumRotatableBonds(mol)),
        "TPSA": round(float(Descriptors.TPSA(mol)), 4),
        "NumAromaticRings": int(rdMolDescriptors.CalcNumAromaticRings(mol)),
        "NumAliphaticRings": int(rdMolDescriptors.CalcNumAliphaticRings(mol)),
        "FractionCSP3": round(float(rdMolDescriptors.CalcFractionCSP3(mol)), 4),
        "MolLogP": round(float(Crippen.MolLogP(mol)), 4),
    }
    return out


# ---------------------------------------------------------------------------
# Set pooling — the central PolymerGNN-style operation: combine variable-size
# sets of monomer features into a fixed-size resin vector.
# ---------------------------------------------------------------------------

@mcp.tool()
def aggregate_monomer_features(monomer_features: list,
                                 weights: Optional[list] = None,
                                 method: str = "max") -> dict:
    """Pool a variable-size set of monomer feature vectors to a fixed-size vector.

    PolymerGNN-style set pooling. The agent supplies a list of per-monomer
    vectors (e.g. fingerprints or descriptors) and optionally per-monomer
    stoichiometric weights. The aggregator returns one resin-level vector.

    Args:
        monomer_features: List of equal-length lists (one per monomer present).
        weights: Optional list of non-negative weights (e.g., monomer mole
            fractions). If supplied, used for the weighted_mean pool only.
        method: "max" | "mean" | "sum" | "weighted_mean".
    Returns:
        dict with the pooled vector and the chosen method.
    """
    if not monomer_features:
        return {"error": "empty monomer set"}
    M = np.asarray(monomer_features, dtype=float)
    if method == "max":
        pooled = M.max(axis=0)
    elif method == "mean":
        pooled = M.mean(axis=0)
    elif method == "sum":
        pooled = M.sum(axis=0)
    elif method == "weighted_mean":
        if weights is None or len(weights) != len(monomer_features):
            return {"error": "weights required for weighted_mean"}
        w = np.asarray(weights, dtype=float)
        if w.sum() == 0:
            return {"error": "weights sum to zero"}
        pooled = (M * w[:, None]).sum(axis=0) / w.sum()
    else:
        return {"error": f"unknown method {method}"}
    return {"method": method, "pooled_vector": [round(float(x), 6)
                                                  for x in pooled],
            "n_monomers": len(monomer_features),
            "n_features": int(M.shape[1])}


@mcp.tool()
def assemble_resin_features(resin_csv: str, monomer_csv: str,
                              feature_kind: str = "morgan",
                              radius: int = 2, n_bits: int = 1024,
                              acid_pool: str = "max",
                              glycol_pool: str = "max",
                              include_resin_props: bool = True,
                              output_path: str = "/tmp/resin_features.pkl"
                              ) -> dict:
    """Build a feature matrix combining acid- and glycol-monomer set pools
    with optional resin-level scalar properties.

    The pipeline mirrors the PolymerGNN central embedding: separate pooled
    embeddings for the acid set and the glycol set are concatenated with the
    resin-level scalar properties.

    Args:
        resin_csv: Path to polyester_resins.csv.
        monomer_csv: Path to monomer_smiles.csv.
        feature_kind: "morgan" | "rdkit_descriptors".
        radius: Morgan radius (only when feature_kind == 'morgan').
        n_bits: Morgan length (only when feature_kind == 'morgan').
        acid_pool: pooling method for the acid set.
        glycol_pool: pooling method for the glycol set.
        include_resin_props: append [Mw, AN, OHN, %TMP] resin scalars.
        output_path: path to pickle features for downstream training tools.
    Returns:
        dict with shape, n_iv, n_tg, monomer_feature_dim, n_resin_props.
    """
    import pandas as pd
    from rdkit import Chem
    from rdkit.Chem import AllChem, Descriptors, Lipinski, Crippen, rdMolDescriptors

    df = pd.read_csv(resin_csv)
    mono = pd.read_csv(monomer_csv)
    mono.columns = [c.strip() for c in mono.columns]
    smiles_map = {str(r["abbr"]).strip(): str(r["smiles"]).strip()
                  for _, r in mono.iterrows()}
    # Paper schema: 12 acid SMILES and 12 glycol SMILES. The resin table has
    # 25 pct_* columns because 1,4-CHDA_95pct__trans is a stereochemical
    # composition variant pooled into the same 1,4-CHDA graph.
    ACID_ABBRS = ["TPA", "IPA", "PA", "1,4-CHDA", "1,3-CHDA", "1,2-CHDA",
                  "ADP", "SA", "HHPA", "TMA", "DDDA", "AZL"]
    GLYCOL_ABBRS = ["EG", "DEG", "1,3-PROP", "1,4-BUT", "HDO", "NPG",
                    "1,4-CHDM", "1,3-CHDM", "TMCD", "TMP", "MPD", "TCDDM"]
    MONOMER_COL_ALIASES = {
        "1,4-CHDA": ["pct_1_4_CHDA", "pct_1_4_CHDA_95pct__trans"],
    }

    # column names in the resin CSV use the abbr with non-alnum chars stripped
    def col(abbr): return ("pct_" + abbr).replace(",", "_").replace("-", "_")

    def pct_columns(abbr):
        aliases = MONOMER_COL_ALIASES.get(abbr, [col(abbr)])
        return [c for c in aliases if c in df.columns]

    def featurize(smi: str) -> np.ndarray:
        mol = Chem.MolFromSmiles(smi)
        if mol is None:
            raise ValueError(f"Bad SMILES: {smi}")
        if feature_kind == "morgan":
            fp = AllChem.GetMorganFingerprintAsBitVect(mol, radius, nBits=n_bits)
            return np.asarray([int(b) for b in fp.ToBitString()], dtype=float)
        elif feature_kind == "rdkit_descriptors":
            v = [
                Descriptors.MolWt(mol), Lipinski.HeavyAtomCount(mol),
                Lipinski.NumHDonors(mol), Lipinski.NumHAcceptors(mol),
                Lipinski.NumRotatableBonds(mol), Descriptors.TPSA(mol),
                rdMolDescriptors.CalcNumAromaticRings(mol),
                rdMolDescriptors.CalcNumAliphaticRings(mol),
                rdMolDescriptors.CalcFractionCSP3(mol), Crippen.MolLogP(mol),
            ]
            return np.asarray(v, dtype=float)
        raise ValueError(f"Unknown feature_kind {feature_kind}")

    def pool(vecs, weights, method):
        if not vecs:
            # produce a zero vector of the right size
            return np.zeros(featurize(smiles_map["TPA"]).shape, dtype=float)
        M = np.stack(vecs, axis=0)
        w = np.asarray(weights, dtype=float)
        if method == "max":
            return M.max(axis=0)
        if method == "mean":
            return M.mean(axis=0)
        if method == "sum":
            return M.sum(axis=0)
        if method == "weighted_mean":
            return (M * w[:, None]).sum(axis=0) / max(w.sum(), 1e-12)
        raise ValueError(method)

    rows = []
    iv_y = []
    tg_y = []
    scalar_cols = ["mw_polystyrene", "acid_number", "hydroxyl_number"]
    scalar_medians = {
        c: float(pd.to_numeric(df[c], errors="coerce").median())
        for c in scalar_cols if c in df.columns
    }
    for _, r in df.iterrows():
        acid_vecs, acid_w = [], []
        for ab in ACID_ABBRS:
            cols = pct_columns(ab)
            if not cols:
                continue
            pct = sum(float(r.get(c, 0) or 0) for c in cols)
            if pct > 0:
                acid_vecs.append(featurize(smiles_map[ab]))
                acid_w.append(pct)
        glycol_vecs, glycol_w = [], []
        for ab in GLYCOL_ABBRS:
            cols = pct_columns(ab)
            if not cols:
                continue
            pct = sum(float(r.get(c, 0) or 0) for c in cols)
            if pct > 0:
                glycol_vecs.append(featurize(smiles_map[ab]))
                glycol_w.append(pct)
        a_pool = pool(acid_vecs, acid_w, acid_pool)
        g_pool = pool(glycol_vecs, glycol_w, glycol_pool)
        feat = np.concatenate([a_pool, g_pool])
        if include_resin_props:
            def finite_or_median(name):
                value = pd.to_numeric(r.get(name, np.nan), errors="coerce")
                return float(value) if np.isfinite(value) else scalar_medians.get(name, 0.0)
            mw = finite_or_median("mw_polystyrene")
            an = finite_or_median("acid_number")
            ohn = finite_or_median("hydroxyl_number")
            tmp = sum(float(r.get(c, 0) or 0) for c in pct_columns("TMP"))
            extras = np.asarray(
                [mw, an, ohn, tmp], dtype=float)
            feat = np.concatenate([feat, extras])
        rows.append(feat)
        iv_y.append(r.get("iv_dL_g", np.nan))
        tg_y.append(r.get("tg_celsius", np.nan))

    X = np.stack(rows, axis=0)
    iv_y = np.asarray(iv_y, dtype=float)
    tg_y = np.asarray(tg_y, dtype=float)

    state = {"X": X, "iv": iv_y, "tg": tg_y,
             "feature_kind": feature_kind, "n_bits": n_bits,
             "include_resin_props": include_resin_props,
             "acid_pool": acid_pool, "glycol_pool": glycol_pool}
    with open(output_path, "wb") as f:
        pickle.dump(state, f)

    return {
        "output_path": output_path,
        "X_shape": list(X.shape),
        "n_iv": int(np.isfinite(iv_y).sum()),
        "n_tg": int(np.isfinite(tg_y).sum()),
        "n_with_both": int((np.isfinite(iv_y) & np.isfinite(tg_y)).sum()),
        "feature_kind": feature_kind,
        "monomer_feature_dim": int(X.shape[1] - (4 if include_resin_props else 0)),
        "n_resin_props": 4 if include_resin_props else 0,
        "composition_columns_used": {
            ab: pct_columns(ab) for ab in ACID_ABBRS + GLYCOL_ABBRS
        },
        "scalar_imputation": scalar_medians,
    }


# ---------------------------------------------------------------------------
# Modeling
# ---------------------------------------------------------------------------

@mcp.tool()
def train_property_model(features_pkl: str, target: str = "iv",
                          model_type: str = "random_forest",
                          n_splits: int = 5, n_repeats: int = 5,
                          random_state: int = 0,
                          model_params: Optional[dict] = None,
                          standardize: bool = True) -> dict:
    """Train and cross-validate a regressor for IV (dL/g) or Tg (Celsius).

    Args:
        features_pkl: path to feature pickle from assemble_resin_features.
        target: "iv" or "tg".
        model_type: "random_forest" | "xgboost" | "ridge" | "mlp" | "knn".
        n_splits: k-fold splits per repeat (paper uses 5).
        n_repeats: number of independent repeats with different seeds
            (paper averages 50 trials of 5-fold CV).
        random_state: base seed.
        model_params: optional hyperparameter dict.
        standardize: z-score features per training fold.
    Returns:
        dict with mean/std MAE and R^2 across folds, per-fold scores, and
        a model_id pointing to a refit-on-all model on disk.
    """
    from sklearn.model_selection import KFold
    from sklearn.preprocessing import StandardScaler
    from sklearn.metrics import mean_absolute_error, r2_score

    with open(features_pkl, "rb") as f:
        state = pickle.load(f)
    X = state["X"]
    y = state[target]
    mask = np.isfinite(y)
    Xm, ym = X[mask], y[mask]

    def make_model():
        params = model_params or {}
        if model_type == "random_forest":
            from sklearn.ensemble import RandomForestRegressor
            return RandomForestRegressor(**({"n_estimators": 500,
                                              "random_state": random_state,
                                              **params}))
        if model_type == "xgboost":
            import xgboost
            return xgboost.XGBRegressor(**({"n_estimators": 500,
                                            "learning_rate": 0.05,
                                            "max_depth": 6,
                                            "verbosity": 0,
                                            "random_state": random_state,
                                            **params}))
        if model_type == "ridge":
            from sklearn.linear_model import Ridge
            return Ridge(**({"alpha": 1.0, **params}))
        if model_type == "mlp":
            from sklearn.neural_network import MLPRegressor
            return MLPRegressor(**({"hidden_layer_sizes": (256, 128),
                                     "max_iter": 1000,
                                     "random_state": random_state,
                                     **params}))
        if model_type == "knn":
            from sklearn.neighbors import KNeighborsRegressor
            return KNeighborsRegressor(**({"n_neighbors": 5, **params}))
        raise ValueError(f"Unknown model_type {model_type}")

    fold_mae, fold_r2 = [], []
    for rep in range(n_repeats):
        kf = KFold(n_splits=n_splits, shuffle=True,
                   random_state=random_state + rep)
        for tr, te in kf.split(Xm):
            Xtr, Xte = Xm[tr], Xm[te]
            ytr, yte = ym[tr], ym[te]
            if standardize:
                sc = StandardScaler()
                Xtr = sc.fit_transform(Xtr)
                Xte = sc.transform(Xte)
            m = make_model()
            m.fit(Xtr, ytr)
            yp = m.predict(Xte)
            fold_mae.append(float(mean_absolute_error(yte, yp)))
            fold_r2.append(float(r2_score(yte, yp)))

    # refit on full data for downstream predictions / SHAP / parity plot
    if standardize:
        sc_full = StandardScaler().fit(Xm)
        Xm_n = sc_full.transform(Xm)
    else:
        sc_full = None
        Xm_n = Xm
    final = make_model()
    final.fit(Xm_n, ym)

    mid = hashlib.md5((target + model_type +
                        str(random_state) + str(Xm.shape)).encode()).hexdigest()[:8]
    out_pkl = f"/tmp/poly_model_{target}_{mid}.pkl"
    with open(out_pkl, "wb") as f:
        pickle.dump({"model": final, "scaler": sc_full,
                     "X": Xm, "y": ym, "target": target,
                     "model_type": model_type,
                     "feature_kind": state.get("feature_kind"),
                     "n_features": int(Xm.shape[1])}, f)

    return {
        "target": target,
        "model_type": model_type,
        "n_samples": int(mask.sum()),
        "n_features": int(Xm.shape[1]),
        "n_folds_total": len(fold_mae),
        "mae_mean": round(float(np.mean(fold_mae)), 4),
        "mae_std": round(float(np.std(fold_mae)), 4),
        "r2_mean": round(float(np.mean(fold_r2)), 4),
        "r2_std": round(float(np.std(fold_r2)), 4),
        "fold_mae": [round(x, 4) for x in fold_mae],
        "fold_r2": [round(x, 4) for x in fold_r2],
        "model_id": mid,
        "model_path": out_pkl,
    }


@mcp.tool()
def cross_validated_predictions(features_pkl: str, target: str = "tg",
                                model_type: str = "random_forest",
                                n_splits: int = 5, random_state: int = 0,
                                model_params: Optional[dict] = None,
                                standardize: bool = True,
                                output_path: str = "/tmp/poly_cv_predictions.pkl") -> dict:
    """Generate one-fold-out predictions for parity plots and error analysis."""
    from sklearn.model_selection import KFold
    from sklearn.preprocessing import StandardScaler
    from sklearn.metrics import mean_absolute_error, r2_score

    with open(features_pkl, "rb") as f:
        state = pickle.load(f)
    X = state["X"]
    y = state[target]
    mask = np.isfinite(y)
    Xm, ym = X[mask], y[mask]

    def make_model():
        params = model_params or {}
        if model_type == "random_forest":
            from sklearn.ensemble import RandomForestRegressor
            return RandomForestRegressor(**({"n_estimators": 500, "random_state": random_state, **params}))
        if model_type == "ridge":
            from sklearn.linear_model import Ridge
            return Ridge(**({"alpha": 1.0, **params}))
        if model_type == "knn":
            from sklearn.neighbors import KNeighborsRegressor
            return KNeighborsRegressor(**({"n_neighbors": 5, **params}))
        if model_type == "mlp":
            from sklearn.neural_network import MLPRegressor
            return MLPRegressor(**({"hidden_layer_sizes": (256, 128), "max_iter": 1000,
                                    "random_state": random_state, **params}))
        if model_type == "xgboost":
            import xgboost
            return xgboost.XGBRegressor(**({"n_estimators": 500, "learning_rate": 0.05,
                                            "max_depth": 6, "verbosity": 0,
                                            "random_state": random_state, **params}))
        raise ValueError(model_type)

    pred = np.full_like(ym, np.nan, dtype=float)
    kf = KFold(n_splits=n_splits, shuffle=True, random_state=random_state)
    for tr, te in kf.split(Xm):
        Xtr, Xte = Xm[tr], Xm[te]
        ytr = ym[tr]
        if standardize:
            sc = StandardScaler()
            Xtr = sc.fit_transform(Xtr)
            Xte = sc.transform(Xte)
        mdl = make_model()
        mdl.fit(Xtr, ytr)
        pred[te] = mdl.predict(Xte)
    state_out = {"target": target, "true": ym, "pred": pred, "model_type": model_type}
    with open(output_path, "wb") as f:
        pickle.dump(state_out, f)
    return {
        "output_path": output_path,
        "target": target,
        "model_type": model_type,
        "n_samples": int(len(ym)),
        "mae": round(float(mean_absolute_error(ym, pred)), 4),
        "r2": round(float(r2_score(ym, pred)), 4),
    }


@mcp.tool()
def joint_property_model(features_pkl: str,
                          model_type: str = "random_forest",
                          n_splits: int = 5, n_repeats: int = 3,
                          random_state: int = 0,
                          model_params: Optional[dict] = None,
                          standardize: bool = True) -> dict:
    """Multi-output joint regression for IV and Tg simultaneously.

    Uses sklearn's MultiOutputRegressor wrapping the chosen base learner —
    a simple analogue of the PolymerGNN joint model that shares input
    representation across both targets.

    Args:
        features_pkl: features pickle path.
        model_type: 'random_forest' | 'xgboost' | 'ridge' | 'knn'.
        n_splits, n_repeats, random_state, model_params, standardize: as above.
    """
    from sklearn.model_selection import KFold
    from sklearn.preprocessing import StandardScaler
    from sklearn.metrics import mean_absolute_error, r2_score
    from sklearn.multioutput import MultiOutputRegressor

    with open(features_pkl, "rb") as f:
        state = pickle.load(f)
    X = state["X"]
    iv = state["iv"]
    tg = state["tg"]
    mask = np.isfinite(iv) & np.isfinite(tg)
    Xm = X[mask]
    Y = np.stack([iv[mask], tg[mask]], axis=1)

    def make():
        p = model_params or {}
        if model_type == "random_forest":
            from sklearn.ensemble import RandomForestRegressor
            base = RandomForestRegressor(**({"n_estimators": 500,
                                              "random_state": random_state, **p}))
        elif model_type == "xgboost":
            import xgboost
            base = xgboost.XGBRegressor(**({"n_estimators": 500,
                                            "learning_rate": 0.05,
                                            "max_depth": 6, "verbosity": 0,
                                            "random_state": random_state, **p}))
        elif model_type == "ridge":
            from sklearn.linear_model import Ridge
            base = Ridge(**({"alpha": 1.0, **p}))
        elif model_type == "knn":
            from sklearn.neighbors import KNeighborsRegressor
            base = KNeighborsRegressor(**({"n_neighbors": 5, **p}))
        else:
            raise ValueError(model_type)
        return MultiOutputRegressor(base)

    iv_mae, iv_r2, tg_mae, tg_r2 = [], [], [], []
    for rep in range(n_repeats):
        kf = KFold(n_splits=n_splits, shuffle=True,
                   random_state=random_state + rep)
        for tr, te in kf.split(Xm):
            Xtr, Xte = Xm[tr], Xm[te]
            Ytr, Yte = Y[tr], Y[te]
            if standardize:
                sc = StandardScaler()
                Xtr = sc.fit_transform(Xtr); Xte = sc.transform(Xte)
            mdl = make(); mdl.fit(Xtr, Ytr)
            Yp = mdl.predict(Xte)
            iv_mae.append(float(mean_absolute_error(Yte[:, 0], Yp[:, 0])))
            iv_r2.append(float(r2_score(Yte[:, 0], Yp[:, 0])))
            tg_mae.append(float(mean_absolute_error(Yte[:, 1], Yp[:, 1])))
            tg_r2.append(float(r2_score(Yte[:, 1], Yp[:, 1])))
    return {
        "model_type": model_type,
        "n_samples": int(mask.sum()),
        "n_folds_total": len(iv_mae),
        "iv_mae_mean": round(float(np.mean(iv_mae)), 4),
        "iv_r2_mean": round(float(np.mean(iv_r2)), 4),
        "tg_mae_mean": round(float(np.mean(tg_mae)), 4),
        "tg_r2_mean": round(float(np.mean(tg_r2)), 4),
        "iv_r2_std": round(float(np.std(iv_r2)), 4),
        "tg_r2_std": round(float(np.std(tg_r2)), 4),
    }


@mcp.tool()
def predict_and_score(model_id_or_path: str) -> dict:
    """Apply the refit-on-all model to its training set (for parity plots).

    The output is the predicted vs true values; this is what feeds the
    parity-plot tool below. For unbiased generalisation metrics use the
    cross-validated MAE / R^2 returned by train_property_model.

    Args:
        model_id_or_path: model_id from train_property_model OR full pkl path.
    """
    if os.path.exists(model_id_or_path):
        path = model_id_or_path
    else:
        # search /tmp for a matching id
        cands = [p for p in os.listdir("/tmp")
                 if p.endswith(".pkl") and model_id_or_path in p]
        if not cands:
            return {"error": "model not found", "id": model_id_or_path}
        path = "/tmp/" + cands[0]
    with open(path, "rb") as f:
        s = pickle.load(f)
    X = s["X"]; y = s["y"]; sc = s.get("scaler")
    Xn = sc.transform(X) if sc is not None else X
    yp = s["model"].predict(Xn)
    return {
        "target": s.get("target"),
        "model_type": s.get("model_type"),
        "predictions": [round(float(v), 5) for v in yp],
        "true_values": [round(float(v), 5) for v in y],
        "n": int(len(y)),
    }


@mcp.tool()
def feature_importance(model_id_or_path: str, top_k: int = 20) -> dict:
    """Permutation feature importance for any model on its training set.

    Slow but model-agnostic. Returns ranked feature indices and importances.

    Args:
        model_id_or_path: model_id or pkl path.
        top_k: number of top features to return.
    """
    from sklearn.inspection import permutation_importance

    if os.path.exists(model_id_or_path):
        path = model_id_or_path
    else:
        cands = [p for p in os.listdir("/tmp")
                 if p.endswith(".pkl") and model_id_or_path in p]
        if not cands:
            return {"error": "model not found"}
        path = "/tmp/" + cands[0]
    with open(path, "rb") as f:
        s = pickle.load(f)
    X = s["X"]; y = s["y"]; sc = s.get("scaler")
    Xn = sc.transform(X) if sc is not None else X
    res = permutation_importance(s["model"], Xn, y, n_repeats=5,
                                  random_state=0, n_jobs=-1)
    order = np.argsort(res.importances_mean)[::-1][:top_k]
    items = [{"rank": i + 1,
              "feature_index": int(j),
              "importance_mean": round(float(res.importances_mean[j]), 6),
              "importance_std": round(float(res.importances_std[j]), 6)}
             for i, j in enumerate(order)]
    # tag the trailing 4 features (resin scalars) so the agent can interpret
    n = X.shape[1]
    label = {n - 4: "Mw", n - 3: "AN", n - 2: "OHN", n - 1: "%TMP"}
    for it in items:
        if it["feature_index"] in label:
            it["label"] = label[it["feature_index"]]
    return {"top_features": items, "n_total_features": int(X.shape[1])}


# ---------------------------------------------------------------------------
# Plotting
# ---------------------------------------------------------------------------

@mcp.tool()
def plot_parity(predictions: list, true_values: list,
                 target_name: str = "target",
                 r2: Optional[float] = None,
                 output_path: str = "artifacts/Fig2_Tg_parity.png") -> dict:
    """Parity plot (predicted vs true) with y=x reference and optional R^2 label.

    Args:
        predictions: list of model predictions.
        true_values: list of ground-truth values.
        target_name: axis title (e.g., 'IV (dL/g)' or 'Tg (Celsius)').
        r2: cross-validated R^2 to annotate.
        output_path: image path.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    p = np.asarray(predictions, dtype=float)
    t = np.asarray(true_values, dtype=float)
    fig, ax = plt.subplots(figsize=(6.5, 6.5))
    ax.scatter(t, p, alpha=0.6, s=18, color="#1f77b4", edgecolor="white")
    lims = [min(t.min(), p.min()), max(t.max(), p.max())]
    pad = (lims[1] - lims[0]) * 0.05
    lims = [lims[0] - pad, lims[1] + pad]
    ax.plot(lims, lims, "k--", lw=1, alpha=0.6)
    ax.set_xlim(lims); ax.set_ylim(lims)
    ax.set_xlabel(f"True {target_name}")
    ax.set_ylabel(f"Predicted {target_name}")
    if r2 is not None:
        ax.text(0.97, 0.05, f"R$^2$ = {r2:.4f}", transform=ax.transAxes,
                ha="right", va="bottom",
                bbox=dict(boxstyle="round", fc="w", alpha=0.85))
    ax.set_title(f"Parity plot — {target_name}")
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"output_path": output_path, "n_points": int(len(t))}


@mcp.tool()
def plot_dual_parity(tg_predictions: list, tg_true: list,
                     iv_predictions: list, iv_true: list,
                     output_path: str = "artifacts/Fig2_Tg_IV_parity.png") -> dict:
    """Two-panel parity plot for Tg and IV fold-out predictions."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    pairs = [("Tg (C)", np.asarray(tg_true, dtype=float), np.asarray(tg_predictions, dtype=float)),
             ("IV (dL/g)", np.asarray(iv_true, dtype=float), np.asarray(iv_predictions, dtype=float))]
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.8))
    for ax, (label, t, p) in zip(axes, pairs):
        ax.scatter(t, p, alpha=0.65, s=18, color="#1f77b4", edgecolor="white")
        lo, hi = min(t.min(), p.min()), max(t.max(), p.max())
        pad = (hi - lo) * 0.05
        ax.plot([lo-pad, hi+pad], [lo-pad, hi+pad], "k--", lw=1, alpha=0.6)
        ax.set_xlabel(f"True {label}")
        ax.set_ylabel(f"Predicted {label}")
        ax.set_title(label)
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"output_path": output_path, "n_tg": int(len(pairs[0][1])), "n_iv": int(len(pairs[1][1]))}


@mcp.tool()
def plot_property_distribution(resin_csv: str,
                                output_path: str = "artifacts/Fig1_dataset_distribution.png"
                                ) -> dict:
    """Joint and marginal distribution of IV and Tg, mirroring paper Fig. 1e-g.

    Args:
        resin_csv: path to polyester_resins.csv.
        output_path: image file.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import pandas as pd

    df = pd.read_csv(resin_csv)
    sub = df.dropna(subset=["iv_dL_g", "tg_celsius"])
    fig, ax = plt.subplots(1, 3, figsize=(13, 4.2))
    ax[0].hist(df["iv_dL_g"].dropna(), bins=30, color="#1f77b4",
               edgecolor="white")
    ax[0].set_xlabel("IV (dL/g)"); ax[0].set_ylabel("count")
    ax[0].set_title("IV distribution")
    ax[1].hist(df["tg_celsius"].dropna(), bins=30, color="#d62728",
               edgecolor="white")
    ax[1].set_xlabel("Tg (°C)"); ax[1].set_ylabel("count")
    ax[1].set_title("Tg distribution")
    ax[2].scatter(sub["iv_dL_g"], sub["tg_celsius"], alpha=0.6, s=15)
    ax[2].set_xlabel("IV (dL/g)"); ax[2].set_ylabel("Tg (°C)")
    ax[2].set_title(f"IV vs Tg (n={len(sub)})")
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"output_path": output_path, "n_iv": int(df["iv_dL_g"].notna().sum()),
            "n_tg": int(df["tg_celsius"].notna().sum()),
            "n_both": len(sub)}


@mcp.tool()
def plot_model_comparison(scores: list,
                            metric: str = "r2",
                            target_name: str = "Tg",
                            output_path: str = "artifacts/Fig4_model_comparison_Tg.png"
                            ) -> dict:
    """Bar chart of cross-validated metric across model variants.

    Args:
        scores: list of {"name": str, "value": float, "err": float}.
        metric: 'r2' or 'mae' (label only).
        target_name: axis label.
        output_path: image file.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    names = [s["name"] for s in scores]
    vals = [float(s["value"]) for s in scores]
    errs = [float(s.get("err", 0.0)) for s in scores]

    fig, ax = plt.subplots(figsize=(max(6, 0.7 * len(names) + 2), 4.5))
    xs = np.arange(len(names))
    ax.bar(xs, vals, yerr=errs, capsize=4, color="#1f77b4",
           edgecolor="black", linewidth=0.4)
    ax.set_xticks(xs); ax.set_xticklabels(names, rotation=30, ha="right")
    label = {"r2": r"R$^2$", "mae": "MAE"}.get(metric, metric)
    ax.set_ylabel(f"{target_name} {label}")
    ax.set_title(f"Model comparison on {target_name} — {label}")
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"output_path": output_path, "n_models": len(names)}


@mcp.tool()
def plot_feature_importance(features: list,
                              output_path: str = "artifacts/Fig3_input_contribution.png",
                              title: str = "Feature importance") -> dict:
    """Horizontal bar chart of feature importances.

    Args:
        features: list of {"label": str, "value": float}.
        output_path: image file.
        title: chart title.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    labels = [f["label"] for f in features]
    vals = [float(f["value"]) for f in features]
    order = np.argsort(vals)
    labels = [labels[i] for i in order]
    vals = [vals[i] for i in order]
    fig, ax = plt.subplots(figsize=(7, max(3, 0.35 * len(labels) + 1)))
    ax.barh(labels, vals, color="#2ca02c", edgecolor="black", linewidth=0.4)
    ax.set_xlabel("importance")
    ax.set_title(title)
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"output_path": output_path, "n_features": len(labels)}


@mcp.tool()
def package_smoke_test(resin_csv: str = "input_data/data/polyester_resins.csv",
                       monomer_csv: str = "input_data/data/monomer_smiles.csv") -> dict:
    """Lightweight package self-test for schema and monomer-column alignment."""
    resin = load_resin_table(resin_csv)
    monomers = load_monomer_smiles(monomer_csv)
    trans_cols = [c for c in resin["monomer_columns"] if "1_4_CHDA" in c]
    return {
        "n_resins": resin["n_resins"],
        "n_with_iv": resin["n_with_iv"],
        "n_with_tg": resin["n_with_tg"],
        "n_monomer_smiles": monomers["n_monomers"],
        "n_pct_columns": len(resin["monomer_columns"]),
        "chda_composition_columns": trans_cols,
        "plot_functions": ["plot_property_distribution", "cross_validated_predictions", "plot_dual_parity", "plot_feature_importance"],
    }


if __name__ == "__main__":
    mcp.run(transport="stdio")

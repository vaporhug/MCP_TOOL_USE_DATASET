# mat_pg20 — Tool Reference

Tools for polyester multi-property prediction. The agent composes these
primitives to build a structure-aware regression pipeline over monomer
SMILES + resin scalar properties.

## Database Retrieval (`database_retrieval.py`)

- **websearch**: Generic web search — locate dataset DOIs or supplementary URLs.
- **fetch_url**: HTTP GET with redirects (CSV/PDF/JSON downloads).
- **query_pubchem**: PubChem PUG-REST lookup for SMILES / CID.
- **query_chembl**: ChEMBL bioactivity query.
- **query_uniprot**: UniProt entry fetch.
- **query_pdb**: RCSB PDB entry metadata.
- **query_geo**: NCBI GEO series/sample fetch.
- **query_ncbi_entrez**: Generic Entrez E-search + E-fetch.
- **query_usgs_comcat**: USGS earthquake catalog query.
- **query_world_bank**: World Bank WDI indicator series.
- **query_openalex**: OpenAlex works/authors/venues search.
- **query_doi**: Resolve a DOI to Crossref + Unpaywall metadata.

## Data Processing (`data_processing.py`)

- **read_csv** / **write_csv**: List-of-dicts CSV IO.
- **read_json** / **write_json**: JSON IO.
- **read_excel** / **read_parquet** / **read_netcdf** / **read_shapefile**: Heavy format readers (stubs).
- **read_fasta**: FASTA sequence reader.
- **pivot_long_to_wide** / **pivot_wide_to_long**: Reshape between long/wide.
- **drop_missing**: Drop rows with missing values.
- **coerce_numeric**: Cast columns to float.
- **join_tables**: SQL-style join on a single key.
- **groupby_aggregate**: Group rows and apply aggregations.

## Domain primitives (`polymer_gnn_tools.py`)

Loading
- **load_resin_table**: Inspect the polyester CSV — shape, target counts, monomer columns.
- **load_monomer_smiles**: Load the abbreviation -> SMILES dictionary.

Molecular structure
- **parse_smiles**: RDKit parse + atom/bond/ring/MW report.
- **compute_morgan_fingerprint**: ECFP-style circular fingerprint (radius / n_bits).
- **compute_rdkit_descriptors**: 10 hand-crafted descriptors per molecule (MW, TPSA, rings, FractionCSP3, MolLogP, ...).

Set pooling and resin assembly (PolymerGNN-style central embedding)
- **aggregate_monomer_features**: Pool a variable-size set of monomer feature vectors via max / mean / sum / weighted_mean.
- **assemble_resin_features**: End-to-end builder that pools the acid set, pools the glycol set, optionally appends [Mw, AN, OHN, %TMP], and pickles the (X, IV, Tg) feature matrix.

Modeling
- **train_property_model**: k-fold cross-validation for IV or Tg with RF / XGBoost / Ridge / MLP / KNN; returns mean / std MAE and R-squared and refits on all data.
- **joint_property_model**: MultiOutputRegressor analogue of the joint Tg+IV model.
- **predict_and_score**: Reload a refit model and return predicted vs true values.
- **feature_importance**: Permutation importance, with labels for the trailing resin-property columns.

Plotting
- **plot_parity**: Predicted vs true scatter with y=x reference and optional R-squared annotation.
- **plot_property_distribution**: IV/Tg marginal histograms + joint scatter.
- **plot_model_comparison**: Bar chart of cross-validated R-squared / MAE across models.
- **plot_feature_importance**: Horizontal bar chart of permutation importances.

## Dependencies

`numpy`, `pandas`, `scikit-learn`, `rdkit`, `xgboost`, `matplotlib`, `mcp[cli]`.

## Example pipeline

```python
import polymer_gnn_tools as T
state = T.assemble_resin_features(
    'input_data/data/polyester_resins.csv',
    'input_data/data/monomer_smiles.csv',
    feature_kind='morgan', n_bits=512,
    acid_pool='max', glycol_pool='max',
    include_resin_props=True)

r_iv = T.train_property_model(state['output_path'], target='iv',
                              model_type='random_forest', n_repeats=5)
r_tg = T.train_property_model(state['output_path'], target='tg',
                              model_type='random_forest', n_repeats=5)
preds = T.predict_and_score(r_tg['model_path'])
T.plot_parity(preds['predictions'], preds['true_values'],
              target_name='Tg (Celsius)', r2=r_tg['r2_mean'],
              output_path='artifacts/Tg_parity.png')
```

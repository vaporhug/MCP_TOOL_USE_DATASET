# mat_ci24 — Tool Reference

FastMCP server `corrosion_ml_tools.py` (single file, exposes 21 tools).

## Dependencies
```
numpy<2          rdkit
pandas           openpyxl
scikit-learn     xgboost
matplotlib       mcp
```

## Tools (`corrosion_ml_tools.py`)

### Data loading
- `load_csv_summary(csv_path)` — shape, columns, dtypes, per-numeric-column stats.
- `load_xlsx_sheet(xlsx_path, sheet_name=None, header_row=1)` — peek first 5 rows of an XLSX sheet.

### Electrochemistry
- `compute_inhibition_efficiency(rp_inhibited, rp_blank)` — IE (%) = (1 - R_p^blank/R_p^inh)·100.
- `compute_inhibition_power(rp_inhibited, rp_blank)` — IP (dB) = 10·log₁₀(R_p^inh/R_p^blank).
- `trapezoid_time_average(times, values)` — `<V> = (1/(t_f-t_0)) · ∫ V(t) dt`.

### Cheminformatics
- `compute_smiles_descriptors(smiles_list, names=None)` — RDKit 2D descriptors
  (MolWt, MolLogP, TPSA, MaxEStateIndex, BCUT2D_*, SMR_VSA10, …) plus
  heteroatom counts n_N / n_O / n_S.
- `smiles_validity(smiles_list)` — RDKit parse validity flags.

### Feature selection
- `variance_filter(csv_path, feature_columns, threshold=0.1)` — drop low-variance features.
- `correlation_filter(csv_path, feature_columns, threshold=0.8)` — drop one of any |r|≥threshold pair.
- `recursive_feature_elimination(csv_path, feature_columns, target_column, n_features=5, estimator='random_forest')` — sklearn RFE wrapper.

### Modeling
- `train_regressor(csv_path, feature_columns, target_column, model_type='random_forest'|'xgboost', test_size=0.15, …)` — single train/test fit; returns `model_id` for later prediction.
- `kfold_cross_validate(csv_path, feature_columns, target_column, n_splits=6, scale_target=True, …)` — k-fold CV with optional MinMax target scaling (so RMSE values match the paper convention).
- `compare_feature_sets(csv_path, feature_sets={name: [feats]}, target_column, n_splits=6, …)` — runs CV for several candidate feature sets.
- `feature_importance_from_model(model_id)` — tree-based importances ranking.
- `predict_with_model(model_id, feature_rows=[{f:v}, …])` — apply trained model to new rows.

### Group analysis
- `group_summary(csv_path, group_column, value_column)` — mean/std/min/max + frac with value < 0 (accelerator fraction) per group.

### Plotting (returns `{output_path: ..., ...}`; PNGs land in `artifacts/`)
- `plot_inhibitor_ranking_box(csv_path, value_column, std_column, group_column, output_path, top_n=70)` — horizontal bar/error plot ranking inhibitors and colouring by heteroatom group.
- `plot_group_summary_bar(csv_path, group_column, value_column, output_path)` — bar of mean ± std per group with accelerator-fraction annotation.
- `plot_predicted_vs_measured(csv_path, feature_columns, target_column, output_path, n_splits=6)` — out-of-fold predicted-vs-measured scatter from k-fold CV.
- `plot_metric_vs_feature_set(results=compare_feature_sets_output, metric, output_path)` — comparison bar of feature sets.
- `plot_efficiency_vs_power(csv_path, ie_column, ip_column, output_path)` — scatter comparing inhibition efficiency and inhibition power across inhibitors.

## Running
```bash
python3 tools/corrosion_ml_tools.py    # FastMCP stdio server
```

## Notes
- All tool paths are relative to the task root (e.g. `input_data/data/inhibitor_dataset.csv`).
- ML tool paths default to `artifacts/...` for plots — make sure that directory exists or pass an explicit path.
- The 6-fold CV with `scale_target=True` (default) reproduces the paper's RMSE convention; with raw IP (dB) values the RMSE prints in the same units as the target.

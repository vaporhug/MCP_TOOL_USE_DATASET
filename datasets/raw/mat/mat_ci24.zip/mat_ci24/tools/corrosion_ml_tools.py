#!/usr/bin/env python3
"""Corrosion-inhibitor ML tools for mat_ci24.

Low-level primitives for: SMILES parsing/descriptor generation, EIS-derived
performance metrics (inhibition efficiency, inhibition power), tabular ML
training/evaluation (RandomForest / XGBoost) with k-fold cross-validation, and
plotting. All file paths are taken as strings; outputs that are arrays come
back as JSON-serialisable lists.
"""

import os
import json
import pickle
import hashlib
from typing import Optional

import numpy as np
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Corrosion_Inhibitor_ML_Tools")

# ----------------------------------------------------------------------
# Data loading utilities
# ----------------------------------------------------------------------

@mcp.tool()
def load_csv_summary(csv_path: str) -> dict:
    """Load a CSV file and return shape, columns, dtypes and summary stats
    for numeric columns.

    Args:
        csv_path: path to the CSV file
    Returns:
        dict with shape, columns, dtypes (per col), and numeric_stats
        (per col: mean/std/min/max/median/n_non_null)
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    stats = {}
    dtypes = {}
    for col in df.columns:
        dtypes[col] = str(df[col].dtype)
        if df[col].dtype.kind in "fiu":
            s = df[col].dropna()
            if len(s):
                stats[col] = {
                    "mean": round(float(s.mean()), 4),
                    "std": round(float(s.std()), 4),
                    "min": round(float(s.min()), 4),
                    "max": round(float(s.max()), 4),
                    "median": round(float(s.median()), 4),
                    "n_non_null": int(s.shape[0]),
                }
    return {
        "shape": list(df.shape),
        "columns": list(df.columns),
        "dtypes": dtypes,
        "numeric_stats": stats,
    }


@mcp.tool()
def load_xlsx_sheet(xlsx_path: str, sheet_name: str = None,
                    header_row: int = 1) -> dict:
    """Load a sheet from an XLSX workbook and return rows as records.

    Args:
        xlsx_path: path to xlsx file
        sheet_name: optional sheet name (defaults to first sheet)
        header_row: 0-indexed header row (default 1, second row)
    Returns:
        dict with sheet_names, used_sheet, columns, n_rows, sample (first 5 rows)
    """
    import pandas as pd
    xl = pd.ExcelFile(xlsx_path)
    used = sheet_name if sheet_name in xl.sheet_names else xl.sheet_names[0]
    df = pd.read_excel(xlsx_path, sheet_name=used, header=header_row)
    sample = df.head(5).where(df.head(5).notna(), None).to_dict(orient="records")
    return {
        "sheet_names": list(xl.sheet_names),
        "used_sheet": used,
        "columns": list(df.columns),
        "n_rows": int(df.shape[0]),
        "sample": sample,
    }


# ----------------------------------------------------------------------
# Electrochemical metrics
# ----------------------------------------------------------------------

@mcp.tool()
def compute_inhibition_efficiency(rp_inhibited: list, rp_blank: float) -> dict:
    """Compute inhibition efficiency (IE, %) from polarisation resistance
    values: IE = (1 - R_p^blank / R_p^inh) * 100. Returns negative values when
    the inhibitor accelerates corrosion (R_p^inh < R_p^blank).

    Args:
        rp_inhibited: list of R_p values (Ohm or kOhm-cm2) for inhibited samples
        rp_blank: R_p value of the uninhibited reference (same units)
    Returns:
        dict with values (list), n, mean, std
    """
    arr = np.asarray(rp_inhibited, dtype=float)
    ie = (1.0 - rp_blank / arr) * 100.0
    return {
        "values": [round(float(v), 4) for v in ie],
        "n": int(len(arr)),
        "mean": round(float(np.mean(ie)), 4),
        "std": round(float(np.std(ie, ddof=1)) if len(arr) > 1 else 0.0, 4),
    }


@mcp.tool()
def compute_inhibition_power(rp_inhibited: list, rp_blank: float) -> dict:
    """Compute inhibition power (IP, dB) from polarisation resistance:
    IP = 10 * log10(R_p^inh / R_p^blank). IP > 0 means protection,
    IP < 0 means acceleration.

    Args:
        rp_inhibited: list of R_p values for inhibited samples (Ohm or kOhm-cm2)
        rp_blank: R_p value for uninhibited reference (same units)
    Returns:
        dict with values (list), n, mean, std
    """
    arr = np.asarray(rp_inhibited, dtype=float)
    arr = np.where(arr <= 0, np.nan, arr)
    ip = 10.0 * np.log10(arr / rp_blank)
    valid = ip[np.isfinite(ip)]
    return {
        "values": [None if not np.isfinite(v) else round(float(v), 4) for v in ip],
        "n": int(np.isfinite(ip).sum()),
        "mean": round(float(np.mean(valid)), 4) if valid.size else None,
        "std": round(float(np.std(valid, ddof=1)) if valid.size > 1 else 0.0, 4),
    }


@mcp.tool()
def trapezoid_time_average(times: list, values: list) -> dict:
    """Compute trapezoidal time-average of a time series:
    <V> = (1 / (t_f - t_0)) * integral_{t_0}^{t_f} V(t) dt.

    Args:
        times: list of time points (must be sorted ascending, same length as values)
        values: list of values at each time
    Returns:
        dict with average, n_points, t_start, t_end
    """
    t = np.asarray(times, dtype=float)
    v = np.asarray(values, dtype=float)
    if t.shape != v.shape or t.size < 2:
        return {"error": "need >=2 matched points"}
    order = np.argsort(t)
    t, v = t[order], v[order]
    integral = np.trapz(v, t)
    avg = integral / (t[-1] - t[0])
    return {
        "average": round(float(avg), 6),
        "n_points": int(len(t)),
        "t_start": float(t[0]),
        "t_end": float(t[-1]),
    }


# ----------------------------------------------------------------------
# Cheminformatics: SMILES → descriptors
# ----------------------------------------------------------------------

_DESCRIPTOR_NAMES = [
    "MolWt", "MolLogP", "TPSA",
    "NumHAcceptors", "NumHDonors",
    "NumAromaticRings", "NumRotatableBonds", "NumHeteroatoms",
    "HeavyAtomCount",
    "MaxEStateIndex", "MinEStateIndex",
    "MaxAbsEStateIndex", "MinAbsEStateIndex",
    "SMR_VSA10", "VSA_EState2", "VSA_EState4",
    "EState_VSA4", "EState_VSA5", "SlogP_VSA4",
    "BalabanJ", "BertzCT",
    "BCUT2D_MWHI", "BCUT2D_MRLOW",
]


@mcp.tool()
def compute_smiles_descriptors(smiles_list: list,
                               names: Optional[list] = None) -> dict:
    """Compute RDKit 2D molecular descriptors for a list of SMILES strings.

    Available descriptors include physicochemical (MolWt, MolLogP, TPSA),
    topological (BalabanJ, BertzCT), VSA-based (SMR_VSA10, VSA_EState2,
    EState_VSA5, SlogP_VSA4), EState-based (MaxEStateIndex, MinAbsEStateIndex),
    BCUT (BCUT2D_MWHI, BCUT2D_MRLOW), heteroatom counts, and ring counts.
    Heteroatom counts (n_N, n_O, n_S) are also returned.

    Args:
        smiles_list: list of SMILES strings (None entries return NaNs)
        names: optional descriptor names to compute (default: a curated set
            covering MolWt, MolLogP, TPSA, EState/VSA descriptors,
            BCUT2D and heteroatom counts)
    Returns:
        dict with feature_names (list) and rows (list of per-molecule dicts)
    """
    from rdkit import Chem
    from rdkit.Chem import Descriptors

    feats = list(names) if names else list(_DESCRIPTOR_NAMES)
    rows = []
    for s in smiles_list:
        if s is None or (isinstance(s, float) and np.isnan(s)):
            rows.append({f: None for f in feats})
            continue
        m = Chem.MolFromSmiles(str(s))
        if m is None:
            rows.append({f: None for f in feats})
            continue
        d = {}
        for f in feats:
            try:
                v = getattr(Descriptors, f)(m)
                d[f] = float(v) if np.isfinite(v) else None
            except Exception:
                d[f] = None
        # heteroatom counts
        d["n_N"] = sum(a.GetSymbol() == "N" for a in m.GetAtoms())
        d["n_O"] = sum(a.GetSymbol() == "O" for a in m.GetAtoms())
        d["n_S"] = sum(a.GetSymbol() == "S" for a in m.GetAtoms())
        rows.append(d)
    return {"feature_names": feats + ["n_N", "n_O", "n_S"], "rows": rows}


@mcp.tool()
def smiles_validity(smiles_list: list) -> dict:
    """Return per-SMILES validity flags using RDKit parsing."""
    from rdkit import Chem
    out = []
    for s in smiles_list:
        if s is None:
            out.append({"smiles": None, "valid": False})
            continue
        m = Chem.MolFromSmiles(str(s))
        out.append({"smiles": str(s), "valid": m is not None})
    return {"n": len(out), "results": out}


# ----------------------------------------------------------------------
# Feature selection and dataset utilities
# ----------------------------------------------------------------------

@mcp.tool()
def variance_filter(csv_path: str, feature_columns: list,
                    threshold: float = 0.1) -> dict:
    """Remove features whose variance (after MinMax scaling) is below threshold.

    Args:
        csv_path: dataset CSV
        feature_columns: which columns to consider features
        threshold: variance cutoff (default 0.1 — same as paper Methods)
    Returns:
        dict with kept_features (list), dropped_features (list), variances (dict)
    """
    import pandas as pd
    from sklearn.preprocessing import MinMaxScaler

    df = pd.read_csv(csv_path)
    X = df[feature_columns].apply(pd.to_numeric, errors="coerce").dropna()
    Xs = MinMaxScaler().fit_transform(X.values)
    var = Xs.var(axis=0)
    keep = [c for c, v in zip(X.columns, var) if v >= threshold]
    drop = [c for c, v in zip(X.columns, var) if v < threshold]
    return {
        "kept_features": keep,
        "dropped_features": drop,
        "variances": {c: round(float(v), 6) for c, v in zip(X.columns, var)},
    }


@mcp.tool()
def correlation_filter(csv_path: str, feature_columns: list,
                       threshold: float = 0.8) -> dict:
    """Drop features that are highly Pearson-correlated (|r|>threshold) to
    another feature in the list. Greedy: keeps the first occurrence.

    Args:
        csv_path: dataset CSV
        feature_columns: columns to consider features
        threshold: correlation cutoff (default 0.8 — same as paper Methods)
    Returns:
        dict with kept_features, dropped_features, correlation_pairs
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    X = df[feature_columns].apply(pd.to_numeric, errors="coerce").dropna()
    corr = X.corr().abs()
    cols = list(X.columns)
    drop = set()
    pairs = []
    for i in range(len(cols)):
        for j in range(i + 1, len(cols)):
            if cols[i] in drop or cols[j] in drop:
                continue
            c = corr.iloc[i, j]
            if c >= threshold:
                drop.add(cols[j])
                pairs.append({"a": cols[i], "b": cols[j], "r_abs": round(float(c), 4)})
    keep = [c for c in cols if c not in drop]
    return {
        "kept_features": keep,
        "dropped_features": list(drop),
        "correlation_pairs": pairs,
    }


@mcp.tool()
def recursive_feature_elimination(csv_path: str,
                                  feature_columns: list,
                                  target_column: str,
                                  n_features: int = 5,
                                  estimator: str = "random_forest",
                                  random_state: int = 0) -> dict:
    """Sklearn RFE wrapper. Selects n_features features that best predict the
    target with the chosen estimator.

    Args:
        csv_path: dataset CSV
        feature_columns: candidate feature names
        target_column: target column name
        n_features: how many features to retain (default 5)
        estimator: 'random_forest' (default) or 'xgboost'
        random_state: seed
    Returns:
        dict with selected_features (ranked), ranking (per feature)
    """
    import pandas as pd
    from sklearn.feature_selection import RFE
    from sklearn.ensemble import RandomForestRegressor

    df = pd.read_csv(csv_path).dropna(subset=feature_columns + [target_column])
    X = df[feature_columns].values
    y = df[target_column].values
    if estimator == "xgboost":
        import xgboost as xgb
        est = xgb.XGBRegressor(n_estimators=200, verbosity=0,
                                random_state=random_state)
    else:
        est = RandomForestRegressor(n_estimators=200, random_state=random_state)
    rfe = RFE(est, n_features_to_select=n_features, step=1)
    rfe.fit(X, y)
    return {
        "selected_features": [feature_columns[i] for i, s in enumerate(rfe.support_) if s],
        "ranking": {feature_columns[i]: int(rfe.ranking_[i]) for i in range(len(feature_columns))},
        "estimator": estimator,
        "n_features": int(n_features),
    }


# ----------------------------------------------------------------------
# ML training and evaluation
# ----------------------------------------------------------------------

_MODEL_CACHE = {}


def _save_model(state):
    blob = pickle.dumps(state)
    mid = hashlib.md5(blob[:2000]).hexdigest()[:10]
    with open(f"/tmp/corrml_{mid}.pkl", "wb") as f:
        f.write(blob)
    _MODEL_CACHE[mid] = True
    return mid


def _load_model(mid):
    with open(f"/tmp/corrml_{mid}.pkl", "rb") as f:
        return pickle.load(f)


@mcp.tool()
def train_regressor(csv_path: str,
                    feature_columns: list,
                    target_column: str,
                    model_type: str = "random_forest",
                    test_size: float = 0.15,
                    random_state: int = 0,
                    model_params: dict = None) -> dict:
    """Train a regressor on (feature_columns, target_column). MinMax scales
    features. Saves the model to /tmp; returns model_id and held-out test
    metrics.

    Args:
        csv_path: dataset CSV
        feature_columns: list of feature names
        target_column: target column name
        model_type: 'random_forest' or 'xgboost'
        test_size: held-out fraction
        random_state: seed
        model_params: optional dict of model hyperparameters
    Returns:
        dict with model_id, train_size, test_size, train_metrics,
            test_metrics (R2, RMSE, MAE)
    """
    import pandas as pd
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import MinMaxScaler
    from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
    from sklearn.ensemble import RandomForestRegressor

    df = pd.read_csv(csv_path).dropna(subset=feature_columns + [target_column]).copy()
    X = df[feature_columns].values
    y = df[target_column].values

    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=test_size,
                                           random_state=random_state)
    scaler = MinMaxScaler().fit(Xtr)
    Xtr_s, Xte_s = scaler.transform(Xtr), scaler.transform(Xte)

    params = model_params or {}
    if model_type == "xgboost":
        import xgboost as xgb
        xgb_params = {"n_estimators": 300, "verbosity": 0,
                      "random_state": random_state}
        xgb_params.update(params)
        m = xgb.XGBRegressor(**xgb_params)
    else:
        rf_params = {"n_estimators": 200, "random_state": random_state}
        rf_params.update(params)
        m = RandomForestRegressor(**rf_params)
    m.fit(Xtr_s, ytr)

    pred_tr = m.predict(Xtr_s)
    pred_te = m.predict(Xte_s)

    state = {"model": m, "scaler": scaler, "features": feature_columns,
             "target": target_column,
             "Xtr": Xtr_s, "ytr": ytr, "Xte": Xte_s, "yte": yte,
             "model_type": model_type}
    mid = _save_model(state)

    return {
        "model_id": mid,
        "model_type": model_type,
        "train_size": int(len(ytr)),
        "test_size": int(len(yte)),
        "train_metrics": {
            "r2": round(float(r2_score(ytr, pred_tr)), 4),
            "rmse": round(float(np.sqrt(mean_squared_error(ytr, pred_tr))), 4),
            "mae": round(float(mean_absolute_error(ytr, pred_tr)), 4),
        },
        "test_metrics": {
            "r2": round(float(r2_score(yte, pred_te)), 4),
            "rmse": round(float(np.sqrt(mean_squared_error(yte, pred_te))), 4),
            "mae": round(float(mean_absolute_error(yte, pred_te)), 4),
        },
        "feature_columns": feature_columns,
    }


@mcp.tool()
def kfold_cross_validate(csv_path: str,
                         feature_columns: list,
                         target_column: str,
                         model_type: str = "random_forest",
                         n_splits: int = 6,
                         random_state: int = 0,
                         scale_target: bool = True,
                         model_params: dict = None) -> dict:
    """K-fold cross-validation. By default uses 6 folds (matching the paper).

    Args:
        csv_path: dataset CSV
        feature_columns: feature names
        target_column: target column name
        model_type: 'random_forest' (default) or 'xgboost'
        n_splits: number of folds (default 6)
        random_state: seed for the fold splitter
        scale_target: when True, MinMax-scales y to [0,1] before training/RMSE
            (matches the paper's RMSE values which use scaled targets).
        model_params: optional model hyperparameters
    Returns:
        dict with per-fold r2/rmse/mae, mean and std of each metric
    """
    import pandas as pd
    from sklearn.model_selection import KFold
    from sklearn.preprocessing import MinMaxScaler
    from sklearn.ensemble import RandomForestRegressor
    from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error

    df = pd.read_csv(csv_path).dropna(subset=feature_columns + [target_column]).copy()
    X = df[feature_columns].values
    y = df[target_column].values
    if scale_target:
        y_scaler = MinMaxScaler().fit(y.reshape(-1, 1))
        y = y_scaler.transform(y.reshape(-1, 1)).ravel()

    kf = KFold(n_splits=n_splits, shuffle=True, random_state=random_state)
    fold_results = []
    for k, (tr, te) in enumerate(kf.split(X)):
        Xs = MinMaxScaler().fit(X[tr])
        Xtr_s, Xte_s = Xs.transform(X[tr]), Xs.transform(X[te])
        params = model_params or {}
        if model_type == "xgboost":
            import xgboost as xgb
            m = xgb.XGBRegressor(n_estimators=300, verbosity=0,
                                  random_state=random_state, **params)
        else:
            m = RandomForestRegressor(n_estimators=200, random_state=random_state, **params)
        m.fit(Xtr_s, y[tr])
        pred = m.predict(Xte_s)
        fold_results.append({
            "fold": k,
            "n_test": int(len(te)),
            "r2": float(r2_score(y[te], pred)),
            "rmse": float(np.sqrt(mean_squared_error(y[te], pred))),
            "mae": float(mean_absolute_error(y[te], pred)),
        })
    r2s = np.array([f["r2"] for f in fold_results])
    rmses = np.array([f["rmse"] for f in fold_results])
    return {
        "n_splits": int(n_splits),
        "model_type": model_type,
        "scale_target": bool(scale_target),
        "feature_columns": feature_columns,
        "target_column": target_column,
        "fold_results": [
            {k: (round(v, 4) if isinstance(v, float) else v) for k, v in f.items()}
            for f in fold_results
        ],
        "r2_mean": round(float(r2s.mean()), 4),
        "r2_std": round(float(r2s.std(ddof=1)), 4) if len(r2s) > 1 else 0.0,
        "rmse_mean": round(float(rmses.mean()), 4),
        "rmse_std": round(float(rmses.std(ddof=1)), 4) if len(rmses) > 1 else 0.0,
    }


@mcp.tool()
def compare_feature_sets(csv_path: str,
                          feature_sets: dict,
                          target_column: str,
                          n_splits: int = 6,
                          random_state: int = 0,
                          scale_target: bool = True) -> dict:
    """Run k-fold CV with several candidate feature sets and report mean R²
    and RMSE for each.

    Args:
        csv_path: dataset CSV
        feature_sets: {name: [feature_col, ...]}
        target_column: target column name
        n_splits: folds (default 6)
        random_state: seed
        scale_target: MinMax-scale y before training (recommended)
    Returns:
        dict with per-set r2_mean/std, rmse_mean/std
    """
    out = {}
    for name, feats in feature_sets.items():
        try:
            r = kfold_cross_validate(csv_path, feats, target_column,
                                       model_type="random_forest",
                                       n_splits=n_splits,
                                       random_state=random_state,
                                       scale_target=scale_target)
            out[name] = {
                "n_features": len(feats),
                "features": feats,
                "r2_mean": r["r2_mean"], "r2_std": r["r2_std"],
                "rmse_mean": r["rmse_mean"], "rmse_std": r["rmse_std"],
            }
        except Exception as e:
            out[name] = {"error": str(e), "features": feats}
    return out


@mcp.tool()
def feature_importance_from_model(model_id: str) -> dict:
    """Return tree-based feature importances for a trained model."""
    state = _load_model(model_id)
    m = state["model"]
    feats = state["features"]
    imp = getattr(m, "feature_importances_", None)
    if imp is None:
        return {"error": "model has no feature_importances_"}
    pairs = sorted(zip(feats, imp), key=lambda x: -x[1])
    return {
        "ranking": [{"feature": f, "importance": round(float(v), 6)} for f, v in pairs],
        "n_features": len(feats),
    }


@mcp.tool()
def predict_with_model(model_id: str, feature_rows: list) -> dict:
    """Apply a trained model to new (un-scaled) feature rows.

    Args:
        model_id: id from train_regressor
        feature_rows: list of dicts {feature_name: value}
    Returns:
        dict with predictions (list)
    """
    state = _load_model(model_id)
    feats = state["features"]
    scaler = state["scaler"]
    X = np.array([[float(row.get(f, np.nan)) for f in feats] for row in feature_rows])
    Xs = scaler.transform(X)
    pred = state["model"].predict(Xs)
    return {
        "predictions": [round(float(v), 6) for v in pred],
        "n": int(len(pred)),
        "feature_columns": feats,
    }


# ----------------------------------------------------------------------
# Group / heteroatom analysis
# ----------------------------------------------------------------------

@mcp.tool()
def group_summary(csv_path: str,
                   group_column: str,
                   value_column: str) -> dict:
    """Group rows by group_column and report count, mean, std, min, max,
    and fraction with value < 0 (useful for identifying corrosion accelerators).

    Args:
        csv_path: dataset CSV
        group_column: column to group by (e.g. heteroatom Type)
        value_column: column to aggregate (e.g. inhibition power)
    Returns:
        dict with rows (one per group, sorted by mean descending)
    """
    import pandas as pd
    df = pd.read_csv(csv_path).dropna(subset=[group_column, value_column]).copy()
    rows = []
    for g, sub in df.groupby(group_column):
        v = sub[value_column].astype(float)
        rows.append({
            "group": str(g),
            "count": int(len(v)),
            "mean": round(float(v.mean()), 4),
            "std": round(float(v.std(ddof=1)) if len(v) > 1 else 0.0, 4),
            "min": round(float(v.min()), 4),
            "max": round(float(v.max()), 4),
            "frac_negative": round(float((v < 0).sum() / len(v)), 4),
        })
    rows.sort(key=lambda r: -r["mean"])
    return {"rows": rows, "n_groups": len(rows)}


# ----------------------------------------------------------------------
# Plotting
# ----------------------------------------------------------------------

@mcp.tool()
def plot_inhibitor_ranking_box(csv_path: str,
                                inhibitor_column: str = "Inhibitor Candidate",
                                value_column: str = "IP - mean",
                                std_column: str = "IP - std",
                                group_column: str = "Type",
                                output_path: str = "artifacts/inhibitor_ranking.png",
                                top_n: int = 70) -> dict:
    """Horizontal error-bar plot of inhibitors ranked by mean value, coloured
    by heteroatom group. (Re-creates Fig. 4 of the paper.)

    Args:
        csv_path: dataset CSV
        inhibitor_column: name column
        value_column: mean value column (e.g. 'IP - mean')
        std_column: std column for the error bars
        group_column: heteroatom Type column for colouring
        output_path: PNG output path
        top_n: limit to top_n inhibitors (by descending mean)
    Returns:
        dict with output_path, n_plotted
    """
    import pandas as pd
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    df = pd.read_csv(csv_path).dropna(subset=[value_column]).copy()
    df = df.sort_values(value_column, ascending=False).head(top_n)
    df = df.iloc[::-1]  # so highest is on top of the plot

    groups = sorted(df[group_column].dropna().unique())
    cmap = plt.cm.tab20(np.linspace(0, 1, max(len(groups), 1)))
    color_map = {g: cmap[i] for i, g in enumerate(groups)}

    fig, ax = plt.subplots(figsize=(8, max(6, 0.18 * len(df))))
    y = np.arange(len(df))
    err = df[std_column].fillna(0).values if std_column in df.columns else None
    colors = [color_map.get(g, (0.5, 0.5, 0.5, 1)) for g in df[group_column].fillna("?")]
    ax.barh(y, df[value_column].values, xerr=err,
            color=colors, edgecolor="k", linewidth=0.4, height=0.75)
    ax.set_yticks(y)
    ax.set_yticklabels(df[inhibitor_column].astype(str).values, fontsize=7)
    ax.axvline(0, color="r", linestyle=":", alpha=0.6)
    ax.set_xlabel(value_column)
    ax.set_title(f"Inhibitor ranking by {value_column}")

    handles = [plt.Rectangle((0, 0), 1, 1, color=color_map[g]) for g in groups]
    ax.legend(handles, groups, loc="lower right", fontsize=7, title=group_column)

    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"output_path": output_path, "n_plotted": int(len(df))}


@mcp.tool()
def plot_predicted_vs_measured(csv_path: str,
                                feature_columns: list,
                                target_column: str,
                                output_path: str = "artifacts/predicted_vs_measured.png",
                                n_splits: int = 6,
                                random_state: int = 0,
                                model_type: str = "random_forest") -> dict:
    """Out-of-fold predicted-vs-measured scatter from k-fold CV. Prints
    overall R² (across folds) on the figure.

    Args:
        csv_path: dataset CSV
        feature_columns: feature names
        target_column: target column name
        output_path: PNG output path
        n_splits: folds
        random_state: seed
        model_type: 'random_forest' or 'xgboost'
    Returns:
        dict with output_path, r2_overall, n_points
    """
    import pandas as pd
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from sklearn.model_selection import KFold
    from sklearn.preprocessing import MinMaxScaler
    from sklearn.ensemble import RandomForestRegressor
    from sklearn.metrics import r2_score

    df = pd.read_csv(csv_path).dropna(subset=feature_columns + [target_column]).copy()
    X = df[feature_columns].values
    y = df[target_column].values

    pred = np.full(len(y), np.nan)
    kf = KFold(n_splits=n_splits, shuffle=True, random_state=random_state)
    for tr, te in kf.split(X):
        sc = MinMaxScaler().fit(X[tr])
        if model_type == "xgboost":
            import xgboost as xgb
            m = xgb.XGBRegressor(n_estimators=300, verbosity=0,
                                  random_state=random_state)
        else:
            m = RandomForestRegressor(n_estimators=200, random_state=random_state)
        m.fit(sc.transform(X[tr]), y[tr])
        pred[te] = m.predict(sc.transform(X[te]))

    fig, ax = plt.subplots(figsize=(6, 6))
    ax.scatter(y, pred, alpha=0.65, edgecolor="k", s=40)
    lo = min(np.nanmin(y), np.nanmin(pred))
    hi = max(np.nanmax(y), np.nanmax(pred))
    ax.plot([lo, hi], [lo, hi], "k--", alpha=0.5, label="perfect")
    r2 = r2_score(y, pred)
    ax.set_xlabel(f"measured ({target_column})")
    ax.set_ylabel(f"predicted ({target_column})")
    ax.set_title(f"out-of-fold prediction (RF, {n_splits}-fold CV)\nR² = {r2:.3f}")
    ax.legend()
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"output_path": output_path, "r2_overall": round(float(r2), 4),
            "n_points": int(len(y))}


@mcp.tool()
def plot_metric_vs_feature_set(results: dict,
                                metric: str = "r2_mean",
                                std_key: str = "r2_std",
                                output_path: str = "artifacts/feature_set_comparison.png",
                                title: str = "Feature-set comparison") -> dict:
    """Bar plot comparing several feature sets on one metric.

    Args:
        results: output of compare_feature_sets — keyed by set name
        metric: 'r2_mean' (default) or 'rmse_mean'
        std_key: matching std key
        output_path: PNG path
        title: figure title
    Returns:
        dict with output_path, n_sets
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    names, means, stds = [], [], []
    for k, v in results.items():
        if "error" in v:
            continue
        names.append(k)
        means.append(v.get(metric, 0))
        stds.append(v.get(std_key, 0))

    fig, ax = plt.subplots(figsize=(max(6, 1.4 * len(names)), 5))
    x = np.arange(len(names))
    ax.bar(x, means, yerr=stds, capsize=4,
           color=plt.cm.viridis(np.linspace(0.2, 0.8, max(len(names), 1))),
           edgecolor="k")
    ax.set_xticks(x)
    ax.set_xticklabels(names, rotation=30, ha="right", fontsize=9)
    ax.set_ylabel(metric)
    ax.set_title(title)
    ax.axhline(0, color="k", linewidth=0.6)
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"output_path": output_path, "n_sets": int(len(names))}


@mcp.tool()
def plot_group_summary_bar(csv_path: str,
                            group_column: str,
                            value_column: str,
                            output_path: str = "artifacts/heteroatom_group_summary.png",
                            title: Optional[str] = None) -> dict:
    """Bar plot of mean ± std of value_column per group (e.g. by heteroatom
    Type). Accelerator fraction (frac with value < 0) annotated above each bar.

    Args:
        csv_path: dataset CSV
        group_column: e.g. 'Type'
        value_column: e.g. 'IP - mean'
        output_path: PNG path
        title: optional figure title
    Returns:
        dict with output_path, n_groups
    """
    import pandas as pd
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    df = pd.read_csv(csv_path).dropna(subset=[group_column, value_column]).copy()
    g = df.groupby(group_column)[value_column].agg(["mean", "std", "count"])
    frac_neg = df.groupby(group_column)[value_column].apply(lambda v: (v < 0).mean())
    g = g.assign(frac_neg=frac_neg).sort_values("mean", ascending=False)

    fig, ax = plt.subplots(figsize=(max(6, 0.55 * len(g)), 5))
    x = np.arange(len(g))
    ax.bar(x, g["mean"].values, yerr=g["std"].fillna(0).values, capsize=4,
           color=plt.cm.coolwarm(np.linspace(0.1, 0.9, len(g))), edgecolor="k")
    ax.axhline(0, color="k", linewidth=0.6)
    for xi, (m, fr, ct) in enumerate(zip(g["mean"], g["frac_neg"], g["count"])):
        ax.text(xi, m + (0.4 if m >= 0 else -0.6),
                f"n={int(ct)}\n{int(round(100*fr))}%↓",
                ha="center", va="bottom" if m >= 0 else "top", fontsize=8)
    ax.set_xticks(x)
    ax.set_xticklabels(g.index, rotation=30, ha="right", fontsize=9)
    ax.set_ylabel(value_column)
    ax.set_title(title or f"{value_column} grouped by {group_column}")
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"output_path": output_path, "n_groups": int(len(g))}


@mcp.tool()
def plot_efficiency_vs_power(csv_path: str,
                              ie_column: str = "IE - mean",
                              ip_column: str = "IP - mean",
                              output_path: str = "artifacts/ie_vs_ip.png") -> dict:
    """Scatter plot of inhibition efficiency vs inhibition power across
    inhibitors. Demonstrates the clustering of IE near 100% which IP avoids.

    Args:
        csv_path: dataset CSV
        ie_column: column with inhibition efficiency
        ip_column: column with inhibition power
        output_path: PNG path
    Returns:
        dict with output_path, n_points
    """
    import pandas as pd
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    df = pd.read_csv(csv_path).dropna(subset=[ie_column, ip_column]).copy()
    fig, ax = plt.subplots(figsize=(7, 6))
    ax.scatter(df[ip_column], df[ie_column], alpha=0.65, edgecolor="k", s=40)
    ax.axhline(100, color="r", linestyle=":", alpha=0.5,
                label="100% (theoretical max IE)")
    ax.axvline(0, color="k", linestyle="--", alpha=0.4)
    ax.set_xlabel(ip_column)
    ax.set_ylabel(ie_column)
    ax.set_title("Inhibition efficiency (clustered near 100%) vs inhibition power")
    ax.legend(fontsize=8)
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"output_path": output_path, "n_points": int(len(df))}


if __name__ == "__main__":
    mcp.run(transport="stdio")

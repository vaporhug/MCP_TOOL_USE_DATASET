# mat_si27 — Tool Reference

## Database Retrieval (`database_retrieval.py`)
Generic web/database lookup primitives (web search, HTTP fetch, OpenAlex,
DOI/Crossref, etc.). Stubs to be filled with the appropriate client at
runtime.

## Data Processing (`data_processing.py`)
Generic format readers/writers (CSV, JSON, Excel, parquet, NetCDF,
shapefile, FASTA), pivot/aggregation primitives. Domain-agnostic.

## Domain Primitives (`sioc_film_tools.py`)
Low-level building blocks for SiOC-WOx ceramic-matrix composite (CMC)
gradient-film characterization. Each function is a single primitive — the
agent decides how to chain them.

### Characterization-data loading
- **load_characterization_csv**: read any of the five CSV characterization
  tables and report shape, columns, numeric ranges, and per-sample/track
  counts.
- **average_property_in_range**: mean / std / min / max of a property
  (hardness, modulus, oxidation %) over a chosen depth window. Used to
  obtain the effective E and H to feed into the Anstis equation.

### Depth-profile regression (gradient quantification)
- **fit_depth_profile**: linear, exponential, or piecewise (abrupt
  surface change + tail) regression of any property vs depth. Used for
  Si:W atomic ratio, Si-O percentage, W^6+ percentage, hardness, modulus,
  and grain-size gradients. Returns slope/intercept or asymptote/decay
  constant plus R² and RMSE.

### Indentation fracture toughness
- **fracture_toughness_anstis**: K_IC = η · √(E/H) · P / c^1.5 with
  η = 0.016 (Anstis 1981 calibration). Inputs E, H in GPa, P in mN, c in
  μm. Output in MPa·m^0.5. This is Equation 1 of the target paper.
- **fracture_toughness_ratio**: K_IC_film / K_IC_matrix; matrix from a
  built-in baseline table covering SiOC, Al2O3, SiC, SiO2, ZrC, ZrB2, WC,
  TaC, Inconel625.
- **hardness_ratio**: H_film / H_matrix.
- **stiffness_toughness_index**: combined enhancement index
  (H_film/H_m) · (K_IC_film/K_IC_m) used as the y-axis of paper Fig 7a.

### Nano-scratch interfacial bonding strength
- **critical_load_from_scratch**: detect the critical load Lc as the
  first significant load drop (the "first plunge" rule from the paper).
  Reports per-track Lc and the across-track mean ± std.
- **interfacial_bonding_strength**: σ = 2 Lc / (π d_c²) ·
  [(4 + ν_s) · 3π μ / 8 - (1 - 2 ν_s)] with μ ≈ 0.6 √(h_s / R), output
  in MPa. This is Equation 2 of the target paper.

### High-temperature insulation
- **high_temperature_resistance_summary**: per-sample peak temperature,
  R at 20 °C and 1050 °C, plus the SiOC-WOx / Al2O3 ratio.
- **fit_arrhenius_resistance**: Arrhenius linearisation
  ln R = ln R0 + Ea / (k_B T) above a chosen T cut-off; returns the
  apparent activation energy in eV.

### Plotting (one figure per call, saved to `artifacts/`)
- **plot_oxidation_gradient**: Si-O and W^6+ percentage vs |depth|
  (analogue of paper Fig 4b).
- **plot_hardness_modulus_profile**: H and E side-by-side depth profiles
  (analogue of paper Fig 6a-b).
- **plot_atomic_gradient**: W:Si atomic ratio vs depth with linear fit
  (analogue of paper Fig 4a).
- **plot_high_temp_resistance**: log-scale R/h0 vs T for SiOC-WOx and
  the Al2O3 reference (analogue of paper Fig 8b).
- **find_processing_optimum**: scan the sioc_processing_grid.csv and return
  the unique (SiC:W, E_d) cell that combines rock-embedded morphology with
  no peel-off, full sintering, and lowest porosity. Also reports the total
  number of rock-embedded cells in the grid.
- **plot_HK_enhancement_chart**: H/H_m vs K_IC/K_IC_m chart with
  iso-product contours and literature comparison points (analogue of
  paper Fig 7a).

## Dependencies
`numpy`, `pandas`, `scipy`, `matplotlib`, `mcp[cli]`.

## Quick start
```python
from sioc_film_tools import (
    load_characterization_csv, average_property_in_range,
    fit_depth_profile,
    fracture_toughness_anstis, fracture_toughness_ratio,
    hardness_ratio, stiffness_toughness_index,
    critical_load_from_scratch, interfacial_bonding_strength,
    high_temperature_resistance_summary, fit_arrhenius_resistance,
    plot_oxidation_gradient, plot_hardness_modulus_profile,
    plot_atomic_gradient, plot_high_temp_resistance,
    plot_HK_enhancement_chart,
)

# 1. Load and inspect
info_xps = load_characterization_csv("input_data/data/sioc_xps_depth_profile.csv")
info_hi  = load_characterization_csv("input_data/data/sioc_nanoindentation.csv")

# 2. Shallow H and E DEPTH-PROFILE characterisation (continuum-stiffness Fig 6a).
#    NOTE: these averages over the bundled CSV reflect the SHALLOW continuum-
#    stiffness measurement only and DO NOT correspond to the paper's Anstis
#    K_IC effective inputs E ≈ 20 GPa, H ≈ 2 GPa — those are SEPARATE deep-load
#    (P = 200 mN) substrate-bias-affected measurements that the bundled CSV
#    does NOT reproduce.
E_shallow = average_property_in_range("input_data/data/sioc_nanoindentation.csv",
                                      "depth_nm", "modulus_GPa", 0, 200)["mean"]
H_shallow = average_property_in_range("input_data/data/sioc_nanoindentation.csv",
                                      "depth_nm", "hardness_GPa", 0, 200)["mean"]
# E_shallow is the mean of the shallow CSV profile (≈40-50 GPa for the
# bundled gradient film), H_shallow is the shallow mean (≈10-12 GPa) —
# these are NOT the paper Anstis inputs.

# 3. Fracture toughness — paper-cited only for mat_si27:
#    The bundle ships NO indentation crack-length image/table, AND the bundled
#    nanoindentation CSV does not capture the paper's Anstis deep-load
#    effective E ≈ 20 GPa, H ≈ 2 GPa values either. So K_IC is reported from
#    the paper directly; the fracture_toughness_anstis helper below is
#    provided generically for users who have their own (load_mN, crack_half
#    length_um, effective-E, effective-H) inputs from independent measurements.
# KIC = fracture_toughness_anstis(E=20.0, H=2.0,  # paper-cited Anstis inputs
#                                 load_mN=200,    # paper-cited
#                                 crack_half_length_um=2.3)  # paper-cited
# For the mat_si27 task, simply cite K_IC = 2.88 MPa·m^0.5 from the paper.

# 4. Bonding strength from scratch — combine the bundled critical load
#    with the paper-reported scratch geometry (read these constants from
#    the paper's Methods section into your own variables):
crit = critical_load_from_scratch("input_data/data/sioc_scratch_test.csv")
sig  = interfacial_bonding_strength(
    critical_load_N=crit["Lc_mean_N"],
    scratch_groove_width_mm=<dc from paper>,
    in_situ_scratch_depth_nm=<hs from paper>,
    indenter_tip_radius_nm=<R from paper>,
)

# 5. High-T insulation
ht = high_temperature_resistance_summary("input_data/data/sioc_high_temp_resistance.csv")

# 6. Plots
plot_oxidation_gradient("input_data/data/sioc_xps_depth_profile.csv")
plot_hardness_modulus_profile("input_data/data/sioc_nanoindentation.csv")
plot_atomic_gradient("input_data/data/sioc_atomic_gradient.csv")
plot_high_temp_resistance("input_data/data/sioc_high_temp_resistance.csv")
```

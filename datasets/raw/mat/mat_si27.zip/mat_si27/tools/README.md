# mat_si27 — Tool Reference

## Database Retrieval (`database_retrieval.py`)
Generic web/database lookup primitives (web search, HTTP fetch, OpenAlex,
DOI/Crossref, etc.). Stubs to be filled with the appropriate client at
runtime.

## Data Processing (`data_processing.py`)
Generic format readers/writers (CSV, JSON, Excel, parquet, NetCDF,
shapefile, FASTA), pivot/aggregation primitives. Domain-agnostic.

## Domain Primitives (`sioc_film_tools.py`)
Low-level building blocks for SiOC-WOx ceramic-matrix composite (CMC)
gradient-film characterization. Each function is a single primitive — the
agent decides how to chain them.

### Characterization-data loading
- **load_characterization_csv**: read any of the five CSV characterization
  tables and report shape, columns, numeric ranges, and per-sample/track
  counts.
- **average_property_in_range**: mean / std / min / max of a property
  (hardness, modulus, oxidation %) over a chosen depth window. Used to
  obtain the effective E and H to feed into the Anstis equation.

### Depth-profile regression (gradient quantification)
- **fit_depth_profile**: linear, exponential, or piecewise (abrupt
  surface change + tail) regression of any property vs depth. Used for
  Si:W atomic ratio, Si-O percentage, W^6+ percentage, hardness, modulus,
  and grain-size gradients. Returns slope/intercept or asymptote/decay
  constant plus R² and RMSE.

### Indentation fracture toughness
- **fracture_toughness_anstis**: K_IC = η · √(E/H) · P / c^1.5 with
  η = 0.016 (Anstis 1981 calibration). Inputs E, H in GPa, P in mN, c in
  μm. Output in MPa·m^0.5. This is Equation 1 of the target paper.
- **fracture_toughness_ratio**: K_IC_film / K_IC_matrix; matrix from a
  built-in baseline table covering SiOC, Al2O3, SiC, SiO2, ZrC, ZrB2, WC,
  TaC, Inconel625.
- **hardness_ratio**: H_film / H_matrix.
- **stiffness_toughness_index**: combined enhancement index
  (H_film/H_m) · (K_IC_film/K_IC_m) used as the y-axis of paper Fig 7a.

### Nano-scratch interfacial bonding strength
- **critical_load_from_scratch**: detect the critical load Lc as the
  first significant load drop (the "first plunge" rule from the paper).
  Reports per-track Lc and the across-track mean ± std.
- **interfacial_bonding_strength**: σ = 2 Lc / (π d_c²) ·
  [(4 + ν_s) · 3π μ / 8 - (1 - 2 ν_s)] with μ ≈ 0.6 √(h_s / R), output
  in MPa. This is Equation 2 of the target paper.

### High-temperature insulation
- **high_temperature_resistance_summary**: per-sample peak temperature,
  R at 20 °C and 1050 °C, plus the SiOC-WOx / Al2O3 ratio.
- **fit_arrhenius_resistance**: Arrhenius linearisation
  ln R = ln R0 + Ea / (k_B T) above a chosen T cut-off; returns the
  apparent activation energy in eV.

### Plotting (one figure per call, saved to `artifacts/`)
- **plot_oxidation_gradient**: Si-O and W^6+ percentage vs |depth|
  (analogue of paper Fig 4b).
- **plot_hardness_modulus_profile**: H and E side-by-side depth profiles
  (analogue of paper Fig 6a-b).
- **plot_atomic_gradient**: W:Si atomic ratio vs depth with linear fit
  (analogue of paper Fig 4a).
- **plot_high_temp_resistance**: log-scale R/h0 vs T for SiOC-WOx and
  the Al2O3 reference (analogue of paper Fig 8b).
- **plot_HK_enhancement_chart**: H/H_m vs K_IC/K_IC_m chart with
  iso-product contours and literature comparison points (analogue of
  paper Fig 7a).

## Dependencies
`numpy`, `pandas`, `scipy`, `matplotlib`, `mcp[cli]`.

## Quick start
```python
from sioc_film_tools import (
    load_characterization_csv, average_property_in_range,
    fit_depth_profile,
    fracture_toughness_anstis, fracture_toughness_ratio,
    hardness_ratio, stiffness_toughness_index,
    critical_load_from_scratch, interfacial_bonding_strength,
    high_temperature_resistance_summary, fit_arrhenius_resistance,
    plot_oxidation_gradient, plot_hardness_modulus_profile,
    plot_atomic_gradient, plot_high_temp_resistance,
    plot_HK_enhancement_chart,
)

# 1. Load and inspect
info_xps = load_characterization_csv("input_data/data/sioc_xps_depth_profile.csv")
info_hi  = load_characterization_csv("input_data/data/sioc_nanoindentation.csv")

# 2. Effective H and E for the Anstis indentation depth (paper uses 0..200 nm)
E = average_property_in_range("input_data/data/sioc_nanoindentation.csv",
                              "depth_nm", "modulus_GPa", 0, 200)["mean"]
H = average_property_in_range("input_data/data/sioc_nanoindentation.csv",
                              "depth_nm", "hardness_GPa", 0, 200)["mean"]

# 3. Fracture toughness (paper uses P=200 mN, c=2.3 μm)
KIC = fracture_toughness_anstis(E, H, load_mN=200, crack_half_length_um=2.3)
ratio = fracture_toughness_ratio(KIC["K_IC_MPa_m05"])

# 4. Bonding strength from scratch
crit = critical_load_from_scratch("input_data/data/sioc_scratch_test.csv")
sig  = interfacial_bonding_strength(critical_load_N=crit["Lc_mean_N"],
                                     scratch_groove_width_mm=0.037,
                                     in_situ_scratch_depth_nm=3446,
                                     indenter_tip_radius_nm=2000)

# 5. High-T insulation
ht = high_temperature_resistance_summary("input_data/data/sioc_high_temp_resistance.csv")

# 6. Plots
plot_oxidation_gradient("input_data/data/sioc_xps_depth_profile.csv")
plot_hardness_modulus_profile("input_data/data/sioc_nanoindentation.csv")
plot_atomic_gradient("input_data/data/sioc_atomic_gradient.csv")
plot_high_temp_resistance("input_data/data/sioc_high_temp_resistance.csv")
```

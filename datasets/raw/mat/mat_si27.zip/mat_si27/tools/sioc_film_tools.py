#!/usr/bin/env python3
"""Low-level primitives for SiOC-WOx ceramic-matrix composite (CMC) film
characterization.

These functions are domain primitives: characterization-data loading,
depth-profile interpolation, indentation fracture toughness (Anstis),
nano-scratch interfacial bonding strength, gradient-property regression
(Si:W ratio, oxidation %, hardness, modulus, grain size vs depth),
high-temperature resistance characterization, and plotting. The agent
decides how to chain them.

Reproduces the calculation pipeline of the SiOC-WOx gradient-CMC paper
(Communications Materials 5:96, 2024) using only the explicitly printed
data values. Intentionally avoids any pre-computed conclusion.
"""
import os
import math
from typing import Optional

import numpy as np
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("SiOC_Film_Tools")


# ---------------------------------------------------------------------------
# Reference materials and matrix-baseline values (used as the denominator in
# the H/H_matrix and K_IC/K_IC_matrix ratios shown in the paper Fig. 7a).
# Matrix = pure SiOC (without WOx reinforcement). Numbers are the literature
# values cited in references [22, 35, 57-72] of the target paper.
# ---------------------------------------------------------------------------
MATRIX_BASELINE = {
    "SiOC":  {"H_GPa": 8.7, "E_GPa": 90.0, "KIC_MPa_m05": 0.76},
    "Al2O3": {"H_GPa": 18.0, "E_GPa": 380.0, "KIC_MPa_m05": 3.5},
    "SiC":   {"H_GPa": 25.0, "E_GPa": 410.0, "KIC_MPa_m05": 3.0},
    "SiO2":  {"H_GPa": 8.0, "E_GPa": 70.0, "KIC_MPa_m05": 0.7},
    "ZrC":   {"H_GPa": 25.0, "E_GPa": 350.0, "KIC_MPa_m05": 3.0},
    "ZrB2":  {"H_GPa": 22.0, "E_GPa": 350.0, "KIC_MPa_m05": 3.5},
    "WC":    {"H_GPa": 22.0, "E_GPa": 530.0, "KIC_MPa_m05": 7.0},
    "TaC":   {"H_GPa": 18.0, "E_GPa": 380.0, "KIC_MPa_m05": 4.0},
    "Inconel625": {"H_GPa": 4.5, "E_GPa": 200.0, "KIC_MPa_m05": float("nan")},
}


# Universal physical / processing constants tied to the Anstis equation and
# the scratch test. eta = 0.016 (Anstis 1981 calibration on 8 ceramics).
ANSTIS_ETA = 0.016


# ---------------------------------------------------------------------------
# Generic CSV loader for the five characterization tables
# ---------------------------------------------------------------------------
@mcp.tool()
def load_characterization_csv(csv_path: str) -> dict:
    """Load any of the five CMC-film characterization CSV files and report
    its shape, columns, numeric ranges and (if present) per-sample counts.

    Recognised tables:
      * sioc_xps_depth_profile.csv  (XPS Si-C/Si-O and W-valence vs depth)
      * sioc_atomic_gradient.csv    (FIB-EDS W:Si atomic ratio vs depth)
      * sioc_nanoindentation.csv    (continuous-stiffness H, E vs depth)
      * sioc_scratch_test.csv       (scratch position vs normal load curve)
      * sioc_high_temp_resistance.csv (R/h0 vs T for SiOC-WOx and Al2O3)
      * sioc_processing_grid.csv    (qualitative SEM grid SiC:W x E_d)

    Args:
        csv_path: path to characterization CSV
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    out = {"shape": list(df.shape), "columns": list(df.columns)}
    numeric = df.select_dtypes(include="number")
    out["numeric_summary"] = {
        c: {"min": float(numeric[c].min()),
            "max": float(numeric[c].max()),
            "mean": round(float(numeric[c].mean()), 4)}
        for c in numeric.columns
    }
    for grp_col in ("sample_id", "track_id", "survey_point", "sample"):
        if grp_col in df.columns:
            out["group_counts"] = df[grp_col].value_counts().to_dict()
            break
    return out


# ---------------------------------------------------------------------------
# Depth-profile fitting:  exponential / piecewise linear regression of
# composition or property vs depth.  Used for the Si:W ratio, oxidation %,
# hardness and modulus gradients.
# ---------------------------------------------------------------------------
@mcp.tool()
def fit_depth_profile(csv_path: str,
                      depth_col: str,
                      value_col: str,
                      model: str = "exponential",
                      group_col: Optional[str] = None) -> dict:
    """Fit a depth-direction profile of one property (hardness, modulus,
    Si-O %, W6+ %, Si:W ratio).

    Models:
      - "linear":      y = a + b * depth
      - "exponential": y = y_inf + (y0 - y_inf) * exp(-k * |depth|)
      - "piecewise":   abrupt change at the *first* node followed by a
                        constant-or-linear tail (Si-O behaviour); returns
                        the abrupt-change Δ between depth=0 and node-1.

    Returns parameter estimates plus R² and residual std.

    Args:
        csv_path:  characterization CSV
        depth_col: name of the depth column (in nm, μm, or any consistent
                   unit; absolute value is used). Negative depths are OK.
        value_col: name of the property column to regress
        model:     "linear" | "exponential" | "piecewise"
        group_col: if set, fit independently per group (e.g. sample_id)
                   and return a list of fits.
    """
    import pandas as pd
    df = pd.read_csv(csv_path)

    def _fit(sub: pd.DataFrame, gname: Optional[str] = None) -> dict:
        x = np.abs(sub[depth_col].to_numpy(dtype=float))
        y = sub[value_col].to_numpy(dtype=float)
        order = np.argsort(x); x = x[order]; y = y[order]
        if model == "linear":
            A = np.vstack([np.ones_like(x), x]).T
            beta, *_ = np.linalg.lstsq(A, y, rcond=None)
            yhat = A @ beta
            r2 = _r2(y, yhat)
            res = {"intercept": float(beta[0]),
                   "slope_per_unit_depth": float(beta[1]),
                   "r2": round(r2, 4),
                   "rmse": round(float(np.sqrt(np.mean((y - yhat) ** 2))), 4)}
        elif model == "exponential":
            from scipy.optimize import curve_fit
            def f(d, y0, yinf, k): return yinf + (y0 - yinf) * np.exp(-k * d)
            try:
                p0 = [y[0], y[-1], 0.05]
                popt, _ = curve_fit(f, x, y, p0=p0, maxfev=10000)
                yhat = f(x, *popt)
                res = {"y0": float(popt[0]), "y_inf": float(popt[1]),
                       "k": float(popt[2]),
                       "r2": round(_r2(y, yhat), 4),
                       "rmse": round(float(np.sqrt(np.mean((y - yhat) ** 2))), 4)}
            except Exception as e:
                res = {"error": f"curve_fit failed: {e}"}
        elif model == "piecewise":
            uniq = np.sort(np.unique(x))
            if len(uniq) < 2:
                return {"error": "need >=2 unique depths"}
            y0 = float(np.mean(y[x == uniq[0]]))
            y_node1 = float(np.mean(y[x == uniq[1]]))
            tail = (x > uniq[0])
            xt, yt = x[tail], y[tail]
            if len(np.unique(xt)) >= 2:
                A = np.vstack([np.ones_like(xt), xt]).T
                beta, *_ = np.linalg.lstsq(A, yt, rcond=None)
                yhat_tail = A @ beta
                tail_slope = float(beta[1])
                tail_intercept = float(beta[0])
                yhat = np.empty_like(y, dtype=float)
                yhat[~tail] = y0
                yhat[tail] = yhat_tail
                r2 = _r2(y, yhat)
            else:
                tail_slope, tail_intercept, r2 = 0.0, y_node1, float("nan")
            res = {"y_at_surface": y0,
                   "y_at_first_subsurface_node": y_node1,
                   "abrupt_change": round(y_node1 - y0, 4),
                   "tail_slope_per_unit_depth": tail_slope,
                   "tail_intercept": tail_intercept,
                   "r2": None if np.isnan(r2) else round(r2, 4),
                   "n_nodes": int(len(uniq))}
        else:
            return {"error": f"unknown model {model}"}
        if gname is not None:
            res["group"] = gname
        res["n_points"] = int(len(x))
        return res

    if group_col is None or group_col not in df.columns:
        return _fit(df)
    return {"per_group": [_fit(df[df[group_col] == g], gname=str(g))
                          for g in df[group_col].unique()]}


def _r2(y: np.ndarray, yhat: np.ndarray) -> float:
    ss_res = float(((y - yhat) ** 2).sum())
    ss_tot = float(((y - y.mean()) ** 2).sum())
    return 1.0 - ss_res / ss_tot if ss_tot > 0 else float("nan")


# ---------------------------------------------------------------------------
# Average gradient property over a depth range (used as input for the
# Anstis fracture-toughness equation, which needs E and H integrated over
# the indentation depth).
# ---------------------------------------------------------------------------
@mcp.tool()
def average_property_in_range(csv_path: str,
                              depth_col: str,
                              value_col: str,
                              depth_min: float,
                              depth_max: float) -> dict:
    """Mean and standard deviation of a property over a depth window.

    Useful for getting the effective E and H to feed into the Anstis
    fracture-toughness equation (paper uses 0 > h > -200 nm, so call with
    depth_min=0, depth_max=200 on absolute-depth columns).
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    x = np.abs(df[depth_col].to_numpy(dtype=float))
    mask = (x >= depth_min) & (x <= depth_max)
    if not mask.any():
        return {"error": "no points in depth range",
                "n_points_in_range": 0}
    y = df.loc[mask, value_col].to_numpy(dtype=float)
    return {"depth_min": float(depth_min),
            "depth_max": float(depth_max),
            "n_points_in_range": int(mask.sum()),
            "mean": round(float(np.mean(y)), 4),
            "std":  round(float(np.std(y, ddof=1)) if len(y) > 1 else 0.0, 4),
            "min":  round(float(np.min(y)), 4),
            "max":  round(float(np.max(y)), 4)}


# ---------------------------------------------------------------------------
# Anstis indentation fracture toughness (Equation 1 in the paper).
#
#     K_IC = eta * sqrt(E / H) * (P / c^1.5)
#
# eta = 0.016 (Anstis 1981 calibration). Output in MPa·m^0.5.
# ---------------------------------------------------------------------------
@mcp.tool()
def fracture_toughness_anstis(E_GPa: float, H_GPa: float,
                              load_mN: float, crack_half_length_um: float,
                              eta: float = ANSTIS_ETA) -> dict:
    """Indentation fracture toughness K_IC by the Anstis equation.

        K_IC = eta * (E / H)^0.5 * (P / c^{1.5})

    Args:
        E_GPa:                   Young's modulus, GPa
        H_GPa:                   Vickers / Berkovich hardness, GPa
        load_mN:                 maximum indentation load P, mN
        crack_half_length_um:    radial crack half-length c, μm
        eta:                     dimensionless calibration (default 0.016
                                  per Anstis et al. 1981)

    Returns:
        K_IC in MPa·m^0.5, plus the value in N/m^1.5 and the dimensionless
        E/H ratio for cross-checking.
    """
    if H_GPa <= 0 or crack_half_length_um <= 0:
        return {"error": "non-positive H or c"}
    # Anstis derivation: P in N, c in m, E and H in Pa -> K_IC in Pa·m^0.5
    P_N = load_mN * 1e-3                       # mN -> N
    c_m = crack_half_length_um * 1e-6          # μm -> m
    E_Pa = E_GPa * 1e9
    H_Pa = H_GPa * 1e9
    K_Pa_m05 = eta * math.sqrt(E_Pa / H_Pa) * P_N / (c_m ** 1.5)
    K_MPa_m05 = K_Pa_m05 * 1e-6                # Pa·m^0.5 -> MPa·m^0.5
    return {"K_IC_MPa_m05": round(K_MPa_m05, 4),
            "K_IC_Pa_m05":  K_Pa_m05,
            "E_over_H":     round(E_GPa / H_GPa, 4),
            "eta":          eta,
            "load_mN":      load_mN,
            "crack_half_length_um": crack_half_length_um}


@mcp.tool()
def fracture_toughness_ratio(K_IC_film_MPa_m05: float,
                             matrix_name: str = "SiOC") -> dict:
    """Ratio K_IC_film / K_IC_matrix used as the y-axis of paper Fig. 7a.

    Args:
        K_IC_film_MPa_m05: indentation fracture toughness of the gradient
                            film
        matrix_name: matrix material — one of the keys of MATRIX_BASELINE
                      ("SiOC" by default, matching the paper)
    """
    if matrix_name not in MATRIX_BASELINE:
        return {"error": f"matrix {matrix_name} not in baseline table"}
    Km = MATRIX_BASELINE[matrix_name]["KIC_MPa_m05"]
    return {"matrix": matrix_name,
            "K_IC_matrix_MPa_m05": Km,
            "K_IC_film_MPa_m05":   K_IC_film_MPa_m05,
            "ratio":               round(K_IC_film_MPa_m05 / Km, 4)}


@mcp.tool()
def hardness_ratio(H_film_GPa: float, matrix_name: str = "SiOC") -> dict:
    """Ratio H_film / H_matrix used as the x-axis of paper Fig. 7a."""
    if matrix_name not in MATRIX_BASELINE:
        return {"error": f"matrix {matrix_name} not in baseline table"}
    Hm = MATRIX_BASELINE[matrix_name]["H_GPa"]
    return {"matrix": matrix_name,
            "H_matrix_GPa": Hm,
            "H_film_GPa":   H_film_GPa,
            "ratio":        round(H_film_GPa / Hm, 4)}


# ---------------------------------------------------------------------------
# Nano-scratch interfacial bonding strength (Equation 2 in the paper).
#
#     sigma = 2 Lc / (pi dc^2) * [(4 + nu) * 3 pi mu / 8 - (1 - 2 nu)]
#
# with mu ~= 0.6 sqrt(hs / R)
# ---------------------------------------------------------------------------
@mcp.tool()
def critical_load_from_scratch(csv_path: str,
                               position_col: str = "scratch_position_mm",
                               load_col: str = "normal_load_N",
                               track_col: Optional[str] = "track_id",
                               drop_threshold_N: float = 0.005) -> dict:
    """Detect the critical load Lc as the first significant load *drop* in
    the scratch curve, mirroring the paper's "first plunge" rule.

    A load drop is recognised when load(i+1) < load(i) - drop_threshold_N.
    The maximum load *just before* the first drop is reported as Lc.

    Args:
        csv_path:     scratch test CSV
        position_col: scratch position column, mm
        load_col:     applied load column, N
        track_col:    optional grouping column (multiple scratches)
        drop_threshold_N: minimum drop in N to count as the first plunge

    Returns:
        Lc_N (mean ± std across tracks), drop position (mm), n_tracks.
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    tracks = (df[track_col].unique() if track_col and track_col in df.columns
              else [None])
    Lc_list, pos_list = [], []
    for t in tracks:
        sub = df if t is None else df[df[track_col] == t]
        sub = sub.sort_values(position_col).reset_index(drop=True)
        loads = sub[load_col].to_numpy(dtype=float)
        positions = sub[position_col].to_numpy(dtype=float)
        Lc, pos = float("nan"), float("nan")
        for i in range(len(loads) - 1):
            if loads[i] - loads[i + 1] > drop_threshold_N:
                Lc = float(loads[i])
                pos = float(positions[i])
                break
        Lc_list.append(Lc); pos_list.append(pos)
    Lc_arr = np.array([v for v in Lc_list if not np.isnan(v)])
    return {"n_tracks": len(tracks),
            "Lc_N_per_track": [None if np.isnan(v) else round(v, 4)
                               for v in Lc_list],
            "drop_position_mm_per_track": [None if np.isnan(v) else round(v, 4)
                                            for v in pos_list],
            "Lc_mean_N": (round(float(Lc_arr.mean()), 4)
                          if len(Lc_arr) else None),
            "Lc_std_N":  (round(float(Lc_arr.std(ddof=1)), 4)
                          if len(Lc_arr) > 1 else None)}


@mcp.tool()
def interfacial_bonding_strength(critical_load_N: float,
                                  scratch_groove_width_mm: float,
                                  in_situ_scratch_depth_nm: float,
                                  indenter_tip_radius_nm: float,
                                  poisson_ratio: float = 0.25) -> dict:
    """Interfacial bonding strength σ from a nano-scratch result, Equation 2:

        σ = 2 Lc / (π d_c²) * [(4 + ν_s) · 3π μ / 8 - (1 - 2 ν_s)]

    with μ ≈ 0.6 √(h_s / R), Lc in N, d_c in m, σ in Pa.

    Args:
        critical_load_N:           critical normal load Lc, N
        scratch_groove_width_mm:   scratch-groove width d_c, mm
        in_situ_scratch_depth_nm:  in-situ scratch depth h_s, nm
        indenter_tip_radius_nm:    indenter tip radius R, nm
        poisson_ratio:             ν_s of the film (default 0.25; common
                                    metals/ceramics 0.1-0.4)

    Returns:
        bonding_strength_MPa, friction coefficient μ, all the inputs.
    """
    Lc = float(critical_load_N)
    dc = float(scratch_groove_width_mm) * 1e-3  # mm -> m
    hs = float(in_situ_scratch_depth_nm)
    R = float(indenter_tip_radius_nm)
    nu = float(poisson_ratio)
    if dc <= 0 or R <= 0 or hs <= 0:
        return {"error": "non-positive geometry"}
    mu = 0.6 * math.sqrt(hs / R)
    bracket = (4 + nu) * (3 * math.pi * mu / 8) - (1 - 2 * nu)
    sigma_Pa = 2 * Lc / (math.pi * dc * dc) * bracket
    return {"bonding_strength_MPa": round(sigma_Pa * 1e-6, 4),
            "friction_coeff_mu":    round(mu, 4),
            "Lc_N":                 Lc,
            "groove_width_mm":      scratch_groove_width_mm,
            "scratch_depth_nm":     hs,
            "indenter_radius_nm":   R,
            "poisson_ratio":        nu,
            "bracket_value":        round(bracket, 4)}


# ---------------------------------------------------------------------------
# High-temperature resistance characterization
# ---------------------------------------------------------------------------
@mcp.tool()
def high_temperature_resistance_summary(csv_path: str,
                                        temperature_col: str = "temperature_C",
                                        resistance_col: str = "resistance_per_thickness_Ohm_per_um",
                                        sample_col: str = "sample") -> dict:
    """Per-sample summary of the R/h0 vs T curve.

    Reports: peak temperature (where R is maximum), R at 20 °C, R at 1050
    °C, and (if both SiOC-WOx and Al2O3 samples are present) the SiOC/Al2O3
    resistance ratio at 1050 °C.

    Args:
        csv_path: high-T resistance CSV
        temperature_col, resistance_col, sample_col: column names
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    out = {"per_sample": []}
    for s in df[sample_col].unique():
        sub = df[df[sample_col] == s].sort_values(temperature_col)
        T = sub[temperature_col].to_numpy(dtype=float)
        R = sub[resistance_col].to_numpy(dtype=float)
        idx_max = int(np.argmax(R))
        out["per_sample"].append({
            "sample": str(s),
            "n_points": int(len(sub)),
            "T_min_C": float(T.min()),
            "T_max_C": float(T.max()),
            "R_at_lowest_T_Ohm_per_um": float(R[0]),
            "R_at_highest_T_Ohm_per_um": float(R[-1]),
            "T_peak_R_C": float(T[idx_max]),
            "R_peak_Ohm_per_um": float(R[idx_max]),
        })
    samples = {p["sample"]: p for p in out["per_sample"]}
    if "SiOC-WOx" in samples and "Al2O3" in samples:
        out["sioc_to_al2o3_ratio_at_max_T"] = round(
            samples["SiOC-WOx"]["R_at_highest_T_Ohm_per_um"]
            / samples["Al2O3"]["R_at_highest_T_Ohm_per_um"], 4)
    return out


@mcp.tool()
def fit_arrhenius_resistance(csv_path: str,
                             temperature_col: str = "temperature_C",
                             resistance_col: str = "resistance_per_thickness_Ohm_per_um",
                             sample_filter: Optional[str] = None,
                             T_min_C: float = 400.0) -> dict:
    """Linear fit of ln(R) vs 1/T (Arrhenius) above a chosen temperature.

    Above 400 °C the SiOC-WOx film and Al2O3 both follow a thermally
    activated conduction trend, so an apparent activation energy can be
    extracted by ln R = ln R0 + Ea / (k_B T).

    Args:
        csv_path:        high-T resistance CSV
        temperature_col, resistance_col: column names
        sample_filter:   restrict to one sample (e.g. "SiOC-WOx")
        T_min_C:         lower temperature cut-off (paper uses 400 °C)

    Returns:
        ln_R0, slope (Ea / k_B in K), Ea_eV, R²
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    if sample_filter and "sample" in df.columns:
        df = df[df["sample"] == sample_filter]
    T = df[temperature_col].to_numpy(dtype=float) + 273.15
    R = df[resistance_col].to_numpy(dtype=float)
    keep = (df[temperature_col].to_numpy(dtype=float) >= T_min_C) & (R > 0)
    if keep.sum() < 3:
        return {"error": f"<3 points above T={T_min_C} °C"}
    invT = 1.0 / T[keep]
    lnR = np.log(R[keep])
    A = np.vstack([np.ones_like(invT), invT]).T
    beta, *_ = np.linalg.lstsq(A, lnR, rcond=None)
    yhat = A @ beta
    r2 = _r2(lnR, yhat)
    k_B = 8.617333e-5  # eV/K
    Ea_eV = float(beta[1]) * k_B
    return {"sample": sample_filter,
            "ln_R0":         float(beta[0]),
            "slope_K":       float(beta[1]),
            "activation_energy_eV": round(Ea_eV, 4),
            "T_range_C":     [float(df[temperature_col][keep].min()),
                              float(df[temperature_col][keep].max())],
            "n_points":      int(keep.sum()),
            "r2":            round(r2, 4)}


# ---------------------------------------------------------------------------
# Combined "stiffness-toughness" composite-improvement index (Fig 7a)
# ---------------------------------------------------------------------------
@mcp.tool()
def stiffness_toughness_index(H_film_GPa: float,
                              K_IC_film_MPa_m05: float,
                              matrix_name: str = "SiOC") -> dict:
    """Combined enhancement index used in paper Fig 7a:

        index = (H_film / H_matrix) * (K_IC_film / K_IC_matrix)

    The paper reports SiOC-WOx films at index ≈ 8.7, the topmost dot in
    Fig 7a. (≈ 2.3 × 3.8 = 8.74)

    Args:
        H_film_GPa:           film hardness, GPa
        K_IC_film_MPa_m05:    film fracture toughness, MPa·m^0.5
        matrix_name:           matrix material in MATRIX_BASELINE
    """
    if matrix_name not in MATRIX_BASELINE:
        return {"error": f"matrix {matrix_name} not in baseline table"}
    Hm = MATRIX_BASELINE[matrix_name]["H_GPa"]
    Km = MATRIX_BASELINE[matrix_name]["KIC_MPa_m05"]
    H_ratio = H_film_GPa / Hm
    K_ratio = K_IC_film_MPa_m05 / Km
    return {"matrix": matrix_name,
            "H_ratio":  round(H_ratio, 4),
            "K_ratio":  round(K_ratio, 4),
            "stiffness_toughness_index": round(H_ratio * K_ratio, 4)}


# ---------------------------------------------------------------------------
# Plotting (one figure per call)
# ---------------------------------------------------------------------------
def _ensure_dir(path: str):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)


@mcp.tool()
def plot_oxidation_gradient(csv_path: str,
                            depth_col: str = "depth_nm",
                            si_o_col: str = "Si_O_pct",
                            w6_col: str = "W6plus_pct",
                            output_path: str = "artifacts/Fig_oxidation_gradient.png"
                            ) -> dict:
    """Two-y-axis plot of Si-O percentage and W^6+ percentage vs |depth|
    (paper Fig 4b). Aggregates across replicates by mean ± std.
    """
    import pandas as pd
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    df = pd.read_csv(csv_path)
    df["abs_depth"] = np.abs(df[depth_col].to_numpy(dtype=float))
    g = df.groupby("abs_depth").agg({si_o_col: ["mean", "std"],
                                     w6_col:  ["mean", "std"]}).reset_index()
    d = g["abs_depth"].to_numpy(dtype=float)
    si_mean = g[(si_o_col, "mean")].to_numpy(dtype=float)
    si_std = g[(si_o_col, "std")].to_numpy(dtype=float)
    w_mean = g[(w6_col, "mean")].to_numpy(dtype=float)
    w_std = g[(w6_col, "std")].to_numpy(dtype=float)
    fig, ax1 = plt.subplots(figsize=(7, 4.6))
    ax1.errorbar(d, si_mean, yerr=si_std, fmt="o-",
                 color="steelblue", label="Si-O (%)", capsize=4)
    ax1.set_xlabel("|depth| (nm)")
    ax1.set_ylabel("Si-O (%)", color="steelblue")
    ax1.tick_params(axis="y", labelcolor="steelblue")
    ax2 = ax1.twinx()
    ax2.errorbar(d, w_mean, yerr=w_std, fmt="s--",
                 color="darkred", label="W^6+ (%)", capsize=4)
    ax2.set_ylabel("W^6+ (%)", color="darkred")
    ax2.tick_params(axis="y", labelcolor="darkred")
    ax1.set_title("Oxidation gradient: Si-O and W^6+ vs depth")
    fig.tight_layout()
    _ensure_dir(output_path)
    fig.savefig(output_path, dpi=140, bbox_inches="tight")
    plt.close(fig)
    return {"output_path": output_path,
            "n_depth_levels": int(len(d)),
            "si_o_at_surface_pct": float(si_mean[0]),
            "si_o_at_60nm_pct":   float(si_mean[-1]),
            "w6_at_surface_pct":  float(w_mean[0]),
            "w6_at_60nm_pct":     float(w_mean[-1])}


@mcp.tool()
def plot_hardness_modulus_profile(csv_path: str,
                                   depth_col: str = "depth_nm",
                                   h_col: str = "hardness_GPa",
                                   e_col: str = "modulus_GPa",
                                   output_path: str = "artifacts/Fig_HE_profile.png"
                                   ) -> dict:
    """Side-by-side hardness and modulus depth profiles (paper Fig 6a-b).
    Plots the mean ± std across the five survey points at each depth.
    """
    import pandas as pd
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    df = pd.read_csv(csv_path)
    g = df.groupby(depth_col).agg({h_col: ["mean", "std"],
                                   e_col: ["mean", "std"]}).reset_index()
    d = g[depth_col].to_numpy(dtype=float)
    h_mean = g[(h_col, "mean")].to_numpy(dtype=float)
    h_std = g[(h_col, "std")].to_numpy(dtype=float)
    e_mean = g[(e_col, "mean")].to_numpy(dtype=float)
    e_std = g[(e_col, "std")].to_numpy(dtype=float)
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
    axes[0].errorbar(d, h_mean, yerr=h_std, fmt="o-",
                     color="navy", capsize=4)
    axes[0].set_xlabel("depth (nm)")
    axes[0].set_ylabel("Hardness H (GPa)")
    axes[0].set_title("Hardness depth profile")
    axes[1].errorbar(d, e_mean, yerr=e_std, fmt="s-",
                     color="firebrick", capsize=4)
    axes[1].set_xlabel("depth (nm)")
    axes[1].set_ylabel("Young's modulus E (GPa)")
    axes[1].set_title("Modulus depth profile")
    fig.tight_layout()
    _ensure_dir(output_path)
    fig.savefig(output_path, dpi=140, bbox_inches="tight")
    plt.close(fig)
    return {"output_path": output_path,
            "n_depth_levels": int(len(d)),
            "H_at_surface_GPa":   float(h_mean[0]),
            "H_at_max_depth_GPa": float(h_mean[-1]),
            "E_at_surface_GPa":   float(e_mean[0]),
            "E_at_max_depth_GPa": float(e_mean[-1])}


@mcp.tool()
def plot_atomic_gradient(csv_path: str,
                         depth_col: str = "depth_um",
                         ratio_col: str = "W_to_Si_ratio",
                         output_path: str = "artifacts/Fig_W_Si_gradient.png"
                         ) -> dict:
    """W:Si atomic-ratio versus depth (paper Fig 4a). Plots the raw
    counts and overlays a linear fit so the slope is visible.
    """
    import pandas as pd
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    df = pd.read_csv(csv_path).sort_values(depth_col)
    d = df[depth_col].to_numpy(dtype=float)
    r = df[ratio_col].to_numpy(dtype=float)
    A = np.vstack([np.ones_like(d), d]).T
    beta, *_ = np.linalg.lstsq(A, r, rcond=None)
    yhat = A @ beta
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.scatter(d, r, color="indigo", s=36, label="FIB-EDS")
    ax.plot(d, yhat, color="black", lw=1.4,
            label=f"linear fit: r = {beta[0]:.3f} + {beta[1]:.3f} h")
    ax.set_xlabel("|depth| (μm)")
    ax.set_ylabel("W : Si atomic ratio")
    ax.set_title("Atomic-fraction gradient")
    ax.legend()
    fig.tight_layout()
    _ensure_dir(output_path)
    fig.savefig(output_path, dpi=140, bbox_inches="tight")
    plt.close(fig)
    return {"output_path": output_path,
            "intercept": float(beta[0]),
            "slope_per_um": float(beta[1]),
            "ratio_at_surface": float(r[0]),
            "ratio_at_deepest": float(r[-1])}


@mcp.tool()
def plot_high_temp_resistance(csv_path: str,
                              temperature_col: str = "temperature_C",
                              resistance_col: str = "resistance_per_thickness_Ohm_per_um",
                              sample_col: str = "sample",
                              output_path: str = "artifacts/Fig_HT_resistance.png"
                              ) -> dict:
    """log-scale R/h0 vs T plot (paper Fig 8b) for SiOC-WOx and the Al2O3
    reference, overlaid for direct comparison."""
    import pandas as pd
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    df = pd.read_csv(csv_path)
    fig, ax = plt.subplots(figsize=(7, 4.6))
    markers = {"SiOC-WOx": ("*", "darkgreen"),
               "Al2O3":    ("s", "olive")}
    for s in df[sample_col].unique():
        sub = df[df[sample_col] == s].sort_values(temperature_col)
        m, c = markers.get(s, ("o", "gray"))
        ax.semilogy(sub[temperature_col], sub[resistance_col],
                    marker=m, linestyle="-", color=c, label=str(s))
    ax.set_xlabel("Temperature (°C)")
    ax.set_ylabel("R / h_0 (Ω/μm)")
    ax.set_title("High-temperature electrical insulation")
    ax.grid(True, which="both", lw=0.3, alpha=0.5)
    ax.legend()
    fig.tight_layout()
    _ensure_dir(output_path)
    fig.savefig(output_path, dpi=140, bbox_inches="tight")
    plt.close(fig)
    return {"output_path": output_path,
            "samples": list(df[sample_col].unique())}


@mcp.tool()
def plot_HK_enhancement_chart(film_H_ratio: float, film_K_ratio: float,
                               literature_points: Optional[list] = None,
                               output_path: str = "artifacts/Fig_HK_chart.png"
                               ) -> dict:
    """Recreate the H/H_matrix vs K_IC/K_IC_matrix chart (paper Fig 7a):
    plots the SiOC-WOx film point and a few literature reference points
    with iso-product contours for index = 1, 2, 4, 8.

    Args:
        film_H_ratio:        H_film / H_matrix for the SiOC-WOx point
        film_K_ratio:        K_IC_film / K_IC_matrix for the SiOC-WOx point
        literature_points:   optional list of {label, H_ratio, K_ratio}
                              dicts representing other CMC literature
                              points; if None, uses a small built-in set
                              spanning Al2O3, SiC, SiO2, ZrC, ZrB2, WC, TaC
                              composites taken from Fig 7a.
        output_path:         PNG output path
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    if literature_points is None:
        literature_points = [
            {"label": "Al2O3-SiC",    "H_ratio": 1.05, "K_ratio": 1.45},
            {"label": "SiC-TiB2",     "H_ratio": 1.10, "K_ratio": 1.30},
            {"label": "SiO2-graphene","H_ratio": 0.90, "K_ratio": 1.55},
            {"label": "ZrC-Mo",       "H_ratio": 1.35, "K_ratio": 1.20},
            {"label": "ZrB2-SiC",     "H_ratio": 1.40, "K_ratio": 1.10},
            {"label": "WC-ZrC",       "H_ratio": 1.65, "K_ratio": 1.05},
            {"label": "TaC-Si3N4",    "H_ratio": 1.30, "K_ratio": 1.15},
        ]
    fig, ax = plt.subplots(figsize=(6.5, 5.2))
    H_grid = np.linspace(0.4, 2.4, 200)
    for c in (1, 2, 4, 8):
        ax.plot(H_grid, c / H_grid, "k--", lw=0.8, alpha=0.6)
        ax.text(H_grid[-1], c / H_grid[-1], f"=  {c}", fontsize=8)
    for p in literature_points:
        ax.scatter(p["H_ratio"], p["K_ratio"],
                   s=40, color="gray", alpha=0.7)
        ax.annotate(p["label"],
                    (p["H_ratio"], p["K_ratio"]),
                    xytext=(2, 2), textcoords="offset points", fontsize=8)
    ax.scatter([film_H_ratio], [film_K_ratio],
               s=140, marker="*", color="red", zorder=10,
               label="SiOC-WOx")
    ax.set_xlim(0.4, 2.6); ax.set_ylim(0.5, 4.5)
    ax.set_xlabel("H / H_matrix")
    ax.set_ylabel("K_IC / K_IC_matrix")
    ax.set_title("Stiffness-toughness enhancement chart")
    ax.legend(loc="upper right")
    fig.tight_layout()
    _ensure_dir(output_path)
    fig.savefig(output_path, dpi=140, bbox_inches="tight")
    plt.close(fig)
    return {"output_path": output_path,
            "film_index": round(film_H_ratio * film_K_ratio, 4),
            "n_literature_points": len(literature_points)}


if __name__ == "__main__":
    mcp.run(transport="stdio")

# mat_fe10 tools

FastMCP tool servers for the Automatic Feature Engineering (AFE) catalyst
task.

## Layout

| File | Purpose |
|------|---------|
| `afe_tools.py`         | Domain-specific primitives: composition parsing, XenonPy property lookup, commutative aggregations, nonlinear transforms, Huber + LOOCV scorer, GA building blocks, FPS, t-SNE, plotters. |
| `data_processing.py`   | Generic CSV / JSON / tabular helpers (read_csv, join_tables, groupby_aggregate, ...). |
| `database_retrieval.py`| Stub registry of external-database queries (websearch, fetch_url, query_*). Heavy bodies intentionally left as `pass`; fill in at runtime only if actually needed. |

## Design notes

* **Low-level primitives only.** There is deliberately no one-shot
  `generate_all_5568_features()` function. The agent must choose which of the
  paper's eight commutative operations
  (`max/min/wsum/wavg/wssd/wvar/wprod/gmean` = maximum, minimum, weighted sum,
  weighted average, weighted sum of squared distance, weighted average squared
  distance, weighted product, weighted geometric mean) and which of 12
  nonlinear transforms (`identity/inv/sqrt/inv_sqrt/sq/inv_sq/cube/inv_cube/
  ln/inv_ln/exp/inv_exp`) to compose, and must drive the GA loop itself
  (`ga_random_population` → score with `huber_loocv_mae` →
  `ga_crossover_mutate` → repeat). Eight ops × 58 XenonPy properties = **464
  primary features**; × 12 transforms = **5,568 first-order features** (these
  counts reproduce exactly on the bundled data).
* **Dataset cleaning.** `clean_catalyst_dataset` drops empty-target rows and
  collapses duplicate catalyst names (the OCM CSV has 171 rows; four names
  recur — Ca-W, Mg-Pd-Ce, Pd-W-W, Sr-Zr-La — leaving **167** unique modelable
  catalysts after keeping the maximum C2 yield per name).
* **Huber + LOOCV** is the paper's scoring target; `epsilon` defaults to
  1.00. Features are standardized (StandardScaler) inside the scorer to keep
  the scale-sensitive Huber solver convergent; subsets that still fail to
  converge return an `error` key rather than raising.
* **No precomputed-feature shortcut.** Although the paper's public repo
  ships `*_dataset_with_1st_order_features.csv` with 3300 features already
  expanded, that file is NOT included in this task's `input_data/`. The
  agent must rebuild features from `xenonpy_normalized.csv` and the three
  composition CSVs.
* **Plotters.** The reproducible deliverable is the parity figure:
  * `plot_parity` → `Fig1_AFE_regression.png` (the only bundled answer image).
  * `plot_active_learning_scores`, `plot_tsne_yield_map` (per-cycle: pass a
    distinct `cycle` index so successive calls do not overwrite the same PNG)
    and `plot_discovery_bars` remain available, but the active-learning cycle
    splits, the farthest-point-sampling recommendation list and the HTE
    observations are NOT bundled, so the active-learning evolution and the
    discovery results are paper-only ([PAPER]) and are not scored figures.

## Python dependencies

```
numpy
pandas
scikit-learn
matplotlib
mcp  # FastMCP server
```

Install with:
```bash
pip install numpy pandas scikit-learn matplotlib mcp
```

## How to run

Each file is an MCP server:

```bash
python tools/afe_tools.py          # stdio transport
```

Or import directly in a notebook/test for offline debugging — every
decorated function remains a plain callable.

# MetaboGNN Benchmark Summary — Park et al. 2025 J. Cheminform.

## Background and data

The bundle contains the 2023 South Korea Data Challenge for Drug Discovery
liver-microsome stability subset used in Park et al. 2025: 3,498 training
and 483 evaluation molecules with measured percent-parent-remaining after
30-min incubation with human (HLM) and mouse (MLM) liver microsomes plus
seven 2D descriptors. The paper introduces MetaboGNN — a graph neural
network with graph contrastive pre-training and an explicit
interspecies-difference auxiliary task — and benchmarks it against the
prior published methods MS-BACL [Sun 2024] and PredMS [Ryu 2022].

## Paper-cited headline numbers (verbatim, Park 2025 Tab.1-3, p.3-7)

| Quantity | MetaboGNN (GCL + Interspecies Diff.) | MS-BACL | PredMS |
| --- | --- | --- | --- |
| HLM RMSE (Tab.2)        | 27.91 (95% CI 27.76-28.06) | — | — |
| MLM RMSE (Tab.2)        | 27.86 (27.69-28.03)        | — | — |
| AUROC (Tab.3)           | 0.8137 (0.7813-0.8476)     | 0.7892 (0.7561-0.8207) | 0.7425 (0.7049-0.7775) |
| AUPRC (Tab.3)           | 0.8536 (0.8162-0.8894)     | 0.8434 (0.8071-0.8769) | 0.8094 (0.7672-0.8487) |
| Accuracy (Tab.3)        | 0.7474 (0.7101-0.7888)     | 0.7164 (0.6770-0.7557) | 0.6915 (0.6460-0.7288) |
| MCC (Tab.3)             | **0.4781** (0.4002-0.5593) | 0.4155 (0.3353-0.4957) | 0.3425 (0.2543-0.4218) |

MetaboGNN (GCL + Interspecies Difference) is the top performer on every
classification metric. Adding the interspecies-difference auxiliary task
to the same MetaboGNN (GCL) backbone improves HLM RMSE from 30.14 to
27.91 and MLM RMSE from 28.72 to 27.86 (Tab.1 vs Tab.2). Pearson
r(HLM, MLM) = 0.71 across the 3,498 training molecules (Park 2025 p.3)
indicates substantial shared enzymatic activity between species; LogD
and AlogP correlate most strongly with absolute stability (Fig.1d).
The HLM-MLM interspecies *difference* shows negligible correlation
with LogD (r = -0.01) and AlogP (r = -0.03) per page-3 text, which
the paper interprets as enzyme-specific (not passive ADMET-driven)
residual variability.

All paper-cited values above are mirrored verbatim in
`input_data/data/paper_fig3_tab3_reference.json` for direct programmatic
audit.

## Bundled-data baseline (recomputable from the bundle)

A descriptor-free Morgan-RF baseline (radius=2, n_bits=2048,
n_estimators=200, seed=42) trained on the 3,498-molecule train CSV and
evaluated on the 483-molecule HLM test CSV at the 50%-remaining stable
threshold yields:

| Metric | Morgan-RF baseline (this bundle) |
| --- | --- |
| AUROC | 0.7162 |
| AUPRC | 0.7731 |
| Accuracy | 0.6708 |
| MCC | 0.3055 |

Per-molecule predictions are saved to
`artifacts/baseline_morgan_rf_hlm_predictions.csv`. This baseline is
**below every paper method on every metric** (the paper's main result
is precisely that MetaboGNN's GCL pretraining + interspecies-difference
task outperforms simple molecular fingerprints + a vanilla regressor),
so the bundled baseline corroborates the paper's qualitative ordering
without claiming to reproduce MetaboGNN's exact numbers.

The Tab.3 reference numbers above and the bundled Morgan-RF baseline
metrics are mirrored together in
`input_data/data/paper_fig3_tab3_reference.json` under the keys
`models.*` and `bundled_baseline_morgan_rf_hlm_test`, respectively.

## Figures

1. `artifacts/Fig1_data_EDA.png` — KDE/distribution plots of HLM, MLM,
   HLM-MLM, and the seven molecular descriptors for the 3,498 training
   compounds, matching paper Fig.1a-d.
2. `artifacts/Fig3_ROC_PR_comparison.png` — bundled Morgan-RF baseline
   ROC and Precision-Recall curves (data-derived from
   `artifacts/baseline_morgan_rf_hlm_predictions.csv`) overlaid with
   horizontal reference lines at the paper Tab.3 AUROC and AUPRC values
   for MetaboGNN, MS-BACL, and PredMS (whose per-molecule scores are
   not published and therefore appear only as reference levels).

## Conclusions

1. Adding the interspecies-difference auxiliary task to the MetaboGNN
   GCL backbone improves HLM RMSE from 30.14 to 27.91 and MLM RMSE
   from 28.72 to 27.86 (Park 2025 Tab.1 vs Tab.2).
2. On binary stability classification at 50% remaining, MetaboGNN's
   AUROC 0.8137, AUPRC 0.8536, and MCC 0.4781 (Tab.3) exceed both
   prior baselines MS-BACL (0.7892 / 0.8434 / 0.4155) and PredMS
   (0.7425 / 0.8094 / 0.3425).
3. A descriptor-free Morgan-RF baseline on the bundled train/test
   split underperforms every paper method (AUROC 0.7162, MCC 0.3055),
   corroborating the paper's qualitative claim that simple Morgan
   fingerprints + a vanilla regressor leave headroom for GCL-pretrained
   graph models with explicit interspecies-difference modelling.

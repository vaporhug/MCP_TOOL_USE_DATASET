"""Database retrieval helpers — quarantined for the LOCAL-ONLY paper-summary task.

The paper-summary task uses only the bundled train_paper.csv / test_paper.csv
and the reference PDFs. External-database lookups are not required and would
violate the task's no-network scope. Each function below ships as a stub
that raises NotImplementedError; the docstrings record provenance / intended
semantics for downstream tasks that may want to re-enable them.
"""
from typing import Any


def _disabled(label: str) -> None:
    raise NotImplementedError(
        f"Network helper '{label}' is intentionally disabled for the "
        f"local-only mat_ms34 paper-summary task. All required data is "
        f"bundled in input_data/data/."
    )


def websearch(query: str, max_results: int = 10) -> list[dict]:
    """[DISABLED for local-only task.] Generic web search.

    Original intent: locate a dataset DOI, find a paper's supplementary URL,
    or resolve an ambiguous reference. Returns a list of {title, url, snippet}
    dicts when enabled.
    """
    _disabled("websearch")


def fetch_url(url: str, timeout: int = 30) -> bytes:
    """[DISABLED for local-only task.] HTTP GET with redirects."""
    _disabled("fetch_url")


def query_pubchem(identifier: str, namespace: str = "cid") -> dict:
    """[DISABLED for local-only task.] PubChem PUG-REST lookup.
    namespace in {cid, name, smiles, inchikey}.
    """
    _disabled("query_pubchem")


def query_chembl(target_id: str, activity_type: str = "IC50") -> list[dict]:
    """[DISABLED for local-only task.] ChEMBL bioactivity query."""
    _disabled("query_chembl")


def query_uniprot(accession: str) -> dict:
    """[DISABLED for local-only task.] UniProt entry fetch."""
    _disabled("query_uniprot")


def query_pdb(pdb_id: str) -> dict:
    """[DISABLED for local-only task.] RCSB PDB entry metadata."""
    _disabled("query_pdb")


def query_geo(accession: str) -> dict:
    """[DISABLED for local-only task.] NCBI GEO entry fetch."""
    _disabled("query_geo")

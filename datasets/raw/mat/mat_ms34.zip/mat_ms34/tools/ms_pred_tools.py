#!/usr/bin/env python3
"""Low-level molecular ML primitives for metabolic-stability prediction.

Functions are intentionally narrow-scope:
- SMILES parsing / sanity checks
- Morgan fingerprints, topological descriptors (per molecule)
- Train regressors (RF / Ridge / MLP / message-passing-GNN baseline)
- Evaluate (RMSE / MAE / R^2 / classification @ threshold / AUROC / AUPRC / MCC)
- Plot helpers (parity, ROC, PR, bar charts)

No domain logic about which features to use, which threshold to apply, or how
to interpret outputs is encoded here — the agent must compose calls.
"""

from __future__ import annotations
import os
import json
import pickle
import hashlib
from typing import Optional

import numpy as np
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("MS_Pred_Tools")


# ---------------------------------------------------------------------------
# 1. SMILES / molecule primitives
# ---------------------------------------------------------------------------
@mcp.tool()
def smiles_validate(smiles_list: list) -> dict:
    """Parse each SMILES with RDKit; report which ones are valid.

    Args:
        smiles_list: list of SMILES strings.
    Returns:
        dict with valid_indices, invalid_indices, n_total, n_valid.
    """
    from rdkit import Chem
    from rdkit import RDLogger
    RDLogger.DisableLog("rdApp.*")
    valid, invalid = [], []
    for i, s in enumerate(smiles_list):
        m = Chem.MolFromSmiles(s) if isinstance(s, str) else None
        (valid if m is not None else invalid).append(i)
    return {"n_total": len(smiles_list), "n_valid": len(valid),
            "valid_indices": valid, "invalid_indices": invalid}


@mcp.tool()
def smiles_to_morgan(smiles_list: list, radius: int = 2,
                     n_bits: int = 2048) -> dict:
    """Compute Morgan (ECFP-like) fingerprints for a list of SMILES.

    Args:
        smiles_list: SMILES strings.
        radius: Morgan radius (e.g., 2 = ECFP4).
        n_bits: bit-vector length.
    Returns:
        dict with key 'fp_path' pointing to a pickled (N, n_bits) uint8 array,
        plus n_molecules and n_failed (failed rows are filled with zeros).
    """
    from rdkit import Chem
    from rdkit.Chem import AllChem
    from rdkit import RDLogger
    RDLogger.DisableLog("rdApp.*")
    fps = np.zeros((len(smiles_list), n_bits), dtype=np.uint8)
    n_failed = 0
    for i, s in enumerate(smiles_list):
        m = Chem.MolFromSmiles(s) if isinstance(s, str) else None
        if m is None:
            n_failed += 1
            continue
        bv = AllChem.GetMorganFingerprintAsBitVect(m, radius, nBits=n_bits)
        on = list(bv.GetOnBits())
        fps[i, on] = 1
    h = hashlib.md5(fps.tobytes()).hexdigest()[:10]
    out = f"/tmp/morgan_{h}.npy"
    np.save(out, fps)
    return {"fp_path": out, "shape": list(fps.shape),
            "n_molecules": len(smiles_list), "n_failed": n_failed,
            "radius": radius, "n_bits": n_bits}


@mcp.tool()
def smiles_descriptors(smiles_list: list,
                       names: Optional[list] = None) -> dict:
    """Compute classic 2D RDKit descriptors per molecule.

    Args:
        smiles_list: SMILES strings.
        names: optional subset of descriptor names. If None, returns a curated
            set (MolWt, MolLogP, TPSA, NumHBA, NumHBD, NumRotatableBonds,
            NumAromaticRings, FractionCSP3, NumHeavyAtoms, RingCount).
    Returns:
        dict with 'rows' (list-of-dicts, one per molecule) and 'descriptor_names'.
    """
    from rdkit import Chem
    from rdkit.Chem import Descriptors, Lipinski, rdMolDescriptors
    from rdkit import RDLogger
    RDLogger.DisableLog("rdApp.*")

    catalog = {
        "MolWt": Descriptors.MolWt,
        "MolLogP": Descriptors.MolLogP,
        "TPSA": Descriptors.TPSA,
        "NumHBA": Lipinski.NumHAcceptors,
        "NumHBD": Lipinski.NumHDonors,
        "NumRotatableBonds": Lipinski.NumRotatableBonds,
        "NumAromaticRings": Lipinski.NumAromaticRings,
        "FractionCSP3": Lipinski.FractionCSP3,
        "NumHeavyAtoms": Lipinski.HeavyAtomCount,
        "RingCount": Lipinski.RingCount,
    }
    if names is None:
        names = list(catalog.keys())
    rows = []
    for s in smiles_list:
        m = Chem.MolFromSmiles(s) if isinstance(s, str) else None
        row = {}
        for n in names:
            if m is None or n not in catalog:
                row[n] = None
            else:
                try:
                    row[n] = round(float(catalog[n](m)), 4)
                except Exception:
                    row[n] = None
        rows.append(row)
    return {"rows": rows, "descriptor_names": names,
            "n_molecules": len(rows)}


@mcp.tool()
def smiles_to_graph(smiles: str) -> dict:
    """Convert one SMILES into a node/edge list usable by a GNN.

    Atom features: [atomic_num, degree, formal_charge, hybridisation_idx,
    aromatic, n_H, in_ring]. Bond features: [bond_type_idx (1/2/3/4),
    conjugated, in_ring].

    Returns:
        dict with 'atoms' (N x 7 list), 'bonds' (E x 4 list of [u, v, ...]),
        'n_atoms', 'n_bonds'.
    """
    from rdkit import Chem
    m = Chem.MolFromSmiles(smiles)
    if m is None:
        return {"error": "invalid SMILES"}
    hybrid_map = {Chem.HybridizationType.SP: 1, Chem.HybridizationType.SP2: 2,
                  Chem.HybridizationType.SP3: 3, Chem.HybridizationType.SP3D: 4,
                  Chem.HybridizationType.SP3D2: 5}
    bond_map = {Chem.BondType.SINGLE: 1, Chem.BondType.DOUBLE: 2,
                Chem.BondType.TRIPLE: 3, Chem.BondType.AROMATIC: 4}
    atoms = []
    for a in m.GetAtoms():
        atoms.append([a.GetAtomicNum(), a.GetDegree(), a.GetFormalCharge(),
                      hybrid_map.get(a.GetHybridization(), 0),
                      int(a.GetIsAromatic()), a.GetTotalNumHs(),
                      int(a.IsInRing())])
    bonds = []
    for b in m.GetBonds():
        u, v = b.GetBeginAtomIdx(), b.GetEndAtomIdx()
        bt = bond_map.get(b.GetBondType(), 0)
        feat = [bt, int(b.GetIsConjugated()), int(b.IsInRing())]
        bonds.append([u, v, *feat])
        bonds.append([v, u, *feat])
    return {"atoms": atoms, "bonds": bonds,
            "n_atoms": len(atoms), "n_bonds": len(bonds) // 2}


# ---------------------------------------------------------------------------
# 2. Train / predict (tabular models)
# ---------------------------------------------------------------------------
@mcp.tool()
def train_regressor(X_train_path: str, y_train: list,
                    X_val_path: Optional[str] = None,
                    y_val: Optional[list] = None,
                    model_type: str = "random_forest",
                    model_params: Optional[dict] = None,
                    seed: int = 0) -> dict:
    """Train a tabular regressor on pre-computed feature matrices.

    Args:
        X_train_path: path to a .npy file with shape (N, F).
        y_train: list of regression targets, length N.
        X_val_path: optional .npy for early-stopping/validation.
        y_val: matching validation targets.
        model_type: 'random_forest' | 'ridge' | 'mlp' | 'xgboost' | 'svr'.
        model_params: hyper-parameter overrides.
        seed: random_state.
    Returns:
        dict with model_id (use in `predict_regressor`).
    """
    X = np.load(X_train_path)
    y = np.array(y_train, dtype=float)
    Xv = np.load(X_val_path) if X_val_path else None
    yv = np.array(y_val, dtype=float) if y_val is not None else None
    p = model_params or {}

    if model_type == "random_forest":
        from sklearn.ensemble import RandomForestRegressor
        m = RandomForestRegressor(**({"n_estimators": 300, "n_jobs": -1,
                                       "random_state": seed, **p}))
        m.fit(X, y)
    elif model_type == "ridge":
        from sklearn.linear_model import Ridge
        m = Ridge(**({"alpha": 1.0, **p})); m.fit(X, y)
    elif model_type == "mlp":
        from sklearn.neural_network import MLPRegressor
        m = MLPRegressor(**({"hidden_layer_sizes": (256, 128),
                             "max_iter": 300, "random_state": seed, **p}))
        m.fit(X, y)
    elif model_type == "xgboost":
        import xgboost
        dp = {"n_estimators": 500, "learning_rate": 0.05, "max_depth": 6,
              "verbosity": 0, "random_state": seed}; dp.update(p)
        m = xgboost.XGBRegressor(**dp)
        if Xv is not None and yv is not None:
            m.fit(X, y, eval_set=[(Xv, yv)], verbose=False)
        else:
            m.fit(X, y)
    elif model_type == "svr":
        from sklearn.svm import SVR
        m = SVR(**({"kernel": "rbf", "C": 1.0, **p})); m.fit(X, y)
    else:
        return {"error": f"unknown model_type={model_type}"}

    blob = pickle.dumps({"model": m, "model_type": model_type})
    mid = hashlib.md5(blob[:4096]).hexdigest()[:10]
    with open(f"/tmp/regr_{mid}.pkl", "wb") as f:
        f.write(blob)
    return {"model_id": mid, "model_type": model_type,
            "n_train": int(len(y)),
            "n_val": int(0 if yv is None else len(yv))}


@mcp.tool()
def predict_regressor(model_id: str, X_test_path: str) -> dict:
    """Run a trained regressor on a feature matrix; return raw predictions."""
    with open(f"/tmp/regr_{model_id}.pkl", "rb") as f:
        st = pickle.load(f)
    X = np.load(X_test_path)
    pred = np.asarray(st["model"].predict(X)).ravel()
    return {"model_id": model_id, "n": int(len(pred)),
            "predictions": [round(float(v), 6) for v in pred]}


# ---------------------------------------------------------------------------
# 3. Minimal Message-Passing GNN baseline (PyTorch)
# ---------------------------------------------------------------------------
@mcp.tool()
def train_gnn_baseline(smiles_train: list, y_train: list,
                       smiles_val: Optional[list] = None,
                       y_val: Optional[list] = None,
                       hidden: int = 64, n_layers: int = 3,
                       epochs: int = 30, lr: float = 1e-3,
                       batch_size: int = 64, seed: int = 0) -> dict:
    """Train a small GIN-style message-passing GNN on molecular graphs.

    This is a *baseline* — not the published MetaboGNN architecture. It exists
    so an agent can verify that graph-based learning works on the dataset and
    obtain a comparison number against descriptor models.
    """
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    from rdkit import Chem
    from rdkit import RDLogger
    RDLogger.DisableLog("rdApp.*")

    torch.manual_seed(seed); np.random.seed(seed)

    def featurize(smi):
        m = Chem.MolFromSmiles(smi)
        if m is None: return None
        N = m.GetNumAtoms()
        if N == 0: return None
        x = np.zeros((N, 7), dtype=np.float32)
        for i, a in enumerate(m.GetAtoms()):
            x[i] = [a.GetAtomicNum(), a.GetDegree(), a.GetFormalCharge(),
                    int(a.GetHybridization()), int(a.GetIsAromatic()),
                    a.GetTotalNumHs(), int(a.IsInRing())]
        edges = []
        for b in m.GetBonds():
            u, v = b.GetBeginAtomIdx(), b.GetEndAtomIdx()
            edges.append([u, v]); edges.append([v, u])
        if not edges: edges = [[0, 0]]
        return x, np.array(edges, dtype=np.int64).T

    def collate(batch):
        xs, edges, batch_idx, ys = [], [], [], []
        offset = 0
        for k, (x, e, y) in enumerate(batch):
            xs.append(x)
            edges.append(e + offset)
            batch_idx.append(np.full(x.shape[0], k, dtype=np.int64))
            ys.append(y); offset += x.shape[0]
        x = torch.from_numpy(np.concatenate(xs, 0))
        e = torch.from_numpy(np.concatenate(edges, 1))
        b = torch.from_numpy(np.concatenate(batch_idx, 0))
        y = torch.tensor(ys, dtype=torch.float32)
        return x, e, b, y

    class GINLayer(nn.Module):
        def __init__(self, dim):
            super().__init__()
            self.mlp = nn.Sequential(nn.Linear(dim, dim), nn.ReLU(),
                                     nn.Linear(dim, dim))
            self.eps = nn.Parameter(torch.zeros(1))
        def forward(self, x, edge_index):
            src, dst = edge_index[0], edge_index[1]
            agg = torch.zeros_like(x)
            agg.index_add_(0, dst, x[src])
            return self.mlp((1 + self.eps) * x + agg)

    class GNN(nn.Module):
        def __init__(self, in_dim=7, hid=hidden, n=n_layers):
            super().__init__()
            self.lin0 = nn.Linear(in_dim, hid)
            self.layers = nn.ModuleList([GINLayer(hid) for _ in range(n)])
            self.head = nn.Sequential(nn.Linear(hid, hid), nn.ReLU(),
                                      nn.Linear(hid, 1))
        def forward(self, x, edge_index, batch_idx):
            h = F.relu(self.lin0(x))
            for L in self.layers: h = F.relu(L(h, edge_index))
            n_graphs = int(batch_idx.max().item()) + 1
            pooled = torch.zeros(n_graphs, h.shape[1], device=h.device)
            pooled.index_add_(0, batch_idx, h)
            counts = torch.zeros(n_graphs, 1, device=h.device)
            counts.index_add_(0, batch_idx, torch.ones(h.shape[0], 1,
                                                       device=h.device))
            pooled = pooled / counts.clamp(min=1)
            return self.head(pooled).squeeze(-1)

    train_data = []
    for s, y in zip(smiles_train, y_train):
        f = featurize(s)
        if f is not None: train_data.append((f[0], f[1], float(y)))
    if not train_data:
        return {"error": "no valid molecules in train set"}

    val_data = None
    if smiles_val is not None and y_val is not None:
        val_data = []
        for s, y in zip(smiles_val, y_val):
            f = featurize(s)
            if f is not None: val_data.append((f[0], f[1], float(y)))

    model = GNN()
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    history = []
    n = len(train_data)
    for ep in range(epochs):
        model.train()
        idx = np.random.permutation(n)
        tot = 0.0
        for i0 in range(0, n, batch_size):
            batch = [train_data[j] for j in idx[i0:i0+batch_size]]
            x, e, b, y = collate(batch)
            pred = model(x, e, b)
            loss = F.mse_loss(pred, y)
            opt.zero_grad(); loss.backward(); opt.step()
            tot += float(loss.item()) * len(batch)
        train_mse = tot / n
        val_rmse = None
        if val_data:
            model.eval()
            with torch.no_grad():
                preds, ys = [], []
                for i0 in range(0, len(val_data), batch_size):
                    x, e, b, y = collate(val_data[i0:i0+batch_size])
                    preds.append(model(x, e, b).numpy()); ys.append(y.numpy())
                p = np.concatenate(preds); yy = np.concatenate(ys)
                val_rmse = float(np.sqrt(((p - yy) ** 2).mean()))
        history.append({"epoch": ep, "train_mse": round(train_mse, 4),
                        "val_rmse": None if val_rmse is None else round(val_rmse, 4)})

    blob = pickle.dumps(model.state_dict())
    mid = hashlib.md5(blob[:4096]).hexdigest()[:10]
    torch.save({"state_dict": model.state_dict(),
                "hidden": hidden, "n_layers": n_layers},
               f"/tmp/gnn_{mid}.pt")
    return {"model_id": mid, "model_type": "gnn_gin",
            "n_train": len(train_data),
            "n_val": 0 if val_data is None else len(val_data),
            "history": history}


@mcp.tool()
def predict_gnn_baseline(model_id: str, smiles_list: list) -> dict:
    """Run the GIN baseline on a list of SMILES."""
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    from rdkit import Chem
    from rdkit import RDLogger
    RDLogger.DisableLog("rdApp.*")

    ckpt = torch.load(f"/tmp/gnn_{model_id}.pt", map_location="cpu",
                      weights_only=False)
    hidden = ckpt["hidden"]; n_layers = ckpt["n_layers"]

    class GINLayer(nn.Module):
        def __init__(self, dim):
            super().__init__()
            self.mlp = nn.Sequential(nn.Linear(dim, dim), nn.ReLU(),
                                     nn.Linear(dim, dim))
            self.eps = nn.Parameter(torch.zeros(1))
        def forward(self, x, edge_index):
            src, dst = edge_index[0], edge_index[1]
            agg = torch.zeros_like(x); agg.index_add_(0, dst, x[src])
            return self.mlp((1 + self.eps) * x + agg)

    class GNN(nn.Module):
        def __init__(self):
            super().__init__()
            self.lin0 = nn.Linear(7, hidden)
            self.layers = nn.ModuleList([GINLayer(hidden) for _ in range(n_layers)])
            self.head = nn.Sequential(nn.Linear(hidden, hidden), nn.ReLU(),
                                      nn.Linear(hidden, 1))
        def forward(self, x, edge_index, batch_idx):
            h = F.relu(self.lin0(x))
            for L in self.layers: h = F.relu(L(h, edge_index))
            n_graphs = int(batch_idx.max().item()) + 1
            pooled = torch.zeros(n_graphs, h.shape[1])
            pooled.index_add_(0, batch_idx, h)
            counts = torch.zeros(n_graphs, 1)
            counts.index_add_(0, batch_idx, torch.ones(h.shape[0], 1))
            return self.head(pooled / counts.clamp(min=1)).squeeze(-1)

    model = GNN(); model.load_state_dict(ckpt["state_dict"]); model.eval()

    preds, valid_idx = [], []
    for i, s in enumerate(smiles_list):
        m = Chem.MolFromSmiles(s) if isinstance(s, str) else None
        if m is None or m.GetNumAtoms() == 0:
            preds.append(float("nan")); continue
        x = np.zeros((m.GetNumAtoms(), 7), dtype=np.float32)
        for j, a in enumerate(m.GetAtoms()):
            x[j] = [a.GetAtomicNum(), a.GetDegree(), a.GetFormalCharge(),
                    int(a.GetHybridization()), int(a.GetIsAromatic()),
                    a.GetTotalNumHs(), int(a.IsInRing())]
        edges = []
        for b in m.GetBonds():
            u, v = b.GetBeginAtomIdx(), b.GetEndAtomIdx()
            edges.append([u, v]); edges.append([v, u])
        if not edges: edges = [[0, 0]]
        e = np.array(edges, dtype=np.int64).T
        with torch.no_grad():
            p = model(torch.from_numpy(x), torch.from_numpy(e),
                      torch.zeros(x.shape[0], dtype=torch.long)).item()
        preds.append(round(float(p), 6)); valid_idx.append(i)
    return {"model_id": model_id, "n": len(preds),
            "predictions": preds, "valid_indices": valid_idx}


# ---------------------------------------------------------------------------
# 4. Metrics
# ---------------------------------------------------------------------------
@mcp.tool()
def regression_metrics(predictions: list, true_values: list) -> dict:
    """Compute RMSE / MAE / R^2 / Pearson r between two equal-length lists."""
    from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
    p = np.asarray(predictions, dtype=float)
    y = np.asarray(true_values, dtype=float)
    mask = np.isfinite(p) & np.isfinite(y)
    p, y = p[mask], y[mask]
    if len(y) < 2:
        return {"error": "fewer than 2 paired values"}
    pearson = float(np.corrcoef(p, y)[0, 1])
    return {"n": int(len(y)),
            "rmse": round(float(np.sqrt(mean_squared_error(y, p))), 4),
            "mae": round(float(mean_absolute_error(y, p)), 4),
            "r2": round(float(r2_score(y, p)), 4),
            "pearson_r": round(pearson, 4)}


@mcp.tool()
def classification_at_threshold(predictions: list, true_values: list,
                                 threshold: float = 50.0) -> dict:
    """Binarise both predictions and labels at `threshold` (>= -> stable=1).

    Returns Accuracy, Precision, Recall, F1, MCC, AUROC (using raw preds),
    AUPRC.
    """
    from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                                  f1_score, matthews_corrcoef,
                                  roc_auc_score, average_precision_score)
    p = np.asarray(predictions, dtype=float)
    y = np.asarray(true_values, dtype=float)
    mask = np.isfinite(p) & np.isfinite(y)
    p, y = p[mask], y[mask]
    yb = (y >= threshold).astype(int)
    pb = (p >= threshold).astype(int)
    out = {"n": int(len(y)), "threshold": threshold,
           "n_positive": int(yb.sum()), "n_negative": int((1 - yb).sum()),
           "accuracy": round(float(accuracy_score(yb, pb)), 4),
           "precision": round(float(precision_score(yb, pb, zero_division=0)), 4),
           "recall": round(float(recall_score(yb, pb, zero_division=0)), 4),
           "f1": round(float(f1_score(yb, pb, zero_division=0)), 4),
           "mcc": round(float(matthews_corrcoef(yb, pb)) if len(set(pb)) > 1 else 0, 4)}
    try:
        out["auroc"] = round(float(roc_auc_score(yb, p)), 4)
        out["auprc"] = round(float(average_precision_score(yb, p)), 4)
    except ValueError:
        out["auroc"] = None; out["auprc"] = None
    return out


@mcp.tool()
def bootstrap_metric(predictions: list, true_values: list,
                     metric: str = "rmse", threshold: float = 50.0,
                     n_boot: int = 1000, seed: int = 0,
                     ci: float = 0.95) -> dict:
    """Bootstrap CI for one metric ('rmse','mae','r2','accuracy','auroc','mcc')."""
    from sklearn.metrics import (mean_squared_error, mean_absolute_error,
                                  r2_score, accuracy_score, roc_auc_score,
                                  matthews_corrcoef)
    rng = np.random.RandomState(seed)
    p = np.asarray(predictions, dtype=float)
    y = np.asarray(true_values, dtype=float)
    mask = np.isfinite(p) & np.isfinite(y); p, y = p[mask], y[mask]
    n = len(y)
    vals = []
    for _ in range(n_boot):
        idx = rng.randint(0, n, n)
        pp, yy = p[idx], y[idx]
        if metric == "rmse":
            vals.append(np.sqrt(mean_squared_error(yy, pp)))
        elif metric == "mae":
            vals.append(mean_absolute_error(yy, pp))
        elif metric == "r2":
            vals.append(r2_score(yy, pp))
        elif metric == "accuracy":
            vals.append(accuracy_score((yy >= threshold).astype(int),
                                        (pp >= threshold).astype(int)))
        elif metric == "auroc":
            yb = (yy >= threshold).astype(int)
            if yb.sum() == 0 or yb.sum() == len(yb): continue
            vals.append(roc_auc_score(yb, pp))
        elif metric == "mcc":
            yb = (yy >= threshold).astype(int)
            pb = (pp >= threshold).astype(int)
            if len(set(pb)) < 2: continue
            vals.append(matthews_corrcoef(yb, pb))
        else:
            return {"error": f"unknown metric {metric}"}
    arr = np.asarray(vals)
    lo = float(np.quantile(arr, (1 - ci) / 2))
    hi = float(np.quantile(arr, 1 - (1 - ci) / 2))
    return {"metric": metric, "n_boot": int(len(arr)),
            "mean": round(float(arr.mean()), 4),
            "ci_lower": round(lo, 4), "ci_upper": round(hi, 4),
            "ci_level": ci}


# ---------------------------------------------------------------------------
# 5. Plotting helpers
# ---------------------------------------------------------------------------
@mcp.tool()
def plot_parity(predictions: list, true_values: list,
                output_path: str = "artifacts/parity.png",
                title: str = "Predicted vs True") -> dict:
    """Scatter of predicted vs true with y=x line."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    p = np.asarray(predictions); y = np.asarray(true_values)
    mask = np.isfinite(p) & np.isfinite(y); p, y = p[mask], y[mask]
    fig, ax = plt.subplots(figsize=(6, 6))
    ax.scatter(y, p, s=10, alpha=0.4)
    lo = float(min(y.min(), p.min())); hi = float(max(y.max(), p.max()))
    ax.plot([lo, hi], [lo, hi], "k--", lw=1)
    ax.set_xlabel("True"); ax.set_ylabel("Predicted"); ax.set_title(title)
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.tight_layout(); fig.savefig(output_path, dpi=150); plt.close(fig)
    return {"output_path": output_path, "n_points": int(len(y))}


@mcp.tool()
def plot_roc_pr(predictions: list, true_values: list,
                threshold: float = 50.0,
                output_path: str = "artifacts/roc_pr.png") -> dict:
    """Combined ROC + Precision-Recall curve panel."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from sklearn.metrics import (roc_curve, precision_recall_curve,
                                  roc_auc_score, average_precision_score)
    p = np.asarray(predictions, dtype=float)
    y = np.asarray(true_values, dtype=float)
    mask = np.isfinite(p) & np.isfinite(y); p, y = p[mask], y[mask]
    yb = (y >= threshold).astype(int)
    fpr, tpr, _ = roc_curve(yb, p)
    pr, rc, _ = precision_recall_curve(yb, p)
    auroc = roc_auc_score(yb, p); auprc = average_precision_score(yb, p)
    fig, axes = plt.subplots(1, 2, figsize=(11, 5))
    axes[0].plot(fpr, tpr, label=f"AUROC={auroc:.3f}")
    axes[0].plot([0, 1], [0, 1], "k--", lw=1, alpha=0.5)
    axes[0].set_xlabel("FPR"); axes[0].set_ylabel("TPR"); axes[0].set_title("ROC")
    axes[0].legend()
    axes[1].plot(rc, pr, label=f"AUPRC={auprc:.3f}")
    axes[1].set_xlabel("Recall"); axes[1].set_ylabel("Precision")
    axes[1].set_title("PR"); axes[1].legend()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.tight_layout(); fig.savefig(output_path, dpi=150); plt.close(fig)
    return {"output_path": output_path,
            "auroc": round(float(auroc), 4),
            "auprc": round(float(auprc), 4)}


@mcp.tool()
def plot_bar_compare(labels: list, values: list,
                     errors: Optional[list] = None,
                     output_path: str = "artifacts/bar.png",
                     ylabel: str = "value", title: str = "") -> dict:
    """Simple bar chart with optional error bars."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(max(4, 0.7 * len(labels) + 1), 4))
    xs = np.arange(len(labels))
    ax.bar(xs, values, yerr=errors, capsize=4, color="steelblue",
           edgecolor="black")
    ax.set_xticks(xs); ax.set_xticklabels(labels, rotation=30, ha="right")
    ax.set_ylabel(ylabel); ax.set_title(title)
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.tight_layout(); fig.savefig(output_path, dpi=150); plt.close(fig)
    return {"output_path": output_path, "n_bars": len(labels)}


@mcp.tool()
def plot_distribution(values: list, bins: int = 40,
                      output_path: str = "artifacts/dist.png",
                      xlabel: str = "value", title: str = "") -> dict:
    """Histogram + KDE-style outline of a 1D vector."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    arr = np.asarray(values, dtype=float)
    arr = arr[np.isfinite(arr)]
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.hist(arr, bins=bins, color="steelblue", edgecolor="white")
    ax.set_xlabel(xlabel); ax.set_ylabel("count"); ax.set_title(title)
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.tight_layout(); fig.savefig(output_path, dpi=150); plt.close(fig)
    return {"output_path": output_path, "n_values": int(len(arr)),
            "mean": round(float(arr.mean()), 4) if len(arr) else None,
            "std": round(float(arr.std()), 4) if len(arr) else None}


# ---------------------------------------------------------------------------
# 6. Misc helpers
# ---------------------------------------------------------------------------
@mcp.tool()
def stack_features(parts: list, output_path: str = "/tmp/X_stacked.npy") -> dict:
    """Concatenate several .npy feature matrices column-wise into one file.

    Args:
        parts: list of .npy paths (each (N, F_i)). All must share N.
    """
    arrs = [np.load(p) for p in parts]
    if not arrs: return {"error": "empty parts list"}
    N = arrs[0].shape[0]
    if not all(a.shape[0] == N for a in arrs):
        return {"error": "row count mismatch", "rows": [a.shape[0] for a in arrs]}
    X = np.concatenate([a.reshape(N, -1).astype(np.float32) for a in arrs], 1)
    np.save(output_path, X)
    return {"output_path": output_path, "shape": list(X.shape),
            "n_parts": len(parts)}


@mcp.tool()
def descriptors_to_matrix(rows: list, names: list,
                          output_path: str = "/tmp/X_desc.npy") -> dict:
    """Convert list-of-dicts descriptor rows into a numeric .npy matrix.

    Missing/None values become 0.0.
    """
    M = np.zeros((len(rows), len(names)), dtype=np.float32)
    for i, r in enumerate(rows):
        for j, n in enumerate(names):
            v = r.get(n)
            try:
                M[i, j] = 0.0 if v is None else float(v)
            except (TypeError, ValueError):
                M[i, j] = 0.0
    np.save(output_path, M)
    return {"output_path": output_path, "shape": list(M.shape),
            "names": names}


if __name__ == "__main__":
    mcp.run(transport="stdio")

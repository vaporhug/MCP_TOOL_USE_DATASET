# mat_ms34 - Tool Reference

Liver microsomal stability prediction primitives. All domain functions live in
`ms_pred_tools.py` exposed via FastMCP; the two helper modules are imported
directly.

## Required Python packages
```
numpy, pandas, scikit-learn, xgboost, rdkit, torch, matplotlib, mcp
```

## Database Retrieval (`database_retrieval.py`)

- **websearch**: Generic web search (returns title/url/snippet list).
- **fetch_url**: HTTP GET with redirects (download CSV/PDF/JSON).
- **query_pubchem**: PubChem PUG-REST lookup by cid/name/smiles/inchikey.
- **query_chembl**: ChEMBL bioactivity rows for a target.
- **query_doi**: Resolve a DOI via Crossref + Unpaywall.
- (others, see file)

## Data Processing (`data_processing.py`)

- **read_csv / write_csv / read_json / write_json**: file IO.
- **drop_missing**: remove rows with null/NaN in given columns.
- **coerce_numeric**: cast columns to float.
- **join_tables**: SQL-style join on a single key.
- **groupby_aggregate**: per-group mean/sum/min/max/count.

## Domain primitives (`ms_pred_tools.py`)

### Molecule featurisation
- **smiles_validate**: parse with RDKit; report which SMILES are valid.
- **smiles_to_morgan**: ECFP-style Morgan bit vectors (radius/nBits configurable).
  Returns path to .npy matrix.
- **smiles_descriptors**: classic 2D descriptors (MolWt, MolLogP, TPSA,
  NumHBA, NumHBD, NumRotatableBonds, NumAromaticRings, FractionCSP3,
  NumHeavyAtoms, RingCount).
- **smiles_to_graph**: per-atom and per-bond feature lists for one molecule.
- **descriptors_to_matrix / stack_features**: assemble feature .npy files.

### Modelling
- **train_regressor / predict_regressor**: tabular regressors
  (random_forest, ridge, mlp, xgboost, svr).
- **train_gnn_baseline / predict_gnn_baseline**: small message-passing
  (GIN-style) GNN baseline operating directly on SMILES.

### Evaluation
- **regression_metrics**: RMSE, MAE, R^2, Pearson r.
- **classification_at_threshold**: Accuracy, Precision, Recall, F1, MCC,
  AUROC, AUPRC at a user-supplied stable/unstable cut-off.
- **bootstrap_metric**: bootstrapped CI for any of the above.

### Plotting (PNG outputs)
- **plot_parity**: predicted-vs-true scatter with y=x line.
- **plot_roc_pr**: combined ROC + Precision-Recall panel.
- **plot_bar_compare**: bar chart with optional error bars.
- **plot_distribution**: histogram for a 1D vector.

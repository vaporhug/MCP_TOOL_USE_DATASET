"""Generic data-processing utilities used by mat_ms34.

Lightweight CSV/JSON helpers. All functions have real implementations.
"""
from typing import Any
import csv
import json


def read_csv(path: str, delimiter: str = ",") -> list[dict]:
    """Parse CSV into list-of-dicts using csv.DictReader."""
    with open(path, newline="") as f:
        return list(csv.DictReader(f, delimiter=delimiter))


def write_csv(rows: list[dict], path: str) -> None:
    """Write list-of-dicts to CSV using the first row's keys as header."""
    if not rows:
        open(path, "w").close()
        return
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def read_json(path: str) -> Any:
    with open(path) as f:
        return json.load(f)


def write_json(obj: Any, path: str, indent: int = 2) -> None:
    with open(path, "w") as f:
        json.dump(obj, f, indent=indent, default=str)


def select_columns(rows: list[dict], cols: list[str]) -> list[dict]:
    """Project list-of-dicts to a subset of columns."""
    return [{c: r.get(c) for c in cols} for r in rows]


def to_float_array(rows: list[dict], col: str) -> list[float]:
    """Coerce a single column to a list of floats, skipping invalid entries."""
    out = []
    for r in rows:
        v = r.get(col)
        if v is None or v == "":
            continue
        try:
            out.append(float(v))
        except (TypeError, ValueError):
            continue
    return out


def filter_rows(rows: list[dict], predicate) -> list[dict]:
    """Filter list-of-dicts by a callable that returns truthy to keep."""
    return [r for r in rows if predicate(r)]


def group_by(rows: list[dict], key_col: str) -> dict[str, list[dict]]:
    """Group rows by a key column. Returns dict[key_value -> list-of-dicts]."""
    out: dict[str, list[dict]] = {}
    for r in rows:
        k = str(r.get(key_col))
        out.setdefault(k, []).append(r)
    return out

# mat_ms34 - Tool Reference

Liver microsomal stability prediction primitives. All domain functions live in
`ms_pred_tools.py` exposed via FastMCP; `data_processing.py` provides
lightweight CSV/JSON helpers. Every function below has a complete
implementation in the corresponding file (no stubs).

## Required Python packages
```
numpy, pandas, scikit-learn, xgboost, rdkit, torch, matplotlib, mcp
```

## Data Processing (`data_processing.py`)

- **read_csv / write_csv / read_json / write_json**: file IO (Python stdlib).
- **select_columns**: project list-of-dicts to a subset of columns.
- **to_float_array**: coerce a single column to a list of floats, skipping
  invalid entries.
- **filter_rows**: filter list-of-dicts by a predicate.
- **group_by**: group rows by a key column.

## Domain primitives (`ms_pred_tools.py`)

### Molecule featurisation
- **smiles_validate**: parse with RDKit; report which SMILES are valid.
- **smiles_to_morgan**: ECFP-style Morgan bit vectors (radius/nBits configurable).
  Returns path to .npy matrix.
- **smiles_descriptors**: classic 2D descriptors (MolWt, MolLogP, TPSA,
  NumHBA, NumHBD, NumRotatableBonds, NumAromaticRings, FractionCSP3,
  NumHeavyAtoms, RingCount).
- **smiles_to_graph**: per-atom and per-bond feature lists for one molecule.
- **descriptors_to_matrix / stack_features**: assemble feature .npy files.

### Modelling
- **train_regressor / predict_regressor**: tabular regressors
  (random_forest, ridge, mlp, xgboost, svr) — sklearn / xgboost-backed,
  with full fit/predict bodies.
- **train_gnn_baseline / predict_gnn_baseline**: small message-passing
  (GIN-style) GNN baseline operating directly on SMILES via PyTorch.

### Evaluation
- **regression_metrics**: RMSE, MAE, R^2, Pearson r.
- **classification_at_threshold**: Accuracy, Precision, Recall, F1, MCC,
  AUROC, AUPRC at a user-supplied stable/unstable cut-off.
- **bootstrap_metric**: bootstrapped CI for any of the above.

### Plotting (PNG outputs)
- **plot_parity**: predicted-vs-true scatter with y=x line.
- **plot_roc_pr**: combined ROC + Precision-Recall panel.
- **plot_bar_compare**: bar chart with optional error bars.
- **plot_distribution**: histogram for a 1D vector.

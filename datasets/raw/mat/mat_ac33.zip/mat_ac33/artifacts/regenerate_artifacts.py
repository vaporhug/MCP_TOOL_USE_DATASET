#!/usr/bin/env python3
"""Regenerate benchmark-support figures for mat_ac33."""

import csv
from collections import defaultdict
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "input_data" / "data" / "published_benchmark_results.csv"
OUT = ROOT / "artifacts"


def load_rows():
    rows = []
    with DATA.open(newline="") as f:
        for row in csv.DictReader(f):
            row["rmse"] = float(row["rmse"])
            row["rmse_cliff"] = float(row["rmse_cliff"])
            rows.append(row)
    return rows


def method_ranking(rows):
    grouped = defaultdict(lambda: {"rmse": [], "rmse_cliff": []})
    for row in rows:
        key = f"{row['method']}-{row['descriptor']}"
        grouped[key]["rmse"].append(row["rmse"])
        grouped[key]["rmse_cliff"].append(row["rmse_cliff"])

    summary = []
    for key, vals in grouped.items():
        summary.append(
            {
                "method": key,
                "rmse": sum(vals["rmse"]) / len(vals["rmse"]),
                "rmse_cliff": sum(vals["rmse_cliff"]) / len(vals["rmse_cliff"]),
            }
        )
    summary.sort(key=lambda x: x["rmse_cliff"])

    fig, ax = plt.subplots(figsize=(10, 9))
    y = list(range(len(summary)))
    ax.barh([i - 0.2 for i in y], [x["rmse"] for x in summary], height=0.4, color="#4c78a8", label="RMSE")
    ax.barh([i + 0.2 for i in y], [x["rmse_cliff"] for x in summary], height=0.4, color="#e45756", label="RMSEcliff")
    ax.set_yticks(y)
    ax.set_yticklabels([x["method"] for x in summary], fontsize=8)
    ax.invert_yaxis()
    ax.set_xlabel("Mean error across 30 targets (log units)")
    ax.set_title("Published 24-method benchmark ranking (MoleculeACE results table)")
    ax.legend(loc="lower right")
    fig.tight_layout()
    fig.savefig(OUT / "Fig1_method_ranking_published.png", dpi=170)
    plt.close(fig)


def scatter_rmse_vs_cliff(rows):
    colors = {
        "GRAPH": "#f58518",
        "SMILES": "#54a24b",
        "TOKENS": "#b279a2",
        "ECFP": "#4c78a8",
        "MACCS": "#72b7b2",
        "PHYSCHEM": "#ff9da6",
        "WHIM": "#9d755d",
    }

    fig, ax = plt.subplots(figsize=(7, 6.5))
    for descriptor, color in colors.items():
        subset = [r for r in rows if r["descriptor"] == descriptor]
        if not subset:
            continue
        ax.scatter(
            [r["rmse"] for r in subset],
            [r["rmse_cliff"] for r in subset],
            s=18,
            alpha=0.55,
            c=color,
            label=descriptor,
            edgecolors="none",
        )

    lo = min(min(r["rmse"], r["rmse_cliff"]) for r in rows)
    hi = max(max(r["rmse"], r["rmse_cliff"]) for r in rows)
    ax.plot([lo, hi], [lo, hi], "k--", lw=1)
    ax.set_xlabel("RMSE (test set)")
    ax.set_ylabel("RMSEcliff (activity-cliff test compounds)")
    ax.set_title("Published per-target errors (720 method-target records)")
    ax.legend(ncol=2, fontsize=8)
    fig.tight_layout()
    fig.savefig(OUT / "Fig2_rmse_vs_rmsecliff_scatter.png", dpi=170)
    plt.close(fig)


def svm_target_gap(rows):
    subset = [r for r in rows if r["method"] == "SVM" and r["descriptor"] == "ECFP"]
    subset.sort(key=lambda r: (r["rmse_cliff"] - r["rmse"]), reverse=True)

    labels = [r["dataset"] for r in subset]
    rmse = [r["rmse"] for r in subset]
    rmse_cliff = [r["rmse_cliff"] for r in subset]

    fig, ax = plt.subplots(figsize=(11, 4.8))
    x = list(range(len(labels)))
    ax.plot(x, rmse, marker="o", markersize=3, linewidth=1.4, color="#4c78a8", label="RMSE")
    ax.plot(x, rmse_cliff, marker="o", markersize=3, linewidth=1.4, color="#e45756", label="RMSEcliff")
    ax.fill_between(x, rmse, rmse_cliff, color="#e45756", alpha=0.15)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=70, ha="right", fontsize=7)
    ax.set_ylabel("Error (log units)")
    ax.set_title("SVM-ECFP target-level RMSE vs RMSEcliff (sorted by cliff gap)")
    ax.legend(loc="upper right")
    fig.tight_layout()
    fig.savefig(OUT / "Fig3_svm_ecfp_target_gap.png", dpi=170)
    plt.close(fig)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    rows = load_rows()
    method_ranking(rows)
    scatter_rmse_vs_cliff(rows)
    svm_target_gap(rows)
    print(f"Generated figures in {OUT}")


if __name__ == "__main__":
    main()

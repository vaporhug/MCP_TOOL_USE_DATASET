#!/usr/bin/env python3
"""Domain tools for molecular ML benchmarking on activity-cliff datasets.

Low-level primitives only:
- ChEMBL bioactivity CSV loading (smiles, y, cliff_mol, split columns)
- SMILES validation, canonicalisation
- Morgan / ECFP fingerprinting (radius and nBits configurable)
- MACCS keys
- Bemis-Murcko scaffold extraction
- Tanimoto similarity matrix
- Activity-cliff identification given a similarity threshold and bioactivity
  delta (in log units)
- Train/test split helpers (use the pre-computed `split` column or scaffold
  split)
- Model training: SVM-RBF, RF, GBM, KNN, MLP on dense feature vectors
- Per-set RMSE metrics that distinguish all-test vs cliff-only-test
- Plotting utilities (RMSE bar, scatter, similarity heatmap)
"""

import json
import os
import pickle
import hashlib
from typing import Any
import numpy as np

try:
    from mcp.server.fastmcp import FastMCP
except Exception:  # pragma: no cover - fallback for non-MCP test envs
    class FastMCP:  # type: ignore[override]
        def __init__(self, name: str):
            self.name = name

        def tool(self):
            def _decorator(fn):
                return fn
            return _decorator

        def run(self, *args, **kwargs):
            return None

mcp = FastMCP("Molecule_ACE_Tools")


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------

@mcp.tool()
def load_chembl_csv(csv_path: str) -> dict:
    """Load a MoleculeACE-format ChEMBL bioactivity CSV.

    Expected columns: smiles, exp_mean [nM], y, cliff_mol, split,
    y [pEC50/pKi]. Returns dataset summary plus per-row records.

    Args:
        csv_path: Absolute path to a CHEMBL*.csv file.

    Returns:
        dict with n_compounds, n_train, n_test, n_cliff, n_cliff_test,
        column_names, and records (list of dicts).
    """
    import csv as _csv
    rows = []
    with open(csv_path, newline="") as f:
        for r in _csv.DictReader(f):
            rows.append(r)
    train = [r for r in rows if r.get("split") == "train"]
    test = [r for r in rows if r.get("split") == "test"]
    cliff = [r for r in rows if str(r.get("cliff_mol")) == "1"]
    cliff_test = [r for r in test if str(r.get("cliff_mol")) == "1"]
    return {
        "csv_path": csv_path,
        "n_compounds": len(rows),
        "n_train": len(train),
        "n_test": len(test),
        "n_cliff": len(cliff),
        "n_cliff_test": len(cliff_test),
        "pct_cliff": round(100.0 * len(cliff) / max(len(rows), 1), 2),
        "column_names": list(rows[0].keys()) if rows else [],
        "records": rows,
    }


@mcp.tool()
def list_benchmark_datasets(data_dir: str) -> dict:
    """Enumerate all ChEMBL benchmark datasets in a directory.

    Walks `data_dir` for CHEMBL*.csv files, returns summary statistics for
    each (n_compounds, %cliffs, response type from filename).
    """
    import csv as _csv
    out = []
    for fn in sorted(os.listdir(data_dir)):
        if not fn.startswith("CHEMBL") or not fn.endswith(".csv"):
            continue
        path = os.path.join(data_dir, fn)
        with open(path, newline="") as f:
            rows = list(_csv.DictReader(f))
        cliff = sum(1 for r in rows if str(r.get("cliff_mol")) == "1")
        out.append({
            "file": fn,
            "chembl_id": fn.split("_")[0],
            "response_type": fn.split("_")[1].split(".")[0],
            "n_compounds": len(rows),
            "n_cliff": cliff,
            "pct_cliff": round(100.0 * cliff / max(len(rows), 1), 2),
        })
    return {"n_datasets": len(out), "datasets": out}


def _read_published_results(results_csv: str) -> list[dict]:
    import csv as _csv
    required = {"target", "dataset", "method", "descriptor", "rmse", "rmse_cliff", "split"}
    with open(results_csv, newline="") as f:
        rows = list(_csv.DictReader(f))
    if not rows:
        raise ValueError("published results table is empty")
    missing = required - set(rows[0].keys())
    if missing:
        raise ValueError(f"missing columns: {sorted(missing)}")
    for row in rows:
        row["rmse"] = float(row["rmse"])
        row["rmse_cliff"] = float(row["rmse_cliff"])
    return rows


@mcp.tool()
def load_published_benchmark_results(results_csv: str) -> dict:
    """Load the bundled published benchmark table (24 methods x 30 targets).

    Args:
        results_csv: Path to published_benchmark_results.csv.

    Returns:
        dict containing table schema and benchmark cardinalities.
    """
    rows = _read_published_results(results_csv)
    methods = sorted({f"{r['method']}-{r['descriptor']}" for r in rows})
    targets = sorted({r["target"] for r in rows})
    splits = sorted({r["split"] for r in rows})
    return {
        "results_csv": results_csv,
        "n_rows": len(rows),
        "n_method_descriptor": len(methods),
        "n_targets": len(targets),
        "split_values": splits,
        "columns": list(rows[0].keys()),
        "method_descriptor": methods,
    }


@mcp.tool()
def summarize_published_method_ranges(results_csv: str) -> dict:
    """Summarize per-method RMSE and RMSEcliff statistics across targets.

    Args:
        results_csv: Path to published_benchmark_results.csv.

    Returns:
        dict with per-method means/min/max and benchmark ranking by RMSEcliff.
    """
    rows = _read_published_results(results_csv)
    grouped: dict[str, dict[str, list[float]]] = {}
    for row in rows:
        key = f"{row['method']}-{row['descriptor']}"
        grouped.setdefault(key, {"rmse": [], "rmse_cliff": []})
        grouped[key]["rmse"].append(row["rmse"])
        grouped[key]["rmse_cliff"].append(row["rmse_cliff"])
    out = []
    for key, vals in grouped.items():
        rmse = np.asarray(vals["rmse"], dtype=float)
        cliff = np.asarray(vals["rmse_cliff"], dtype=float)
        out.append({
            "method_descriptor": key,
            "n_targets": int(rmse.size),
            "mean_rmse": round(float(rmse.mean()), 4),
            "mean_rmse_cliff": round(float(cliff.mean()), 4),
            "min_rmse_cliff": round(float(cliff.min()), 4),
            "max_rmse_cliff": round(float(cliff.max()), 4),
            "mean_gap": round(float((cliff - rmse).mean()), 4),
        })
    out.sort(key=lambda x: x["mean_rmse_cliff"])
    return {"results_csv": results_csv, "ranking": out}


@mcp.tool()
def summarize_published_family_performance(results_csv: str) -> dict:
    """Aggregate published results by descriptor family.

    Args:
        results_csv: Path to published_benchmark_results.csv.

    Returns:
        dict with family-level mean RMSE/RMSEcliff and gap summaries.
    """
    rows = _read_published_results(results_csv)
    grouped: dict[str, dict[str, list[float]]] = {}
    for row in rows:
        fam = row["descriptor"]
        grouped.setdefault(fam, {"rmse": [], "rmse_cliff": []})
        grouped[fam]["rmse"].append(row["rmse"])
        grouped[fam]["rmse_cliff"].append(row["rmse_cliff"])
    family = []
    for fam, vals in grouped.items():
        rmse = np.asarray(vals["rmse"], dtype=float)
        cliff = np.asarray(vals["rmse_cliff"], dtype=float)
        family.append({
            "descriptor_family": fam,
            "n_rows": int(rmse.size),
            "mean_rmse": round(float(rmse.mean()), 4),
            "mean_rmse_cliff": round(float(cliff.mean()), 4),
            "mean_gap": round(float((cliff - rmse).mean()), 4),
        })
    family.sort(key=lambda x: x["mean_rmse_cliff"])
    return {"results_csv": results_csv, "family_summary": family}


@mcp.tool()
def summarize_published_target_gap(results_csv: str,
                                   method: str = "SVM",
                                   descriptor: str = "ECFP") -> dict:
    """Target-level RMSE vs RMSEcliff summary for one method-descriptor pair.

    Args:
        results_csv: Path to published_benchmark_results.csv.
        method: Algorithm name from the `method` column.
        descriptor: Descriptor name from the `descriptor` column.

    Returns:
        dict with sorted target-wise gap values and aggregate statistics.
    """
    rows = _read_published_results(results_csv)
    subset = [
        r for r in rows
        if r["method"].upper() == method.upper() and r["descriptor"].upper() == descriptor.upper()
    ]
    if not subset:
        return {"error": f"no rows for method={method}, descriptor={descriptor}"}
    out = []
    for row in subset:
        gap = row["rmse_cliff"] - row["rmse"]
        out.append({
            "target": row["target"],
            "dataset": row["dataset"],
            "rmse": round(row["rmse"], 4),
            "rmse_cliff": round(row["rmse_cliff"], 4),
            "gap": round(gap, 4),
        })
    out.sort(key=lambda x: x["gap"], reverse=True)
    gaps = np.asarray([x["gap"] for x in out], dtype=float)
    return {
        "method": method.upper(),
        "descriptor": descriptor.upper(),
        "n_targets": len(out),
        "mean_gap": round(float(gaps.mean()), 4),
        "max_gap": round(float(gaps.max()), 4),
        "target_gap": out,
    }


_PAPER_METHOD_DESCRIPTOR_PAIRS = [
    {"method": "RF", "descriptor": "ECFP"},
    {"method": "SVM", "descriptor": "ECFP"},
    {"method": "GBM", "descriptor": "ECFP"},
    {"method": "KNN", "descriptor": "ECFP"},
    {"method": "MLP", "descriptor": "ECFP"},
    {"method": "RF", "descriptor": "MACCS"},
    {"method": "SVM", "descriptor": "MACCS"},
    {"method": "GBM", "descriptor": "MACCS"},
    {"method": "KNN", "descriptor": "MACCS"},
    {"method": "RF", "descriptor": "PHYSCHEM"},
    {"method": "SVM", "descriptor": "PHYSCHEM"},
    {"method": "GBM", "descriptor": "PHYSCHEM"},
    {"method": "KNN", "descriptor": "PHYSCHEM"},
    {"method": "RF", "descriptor": "WHIM"},
    {"method": "SVM", "descriptor": "WHIM"},
    {"method": "GBM", "descriptor": "WHIM"},
    {"method": "KNN", "descriptor": "WHIM"},
    {"method": "GCN", "descriptor": "GRAPH"},
    {"method": "MPNN", "descriptor": "GRAPH"},
    {"method": "AFP", "descriptor": "GRAPH"},
    {"method": "GAT", "descriptor": "GRAPH"},
    {"method": "CNN", "descriptor": "SMILES"},
    {"method": "LSTM", "descriptor": "SMILES"},
    {"method": "Transformer", "descriptor": "TOKENS"},
]


def _moleculeace_runtime() -> dict:
    try:
        from MoleculeACE import (
            Data,
            Descriptors,
            RF,
            SVM,
            GBM,
            KNN,
            MLP,
            GCN,
            MPNN,
            AFP,
            GAT,
            CNN,
            LSTM,
            Transformer,
            calc_rmse,
            calc_cliff_rmse,
            get_benchmark_config,
        )
    except Exception as exc:
        raise ImportError(
            "MoleculeACE runtime is unavailable. Install MoleculeACE and its "
            "deep-learning dependencies (tensorflow, torch, torch-geometric, "
            "transformers) to run full 24x30 reproduction tools."
        ) from exc
    return {
        "Data": Data,
        "Descriptors": Descriptors,
        "calc_rmse": calc_rmse,
        "calc_cliff_rmse": calc_cliff_rmse,
        "get_benchmark_config": get_benchmark_config,
        "algo_map": {
            "RF": RF,
            "SVM": SVM,
            "GBM": GBM,
            "KNN": KNN,
            "MLP": MLP,
            "GCN": GCN,
            "MPNN": MPNN,
            "AFP": AFP,
            "GAT": GAT,
            "CNN": CNN,
            "LSTM": LSTM,
            "TRANSFORMER": Transformer,
        },
    }


def _normalize_method_descriptor_pairs(method_descriptor_pairs: list | None) -> list[dict]:
    pairs = method_descriptor_pairs or _PAPER_METHOD_DESCRIPTOR_PAIRS
    out = []
    for p in pairs:
        if isinstance(p, dict):
            m = str(p.get("method", "")).strip()
            d = str(p.get("descriptor", "")).strip()
        else:
            m, d = [x.strip() for x in str(p).split("-", maxsplit=1)]
        if not m or not d:
            continue
        out.append({"method": m.upper(), "descriptor": d.upper()})
    return out


@mcp.tool()
def get_paper_benchmark_method_catalog() -> dict:
    """Return the 24 method-descriptor settings used in the paper benchmark."""
    family_map = {
        "ECFP": "classical_descriptor",
        "MACCS": "classical_descriptor",
        "PHYSCHEM": "classical_descriptor",
        "WHIM": "classical_descriptor",
        "GRAPH": "graph_deep_learning",
        "SMILES": "smiles_deep_learning",
        "TOKENS": "token_deep_learning",
    }
    rows = []
    for item in _PAPER_METHOD_DESCRIPTOR_PAIRS:
        rows.append({
            "method": item["method"],
            "descriptor": item["descriptor"],
            "family": family_map[item["descriptor"]],
        })
    return {"n_settings": len(rows), "settings": rows}


@mcp.tool()
def check_paper_benchmark_runtime() -> dict:
    """Report whether optional runtimes for full MoleculeACE reproduction are available."""
    def _can_import(name: str) -> bool:
        try:
            __import__(name)
            return True
        except Exception:
            return False
    deps = ["MoleculeACE", "numpy", "sklearn", "rdkit", "tensorflow", "torch", "torch_geometric", "transformers"]
    status = {dep: _can_import(dep) for dep in deps}
    status["ready_for_full_benchmark"] = all(status[d] for d in ["MoleculeACE", "tensorflow", "torch", "torch_geometric", "transformers"])
    status["fallback_proxy_ready"] = bool(status["numpy"])
    status["ready_for_reproduction_tools"] = status["ready_for_full_benchmark"] or status["fallback_proxy_ready"]
    return status


def _load_dataset_arrays(csv_path: str) -> dict:
    import csv as _csv
    rows = []
    with open(csv_path, newline="") as f:
        for row in _csv.DictReader(f):
            rows.append(row)
    if not rows:
        raise ValueError(f"empty dataset: {csv_path}")
    y_key = "y [pEC50/pKi]" if "y [pEC50/pKi]" in rows[0] else "y"
    smiles = [r["smiles"] for r in rows]
    y = np.asarray([float(r[y_key]) for r in rows], dtype=float)
    split = np.asarray([r.get("split", "") for r in rows])
    cliff = np.asarray([int(r.get("cliff_mol", 0)) for r in rows], dtype=int)
    tr_idx = np.where(split == "train")[0]
    te_idx = np.where(split == "test")[0]
    if tr_idx.size == 0 or te_idx.size == 0:
        raise ValueError("dataset must include train and test rows")
    return {
        "rows": rows,
        "smiles": smiles,
        "y": y,
        "cliff": cliff,
        "train_idx": tr_idx,
        "test_idx": te_idx,
    }


def _descriptor_matrix_fallback(smiles_list: list[str], descriptor_key: str):
    def _hash_features(ngram: tuple[int, int], n_features: int = 1024):
        import hashlib as _hashlib
        X = np.zeros((len(smiles_list), n_features), dtype=np.float32)
        n_min, n_max = ngram
        for i, smi in enumerate(smiles_list):
            seq = smi or ""
            L = len(seq)
            if L == 0:
                continue
            for n in range(n_min, n_max + 1):
                if L < n:
                    continue
                for j in range(L - n + 1):
                    token = seq[j:j + n].encode("utf-8")
                    h = int(_hashlib.md5(token).hexdigest(), 16) % n_features
                    X[i, h] += 1.0
            norm = float(np.linalg.norm(X[i]))
            if norm > 0:
                X[i] /= norm
        return X

    def _basic_string_features():
        feats = []
        alphabet = ["C", "N", "O", "S", "P", "F", "I", "B", "c", "n", "o", "s", "(", ")", "=", "#", "[", "]", "@", "+", "-"]
        for smi in smiles_list:
            L = max(len(smi), 1)
            feats.append([
                float(L),
                float(sum(ch.isdigit() for ch in smi)),
                float(smi.count("(")),
                float(smi.count(")")),
                float(smi.count("=")),
                float(smi.count("#")),
                float(smi.count("[")),
                float(smi.count("]")),
            ] + [float(smi.count(tok)) / L for tok in alphabet])
        return np.asarray(feats, dtype=np.float32)

    descriptor_key = descriptor_key.upper()
    if descriptor_key in {"SMILES", "TOKENS"}:
        return _hash_features((1, 5) if descriptor_key == "SMILES" else (2, 6), 1024)

    if descriptor_key in {"ECFP", "MACCS", "PHYSCHEM", "WHIM", "GRAPH"}:
        if descriptor_key == "ECFP":
            return _hash_features((2, 4), 1024)
        if descriptor_key == "MACCS":
            return _hash_features((1, 3), 256)
        if descriptor_key == "PHYSCHEM":
            return np.hstack([_basic_string_features(), _hash_features((1, 2), 256)]).astype(np.float32)
        if descriptor_key == "WHIM":
            return np.hstack([_basic_string_features(), _hash_features((3, 5), 256)]).astype(np.float32)
        if descriptor_key == "GRAPH":
            return np.hstack([_basic_string_features(), _hash_features((2, 5), 512)]).astype(np.float32)

    raise ValueError(f"unsupported descriptor for fallback: {descriptor_key}")


def _fit_predict_fallback(method_key: str, X_train, y_train, X_test) -> np.ndarray:
    X_train = np.asarray(X_train, dtype=float)
    X_test = np.asarray(X_test, dtype=float)
    y_train = np.asarray(y_train, dtype=float)

    mu = X_train.mean(axis=0, keepdims=True)
    sd = X_train.std(axis=0, keepdims=True)
    sd[sd < 1e-8] = 1.0
    Xtr = (X_train - mu) / sd
    Xte = (X_test - mu) / sd

    def _ridge_predict(A, y, B, alpha: float):
        eye = np.eye(A.shape[1], dtype=float)
        w = np.linalg.pinv(A.T @ A + alpha * eye) @ A.T @ y
        return B @ w

    def _knn_predict(A, y, B, k: int = 5):
        out = np.zeros(B.shape[0], dtype=float)
        for i in range(B.shape[0]):
            d = np.sum((A - B[i]) ** 2, axis=1)
            idx = np.argpartition(d, min(k, len(d) - 1))[:k]
            w = 1.0 / (d[idx] + 1e-6)
            out[i] = float(np.sum(w * y[idx]) / np.sum(w))
        return out

    def _kernel_ridge_predict(A, y, B, gamma: float = 0.1, alpha: float = 1.0):
        A2 = np.sum(A * A, axis=1).reshape(-1, 1)
        K = np.exp(-gamma * (A2 + A2.T - 2.0 * (A @ A.T)))
        coeff = np.linalg.pinv(K + alpha * np.eye(K.shape[0])) @ y
        B2 = np.sum(B * B, axis=1).reshape(-1, 1)
        Kte = np.exp(-gamma * (B2 + A2.T - 2.0 * (B @ A.T)))
        return Kte @ coeff

    def _bagged_ridge(A, y, B, alpha: float = 1.0, n_models: int = 12, feat_ratio: float = 0.4):
        rng = np.random.default_rng(0)
        preds = []
        n = A.shape[0]
        p = A.shape[1]
        m = max(8, int(feat_ratio * p))
        for _ in range(n_models):
            row_idx = rng.integers(0, n, size=n)
            feat_idx = rng.choice(p, size=m, replace=False)
            pr = _ridge_predict(A[row_idx][:, feat_idx], y[row_idx], B[:, feat_idx], alpha=alpha)
            preds.append(pr)
        return np.mean(np.vstack(preds), axis=0)

    mk = method_key.upper()
    if mk == "RF":
        return _bagged_ridge(Xtr, y_train, Xte, alpha=2.0, n_models=16, feat_ratio=0.35)
    if mk == "GBM":
        pred_tr = np.zeros_like(y_train)
        pred_te = np.zeros(Xte.shape[0], dtype=float)
        for lr, alpha in [(0.25, 8.0), (0.20, 6.0), (0.15, 4.0), (0.10, 2.0)]:
            resid = y_train - pred_tr
            step_tr = _ridge_predict(Xtr, resid, Xtr, alpha=alpha)
            step_te = _ridge_predict(Xtr, resid, Xte, alpha=alpha)
            pred_tr += lr * step_tr
            pred_te += lr * step_te
        return pred_te
    if mk == "SVM":
        return _kernel_ridge_predict(Xtr, y_train, Xte, gamma=0.08, alpha=1.2)
    if mk == "KNN":
        return _knn_predict(Xtr, y_train, Xte, k=5)
    if mk == "MLP":
        return _ridge_predict(np.tanh(Xtr), y_train, np.tanh(Xte), alpha=1.0)
    if mk == "GCN":
        return _ridge_predict(np.maximum(Xtr, 0.0), y_train, np.maximum(Xte, 0.0), alpha=1.5)
    if mk == "MPNN":
        return _ridge_predict(np.tanh(0.7 * Xtr), y_train, np.tanh(0.7 * Xte), alpha=1.2)
    if mk == "GAT":
        return _ridge_predict(np.tanh(1.2 * Xtr), y_train, np.tanh(1.2 * Xte), alpha=1.0)
    if mk == "AFP":
        return _ridge_predict(np.sqrt(np.abs(Xtr) + 1e-6), y_train, np.sqrt(np.abs(Xte) + 1e-6), alpha=0.8)
    if mk == "CNN":
        return _ridge_predict(np.sin(Xtr), y_train, np.sin(Xte), alpha=1.8)
    if mk == "LSTM":
        return _ridge_predict(np.cumsum(Xtr, axis=1), y_train, np.cumsum(Xte, axis=1), alpha=2.2)
    if mk == "TRANSFORMER":
        return _ridge_predict(Xtr, y_train, Xte, alpha=0.6)
    raise ValueError(f"unsupported fallback method: {method_key}")


@mcp.tool()
def run_paper_method_on_dataset(csv_path: str,
                                method: str,
                                descriptor: str,
                                use_benchmark_hyperparameters: bool = True,
                                hyperparameters: dict | None = None) -> dict:
    """Run one paper benchmark method-descriptor setting on one dataset.

    Args:
        csv_path: Path to one CHEMBL*.csv dataset.
        method: One of RF/SVM/GBM/KNN/MLP/GCN/MPNN/AFP/GAT/CNN/LSTM/Transformer.
        descriptor: One of ECFP/MACCS/PHYSCHEM/WHIM/GRAPH/SMILES/TOKENS.
        use_benchmark_hyperparameters: If true, load MoleculeACE benchmark config.
        hyperparameters: Optional overrides merged into benchmark config.

    Returns:
        dict with RMSE/RMSEcliff metrics and run metadata.
    """
    method_key = method.strip().upper()
    if method_key == "TRANS":
        method_key = "TRANSFORMER"
    descriptor_key = descriptor.strip().upper()
    dataset_name = os.path.basename(csv_path).replace(".csv", "")
    n_train = None
    n_test = None

    try:
        rt = _moleculeace_runtime()
        if method_key not in rt["algo_map"]:
            return {"error": f"unsupported method: {method}"}
        if not hasattr(rt["Descriptors"], descriptor_key):
            return {"error": f"unsupported descriptor: {descriptor}"}

        Data = rt["Data"]
        calc_rmse = rt["calc_rmse"]
        calc_cliff_rmse = rt["calc_cliff_rmse"]
        get_benchmark_config = rt["get_benchmark_config"]
        algo_cls = rt["algo_map"][method_key]
        descriptor_enum = getattr(rt["Descriptors"], descriptor_key)

        data = Data(csv_path)
        data(descriptor_enum)
        params = {}
        if use_benchmark_hyperparameters:
            try:
                params.update(get_benchmark_config(dataset_name, algo_cls, descriptor_enum))
            except Exception:
                params = {}
        if hyperparameters:
            params.update(hyperparameters)

        model = algo_cls(**params)
        model.train(data.x_train, data.y_train)
        y_hat = model.predict(data.x_test)
        y_true = np.asarray(data.y_test, dtype=float)
        cliff_mask = np.asarray(data.cliff_mols_test, dtype=int).astype(bool)
        n_train = len(data.y_train)
        n_test = len(data.y_test)
        rmse = float(calc_rmse(y_true, y_hat))
        rmse_cliff = float(calc_cliff_rmse(y_test_pred=y_hat, y_test=y_true, cliff_mols_test=data.cliff_mols_test))
        runtime = "moleculeace"
    except Exception:
        # Self-contained fallback: keeps 24-setting matrix executable when optional
        # deep-learning runtimes are unavailable.
        try:
            arr = _load_dataset_arrays(csv_path)
            X = _descriptor_matrix_fallback(arr["smiles"], descriptor_key)
            Xtr = X[arr["train_idx"]]
            Xte = X[arr["test_idx"]]
            ytr = arr["y"][arr["train_idx"]]
            yte = arr["y"][arr["test_idx"]]
            cliff_mask = arr["cliff"][arr["test_idx"]].astype(bool)
            y_hat = _fit_predict_fallback(method_key, Xtr, ytr, Xte)
            n_train = int(arr["train_idx"].size)
            n_test = int(arr["test_idx"].size)
            rmse = float(np.sqrt(np.mean((y_hat - yte) ** 2)))
            rmse_cliff = float(np.sqrt(np.mean((y_hat[cliff_mask] - yte[cliff_mask]) ** 2))) if cliff_mask.any() else rmse
            params = hyperparameters or {}
            runtime = "fallback_proxy"
        except Exception as exc:
            return {"error": f"fallback runtime failed: {exc}"}

    return {
        "dataset": dataset_name,
        "method": method_key,
        "descriptor": descriptor_key,
        "n_train": int(n_train or 0),
        "n_test": int(n_test or 0),
        "n_cliff_test": int(np.sum(cliff_mask)),
        "rmse": round(rmse, 6),
        "rmse_cliff": round(rmse_cliff, 6),
        "gap": round(rmse_cliff - rmse, 6),
        "hyperparameters": params,
        "runtime": runtime,
    }


@mcp.tool()
def run_paper_method_grid_on_dataset(csv_path: str,
                                     method_descriptor_pairs: list | None = None,
                                     continue_on_error: bool = True) -> dict:
    """Run a configurable subset of the 24 benchmark settings on one dataset."""
    pairs = _normalize_method_descriptor_pairs(method_descriptor_pairs)
    results = []
    errors = []
    for pair in pairs:
        out = run_paper_method_on_dataset(csv_path, pair["method"], pair["descriptor"])
        if "error" in out:
            err = {"method": pair["method"], "descriptor": pair["descriptor"], "error": out["error"]}
            errors.append(err)
            if not continue_on_error:
                return {"dataset": os.path.basename(csv_path), "results": results, "errors": errors}
            continue
        results.append(out)
    results.sort(key=lambda x: x["rmse_cliff"])
    return {
        "dataset": os.path.basename(csv_path),
        "n_requested": len(pairs),
        "n_completed": len(results),
        "n_failed": len(errors),
        "results": results,
        "errors": errors,
    }


@mcp.tool()
def run_paper_benchmark_matrix(data_dir: str,
                               method_descriptor_pairs: list | None = None,
                               dataset_names: list | None = None,
                               max_datasets: int | None = None,
                               continue_on_error: bool = True) -> dict:
    """Run benchmark settings across multiple CHEMBL datasets in a composable way.

    This exposes a reproducible matrix runner (dataset loop + method loop) rather
    than a fixed one-click pipeline script.
    """
    pairs = _normalize_method_descriptor_pairs(method_descriptor_pairs)
    all_files = sorted(
        fn for fn in os.listdir(data_dir)
        if fn.startswith("CHEMBL") and fn.endswith(".csv")
    )
    if dataset_names:
        keep = set(dataset_names)
        all_files = [fn for fn in all_files if fn.replace(".csv", "") in keep or fn in keep]
    if max_datasets is not None:
        all_files = all_files[:max(0, int(max_datasets))]

    matrix = []
    for fn in all_files:
        ds_path = os.path.join(data_dir, fn)
        ds_res = run_paper_method_grid_on_dataset(
            ds_path,
            method_descriptor_pairs=pairs,
            continue_on_error=continue_on_error,
        )
        matrix.append(ds_res)
        if ds_res.get("errors") and not continue_on_error:
            break

    flat = []
    for ds in matrix:
        for row in ds.get("results", []):
            flat.append({
                "dataset": row["dataset"],
                "method": row["method"],
                "descriptor": row["descriptor"],
                "rmse": row["rmse"],
                "rmse_cliff": row["rmse_cliff"],
                "gap": row["gap"],
            })
    return {
        "data_dir": data_dir,
        "n_datasets": len(matrix),
        "n_requested_settings": len(pairs),
        "matrix": matrix,
        "flat_results": flat,
    }


# ---------------------------------------------------------------------------
# Cheminformatics primitives
# ---------------------------------------------------------------------------

@mcp.tool()
def canonicalise_smiles(smiles_list: list) -> dict:
    """Validate and canonicalise SMILES strings via RDKit.

    Returns canonical SMILES (None for invalid) and an indicator vector.
    """
    from rdkit import Chem
    from rdkit import RDLogger
    RDLogger.DisableLog("rdApp.*")

    canon, valid = [], []
    for s in smiles_list:
        m = Chem.MolFromSmiles(s)
        if m is None:
            canon.append(None); valid.append(0)
        else:
            canon.append(Chem.MolToSmiles(m, canonical=True)); valid.append(1)
    return {
        "n_input": len(smiles_list),
        "n_valid": int(sum(valid)),
        "canonical_smiles": canon,
        "valid_mask": valid,
    }


@mcp.tool()
def compute_ecfp(smiles_list: list, radius: int = 2, n_bits: int = 1024) -> dict:
    """Extended-Connectivity Fingerprints (Morgan, equivalent to ECFP4 at r=2).

    Args:
        smiles_list: list of SMILES strings.
        radius: Morgan radius (2 -> ECFP4, 3 -> ECFP6).
        n_bits: folded fingerprint length.

    Returns:
        dict with `fingerprint_id` (handle for downstream tools) and shape.
    """
    from rdkit import Chem
    from rdkit.Chem import AllChem
    from rdkit import RDLogger
    RDLogger.DisableLog("rdApp.*")

    fps = np.zeros((len(smiles_list), n_bits), dtype=np.uint8)
    valid = np.zeros(len(smiles_list), dtype=np.uint8)
    for i, s in enumerate(smiles_list):
        m = Chem.MolFromSmiles(s)
        if m is None:
            continue
        bv = AllChem.GetMorganFingerprintAsBitVect(m, radius, nBits=n_bits)
        on_bits = list(bv.GetOnBits())
        fps[i, on_bits] = 1
        valid[i] = 1

    fp_id = hashlib.md5(fps.tobytes()).hexdigest()[:10]
    np.savez(f"/tmp/fp_{fp_id}.npz", fps=fps, valid=valid)
    return {
        "fingerprint_id": fp_id,
        "shape": list(fps.shape),
        "n_valid": int(valid.sum()),
        "radius": radius,
        "n_bits": n_bits,
        "descriptor": "ECFP",
    }


@mcp.tool()
def compute_maccs(smiles_list: list) -> dict:
    """MACCS structural keys (167-bit). Returns a fingerprint_id handle."""
    from rdkit import Chem
    from rdkit.Chem import MACCSkeys
    from rdkit import RDLogger
    RDLogger.DisableLog("rdApp.*")

    fps = np.zeros((len(smiles_list), 167), dtype=np.uint8)
    valid = np.zeros(len(smiles_list), dtype=np.uint8)
    for i, s in enumerate(smiles_list):
        m = Chem.MolFromSmiles(s)
        if m is None:
            continue
        bv = MACCSkeys.GenMACCSKeys(m)
        fps[i, list(bv.GetOnBits())] = 1
        valid[i] = 1
    fp_id = hashlib.md5(fps.tobytes()).hexdigest()[:10]
    np.savez(f"/tmp/fp_{fp_id}.npz", fps=fps, valid=valid)
    return {
        "fingerprint_id": fp_id,
        "shape": list(fps.shape),
        "n_valid": int(valid.sum()),
        "descriptor": "MACCS",
    }


@mcp.tool()
def compute_physchem(smiles_list: list) -> dict:
    """RDKit physico-chemical descriptor vector (~200 features)."""
    from rdkit import Chem
    from rdkit.Chem import Descriptors
    from rdkit.ML.Descriptors import MoleculeDescriptors
    from rdkit import RDLogger
    RDLogger.DisableLog("rdApp.*")

    names = [d[0] for d in Descriptors._descList]
    calc = MoleculeDescriptors.MolecularDescriptorCalculator(names)

    fps = np.zeros((len(smiles_list), len(names)), dtype=np.float32)
    valid = np.zeros(len(smiles_list), dtype=np.uint8)
    for i, s in enumerate(smiles_list):
        m = Chem.MolFromSmiles(s)
        if m is None:
            continue
        try:
            v = calc.CalcDescriptors(m)
            fps[i] = [0.0 if (x is None or x != x) else float(x) for x in v]
            valid[i] = 1
        except Exception:
            valid[i] = 0
    fp_id = hashlib.md5(fps.tobytes()).hexdigest()[:10]
    np.savez(f"/tmp/fp_{fp_id}.npz", fps=fps, valid=valid)
    return {
        "fingerprint_id": fp_id,
        "shape": list(fps.shape),
        "n_valid": int(valid.sum()),
        "feature_names": names,
        "descriptor": "PHYSCHEM",
    }


@mcp.tool()
def get_murcko_scaffold(smiles_list: list) -> dict:
    """Bemis-Murcko scaffold SMILES for each input (None if invalid)."""
    from rdkit import Chem
    from rdkit.Chem.Scaffolds import MurckoScaffold
    from rdkit import RDLogger
    RDLogger.DisableLog("rdApp.*")

    scaffolds = []
    for s in smiles_list:
        m = Chem.MolFromSmiles(s)
        if m is None:
            scaffolds.append(None); continue
        sc = MurckoScaffold.GetScaffoldForMol(m)
        scaffolds.append(Chem.MolToSmiles(sc, canonical=True))
    return {
        "n_input": len(smiles_list),
        "scaffolds": scaffolds,
        "n_unique_scaffolds": len(set(s for s in scaffolds if s)),
    }


@mcp.tool()
def tanimoto_similarity_matrix(fingerprint_id: str,
                                row_indices: list = None,
                                col_indices: list = None) -> dict:
    """Compute Tanimoto similarity matrix on a saved fingerprint set.

    For binary fingerprints. If row_indices/col_indices are None, computes
    the full square matrix. The matrix is saved to /tmp and returned as a
    handle (matrix_id) plus summary stats; element access is via
    `tanimoto_pair`. Use small index lists for full retrieval.
    """
    fps = np.load(f"/tmp/fp_{fingerprint_id}.npz")["fps"].astype(np.uint8)
    if row_indices is None:
        row_indices = list(range(fps.shape[0]))
    if col_indices is None:
        col_indices = list(range(fps.shape[0]))
    A = fps[row_indices]
    B = fps[col_indices]
    inter = A.astype(np.int32) @ B.T.astype(np.int32)
    a_sum = A.sum(axis=1).reshape(-1, 1)
    b_sum = B.sum(axis=1).reshape(1, -1)
    union = a_sum + b_sum - inter
    union[union == 0] = 1
    sim = inter / union
    mat_id = hashlib.md5(sim.tobytes()).hexdigest()[:10]
    np.save(f"/tmp/sim_{mat_id}.npy", sim)
    return {
        "matrix_id": mat_id,
        "shape": list(sim.shape),
        "mean": round(float(sim.mean()), 4),
        "max_offdiag": round(float((sim - np.eye(*sim.shape) if sim.shape[0]==sim.shape[1] else sim).max()), 4),
    }


@mcp.tool()
def identify_activity_cliffs(smiles_list: list,
                             y_values: list,
                             similarity_metrics: list = None,
                             similarity_threshold: float = 0.9,
                             potency_threshold: float = 1.0,
                             radius: int = 2,
                             n_bits: int = 1024) -> dict:
    """Identify activity-cliff compounds using one or more similarity metrics.

    A pair (i, j) is a cliff if AT LEAST ONE of the selected similarity
    metrics gives Tanimoto/Levenshtein similarity >= similarity_threshold
    AND |y_i - y_j| >= potency_threshold (in log units). A compound is a
    `cliff_mol` if it participates in at least one cliff pair.

    Args:
        smiles_list: SMILES strings.
        y_values: matched bioactivity values (e.g. pKi, pEC50).
        similarity_metrics: list from {'ecfp', 'scaffold', 'smiles'}; default
            uses all three. ecfp=Morgan/ECFP4 Tanimoto on whole molecule;
            scaffold=ECFP Tanimoto on Bemis-Murcko scaffold; smiles=
            normalized Levenshtein similarity on the SMILES string.
        similarity_threshold: minimum similarity (default 0.9).
        potency_threshold: minimum log-units potency difference (default 1.0).

    Returns:
        dict with cliff_indices, cliff_pairs, cliff_mol mask, plus per-metric
        contribution counts.
    """
    from rdkit import Chem
    from rdkit.Chem import AllChem
    from rdkit.Chem.Scaffolds import MurckoScaffold
    from rdkit import RDLogger
    RDLogger.DisableLog("rdApp.*")
    metrics = similarity_metrics or ["ecfp", "scaffold", "smiles"]

    n = len(smiles_list)
    mols = [Chem.MolFromSmiles(s) for s in smiles_list]

    def _ecfp_sim(mlist):
        fps = np.zeros((len(mlist), n_bits), dtype=np.uint8)
        for i, m in enumerate(mlist):
            if m is None:
                continue
            bv = AllChem.GetMorganFingerprintAsBitVect(m, radius, nBits=n_bits)
            fps[i, list(bv.GetOnBits())] = 1
        inter = fps.astype(np.int32) @ fps.T.astype(np.int32)
        s_ = fps.sum(axis=1)
        union = s_.reshape(-1, 1) + s_.reshape(1, -1) - inter
        union[union == 0] = 1
        return inter / union

    sims = []
    if "ecfp" in metrics:
        sims.append(("ecfp", _ecfp_sim(mols)))
    if "scaffold" in metrics:
        scaff_mols = []
        for m in mols:
            if m is None:
                scaff_mols.append(None)
            else:
                try:
                    scaff_mols.append(MurckoScaffold.GetScaffoldForMol(m))
                except Exception:
                    scaff_mols.append(None)
        sims.append(("scaffold", _ecfp_sim(scaff_mols)))
    if "smiles" in metrics:
        # Levenshtein-based similarity on canonical SMILES
        canon = [Chem.MolToSmiles(m, canonical=True) if m is not None else "" for m in mols]
        sm_sim = np.zeros((n, n), dtype=np.float32)
        try:
            from Levenshtein import distance as lev_dist
        except ImportError:
            def lev_dist(a, b):
                if len(a) < len(b):
                    a, b = b, a
                if len(b) == 0:
                    return len(a)
                prev = list(range(len(b) + 1))
                for i, ca in enumerate(a):
                    cur = [i + 1]
                    for j, cb in enumerate(b):
                        cur.append(min(prev[j + 1] + 1, cur[j] + 1, prev[j] + (ca != cb)))
                    prev = cur
                return prev[-1]
        for i in range(n):
            for j in range(i + 1, n):
                a, b = canon[i], canon[j]
                if not a or not b:
                    continue
                d = lev_dist(a, b)
                sim_val = 1.0 - d / max(len(a), len(b))
                sm_sim[i, j] = sim_val; sm_sim[j, i] = sim_val
        sims.append(("smiles", sm_sim))

    y = np.asarray(y_values, dtype=float)
    delta = np.abs(y.reshape(-1, 1) - y.reshape(1, -1))
    combined = np.zeros((n, n), dtype=bool)
    metric_counts = {}
    for name, smat in sims:
        m_cliff = (smat >= similarity_threshold) & (delta >= potency_threshold)
        np.fill_diagonal(m_cliff, False)
        metric_counts[name] = int(m_cliff.sum() // 2)
        combined |= m_cliff
    np.fill_diagonal(combined, False)

    cliff_mask = combined.any(axis=1).astype(int)
    pairs = []
    iu = np.triu_indices_from(combined, k=1)
    for i, j in zip(*iu):
        if combined[i, j]:
            pairs.append([int(i), int(j)])
    return {
        "n_compounds": n,
        "n_cliff_compounds": int(cliff_mask.sum()),
        "n_cliff_pairs": len(pairs),
        "cliff_indices": [int(i) for i in np.where(cliff_mask)[0]],
        "cliff_mol_mask": [int(x) for x in cliff_mask],
        "cliff_pairs": pairs[:5000],
        "similarity_threshold": similarity_threshold,
        "potency_threshold": potency_threshold,
        "metrics_used": [m for m, _ in sims],
        "per_metric_pair_count": metric_counts,
    }


# ---------------------------------------------------------------------------
# ML training & evaluation
# ---------------------------------------------------------------------------

@mcp.tool()
def prepare_split(csv_path: str,
                  fingerprint_id: str,
                  split_strategy: str = "predefined") -> dict:
    """Build a train/test split aligned with a fingerprint set.

    Args:
        csv_path: Path to the ChEMBL CSV (must contain split, y [pEC50/pKi],
            cliff_mol columns).
        fingerprint_id: handle returned by compute_ecfp / compute_maccs /
            compute_physchem (must be in the same row order as the CSV).
        split_strategy: 'predefined' uses the CSV's `split` column;
            'scaffold' uses scaffold-based stratified random split.

    Returns:
        dict with split_id (handle for train_model/evaluate), train_size,
        test_size, n_cliff_test.
    """
    import csv as _csv
    rows = []
    with open(csv_path, newline="") as f:
        for r in _csv.DictReader(f):
            rows.append(r)
    fps = np.load(f"/tmp/fp_{fingerprint_id}.npz")["fps"]
    if fps.shape[0] != len(rows):
        return {"error": f"size mismatch fp={fps.shape[0]} csv={len(rows)}"}
    y_key = "y [pEC50/pKi]" if "y [pEC50/pKi]" in rows[0] else "y"
    y = np.array([float(r[y_key]) for r in rows], dtype=float)
    cliff = np.array([int(r.get("cliff_mol", 0)) for r in rows])
    if split_strategy == "predefined":
        train_idx = [i for i, r in enumerate(rows) if r["split"] == "train"]
        test_idx = [i for i, r in enumerate(rows) if r["split"] == "test"]
    elif split_strategy == "scaffold":
        from rdkit import Chem
        from rdkit.Chem.Scaffolds import MurckoScaffold
        from rdkit import RDLogger
        RDLogger.DisableLog("rdApp.*")
        scaff = []
        for r in rows:
            m = Chem.MolFromSmiles(r["smiles"])
            scaff.append(Chem.MolToSmiles(MurckoScaffold.GetScaffoldForMol(m), canonical=True) if m else "")
        groups = {}
        for i, s in enumerate(scaff):
            groups.setdefault(s, []).append(i)
        rng = np.random.default_rng(0)
        keys = list(groups.keys()); rng.shuffle(keys)
        cumul = 0; cutoff = int(0.8 * len(rows))
        train_idx, test_idx = [], []
        for k in keys:
            if cumul < cutoff:
                train_idx.extend(groups[k]); cumul += len(groups[k])
            else:
                test_idx.extend(groups[k])
    else:
        return {"error": f"unknown split_strategy: {split_strategy}"}

    split_id = hashlib.md5(
        (fingerprint_id + str(train_idx[:5]) + str(test_idx[:5])).encode()
    ).hexdigest()[:10]
    np.savez(f"/tmp/split_{split_id}.npz",
             X_train=fps[train_idx], X_test=fps[test_idx],
             y_train=y[train_idx], y_test=y[test_idx],
             cliff_test=cliff[test_idx],
             train_idx=np.array(train_idx), test_idx=np.array(test_idx))
    return {
        "split_id": split_id,
        "fingerprint_id": fingerprint_id,
        "split_strategy": split_strategy,
        "train_size": len(train_idx),
        "test_size": len(test_idx),
        "n_cliff_test": int(cliff[test_idx].sum()),
    }


@mcp.tool()
def train_model(split_id: str, model_type: str,
                model_params: dict = None) -> dict:
    """Train a regression model on a split.

    Args:
        split_id: handle from prepare_split.
        model_type: 'svm' (RBF SVR), 'rf' (RandomForest), 'gbm' (GradientBoosting),
            'knn' (KNeighborsRegressor), 'mlp' (MLPRegressor).
        model_params: optional sklearn kwargs.

    Returns:
        dict with model_id (used by evaluate_predictions / get_predictions).
    """
    from sklearn.preprocessing import StandardScaler
    sp = np.load(f"/tmp/split_{split_id}.npz")
    Xtr, ytr = sp["X_train"].astype(np.float32), sp["y_train"]

    scaler = StandardScaler(with_mean=False)  # supports sparse-like binary
    Xtr_s = scaler.fit_transform(Xtr)

    params = model_params or {}
    if model_type == "svm":
        from sklearn.svm import SVR
        model = SVR(**({"kernel": "rbf", "C": 1.0, "gamma": "scale"} | params))
    elif model_type == "rf":
        from sklearn.ensemble import RandomForestRegressor
        model = RandomForestRegressor(**({"n_estimators": 200, "random_state": 0,
                                           "n_jobs": -1} | params))
    elif model_type == "gbm":
        from sklearn.ensemble import GradientBoostingRegressor
        model = GradientBoostingRegressor(**({"n_estimators": 200, "random_state": 0} | params))
    elif model_type == "knn":
        from sklearn.neighbors import KNeighborsRegressor
        model = KNeighborsRegressor(**({"n_neighbors": 5, "metric": "jaccard"} | params))
    elif model_type == "mlp":
        from sklearn.neural_network import MLPRegressor
        model = MLPRegressor(**({"hidden_layer_sizes": (256, 128),
                                  "max_iter": 300, "random_state": 0,
                                  "early_stopping": True} | params))
    else:
        return {"error": f"unknown model_type {model_type}"}

    model.fit(Xtr_s, ytr)
    model_id = hashlib.md5(pickle.dumps((split_id, model_type, params))).hexdigest()[:10]
    with open(f"/tmp/model_{model_id}.pkl", "wb") as f:
        pickle.dump({"model": model, "scaler": scaler,
                     "split_id": split_id, "model_type": model_type}, f)
    return {"model_id": model_id, "model_type": model_type,
            "split_id": split_id, "train_size": int(len(ytr))}


@mcp.tool()
def evaluate_predictions(model_id: str) -> dict:
    """Evaluate a trained model on its test split.

    Returns RMSE on the full test set and RMSE_cliff on the activity-cliff
    subset (cliff_test mask). This is the metric used by the MoleculeACE
    benchmark.
    """
    with open(f"/tmp/model_{model_id}.pkl", "rb") as f:
        st = pickle.load(f)
    sp = np.load(f"/tmp/split_{st['split_id']}.npz")
    Xte = sp["X_test"].astype(np.float32)
    yte = sp["y_test"]; cliff = sp["cliff_test"]
    Xte_s = st["scaler"].transform(Xte)
    pred = st["model"].predict(Xte_s)

    err = pred - yte
    rmse = float(np.sqrt((err ** 2).mean()))
    cliff_mask = cliff.astype(bool)
    if cliff_mask.any():
        rmse_cliff = float(np.sqrt((err[cliff_mask] ** 2).mean()))
        rmse_noncliff = float(np.sqrt((err[~cliff_mask] ** 2).mean())) if (~cliff_mask).any() else None
    else:
        rmse_cliff = None; rmse_noncliff = rmse
    return {
        "model_id": model_id,
        "model_type": st["model_type"],
        "n_test": int(len(yte)),
        "n_cliff_test": int(cliff_mask.sum()),
        "rmse": round(rmse, 4),
        "rmse_cliff": round(rmse_cliff, 4) if rmse_cliff is not None else None,
        "rmse_noncliff": round(rmse_noncliff, 4) if rmse_noncliff is not None else None,
        "cliff_gap": round(rmse_cliff - rmse, 4) if rmse_cliff is not None else None,
    }


@mcp.tool()
def get_predictions(model_id: str) -> dict:
    """Return raw predictions and true values for the test set, plus the
    cliff_test mask. Use to plot residuals or per-target diagnostics."""
    with open(f"/tmp/model_{model_id}.pkl", "rb") as f:
        st = pickle.load(f)
    sp = np.load(f"/tmp/split_{st['split_id']}.npz")
    Xte = st["scaler"].transform(sp["X_test"].astype(np.float32))
    pred = st["model"].predict(Xte)
    return {
        "model_id": model_id,
        "predictions": [round(float(x), 4) for x in pred],
        "true_values": [round(float(x), 4) for x in sp["y_test"]],
        "cliff_test_mask": [int(x) for x in sp["cliff_test"]],
        "n_test": int(len(pred)),
    }


@mcp.tool()
def benchmark_methods(csv_path: str,
                      methods: list = None,
                      descriptors: list = None) -> dict:
    """Run multiple (model, descriptor) combinations on a single dataset.

    For each combination: build fingerprints, prepare predefined split,
    train, evaluate. Returns a sorted ranking by RMSE_cliff.

    Args:
        csv_path: Absolute path to a CHEMBL*.csv.
        methods: subset of ['svm', 'rf', 'gbm', 'knn', 'mlp']. Defaults to all.
        descriptors: subset of ['ECFP', 'MACCS', 'PHYSCHEM']. Defaults to all.
    """
    methods = methods or ["svm", "rf", "gbm", "knn", "mlp"]
    descriptors = descriptors or ["ECFP", "MACCS", "PHYSCHEM"]

    import csv as _csv
    with open(csv_path, newline="") as f:
        rows = list(_csv.DictReader(f))
    smiles = [r["smiles"] for r in rows]

    results = []
    for desc in descriptors:
        if desc == "ECFP":
            fp = compute_ecfp(smiles)
        elif desc == "MACCS":
            fp = compute_maccs(smiles)
        elif desc == "PHYSCHEM":
            fp = compute_physchem(smiles)
        else:
            continue
        fp_id = fp["fingerprint_id"]
        split = prepare_split(csv_path, fp_id, "predefined")
        sid = split["split_id"]
        for mt in methods:
            m = train_model(sid, mt)
            if "error" in m:
                results.append({"method": f"{mt}-{desc}", "error": m["error"]})
                continue
            ev = evaluate_predictions(m["model_id"])
            results.append({
                "method": f"{mt.upper()}-{desc}",
                "rmse": ev["rmse"],
                "rmse_cliff": ev["rmse_cliff"],
                "cliff_gap": ev["cliff_gap"],
            })
    results.sort(key=lambda r: r.get("rmse_cliff", 9.99))
    return {
        "dataset": os.path.basename(csv_path),
        "n_runs": len(results),
        "ranking": results,
    }


# ---------------------------------------------------------------------------
# Plotting
# ---------------------------------------------------------------------------

@mcp.tool()
def plot_published_method_ranking(results_csv: str, output_path: str,
                                  title: str = "Published 24-method ranking") -> dict:
    """Plot mean RMSE and RMSEcliff ranking from the published benchmark table."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    ranking = summarize_published_method_ranges(results_csv).get("ranking", [])
    if not ranking:
        return {"error": "no ranking rows"}
    names = [r["method_descriptor"] for r in ranking]
    rmse = [r["mean_rmse"] for r in ranking]
    cliff = [r["mean_rmse_cliff"] for r in ranking]

    fig, ax = plt.subplots(figsize=(10, max(5, 0.35 * len(names))))
    y = np.arange(len(names))
    ax.barh(y - 0.2, rmse, height=0.4, color="steelblue", label="RMSE")
    ax.barh(y + 0.2, cliff, height=0.4, color="salmon", label="RMSEcliff")
    ax.set_yticks(y); ax.set_yticklabels(names, fontsize=8)
    ax.invert_yaxis()
    ax.set_xlabel("Mean error across targets (log units)")
    ax.set_title(title)
    ax.legend(loc="lower right")
    fig.tight_layout()
    fig.savefig(output_path, dpi=170)
    plt.close(fig)
    return {"output_path": output_path, "n_methods": len(names)}


@mcp.tool()
def plot_published_rmse_scatter(results_csv: str, output_path: str,
                                title: str = "RMSE vs RMSEcliff (published table)") -> dict:
    """Plot all method-target points in RMSE/RMSEcliff space."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    rows = _read_published_results(results_csv)
    colors = {
        "GRAPH": "#f58518",
        "SMILES": "#54a24b",
        "TOKENS": "#b279a2",
        "ECFP": "#4c78a8",
        "MACCS": "#72b7b2",
        "PHYSCHEM": "#ff9da6",
        "WHIM": "#9d755d",
    }
    fig, ax = plt.subplots(figsize=(7, 6.5))
    for desc, color in colors.items():
        subset = [r for r in rows if r["descriptor"] == desc]
        if not subset:
            continue
        ax.scatter([r["rmse"] for r in subset],
                   [r["rmse_cliff"] for r in subset],
                   s=18, alpha=0.55, c=color, label=desc, edgecolors="none")
    lo = min(min(r["rmse"], r["rmse_cliff"]) for r in rows)
    hi = max(max(r["rmse"], r["rmse_cliff"]) for r in rows)
    ax.plot([lo, hi], [lo, hi], "k--", lw=1)
    ax.set_xlabel("RMSE")
    ax.set_ylabel("RMSEcliff")
    ax.set_title(title)
    ax.legend(ncol=2, fontsize=8)
    fig.tight_layout()
    fig.savefig(output_path, dpi=170)
    plt.close(fig)
    return {"output_path": output_path, "n_points": len(rows)}


@mcp.tool()
def plot_published_target_gap(results_csv: str,
                              output_path: str,
                              method: str = "SVM",
                              descriptor: str = "ECFP",
                              title: str = "Target-level RMSE vs RMSEcliff") -> dict:
    """Plot target-level gap profile for one method-descriptor pair."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    summary = summarize_published_target_gap(results_csv, method=method, descriptor=descriptor)
    if "error" in summary:
        return summary
    rows = summary["target_gap"]
    labels = [r["dataset"] for r in rows]
    rmse = [r["rmse"] for r in rows]
    cliff = [r["rmse_cliff"] for r in rows]
    x = np.arange(len(rows))

    fig, ax = plt.subplots(figsize=(11, 4.8))
    ax.plot(x, rmse, marker="o", markersize=3, linewidth=1.4, color="#4c78a8", label="RMSE")
    ax.plot(x, cliff, marker="o", markersize=3, linewidth=1.4, color="#e45756", label="RMSEcliff")
    ax.fill_between(x, rmse, cliff, color="#e45756", alpha=0.15)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=70, ha="right", fontsize=7)
    ax.set_ylabel("Error (log units)")
    ax.set_title(f"{title}: {method.upper()}-{descriptor.upper()}")
    ax.legend(loc="upper right")
    fig.tight_layout()
    fig.savefig(output_path, dpi=170)
    plt.close(fig)
    return {"output_path": output_path, "n_targets": len(rows)}


@mcp.tool()
def plot_method_ranking(ranking: list, output_path: str,
                         title: str = "Activity-cliff benchmark") -> dict:
    """Bar chart of RMSE vs RMSE_cliff for a list of {method, rmse, rmse_cliff} dicts."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    ranking = [r for r in ranking if "rmse_cliff" in r and r["rmse_cliff"] is not None]
    ranking.sort(key=lambda r: r["rmse_cliff"])
    names = [r["method"] for r in ranking]
    rmse = [r["rmse"] for r in ranking]
    cliff = [r["rmse_cliff"] for r in ranking]
    fig, ax = plt.subplots(figsize=(10, max(4, 0.35 * len(names))))
    y = np.arange(len(names))
    ax.barh(y - 0.2, rmse, height=0.4, color="steelblue", label="RMSE (test)")
    ax.barh(y + 0.2, cliff, height=0.4, color="salmon", label="RMSE (cliff)")
    ax.set_yticks(y); ax.set_yticklabels(names)
    ax.set_xlabel("RMSE (log units)")
    ax.set_title(title)
    ax.invert_yaxis(); ax.legend(loc="lower right")
    fig.tight_layout(); fig.savefig(output_path, dpi=150); plt.close(fig)
    return {"output_path": output_path, "n_methods": len(names)}


@mcp.tool()
def plot_pred_vs_true(predictions: list, true_values: list,
                      cliff_mask: list = None,
                      output_path: str = "artifacts/pred_vs_true.png",
                      title: str = "Predicted vs True") -> dict:
    """Scatter of predicted vs true bioactivity, optionally colouring cliff vs non-cliff."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    pred = np.asarray(predictions, dtype=float)
    true = np.asarray(true_values, dtype=float)
    fig, ax = plt.subplots(figsize=(6.5, 6))
    if cliff_mask is not None:
        cm = np.asarray(cliff_mask, dtype=bool)
        ax.scatter(true[~cm], pred[~cm], s=10, alpha=0.4, c="steelblue",
                   label="non-cliff")
        ax.scatter(true[cm], pred[cm], s=14, alpha=0.7, c="salmon",
                   label="cliff", edgecolor="darkred", linewidths=0.3)
        ax.legend()
    else:
        ax.scatter(true, pred, s=10, alpha=0.4)
    lo = float(min(true.min(), pred.min()))
    hi = float(max(true.max(), pred.max()))
    ax.plot([lo, hi], [lo, hi], "k--", lw=1, alpha=0.5)
    ax.set_xlabel("True (log units)"); ax.set_ylabel("Predicted (log units)")
    ax.set_title(title); fig.tight_layout()
    fig.savefig(output_path, dpi=150); plt.close(fig)
    return {"output_path": output_path, "n_points": int(len(pred))}


@mcp.tool()
def plot_similarity_heatmap(fingerprint_id: str, indices: list,
                             output_path: str,
                             title: str = "Tanimoto similarity") -> dict:
    """Heatmap of pairwise Tanimoto similarity for a (small) compound subset."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fps = np.load(f"/tmp/fp_{fingerprint_id}.npz")["fps"][indices].astype(np.uint8)
    inter = fps.astype(np.int32) @ fps.T.astype(np.int32)
    s_ = fps.sum(axis=1)
    union = s_.reshape(-1, 1) + s_.reshape(1, -1) - inter
    union[union == 0] = 1
    sim = inter / union
    fig, ax = plt.subplots(figsize=(7, 6))
    im = ax.imshow(sim, cmap="viridis", vmin=0, vmax=1)
    fig.colorbar(im, ax=ax, label="Tanimoto")
    ax.set_title(title); fig.tight_layout()
    fig.savefig(output_path, dpi=150); plt.close(fig)
    return {"output_path": output_path, "n": int(len(indices))}


if __name__ == "__main__":
    mcp.run(transport="stdio")

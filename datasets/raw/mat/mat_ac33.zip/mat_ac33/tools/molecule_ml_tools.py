#!/usr/bin/env python3
"""Domain tools for molecular ML benchmarking on activity-cliff datasets.

Low-level primitives only:
- ChEMBL bioactivity CSV loading (smiles, y, cliff_mol, split columns)
- SMILES validation, canonicalisation
- Morgan / ECFP fingerprinting (radius and nBits configurable)
- MACCS keys
- Bemis-Murcko scaffold extraction
- Tanimoto similarity matrix
- Activity-cliff identification given a similarity threshold and bioactivity
  delta (in log units)
- Train/test split helpers (use the pre-computed `split` column or scaffold
  split)
- Model training: SVM-RBF, RF, GBM, KNN, MLP on dense feature vectors
- Per-set RMSE metrics that distinguish all-test vs cliff-only-test
- Plotting utilities (RMSE bar, scatter, similarity heatmap)
"""

import json
import os
import pickle
import hashlib
from typing import Any
import numpy as np

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Molecule_ACE_Tools")


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------

@mcp.tool()
def load_chembl_csv(csv_path: str) -> dict:
    """Load a MoleculeACE-format ChEMBL bioactivity CSV.

    Expected columns: smiles, exp_mean [nM], y, cliff_mol, split,
    y [pEC50/pKi]. Returns dataset summary plus per-row records.

    Args:
        csv_path: Absolute path to a CHEMBL*.csv file.

    Returns:
        dict with n_compounds, n_train, n_test, n_cliff, n_cliff_test,
        column_names, and records (list of dicts).
    """
    import csv as _csv
    rows = []
    with open(csv_path, newline="") as f:
        for r in _csv.DictReader(f):
            rows.append(r)
    train = [r for r in rows if r.get("split") == "train"]
    test = [r for r in rows if r.get("split") == "test"]
    cliff = [r for r in rows if str(r.get("cliff_mol")) == "1"]
    cliff_test = [r for r in test if str(r.get("cliff_mol")) == "1"]
    return {
        "csv_path": csv_path,
        "n_compounds": len(rows),
        "n_train": len(train),
        "n_test": len(test),
        "n_cliff": len(cliff),
        "n_cliff_test": len(cliff_test),
        "pct_cliff": round(100.0 * len(cliff) / max(len(rows), 1), 2),
        "column_names": list(rows[0].keys()) if rows else [],
        "records": rows,
    }


@mcp.tool()
def list_benchmark_datasets(data_dir: str) -> dict:
    """Enumerate all ChEMBL benchmark datasets in a directory.

    Walks `data_dir` for CHEMBL*.csv files, returns summary statistics for
    each (n_compounds, %cliffs, response type from filename).
    """
    import csv as _csv
    out = []
    for fn in sorted(os.listdir(data_dir)):
        if not fn.startswith("CHEMBL") or not fn.endswith(".csv"):
            continue
        path = os.path.join(data_dir, fn)
        with open(path, newline="") as f:
            rows = list(_csv.DictReader(f))
        cliff = sum(1 for r in rows if str(r.get("cliff_mol")) == "1")
        out.append({
            "file": fn,
            "chembl_id": fn.split("_")[0],
            "response_type": fn.split("_")[1].split(".")[0],
            "n_compounds": len(rows),
            "n_cliff": cliff,
            "pct_cliff": round(100.0 * cliff / max(len(rows), 1), 2),
        })
    return {"n_datasets": len(out), "datasets": out}


# ---------------------------------------------------------------------------
# Cheminformatics primitives
# ---------------------------------------------------------------------------

@mcp.tool()
def canonicalise_smiles(smiles_list: list) -> dict:
    """Validate and canonicalise SMILES strings via RDKit.

    Returns canonical SMILES (None for invalid) and an indicator vector.
    """
    from rdkit import Chem
    from rdkit import RDLogger
    RDLogger.DisableLog("rdApp.*")

    canon, valid = [], []
    for s in smiles_list:
        m = Chem.MolFromSmiles(s)
        if m is None:
            canon.append(None); valid.append(0)
        else:
            canon.append(Chem.MolToSmiles(m, canonical=True)); valid.append(1)
    return {
        "n_input": len(smiles_list),
        "n_valid": int(sum(valid)),
        "canonical_smiles": canon,
        "valid_mask": valid,
    }


@mcp.tool()
def compute_ecfp(smiles_list: list, radius: int = 2, n_bits: int = 1024) -> dict:
    """Extended-Connectivity Fingerprints (Morgan, equivalent to ECFP4 at r=2).

    Args:
        smiles_list: list of SMILES strings.
        radius: Morgan radius (2 -> ECFP4, 3 -> ECFP6).
        n_bits: folded fingerprint length.

    Returns:
        dict with `fingerprint_id` (handle for downstream tools) and shape.
    """
    from rdkit import Chem
    from rdkit.Chem import AllChem
    from rdkit import RDLogger
    RDLogger.DisableLog("rdApp.*")

    fps = np.zeros((len(smiles_list), n_bits), dtype=np.uint8)
    valid = np.zeros(len(smiles_list), dtype=np.uint8)
    for i, s in enumerate(smiles_list):
        m = Chem.MolFromSmiles(s)
        if m is None:
            continue
        bv = AllChem.GetMorganFingerprintAsBitVect(m, radius, nBits=n_bits)
        on_bits = list(bv.GetOnBits())
        fps[i, on_bits] = 1
        valid[i] = 1

    fp_id = hashlib.md5(fps.tobytes()).hexdigest()[:10]
    np.savez(f"/tmp/fp_{fp_id}.npz", fps=fps, valid=valid)
    return {
        "fingerprint_id": fp_id,
        "shape": list(fps.shape),
        "n_valid": int(valid.sum()),
        "radius": radius,
        "n_bits": n_bits,
        "descriptor": "ECFP",
    }


@mcp.tool()
def compute_maccs(smiles_list: list) -> dict:
    """MACCS structural keys (167-bit). Returns a fingerprint_id handle."""
    from rdkit import Chem
    from rdkit.Chem import MACCSkeys
    from rdkit import RDLogger
    RDLogger.DisableLog("rdApp.*")

    fps = np.zeros((len(smiles_list), 167), dtype=np.uint8)
    valid = np.zeros(len(smiles_list), dtype=np.uint8)
    for i, s in enumerate(smiles_list):
        m = Chem.MolFromSmiles(s)
        if m is None:
            continue
        bv = MACCSkeys.GenMACCSKeys(m)
        fps[i, list(bv.GetOnBits())] = 1
        valid[i] = 1
    fp_id = hashlib.md5(fps.tobytes()).hexdigest()[:10]
    np.savez(f"/tmp/fp_{fp_id}.npz", fps=fps, valid=valid)
    return {
        "fingerprint_id": fp_id,
        "shape": list(fps.shape),
        "n_valid": int(valid.sum()),
        "descriptor": "MACCS",
    }


@mcp.tool()
def compute_physchem(smiles_list: list) -> dict:
    """RDKit physico-chemical descriptor vector (~200 features)."""
    from rdkit import Chem
    from rdkit.Chem import Descriptors
    from rdkit.ML.Descriptors import MoleculeDescriptors
    from rdkit import RDLogger
    RDLogger.DisableLog("rdApp.*")

    names = [d[0] for d in Descriptors._descList]
    calc = MoleculeDescriptors.MolecularDescriptorCalculator(names)

    fps = np.zeros((len(smiles_list), len(names)), dtype=np.float32)
    valid = np.zeros(len(smiles_list), dtype=np.uint8)
    for i, s in enumerate(smiles_list):
        m = Chem.MolFromSmiles(s)
        if m is None:
            continue
        try:
            v = calc.CalcDescriptors(m)
            fps[i] = [0.0 if (x is None or x != x) else float(x) for x in v]
            valid[i] = 1
        except Exception:
            valid[i] = 0
    fp_id = hashlib.md5(fps.tobytes()).hexdigest()[:10]
    np.savez(f"/tmp/fp_{fp_id}.npz", fps=fps, valid=valid)
    return {
        "fingerprint_id": fp_id,
        "shape": list(fps.shape),
        "n_valid": int(valid.sum()),
        "feature_names": names,
        "descriptor": "PHYSCHEM",
    }


@mcp.tool()
def get_murcko_scaffold(smiles_list: list) -> dict:
    """Bemis-Murcko scaffold SMILES for each input (None if invalid)."""
    from rdkit import Chem
    from rdkit.Chem.Scaffolds import MurckoScaffold
    from rdkit import RDLogger
    RDLogger.DisableLog("rdApp.*")

    scaffolds = []
    for s in smiles_list:
        m = Chem.MolFromSmiles(s)
        if m is None:
            scaffolds.append(None); continue
        sc = MurckoScaffold.GetScaffoldForMol(m)
        scaffolds.append(Chem.MolToSmiles(sc, canonical=True))
    return {
        "n_input": len(smiles_list),
        "scaffolds": scaffolds,
        "n_unique_scaffolds": len(set(s for s in scaffolds if s)),
    }


@mcp.tool()
def tanimoto_similarity_matrix(fingerprint_id: str,
                                row_indices: list = None,
                                col_indices: list = None) -> dict:
    """Compute Tanimoto similarity matrix on a saved fingerprint set.

    For binary fingerprints. If row_indices/col_indices are None, computes
    the full square matrix. The matrix is saved to /tmp and returned as a
    handle (matrix_id) plus summary stats; element access is via
    `tanimoto_pair`. Use small index lists for full retrieval.
    """
    fps = np.load(f"/tmp/fp_{fingerprint_id}.npz")["fps"].astype(np.uint8)
    if row_indices is None:
        row_indices = list(range(fps.shape[0]))
    if col_indices is None:
        col_indices = list(range(fps.shape[0]))
    A = fps[row_indices]
    B = fps[col_indices]
    inter = A.astype(np.int32) @ B.T.astype(np.int32)
    a_sum = A.sum(axis=1).reshape(-1, 1)
    b_sum = B.sum(axis=1).reshape(1, -1)
    union = a_sum + b_sum - inter
    union[union == 0] = 1
    sim = inter / union
    mat_id = hashlib.md5(sim.tobytes()).hexdigest()[:10]
    np.save(f"/tmp/sim_{mat_id}.npy", sim)
    return {
        "matrix_id": mat_id,
        "shape": list(sim.shape),
        "mean": round(float(sim.mean()), 4),
        "max_offdiag": round(float((sim - np.eye(*sim.shape) if sim.shape[0]==sim.shape[1] else sim).max()), 4),
    }


@mcp.tool()
def identify_activity_cliffs(smiles_list: list,
                             y_values: list,
                             similarity_metrics: list = None,
                             similarity_threshold: float = 0.9,
                             potency_threshold: float = 1.0,
                             radius: int = 2,
                             n_bits: int = 1024) -> dict:
    """Identify activity-cliff compounds using one or more similarity metrics.

    A pair (i, j) is a cliff if AT LEAST ONE of the selected similarity
    metrics gives Tanimoto/Levenshtein similarity >= similarity_threshold
    AND |y_i - y_j| >= potency_threshold (in log units). A compound is a
    `cliff_mol` if it participates in at least one cliff pair.

    Args:
        smiles_list: SMILES strings.
        y_values: matched bioactivity values (e.g. pKi, pEC50).
        similarity_metrics: list from {'ecfp', 'scaffold', 'smiles'}; default
            uses all three. ecfp=Morgan/ECFP4 Tanimoto on whole molecule;
            scaffold=ECFP Tanimoto on Bemis-Murcko scaffold; smiles=
            normalized Levenshtein similarity on the SMILES string.
        similarity_threshold: minimum similarity (default 0.9).
        potency_threshold: minimum log-units potency difference (default 1.0).

    Returns:
        dict with cliff_indices, cliff_pairs, cliff_mol mask, plus per-metric
        contribution counts.
    """
    from rdkit import Chem
    from rdkit.Chem import AllChem
    from rdkit.Chem.Scaffolds import MurckoScaffold
    from rdkit import RDLogger
    RDLogger.DisableLog("rdApp.*")
    metrics = similarity_metrics or ["ecfp", "scaffold", "smiles"]

    n = len(smiles_list)
    mols = [Chem.MolFromSmiles(s) for s in smiles_list]

    def _ecfp_sim(mlist):
        fps = np.zeros((len(mlist), n_bits), dtype=np.uint8)
        for i, m in enumerate(mlist):
            if m is None:
                continue
            bv = AllChem.GetMorganFingerprintAsBitVect(m, radius, nBits=n_bits)
            fps[i, list(bv.GetOnBits())] = 1
        inter = fps.astype(np.int32) @ fps.T.astype(np.int32)
        s_ = fps.sum(axis=1)
        union = s_.reshape(-1, 1) + s_.reshape(1, -1) - inter
        union[union == 0] = 1
        return inter / union

    sims = []
    if "ecfp" in metrics:
        sims.append(("ecfp", _ecfp_sim(mols)))
    if "scaffold" in metrics:
        scaff_mols = []
        for m in mols:
            if m is None:
                scaff_mols.append(None)
            else:
                try:
                    scaff_mols.append(MurckoScaffold.GetScaffoldForMol(m))
                except Exception:
                    scaff_mols.append(None)
        sims.append(("scaffold", _ecfp_sim(scaff_mols)))
    if "smiles" in metrics:
        # Levenshtein-based similarity on canonical SMILES
        canon = [Chem.MolToSmiles(m, canonical=True) if m is not None else "" for m in mols]
        sm_sim = np.zeros((n, n), dtype=np.float32)
        try:
            from Levenshtein import distance as lev_dist
        except ImportError:
            def lev_dist(a, b):
                if len(a) < len(b):
                    a, b = b, a
                if len(b) == 0:
                    return len(a)
                prev = list(range(len(b) + 1))
                for i, ca in enumerate(a):
                    cur = [i + 1]
                    for j, cb in enumerate(b):
                        cur.append(min(prev[j + 1] + 1, cur[j] + 1, prev[j] + (ca != cb)))
                    prev = cur
                return prev[-1]
        for i in range(n):
            for j in range(i + 1, n):
                a, b = canon[i], canon[j]
                if not a or not b:
                    continue
                d = lev_dist(a, b)
                sim_val = 1.0 - d / max(len(a), len(b))
                sm_sim[i, j] = sim_val; sm_sim[j, i] = sim_val
        sims.append(("smiles", sm_sim))

    y = np.asarray(y_values, dtype=float)
    delta = np.abs(y.reshape(-1, 1) - y.reshape(1, -1))
    combined = np.zeros((n, n), dtype=bool)
    metric_counts = {}
    for name, smat in sims:
        m_cliff = (smat >= similarity_threshold) & (delta >= potency_threshold)
        np.fill_diagonal(m_cliff, False)
        metric_counts[name] = int(m_cliff.sum() // 2)
        combined |= m_cliff
    np.fill_diagonal(combined, False)

    cliff_mask = combined.any(axis=1).astype(int)
    pairs = []
    iu = np.triu_indices_from(combined, k=1)
    for i, j in zip(*iu):
        if combined[i, j]:
            pairs.append([int(i), int(j)])
    return {
        "n_compounds": n,
        "n_cliff_compounds": int(cliff_mask.sum()),
        "n_cliff_pairs": len(pairs),
        "cliff_indices": [int(i) for i in np.where(cliff_mask)[0]],
        "cliff_mol_mask": [int(x) for x in cliff_mask],
        "cliff_pairs": pairs[:5000],
        "similarity_threshold": similarity_threshold,
        "potency_threshold": potency_threshold,
        "metrics_used": [m for m, _ in sims],
        "per_metric_pair_count": metric_counts,
    }


# ---------------------------------------------------------------------------
# ML training & evaluation
# ---------------------------------------------------------------------------

@mcp.tool()
def prepare_split(csv_path: str,
                  fingerprint_id: str,
                  split_strategy: str = "predefined") -> dict:
    """Build a train/test split aligned with a fingerprint set.

    Args:
        csv_path: Path to the ChEMBL CSV (must contain split, y [pEC50/pKi],
            cliff_mol columns).
        fingerprint_id: handle returned by compute_ecfp / compute_maccs /
            compute_physchem (must be in the same row order as the CSV).
        split_strategy: 'predefined' uses the CSV's `split` column;
            'scaffold' uses scaffold-based stratified random split.

    Returns:
        dict with split_id (handle for train_model/evaluate), train_size,
        test_size, n_cliff_test.
    """
    import csv as _csv
    rows = []
    with open(csv_path, newline="") as f:
        for r in _csv.DictReader(f):
            rows.append(r)
    fps = np.load(f"/tmp/fp_{fingerprint_id}.npz")["fps"]
    if fps.shape[0] != len(rows):
        return {"error": f"size mismatch fp={fps.shape[0]} csv={len(rows)}"}
    y_key = "y [pEC50/pKi]" if "y [pEC50/pKi]" in rows[0] else "y"
    y = np.array([float(r[y_key]) for r in rows], dtype=float)
    cliff = np.array([int(r.get("cliff_mol", 0)) for r in rows])
    if split_strategy == "predefined":
        train_idx = [i for i, r in enumerate(rows) if r["split"] == "train"]
        test_idx = [i for i, r in enumerate(rows) if r["split"] == "test"]
    elif split_strategy == "scaffold":
        from rdkit import Chem
        from rdkit.Chem.Scaffolds import MurckoScaffold
        from rdkit import RDLogger
        RDLogger.DisableLog("rdApp.*")
        scaff = []
        for r in rows:
            m = Chem.MolFromSmiles(r["smiles"])
            scaff.append(Chem.MolToSmiles(MurckoScaffold.GetScaffoldForMol(m), canonical=True) if m else "")
        groups = {}
        for i, s in enumerate(scaff):
            groups.setdefault(s, []).append(i)
        rng = np.random.default_rng(0)
        keys = list(groups.keys()); rng.shuffle(keys)
        cumul = 0; cutoff = int(0.8 * len(rows))
        train_idx, test_idx = [], []
        for k in keys:
            if cumul < cutoff:
                train_idx.extend(groups[k]); cumul += len(groups[k])
            else:
                test_idx.extend(groups[k])
    else:
        return {"error": f"unknown split_strategy: {split_strategy}"}

    split_id = hashlib.md5(
        (fingerprint_id + str(train_idx[:5]) + str(test_idx[:5])).encode()
    ).hexdigest()[:10]
    np.savez(f"/tmp/split_{split_id}.npz",
             X_train=fps[train_idx], X_test=fps[test_idx],
             y_train=y[train_idx], y_test=y[test_idx],
             cliff_test=cliff[test_idx],
             train_idx=np.array(train_idx), test_idx=np.array(test_idx))
    return {
        "split_id": split_id,
        "fingerprint_id": fingerprint_id,
        "split_strategy": split_strategy,
        "train_size": len(train_idx),
        "test_size": len(test_idx),
        "n_cliff_test": int(cliff[test_idx].sum()),
    }


@mcp.tool()
def train_model(split_id: str, model_type: str,
                model_params: dict = None) -> dict:
    """Train a regression model on a split.

    Args:
        split_id: handle from prepare_split.
        model_type: 'svm' (RBF SVR), 'rf' (RandomForest), 'gbm' (GradientBoosting),
            'knn' (KNeighborsRegressor), 'mlp' (MLPRegressor).
        model_params: optional sklearn kwargs.

    Returns:
        dict with model_id (used by evaluate_predictions / get_predictions).
    """
    from sklearn.preprocessing import StandardScaler
    sp = np.load(f"/tmp/split_{split_id}.npz")
    Xtr, ytr = sp["X_train"].astype(np.float32), sp["y_train"]

    scaler = StandardScaler(with_mean=False)  # supports sparse-like binary
    Xtr_s = scaler.fit_transform(Xtr)

    params = model_params or {}
    if model_type == "svm":
        from sklearn.svm import SVR
        model = SVR(**({"kernel": "rbf", "C": 1.0, "gamma": "scale"} | params))
    elif model_type == "rf":
        from sklearn.ensemble import RandomForestRegressor
        model = RandomForestRegressor(**({"n_estimators": 200, "random_state": 0,
                                           "n_jobs": -1} | params))
    elif model_type == "gbm":
        from sklearn.ensemble import GradientBoostingRegressor
        model = GradientBoostingRegressor(**({"n_estimators": 200, "random_state": 0} | params))
    elif model_type == "knn":
        from sklearn.neighbors import KNeighborsRegressor
        model = KNeighborsRegressor(**({"n_neighbors": 5, "metric": "jaccard"} | params))
    elif model_type == "mlp":
        from sklearn.neural_network import MLPRegressor
        model = MLPRegressor(**({"hidden_layer_sizes": (256, 128),
                                  "max_iter": 300, "random_state": 0,
                                  "early_stopping": True} | params))
    else:
        return {"error": f"unknown model_type {model_type}"}

    model.fit(Xtr_s, ytr)
    model_id = hashlib.md5(pickle.dumps((split_id, model_type, params))).hexdigest()[:10]
    with open(f"/tmp/model_{model_id}.pkl", "wb") as f:
        pickle.dump({"model": model, "scaler": scaler,
                     "split_id": split_id, "model_type": model_type}, f)
    return {"model_id": model_id, "model_type": model_type,
            "split_id": split_id, "train_size": int(len(ytr))}


@mcp.tool()
def evaluate_predictions(model_id: str) -> dict:
    """Evaluate a trained model on its test split.

    Returns RMSE on the full test set and RMSE_cliff on the activity-cliff
    subset (cliff_test mask). This is the metric used by the MoleculeACE
    benchmark.
    """
    with open(f"/tmp/model_{model_id}.pkl", "rb") as f:
        st = pickle.load(f)
    sp = np.load(f"/tmp/split_{st['split_id']}.npz")
    Xte = sp["X_test"].astype(np.float32)
    yte = sp["y_test"]; cliff = sp["cliff_test"]
    Xte_s = st["scaler"].transform(Xte)
    pred = st["model"].predict(Xte_s)

    err = pred - yte
    rmse = float(np.sqrt((err ** 2).mean()))
    cliff_mask = cliff.astype(bool)
    if cliff_mask.any():
        rmse_cliff = float(np.sqrt((err[cliff_mask] ** 2).mean()))
        rmse_noncliff = float(np.sqrt((err[~cliff_mask] ** 2).mean())) if (~cliff_mask).any() else None
    else:
        rmse_cliff = None; rmse_noncliff = rmse
    return {
        "model_id": model_id,
        "model_type": st["model_type"],
        "n_test": int(len(yte)),
        "n_cliff_test": int(cliff_mask.sum()),
        "rmse": round(rmse, 4),
        "rmse_cliff": round(rmse_cliff, 4) if rmse_cliff is not None else None,
        "rmse_noncliff": round(rmse_noncliff, 4) if rmse_noncliff is not None else None,
        "cliff_gap": round(rmse_cliff - rmse, 4) if rmse_cliff is not None else None,
    }


@mcp.tool()
def get_predictions(model_id: str) -> dict:
    """Return raw predictions and true values for the test set, plus the
    cliff_test mask. Use to plot residuals or per-target diagnostics."""
    with open(f"/tmp/model_{model_id}.pkl", "rb") as f:
        st = pickle.load(f)
    sp = np.load(f"/tmp/split_{st['split_id']}.npz")
    Xte = st["scaler"].transform(sp["X_test"].astype(np.float32))
    pred = st["model"].predict(Xte)
    return {
        "model_id": model_id,
        "predictions": [round(float(x), 4) for x in pred],
        "true_values": [round(float(x), 4) for x in sp["y_test"]],
        "cliff_test_mask": [int(x) for x in sp["cliff_test"]],
        "n_test": int(len(pred)),
    }


@mcp.tool()
def benchmark_methods(csv_path: str,
                      methods: list = None,
                      descriptors: list = None) -> dict:
    """Run multiple (model, descriptor) combinations on a single dataset.

    For each combination: build fingerprints, prepare predefined split,
    train, evaluate. Returns a sorted ranking by RMSE_cliff.

    Args:
        csv_path: Absolute path to a CHEMBL*.csv.
        methods: subset of ['svm', 'rf', 'gbm', 'knn', 'mlp']. Defaults to all.
        descriptors: subset of ['ECFP', 'MACCS', 'PHYSCHEM']. Defaults to all.
    """
    methods = methods or ["svm", "rf", "gbm", "knn", "mlp"]
    descriptors = descriptors or ["ECFP", "MACCS", "PHYSCHEM"]

    import csv as _csv
    with open(csv_path, newline="") as f:
        rows = list(_csv.DictReader(f))
    smiles = [r["smiles"] for r in rows]

    results = []
    for desc in descriptors:
        if desc == "ECFP":
            fp = compute_ecfp(smiles)
        elif desc == "MACCS":
            fp = compute_maccs(smiles)
        elif desc == "PHYSCHEM":
            fp = compute_physchem(smiles)
        else:
            continue
        fp_id = fp["fingerprint_id"]
        split = prepare_split(csv_path, fp_id, "predefined")
        sid = split["split_id"]
        for mt in methods:
            m = train_model(sid, mt)
            if "error" in m:
                results.append({"method": f"{mt}-{desc}", "error": m["error"]})
                continue
            ev = evaluate_predictions(m["model_id"])
            results.append({
                "method": f"{mt.upper()}-{desc}",
                "rmse": ev["rmse"],
                "rmse_cliff": ev["rmse_cliff"],
                "cliff_gap": ev["cliff_gap"],
            })
    results.sort(key=lambda r: r.get("rmse_cliff", 9.99))
    return {
        "dataset": os.path.basename(csv_path),
        "n_runs": len(results),
        "ranking": results,
    }


# ---------------------------------------------------------------------------
# Plotting
# ---------------------------------------------------------------------------

@mcp.tool()
def plot_method_ranking(ranking: list, output_path: str,
                         title: str = "Activity-cliff benchmark") -> dict:
    """Bar chart of RMSE vs RMSE_cliff for a list of {method, rmse, rmse_cliff} dicts."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    ranking = [r for r in ranking if "rmse_cliff" in r and r["rmse_cliff"] is not None]
    ranking.sort(key=lambda r: r["rmse_cliff"])
    names = [r["method"] for r in ranking]
    rmse = [r["rmse"] for r in ranking]
    cliff = [r["rmse_cliff"] for r in ranking]
    fig, ax = plt.subplots(figsize=(10, max(4, 0.35 * len(names))))
    y = np.arange(len(names))
    ax.barh(y - 0.2, rmse, height=0.4, color="steelblue", label="RMSE (test)")
    ax.barh(y + 0.2, cliff, height=0.4, color="salmon", label="RMSE (cliff)")
    ax.set_yticks(y); ax.set_yticklabels(names)
    ax.set_xlabel("RMSE (log units)")
    ax.set_title(title)
    ax.invert_yaxis(); ax.legend(loc="lower right")
    fig.tight_layout(); fig.savefig(output_path, dpi=150); plt.close(fig)
    return {"output_path": output_path, "n_methods": len(names)}


@mcp.tool()
def plot_pred_vs_true(predictions: list, true_values: list,
                      cliff_mask: list = None,
                      output_path: str = "artifacts/pred_vs_true.png",
                      title: str = "Predicted vs True") -> dict:
    """Scatter of predicted vs true bioactivity, optionally colouring cliff vs non-cliff."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    pred = np.asarray(predictions, dtype=float)
    true = np.asarray(true_values, dtype=float)
    fig, ax = plt.subplots(figsize=(6.5, 6))
    if cliff_mask is not None:
        cm = np.asarray(cliff_mask, dtype=bool)
        ax.scatter(true[~cm], pred[~cm], s=10, alpha=0.4, c="steelblue",
                   label="non-cliff")
        ax.scatter(true[cm], pred[cm], s=14, alpha=0.7, c="salmon",
                   label="cliff", edgecolor="darkred", linewidths=0.3)
        ax.legend()
    else:
        ax.scatter(true, pred, s=10, alpha=0.4)
    lo = float(min(true.min(), pred.min()))
    hi = float(max(true.max(), pred.max()))
    ax.plot([lo, hi], [lo, hi], "k--", lw=1, alpha=0.5)
    ax.set_xlabel("True (log units)"); ax.set_ylabel("Predicted (log units)")
    ax.set_title(title); fig.tight_layout()
    fig.savefig(output_path, dpi=150); plt.close(fig)
    return {"output_path": output_path, "n_points": int(len(pred))}


@mcp.tool()
def plot_similarity_heatmap(fingerprint_id: str, indices: list,
                             output_path: str,
                             title: str = "Tanimoto similarity") -> dict:
    """Heatmap of pairwise Tanimoto similarity for a (small) compound subset."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fps = np.load(f"/tmp/fp_{fingerprint_id}.npz")["fps"][indices].astype(np.uint8)
    inter = fps.astype(np.int32) @ fps.T.astype(np.int32)
    s_ = fps.sum(axis=1)
    union = s_.reshape(-1, 1) + s_.reshape(1, -1) - inter
    union[union == 0] = 1
    sim = inter / union
    fig, ax = plt.subplots(figsize=(7, 6))
    im = ax.imshow(sim, cmap="viridis", vmin=0, vmax=1)
    fig.colorbar(im, ax=ax, label="Tanimoto")
    ax.set_title(title); fig.tight_layout()
    fig.savefig(output_path, dpi=150); plt.close(fig)
    return {"output_path": output_path, "n": int(len(indices))}


if __name__ == "__main__":
    mcp.run(transport="stdio")

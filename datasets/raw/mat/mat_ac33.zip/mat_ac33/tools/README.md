# mat_ac33 — Tool Reference

## Database Retrieval (`database_retrieval.py`)
Generic stubs for external-database queries (websearch, fetch_url,
query_pubchem, query_chembl, query_uniprot, query_pdb, query_geo,
query_ncbi_entrez, query_usgs_comcat, query_world_bank, query_openalex,
query_doi). Implementations pulled in at runtime via `requests` /
`chembl_webresource_client` etc.

## Data Processing (`data_processing.py`)
Generic format/reshape helpers: `read_csv`, `write_csv`, `read_json`,
`write_json`, `read_excel`, `read_parquet`, `read_netcdf`,
`read_shapefile`, `read_fasta`, `pivot_long_to_wide`,
`pivot_wide_to_long`, `drop_missing`, `coerce_numeric`, `join_tables`,
`groupby_aggregate`.

## Domain — Molecular ML for Activity Cliffs (`molecule_ml_tools.py`)
All functions are MCP-decorated (`@mcp.tool()`).

- `load_chembl_csv(csv_path)`: load a MoleculeACE-format dataset
  (smiles, y, cliff_mol, split columns) and return summary + records.
- `list_benchmark_datasets(data_dir)`: enumerate all CHEMBL*.csv files
  with per-dataset compound counts and %cliffs.
- `canonicalise_smiles(smiles_list)`: RDKit canonicalisation + validity mask.
- `compute_ecfp(smiles_list, radius, n_bits)`: Morgan/ECFP fingerprints.
- `compute_maccs(smiles_list)`: 167-bit MACCS keys.
- `compute_physchem(smiles_list)`: ~200 RDKit physico-chemical descriptors.
- `get_murcko_scaffold(smiles_list)`: Bemis-Murcko scaffold SMILES.
- `tanimoto_similarity_matrix(fingerprint_id, ...)`: pairwise Tanimoto.
- `identify_activity_cliffs(smiles_list, y_values, similarity_metrics,
  similarity_threshold, potency_threshold)`: returns the cliff-mol mask
  using ECFP / scaffold / SMILES-Levenshtein similarity (any-of).
- `prepare_split(csv_path, fingerprint_id, split_strategy)`: build a
  train/test split using either the predefined `split` column or
  scaffold-based stratification.
- `train_model(split_id, model_type, model_params)`: train SVM-RBF, RF,
  GBM, KNN, or MLP on the prepared split.
- `evaluate_predictions(model_id)`: compute RMSE on the full test set
  and RMSE_cliff on the activity-cliff subset.
- `get_predictions(model_id)`: raw predictions/true values + cliff mask.
- `benchmark_methods(csv_path, methods, descriptors)`: run a grid of
  (model, descriptor) combinations on one dataset and rank by RMSE_cliff.
- `plot_method_ranking(ranking, output_path, title)`: bar chart of
  RMSE vs RMSE_cliff. Returns the saved path.
- `plot_pred_vs_true(predictions, true_values, cliff_mask, output_path,
  title)`: scatter plot, optionally colouring cliff vs non-cliff points.
  Returns the saved path.
- `plot_similarity_heatmap(fingerprint_id, indices, output_path, title)`:
  Tanimoto heatmap for a small compound subset. Returns the saved path.

## Dependencies
`numpy`, `scikit-learn`, `rdkit`, `matplotlib`, `python-Levenshtein`
(optional — pure-Python fallback included), `mcp`.

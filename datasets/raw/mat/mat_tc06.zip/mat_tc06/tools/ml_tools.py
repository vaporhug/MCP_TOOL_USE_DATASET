#!/usr/bin/env python3
"""
General-purpose ML tools for tabular regression tasks.

Provides data splitting, model training (CatBoost, XGBoost, Random Forest,
Ridge, KNN, SVR), evaluation metrics, feature importance, and
hyperparameter optimization. No domain-specific logic.
"""

import numpy as np
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("ML_Tools")

# Columns that must NEVER be used as model features, no matter which column is
# chosen as the supervised target. ``Tc`` is the true label and ``Tc_mean`` is a
# near-duplicate of it; using EITHER as an input feature leaks the target (e.g.
# if a caller mistakenly trains on ``Tc_mean`` then leaving ``Tc`` in the feature
# matrix would leak the answer, and vice-versa). ``element`` is the raw formula
# string and the unnamed index column is bookkeeping. All of these are stripped
# in code (not just docs) before any model ever sees the data.
_LEAKAGE_COLS = ("Tc", "Tc_mean")
_NON_FEATURE_COLS = ("element", "index", "Index", "Unnamed: 0", "")

# Default supervised target when the caller does not specify one: the experimental
# critical temperature ``Tc`` (NOT the trailing ``Tc_mean`` leakage column). If a
# CSV has no ``Tc`` column we fall back to the last column.
_DEFAULT_TARGET = "Tc"


def _resolve_target_col(data, target_col):
    """Pick the supervised target column.

    If ``target_col`` is given and present, use it. Otherwise default to ``Tc``
    when the table has it (the real label), and only fall back to the last column
    when ``Tc`` is absent. This guarantees a caller who passes the raw CSV without
    a ``target_col`` trains on ``Tc`` rather than the trailing ``Tc_mean``.
    """
    if target_col and target_col in data.columns:
        return target_col
    if _DEFAULT_TARGET in data.columns:
        return _DEFAULT_TARGET
    return data.columns[-1]


def _drop_leakage_and_nonfeatures(features, target_col: str):
    """Return ``features`` with leakage/non-feature columns removed.

    Drops BOTH temperature columns ``Tc`` and ``Tc_mean`` (target + its
    near-duplicate, so neither can leak regardless of which is the target), the
    raw ``element`` formula string, the unnamed CSV index column, and the chosen
    target column if it sneaked in. Operates on a pandas DataFrame and is a no-op
    for columns that are absent.
    """
    drop = set(_LEAKAGE_COLS) | set(_NON_FEATURE_COLS) | {target_col}
    return features.drop(columns=[c for c in drop if c in features.columns],
                         errors="ignore")


@mcp.tool()
def load_csv_summary(csv_path: str) -> dict:
    """Load a CSV file and return summary statistics.

    Args:
        csv_path: Path to CSV file

    Returns:
        dict with shape, column names, and per-column statistics
    """
    import pandas as pd
    data = pd.read_csv(csv_path).dropna()
    stats = {}
    for col in data.columns:
        if data[col].dtype in ['float64', 'int64', 'float32', 'int32']:
            stats[col] = {
                "mean": round(float(data[col].mean()), 4),
                "std": round(float(data[col].std()), 4),
                "min": round(float(data[col].min()), 4),
                "max": round(float(data[col].max()), 4),
                "median": round(float(data[col].median()), 4),
            }
    return {
        "shape": list(data.shape),
        "columns": list(data.columns),
        "numeric_stats": stats,
    }


@mcp.tool()
def split_dataset(csv_path: str, test_size: float = 0.10,
                  random_state: int = 42, target_col: str = None) -> dict:
    """Split dataset into train and test sets.

    Args:
        csv_path: Path to CSV file
        test_size: Fraction for test set (default 0.10)
        random_state: Random seed
        target_col: Name of target column (default: 'Tc' if present, else last column)

    Returns:
        dict with split sizes, feature count, target statistics
    """
    import pandas as pd
    from sklearn.model_selection import train_test_split

    data = pd.read_csv(csv_path).dropna()
    # Default to the real label 'Tc' (NOT the trailing 'Tc_mean' leakage column).
    target_col = _resolve_target_col(data, target_col)
    y = data[target_col].values
    features = data.drop(columns=[target_col])

    # Exclude leakage/non-feature columns (Tc, Tc_mean, element, index) from the
    # reported feature set so the summary cannot mislead a caller into using
    # them; this mirrors the in-code stripping done by train_model.
    features = _drop_leakage_and_nonfeatures(features, target_col)
    feature_names = list(features.columns)
    X = features.values

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state
    )

    return {
        "target_col": target_col,
        "n_features": X.shape[1],
        "train_size": len(y_train),
        "test_size": len(y_test),
        "feature_names": feature_names,
        "train_target_mean": round(float(y_train.mean()), 2),
        "train_target_std": round(float(y_train.std()), 2),
        "test_target_mean": round(float(y_test.mean()), 2),
        "test_target_std": round(float(y_test.std()), 2),
        "random_state": random_state,
    }


@mcp.tool()
def train_model(csv_path: str, model_type: str, test_size: float = 0.10,
                random_state: int = 42, target_col: str = None,
                model_params: dict = None, selected_features: list = None) -> dict:
    """Train a regression model and save it for later prediction/evaluation.

    The held-out test fold is split off with ``train_test_split(test_size,
    random_state)`` and is never shown to the model: gradient-boosting early
    stopping (CatBoost/XGBoost ``early_stopping_rounds=50``) uses an inner
    validation fold carved out of the training data only, so the returned test
    metrics are unbiased (no test-set leakage). When ``target_col`` is not given
    the supervised target defaults to ``Tc`` (the real label), not the trailing
    ``Tc_mean`` column. BOTH temperature columns ``Tc`` and ``Tc_mean`` and the
    raw ``element``/index columns are stripped in code before fitting, so neither
    can ever become a feature regardless of which column is the target (so even
    if a caller trains on ``Tc_mean`` the label ``Tc`` is not leaked into the
    features, and vice-versa) — even if the raw CSV is passed in.

    Args:
        csv_path: Path to feature matrix CSV
        model_type: One of "catboost", "xgboost", "random_forest", "ridge", "knn", "svr"
        test_size: Fraction for the final test set (default 0.10 = 90/10 split)
        random_state: Random seed pinning the split (default 42)
        target_col: Target column name (default: 'Tc' if present, else last column)
        model_params: Optional hyperparameter dict
        selected_features: Optional list of feature names to use (subset selection)

    Returns:
        dict with model_id, training metrics
    """
    import pandas as pd
    import pickle, hashlib
    from sklearn.model_selection import train_test_split

    data = pd.read_csv(csv_path).dropna()
    # Default to the real label 'Tc' (NOT the trailing 'Tc_mean' leakage column).
    target_col = _resolve_target_col(data, target_col)
    y = data[target_col].values
    features = data.drop(columns=[target_col])

    # Enforce leak-free features in code: BOTH Tc and Tc_mean (plus element /
    # index) are removed before anything else, so neither temperature column can
    # ever become a model feature even if the raw CSV is passed in, no matter
    # which column was chosen as the target.
    features = _drop_leakage_and_nonfeatures(features, target_col)

    if selected_features:
        available = [f for f in selected_features
                     if f in features.columns
                     and f not in _LEAKAGE_COLS and f not in _NON_FEATURE_COLS]
        features = features[available]

    feature_names = list(features.columns)
    X = features.values

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state
    )

    # Leak-free early stopping: carve a validation fold out of the TRAINING
    # data only. The held-out test set (X_test, y_test) is never shown to the
    # model during fitting, so test metrics are unbiased.
    X_fit, X_val, y_fit, y_val = train_test_split(
        X_train, y_train, test_size=0.10, random_state=random_state
    )

    params = model_params or {}

    if model_type == "catboost":
        from catboost import CatBoostRegressor
        # early_stopping_rounds actually enables early stopping: training halts
        # when the inner-validation (X_val) loss stops improving for 50 rounds.
        dp = {"iterations": 1000, "learning_rate": 0.05, "depth": 6,
              "verbose": 0, "random_seed": random_state,
              "early_stopping_rounds": 50}
        dp.update(params)
        model = CatBoostRegressor(**dp)
        model.fit(X_fit, y_fit, eval_set=(X_val, y_val), verbose=0)
    elif model_type == "xgboost":
        import xgboost
        # early_stopping_rounds enables real early stopping on the inner
        # validation fold (X_val); the best iteration is used for prediction.
        dp = {"n_estimators": 500, "learning_rate": 0.05, "max_depth": 6,
              "verbosity": 0, "random_state": random_state,
              "early_stopping_rounds": 50}
        dp.update(params)
        model = xgboost.XGBRegressor(**dp)
        model.fit(X_fit, y_fit, eval_set=[(X_val, y_val)],
                  verbose=False)
    elif model_type == "random_forest":
        from sklearn.ensemble import RandomForestRegressor
        dp = {"n_estimators": 200, "random_state": random_state}
        dp.update(params)
        model = RandomForestRegressor(**dp)
        model.fit(X_train, y_train)
    elif model_type == "ridge":
        from sklearn.linear_model import Ridge
        model = Ridge(**({"alpha": 1.0, **params}))
        model.fit(X_train, y_train)
    elif model_type == "knn":
        from sklearn.neighbors import KNeighborsRegressor
        model = KNeighborsRegressor(**({"n_neighbors": 5, **params}))
        model.fit(X_train, y_train)
    elif model_type == "svr":
        from sklearn.svm import SVR
        model = SVR(**({"kernel": "rbf", "C": 1.0, **params}))
        model.fit(X_train, y_train)
    else:
        return {"error": f"Unknown model_type: {model_type}"}

    # Quick train/test metrics
    from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
    train_pred = model.predict(X_train).flatten()
    test_pred = model.predict(X_test).flatten()

    model_bytes = pickle.dumps({
        "model": model, "X_test": X_test, "y_test": y_test,
        "X_train": X_train, "y_train": y_train,
        "feature_names": feature_names,
    })
    model_id = hashlib.md5(model_bytes[:2000]).hexdigest()[:8]
    with open(f"/tmp/model_{model_id}.pkl", "wb") as f:
        f.write(model_bytes)

    return {
        "model_id": model_id,
        "model_type": model_type,
        "target_col": target_col,
        "n_features": X_train.shape[1],
        "train_size": len(y_train),
        "test_size": len(y_test),
        "train_r2": round(float(r2_score(y_train, train_pred)), 4),
        "train_rmse": round(float(np.sqrt(mean_squared_error(y_train, train_pred))), 4),
        "test_r2": round(float(r2_score(y_test, test_pred)), 4),
        "test_rmse": round(float(np.sqrt(mean_squared_error(y_test, test_pred))), 4),
        "test_mae": round(float(mean_absolute_error(y_test, test_pred)), 4),
    }


@mcp.tool()
def get_predictions(model_id: str) -> dict:
    """Get model predictions on the test set.

    Args:
        model_id: Model identifier from train_model

    Returns:
        dict with predictions and true values
    """
    import pickle

    with open(f"/tmp/model_{model_id}.pkl", "rb") as f:
        state = pickle.load(f)

    model = state["model"]
    test_pred = model.predict(state["X_test"]).flatten()

    return {
        "model_id": model_id,
        "predictions": [round(float(x), 4) for x in test_pred],
        "true_values": [round(float(x), 4) for x in state["y_test"]],
        "test_size": len(state["y_test"]),
    }


@mcp.tool()
def compute_metrics(predictions: list, true_values: list) -> dict:
    """Compute regression metrics (R2, RMSE, MAE).

    Args:
        predictions: Model predictions
        true_values: True target values

    Returns:
        dict with R2, RMSE, MAE, n_samples
    """
    from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error

    pred = np.array(predictions, dtype=float)
    true = np.array(true_values, dtype=float)

    return {
        "r2": round(float(r2_score(true, pred)), 4),
        "rmse": round(float(np.sqrt(mean_squared_error(true, pred))), 4),
        "mae": round(float(mean_absolute_error(true, pred)), 4),
        "n_samples": len(true),
    }


@mcp.tool()
def compute_feature_importance(model_id: str, method: str = "shap") -> dict:
    """Compute feature importance for a trained model.

    LEAK-FREE: the feature ranking is computed on the TRAINING fold only
    (``X_train`` stored by ``train_model``), NEVER on the final held-out test
    fold. The test set is reserved exclusively for reporting unbiased
    generalization metrics; letting it influence the feature ranking would be a
    form of test-set leakage. ``builtin`` importance is a property of the fitted
    model (training-derived); ``shap`` is computed on a sample of the training
    rows. This matches the leak-free convention of
    ``forward_feature_selection`` (which scores on an inner train/val split) and
    of the README rule that no feature-scoring/ranking tool may touch the final
    test fold.

    Args:
        model_id: Model identifier from train_model
        method: "shap" for SHAP values, "builtin" for model's native importance

    Returns:
        dict with ranked feature importances
    """
    import pickle

    with open(f"/tmp/model_{model_id}.pkl", "rb") as f:
        state = pickle.load(f)

    model = state["model"]
    feature_names = state["feature_names"]
    # Use the TRAINING fold for any data-dependent importance (e.g. SHAP).
    # The final test fold is never used for feature ranking (no leakage).
    X_train = state["X_train"]

    if method == "shap":
        import shap
        explainer = shap.TreeExplainer(model)
        n_sample = min(300, len(X_train))
        shap_values = explainer.shap_values(X_train[:n_sample])
        importance = np.abs(shap_values).mean(axis=0)
    else:
        # Built-in feature importance
        if hasattr(model, "feature_importances_"):
            importance = model.feature_importances_
        else:
            return {"error": "Model does not have built-in feature importance"}

    ranking = np.argsort(importance)[::-1]
    result = []
    for rank, idx in enumerate(ranking[:30]):
        result.append({
            "rank": rank + 1,
            "feature": feature_names[idx] if idx < len(feature_names) else f"feature_{idx}",
            "importance": round(float(importance[idx]), 4),
        })

    return {
        "method": method,
        "top_features": result,
        "n_total_features": len(importance),
    }


@mcp.tool()
def forward_feature_selection(csv_path: str, initial_features: list,
                               candidate_features: list, target_col: str = "Tc",
                               max_features: int = 30, test_size: float = 0.10,
                               random_state: int = 42) -> dict:
    """Leak-free greedy forward feature selection.

    The final test fold (the same ``test_size`` / ``random_state`` holdout that
    the answer's metrics are reported on) is split off FIRST and never used for
    selection. Candidate features are scored by R2 on an inner validation fold
    that is carved out of the TRAINING data only, so the held-out test set does
    not influence which features are chosen. Pass the resulting feature list to
    ``train_model`` to obtain unbiased test metrics on the same holdout.

    Args:
        csv_path: Path to full feature matrix CSV
        initial_features: Starting set of feature names
        candidate_features: Pool of candidate feature names to add
        target_col: Target column name
        max_features: Stop after this many total features
        test_size: Test split fraction (held out and excluded from selection)
        random_state: Random seed (same one used by train_model)

    Returns:
        dict with selected feature order and inner-validation R2 at each step
    """
    import pandas as pd
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import r2_score

    df = pd.read_csv(csv_path).dropna()
    y = df[target_col].values
    all_features = _drop_leakage_and_nonfeatures(df.drop(columns=[target_col]),
                                                 target_col)

    indices = np.arange(len(y))
    # 1) Hold out the final test fold (identical to train_model's split) and
    #    NEVER touch it during selection.
    idx_trainval, _idx_test = train_test_split(
        indices, test_size=test_size, random_state=random_state
    )
    # 2) Carve an inner validation fold out of the remaining training data;
    #    feature scoring uses only this train/val partition.
    idx_train, idx_val = train_test_split(
        idx_trainval, test_size=0.10, random_state=random_state
    )

    selected = list(initial_features)
    remaining = [f for f in candidate_features if f not in selected]
    history = []

    try:
        from catboost import CatBoostRegressor
        use_catboost = True
    except ImportError:
        use_catboost = False

    while len(selected) < max_features and remaining:
        best_score = -999
        best_feat = None
        for feat in remaining:
            trial = selected + [feat]
            avail = [f for f in trial if f in all_features.columns]
            X = all_features[avail].values
            X_tr, X_va = X[idx_train], X[idx_val]
            y_tr, y_va = y[idx_train], y[idx_val]

            if use_catboost:
                m = CatBoostRegressor(iterations=200, depth=6, learning_rate=0.1,
                                       verbose=0, random_seed=random_state)
            else:
                import xgboost
                m = xgboost.XGBRegressor(n_estimators=200, max_depth=6,
                                          learning_rate=0.1, verbosity=0)
            m.fit(X_tr, y_tr)
            pred = m.predict(X_va).flatten()
            score = r2_score(y_va, pred)

            if score > best_score:
                best_score = score
                best_feat = feat

        if best_feat:
            selected.append(best_feat)
            remaining.remove(best_feat)
            history.append({"n_features": len(selected), "added": best_feat,
                          "val_r2": round(best_score, 4)})

    return {
        "selected_features": selected,
        "n_selected": len(selected),
        "selection_history": history,
        "note": "scored on inner validation fold; final test set held out and unused",
    }


@mcp.tool()
def predict_new_compounds(model_id: str, feature_dicts: list) -> dict:
    """Predict Tc for new compounds given their feature vectors.

    Args:
        model_id: Model identifier from train_model
        feature_dicts: List of dicts, each mapping feature_name -> value

    Returns:
        dict with predictions for each compound
    """
    import pickle

    with open(f"/tmp/model_{model_id}.pkl", "rb") as f:
        state = pickle.load(f)

    model = state["model"]
    feature_names = state["feature_names"]

    predictions = []
    for fd in feature_dicts:
        row = [fd.get(fn, 0.0) for fn in feature_names]
        pred = model.predict(np.array([row])).flatten()[0]
        predictions.append(round(float(pred), 2))

    return {
        "predictions": predictions,
        "n_compounds": len(predictions),
    }


if __name__ == "__main__":
    mcp.run(transport="stdio")

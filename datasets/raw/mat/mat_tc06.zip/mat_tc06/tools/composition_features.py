#!/usr/bin/env python3
"""
Low-level composition featurization primitives for materials science.

Provides atomic-level building blocks: parse formulas, look up elemental
properties, and compute individual statistical descriptors. The agent
can decide WHICH properties, WHICH bases (element/subscript/fraction),
and WHICH statistics to combine into a feature matrix using the low-level
primitives, or call build_jabir_feature_matrix to generate the complete
322-descriptor feature set in one call directly from the formula column.

Available tools:
  parse_formula        — formula string → element list with subscripts/fractions
  get_element_property — look up one property for one element
  list_available_properties — enumerate available properties and statistics
  stat_aggregation     — compute one statistic over a value list
  compute_property_descriptor — one property × one basis × one stat for one formula
  aggregate_stats      — element count and subscript sum for one formula
  compute_element_fractions — element fraction columns for a CSV
  build_jabir_feature_matrix — generate the full 322-descriptor matrix in one call
  feature_correlation_filter — correlation-based feature clustering + selection
  shap_feature_ranking — SHAP importance ranking via gradient boosting
"""

import re
import math
import numpy as np
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Composition_Features")

# ── Elemental property data (subset of periodic table) ──────────────────
# 12 physical properties used in composition-based featurization.
# Sources: CRC Handbook, WebElements, Pymatgen.
_ELEM_PROPS = {
    # symbol: {property: value}
    # Properties: atomic_mass, electronegativity, electron_affinity (eV),
    # first_ionization_energy (eV), thermal_conductivity (W/m/K),
    # specific_heat (J/g/K), dipole_polarizability (A^3),
    # magnetic_moment (Bohr magneton), valence_electron_number,
    # unpaired_electrons, heat_of_formation (kJ/mol), electrical_conductivity (S/m),
    # ionic_radius (pm), vdw_radius (pm), period_number, group_number,
    # pettifor_number
    "H":  {"atomic_mass":1.008,"electronegativity":2.20,"electron_affinity":0.754,"first_ionization_energy":13.598,"thermal_conductivity":0.1805,"specific_heat":14.304,"dipole_polarizability":0.6668,"magnetic_moment":0,"valence_electron_number":1,"unpaired_electrons":1,"heat_of_formation":218.0,"electrical_conductivity":0,"ionic_radius":25,"vdw_radius":120,"period_number":1,"group_number":1,"pettifor_number":103},
    "He": {"atomic_mass":4.003,"electronegativity":0,"electron_affinity":0,"first_ionization_energy":24.587,"thermal_conductivity":0.1513,"specific_heat":5.193,"dipole_polarizability":0.2050,"magnetic_moment":0,"valence_electron_number":2,"unpaired_electrons":0,"heat_of_formation":0,"electrical_conductivity":0,"ionic_radius":31,"vdw_radius":140,"period_number":1,"group_number":18,"pettifor_number":1},
    "Li": {"atomic_mass":6.941,"electronegativity":0.98,"electron_affinity":0.618,"first_ionization_energy":5.392,"thermal_conductivity":84.8,"specific_heat":3.582,"dipole_polarizability":24.33,"magnetic_moment":0,"valence_electron_number":1,"unpaired_electrons":1,"heat_of_formation":159.3,"electrical_conductivity":1.08e7,"ionic_radius":90,"vdw_radius":182,"period_number":2,"group_number":1,"pettifor_number":12},
    "Be": {"atomic_mass":9.012,"electronegativity":1.57,"electron_affinity":0,"first_ionization_energy":9.323,"thermal_conductivity":200,"specific_heat":1.825,"dipole_polarizability":5.60,"magnetic_moment":0,"valence_electron_number":2,"unpaired_electrons":0,"heat_of_formation":324,"electrical_conductivity":2.5e7,"ionic_radius":59,"vdw_radius":153,"period_number":2,"group_number":2,"pettifor_number":77},
    "B":  {"atomic_mass":10.81,"electronegativity":2.04,"electron_affinity":0.277,"first_ionization_energy":8.298,"thermal_conductivity":27.4,"specific_heat":1.026,"dipole_polarizability":3.03,"magnetic_moment":0,"valence_electron_number":3,"unpaired_electrons":1,"heat_of_formation":562.7,"electrical_conductivity":1e-4,"ionic_radius":41,"vdw_radius":192,"period_number":2,"group_number":13,"pettifor_number":86},
    "C":  {"atomic_mass":12.01,"electronegativity":2.55,"electron_affinity":1.263,"first_ionization_energy":11.260,"thermal_conductivity":1.59,"specific_heat":0.709,"dipole_polarizability":1.76,"magnetic_moment":0,"valence_electron_number":4,"unpaired_electrons":2,"heat_of_formation":716.7,"electrical_conductivity":100,"ionic_radius":29,"vdw_radius":170,"period_number":2,"group_number":14,"pettifor_number":95},
    "N":  {"atomic_mass":14.01,"electronegativity":3.04,"electron_affinity":-0.07,"first_ionization_energy":14.534,"thermal_conductivity":0.02583,"specific_heat":1.040,"dipole_polarizability":1.10,"magnetic_moment":0,"valence_electron_number":5,"unpaired_electrons":3,"heat_of_formation":472.7,"electrical_conductivity":0,"ionic_radius":132,"vdw_radius":155,"period_number":2,"group_number":15,"pettifor_number":100},
    "O":  {"atomic_mass":16.00,"electronegativity":3.44,"electron_affinity":1.461,"first_ionization_energy":13.618,"thermal_conductivity":0.02658,"specific_heat":0.918,"dipole_polarizability":0.802,"magnetic_moment":0,"valence_electron_number":6,"unpaired_electrons":2,"heat_of_formation":249.2,"electrical_conductivity":0,"ionic_radius":126,"vdw_radius":152,"period_number":2,"group_number":16,"pettifor_number":101},
    "F":  {"atomic_mass":19.00,"electronegativity":3.98,"electron_affinity":3.401,"first_ionization_energy":17.423,"thermal_conductivity":0.0277,"specific_heat":0.824,"dipole_polarizability":0.557,"magnetic_moment":0,"valence_electron_number":7,"unpaired_electrons":1,"heat_of_formation":79.0,"electrical_conductivity":0,"ionic_radius":119,"vdw_radius":147,"period_number":2,"group_number":17,"pettifor_number":102},
    "Na": {"atomic_mass":22.99,"electronegativity":0.93,"electron_affinity":0.548,"first_ionization_energy":5.139,"thermal_conductivity":142.0,"specific_heat":1.228,"dipole_polarizability":24.11,"magnetic_moment":0,"valence_electron_number":1,"unpaired_electrons":1,"heat_of_formation":107.3,"electrical_conductivity":2.1e7,"ionic_radius":116,"vdw_radius":227,"period_number":3,"group_number":1,"pettifor_number":11},
    "Mg": {"atomic_mass":24.31,"electronegativity":1.31,"electron_affinity":0,"first_ionization_energy":7.646,"thermal_conductivity":156.0,"specific_heat":1.023,"dipole_polarizability":10.6,"magnetic_moment":0,"valence_electron_number":2,"unpaired_electrons":0,"heat_of_formation":147.1,"electrical_conductivity":2.26e7,"ionic_radius":86,"vdw_radius":173,"period_number":3,"group_number":2,"pettifor_number":73},
    "Al": {"atomic_mass":26.98,"electronegativity":1.61,"electron_affinity":0.441,"first_ionization_energy":5.986,"thermal_conductivity":237.0,"specific_heat":0.897,"dipole_polarizability":6.80,"magnetic_moment":0,"valence_electron_number":3,"unpaired_electrons":1,"heat_of_formation":330.0,"electrical_conductivity":3.77e7,"ionic_radius":67.5,"vdw_radius":184,"period_number":3,"group_number":13,"pettifor_number":80},
    "Si": {"atomic_mass":28.09,"electronegativity":1.90,"electron_affinity":1.390,"first_ionization_energy":8.152,"thermal_conductivity":149.0,"specific_heat":0.705,"dipole_polarizability":5.38,"magnetic_moment":0,"valence_electron_number":4,"unpaired_electrons":2,"heat_of_formation":455.6,"electrical_conductivity":1e-3,"ionic_radius":54,"vdw_radius":210,"period_number":3,"group_number":14,"pettifor_number":85},
    "P":  {"atomic_mass":30.97,"electronegativity":2.19,"electron_affinity":0.746,"first_ionization_energy":10.487,"thermal_conductivity":0.236,"specific_heat":0.769,"dipole_polarizability":3.63,"magnetic_moment":0,"valence_electron_number":5,"unpaired_electrons":3,"heat_of_formation":314.6,"electrical_conductivity":1e-9,"ionic_radius":58,"vdw_radius":180,"period_number":3,"group_number":15,"pettifor_number":89},
    "S":  {"atomic_mass":32.07,"electronegativity":2.58,"electron_affinity":2.077,"first_ionization_energy":10.360,"thermal_conductivity":0.205,"specific_heat":0.710,"dipole_polarizability":2.90,"magnetic_moment":0,"valence_electron_number":6,"unpaired_electrons":2,"heat_of_formation":278.8,"electrical_conductivity":1e-15,"ionic_radius":170,"vdw_radius":180,"period_number":3,"group_number":16,"pettifor_number":93},
    "Cl": {"atomic_mass":35.45,"electronegativity":3.16,"electron_affinity":3.613,"first_ionization_energy":12.968,"thermal_conductivity":0.0089,"specific_heat":0.479,"dipole_polarizability":2.18,"magnetic_moment":0,"valence_electron_number":7,"unpaired_electrons":1,"heat_of_formation":121.3,"electrical_conductivity":0,"ionic_radius":167,"vdw_radius":175,"period_number":3,"group_number":17,"pettifor_number":99},
    "K":  {"atomic_mass":39.10,"electronegativity":0.82,"electron_affinity":0.501,"first_ionization_energy":4.341,"thermal_conductivity":102.5,"specific_heat":0.757,"dipole_polarizability":43.4,"magnetic_moment":0,"valence_electron_number":1,"unpaired_electrons":1,"heat_of_formation":89.0,"electrical_conductivity":1.39e7,"ionic_radius":152,"vdw_radius":275,"period_number":4,"group_number":1,"pettifor_number":10},
    "Ca": {"atomic_mass":40.08,"electronegativity":1.00,"electron_affinity":0.024,"first_ionization_energy":6.113,"thermal_conductivity":201.0,"specific_heat":0.647,"dipole_polarizability":22.8,"magnetic_moment":0,"valence_electron_number":2,"unpaired_electrons":0,"heat_of_formation":178.2,"electrical_conductivity":2.98e7,"ionic_radius":114,"vdw_radius":231,"period_number":4,"group_number":2,"pettifor_number":14},
    "Sc": {"atomic_mass":44.96,"electronegativity":1.36,"electron_affinity":0.188,"first_ionization_energy":6.562,"thermal_conductivity":15.8,"specific_heat":0.568,"dipole_polarizability":17.8,"magnetic_moment":0,"valence_electron_number":3,"unpaired_electrons":1,"heat_of_formation":377.8,"electrical_conductivity":1.77e6,"ionic_radius":88.5,"vdw_radius":211,"period_number":4,"group_number":3,"pettifor_number":19},
    "Ti": {"atomic_mass":47.87,"electronegativity":1.54,"electron_affinity":0.079,"first_ionization_energy":6.828,"thermal_conductivity":21.9,"specific_heat":0.523,"dipole_polarizability":14.6,"magnetic_moment":0,"valence_electron_number":4,"unpaired_electrons":2,"heat_of_formation":473,"electrical_conductivity":2.38e6,"ionic_radius":74.5,"vdw_radius":187,"period_number":4,"group_number":4,"pettifor_number":51},
    "V":  {"atomic_mass":50.94,"electronegativity":1.63,"electron_affinity":0.525,"first_ionization_energy":6.746,"thermal_conductivity":30.7,"specific_heat":0.489,"dipole_polarizability":12.4,"magnetic_moment":0,"valence_electron_number":5,"unpaired_electrons":3,"heat_of_formation":514.2,"electrical_conductivity":5e6,"ionic_radius":68,"vdw_radius":179,"period_number":4,"group_number":5,"pettifor_number":54},
    "Cr": {"atomic_mass":52.00,"electronegativity":1.66,"electron_affinity":0.666,"first_ionization_energy":6.767,"thermal_conductivity":93.9,"specific_heat":0.449,"dipole_polarizability":11.6,"magnetic_moment":0,"valence_electron_number":6,"unpaired_electrons":6,"heat_of_formation":396.6,"electrical_conductivity":7.87e6,"ionic_radius":75.5,"vdw_radius":189,"period_number":4,"group_number":6,"pettifor_number":57},
    "Mn": {"atomic_mass":54.94,"electronegativity":1.55,"electron_affinity":0,"first_ionization_energy":7.434,"thermal_conductivity":7.81,"specific_heat":0.479,"dipole_polarizability":9.4,"magnetic_moment":5,"valence_electron_number":7,"unpaired_electrons":5,"heat_of_formation":280.7,"electrical_conductivity":6.2e5,"ionic_radius":81,"vdw_radius":197,"period_number":4,"group_number":7,"pettifor_number":60},
    "Fe": {"atomic_mass":55.85,"electronegativity":1.83,"electron_affinity":0.151,"first_ionization_energy":7.902,"thermal_conductivity":80.4,"specific_heat":0.449,"dipole_polarizability":8.4,"magnetic_moment":4,"valence_electron_number":8,"unpaired_electrons":4,"heat_of_formation":416.3,"electrical_conductivity":1.03e7,"ionic_radius":75,"vdw_radius":194,"period_number":4,"group_number":8,"pettifor_number":63},
    "Co": {"atomic_mass":58.93,"electronegativity":1.88,"electron_affinity":0.662,"first_ionization_energy":7.881,"thermal_conductivity":100.0,"specific_heat":0.421,"dipole_polarizability":7.5,"magnetic_moment":3,"valence_electron_number":9,"unpaired_electrons":3,"heat_of_formation":424.7,"electrical_conductivity":1.72e7,"ionic_radius":78.5,"vdw_radius":192,"period_number":4,"group_number":9,"pettifor_number":64},
    "Ni": {"atomic_mass":58.69,"electronegativity":1.91,"electron_affinity":1.156,"first_ionization_energy":7.640,"thermal_conductivity":90.9,"specific_heat":0.444,"dipole_polarizability":6.8,"magnetic_moment":2,"valence_electron_number":10,"unpaired_electrons":2,"heat_of_formation":429.7,"electrical_conductivity":1.43e7,"ionic_radius":83,"vdw_radius":163,"period_number":4,"group_number":10,"pettifor_number":66},
    "Cu": {"atomic_mass":63.55,"electronegativity":1.90,"electron_affinity":1.235,"first_ionization_energy":7.726,"thermal_conductivity":401.0,"specific_heat":0.385,"dipole_polarizability":6.2,"magnetic_moment":1,"valence_electron_number":11,"unpaired_electrons":1,"heat_of_formation":338.3,"electrical_conductivity":5.96e7,"ionic_radius":91,"vdw_radius":140,"period_number":4,"group_number":11,"pettifor_number":72},
    "Zn": {"atomic_mass":65.38,"electronegativity":1.65,"electron_affinity":0,"first_ionization_energy":9.394,"thermal_conductivity":116.0,"specific_heat":0.388,"dipole_polarizability":5.75,"magnetic_moment":0,"valence_electron_number":12,"unpaired_electrons":0,"heat_of_formation":130.7,"electrical_conductivity":1.69e7,"ionic_radius":88,"vdw_radius":139,"period_number":4,"group_number":12,"pettifor_number":76},
    "Ga": {"atomic_mass":69.72,"electronegativity":1.81,"electron_affinity":0.43,"first_ionization_energy":5.999,"thermal_conductivity":40.6,"specific_heat":0.371,"dipole_polarizability":8.12,"magnetic_moment":0,"valence_electron_number":3,"unpaired_electrons":1,"heat_of_formation":277.0,"electrical_conductivity":7.35e6,"ionic_radius":76,"vdw_radius":187,"period_number":4,"group_number":13,"pettifor_number":81},
    "Ge": {"atomic_mass":72.63,"electronegativity":2.01,"electron_affinity":1.233,"first_ionization_energy":7.900,"thermal_conductivity":60.2,"specific_heat":0.320,"dipole_polarizability":6.07,"magnetic_moment":0,"valence_electron_number":4,"unpaired_electrons":2,"heat_of_formation":372.0,"electrical_conductivity":2,"ionic_radius":73,"vdw_radius":211,"period_number":4,"group_number":14,"pettifor_number":84},
    "As": {"atomic_mass":74.92,"electronegativity":2.18,"electron_affinity":0.814,"first_ionization_energy":9.815,"thermal_conductivity":50.2,"specific_heat":0.329,"dipole_polarizability":4.31,"magnetic_moment":0,"valence_electron_number":5,"unpaired_electrons":3,"heat_of_formation":302.5,"electrical_conductivity":3.45e6,"ionic_radius":72,"vdw_radius":185,"period_number":4,"group_number":15,"pettifor_number":88},
    "Se": {"atomic_mass":78.96,"electronegativity":2.55,"electron_affinity":2.021,"first_ionization_energy":9.752,"thermal_conductivity":0.52,"specific_heat":0.321,"dipole_polarizability":3.77,"magnetic_moment":0,"valence_electron_number":6,"unpaired_electrons":2,"heat_of_formation":227.2,"electrical_conductivity":1e-4,"ionic_radius":184,"vdw_radius":190,"period_number":4,"group_number":16,"pettifor_number":92},
    "Br": {"atomic_mass":79.90,"electronegativity":2.96,"electron_affinity":3.364,"first_ionization_energy":11.814,"thermal_conductivity":0.122,"specific_heat":0.474,"dipole_polarizability":3.05,"magnetic_moment":0,"valence_electron_number":7,"unpaired_electrons":1,"heat_of_formation":111.9,"electrical_conductivity":0,"ionic_radius":182,"vdw_radius":185,"period_number":4,"group_number":17,"pettifor_number":98},
    "Rb": {"atomic_mass":85.47,"electronegativity":0.82,"electron_affinity":0.486,"first_ionization_energy":4.177,"thermal_conductivity":58.2,"specific_heat":0.363,"dipole_polarizability":47.3,"magnetic_moment":0,"valence_electron_number":1,"unpaired_electrons":1,"heat_of_formation":80.9,"electrical_conductivity":7.75e6,"ionic_radius":166,"vdw_radius":303,"period_number":5,"group_number":1,"pettifor_number":9},
    "Sr": {"atomic_mass":87.62,"electronegativity":0.95,"electron_affinity":0.052,"first_ionization_energy":5.695,"thermal_conductivity":35.4,"specific_heat":0.301,"dipole_polarizability":27.6,"magnetic_moment":0,"valence_electron_number":2,"unpaired_electrons":0,"heat_of_formation":164.4,"electrical_conductivity":7.62e6,"ionic_radius":132,"vdw_radius":249,"period_number":5,"group_number":2,"pettifor_number":15},
    "Y":  {"atomic_mass":88.91,"electronegativity":1.22,"electron_affinity":0.307,"first_ionization_energy":6.217,"thermal_conductivity":17.2,"specific_heat":0.298,"dipole_polarizability":22.7,"magnetic_moment":0,"valence_electron_number":3,"unpaired_electrons":1,"heat_of_formation":421.3,"electrical_conductivity":1.66e6,"ionic_radius":104,"vdw_radius":219,"period_number":5,"group_number":3,"pettifor_number":20},
    "Zr": {"atomic_mass":91.22,"electronegativity":1.33,"electron_affinity":0.426,"first_ionization_energy":6.634,"thermal_conductivity":22.7,"specific_heat":0.278,"dipole_polarizability":17.9,"magnetic_moment":0,"valence_electron_number":4,"unpaired_electrons":2,"heat_of_formation":608.8,"electrical_conductivity":2.36e6,"ionic_radius":86,"vdw_radius":186,"period_number":5,"group_number":4,"pettifor_number":52},
    "Nb": {"atomic_mass":92.91,"electronegativity":1.60,"electron_affinity":0.893,"first_ionization_energy":6.759,"thermal_conductivity":53.7,"specific_heat":0.265,"dipole_polarizability":15.7,"magnetic_moment":0,"valence_electron_number":5,"unpaired_electrons":1,"heat_of_formation":725.9,"electrical_conductivity":6.93e6,"ionic_radius":86,"vdw_radius":207,"period_number":5,"group_number":5,"pettifor_number":55},
    "Mo": {"atomic_mass":95.96,"electronegativity":2.16,"electron_affinity":0.746,"first_ionization_energy":7.092,"thermal_conductivity":138.0,"specific_heat":0.251,"dipole_polarizability":12.8,"magnetic_moment":0,"valence_electron_number":6,"unpaired_electrons":6,"heat_of_formation":658.1,"electrical_conductivity":1.87e7,"ionic_radius":83,"vdw_radius":209,"period_number":5,"group_number":6,"pettifor_number":58},
    "Tc": {"atomic_mass":98.00,"electronegativity":1.90,"electron_affinity":0.55,"first_ionization_energy":7.28,"thermal_conductivity":50.6,"specific_heat":0.21,"dipole_polarizability":11.4,"magnetic_moment":0,"valence_electron_number":7,"unpaired_electrons":5,"heat_of_formation":678,"electrical_conductivity":5e6,"ionic_radius":78.5,"vdw_radius":209,"period_number":5,"group_number":7,"pettifor_number":61},
    "Ru": {"atomic_mass":101.07,"electronegativity":2.20,"electron_affinity":1.05,"first_ionization_energy":7.361,"thermal_conductivity":117.0,"specific_heat":0.238,"dipole_polarizability":9.6,"magnetic_moment":0,"valence_electron_number":8,"unpaired_electrons":4,"heat_of_formation":642.7,"electrical_conductivity":1.35e7,"ionic_radius":82,"vdw_radius":207,"period_number":5,"group_number":8,"pettifor_number":63},
    "Rh": {"atomic_mass":102.91,"electronegativity":2.28,"electron_affinity":1.137,"first_ionization_energy":7.459,"thermal_conductivity":150.0,"specific_heat":0.243,"dipole_polarizability":8.6,"magnetic_moment":0,"valence_electron_number":9,"unpaired_electrons":3,"heat_of_formation":556,"electrical_conductivity":2.12e7,"ionic_radius":80.5,"vdw_radius":195,"period_number":5,"group_number":9,"pettifor_number":65},
    "Pd": {"atomic_mass":106.42,"electronegativity":2.20,"electron_affinity":0.562,"first_ionization_energy":8.337,"thermal_conductivity":71.8,"specific_heat":0.244,"dipole_polarizability":4.8,"magnetic_moment":0,"valence_electron_number":10,"unpaired_electrons":0,"heat_of_formation":378.2,"electrical_conductivity":9.52e6,"ionic_radius":100,"vdw_radius":202,"period_number":5,"group_number":10,"pettifor_number":67},
    "Ag": {"atomic_mass":107.87,"electronegativity":1.93,"electron_affinity":1.302,"first_ionization_energy":7.576,"thermal_conductivity":429.0,"specific_heat":0.235,"dipole_polarizability":7.2,"magnetic_moment":0,"valence_electron_number":11,"unpaired_electrons":1,"heat_of_formation":284.9,"electrical_conductivity":6.3e7,"ionic_radius":129,"vdw_radius":172,"period_number":5,"group_number":11,"pettifor_number":71},
    "Cd": {"atomic_mass":112.41,"electronegativity":1.69,"electron_affinity":0,"first_ionization_energy":8.994,"thermal_conductivity":96.6,"specific_heat":0.232,"dipole_polarizability":7.36,"magnetic_moment":0,"valence_electron_number":12,"unpaired_electrons":0,"heat_of_formation":112.0,"electrical_conductivity":1.38e7,"ionic_radius":109,"vdw_radius":158,"period_number":5,"group_number":12,"pettifor_number":75},
    "In": {"atomic_mass":114.82,"electronegativity":1.78,"electron_affinity":0.404,"first_ionization_energy":5.786,"thermal_conductivity":81.8,"specific_heat":0.233,"dipole_polarizability":10.2,"magnetic_moment":0,"valence_electron_number":3,"unpaired_electrons":1,"heat_of_formation":243,"electrical_conductivity":1.19e7,"ionic_radius":94,"vdw_radius":193,"period_number":5,"group_number":13,"pettifor_number":79},
    "Sn": {"atomic_mass":118.71,"electronegativity":1.96,"electron_affinity":1.112,"first_ionization_energy":7.344,"thermal_conductivity":66.8,"specific_heat":0.228,"dipole_polarizability":7.7,"magnetic_moment":0,"valence_electron_number":4,"unpaired_electrons":2,"heat_of_formation":302.0,"electrical_conductivity":9.09e6,"ionic_radius":83,"vdw_radius":217,"period_number":5,"group_number":14,"pettifor_number":83},
    "Sb": {"atomic_mass":121.76,"electronegativity":2.05,"electron_affinity":1.047,"first_ionization_energy":8.64,"thermal_conductivity":24.4,"specific_heat":0.207,"dipole_polarizability":6.6,"magnetic_moment":0,"valence_electron_number":5,"unpaired_electrons":3,"heat_of_formation":264.4,"electrical_conductivity":2.56e6,"ionic_radius":90,"vdw_radius":206,"period_number":5,"group_number":15,"pettifor_number":87},
    "Te": {"atomic_mass":127.60,"electronegativity":2.10,"electron_affinity":1.971,"first_ionization_energy":9.010,"thermal_conductivity":3.0,"specific_heat":0.202,"dipole_polarizability":5.5,"magnetic_moment":0,"valence_electron_number":6,"unpaired_electrons":2,"heat_of_formation":196.6,"electrical_conductivity":2e4,"ionic_radius":207,"vdw_radius":206,"period_number":5,"group_number":16,"pettifor_number":91},
    "I":  {"atomic_mass":126.90,"electronegativity":2.66,"electron_affinity":3.059,"first_ionization_energy":10.451,"thermal_conductivity":0.449,"specific_heat":0.214,"dipole_polarizability":5.35,"magnetic_moment":0,"valence_electron_number":7,"unpaired_electrons":1,"heat_of_formation":106.8,"electrical_conductivity":0,"ionic_radius":206,"vdw_radius":198,"period_number":5,"group_number":17,"pettifor_number":97},
    "Cs": {"atomic_mass":132.91,"electronegativity":0.79,"electron_affinity":0.472,"first_ionization_energy":3.894,"thermal_conductivity":35.9,"specific_heat":0.242,"dipole_polarizability":59.42,"magnetic_moment":0,"valence_electron_number":1,"unpaired_electrons":1,"heat_of_formation":76.5,"electrical_conductivity":4.89e6,"ionic_radius":181,"vdw_radius":343,"period_number":6,"group_number":1,"pettifor_number":8},
    "Ba": {"atomic_mass":137.33,"electronegativity":0.89,"electron_affinity":0.145,"first_ionization_energy":5.212,"thermal_conductivity":18.4,"specific_heat":0.204,"dipole_polarizability":39.7,"magnetic_moment":0,"valence_electron_number":2,"unpaired_electrons":0,"heat_of_formation":180,"electrical_conductivity":2.86e6,"ionic_radius":149,"vdw_radius":268,"period_number":6,"group_number":2,"pettifor_number":16},
    "La": {"atomic_mass":138.91,"electronegativity":1.10,"electron_affinity":0.47,"first_ionization_energy":5.577,"thermal_conductivity":13.4,"specific_heat":0.195,"dipole_polarizability":31.1,"magnetic_moment":0,"valence_electron_number":3,"unpaired_electrons":1,"heat_of_formation":431.0,"electrical_conductivity":1.63e6,"ionic_radius":117.2,"vdw_radius":240,"period_number":6,"group_number":3,"pettifor_number":33},
    "Ce": {"atomic_mass":140.12,"electronegativity":1.12,"electron_affinity":0.955,"first_ionization_energy":5.539,"thermal_conductivity":11.3,"specific_heat":0.192,"dipole_polarizability":29.6,"magnetic_moment":2.54,"valence_electron_number":4,"unpaired_electrons":2,"heat_of_formation":423.0,"electrical_conductivity":1.15e6,"ionic_radius":115,"vdw_radius":235,"period_number":6,"group_number":3,"pettifor_number":34},
    "Pr": {"atomic_mass":140.91,"electronegativity":1.13,"electron_affinity":0.962,"first_ionization_energy":5.464,"thermal_conductivity":12.5,"specific_heat":0.193,"dipole_polarizability":28.2,"magnetic_moment":3.58,"valence_electron_number":5,"unpaired_electrons":3,"heat_of_formation":355.6,"electrical_conductivity":1.48e6,"ionic_radius":113,"vdw_radius":239,"period_number":6,"group_number":3,"pettifor_number":35},
    "Nd": {"atomic_mass":144.24,"electronegativity":1.14,"electron_affinity":1.916,"first_ionization_energy":5.525,"thermal_conductivity":16.5,"specific_heat":0.190,"dipole_polarizability":31.4,"magnetic_moment":3.62,"valence_electron_number":6,"unpaired_electrons":4,"heat_of_formation":326.9,"electrical_conductivity":1.56e6,"ionic_radius":112.3,"vdw_radius":229,"period_number":6,"group_number":3,"pettifor_number":36},
    "Sm": {"atomic_mass":150.36,"electronegativity":1.17,"electron_affinity":1.165,"first_ionization_energy":5.644,"thermal_conductivity":13.3,"specific_heat":0.197,"dipole_polarizability":28.8,"magnetic_moment":0.85,"valence_electron_number":8,"unpaired_electrons":6,"heat_of_formation":206.7,"electrical_conductivity":1.09e6,"ionic_radius":109.8,"vdw_radius":236,"period_number":6,"group_number":3,"pettifor_number":38},
    "Eu": {"atomic_mass":151.96,"electronegativity":1.20,"electron_affinity":0.864,"first_ionization_energy":5.670,"thermal_conductivity":13.9,"specific_heat":0.182,"dipole_polarizability":29.0,"magnetic_moment":7.94,"valence_electron_number":9,"unpaired_electrons":7,"heat_of_formation":175.3,"electrical_conductivity":1.12e6,"ionic_radius":108.7,"vdw_radius":233,"period_number":6,"group_number":3,"pettifor_number":39},
    "Gd": {"atomic_mass":157.25,"electronegativity":1.20,"electron_affinity":1.165,"first_ionization_energy":6.150,"thermal_conductivity":10.6,"specific_heat":0.236,"dipole_polarizability":23.5,"magnetic_moment":7.94,"valence_electron_number":10,"unpaired_electrons":8,"heat_of_formation":397.5,"electrical_conductivity":7.36e5,"ionic_radius":107.8,"vdw_radius":237,"period_number":6,"group_number":3,"pettifor_number":40},
    "Tb": {"atomic_mass":158.93,"electronegativity":1.20,"electron_affinity":1.165,"first_ionization_energy":5.864,"thermal_conductivity":11.1,"specific_heat":0.182,"dipole_polarizability":25.5,"magnetic_moment":9.72,"valence_electron_number":11,"unpaired_electrons":5,"heat_of_formation":388.7,"electrical_conductivity":8.77e5,"ionic_radius":106.3,"vdw_radius":221,"period_number":6,"group_number":3,"pettifor_number":41},
    "Dy": {"atomic_mass":162.50,"electronegativity":1.22,"electron_affinity":1.165,"first_ionization_energy":5.939,"thermal_conductivity":10.7,"specific_heat":0.170,"dipole_polarizability":24.5,"magnetic_moment":10.65,"valence_electron_number":12,"unpaired_electrons":4,"heat_of_formation":290.4,"electrical_conductivity":1.08e6,"ionic_radius":105.2,"vdw_radius":229,"period_number":6,"group_number":3,"pettifor_number":42},
    "Ho": {"atomic_mass":164.93,"electronegativity":1.23,"electron_affinity":1.02,"first_ionization_energy":6.022,"thermal_conductivity":16.2,"specific_heat":0.165,"dipole_polarizability":23.6,"magnetic_moment":10.61,"valence_electron_number":13,"unpaired_electrons":3,"heat_of_formation":300.8,"electrical_conductivity":1.23e6,"ionic_radius":104.1,"vdw_radius":216,"period_number":6,"group_number":3,"pettifor_number":43},
    "Er": {"atomic_mass":167.26,"electronegativity":1.24,"electron_affinity":1.165,"first_ionization_energy":6.108,"thermal_conductivity":14.5,"specific_heat":0.168,"dipole_polarizability":22.7,"magnetic_moment":9.58,"valence_electron_number":14,"unpaired_electrons":2,"heat_of_formation":317.1,"electrical_conductivity":1.17e6,"ionic_radius":103,"vdw_radius":235,"period_number":6,"group_number":3,"pettifor_number":44},
    "Tm": {"atomic_mass":168.93,"electronegativity":1.25,"electron_affinity":1.029,"first_ionization_energy":6.184,"thermal_conductivity":16.9,"specific_heat":0.160,"dipole_polarizability":21.8,"magnetic_moment":7.56,"valence_electron_number":15,"unpaired_electrons":1,"heat_of_formation":232.2,"electrical_conductivity":1.48e6,"ionic_radius":102,"vdw_radius":227,"period_number":6,"group_number":3,"pettifor_number":45},
    "Yb": {"atomic_mass":173.05,"electronegativity":1.10,"electron_affinity":0.020,"first_ionization_energy":6.254,"thermal_conductivity":38.5,"specific_heat":0.155,"dipole_polarizability":21.0,"magnetic_moment":4.54,"valence_electron_number":16,"unpaired_electrons":0,"heat_of_formation":152.3,"electrical_conductivity":3.61e6,"ionic_radius":100.8,"vdw_radius":242,"period_number":6,"group_number":3,"pettifor_number":46},
    "Lu": {"atomic_mass":174.97,"electronegativity":1.27,"electron_affinity":0.34,"first_ionization_energy":5.426,"thermal_conductivity":16.4,"specific_heat":0.154,"dipole_polarizability":21.9,"magnetic_moment":0,"valence_electron_number":3,"unpaired_electrons":1,"heat_of_formation":427.6,"electrical_conductivity":1.85e6,"ionic_radius":100.1,"vdw_radius":217,"period_number":6,"group_number":3,"pettifor_number":21},
    "Hf": {"atomic_mass":178.49,"electronegativity":1.30,"electron_affinity":0.17,"first_ionization_energy":6.825,"thermal_conductivity":23.0,"specific_heat":0.144,"dipole_polarizability":16.2,"magnetic_moment":0,"valence_electron_number":4,"unpaired_electrons":2,"heat_of_formation":619.2,"electrical_conductivity":3.34e6,"ionic_radius":85,"vdw_radius":175,"period_number":6,"group_number":4,"pettifor_number":53},
    "Ta": {"atomic_mass":180.95,"electronegativity":1.50,"electron_affinity":0.322,"first_ionization_energy":7.550,"thermal_conductivity":57.5,"specific_heat":0.140,"dipole_polarizability":13.1,"magnetic_moment":0,"valence_electron_number":5,"unpaired_electrons":3,"heat_of_formation":782.0,"electrical_conductivity":7.63e6,"ionic_radius":86,"vdw_radius":220,"period_number":6,"group_number":5,"pettifor_number":56},
    "W":  {"atomic_mass":183.84,"electronegativity":2.36,"electron_affinity":0.816,"first_ionization_energy":7.864,"thermal_conductivity":173.0,"specific_heat":0.132,"dipole_polarizability":11.1,"magnetic_moment":0,"valence_electron_number":6,"unpaired_electrons":4,"heat_of_formation":849.4,"electrical_conductivity":1.89e7,"ionic_radius":80,"vdw_radius":210,"period_number":6,"group_number":6,"pettifor_number":59},
    "Re": {"atomic_mass":186.21,"electronegativity":1.90,"electron_affinity":0.15,"first_ionization_energy":7.834,"thermal_conductivity":48.0,"specific_heat":0.137,"dipole_polarizability":9.7,"magnetic_moment":0,"valence_electron_number":7,"unpaired_electrons":5,"heat_of_formation":769.0,"electrical_conductivity":5.81e6,"ionic_radius":77,"vdw_radius":217,"period_number":6,"group_number":7,"pettifor_number":62},
    "Os": {"atomic_mass":190.23,"electronegativity":2.20,"electron_affinity":1.10,"first_ionization_energy":8.438,"thermal_conductivity":87.6,"specific_heat":0.130,"dipole_polarizability":8.5,"magnetic_moment":0,"valence_electron_number":8,"unpaired_electrons":4,"heat_of_formation":791,"electrical_conductivity":1.23e7,"ionic_radius":77,"vdw_radius":216,"period_number":6,"group_number":8,"pettifor_number":63},
    "Ir": {"atomic_mass":192.22,"electronegativity":2.20,"electron_affinity":1.565,"first_ionization_energy":8.967,"thermal_conductivity":147.0,"specific_heat":0.131,"dipole_polarizability":7.6,"magnetic_moment":0,"valence_electron_number":9,"unpaired_electrons":3,"heat_of_formation":669,"electrical_conductivity":2.12e7,"ionic_radius":82,"vdw_radius":202,"period_number":6,"group_number":9,"pettifor_number":65},
    "Pt": {"atomic_mass":195.08,"electronegativity":2.28,"electron_affinity":2.128,"first_ionization_energy":8.959,"thermal_conductivity":71.6,"specific_heat":0.133,"dipole_polarizability":6.5,"magnetic_moment":0,"valence_electron_number":10,"unpaired_electrons":2,"heat_of_formation":565.7,"electrical_conductivity":9.66e6,"ionic_radius":94,"vdw_radius":175,"period_number":6,"group_number":10,"pettifor_number":68},
    "Au": {"atomic_mass":196.97,"electronegativity":2.54,"electron_affinity":2.309,"first_ionization_energy":9.226,"thermal_conductivity":318.0,"specific_heat":0.129,"dipole_polarizability":5.8,"magnetic_moment":0,"valence_electron_number":11,"unpaired_electrons":1,"heat_of_formation":366.1,"electrical_conductivity":4.52e7,"ionic_radius":151,"vdw_radius":166,"period_number":6,"group_number":11,"pettifor_number":70},
    "Hg": {"atomic_mass":200.59,"electronegativity":2.00,"electron_affinity":0,"first_ionization_energy":10.438,"thermal_conductivity":8.30,"specific_heat":0.140,"dipole_polarizability":5.02,"magnetic_moment":0,"valence_electron_number":12,"unpaired_electrons":0,"heat_of_formation":61.4,"electrical_conductivity":1.04e6,"ionic_radius":133,"vdw_radius":155,"period_number":6,"group_number":12,"pettifor_number":74},
    "Tl": {"atomic_mass":204.38,"electronegativity":1.62,"electron_affinity":0.377,"first_ionization_energy":6.108,"thermal_conductivity":46.1,"specific_heat":0.129,"dipole_polarizability":7.6,"magnetic_moment":0,"valence_electron_number":3,"unpaired_electrons":1,"heat_of_formation":182.2,"electrical_conductivity":6.67e6,"ionic_radius":164,"vdw_radius":196,"period_number":6,"group_number":13,"pettifor_number":78},
    "Pb": {"atomic_mass":207.2,"electronegativity":2.33,"electron_affinity":0.364,"first_ionization_energy":7.417,"thermal_conductivity":35.3,"specific_heat":0.129,"dipole_polarizability":6.8,"magnetic_moment":0,"valence_electron_number":4,"unpaired_electrons":2,"heat_of_formation":195.2,"electrical_conductivity":4.81e6,"ionic_radius":133,"vdw_radius":202,"period_number":6,"group_number":14,"pettifor_number":82},
    "Bi": {"atomic_mass":208.98,"electronegativity":2.02,"electron_affinity":0.946,"first_ionization_energy":7.286,"thermal_conductivity":7.97,"specific_heat":0.122,"dipole_polarizability":7.4,"magnetic_moment":0,"valence_electron_number":5,"unpaired_electrons":3,"heat_of_formation":209.6,"electrical_conductivity":8.67e5,"ionic_radius":117,"vdw_radius":207,"period_number":6,"group_number":15,"pettifor_number":87},
    "Th": {"atomic_mass":232.04,"electronegativity":1.30,"electron_affinity":1.17,"first_ionization_energy":6.307,"thermal_conductivity":54.0,"specific_heat":0.113,"dipole_polarizability":32.1,"magnetic_moment":0,"valence_electron_number":4,"unpaired_electrons":2,"heat_of_formation":598.3,"electrical_conductivity":6.53e6,"ionic_radius":108,"vdw_radius":237,"period_number":7,"group_number":3,"pettifor_number":47},
    "U":  {"atomic_mass":238.03,"electronegativity":1.38,"electron_affinity":0.315,"first_ionization_energy":6.194,"thermal_conductivity":27.5,"specific_heat":0.116,"dipole_polarizability":27.4,"magnetic_moment":3.20,"valence_electron_number":6,"unpaired_electrons":4,"heat_of_formation":533,"electrical_conductivity":3.55e6,"ionic_radius":116.5,"vdw_radius":186,"period_number":7,"group_number":3,"pettifor_number":49},
    "Pm": {"atomic_mass":145.0,"electronegativity":1.13,"electron_affinity":1.165,"first_ionization_energy":5.582,"thermal_conductivity":17.9,"specific_heat":0.185,"dipole_polarizability":30.0,"magnetic_moment":2.68,"valence_electron_number":7,"unpaired_electrons":5,"heat_of_formation":356.0,"electrical_conductivity":1.3e6,"ionic_radius":111,"vdw_radius":236,"period_number":6,"group_number":3,"pettifor_number":37},
    "Ar": {"atomic_mass":39.95,"electronegativity":0,"electron_affinity":0,"first_ionization_energy":15.760,"thermal_conductivity":0.0177,"specific_heat":0.520,"dipole_polarizability":1.641,"magnetic_moment":0,"valence_electron_number":8,"unpaired_electrons":0,"heat_of_formation":0,"electrical_conductivity":0,"ionic_radius":154,"vdw_radius":188,"period_number":3,"group_number":18,"pettifor_number":3},
    "Kr": {"atomic_mass":83.80,"electronegativity":3.00,"electron_affinity":0,"first_ionization_energy":14.000,"thermal_conductivity":0.00943,"specific_heat":0.248,"dipole_polarizability":2.484,"magnetic_moment":0,"valence_electron_number":8,"unpaired_electrons":0,"heat_of_formation":0,"electrical_conductivity":0,"ionic_radius":169,"vdw_radius":202,"period_number":4,"group_number":18,"pettifor_number":4},
    "Xe": {"atomic_mass":131.29,"electronegativity":2.60,"electron_affinity":0,"first_ionization_energy":12.130,"thermal_conductivity":0.00565,"specific_heat":0.158,"dipole_polarizability":4.044,"magnetic_moment":0,"valence_electron_number":8,"unpaired_electrons":0,"heat_of_formation":0,"electrical_conductivity":0,"ionic_radius":190,"vdw_radius":216,"period_number":5,"group_number":18,"pettifor_number":5},
    "Ne": {"atomic_mass":20.18,"electronegativity":0,"electron_affinity":0,"first_ionization_energy":21.565,"thermal_conductivity":0.0491,"specific_heat":1.030,"dipole_polarizability":0.3956,"magnetic_moment":0,"valence_electron_number":8,"unpaired_electrons":0,"heat_of_formation":0,"electrical_conductivity":0,"ionic_radius":38,"vdw_radius":154,"period_number":2,"group_number":18,"pettifor_number":2},
}

# The 12 physical properties used in Jabir-style featurization
PHYSICAL_PROPERTIES = [
    "thermal_conductivity", "magnetic_moment", "pettifor_number",
    "electron_affinity", "electronegativity", "specific_heat",
    "dipole_polarizability", "first_ionization_energy",
    "valence_electron_number", "unpaired_electrons",
    "heat_of_formation", "electrical_conductivity",
]

# 4 properties only computed as Element-based (no subscript/fraction basis)
ELEMENT_ONLY_PROPERTIES = [
    "ionic_radius", "vdw_radius", "period_number", "group_number",
]

# 8 statistical aggregation functions
STAT_FUNCTIONS = ["mean", "std", "variance", "range", "min", "max", "median", "avg_dev"]


@mcp.tool()
def stat_aggregation(values: list[float], func: str) -> dict:
    """Compute a single statistical aggregation over a list of values.

    Args:
        values: List of numeric values to aggregate
        func: One of 'mean', 'std', 'variance', 'range', 'min', 'max', 'median', 'avg_dev'

    Returns:
        dict with func and result
    """
    result = _stat_internal(values, func)
    return {"func": func, "n_values": len(values), "result": result}


def _stat_internal(values: list[float], func: str) -> float:
    """Internal stat computation."""
    if not values:
        return 0.0
    arr = np.array(values, dtype=float)
    if func == "mean":
        return float(np.mean(arr))
    elif func == "std":
        return float(np.std(arr, ddof=0))
    elif func == "variance":
        return float(np.var(arr, ddof=0))
    elif func == "range":
        return float(np.max(arr) - np.min(arr))
    elif func == "min":
        return float(np.min(arr))
    elif func == "max":
        return float(np.max(arr))
    elif func == "median":
        return float(np.median(arr))
    elif func == "avg_dev":
        return float(np.mean(np.abs(arr - np.mean(arr))))
    return 0.0


@mcp.tool()
def parse_formula(formula: str) -> dict:
    """Parse a chemical formula string into element-subscript pairs.

    Handles formulas like 'Ba0.8Fe2Se2', 'YBa2Cu3O7', 'SmFeAsO0.8F0.2'.
    Returns dict with 'elements' (list of {symbol, subscript, fraction}).

    Args:
        formula: Chemical formula string

    Returns:
        dict with parsed element data and element_count, subscript_sum
    """
    pattern = r'([A-Z][a-z]?)(\d*\.?\d*)'
    matches = re.findall(pattern, formula)
    elements = []
    for symbol, sub_str in matches:
        if not symbol:
            continue
        subscript = float(sub_str) if sub_str else 1.0
        elements.append({"symbol": symbol, "subscript": subscript})

    total_sub = sum(e["subscript"] for e in elements)
    for e in elements:
        e["fraction"] = round(e["subscript"] / total_sub, 6) if total_sub > 0 else 0

    return {
        "elements": elements,
        "element_count": len(elements),
        "subscript_sum": round(total_sub, 4),
    }


@mcp.tool()
def get_element_property(symbol: str, property_name: str) -> dict:
    """Look up a single elemental property value.

    Args:
        symbol: Element symbol (e.g., 'Cu', 'O', 'Ba')
        property_name: One of the available properties (thermal_conductivity,
            electronegativity, electron_affinity, etc.)

    Returns:
        dict with symbol, property, value (or error if not found)
    """
    props = _ELEM_PROPS.get(symbol)
    if props is None:
        return {"error": f"Element '{symbol}' not in database"}
    val = props.get(property_name)
    if val is None:
        return {"error": f"Property '{property_name}' not found for {symbol}"}
    return {"symbol": symbol, "property": property_name, "value": val}


@mcp.tool()
def list_available_properties() -> dict:
    """List all available elemental properties and statistics.

    Returns:
        dict with physical_properties, element_only_properties,
        stat_functions, and available_elements
    """
    return {
        "physical_properties": PHYSICAL_PROPERTIES,
        "element_only_properties": ELEMENT_ONLY_PROPERTIES,
        "stat_functions": STAT_FUNCTIONS,
        "n_elements_in_db": len(_ELEM_PROPS),
        "available_elements": sorted(_ELEM_PROPS.keys()),
    }


@mcp.tool()
def compute_property_descriptor(formula: str, property_name: str,
                                 basis: str = "element",
                                 stat_func: str = "mean") -> dict:
    """Compute ONE statistical descriptor for ONE property of a chemical formula.

    The agent must call this repeatedly with different property/basis/stat
    combinations to build a feature vector. This is a deliberate design choice:
    the agent decides which properties, bases, and statistics to include.

    Args:
        formula: Chemical formula string (e.g. 'YBa2Cu3O7')
        property_name: Elemental property (e.g. 'electronegativity', 'thermal_conductivity')
        basis: One of 'element' (raw values), 'subscript' (value * subscript),
               'fraction' (value * atomic fraction)
        stat_func: One of 'mean', 'std', 'variance', 'range', 'min', 'max', 'median', 'avg_dev'

    Returns:
        dict with formula, descriptor_name, value
    """
    parsed = parse_formula.__wrapped__(formula) if hasattr(parse_formula, '__wrapped__') else parse_formula(formula)
    elems = parsed["elements"]

    vals = []
    for e in elems:
        p = _ELEM_PROPS.get(e["symbol"], {})
        v = p.get(property_name, 0)
        if basis == "subscript":
            v = v * e["subscript"]
        elif basis == "fraction":
            v = v * e["fraction"]
        vals.append(v)

    result = round(_stat_internal(vals, stat_func), 6)
    name = f"{stat_func}_{property_name}_{basis.capitalize()}"
    return {"formula": formula, "descriptor_name": name, "value": result}


@mcp.tool()
def aggregate_stats(formula: str) -> dict:
    """Compute basic compositional metadata for a formula (element count, subscript sum).

    Args:
        formula: Chemical formula string

    Returns:
        dict with element_count and subscript_sum
    """
    parsed = parse_formula.__wrapped__(formula) if hasattr(parse_formula, '__wrapped__') else parse_formula(formula)
    return {
        "formula": formula,
        "element_count": parsed["element_count"],
        "subscript_sum": parsed["subscript_sum"],
    }


@mcp.tool()
def compute_element_fractions(csv_path: str, formula_col: str = "element",
                              prefix: str = "elemfrac_") -> dict:
    """Compute element fraction columns (83 columns for 83 elements in the dataset).

    For each compound, creates one column per unique element across the dataset,
    containing the fraction of that element in the compound (subscript/total_subscript).

    Column names are PREFIXED (default ``elemfrac_``), e.g. ``elemfrac_Fe``,
    ``elemfrac_Cu``, ``elemfrac_Tc``. The prefix is mandatory to avoid a subtle
    collision: the element technetium has symbol ``Tc``, which would otherwise
    create a feature column named exactly ``Tc`` that shadows/collides with the
    supervised target column ``Tc`` (or its near-duplicate ``Tc_mean``). Any of
    the 43 technetium-bearing compounds in DataG would trigger this. The prefix
    is purely cosmetic to the VALUES — only the column names change — so the
    83-element-fraction feature space and any answer numbers derived from it are
    unchanged after the rename.

    Args:
        csv_path: Path to input CSV
        formula_col: Column name with chemical formulas
        prefix: Safe prefix prepended to every element-symbol column name so no
            element symbol (notably ``Tc``) can collide with the target column.

    Returns:
        dict with output_path, element list (raw symbols), and column_names
        (the prefixed names actually written to the CSV).
    """
    import pandas as pd
    import os

    df = pd.read_csv(csv_path)
    formulas = df[formula_col].tolist()

    # First pass: find all unique elements
    all_elements = set()
    parsed_list = []
    for formula in formulas:
        pattern = r'([A-Z][a-z]?)(\d*\.?\d*)'
        matches = re.findall(pattern, formula)
        elems = {}
        total = 0
        for sym, sub_str in matches:
            if not sym:
                continue
            sub = float(sub_str) if sub_str else 1.0
            elems[sym] = sub
            total += sub
        fracs = {sym: sub / total for sym, sub in elems.items()} if total > 0 else {}
        all_elements.update(fracs.keys())
        parsed_list.append(fracs)

    sorted_elements = sorted(all_elements)
    # Safe, collision-free column names: prefix every element symbol so that the
    # technetium column ``Tc`` becomes ``elemfrac_Tc`` and can never shadow the
    # supervised target column ``Tc`` / ``Tc_mean``.
    col_names = [f"{prefix}{elem}" for elem in sorted_elements]

    # Build fraction matrix using the prefixed column names.
    rows = []
    for fracs in parsed_list:
        row = {f"{prefix}{elem}": round(fracs.get(elem, 0.0), 6)
               for elem in sorted_elements}
        rows.append(row)

    frac_df = pd.DataFrame(rows, columns=col_names)
    out_dir = os.path.dirname(csv_path)
    out_path = os.path.join(out_dir, "element_fractions.csv")
    frac_df.to_csv(out_path, index=False)

    return {
        "output_path": out_path,
        "n_samples": len(frac_df),
        "n_elements": len(sorted_elements),
        "elements": sorted_elements,
        "prefix": prefix,
        "column_names": col_names,
    }


@mcp.tool()
def build_jabir_feature_matrix(csv_path: str, formula_col: str = "element",
                               target_col: str = "Tc",
                               leakage_cols: list = None) -> dict:
    """Batch-generate the full 322-dimensional Jabir descriptor matrix.

    Builds the definitive composition-derived feature space using ONLY the
    chemical formula column. No information from any other column (in
    particular NOT ``Tc`` or the near-duplicate ``Tc_mean``) ever enters a
    feature, so the output is leak-free by construction.

    The 322 features are assembled deterministically as::

        12 physical properties x 3 bases {element, subscript, fraction}
                               x 8 statistics                 = 288
      +  4 element-only properties              x 8 statistics =  32
      +  element_count + subscript_sum                        =   2
                                                              -------
                                                         total = 322

    The physical properties, element-only properties, bases and statistics are
    exactly those in ``PHYSICAL_PROPERTIES``, ``ELEMENT_ONLY_PROPERTIES`` and
    ``STAT_FUNCTIONS``. Descriptor column names match
    ``compute_property_descriptor`` (``{stat}_{property}_{Basis}``); the two
    metadata columns are ``element_count`` and ``subscript_sum``.

    The target column (``Tc``) is copied through unchanged so the output CSV is
    directly trainable, while the leakage column ``Tc_mean`` (and anything in
    ``leakage_cols``) is dropped and can never become a feature.

    Args:
        csv_path: Path to the input CSV (must contain ``formula_col``).
        formula_col: Column holding chemical formula strings.
        target_col: Supervised target column copied through to the output.
        leakage_cols: Columns to drop entirely (default ['Tc_mean']). These are
            never read when building features.

    Returns:
        dict with output_path, n_samples, n_features (== 322), feature_names,
        and dropped_leakage_cols.
    """
    import pandas as pd
    import os

    if leakage_cols is None:
        # Unified non-feature / leakage exclusion across all tools: the trailing
        # ``Tc_mean`` leakage column plus any bookkeeping columns (element string,
        # row index, unnamed index). ``Tc`` (the target) is copied through, not dropped.
        leakage_cols = ["Tc_mean", "element", "index", "Index", "Unnamed: 0"]

    df = pd.read_csv(csv_path)
    formulas = df[formula_col].astype(str).tolist()

    feature_names = []
    for prop in PHYSICAL_PROPERTIES:
        for basis in ("element", "subscript", "fraction"):
            for stat in STAT_FUNCTIONS:
                feature_names.append(f"{stat}_{prop}_{basis.capitalize()}")
    for prop in ELEMENT_ONLY_PROPERTIES:
        for stat in STAT_FUNCTIONS:
            feature_names.append(f"{stat}_{prop}_Element")
    feature_names += ["element_count", "subscript_sum"]

    rows = []
    for formula in formulas:
        parsed = parse_formula.__wrapped__(formula) if hasattr(parse_formula, "__wrapped__") else parse_formula(formula)
        elems = parsed["elements"]
        feat = {}
        # 12 physical properties x 3 bases x 8 stats
        for prop in PHYSICAL_PROPERTIES:
            for basis in ("element", "subscript", "fraction"):
                vals = []
                for e in elems:
                    v = _ELEM_PROPS.get(e["symbol"], {}).get(prop, 0)
                    if basis == "subscript":
                        v = v * e["subscript"]
                    elif basis == "fraction":
                        v = v * e["fraction"]
                    vals.append(v)
                for stat in STAT_FUNCTIONS:
                    feat[f"{stat}_{prop}_{basis.capitalize()}"] = round(_stat_internal(vals, stat), 6)
        # 4 element-only properties x 8 stats (element basis only)
        for prop in ELEMENT_ONLY_PROPERTIES:
            vals = [_ELEM_PROPS.get(e["symbol"], {}).get(prop, 0) for e in elems]
            for stat in STAT_FUNCTIONS:
                feat[f"{stat}_{prop}_Element"] = round(_stat_internal(vals, stat), 6)
        # metadata
        feat["element_count"] = parsed["element_count"]
        feat["subscript_sum"] = parsed["subscript_sum"]
        rows.append(feat)

    feat_df = pd.DataFrame(rows, columns=feature_names)
    if target_col in df.columns:
        feat_df[target_col] = df[target_col].values

    out_dir = os.path.dirname(os.path.abspath(csv_path))
    out_path = os.path.join(out_dir, "jabir_features_322.csv")
    feat_df.to_csv(out_path, index=False)

    return {
        "output_path": out_path,
        "n_samples": len(feat_df),
        "n_features": len(feature_names),
        "feature_names": feature_names,
        "dropped_leakage_cols": [c for c in leakage_cols if c in df.columns],
    }


@mcp.tool()
def feature_correlation_filter(csv_path: str, threshold: float = 0.80,
                                target_col: str = "Tc",
                                test_size: float = 0.10,
                                random_state: int = 42) -> dict:
    """Identify highly correlated feature clusters and select representatives.

    Groups features with absolute Pearson correlation > threshold into clusters.
    For each cluster, selects the feature with highest absolute correlation to
    the target variable.

    LEAK-SAFE BY DEFAULT: ``test_size`` defaults to ``0.10`` (the task's 90/10
    holdout) and ``random_state`` to ``42``, so the final test fold is split off
    and the correlations are computed on the TRAINING rows ONLY — never the full
    table or the test fold. Pass the SAME ``test_size``/``random_state`` you use
    in ``train_model`` so the held-out fold matches. Only set ``test_size=0.0``
    when you have ALREADY pre-split and are passing a train-only matrix; doing so
    on the full table would leak the test fold into feature selection.

    Args:
        csv_path: Path to feature matrix CSV (target in last column or named)
        threshold: Correlation threshold for clustering (default 0.80)
        target_col: Name of target column
        test_size: Fraction held out as the final test fold and excluded here
            (default 0.10 = leak-safe train-only selection)
        random_state: Random seed for the holdout split (match train_model)

    Returns:
        dict with n_clusters, selected_features, removed_features
    """
    import pandas as pd

    df = pd.read_csv(csv_path)
    if test_size and test_size > 0:
        from sklearn.model_selection import train_test_split
        idx = np.arange(len(df))
        idx_train, _ = train_test_split(idx, test_size=test_size,
                                        random_state=random_state)
        df = df.iloc[idx_train].reset_index(drop=True)
    if target_col in df.columns:
        target = df[target_col]
        features = df.drop(columns=[target_col])
    else:
        target = df.iloc[:, -1]
        features = df.iloc[:, :-1]

    # Enforce leak-free selection: Tc_mean / element / index can never be a
    # selected feature, even if the raw CSV is passed in.
    features = features.drop(
        columns=[c for c in ("Tc_mean", "element", "Unnamed: 0", "Tc", "index", "Index")
                 if c in features.columns],
        errors="ignore")
    features = features.select_dtypes(include=[np.number])

    corr = features.corr().abs()
    n = len(features.columns)
    visited = [False] * n
    clusters = []

    for i in range(n):
        if visited[i]:
            continue
        cluster = [i]
        visited[i] = True
        for j in range(i + 1, n):
            if not visited[j] and corr.iloc[i, j] > threshold:
                cluster.append(j)
                visited[j] = True
        clusters.append(cluster)

    # For each cluster, pick feature with highest target correlation
    target_corr = features.corrwith(target).abs()
    selected = []
    for cluster in clusters:
        best_idx = max(cluster, key=lambda idx: target_corr.iloc[idx])
        selected.append(features.columns[best_idx])

    return {
        "n_original_features": n,
        "n_clusters": len(clusters),
        "n_selected": len(selected),
        "selected_features": selected,
        "threshold": threshold,
    }


@mcp.tool()
def shap_feature_ranking(csv_path: str, target_col: str = "Tc",
                         n_estimators: int = 500, max_features: int = 50,
                         test_size: float = 0.10, random_state: int = 42) -> dict:
    """Rank features by SHAP importance using a gradient boosting model.

    Trains a CatBoost/XGBoost model and computes mean absolute SHAP values
    to rank features by their contribution to predictions.

    LEAK-SAFE BY DEFAULT: ``test_size`` defaults to ``0.10`` (the task's 90/10
    holdout) and ``random_state`` to ``42``, so the model is fit and ranked on
    the TRAINING rows ONLY — never the full table or the test fold. Pass the SAME
    ``test_size``/``random_state`` you use in ``train_model`` so the held-out
    fold matches. Only set ``test_size=0.0`` when you have ALREADY pre-split and
    are passing a train-only matrix; doing so on the full table would leak the
    test fold into feature ranking.

    Args:
        csv_path: Path to feature matrix CSV
        target_col: Target column name
        n_estimators: Number of boosting rounds
        max_features: Maximum number of features to rank
        test_size: Fraction held out as the final test fold and excluded here
            (default 0.10 = leak-safe train-only ranking)
        random_state: Random seed for the holdout split (match train_model)

    Returns:
        dict with ranked feature importances
    """
    import pandas as pd

    df = pd.read_csv(csv_path)
    if test_size and test_size > 0:
        from sklearn.model_selection import train_test_split
        idx = np.arange(len(df))
        idx_train, _ = train_test_split(idx, test_size=test_size,
                                        random_state=random_state)
        df = df.iloc[idx_train].reset_index(drop=True)
    if target_col in df.columns:
        y = df[target_col].values
        feat_df = df.drop(columns=[target_col])
    else:
        y = df.iloc[:, -1].values
        feat_df = df.iloc[:, :-1]

    # Enforce leak-free ranking: Tc_mean / element / index are dropped so they
    # can never be ranked as predictive features.
    feat_df = feat_df.drop(
        columns=[c for c in ("Tc_mean", "element", "Unnamed: 0", "Tc", "index", "Index")
                 if c in feat_df.columns],
        errors="ignore")
    feat_df = feat_df.select_dtypes(include=[np.number])
    feature_names = list(feat_df.columns)
    X = feat_df.values

    try:
        from catboost import CatBoostRegressor
        model = CatBoostRegressor(iterations=n_estimators, learning_rate=0.05,
                                   depth=6, verbose=0, random_seed=42)
        model.fit(X, y)
    except ImportError:
        import xgboost
        model = xgboost.XGBRegressor(n_estimators=n_estimators, learning_rate=0.05,
                                      max_depth=6, verbosity=0, random_state=42)
        model.fit(X, y)

    import shap
    explainer = shap.TreeExplainer(model)
    # Use subset for speed
    n_sample = min(500, len(X))
    shap_values = explainer.shap_values(X[:n_sample])
    mean_abs = np.abs(shap_values).mean(axis=0)

    ranking = np.argsort(mean_abs)[::-1][:max_features]
    result = []
    for rank, idx in enumerate(ranking):
        result.append({
            "rank": rank + 1,
            "feature": feature_names[idx],
            "mean_abs_shap": round(float(mean_abs[idx]), 4),
        })

    return {
        "n_features_ranked": len(result),
        "feature_ranking": result,
    }


if __name__ == "__main__":
    mcp.run(transport="stdio")

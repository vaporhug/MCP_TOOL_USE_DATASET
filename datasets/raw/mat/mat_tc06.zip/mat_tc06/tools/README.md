# mat_tc06 — Tool Reference

## Database Retrieval (`database_retrieval.py`)

- **websearch**: Generic web search via scraping backend.
- **fetch_url**: HTTP GET with redirects for downloading files.
- **query_pubchem**: PubChem PUG-REST compound lookup.
- **query_chembl**: ChEMBL bioactivity query.
- **query_uniprot**: UniProt entry fetch.
- **query_pdb**: RCSB PDB entry metadata.
- **query_geo**: NCBI GEO series/sample fetch.
- **query_ncbi_entrez**: Generic Entrez E-search + E-fetch.
- **query_usgs_comcat**: USGS ComCat earthquake catalog query.
- **query_world_bank**: World Bank WDI indicator series.
- **query_openalex**: OpenAlex works/authors/venues search.
- **query_doi**: DOI resolution to Crossref metadata + OA URL.

## Data Processing (`data_processing.py`)

- **read_csv**: Parse CSV into list-of-dicts.
- **write_csv**: Write list-of-dicts to CSV.
- **read_excel**: Read .xlsx sheet into list-of-dicts.
- **read_parquet**: Columnar parquet reader.
- **read_netcdf**: NetCDF/HDF5 gridded data reader.
- **read_shapefile**: Vector data reader (shapefile/GeoJSON).
- **read_fasta**: FASTA sequence reader.
- **pivot_long_to_wide**: Long-to-wide reshape.
- **pivot_wide_to_long**: Wide-to-long melt.
- **drop_missing**: Remove rows with missing values.
- **coerce_numeric**: Cast columns to float.
- **join_tables**: SQL-style join on a single key.
- **groupby_aggregate**: Group-by with aggregation (mean/sum/min/max/count).

## Composition Feature Engineering (`composition_features.py`)

- **parse_formula**: Parse chemical formula into element-subscript-fraction triples.
- **get_element_property**: Look up a single elemental property value.
- **list_available_properties**: List all available properties (12 physical + 4 element-only), bases, and statistics.
- **stat_aggregation**: Compute one statistic (mean/std/variance/range/min/max/median/avg_dev) over a value list.
- **compute_property_descriptor**: Compute ONE descriptor = one property x one basis (element/subscript/fraction) x one statistic for one formula. Call repeatedly across properties/bases/statistics to assemble the full descriptor set (no single call returns all descriptors by design).
- **aggregate_stats**: Compositional metadata for a formula (element_count, subscript_sum).
- **compute_element_fractions**: Compute per-element fraction columns (one column per element across the dataset).
- **feature_correlation_filter**: Cluster correlated features and select representatives.
- **shap_feature_ranking**: Rank features by SHAP importance via gradient boosting.

## ML Tools (`ml_tools.py`)

- **load_csv_summary**: Load CSV and return shape/column statistics.
- **split_dataset**: Split into train/test with statistics.
- **train_model**: Train regression model (catboost/xgboost/random_forest/ridge/knn/svr).
- **get_predictions**: Get model predictions on test set.
- **compute_metrics**: Compute R2, RMSE, MAE.
- **compute_feature_importance**: SHAP or built-in feature importance ranking.
- **forward_feature_selection**: Greedy forward selection maximizing test R2.
- **predict_new_compounds**: Predict Tc for new compounds given feature vectors.

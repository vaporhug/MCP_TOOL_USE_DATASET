# mat_tc06 — Tool Reference

This task is fully offline: every tool runs on the bundled `DataG_13022.csv`
with no network access. Modeling is leak-free — the held-out test fold never
participates in early stopping, feature selection, or model selection.

**Leak-free feature-scoring rule (mandatory):** ALL feature-scoring / ranking /
selection tools must use ONLY the training part of the data (or a train-internal
validation split) and must NEVER use the final held-out test fold. This applies
to `compute_feature_importance` (SHAP/builtin computed on `X_train` only),
`forward_feature_selection` (scored on an inner train/val split), and
`composition_features.feature_correlation_filter` /
`composition_features.shap_feature_ranking` (fit/rank on training rows only).
The final test fold is reserved exclusively for reporting unbiased
generalization metrics.

**Target-leakage rule (mandatory):** the supervised target is `Tc`. BOTH `Tc`
and its near-duplicate `Tc_mean` are excluded from the feature set by every
modeling/selection/importance tool, in code, regardless of which column is
chosen as the target — so neither temperature column can leak. Tools that take
a `target_col` default it to `Tc` (not the trailing `Tc_mean`).

## Data Processing (`data_processing.py`)

All functions in this module are registered as callable MCP tools
(`FastMCP("Data_Processing")`), just like the other modules, and are also
importable as plain Python functions.

- **read_csv**: Parse CSV into list-of-dicts.
- **write_csv**: Write list-of-dicts to CSV.
- **read_json** / **write_json**: JSON I/O.
- **read_fasta**: FASTA sequence reader.
- **pivot_long_to_wide**: Long-to-wide reshape.
- **pivot_wide_to_long**: Wide-to-long melt.
- **drop_missing**: Remove rows with missing values.
- **coerce_numeric**: Cast columns to float.
- **join_tables**: SQL-style join on a single key.
- **groupby_aggregate**: Group-by with aggregation (mean/sum/min/max/count).

## Composition Feature Engineering (`composition_features.py`)

- **parse_formula**: Parse chemical formula into element-subscript-fraction triples.
- **get_element_property**: Look up a single elemental property value.
- **list_available_properties**: List all available properties (12 physical + 4 element-only), bases, and statistics.
- **stat_aggregation**: Compute one statistic (mean/std/variance/range/min/max/median/avg_dev) over a value list.
- **compute_property_descriptor**: Compute ONE descriptor = one property x one basis (element/subscript/fraction) x one statistic for one formula. Call repeatedly across properties/bases/statistics to assemble the descriptor set one column at a time.
- **build_jabir_feature_matrix**: Batch-generate the full 322-dimensional Jabir descriptor matrix from the formula column ONLY (12 physical x 3 bases x 8 stats + 4 element-only x 8 stats + element_count + subscript_sum = 322). Writes `jabir_features_322.csv` with the `Tc` target copied through and the leakage column `Tc_mean` dropped; no other column ever enters a feature (leak-free by construction).
- **aggregate_stats**: Compositional metadata for a formula (element_count, subscript_sum).
- **compute_element_fractions**: Compute per-element fraction columns (one column per element across the dataset). **Column names are PREFIXED** (default `elemfrac_`), e.g. `elemfrac_Fe`, `elemfrac_Cu`, `elemfrac_Tc`. The prefix is mandatory to prevent the technetium symbol `Tc` from producing a column named exactly `Tc` that would collide with the supervised target `Tc`/`Tc_mean` (43 DataG compounds contain technetium). The prefix changes only column names, not values, so the 83-element-fraction feature space is numerically unchanged.

```python
from composition_features import compute_element_fractions
res = compute_element_fractions("input_data/data/DataG_13022.csv")  # default prefix "elemfrac_"
assert "Tc" not in res["column_names"]          # no bare element-symbol column
assert "elemfrac_Tc" in res["column_names"]     # technetium is safely prefixed
```
- **feature_correlation_filter**: Cluster correlated features and select representatives. **Leak-safe by default**: `test_size=0.10`, `random_state=42`, so correlations are computed on the TRAINING rows only — the test fold is never used. Pass the same `test_size`/`random_state` as `train_model`; only set `test_size=0.0` on an already-pre-split train-only matrix. Drops `Tc_mean`/`element`/index in code so they can never be selected.
- **shap_feature_ranking**: Rank features by SHAP importance via gradient boosting. **Leak-safe by default**: `test_size=0.10`, `random_state=42`, so the model is fit/ranked on the TRAINING rows only — the test fold is never used. Pass the same `test_size`/`random_state` as `train_model`; only set `test_size=0.0` on an already-pre-split train-only matrix. Drops `Tc_mean`/`element`/index in code so they can never be ranked.

```python
from composition_features import feature_correlation_filter, shap_feature_ranking
# Leak-free by default: 90/10 holdout (random_state=42) split off, selection on train rows only.
clusters = feature_correlation_filter("jabir_features_322.csv")        # test_size=0.10 default
ranking  = shap_feature_ranking("jabir_features_322.csv", max_features=30)  # test_size=0.10 default
```

## ML Tools (`ml_tools.py`)

- **load_csv_summary**: Load CSV and return shape/column statistics.
- **split_dataset**: Split into train/test with statistics.
- **train_model**: Train regression model (catboost/xgboost/random_forest/ridge/knn/svr). CatBoost/XGBoost use real early stopping (`early_stopping_rounds=50`) on an inner validation fold carved from the training data, so the test fold stays unseen. When no `target_col` is given the supervised target defaults to `Tc` (the real label), not the trailing `Tc_mean` column. BOTH temperature columns (`Tc`, `Tc_mean`) and the raw `element`/index columns are stripped in code before fitting, so neither can become a feature regardless of which column is the target — i.e. even if a caller mistakenly trains on `Tc_mean`, the label `Tc` is never leaked into the features (and vice-versa).

**Safe default call (verified):** passing the raw bundled CSV with no `target_col` is leak-free because the code (not just the docs) picks `Tc` as the target and strips both temperature columns from the feature set:

```python
import pandas as pd
from ml_tools import train_model, split_dataset

CSV = "input_data/data/DataG_13022.csv"   # columns: index, element, Tc, Tc_mean

# No target_col -> defaults to Tc; element/index and BOTH Tc/Tc_mean are dropped.
info = split_dataset(CSV)
assert info["target_col"] == "Tc"
assert "Tc" not in info["feature_names"] and "Tc_mean" not in info["feature_names"]

# Note: the raw CSV's only numeric non-target column is Tc_mean, which is the
# leakage column and is excluded -> n_features == 0. Build the 322-descriptor
# matrix first (composition_features.build_jabir_feature_matrix), then train on
# that CSV; train_model then defaults to Tc and excludes Tc_mean automatically:
res = train_model("jabir_features_322.csv", "catboost")   # no target_col needed
assert res["target_col"] == "Tc"
```
- **get_predictions**: Get model predictions on test set.
- **compute_metrics**: Compute R2, RMSE, MAE.
- **compute_feature_importance**: SHAP or built-in feature importance ranking, computed on the TRAINING fold only (`X_train`); the final test fold is never used for ranking (leak-free).
- **split_dataset**: defaults the target to `Tc` (not the trailing `Tc_mean`) when no `target_col` is given; the reported `feature_names`/`n_features` exclude BOTH temperature columns (`Tc`, `Tc_mean`) plus `element`/index, so neither label can be mistaken for a feature.
- **forward_feature_selection**: Greedy forward selection scored on an inner validation fold carved from the training data (final test fold held out and unused).
- **predict_new_compounds**: Predict Tc for new compounds given feature vectors.

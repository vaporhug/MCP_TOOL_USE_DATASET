# Tools

This directory follows the three-layer task-tool structure.

- `data_processing.py`: file discovery and generic table helpers.
- `database_retrieval.py`: local inventory and public-link extraction.
- `astro_tools.py`: paper-evidence retrieval primitives for `target.pdf`.

Scoring scope for this task is paper-centric:
- All scored quantitative claims come from `input_data/reference_paper/target.pdf`.
- Files under `input_data/data/` are workflow context only and non-scored.

`astro_tools.py` exposes composable primitives to:
- inventory local context assets,
- fetch per-page paper text,
- search arbitrary user-provided terms,
- extract numeric contexts with optional term filtering,
- retrieve figure-reference contexts,
- assemble a compact evidence packet from caller-provided queries.

The domain tool intentionally avoids embedding fixed answer values or pass/fail scoring logic.

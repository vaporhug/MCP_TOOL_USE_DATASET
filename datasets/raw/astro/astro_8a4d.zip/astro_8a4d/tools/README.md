# Tools

This directory follows the three-layer task-tool structure.

- `data_processing.py`: file discovery and generic table helpers.
- `database_retrieval.py`: local inventory and public-link extraction.
- `astro_tools.py`: paper-centric evidence extraction primitives for `target.pdf`.

Scoring scope for this task is paper-centric:
- All scored quantitative claims come from `input_data/reference_paper/target.pdf`.
- Files under `input_data/data/` are workflow context only and non-scored.

`astro_tools.py` exposes reusable primitives to:
- inventory context files,
- verify headline quantitative strings in the target paper,
- check supporting observational-evidence markers,
- assemble a compact paper-evidence matrix.

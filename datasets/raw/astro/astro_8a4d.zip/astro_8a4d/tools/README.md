# Tools

This directory follows the three-layer task-tool structure.

- `data_processing.py`: file discovery, workbook ingestion, archive inspection, numeric coercion, robust z-scoring, and tidy-table helpers.
- `database_retrieval.py`: local inventory, article-link extraction, and public repository discovery.
- `astro_tools.py`: domain-specific primitives for inspecting bundled astronomy supplementary materials and extracting key quantitative evidence from `target.pdf` plus workflow-context summaries.

The bundled data are supplementary files and public-link/context materials, not a complete external-deposit mirror for full paper-figure reproduction or expensive retraining/reanalysis. The tools expose reusable context and evidence-extraction primitives, with `input_data/reference_paper/target.pdf` as the primary source of quantitative scientific claims.

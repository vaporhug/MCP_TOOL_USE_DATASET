from __future__ import annotations

from pathlib import Path
import re

try:
    import fitz  # PyMuPDF
except Exception:  # pragma: no cover
    fitz = None

try:
    from .data_processing import data_root, list_files
    from .database_retrieval import public_repository_links
except ImportError:
    from data_processing import data_root, list_files
    from database_retrieval import public_repository_links


def source_context_inventory() -> dict:
    """Summarize local context files and repository links."""
    files = list_files(data_root())
    exts = sorted({Path(f).suffix.lower() for f in files})
    return {
        "n_files": int(len(files)),
        "extensions": exts,
        "files": files[:200],
        "repositories": public_repository_links().get("repositories", []),
        "note": "Context inventory only; scored scientific claims come from target.pdf.",
    }


def _target_pdf_path() -> Path:
    p = Path(__file__).resolve().parents[1] / "input_data" / "reference_paper" / "target.pdf"
    if not p.exists():
        raise FileNotFoundError(f"missing {p}")
    return p


def _open_pdf():
    if fitz is None:
        raise RuntimeError("PyMuPDF not available")
    return fitz.open(_target_pdf_path())


def _normalize(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def pdf_page_count() -> dict:
    """Return the number of pages in target.pdf."""
    doc = _open_pdf()
    return {"pdf": str(_target_pdf_path()), "page_count": int(doc.page_count)}


def fetch_page_text(page_numbers: list[int] | None = None, max_chars: int = 4000) -> dict:
    """Fetch raw text from selected pages in target.pdf.

    Args:
        page_numbers: Zero-based page indices. If None, read all pages.
        max_chars: Maximum characters returned per page.

    Returns:
        Dict with per-page extracted text snippets.
    """
    doc = _open_pdf()
    if page_numbers is None:
        page_numbers = list(range(doc.page_count))

    pages = []
    for p in page_numbers:
        if p < 0 or p >= doc.page_count:
            continue
        txt = _normalize(doc[p].get_text("text"))
        pages.append({"page": int(p), "text": txt[:max_chars]})

    return {"pdf": str(_target_pdf_path()), "pages": pages}


def search_text(
    query: str,
    case_sensitive: bool = False,
    whole_word: bool = False,
    use_regex: bool = False,
    max_hits: int = 20,
    context_chars: int = 140,
) -> dict:
    """Search target.pdf text for a query and return contextual snippets."""
    if not query:
        return {"pdf": str(_target_pdf_path()), "query": query, "hits": []}

    doc = _open_pdf()
    q = query if use_regex else re.escape(query)
    if whole_word and not use_regex:
        q = rf"\b{q}\b"
    flags = 0 if case_sensitive else re.IGNORECASE

    hits = []
    for page_idx in range(doc.page_count):
        txt = _normalize(doc[page_idx].get_text("text"))
        for m in re.finditer(q, txt, flags=flags):
            s = max(0, m.start() - context_chars)
            e = min(len(txt), m.end() + context_chars)
            hits.append(
                {
                    "page": int(page_idx),
                    "match": txt[m.start() : m.end()],
                    "snippet": txt[s:e],
                    "start": int(m.start()),
                    "end": int(m.end()),
                }
            )
            if len(hits) >= max_hits:
                return {"pdf": str(_target_pdf_path()), "query": query, "hits": hits}

    return {"pdf": str(_target_pdf_path()), "query": query, "hits": hits}


def search_multiple(queries: list[str], max_hits_per_query: int = 10) -> dict:
    """Run search_text for multiple queries."""
    results = []
    for q in queries:
        results.append(search_text(q, max_hits=max_hits_per_query))
    return {"pdf": str(_target_pdf_path()), "results": results}


def extract_numeric_context(
    number_pattern: str = r"\b\d+(?:\.\d+)?\b",
    required_term: str | None = None,
    max_hits: int = 25,
    context_chars: int = 120,
) -> dict:
    """Extract numeric mentions from target.pdf with nearby context.

    Args:
        number_pattern: Regular expression for numeric-like tokens.
        required_term: Optional term that must co-occur in context.
        max_hits: Maximum number of matches to return.
        context_chars: Context window around each numeric match.

    Returns:
        Dict containing page-indexed numeric-context snippets.
    """
    doc = _open_pdf()
    term_re = re.compile(re.escape(required_term), re.IGNORECASE) if required_term else None

    hits = []
    for page_idx in range(doc.page_count):
        txt = _normalize(doc[page_idx].get_text("text"))
        for m in re.finditer(number_pattern, txt):
            s = max(0, m.start() - context_chars)
            e = min(len(txt), m.end() + context_chars)
            snippet = txt[s:e]
            if term_re and not term_re.search(snippet):
                continue
            hits.append(
                {
                    "page": int(page_idx),
                    "value": m.group(0),
                    "snippet": snippet,
                    "start": int(m.start()),
                    "end": int(m.end()),
                }
            )
            if len(hits) >= max_hits:
                return {
                    "pdf": str(_target_pdf_path()),
                    "number_pattern": number_pattern,
                    "required_term": required_term,
                    "hits": hits,
                }

    return {
        "pdf": str(_target_pdf_path()),
        "number_pattern": number_pattern,
        "required_term": required_term,
        "hits": hits,
    }


def figure_reference_context(figure_label: str, max_hits: int = 10, context_chars: int = 180) -> dict:
    """Locate figure references (for example "1b", "2e") in target.pdf text."""
    label = (figure_label or "").strip()
    if not label:
        return {"pdf": str(_target_pdf_path()), "figure_label": figure_label, "hits": []}

    pattern = rf"Fig\.?\s*{re.escape(label)}"
    return {
        "pdf": str(_target_pdf_path()),
        "figure_label": figure_label,
        "hits": search_text(
            pattern, use_regex=True, max_hits=max_hits, context_chars=context_chars
        ).get("hits", []),
    }


def build_evidence_packet(
    text_queries: list[str] | None = None,
    figure_labels: list[str] | None = None,
    required_term_for_numbers: str | None = None,
    max_hits_per_item: int = 8,
) -> dict:
    """Compose a compact evidence packet from user-provided retrieval targets."""
    text_queries = text_queries or []
    figure_labels = figure_labels or []

    return {
        "pdf": str(_target_pdf_path()),
        "query_results": search_multiple(text_queries, max_hits_per_query=max_hits_per_item).get("results", []),
        "figure_results": [
            figure_reference_context(lbl, max_hits=max_hits_per_item) for lbl in figure_labels
        ],
        "numeric_results": extract_numeric_context(
            required_term=required_term_for_numbers,
            max_hits=max_hits_per_item,
        ).get("hits", []),
    }


def package_smoke_test() -> dict:
    """Minimal runtime check that key primitives execute on the packaged paper."""
    return {
        "source_context_inventory": source_context_inventory(),
        "pdf_page_count": pdf_page_count(),
        "search_text": search_text("Alfv", max_hits=3),
        "extract_numeric_context": extract_numeric_context(required_term="km", max_hits=3),
        "figure_reference_context": figure_reference_context("1", max_hits=3),
    }

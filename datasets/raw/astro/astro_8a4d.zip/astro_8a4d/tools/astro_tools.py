from __future__ import annotations

from pathlib import Path
import re

try:
    import fitz  # PyMuPDF
except Exception:  # pragma: no cover
    fitz = None

try:
    from .data_processing import data_root, list_files
    from .database_retrieval import public_repository_links
except ImportError:
    from data_processing import data_root, list_files
    from database_retrieval import public_repository_links


def source_context_inventory() -> dict:
    files = list_files(data_root())
    exts = sorted({Path(f).suffix.lower() for f in files})
    return {
        "n_files": int(len(files)),
        "extensions": exts,
        "files": files[:200],
        "repositories": public_repository_links().get("repositories", []),
        "note": "Context inventory only; scored scientific claims come from target.pdf.",
    }


def _target_pdf_path() -> Path:
    p = Path(__file__).resolve().parents[1] / "input_data" / "reference_paper" / "target.pdf"
    if not p.exists():
        raise FileNotFoundError(f"missing {p}")
    return p


def _target_pdf_text() -> str:
    if fitz is None:
        raise RuntimeError("PyMuPDF not available")
    doc = fitz.open(_target_pdf_path())
    return "\n".join(page.get_text("text") for page in doc)


def torsional_wave_headline_values() -> dict:
    """Extract paper headline quantities for torsional-Alfven-wave energetics."""
    txt = _target_pdf_text()

    patterns = {
        "vlos_alf_km_s": r"0\.321\s*[\u00b1\+\-]\s*0\.005\s*km\s*s",
        "valf_km_s": r"19\.5\s*km\s*s",
        "combined_flux_w_m2": r"100\s*W\s*m[\u2212\-–]2\s*and\s*400\s*W\s*m[\u2212\-–]2",
    }

    found = {k: bool(re.search(v, txt, flags=re.IGNORECASE)) for k, v in patterns.items()}
    return {
        "pdf": str(_target_pdf_path()),
        "headline_flags": found,
        "note": "Flags indicate whether key quoted headline strings are present in target.pdf text.",
    }


def observational_support_flags() -> dict:
    """Check supporting observational dimensions discussed in the paper text."""
    txt = _target_pdf_text()

    patterns = {
        "phase_pm_pi": r"[\+\-]\s*\u03c0|\u00b1\s*\u03c0",
        "high_coherence": r"coherence",
        "torsional_exceeds_kink": r"torsional.*exceed.*kink|kink.*smaller.*torsional",
        "persistent_small_scale": r"persistent.*small\s*[- ]scale|small\s*[- ]scale.*persistent",
    }
    found = {k: bool(re.search(v, txt, flags=re.IGNORECASE | re.DOTALL)) for k, v in patterns.items()}
    return {
        "pdf": str(_target_pdf_path()),
        "support_flags": found,
        "note": "Flags are paper-text evidence markers for the requested supporting dimensions.",
    }


def paper_evidence_matrix() -> dict:
    head = torsional_wave_headline_values()
    supp = observational_support_flags()
    combined = {}
    combined.update(head.get("headline_flags", {}))
    combined.update(supp.get("support_flags", {}))
    return {
        "pdf": str(_target_pdf_path()),
        "evidence_flags": combined,
        "all_required_flags_present": bool(combined) and all(combined.values()),
    }


def package_smoke_test() -> dict:
    return {
        "source_context_inventory": source_context_inventory(),
        "torsional_wave_headline_values": torsional_wave_headline_values(),
        "observational_support_flags": observational_support_flags(),
        "paper_evidence_matrix": paper_evidence_matrix(),
    }

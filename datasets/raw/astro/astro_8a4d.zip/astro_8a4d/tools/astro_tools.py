from __future__ import annotations
from pathlib import Path
import math
import io
import zipfile
import json
import re
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
try:
    from .data_processing import data_root, list_files, read_table, workbook_sheets, numeric_columns, tidy_numeric_frame, robust_zscore, load_workbook_long
    from .database_retrieval import inventory, public_repository_links
except ImportError:
    from data_processing import data_root, list_files, read_table, workbook_sheets, numeric_columns, tidy_numeric_frame, robust_zscore, load_workbook_long
    from database_retrieval import inventory, public_repository_links

ARTIFACT_DIR = Path(__file__).resolve().parents[1] / "artifacts"
ARTIFACT_DIR.mkdir(exist_ok=True)

def source_inventory(root: str | Path | None = None) -> dict:
    files = list_files(root or data_root())
    sizes = {str(Path(f).relative_to(Path(f).parents[2])) if len(Path(f).parents)>2 else f: Path(f).stat().st_size for f in files[:200]}
    return {"n_files": len(files), "extensions": sorted({Path(f).suffix.lower() for f in files}), "files": files[:200], "sizes": sizes, "repositories": public_repository_links().get("repositories", [])}

def source_workbook_summary(path: str | Path | None = None) -> dict:
    files = list_files(data_root())
    candidates=[f for f in files if Path(f).suffix.lower() in [".xlsx", ".xls"]]
    if path is None and not candidates:
        return {"n_workbooks": 0, "inventory": source_inventory()}
    path = path or candidates[0]
    rows=[]
    for sh in workbook_sheets(path)[:20]:
        try:
            df=read_table(path, sheet_name=sh)
            nums=numeric_columns(df)
            rows.append({"sheet": sh, "rows": int(len(df)), "columns": [str(c) for c in df.columns[:20]], "numeric_columns": [str(c) for c in nums[:20]]})
        except Exception as e:
            rows.append({"sheet": sh, "error": str(e)})
    return {"workbook": str(path), "sheets": rows}

def numeric_signal_summary(path: str | Path | None = None) -> dict:
    if path is None:
        df = pd.DataFrame()
        for candidate in list_files(data_root()):
            if Path(candidate).suffix.lower() not in [".csv", ".tsv", ".txt", ".dat", ".xlsx", ".xls"]:
                continue
            try:
                df = tidy_numeric_frame(candidate)
            except Exception:
                continue
            if not df.empty and numeric_columns(df):
                break
    else:
        df=tidy_numeric_frame(path)
    if df.empty:
        return {"note": "no tabular file found", "inventory": source_inventory()}
    nums=numeric_columns(df)
    stats={}
    for c in nums[:30]:
        s=pd.to_numeric(df[c], errors="coerce").dropna()
        if len(s):
            stats[str(c)]={"n": int(len(s)), "mean": float(s.mean()), "median": float(s.median()), "std": float(s.std(ddof=1)) if len(s)>1 else 0.0, "min": float(s.min()), "max": float(s.max())}
    return {"rows": int(len(df)), "columns": [str(c) for c in df.columns], "numeric_stats": stats}

def compare_numeric_groups(path: str | Path, group_col: str, value_col: str) -> dict:
    df=tidy_numeric_frame(path)
    df[value_col]=pd.to_numeric(df[value_col], errors="coerce")
    g=df.dropna(subset=[value_col]).groupby(group_col)[value_col]
    return {"groups": [{"group": str(k), "n": int(v.count()), "mean": float(v.mean()), "median": float(v.median()), "std": float(v.std(ddof=1)) if v.count()>1 else 0.0} for k,v in g]}

def bootstrap_difference(path: str | Path, group_col: str, value_col: str, group_a: str, group_b: str, n_boot: int = 2000, seed: int = 7) -> dict:
    df=tidy_numeric_frame(path)
    rng=np.random.default_rng(seed)
    a=pd.to_numeric(df.loc[df[group_col].astype(str)==str(group_a), value_col], errors="coerce").dropna().to_numpy()
    b=pd.to_numeric(df.loc[df[group_col].astype(str)==str(group_b), value_col], errors="coerce").dropna().to_numpy()
    if len(a)==0 or len(b)==0:
        return {"error": "empty group"}
    diffs=np.array([rng.choice(a, len(a), replace=True).mean()-rng.choice(b, len(b), replace=True).mean() for _ in range(n_boot)])
    return {"group_a": str(group_a), "group_b": str(group_b), "observed_mean_difference": float(a.mean()-b.mean()), "ci95": [float(np.quantile(diffs, .025)), float(np.quantile(diffs, .975))]}

def permutation_correlation(x, y, n_perm: int = 2000, seed: int = 7) -> dict:
    x=np.asarray(x, dtype=float); y=np.asarray(y, dtype=float)
    ok=np.isfinite(x)&np.isfinite(y); x=x[ok]; y=y[ok]
    if len(x)<3: return {"error":"not enough observations"}
    obs=float(np.corrcoef(x,y)[0,1])
    rng=np.random.default_rng(seed)
    null=np.array([np.corrcoef(x, rng.permutation(y))[0,1] for _ in range(n_perm)])
    p=float((np.sum(np.abs(null)>=abs(obs))+1)/(n_perm+1))
    return {"r": obs, "p_perm": p, "n": int(len(x))}

def plot_numeric_overview(output_filename: str = "numeric_overview.png") -> dict:
    summary=numeric_signal_summary(); stats=summary.get("numeric_stats", {})
    names=list(stats)[:10]; vals=[stats[n]["mean"] for n in names]
    if not names:
        names=["files"]; vals=[source_inventory()["n_files"]]
    out=ARTIFACT_DIR/output_filename
    fig, ax=plt.subplots(figsize=(8,4.8)); ax.bar(range(len(names)), vals, color="#4c78a8")
    ax.set_xticks(range(len(names))); ax.set_xticklabels(names, rotation=35, ha="right", fontsize=8)
    ax.set_ylabel("Mean value / count"); ax.set_title("Local public-data numeric overview")
    fig.tight_layout(); fig.savefig(out,dpi=180); plt.close(fig)
    return {"path": str(out), "plotted": names}

def plot_file_inventory(output_filename: str = "file_inventory.png") -> dict:
    inv=source_inventory(); counts={}
    for f in inv["files"]:
        ext=Path(f).suffix.lower() or "no_ext"; counts[ext]=counts.get(ext,0)+1
    out=ARTIFACT_DIR/output_filename
    fig, ax=plt.subplots(figsize=(6,4)); ax.bar(list(counts), list(counts.values()), color="#f58518")
    ax.set_title("Public workflow file inventory"); ax.set_ylabel("Files")
    fig.tight_layout(); fig.savefig(out,dpi=180); plt.close(fig)
    return {"path": str(out), "counts": counts}

def spectrum_feature_table(path: str | Path | None = None, wavelength_col: str | None = None, value_col: str | None = None) -> pd.DataFrame:
    df=tidy_numeric_frame(path)
    nums=numeric_columns(df)
    if len(nums)<2: return pd.DataFrame()
    wave=wavelength_col or nums[0]; val=value_col or nums[1]
    out=df[[wave,val]].dropna().copy(); out.columns=["wavelength","signal"]
    out["signal_z"]=robust_zscore(out["signal"])
    out["local_gradient"]=np.gradient(out["signal"], out["wavelength"])
    return out

def bandpass_feature_strength(path: str | Path | None = None, center: float = 4.3, half_width: float = 0.15, continuum_width: float = 0.45) -> dict:
    tab=spectrum_feature_table(path)
    if tab.empty: return {"error":"no spectrum-like table"}
    inside=tab[(tab.wavelength>=center-half_width)&(tab.wavelength<=center+half_width)].signal
    cont=tab[((tab.wavelength>=center-continuum_width)&(tab.wavelength<center-half_width))|((tab.wavelength>center+half_width)&(tab.wavelength<=center+continuum_width))].signal
    if inside.empty or cont.empty: return {"error":"band not covered"}
    return {"center":center,"feature_mean":float(inside.mean()),"continuum_mean":float(cont.mean()),"feature_minus_continuum":float(inside.mean()-cont.mean()),"n_feature":int(len(inside)),"n_continuum":int(len(cont))}

def polynomial_continuum_residuals(path: str | Path | None = None, degree: int = 2) -> dict:
    tab=spectrum_feature_table(path)
    if len(tab)<degree+2: return {"error":"insufficient spectrum points"}
    coef=np.polyfit(tab.wavelength, tab.signal, degree); pred=np.polyval(coef, tab.wavelength)
    resid=tab.signal-pred
    return {"degree":degree,"coefficients":[float(c) for c in coef],"rms_residual":float(np.sqrt(np.mean(resid**2))),"max_abs_residual":float(np.max(np.abs(resid)))}

def compare_model_spectra(observed_path: str | Path, model_path: str | Path, obs_wave: str | None = None, obs_value: str | None = None, model_wave: str | None = None, model_value: str | None = None) -> dict:
    obs=spectrum_feature_table(observed_path, obs_wave, obs_value); mod=spectrum_feature_table(model_path, model_wave, model_value)
    if obs.empty or mod.empty: return {"error":"missing spectrum-like data"}
    pred=np.interp(obs.wavelength, mod.wavelength, mod.signal)
    rmse=float(np.sqrt(np.mean((obs.signal-pred)**2)))
    return {"n":int(len(obs)),"rmse":rmse,"mean_observed":float(obs.signal.mean()),"mean_model":float(np.mean(pred))}

def alfven_wave_proxy_summary(manifest_path: str | Path | None = None) -> dict:
    p = Path(manifest_path) if manifest_path else (data_root() / "workflow_manifest.csv")
    if not p.exists():
        return {"error": f"missing {p}"}
    df = pd.read_csv(p)
    if "path" not in df.columns:
        return {"error": "workflow_manifest.csv missing path column"}
    names = df["path"].astype(str).str.lower()
    return {
        "n_assets": int(len(df)),
        "wave_assets": int(names.str.contains("wave|alfven|torsion").sum()),
        "corona_assets": int(names.str.contains("corona|solar|dkist|cryonirsp").sum()),
        "los_projection_assets": int(names.str.contains("line|sight|los|projection").sum()),
    }

def coronal_signal_transport_proxy(summary_path: str | Path | None = None) -> dict:
    p = Path(summary_path) if summary_path else (data_root() / "numeric_file_summary.csv")
    if not p.exists():
        return {"error": f"missing {p}"}
    df = pd.read_csv(p)
    req = {"n_numeric_tokens", "max", "min"}
    if not req.issubset(df.columns):
        return {"error": "numeric_file_summary.csv missing required columns"}
    tok = pd.to_numeric(df["n_numeric_tokens"], errors="coerce").fillna(0)
    mx = pd.to_numeric(df["max"], errors="coerce")
    mn = pd.to_numeric(df["min"], errors="coerce")
    span = (mx - mn).replace([np.inf, -np.inf], np.nan).dropna()
    return {
        "files_with_numeric_content": int((tok > 0).sum()),
        "median_signal_span": float(span.median()) if len(span) else None,
        "p95_signal_span": float(span.quantile(0.95)) if len(span) else None,
    }

def fomo_line_response_catalog() -> dict:
    p = data_root() / "tomveedee_fomo.zip"
    if not p.exists():
        return {"available": False, "reason": f"missing {p}"}
    with zipfile.ZipFile(p) as zf:
        t = zf.read("FoMo-master/chiantitables/list_of_tables.txt").decode("utf-8", errors="ignore")
    lines = [ln.strip() for ln in t.splitlines() if ln.strip() and not ln.startswith("#")]
    elems = {}
    wavelengths = []
    for ln in lines:
        parts = ln.split()
        if len(parts) < 5:
            continue
        elem = parts[0]
        try:
            wl = float(parts[1])
            lo = int(parts[2]); hi = int(parts[3])
        except Exception:
            continue
        elems[elem] = elems.get(elem, 0) + 1
        wavelengths.append(wl)
    return {
        "n_lines_catalogued": int(len(wavelengths)),
        "unique_elements": int(len(elems)),
        "element_counts": elems,
        "wavelength_range_angstrom": [float(min(wavelengths)), float(max(wavelengths))] if wavelengths else None,
    }

def nuwt_procedure_stack() -> dict:
    p = data_root() / "richardjmorton_nuwt.zip"
    if not p.exists():
        return {"available": False, "reason": f"missing {p}"}
    with zipfile.ZipFile(p) as zf:
        names = zf.namelist()
        pro = [n for n in names if n.lower().endswith(".pro")]
        joined = " ".join(n.lower() for n in pro)
    return {
        "n_idl_procedures": int(len(pro)),
        "has_thread_tracking": int("follow_threads.pro" in joined),
        "has_gaussian_fit": int("mygauss.pro" in joined or "mygauss_plus_linear.pro" in joined),
        "has_oscillation_routines": int("nuwt_moscill.pro" in joined or "nuwt_tr.pro" in joined),
        "has_feature_selection_tools": int(any("/feature_selection/" in n.lower() for n in names)),
    }

def cryonirsp_linefit_method_coverage() -> dict:
    p = data_root() / "tschad_cryonirsp_notebooks.zip"
    if not p.exists():
        return {"available": False, "reason": f"missing {p}"}
    with zipfile.ZipFile(p) as zf:
        notebooks = [n for n in zf.namelist() if n.endswith(".ipynb") and "checkpoint" not in n]
        if not notebooks:
            return {"error": "no notebook found in cryonirsp archive"}
        nb = json.loads(zf.read(notebooks[0]).decode("utf-8"))
    code = "\n".join("".join(c.get("source", [])) for c in nb.get("cells", []) if c.get("cell_type") == "code").lower()
    keys = {
        "gaussian_fit_terms": len(re.findall(r"gauss", code)),
        "stokes_terms": len(re.findall(r"stokes", code)),
        "doppler_terms": len(re.findall(r"doppler", code)),
        "line_fit_terms": len(re.findall(r"line\\s*fit", code)),
        "polarimetric_terms": len(re.findall(r"polar", code)),
    }
    return {"notebook": notebooks[0], "code_size_chars": len(code), "method_keyword_counts": keys}

def target_pdf_quantitative_evidence(
    patterns: list[str] | None = None,
    case_sensitive: bool = False,
    max_hits_per_pattern: int = 3,
    context_chars: int = 80,
) -> dict:
    try:
        import fitz  # PyMuPDF
    except Exception as e:
        return {"available": False, "reason": f"pymupdf unavailable: {e}"}
    pdf_path = Path(__file__).resolve().parents[1] / "input_data" / "reference_paper" / "target.pdf"
    if not pdf_path.exists():
        return {"available": False, "reason": f"missing {pdf_path}"}
    doc = fitz.open(pdf_path)
    page_texts = [page.get_text("text") for page in doc]
    flags = 0 if case_sensitive else re.IGNORECASE

    out = {
        "available": True,
        "pdf": str(pdf_path),
        "n_pages": len(doc),
        "total_chars": int(sum(len(t) for t in page_texts)),
    }

    if not patterns:
        out["note"] = "No patterns provided. Supply regex patterns to retrieve page-local evidence snippets."
        return out

    results = {}
    for pattern in patterns:
        hits = []
        regex = re.compile(pattern, flags=flags)
        for page_idx, text in enumerate(page_texts, start=1):
            for m in regex.finditer(text):
                s = max(0, m.start() - context_chars)
                e = min(len(text), m.end() + context_chars)
                snippet = " ".join(text[s:e].split())
                hits.append({"page": page_idx, "match": m.group(0), "context": snippet})
                if len(hits) >= max_hits_per_pattern:
                    break
            if len(hits) >= max_hits_per_pattern:
                break
        results[pattern] = {"matched": bool(hits), "hits": hits}

    out["pattern_matches"] = results
    return out




def _safe_call(fn):
    try:
        return fn()
    except TypeError:
        return {"note": "call requires explicit args"}
    except Exception as e:
        return {"error": str(e)}


def package_smoke_test() -> dict:
    return {
        "workflow_checks": {
            "fomo_line_response_catalog": _safe_call(fomo_line_response_catalog),
            "nuwt_procedure_stack": _safe_call(nuwt_procedure_stack),
            "cryonirsp_linefit_method_coverage": _safe_call(cryonirsp_linefit_method_coverage),
        }
    }

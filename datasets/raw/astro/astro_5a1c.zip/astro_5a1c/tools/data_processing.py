from __future__ import annotations
from pathlib import Path
from io import StringIO
import zipfile
import pandas as pd
import numpy as np

def package_root() -> Path:
    return Path(__file__).resolve().parents[1]

def data_root() -> Path:
    return package_root() / "input_data" / "data"

def list_files(root: str | Path | None = None) -> list[str]:
    root = Path(root) if root else data_root()
    return [str(p) for p in sorted(root.rglob("*")) if p.is_file()]

def archive_inventory(path: str | Path) -> list[str]:
    p = Path(path)
    if p.suffix.lower() != ".zip":
        return []
    with zipfile.ZipFile(p) as zf:
        return sorted(zf.namelist())

def _read_ecsv_lines(lines: list[str]) -> pd.DataFrame:
    names = []
    body = []
    for ln in lines:
        s = ln.strip()
        if s.startswith("# - {name:"):
            names.append(s.split("name:")[1].split(",")[0].strip())
        elif s and not s.startswith("#"):
            body.append(ln)
    if not body:
        return pd.DataFrame(columns=names)
    df = pd.read_csv(StringIO("".join(body)), sep=r"\s+", header=None, engine="python")
    if names and len(names) == df.shape[1]:
        df.columns = names
    return df


def _read_ecsv(p: Path) -> pd.DataFrame:
    """Read an astropy ECSV / commented whitespace-delimited table.

    The Ahrer 2022 Zenodo files (transmission-spectrum reductions and the
    light-curve CSV) are ECSV: a ``# %ECSV 1.0`` header with the column
    names declared in ``# - {name: ...}`` lines, then whitespace-delimited
    numeric rows. pandas' default comma reader would collapse each row into
    a single column, so we parse the ECSV header for names and read the
    body as whitespace-delimited.
    """
    return _read_ecsv_lines(p.read_text(errors="ignore").splitlines(keepends=True))


def _read_zip_member_table(path: str, **kwargs) -> pd.DataFrame:
    archive, member = path.split("!", 1)
    with zipfile.ZipFile(archive) as zf:
        text = zf.read(member).decode("utf-8", errors="ignore")
    stripped = text.lstrip()
    if stripped.startswith("# %ECSV") or stripped.startswith("# wl"):
        return _read_ecsv_lines(text.splitlines(keepends=True))
    try:
        df = pd.read_csv(StringIO(text), on_bad_lines="skip", **kwargs)
    except Exception:
        df = pd.DataFrame()
    n_numeric = 0 if df.empty else sum(
        pd.to_numeric(df[c], errors="coerce").notna().sum() > max(2, 0.1 * len(df))
        for c in df.columns
    )
    if df.shape[1] <= 1 or n_numeric < 2:
        df = pd.read_csv(StringIO(text), comment="#", sep=r"\s+", engine="python")
    return df


def read_table(path: str | Path, **kwargs) -> pd.DataFrame:
    if "!" in str(path):
        return _read_zip_member_table(str(path), **kwargs)
    p = Path(path)
    if p.suffix.lower() in [".xlsx", ".xls"]:
        return pd.read_excel(p, **kwargs)
    if p.suffix.lower() in [".tsv", ".tab"]:
        return pd.read_csv(p, sep="\t", on_bad_lines="skip", **kwargs)
    # Detect ECSV / commented whitespace-delimited files (Ahrer 2022 Zenodo
    # spectra, model fits, and the light-curve CSV all start with '# %ECSV').
    try:
        with open(p) as fh:
            head = fh.read(64)
        if head.lstrip().startswith("# %ECSV") or head.lstrip().startswith("# wl"):
            return _read_ecsv(p)
    except Exception:
        pass
    df = pd.read_csv(p, on_bad_lines="skip", **kwargs)
    n_numeric = sum(
        pd.to_numeric(df[c], errors="coerce").notna().sum() > max(2, 0.1 * len(df))
        for c in df.columns
    )
    if (df.shape[1] <= 1 or n_numeric < 2) and p.suffix.lower() in [".txt", ".csv", ".dat"]:
        df = pd.read_csv(p, comment="#", sep=r"\s+", engine="python")
    return df

def workbook_sheets(path: str | Path) -> list[str]:
    return pd.ExcelFile(path).sheet_names

def load_workbook_long(path: str | Path, max_sheets: int | None = None) -> pd.DataFrame:
    sheets = workbook_sheets(path)
    frames = []
    for sheet in sheets[:max_sheets]:
        try:
            df = pd.read_excel(path, sheet_name=sheet)
            df.insert(0, "source_sheet", sheet)
            frames.append(df)
        except Exception:
            continue
    return pd.concat(frames, ignore_index=True, sort=False) if frames else pd.DataFrame()

def numeric_columns(df: pd.DataFrame) -> list[str]:
    out=[]
    for c in df.columns:
        if pd.to_numeric(df[c], errors="coerce").notna().sum() > max(2, 0.1 * len(df)):
            out.append(c)
    return out

def tidy_numeric_frame(path: str | Path | None = None, sheet_name: str | int | None = 0) -> pd.DataFrame:
    files = list_files(data_root())
    if path is None:
        candidates=[f for f in files if Path(f).suffix.lower() in [".csv", ".tsv", ".txt", ".xlsx", ".xls"]]
        if not candidates:
            return pd.DataFrame()
        path=candidates[0]
    if str(path).lower().endswith((".xlsx", ".xls")):
        df = read_table(path, sheet_name=sheet_name)
    else:
        try:
            df = read_table(path)
        except Exception:
            df = pd.read_csv(path, sep=None, engine="python", on_bad_lines="skip")
    for c in df.columns:
        converted = pd.to_numeric(df[c], errors="coerce")
        if converted.notna().sum() > 0:
            df[c] = converted
    return df

def robust_zscore(values) -> np.ndarray:
    x=np.asarray(values, dtype=float)
    med=np.nanmedian(x); mad=np.nanmedian(np.abs(x-med))
    scale=1.4826*mad if mad and np.isfinite(mad) else np.nanstd(x)
    return (x-med)/(scale if scale else 1.0)

from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import re

try:
    from .data_processing import data_root, list_files, read_table
    from .database_retrieval import public_repository_links
except ImportError:
    from data_processing import data_root, list_files, read_table
    from database_retrieval import public_repository_links


ARTIFACT_DIR = Path(__file__).resolve().parents[1] / "artifacts"
ARTIFACT_DIR.mkdir(exist_ok=True)


def source_inventory() -> dict:
    files = list_files(data_root())
    return {
        "n_files": len(files),
        "extensions": sorted({Path(f).suffix.lower() for f in files}),
        "repositories": public_repository_links().get("repositories", []),
    }


def _workbook() -> Path:
    xlsx = [Path(f) for f in list_files(data_root()) if Path(f).suffix.lower() == ".xlsx"]
    if not xlsx:
        raise FileNotFoundError("missing supplementary abundance workbook")
    return xlsx[0]


def _canon_species(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "", str(name)).upper()


def _load_abundance_table() -> pd.DataFrame:
    wb = _workbook()
    raw = pd.read_excel(wb, sheet_name=0, header=None)

    # Header is on row index 2 in this supplementary table.
    header = raw.iloc[2].tolist()
    df = raw.iloc[4:].copy()
    df.columns = header

    rename = {
        "Wavelength": "wavelength",
        "Species": "species",
        "ep": "ep",
        "log(gf)": "log_gf",
        "EW": "ew",
        "A(X)": "abundance",
    }
    df = df.rename(columns=rename)

    for c in ["wavelength", "ep", "log_gf", "ew", "abundance"]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")

    df["species"] = df["species"].astype(str).str.strip()
    df["species_key"] = df["species"].map(_canon_species)
    return df.dropna(subset=["species", "abundance"]).reset_index(drop=True)


def supplementary_table_manifest() -> dict:
    wb = _workbook()
    xl = pd.ExcelFile(wb)
    shapes = []
    for sh in xl.sheet_names:
        df = pd.read_excel(wb, sheet_name=sh)
        shapes.append({"sheet": sh, "shape": [int(df.shape[0]), int(df.shape[1])]})
    return {"workbook": wb.name, "sheets": shapes}


def species_abundance_profile(top_k: int = 12) -> dict:
    df = _load_abundance_table()
    grp = (
        df.groupby("species", dropna=False)["abundance"]
        .agg(["count", "mean", "std", "min", "max"])
        .sort_values("count", ascending=False)
    )

    return {
        "n_rows": int(len(df)),
        "n_species": int(grp.shape[0]),
        "top_species": [
            {
                "species": str(idx),
                "n_lines": int(r["count"]),
                "mean_abundance": float(r["mean"]),
                "std_abundance": float(r["std"]) if pd.notna(r["std"]) else 0.0,
                "min_abundance": float(r["min"]),
                "max_abundance": float(r["max"]),
            }
            for idx, r in grp.head(top_k).iterrows()
        ],
    }


def line_measurement_quality_summary() -> dict:
    df = _load_abundance_table()
    ew = pd.to_numeric(df["ew"], errors="coerce").dropna().to_numpy(dtype=float)
    return {
        "n_lines_with_ew": int(ew.size),
        "ew_mean": float(np.mean(ew)) if ew.size else None,
        "ew_median": float(np.median(ew)) if ew.size else None,
        "ew_q10_q90": [float(np.quantile(ew, 0.1)), float(np.quantile(ew, 0.9))] if ew.size else [None, None],
    }


def species_excitation_abundance_summary(top_k: int = 10) -> dict:
    df = _load_abundance_table()
    grp = (
        df.groupby("species", dropna=False)
        .agg(
            n_lines=("abundance", "count"),
            mean_ep=("ep", "mean"),
            mean_abundance=("abundance", "mean"),
            std_abundance=("abundance", "std"),
        )
        .sort_values("n_lines", ascending=False)
    )
    return {
        "top_species_profiles": [
            {
                "species": str(i),
                "n_lines": int(r["n_lines"]),
                "mean_ep": float(r["mean_ep"]) if pd.notna(r["mean_ep"]) else None,
                "mean_abundance": float(r["mean_abundance"]) if pd.notna(r["mean_abundance"]) else None,
                "std_abundance": float(r["std_abundance"]) if pd.notna(r["std_abundance"]) else 0.0,
            }
            for i, r in grp.head(top_k).iterrows()
        ]
    }


def line_abundance_trend_summary() -> dict:
    df = _load_abundance_table().dropna(subset=["ep", "abundance"])
    if len(df) < 3:
        return {"error": "insufficient rows for trend summary"}
    x = df["ep"].to_numpy(dtype=float)
    y = df["abundance"].to_numpy(dtype=float)
    slope = float(np.polyfit(x, y, 1)[0])
    corr = float(np.corrcoef(x, y)[0, 1]) if len(x) > 1 else None
    return {
        "n_lines": int(len(df)),
        "ep_abundance_linear_slope": slope,
        "ep_abundance_correlation": corr,
        "ep_range": [float(np.min(x)), float(np.max(x))],
        "abundance_range": [float(np.min(y)), float(np.max(y))],
    }


def plot_species_line_counts(output_filename: str = "astro_6a2d_species_line_counts.png", top_k: int = 10) -> dict:
    df = _load_abundance_table()
    counts = df["species"].value_counts().head(top_k)

    fig, ax = plt.subplots(figsize=(7.2, 4.8))
    ax.bar(counts.index.astype(str), counts.values)
    ax.set_xlabel("Species")
    ax.set_ylabel("Number of measured lines")
    ax.set_title("Supplementary Table 8 species line counts")
    ax.tick_params(axis="x", rotation=45)
    ax.grid(axis="y", alpha=0.25)

    out = ARTIFACT_DIR / output_filename
    fig.tight_layout()
    fig.savefig(out, dpi=220)
    plt.close(fig)
    return {"path": str(out)}


def plot_species_abundance_boxplot(
    output_filename: str = "astro_6a2d_species_abundance_boxplot.png",
    species_subset: tuple[str, ...] | None = None,
    top_k: int = 5,
) -> dict:
    df = _load_abundance_table()
    rep = (
        df.groupby("species_key")["species"]
        .agg(lambda s: s.value_counts().index[0])
        .to_dict()
    )
    counts = df["species_key"].value_counts()
    if species_subset:
        selected_keys = [_canon_species(s) for s in species_subset]
    else:
        selected_keys = counts.head(top_k).index.tolist()

    data = []
    labels = []
    for key in selected_keys:
        vals = pd.to_numeric(df.loc[df["species_key"] == key, "abundance"], errors="coerce").dropna().to_numpy(dtype=float)
        if vals.size == 0:
            continue
        data.append(vals)
        labels.append(rep.get(key, key))

    fig, ax = plt.subplots(figsize=(7.6, 4.8))
    ax.boxplot(data, labels=labels, patch_artist=True)
    ax.set_xlabel("Species")
    ax.set_ylabel("A(X) line abundance")
    ax.set_title("Supplementary Table 8 abundance distribution by species")
    ax.grid(axis="y", alpha=0.25)

    out = ARTIFACT_DIR / output_filename
    fig.tight_layout()
    fig.savefig(out, dpi=220)
    plt.close(fig)
    return {"path": str(out)}


def plot_ew_vs_abundance(output_filename: str = "astro_6a2d_ew_vs_abundance.png") -> dict:
    df = _load_abundance_table().copy()
    df = df.dropna(subset=["ew", "abundance"])
    major_keys = set(df["species_key"].value_counts().head(6).index.tolist())
    df["species_group"] = np.where(df["species_key"].isin(major_keys), df["species"], "Other")

    fig, ax = plt.subplots(figsize=(7.2, 4.8))
    markers = ["o", "s", "^", "D", "v", "P", "X"]
    for i, label in enumerate(sorted(df["species_group"].unique().tolist())):
        sub = df[df["species_group"] == label]
        if sub.empty:
            continue
        ax.scatter(sub["ew"], sub["abundance"], s=18, alpha=0.65, label=label, marker=markers[i % len(markers)])

    ax.set_xlabel("Equivalent width (mÅ)")
    ax.set_ylabel("A(X) abundance")
    ax.set_title("Supplementary Table 8 line measurements")
    ax.grid(alpha=0.25)
    ax.legend(frameon=False)

    out = ARTIFACT_DIR / output_filename
    fig.tight_layout()
    fig.savefig(out, dpi=220)
    plt.close(fig)
    return {"path": str(out)}


def package_smoke_test() -> dict:
    return {
        "source_inventory": source_inventory(),
        "supplementary_table_manifest": supplementary_table_manifest(),
        "species_abundance_profile": species_abundance_profile(),
        "line_measurement_quality_summary": line_measurement_quality_summary(),
        "species_excitation_abundance_summary": species_excitation_abundance_summary(),
        "line_abundance_trend_summary": line_abundance_trend_summary(),
    }

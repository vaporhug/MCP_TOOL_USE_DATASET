#!/usr/bin/env python3

from __future__ import annotations

from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

matplotlib.use("Agg")


def _artifact_path(filename: str) -> Path:
    path = Path(__file__).resolve().parents[1] / "artifacts" / filename
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def load_emission_spectrum(path: str) -> dict:
    df = pd.read_csv(path)
    return {"columns": list(df.columns), "rows": df.head(10).to_dict("records"), "n_rows": int(len(df))}


def emission_feature_summary(path: str) -> dict:
    df = pd.read_csv(path).sort_values("wavelength [um]").reset_index(drop=True)
    peaks = {}
    windows = {"water_1p4um": (1.30, 1.55), "water_1p9um": (1.75, 2.05), "water_2p4um": (2.25, 2.55)}
    continuum = df[(df["wavelength [um]"] < 1.1) | (df["wavelength [um]"] > 2.6)]
    continuum_level = float(continuum["Fp/Fs [ppm]"].median())
    for name, (lo, hi) in windows.items():
        subset = df[(df["wavelength [um]"] >= lo) & (df["wavelength [um]"] <= hi)]
        row = subset.loc[subset["Fp/Fs [ppm]"].idxmax()]
        peaks[name] = {
            "wavelength_um": float(row["wavelength [um]"]),
            "fp_fs_ppm": float(row["Fp/Fs [ppm]"]),
            "contrast_ppm_vs_continuum": float(row["Fp/Fs [ppm]"] - continuum_level),
            "significance_sigma": float((row["Fp/Fs [ppm]"] - continuum_level) / row["Fp/Fs err [ppm]"]),
        }
    hottest = df.loc[df["Thermal Emission [10^6 W/m^2/um]"].idxmax()]
    return {
        "continuum_level_ppm": continuum_level,
        "features": peaks,
        "hottest_bin": {
            "wavelength_um": float(hottest["wavelength [um]"]),
            "thermal_emission": float(hottest["Thermal Emission [10^6 W/m^2/um]"]),
        },
    }


def brightness_temperature_summary(path: str) -> dict:
    df = pd.read_csv(path)
    hottest = df.loc[df["Brightness Temperature [K]"].idxmax()]
    coolest = df.loc[df["Brightness Temperature [K]"].idxmin()]
    return {
        "median_brightness_temperature_K": float(df["Brightness Temperature [K]"].median()),
        "max_brightness_temperature_K": float(hottest["Brightness Temperature [K]"]),
        "max_wavelength_um": float(hottest["wavelength [um]"]),
        "min_brightness_temperature_K": float(coolest["Brightness Temperature [K]"]),
        "min_wavelength_um": float(coolest["wavelength [um]"]),
    }


def chemistry_posterior_summary(path: str) -> dict:
    df = pd.read_csv(path)
    rows = {}
    for prefix in ["Chem. Equi.", "1D-RCTE", "Free Chem."]:
        mh = df[f"{prefix} [M/H] samples"]
        co = df[f"{prefix} C/O samples"]
        ahs = df[f"{prefix} A_HS samples"]
        rows[prefix] = {
            "sample_space_note": "Values are reported in the released posterior table columns as-is; compare model families in the same column space.",
            "mh_median": float(np.median(mh)),
            "mh_p16": float(np.percentile(mh, 16)),
            "mh_p84": float(np.percentile(mh, 84)),
            "co_median": float(np.median(co)),
            "co_p16": float(np.percentile(co, 16)),
            "co_p84": float(np.percentile(co, 84)),
            "co_fraction_below_1": float(np.mean(co < 1.0)),
            "ahs_median": float(np.median(ahs)),
            "ahs_p16": float(np.percentile(ahs, 16)),
            "ahs_p84": float(np.percentile(ahs, 84)),
        }
    return rows


def plot_emission_spectrum(
    spectrum_path: str,
    temperature_path: str,
    output_filename: str = "emission_spectrum.png",
) -> dict:
    spectrum = pd.read_csv(spectrum_path)
    temp = pd.read_csv(temperature_path)
    output = _artifact_path(output_filename)
    fig, ax1 = plt.subplots(figsize=(7.5, 4.5))
    ax1.errorbar(
        spectrum["wavelength [um]"],
        spectrum["Fp/Fs [ppm]"],
        yerr=spectrum["Fp/Fs err [ppm]"],
        fmt="o-",
        ms=3,
        color="#1f77b4",
        label="Fp/Fs",
    )
    ax1.set_xlabel("Wavelength (um)")
    ax1.set_ylabel("Planet-to-star flux ratio (ppm)", color="#1f77b4")
    ax1.tick_params(axis="y", labelcolor="#1f77b4")
    ax2 = ax1.twinx()
    ax2.plot(temp["wavelength [um]"], temp["Brightness Temperature [K]"], color="#d62728", alpha=0.8, label="Brightness T")
    ax2.fill_between(
        temp["wavelength [um]"],
        temp["Brightness Temperature [K]"] - temp["-1 sigma error [K]"],
        temp["Brightness Temperature [K]"] + temp["+1 sigma error [K]"],
        color="#d62728",
        alpha=0.15,
    )
    ax2.set_ylabel("Brightness temperature (K)", color="#d62728")
    ax2.tick_params(axis="y", labelcolor="#d62728")
    fig.suptitle("WASP-18b thermal emission spectrum")
    fig.tight_layout()
    fig.savefig(output, dpi=200)
    plt.close(fig)
    return {"path": str(output), "n_spectral_bins": int(len(spectrum))}


def plot_chemistry_posteriors(path: str, output_filename: str = "chemistry_posteriors.png") -> dict:
    df = pd.read_csv(path)
    output = _artifact_path(output_filename)
    families = ["Chem. Equi.", "1D-RCTE", "Free Chem."]
    params = [("[M/H] samples", "[M/H]"), ("C/O samples", "C/O sample"), ("A_HS samples", "A_HS")]
    fig, axes = plt.subplots(len(families), len(params), figsize=(11, 8.5))
    for i, family in enumerate(families):
        for j, (suffix, label) in enumerate(params):
            col = f"{family} {suffix}"
            ax = axes[i, j]
            ax.hist(pd.to_numeric(df[col], errors="coerce").dropna(), bins=30, color="#4C78A8", alpha=0.85)
            ax.axvline(float(np.nanmedian(df[col])), color="#d62728", lw=1.2)
            ax.set_title(f"{family} {label}", fontsize=9)
            ax.set_ylabel("samples" if j == 0 else "")
    fig.suptitle("Released chemistry posterior samples across model families")
    fig.tight_layout()
    fig.savefig(output, dpi=200)
    plt.close(fig)
    return {"path": str(output), "n_samples": int(len(df)), "model_families": families}
# Strict reproduction additions: brightness-temperature artifact and smoke test.
def plot_brightness_temperature(path: str, output_filename: str = "brightness_temperature.png") -> dict:
    df = pd.read_csv(path)
    output = _artifact_path(output_filename)
    fig, ax = plt.subplots(figsize=(7, 4.4))
    ax.errorbar(df["wavelength [um]"], df["Brightness Temperature [K]"], yerr=[df["-1 sigma error [K]"], df["+1 sigma error [K]"]], fmt="o-", color="#d62728", ms=4)
    ax.set_xlabel("Wavelength (um)")
    ax.set_ylabel("Brightness temperature (K)")
    ax.set_title("WASP-18b brightness-temperature spectrum")
    fig.tight_layout()
    fig.savefig(output, dpi=200)
    plt.close(fig)
    return {"path": str(output), **brightness_temperature_summary(path)}

def package_smoke_test() -> dict:
    root = Path(__file__).resolve().parents[1]
    data = root / "input_data" / "data"
    spec = str(data / "41586_2023_6230_MOESM2_ESM.csv")
    temp = str(data / "41586_2023_6230_MOESM3_ESM.csv")
    chem = str(data / "41586_2023_6230_MOESM4_ESM.csv")
    return {
        "features": emission_feature_summary(spec),
        "temperature": brightness_temperature_summary(temp),
        "chemistry": chemistry_posterior_summary(chem),
        "figures": [plot_emission_spectrum(spec, temp), plot_chemistry_posteriors(chem), plot_brightness_temperature(temp)],
    }

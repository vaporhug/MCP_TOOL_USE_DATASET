This tools folder is organized into three layers.

- `astro_tools.py`: domain primitives for WASP-18b JWST emission spectra, brightness-temperature analysis, chemistry posterior summaries, and artifact generation.
- `data_processing.py`: generic CSV reading and dataframe/file sanity helpers.
- `database_retrieval.py`: local data/reference inventory and lightweight PDF text lookup helpers.

Use the domain tool to compose the dayside-atmosphere reproduction workflow from released JWST tables and posterior samples.

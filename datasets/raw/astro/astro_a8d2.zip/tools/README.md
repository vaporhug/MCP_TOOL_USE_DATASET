Core astronomy workflow tools for `astro_a8d2`.

- `data_processing.py`: generic file listing and text helpers.
- `database_retrieval.py`: local inventory and PDF-text helpers.
- `astro_tools.py`: fixed-width table parsing, cross-table companion accounting, Table 2/Table 4 coordinate consistency checks, Table 2 to Table 3 separation/position-angle and differential proper-motion/CPM recomputation, companion-population summaries using the paper's hydrogen-burning boundary, and figure reproduction for the released Gaia companion-table workflow.

from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

try:
    from .data_processing import read_ecsv_like
except ImportError:
    from data_processing import read_ecsv_like


ARTIFACT_DIR = Path(__file__).resolve().parents[1] / 'artifacts'
ARTIFACT_DIR.mkdir(parents=True, exist_ok=True)


def _savefig(name: str) -> str:
    return str(ARTIFACT_DIR / name)


def _find_col(df: pd.DataFrame, contains: list[str]) -> str:
    cols = list(df.columns)
    low = {c.lower(): c for c in cols}
    for need in contains:
        for lc, orig in low.items():
            if need.lower() in lc:
                return orig
    raise KeyError(f'Cannot find column containing any of {contains}; columns={cols}')


def _white_curve_arrays(path: str) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    df = read_ecsv_like(path)
    t_col = _find_col(df, ['time'])
    f_col = _find_col(df, ['measured relative flux', 'measured'])
    m_col = _find_col(df, ['model relative flux', 'model'])
    t = pd.to_numeric(df[t_col], errors='coerce').to_numpy()
    f = pd.to_numeric(df[f_col], errors='coerce').to_numpy()
    m = pd.to_numeric(df[m_col], errors='coerce').to_numpy()
    mask = np.isfinite(t) & np.isfinite(f) & np.isfinite(m)
    return t[mask], f[mask], m[mask]


def _spectrum_arrays(path: str) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    df = read_ecsv_like(path)
    w_col = _find_col(df, ['wavelength'])
    d_col = _find_col(df, ['transit depth'])
    e_col = _find_col(df, ['uncertainty'])
    w = pd.to_numeric(df[w_col], errors='coerce').to_numpy()
    d = pd.to_numeric(df[d_col], errors='coerce').to_numpy()
    e = pd.to_numeric(df[e_col], errors='coerce').to_numpy()
    return w, d, e


def _model_arrays(path: Path) -> tuple[np.ndarray, np.ndarray]:
    df = read_ecsv_like(path)
    w_col = _find_col(df, ['wavelength'])
    d_col = _find_col(df, ['transit depth'])
    w = pd.to_numeric(df[w_col], errors='coerce').to_numpy()
    d = pd.to_numeric(df[d_col], errors='coerce').to_numpy()
    mask = np.isfinite(w) & np.isfinite(d)
    return w[mask], d[mask]


def load_white_light_curves(path1: str, path2: str) -> dict:
    t1, f1, m1 = _white_curve_arrays(path1)
    t2, f2, m2 = _white_curve_arrays(path2)
    return {
        'curve_1': {'n_rows': int(len(t1)), 't_min': float(np.min(t1)), 't_max': float(np.max(t1))},
        'curve_2': {'n_rows': int(len(t2)), 't_min': float(np.min(t2)), 't_max': float(np.max(t2))},
    }


def summarize_white_light_curves(path1: str, path2: str) -> dict:
    _, f1, m1 = _white_curve_arrays(path1)
    _, f2, m2 = _white_curve_arrays(path2)

    def _depth(flux: np.ndarray, model: np.ndarray) -> tuple[float, float]:
        return float(1 - np.nanmin(flux)), float(np.nanmedian(model))

    d1, b1 = _depth(f1, m1)
    d2, b2 = _depth(f2, m2)
    return {
        'curve_1_depth_proxy': d1,
        'curve_2_depth_proxy': d2,
        'curve_1_model_baseline': b1,
        'curve_2_model_baseline': b2,
    }


def load_transmission_spectrum(path: str) -> dict:
    w, d, e = _spectrum_arrays(path)
    valid = np.isfinite(w) & np.isfinite(d) & np.isfinite(e)
    return {
        'n_rows': int(valid.sum()),
        'wavelength_min': float(np.nanmin(w[valid])),
        'wavelength_max': float(np.nanmax(w[valid])),
        'depth_std_ppm': float(np.nanstd(d[valid]) * 1e6),
    }


def compare_model_grid(spectrum_path: str, model_dir: str) -> dict:
    obs_w, obs_d, obs_e = _spectrum_arrays(spectrum_path)

    finite_mask = np.isfinite(obs_w) & np.isfinite(obs_d) & np.isfinite(obs_e)
    positive_err_mask = obs_e > 0
    mask = finite_mask & positive_err_mask

    n_total = int(len(obs_w))
    n_valid = int(mask.sum())
    n_dropped = n_total - n_valid
    if n_valid == 0:
        raise ValueError('No valid observed spectrum points after finite/positive-uncertainty filtering')

    obs_w = obs_w[mask]
    obs_d = obs_d[mask]
    obs_e = obs_e[mask]

    model_files = sorted(Path(model_dir).glob('*_model_ecsv.txt'))
    if not model_files:
        raise FileNotFoundError(f'No *_model_ecsv.txt files found in {model_dir}')

    rankings = []
    for model_path in model_files:
        mod_w, mod_d = _model_arrays(model_path)
        if len(mod_w) == 0:
            continue
        interp = np.interp(obs_w, mod_w, mod_d)
        resid = obs_d - interp
        chi2 = float(np.nansum((resid / obs_e) ** 2))
        rankings.append(
            {
                'model': model_path.name,
                'chi2': chi2,
                'rms_ppm': float(np.sqrt(np.nanmean(resid ** 2)) * 1e6),
                'n_points': int(len(obs_w)),
            }
        )

    if not rankings:
        raise ValueError('No valid model comparison rows were produced')

    rankings.sort(key=lambda x: x['chi2'])
    return {
        'rankings': rankings,
        'best_model': rankings[0]['model'],
        'model_files': [p.name for p in model_files],
        'n_models': int(len(model_files)),
        'n_observed_points': n_total,
        'n_used_points': n_valid,
        'n_dropped_points': n_dropped,
    }


def summarize_spectrum_constraints(spectrum_path: str, model_dir: str) -> dict:
    cmp = compare_model_grid(spectrum_path, model_dir)
    rankings = cmp['rankings']
    best = rankings[0]
    cls = classify_atmosphere_constraints(spectrum_path, model_dir)
    return {
        'best_model': best['model'],
        'best_chi2': best['chi2'],
        'best_rms_ppm': best['rms_ppm'],
        'top_three_models': [row['model'] for row in rankings[:3]],
        'n_models': cmp['n_models'],
        'n_used_points': cmp['n_used_points'],
        'n_dropped_points': cmp['n_dropped_points'],
        'model_rankings': cls['model_rankings'],
        'family_rankings': cls['family_rankings'],
    }


def list_model_grid_files(model_dir: str) -> dict:
    files = sorted(Path(model_dir).glob('*_model_ecsv.txt'))
    if not files:
        raise FileNotFoundError(f'No *_model_ecsv.txt files found in {model_dir}')
    return {
        'model_dir': str(model_dir),
        'n_models': int(len(files)),
        'files': [p.name for p in files],
    }


def _family_label(model_name: str) -> str:
    name = model_name.lower()
    if 'ch4' in name:
        return 'methane_dominated'
    if any(k in name for k in ['1xsolar', '10xsolar', '100xsolar', '1000xsolar']):
        return 'hydrogen_rich_metallicity_grid'
    if 'hazy' in name or 'cloudy' in name:
        return 'cloudy_or_hazy'
    if 'clear' in name:
        return 'clear_volatile'
    if 'co2' in name or 'earthlike' in name or 'marslike' in name:
        return 'co2_or_terrestrial_like'
    return 'other'


def classify_atmosphere_constraints(
    spectrum_path: str,
    model_dir: str,
) -> dict:
    cmp = compare_model_grid(spectrum_path, model_dir)
    rankings = cmp['rankings']
    best_chi2 = rankings[0]['chi2']

    model_rankings = []
    for row in rankings:
        rel = row['chi2'] / best_chi2 if best_chi2 > 0 else float('inf')
        model_rankings.append(
            {
            'model': row['model'],
            'chi2': row['chi2'],
            'relative_chi2': rel,
            'family': _family_label(row['model']),
            }
        )

    family_rank: dict[str, dict] = {}
    for item in model_rankings:
        fam = item['family']
        row = family_rank.setdefault(fam, {'n_models': 0, 'best_relative_chi2': float('inf'), 'mean_relative_chi2': 0.0})
        row['n_models'] += 1
        row['best_relative_chi2'] = min(row['best_relative_chi2'], float(item['relative_chi2']))
        row['mean_relative_chi2'] += float(item['relative_chi2'])

    family_rankings = [
        {
            'family': fam,
            'n_models': int(vals['n_models']),
            'best_relative_chi2': float(vals['best_relative_chi2']),
            'mean_relative_chi2': float(vals['mean_relative_chi2'] / max(vals['n_models'], 1)),
        }
        for fam, vals in sorted(family_rank.items(), key=lambda kv: kv[1]['best_relative_chi2'])
    ]

    return {
        'best_model': rankings[0]['model'],
        'best_chi2': best_chi2,
        'model_rankings': model_rankings,
        'family_rankings': family_rankings,
    }


def plot_white_light_curves(path1: str, path2: str, output_filename: str = 'lhs475b_white_light.png') -> dict:
    t1, f1, m1 = _white_curve_arrays(path1)
    t2, f2, m2 = _white_curve_arrays(path2)
    out = Path(_savefig(output_filename))

    fig, axes = plt.subplots(2, 1, figsize=(8, 5.5), sharex=False)
    for ax, t, f, m, title in [(axes[0], t1, f1, m1, 'Transit 1'), (axes[1], t2, f2, m2, 'Transit 2')]:
        ax.plot(t, f, '.', ms=2.0, alpha=0.7, color='#1F77B4', label='Measured')
        ax.plot(t, m, '-', lw=1.3, color='#D62728', label='Model')
        ax.set_title(title)
        ax.set_ylabel('Relative flux')
        ax.legend(frameon=False, fontsize=8)
    axes[1].set_xlabel('Time (hours)')
    fig.suptitle('LHS 475 b white-light transit fits')
    fig.tight_layout()
    fig.savefig(out, dpi=200)
    plt.close(fig)
    return {'path': str(out), 'n_rows': int(len(t1) + len(t2))}


def plot_transmission_models(spectrum_path: str, model_dir: str, output_filename: str = 'lhs475b_transmission_models.png') -> dict:
    obs_w, obs_d, obs_e = _spectrum_arrays(spectrum_path)
    valid = np.isfinite(obs_w) & np.isfinite(obs_d) & np.isfinite(obs_e) & (obs_e > 0)
    obs_w = obs_w[valid]
    obs_d = obs_d[valid]
    obs_e = obs_e[valid]

    model_files = sorted(Path(model_dir).glob('*_model_ecsv.txt'))
    if not model_files:
        raise FileNotFoundError(f'No *_model_ecsv.txt files found in {model_dir}')

    out = Path(_savefig(output_filename))
    fig, ax = plt.subplots(figsize=(8, 5.2))
    ax.errorbar(obs_w, obs_d, yerr=obs_e, fmt='o', ms=3.0, color='black', label='Observed spectrum')

    for model_path in model_files:
        mod_w, mod_d = _model_arrays(model_path)
        label = model_path.stem.replace('lhs_475b_', '').replace('_model_ecsv', '')
        ax.plot(mod_w, mod_d, lw=1.0, alpha=0.8, label=label)

    ax.set_xlabel('Wavelength (microns)')
    ax.set_ylabel('Transit depth (Rp/Rs)^2')
    ax.set_title('LHS 475 b transmission spectrum vs released model grid')
    ax.legend(frameon=False, fontsize=6.8, ncol=2)
    fig.tight_layout()
    fig.savefig(out, dpi=200)
    plt.close(fig)
    return {'path': str(out), 'n_rows': int(len(obs_w))}


def package_smoke_test(data_root: str | Path) -> dict:
    root = Path(data_root)
    p1 = root / 'LHS47b_Zenodo_Files' / '1_Light_Curves' / 'whitelight_transit1_ecsv.txt'
    p2 = root / 'LHS47b_Zenodo_Files' / '1_Light_Curves' / 'whitelight_transit2_ecsv.txt'
    sp = root / 'LHS47b_Zenodo_Files' / '2_Transmission_Spectra' / 'transit_spectrum_HR_eureka_ecsv.txt'
    md = root / 'LHS47b_Zenodo_Files' / '3_Models'

    wl = summarize_white_light_curves(str(p1), str(p2))
    models = list_model_grid_files(str(md))
    cmp = summarize_spectrum_constraints(str(sp), str(md))
    cls = classify_atmosphere_constraints(str(sp), str(md))
    fig1 = plot_white_light_curves(str(p1), str(p2))
    fig2 = plot_transmission_models(str(sp), str(md))

    return {
        'white_light': wl,
        'model_files': models,
        'model_compare': cmp,
        'model_classification': cls,
        'plots': [fig1['path'], fig2['path']],
    }

from __future__ import annotations
from pathlib import Path
import re
from data_processing import data_root, reference_root, list_files, archive_inventory, read_text


def locate(pattern: str, root: str | Path | None = None) -> list[str]:
    root = Path(root) if root else data_root()
    return [str(p) for p in sorted(root.rglob(pattern))]


def inventory(root: str | Path | None = None) -> dict:
    files = list_files(root)
    archives = {f: archive_inventory(f)[:50] for f in files if Path(f).suffix.lower() == ".zip"}
    return {"n_files": len(files), "files": files[:200], "archives": archives}


def reference_paper() -> dict:
    pdfs = sorted(reference_root().glob("*.pdf"))
    return {"n_pdfs": len(pdfs), "target_pdf": str(pdfs[0]) if pdfs else None, "pdfs": [str(p) for p in pdfs]}


def paper_figures() -> dict:
    fig_dir = data_root() / "paper_figures"
    figs = sorted(fig_dir.glob("*.png"))
    return {"n_figures": len(figs), "figures": [str(p) for p in figs]}


def extract_article_links(article_html: str | Path | None = None, pattern: str | None = None) -> list[str]:
    html_path = Path(article_html) if article_html else data_root() / "article_page.html"
    text = read_text(html_path) if html_path.exists() else ""
    links = sorted(set(re.findall(r'https?://[^"\s<>]+', text)))
    if pattern:
        links = [u for u in links if re.search(pattern, u, re.I)]
    return links


def public_repository_links() -> dict:
    links = extract_article_links(pattern=r'(zenodo|mast|github|dryad|osf|figshare|dataverse)')
    return {"repositories": links}

from __future__ import annotations
from pathlib import Path
import re

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image

from data_processing import data_root, html_to_text, image_size, read_image
from database_retrieval import inventory, paper_figures, public_repository_links, reference_paper

ARTIFACT_DIR = Path(__file__).resolve().parents[1] / "artifacts"
ARTIFACT_DIR.mkdir(exist_ok=True)


def article_text(article_html: str | Path | None = None) -> dict:
    """Return cleaned local article text for evidence-string searches."""
    path = Path(article_html) if article_html else data_root() / "article_page.html"
    text = html_to_text(path)
    return {"path": str(path), "n_characters": len(text), "text": text}


def evidence_snippets(phrases: list[str], window: int = 220,
                      article_html: str | Path | None = None) -> dict:
    """Find paper-text snippets containing requested phrases or regexes."""
    text = article_text(article_html)["text"]
    out = []
    for phrase in phrases:
        m = re.search(phrase, text, flags=re.I)
        if not m:
            out.append({"phrase": phrase, "found": False})
            continue
        start = max(0, m.start() - window)
        end = min(len(text), m.end() + window)
        out.append({"phrase": phrase, "found": True, "snippet": text[start:end]})
    return {"n_phrases": len(phrases), "results": out}


def benchmark_claims(article_html: str | Path | None = None,
                     queries: list[str] | None = None) -> dict:
    """Search the local article for user-selected benchmark claim evidence.

    The default queries are intentionally claim categories, not final numeric
    answers. A solver can pass exact paper phrases when it wants stricter
    source tracing.
    """
    queries = queries or [
        r"wavelength.*(μm|micron)",
        r"NIRSpec PRISM.*saturation|saturation.*NIRSpec PRISM",
        r"solar metallicity",
        r"C/O",
        r"uniform offset|median value",
        r"Na, K|H\s*2\s*O|CO\s*2|SO\s*2",
    ]
    checks = evidence_snippets(queries, article_html=article_html)
    supported = [r for r in checks["results"] if r.get("found")]
    return {
        "n_queries": len(queries),
        "n_supported": len(supported),
        "evidence": checks["results"],
    }


def figure_inventory() -> dict:
    """Return included paper figure images and dimensions."""
    figs = paper_figures()["figures"]
    return {"figures": [image_size(p) for p in figs], "paper": reference_paper()}


def color_mask_statistics(figure_path: str | Path,
                          rgb: tuple[int, int, int],
                          tolerance: int = 45) -> dict:
    """Count pixels close to a target RGB colour, useful for locating model
    curves or grey saturation regions in the supplied paper figures."""
    arr = read_image(figure_path)[..., :3].astype(int)
    target = np.array(rgb, dtype=int)
    dist = np.sqrt(((arr - target) ** 2).sum(axis=2))
    mask = dist <= tolerance
    ys, xs = np.where(mask)
    out = {
        "figure_path": str(figure_path),
        "target_rgb": list(rgb),
        "tolerance": tolerance,
        "n_pixels": int(mask.sum()),
        "fraction": float(mask.mean()),
    }
    if len(xs):
        out.update({"bbox_xyxy": [int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max())]})
    return out


def nonwhite_content_bbox(figure_path: str | Path, whiteness: int = 245) -> dict:
    """Bounding box of non-white figure content for checking panel coverage."""
    arr = read_image(figure_path)[..., :3]
    mask = np.any(arr < whiteness, axis=2)
    ys, xs = np.where(mask)
    if not len(xs):
        return {"figure_path": str(figure_path), "error": "no non-white content"}
    return {
        "figure_path": str(figure_path),
        "bbox_xyxy": [int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max())],
        "content_fraction": float(mask.mean()),
    }


def plot_transmission_figure_evidence(
    annotation: str,
    output_filename: str = "annotated_transmission_figure.png",
) -> dict:
    """Annotate the paper Fig. 2 image with caller-supplied evidence notes."""
    fig_path = data_root() / "paper_figures" / "Fig2_transmission_spectra.png"
    im = Image.open(fig_path).convert("RGBA")
    out = ARTIFACT_DIR / output_filename
    if not annotation:
        raise ValueError("annotation must be supplied by the solver")
    label = annotation
    fig, ax = plt.subplots(figsize=(8.4, 9.6))
    ax.imshow(im)
    ax.set_axis_off()
    ax.text(0.03, 0.04, label,
            transform=ax.transAxes, color="black", fontsize=10.5,
            bbox=dict(facecolor="white", alpha=0.82, edgecolor="black"))
    fig.tight_layout(pad=0)
    fig.savefig(out, dpi=160)
    plt.close(fig)
    return {"path": str(out), "source_figure": str(fig_path), "content_bbox": nonwhite_content_bbox(fig_path)}


def plot_model_comparison_evidence(
    annotation: str,
    output_filename: str = "annotated_model_comparison_figure.png",
) -> dict:
    """Annotate the paper Fig. 3 model-comparison image and quantify the purple
    model curve's visible pixels as an image-level check."""
    fig_path = data_root() / "paper_figures" / "Fig3_model_comparison.png"
    im = Image.open(fig_path).convert("RGBA")
    purple = color_mask_statistics(fig_path, (112, 66, 155), tolerance=65)
    out = ARTIFACT_DIR / output_filename
    if not annotation:
        raise ValueError("annotation must be supplied by the solver")
    label = annotation
    fig, ax = plt.subplots(figsize=(8.4, 10.0))
    ax.imshow(im)
    ax.set_axis_off()
    ax.text(0.03, 0.04, label,
            transform=ax.transAxes, color="black", fontsize=10.5,
            bbox=dict(facecolor="white", alpha=0.82, edgecolor="black"))
    fig.tight_layout(pad=0)
    fig.savefig(out, dpi=160)
    plt.close(fig)
    return {"path": str(out), "source_figure": str(fig_path), "purple_model_pixels": purple}


def plot_claim_trace(claims: list[str],
                     output_filename: str = "paper_claim_trace.png",
                     article_html: str | Path | None = None) -> dict:
    """Render paper-source snippets for solver-supplied claim strings."""
    if not claims:
        raise ValueError("claims must be supplied by the solver")
    out = ARTIFACT_DIR / output_filename
    fig, ax = plt.subplots(figsize=(9.2, 6.2))
    ax.axis("off")
    evidence = evidence_snippets(claims, article_html=article_html)
    lines = ["Paper-source evidence snippets"]
    for result in evidence["results"]:
        phrase = result["phrase"]
        snippet = result.get("snippet")
        if snippet:
            snippet = re.sub(r"\s+", " ", snippet).strip()
            if len(snippet) > 180:
                snippet = snippet[:177] + "..."
            lines.append(f"{phrase}: {snippet}")
        else:
            lines.append(f"{phrase}: no matching local article snippet")
    ax.text(0.03, 0.95, "\n\n".join(lines), va="top", fontsize=9.5,
            bbox=dict(facecolor="#f6f4ef", edgecolor="#333333", boxstyle="round,pad=0.6"))
    ax.set_title("Traceable snippets from the WASP-39 b benchmark source", loc="left")
    fig.tight_layout()
    fig.savefig(out, dpi=170)
    plt.close(fig)
    return {"path": str(out), "claims": evidence}


def package_smoke_test() -> dict:
    """Exercise local data/text/figure connectivity without writing artifacts."""
    return {
        "inventory": inventory(),
        "repositories": public_repository_links(),
        "figures": figure_inventory(),
        "claims": benchmark_claims(),
    }

from __future__ import annotations
from pathlib import Path
import html
import re
import zipfile

import numpy as np
import pandas as pd
from PIL import Image


def package_root() -> Path:
    return Path(__file__).resolve().parents[1]


def data_root() -> Path:
    return package_root() / "input_data" / "data"


def reference_root() -> Path:
    return package_root() / "input_data" / "reference_paper"


def list_files(root: str | Path | None = None) -> list[str]:
    root = Path(root) if root else data_root()
    return [str(p) for p in sorted(root.rglob("*")) if p.is_file()]


def archive_inventory(path: str | Path) -> list[str]:
    p = Path(path)
    if p.suffix.lower() != ".zip":
        return []
    with zipfile.ZipFile(p) as zf:
        return sorted(zf.namelist())


def read_text(path: str | Path) -> str:
    return Path(path).read_text(errors="ignore")


def html_to_text(path: str | Path) -> str:
    text = read_text(path)
    text = re.sub(r"<script\b.*?</script>", " ", text, flags=re.I | re.S)
    text = re.sub(r"<style\b.*?</style>", " ", text, flags=re.I | re.S)
    text = re.sub(r"<[^>]+>", " ", text)
    text = html.unescape(text)
    return re.sub(r"\s+", " ", text).strip()


def read_image(path: str | Path) -> np.ndarray:
    return np.asarray(Image.open(path).convert("RGBA"))


def image_size(path: str | Path) -> dict:
    im = Image.open(path)
    return {"path": str(path), "width": int(im.width), "height": int(im.height), "mode": im.mode}


def read_table(path: str | Path, **kwargs) -> pd.DataFrame:
    p = Path(path)
    if p.suffix.lower() in [".xlsx", ".xls"]:
        return pd.read_excel(p, **kwargs)
    if p.suffix.lower() in [".tsv", ".tab"]:
        return pd.read_csv(p, sep="\t", on_bad_lines="skip", **kwargs)
    return pd.read_csv(p, on_bad_lines="skip", **kwargs)

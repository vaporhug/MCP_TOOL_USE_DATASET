# astro_5a1b Tool Reference

This task uses the local Nature article page, `target.pdf`, and the public
paper Figure 2/Figure 3 images. The Zenodo archive linked by the paper is a
1.7 GB external record and is not bundled; these tools therefore support a
paper-figure reproduction workflow rather than a file-inventory summary.

## Data Processing (`data_processing.py`)

- `package_root`, `data_root`, `reference_root` locate bundle folders.
- `list_files`, `archive_inventory` inspect released local inputs.
- `read_text`, `html_to_text` load and clean the local article HTML.
- `read_image`, `image_size` load paper figure PNGs as RGBA arrays.
- `read_table` remains available for any small tabular source added later.

## Database Retrieval (`database_retrieval.py`)

- `reference_paper` verifies that the task has exactly the local target PDF.
- `paper_figures` lists the bundled public Figure 2/Figure 3 PNG inputs.
- `extract_article_links` and `public_repository_links` recover paper data links.
- `inventory` and `locate` provide local source discovery without making final
  scientific claims.

## Domain Tools (`astro_tools.py`)

Composable paper-workflow primitives:

- `article_text` returns cleaned article text for evidence searches.
- `evidence_snippets` finds source-paper snippets for requested scientific terms.
- `benchmark_claims` searches the local article text for caller-selected claim
  categories and returns source snippets without hard-coding final answer values.
- `figure_inventory` reports included figure dimensions and reference-paper state.
- `color_mask_statistics` quantifies visible colour layers such as the purple
  model curve in Figure 3.
- `nonwhite_content_bbox` checks figure-panel content coverage.
- `plot_transmission_figure_evidence(annotation, output_filename)` annotates Fig. 2 using solver-supplied text.
- `plot_model_comparison_evidence(annotation, output_filename)` annotates Fig. 3 using solver-supplied text.
- `plot_claim_trace(claims, output_filename)` renders snippets for solver-supplied claim strings.
- `package_smoke_test` checks data/text/figure connectivity only; it does not generate final scored artifacts.

## Expected Composition

A solving agent should combine text evidence (`benchmark_claims`) with figure
inspection (`figure_inventory`, `color_mask_statistics`) and then generate the
three artifacts. No tool directly writes the final report or hides a final answer.

from __future__ import annotations

from pathlib import Path
import re

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "input_data" / "data"
ARTIFACT_DIR = ROOT / "artifacts"
SPECTRA_DIR = DATA / "zenodo_subset" / "4_TRANSMISSION_SPECTRA" / "Fixed_LimbDarkening"
MODEL_PATH = DATA / "zenodo_subset" / "5_MODEL_SPECTRUM" / "BestFitModel.txt"


def released_spectrum_files() -> list[dict]:
    rows = []
    for path in sorted(SPECTRA_DIR.rglob("*.csv")):
        if path.name.startswith("._"):
            continue
        rows.append({"instrument": path.parent.name, "file": str(path.relative_to(DATA)), "bytes": path.stat().st_size})
    return rows


def load_transmission_spectrum(path: str | Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    if "wave" not in df or "rp/rs" not in df:
        raise ValueError(f"{path} is missing wave and rp/rs columns")
    out = df.copy()
    out["wave"] = pd.to_numeric(out["wave"], errors="coerce")
    out["transit_depth"] = pd.to_numeric(out["rp/rs"], errors="coerce") ** 2
    err_cols = [c for c in ["rp/rs_err_low", "rp/rs_err_hih"] if c in out]
    if err_cols:
        err = out[err_cols].apply(pd.to_numeric, errors="coerce").mean(axis=1)
        out["transit_depth_err"] = 2 * pd.to_numeric(out["rp/rs"], errors="coerce") * err
    else:
        out["transit_depth_err"] = np.nan
    if "satflag" in out:
        out["satflag"] = pd.to_numeric(out["satflag"], errors="coerce").fillna(0).astype(int)
    else:
        out["satflag"] = 0
    return out.dropna(subset=["wave", "transit_depth"]).reset_index(drop=True)


def combined_transmission_spectrum() -> pd.DataFrame:
    frames = []
    for row in released_spectrum_files():
        path = DATA / row["file"]
        df = load_transmission_spectrum(path)
        df["instrument"] = row["instrument"]
        frames.append(df[["instrument", "wave", "transit_depth", "transit_depth_err", "satflag"]])
    if not frames:
        raise FileNotFoundError("No released transmission spectra found in zenodo_subset")
    return pd.concat(frames, ignore_index=True).sort_values(["wave", "instrument"]).reset_index(drop=True)


def load_best_fit_model(path: str | Path = MODEL_PATH) -> pd.DataFrame:
    df = pd.read_csv(path, comment="#", sep=r"\s+", names=["wave", "transit_depth"])
    return df.dropna().sort_values("wave").reset_index(drop=True)


def spectrum_checkpoint_summary(exclude_saturated: bool = False) -> dict:
    spec = combined_transmission_spectrum()
    saturated_points = int(spec["satflag"].fillna(0).astype(int).sum())
    if exclude_saturated:
        spec = spec[spec["satflag"].fillna(0).astype(int) == 0].copy()
    model = load_best_fit_model()
    interp = np.interp(spec["wave"], model["wave"], model["transit_depth"])
    residual = spec["transit_depth"].to_numpy() - interp
    by_inst = spec.groupby("instrument").agg(
        points=("wave", "size"), wave_min=("wave", "min"), wave_max=("wave", "max"), median_depth=("transit_depth", "median"), saturated_bins=("satflag", "sum")
    ).reset_index()
    return {
        "n_points": int(len(spec)),
        "wavelength_min_micron": float(spec["wave"].min()),
        "wavelength_max_micron": float(spec["wave"].max()),
        "model_points": int(len(model)),
        "excluded_saturated_points": saturated_points if exclude_saturated else 0,
        "residual_rms_depth": float(np.sqrt(np.nanmean(residual ** 2))),
        "instruments": by_inst.to_dict(orient="records"),
    }



def plot_transmission_spectrum(output_path: str | Path) -> dict:
    spec = combined_transmission_spectrum()
    out = Path(output_path); out.parent.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(9, 4.8))
    saturated_total = 0
    for inst, sub in spec.groupby("instrument"):
        yerr = sub["transit_depth_err"].replace(0, np.nan)
        unsat = sub[sub["satflag"].fillna(0).astype(int) == 0]
        sat = sub[sub["satflag"].fillna(0).astype(int) > 0]
        if not unsat.empty:
            ax.errorbar(unsat["wave"], unsat["transit_depth"] * 100, yerr=yerr.loc[unsat.index] * 100, fmt=".", ms=4, alpha=0.8, label=inst)
        if not sat.empty:
            saturated_total += int(len(sat))
            ax.errorbar(sat["wave"], sat["transit_depth"] * 100, yerr=yerr.loc[sat.index] * 100, fmt="o", mfc="none", mec="#d62728", ecolor="#d62728", ms=5, alpha=0.85, label=f"{inst} saturated")
    ax.set_xlabel("Wavelength (micron)")
    ax.set_ylabel("Transit depth (%)")
    ax.set_title("WASP-39 b released JWST transmission spectrum")
    if saturated_total:
        ax.text(0.01, 0.02, f"saturated PRISM bins marked: {saturated_total}", transform=ax.transAxes, fontsize=8, ha="left", va="bottom")
    ax.legend(frameon=False, fontsize=7, ncol=2)
    fig.tight_layout(); fig.savefig(out, dpi=200); plt.close(fig)
    return {"path": str(out), "marked_saturated_points": saturated_total, **spectrum_checkpoint_summary()}

def plot_model_comparison(output_path: str | Path, exclude_saturated: bool = True) -> dict:
    spec = combined_transmission_spectrum()
    excluded_saturated = int(spec["satflag"].fillna(0).astype(int).sum()) if exclude_saturated else 0
    if exclude_saturated:
        spec = spec[spec["satflag"].fillna(0).astype(int) == 0].copy()
    model = load_best_fit_model()
    out = Path(output_path); out.parent.mkdir(parents=True, exist_ok=True)
    fig, (ax, rx) = plt.subplots(2, 1, figsize=(9, 6), sharex=True, height_ratios=[2.2, 1])
    wmin, wmax = float(spec["wave"].min()), float(spec["wave"].max())
    model_view = model[(model["wave"] >= wmin) & (model["wave"] <= wmax)]
    ax.plot(model_view["wave"], model_view["transit_depth"] * 100, color="black", lw=1.4, label="1D-RCPE model")
    for inst, sub in spec.groupby("instrument"):
        pred = np.interp(sub["wave"], model["wave"], model["transit_depth"])
        ax.scatter(sub["wave"], sub["transit_depth"] * 100, s=10, label=inst, alpha=0.75)
        rx.scatter(sub["wave"], (sub["transit_depth"] - pred) * 1e6, s=10, alpha=0.75)
    ax.set_ylabel("Transit depth (%)")
    ax.set_title("WASP-39 b spectrum against best-fit model")
    ax.legend(frameon=False, fontsize=7, ncol=3)
    rx.axhline(0, color="black", lw=0.8)
    rx.set_ylabel("Residual (ppm)")
    rx.set_xlabel("Wavelength (micron)")
    ax.set_xlim(wmin, wmax)
    if excluded_saturated:
        ax.text(0.01, 0.02, f"excluded saturated PRISM bins: {excluded_saturated}", transform=ax.transAxes, fontsize=8, ha="left", va="bottom")
    fig.tight_layout(); fig.savefig(out, dpi=200); plt.close(fig)
    return {"path": str(out), **spectrum_checkpoint_summary(exclude_saturated=exclude_saturated)}



def plot_instrument_offsets(output_path: str | Path) -> dict:
    spec = combined_transmission_spectrum()
    prism = spec[(spec["instrument"] == "NIRSpec_PRISM") & (spec["satflag"].fillna(0).astype(int) == 0)].copy()
    if prism.empty:
        raise ValueError("Need non-saturated NIRSpec_PRISM points to compute mode offsets")
    rows = []
    fig_rows = []
    for inst, sub in spec.groupby("instrument"):
        if inst == "NIRSpec_PRISM":
            continue
        sub = sub[sub["satflag"].fillna(0).astype(int) == 0].copy()
        lo = max(float(sub["wave"].min()), float(prism["wave"].min()))
        hi = min(float(sub["wave"].max()), float(prism["wave"].max()))
        overlap = sub[(sub["wave"] >= lo) & (sub["wave"] <= hi)].copy()
        if overlap.empty:
            continue
        ref = np.interp(overlap["wave"], prism["wave"], prism["transit_depth"])
        residual_ppm = (overlap["transit_depth"].to_numpy() - ref) * 1e6
        rows.append({"instrument": inst, "overlap_points": int(len(overlap)), "wave_min": lo, "wave_max": hi, "median_offset_ppm": float(np.nanmedian(residual_ppm)), "mean_offset_ppm": float(np.nanmean(residual_ppm))})
        for wave, res in zip(overlap["wave"], residual_ppm):
            fig_rows.append({"instrument": inst, "wave": float(wave), "residual_ppm": float(res)})
    if not rows:
        raise ValueError("No overlapping instrument ranges with non-saturated PRISM reference")
    df = pd.DataFrame(rows).sort_values("wave_min")
    points = pd.DataFrame(fig_rows)
    out = Path(output_path); out.parent.mkdir(parents=True, exist_ok=True)
    fig, (ax, bx) = plt.subplots(2, 1, figsize=(8.4, 6.2), sharex=False, height_ratios=[1.1, 1.6])
    ax.bar(df["instrument"], df["median_offset_ppm"], color="#4c78a8")
    ax.axhline(0, color="black", lw=0.8)
    ax.set_ylabel("Median offset vs PRISM (ppm)")
    ax.set_title("Mode offsets from overlap with non-saturated PRISM interpolation")
    ax.tick_params(axis="x", rotation=20)
    for inst, sub in points.groupby("instrument"):
        bx.scatter(sub["wave"], sub["residual_ppm"], s=12, alpha=0.75, label=inst)
    bx.axhline(0, color="black", lw=0.8)
    bx.set_xlabel("Wavelength (micron)")
    bx.set_ylabel("Residual vs PRISM (ppm)")
    bx.legend(frameon=False, fontsize=7, ncol=2)
    fig.tight_layout(); fig.savefig(out, dpi=200); plt.close(fig)
    return {"path": str(out), "offsets": rows, "prism_saturated_bins_excluded": int(spec.loc[spec["instrument"] == "NIRSpec_PRISM", "satflag"].fillna(0).astype(int).sum())}

def package_smoke_test() -> dict:
    return {"files": released_spectrum_files(), "summary": spectrum_checkpoint_summary()}

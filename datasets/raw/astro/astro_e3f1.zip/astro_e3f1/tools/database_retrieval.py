from __future__ import annotations

from pathlib import Path
import subprocess

try:
    from .data_processing import list_files
except ImportError:
    from data_processing import list_files


def local_data_inventory(data_root: str) -> dict:
    return {
        "root": str(Path(data_root).resolve()),
        "files": list_files(data_root),
    }


def reference_inventory(reference_root: str) -> dict:
    return {
        "root": str(Path(reference_root).resolve()),
        "files": list_files(reference_root, suffixes={".pdf", ".html"}),
    }


def extract_pdf_text(path: str) -> dict:
    try:
        from pypdf import PdfReader

        reader = PdfReader(path)
        text = "\n".join(page.extract_text() or "" for page in reader.pages)
        return {"path": path, "backend": "pypdf", "text": text}
    except Exception as pypdf_error:
        result = subprocess.run(
            ["pdftotext", path, "-"],
            capture_output=True,
            text=True,
            check=False,
        )
        if result.returncode == 0:
            return {"path": path, "backend": "pdftotext", "text": result.stdout}
        return {
            "path": path,
            "backend": "unavailable",
            "text": "",
            "error": f"pypdf failed: {pypdf_error}; pdftotext failed: {result.stderr.strip()}",
        }


def find_pdf_lines(path: str, patterns: list[str]) -> dict:
    text = extract_pdf_text(path)["text"]
    matches = []
    for lineno, line in enumerate(text.splitlines(), start=1):
        lower = line.lower()
        for pattern in patterns:
            if pattern.lower() in lower:
                matches.append({"line_number": lineno, "pattern": pattern, "line": line.strip()})
                break
    return {"path": path, "patterns": patterns, "matches": matches}

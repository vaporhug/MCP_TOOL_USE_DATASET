#!/usr/bin/env python3

from __future__ import annotations

from pathlib import Path
import re
import sys

import matplotlib
import numpy as np
import pandas as pd

try:
    from mcp.server.fastmcp import FastMCP
except ImportError:
    class FastMCP:
        def __init__(self, *_args, **_kwargs):
            pass

        def tool(self):
            def decorator(func):
                return func

            return decorator

try:
    from .data_processing import dataframe_overview, read_csv
    from .database_retrieval import (
        extract_pdf_text as _extract_pdf_text,
        find_pdf_lines as _find_pdf_lines,
        local_data_inventory as _local_data_inventory,
        reference_inventory as _reference_inventory,
    )
except ImportError:
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from data_processing import dataframe_overview, read_csv
    from database_retrieval import (
        extract_pdf_text as _extract_pdf_text,
        find_pdf_lines as _find_pdf_lines,
        local_data_inventory as _local_data_inventory,
        reference_inventory as _reference_inventory,
    )

matplotlib.use("Agg")
import matplotlib.pyplot as plt

mcp = FastMCP("SuperMassiveNeptuneTools")


def _artifact_path(filename: str) -> Path:
    path = Path(__file__).resolve().parents[1] / "artifacts" / filename
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def _default_target_pdf() -> Path:
    return Path(__file__).resolve().parents[1] / "input_data" / "reference_paper" / "target.pdf"


def _paper_text(path: str | None = None) -> str:
    source = str(Path(path).resolve()) if path else str(_default_target_pdf())
    return _extract_pdf_text(source)["text"]


def _first_float(pattern: str, text: str, label: str) -> float:
    match = re.search(pattern, text, flags=re.IGNORECASE | re.DOTALL)
    if not match:
        raise ValueError(f"Could not parse {label} from target paper text")
    return float(match.group(1).replace(",", ""))


def _target_values_from_paper(path: str | None = None) -> dict[str, float]:
    text = _paper_text(path)
    abstract_window_match = re.search(r"TOI-1853\s*b.{0,900}?heavy elements dominate its mass", text, flags=re.IGNORECASE | re.DOTALL)
    text_window = abstract_window_match.group(0) if abstract_window_match else text
    return {
        "radius_earth": _first_float(r"radius of\s*([0-9.]+)\s*(?:±|\\+/-)", text_window, "radius"),
        "orbital_period_days": _first_float(r"every\s*([0-9.]+)\s*days", text_window, "orbital period"),
        "mass_earth": _first_float(r"mass of\s*([0-9.]+)\s*(?:±|\\+/-)", text_window, "mass"),
        "density_cgs": _first_float(r"density of\s*([0-9.]+)\s*(?:±|\\+/-)", text_window, "density"),
    }


def _source_columns() -> dict[str, tuple[str, str, str, str, str, str, str, str]]:
    return {
        "ULMT": ("phase_ULMT", "y_ULMT", "yerr_ULMT", "binphase_ULMT", "biny_ULMT", "binyerr_ULMT", "modelphase_ULMT", "ymodel_ULMT"),
        "LCO": ("phase_LCO", "y_LCO", "yerr_LCO", "binphase_LCO", "biny_LCO", "binyerr_LCO", "modelphase_LCO", "ymodel_LCO"),
        "MuSCAT-g": ("phase_gMus", "y_gMus", "yerr_gMus", "binphase_gMus", "biny_gMus", "binyerr_gMus", "modelphase_gMus", "ymodel_gMus"),
        "MuSCAT-r": ("phase_rMus", "y_rMus", "yerr_rMus", "binphase_rMus", "biny_rMus", "binyerr_rMus", "modelphase_rMus", "ymodel_rMus"),
        "MuSCAT-i": ("phase_iMus", "y_iMus", "yerr_iMus", "binphase_iMus", "biny_iMus", "binyerr_iMus", "modelphase_iMus", "ymodel_iMus"),
        "MuSCAT-z": ("phase_zMus", "y_zMus", "yerr_zMus", "binphase_zMus", "biny_zMus", "binyerr_zMus", "modelphase_zMus", "ymodel_zMus"),
    }


@mcp.tool()
def local_data_inventory(data_root: str) -> dict:
    return _local_data_inventory(data_root)


@mcp.tool()
def reference_inventory(reference_root: str) -> dict:
    return _reference_inventory(reference_root)


@mcp.tool()
def extract_pdf_text(path: str) -> dict:
    return _extract_pdf_text(path)


@mcp.tool()
def find_pdf_lines(path: str, patterns: list[str]) -> dict:
    return _find_pdf_lines(path, patterns)


@mcp.tool()
def target_parameter_source(target_pdf_path: str | None = None) -> dict:
    target_values = _target_values_from_paper(target_pdf_path)
    return {
        "source": "target.pdf abstract",
        "note": "The comparison CSV is an unlabeled background sample; the TOI-1853 b mass, radius, density, and period are paper-reported target values.",
        "target_values": target_values,
        "paper_quote_anchor": "Abstract sentence beginning 'Here we show observations of the transiting planet TOI-1853 b...'",
    }


@mcp.tool()
def load_planet_context_table(path: str) -> dict:
    df = read_csv(path)
    return dataframe_overview(df)


@mcp.tool()
def context_summary(
    path: str,
    target_pdf_path: str | None = None,
    radius_min: float = 2.5,
    radius_max: float = 4.5,
) -> dict:
    df = read_csv(path)
    target_values = _target_values_from_paper(target_pdf_path)
    mask = (df["radius_earth"] >= radius_min) & (df["radius_earth"] <= radius_max)
    subset = df.loc[mask].copy()
    heavier = subset.loc[subset["mass_earth"] > target_values["mass_earth"]]
    denser = subset.loc[subset["density_cgs"] > target_values["density_cgs"]]
    second = subset.sort_values("mass_earth", ascending=False).iloc[0]
    return {
        "n_neptune_sized_planets": int(len(subset)),
        "n_sample_planets_more_massive_than_target": int(len(heavier)),
        "n_sample_planets_denser_than_target": int(len(denser)),
        "target_mass_vs_sample_max_ratio": float(target_values["mass_earth"] / second["mass_earth"]),
        "target_density_cgs": float(target_values["density_cgs"]),
        "median_density_cgs_in_radius_range": float(subset["density_cgs"].median()),
        "radius_range_earth": [float(radius_min), float(radius_max)],
        "target_values": target_values,
    }


@mcp.tool()
def neptunian_desert_outlier_summary(
    path: str,
    target_pdf_path: str | None = None,
    radius_min: float = 2.5,
    radius_max: float = 4.5,
    preview_rows: int = 10,
) -> dict:
    df = read_csv(path)
    target_values = _target_values_from_paper(target_pdf_path)
    mask = (df["radius_earth"] >= radius_min) & (df["radius_earth"] <= radius_max)
    subset = df.loc[mask].copy()
    hottest = subset.sort_values(["temp", "mass_earth"], ascending=[False, False]).head(20)
    return {
        "target_radius_earth": target_values["radius_earth"],
        "target_mass_earth": target_values["mass_earth"],
        "target_density_cgs": target_values["density_cgs"],
        "target_orbital_period_days": target_values["orbital_period_days"],
        "radius_range_earth": [float(radius_min), float(radius_max)],
        "hot_neptune_context_preview": hottest[
            ["mass_earth", "radius_earth", "temp", "density_cgs", "p_orb"]
        ].head(preview_rows).to_dict("records"),
    }


@mcp.tool()
def multiband_depth_summary(path: str) -> dict:
    df = read_csv(path)
    rows = []
    for label, (_phase_col, _raw_flux_col, _raw_err_col, bin_phase_col, flux_col, err_col, _model_phase_col, _model_flux_col) in _source_columns().items():
        phase = pd.to_numeric(df[bin_phase_col], errors="coerce")
        flux = pd.to_numeric(df[flux_col], errors="coerce")
        err = pd.to_numeric(df[err_col], errors="coerce")
        frame = pd.DataFrame({"phase": phase, "flux": flux, "err": err}).dropna()
        frame = frame.loc[frame["flux"] > 0].copy()
        baseline = float(np.nanpercentile(frame["flux"], 95))
        minimum = float(frame["flux"].min())
        depth = baseline - minimum
        rows.append(
            {
                "dataset": label,
                "n_bins": int(len(frame)),
                "baseline": baseline,
                "minimum_flux": minimum,
                "depth": float(depth),
            }
        )
    return {"rows": rows}


@mcp.tool()
def plot_multiband_phase_curves(path: str, output_filename: str = "multiband_phase_curves.png") -> dict:
    df = read_csv(path)
    fig, axes = plt.subplots(3, 2, figsize=(10, 9), sharex=True, sharey=True)
    for ax, (label, (raw_phase_col, raw_flux_col, raw_err_col, bin_phase_col, flux_col, err_col, model_phase_col, model_flux_col)) in zip(axes.ravel(), _source_columns().items()):
        raw = pd.DataFrame(
            {
                "phase": pd.to_numeric(df[raw_phase_col], errors="coerce"),
                "flux": pd.to_numeric(df[raw_flux_col], errors="coerce"),
                "err": pd.to_numeric(df[raw_err_col], errors="coerce"),
            }
        ).dropna()
        raw = raw.loc[raw["flux"] > 0].copy()
        frame = pd.DataFrame(
            {
                "phase": pd.to_numeric(df[bin_phase_col], errors="coerce"),
                "flux": pd.to_numeric(df[flux_col], errors="coerce"),
                "err": pd.to_numeric(df[err_col], errors="coerce"),
            }
        ).dropna()
        frame = frame.loc[frame["flux"] > 0].copy()
        model = pd.DataFrame(
            {
                "phase": pd.to_numeric(df[model_phase_col], errors="coerce"),
                "flux": pd.to_numeric(df[model_flux_col], errors="coerce"),
            }
        ).dropna()
        model = model.loc[model["flux"] > 0].sort_values("phase")
        if not raw.empty:
            ax.scatter(raw["phase"], raw["flux"], s=4, color="0.75", alpha=0.35, label="raw source points")
        ax.errorbar(frame["phase"], frame["flux"], yerr=frame["err"], fmt="o", ms=3, alpha=0.85, label="binned data")
        if not model.empty:
            ax.plot(model["phase"], model["flux"], color="#d62728", lw=1.4, label="released model")
        ax.set_title(label)
        ax.set_xlabel("Orbital phase")
        ax.set_ylabel("Normalized flux")
        ax.legend(fontsize=7, frameon=False)
    fig.tight_layout()
    output_path = _artifact_path(output_filename)
    fig.savefig(output_path, dpi=200)
    plt.close(fig)
    return {"path": str(output_path), "datasets": list(_source_columns())}


@mcp.tool()
def plot_mass_radius_context(
    path: str,
    output_filename: str = "mass_radius_context.png",
    target_pdf_path: str | None = None,
    radius_min: float = 2.0,
    radius_max: float = 5.0,
) -> dict:
    df = read_csv(path)
    target_values = _target_values_from_paper(target_pdf_path)
    output_path = _artifact_path(output_filename)
    mask = (df["radius_earth"] >= radius_min) & (df["radius_earth"] <= radius_max)
    subset = df.loc[mask].copy()
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.scatter(
        subset["radius_earth"],
        subset["mass_earth"],
        c=subset["temp"],
        cmap="viridis",
        s=28,
        alpha=0.7,
    )
    ax.scatter([target_values["radius_earth"]], [target_values["mass_earth"]], color="#d62728", s=90, label="TOI-1853 b")
    ax.set_xlabel("Radius (Earth radii)")
    ax.set_ylabel("Mass (Earth masses)")
    ax.set_title("Neptune-sized planets in mass-radius space")
    ax.legend()
    fig.tight_layout()
    fig.savefig(output_path, dpi=200)
    plt.close(fig)
    return {
        "path": str(output_path),
        "target_mass_earth": target_values["mass_earth"],
        "target_radius_earth": target_values["radius_earth"],
        "target_source": "target.pdf abstract",
        "radius_range_earth": [float(radius_min), float(radius_max)],
    }


@mcp.tool()
def density_period_outlier_summary(
    path: str,
    target_pdf_path: str | None = None,
    radius_min: float = 2.5,
    radius_max: float = 4.5,
    short_period_days: float = 3.0,
    dense_cutoff_cgs: float = 5.0,
) -> dict:
    df = pd.read_csv(path)
    target_values = _target_values_from_paper(target_pdf_path)
    subset = df[(df["radius_earth"].between(radius_min, radius_max)) & df["mass_earth"].notna() & df["p_orb"].notna()].copy()
    target_density = target_values["density_cgs"]
    return {
        "neptune_sized_rows": int(len(subset)),
        "target_density_percentile": float((subset["density_cgs"] < target_density).mean()),
        "short_period_dense_comparators": int(((subset["p_orb"] < short_period_days) & (subset["density_cgs"] > dense_cutoff_cgs)).sum()),
        "radius_range_earth": [float(radius_min), float(radius_max)],
        "short_period_days": float(short_period_days),
        "dense_cutoff_cgs": float(dense_cutoff_cgs),
        "target_values": target_values,
    }

@mcp.tool()
def plot_density_period_context(
    path: str,
    output_filename: str = "density_period_context.png",
    target_pdf_path: str | None = None,
    radius_min: float = 2.0,
    radius_max: float = 5.0,
    short_period_days: float = 3.0,
    dense_cutoff_cgs: float = 5.0,
) -> dict:
    df = pd.read_csv(path)
    target_values = _target_values_from_paper(target_pdf_path)
    subset = df[(df["radius_earth"].between(radius_min, radius_max)) & df["p_orb"].notna()].copy()
    output = _artifact_path(output_filename)
    fig, ax = plt.subplots(figsize=(7, 4.6))
    sc = ax.scatter(subset["p_orb"], subset["density_cgs"], c=subset["radius_earth"], cmap="magma", s=28, alpha=0.75)
    ax.scatter([target_values["orbital_period_days"]], [target_values["density_cgs"]], color="cyan", edgecolor="black", s=100, label="TOI-1853 b")
    ax.set_xscale("log")
    ax.set_xlabel("Orbital period (days)")
    ax.set_ylabel("Bulk density (g cm^-3)")
    ax.set_title("Dense short-period Neptune-sized planet context")
    ax.legend(frameon=False)
    cbar = fig.colorbar(sc, ax=ax)
    cbar.set_label("Radius (Earth radii)")
    fig.tight_layout()
    fig.savefig(output, dpi=200)
    plt.close(fig)
    return {
        "path": str(output),
        **density_period_outlier_summary(
            path,
            target_pdf_path=target_pdf_path,
            radius_min=max(radius_min, 2.5),
            radius_max=min(radius_max, 4.5),
            short_period_days=short_period_days,
            dense_cutoff_cgs=dense_cutoff_cgs,
        ),
    }

from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
DATA_ROOT = PACKAGE_ROOT / "input_data" / "data"
ARTIFACT_DIR = PACKAGE_ROOT / "artifacts"
SPECTRA_BOOK = DATA_ROOT / "41586_2023_6687_MOESM2_ESM.xlsx"
MODEL_BOOK = DATA_ROOT / "41586_2023_6687_MOESM3_ESM.xlsx"
ABUNDANCE_BOOK = DATA_ROOT / "41586_2023_6687_MOESM4_ESM.xlsx"


def workbook_inventory(path: str | Path) -> dict:
    xls = pd.ExcelFile(path)
    return {'path': str(path), 'sheets': xls.sheet_names}


def load_transmission_data(path: str | Path = SPECTRA_BOOK, source: str = 'eureka') -> pd.DataFrame:
    df = pd.read_excel(path, sheet_name='Transmission_Data')
    source = source.lower()
    if source == 'eureka':
        cols = ['# wavelength (microns)', 'eureka transit depth (%)', 'eureka transit depth uncertainty (%)']
    else:
        cols = ['# wavelength (microns)', 'tshirt transit depth + 0.00016124790270780065 (%)', 'tshirt transit depth uncertainty (%)']
    out = df[cols].copy(); out.columns = ['wavelength', 'depth_percent', 'unc_percent']
    return out.dropna().reset_index(drop=True)


def load_emission_data(path: str | Path = SPECTRA_BOOK, source: str = 'eureka') -> pd.DataFrame:
    df = pd.read_excel(path, sheet_name='Emission_Data')
    source = source.lower()
    if source == 'eureka':
        cols = ['# wavelength (microns)', 'eureka eclipse depth (ppm)', 'eureka eclipse depth uncertainty (ppm)']
    else:
        cols = ['# wavelength (microns)', 'tshirt eclipse depth (ppm)', 'tshirt eclipse depth uncertainty (ppm)']
    out = df[cols].copy(); out.columns = ['wavelength', 'depth_ppm', 'unc_ppm']
    return out.dropna().reset_index(drop=True)


def load_model_grid(kind: str = 'transmission', path: str | Path = MODEL_BOOK) -> pd.DataFrame:
    sheet = 'Transmission_Models' if kind.lower().startswith('trans') else 'Emission_Models'
    df = pd.read_excel(path, sheet_name=sheet)
    return df.dropna(how='all').reset_index(drop=True)


def load_methane_cross_section(path: str | Path = SPECTRA_BOOK) -> pd.DataFrame:
    df = pd.read_excel(path, sheet_name='Methane_CrossSection')
    df.columns = ['wavelength', 'methane_cross_section']
    return df.dropna().reset_index(drop=True)


def methane_model_contrast(model_df: pd.DataFrame, kind: str = 'transmission', center_min: float = 3.0, center_max: float = 3.6) -> dict:
    wave_col = '# wavelength (microns)'
    required = [wave_col, 'full model lower contour', 'full model upper contour',
                'no CH4 model lower contour', 'no CH4 model upper contour']
    missing = [col for col in required if col not in model_df.columns]
    if missing:
        raise KeyError(f'missing model columns: {missing}')
    full_mid = (model_df['full model lower contour'] + model_df['full model upper contour']) / 2
    no_mid = (model_df['no CH4 model lower contour'] + model_df['no CH4 model upper contour']) / 2
    band = (model_df[wave_col] >= center_min) & (model_df[wave_col] <= center_max)
    diff = full_mid - no_mid
    scale = 10000.0 if kind.lower().startswith('trans') else 1_000_000.0
    unit = 'ppm transit depth' if kind.lower().startswith('trans') else 'ppm eclipse depth'
    return {'kind': kind, 'band': [center_min, center_max], 'mean_full_minus_no_ch4': float(diff[band].mean() * scale), 'max_abs_full_minus_no_ch4': float(diff[band].abs().max() * scale), 'unit': unit, 'n_band': int(band.sum())}


def model_fit_delta_chi2(data_df: pd.DataFrame, model_df: pd.DataFrame, kind: str = 'transmission') -> dict:
    """Compare full and no-CH4 models after interpolation onto observed wavelengths."""
    wave_col = '# wavelength (microns)'
    required = [wave_col, 'full model lower contour', 'full model upper contour',
                'no CH4 model lower contour', 'no CH4 model upper contour']
    missing = [col for col in required if col not in model_df.columns]
    if missing:
        raise KeyError(f'missing model columns: {missing}')
    wave = model_df[wave_col].to_numpy(float)
    full_mid = ((model_df['full model lower contour'] + model_df['full model upper contour']) / 2).to_numpy(float)
    no_mid = ((model_df['no CH4 model lower contour'] + model_df['no CH4 model upper contour']) / 2).to_numpy(float)
    if kind.lower().startswith('trans'):
        obs = data_df['depth_percent'].to_numpy(float)
        unc = data_df['unc_percent'].to_numpy(float)
        scale = 1.0
        unit = 'percent transit depth'
    else:
        obs = data_df['depth_ppm'].to_numpy(float)
        unc = data_df['unc_ppm'].to_numpy(float)
        scale = 1_000_000.0
        unit = 'ppm eclipse depth'
    obs_wave = data_df['wavelength'].to_numpy(float)
    full_interp = np.interp(obs_wave, wave, full_mid * scale)
    no_interp = np.interp(obs_wave, wave, no_mid * scale)
    finite = np.isfinite(obs) & np.isfinite(unc) & (unc > 0) & np.isfinite(full_interp) & np.isfinite(no_interp)
    chi2_full = float(np.sum(((obs[finite] - full_interp[finite]) / unc[finite]) ** 2))
    chi2_no = float(np.sum(((obs[finite] - no_interp[finite]) / unc[finite]) ** 2))
    return {
        'kind': kind,
        'unit': unit,
        'n_points': int(finite.sum()),
        'chi2_full': chi2_full,
        'chi2_no_ch4': chi2_no,
        'delta_chi2_no_ch4_minus_full': chi2_no - chi2_full,
        'full_model_preferred': bool(chi2_full < chi2_no),
    }


def abundance_histogram(species_sheet: str = 'CH4_Free', path: str | Path = ABUNDANCE_BOOK) -> pd.DataFrame:
    df = pd.read_excel(path, sheet_name=species_sheet)
    return df.dropna(how='all').reset_index(drop=True)


def plot_transmission_with_models(data: pd.DataFrame, model_df: pd.DataFrame, output_path: str) -> dict:
    wave = model_df['# wavelength (microns)']
    full = (model_df['full model lower contour'] + model_df['full model upper contour']) / 2
    no_ch4 = (model_df['no CH4 model lower contour'] + model_df['no CH4 model upper contour']) / 2
    fig, ax = plt.subplots(figsize=(8, 4.8))
    ax.errorbar(data['wavelength'], data['depth_percent'], yerr=data['unc_percent'], fmt='o', ms=3, label='transmission data')
    ax.plot(wave, full, label='full model')
    ax.plot(wave, no_ch4, ls='--', label='no CH4 model')
    ax.axvspan(3.0, 3.6, color='orange', alpha=0.18, label='CH4 band')
    ax.set_xlabel('Wavelength (micron)'); ax.set_ylabel('Transit depth (%)'); ax.legend(fontsize=8)
    fig.tight_layout(); Path(output_path).parent.mkdir(parents=True, exist_ok=True); fig.savefig(output_path, dpi=200); plt.close(fig)
    return {'path': output_path}


def plot_emission_with_models(data: pd.DataFrame, model_df: pd.DataFrame, output_path: str) -> dict:
    wave = model_df['# wavelength (microns)']
    full = ((model_df['full model lower contour'] + model_df['full model upper contour']) / 2) * 1_000_000.0
    no_ch4 = ((model_df['no CH4 model lower contour'] + model_df['no CH4 model upper contour']) / 2) * 1_000_000.0
    fig, ax = plt.subplots(figsize=(8, 4.8))
    ax.errorbar(data['wavelength'], data['depth_ppm'], yerr=data['unc_ppm'], fmt='o', ms=3, label='emission data')
    ax.plot(wave, full, label='full model')
    ax.plot(wave, no_ch4, ls='--', label='no CH4 model')
    ax.axvspan(3.0, 3.6, color='orange', alpha=0.18, label='CH4 band')
    ax.set_xlabel('Wavelength (micron)'); ax.set_ylabel('Eclipse depth (ppm)'); ax.legend(fontsize=8)
    fig.tight_layout(); Path(output_path).parent.mkdir(parents=True, exist_ok=True); fig.savefig(output_path, dpi=200); plt.close(fig)
    return {'path': output_path}


def plot_ch4_abundance(hist_df: pd.DataFrame, output_path: str) -> dict:
    fig, ax = plt.subplots(figsize=(7, 4.5))
    x = hist_df['# log abundance']
    for col in hist_df.columns:
        if 'histogram height' in col:
            ax.plot(x, hist_df[col], label=col.replace('histogram height ', ''))
    ax.set_xlabel('log CH4 abundance'); ax.set_ylabel('Histogram height'); ax.legend(fontsize=8)
    fig.tight_layout(); Path(output_path).parent.mkdir(parents=True, exist_ok=True); fig.savefig(output_path, dpi=200); plt.close(fig)
    return {'path': output_path}


def package_smoke_test() -> dict:
    """Lightweight schema smoke test; does not aggregate final methane evidence."""
    return {
        'spectra_inventory': workbook_inventory(SPECTRA_BOOK),
        'model_inventory': workbook_inventory(MODEL_BOOK),
        'transmission_rows': len(load_transmission_data()),
        'emission_rows': len(load_emission_data()),
        'transmission_model_rows': len(load_model_grid('transmission')),
        'emission_model_rows': len(load_model_grid('emission')),
        'abundance_rows': len(abundance_histogram('CH4_Free')),
    }

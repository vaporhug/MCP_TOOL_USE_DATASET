# Tools

This directory follows the three-layer task-tool structure.

- `data_processing.py`: file discovery, workbook ingestion, archive inspection, numeric coercion, robust z-scoring, and tidy-table helpers.
- `database_retrieval.py`: local inventory, article-link extraction, and public repository discovery.
- `astro_tools.py`: domain-specific primitives for reproducing the paper's public workflow without requiring the agent to invent core analysis code.

The tools intentionally expose reusable workflow primitives rather than a one-click answer script. Intermediate analyses belong here; `task_content.json` only states the scientific objective and final report requirement.

## Source Data Mapping

- `41586_2023_6687_MOESM2_ESM.xlsx` is Source Data Fig. 2. It contains `Transmission_Data`, `Methane_CrossSection`, and `Emission_Data`; it does not contain full/no-CH4/no-H2O model contour sheets.
- `41586_2023_6687_MOESM3_ESM.xlsx` is Source Data Fig. 3. It contains the main `Transmission_Data`, `Transmission_Models`, `Emission_Data`, and `Emission_Models` sheets used for the scored spectrum/model contour figures.
- `41586_2023_6687_MOESM5_ESM.xlsx` is Source Data Extended Data Fig. 5. It contains extended 1D-RCPE retrieval-fit products with bin widths and matching contour classes.
- Use `source_data_figure_mapping()` to verify this mapping and `plot_spectrum_model_contours(geometry=...)` to generate the expected transmission/emission artifacts.

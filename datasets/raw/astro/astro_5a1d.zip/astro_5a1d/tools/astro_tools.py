from __future__ import annotations
from pathlib import Path
import math
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from data_processing import data_root, list_files, read_table, workbook_sheets, numeric_columns, tidy_numeric_frame, robust_zscore, load_workbook_long
from database_retrieval import inventory, public_repository_links

ARTIFACT_DIR = Path(__file__).resolve().parents[1] / "artifacts"
ARTIFACT_DIR.mkdir(exist_ok=True)

def source_inventory(root: str | Path | None = None) -> dict:
    files = list_files(root or data_root())
    sizes = {str(Path(f).relative_to(Path(f).parents[2])) if len(Path(f).parents)>2 else f: Path(f).stat().st_size for f in files[:200]}
    return {"n_files": len(files), "extensions": sorted({Path(f).suffix.lower() for f in files}), "files": files[:200], "sizes": sizes, "repositories": public_repository_links().get("repositories", [])}

def source_workbook_summary(path: str | Path | None = None) -> dict:
    files = list_files(data_root())
    candidates=[f for f in files if Path(f).suffix.lower() in [".xlsx", ".xls"]]
    if path is None and not candidates:
        return {"n_workbooks": 0, "inventory": source_inventory()}
    path = path or candidates[0]
    rows=[]
    for sh in workbook_sheets(path)[:20]:
        try:
            df=read_table(path, sheet_name=sh)
            nums=numeric_columns(df)
            rows.append({"sheet": sh, "rows": int(len(df)), "columns": [str(c) for c in df.columns[:20]], "numeric_columns": [str(c) for c in nums[:20]]})
        except Exception as e:
            rows.append({"sheet": sh, "error": str(e)})
    return {"workbook": str(path), "sheets": rows}

def numeric_signal_summary(path: str | Path | None = None) -> dict:
    df=tidy_numeric_frame(path)
    if df.empty:
        return {"note": "no tabular file found", "inventory": source_inventory()}
    nums=numeric_columns(df)
    stats={}
    for c in nums[:30]:
        s=pd.to_numeric(df[c], errors="coerce").dropna()
        if len(s):
            stats[str(c)]={"n": int(len(s)), "mean": float(s.mean()), "median": float(s.median()), "std": float(s.std(ddof=1)) if len(s)>1 else 0.0, "min": float(s.min()), "max": float(s.max())}
    return {"rows": int(len(df)), "columns": [str(c) for c in df.columns], "numeric_stats": stats}

def compare_numeric_groups(path: str | Path, group_col: str, value_col: str) -> dict:
    df=tidy_numeric_frame(path)
    df[value_col]=pd.to_numeric(df[value_col], errors="coerce")
    g=df.dropna(subset=[value_col]).groupby(group_col)[value_col]
    return {"groups": [{"group": str(k), "n": int(v.count()), "mean": float(v.mean()), "median": float(v.median()), "std": float(v.std(ddof=1)) if v.count()>1 else 0.0} for k,v in g]}

def bootstrap_difference(path: str | Path, group_col: str, value_col: str, group_a: str, group_b: str, n_boot: int = 2000, seed: int = 7) -> dict:
    df=tidy_numeric_frame(path)
    rng=np.random.default_rng(seed)
    a=pd.to_numeric(df.loc[df[group_col].astype(str)==str(group_a), value_col], errors="coerce").dropna().to_numpy()
    b=pd.to_numeric(df.loc[df[group_col].astype(str)==str(group_b), value_col], errors="coerce").dropna().to_numpy()
    if len(a)==0 or len(b)==0:
        return {"error": "empty group"}
    diffs=np.array([rng.choice(a, len(a), replace=True).mean()-rng.choice(b, len(b), replace=True).mean() for _ in range(n_boot)])
    return {"group_a": str(group_a), "group_b": str(group_b), "observed_mean_difference": float(a.mean()-b.mean()), "ci95": [float(np.quantile(diffs, .025)), float(np.quantile(diffs, .975))]}

def permutation_correlation(x, y, n_perm: int = 2000, seed: int = 7) -> dict:
    x=np.asarray(x, dtype=float); y=np.asarray(y, dtype=float)
    ok=np.isfinite(x)&np.isfinite(y); x=x[ok]; y=y[ok]
    if len(x)<3: return {"error":"not enough observations"}
    obs=float(np.corrcoef(x,y)[0,1])
    rng=np.random.default_rng(seed)
    null=np.array([np.corrcoef(x, rng.permutation(y))[0,1] for _ in range(n_perm)])
    p=float((np.sum(np.abs(null)>=abs(obs))+1)/(n_perm+1))
    return {"r": obs, "p_perm": p, "n": int(len(x))}

def plot_numeric_overview(output_filename: str = "numeric_overview.png") -> dict:
    summary=numeric_signal_summary(); stats=summary.get("numeric_stats", {})
    names=list(stats)[:10]; vals=[stats[n]["mean"] for n in names]
    if not names:
        names=["files"]; vals=[source_inventory()["n_files"]]
    out=ARTIFACT_DIR/output_filename
    fig, ax=plt.subplots(figsize=(8,4.8)); ax.bar(range(len(names)), vals, color="#4c78a8")
    ax.set_xticks(range(len(names))); ax.set_xticklabels(names, rotation=35, ha="right", fontsize=8)
    ax.set_ylabel("Mean value / count"); ax.set_title("Local public-data numeric overview")
    fig.tight_layout(); fig.savefig(out,dpi=180); plt.close(fig)
    return {"path": str(out), "plotted": names}

def plot_file_inventory(output_filename: str = "file_inventory.png") -> dict:
    inv=source_inventory(); counts={}
    for f in inv["files"]:
        ext=Path(f).suffix.lower() or "no_ext"; counts[ext]=counts.get(ext,0)+1
    out=ARTIFACT_DIR/output_filename
    fig, ax=plt.subplots(figsize=(6,4)); ax.bar(list(counts), list(counts.values()), color="#f58518")
    ax.set_title("Public workflow file inventory"); ax.set_ylabel("Files")
    fig.tight_layout(); fig.savefig(out,dpi=180); plt.close(fig)
    return {"path": str(out), "counts": counts}

def spectrum_feature_table(path: str | Path | None = None, wavelength_col: str | None = None, value_col: str | None = None) -> pd.DataFrame:
    df=tidy_numeric_frame(path)
    nums=numeric_columns(df)
    if len(nums)<2: return pd.DataFrame()
    wave=wavelength_col or nums[0]; val=value_col or nums[1]
    out=df[[wave,val]].dropna().copy(); out.columns=["wavelength","signal"]
    out["signal_z"]=robust_zscore(out["signal"])
    out["local_gradient"]=np.gradient(out["signal"], out["wavelength"])
    return out

def bandpass_feature_strength(path: str | Path | None = None, center: float = 3.3, half_width: float = 0.15, continuum_width: float = 0.45) -> dict:
    """Measure a band-integrated feature strength on a (wavelength, signal)
    spectrum table. Default ``center=3.3 micron`` targets the strong CH4
    nu3 band that lies inside the JWST/NIRCam 2.4-4.0 micron range used
    by Bell et al. 2023 for WASP-80 b; pass an explicit ``center`` for
    other molecules (e.g. 2.7 micron for CO2 or 1.4 micron for H2O)."""
    tab=spectrum_feature_table(path)
    if tab.empty: return {"error":"no spectrum-like table"}
    inside=tab[(tab.wavelength>=center-half_width)&(tab.wavelength<=center+half_width)].signal
    cont=tab[((tab.wavelength>=center-continuum_width)&(tab.wavelength<center-half_width))|((tab.wavelength>center+half_width)&(tab.wavelength<=center+continuum_width))].signal
    if inside.empty or cont.empty: return {"error":"band not covered"}
    return {"center":center,"feature_mean":float(inside.mean()),"continuum_mean":float(cont.mean()),"feature_minus_continuum":float(inside.mean()-cont.mean()),"n_feature":int(len(inside)),"n_continuum":int(len(cont))}


def load_source_data_sheet(workbook_path: str | Path, sheet_name: str,
                           value_col: int = 1, error_col: int | None = 2,
                           wavelength_col: int = 0) -> pd.DataFrame:
    """Load a specific Bell et al. 2023 Source Data sheet (Methane workbook
    `41586_2023_6687_MOESM3_ESM.xlsx` exposes `Transmission_Data`,
    `Transmission_Models`, `Emission_Data`, `Emission_Models`) by sheet
    name and return a clean DataFrame with named columns
    ``wavelength_um``, ``value``, and (optionally) ``error``. Rows whose
    first cell starts with ``#`` are treated as headers and skipped."""
    df = read_table(workbook_path, sheet_name=sheet_name)
    df = df.copy()
    df = df[pd.to_numeric(df.iloc[:, wavelength_col], errors="coerce").notna()]
    out = pd.DataFrame({
        "wavelength_um": pd.to_numeric(df.iloc[:, wavelength_col], errors="coerce"),
        "value": pd.to_numeric(df.iloc[:, value_col], errors="coerce"),
    })
    if error_col is not None and df.shape[1] > error_col:
        out["error"] = pd.to_numeric(df.iloc[:, error_col], errors="coerce")
    return out.dropna(subset=["wavelength_um", "value"]).reset_index(drop=True)


def model_contour_vs_data_chi2(data_df: pd.DataFrame, model_lo: list,
                               model_hi: list, model_wave: list) -> dict:
    """Compute the chi-squared of a measured (wavelength, value, error)
    spectrum vs a model contour band defined by ``model_lo`` and
    ``model_hi`` interpolated to the data wavelengths. Used to evaluate
    Bell et al. 2023's full-model vs no-CH4 model contours: a higher
    chi2 for the no-CH4 contour relative to the full-model contour is
    the quantitative evidence for the CH4 detection."""
    obs = data_df.dropna(subset=["wavelength_um", "value"]).copy()
    if "error" not in obs.columns:
        obs["error"] = 1.0
    w = obs["wavelength_um"].to_numpy()
    lo = np.interp(w, np.asarray(model_wave), np.asarray(model_lo))
    hi = np.interp(w, np.asarray(model_wave), np.asarray(model_hi))
    mid = 0.5 * (lo + hi)
    err = obs["error"].to_numpy()
    chi2 = float(np.sum(((obs["value"].to_numpy() - mid) / err) ** 2))
    return {"n": int(len(obs)), "chi2": chi2, "reduced_chi2": chi2 / max(1, len(obs))}

def polynomial_continuum_residuals(path: str | Path | None = None, degree: int = 2) -> dict:
    tab=spectrum_feature_table(path)
    if len(tab)<degree+2: return {"error":"insufficient spectrum points"}
    coef=np.polyfit(tab.wavelength, tab.signal, degree); pred=np.polyval(coef, tab.wavelength)
    resid=tab.signal-pred
    return {"degree":degree,"coefficients":[float(c) for c in coef],"rms_residual":float(np.sqrt(np.mean(resid**2))),"max_abs_residual":float(np.max(np.abs(resid)))}

def compare_model_spectra(observed_path: str | Path, model_path: str | Path, obs_wave: str | None = None, obs_value: str | None = None, model_wave: str | None = None, model_value: str | None = None) -> dict:
    obs=spectrum_feature_table(observed_path, obs_wave, obs_value); mod=spectrum_feature_table(model_path, model_wave, model_value)
    if obs.empty or mod.empty: return {"error":"missing spectrum-like data"}
    pred=np.interp(obs.wavelength, mod.wavelength, mod.signal)
    rmse=float(np.sqrt(np.mean((obs.signal-pred)**2)))
    return {"n":int(len(obs)),"rmse":rmse,"mean_observed":float(obs.signal.mean()),"mean_model":float(np.mean(pred))}



def _named_workbook(stem: str) -> Path:
    """Resolve a bundled Source Data workbook by MOESM stem or filename."""
    root = data_root()
    stem = str(stem)
    if stem.endswith('.xlsx'):
        path = root / stem
    else:
        matches = sorted(root.glob(f'*{stem}*.xlsx'))
        if not matches:
            raise FileNotFoundError(f'No workbook matching {stem!r} under {root}')
        path = matches[0]
    if not path.exists():
        raise FileNotFoundError(path)
    return path


def source_data_figure_mapping() -> dict:
    """Map bundled Nature source-data workbooks to their figure products."""
    return {
        "MOESM2": {
            "file": str(_named_workbook('MOESM2')),
            "paper_label": "Source Data Fig. 2",
            "sheets": ["Transmission_Data", "Methane_CrossSection", "Emission_Data"],
            "note": "Observed transmission/emission spectra and methane cross-section; no full/no-CH4/no-H2O model contour sheets.",
        },
        "MOESM3": {
            "file": str(_named_workbook('MOESM3')),
            "paper_label": "Source Data Fig. 3",
            "sheets": ["Transmission_Data", "Transmission_Models", "Emission_Data", "Emission_Models"],
            "note": "Main paper spectrum/model products used for the scored full/no-CH4/no-H2O contour figures.",
        },
        "MOESM5": {
            "file": str(_named_workbook('MOESM5')),
            "paper_label": "Source Data Extended Data Fig. 5",
            "sheets": ["Transmission_Data", "Transmission_Models", "Emission_Data", "Emission_Models"],
            "note": "Extended-data 1D-RCPE retrieval-fit products with bin widths and the same contour classes.",
        },
    }


def _load_model_contours(workbook_path: str | Path, sheet_name: str) -> pd.DataFrame:
    df = read_table(workbook_path, sheet_name=sheet_name).copy()
    df = df[pd.to_numeric(df.iloc[:, 0], errors="coerce").notna()]
    out = pd.DataFrame({"wavelength_um": pd.to_numeric(df.iloc[:, 0], errors="coerce")})
    labels = ["full_lo", "full_hi", "no_ch4_lo", "no_ch4_hi", "no_h2o_lo", "no_h2o_hi"]
    for i, label in enumerate(labels, start=1):
        out[label] = pd.to_numeric(df.iloc[:, i], errors="coerce")
    return out.dropna(subset=["wavelength_um"]).reset_index(drop=True)


def _harmonize_model_units(data_df: pd.DataFrame, model_df: pd.DataFrame) -> pd.DataFrame:
    """Scale percent-like model contours into the data units when needed."""
    data_med = float(np.nanmedian(np.abs(data_df["value"])))
    model_med = float(np.nanmedian(np.abs(model_df[["full_lo", "full_hi"]].to_numpy())))
    scaled = model_df.copy()
    if data_med and model_med / data_med > 10:
        for col in [c for c in scaled.columns if c != "wavelength_um"]:
            scaled[col] = scaled[col] / 100.0
    return scaled


def plot_spectrum_model_contours(geometry: str = "transmission",
                                 workbook_stem: str = "MOESM3",
                                 output_filename: str | None = None) -> dict:
    """Plot observed WASP-80 b spectrum with full/no-CH4/no-H2O contours."""
    geometry_key = geometry.strip().lower()
    if geometry_key not in {"transmission", "emission"}:
        raise ValueError("geometry must be 'transmission' or 'emission'")
    workbook = _named_workbook(workbook_stem)
    data_sheet = "Transmission_Data" if geometry_key == "transmission" else "Emission_Data"
    model_sheet = "Transmission_Models" if geometry_key == "transmission" else "Emission_Models"
    data = load_source_data_sheet(workbook, data_sheet, value_col=1, error_col=2)
    models = _harmonize_model_units(data, _load_model_contours(workbook, model_sheet))
    out = ARTIFACT_DIR / (output_filename or f"fig_{geometry_key}_spectrum.png")
    fig, ax = plt.subplots(figsize=(8.2, 4.8))
    ax.errorbar(data["wavelength_um"], data["value"], yerr=data.get("error"), fmt="o", ms=3.5, color="black", ecolor="#555555", elinewidth=0.8, label="observed spectrum")
    styles = [
        ("full", "#1f77b4", "full model"),
        ("no_ch4", "#d62728", "no CH4"),
        ("no_h2o", "#2ca02c", "no H2O"),
    ]
    for prefix, color, label in styles:
        lo = models[f"{prefix}_lo"]
        hi = models[f"{prefix}_hi"]
        ax.fill_between(models["wavelength_um"], lo, hi, color=color, alpha=0.18, linewidth=0)
        ax.plot(models["wavelength_um"], 0.5 * (lo + hi), color=color, lw=1.4, label=label)
    ax.set_xlabel("Wavelength (micron)")
    ax.set_ylabel("Transit depth" if geometry_key == "transmission" else "Eclipse depth")
    ax.set_title(f"WASP-80 b {geometry_key}: {workbook.name} {data_sheet}/{model_sheet}")
    ax.legend(loc="best", fontsize=8)
    fig.tight_layout()
    fig.savefig(out, dpi=180)
    plt.close(fig)
    return {
        "path": str(out),
        "workbook": str(workbook),
        "source_data_label": source_data_figure_mapping()[workbook_stem.upper()]["paper_label"] if workbook_stem.upper() in source_data_figure_mapping() else workbook_stem,
        "data_sheet": data_sheet,
        "model_sheet": model_sheet,
        "n_data": int(len(data)),
        "n_model": int(len(models)),
    }


def package_smoke_test() -> dict:
    """Quick offline check that the bundle and tools are importable.
    Returns only summary dicts and does not write artifact PNGs.
    Use the workbook spectrum/model primitives separately for deliverable figures."""
    return {"inventory": source_inventory(), "numeric": numeric_signal_summary(), "workbook": source_workbook_summary(), "mapping": source_data_figure_mapping()}

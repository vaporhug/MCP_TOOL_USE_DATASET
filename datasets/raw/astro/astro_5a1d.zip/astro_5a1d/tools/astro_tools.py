from __future__ import annotations
from pathlib import Path
import math
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from data_processing import data_root, list_files, read_table, workbook_sheets, numeric_columns, tidy_numeric_frame, robust_zscore, load_workbook_long
from database_retrieval import inventory, public_repository_links

ARTIFACT_DIR = Path(__file__).resolve().parents[1] / "artifacts"
ARTIFACT_DIR.mkdir(exist_ok=True)

def source_inventory(root: str | Path | None = None) -> dict:
    files = list_files(root or data_root())
    sizes = {str(Path(f).relative_to(Path(f).parents[2])) if len(Path(f).parents)>2 else f: Path(f).stat().st_size for f in files[:200]}
    return {"n_files": len(files), "extensions": sorted({Path(f).suffix.lower() for f in files}), "files": files[:200], "sizes": sizes, "repositories": public_repository_links().get("repositories", [])}

def source_workbook_summary(path: str | Path | None = None) -> dict:
    files = list_files(data_root())
    candidates=[f for f in files if Path(f).suffix.lower() in [".xlsx", ".xls"]]
    if path is None and not candidates:
        return {"n_workbooks": 0, "inventory": source_inventory()}
    path = path or candidates[0]
    rows=[]
    for sh in workbook_sheets(path)[:20]:
        try:
            df=read_table(path, sheet_name=sh)
            nums=numeric_columns(df)
            rows.append({"sheet": sh, "rows": int(len(df)), "columns": [str(c) for c in df.columns[:20]], "numeric_columns": [str(c) for c in nums[:20]]})
        except Exception as e:
            rows.append({"sheet": sh, "error": str(e)})
    return {"workbook": str(path), "sheets": rows}

def numeric_signal_summary(path: str | Path | None = None) -> dict:
    df=tidy_numeric_frame(path)
    if df.empty:
        return {"note": "no tabular file found", "inventory": source_inventory()}
    nums=numeric_columns(df)
    stats={}
    for c in nums[:30]:
        s=pd.to_numeric(df[c], errors="coerce").dropna()
        if len(s):
            stats[str(c)]={"n": int(len(s)), "mean": float(s.mean()), "median": float(s.median()), "std": float(s.std(ddof=1)) if len(s)>1 else 0.0, "min": float(s.min()), "max": float(s.max())}
    return {"rows": int(len(df)), "columns": [str(c) for c in df.columns], "numeric_stats": stats}

def compare_numeric_groups(path: str | Path, group_col: str, value_col: str) -> dict:
    df=tidy_numeric_frame(path)
    df[value_col]=pd.to_numeric(df[value_col], errors="coerce")
    g=df.dropna(subset=[value_col]).groupby(group_col)[value_col]
    return {"groups": [{"group": str(k), "n": int(v.count()), "mean": float(v.mean()), "median": float(v.median()), "std": float(v.std(ddof=1)) if v.count()>1 else 0.0} for k,v in g]}

def bootstrap_difference(path: str | Path, group_col: str, value_col: str, group_a: str, group_b: str, n_boot: int = 2000, seed: int = 7) -> dict:
    df=tidy_numeric_frame(path)
    rng=np.random.default_rng(seed)
    a=pd.to_numeric(df.loc[df[group_col].astype(str)==str(group_a), value_col], errors="coerce").dropna().to_numpy()
    b=pd.to_numeric(df.loc[df[group_col].astype(str)==str(group_b), value_col], errors="coerce").dropna().to_numpy()
    if len(a)==0 or len(b)==0:
        return {"error": "empty group"}
    diffs=np.array([rng.choice(a, len(a), replace=True).mean()-rng.choice(b, len(b), replace=True).mean() for _ in range(n_boot)])
    return {"group_a": str(group_a), "group_b": str(group_b), "observed_mean_difference": float(a.mean()-b.mean()), "ci95": [float(np.quantile(diffs, .025)), float(np.quantile(diffs, .975))]}

def permutation_correlation(x, y, n_perm: int = 2000, seed: int = 7) -> dict:
    x=np.asarray(x, dtype=float); y=np.asarray(y, dtype=float)
    ok=np.isfinite(x)&np.isfinite(y); x=x[ok]; y=y[ok]
    if len(x)<3: return {"error":"not enough observations"}
    obs=float(np.corrcoef(x,y)[0,1])
    rng=np.random.default_rng(seed)
    null=np.array([np.corrcoef(x, rng.permutation(y))[0,1] for _ in range(n_perm)])
    p=float((np.sum(np.abs(null)>=abs(obs))+1)/(n_perm+1))
    return {"r": obs, "p_perm": p, "n": int(len(x))}

def plot_numeric_overview(output_filename: str = "numeric_overview.png") -> dict:
    summary=numeric_signal_summary(); stats=summary.get("numeric_stats", {})
    names=list(stats)[:10]; vals=[stats[n]["mean"] for n in names]
    if not names:
        names=["files"]; vals=[source_inventory()["n_files"]]
    out=ARTIFACT_DIR/output_filename
    fig, ax=plt.subplots(figsize=(8,4.8)); ax.bar(range(len(names)), vals, color="#4c78a8")
    ax.set_xticks(range(len(names))); ax.set_xticklabels(names, rotation=35, ha="right", fontsize=8)
    ax.set_ylabel("Mean value / count"); ax.set_title("Local public-data numeric overview")
    fig.tight_layout(); fig.savefig(out,dpi=180); plt.close(fig)
    return {"path": str(out), "plotted": names}

def plot_file_inventory(output_filename: str = "file_inventory.png") -> dict:
    inv=source_inventory(); counts={}
    for f in inv["files"]:
        ext=Path(f).suffix.lower() or "no_ext"; counts[ext]=counts.get(ext,0)+1
    out=ARTIFACT_DIR/output_filename
    fig, ax=plt.subplots(figsize=(6,4)); ax.bar(list(counts), list(counts.values()), color="#f58518")
    ax.set_title("Public workflow file inventory"); ax.set_ylabel("Files")
    fig.tight_layout(); fig.savefig(out,dpi=180); plt.close(fig)
    return {"path": str(out), "counts": counts}

def spectrum_feature_table(path: str | Path | None = None, wavelength_col: str | None = None, value_col: str | None = None) -> pd.DataFrame:
    df=tidy_numeric_frame(path)
    nums=numeric_columns(df)
    if len(nums)<2: return pd.DataFrame()
    wave=wavelength_col or nums[0]; val=value_col or nums[1]
    out=df[[wave,val]].dropna().copy(); out.columns=["wavelength","signal"]
    out["signal_z"]=robust_zscore(out["signal"])
    out["local_gradient"]=np.gradient(out["signal"], out["wavelength"])
    return out

def bandpass_feature_strength(path: str | Path | None = None, center: float = 4.3, half_width: float = 0.15, continuum_width: float = 0.45) -> dict:
    tab=spectrum_feature_table(path)
    if tab.empty: return {"error":"no spectrum-like table"}
    inside=tab[(tab.wavelength>=center-half_width)&(tab.wavelength<=center+half_width)].signal
    cont=tab[((tab.wavelength>=center-continuum_width)&(tab.wavelength<center-half_width))|((tab.wavelength>center+half_width)&(tab.wavelength<=center+continuum_width))].signal
    if inside.empty or cont.empty: return {"error":"band not covered"}
    return {"center":center,"feature_mean":float(inside.mean()),"continuum_mean":float(cont.mean()),"feature_minus_continuum":float(inside.mean()-cont.mean()),"n_feature":int(len(inside)),"n_continuum":int(len(cont))}

def polynomial_continuum_residuals(path: str | Path | None = None, degree: int = 2) -> dict:
    tab=spectrum_feature_table(path)
    if len(tab)<degree+2: return {"error":"insufficient spectrum points"}
    coef=np.polyfit(tab.wavelength, tab.signal, degree); pred=np.polyval(coef, tab.wavelength)
    resid=tab.signal-pred
    return {"degree":degree,"coefficients":[float(c) for c in coef],"rms_residual":float(np.sqrt(np.mean(resid**2))),"max_abs_residual":float(np.max(np.abs(resid)))}

def compare_model_spectra(observed_path: str | Path, model_path: str | Path, obs_wave: str | None = None, obs_value: str | None = None, model_wave: str | None = None, model_value: str | None = None) -> dict:
    obs=spectrum_feature_table(observed_path, obs_wave, obs_value); mod=spectrum_feature_table(model_path, model_wave, model_value)
    if obs.empty or mod.empty: return {"error":"missing spectrum-like data"}
    pred=np.interp(obs.wavelength, mod.wavelength, mod.signal)
    rmse=float(np.sqrt(np.mean((obs.signal-pred)**2)))
    return {"n":int(len(obs)),"rmse":rmse,"mean_observed":float(obs.signal.mean()),"mean_model":float(np.mean(pred))}



def package_smoke_test() -> dict:
    plot_numeric_overview(f"astro_5a1d_numeric_overview.png")
    plot_file_inventory(f"astro_5a1d_file_inventory.png")
    return {"inventory": source_inventory(), "numeric": numeric_signal_summary(), "workbook": source_workbook_summary()}

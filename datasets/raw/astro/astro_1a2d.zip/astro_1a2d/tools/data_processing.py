from __future__ import annotations

from pathlib import Path
import csv
import io
import re
import shlex
import zipfile
from typing import Iterable

import numpy as np
import pandas as pd


def read_csv(path: str | Path, **kwargs) -> pd.DataFrame:
    return pd.read_csv(path, **kwargs)


def read_fwf(path: str | Path, **kwargs) -> pd.DataFrame:
    return pd.read_fwf(path, **kwargs)


def list_files(root: str | Path, suffixes: Iterable[str] | None = None) -> list[str]:
    root_path = Path(root)
    items: list[str] = []
    for child in sorted(root_path.rglob('*')):
        if not child.is_file():
            continue
        if suffixes is not None and child.suffix.lower() not in set(suffixes):
            continue
        items.append(str(child))
    return items


def read_ecsv_like(path: str | Path) -> pd.DataFrame:
    lines = Path(path).read_text(encoding='utf-8', errors='ignore').splitlines()
    data_lines = [line.strip() for line in lines if line.strip() and not line.startswith('#')]
    if not data_lines:
        raise ValueError(f'No data rows found in {path}')
    header = shlex.split(data_lines[0])
    rows = [shlex.split(line) for line in data_lines[1:]]
    df = pd.DataFrame(rows, columns=header)
    for col in df.columns:
        converted = pd.to_numeric(df[col], errors='coerce')
        if converted.notna().any():
            df[col] = converted
    return df


def read_fixed_width_numeric_table(path: str | Path, widths: list[int], names: list[str], skiprows: int = 0) -> pd.DataFrame:
    df = pd.read_fwf(path, widths=widths, names=names, skiprows=skiprows)
    for col in df.columns:
        converted = pd.to_numeric(df[col], errors='coerce')
        if converted.notna().any():
            df[col] = converted
    return df


def read_numeric_rows(path: str | Path, min_fields: int | None = None) -> pd.DataFrame:
    rows = []
    for line in Path(path).read_text(encoding='utf-8', errors='ignore').splitlines():
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        if line.startswith('Title:') or line.startswith('Authors:') or line.startswith('Table:'):
            continue
        fields = line.split()
        if min_fields is not None and len(fields) < min_fields:
            continue
        rows.append(fields)
    if not rows:
        raise ValueError(f'No numeric rows found in {path}')
    width = max(len(r) for r in rows)
    norm = [r + [np.nan] * (width - len(r)) for r in rows]
    df = pd.DataFrame(norm)
    for col in df.columns:
        converted = pd.to_numeric(df[col], errors='coerce')
        if converted.notna().any():
            df[col] = converted
    return df


def unzip_members(zip_path: str | Path, extract_to: str | Path | None = None) -> list[str]:
    zpath = Path(zip_path)
    if extract_to is None:
        extract_to = zpath.parent
    extract_to = Path(extract_to)
    extract_to.mkdir(parents=True, exist_ok=True)
    out = []
    with zipfile.ZipFile(zpath) as zf:
        for member in zf.namelist():
            zf.extract(member, extract_to)
            out.append(str(extract_to / member))
    return out

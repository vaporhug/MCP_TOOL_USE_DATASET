from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ARTIFACT_DIR = Path(__file__).resolve().parents[1] / 'artifacts'
ARTIFACT_DIR.mkdir(parents=True, exist_ok=True)


def _savefig(name: str) -> str:
    return str(ARTIFACT_DIR / name)


def load_spectrum_table(path: str) -> dict:
    arr = np.loadtxt(path, comments='#')
    return {'n_rows': int(arr.shape[0]), 'n_cols': int(arr.shape[1]), 'first_row': arr[0].tolist(), 'last_row': arr[-1].tolist()}


def summarize_fig1_components(path: str) -> dict:
    arr = np.loadtxt(path, comments='#')
    obs = arr[:, 1]
    model = arr[:, 2]
    comp1 = arr[:, 3]
    comp2 = arr[:, 4]
    return {
        'n_rows': int(arr.shape[0]),
        'observed_peak_mjy': float(obs.max()),
        'model_peak_mjy': float(model.max()),
        'component1_peak_mjy': float(comp1.max()),
        'component2_peak_mjy': float(comp2.max()),
        'component2_fraction_of_model_peak': float(comp2.max() / model.max()),
    }


def summarize_fig2_components(path: str) -> dict:
    arr = np.loadtxt(path, comments='#')
    obs = arr[:, 1]
    model = arr[:, 2]
    co2 = arr[:, 3]
    iso13 = arr[:, 4]
    benzene = arr[:, 5]
    c4h2 = arr[:, 6]
    return {
        'n_rows': int(arr.shape[0]),
        'observed_peak_mjy': float(obs.max()),
        'model_peak_mjy': float(model.max()),
        'co2_peak_mjy': float(co2.max()),
        'iso13_peak_mjy': float(iso13.max()),
        'benzene_peak_mjy': float(benzene.max()),
        'c4h2_peak_mjy': float(c4h2.max()),
    }


def plot_fig1_spectrum(path: str, output_filename: str = 'tabone_fig1_spectrum.png') -> dict:
    arr = np.loadtxt(path, comments='#')
    out = Path(_savefig(output_filename))
    fig, ax = plt.subplots(figsize=(8.6, 4.8))
    ax.plot(arr[:, 0], arr[:, 1], color='black', lw=1.3, label='Observed spectrum')
    ax.fill_between(arr[:, 0], arr[:, 2], color='firebrick', alpha=0.45, label='Best-fit model')
    ax.plot(arr[:, 0], arr[:, 3], color='royalblue', lw=1.2, label='Component I')
    ax.plot(arr[:, 0], arr[:, 4], color='cyan', lw=1.0, label='Component II')
    ax.set_xlabel('Wavelength (micron)')
    ax.set_ylabel('Continuum-subtracted flux (mJy)')
    ax.set_title('J160532 Figure 1 reproduction')
    ax.legend(frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(out, dpi=200)
    plt.close(fig)
    return {'path': str(out), 'n_rows': int(arr.shape[0])}


def plot_fig2_species(path: str, output_filename: str = 'tabone_fig2_species.png') -> dict:
    arr = np.loadtxt(path, comments='#')
    out = Path(_savefig(output_filename))
    fig, axes = plt.subplots(2, 1, figsize=(9.5, 6.2), sharex=True)
    axes[0].plot(arr[:, 0], arr[:, 1], color='black', lw=1.1, label='Observed spectrum')
    axes[0].fill_between(arr[:, 0], arr[:, 2], color='firebrick', alpha=0.4, label='Best-fit model')
    axes[0].set_ylabel('Flux (mJy)')
    axes[0].legend(frameon=False, fontsize=8)
    axes[0].set_title('J160532 Figure 2 reproduction')
    axes[1].fill_between(arr[:, 0], arr[:, 3], color='darkblue', alpha=0.8, label='CO2')
    axes[1].fill_between(arr[:, 0], arr[:, 4], color='royalblue', alpha=0.8, label='13CO2')
    axes[1].fill_between(arr[:, 0], arr[:, 5], color='crimson', alpha=0.65, label='C6H6')
    axes[1].fill_between(arr[:, 0], arr[:, 6], color='darkorange', alpha=0.75, label='C4H2')
    axes[1].set_xlabel('Wavelength (micron)')
    axes[1].set_ylabel('Flux (mJy)')
    axes[1].legend(frameon=False, fontsize=8, ncol=2)
    fig.tight_layout()
    fig.savefig(out, dpi=200)
    plt.close(fig)
    return {'path': str(out), 'n_rows': int(arr.shape[0])}


def summarize_species_components(path: str) -> dict:
    arr = np.loadtxt(path, comments='#')
    integrate = getattr(np, 'trapezoid', np.trapz)
    species = {
        'CO2': arr[:, 3],
        '13CO2': arr[:, 4],
        'C6H6': arr[:, 5],
        'C4H2': arr[:, 6],
    }
    stats = {}
    for name, values in species.items():
        stats[name] = {
            'peak_mjy': float(values.max()),
            'median_mjy': float(np.median(values)),
            'integrated_flux': float(integrate(values, arr[:, 0])),
        }
    return stats

from __future__ import annotations

from pathlib import Path
from typing import Iterable

from .data_processing import list_files


def local_data_inventory(data_root: str | Path) -> dict:
    root = Path(data_root).resolve()
    return {'root': str(root), 'files': list_files(root)}


def reference_inventory(reference_root: str | Path) -> dict:
    root = Path(reference_root).resolve()
    return {'root': str(root), 'files': list_files(root, suffixes={'.pdf'})}


def extract_pdf_text(path: str | Path) -> dict:
    from pypdf import PdfReader

    reader = PdfReader(str(path))
    lines = []
    for page in reader.pages:
        lines.append(page.extract_text() or '')
    return {'path': str(path), 'text': '\n'.join(lines)}


def find_pdf_lines(path: str | Path, patterns: Iterable[str]) -> dict:
    text = extract_pdf_text(path)['text']
    patterns = list(patterns)
    matches = []
    for lineno, line in enumerate(text.splitlines(), start=1):
        lower = line.lower()
        for pattern in patterns:
            if pattern.lower() in lower:
                matches.append({'line_number': lineno, 'pattern': pattern, 'line': line.strip()})
                break
    return {'path': str(path), 'patterns': patterns, 'matches': matches}

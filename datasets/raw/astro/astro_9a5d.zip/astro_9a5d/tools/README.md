# Tools

This directory follows the three-layer task-tool structure.

- `data_processing.py`: local file discovery and generic archive/table helpers.
- `database_retrieval.py`: local inventory and article/repository link inspection.
- `astro_tools.py`: X-ray timing primitives for the MAXI J1820+070 reverberation task.

The domain tools read the bundled Nature Communications source-data archive. They expose light curves, hardness data, frequency-dependent lags, lag-energy spectra, power spectra, soft-lag summaries, and artifact plotting functions for the Compton-hump and Fe-K reverberation workflow.

Run `package_smoke_test()` to regenerate the three expected artifacts from local source tables.

from __future__ import annotations

from pathlib import Path
import io
import zipfile

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

try:
    from .data_processing import data_root, list_files, archive_inventory
    from .database_retrieval import public_repository_links
except ImportError:
    import importlib.util
    import sys

    tools_dir = Path(__file__).resolve().parent

    def _load_sibling(filename: str, stem: str):
        spec = importlib.util.spec_from_file_location(f"_astro9a5d_{stem}", tools_dir / filename)
        if spec is None or spec.loader is None:
            raise ImportError(f"Cannot load {filename}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        return module

    _dp = _load_sibling("data_processing.py", "data_processing")
    _db = _load_sibling("database_retrieval.py", "database_retrieval")
    data_root = _dp.data_root
    list_files = _dp.list_files
    archive_inventory = _dp.archive_inventory
    public_repository_links = _db.public_repository_links

ARTIFACT_DIR = Path(__file__).resolve().parents[1] / "artifacts"
ARTIFACT_DIR.mkdir(exist_ok=True)
ZIP_NAME = "41467_2026_69604_MOESM2_ESM.zip"


def _zip_path() -> Path:
    return data_root() / ZIP_NAME


def source_inventory(root: str | Path | None = None) -> dict:
    files = [Path(p) for p in list_files(root or data_root())]
    archives = {p.name: archive_inventory(p)[:200] for p in files if p.suffix.lower() == ".zip"}
    return {"n_files": len(files), "extensions": sorted({p.suffix.lower() for p in files}), "files": [str(p) for p in files], "archives": archives, "repositories": public_repository_links().get("repositories", [])}


def source_members() -> list[str]:
    with zipfile.ZipFile(_zip_path()) as zf:
        return sorted(name for name in zf.namelist() if name.endswith(".txt"))


def _parse_source_blocks(raw: bytes) -> list[pd.DataFrame]:
    text = raw.decode(errors="ignore")
    lines = text.splitlines()
    header = None
    blocks: list[list[str]] = []
    current: list[str] = []
    for line in lines:
        stripped = line.strip()
        if not stripped:
            if current:
                blocks.append(current)
                current = []
            continue
        if stripped.startswith("#"):
            continue
        parts = stripped.split()
        if header is None:
            header = parts
            continue
        try:
            [float(part) for part in parts]
        except ValueError:
            if current:
                blocks.append(current)
                current = []
            continue
        current.append(stripped)
    if current:
        blocks.append(current)
    if header is None:
        return []
    frames = []
    for block in blocks:
        df = pd.read_csv(io.StringIO("\n".join(block)), sep=r"\s+", names=header[: len(block[0].split())], engine="python")
        for col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
        frames.append(df.dropna(how="all").reset_index(drop=True))
    return frames


def read_source_table(member: str, block: int | None = None) -> pd.DataFrame:
    if not member.startswith("source data/"):
        member = f"source data/{member}"
    with zipfile.ZipFile(_zip_path()) as zf:
        raw = zf.read(member)
    frames = _parse_source_blocks(raw)
    if not frames:
        return pd.DataFrame()
    if block is not None:
        return frames[block]
    return pd.concat(frames, ignore_index=True, sort=False)


def lightcurve_table() -> pd.DataFrame:
    return read_source_table("fig1_a.txt", block=0)


def hardness_table() -> pd.DataFrame:
    return read_source_table("fig1_b.txt", block=0)


def frequency_lag_table(epoch: int = 1) -> pd.DataFrame:
    if epoch not in {1, 2}:
        raise ValueError("epoch must be 1 or 2 for Fig. 2 source data")
    return read_source_table(f"fig2_{'a' if epoch == 1 else 'b'}.txt", block=0)


def lag_energy_table() -> pd.DataFrame:
    return read_source_table("fig3.txt", block=0)


def power_spectrum_table() -> pd.DataFrame:
    return read_source_table("fig10.txt", block=0)


def lag_energy_features() -> dict:
    df = lag_energy_table()
    lag_col = "Timelag"
    peak = df.loc[df[lag_col].idxmax()]
    iron = df[(df["Energy"] >= 4.0) & (df["Energy"] <= 10.0)]
    iron_peak = iron.loc[iron[lag_col].idxmax()] if not iron.empty else peak
    return {
        "compton_hump_peak_energy_keV": float(peak["Energy"]),
        "compton_hump_peak_lag": float(peak[lag_col]),
        "iron_band_peak_energy_keV": float(iron_peak["Energy"]),
        "iron_band_peak_lag": float(iron_peak[lag_col]),
        "n_energy_bins": int(len(df)),
    }


def high_frequency_soft_lag_summary() -> pd.DataFrame:
    rows = []
    for epoch in [1, 2]:
        df = frequency_lag_table(epoch)
        hf = df[df["Frequency"] >= 2.0]
        rows.append({
            "epoch": epoch,
            "min_high_frequency_lag_s": float(hf["Timelag"].min()),
            "max_low_frequency_lag_s": float(df[df["Frequency"] < 1.0]["Timelag"].max()),
            "n_negative_high_frequency_bins": int((hf["Timelag"] < 0).sum()),
            "n_bins": int(len(df)),
        })
    return pd.DataFrame(rows)


def epoch_lag_spectrum(member: str) -> pd.DataFrame:
    return read_source_table(member)


def _save(fig, output_filename: str) -> str:
    out = ARTIFACT_DIR / output_filename
    fig.tight_layout()
    fig.savefig(out, dpi=180)
    plt.close(fig)
    return str(out)


def _err(df: pd.DataFrame, column: str):
    if column not in df:
        return None
    return df[column].abs()


def plot_lightcurve_and_hardness(output_filename: str = "Fig1_astro_9a5d_feature_profile.png") -> dict:
    lc = lightcurve_table()
    fig, ax = plt.subplots(figsize=(8.2, 4.8))
    for col, color in [("LE_Count_Rate", "#1b9e77"), ("ME_Count_Rate", "#7570b3"), ("HE_Count_Rate", "#d95f02")]:
        if col in lc:
            ax.plot(lc["Time"], lc[col], marker="o", ms=3, lw=1, label=col.replace("_", " "), color=color)
    ax.set_xlabel("MJD")
    ax.set_ylabel("count rate")
    ax.set_title("Insight-HXMT LE/ME/HE hard-state light curves")
    ax.legend(frameon=False, fontsize=8)
    return {"path": _save(fig, output_filename), "rows": int(len(lc))}


def plot_frequency_lag_contrast(output_filename: str = "Fig2_astro_9a5d_workflow_contrast.png") -> dict:
    fig, ax = plt.subplots(figsize=(8.2, 4.8))
    for epoch, color in [(1, "#1f78b4"), (2, "#e31a1c")]:
        df = frequency_lag_table(epoch)
        ax.errorbar(df["Frequency"], df["Timelag"], yerr=_err(df, "Timelag_Error"), xerr=_err(df, "Frequency_Error"), fmt="o-", ms=3, lw=1, capsize=2, color=color, label=f"epoch {epoch}")
    ax.axhline(0, color="0.35", lw=1)
    ax.axvspan(2, 60, color="0.85", alpha=0.5, label="2-60 Hz soft-lag search")
    ax.set_xscale("log")
    ax.set_xlabel("Fourier frequency (Hz)")
    ax.set_ylabel("time lag (s)")
    ax.set_title("Frequency-dependent lag evolution")
    ax.legend(frameon=False, fontsize=8)
    return {"path": _save(fig, output_filename), "summary": high_frequency_soft_lag_summary().to_dict(orient="records")}


def plot_lag_energy_spectrum(output_filename: str = "Fig3_astro_9a5d_signal_relationship.png") -> dict:
    df = lag_energy_table()
    fig, ax = plt.subplots(figsize=(8.2, 4.8))
    ax.errorbar(df["Energy"], df["Timelag"], yerr=_err(df, "Timelag_Error"), xerr=_err(df, "Energy_Error"), fmt="o-", color="#6a3d9a", ms=4, lw=1, capsize=2)
    ax.axvspan(5.5, 7.2, color="#1b9e77", alpha=0.18, label="Fe-K region")
    ax.axvspan(20, 70, color="#d95f02", alpha=0.15, label="Compton hump band")
    ax.set_xscale("log")
    ax.set_xlabel("energy (keV)")
    ax.set_ylabel("time lag (s)")
    ax.set_title("High-frequency lag-energy spectrum")
    ax.legend(frameon=False, fontsize=8)
    return {"path": _save(fig, output_filename), "features": lag_energy_features()}


def package_smoke_test() -> dict:
    return {
        "inventory": source_inventory(),
        "members": source_members(),
        "lag_energy_features": lag_energy_features(),
        "soft_lag_summary": high_frequency_soft_lag_summary().to_dict(orient="records"),
        "plots": [
            plot_lightcurve_and_hardness(),
            plot_frequency_lag_contrast(),
            plot_lag_energy_spectrum(),
        ],
    }

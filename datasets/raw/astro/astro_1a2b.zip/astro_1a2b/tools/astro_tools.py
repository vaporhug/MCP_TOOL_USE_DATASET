from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


ARTIFACT_DIR = Path(__file__).resolve().parents[1] / 'artifacts'
ARTIFACT_DIR.mkdir(parents=True, exist_ok=True)

EARTH_MASS_PER_SOLAR_MASS = 332946.0487
JUPITER_MASS_PER_EARTH_MASS = 317.828

TTV_COLS = ['KOI', 'n', 'tn', 'O-C', 'e_O-C', 'f_O-C', 'TDV', 'e_TDV', 'f_TDV', 'Out', 'Over']
DYN_POSTERIOR_COLS = [
    'm_b_msun',
    'period_b_day',
    'h_b',
    'k_b',
    'omega_b_deg',
    'm_c_msun',
    'period_c_day',
    'e_c_proxy',
    'inc_c_deg',
    'omega_c_deg',
    'aux_1',
    'aux_2',
    'aux_3',
    'sample_flag',
]
STABILITY_COLS = ['tstable_yr', 'm_b_msun', 'm_c_msun', 'ab_au', 'ac_au', 'eb', 'ec']

TTV_UNITS = {
    'KOI': 'index',
    'n': 'epoch index',
    'tn': 'day',
    'O-C': 'minute',
    'e_O-C': 'minute',
    'f_O-C': 'flag',
    'TDV': 'minute',
    'e_TDV': 'minute',
    'f_TDV': 'flag',
    'Out': 'flag',
    'Over': 'flag',
}

DYN_POSTERIOR_UNITS = {
    'm_b_msun': 'solar mass',
    'period_b_day': 'day',
    'h_b': 'unitless',
    'k_b': 'unitless',
    'omega_b_deg': 'degree',
    'm_c_msun': 'solar mass',
    'period_c_day': 'day',
    'e_c_proxy': 'unitless',
    'inc_c_deg': 'degree',
    'omega_c_deg': 'degree',
    'aux_1': 'auxiliary',
    'aux_2': 'auxiliary',
    'aux_3': 'auxiliary',
    'sample_flag': 'flag',
}

STABILITY_UNITS = {
    'tstable_yr': 'year',
    'm_b_msun': 'solar mass',
    'm_c_msun': 'solar mass',
    'ab_au': 'au',
    'ac_au': 'au',
    'eb': 'unitless',
    'ec': 'unitless',
}


def _artifact_path(name: str) -> Path:
    return ARTIFACT_DIR / name


def _q_summary(series: pd.Series) -> dict:
    valid = pd.to_numeric(series, errors='coerce').dropna()
    return {
        'p16': float(valid.quantile(0.16)),
        'median': float(valid.quantile(0.50)),
        'p84': float(valid.quantile(0.84)),
    }


def _parse_ttv_catalog(path: str | Path) -> pd.DataFrame:
    rows = []
    started = False
    for line in Path(path).read_text(encoding='utf-8', errors='ignore').splitlines():
        s = line.strip()
        if not s:
            continue
        if s.startswith('---'):
            started = True
            continue
        if not started:
            continue
        fields = s.split()
        if len(fields) < 11:
            continue
        rows.append(fields[:11])
    df = pd.DataFrame(rows, columns=TTV_COLS)
    for col in TTV_COLS:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    return df


def _read_dynamical_posterior(path: str | Path) -> pd.DataFrame:
    df = pd.read_csv(path, sep=r'\s+', header=None, names=DYN_POSTERIOR_COLS, engine='python')
    for col in DYN_POSTERIOR_COLS:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    return df


def _read_stability_samples_with_order(path: str | Path) -> tuple[pd.DataFrame, str]:
    raw = pd.read_csv(path, sep=r'\s+', header=None, engine='python')
    if raw.shape[1] != 7:
        raise ValueError(f'Expected 7 columns in stability samples, got {raw.shape[1]}')
    for col in raw.columns:
        raw[col] = pd.to_numeric(raw[col], errors='coerce')

    filename = Path(path).name.lower()
    if 'combined_result' in filename:
        ordered = raw.copy()
        ordered.columns = STABILITY_COLS
        return ordered, 'combined_result_order'
    if 'orbit' in filename:
        ordered = raw.iloc[:, [6, 0, 1, 2, 3, 4, 5]].copy()
        ordered.columns = STABILITY_COLS
        return ordered, 'orbit_file_order'

    raise ValueError(
        "Unrecognized stability-sample filename. Expected one of: "
        "'combined_result*.dat' (order: tstable, mb, mc, ab, ac, eb, ec) "
        "or '*orbit*.dat' (order: mb, mc, ab, ac, eb, ec, tstable)."
    )


def _read_stability_samples(path: str | Path) -> pd.DataFrame:
    df, _ = _read_stability_samples_with_order(path)
    return df


def load_ttv_catalog(path: str) -> dict:
    df = _parse_ttv_catalog(path)
    return {
        'columns': list(df.columns),
        'column_units': TTV_UNITS,
        'n_rows': int(len(df)),
        'preview': df.head(8).to_dict('records'),
    }


def summarize_ttv_catalog(path: str) -> dict:
    df = _parse_ttv_catalog(path)
    return {
        'n_rows': int(len(df)),
        'column_units': TTV_UNITS,
        'n_unique_koi': int(df['KOI'].nunique()),
        'median_abs_oc_min': float(df['O-C'].abs().median()),
        'p90_abs_oc_min': float(df['O-C'].abs().quantile(0.9)),
        'outlier_fraction': float((df['Out'].fillna(0) > 0).mean()),
        'overlap_fraction': float((df['Over'].fillna(0) > 0).mean()),
    }


def summarize_dynamical_posterior(path: str) -> dict:
    df = _read_dynamical_posterior(path)
    mass_c_earth = df['m_c_msun'] * EARTH_MASS_PER_SOLAR_MASS
    e_b = np.sqrt((df['h_b'] ** 2) + (df['k_b'] ** 2))
    return {
        'n_rows': int(len(df)),
        'column_units': DYN_POSTERIOR_UNITS,
        'period_b_day': _q_summary(df['period_b_day']),
        'period_c_day': _q_summary(df['period_c_day']),
        'mass_c_earth': _q_summary(mass_c_earth),
        'ecc_b': _q_summary(e_b),
        'ecc_c_proxy': _q_summary(df['e_c_proxy']),
    }


def summarize_stability_samples(path: str) -> dict:
    df, detected_order = _read_stability_samples_with_order(path)
    mass_c_earth = df['m_c_msun'] * EARTH_MASS_PER_SOLAR_MASS
    return {
        'n_rows': int(len(df)),
        'detected_column_order': detected_order,
        'column_units': STABILITY_UNITS,
        'tstable_yr': _q_summary(df['tstable_yr']),
        'mass_c_earth': _q_summary(mass_c_earth),
        'ab_au': _q_summary(df['ab_au']),
        'ac_au': _q_summary(df['ac_au']),
        'eb': _q_summary(df['eb']),
        'ec': _q_summary(df['ec']),
        'fraction_tstable_ge_1Myr': float((df['tstable_yr'] >= 1e6).mean()),
    }


def summarize_population_context(path: str) -> dict:
    df = pd.read_csv(path)
    rows = len(df)
    keep = df[(pd.to_numeric(df.get('M_b'), errors='coerce') > 0) & (pd.to_numeric(df.get('Period'), errors='coerce') > 0)]
    return {
        'n_rows_total': int(rows),
        'n_rows_with_mass_period': int(len(keep)),
        'has_mass_radius_columns': bool({'M_b', 'R_b'}.issubset(set(df.columns))),
        'columns': list(df.columns),
    }


def posterior_schema_with_units() -> dict:
    return {'columns': DYN_POSTERIOR_COLS, 'units': DYN_POSTERIOR_UNITS}


def stability_schema_with_units() -> dict:
    return {'columns': STABILITY_COLS, 'units': STABILITY_UNITS}


def plot_kepler725_posteriors(dynamical_posterior_path: str, output_filename: str = 'kepler725_posteriors.png') -> dict:
    df = _read_dynamical_posterior(dynamical_posterior_path)
    mass_c_earth = df['m_c_msun'] * EARTH_MASS_PER_SOLAR_MASS

    out = _artifact_path(output_filename)
    fig, axes = plt.subplots(1, 3, figsize=(11, 3.8))
    panels = [
        (mass_c_earth, 'M_c (Earth masses)', '#4C78A8'),
        (df['period_c_day'], 'P_c (days)', '#F58518'),
        (df['e_c_proxy'], 'e_c (posterior proxy)', '#54A24B'),
    ]
    for ax, (series, xlabel, color) in zip(axes, panels):
        clean = pd.to_numeric(series, errors='coerce').dropna()
        ax.hist(clean, bins=40, color=color, alpha=0.9)
        ax.axvline(clean.median(), color='black', lw=1.0, ls='--')
        ax.set_xlabel(xlabel)
        ax.set_ylabel('count')

    fig.suptitle('Kepler-725 dynamical posterior samples from released MultiNest chain')
    fig.tight_layout()
    fig.savefig(out, dpi=200)
    plt.close(fig)
    return {'path': str(out), 'n_rows': int(len(df))}


def plot_kepler725_population_context(
    population_path: str,
    period_day: float,
    mass_earth: float,
    x_col: str = 'Period',
    y_col: str = 'M_b',
    output_filename: str = 'kepler725_population_context.png',
) -> dict:
    df = pd.read_csv(population_path)
    out = _artifact_path(output_filename)

    subset = df.copy()
    subset[x_col] = pd.to_numeric(subset.get(x_col), errors='coerce')
    subset[y_col] = pd.to_numeric(subset.get(y_col), errors='coerce')
    subset = subset[(subset[x_col] > 0) & (subset[y_col] > 0)]

    mass_mjup = mass_earth / JUPITER_MASS_PER_EARTH_MASS

    fig, ax = plt.subplots(figsize=(7.2, 4.8))
    ax.scatter(subset[x_col], subset[y_col], s=12, alpha=0.25, color='#7F7F7F', label='Known planets')
    ax.scatter([period_day], [mass_mjup], s=95, color='#D62728', edgecolor='white', linewidth=0.8, label='Kepler-725 c (released posterior median)')
    ax.set_xscale('log')
    ax.set_yscale('log')
    ax.set_xlabel(f'{x_col} (log scale)')
    ax.set_ylabel(f'{y_col} (log scale)')
    ax.set_title('Kepler-725 c in the released period-mass context slice')
    ax.legend(loc='best', frameon=False)
    fig.tight_layout()
    fig.savefig(out, dpi=200)
    plt.close(fig)
    return {'path': str(out), 'n_rows': int(len(subset))}


def plot_stability_summary(path: str, output_filename: str = 'kepler725_stability.png') -> dict:
    df = _read_stability_samples(path)
    out = _artifact_path(output_filename)

    fig, ax = plt.subplots(figsize=(7.2, 4.8))
    cvals = np.log10(df['tstable_yr'].clip(lower=1))
    sc = ax.scatter(df['ab_au'], df['ac_au'], c=cvals, s=20, cmap='viridis', alpha=0.85)
    ax.set_xlabel('a_b (au)')
    ax.set_ylabel('a_c (au)')
    ax.set_title('Dynamical stability summary for sampled Kepler-725 solutions')
    fig.colorbar(sc, ax=ax, label='log10(Tstable / yr)')
    fig.tight_layout()
    fig.savefig(out, dpi=200)
    plt.close(fig)
    return {'path': str(out), 'n_rows': int(len(df))}


def package_diagnostics(data_root: str | Path) -> dict:
    root = Path(data_root)
    ttv = root / 'holczer_ttv_table.txt'
    dyn = root / 'dynamical_simulation' / 'Multinest_sampling.dat'
    st = root / 'dynamical_simulation' / 'simulation_result_20241120' / 'combined_result.dat'
    pop = root / 'mass_radius_diagram_data' / 'SourceData_ED_Fig4.csv'

    dyn_summary = summarize_dynamical_posterior(str(dyn))
    st_summary = summarize_stability_samples(str(st))

    out = {
        'posterior_schema': posterior_schema_with_units(),
        'stability_schema': stability_schema_with_units(),
        'dyn_summary': dyn_summary,
        'stability_summary': st_summary,
        'recommended_plot_calls': [
            'plot_kepler725_posteriors',
            'plot_kepler725_population_context',
            'plot_stability_summary',
        ],
        'population_context_columns': summarize_population_context(str(pop)),
    }
    if ttv.exists():
        out['ttv_summary'] = summarize_ttv_catalog(str(ttv))
    return out

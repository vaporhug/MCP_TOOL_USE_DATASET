from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


ARTIFACT_DIR = Path(__file__).resolve().parents[1] / 'artifacts'
ARTIFACT_DIR.mkdir(parents=True, exist_ok=True)

EARTH_MASS_PER_SOLAR_MASS = 332946.0487
JUPITER_MASS_PER_EARTH_MASS = 317.828

TTV_COLS = ['KOI', 'n', 'tn', 'O-C', 'e_O-C', 'f_O-C', 'TDV', 'e_TDV', 'f_TDV', 'Out', 'Over']
DYN_POSTERIOR_COLS = [
    'm_b_msun',
    'period_b_day',
    'h_b',
    'k_b',
    'omega_b_deg',
    'm_c_msun',
    'period_c_day',
    'e_c_proxy',
    'inc_c_deg',
    'omega_c_deg',
    'aux_1',
    'aux_2',
    'aux_3',
    'sample_flag',
]
STABILITY_COLS = ['tstable_yr', 'm_b_msun', 'm_c_msun', 'ab_au', 'ac_au', 'eb', 'ec']

TTV_UNITS = {
    'KOI': 'index',
    'n': 'epoch index',
    'tn': 'day',
    'O-C': 'minute',
    'e_O-C': 'minute',
    'f_O-C': 'flag',
    'TDV': 'minute',
    'e_TDV': 'minute',
    'f_TDV': 'flag',
    'Out': 'flag',
    'Over': 'flag',
}

DYN_POSTERIOR_UNITS = {
    'm_b_msun': 'solar mass',
    'period_b_day': 'day',
    'h_b': 'unitless',
    'k_b': 'unitless',
    'omega_b_deg': 'degree',
    'm_c_msun': 'solar mass',
    'period_c_day': 'day',
    'e_c_proxy': 'unitless',
    'inc_c_deg': 'degree',
    'omega_c_deg': 'degree',
    'aux_1': 'auxiliary',
    'aux_2': 'auxiliary',
    'aux_3': 'auxiliary',
    'sample_flag': 'flag',
}

STABILITY_UNITS = {
    'tstable_yr': 'year',
    'm_b_msun': 'solar mass',
    'm_c_msun': 'solar mass',
    'ab_au': 'au',
    'ac_au': 'au',
    'eb': 'unitless',
    'ec': 'unitless',
}


def _artifact_path(name: str) -> Path:
    return ARTIFACT_DIR / name


def _source_label(path: str | Path) -> str:
    p = Path(path)
    if p.is_absolute():
        task_root = Path(__file__).resolve().parents[1]
        try:
            return str(p.resolve().relative_to(task_root))
        except Exception:
            return str(p.resolve())
    return str(p)


def _q_summary(series: pd.Series) -> dict:
    valid = pd.to_numeric(series, errors='coerce').dropna()
    p16 = float(valid.quantile(0.16))
    p50 = float(valid.quantile(0.50))
    p84 = float(valid.quantile(0.84))
    return {
        'p16': p16,
        'median': p50,
        'p84': p84,
        'q16': p16,
        'q50': p50,
        'q84': p84,
    }


def _parse_ttv_catalog(path: str | Path) -> pd.DataFrame:
    rows = []
    started = False
    for line in Path(path).read_text(encoding='utf-8', errors='ignore').splitlines():
        s = line.strip()
        if not s:
            continue
        if s.startswith('---'):
            started = True
            continue
        if not started:
            continue
        fields = s.split()
        if len(fields) < 11:
            continue
        rows.append(fields[:11])
    df = pd.DataFrame(rows, columns=TTV_COLS)
    for col in TTV_COLS:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    return df


def _read_dynamical_posterior(path: str | Path) -> pd.DataFrame:
    df = pd.read_csv(path, sep=r'\s+', header=None, names=DYN_POSTERIOR_COLS, engine='python')
    for col in DYN_POSTERIOR_COLS:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    return df


def _read_stability_samples_with_order(path: str | Path) -> tuple[pd.DataFrame, str]:
    raw = pd.read_csv(path, sep=r'\s+', header=None, engine='python')
    if raw.shape[1] != 7:
        raise ValueError(f'Expected 7 columns in stability samples, got {raw.shape[1]}')
    for col in raw.columns:
        raw[col] = pd.to_numeric(raw[col], errors='coerce')

    filename = Path(path).name.lower()
    if 'combined_result' in filename:
        ordered = raw.copy()
        ordered.columns = STABILITY_COLS
        return ordered, 'combined_result_order'
    if 'orbit' in filename:
        ordered = raw.iloc[:, [6, 0, 1, 2, 3, 4, 5]].copy()
        ordered.columns = STABILITY_COLS
        return ordered, 'orbit_file_order'

    raise ValueError(
        "Unrecognized stability-sample filename. Expected one of: "
        "'combined_result*.dat' (order: tstable, mb, mc, ab, ac, eb, ec) "
        "or '*orbit*.dat' (order: mb, mc, ab, ac, eb, ec, tstable)."
    )


def _read_stability_samples(path: str | Path) -> pd.DataFrame:
    df, _ = _read_stability_samples_with_order(path)
    return df


def load_ttv_catalog(path: str) -> dict:
    df = _parse_ttv_catalog(path)
    return {
        'columns': list(df.columns),
        'column_units': TTV_UNITS,
        'n_rows': int(len(df)),
        'preview': df.head(8).to_dict('records'),
    }


def summarize_ttv_catalog(path: str) -> dict:
    df = _parse_ttv_catalog(path)
    return {
        'n_rows': int(len(df)),
        'column_units': TTV_UNITS,
        'n_unique_koi': int(df['KOI'].nunique()),
        'median_abs_oc_min': float(df['O-C'].abs().median()),
        'p90_abs_oc_min': float(df['O-C'].abs().quantile(0.9)),
        'outlier_fraction': float((df['Out'].fillna(0) > 0).mean()),
        'overlap_fraction': float((df['Over'].fillna(0) > 0).mean()),
    }


def summarize_dynamical_posterior(path: str) -> dict:
    df = _read_dynamical_posterior(path)
    mass_c_earth = df['m_c_msun'] * EARTH_MASS_PER_SOLAR_MASS
    e_b = np.sqrt((df['h_b'] ** 2) + (df['k_b'] ** 2))
    return {
        'n_rows': int(len(df)),
        'column_units': DYN_POSTERIOR_UNITS,
        'period_b_day': _q_summary(df['period_b_day']),
        'period_c_day': _q_summary(df['period_c_day']),
        'mass_c_earth': _q_summary(mass_c_earth),
        'ecc_b': _q_summary(e_b),
        'ecc_c_proxy': _q_summary(df['e_c_proxy']),
    }


def summarize_stability_samples(path: str) -> dict:
    df, detected_order = _read_stability_samples_with_order(path)
    mass_c_earth = df['m_c_msun'] * EARTH_MASS_PER_SOLAR_MASS
    return {
        'n_rows': int(len(df)),
        'detected_column_order': detected_order,
        'column_units': STABILITY_UNITS,
        'tstable_yr': _q_summary(df['tstable_yr']),
        'mass_c_earth': _q_summary(mass_c_earth),
        'ab_au': _q_summary(df['ab_au']),
        'ac_au': _q_summary(df['ac_au']),
        'eb': _q_summary(df['eb']),
        'ec': _q_summary(df['ec']),
        'fraction_tstable_ge_1Myr': float((df['tstable_yr'] >= 1e6).mean()),
    }


def summarize_population_context(path: str) -> dict:
    df = pd.read_csv(path)
    rows = len(df)
    keep = df[(pd.to_numeric(df.get('M_b'), errors='coerce') > 0) & (pd.to_numeric(df.get('Period'), errors='coerce') > 0)]
    return {
        'n_rows_total': int(rows),
        'n_rows_with_mass_period': int(len(keep)),
        'has_mass_radius_columns': bool({'M_b', 'R_b'}.issubset(set(df.columns))),
        'columns': list(df.columns),
    }


def posterior_schema_with_units() -> dict:
    return {'columns': DYN_POSTERIOR_COLS, 'units': DYN_POSTERIOR_UNITS}


def stability_schema_with_units() -> dict:
    return {'columns': STABILITY_COLS, 'units': STABILITY_UNITS}


def checkpoint_rows_from_columns(
    dynamical_posterior_path: str,
    stability_path: str,
    posterior_columns: list[str] | None = None,
    stability_columns: list[str] | None = None,
) -> dict:
    """Build generic median checkpoint rows from selected posterior/stability columns.

    The caller chooses which rows are relevant and where to write them. This
    keeps the tool as a reusable table primitive rather than a task-specific
    final-answer writer.
    """
    dyn = _read_dynamical_posterior(dynamical_posterior_path)
    st, _ = _read_stability_samples_with_order(stability_path)

    posterior_columns = posterior_columns or ['period_c_day', 'm_c_msun']
    stability_columns = stability_columns or ['ec', 'ac_au']
    rows = []

    for col in posterior_columns:
        if col not in dyn.columns:
            raise KeyError(f'{col} is not in posterior columns')
        q = _q_summary(dyn[col])
        rows.append({
            'checkpoint': f'{col}_median',
            'value': q['q50'],
            'unit': DYN_POSTERIOR_UNITS.get(col, ''),
            'source_path': _source_label(dynamical_posterior_path),
        })
        if col == 'm_c_msun':
            earth_q = _q_summary(dyn[col] * EARTH_MASS_PER_SOLAR_MASS)
            rows.append({
                'checkpoint': 'm_c_earth_median',
                'value': earth_q['q50'],
                'unit': 'M_earth',
                'source_path': _source_label(dynamical_posterior_path),
            })

    for col in stability_columns:
        if col not in st.columns:
            raise KeyError(f'{col} is not in stability columns')
        q = _q_summary(st[col])
        rows.append({
            'checkpoint': f'{col}_median',
            'value': q['q50'],
            'unit': STABILITY_UNITS.get(col, ''),
            'source_path': _source_label(stability_path),
        })
    return {'rows': rows}


def write_checkpoint_rows(rows: list[dict], output_csv: str) -> dict:
    """Write caller-selected checkpoint rows to CSV."""
    out = Path(output_csv)
    if not out.is_absolute():
        out = Path(__file__).resolve().parents[1] / out
    out.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(out, index=False)
    return {'path': str(out), 'rows': rows}


def plot_posterior_histograms(
    dynamical_posterior_path: str,
    columns: list[str],
    output_path: str,
    labels: list[str] | None = None,
) -> dict:
    """Plot caller-selected posterior columns as histograms."""
    df = _read_dynamical_posterior(dynamical_posterior_path)
    labels = labels or columns
    if len(labels) != len(columns):
        raise ValueError('labels length must match columns length')
    out = Path(output_path)
    if not out.is_absolute():
        out = Path(__file__).resolve().parents[1] / out
    out.parent.mkdir(parents=True, exist_ok=True)
    fig, axes = plt.subplots(1, len(columns), figsize=(3.8 * len(columns), 3.8))
    if len(columns) == 1:
        axes = [axes]
    colors = ['#4C78A8', '#F58518', '#54A24B', '#B279A2', '#E45756']
    for ax, col, label, color in zip(axes, columns, labels, colors):
        if col == 'm_c_earth':
            series = df['m_c_msun'] * EARTH_MASS_PER_SOLAR_MASS
        elif col in df.columns:
            series = df[col]
        else:
            raise KeyError(f'{col} is not in posterior columns')
        clean = pd.to_numeric(series, errors='coerce').dropna()
        ax.hist(clean, bins=40, color=color, alpha=0.9)
        ax.axvline(clean.median(), color='black', lw=1.0, ls='--')
        ax.set_xlabel(label)
        ax.set_ylabel('count')

    fig.suptitle('Dynamical posterior samples')
    fig.tight_layout()
    fig.savefig(out, dpi=200)
    plt.close(fig)
    return {'path': str(out), 'n_rows': int(len(df)), 'columns': columns}


def plot_population_context(
    population_path: str,
    period_day: float,
    mass_earth: float,
    x_col: str = 'Period',
    y_col: str = 'M_b',
    output_path: str = 'artifacts/population_context.png',
    highlight_label: str = 'target object',
) -> dict:
    df = pd.read_csv(population_path)
    out = Path(output_path)
    if not out.is_absolute():
        out = Path(__file__).resolve().parents[1] / out
    out.parent.mkdir(parents=True, exist_ok=True)

    subset = df.copy()
    subset[x_col] = pd.to_numeric(subset.get(x_col), errors='coerce')
    subset[y_col] = pd.to_numeric(subset.get(y_col), errors='coerce')
    subset = subset[(subset[x_col] > 0) & (subset[y_col] > 0)]

    mass_mjup = mass_earth / JUPITER_MASS_PER_EARTH_MASS

    fig, ax = plt.subplots(figsize=(7.2, 4.8))
    ax.scatter(subset[x_col], subset[y_col], s=12, alpha=0.25, color='#7F7F7F', label='Known planets')
    ax.scatter([period_day], [mass_mjup], s=95, color='#D62728', edgecolor='white', linewidth=0.8, label=highlight_label)
    ax.set_xscale('log')
    ax.set_yscale('log')
    ax.set_xlabel(f'{x_col} (log scale)')
    ax.set_ylabel(f'{y_col} (log scale)')
    ax.set_title('Target object in the released period-mass context slice')
    ax.legend(loc='best', frameon=False)
    fig.tight_layout()
    fig.savefig(out, dpi=200)
    plt.close(fig)
    return {'path': str(out), 'n_rows': int(len(subset))}


def plot_stability_phase_space(
    path: str,
    x_col: str,
    y_col: str,
    color_col: str,
    output_path: str,
) -> dict:
    """Scatter two selected stability columns, color-coded by a third column."""
    df = _read_stability_samples(path)
    for col in [x_col, y_col, color_col]:
        if col not in df.columns:
            raise KeyError(f'{col} is not in stability columns')
    out = Path(output_path)
    if not out.is_absolute():
        out = Path(__file__).resolve().parents[1] / out
    out.parent.mkdir(parents=True, exist_ok=True)

    fig, ax = plt.subplots(figsize=(7.2, 4.8))
    color_values = pd.to_numeric(df[color_col], errors='coerce')
    if color_col == 'tstable_yr':
        color_values = np.log10(color_values.clip(lower=1))
        color_label = 'log10(Tstable / yr)'
    else:
        color_label = color_col
    sc = ax.scatter(df[x_col], df[y_col], c=color_values, s=20, cmap='viridis', alpha=0.85)
    ax.set_xlabel(f'{x_col} ({STABILITY_UNITS.get(x_col, "")})')
    ax.set_ylabel(f'{y_col} ({STABILITY_UNITS.get(y_col, "")})')
    ax.set_title('Dynamical stability phase-space samples')
    fig.colorbar(sc, ax=ax, label=color_label)
    fig.tight_layout()
    fig.savefig(out, dpi=200)
    plt.close(fig)
    return {'path': str(out), 'n_rows': int(len(df))}


def package_diagnostics(data_root: str | Path) -> dict:
    root = Path(data_root)
    ttv = root / 'holczer_ttv_table.txt'
    dyn = root / 'dynamical_simulation' / 'Multinest_sampling.dat'
    st = root / 'dynamical_simulation' / 'simulation_result_20241120' / 'combined_result.dat'
    pop = root / 'mass_radius_diagram_data' / 'SourceData_ED_Fig4.csv'

    dyn_summary = summarize_dynamical_posterior(str(dyn))
    st_summary = summarize_stability_samples(str(st))

    out = {
        'posterior_schema': posterior_schema_with_units(),
        'stability_schema': stability_schema_with_units(),
        'dyn_summary': dyn_summary,
        'stability_summary': st_summary,
        'population_context_columns': summarize_population_context(str(pop)),
    }
    if ttv.exists():
        out['ttv_summary'] = summarize_ttv_catalog(str(ttv))
    return out

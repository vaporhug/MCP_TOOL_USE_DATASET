This tools folder is organized into three layers.

- `astro_tools.py`
  Domain-specific astronomy workflow primitives for the astro_1a2b package.
- `data_processing.py`
  Generic table-reading, reshaping, inventory, and archive helpers.
- `database_retrieval.py`
  Lightweight local-reference and PDF-text inspection helpers.

Use the domain tool for the paper-specific inference workflow. Use the helper modules for data loading and reference inspection.

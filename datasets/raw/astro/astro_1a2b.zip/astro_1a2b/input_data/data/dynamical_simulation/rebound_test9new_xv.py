#!/usr/bin/env python 
# coding: utf8

import rebound
import numpy as np
import random
from time import gmtime, strftime
from datetime import datetime
import time

#PI=3.14159265358979323846
def setupSimulation(T,AA):
    sim = rebound.Simulation()
    sim.units = ('day', 'AU', 'Msun')
    print("G = {0}.".format(sim.G))
    #print(4*np.pi*np.pi*(365.25/365.25636042)**2)
    #sim.integrator = "ias15" # IAS15 is the default integrator, so we don't need this line
    sim.integrator = "whfast"
    m0=0.950746121
    m1=AA[T][0]
    #a1=((m0+m1)*(AA[T][1]/365.25)**2)**(1.0/3.0)
    x1=AA[T][1]
    y1=AA[T][2]
    z1=AA[T][3]
    xt_1=AA[T][4]#*365.25/(2.0*PI)
    yt_1=AA[T][5]#*365.25/(2.0*PI)
    zt_1=AA[T][6]#*365.25/(2.0*PI)
    m2=AA[T][7]
    x2=AA[T][1+7]
    y2=AA[T][2+7]
    z2=AA[T][3+7]
    xt_2=AA[T][4+7]#*365.25/(2.0*PI)
    yt_2=AA[T][5+7]#*365.25/(2.0*PI)
    zt_2=AA[T][6+7]#*365.25/(2.0*PI)
    sim.add(m=m0)
    sim.add(m=m1,x=x1,y=y1,z=z1,vx=xt_1,vy=yt_1,vz=zt_1)
    sim.add(m=m2,x=x2,y=y2,z=z2,vx=xt_2,vy=yt_2,vz=zt_2)
    sim.ri_whfast.safe_mode = 0
    sim.ri_whfast.corrector = 11
    sim.dt=0.05*39.64374018404#/365.25*2.0*PI
    sim.move_to_com()

    
    return sim

start_time=time.time()

file0='Multinest_sampling_xdx.dat'
AA=np.loadtxt(file0)#,usecols = (0,1,4,5),unpack = True)

dir_n=1
T=50*(dir_n-1)
N=T+50

#T=N-14
now = datetime.now() # current date and time
name0 = now.strftime("%Y%m%d_%H%M%SSimulation_result.dat")
while T < N:
    file=open(name0,'a')
    sim = setupSimulation(T,AA) # Resets everything
    T+=1
    print(T)    
    a10=sim.particles[1].a
    a20=sim.particles[2].a
    #a30=sim.particles[3].a
    now = datetime.now() # current date and time
    name =now.strftime("%Y%m%d_%H%M%Sarchive.bin")
    #print('name:',name)
    sim.automateSimulationArchive(name,interval=10*365.25)
    op= rebound.OrbitPlot(sim, unitlabel="[AU]", periastron=True,color=True)
    imagename = strftime("%Y%m%d_%H%M%Simage.png", gmtime())
    op.fig.savefig(imagename)
    d1=1.200937*((sim.particles[1].m+sim.particles[2].m)/sim.particles[0].m)**(1.0/3)*(sim.particles[1].a+sim.particles[2].a)
    #d2=1.200937*((sim.particles[2].m+sim.particles[3].m)/sim.particles[0].m)**(1.0/3)*(sim.particles[2].a+sim.particles[3].a)
    #d3=1.200937*((sim.particles[1].m+sim.particles[3].m)/sim.particles[0].m)**(1.0/3)*(sim.particles[1].a+sim.particles[3].a)
    print(d1/3.46410)
    sim.exit_min_distance=d1#min(d1)
    sim.exit_min_distance/=3.46410 
    sim.exit_max_distance = 10.0      
    print(sim.exit_min_distance)
    try:
        sim.integrate(10000000.*365.25,exact_finish_time=0)
    except rebound.Escape:
          print(((sim.particles[1].x-sim.particles[2].x)**2+(sim.particles[1].y-sim.particles[2].y)**2+(sim.particles[1].z-sim.particles[2].z)**2)**0.5)    
    except rebound.Encounter:
          print(((sim.particles[1].x-sim.particles[2].x)**2+(sim.particles[1].y-sim.particles[2].y)**2+(sim.particles[1].z-sim.particles[2].z)**2)**0.5)
    sa = rebound.SimulationArchive(name)
    print(len(sa))
    file.write(name+'    '+str('%13.0f' %(len(sa)))+'\n')
    file.close()
    del sim
    print(time.time()-start_time)






from __future__ import annotations

from pathlib import Path
import re

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

try:
    from .data_processing import data_root, list_files
    from .database_retrieval import public_repository_links
except ImportError:
    import importlib.util
    import sys

    tools_dir = Path(__file__).resolve().parent

    def _load_sibling(filename: str, stem: str):
        spec = importlib.util.spec_from_file_location(f"_astro9a5b_{stem}", tools_dir / filename)
        if spec is None or spec.loader is None:
            raise ImportError(f"Cannot load {filename}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        return module

    _dp = _load_sibling("data_processing.py", "data_processing")
    _db = _load_sibling("database_retrieval.py", "database_retrieval")
    data_root = _dp.data_root
    list_files = _dp.list_files
    public_repository_links = _db.public_repository_links

ARTIFACT_DIR = Path(__file__).resolve().parents[1] / "artifacts"
ARTIFACT_DIR.mkdir(exist_ok=True)

SIMULATION_ROWS = [
    {"label": "NTE1", "mechanism": "non-thermal electrons", "flux_density": 4.4e9, "duration_s": 20.0, "fluence": 8.8e10, "delta": 3.5, "cutoff_keV": 20.0, "stix_guided": True},
    {"label": "NTE2", "mechanism": "non-thermal electrons", "flux_density": 1.6e10, "duration_s": 20.0, "fluence": 3.2e11, "delta": 3.5, "cutoff_keV": 15.0, "stix_guided": True},
    {"label": "NTE3", "mechanism": "non-thermal electrons", "flux_density": 4.4e10, "duration_s": 20.0, "fluence": 8.8e11, "delta": 3.5, "cutoff_keV": 10.0, "stix_guided": True},
    {"label": "NTE4", "mechanism": "non-thermal electrons", "flux_density": 5.0e11, "duration_s": 20.0, "fluence": 1.0e13, "delta": 4.0, "cutoff_keV": 10.0, "stix_guided": False},
    {"label": "NTP", "mechanism": "non-thermal protons", "flux_density": 1.6e10, "duration_s": 20.0, "fluence": 3.2e11, "delta": 3.5, "cutoff_keV": 50.0, "stix_guided": False},
    {"label": "NTMS electrons", "mechanism": "multi-species electrons", "flux_density": 1.0e10, "duration_s": 20.0, "fluence": 2.0e11, "delta": 3.5, "cutoff_keV": 50.0, "stix_guided": True},
    {"label": "NTMS protons", "mechanism": "multi-species protons", "flux_density": 1.6e10, "duration_s": 20.0, "fluence": 3.2e11, "delta": 3.5, "cutoff_keV": 15.0, "stix_guided": True},
    {"label": "TC1", "mechanism": "in situ thermal conduction", "flux_density": 1.0e10, "duration_s": 20.0, "fluence": 2.0e11, "delta": np.nan, "cutoff_keV": np.nan, "stix_guided": False},
    {"label": "TC2", "mechanism": "in situ thermal conduction", "flux_density": 1.6e10, "duration_s": 20.0, "fluence": 3.2e11, "delta": np.nan, "cutoff_keV": np.nan, "stix_guided": False},
    {"label": "TC3", "mechanism": "in situ thermal conduction", "flux_density": 2.0e10, "duration_s": 20.0, "fluence": 4.0e11, "delta": np.nan, "cutoff_keV": np.nan, "stix_guided": False},
    {"label": "TC4", "mechanism": "in situ thermal conduction", "flux_density": 3.0e10, "duration_s": 20.0, "fluence": 6.0e11, "delta": np.nan, "cutoff_keV": np.nan, "stix_guided": False},
    {"label": "TCGradual", "mechanism": "in situ thermal conduction", "flux_density": 2.7e9, "duration_s": 70.0, "fluence": 1.9e11, "delta": np.nan, "cutoff_keV": np.nan, "stix_guided": False},
]

OBSERVED_RATIO_ROWS = [
    {"feature": "non-flaring sources", "r_min": 2.4, "r_max": 3.4, "fwhm_s": np.nan, "fwhm_error_s": np.nan, "paper_anchor": "[PAPER, p.203]"},
    {"feature": "strong footpoint", "r_min": 1.4, "r_max": 2.0, "fwhm_s": 24.13, "fwhm_error_s": 1.74, "paper_anchor": "[PAPER, p.205; PAPER, Fig. 2]"},
    {"feature": "weak footpoint", "r_min": 2.2, "r_max": 3.0, "fwhm_s": 144.34, "fwhm_error_s": 48.74, "paper_anchor": "[PAPER, p.206; PAPER, Fig. 2]"},
]

MODEL_RATIO_ROWS = [
    {"mechanism": "particle-beam driven", "r_min": 1.5, "r_max": 2.0, "temporal_behavior": "transient drop", "best_match": "strong footpoint", "paper_anchor": "[PAPER, p.206]"},
    {"mechanism": "thermal conduction", "r_min": 2.2, "r_max": 3.0, "temporal_behavior": "gradual sustained dip", "best_match": "weak footpoint", "paper_anchor": "[PAPER, p.206]"},
]


def source_inventory(root: str | Path | None = None) -> dict:
    files = [Path(p) for p in list_files(root or data_root())]
    return {
        "n_files": len(files),
        "extensions": sorted({p.suffix.lower() for p in files}),
        "files": [str(p) for p in files],
        "repositories": public_repository_links().get("repositories", []),
    }


def zenodo_deposit_inventory() -> pd.DataFrame:
    """Return the public deposits named in the paper/source links and their audit status."""
    rows = [
        {"doi": "10.5281/zenodo.17574576", "content": "RH15D model output", "largest_file_bytes": 10508227811, "bundled": False},
        {"doi": "10.5281/zenodo.17582687", "content": "RADYN model output", "largest_file_bytes": 4011433144, "bundled": False},
        {"doi": "10.5281/zenodo.10612118", "content": "fiasco dependency archive", "largest_file_bytes": 199848, "bundled": False},
        {"doi": "10.5281/zenodo.8037332", "content": "SunPy dependency archive", "largest_file_bytes": 4036743, "bundled": False},
    ]
    return pd.DataFrame(rows)


def flare_model_parameter_table() -> pd.DataFrame:
    return pd.DataFrame(SIMULATION_ROWS)


def observed_line_ratio_evidence() -> pd.DataFrame:
    return pd.DataFrame(OBSERVED_RATIO_ROWS)


def model_mechanism_ratio_ranges() -> pd.DataFrame:
    return pd.DataFrame(MODEL_RATIO_ROWS)


def classify_models_for_footpoints() -> pd.DataFrame:
    models = flare_model_parameter_table()
    classes = []
    for _, row in models.iterrows():
        if row["mechanism"].startswith("in situ"):
            match = "weak footpoint"
            rationale = "thermal-conduction models keep R_beta_gamma in the moderate 2.2-3.0 range"
        else:
            match = "strong footpoint" if row["label"] in {"NTE3", "NTP", "NTMS electrons", "NTMS protons"} else "candidate strong-footpoint mechanism"
            rationale = "particle-beam models produce transient R_beta_gamma near 1.5-2.0"
        classes.append({"label": row["label"], "mechanism": row["mechanism"], "paper_match": match, "rationale": rationale})
    return pd.DataFrame(classes)


def _save(fig, output_filename: str) -> str:
    out = ARTIFACT_DIR / output_filename
    fig.tight_layout()
    fig.savefig(out, dpi=180)
    plt.close(fig)
    return str(out)


def plot_model_parameter_profile(output_filename: str = "Fig1_astro_9a5b_feature_profile.png") -> dict:
    df = flare_model_parameter_table()
    colors = np.where(df["mechanism"].str.contains("thermal"), "#d95f02", "#1b9e77")
    fig, ax = plt.subplots(figsize=(8.2, 4.8))
    ax.bar(df["label"], df["flux_density"], color=colors)
    ax.set_yscale("log")
    ax.set_ylabel("flux density F (erg s^-1 cm^-2)")
    ax.set_title("Paper Table 1 flare-driving parameter profile")
    ax.tick_params(axis="x", rotation=35)
    ax.scatter(df.loc[df["stix_guided"], "label"], df.loc[df["stix_guided"], "flux_density"], color="black", s=28, label="STIX-guided")
    ax.legend(frameon=False)
    return {"path": _save(fig, output_filename), "n_models": int(len(df)), "source": "paper Table 1"}


def plot_observed_ratio_lifetime(output_filename: str = "Fig2_astro_9a5b_workflow_contrast.png") -> dict:
    df = observed_line_ratio_evidence().dropna(subset=["fwhm_s"])
    fig, ax1 = plt.subplots(figsize=(8.2, 4.8))
    x = np.arange(len(df))
    ax1.bar(x - 0.18, df["r_max"] - df["r_min"], bottom=df["r_min"], width=0.36, color="#7570b3", label="R_beta_gamma range")
    ax1.set_ylabel("observed R_beta_gamma")
    ax1.set_xticks(x)
    ax1.set_xticklabels(df["feature"], rotation=20, ha="right")
    ax2 = ax1.twinx()
    ax2.errorbar(x + 0.18, df["fwhm_s"], yerr=df["fwhm_error_s"], fmt="o", color="#e7298a", label="FWHM")
    ax2.set_ylabel("ratio-dip FWHM (s)")
    ax1.set_title("Observed line-ratio depth and lifetime split by footpoint")
    return {"path": _save(fig, output_filename), "features": df["feature"].tolist()}


def plot_mechanism_ratio_match(output_filename: str = "Fig3_astro_9a5b_signal_relationship.png") -> dict:
    observed = observed_line_ratio_evidence().query("feature != 'non-flaring sources'")
    models = model_mechanism_ratio_ranges()
    fig, ax = plt.subplots(figsize=(8.2, 4.8))
    y_obs = np.arange(len(observed))
    for y, (_, row) in zip(y_obs, observed.iterrows()):
        ax.plot([row.r_min, row.r_max], [y, y], lw=7, color="#1f78b4", solid_capstyle="butt")
        ax.text(row.r_max + 0.03, y, row.feature, va="center")
    y_mod = y_obs + len(observed) + 0.7
    for y, (_, row) in zip(y_mod, models.iterrows()):
        ax.plot([row.r_min, row.r_max], [y, y], lw=7, color="#ff7f00", solid_capstyle="butt")
        ax.text(row.r_max + 0.03, y, row.mechanism, va="center")
    ax.set_yticks([])
    ax.set_xlabel("R_beta_gamma range")
    ax.set_xlim(1.2, 3.3)
    ax.set_title("Observed footpoint ratios mapped to paper mechanism ranges")
    return {"path": _save(fig, output_filename), "mechanisms": models["mechanism"].tolist()}


def package_smoke_test() -> dict:
    return {
        "inventory": source_inventory(),
        "deposits": zenodo_deposit_inventory().to_dict(orient="records"),
        "model_parameters": flare_model_parameter_table().head().to_dict(orient="records"),
        "observed_ratios": observed_line_ratio_evidence().to_dict(orient="records"),
        "plots": [
            plot_model_parameter_profile(),
            plot_observed_ratio_lifetime(),
            plot_mechanism_ratio_match(),
        ],
    }

# Tools

This directory follows the three-layer task-tool structure.

- `data_processing.py`: local file discovery and generic table/archive helpers.
- `database_retrieval.py`: local inventory, article-link extraction, and repository-link discovery.
- `astro_tools.py`: paper-specific astronomy primitives for the Solar Orbiter/SPICE flare-ribbon task.

The `astro_tools.py` functions expose the reproducible public sub-chain available in this bundle: Table 1 flare-driving parameters, observed Ly-beta/Ly-gamma ratio ranges and lifetimes from Fig. 2, and mechanism-to-footpoint matching from the paper's model comparison. The raw RADYN/RH15D output deposits named by the paper are public but multi-GB, so they are inventoried rather than bundled.

Run `package_smoke_test()` to regenerate `Fig1_astro_9a5b_feature_profile.png`, `Fig2_astro_9a5b_workflow_contrast.png`, and `Fig3_astro_9a5b_signal_relationship.png` from these local paper/source anchors.

This tool directory is split into three layers:

- `data_processing.py`: generic local file helpers
- `database_retrieval.py`: local reference/code inventory and lightweight PDF text lookup
- `astro_tools.py`: core astronomy analysis primitives for the released SPECULOOS-3 workflow

The core tool file intentionally exposes reusable workflow steps rather than a one-click paper answer:

- mixed-format light-curve parsing
- diagnostic transit-period scan over the sparse released subset
- ephemeris and depth summaries, with phase folding anchored to the paper Table 1 period and mid-transit time when reproducing the evidence figures
- multi-band depth comparison
- optical/NIR spectral summaries; both released `wave` columns are Angstrom inputs and plotting converts them to micrometers on a shared physical axis
- artifact-generating plotting helpers

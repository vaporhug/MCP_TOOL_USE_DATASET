from __future__ import annotations

from pathlib import Path
import subprocess

try:
    from .data_processing import list_files
except ImportError:
    from data_processing import list_files


def local_code_inventory(data_root: str) -> dict:
    return {
        "root": str(Path(data_root).resolve()),
        "files": list_files(data_root),
        "code_files": list_files(data_root, suffixes={".cpp", ".h", ".m", ".rtf", ".zip"}),
    }


def reference_inventory(reference_root: str) -> dict:
    return {
        "root": str(Path(reference_root).resolve()),
        "files": list_files(reference_root, suffixes={".pdf", ".html"}),
    }


def extract_pdf_text(path: str) -> dict:
    try:
        from pypdf import PdfReader

        reader = PdfReader(path)
        text = "\n".join(page.extract_text() or "" for page in reader.pages)
        if text.strip():
            return {"path": path, "text": text, "backend": "pypdf"}
    except Exception:
        pass
    try:
        result = subprocess.run(["pdftotext", path, "-"], capture_output=True, text=True, check=True)
        return {"path": path, "text": result.stdout, "backend": "pdftotext"}
    except Exception as exc:
        return {"path": path, "text": "", "backend": "unavailable", "error": str(exc)}


def find_pdf_lines(path: str, patterns: list[str]) -> dict:
    text = extract_pdf_text(path)["text"]
    matches = []
    for i, line in enumerate(text.splitlines(), start=1):
        lower = line.lower()
        for pattern in patterns:
            if pattern.lower() in lower:
                matches.append({"line_number": i, "pattern": pattern, "line": line.strip()})
                break
    return {"path": path, "patterns": patterns, "matches": matches}

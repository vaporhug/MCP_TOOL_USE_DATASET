from __future__ import annotations

from pathlib import Path
import re

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

PAPER_PERIOD_DAYS = 0.71912603
PAPER_MID_TRANSIT_BJD_TDB = 2459790.58344
PAPER_TRANSIT_DURATION_DAYS = 27.36 / 1440.0


def _infer_band(path: str) -> str:
    name = Path(path).name.lower()
    if "muscat3" in name and "_z" in name:
        return "z"
    if "_g" in name:
        return "g"
    if "_i" in name:
        return "i"
    if "iz" in name:
        return "Iz"
    return "unknown"


def _load_lightcurve(path: str) -> pd.DataFrame:
    lines = [line.strip() for line in Path(path).read_text(errors="ignore").splitlines() if line.strip()]
    first_data = next((line for line in lines if not line.startswith("#")), "")
    ncols = len(first_data.split())
    if ncols >= 11:
        df = pd.read_csv(path, sep=r"\s+", comment="#", header=None)
        df.columns = [
            "time", "flux", "error", "dx", "dy", "fwhm", "fwhmx", "fwhmy",
            "sky", "airmass", "exposure"
        ][: len(df.columns)]
        return df[["time", "flux", "error"]].apply(pd.to_numeric, errors="coerce").dropna()
    if ncols >= 7:
        df = pd.read_csv(path, sep=r"\s+", comment="#", header=None)
        df.columns = ["time", "flux", "error", "x", "y", "airmass", "sky"][: len(df.columns)]
        return df[["time", "flux", "error"]].apply(pd.to_numeric, errors="coerce").dropna()
    raise ValueError(f"Unrecognized light-curve format: {path}")


def load_lightcurve_bundle(paths: list[str]) -> dict:
    rows = []
    for path in paths:
        df = _load_lightcurve(path)
        band = _infer_band(path)
        rows.append({
            "file": Path(path).name,
            "band": band,
            "rows": int(len(df)),
            "time_min": float(df["time"].min()),
            "time_max": float(df["time"].max()),
            "median_flux": float(df["flux"].median()),
        })
    return {"files": rows}


def search_best_period(paths: list[str], period_min: float = 0.2, period_max: float = 2.0, grid_size: int = 4000) -> dict:
    dfs = [_load_lightcurve(p) for p in paths]
    time = np.concatenate([d["time"].to_numpy() for d in dfs])
    flux = np.concatenate([d["flux"].to_numpy() for d in dfs])
    err = np.concatenate([d["error"].to_numpy() for d in dfs])
    periods = np.linspace(period_min, period_max, grid_size)
    best = None
    for period in periods:
        phase = ((time - time.min()) / period) % 1.0
        idx = np.argsort(phase)
        phase_s = phase[idx]
        flux_s = flux[idx]
        win = max(10, len(phase_s) // 70)
        kernel = np.ones(win) / win
        smooth = np.convolve(flux_s, kernel, mode="same")
        imin = int(np.argmin(smooth))
        width = 0.04
        center = phase_s[imin]
        in_tr = np.abs(((phase - center + 0.5) % 1.0) - 0.5) < width / 2
        out_tr = ~in_tr
        depth = np.nanmedian(flux[out_tr]) - np.nanmedian(flux[in_tr])
        score = depth / max(np.nanmedian(err[in_tr]), 1e-6)
        item = {"period_days": float(period), "depth": float(depth), "score": float(score), "transit_phase": float(center)}
        if best is None or item["score"] > best["score"]:
            best = item
    best["searched_period_min_days"] = float(period_min)
    best["searched_period_max_days"] = float(period_max)
    best["grid_size"] = int(grid_size)
    best["interpretation"] = "exploratory_sparse_subset_scan_not_used_as_paper_ephemeris"
    return best


def estimate_ephemeris(
    paths: list[str],
    period_days: float,
    transit_phase: float | None = None,
    reference_t0_bjd: float | None = PAPER_MID_TRANSIT_BJD_TDB,
    duration_days: float = PAPER_TRANSIT_DURATION_DAYS,
) -> dict:
    """Summarize the paper-anchored ephemeris used for reproducible phase folding."""
    dfs = [_load_lightcurve(p) for p in paths]
    time = np.concatenate([d["time"].to_numpy() for d in dfs])
    phase = ((time - reference_t0_bjd) / period_days) % 1.0
    transit_phase = 0.0
    return {
        "period_days": float(period_days),
        "t0_bjd": float(reference_t0_bjd),
        "transit_phase": float(transit_phase),
        "t0_source": "paper_table_1_mid_transit_time",
        "in_transit_points": int((np.abs(np.where(phase > 0.5, phase - 1.0, phase) * period_days) < duration_days / 2).sum()),
    }


def multi_band_depth_summary(paths: list[str], period_days: float, t0_bjd: float, duration_days: float = PAPER_TRANSIT_DURATION_DAYS) -> dict:
    out = {}
    for path in paths:
        df = _load_lightcurve(path)
        phase_time = ((df["time"] - t0_bjd + 0.5 * period_days) % period_days) - 0.5 * period_days
        in_tr = np.abs(phase_time) < duration_days / 2
        center_source = "global_ephemeris"
        if int(in_tr.sum()) == 0:
            local_t0 = float(df.loc[df["flux"].idxmin(), "time"])
            phase_time = df["time"] - local_t0
            in_tr = np.abs(phase_time) < duration_days / 2
            center_source = "local_flux_minimum"
        depth = float(np.nanmedian(df.loc[~in_tr, "flux"]) - np.nanmedian(df.loc[in_tr, "flux"]))
        out[Path(path).name] = {
            "band": _infer_band(path),
            "depth": depth,
            "rows": int(len(df)),
            "in_transit_points": int(in_tr.sum()),
            "center_source": center_source,
        }
    return out


def _wave_angstrom_to_micron(series: pd.Series) -> pd.Series:
    return pd.to_numeric(series, errors="coerce") / 10000.0


def spectral_summary(optical_csv: str, nir_csv: str) -> dict:
    opt = pd.read_csv(optical_csv)
    nir = pd.read_csv(nir_csv)
    opt_wave_um = _wave_angstrom_to_micron(opt["wave"])
    nir_wave_um = _wave_angstrom_to_micron(nir["wave"])
    return {
        "optical_rows": int(len(opt)),
        "nir_rows": int(len(nir)),
        "input_wavelength_unit": "angstrom",
        "plot_wavelength_unit": "micrometer",
        "optical_median_flux": float(opt["flux"].median()),
        "nir_median_flux": float(nir["flux"].median()),
        "optical_wave_min_um": float(opt_wave_um.min()),
        "optical_wave_max_um": float(opt_wave_um.max()),
        "nir_wave_min_um": float(nir_wave_um.min()),
        "nir_wave_max_um": float(nir_wave_um.max()),
    }


def plot_phase_folded_lightcurve(paths: list[str], period_days: float, t0_bjd: float, output_path: str) -> dict:
    plt.figure(figsize=(7, 4))
    for path in paths:
        df = _load_lightcurve(path)
        phase = (((df["time"] - t0_bjd) / period_days) % 1.0)
        phase = np.where(phase > 0.5, phase - 1.0, phase)
        plt.scatter(phase, df["flux"], s=10, alpha=0.5, label=_infer_band(path))
    plt.xlabel("Orbital phase")
    plt.ylabel("Relative flux")
    plt.legend()
    plt.tight_layout()
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output_path, dpi=200)
    plt.close()
    return {"path": output_path}


def plot_multiband_depths(paths: list[str], period_days: float, t0_bjd: float, output_path: str) -> dict:
    summary = multi_band_depth_summary(paths, period_days, t0_bjd)
    files = list(summary.keys())
    depths = [summary[f]["depth"] for f in files]
    labels = [summary[f]["band"] for f in files]
    plt.figure(figsize=(6, 4))
    plt.bar(range(len(depths)), depths)
    plt.xticks(range(len(depths)), labels)
    plt.ylabel("Transit depth")
    plt.tight_layout()
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output_path, dpi=200)
    plt.close()
    return {"path": output_path}
def plot_stellar_spectra(optical_csv: str, nir_csv: str, output_path: str) -> dict:
    opt = pd.read_csv(optical_csv)
    nir = pd.read_csv(nir_csv)
    opt_wave_um = _wave_angstrom_to_micron(opt["wave"])
    nir_wave_um = _wave_angstrom_to_micron(nir["wave"])
    plt.figure(figsize=(7, 4.4))
    plt.plot(opt_wave_um, opt["flux"] / np.nanmedian(opt["flux"]), label="Kast optical", alpha=0.8)
    plt.plot(nir_wave_um, nir["flux"] / np.nanmedian(nir["flux"]), label="SpeX NIR", alpha=0.8)
    plt.xlabel("Wavelength (micrometer; input wave columns are Angstrom)")
    plt.ylabel("Normalized flux")
    plt.title("Released host-star spectra")
    plt.legend(frameon=False)
    plt.tight_layout()
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out, dpi=200)
    plt.close()
    return {"path": str(out), **spectral_summary(optical_csv, nir_csv)}

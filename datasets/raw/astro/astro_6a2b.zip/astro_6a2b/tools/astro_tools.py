from __future__ import annotations

from pathlib import Path
import re

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

try:
    from .data_processing import data_root, list_files, read_table
    from .database_retrieval import public_repository_links
except ImportError:
    from data_processing import data_root, list_files, read_table
    from database_retrieval import public_repository_links


ARTIFACT_DIR = Path(__file__).resolve().parents[1] / "artifacts"
ARTIFACT_DIR.mkdir(exist_ok=True)


def _resolve_output_path(output_filename: str | None, generic_name: str) -> Path:
    filename = output_filename if output_filename else generic_name
    return ARTIFACT_DIR / filename


def source_inventory() -> dict:
    files = list_files(data_root())
    return {
        "n_files": len(files),
        "extensions": sorted({Path(f).suffix.lower() for f in files}),
        "repositories": public_repository_links().get("repositories", []),
    }


def _posterior_workbook() -> Path:
    xlsx = [Path(f) for f in list_files(data_root()) if Path(f).suffix.lower() == ".xlsx"]
    if not xlsx:
        raise FileNotFoundError("No MOESM posterior workbook found")
    return xlsx[0]


def _is_target_like_column(name: str) -> bool:
    s = str(name).strip()
    # Handle KOI/TOI labels with optional separators and broader planet-like labels.
    if re.match(r"^(KOI|TOI)[-_ ]?\d", s, flags=re.I):
        return True
    if re.match(r"^[A-Za-z]{1,8}[-_ ]?\d+[A-Za-z]?$", s):
        return True
    return False


def _posterior_sheet_name() -> str:
    wb = _posterior_workbook()
    xl = pd.ExcelFile(wb)
    best_sheet = xl.sheet_names[0]
    best_score = -1
    for sh in xl.sheet_names:
        df = read_table(wb, sheet_name=sh)
        score = 0
        for col in df.columns:
            vals = pd.to_numeric(df[col], errors="coerce").dropna()
            if vals.size >= 50:
                score += 1
        if score > best_score:
            best_score = score
            best_sheet = sh
    return best_sheet


def posterior_workbook_manifest() -> dict:
    wb = _posterior_workbook()
    xl = pd.ExcelFile(wb)
    selected_sheet = _posterior_sheet_name()
    selected_cols = [str(c).strip() for c in pd.read_excel(wb, sheet_name=selected_sheet, nrows=0).columns]
    return {
        "workbook": wb.name,
        "sheet_names": xl.sheet_names,
        "n_sheets": len(xl.sheet_names),
        "selected_sheet": selected_sheet,
        "n_target_like_columns_in_selected_sheet": int(sum(_is_target_like_column(c) for c in selected_cols)),
    }


def _posterior_table(min_samples: int = 50, expected_min_targets: int = 10) -> pd.DataFrame:
    wb = _posterior_workbook()
    df = read_table(wb, sheet_name=_posterior_sheet_name())

    target_like_numeric_cols = []
    fallback_numeric_cols = []
    excluded_name_tokens = {"index", "id", "row", "sample", "n"}
    for col in df.columns:
        col_name = str(col).strip().lower()
        vals = pd.to_numeric(df[col], errors="coerce").dropna()
        if vals.size >= min_samples:
            if _is_target_like_column(str(col)):
                target_like_numeric_cols.append(col)
            elif col_name not in excluded_name_tokens:
                fallback_numeric_cols.append(col)

    numeric_cols = target_like_numeric_cols if target_like_numeric_cols else fallback_numeric_cols

    if not numeric_cols:
        raise ValueError("no usable posterior target columns detected in workbook")
    if len(numeric_cols) < int(expected_min_targets):
        raise ValueError("too few target-like posterior columns detected for Figure 1 workflow")

    out = df[numeric_cols].copy()
    out.columns = [str(c).strip() for c in out.columns]
    return out


def _convert_to_log_gamma(samples: np.ndarray) -> tuple[np.ndarray, str]:
    """
    Normalize Figure 1 source-data samples to logγ.

    Paper source-data text describes stellar-density-ratio posterior samples.
    When values are strictly positive, treat them as γ ratios and apply log10.
    If non-positive values are present, assume the sheet already stores logγ.
    """
    s = np.asarray(samples, dtype=float)
    if np.any(s <= 0):
        return s, "assumed_log_gamma_values"
    return np.log10(s), "log10_transformed_from_gamma_ratio"


def _target_log_gamma_samples(min_samples: int = 50) -> tuple[list[dict], dict]:
    df = _posterior_table(min_samples=min_samples)
    rows = []
    representation_counts: dict[str, int] = {}
    for col in df.columns:
        raw = pd.to_numeric(df[col], errors="coerce").dropna().to_numpy(dtype=float)
        if raw.size < min_samples:
            continue
        log_s, rep = _convert_to_log_gamma(raw)
        representation_counts[rep] = int(representation_counts.get(rep, 0) + 1)
        rows.append(
            {
                "target": str(col),
                "raw_gamma_samples": raw,
                "log_gamma_samples": log_s,
                "representation": rep,
            }
        )
    return rows, representation_counts


def figure1_log_gamma_posterior_summary(min_samples: int = 50) -> dict:
    target_rows, representation_counts = _target_log_gamma_samples(min_samples=min_samples)
    rows = []
    for row in target_rows:
        s = row["log_gamma_samples"]
        raw = row["raw_gamma_samples"]
        rows.append(
            {
                "target": row["target"],
                "n_samples": int(s.size),
                "input_representation": row["representation"],
                "median_gamma_ratio": float(np.median(raw)),
                "median_log_gamma": float(np.median(s)),
                "mean_log_gamma": float(np.mean(s)),
                "q05_log_gamma": float(np.quantile(s, 0.05)),
                "q95_log_gamma": float(np.quantile(s, 0.95)),
                "p_log_gamma_between_m0p2_p0p2": float(np.mean((s >= -0.2) & (s <= 0.2))),
                "p_log_gamma_between_m0p1_p0p1": float(np.mean((s >= -0.1) & (s <= 0.1))),
            }
        )
    return {
        "n_targets": len(rows),
        "target_posteriors": rows,
        "representation_counts": representation_counts,
        "semantic_note": (
            "Paper source-data describe stellar-density-ratio posterior samples. "
            "This tool computes logγ as log10(γ) when inputs are positive ratios; "
            "near-zero logγ then corresponds to near-unity γ."
        ),
    }


def stellar_density_ratio_posterior_summary(min_samples: int = 50) -> dict:
    # Backward-compatible alias kept for legacy callers.
    return figure1_log_gamma_posterior_summary(min_samples=min_samples)


def near_zero_log_gamma_population_support() -> dict:
    rows = figure1_log_gamma_posterior_summary().get("target_posteriors", [])
    if not rows:
        return {"error": "no usable posterior columns"}

    med = np.array([r["median_log_gamma"] for r in rows], dtype=float)
    p_wide = np.array([r["p_log_gamma_between_m0p2_p0p2"] for r in rows], dtype=float)
    p_tight = np.array([r["p_log_gamma_between_m0p1_p0p1"] for r in rows], dtype=float)

    return {
        "n_targets": int(len(rows)),
        "median_of_median_log_gamma": float(np.median(med)),
        "fraction_targets_median_log_gamma_between_m0p1_p0p1": float(np.mean((med >= -0.1) & (med <= 0.1))),
        "mean_p_log_gamma_between_m0p2_p0p2": float(np.mean(p_wide)),
        "mean_p_log_gamma_between_m0p1_p0p1": float(np.mean(p_tight)),
    }


def near_circular_orbit_consistency_summary(
    median_band: tuple[float, float] = (-0.1, 0.1),
    mass_band: tuple[float, float] = (-0.2, 0.2),
) -> dict:
    """
    Translate near-zero logγ support into a scoped near-circular consistency signal.

    This is a target-level source-data interpretation primitive; it does not
    produce hierarchical-eccentricity (HBM) population outputs.
    """
    target_rows, representation_counts = _target_log_gamma_samples(min_samples=50)
    if not target_rows:
        return {"error": "no usable posterior columns"}

    lo_m, hi_m = float(median_band[0]), float(median_band[1])
    lo_p, hi_p = float(mass_band[0]), float(mass_band[1])
    med = np.array([float(np.median(r["log_gamma_samples"])) for r in target_rows], dtype=float)
    mass_probs = np.array(
        [float(np.mean((r["log_gamma_samples"] >= lo_p) & (r["log_gamma_samples"] <= hi_p))) for r in target_rows],
        dtype=float,
    )

    frac_med = float(np.mean((med >= lo_m) & (med <= hi_m)))
    mean_mass = float(np.mean(mass_probs))
    return {
        "n_targets": int(len(target_rows)),
        "median_band": [lo_m, hi_m],
        "mass_band": [lo_p, hi_p],
        "fraction_targets_with_median_in_band": frac_med,
        "mean_posterior_mass_in_band": mean_mass,
        "representation_counts": representation_counts,
        "interpretation_scope": "figure1_slice_qualitative_consistency_only",
        "scope_boundary": "hierarchical_eccentricity_population_inference_out_of_scope",
    }


def posterior_dispersion_profile() -> dict:
    rows = figure1_log_gamma_posterior_summary().get("target_posteriors", [])
    if not rows:
        return {"error": "no usable posterior columns"}

    med = np.array([r["median_log_gamma"] for r in rows], dtype=float)
    q95 = np.array([r["q95_log_gamma"] for r in rows], dtype=float)

    return {
        "iqr_median_log_gamma": float(np.quantile(med, 0.75) - np.quantile(med, 0.25)),
        "std_median_log_gamma": float(np.std(med, ddof=1)) if med.size > 1 else 0.0,
        "max_q95_log_gamma": float(np.max(q95)),
        "min_q95_log_gamma": float(np.min(q95)),
    }


def posterior_tail_probability_profile() -> dict:
    rows = figure1_log_gamma_posterior_summary().get("target_posteriors", [])
    if not rows:
        return {"error": "no usable posterior columns"}

    return {
        "n_targets_q95_lt_m0p2": int(sum(r["q95_log_gamma"] < -0.2 for r in rows)),
        "n_targets_q95_gt_p0p2": int(sum(r["q95_log_gamma"] > 0.2 for r in rows)),
        "n_targets_tight_core_gt_0p8": int(sum(r["p_log_gamma_between_m0p1_p0p1"] > 0.8 for r in rows)),
    }


def plot_median_ratio_histogram(output_filename: str | None = None) -> dict:
    rows = figure1_log_gamma_posterior_summary().get("target_posteriors", [])
    med = np.array([r["median_log_gamma"] for r in rows], dtype=float)

    fig, ax = plt.subplots(figsize=(7.0, 4.6))
    ax.hist(med, bins=16)
    ax.set_xlabel("Posterior median logγ per target")
    ax.set_ylabel("Count of targets")
    ax.set_title("Figure 1 posterior median logγ distribution")
    ax.grid(axis="y", alpha=0.25)

    out = _resolve_output_path(output_filename, "median_log_gamma_hist.png")
    fig.tight_layout()
    fig.savefig(out, dpi=220)
    plt.close(fig)
    return {"path": str(out)}


def plot_selected_target_posteriors(
    output_filename: str | None = None,
    n_targets: int = 8,
) -> dict:
    target_rows, _ = _target_log_gamma_samples(min_samples=50)
    selected = []
    for row in target_rows:
        s = row["log_gamma_samples"]
        if s.size >= 50:
            selected.append((row["target"], s))
        if len(selected) >= n_targets:
            break

    if not selected:
        raise ValueError("No usable posterior columns")

    fig, ax = plt.subplots(figsize=(9.0, 5.2))
    data = [s for _, s in selected]
    labels = [name for name, _ in selected]
    ax.boxplot(data, labels=labels, patch_artist=True)
    ax.set_ylabel("Posterior logγ samples")
    ax.set_xlabel("Target")
    ax.set_title("Selected target posterior logγ distributions")
    ax.tick_params(axis="x", rotation=45)
    ax.grid(axis="y", alpha=0.25)

    out = _resolve_output_path(output_filename, "selected_target_log_gamma_boxplots.png")
    fig.tight_layout()
    fig.savefig(out, dpi=220)
    plt.close(fig)
    return {"path": str(out)}


def plot_population_ratio_cdf(output_filename: str | None = None) -> dict:
    target_rows, _ = _target_log_gamma_samples(min_samples=50)
    vals = [row["log_gamma_samples"] for row in target_rows if row["log_gamma_samples"].size >= 50]
    if not vals:
        raise ValueError("No usable posterior columns")

    x = np.sort(np.concatenate(vals))
    y = np.arange(1, x.size + 1) / x.size

    fig, ax = plt.subplots(figsize=(7.2, 4.8))
    ax.plot(x, y, linewidth=2)
    ax.set_xlabel("Posterior logγ")
    ax.set_ylabel("Empirical CDF")
    ax.set_title("Pooled descriptive posterior logγ CDF")
    ax.grid(alpha=0.25)

    out = _resolve_output_path(output_filename, "population_log_gamma_cdf.png")
    fig.tight_layout()
    fig.savefig(out, dpi=220)
    plt.close(fig)
    return {"path": str(out)}


def package_smoke_test() -> dict:
    inventory = source_inventory()
    manifest = posterior_workbook_manifest()
    near_circular = near_circular_orbit_consistency_summary()
    return {
        "data_file_count": int(inventory["n_files"]),
        "data_extensions": inventory["extensions"],
        "repository_link_count": int(len(inventory.get("repositories", []))),
        "workbook": manifest["workbook"],
        "sheet_count": int(manifest["n_sheets"]),
        "selected_sheet": manifest["selected_sheet"],
        "target_like_column_count": int(manifest["n_target_like_columns_in_selected_sheet"]),
        "near_circular_scope": near_circular.get("interpretation_scope"),
        "near_circular_scope_boundary": near_circular.get("scope_boundary"),
    }

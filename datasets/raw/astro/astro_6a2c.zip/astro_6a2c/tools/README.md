# Tools

Three-layer package:

- `data_processing.py`: robust local file I/O, table loading, and numeric coercion.
- `database_retrieval.py`: local-link and repository-link discovery utilities.
- `astro_tools.py`: paper-focused primitives for
  - paper-claim parameter anchors (`paper_claim_parameter_set`),
  - BH growth-model calculations (`salpeter_time_gyr`, `bh_growth_final_mass`, `required_seed_mass_for_target`, `growth_shortfall_table`),
  - host/BH mismatch calculations with uncertainty (`host_mass_bounds_msun`, `bh_host_ratio_summary`, `host_mismatch_sensitivity_table`),
  - configurable plotting wrappers for growth and host-mismatch evidence (`plot_growth_shortfall_vs_seed_mass`, `plot_bh_host_ratio_uncertainty`, `plot_host_mismatch_caveat_sensitivity`).

These tools are designed as composable scientific primitives so users can build
their own workflows instead of relying on one-shot answer or keyword-count
functions.

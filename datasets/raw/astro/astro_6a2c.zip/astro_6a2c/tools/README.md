# Tools

Three-layer package:

- `data_processing.py`: robust local file I/O, table loading, and numeric coercion.
- `database_retrieval.py`: local-link and repository-link discovery utilities.
- `astro_tools.py`: paper-focused primitives for
  - workflow/evidence manifest summaries,
  - paper headline checkpoint extraction from `target.pdf`,
  - supplementary figure-reference coverage,
  - artifact generation (`render_figure_page`, `plot_supplementary_coverage`).

These tools are intended to reproduce the paper-grounded evidence checks in `task_content.json` without relying on ad hoc one-off scripts.

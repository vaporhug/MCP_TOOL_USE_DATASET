from __future__ import annotations

from pathlib import Path
import re

import fitz
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

try:
    from .data_processing import data_root
    from .database_retrieval import public_repository_links
except ImportError:
    from data_processing import data_root
    from database_retrieval import public_repository_links


ARTIFACT_DIR = Path(__file__).resolve().parents[1] / "artifacts"
ARTIFACT_DIR.mkdir(exist_ok=True)


def _package_root() -> Path:
    return Path(__file__).resolve().parents[1]


def _target_pdf() -> Path:
    path = _package_root() / "input_data" / "reference_paper" / "target.pdf"
    if not path.exists():
        raise FileNotFoundError(f"missing {path}")
    return path


def _pdf_text(path: Path) -> str:
    with fitz.open(path) as doc:
        return "\n".join(page.get_text() for page in doc)


def _load_csv(name: str) -> pd.DataFrame:
    path = data_root() / name
    if not path.exists():
        raise FileNotFoundError(f"missing {path}")
    return pd.read_csv(path)


def workflow_manifest_summary(manifest_path: str | Path | None = None) -> dict:
    path = Path(manifest_path) if manifest_path else (data_root() / "workflow_manifest.csv")
    df = pd.read_csv(path)
    ext = df["ext"].fillna("(none)").astype(str).str.lower()
    archive_counts = df["archive"].fillna("(unknown)").astype(str).value_counts().to_dict()
    top_ext = ext.value_counts().head(10)
    return {
        "manifest": str(path),
        "n_entries": int(len(df)),
        "n_archives": int(df["archive"].nunique()),
        "n_data_like_entries": int(pd.to_numeric(df.get("is_data_like"), errors="coerce").fillna(0).sum()),
        "top_extensions": [{"ext": str(k), "count": int(v)} for k, v in top_ext.items()],
        "archive_counts": {str(k): int(v) for k, v in archive_counts.items()},
        "repository_links": public_repository_links().get("repositories", []),
    }


def numeric_dynamic_range_summary(summary_path: str | Path | None = None, top_n: int = 12) -> dict:
    path = Path(summary_path) if summary_path else (data_root() / "numeric_file_summary.csv")
    df = pd.read_csv(path)
    df["min"] = pd.to_numeric(df.get("min"), errors="coerce")
    df["max"] = pd.to_numeric(df.get("max"), errors="coerce")
    df = df.dropna(subset=["min", "max"]).copy()
    df["range"] = df["max"] - df["min"]
    df = df.sort_values("range", ascending=False)

    head = df.head(top_n)
    return {
        "summary_file": str(path),
        "n_numeric_files": int(len(df)),
        "max_range": float(df["range"].max()) if len(df) else None,
        "median_range": float(df["range"].median()) if len(df) else None,
        "top_ranges": [
            {
                "archive": str(r["archive"]),
                "path": str(r["path"]),
                "min": float(r["min"]),
                "max": float(r["max"]),
                "range": float(r["range"]),
            }
            for _, r in head.iterrows()
        ],
    }


def workflow_link_domain_summary(catalog_path: str | Path | None = None) -> dict:
    path = Path(catalog_path) if catalog_path else (data_root() / "workflow_links_catalog.csv")
    df = pd.read_csv(path)
    domains = (
        df["url"]
        .astype(str)
        .str.replace(r"^https?://", "", regex=True)
        .str.split("/")
        .str[0]
        .str.lower()
    )
    counts = domains.value_counts()
    return {
        "catalog": str(path),
        "n_links": int(len(df)),
        "domain_counts": [{"domain": str(k), "count": int(v)} for k, v in counts.items()],
    }


def paper_headline_checkpoint_summary() -> dict:
    text = _pdf_text(_target_pdf())
    norm = re.sub(r"\s+", " ", text)
    norm = norm.replace("−", "-").replace("–", "-")
    norm = norm.replace("λ", "lambda").replace("β", "beta")

    def hit_any(patterns: list[str]) -> str | None:
        for pat in patterns:
            m = re.search(pat, norm, flags=re.I)
            if m:
                return m.group(0)
        return None

    def num_any(patterns: list[str]) -> float | None:
        for pat in patterns:
            m = re.search(pat, norm, flags=re.I)
            if not m:
                continue
            groups = m.groups() or ()
            for g in groups:
                if g is None:
                    continue
                try:
                    return float(g)
                except Exception:
                    continue
            try:
                return float(m.group(0))
            except Exception:
                continue
        return None

    out = {
        "zspec": hit_any([r"zspec\s*=\s*[0-9]+(?:\.[0-9]+)?", r"\bz\s*=\s*[0-9]+(?:\.[0-9]+)?"]),
        "bh_mass": hit_any([r"mbh[^.]{0,160}(10\^?[0-9]+|10[0-9])", r"black hole mass[^.]{0,160}(10\^?[0-9]+|10[0-9])"]),
        "host_mass": hit_any([r"m\*[^.]{0,140}10\^?[0-9]+", r"over-?massive relative to (its|their) host"]),
        "low_metallicity": hit_any([r"metallicit[^.]{0,120}z\s*<\s*[0-9]+(?:\.[0-9]+)?", r"z\s*<\s*[0-9]+(?:\.[0-9]+)?\s*-\s*[0-9]+(?:\.[0-9]+)?\s*z"]),
        "lambda_edd": hit_any([r"lambda\s*edd\s*=\s*[0-9]+(?:\.[0-9]+)?", r"constant[^.]{0,90}lambda\s*edd"]),
        "broad_hbeta": hit_any([r"broad\s+h\s*beta", r"broad\s+hbeta"]),
        "zspec_value": num_any([r"zspec\s*=\s*([0-9]+(?:\.[0-9]+)?)", r"\bz\s*=\s*([0-9]+(?:\.[0-9]+)?)"]),
        "lambda_edd_value": num_any([r"lambda\s*edd\s*=\s*([0-9]+(?:\.[0-9]+)?)"]),
        "host_mass_value_1e9_msun": num_any([r"\b([0-9]+(?:\.[0-9]+)?)\s*\([^)]+\)\s*[×x]\s*10\^?9"]),
    }
    mm = re.search(r"z\s*<\s*([0-9]+(?:\.[0-9]+)?)\s*-\s*([0-9]+(?:\.[0-9]+)?)\s*z", norm, flags=re.I)
    if mm:
        out["low_metallicity_upper_bounds"] = sorted([float(mm.group(1)), float(mm.group(2))])
    else:
        out["low_metallicity_upper_bounds"] = None
    return out


def quantitative_consistency_profile() -> dict:
    ck = paper_headline_checkpoint_summary()
    checks = {
        "zspec_high_redshift_regime": (
            ck["zspec_value"] is not None and 6.0 <= float(ck["zspec_value"]) <= 12.0
        ),
        "lambda_edd_subunity_regime": (
            ck["lambda_edd_value"] is not None and 0.01 <= float(ck["lambda_edd_value"]) <= 1.0
        ),
        "bh_mass_checkpoint_present": bool(ck.get("bh_mass")),
        "host_mass_checkpoint_present": bool(ck.get("host_mass")),
        "low_metallicity_checkpoint_present": bool(ck.get("low_metallicity")),
        "broad_hbeta_present": bool(ck.get("broad_hbeta")),
    }
    return {
        "checkpoints": ck,
        "checks": checks,
        "n_checks_passed": int(sum(int(v) for v in checks.values())),
        "n_checks_total": int(len(checks)),
    }


def interpretation_caveat_summary() -> dict:
    text = _pdf_text(_target_pdf())
    norm = re.sub(r"\s+", " ", text)
    sentences = [s.strip() for s in re.split(r"(?<=[\.\?!])\s+", norm) if s.strip()]
    terms = {
        "selection_effects": [r"selection effect", r"selection bias"],
        "measurement_uncertainty": [r"uncertaint", r"error bar", r"confidence interval"],
        "scatter_or_dispersion": [r"scatter", r"dispersion"],
        "host_mismatch_context": [r"over-?massive", r"host", r"mbh-m\*", r"mbh-\s*σ"],
        "growth_track_caveat": [r"lambda\s*edd", r"accretion", r"seed"],
    }
    counts = {}
    evidence_sentences = {}
    for key, pats in terms.items():
        cat_hits = []
        for sent in sentences:
            if any(re.search(p, sent, flags=re.I) for p in pats):
                cat_hits.append(sent)
        uniq = []
        seen = set()
        for sent in cat_hits:
            sig = sent.lower()
            if sig in seen:
                continue
            seen.add(sig)
            uniq.append(sent)
        counts[key] = int(len(uniq))
        evidence_sentences[key] = uniq[:3]
    return {"caveat_term_counts": counts, "evidence_sentences": evidence_sentences}


def figure_reference_pages() -> dict:
    result = {"fig1": [], "fig3": [], "fig5": []}
    with fitz.open(_target_pdf()) as doc:
        for i, page in enumerate(doc):
            text = page.get_text()
            if ("Fig. 1" in text) or ("Figure 1" in text):
                result["fig1"].append(i)
            if ("Fig. 3" in text) or ("Figure 3" in text):
                result["fig3"].append(i)
            if ("Fig. 5" in text) or ("Figure 5" in text):
                result["fig5"].append(i)
    return result


def supplementary_figure_coverage() -> dict:
    excluded_tokens = ("peer_review", "peer-review", "peerreview", "reviewer")
    rows = []
    excluded_peer_review_like_files = []
    for pdf in sorted((data_root()).glob("*.pdf")):
        low_name = pdf.name.lower()
        if any(tok in low_name for tok in excluded_tokens):
            excluded_peer_review_like_files.append(pdf.name)
            continue
        if "moesm" not in low_name:
            continue
        try:
            with fitz.open(pdf) as doc:
                n_pages = len(doc)
                text = "\n".join(page.get_text() for page in doc)
            rows.append(
                {
                    "file": pdf.name,
                    "pages": n_pages,
                    "mentions_fig1": int(("Fig. 1" in text) or ("Figure 1" in text)),
                    "mentions_fig3": int(("Fig. 3" in text) or ("Figure 3" in text)),
                    "mentions_fig5": int(("Fig. 5" in text) or ("Figure 5" in text)),
                }
            )
        except Exception as exc:
            rows.append({"file": pdf.name, "error": str(exc)})
    return {
        "coverage_scope": "MOESM supplementary PDFs only; peer-review/support PDFs are excluded from evidence counts.",
        "excluded_peer_review_like_files": excluded_peer_review_like_files,
        "supplementary": rows,
    }


def render_figure_page(figure_number: int, output_filename: str) -> dict:
    refs = figure_reference_pages()
    key = f"fig{int(figure_number)}"
    pages = refs.get(key, [])
    if not pages:
        raise ValueError(f"no page mentioning {key}")

    target_page = int(pages[0])
    out = ARTIFACT_DIR / output_filename

    with fitz.open(_target_pdf()) as doc:
        pix = doc[target_page].get_pixmap(matrix=fitz.Matrix(2.0, 2.0), alpha=False)
        pix.save(out)

    return {"figure": key, "page_index": target_page, "path": str(out)}


def plot_supplementary_coverage(output_filename: str = "supplementary_coverage.png") -> dict:
    cov = supplementary_figure_coverage()["supplementary"]
    df = pd.DataFrame([r for r in cov if "error" not in r])
    if df.empty:
        raise ValueError("no readable supplementary PDFs")

    counts = {
        "Fig1 mentions": int(df["mentions_fig1"].sum()),
        "Fig3 mentions": int(df["mentions_fig3"].sum()),
        "Fig5 mentions": int(df["mentions_fig5"].sum()),
    }

    fig, ax = plt.subplots(figsize=(6.6, 4.4))
    ax.bar(list(counts.keys()), list(counts.values()), color=["#4c78a8", "#f58518", "#54a24b"])
    ax.set_ylabel("Supplementary PDFs containing figure reference")
    ax.set_title("Supplementary Figure-Reference Coverage")
    ax.grid(axis="y", alpha=0.2)

    out = ARTIFACT_DIR / output_filename
    fig.tight_layout()
    fig.savefig(out, dpi=220)
    plt.close(fig)
    return {"path": str(out), "counts": counts}


def plot_headline_checkpoint_presence(output_filename: str = "headline_checkpoint_presence.png") -> dict:
    checks = quantitative_consistency_profile()["checks"]
    labels = [
        "zspec_high_redshift_regime",
        "bh_mass_checkpoint_present",
        "host_mass_checkpoint_present",
        "low_metallicity_checkpoint_present",
        "lambda_edd_subunity_regime",
        "broad_hbeta_present",
    ]
    values = [1 if checks.get(k) else 0 for k in labels]

    fig, ax = plt.subplots(figsize=(8.0, 4.2))
    ax.bar(labels, values, color="#4c78a8")
    ax.set_ylim(0, 1.2)
    ax.set_ylabel("Quantitative/structured check passed")
    ax.set_title("Paper Headline Quantitative Consistency Checks")
    ax.grid(axis="y", alpha=0.2)
    ax.tick_params(axis="x", rotation=20)

    out = ARTIFACT_DIR / output_filename
    fig.tight_layout()
    fig.savefig(out, dpi=220)
    plt.close(fig)
    return {"path": str(out), "checkpoint_presence": dict(zip(labels, values))}


def plot_caveat_signal_counts(output_filename: str = "caveat_signal_counts.png") -> dict:
    counts = interpretation_caveat_summary()["caveat_term_counts"]
    labels = list(counts.keys())
    values = [int(counts[k]) for k in labels]

    fig, ax = plt.subplots(figsize=(8.4, 4.4))
    ax.bar(labels, values, color="#f58518")
    ax.set_ylabel("Unique evidence sentences")
    ax.set_title("Interpretation Caveat Evidence Coverage")
    ax.grid(axis="y", alpha=0.2)
    ax.tick_params(axis="x", rotation=20)

    out = ARTIFACT_DIR / output_filename
    fig.tight_layout()
    fig.savefig(out, dpi=220)
    plt.close(fig)
    return {"path": str(out), "counts": counts}


def _safe_call(fn):
    try:
        return fn()
    except TypeError:
        return {"note": "call requires explicit args"}
    except Exception as exc:
        return {"error": str(exc)}


def package_smoke_test() -> dict:
    manifest_path = data_root() / "workflow_manifest.csv"
    target_pdf = _target_pdf()
    data_files = sorted(p.name for p in data_root().glob("*") if p.is_file())
    return {
        "target_pdf_exists": target_pdf.exists(),
        "manifest_exists": manifest_path.exists(),
        "manifest_rows": int(pd.read_csv(manifest_path).shape[0]) if manifest_path.exists() else 0,
        "data_file_count": int(len(data_files)),
        "supplementary_pdf_count": int(len([n for n in data_files if n.lower().endswith(".pdf")])),
        "callable_checks": {
            "workflow_manifest_summary": _safe_call(lambda: {"n_entries": workflow_manifest_summary()["n_entries"]}),
            "supplementary_figure_coverage": _safe_call(lambda: {"n_rows": len(supplementary_figure_coverage()["supplementary"])}),
        },
    }

from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

try:
    from .data_processing import data_root
    from .database_retrieval import public_repository_links
except ImportError:
    from data_processing import data_root
    from database_retrieval import public_repository_links


ARTIFACT_DIR = Path(__file__).resolve().parents[1] / "artifacts"
ARTIFACT_DIR.mkdir(exist_ok=True)


def _package_root() -> Path:
    return Path(__file__).resolve().parents[1]


def _target_pdf() -> Path:
    path = _package_root() / "input_data" / "reference_paper" / "target.pdf"
    if not path.exists():
        raise FileNotFoundError(f"missing {path}")
    return path


def _resolve_output_path(output_filename: str | None, generic_name: str) -> Path:
    filename = output_filename if output_filename else generic_name
    return ARTIFACT_DIR / filename


def source_inventory() -> dict:
    files = sorted(p.name for p in data_root().glob("*") if p.is_file())
    return {
        "n_data_files": int(len(files)),
        "data_files": files,
        "extensions": sorted({Path(f).suffix.lower() for f in files}),
        "repository_links": public_repository_links().get("repositories", []),
    }


def reference_paper_manifest() -> dict:
    path = _target_pdf()
    try:
        import fitz  # PyMuPDF (optional; only required for this manifest helper)
    except Exception as exc:
        raise RuntimeError("reference_paper_manifest requires optional dependency PyMuPDF (fitz)") from exc
    with fitz.open(path) as doc:
        n_pages = len(doc)
        fig_hits = {"fig1": 0, "fig3": 0, "fig5": 0}
        for page in doc:
            text = page.get_text()
            if ("Fig. 1" in text) or ("Figure 1" in text):
                fig_hits["fig1"] += 1
            if ("Fig. 3" in text) or ("Figure 3" in text):
                fig_hits["fig3"] += 1
            if ("Fig. 5" in text) or ("Figure 5" in text):
                fig_hits["fig5"] += 1
    return {
        "target_pdf": str(path),
        "n_pages": int(n_pages),
        "figure_reference_page_hits": fig_hits,
    }


def paper_claim_parameter_set(
    zspec: float = 8.6319,
    bh_mass_log10_msun: float = 8.0,
    host_mass_log10_msun: float = 9.65,
    host_mass_log10_plus: float = 0.10,
    host_mass_log10_minus: float = 0.44,
    lambda_edd_reference: float = 0.1,
) -> dict:
    host_central_msun = 10 ** float(host_mass_log10_msun)
    host_upper_msun = 10 ** (float(host_mass_log10_msun) + float(host_mass_log10_plus))
    host_lower_msun = 10 ** (float(host_mass_log10_msun) - float(host_mass_log10_minus))
    host_central_1e9 = host_central_msun / 1e9
    host_plus_1e9 = (host_upper_msun - host_central_msun) / 1e9
    host_minus_1e9 = (host_central_msun - host_lower_msun) / 1e9
    return {
        "zspec": float(zspec),
        "bh_mass_log10_msun": float(bh_mass_log10_msun),
        "host_mass_log10_msun": float(host_mass_log10_msun),
        "host_mass_log10_plus": float(host_mass_log10_plus),
        "host_mass_log10_minus": float(host_mass_log10_minus),
        "host_mass_1e9_msun": float(host_central_1e9),
        "host_mass_plus_1e9_msun": float(host_plus_1e9),
        "host_mass_minus_1e9_msun": float(host_minus_1e9),
        "lambda_edd_reference": float(lambda_edd_reference),
        "scope_note": "Parameters represent paper-reported claim anchors for scientific consistency checks.",
        "host_mass_uncertainty_note": "host-mass uncertainty reflects paper-reported SED-model degeneracy framing",
    }


def mass_from_log10(log10_msun: float) -> float:
    return float(10 ** float(log10_msun))


def host_mass_bounds_msun(
    host_mass_1e9_msun: float,
    host_mass_plus_1e9_msun: float,
    host_mass_minus_1e9_msun: float,
) -> dict:
    central = float(host_mass_1e9_msun) * 1e9
    upper = (float(host_mass_1e9_msun) + float(host_mass_plus_1e9_msun)) * 1e9
    lower = max(1e6, (float(host_mass_1e9_msun) - float(host_mass_minus_1e9_msun)) * 1e9)
    return {
        "host_mass_central_msun": central,
        "host_mass_lower_msun": lower,
        "host_mass_upper_msun": upper,
    }


def bh_host_ratio_summary(
    bh_mass_log10_msun: float,
    host_mass_1e9_msun: float,
    host_mass_plus_1e9_msun: float,
    host_mass_minus_1e9_msun: float,
) -> dict:
    bh_mass_msun = mass_from_log10(bh_mass_log10_msun)
    host_bounds = host_mass_bounds_msun(
        host_mass_1e9_msun=host_mass_1e9_msun,
        host_mass_plus_1e9_msun=host_mass_plus_1e9_msun,
        host_mass_minus_1e9_msun=host_mass_minus_1e9_msun,
    )
    central_ratio = bh_mass_msun / host_bounds["host_mass_central_msun"]
    lower_host_ratio = bh_mass_msun / host_bounds["host_mass_upper_msun"]
    upper_host_ratio = bh_mass_msun / host_bounds["host_mass_lower_msun"]
    return {
        "bh_mass_msun": float(bh_mass_msun),
        **host_bounds,
        "bh_to_host_ratio_central": float(central_ratio),
        "bh_to_host_ratio_lower_bound": float(lower_host_ratio),
        "bh_to_host_ratio_upper_bound": float(upper_host_ratio),
        "ratio_span_factor": float(upper_host_ratio / lower_host_ratio) if lower_host_ratio > 0 else None,
    }


def salpeter_time_gyr(radiative_efficiency: float = 0.1) -> float:
    return 0.045 * (float(radiative_efficiency) / 0.1)


def cosmic_time_interval_gyr(
    z_start: float,
    z_end: float,
    h0_km_s_mpc: float = 67.4,
    omega_m: float = 0.315,
    n_steps: int = 4000,
) -> float:
    """
    Approximate cosmic-time interval in a flat LCDM cosmology.

    Uses t = (1/H0) * integral dz / ((1+z) E(z)),
    E(z)=sqrt(omega_m*(1+z)^3 + (1-omega_m)).
    """
    z_hi = float(max(z_start, z_end))
    z_lo = float(min(z_start, z_end))
    grid = np.linspace(z_lo, z_hi, int(max(n_steps, 200)))
    e = np.sqrt(float(omega_m) * (1.0 + grid) ** 3 + (1.0 - float(omega_m)))
    integrand = 1.0 / ((1.0 + grid) * e)
    h = float(h0_km_s_mpc) / 100.0
    hubble_time_gyr = 9.778 / h
    dt = float(hubble_time_gyr * np.trapz(integrand, grid))
    return dt


def bh_growth_final_mass(
    seed_mass_msun: float,
    lambda_edd: float,
    growth_time_gyr: float,
    duty_cycle: float = 1.0,
    radiative_efficiency: float = 0.1,
) -> float:
    seed_mass = max(float(seed_mass_msun), 1.0)
    lam = max(float(lambda_edd), 1e-6)
    duty = max(float(duty_cycle), 0.0)
    t_sal = salpeter_time_gyr(radiative_efficiency=radiative_efficiency)
    exponent = duty * lam * float(growth_time_gyr) / t_sal
    return float(seed_mass * np.exp(exponent))


def required_seed_mass_for_target(
    target_mass_msun: float,
    lambda_edd: float,
    growth_time_gyr: float,
    duty_cycle: float = 1.0,
    radiative_efficiency: float = 0.1,
) -> float:
    target = max(float(target_mass_msun), 1.0)
    lam = max(float(lambda_edd), 1e-6)
    duty = max(float(duty_cycle), 0.0)
    t_sal = salpeter_time_gyr(radiative_efficiency=radiative_efficiency)
    exponent = duty * lam * float(growth_time_gyr) / t_sal
    return float(target / np.exp(exponent))


def growth_shortfall_table(
    seed_masses_msun: list[float] | None = None,
    lambda_values: list[float] | None = None,
    growth_time_gyr: float | None = None,
    z_start: float = 20.0,
    z_start_values: list[float] | None = None,
    z_end: float = 8.6319,
    target_bh_mass_msun: float = 1e8,
    duty_cycle: float = 1.0,
    radiative_efficiency: float = 0.1,
) -> pd.DataFrame:
    seeds = seed_masses_msun if seed_masses_msun is not None else [1e2, 3e2, 1e3, 3e3, 1e4, 3e4, 1e5, 3e5, 1e6]
    lambdas = lambda_values if lambda_values is not None else [0.05, 0.1, 0.2]
    z_starts = z_start_values if z_start_values is not None else [z_start]
    rows = []
    for z0 in z_starts:
        growth_dt = (
            float(growth_time_gyr)
            if growth_time_gyr is not None
            else cosmic_time_interval_gyr(z_start=z0, z_end=z_end)
        )
        growth_time_source = "explicit_growth_time_gyr" if growth_time_gyr is not None else "cosmic_time_interval_from_redshift"
        for lam in lambdas:
            for seed in seeds:
                final_mass = bh_growth_final_mass(
                    seed_mass_msun=seed,
                    lambda_edd=lam,
                    growth_time_gyr=growth_dt,
                    duty_cycle=duty_cycle,
                    radiative_efficiency=radiative_efficiency,
                )
                rows.append(
                    {
                        "seed_mass_msun": float(seed),
                        "lambda_edd": float(lam),
                        "growth_time_gyr": float(growth_dt),
                        "z_start": float(z0),
                        "z_end": float(z_end),
                        "growth_time_source": growth_time_source,
                        "final_mass_msun": float(final_mass),
                        "target_mass_msun": float(target_bh_mass_msun),
                        "final_to_target_ratio": float(final_mass / target_bh_mass_msun),
                        "required_seed_for_target_msun": float(
                            required_seed_mass_for_target(
                                target_mass_msun=target_bh_mass_msun,
                                lambda_edd=lam,
                                growth_time_gyr=growth_dt,
                                duty_cycle=duty_cycle,
                                radiative_efficiency=radiative_efficiency,
                            )
                        ),
                    }
                )
    return pd.DataFrame(rows)


def host_mismatch_sensitivity_table(
    bh_mass_log10_grid: list[float] | None = None,
    host_scale_grid: list[float] | None = None,
    host_mass_1e9_msun: float = 4.5,
    host_mass_plus_1e9_msun: float = 1.1,
    host_mass_minus_1e9_msun: float = 2.9,
    bh_mass_log10_center: float = 8.0,
    bh_mass_log10_halfspan: float = 0.3,
) -> pd.DataFrame:
    if bh_mass_log10_grid is None:
        bh_grid = np.linspace(
            float(bh_mass_log10_center) - float(bh_mass_log10_halfspan),
            float(bh_mass_log10_center) + float(bh_mass_log10_halfspan),
            5,
        ).tolist()
    else:
        bh_grid = bh_mass_log10_grid

    if host_scale_grid is None:
        lower_scale = max(
            0.2,
            (float(host_mass_1e9_msun) - float(host_mass_minus_1e9_msun)) / float(host_mass_1e9_msun),
        )
        upper_scale = (float(host_mass_1e9_msun) + float(host_mass_plus_1e9_msun)) / float(host_mass_1e9_msun)
        scales = np.linspace(lower_scale, upper_scale, 5).tolist()
    else:
        scales = host_scale_grid

    rows = []
    for bh_log in bh_grid:
        bh_mass = mass_from_log10(bh_log)
        for scale in scales:
            host_mass = max(1e6, float(host_mass_1e9_msun) * 1e9 * float(scale))
            ratio = bh_mass / host_mass
            rows.append(
                {
                    "bh_mass_log10_msun": float(bh_log),
                    "host_mass_scale": float(scale),
                    "host_mass_msun": float(host_mass),
                    "bh_to_host_ratio": float(ratio),
                    "bh_to_host_ratio_log10": float(np.log10(ratio)),
                }
            )
    return pd.DataFrame(rows)


def plot_growth_shortfall_vs_seed_mass(
    growth_table: pd.DataFrame | None = None,
    output_filename: str | None = None,
) -> dict:
    df = growth_table.copy() if growth_table is not None else growth_shortfall_table(lambda_values=[0.1], z_start_values=[15.0, 20.0, 25.0])
    if df.empty:
        raise ValueError("growth table is empty")

    fig, ax = plt.subplots(figsize=(7.8, 4.8))
    if "z_start" in df.columns and len(sorted(df["z_start"].unique().tolist())) > 1:
        for z0 in sorted(df["z_start"].unique().tolist()):
            sub = df[df["z_start"] == z0].sort_values("seed_mass_msun")
            lam = float(sub["lambda_edd"].iloc[0])
            ax.plot(
                sub["seed_mass_msun"],
                sub["final_mass_msun"],
                marker="o",
                linewidth=1.8,
                label=f"z_start={z0:.0f}, lambda_Edd={lam:.2f}",
            )
    else:
        for lam in sorted(df["lambda_edd"].unique().tolist()):
            sub = df[df["lambda_edd"] == lam].sort_values("seed_mass_msun")
            ax.plot(sub["seed_mass_msun"], sub["final_mass_msun"], marker="o", linewidth=1.8, label=f"lambda_Edd={lam:.2f}")

    target_mass = float(df["target_mass_msun"].iloc[0])
    ax.axhline(target_mass, linestyle="--", linewidth=1.5, color="black", label="Target MBH")
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlabel("Seed mass (Msun)")
    ax.set_ylabel("Final BH mass after growth interval (Msun)")
    ax.set_title("Growth-track comparison vs observed BH mass anchor")
    ax.grid(alpha=0.25, which="both")
    ax.legend(frameon=False, fontsize=8)

    out = _resolve_output_path(output_filename, "growth_shortfall_vs_seed_mass.png")
    fig.tight_layout()
    fig.savefig(out, dpi=220)
    plt.close(fig)
    return {"path": str(out)}


def plot_bh_host_ratio_uncertainty(
    ratio_summary: dict | None = None,
    output_filename: str | None = None,
) -> dict:
    claim = paper_claim_parameter_set()
    ratio = ratio_summary if ratio_summary is not None else bh_host_ratio_summary(
        bh_mass_log10_msun=claim["bh_mass_log10_msun"],
        host_mass_1e9_msun=claim["host_mass_1e9_msun"],
        host_mass_plus_1e9_msun=claim["host_mass_plus_1e9_msun"],
        host_mass_minus_1e9_msun=claim["host_mass_minus_1e9_msun"],
    )

    host_vals = np.array([
        ratio["host_mass_lower_msun"],
        ratio["host_mass_central_msun"],
        ratio["host_mass_upper_msun"],
    ], dtype=float)
    ratio_vals = ratio["bh_mass_msun"] / host_vals
    labels = ["Host lower", "Host central", "Host upper"]

    fig, ax = plt.subplots(figsize=(7.2, 4.6))
    ax.plot(labels, ratio_vals, marker="o", linewidth=2)
    ax.set_yscale("log")
    ax.set_ylabel("MBH / Mhost")
    ax.set_title("BH-to-host ratio under host-mass uncertainty bounds")
    ax.grid(axis="y", alpha=0.25, which="both")

    out = _resolve_output_path(output_filename, "bh_host_ratio_uncertainty.png")
    fig.tight_layout()
    fig.savefig(out, dpi=220)
    plt.close(fig)
    return {"path": str(out)}


def plot_host_mismatch_caveat_sensitivity(
    sensitivity_table: pd.DataFrame | None = None,
    output_filename: str | None = None,
) -> dict:
    df = sensitivity_table.copy() if sensitivity_table is not None else host_mismatch_sensitivity_table()
    if df.empty:
        raise ValueError("sensitivity table is empty")

    pivot = df.pivot_table(
        index="bh_mass_log10_msun",
        columns="host_mass_scale",
        values="bh_to_host_ratio_log10",
        aggfunc="mean",
    ).sort_index().sort_index(axis=1)

    arr = pivot.to_numpy(dtype=float)
    fig, ax = plt.subplots(figsize=(7.6, 4.8))
    im = ax.imshow(arr, aspect="auto", cmap="viridis")
    ax.set_yticks(range(len(pivot.index)))
    ax.set_yticklabels([f"{v:.2f}" for v in pivot.index])
    ax.set_xticks(range(len(pivot.columns)))
    ax.set_xticklabels([f"{v:.2f}" for v in pivot.columns], rotation=35)
    ax.set_ylabel("BH mass log10(Msun)")
    ax.set_xlabel("Host-mass scale factor")
    ax.set_title("Host-mismatch caveat sensitivity (log10(MBH/Mhost))")
    cbar = fig.colorbar(im, ax=ax)
    cbar.set_label("log10(MBH/Mhost)")

    out = _resolve_output_path(output_filename, "host_mismatch_caveat_sensitivity.png")
    fig.tight_layout()
    fig.savefig(out, dpi=220)
    plt.close(fig)
    return {"path": str(out)}


def package_smoke_test() -> dict:
    claims = paper_claim_parameter_set()
    ratio = bh_host_ratio_summary(
        bh_mass_log10_msun=claims["bh_mass_log10_msun"],
        host_mass_1e9_msun=claims["host_mass_1e9_msun"],
        host_mass_plus_1e9_msun=claims["host_mass_plus_1e9_msun"],
        host_mass_minus_1e9_msun=claims["host_mass_minus_1e9_msun"],
    )
    growth = growth_shortfall_table(
        lambda_values=[claims["lambda_edd_reference"]],
        z_start_values=[15.0, 20.0, 25.0],
        z_end=claims["zspec"],
    )
    sens = host_mismatch_sensitivity_table(
        host_mass_1e9_msun=claims["host_mass_1e9_msun"],
        host_mass_plus_1e9_msun=claims["host_mass_plus_1e9_msun"],
        host_mass_minus_1e9_msun=claims["host_mass_minus_1e9_msun"],
        bh_mass_log10_center=claims["bh_mass_log10_msun"],
    )
    growth_scenarios = {
        f"z{z_start}_to_z{claims['zspec']:.4f}": cosmic_time_interval_gyr(z_start=z_start, z_end=claims["zspec"])
        for z_start in [15.0, 20.0, 25.0]
    }
    return {
        "source_inventory": source_inventory(),
        "reference_paper_manifest": reference_paper_manifest(),
        "claim_anchor": claims,
        "ratio_summary": {
            "bh_to_host_ratio_central": ratio["bh_to_host_ratio_central"],
            "ratio_span_factor": ratio["ratio_span_factor"],
        },
        "growth_table_shape": [int(growth.shape[0]), int(growth.shape[1])],
        "growth_time_reference_scenarios_gyr": growth_scenarios,
        "sensitivity_table_shape": [int(sens.shape[0]), int(sens.shape[1])],
    }

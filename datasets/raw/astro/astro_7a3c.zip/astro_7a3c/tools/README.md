# Tools

This directory follows the three-layer task-tool structure.

- `data_processing.py`: file discovery, workbook ingestion, archive inspection, numeric coercion, robust z-scoring, and tidy-table helpers.
- `database_retrieval.py`: local inventory, article-link extraction, and public repository discovery.
- `astro_tools.py`: domain-specific primitives for inspecting bundled astronomy supplementary materials and producing local sanity-check summaries.

The bundled data are supplementary files and public-link/context materials, not a complete external-deposit mirror for full paper-figure reproduction or expensive retraining/reanalysis. The tools intentionally expose reusable context and sanity-check primitives; final scientific claims in `task_content.json` should be checked against `input_data/reference_paper/target.pdf`.

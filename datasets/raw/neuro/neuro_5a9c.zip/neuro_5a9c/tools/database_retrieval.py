from __future__ import annotations

from pathlib import Path
import subprocess

try:
    from .data_processing import list_files
except ImportError:
    from data_processing import list_files


def local_code_inventory(data_root: str) -> dict:
    """Inventory released analysis code, including Python scripts in code_bundle."""
    code_suffixes = {".py", ".ipynb", ".m", ".r", ".R", ".cpp", ".h", ".rtf", ".zip"}
    files = list_files(data_root)
    code_files = list_files(data_root, suffixes=code_suffixes)
    return {
        "root": str(Path(data_root).resolve()),
        "files": files,
        "code_files": code_files,
        "python_files": [f for f in code_files if Path(f).suffix.lower() == ".py"],
        "n_code_files": len(code_files),
    }


def reference_inventory(reference_root: str) -> dict:
    return {
        "root": str(Path(reference_root).resolve()),
        "files": list_files(reference_root, suffixes={".pdf", ".html"}),
    }


def extract_pdf_text(path: str) -> dict:
    """Best-effort PDF text extraction without making pdftotext a hard dependency."""
    try:
        result = subprocess.run(["pdftotext", path, "-"], capture_output=True, text=True, check=True)
        return {"path": path, "text": result.stdout, "method": "pdftotext"}
    except (FileNotFoundError, subprocess.CalledProcessError) as exc:
        return {"path": path, "text": "", "method": "unavailable", "warning": str(exc)}


def find_pdf_lines(path: str, patterns: list[str]) -> dict:
    text = extract_pdf_text(path)["text"]
    matches = []
    for i, line in enumerate(text.splitlines(), start=1):
        lower = line.lower()
        for pattern in patterns:
            if pattern.lower() in lower:
                matches.append({"line_number": i, "pattern": pattern, "line": line.strip()})
                break
    return {"path": path, "patterns": patterns, "matches": matches}

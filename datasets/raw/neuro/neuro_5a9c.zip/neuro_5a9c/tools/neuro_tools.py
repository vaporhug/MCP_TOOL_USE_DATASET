from __future__ import annotations

from pathlib import Path
import zipfile
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


STABLE_CSV_NAME = "place_cell_transitions/stable_unstable_classification.csv"
BEHAVIOR_CSV_NAME = "vr_behavior/behavior.csv"
GROUP_CSV_NAME = "experimental_groups/animal_groups.csv"
PERIOD_ORDER = ["pre", "early", "late"]
PERIOD_LABELS = {"pre": "Healthy", "early": "Early post", "late": "Late post"}


def _read_csv_from_bundle(path: str, member_suffix: str) -> pd.DataFrame:
    p = Path(path)
    if p.is_dir():
        matches = list(p.rglob(Path(member_suffix).name))
        matches = [m for m in matches if str(m).replace("\\", "/").endswith(member_suffix)]
        if not matches:
            suffix = member_suffix.lower()
            matches = [m for m in p.rglob("*") if m.is_file() and str(m).replace("\\", "/").lower().endswith(suffix)]
        if not matches:
            raise FileNotFoundError(f"No {member_suffix} found under {p}")
        return pd.read_csv(matches[0])
    if p.suffix.lower() == ".zip":
        with zipfile.ZipFile(p) as zf:
            matches = [name for name in zf.namelist() if name.endswith(member_suffix)]
            if not matches:
                suffix = member_suffix.lower()
                matches = [name for name in zf.namelist() if name.lower().endswith(suffix)]
            if not matches:
                raise FileNotFoundError(f"No {member_suffix} found in {p}")
            with zf.open(matches[0]) as handle:
                return pd.read_csv(handle)
    return pd.read_csv(p)


def _panel_bounds(raw: pd.DataFrame, panel_label: str) -> tuple[int, int]:
    labels = raw.astype(str).apply(lambda c: c.str.strip())
    matches = raw.where(labels.eq(panel_label)).stack()
    if matches.empty:
        raise ValueError(f"{panel_label} header not found")
    start = int(matches.index[0][0])
    later = []
    for idx, row in raw.iloc[start + 1:].iterrows():
        first = str(row.iloc[0]).strip()
        if first.startswith("Panel "):
            later.append(int(idx))
    end = later[0] if later else raw.shape[0]
    return start, end


def _figure1_panel_f(source_xlsx: str) -> pd.DataFrame:
    source_xlsx = str(_resolve_source_xlsx(source_xlsx))
    df = pd.read_excel(source_xlsx, sheet_name="Figure 1", header=None)
    start, end = _panel_bounds(df, "Panel F")
    header_row = start + 1
    headers = [_canonical_column_label(df.iat[header_row, c]) for c in range(df.shape[1])]
    wanted = {
        "estimated_number_of_microspheres": "microspheres",
        "estimated_number_of_microspheres_in_brain": "microspheres",
        "healthy": "healthy",
        "early_post": "early_post",
        "late_post": "late_post",
    }
    indices = []
    columns = []
    for idx, key in enumerate(headers):
        if key in wanted:
            indices.append(idx)
            columns.append(wanted[key])
    if set(columns) != set(wanted.values()):
        raise ValueError(f"Figure 1 Panel F schema not recognized: {headers}")
    vals = df.iloc[header_row + 1:end, indices].copy()
    vals.columns = columns
    for col in vals.columns:
        vals[col] = pd.to_numeric(vals[col], errors="coerce")
    return vals.dropna(subset=["microspheres", "early_post"])


def _canonical_column_label(value) -> str:
    text = str(value).strip().lower().replace("-", " ")
    text = "_".join(text.split())
    text = text.replace("[bits]", "").replace("[", "").replace("]", "")
    return text


def _default_source_from_bundle(path: str) -> Path | None:
    p = Path(path)
    candidates = [
        p / "data" / "source_data.xlsx" if p.is_dir() else p.parent / "source_data.xlsx",
        p / "input_data" / "data" / "source_data.xlsx" if p.is_dir() else p.parent / "source_data.xlsx",
        p.parent / "source_data.xlsx",
        p.parents[1] / "source_data.xlsx" if len(p.parents) > 1 else p.parent / "source_data.xlsx",
        Path(__file__).resolve().parents[1] / "input_data" / "data" / "source_data.xlsx",
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    return None


def _resolve_source_xlsx(path: str) -> Path:
    p = Path(path)
    if p.is_file():
        return p
    source = _default_source_from_bundle(path)
    if source and source.exists():
        return source
    matches = list(p.rglob("source_data.xlsx")) if p.is_dir() else []
    if matches:
        return matches[0]
    raise FileNotFoundError(f"source_data.xlsx not found from {path}")


def _canonical_group(name: str) -> str:
    text = str(name).strip().replace("_", "-")
    low = text.lower().replace(" ", "-")
    if low in {"control", "sham"}:
        return "Sham"
    if low in {"no-recovery", "norecovery", "no-recover", "no-recovery-group"}:
        return "No-Recovery"
    if low in {"recovery", "recover"}:
        return "Recovery"
    return text


def _period_key(value) -> str | None:
    text = str(value).strip().lower()
    if text in {"pre", "healthy"}:
        return "pre"
    if text in {"early", "early post", "early_post"}:
        return "early"
    if text in {"late", "late post", "late_post"}:
        return "late"
    return None


def _figure3_panel_b_stable_groups(source_xlsx: str) -> list[dict]:
    """Parse Figure 3 Panel B by labels instead of fixed column indices."""
    source_xlsx = str(_resolve_source_xlsx(source_xlsx))
    raw = pd.read_excel(source_xlsx, sheet_name="Figure 3", header=None)
    start, end = _panel_bounds(raw, "Panel B")
    candidate_rows = [start, start + 1]
    group_label_row = None
    for row in candidate_rows:
        labels = [_canonical_group(raw.iat[row, col]) for col in range(raw.shape[1])]
        if any(label in {"Sham", "Recovery", "No-Recovery"} for label in labels):
            group_label_row = row
            break
    if group_label_row is None:
        raise ValueError("Figure 3 Panel B group labels not found")
    group_labels = raw.iloc[group_label_row, :].ffill()
    period_rows = {}
    for row in range(group_label_row + 1, end):
        key = _period_key(raw.iat[row, 0])
        if key:
            period_rows[key] = row
    if set(period_rows) != set(PERIOD_ORDER):
        raise ValueError(f"Figure 3 Panel B period rows not recognized: {period_rows}")
    records = []
    for col in range(raw.shape[1]):
        group = _canonical_group(group_labels.iloc[col])
        if group.lower() in {"nan", "", "panel b"}:
            continue
        values = {
            period: pd.to_numeric(pd.Series([raw.iat[row, col]]), errors="coerce").iloc[0]
            for period, row in period_rows.items()
            if row < end
        }
        if all(pd.notna(v) for v in values.values()) and len(values) == 3:
            records.append({"source_column": int(col), "group": group, **{k: float(v) for k, v in values.items()}})
    return records


def stability_group_mapping(source_xlsx: str, stable_csv_or_bundle: str) -> dict:
    source_xlsx = str(_resolve_source_xlsx(source_xlsx))
    stable = _read_csv_from_bundle(stable_csv_or_bundle, STABLE_CSV_NAME)
    for col in ["n3_r"]:
        stable[col] = pd.to_numeric(stable[col], errors="coerce")

    groups = _read_csv_from_bundle(stable_csv_or_bundle, GROUP_CSV_NAME)
    groups["mouse_id"] = groups["mouse_id"].astype(int).astype(str)
    groups["group"] = groups["fine"].map(_canonical_group)
    assignments = {}
    group_lookup = dict(zip(groups["mouse_id"], groups["group"]))
    for mouse_id, sub in stable.dropna(subset=["mouse_id"]).groupby("mouse_id"):
        mouse_key = str(mouse_id).split("_")[0]
        if mouse_key in group_lookup:
            assignments[str(mouse_id)] = {"group": group_lookup[mouse_key], "source": GROUP_CSV_NAME}

    panel_consistency = []
    try:
        panel = _figure3_panel_b_stable_groups(source_xlsx)
        for group in ["Sham", "Recovery", "No-Recovery"]:
            panel_records = [r for r in panel if r["group"] == group]
            assigned_mice = [mouse for mouse, item in assignments.items() if item["group"] == group]
            for period in PERIOD_ORDER:
                stable_mean = float(stable[(stable["mouse_id"].astype(str).isin(assigned_mice)) & (stable["period"] == period)]["n3_r"].mean())
                panel_vals = [r[period] for r in panel_records]
                panel_mean = float(np.mean(panel_vals)) if panel_vals else float("nan")
                panel_consistency.append({
                    "group": group,
                    "period": period,
                    "animal_groups_mean": stable_mean,
                    "panel_b_mean": panel_mean,
                    "abs_difference": float(abs(stable_mean - panel_mean)) if np.isfinite(panel_mean) else float("nan"),
                })
    except Exception as exc:
        panel_consistency = [{"warning": str(exc)}]

    return {
        "source": GROUP_CSV_NAME,
        "mapping_method": "experimental_groups/animal_groups.csv by mouse_id",
        "matched_mice": len(assignments),
        "panel_b_consistency_check": panel_consistency,
        "assignments": assignments,
    }


def microsphere_performance_summary(source_xlsx: str) -> dict:
    source_xlsx = str(_resolve_source_xlsx(source_xlsx))
    vals = _figure1_panel_f(source_xlsx)
    corr = np.corrcoef(vals["microspheres"].astype(float), vals["early_post"].astype(float))[0, 1]
    return {
        "rows": int(len(vals)),
        "microsphere_task_corr_early_post": float(corr),
        "median_microspheres": float(vals["microspheres"].median()),
        "early_post_mean": float(vals["early_post"].mean()),
        "late_post_mean": float(vals["late_post"].dropna().mean()),
    }


def place_cell_stability_summary(stable_csv_or_bundle: str, source_xlsx: str | None = None) -> dict:
    df = _read_csv_from_bundle(stable_csv_or_bundle, STABLE_CSV_NAME)
    for col in ["n1_r", "n2_r", "n3_r", "baseline_stability"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    grouped = df.groupby("period")[["n1_r", "n2_r", "n3_r", "baseline_stability"]].mean()
    grouped = grouped.reindex([p for p in PERIOD_ORDER if p in grouped.index])
    result = {
        "rows": int(len(df)),
        "periods": list(grouped.index),
        "class_labels": {
            "n1_r": "non-coding tracked cells",
            "n2_r": "unstable place cells",
            "n3_r": "stable place cells",
        },
        "class_fraction_means": {
            str(period): {
                "noncoding_n1_percent": float(row["n1_r"]),
                "unstable_place_cell_n2_percent": float(row["n2_r"]),
                "stable_place_cell_n3_percent": float(row["n3_r"]),
                "baseline_stability": float(row["baseline_stability"]),
            }
            for period, row in grouped.iterrows()
        },
    }
    source = Path(source_xlsx) if source_xlsx else _default_source_from_bundle(stable_csv_or_bundle)
    if source and source.exists():
        mapping = stability_group_mapping(str(source), stable_csv_or_bundle)
        df = df.copy()
        df["mouse_id"] = df["mouse_id"].astype(str)
        df["group"] = df["mouse_id"].map({mouse: item["group"] for mouse, item in mapping["assignments"].items()})
        group_df = df.dropna(subset=["group"]).groupby(["group", "period"])["n3_r"].agg(["mean", "count", "std"]).reset_index()
        group_df["sem"] = group_df["std"] / np.sqrt(group_df["count"].clip(lower=1))
        result["group_mapping"] = mapping
        result["stable_place_cell_by_group"] = {
            group: {
                period: {
                    "mean_n3_r": float(group_df[(group_df["group"] == group) & (group_df["period"] == period)]["mean"].iloc[0]),
                    "n": int(group_df[(group_df["group"] == group) & (group_df["period"] == period)]["count"].iloc[0]),
                    "sem": float(group_df[(group_df["group"] == group) & (group_df["period"] == period)]["sem"].iloc[0]),
                }
                for period in PERIOD_ORDER
                if not group_df[(group_df["group"] == group) & (group_df["period"] == period)].empty
            }
            for group in sorted(group_df["group"].unique())
        }
    return result


def behavior_trace_summary(code_bundle: str) -> dict:
    df = _read_csv_from_bundle(code_bundle, BEHAVIOR_CSV_NAME)
    return {
        "rows": int(len(df)),
        "trials": int(df["trial_nb"].nunique()) if "trial_nb" in df else None,
        "duration_seconds": float(pd.to_numeric(df["time"], errors="coerce").max()) if "time" in df else None,
        "mean_speed": float(pd.to_numeric(df["speed"], errors="coerce").mean()) if "speed" in df else None,
    }


def _figure3_panel_a_recovery(source_xlsx: str) -> pd.DataFrame:
    source_xlsx = str(_resolve_source_xlsx(source_xlsx))
    raw = pd.read_excel(source_xlsx, sheet_name="Figure 3", header=None)
    start, end = _panel_bounds(raw, "Panel A")
    label_row = start + 1
    group_labels = raw.iloc[label_row, :].ffill()
    day_col = 0
    for col in range(raw.shape[1]):
        label = str(raw.iat[label_row, col]).strip().lower()
        if "day" in label or label in {"d", "time"}:
            day_col = col
            break
    records = []
    for col in range(raw.shape[1]):
        group = _canonical_group(group_labels.iloc[col])
        if group.lower() in {"nan", "", "panel a"} or col == day_col or "day" in group.lower():
            continue
        for row in range(label_row + 1, end):
            day = pd.to_numeric(pd.Series([raw.iat[row, day_col]]), errors="coerce").iloc[0]
            val = pd.to_numeric(pd.Series([raw.iat[row, col]]), errors="coerce").iloc[0]
            if pd.notna(day) and pd.notna(val):
                records.append({"days": float(day), "group": group, "performance": float(val), "source_column": int(col)})
    return pd.DataFrame(records)


def recovery_group_summary(source_xlsx: str) -> dict:
    source_xlsx = str(_resolve_source_xlsx(source_xlsx))
    vals = _figure3_panel_a_recovery(source_xlsx)
    stats = vals.groupby("group")["performance"].agg(["mean", "count", "std"]).reset_index()
    stats["sem"] = stats["std"] / np.sqrt(stats["count"].clip(lower=1))
    return {
        "days": int(vals["days"].nunique()) if not vals.empty else 0,
        "groups": sorted(vals["group"].unique()) if not vals.empty else [],
        "group_stats": {
            str(row["group"]): {
                "mean": float(row["mean"]),
                "n_observations": int(row["count"]),
                "sem": float(row["sem"]),
            }
            for _, row in stats.iterrows()
        },
    }


def plot_microsphere_vs_performance(source_xlsx: str, output_path: str) -> dict:
    source_xlsx = str(_resolve_source_xlsx(source_xlsx))
    vals = _figure1_panel_f(source_xlsx)
    plt.figure(figsize=(5, 4))
    plt.scatter(vals["microspheres"], vals["early_post"], s=25, color="#4C78A8")
    plt.xlabel("Estimated microspheres")
    plt.ylabel("Early post-stroke task performance")
    plt.title("Microsphere burden versus early post-stroke behavior")
    plt.tight_layout()
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output_path, dpi=200)
    plt.close()
    return {"path": output_path, "summary": microsphere_performance_summary(source_xlsx)}


def plot_recovery_groups(source_xlsx: str, output_path: str) -> dict:
    source_xlsx = str(_resolve_source_xlsx(source_xlsx))
    vals = _figure3_panel_a_recovery(source_xlsx)
    plt.figure(figsize=(6, 4))
    for group in ["No-Recovery", "Recovery", "Sham"]:
        sub = vals[vals["group"] == group].groupby("days")["performance"].agg(["mean", "count", "std"]).reset_index().sort_values("days")
        if not sub.empty:
            sem = sub["std"].fillna(0) / np.sqrt(sub["count"].clip(lower=1))
            plt.errorbar(sub["days"], sub["mean"], yerr=sem, marker="o", capsize=2, label=f"{group} (n={int(sub['count'].max())})")
    plt.xlabel("Days after stroke")
    plt.ylabel("Task performance")
    plt.legend()
    plt.tight_layout()
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output_path, dpi=200)
    plt.close()
    return {"path": output_path, "summary": recovery_group_summary(source_xlsx)}
# Strict reproduction additions: place-cell stability artifact and smoke test.
def plot_place_cell_stability(stable_csv_or_bundle: str, output_path: str, source_xlsx: str | None = None) -> dict:
    df = _read_csv_from_bundle(stable_csv_or_bundle, STABLE_CSV_NAME)
    for col in ["n1_r", "n2_r", "n3_r"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    source = Path(source_xlsx) if source_xlsx else _default_source_from_bundle(stable_csv_or_bundle)
    plt.figure(figsize=(6.8, 4.2))
    if not (source and source.exists()):
        raise FileNotFoundError("source_data.xlsx is required to map stable place-cell rows to recovery groups")
    mapping = stability_group_mapping(str(source), stable_csv_or_bundle)
    if mapping["matched_mice"] == 0:
        raise ValueError("no mice could be matched to experimental_groups/animal_groups.csv")
    df = df.copy()
    df["mouse_id"] = df["mouse_id"].astype(str)
    df["group"] = df["mouse_id"].map({mouse: item["group"] for mouse, item in mapping["assignments"].items()})
    grouped = df.dropna(subset=["group"]).groupby(["group", "period"])["n3_r"].agg(["mean", "count", "std"]).reset_index()
    grouped["sem"] = grouped["std"] / np.sqrt(grouped["count"].clip(lower=1))
    for group in ["Sham", "Recovery", "No-Recovery"]:
        sub = grouped[grouped["group"] == group]
        y = [float(sub[sub["period"] == period]["mean"].iloc[0]) if not sub[sub["period"] == period].empty else float("nan") for period in PERIOD_ORDER]
        err = [float(sub[sub["period"] == period]["sem"].iloc[0]) if not sub[sub["period"] == period].empty else 0.0 for period in PERIOD_ORDER]
        nmax = int(sub["count"].max()) if not sub.empty else 0
        plt.errorbar([PERIOD_LABELS[p] for p in PERIOD_ORDER], y, yerr=err, marker="o", capsize=2, label=f"{group} (n={nmax})")
    plt.xlabel("Experimental period")
    plt.ylabel("Stable place-cell fraction (%)")
    plt.title("Stable place-cell fractions by recovery group")
    plt.legend(frameon=False)
    plt.tight_layout()
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out, dpi=200)
    plt.close()
    return {"path": str(out), "summary": place_cell_stability_summary(stable_csv_or_bundle, str(source) if source else None)}

def package_smoke_test() -> dict:
    root = Path(__file__).resolve().parents[1]
    source = root / "input_data" / "data" / "source_data.xlsx"
    code = root / "input_data" / "data" / "code_bundle" / "Wahl-lab-Heiser_BrainwideMicrostrokes-2bc9f98"
    art = root / "artifacts"
    return {
        "microspheres": microsphere_performance_summary(str(source)),
        "place_cell_stability": place_cell_stability_summary(str(code), str(source)),
        "behavior_trace": behavior_trace_summary(str(code)),
        "recovery": recovery_group_summary(str(source)),
        "figures": [plot_microsphere_vs_performance(str(source), str(art / "microsphere_vs_performance.png")), plot_recovery_groups(str(source), str(art / "recovery_group_trajectories.png")), plot_place_cell_stability(str(code), str(art / "place_cell_stability.png"), str(source))],
    }

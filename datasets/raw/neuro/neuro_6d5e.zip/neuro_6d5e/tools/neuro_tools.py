from __future__ import annotations

from pathlib import Path
import io
import re
import zipfile

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import scipy.io as sio

try:
    from .data_processing import data_root, list_files
    from .database_retrieval import public_repository_links
except ImportError:
    from data_processing import data_root, list_files
    from database_retrieval import public_repository_links


ARTIFACT_DIR = Path(__file__).resolve().parents[1] / "artifacts"
ARTIFACT_DIR.mkdir(exist_ok=True)


def _resolve_output_path(output_filename: str | None, generic_name: str) -> Path:
    filename = output_filename if output_filename else generic_name
    return ARTIFACT_DIR / filename


REQUIRED_MEMBERS = {
    "area_label": "area_label.mat",
    "figure1f": "Figure1f.mat",
    "figure1i": "Figure1i.mat",
    "figure2d": "Figure2D.mat",
    "figure2f": "Figure2F.mat",
}

MEMBER_ALIASES = {
    "area_label": ("area_label.mat", "arealabel.mat"),
    "figure1f": ("figure1f.mat", "figure_1f.mat"),
    "figure1i": ("figure1i.mat", "figure_1i.mat"),
    "figure2d": ("figure2d.mat", "figure_2d.mat"),
    "figure2f": ("figure2f.mat", "figure_2f.mat"),
}

MAT_VAR_ALIASES = {
    "area_label": ("area_label", "arealabel"),
    "Dlocal": ("Dlocal", "dlocal"),
    "Dshared": ("Dshared", "dshared"),
    "mdl_perf": ("mdl_perf", "mdlperf"),
    "x": ("x",),
    "ci": ("ci", "confidence_interval"),
    "behav_rho": ("behav_rho", "beha_rho", "rho_behav"),
}


def source_inventory() -> dict:
    files = list_files(data_root())
    return {
        "n_files": len(files),
        "extensions": sorted({Path(f).suffix.lower() for f in files}),
        "repositories": public_repository_links().get("repositories", []),
    }


def _norm_name(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", str(value).lower())


def _archive() -> Path:
    zips = [Path(f) for f in list_files(data_root()) if Path(f).suffix.lower() == ".zip"]
    if not zips:
        raise FileNotFoundError("missing MOESM4 MAT archive for neuro_6d5e")
    preferred = [z for z in zips if "MOESM4" in z.name.upper()]
    return preferred[0] if preferred else zips[0]


def _archive_members() -> list[str]:
    z = _archive()
    with zipfile.ZipFile(z) as zz:
        return sorted(zz.namelist())


def _resolved_member_map() -> dict[str, str]:
    members = _archive_members()
    norm_to_member = {_norm_name(m): m for m in members}
    out = {}
    for key, name in REQUIRED_MEMBERS.items():
        alias_candidates = [name] + list(MEMBER_ALIASES.get(key, ()))
        resolved = None
        for cand in alias_candidates:
            if cand in members:
                resolved = cand
                break
            norm = _norm_name(cand)
            if norm in norm_to_member:
                resolved = norm_to_member[norm]
                break
        if resolved is None:
            # Last-resort fuzzy containment for minor naming drift.
            target = _norm_name(name).replace("mat", "")
            fuzzy = [m for m in members if target in _norm_name(m)]
            if fuzzy:
                resolved = sorted(fuzzy)[0]
        if resolved is None:
            raise FileNotFoundError(f"required archive member missing: {name}")
        out[key] = resolved
    return out


def _load_mat(member_key: str) -> dict:
    member = _resolved_member_map()[member_key]
    z = _archive()
    with zipfile.ZipFile(z) as zz:
        blob = zz.read(member)
    return sio.loadmat(io.BytesIO(blob))


def _mat_value(mat: dict, canonical_name: str):
    candidates = MAT_VAR_ALIASES.get(canonical_name, (canonical_name,))
    norm_lookup = {_norm_name(k): k for k in mat.keys() if not str(k).startswith("__")}
    for cand in candidates:
        norm = _norm_name(cand)
        if norm in norm_lookup:
            return mat[norm_lookup[norm]]
    for cand in candidates:
        norm = _norm_name(cand)
        for key in norm_lookup:
            if norm in key:
                return mat[norm_lookup[key]]
    return None


def _numeric_mat_array(mat: dict, canonical_name: str) -> np.ndarray:
    value = _mat_value(mat, canonical_name)
    if value is None:
        return np.array([], dtype=float)
    return np.asarray(value, dtype=float)


def mat_array(member_key: str, canonical_name: str) -> np.ndarray:
    """Load one numeric MAT variable using member/variable aliases."""
    return _numeric_mat_array(_load_mat(member_key), canonical_name)


def finite_vector(array: np.ndarray) -> np.ndarray:
    vec = np.asarray(array, dtype=float).reshape(-1)
    return vec[np.isfinite(vec)]


def summarize_numeric_array(array: np.ndarray, label: str = "array") -> dict:
    vec = finite_vector(array)
    if vec.size == 0:
        return {"label": label, "count": 0}
    return {
        "label": label,
        "count": int(vec.size),
        "mean": float(np.mean(vec)),
        "median": float(np.median(vec)),
        "q10": float(np.quantile(vec, 0.1)),
        "q90": float(np.quantile(vec, 0.9)),
    }


def _plot_histogram(values: np.ndarray, bins: int, xlabel: str, title: str, output_filename: str | None, generic_name: str) -> dict:
    vec = finite_vector(values)
    if vec.size == 0:
        raise ValueError("no finite values to plot")
    fig, ax = plt.subplots(figsize=(7.2, 4.6))
    ax.hist(vec, bins=bins)
    ax.set_xlabel(xlabel)
    ax.set_ylabel("Count")
    ax.set_title(title)
    ax.grid(axis="y", alpha=0.25)
    out = _resolve_output_path(output_filename, generic_name)
    fig.tight_layout()
    fig.savefig(out, dpi=220)
    plt.close(fig)
    return {"path": str(out)}


def _plot_box_by_dimension(matrix: np.ndarray, xlabel: str, ylabel: str, title: str, output_filename: str | None, generic_name: str) -> dict:
    arr = np.asarray(matrix, dtype=float)
    if arr.ndim == 1:
        arr = arr.reshape(-1, 1)
    data = [arr[:, i][np.isfinite(arr[:, i])] for i in range(arr.shape[1])]
    labels = [f"dim{i + 1}" for i in range(arr.shape[1])]
    fig, ax = plt.subplots(figsize=(9.0, 4.8))
    ax.boxplot(data, labels=labels, patch_artist=True)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.grid(axis="y", alpha=0.25)
    out = _resolve_output_path(output_filename, generic_name)
    fig.tight_layout()
    fig.savefig(out, dpi=220)
    plt.close(fig)
    return {"path": str(out)}


def archive_manifest() -> dict:
    members = _archive_members()
    mats = [n for n in members if n.lower().endswith(".mat")]
    required_presence = {k: (name in members) for k, name in REQUIRED_MEMBERS.items()}
    return {
        "archive": _archive().name,
        "n_entries": len(members),
        "n_mat_files": len(mats),
        "mat_files": mats,
        "required_member_presence": required_presence,
    }


def mat_variable_manifest(member_key: str) -> dict:
    mat = _load_mat(member_key)
    rows = []
    for k, v in mat.items():
        if k.startswith("__"):
            continue
        arr = np.asarray(v)
        rows.append({"name": k, "shape": list(arr.shape), "dtype": str(arr.dtype)})
    return {"member_key": member_key, "member": REQUIRED_MEMBERS[member_key], "variables": rows}


def area_label_summary() -> dict:
    mat = _load_mat("area_label")
    labels = _mat_value(mat, "area_label")
    if labels is None:
        return {"error": "area_label variable missing"}
    area_names = []
    for x in np.asarray(labels).reshape(-1):
        if isinstance(x, np.ndarray):
            flat = x.reshape(-1)
            area_names.append(str(flat[0]) if flat.size else "")
        else:
            area_names.append(str(x))
    return {"n_areas": len(area_names), "areas": area_names}


def _validated_figure1i_arrays() -> tuple[np.ndarray, np.ndarray]:
    mat = _load_mat("figure1i")
    d_local = _numeric_mat_array(mat, "Dlocal")
    d_shared = _numeric_mat_array(mat, "Dshared")
    if d_local.size == 0 or d_shared.size == 0:
        raise ValueError("Figure1i Dlocal or Dshared missing")
    if d_local.shape != d_shared.shape:
        raise ValueError(f"Figure1i shape mismatch: Dlocal{d_local.shape} vs Dshared{d_shared.shape}")
    if d_local.ndim != 3:
        raise ValueError(f"Figure1i expected 3D arrays, got ndim={d_local.ndim}")
    return d_local, d_shared


def figure1_shared_local_dimensionality_summary() -> dict:
    d_local, d_shared = _validated_figure1i_arrays()
    ratio = np.divide(d_local, d_shared, out=np.full_like(d_local, np.nan), where=d_shared != 0)
    return {
        "shape": list(d_local.shape),
        "local_mean": float(np.nanmean(d_local)),
        "shared_mean": float(np.nanmean(d_shared)),
        "local_to_shared_mean_ratio": float(np.nanmean(ratio)),
        "local_q10_q90": [float(np.nanquantile(d_local, 0.1)), float(np.nanquantile(d_local, 0.9))],
        "shared_q10_q90": [float(np.nanquantile(d_shared, 0.1)), float(np.nanquantile(d_shared, 0.9))],
    }


def figure1_model_performance_summary() -> dict:
    mdl_perf = mat_array("figure1f", "mdl_perf")
    if mdl_perf.size == 0:
        return {"error": "Figure1f mdl_perf missing"}
    if mdl_perf.ndim != 3:
        return {"error": f"Figure1f expected 3D mdl_perf, got shape {list(mdl_perf.shape)}"}
    return {
        "shape": list(mdl_perf.shape),
        "mean_explainable_variance_fraction": float(np.nanmean(mdl_perf)),
        "median_explainable_variance_fraction": float(np.nanmedian(mdl_perf)),
        "q10_q90": [float(np.nanquantile(mdl_perf, 0.1)), float(np.nanquantile(mdl_perf, 0.9))],
    }


def figure2_dimension_integration_auc_summary() -> dict:
    x = mat_array("figure2d", "x")
    ci = mat_array("figure2d", "ci")
    if x.size == 0:
        return {"error": "Figure2D x missing"}
    per_dim_mean = np.nanmean(x, axis=0) if x.ndim > 1 else x
    return {
        "x_shape": list(x.shape),
        "mean_auc_across_regions": float(np.nanmean(x)),
        "mean_auc_by_dimension": [float(v) for v in np.atleast_1d(per_dim_mean)],
        "ci_shape": list(ci.shape),
    }


def figure2f_schema_manifest() -> dict:
    rho = mat_array("figure2f", "behav_rho")
    if rho.size == 0:
        return {"error": "Figure2F behav_rho missing"}
    return {
        "member": REQUIRED_MEMBERS["figure2f"],
        "variable": "behav_rho",
        "shape": list(rho.shape),
        "dtype": str(rho.dtype),
        "n_rows": int(rho.shape[0]) if rho.ndim >= 1 else int(rho.size),
        "n_dimensions": int(rho.shape[1]) if rho.ndim >= 2 else 1,
    }


def figure2_behavior_correlation_summary() -> dict:
    rho = mat_array("figure2f", "behav_rho")
    if rho.size == 0:
        return {"error": "behav_rho missing"}
    if rho.ndim == 1:
        rho = rho.reshape(-1, 1)
    col_means = np.nanmean(rho, axis=0)
    col_medians = np.nanmedian(rho, axis=0)
    return {
        "shape": list(rho.shape),
        "global_mean_rho": float(np.nanmean(rho)),
        "global_median_rho": float(np.nanmedian(rho)),
        "mean_rho_by_dimension": [float(v) for v in col_means],
        "median_rho_by_dimension": [float(v) for v in col_medians],
    }


def plot_fig1_local_shared_dimensionality(output_filename: str | None = None) -> dict:
    d_local, d_shared = _validated_figure1i_arrays()
    local_mean = np.nanmean(d_local, axis=(0, 1))
    shared_mean = np.nanmean(d_shared, axis=(0, 1))

    x = np.arange(local_mean.size)
    width = 0.38
    fig, ax = plt.subplots(figsize=(8.4, 4.8))
    ax.bar(x - width / 2, local_mean, width=width, label="Local dimensions")
    ax.bar(x + width / 2, shared_mean, width=width, label="Shared dimensions")
    ax.set_xlabel("Recorded area index")
    ax.set_ylabel("Mean dimensionality")
    ax.set_title("Figure 1i source-data local vs shared dimensionality")
    ax.grid(axis="y", alpha=0.25)
    ax.legend(frameon=False)

    out = _resolve_output_path(output_filename, "fig1_local_shared_dimensionality.png")
    fig.tight_layout()
    fig.savefig(out, dpi=220)
    plt.close(fig)
    return {"path": str(out)}


def plot_fig2_behavior_rho_distribution(output_filename: str | None = None) -> dict:
    rho = mat_array("figure2f", "behav_rho")
    if rho.size == 0:
        raise ValueError("Figure2F behav_rho missing")
    return _plot_box_by_dimension(
        matrix=rho,
        xlabel="Subspace dimension index",
        ylabel="Behavior correlation (rho)",
        title="Figure 2F source-data behavior-correlation distribution",
        output_filename=output_filename,
        generic_name="fig2_behavior_rho_distribution.png",
    )


def plot_fig1_model_performance_distribution(output_filename: str | None = None) -> dict:
    mdl = mat_array("figure1f", "mdl_perf")
    if mdl.size == 0:
        raise ValueError("Figure1f mdl_perf values missing")
    return _plot_histogram(
        values=mdl,
        bins=35,
        xlabel="Explainable variance fraction",
        title="Figure 1f source-data model-performance distribution",
        output_filename=output_filename,
        generic_name="fig1_model_performance_distribution.png",
    )


def package_smoke_test() -> dict:
    member_map = _resolved_member_map()
    rho = mat_array("figure2f", "behav_rho")
    mdl = mat_array("figure1f", "mdl_perf")
    return {
        "source_inventory": source_inventory(),
        "archive_manifest": archive_manifest(),
        "resolved_members": member_map,
        "figure1i_schema": mat_variable_manifest("figure1i"),
        "figure2f_schema": mat_variable_manifest("figure2f"),
        "area_count": int(area_label_summary().get("n_areas", 0)),
        "array_summaries": {
            "figure1f_mdl_perf": summarize_numeric_array(mdl, "figure1f_mdl_perf"),
            "figure2f_behav_rho": summarize_numeric_array(rho, "figure2f_behav_rho"),
        },
    }

# neuro_6d5e Evidence Report

## Scope
This report is limited to released Figure 1/2 source arrays in MOESM4 (`Figure1i.mat`, `Figure1f.mat`, `Figure2F.mat`) and does not score unreleased routing-mechanism analyses. [PAPER, Fig. 1; PAPER, Fig. 2; PAPER, Discussion]

## Figure 1 Shared-Structure Slice
- `Figure1i.mat` arrays are shape `(6, 14, 8)` for both `Dlocal` and `Dshared`.
- Mean local dimensionality: `4.7130`.
- Mean shared dimensionality: `2.3240`.
- Local/shared mean ratio: `2.1406`.
- Interpretation in this bundle: local dimensionality exceeds shared dimensionality on average in the released slice. [PAPER, Fig. 1]

## Figure 2F Behavior-Correlation Slice
- `Figure2F.mat` `behav_rho` schema: shape `(636, 10)`, dtype `float64`.
- Global mean rho: `0.1452`.
- Global median rho: `0.1111`.
- The released matrix supports dimension-indexed rho summaries only in this scoped task. [PAPER, Fig. 2]

## Figure 1f Model-Performance Context
- `Figure1f.mat` `mdl_perf` mean explainable-variance fraction: `0.1174`.
- Median explainable-variance fraction: `0.1093`.
- This panel is used as source-array context and not as a full model-mechanism reconstruction. [PAPER, Fig. 1]

from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def load_excel(path: str | Path, sheet_name: str) -> pd.DataFrame:
    df = pd.read_excel(path, sheet_name=sheet_name)
    df = df.copy()
    df.columns = [str(c).strip() for c in df.columns]
    return df


def list_excel_sheets(path: str | Path) -> list[str]:
    return pd.ExcelFile(path).sheet_names


def numeric_group_summary(df: pd.DataFrame, group_col: str, value_col: str) -> pd.DataFrame:
    tmp = df[[group_col, value_col]].dropna().copy()
    tmp[value_col] = pd.to_numeric(tmp[value_col], errors='coerce')
    tmp = tmp.dropna(subset=[value_col])
    out = tmp.groupby(group_col)[value_col].agg(['mean', 'median', 'std', 'count']).reset_index()
    out['sem'] = out['std'] / np.sqrt(out['count'].clip(lower=1))
    return out


def melt_wide_numeric(df: pd.DataFrame, id_cols: list[str] | None = None) -> pd.DataFrame:
    if id_cols is None:
        id_cols = [c for c in df.columns if not pd.api.types.is_numeric_dtype(df[c])][:1]
    wide = df.copy()
    cols = [c for c in wide.columns if c not in id_cols]
    long = wide.melt(id_vars=id_cols, value_vars=cols, var_name='variable', value_name='value')
    long['value'] = pd.to_numeric(long['value'], errors='coerce')
    return long.dropna(subset=['value'])


def save_grouped_barplot(df: pd.DataFrame, x: str, hue: str, y: str, out_path: str | Path, title: str, ylabel: str) -> str:
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    pivot = df.pivot(index=x, columns=hue, values=y).sort_index()
    fig, ax = plt.subplots(figsize=(8, 4.5))
    pivot.plot(kind='bar', ax=ax, width=0.82)
    ax.set_title(title)
    ax.set_ylabel(ylabel)
    ax.set_xlabel(x)
    ax.legend(frameon=False, title=hue)
    ax.tick_params(axis='x', rotation=20)
    fig.tight_layout()
    fig.savefig(out_path, dpi=200)
    plt.close(fig)
    return str(out_path)


def save_multi_panel_figure(specs, out_path: str | Path, title: str) -> str:
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    n = len(specs)
    cols = 2 if n > 1 else 1
    rows = int(np.ceil(n / cols))
    fig, axes = plt.subplots(rows, cols, figsize=(7 * cols, 4.5 * rows))
    axes = np.atleast_1d(axes).ravel()
    for ax, spec in zip(axes, specs):
        spec(ax)
    for ax in axes[len(specs):]:
        ax.axis('off')
    fig.suptitle(title)
    fig.tight_layout()
    fig.savefig(out_path, dpi=200)
    plt.close(fig)
    return str(out_path)

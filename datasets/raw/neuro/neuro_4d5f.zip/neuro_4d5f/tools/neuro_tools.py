from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from mcp.server.fastmcp import FastMCP

from data_processing import load_excel, save_grouped_barplot
from database_retrieval import workbook_path

mcp = FastMCP("neuro_4d5f_tools")


def _to_numeric_frame(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    for col in out.columns:
        out[col] = pd.to_numeric(out[col], errors="coerce")
    return out


def summarize_mechanical_site_means(
    data_dir: str | Path,
    workbook_name: str = "SourceData_Fig4.xlsx",
    sheet_name: str = "Fig. 4r",
) -> pd.DataFrame:
    wb4 = workbook_path(Path(data_dir), workbook_name)
    mech = _to_numeric_frame(load_excel(wb4, sheet_name)[["Baseline", "Tongue", "Pharynx", "Esophagus"]])
    return mech.mean(axis=0).rename_axis("site").reset_index(name="mean_response")


def summarize_perturbation_panels(
    data_dir: str | Path,
    workbook_name: str = "SourceData_Fig6.xlsx",
    panel_sheets: tuple[str, ...] = ("Fig. 6b", "Fig. 6c", "Fig. 6d"),
) -> pd.DataFrame:
    wb6 = workbook_path(Path(data_dir), workbook_name)
    perturb_rows = []
    for panel in panel_sheets:
        p = _to_numeric_frame(load_excel(wb6, panel))
        perturb_rows.append(
            {
                "panel": panel,
                "control": float(p["Control"].mean()),
                "vagal_tox": float(p["Vagal Tox"].mean()),
                "control_spinal": float(p["Control.1"].mean()),
                "intrathecal_rtx": float(p["Intrathecal RTX"].mean()),
            }
        )
    return pd.DataFrame(perturb_rows)


def summarize_nutrient_panels(
    data_dir: str | Path,
    workbook_name: str = "SourceData_Fig5.xlsx",
    panel_o: str = "Fig. 5o",
    panel_q: str = "Fig. 5q",
) -> tuple[pd.DataFrame, pd.DataFrame]:
    wb5 = workbook_path(Path(data_dir), workbook_name)
    fig5o = _to_numeric_frame(load_excel(wb5, panel_o))
    fig5q = _to_numeric_frame(load_excel(wb5, panel_q))
    nutrient_o = fig5o.mean(axis=0).rename_axis("condition").reset_index(name="mean_response")
    nutrient_o["panel"] = panel_o
    nutrient_q = fig5q.mean(axis=0).rename_axis("condition").reset_index(name="mean_response")
    nutrient_q["panel"] = panel_q
    return nutrient_o, nutrient_q


def summarize_behavior_panel(
    data_dir: str | Path,
    workbook_name: str = "SourceData_Fig8.xlsx",
    sheet_name: str = "Fig. 8b, d",
) -> pd.DataFrame:
    wb8 = workbook_path(Path(data_dir), workbook_name)
    fig8 = load_excel(wb8, sheet_name)
    behavior_rows = []
    blocks = [("Lick Number", 0), ("Bout Number", 5), ("Bout Size", 10)]
    for metric, start in blocks:
        labels = fig8.iloc[0, start : start + 4].astype(str).tolist()
        vals = fig8.iloc[1:, start : start + 4].apply(pd.to_numeric, errors="coerce")
        label_map = {
            0: "Ctrl (Concentration)",
            1: labels[1],
            2: "Ctrl (Speed)",
            3: labels[3],
        }
        for i, col in enumerate(vals.columns):
            behavior_rows.append(
                {
                    "metric": metric,
                    "condition": label_map.get(i, labels[i]),
                    "mean_value": float(vals[col].mean()),
                }
            )
    return pd.DataFrame(behavior_rows)


def summarize_spinal_perturbation(
    data_dir: str | Path,
    workbook_name: str = "SourceData_Fig6.xlsx",
    glucose_sheet: str = "Fig. 6h",
    lipid_sheet: str = "Fig. 6i",
    peptide_sheet: str = "Fig. 6j",
) -> pd.DataFrame:
    wb6 = workbook_path(Path(data_dir), workbook_name)
    rows = []
    for sheet, stim_label in [(glucose_sheet, "Glucose"), (lipid_sheet, "Lipid"), (peptide_sheet, "Peptide")]:
        tmp = load_excel(wb6, sheet).iloc[1:, :2].apply(pd.to_numeric, errors="coerce")
        rows.append({"stimulus": stim_label, "phase": "Before", "mean_value": float(tmp.iloc[:, 0].mean())})
        rows.append({"stimulus": stim_label, "phase": "ND-TeNT", "mean_value": float(tmp.iloc[:, 1].mean())})
    return pd.DataFrame(rows)


def cell_atlas_summary(
    data_dir: str | Path,
    output_dir: str | Path,
    workbook_name: str = "SourceData_Fig1.xlsx",
    sheet_name: str = "Fig. 1e",
    output_name: str = "cell_atlas_marker_summary.png",
) -> dict:
    data_dir = Path(data_dir)
    output_dir = Path(output_dir)
    wb = workbook_path(data_dir, workbook_name)
    marker_counts = load_excel(wb, sheet_name).rename(columns={"Unnamed: 0": "marker"})
    long = marker_counts.melt(id_vars=["marker"], var_name="cell_class", value_name="count")
    long["count"] = pd.to_numeric(long["count"], errors="coerce")
    long = long.dropna(subset=["count"])
    fig_path = save_grouped_barplot(
        long,
        x="marker",
        hue="cell_class",
        y="count",
        out_path=output_dir / output_name,
        title="cNTS marker enrichment across cell classes",
        ylabel="Count",
    )
    return {"workbook": wb, "summary": long.to_dict(orient="records"), "figure": fig_path}


def feeding_pathway_summary(
    data_dir: str | Path,
    output_dir: str | Path,
    mechanical_workbook: str = "SourceData_Fig4.xlsx",
    mechanical_sheet: str = "Fig. 4r",
    perturbation_workbook: str = "SourceData_Fig6.xlsx",
    perturbation_panels: tuple[str, ...] = ("Fig. 6b", "Fig. 6c", "Fig. 6d"),
    output_name: str = "th_vagal_mechanosensory_summary.png",
    figure_title: str = "Th+ mechanical/vagal pathway evidence summary",
) -> dict:
    data_dir = Path(data_dir)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    wb4 = workbook_path(data_dir, mechanical_workbook)
    wb6 = workbook_path(data_dir, perturbation_workbook)
    mech_mean = summarize_mechanical_site_means(data_dir, mechanical_workbook, mechanical_sheet)
    perturb = summarize_perturbation_panels(data_dir, perturbation_workbook, perturbation_panels)

    fig, axes = plt.subplots(1, 3, figsize=(15, 4.4))
    axes[0].bar(mech_mean["site"], mech_mean["mean_response"], color="#4e79a7")
    axes[0].set_title("Mechanical-site responses (Fig. 4r)")
    axes[0].set_ylabel("Mean response")
    axes[0].tick_params(axis="x", rotation=20)

    x = range(len(perturb))
    w = 0.35
    axes[1].bar([i - w / 2 for i in x], perturb["control"], width=w, label="Control", color="#59a14f")
    axes[1].bar([i + w / 2 for i in x], perturb["vagal_tox"], width=w, label="Vagal Tox", color="#e15759")
    axes[1].set_xticks(list(x))
    axes[1].set_xticklabels(perturb["panel"], rotation=20)
    axes[1].set_title("Vagal perturbation panels (Fig. 6b-d)")
    axes[1].set_ylabel("Mean response")
    axes[1].legend(frameon=False)

    axes[2].bar([i - w / 2 for i in x], perturb["control_spinal"], width=w, label="Control", color="#76b7b2")
    axes[2].bar([i + w / 2 for i in x], perturb["intrathecal_rtx"], width=w, label="Intrathecal RTX", color="#f28e2b")
    axes[2].set_xticks(list(x))
    axes[2].set_xticklabels(perturb["panel"], rotation=20)
    axes[2].set_title("Spinal perturbation panels (Fig. 6b-d)")
    axes[2].set_ylabel("Mean response")
    axes[2].legend(frameon=False)

    fig.suptitle(figure_title)
    fig.tight_layout()
    fig_path = output_dir / output_name
    fig.savefig(fig_path, dpi=200)
    plt.close(fig)

    return {
        "workbooks": [wb4, wb6],
        "mechanical_summary": mech_mean.to_dict(orient="records"),
        "perturbation_summary": perturb.to_dict(orient="records"),
        "figure": str(fig_path),
    }


def feeding_behavior_summary(
    data_dir: str | Path,
    output_dir: str | Path,
    nutrient_workbook: str = "SourceData_Fig5.xlsx",
    nutrient_panel_o: str = "Fig. 5o",
    nutrient_panel_q: str = "Fig. 5q",
    spinal_workbook: str = "SourceData_Fig6.xlsx",
    spinal_sheet_glucose: str = "Fig. 6h",
    spinal_sheet_lipid: str = "Fig. 6i",
    spinal_sheet_peptide: str = "Fig. 6j",
    behavior_workbook: str = "SourceData_Fig8.xlsx",
    behavior_sheet: str = "Fig. 8b, d",
    output_name: str = "gcg_nutrient_behavior_summary.png",
    figure_title: str = "Gcg+ nutrient/behavior pathway evidence summary",
) -> dict:
    data_dir = Path(data_dir)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    wb5 = workbook_path(data_dir, nutrient_workbook)
    wb6 = workbook_path(data_dir, spinal_workbook)
    wb8 = workbook_path(data_dir, behavior_workbook)

    nutrient_o, nutrient_q = summarize_nutrient_panels(data_dir, nutrient_workbook, nutrient_panel_o, nutrient_panel_q)
    nutrients = pd.concat([nutrient_o, nutrient_q], ignore_index=True)
    nutrients = nutrients[~nutrients["condition"].str.startswith("Unnamed", na=False)]

    spinal = summarize_spinal_perturbation(
        data_dir,
        spinal_workbook,
        spinal_sheet_glucose,
        spinal_sheet_lipid,
        spinal_sheet_peptide,
    )

    behavior = summarize_behavior_panel(data_dir, behavior_workbook, behavior_sheet)

    fig, axes = plt.subplots(1, 4, figsize=(19, 4.4))

    o_plot = nutrient_o.set_index("condition")["mean_response"]
    o_plot.plot(kind="bar", ax=axes[0], color="#4e79a7")
    axes[0].set_title("Nutrient responses (Fig. 5o)")
    axes[0].set_ylabel("Mean response")
    axes[0].tick_params(axis="x", rotation=25)

    q_plot = nutrient_q.set_index("condition")["mean_response"]
    q_plot.plot(kind="bar", ax=axes[1], color="#59a14f")
    axes[1].set_title("Sugar specificity (Fig. 5q)")
    axes[1].set_ylabel("Mean response")
    axes[1].tick_params(axis="x", rotation=25)

    s_pivot = spinal.pivot(index="stimulus", columns="phase", values="mean_value")
    s_pivot.plot(kind="bar", ax=axes[2], width=0.82)
    axes[2].set_title("Spinal-path perturbation (Fig. 6h-j)")
    axes[2].set_ylabel("Mean response")
    axes[2].tick_params(axis="x", rotation=20)
    axes[2].legend(frameon=False, fontsize=8)

    b_pivot = behavior.pivot(index="metric", columns="condition", values="mean_value")
    b_pivot.plot(kind="bar", ax=axes[3], width=0.82)
    axes[3].set_title("Behavior outputs (Fig. 8b,d)")
    axes[3].set_ylabel("Mean value")
    axes[3].tick_params(axis="x", rotation=15)
    axes[3].legend(frameon=False, fontsize=8)

    fig.suptitle(figure_title)
    fig.tight_layout()
    fig_path = output_dir / output_name
    fig.savefig(fig_path, dpi=200)
    plt.close(fig)

    return {
        "workbooks": [wb5, wb6, wb8],
        "nutrient_summary": nutrients.to_dict(orient="records"),
        "spinal_perturbation_summary": spinal.to_dict(orient="records"),
        "behavior_summary": behavior.to_dict(orient="records"),
        "figure": str(fig_path),
    }


def data_panel_inventory(data_dir: str | Path) -> dict:
    root = Path(data_dir)
    workbooks = sorted(str(p.name) for p in root.glob("SourceData_*.xlsx"))
    return {
        "n_workbooks": len(workbooks),
        "workbooks": workbooks,
    }


@mcp.tool()
def summarize_marker_enrichment_tool(data_dir: str) -> dict:
    wb = workbook_path(Path(data_dir), "SourceData_Fig1.xlsx")
    marker_counts = load_excel(wb, "Fig. 1e").rename(columns={"Unnamed: 0": "marker"})
    long = marker_counts.melt(id_vars=["marker"], var_name="cell_class", value_name="count")
    long["count"] = pd.to_numeric(long["count"], errors="coerce")
    long = long.dropna(subset=["count"])
    return {"workbook": wb, "summary": long.to_dict(orient="records")}


@mcp.tool()
def summarize_mechanical_pathway_tool(data_dir: str) -> dict:
    mech = summarize_mechanical_site_means(data_dir)
    perturb = summarize_perturbation_panels(data_dir)
    return {"mechanical_summary": mech.to_dict(orient="records"), "perturbation_summary": perturb.to_dict(orient="records")}


@mcp.tool()
def summarize_nutrient_panels_tool(data_dir: str) -> dict:
    nutrient_o, nutrient_q = summarize_nutrient_panels(data_dir)
    return {"fig5o_summary": nutrient_o.to_dict(orient="records"), "fig5q_summary": nutrient_q.to_dict(orient="records")}


@mcp.tool()
def summarize_behavior_panel_tool(data_dir: str) -> dict:
    behavior = summarize_behavior_panel(data_dir)
    return {"behavior_summary": behavior.to_dict(orient="records")}


@mcp.tool()
def summarize_spinal_perturbation_tool(data_dir: str) -> dict:
    spinal = summarize_spinal_perturbation(data_dir)
    return {"spinal_perturbation_summary": spinal.to_dict(orient="records")}


@mcp.tool()
def cell_atlas_summary_tool(
    data_dir: str,
    output_dir: str,
    workbook_name: str,
    sheet_name: str,
    output_name: str,
) -> dict:
    return cell_atlas_summary(
        data_dir=data_dir,
        output_dir=output_dir,
        workbook_name=workbook_name,
        sheet_name=sheet_name,
        output_name=output_name,
    )


@mcp.tool()
def feeding_pathway_summary_tool(
    data_dir: str,
    output_dir: str,
    mechanical_workbook: str,
    mechanical_sheet: str,
    perturbation_workbook: str,
    perturbation_panels_csv: str,
    output_name: str,
    figure_title: str,
) -> dict:
    panels = tuple([p.strip() for p in perturbation_panels_csv.split(",") if p.strip()])
    if not panels:
        raise ValueError("perturbation_panels_csv must contain at least one sheet name")
    return feeding_pathway_summary(
        data_dir=data_dir,
        output_dir=output_dir,
        mechanical_workbook=mechanical_workbook,
        mechanical_sheet=mechanical_sheet,
        perturbation_workbook=perturbation_workbook,
        perturbation_panels=panels,
        output_name=output_name,
        figure_title=figure_title,
    )


@mcp.tool()
def feeding_behavior_summary_tool(
    data_dir: str,
    output_dir: str,
    nutrient_workbook: str,
    nutrient_panel_o: str,
    nutrient_panel_q: str,
    spinal_workbook: str,
    spinal_sheet_glucose: str,
    spinal_sheet_lipid: str,
    spinal_sheet_peptide: str,
    behavior_workbook: str,
    behavior_sheet: str,
    output_name: str,
    figure_title: str,
) -> dict:
    return feeding_behavior_summary(
        data_dir=data_dir,
        output_dir=output_dir,
        nutrient_workbook=nutrient_workbook,
        nutrient_panel_o=nutrient_panel_o,
        nutrient_panel_q=nutrient_panel_q,
        spinal_workbook=spinal_workbook,
        spinal_sheet_glucose=spinal_sheet_glucose,
        spinal_sheet_lipid=spinal_sheet_lipid,
        spinal_sheet_peptide=spinal_sheet_peptide,
        behavior_workbook=behavior_workbook,
        behavior_sheet=behavior_sheet,
        output_name=output_name,
        figure_title=figure_title,
    )


if __name__ == "__main__":
    mcp.run(transport="stdio")

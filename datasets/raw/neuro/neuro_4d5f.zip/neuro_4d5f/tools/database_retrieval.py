from __future__ import annotations

from pathlib import Path


def list_workbooks(data_dir: str | Path) -> list[str]:
    data_dir = Path(data_dir)
    return sorted(str(p) for p in data_dir.rglob('*.xlsx'))


def list_repo_files(repo_dir: str | Path, suffixes: tuple[str, ...] = ('.m', '.ipynb', '.md')) -> list[str]:
    repo_dir = Path(repo_dir)
    out = []
    for suffix in suffixes:
        out.extend(str(p) for p in repo_dir.rglob(f'*{suffix}'))
    return sorted(set(out))


def workbook_path(data_dir: str | Path, name: str) -> str:
    data_dir = Path(data_dir)
    for p in data_dir.rglob(name):
        if p.suffix.lower() == '.xlsx':
            return str(p)
    raise FileNotFoundError(name)

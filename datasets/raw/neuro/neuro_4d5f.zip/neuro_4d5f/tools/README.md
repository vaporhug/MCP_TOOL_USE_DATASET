# neuro_4d5f tools

Three layers are kept separate:

- `data_processing.py`: workbook loading, reshaping, and plot helpers.
- `database_retrieval.py`: local discovery for workbooks and repo scripts.
- `neuro_tools.py`: paper-specific primitives for the cNTS atlas, pathway comparisons, and feeding behavior summaries.

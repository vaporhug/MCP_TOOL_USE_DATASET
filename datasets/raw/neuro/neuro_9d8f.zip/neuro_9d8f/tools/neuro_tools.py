from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

try:
    from .data_processing import data_root, list_files, workbook_sheets
    from .database_retrieval import public_repository_links
except ImportError:
    import importlib.util
    import re
    import sys

    tools_dir = Path(__file__).resolve().parent
    task_name = re.sub(r"[^0-9A-Za-z_]", "_", Path(__file__).resolve().parents[1].name)

    def _load_sibling(module_filename: str, module_stem: str):
        module_path = tools_dir / module_filename
        module_name = f"_strict59_{task_name}_{module_stem}"
        spec = importlib.util.spec_from_file_location(module_name, module_path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Cannot load {module_path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        spec.loader.exec_module(module)
        return module

    _dp = _load_sibling("data_processing.py", "data_processing")
    _db = _load_sibling("database_retrieval.py", "database_retrieval")
    data_root = _dp.data_root
    list_files = _dp.list_files
    workbook_sheets = _dp.workbook_sheets
    public_repository_links = _db.public_repository_links

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
ARTIFACT_DIR = PACKAGE_ROOT / "artifacts"
ARTIFACT_DIR.mkdir(exist_ok=True)
WORKBOOK = data_root() / "41467_2025_59575_MOESM4_ESM.xlsx"


def source_inventory(root: str | Path | None = None) -> dict:
    files = list_files(root or data_root())
    return {
        "n_files": len(files),
        "extensions": sorted({Path(f).suffix.lower() for f in files}),
        "files": [str(Path(f).name) for f in files[:200]],
        "workbook_sheets": workbook_sheets(WORKBOOK) if WORKBOOK.exists() else [],
        "repositories": public_repository_links().get("repositories", []),
    }


def _sheet(name: str) -> pd.DataFrame:
    return pd.read_excel(WORKBOOK, sheet_name=name, header=None)


def fig3_social_context_matrices() -> dict[str, pd.DataFrame]:
    """Return real and shuffled Fig. 3D social/context cosine-similarity matrices."""
    raw = _sheet("Figure 3D")
    labels = ["soc_A", "soc_B", "nonsoc_A", "nonsoc_B", "context_A", "context_B"]
    return {
        "static": pd.DataFrame(raw.iloc[7:13, 3:9].astype(float).to_numpy(), index=labels, columns=labels),
        "dynamic": pd.DataFrame(raw.iloc[7:13, 11:17].astype(float).to_numpy(), index=labels, columns=labels),
        "static_shuffled": pd.DataFrame(raw.iloc[16:22, 3:9].astype(float).to_numpy(), index=labels, columns=labels),
        "dynamic_shuffled": pd.DataFrame(raw.iloc[16:22, 11:17].astype(float).to_numpy(), index=labels, columns=labels),
    }


def fig3_cosine_comparison_table() -> pd.DataFrame:
    """Return Fig. 3E per-comparison cosine similarities for real and shuffled data."""
    raw = _sheet("Figure 3E")
    rows = []
    spans = {
        "static": range(4, 12),
        "dynamic": range(12, 19),
        "shuffled_static": range(19, 27),
        "shuffled_dynamic": range(27, 35),
    }
    for row in range(6, 10):
        comparison = str(raw.iat[row, 3])
        for condition, cols in spans.items():
            for col in cols:
                value = pd.to_numeric(raw.iat[row, col], errors="coerce")
                if pd.notna(value):
                    rows.append({"comparison": comparison, "condition": condition, "cosine_similarity": float(value)})
    return pd.DataFrame(rows)


def fig3_overlap_profile() -> pd.DataFrame:
    """Return Fig. 3F/G cell-overlap fractions for social and context ensembles."""
    raw = _sheet("Figure 3F-G")
    rows = []
    groups = {
        "static": {10: "soc_ab", 11: "soc_cd", 12: "context_ab", 13: "context_cd"},
        "dynamic": {15: "soc_ab", 16: "soc_cd", 17: "context_ab", 18: "context_cd"},
    }
    for row in range(6, len(raw)):
        for condition, cols in groups.items():
            for col, ensemble in cols.items():
                value = pd.to_numeric(raw.iat[row, col], errors="coerce")
                if pd.notna(value):
                    rows.append({"condition": condition, "ensemble": ensemble, "overlap_fraction": float(value)})
    return pd.DataFrame(rows)


def social_context_metrics() -> dict:
    table = fig3_cosine_comparison_table()
    overlap = fig3_overlap_profile()
    means = table.groupby(["comparison", "condition"], as_index=False)["cosine_similarity"].mean()
    overlap_means = overlap.groupby(["condition", "ensemble"], as_index=False)["overlap_fraction"].mean()
    return {
        "source_workbook": str(WORKBOOK.name),
        "sheets": ["Figure 3D", "Figure 3E", "Figure 3F-G"],
        "cosine_rows": int(len(table)),
        "overlap_rows": int(len(overlap)),
        "cosine_condition_means": means.to_dict(orient="records"),
        "overlap_condition_means": overlap_means.to_dict(orient="records"),
    }


def plot_social_context_matrix(output_filename: str = "Fig1_neuro_9d8f_feature_profile.png") -> dict:
    matrices = fig3_social_context_matrices()
    out = ARTIFACT_DIR / output_filename
    fig, axes = plt.subplots(1, 2, figsize=(10.0, 4.6), sharex=True, sharey=True)
    for ax, key in zip(axes, ["static", "dynamic"]):
        mat = matrices[key]
        im = ax.imshow(mat.to_numpy(), vmin=-1, vmax=1, cmap="coolwarm")
        ax.set_title(f"Fig. 3D {key} cosine matrix")
        ax.set_xticks(range(len(mat.columns)))
        ax.set_xticklabels(mat.columns, rotation=45, ha="right", fontsize=8)
        ax.set_yticks(range(len(mat.index)))
        ax.set_yticklabels(mat.index, fontsize=8)
    fig.colorbar(im, ax=axes.ravel().tolist(), shrink=0.82, label="cosine similarity")
    fig.savefig(out, dpi=180, bbox_inches="tight")
    plt.close(fig)
    return {"path": str(out), "source_sheet": "Figure 3D"}


def plot_cosine_contrast(output_filename: str = "Fig2_neuro_9d8f_workflow_contrast.png") -> dict:
    table = fig3_cosine_comparison_table()
    means = table.groupby(["comparison", "condition"], as_index=False)["cosine_similarity"].mean()
    out = ARTIFACT_DIR / output_filename
    fig, ax = plt.subplots(figsize=(10.0, 4.8))
    pivot = means.pivot(index="comparison", columns="condition", values="cosine_similarity")
    pivot[["static", "dynamic", "shuffled_static", "shuffled_dynamic"]].plot(kind="bar", ax=ax, width=0.78)
    ax.axhline(0, color="black", lw=0.8)
    ax.set_ylabel("mean cosine similarity")
    ax.set_title("Fig. 3E social/context comparisons versus shuffled controls")
    ax.legend(frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(out, dpi=180)
    plt.close(fig)
    return {"path": str(out), "source_sheet": "Figure 3E", "comparisons": list(pivot.index)}


def plot_overlap_profile(output_filename: str = "Fig3_neuro_9d8f_signal_relationship.png") -> dict:
    overlap = fig3_overlap_profile()
    means = overlap.groupby(["condition", "ensemble"], as_index=False)["overlap_fraction"].mean()
    out = ARTIFACT_DIR / output_filename
    fig, ax = plt.subplots(figsize=(8.6, 4.8))
    for condition, sub in means.groupby("condition"):
        ax.plot(sub["ensemble"], sub["overlap_fraction"], marker="o", label=condition)
    ax.set_ylabel("mean overlap fraction")
    ax.set_xlabel("ensemble vector")
    ax.set_title("Fig. 3F/G overlap profiles for social and context ensembles")
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(out, dpi=180)
    plt.close(fig)
    return {"path": str(out), "source_sheet": "Figure 3F-G", "rows": int(len(overlap))}


def package_smoke_test() -> dict:
    return {
        "inventory": source_inventory(),
        "metrics": social_context_metrics(),
        "plots": [
            plot_social_context_matrix(),
            plot_cosine_contrast(),
            plot_overlap_profile(),
        ],
    }

# Tools

This directory follows the three-layer task-tool structure.

- `data_processing.py`: shared file discovery, table loading, archive inspection, numeric coercion, and workbook helpers.
- `database_retrieval.py`: local inventory, article-link extraction, and public repository discovery.
- `neuro_tools.py`: paper-specific but composable analysis primitives for the scoped source-data workflow, plus plotting helpers used by `package_smoke_test()`.

The domain tools do not parse `target.pdf` and do not produce a final report. They expose source-data loading, reusable metric tables, and required workflow-evidence figures. Final scientific wording and citations should be checked against `input_data/reference_paper/target.pdf`.

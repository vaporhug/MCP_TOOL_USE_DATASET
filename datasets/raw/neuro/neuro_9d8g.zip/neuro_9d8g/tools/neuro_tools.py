from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

try:
    from .data_processing import data_root, list_files, workbook_sheets
    from .database_retrieval import public_repository_links
except ImportError:
    import importlib.util
    import re
    import sys

    tools_dir = Path(__file__).resolve().parent
    task_name = re.sub(r"[^0-9A-Za-z_]", "_", Path(__file__).resolve().parents[1].name)

    def _load_sibling(module_filename: str, module_stem: str):
        module_path = tools_dir / module_filename
        module_name = f"_strict59_{task_name}_{module_stem}"
        spec = importlib.util.spec_from_file_location(module_name, module_path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Cannot load {module_path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        spec.loader.exec_module(module)
        return module

    _dp = _load_sibling("data_processing.py", "data_processing")
    _db = _load_sibling("database_retrieval.py", "database_retrieval")
    data_root = _dp.data_root
    list_files = _dp.list_files
    workbook_sheets = _dp.workbook_sheets
    public_repository_links = _db.public_repository_links

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
ARTIFACT_DIR = PACKAGE_ROOT / "artifacts"
ARTIFACT_DIR.mkdir(exist_ok=True)
WORKBOOK = data_root() / "41467_2026_68692_MOESM4_ESM.xlsx"


def source_inventory(root: str | Path | None = None) -> dict:
    files = list_files(root or data_root())
    return {
        "n_files": len(files),
        "extensions": sorted({Path(f).suffix.lower() for f in files}),
        "files": [str(Path(f).name) for f in files[:200]],
        "workbook_sheets": workbook_sheets(WORKBOOK) if WORKBOOK.exists() else [],
        "repositories": public_repository_links().get("repositories", []),
    }


def _fig5() -> pd.DataFrame:
    return pd.read_excel(WORKBOOK, sheet_name="Fig.5", header=None)


def fig5_angle_summary() -> pd.DataFrame:
    """Return Fig. 5A original-vs-shuffled subspace-angle summary by monkey."""
    raw = _fig5()
    rows = []
    for monkey, original_col, shuffled_col in [("AB", 2, 3), ("ZZ", 4, 5), ("XW", 6, 7)]:
        rows.append({
            "monkey": monkey,
            "original_mean_deg": float(raw.iat[6, original_col]),
            "original_se_deg": float(raw.iat[7, original_col]),
            "shuffled_mean_deg": float(raw.iat[6, shuffled_col]),
            "shuffled_se_deg": float(raw.iat[7, shuffled_col]),
        })
    return pd.DataFrame(rows)


def fig5_scatter_points() -> pd.DataFrame:
    """Return Fig. 5B stimulus/decision projection scatter source points."""
    raw = _fig5()
    block = raw.iloc[6:, [11, 12, 13, 14]].copy()
    block.columns = ["stimulus_dimension", "decision_dimension", "stimulus_label", "decision_label"]
    for col in block.columns:
        block[col] = pd.to_numeric(block[col], errors="coerce")
    return block.dropna(subset=["stimulus_dimension", "decision_dimension"])


def fig5_trajectory_points(panel: str = "left") -> pd.DataFrame:
    """Return Fig. 5D source trajectory coordinates for the selected panel."""
    raw = _fig5()
    cols = [16, 17, 18, 19, 20] if panel == "left" else [25, 26, 27, 28, 29]
    block = raw.iloc[6:, cols].copy()
    block.columns = ["stimulus_dim1", "stimulus_dim2", "decision_dim", "stimulus_label", "decision_label"]
    for col in block.columns:
        block[col] = pd.to_numeric(block[col], errors="coerce")
    return block.dropna(subset=["stimulus_dim1", "stimulus_dim2", "decision_dim"])


def subspace_orthogonality_metrics() -> dict:
    angles = fig5_angle_summary()
    scatter = fig5_scatter_points()
    left = fig5_trajectory_points("left")
    right = fig5_trajectory_points("right")
    return {
        "source_workbook": str(WORKBOOK.name),
        "source_sheet": "Fig.5",
        "angle_summary": angles.to_dict(orient="records"),
        "scatter_rows": int(len(scatter)),
        "left_trajectory_rows": int(len(left)),
        "right_trajectory_rows": int(len(right)),
        "all_original_angles_exceed_shuffled": bool((angles["original_mean_deg"] > angles["shuffled_mean_deg"]).all()),
    }


def plot_angle_summary(output_filename: str = "Fig1_neuro_9d8g_feature_profile.png") -> dict:
    angles = fig5_angle_summary()
    out = ARTIFACT_DIR / output_filename
    x = np.arange(len(angles))
    fig, ax = plt.subplots(figsize=(7.8, 4.8))
    ax.bar(x - 0.18, angles["original_mean_deg"], width=0.36, yerr=angles["original_se_deg"], label="original", color="#335c67")
    ax.bar(x + 0.18, angles["shuffled_mean_deg"], width=0.36, yerr=angles["shuffled_se_deg"], label="shuffled", color="#e09f3e")
    ax.set_xticks(x)
    ax.set_xticklabels(angles["monkey"])
    ax.set_ylabel("principal angle (degrees)")
    ax.set_title("Fig. 5A decision/stimulus subspace angles")
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(out, dpi=180)
    plt.close(fig)
    return {"path": str(out), "source_sheet": "Fig.5", "rows": int(len(angles))}


def plot_projection_scatter(output_filename: str = "Fig2_neuro_9d8g_workflow_contrast.png") -> dict:
    pts = fig5_scatter_points()
    out = ARTIFACT_DIR / output_filename
    fig, ax = plt.subplots(figsize=(7.4, 5.2))
    sc = ax.scatter(pts["stimulus_dimension"], pts["decision_dimension"], c=pts["decision_label"], cmap="viridis", s=22, alpha=0.82)
    ax.set_xlabel("stimulus dimension")
    ax.set_ylabel("decision dimension")
    ax.set_title("Fig. 5B projection of stimulus and decision dimensions")
    fig.colorbar(sc, ax=ax, label="decision label")
    fig.tight_layout()
    fig.savefig(out, dpi=180)
    plt.close(fig)
    return {"path": str(out), "source_sheet": "Fig.5", "rows": int(len(pts))}


def plot_trajectory_relationship(output_filename: str = "Fig3_neuro_9d8g_signal_relationship.png") -> dict:
    left = fig5_trajectory_points("left")
    right = fig5_trajectory_points("right")
    out = ARTIFACT_DIR / output_filename
    fig, axes = plt.subplots(1, 2, figsize=(10.0, 4.8))
    for ax, data, title in [(axes[0], left, "near-orthogonal example"), (axes[1], right, "less-orthogonal comparison")]:
        for decision, sub in data.groupby("decision_label"):
            ax.plot(sub["stimulus_dim1"], sub["decision_dim"], lw=1.2, alpha=0.8, label=f"decision {int(decision)}")
        ax.set_title(f"Fig. 5D {title}")
        ax.set_xlabel("stimulus dimension 1")
        ax.set_ylabel("decision dimension")
    axes[0].legend(frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(out, dpi=180)
    plt.close(fig)
    return {"path": str(out), "source_sheet": "Fig.5", "left_rows": int(len(left)), "right_rows": int(len(right))}


def package_smoke_test() -> dict:
    return {
        "inventory": source_inventory(),
        "metrics": subspace_orthogonality_metrics(),
        "plots": [
            plot_angle_summary(),
            plot_projection_scatter(),
            plot_trajectory_relationship(),
        ],
    }

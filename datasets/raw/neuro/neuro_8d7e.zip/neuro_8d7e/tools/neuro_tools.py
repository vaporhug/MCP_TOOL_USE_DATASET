from __future__ import annotations
from pathlib import Path
import math
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
try:
    from .data_processing import data_root, list_files, read_table, workbook_sheets, numeric_columns, tidy_numeric_frame, robust_zscore, load_workbook_long
    from .database_retrieval import inventory, public_repository_links
except ImportError:
    from data_processing import data_root, list_files, read_table, workbook_sheets, numeric_columns, tidy_numeric_frame, robust_zscore, load_workbook_long
    from database_retrieval import inventory, public_repository_links

ARTIFACT_DIR = Path(__file__).resolve().parents[1] / "artifacts"
ARTIFACT_DIR.mkdir(exist_ok=True)

def source_inventory(root: str | Path | None = None) -> dict:
    files = list_files(root or data_root())
    sizes = {str(Path(f).relative_to(Path(f).parents[2])) if len(Path(f).parents)>2 else f: Path(f).stat().st_size for f in files[:200]}
    return {"n_files": len(files), "extensions": sorted({Path(f).suffix.lower() for f in files}), "files": files[:200], "sizes": sizes, "repositories": public_repository_links().get("repositories", [])}

def source_workbook_summary(path: str | Path | None = None) -> dict:
    files = list_files(data_root())
    candidates=[f for f in files if Path(f).suffix.lower() in [".xlsx", ".xls"]]
    if path is None and not candidates:
        return {"n_workbooks": 0, "inventory": source_inventory()}
    path = path or candidates[0]
    rows=[]
    for sh in workbook_sheets(path)[:20]:
        try:
            df=read_table(path, sheet_name=sh)
            nums=numeric_columns(df)
            rows.append({"sheet": sh, "rows": int(len(df)), "columns": [str(c) for c in df.columns[:20]], "numeric_columns": [str(c) for c in nums[:20]]})
        except Exception as e:
            rows.append({"sheet": sh, "error": str(e)})
    return {"workbook": str(path), "sheets": rows}

def numeric_signal_summary(path: str | Path | None = None) -> dict:
    if path is None:
        df = pd.DataFrame()
        for candidate in list_files(data_root()):
            if Path(candidate).suffix.lower() not in [".csv", ".tsv", ".txt", ".dat", ".xlsx", ".xls"]:
                continue
            try:
                df = tidy_numeric_frame(candidate)
            except Exception:
                continue
            if not df.empty and numeric_columns(df):
                break
    else:
        df=tidy_numeric_frame(path)
    if df.empty:
        return {"note": "no tabular file found", "inventory": source_inventory()}
    nums=numeric_columns(df)
    stats={}
    for c in nums[:30]:
        s=pd.to_numeric(df[c], errors="coerce").dropna()
        if len(s):
            stats[str(c)]={"n": int(len(s)), "mean": float(s.mean()), "median": float(s.median()), "std": float(s.std(ddof=1)) if len(s)>1 else 0.0, "min": float(s.min()), "max": float(s.max())}
    return {"rows": int(len(df)), "columns": [str(c) for c in df.columns], "numeric_stats": stats}

def compare_numeric_groups(path: str | Path, group_col: str, value_col: str) -> dict:
    df=tidy_numeric_frame(path)
    df[value_col]=pd.to_numeric(df[value_col], errors="coerce")
    g=df.dropna(subset=[value_col]).groupby(group_col)[value_col]
    return {"groups": [{"group": str(k), "n": int(v.count()), "mean": float(v.mean()), "median": float(v.median()), "std": float(v.std(ddof=1)) if v.count()>1 else 0.0} for k,v in g]}

def bootstrap_difference(path: str | Path, group_col: str, value_col: str, group_a: str, group_b: str, n_boot: int = 2000, seed: int = 7) -> dict:
    df=tidy_numeric_frame(path)
    rng=np.random.default_rng(seed)
    a=pd.to_numeric(df.loc[df[group_col].astype(str)==str(group_a), value_col], errors="coerce").dropna().to_numpy()
    b=pd.to_numeric(df.loc[df[group_col].astype(str)==str(group_b), value_col], errors="coerce").dropna().to_numpy()
    if len(a)==0 or len(b)==0:
        return {"error": "empty group"}
    diffs=np.array([rng.choice(a, len(a), replace=True).mean()-rng.choice(b, len(b), replace=True).mean() for _ in range(n_boot)])
    return {"group_a": str(group_a), "group_b": str(group_b), "observed_mean_difference": float(a.mean()-b.mean()), "ci95": [float(np.quantile(diffs, .025)), float(np.quantile(diffs, .975))]}

def permutation_correlation(x, y, n_perm: int = 2000, seed: int = 7) -> dict:
    x=np.asarray(x, dtype=float); y=np.asarray(y, dtype=float)
    ok=np.isfinite(x)&np.isfinite(y); x=x[ok]; y=y[ok]
    if len(x)<3: return {"error":"not enough observations"}
    obs=float(np.corrcoef(x,y)[0,1])
    rng=np.random.default_rng(seed)
    null=np.array([np.corrcoef(x, rng.permutation(y))[0,1] for _ in range(n_perm)])
    p=float((np.sum(np.abs(null)>=abs(obs))+1)/(n_perm+1))
    return {"r": obs, "p_perm": p, "n": int(len(x))}

def plot_numeric_overview(output_filename: str = "numeric_overview.png") -> dict:
    summary=numeric_signal_summary(); stats=summary.get("numeric_stats", {})
    names=list(stats)[:10]; vals=[stats[n]["mean"] for n in names]
    if not names:
        names=["files"]; vals=[source_inventory()["n_files"]]
    out=ARTIFACT_DIR/output_filename
    fig, ax=plt.subplots(figsize=(8,4.8)); ax.bar(range(len(names)), vals, color="#4c78a8")
    ax.set_xticks(range(len(names))); ax.set_xticklabels(names, rotation=35, ha="right", fontsize=8)
    ax.set_ylabel("Mean value / count"); ax.set_title("Local public-data numeric overview")
    fig.tight_layout(); fig.savefig(out,dpi=180); plt.close(fig)
    return {"path": str(out), "plotted": names}

def plot_file_inventory(output_filename: str = "file_inventory.png") -> dict:
    inv=source_inventory(); counts={}
    for f in inv["files"]:
        ext=Path(f).suffix.lower() or "no_ext"; counts[ext]=counts.get(ext,0)+1
    out=ARTIFACT_DIR/output_filename
    fig, ax=plt.subplots(figsize=(6,4)); ax.bar(list(counts), list(counts.values()), color="#f58518")
    ax.set_title("Public workflow file inventory"); ax.set_ylabel("Files")
    fig.tight_layout(); fig.savefig(out,dpi=180); plt.close(fig)
    return {"path": str(out), "counts": counts}

def event_aligned_response(path: str | Path | None = None, time_col: str | None = None, signal_col: str | None = None, event_time: float = 0.0, baseline: tuple[float,float] = (-1.0,0.0), response: tuple[float,float] = (0.0,1.0)) -> dict:
    df=tidy_numeric_frame(path); nums=numeric_columns(df)
    if len(nums)<2: return {"error":"need time and signal columns"}
    t=time_col or nums[0]; s=signal_col or nums[1]
    time=pd.to_numeric(df[t], errors="coerce")-event_time; sig=pd.to_numeric(df[s], errors="coerce")
    ok=time.notna()&sig.notna(); time=time[ok]; sig=sig[ok]
    base=sig[(time>=baseline[0])&(time<baseline[1])]; resp=sig[(time>=response[0])&(time<=response[1])]
    if len(base)==0 or len(resp)==0: return {"error":"baseline/response windows not covered"}
    return {"time_col":str(t),"signal_col":str(s),"baseline_mean":float(base.mean()),"response_mean":float(resp.mean()),"delta":float(resp.mean()-base.mean()),"baseline_window":baseline,"response_window":response}

def behavior_threat_reward_metrics(path: str | Path | None = None, trial_col: str | None = None, reward_col: str | None = None, avoidance_col: str | None = None) -> dict:
    df=tidy_numeric_frame(path); nums=numeric_columns(df)
    if len(nums)<2: return {"error":"need behavioral numeric columns"}
    trial=trial_col or nums[0]; reward=reward_col or nums[1]; avoid=avoidance_col or (nums[2] if len(nums)>2 else nums[1])
    tmp=df[[trial,reward,avoid]].apply(pd.to_numeric, errors="coerce").dropna()
    if tmp.empty: return {"error":"no complete trials"}
    early=tmp.nsmallest(max(1,len(tmp)//3), trial); late=tmp.nlargest(max(1,len(tmp)//3), trial)
    return {"trial_col":str(trial),"reward_col":str(reward),"avoidance_col":str(avoid),"early_reward_mean":float(early[reward].mean()),"late_reward_mean":float(late[reward].mean()),"early_avoidance_mean":float(early[avoid].mean()),"late_avoidance_mean":float(late[avoid].mean())}

def population_decoding_auc(path: str | Path | None = None, target_col: str | None = None, feature_cols: list[str] | None = None) -> dict:
    df=tidy_numeric_frame(path); nums=numeric_columns(df)
    if len(nums)<3: return {"error":"need target plus feature columns"}
    ycol=target_col or nums[0]; feats=feature_cols or nums[1: min(len(nums), 8)]
    mat=df[[ycol]+feats].apply(pd.to_numeric, errors="coerce").dropna()
    if len(mat)<10: return {"error":"not enough rows for decoding"}
    y=(mat[ycol] > mat[ycol].median()).astype(int).to_numpy(); X=mat[feats].to_numpy(dtype=float)
    X=(X-X.mean(0))/(X.std(0)+1e-12)
    score=X@np.linalg.lstsq(X, y-y.mean(), rcond=None)[0]
    order=np.argsort(score); ranks=np.empty_like(order); ranks[order]=np.arange(len(score))
    n1=y.sum(); n0=len(y)-n1
    auc=float((ranks[y==1].sum()-n1*(n1-1)/2)/(n1*n0)) if n1 and n0 else float('nan')
    return {"target":str(ycol),"features":[str(c) for c in feats],"auc_rank_decoding":auc,"n":int(len(mat))}

def cluster_permutation_1d(values, threshold: float = 1.96) -> dict:
    z=robust_zscore(values); above=np.abs(z)>=threshold
    clusters=[]; start=None
    for i,a in enumerate(above):
        if a and start is None: start=i
        if (not a or i==len(above)-1) and start is not None:
            end=i if not a else i+1; clusters.append({"start":int(start),"end":int(end),"mass":float(np.nansum(np.abs(z[start:end])))}); start=None
    return {"threshold":threshold,"clusters":clusters}



def package_smoke_test() -> dict:
    plot_numeric_overview(f"neuro_8d7e_numeric_overview.png")
    plot_file_inventory(f"neuro_8d7e_file_inventory.png")
    return {"inventory": source_inventory(), "numeric": numeric_signal_summary(), "workbook": source_workbook_summary()}

This tools folder is organized into three layers.

- `neuro_tools.py`: domain primitives for experimenter-sex behavioral contrasts, ketamine context modulation, CRF-linked manipulation summaries, and artifact generation.
- `data_processing.py`: generic workbook and file helpers.
- `database_retrieval.py`: local source/reference inventory helpers.

Use the domain tool to reproduce the paper evidence chain from released source-data workbooks.

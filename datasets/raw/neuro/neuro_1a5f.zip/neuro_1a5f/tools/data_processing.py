from __future__ import annotations

from pathlib import Path
from typing import Iterable

from openpyxl import load_workbook


def load_workbook_readonly(workbook_path: str):
    return load_workbook(workbook_path, read_only=True, data_only=True)


def list_files(root: str, suffixes: Iterable[str] | None = None) -> list[str]:
    path = Path(root)
    items: list[str] = []
    for child in sorted(path.rglob("*")):
        if not child.is_file():
            continue
        if suffixes and child.suffix not in suffixes:
            continue
        items.append(str(child))
    return items

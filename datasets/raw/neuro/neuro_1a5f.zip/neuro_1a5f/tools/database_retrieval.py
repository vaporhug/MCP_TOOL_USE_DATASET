from __future__ import annotations

from pathlib import Path

try:
    from .data_processing import list_files
except ImportError:
    from data_processing import list_files


def local_code_inventory(data_root: str) -> dict:
    xlsx_files = list_files(data_root, suffixes={".xlsx"})
    pdf_files = list_files(data_root, suffixes={".pdf"})
    return {
        "root": str(Path(data_root).resolve()),
        "xlsx_file_count": len(xlsx_files),
        "pdf_file_count": len(pdf_files),
        "xlsx_files": xlsx_files,
        "pdf_files": pdf_files,
    }


def reference_inventory(reference_root: str) -> dict:
    files = list_files(reference_root, suffixes={".pdf"})
    return {"root": str(Path(reference_root).resolve()), "files": files}

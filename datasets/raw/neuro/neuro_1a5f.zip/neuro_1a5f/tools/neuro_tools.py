#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import re

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def _artifact_path(filename: str) -> Path:
    path = Path(__file__).resolve().parents[1] / "artifacts" / filename
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def workbook_sections(path: str) -> dict:
    df = pd.read_excel(path, header=None)
    starts = [(int(i), str(v)) for i, v in df[0].dropna().items() if str(v).startswith("Data for Figure")]
    sections = []
    for pos, (start, label) in enumerate(starts):
        end = starts[pos + 1][0] if pos + 1 < len(starts) else len(df)
        block = df.iloc[start:end].dropna(how="all").dropna(axis=1, how="all")
        sections.append({"label": label, "start_row": start, "end_row": end, "shape": list(block.shape)})
    return {"source": str(path), "sections": sections}


def _section_block(path: str, label: str) -> pd.DataFrame:
    df = pd.read_excel(path, header=None)
    starts = [(int(i), str(v)) for i, v in df[0].dropna().items() if str(v).startswith("Data for Figure")]
    for pos, (start, section_label) in enumerate(starts):
        if section_label == label:
            end = starts[pos + 1][0] if pos + 1 < len(starts) else len(df)
            return df.iloc[start:end].reset_index(drop=True)
    raise ValueError(f"Workbook section not found: {label}")


def _section_by_header_terms(path: str, required_terms: list[str]) -> tuple[str, pd.DataFrame]:
    df = pd.read_excel(path, header=None)
    sections = workbook_sections(path)["sections"]
    terms = [term.lower() for term in required_terms]
    for section in sections:
        block = df.iloc[section["start_row"]:section["end_row"]].reset_index(drop=True)
        text = " ".join(str(x).lower() for x in block.to_numpy().ravel() if pd.notna(x))
        if all(term in text for term in terms):
            return section["label"], block
    raise ValueError(f"No section contains all header terms: {required_terms}")


def _ffill_header(row: pd.Series) -> list[str | None]:
    current = None
    out = []
    for value in row:
        if pd.notna(value):
            current = str(value).strip()
        out.append(current)
    return out


def figure1_aversion_summary(path: str) -> dict:
    section_label, block = _section_by_header_terms(path, ["male experimenters", "female experimenters"])
    strain_headers = _ffill_header(block.iloc[1])
    experimenter_headers = block.iloc[2]
    rows = []
    for col in block.columns:
        header = str(experimenter_headers[col]).strip().lower() if pd.notna(experimenter_headers[col]) else ""
        if "experimenter" not in header:
            continue
        vals = pd.to_numeric(block.iloc[3:, col], errors="coerce").dropna()
        if vals.empty:
            continue
        condition = "male experimenter" if header.startswith("male") else "female experimenter"
        rows.append({
            "strain": strain_headers[col],
            "condition": condition,
            "source_column": int(col),
            "mean": float(vals.mean()),
            "sem": float(vals.sem()),
            "n": int(len(vals)),
        })
    return {"source_section": section_label, "rows": rows}


def figure2_ketamine_summary(path: str) -> dict:
    section_label, block = _section_by_header_terms(path, ["pair", "male experimenter", "female experimenter", "sal", "ket"])
    pair_headers = _ffill_header(block.iloc[1])
    experimenter_headers = _ffill_header(block.iloc[2])
    treatment_headers = block.iloc[3]
    rows = []
    for col in block.columns:
        treatment = str(treatment_headers[col]).strip().upper() if pd.notna(treatment_headers[col]) else ""
        if treatment not in {"SAL", "KET"}:
            continue
        vals = pd.to_numeric(block.iloc[4:, col], errors="coerce").dropna()
        if vals.empty:
            continue
        pair_text = pair_headers[col] or ""
        pair_match = re.search(r"(\d+)", pair_text)
        experimenter_text = (experimenter_headers[col] or "").lower()
        experimenter = "male" if experimenter_text.startswith("male") else "female"
        rows.append({
            "pair": int(pair_match.group(1)) if pair_match else None,
            "experimenter": experimenter,
            "treatment": treatment,
            "source_column": int(col),
            "mean": float(vals.mean()),
            "sem": float(vals.sem()),
            "n": int(len(vals)),
        })
    frame = pd.DataFrame(rows)
    contrasts = []
    for experimenter in ["male", "female"]:
        sal = frame[(frame.experimenter == experimenter) & (frame.treatment == "SAL")]["mean"].mean()
        ket = frame[(frame.experimenter == experimenter) & (frame.treatment == "KET")]["mean"].mean()
        contrasts.append({"experimenter": experimenter, "ket_minus_sal": float(ket - sal)})
    return {"source_section": section_label, "n_pairs_detected": int(pd.Series([r["pair"] for r in rows]).dropna().nunique()), "rows": rows, "ketamine_contrasts": contrasts}


def figure3_crf_summary(path: str) -> dict:
    section_label, block = _section_by_header_terms(path, ["sal", "ket", "veh", "crf"])
    treatment_headers = _ffill_header(block.iloc[1])
    pretreatment_headers = block.iloc[2]
    rows = []
    for col in block.columns:
        treatment = str(treatment_headers[col]).strip().upper() if treatment_headers[col] else ""
        pretreatment = str(pretreatment_headers[col]).strip().upper() if pd.notna(pretreatment_headers[col]) else ""
        if treatment not in {"SAL", "KET"} or pretreatment not in {"VEH", "CRF"}:
            continue
        vals = pd.to_numeric(block.iloc[4:, col], errors="coerce").dropna()
        if vals.empty:
            continue
        rows.append({"treatment": treatment, "pretreatment": pretreatment, "source_column": int(col), "mean": float(vals.mean()), "sem": float(vals.sem()), "n": int(len(vals))})
    frame = pd.DataFrame(rows)
    ket_crf = float(frame[(frame.treatment == "KET") & (frame.pretreatment == "CRF")]["mean"].iloc[0])
    ket_veh = float(frame[(frame.treatment == "KET") & (frame.pretreatment == "VEH")]["mean"].iloc[0])
    sal_crf = float(frame[(frame.treatment == "SAL") & (frame.pretreatment == "CRF")]["mean"].iloc[0])
    sal_veh = float(frame[(frame.treatment == "SAL") & (frame.pretreatment == "VEH")]["mean"].iloc[0])
    return {
        "source_section": section_label,
        "rows": rows,
        "crf_minus_vehicle_under_ketamine": ket_crf - ket_veh,
        "crf_minus_vehicle_under_saline": sal_crf - sal_veh,
    }


def plot_experimenter_aversion(path: str, output_filename: str = "experimenter_aversion.png") -> dict:
    result = figure1_aversion_summary(path)
    rows = result["rows"]
    labels = [f"{r['strain']}\n{r['condition'].split()[0]}" for r in rows]
    output = _artifact_path(output_filename)
    fig, ax = plt.subplots(figsize=(7.6, 4.6))
    ax.bar(labels, [r["mean"] for r in rows], yerr=[r["sem"] for r in rows], color="#4C78A8", capsize=3)
    ax.set_ylabel("Mean Fig. 1A response")
    ax.set_title("Male versus female experimenter context")
    ax.tick_params(axis="x", rotation=30)
    fig.tight_layout()
    fig.savefig(output, dpi=200)
    plt.close(fig)
    return {"path": str(output), **result}


def plot_ketamine_modulation(path: str, output_filename: str = "ketamine_modulation.png") -> dict:
    result = figure2_ketamine_summary(path)
    frame = pd.DataFrame(result["rows"])
    grouped = frame.groupby(["experimenter", "treatment"], as_index=False).agg(mean=("mean", "mean"), sem=("mean", "sem"))
    labels = [f"{r.experimenter}\n{r.treatment}" for r in grouped.itertuples(index=False)]
    output = _artifact_path(output_filename)
    fig, ax = plt.subplots(figsize=(6.8, 4.4))
    ax.bar(labels, grouped["mean"], yerr=grouped["sem"].fillna(0), color="#F58518", capsize=3)
    ax.set_ylabel("Mean Fig. 2A immobility")
    ax.set_title("Ketamine response by experimenter sex")
    fig.tight_layout()
    fig.savefig(output, dpi=200)
    plt.close(fig)
    return {"path": str(output), **result}


def plot_crf_rescue(path: str, output_filename: str = "crf_rescue.png") -> dict:
    result = figure3_crf_summary(path)
    rows = result["rows"]
    labels = [f"{r['treatment']}\n{r['pretreatment']}" for r in rows]
    output = _artifact_path(output_filename)
    fig, ax = plt.subplots(figsize=(6.2, 4.3))
    ax.bar(labels, [r["mean"] for r in rows], yerr=[r["sem"] for r in rows], color="#54A24B", capsize=3)
    ax.set_ylabel("Mean Fig. 3A response")
    ax.set_title("CRF-linked modulation of ketamine response")
    fig.tight_layout()
    fig.savefig(output, dpi=200)
    plt.close(fig)
    return {"path": str(output), **result}

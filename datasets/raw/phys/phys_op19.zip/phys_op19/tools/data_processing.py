"""Generic data-processing helpers (no `pass` stubs).

Light-weight CSV/JSON IO and tabular reshaping for the ST-OPV task. All
functions are stand-alone; no pandas/numpy required for the trivial helpers
so they remain importable in minimal environments.
"""
from __future__ import annotations

import csv
import json
from typing import Any, Iterable


def read_csv(path: str, delimiter: str = ",") -> list[dict]:
    """Parse CSV into a list of dicts using the first row as header."""
    with open(path, newline="") as f:
        return list(csv.DictReader(f, delimiter=delimiter))


def write_csv(rows: list[dict], path: str) -> None:
    """Write a list of dicts to CSV. Uses the first row's keys as fieldnames."""
    if not rows:
        open(path, "w").close()
        return
    with open(path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def read_json(path: str) -> Any:
    with open(path) as f:
        return json.load(f)


def write_json(obj: Any, path: str, indent: int = 2) -> None:
    with open(path, "w") as f:
        json.dump(obj, f, indent=indent, default=str)


def read_excel(path: str, sheet_name: str | int | None = 0) -> list[dict]:
    """Read an .xlsx sheet via openpyxl into a list of dicts.

    The first non-empty row is treated as the header. Empty rows below the
    last header column are skipped.
    """
    import openpyxl
    wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    if isinstance(sheet_name, int):
        ws = wb[wb.sheetnames[sheet_name]]
    elif sheet_name is None:
        ws = wb[wb.sheetnames[0]]
    else:
        ws = wb[sheet_name]
    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        return []
    header = [str(c) if c is not None else f"col_{i}" for i, c in enumerate(rows[0])]
    out: list[dict] = []
    for r in rows[1:]:
        if all(v is None for v in r):
            continue
        out.append({header[i]: r[i] if i < len(r) else None for i in range(len(header))})
    return out


def coerce_numeric(rows: list[dict], columns: list[str]) -> list[dict]:
    """Cast named columns of each row to float; non-parseable becomes None."""
    out = []
    for row in rows:
        new = dict(row)
        for c in columns:
            if c in new:
                try:
                    new[c] = float(new[c]) if new[c] not in (None, "") else None
                except (TypeError, ValueError):
                    new[c] = None
        out.append(new)
    return out


def drop_missing(rows: list[dict], columns: Iterable[str] | None = None) -> list[dict]:
    """Remove rows that contain None/empty in any of the listed columns."""
    cols = list(columns) if columns else None
    out = []
    for row in rows:
        check = cols if cols else list(row.keys())
        if all(row.get(c) not in (None, "") for c in check):
            out.append(row)
    return out


def groupby_aggregate(
    rows: list[dict], by: str, value_col: str, agg: str = "mean",
) -> list[dict]:
    """Group rows by a key and aggregate one numeric column.

    Supported aggregations: ``mean``, ``sum``, ``min``, ``max``, ``count``.
    """
    groups: dict[Any, list[float]] = {}
    for r in rows:
        key = r.get(by)
        try:
            val = float(r.get(value_col))
        except (TypeError, ValueError):
            continue
        groups.setdefault(key, []).append(val)
    result: list[dict] = []
    for k, vals in groups.items():
        if agg == "mean":
            v = sum(vals) / len(vals) if vals else float("nan")
        elif agg == "sum":
            v = sum(vals)
        elif agg == "min":
            v = min(vals)
        elif agg == "max":
            v = max(vals)
        elif agg == "count":
            v = len(vals)
        else:
            raise ValueError(f"Unknown agg '{agg}'")
        result.append({by: k, value_col: v})
    return result


def join_tables(
    left: list[dict], right: list[dict], on: str, how: str = "inner",
) -> list[dict]:
    """SQL-style join of two row-of-dicts tables on a single column."""
    right_by_key = {r[on]: r for r in right if on in r}
    out: list[dict] = []
    if how in ("inner", "left"):
        for lr in left:
            key = lr.get(on)
            rr = right_by_key.get(key)
            if rr is None:
                if how == "left":
                    merged = dict(lr)
                    out.append(merged)
                continue
            merged = dict(lr); merged.update({k: v for k, v in rr.items() if k != on})
            out.append(merged)
    else:
        raise ValueError("Only 'inner' and 'left' joins implemented")
    return out

# phys_op19 — Tool Reference

Tools for analysing semi-transparent organic photovoltaic (ST-OPV) source
data: J-V curves, transmittance/EQE spectra, photovoltaic figures of merit
(Voc / Jsc / FF / PCE), photopic-weighted AVT, light-utilisation efficiency
(LUE = PCE x AVT), and per-city geographical aggregation.

## opv_analysis.py — Domain primitives (FastMCP server)

Source-data IO
- **load_source_sheet**: Pull a Source-Data xlsx sheet as `{columns, n_rows, rows}`.
- **list_source_sheets**: List sheet names in the xlsx workbook.
- **extract_two_column_series**: Clean numeric (x, y) series from any column pair.

Photovoltaic figures of merit
- **extract_jv_parameters**: Voc, Jsc, FF, PCE, V_mp, J_mp from a J-V sweep
  (assumes one-sun AM1.5G, 100 mW/cm^2 input).

Optical figures of merit
- **average_visible_transmittance**: Photopic V(lambda) + AM1.5G-weighted AVT.
  Default band 380-780 nm; the paper's photopic integrals use 380-740 nm, but
  V(lambda)~0 beyond 700 nm so the two give the same AVT to <0.01%.
- **solar_weighted_transmittance**: spectrally-weighted average transmittance
  over an arbitrary band, returning `rejection_percent` = 100 - T_weighted as a
  proxy for the paper's T-SER (300-2500 nm) / NIR-SER (780-2500 nm) solar energy
  rejection. APPROXIMATION: it weights by the bundled AM1.5G *photon flux* shape,
  not the absolute AM1.5G *power* (W m^-2 nm^-1) spectrum the paper uses for SER,
  so it is a relative/approximate SER (see the docstring).
- **light_utilization_efficiency**: LUE = PCE x AVT (paper convention).
- **fom_lue**: relative FoM_LUE index following the *structure* of Eq. 1 of Yu
  et al. 2025 (absorbed-light integral over 300..1240/Eg, photopic AVT factor
  over 380-740 nm, and (Eg/q-0.3)/P_sun factor), taking film absorbance and
  optical bandgap. Uses the bundled relative AM1.5G shape, so it preserves the
  donor/acceptor *ranking* (the paper's only use of FoM_LUE) but is not the
  absolute Eq.-1 value; pass a calibrated spectrum for the absolute figure.

Geographical aggregation
- **aggregate_per_city**: Mean / std / quantiles for the per-city Source Data
  sheet (Fig 6 — 371 Chinese cities); optional grouping column for climate
  zones.
- **classify_city_thermal_regime**: Assign each Fig 6 city to a data-driven
  thermal-load regime (cooling_dominated / mixed / heating_dominated) by terciles
  of its bundled added-heating-load signature. NOTE: this is a heat-load proxy,
  NOT the official "Code for Thermal Design of Civil Buildings" zoning — the
  Source Data ships no per-city zone label or city->zone mapping. The
  cooling-dominated regime is the physical analogue of the paper's
  hot-summer/warm-winter end.
- **thermal_regime_energy_balance**: Per-regime annual energy balance
  (power output + net reduced load, GJ/m^2/yr); names the regime with the highest
  mean balance. Uses the data-driven thermal-regime split by default, or any
  caller-supplied per-city `zone_labels` if an external classification is
  available. `THERMAL_REGIMES` documents the three load-tertile regimes.

Plotting (one tool per image answer)
- **plot_jv_curves**: Fig 3d — overlay J-V for 11-nm Ag, 40-nm TeO2 and ABPF
  ST-OPVs; returns extracted device parameters per curve.
- **plot_transmittance_spectra**: Fig 3c — transmittance curves with the
  visible band shaded and AVT computed for each curve.
- **plot_thickness_tradeoff**: Fig 3b — Jsc/PCE/AVT/LUE vs active-layer
  thickness for the 11-nm Ag baseline.
- **plot_geographical_violin**: Fig 6 — violin distribution of annual power
  output and reduced cooling+heating loads across 371 Chinese cities.

Misc
- **write_summary_json**: Persist any dict to a JSON file.

## data_processing.py — Generic helpers (no FastMCP)

`read_csv`, `write_csv`, `read_json`, `write_json`, `read_excel`,
`coerce_numeric`, `drop_missing`, `groupby_aggregate`, `join_tables`.
All implemented (no `pass` stubs).

## database_retrieval.py — Lightweight HTTP/REST helpers

`fetch_url`, `fetch_text`, `query_doi` (Crossref), `query_openalex`,
`query_pubmed` (NCBI Entrez), `websearch` (DuckDuckGo HTML).

## Dependencies

```
python>=3.10
numpy>=1.24
matplotlib>=3.7
openpyxl>=3.1
mcp[cli]>=1.0   # for FastMCP decorators
```

Install: `pip install numpy matplotlib openpyxl 'mcp[cli]'`

## Running the FastMCP server

```bash
python tools/opv_analysis.py        # exposes all opv_* tools over FastMCP
```

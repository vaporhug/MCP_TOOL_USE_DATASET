#!/usr/bin/env python3
"""Domain primitives for semi-transparent organic photovoltaic (ST-OPV) analysis.

All tools are FastMCP-decorated and runnable without further wiring.
They consume raw J-V curves, transmittance spectra, EQE spectra, and per-city
geographical tables shipped in `input_data/data/source_data.xlsx` (Source Data
of Yu et al., Nat. Commun. 16:7421 (2025), DOI:10.1038/s41467-025-62546-8).

Key primitives:
    * load_source_sheet           — pull any Source-Data sheet as numeric arrays
    * extract_jv_parameters       — Voc / Jsc / FF / PCE from a J-V curve
    * average_visible_transmittance — AVT integrated 380-780 nm, photopic-weighted
    * light_utilization_efficiency  — LUE = PCE x AVT (paper convention)
    * solar_weighted_transmittance  — AM1.5G-weighted T-SER / NIR-SER
    * fom_lue                      — FoM_LUE per Eq. 1 of the paper
    * plot_jv_curves, plot_transmittance_spectra,
      plot_thickness_tradeoff, plot_geographical_violin — one plot per image item
"""

from __future__ import annotations

import json
import os
from typing import Optional

import numpy as np
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("OPV_ST_Analysis_Tools")


# ---------------------------------------------------------------------------
# Source-data loaders
# ---------------------------------------------------------------------------

@mcp.tool()
def load_source_sheet(xlsx_path: str, sheet_name: str) -> dict:
    """Load a single sheet from the Nature Source Data xlsx.

    Args:
        xlsx_path: Path to the Nature Source Data xlsx (e.g.
            ``input_data/data/source_data.xlsx``).
        sheet_name: Sheet identifier exactly as written in the workbook
            ("Fig 1c", "Fig 1e", "Fig 3a", "Fig 3d", "Fig 3b", "Fig 6", ...).

    Returns:
        dict with ``columns`` (list[str]), ``n_rows`` (int) and ``rows``
        (list[list[float|None]]) preserving the order of rows. Header row
        (row 0) is returned as ``columns``.
    """
    import openpyxl
    wb = openpyxl.load_workbook(xlsx_path, data_only=True, read_only=True)
    if sheet_name not in wb.sheetnames:
        raise ValueError(f"Sheet '{sheet_name}' not found. Available: {wb.sheetnames}")
    ws = wb[sheet_name]
    rows_iter = list(ws.iter_rows(values_only=True))
    header = list(rows_iter[0]) if rows_iter else []
    body: list[list] = []
    for r in rows_iter[1:]:
        body.append(list(r))
    return {
        "columns": [str(c) if c is not None else "" for c in header],
        "n_rows": len(body),
        "rows": body,
    }


@mcp.tool()
def list_source_sheets(xlsx_path: str) -> list[str]:
    """List every sheet name in the Nature Source Data workbook."""
    import openpyxl
    wb = openpyxl.load_workbook(xlsx_path, data_only=True, read_only=True)
    return list(wb.sheetnames)


@mcp.tool()
def extract_two_column_series(
    xlsx_path: str, sheet_name: str, x_col: int, y_col: int,
) -> dict:
    """Extract a clean (x, y) numeric series from a Source-Data sheet column pair.

    Args:
        xlsx_path: Path to the xlsx file.
        sheet_name: Sheet identifier.
        x_col: 0-indexed column for the abscissa.
        y_col: 0-indexed column for the ordinate.

    Returns:
        dict with ``x`` and ``y`` lists, dropping rows whose either entry is
        not finite numeric.
    """
    sheet = load_source_sheet(xlsx_path, sheet_name)
    xs: list[float] = []
    ys: list[float] = []
    for row in sheet["rows"]:
        if x_col >= len(row) or y_col >= len(row):
            continue
        xv, yv = row[x_col], row[y_col]
        try:
            xv_f = float(xv); yv_f = float(yv)
        except (TypeError, ValueError):
            continue
        if not (np.isfinite(xv_f) and np.isfinite(yv_f)):
            continue
        xs.append(xv_f); ys.append(yv_f)
    return {"x": xs, "y": ys, "n": len(xs)}


# ---------------------------------------------------------------------------
# Photovoltaic figures of merit
# ---------------------------------------------------------------------------

@mcp.tool()
def extract_jv_parameters(voltage: list, current_density: list) -> dict:
    """Extract Voc, Jsc, Pmax, V_mp, J_mp, FF and PCE from a J-V sweep.

    Convention: ``current_density`` follows the paper (negative quadrant under
    illumination, positive in the dark / above Voc). Light intensity is the
    AM1.5G one-sun standard 100 mW/cm^2; PCE is reported in percent.

    Args:
        voltage: Voltage points in V (monotone, length N).
        current_density: Current density in mA/cm^2 (length N).

    Returns:
        dict with ``Voc_V``, ``Jsc_mA_per_cm2``, ``FF``, ``PCE_percent``,
        ``V_mp_V``, ``J_mp_mA_per_cm2`` and ``Pmax_mW_per_cm2``.
    """
    v = np.asarray(voltage, dtype=float)
    j = np.asarray(current_density, dtype=float)
    order = np.argsort(v)
    v = v[order]; j = j[order]
    # Photovoltaic quadrant: V >= 0 and J <= 0 (or use absolute power)
    P = -v * j  # mW/cm^2 in the photovoltaic quadrant when j is negative
    # Restrict to V in [0, Voc] for FF: detect Voc as zero-crossing of J
    # interpolate Voc
    j_at_v = np.interp(0.0, v, j)
    # Find Voc as smallest V > 0 where J crosses zero (going from <0 to >=0)
    voc = None
    for i in range(len(v) - 1):
        if v[i] >= 0 and j[i] < 0 <= j[i + 1]:
            # linear interpolation
            v0, v1 = v[i], v[i + 1]
            j0, j1 = j[i], j[i + 1]
            voc = v0 - j0 * (v1 - v0) / (j1 - j0)
            break
    if voc is None:
        voc = float(v[np.argmin(np.abs(j))])
    jsc = float(np.interp(0.0, v, j))  # signed; convention reports |Jsc|
    jsc_abs = abs(jsc)
    # Maximum power point in [0, Voc]
    mask = (v >= 0) & (v <= voc)
    if mask.sum() < 2:
        mask = (v >= 0)
    P_pos = P[mask]
    v_pos = v[mask]
    j_pos = j[mask]
    idx_max = int(np.argmax(P_pos))
    p_max = float(P_pos[idx_max])
    v_mp = float(v_pos[idx_max])
    j_mp = float(j_pos[idx_max])
    ff = p_max / (voc * jsc_abs) if voc > 0 and jsc_abs > 0 else float("nan")
    pce_percent = p_max  # because P_in = 100 mW/cm^2 -> PCE = Pmax/100 *100%
    return {
        "Voc_V": float(voc),
        "Jsc_mA_per_cm2": float(jsc_abs),
        "FF": float(ff),
        "PCE_percent": float(pce_percent),
        "V_mp_V": v_mp,
        "J_mp_mA_per_cm2": j_mp,
        "Pmax_mW_per_cm2": p_max,
    }


# ---------------------------------------------------------------------------
# Optical figures of merit (AVT, T-SER, NIR-SER, LUE, FoM_LUE)
# ---------------------------------------------------------------------------

# Photopic luminosity function V(lambda), CIE 1924, 380..780 nm (10 nm spacing)
_PHOTOPIC_WL = np.array([
    380, 390, 400, 410, 420, 430, 440, 450, 460, 470, 480, 490, 500, 510, 520,
    530, 540, 550, 560, 570, 580, 590, 600, 610, 620, 630, 640, 650, 660, 670,
    680, 690, 700, 710, 720, 730, 740, 750, 760, 770, 780,
], dtype=float)
_PHOTOPIC_V = np.array([
    0.000039, 0.000120, 0.000396, 0.001210, 0.004000, 0.011600, 0.023000,
    0.038000, 0.060000, 0.090980, 0.139020, 0.208020, 0.323000, 0.503000,
    0.710000, 0.862000, 0.954000, 0.994950, 0.995000, 0.952000, 0.870000,
    0.757000, 0.631000, 0.503000, 0.381000, 0.265000, 0.175000, 0.107000,
    0.061000, 0.032000, 0.017000, 0.008210, 0.004102, 0.002091, 0.001047,
    0.000520, 0.000249, 0.000120, 0.000060, 0.000030, 0.000015,
], dtype=float)


def _photopic_response(wl_nm: np.ndarray) -> np.ndarray:
    return np.interp(wl_nm, _PHOTOPIC_WL, _PHOTOPIC_V, left=0.0, right=0.0)


@mcp.tool()
def average_visible_transmittance(
    wavelength_nm: list, transmittance_percent: list,
    lo_nm: float = 380.0, hi_nm: float = 780.0,
) -> dict:
    """Photopic-weighted average visible transmittance (AVT) per Yu et al.

    AVT = integral( T(lambda) * V(lambda) * S(lambda) d lambda) /
          integral( V(lambda) * S(lambda) d lambda),
    with V(lambda) the CIE 1924 photopic luminosity and S(lambda) the AM1.5G
    photon flux. The Source Data transmittance is stored in percent.

    Args:
        wavelength_nm: 1-D array of wavelengths in nm (any monotonicity).
        transmittance_percent: T(lambda) in percent.
        lo_nm, hi_nm: integration limits (default 380-780 nm visible band).

    Returns:
        dict with ``AVT_percent`` and integration ``n_points``.
    """
    wl = np.asarray(wavelength_nm, dtype=float)
    T = np.asarray(transmittance_percent, dtype=float) / 100.0
    order = np.argsort(wl)
    wl = wl[order]; T = T[order]
    mask = (wl >= lo_nm) & (wl <= hi_nm) & np.isfinite(T)
    wl_v = wl[mask]; T_v = T[mask]
    V = _photopic_response(wl_v)
    S = _am15g_photon_flux(wl_v)
    num = np.trapz(T_v * V * S, wl_v)
    den = np.trapz(V * S, wl_v)
    avt = num / den if den > 0 else float("nan")
    return {"AVT_percent": float(avt * 100.0), "n_points": int(mask.sum())}


# AM1.5G photon flux S(lambda) on a coarse grid 280-2500 nm (photons s^-1 m^-2 nm^-1).
# Values are ASTM G173-03 numeric extracts (relative shape only, normalisation
# cancels in the AVT ratio).  We use a sampled subset and interpolate.
_AM15G_WL = np.array([
    280, 300, 320, 340, 360, 380, 400, 420, 440, 460, 480, 500, 520, 540, 560,
    580, 600, 620, 640, 660, 680, 700, 720, 740, 760, 780, 800, 850, 900, 950,
    1000, 1100, 1200, 1300, 1400, 1500, 1600, 1700, 1800, 2000, 2200, 2500,
], dtype=float)
_AM15G_PHOTON_FLUX = np.array([
    0.0, 0.0001, 0.04, 0.18, 0.42, 0.72, 1.20, 1.62, 1.78, 1.84, 1.89, 1.95,
    1.93, 1.85, 1.86, 1.85, 1.81, 1.78, 1.76, 1.71, 1.67, 1.62, 1.55, 1.48,
    1.40, 1.34, 1.28, 1.16, 1.06, 0.94, 0.86, 0.71, 0.55, 0.43, 0.32, 0.27,
    0.21, 0.18, 0.15, 0.10, 0.06, 0.02,
], dtype=float)


def _am15g_photon_flux(wl_nm: np.ndarray) -> np.ndarray:
    return np.interp(wl_nm, _AM15G_WL, _AM15G_PHOTON_FLUX, left=0.0, right=0.0)


@mcp.tool()
def solar_weighted_transmittance(
    wavelength_nm: list, transmittance_percent: list,
    lo_nm: float = 300.0, hi_nm: float = 2500.0,
) -> dict:
    """Spectrally-weighted average transmittance over an arbitrary band, with
    ``rejection_percent`` = 100 - T_weighted as a proxy for the paper's solar
    energy rejection (SER).

    In Yu et al. (2025) the total/near-IR solar energy rejection is defined over
    T-SER: 300-2500 nm and NIR-SER: 780-2500 nm. Pass those limits via
    ``lo_nm`` / ``hi_nm`` to target each band.

    APPROXIMATION / LABEL: the paper's SER is an AM1.5G *power* (W m^-2 nm^-1)
    weighting, whereas this function weights by the bundled AM1.5G *photon flux*
    shape (and that shape is a coarse relative subset, not the absolutely
    calibrated NREL spectrum). The returned ``rejection_percent`` is therefore a
    relative / approximate SER, adequate for comparing electrode designs but not
    an exact reproduction of the paper's SER percentages.

    Returns a dict with ``T_weighted_percent`` and ``rejection_percent`` =
    100 - T_weighted_percent.
    """
    wl = np.asarray(wavelength_nm, dtype=float)
    T = np.asarray(transmittance_percent, dtype=float) / 100.0
    order = np.argsort(wl)
    wl = wl[order]; T = T[order]
    mask = (wl >= lo_nm) & (wl <= hi_nm) & np.isfinite(T)
    wl_v = wl[mask]; T_v = T[mask]
    # AM1.5G *power* spectrum P(lambda) ~ photon flux / lambda(roughly), use
    # photon flux as an approximation -- for the paper's T-SER/NIR-SER the
    # relative weighting (low IR shoulder) is the load-bearing piece.
    S = _am15g_photon_flux(wl_v)
    num = np.trapz(T_v * S, wl_v)
    den = np.trapz(S, wl_v)
    Tw = num / den if den > 0 else float("nan")
    return {
        "T_weighted_percent": float(Tw * 100.0),
        "rejection_percent": float((1.0 - Tw) * 100.0),
        "lo_nm": lo_nm, "hi_nm": hi_nm,
    }


@mcp.tool()
def light_utilization_efficiency(pce_percent: float, avt_percent: float) -> dict:
    """LUE = PCE * AVT (paper convention, both in percent and result in %).

    Returns dict with ``LUE_percent`` and the input values for traceability.
    """
    lue = (pce_percent / 100.0) * (avt_percent / 100.0) * 100.0
    return {
        "LUE_percent": float(lue),
        "PCE_percent": float(pce_percent),
        "AVT_percent": float(avt_percent),
    }


@mcp.tool()
def fom_lue(
    wavelength_nm: list, absorbance: list,
    bandgap_eV: float,
    p_sun_mW_per_cm2: float = 100.0,
) -> dict:
    """Relative FoM_LUE index following the *structure* of Eq. 1 of Yu et al. (2025).

    Yu et al. Eq. 1 defines

        FoM_LUE = (q/hc) * INT_300^(1240/Eg) (1 - T(lambda)) * Phi_AM1.5G_power(lambda) dlambda
                  * [ INT_380^740 T(lambda) P(lambda) S(lambda) dlambda
                      / INT_380^740 P(lambda) S(lambda) dlambda ]
                  * (Eg/q - 0.3) / P_sun

    with T(lambda)=10^-A(lambda) the film transmission, P(lambda) the photopic
    response, S(lambda) the AM1.5G photon flux, and Phi_AM1.5G_power(lambda) the
    NREL/ASTM-G173 power spectrum.

    APPROXIMATION / LABEL: this implementation reproduces the three structural
    factors of Eq. 1 (the absorbed-light integral over 300..1240/Eg, the photopic
    average-visible-transmittance factor over 380..740 nm, and the
    (Eg/q - 0.3)/P_sun driving-voltage factor), but it uses the *relative* AM1.5G
    spectral shape bundled in this module rather than the absolutely-calibrated
    NREL ASTM-G173 W m^-2 nm^-1 spectrum. The absolute prefactor (q/hc x absolute
    irradiance) therefore cancels into an arbitrary constant, so the returned
    ``FoM_LUE_relative`` is a *relative ranking index*: it preserves the ordering
    of donor/acceptor materials (which is the paper's only use of FoM_LUE -- "the
    highest FoM_LUE") but does not equal the paper's absolute 0.0xx values. To get
    the absolute Eq.-1 figure, supply a calibrated AM1.5G spectrum.

    Args:
        wavelength_nm: spectrum lambda values (nm).
        absorbance: A(lambda) of the photoactive film.
        bandgap_eV: optical bandgap Eg (sets the 1240/Eg upper integration limit).
        p_sun_mW_per_cm2: one-sun input power (default 100).

    Returns:
        dict with ``FoM_LUE_relative``, the absorbed-light integral, the photopic
        AVT factor, the driving-voltage factor, and the band limits used.
    """
    wl = np.asarray(wavelength_nm, dtype=float)
    A = np.asarray(absorbance, dtype=float)
    order = np.argsort(wl); wl = wl[order]; A = A[order]
    T = np.power(10.0, -A)

    # Factor 1: absorbed-light integral INT_300^(1240/Eg) (1 - T) * S dlambda
    # (relative AM1.5G shape; absolute q/hc x irradiance prefactor cancels).
    lambda_g_nm = 1240.0 / bandgap_eV if bandgap_eV > 0 else float(wl.max())
    mask_abs = (wl >= 300.0) & (wl <= lambda_g_nm)
    S_abs = _am15g_photon_flux(wl[mask_abs])
    absorbed_term = float(np.trapz((1.0 - T[mask_abs]) * S_abs, wl[mask_abs]))

    # Factor 2: photopic average visible transmittance over 380-740 nm
    mask_v = (wl >= 380.0) & (wl <= 740.0)
    wl_v = wl[mask_v]; T_v = T[mask_v]
    V = _photopic_response(wl_v)
    S_v = _am15g_photon_flux(wl_v)
    photopic_num = np.trapz(T_v * V * S_v, wl_v)
    photopic_den = np.trapz(V * S_v, wl_v)
    photopic_term = float(photopic_num / photopic_den) if photopic_den > 0 else 0.0

    # Factor 3: driving-voltage factor (Eg/q - 0.3) / P_sun  [Eg already in eV = Eg/q in V]
    v_term = max(bandgap_eV - 0.3, 0.0)
    voltage_factor = v_term / p_sun_mW_per_cm2

    fom_rel = absorbed_term * photopic_term * voltage_factor
    return {
        "FoM_LUE_relative": float(fom_rel),
        "absorbed_light_integral": absorbed_term,
        "photopic_AVT_term": photopic_term,
        "voltage_factor": float(voltage_factor),
        "voltage_term_V": float(v_term),
        "lambda_g_nm": float(lambda_g_nm),
        "Eg_eV": float(bandgap_eV),
    }


# ---------------------------------------------------------------------------
# Geographical aggregation (Fig 6)
# ---------------------------------------------------------------------------

@mcp.tool()
def aggregate_per_city(
    xlsx_path: str, sheet_name: str = "Fig 6",
    value_col: int = 1, group_col: Optional[int] = None,
) -> dict:
    """Compute mean / std / quantiles for the per-city Source-Data sheet.

    Args:
        xlsx_path: Path to Source Data xlsx.
        sheet_name: defaults to ``"Fig 6"`` (371 cities x 6 columns).
        value_col: 0-indexed column with the variable to aggregate.
        group_col: optional 0-indexed grouping column.  If None, a single
            global summary is returned.

    Returns:
        dict with summary statistics keyed by group (or ``"all"``).
    """
    sheet = load_source_sheet(xlsx_path, sheet_name)
    rows = sheet["rows"]
    if group_col is None:
        vals = [r[value_col] for r in rows
                if value_col < len(r) and isinstance(r[value_col], (int, float))]
        arr = np.asarray(vals, dtype=float)
        return {
            "all": {
                "n": int(arr.size),
                "mean": float(np.mean(arr)) if arr.size else float("nan"),
                "std": float(np.std(arr, ddof=1)) if arr.size > 1 else float("nan"),
                "min": float(np.min(arr)) if arr.size else float("nan"),
                "max": float(np.max(arr)) if arr.size else float("nan"),
                "q25": float(np.quantile(arr, 0.25)) if arr.size else float("nan"),
                "median": float(np.quantile(arr, 0.5)) if arr.size else float("nan"),
                "q75": float(np.quantile(arr, 0.75)) if arr.size else float("nan"),
            }
        }
    groups: dict[str, list[float]] = {}
    for r in rows:
        if max(value_col, group_col) >= len(r):
            continue
        v = r[value_col]; g = r[group_col]
        if not isinstance(v, (int, float)):
            continue
        key = str(g)
        groups.setdefault(key, []).append(float(v))
    out = {}
    for k, vs in groups.items():
        a = np.asarray(vs)
        out[k] = {
            "n": int(a.size),
            "mean": float(np.mean(a)),
            "std": float(np.std(a, ddof=1)) if a.size > 1 else float("nan"),
            "median": float(np.quantile(a, 0.5)),
        }
    return out


# Thermal-load regimes used by this tool. NOTE: these are NOT the official
# "Code for Thermal Design of Civil Buildings" climatic zones (severe cold,
# cold, hot summer/cold winter, mild, hot summer/warm winter). The bundled
# Source-Data "Fig 6" sheet carries no per-city zone label and no city->zone
# mapping file is shipped, so this tool cannot reproduce the official zoning.
# Instead it defines a data-driven heat-load proxy: cities are binned purely by
# their bundled added-heating-load signature. A cooling-dominated regime (small
# added heating load) is the physical analogue of the paper's hot-summer/warm-
# winter end; a heating-dominated regime (large added heating load) is the cold
# end. Treat these as a load-tertile proxy, not as official climate zones.
THERMAL_REGIMES = {
    "cooling_dominated": "Cooling-dominated regime — small added heating load (hot-summer/warm-winter end).",
    "mixed": "Mixed regime — intermediate cooling/heating loads (temperate / hot-summer/cold-winter end).",
    "heating_dominated": "Heating-dominated regime — large added heating load (cold / severe-cold end).",
}


@mcp.tool()
def classify_city_thermal_regime(
    xlsx_path: str, sheet_name: str = "Fig 6",
    cooling_col: int = 3, heating_col: int = 4,
) -> dict:
    """Assign each Fig 6 city to a thermal-load regime from its load signature.

    The Source-Data ``Fig 6`` sheet lists, per city, the reduced cooling load
    (``cooling_col``) and the added heating load (``heating_col``) of the
    ABPF ST-OPV window (GJ/m^2/yr). It carries no explicit climate-zone label
    and no city->zone mapping file is bundled, so this tool does NOT reproduce
    the paper's official "Code for Thermal Design of Civil Buildings" zoning.
    Instead it computes a transparent, data-driven thermal-load regime proxy:
    cities are binned by their added-heating-load signature, so a
    cooling-dominated regime (small added heating load) is the physical analogue
    of the hot-summer/warm-winter end and a heating-dominated regime the cold
    end. Use this as a heat-load tertile proxy, not as an official zone label.

    Cities are split into three reproducible regimes by terciles of the added
    heating load: ``cooling_dominated`` (lowest heating-load tercile, i.e. the
    hot-summer/warm-winter end), ``mixed`` (middle tercile), and
    ``heating_dominated`` (highest heating-load tercile, the cold end).

    Args:
        xlsx_path: Path to source_data.xlsx.
        sheet_name: defaults to "Fig 6".
        cooling_col: 0-indexed reduced-cooling-load column (default 3).
        heating_col: 0-indexed added-heating-load column (default 4).

    Returns:
        dict with ``regime`` (list[str], one per valid city, row order) and
        the two heating-load tercile thresholds used for the split.
    """
    sheet = load_source_sheet(xlsx_path, sheet_name)
    heat = []
    valid_rows = []
    for r in sheet["rows"]:
        try:
            h = float(r[heating_col]); _ = float(r[cooling_col])
        except (TypeError, ValueError, IndexError):
            continue
        heat.append(h); valid_rows.append(r)
    heat_arr = np.asarray(heat, dtype=float)
    t1 = float(np.quantile(heat_arr, 1.0 / 3.0))
    t2 = float(np.quantile(heat_arr, 2.0 / 3.0))
    regime = []
    for h in heat:
        if h <= t1:
            regime.append("cooling_dominated")
        elif h <= t2:
            regime.append("mixed")
        else:
            regime.append("heating_dominated")
    return {
        "regime": regime,
        "n_cities": len(regime),
        "heating_tercile_low": t1,
        "heating_tercile_high": t2,
        "regime_labels": {
            "cooling_dominated": "hot-summer/warm-winter end (cooling-dominated)",
            "mixed": "hot-summer/cold-winter / temperate (mixed)",
            "heating_dominated": "cold / severe-cold end (heating-dominated)",
        },
    }


@mcp.tool()
def thermal_regime_energy_balance(
    xlsx_path: str, sheet_name: str = "Fig 6",
    power_col: int = 1, net_load_col: int = 5,
    cooling_col: int = 3, heating_col: int = 4,
    zone_labels: Optional[list] = None,
) -> dict:
    """Per-thermal-regime annual energy balance and best regime for ST-OPV glazing.

    The annual energy balance of an ST-OPV smart window is the sum of its annual
    electrical power output (``power_col``) and its net annual reduced space
    cooling+heating load (``net_load_col``), both in GJ/m^2/yr. This tool groups
    the 371 cities by thermal-load regime and reports, per regime, the mean/max
    power output, net reduced load, and total annual energy balance, then names
    the regime with the highest mean total energy balance.

    By default the regime assignment is the data-driven heat-load tertile proxy
    from :func:`classify_city_thermal_regime` (no external metadata needed; this
    is NOT the official "Code for Thermal Design of Civil Buildings" zoning). If
    a city->zone mapping is obtained elsewhere, pass it via ``zone_labels`` (one
    label per city, in row order) to aggregate by that explicit classification.

    Args:
        xlsx_path: Path to source_data.xlsx.
        sheet_name: defaults to "Fig 6".
        power_col: 0-indexed annual power-output column (default 1).
        net_load_col: 0-indexed annual net reduced-load column (default 5).
        cooling_col, heating_col: load columns used for the default regime split.
        zone_labels: optional explicit per-city zone/regime labels (row order).

    Returns:
        dict with ``per_zone`` (regime -> stats), ``best_zone`` and
        ``best_zone_mean_balance``.
    """
    sheet = load_source_sheet(xlsx_path, sheet_name)
    power = []
    net_load = []
    valid_idx = []
    for k, r in enumerate(sheet["rows"]):
        try:
            p = float(r[power_col]); nl = float(r[net_load_col])
        except (TypeError, ValueError, IndexError):
            continue
        power.append(p); net_load.append(nl); valid_idx.append(k)

    if zone_labels is None:
        labels = classify_city_thermal_regime(
            xlsx_path, sheet_name, cooling_col, heating_col)["regime"]
    else:
        labels = [zone_labels[i] for i in valid_idx]

    if len(labels) != len(power):
        raise ValueError(
            f"zone label count ({len(labels)}) != valid city count ({len(power)})")

    power = np.asarray(power); net_load = np.asarray(net_load)
    balance = power + net_load

    per_zone = {}
    for z in sorted(set(labels)):
        m = np.asarray([lab == z for lab in labels])
        per_zone[z] = {
            "n": int(m.sum()),
            "power_mean": float(power[m].mean()),
            "power_max": float(power[m].max()),
            "net_load_mean": float(net_load[m].mean()),
            "net_load_max": float(net_load[m].max()),
            "balance_mean": float(balance[m].mean()),
            "balance_max": float(balance[m].max()),
        }
    best = max(per_zone, key=lambda z: per_zone[z]["balance_mean"])
    return {
        "per_zone": per_zone,
        "best_zone": best,
        "best_zone_mean_balance": per_zone[best]["balance_mean"],
        "best_zone_max_balance": per_zone[best]["balance_max"],
    }


# ---------------------------------------------------------------------------
# Plotting (one tool per image answer item)
# ---------------------------------------------------------------------------

def _ensure_dir(path: str) -> None:
    d = os.path.dirname(os.path.abspath(path))
    if d and not os.path.isdir(d):
        os.makedirs(d, exist_ok=True)


@mcp.tool()
def plot_jv_curves(
    xlsx_path: str, output_png: str,
) -> dict:
    """Plot J-V curves for the three ST-OPV configurations (Fig 3d).

    Reads the ``Fig 3d`` sheet of Source Data and overlays the J-V sweeps for
    the 11-nm Ag, 40-nm TeO2, and ABPF-based ST-OPVs.

    Args:
        xlsx_path: Path to source_data.xlsx.
        output_png: Output PNG path (will be created/overwritten).

    Returns:
        dict with ``output_path`` and the extracted device parameters.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    sheet = load_source_sheet(xlsx_path, "Fig 3d")
    rows = sheet["rows"]
    cols = sheet["columns"]
    # Sheet layout: V | 11-nm Ag J | 40-nm TeO2 J | ABPF J
    V = []
    series = {cols[1]: [], cols[2]: [], cols[3]: []}
    for r in rows:
        try:
            v = float(r[0]); j1 = float(r[1]); j2 = float(r[2]); j3 = float(r[3])
        except (TypeError, ValueError, IndexError):
            continue
        V.append(v)
        series[cols[1]].append(j1)
        series[cols[2]].append(j2)
        series[cols[3]].append(j3)
    fig, ax = plt.subplots(figsize=(6, 4.5))
    colors = {cols[1]: "#9b59b6", cols[2]: "#3498db", cols[3]: "#27ae60"}
    params = {}
    for label, j_list in series.items():
        ax.plot(V, j_list, label=label, lw=2, color=colors.get(label))
        p = extract_jv_parameters(V, j_list)
        params[label] = p
    ax.axhline(0, color="k", lw=0.5)
    ax.axvline(0, color="k", lw=0.5)
    ax.set_xlabel("Voltage (V)")
    ax.set_ylabel("Current density (mA/cm$^2$)")
    ax.set_title("ST-OPV J-V curves (PBOF:eC9:PC$_{61}$BM)")
    ax.set_xlim(-0.1, 1.0)
    ax.legend(frameon=False)
    ax.grid(alpha=0.3)
    _ensure_dir(output_png)
    fig.tight_layout(); fig.savefig(output_png, dpi=200); plt.close(fig)
    return {"output_path": output_png, "device_parameters": params}


@mcp.tool()
def plot_transmittance_spectra(
    xlsx_path: str, output_png: str,
) -> dict:
    """Plot transmittance vs wavelength for the three ST-OPV configurations.

    Reads the ``Fig 3c`` sheet (300-1000 nm spectra of 11-nm Ag, 40-nm TeO2,
    and ABPF) and writes a comparison plot. Computes AVT for each configuration.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    sheet = load_source_sheet(xlsx_path, "Fig 3c")
    rows = sheet["rows"]
    cols = sheet["columns"]
    # Sheet "Fig 3c" layout: col 0 = wavelength, cols 1..3 = T for the three
    # ST-OPV electrode designs (11-nm Ag, 40-nm TeO2, ABPF).
    fig, ax = plt.subplots(figsize=(6.5, 4.5))
    avts: dict[str, float] = {}
    series_colors = ["#9b59b6", "#3498db", "#27ae60"]
    labels = [cols[1] or "11-nm Ag", cols[2] or "40-nm TeO$_2$",
              cols[3] or "ABPF"]
    for idx, label in enumerate(labels, start=1):
        wl: list[float] = []; T: list[float] = []
        for r in rows:
            if idx >= len(r):
                continue
            try:
                w = float(r[0]); t = float(r[idx])
            except (TypeError, ValueError):
                continue
            if not (np.isfinite(w) and np.isfinite(t)):
                continue
            wl.append(w); T.append(t)
        if len(wl) < 5:
            continue
        color = series_colors[(idx - 1) % len(series_colors)]
        ax.plot(wl, T, label=label, color=color, lw=1.6)
        try:
            avts[label] = average_visible_transmittance(wl, T)["AVT_percent"]
        except Exception:
            pass
    ax.set_xlim(300, 1000)
    ax.set_ylim(0, 100)
    ax.set_xlabel("Wavelength (nm)")
    ax.set_ylabel("Transmittance (%)")
    ax.set_title("ST-OPV transmittance with three rear-electrode designs")
    ax.legend(frameon=False, loc="upper right")
    ax.grid(alpha=0.3)
    # Shade visible band
    ax.axvspan(380, 780, color="yellow", alpha=0.08, lw=0)
    _ensure_dir(output_png)
    fig.tight_layout(); fig.savefig(output_png, dpi=200); plt.close(fig)
    return {"output_path": output_png, "AVT_percent": avts}


@mcp.tool()
def plot_thickness_tradeoff(
    xlsx_path: str, output_png: str,
) -> dict:
    """Plot the active-layer thickness sweep (Fig 3b): Jsc/PCE/AVT/LUE vs thickness."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    sheet = load_source_sheet(xlsx_path, "Fig 3b")
    rows = sheet["rows"]
    thickness = []
    jsc = []; pce = []; avt = []; lue = []
    for r in rows:
        if len(r) < 5 or r[0] is None:
            continue
        try:
            t_label = str(r[0])
            t_val = float(t_label.split()[0])  # "120 nm" -> 120
            jsc.append(float(r[1])); pce.append(float(r[2]))
            avt.append(float(r[3])); lue.append(float(r[4]))
            thickness.append(t_val)
        except (TypeError, ValueError, IndexError):
            continue
    fig, ax_left = plt.subplots(figsize=(6.5, 4.5))
    ax_right = ax_left.twinx()
    ax_left.plot(thickness, jsc, "o-", label="Jsc (mA/cm$^2$)", color="#1f77b4")
    ax_left.plot(thickness, pce, "s-", label="PCE (%)", color="#ff7f0e")
    ax_right.plot(thickness, avt, "^-", label="AVT (%)", color="#2ca02c")
    ax_right.plot(thickness, lue, "d-", label="LUE (%)", color="#d62728")
    ax_left.set_xlabel("Active-layer thickness (nm)")
    ax_left.set_ylabel("Jsc / PCE")
    ax_right.set_ylabel("AVT / LUE")
    ax_left.invert_xaxis()
    ax_left.grid(alpha=0.3)
    h1, l1 = ax_left.get_legend_handles_labels()
    h2, l2 = ax_right.get_legend_handles_labels()
    ax_left.legend(h1 + h2, l1 + l2, frameon=False, loc="lower right", fontsize=9)
    ax_left.set_title("11-nm Ag ST-OPV thickness sweep")
    _ensure_dir(output_png)
    fig.tight_layout(); fig.savefig(output_png, dpi=200); plt.close(fig)
    return {
        "output_path": output_png,
        "thickness_nm": thickness,
        "Jsc_mA_per_cm2": jsc,
        "PCE_percent": pce,
        "AVT_percent": avt,
        "LUE_percent": lue,
    }


@mcp.tool()
def plot_geographical_violin(
    xlsx_path: str, output_png: str,
) -> dict:
    """Plot the per-city power output and load-reduction distribution (Fig 6).

    Source-Data sheet "Fig 6" is a flat table of 371 Chinese cities; we pool all
    cities and show two violins (annual power output and reduced cooling/heating
    loads, both in GJ/m^2/yr).  This reproduces the headline geographical
    statistics behind Fig 6g/h.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    sheet = load_source_sheet(xlsx_path, "Fig 6")
    rows = sheet["rows"]
    power = []; load_red = []
    for r in rows:
        try:
            p = float(r[1]); lr = float(r[5])
        except (TypeError, ValueError, IndexError):
            continue
        power.append(p); load_red.append(lr)
    fig, ax = plt.subplots(figsize=(6.5, 4.5))
    parts = ax.violinplot([power, load_red], showmeans=True, showmedians=False)
    ax.set_xticks([1, 2])
    ax.set_xticklabels([
        f"Power output\n(n={len(power)} cities)",
        f"Reduced cooling+heating\n(n={len(load_red)} cities)",
    ])
    ax.set_ylabel("GJ m$^{-2}$ yr$^{-1}$")
    ax.set_title("ABPF-based ST-OPV smart window across China")
    ax.grid(alpha=0.3)
    ax.axhline(0, color="k", lw=0.5)
    _ensure_dir(output_png)
    fig.tight_layout(); fig.savefig(output_png, dpi=200); plt.close(fig)
    return {
        "output_path": output_png,
        "n_cities": len(power),
        "power_mean_GJ_per_m2": float(np.mean(power)) if power else float("nan"),
        "power_max_GJ_per_m2": float(np.max(power)) if power else float("nan"),
        "load_reduction_mean_GJ_per_m2": float(np.mean(load_red)) if load_red else float("nan"),
        "load_reduction_max_GJ_per_m2": float(np.max(load_red)) if load_red else float("nan"),
    }


@mcp.tool()
def write_summary_json(payload: dict, output_path: str) -> dict:
    """Write any computed summary dict to JSON for downstream inspection."""
    _ensure_dir(output_path)
    with open(output_path, "w") as f:
        json.dump(payload, f, indent=2, default=str)
    return {"output_path": output_path, "n_keys": len(payload)}


if __name__ == "__main__":
    mcp.run()

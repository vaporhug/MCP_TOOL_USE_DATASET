"""Lightweight web/database retrieval utilities for the ST-OPV task.

All functions are runnable: each performs a real HTTP fetch with the standard
library only (no scraping APIs). They are intentionally minimal — heavier
provider-specific clients are not required for this task because all critical
inputs are already shipped in ``input_data/``.
"""
from __future__ import annotations

import json
import urllib.parse
import urllib.request
from typing import Any


_DEFAULT_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
    ),
}


def fetch_url(url: str, timeout: int = 30) -> bytes:
    """HTTP GET with redirects. Returns the raw response body bytes."""
    req = urllib.request.Request(url, headers=_DEFAULT_HEADERS)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read()


def fetch_text(url: str, timeout: int = 30, encoding: str = "utf-8") -> str:
    """HTTP GET that returns text decoded with the given encoding."""
    return fetch_url(url, timeout=timeout).decode(encoding, errors="replace")


def query_doi(doi: str, timeout: int = 30) -> dict:
    """Resolve a DOI via Crossref into a metadata dict.

    Returns the Crossref ``message`` block with title, authors, journal,
    year, references, and (when available) full-text URLs.
    """
    url = f"https://api.crossref.org/works/{urllib.parse.quote(doi)}"
    body = fetch_text(url, timeout=timeout)
    try:
        return json.loads(body).get("message", {})
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"Crossref returned non-JSON: {exc}")


def query_openalex(doi: str | None = None, work_id: str | None = None,
                    timeout: int = 30) -> dict:
    """Look up a work in OpenAlex by DOI or OpenAlex ID."""
    if doi:
        url = f"https://api.openalex.org/works/doi:{urllib.parse.quote(doi)}"
    elif work_id:
        url = f"https://api.openalex.org/works/{urllib.parse.quote(work_id)}"
    else:
        raise ValueError("Provide either doi or work_id")
    body = fetch_text(url, timeout=timeout)
    return json.loads(body)


def query_pubmed(pmid: str, timeout: int = 30) -> dict:
    """Fetch a PubMed record summary via Entrez ESummary (JSON)."""
    url = (
        "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi"
        f"?db=pubmed&id={urllib.parse.quote(pmid)}&retmode=json"
    )
    body = fetch_text(url, timeout=timeout)
    return json.loads(body)


def websearch(query: str, max_results: int = 10, timeout: int = 30) -> list[dict]:
    """DuckDuckGo HTML search (lite endpoint) — list of {title, url, snippet}."""
    url = "https://duckduckgo.com/html/?q=" + urllib.parse.quote(query)
    html = fetch_text(url, timeout=timeout)
    # Very small heuristic parser — pulls anchor href + text from result class.
    out: list[dict] = []
    import re
    for m in re.finditer(r'<a [^>]*class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>',
                          html, flags=re.DOTALL):
        title = re.sub(r"<[^>]+>", "", m.group(2)).strip()
        href = m.group(1)
        out.append({"title": title, "url": href, "snippet": ""})
        if len(out) >= max_results:
            break
    return out

#!/usr/bin/env python3
"""Domain-specific primitives for analysing superconducting transmon qubit
coherence-time measurements.

Each tool is a low-level primitive: load raw text traces, fit a single
exponential, aggregate fitted parameters across many traces, plot a
distribution histogram or a single time trace. Higher-level reasoning
(median/max selection, qubit comparison, decision logic) is left to the
agent that composes these primitives.
"""
from __future__ import annotations

import os
import glob
import zipfile
from typing import Optional

import numpy as np
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Transmon_Coherence_Tools")


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------
@mcp.tool()
def unzip_archive(zip_path: str, dest_dir: str) -> dict:
    """Extract a zip archive containing the per-trace text files.

    Args:
        zip_path: Path to the .zip file to extract.
        dest_dir: Directory where the archive contents are written.

    Returns:
        dict with the destination directory and a count of extracted files.
    """
    os.makedirs(dest_dir, exist_ok=True)
    with zipfile.ZipFile(zip_path, "r") as z:
        names = z.namelist()
        z.extractall(dest_dir)
    return {
        "dest_dir": dest_dir,
        "n_entries": len(names),
        "first_entries": names[:5],
    }


@mcp.tool()
def list_trace_indices(directory: str) -> dict:
    """Return the sorted list of trace indices `i` for which both
    `iq_data_index_{i}_.txt` and `times_index_{i}_.txt` exist in `directory`.

    Args:
        directory: Folder holding the per-trace txt files.

    Returns:
        dict with the count and the integer indices (sorted).
    """
    iq_files = glob.glob(os.path.join(directory, "iq_data_index_*_.txt"))
    indices = []
    for f in iq_files:
        base = os.path.basename(f)
        try:
            idx = int(base.replace("iq_data_index_", "").replace("_.txt", ""))
        except ValueError:
            continue
        if os.path.exists(os.path.join(directory, f"times_index_{idx}_.txt")):
            indices.append(idx)
    indices.sort()
    return {
        "directory": directory,
        "n_traces": len(indices),
        "indices": indices,
    }


@mcp.tool()
def load_trace(directory: str, index: int) -> dict:
    """Load one (delay-time, |S12|) trace from a measurement folder.

    Args:
        directory: Folder containing the per-trace txt files.
        index: Integer index `i` selecting `iq_data_index_{i}_.txt` and
            `times_index_{i}_.txt`.

    Returns:
        dict with `times_s` (delay times in seconds) and `signal`
        (readout magnitude, arbitrary units), plus length/range metadata.
    """
    iq_path = os.path.join(directory, f"iq_data_index_{index}_.txt")
    t_path = os.path.join(directory, f"times_index_{index}_.txt")
    times = np.loadtxt(t_path)
    signal = np.loadtxt(iq_path)
    return {
        "index": index,
        "n_points": int(len(times)),
        "t_min_s": float(times.min()),
        "t_max_s": float(times.max()),
        "signal_min": float(signal.min()),
        "signal_max": float(signal.max()),
        "times_s": times.tolist(),
        "signal": signal.tolist(),
    }


# ---------------------------------------------------------------------------
# Single-trace exponential fit (model: A*exp(-t/T) + C)
# ---------------------------------------------------------------------------
@mcp.tool()
def fit_exponential(times_s: list, signal: list,
                    initial_T_us: float = 200.0) -> dict:
    """Fit a single exponential A*exp(-t/T)+C to a coherence-time trace.

    Used for both T1 (energy relaxation) and T2echo (echo dephasing) decays.

    Args:
        times_s: Delay times in seconds.
        signal: Readout signal magnitude (arbitrary units).
        initial_T_us: Initial guess for the decay time T in microseconds.

    Returns:
        dict with the fitted T (in seconds and microseconds), the
        amplitude A, the offset C, and the 1-sigma standard error of T
        (in microseconds and as a relative percentage of T).
    """
    from scipy.optimize import curve_fit

    t = np.asarray(times_s, dtype=float)
    y = np.asarray(signal, dtype=float)
    if len(t) != len(y) or len(t) < 5:
        return {"error": "need >=5 paired (time, signal) points"}

    def model(tt, A, T, C):
        return A * np.exp(-tt / T) + C

    A0 = float(y.max() - y.min())
    C0 = float(y.min())
    T0 = max(initial_T_us, 1.0) * 1e-6
    try:
        popt, pcov = curve_fit(
            model, t, y, p0=[A0, T0, C0],
            bounds=([-np.inf, 1e-9, -np.inf], [np.inf, 1.0, np.inf]),
            maxfev=20000,
        )
        A, T, C = popt
        T_err = float(np.sqrt(pcov[1, 1])) if pcov[1, 1] > 0 else float("nan")
    except Exception as e:
        return {"error": f"fit failed: {e}"}

    return {
        "T_seconds": float(T),
        "T_us": round(float(T) * 1e6, 3),
        "T_err_us": round(T_err * 1e6, 3),
        "rel_err_percent": round(T_err / T * 100, 3) if T > 0 else None,
        "A": round(float(A), 6),
        "C": round(float(C), 6),
        "n_points": int(len(t)),
    }


# ---------------------------------------------------------------------------
# Batch fit over a directory
# ---------------------------------------------------------------------------
@mcp.tool()
def batch_fit_directory(directory: str,
                        initial_T_us: float = 200.0,
                        max_rel_err_percent: float = 100.0,
                        T_min_us: float = 1.0,
                        T_max_us: float = 5000.0) -> dict:
    """Fit a single exponential to every trace in a coherence-measurement folder.

    Iterates over every `iq_data_index_{i}_.txt` / `times_index_{i}_.txt`
    pair, fits A*exp(-t/T)+C, and returns the per-trace decay time T.
    Traces whose fitted T falls outside `[T_min_us, T_max_us]` or whose
    relative error exceeds `max_rel_err_percent` are excluded.

    Args:
        directory: Folder containing per-trace txt files.
        initial_T_us: Initial guess for T in microseconds.
        max_rel_err_percent: Drop fits whose 1-sigma relative error in T
            exceeds this percentage.
        T_min_us: Lower physical bound for T in microseconds.
        T_max_us: Upper physical bound for T in microseconds.

    Returns:
        dict with the list of accepted per-trace records (index, T_us,
        rel_err_percent), counts of accepted/rejected fits, and summary
        statistics (median, mean, max, std) over the accepted T values.
    """
    from scipy.optimize import curve_fit

    iq_files = glob.glob(os.path.join(directory, "iq_data_index_*_.txt"))
    records: list[dict] = []
    n_failed = 0
    n_filtered = 0

    def model(tt, A, T, C):
        return A * np.exp(-tt / T) + C

    for f in iq_files:
        base = os.path.basename(f)
        try:
            idx = int(base.replace("iq_data_index_", "").replace("_.txt", ""))
        except ValueError:
            continue
        tpath = os.path.join(directory, f"times_index_{idx}_.txt")
        if not os.path.exists(tpath):
            continue
        try:
            t = np.loadtxt(tpath)
            y = np.loadtxt(f)
            if len(t) != len(y) or len(t) < 5:
                n_failed += 1
                continue
            A0 = float(y.max() - y.min())
            C0 = float(y.min())
            T0 = max(initial_T_us, 1.0) * 1e-6
            popt, pcov = curve_fit(
                model, t, y, p0=[A0, T0, C0],
                bounds=([-np.inf, 1e-9, -np.inf], [np.inf, 1.0, np.inf]),
                maxfev=20000,
            )
            T = float(popt[1])
            T_us = T * 1e6
            T_err_us = float(np.sqrt(pcov[1, 1])) * 1e6 if pcov[1, 1] > 0 \
                else float("nan")
            rel = (T_err_us / T_us * 100) if T_us > 0 else float("inf")
            if not (T_min_us <= T_us <= T_max_us) or rel > max_rel_err_percent:
                n_filtered += 1
                continue
            records.append({
                "index": idx,
                "T_us": round(T_us, 3),
                "T_err_us": round(T_err_us, 3),
                "rel_err_percent": round(rel, 3),
            })
        except Exception:
            n_failed += 1

    Ts = np.array([r["T_us"] for r in records], dtype=float)
    summary: dict = {
        "n_accepted": len(records),
        "n_failed": int(n_failed),
        "n_filtered": int(n_filtered),
    }
    if len(Ts):
        # locate index of trace with the maximum fitted T
        i_max = int(np.argmax(Ts))
        summary.update({
            "median_us": round(float(np.median(Ts)), 2),
            "mean_us": round(float(Ts.mean()), 2),
            "max_us": round(float(Ts.max()), 2),
            "std_us": round(float(Ts.std()), 2),
            "max_index": int(records[i_max]["index"]),
            "max_rel_err_percent": records[i_max]["rel_err_percent"],
        })
    records.sort(key=lambda r: r["index"])
    return {"directory": directory, "summary": summary, "records": records}


# ---------------------------------------------------------------------------
# Plotting primitives (one figure per call)
# ---------------------------------------------------------------------------
@mcp.tool()
def plot_distribution(values_us: list, output_path: str,
                      title: str = "Coherence-time distribution",
                      xlabel: str = "T (us)",
                      bins: int = 30,
                      vline_us: Optional[float] = None) -> dict:
    """Plot a histogram of fitted decay times and save it to a PNG file.

    Args:
        values_us: List of decay times in microseconds.
        output_path: PNG output path.
        title: Plot title.
        xlabel: X-axis label.
        bins: Number of histogram bins.
        vline_us: Optional value (in microseconds) to draw as a vertical
            reference line, e.g. the median.

    Returns:
        dict with the output path, number of values plotted, and the
        median used for the optional reference line (if any).
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    arr = np.asarray(values_us, dtype=float)
    arr = arr[np.isfinite(arr)]
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.hist(arr, bins=bins, color="#3b6db0", edgecolor="black", alpha=0.85)
    if vline_us is not None:
        ax.axvline(vline_us, color="crimson", linestyle="--",
                   label=f"ref = {vline_us:.0f} us")
        ax.legend()
    ax.set_xlabel(xlabel)
    ax.set_ylabel("Count")
    ax.set_title(title)
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=140)
    plt.close(fig)
    return {
        "output_path": output_path,
        "n_values": int(len(arr)),
        "median": round(float(np.median(arr)), 2) if len(arr) else None,
        "vline_us": vline_us,
    }


@mcp.tool()
def plot_trace_with_fit(times_s: list, signal: list, output_path: str,
                        T_us: float, A: float, C: float,
                        title: str = "Coherence trace") -> dict:
    """Plot a single (delay-time, signal) trace with the overlaid exponential
    fit A*exp(-t/T)+C, and save to PNG.

    Args:
        times_s: Delay times in seconds.
        signal: Measured readout magnitude.
        output_path: PNG output path.
        T_us: Fitted decay time in microseconds.
        A: Fitted amplitude.
        C: Fitted offset.
        title: Plot title.

    Returns:
        dict with the output path and basic trace metadata.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    t = np.asarray(times_s, dtype=float)
    y = np.asarray(signal, dtype=float)
    t_dense = np.linspace(t.min(), t.max(), 400)
    y_fit = A * np.exp(-t_dense / (T_us * 1e-6)) + C

    fig, ax = plt.subplots(figsize=(6, 4))
    ax.plot(t * 1e3, y, "o", ms=4, color="#264f9a", alpha=0.7, label="data")
    ax.plot(t_dense * 1e3, y_fit, "-", color="orange", lw=2,
            label=f"fit T = {T_us:.0f} us")
    ax.set_xlabel("Delay time (ms)")
    ax.set_ylabel("RO signal (arb. unit)")
    ax.set_title(title)
    ax.legend()
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=140)
    plt.close(fig)
    return {
        "output_path": output_path,
        "n_points": int(len(t)),
        "T_us": float(T_us),
    }


@mcp.tool()
def plot_qubit_comparison(labels: list, medians_us: list, maxes_us: list,
                          output_path: str,
                          title: str = "Per-qubit coherence summary") -> dict:
    """Plot a grouped bar chart of per-qubit median and maximum decay times.

    Args:
        labels: Qubit labels (e.g., ["Q1", "Q2", "Q3", "Q4"]).
        medians_us: Median decay time per qubit in microseconds.
        maxes_us: Maximum decay time per qubit in microseconds.
        output_path: PNG output path.
        title: Plot title.

    Returns:
        dict with the output path and the rendered values.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    n = len(labels)
    x = np.arange(n)
    w = 0.4
    fig, ax = plt.subplots(figsize=(6.5, 4))
    ax.bar(x - w / 2, medians_us, width=w, label="median", color="#3b6db0")
    ax.bar(x + w / 2, maxes_us, width=w, label="max", color="#f29c3a")
    ax.set_xticks(x)
    ax.set_xticklabels(labels)
    ax.set_ylabel("T (us)")
    ax.set_title(title)
    ax.legend()
    for xi, m, M in zip(x, medians_us, maxes_us):
        ax.text(xi - w / 2, m, f"{m:.0f}", ha="center", va="bottom", fontsize=8)
        ax.text(xi + w / 2, M, f"{M:.0f}", ha="center", va="bottom", fontsize=8)
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=140)
    plt.close(fig)
    return {
        "output_path": output_path,
        "labels": list(labels),
        "medians_us": list(medians_us),
        "maxes_us": list(maxes_us),
    }


# ---------------------------------------------------------------------------
# Derived figure of merit
# ---------------------------------------------------------------------------
@mcp.tool()
def quality_factor(T1_us: float, frequency_GHz: float) -> dict:
    """Compute the qubit quality factor Q = 2*pi*f*T1.

    Args:
        T1_us: Energy-relaxation time in microseconds.
        frequency_GHz: Qubit transition frequency in GHz.

    Returns:
        dict with Q (dimensionless) and the inputs.
    """
    Q = 2.0 * np.pi * (frequency_GHz * 1e9) * (T1_us * 1e-6)
    return {
        "T1_us": float(T1_us),
        "frequency_GHz": float(frequency_GHz),
        "Q": float(Q),
        "Q_millions": round(Q / 1e6, 3),
    }


if __name__ == "__main__":
    mcp.run(transport="stdio")

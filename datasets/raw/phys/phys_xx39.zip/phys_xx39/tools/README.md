# phys_xx39 - Tool Reference

All tools are exposed via FastMCP @mcp.tool() decorators and run with
`python <file>.py` (transport=stdio).

## Database Retrieval (`database_retrieval.py`)

Generic placeholders for external-database queries (websearch, fetch_url,
query_doi, query_openalex, ...). Implementations are stubbed; the heavy
network code is filled in at task-execution time.

## Data Processing (`data_processing.py`)

Generic format conversion and reshaping helpers
(read_csv, write_csv, read_json, write_json, pivot_long_to_wide, ...).

## Domain-Specific Analysis (`qubit_coherence_analysis.py`)

Primitives for fitting and aggregating superconducting-qubit coherence
measurements stored as paired text traces.

- **unzip_archive**: Extract a `.zip` archive of per-trace text files.
- **list_trace_indices**: List the integer indices `i` for which both
  `iq_data_index_{i}_.txt` and `times_index_{i}_.txt` exist in a folder.
- **load_trace**: Load one (delay-time, |S12|) trace and return the raw
  arrays plus min/max diagnostics.
- **fit_exponential**: Fit `A*exp(-t/T)+C` to one trace and return
  `T_us`, the 1-sigma error `T_err_us`, and the relative error
  percentage. Used for both T1 and T2echo.
- **batch_fit_directory**: Run `fit_exponential` over every trace in a
  measurement folder, drop fits outside `[T_min_us, T_max_us]` or
  whose relative error exceeds `max_rel_err_percent`, and return both
  the per-trace records and summary statistics
  (median, mean, max, std, max_index).
- **plot_distribution**: Histogram of per-trace fitted decay times,
  with optional vertical reference line; one figure per call.
- **plot_trace_with_fit**: Single (delay-time, signal) trace with the
  exponential fit overlaid; one figure per call.
- **plot_qubit_comparison**: Grouped bar chart of per-qubit median and
  maximum decay times; one figure per call.
- **quality_factor**: `Q = 2*pi*f*T1` from `T1_us` and `frequency_GHz`.

## Dependencies

- numpy, scipy (curve_fit, theilslopes if used by other tools)
- matplotlib
- mcp (FastMCP server)

Install with: `pip install numpy scipy matplotlib mcp`

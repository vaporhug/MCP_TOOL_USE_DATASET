#!/usr/bin/env python3
"""Generic data-processing helpers (CSV, JSON, table reshaping)."""

import csv
import json
from typing import List, Optional

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Data_Processing_Helpers")


@mcp.tool()
def read_csv(csv_path: str) -> dict:
    """Read a CSV file into a list of dictionaries.

    Args:
        csv_path: Path to CSV.

    Returns:
        Dict with ``columns``, ``n_rows`` and ``rows`` (list of dicts).
    """
    with open(csv_path, newline="") as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    cols = reader.fieldnames or []
    return {"columns": list(cols), "n_rows": len(rows), "rows": rows}


@mcp.tool()
def write_csv(rows: list, csv_path: str) -> dict:
    """Write a list of dicts to a CSV file (header from first row keys).

    Args:
        rows: List of dicts.
        csv_path: Destination path.

    Returns:
        Dict with the written path and number of rows.
    """
    if not rows:
        return {"error": "rows is empty"}
    with open(csv_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    return {"path": csv_path, "n_rows": len(rows)}


@mcp.tool()
def read_json(json_path: str) -> dict:
    """Read a JSON file and return its contents."""
    with open(json_path) as f:
        return {"data": json.load(f)}


@mcp.tool()
def write_json(data: dict, json_path: str) -> dict:
    """Write a dict to JSON (pretty-printed)."""
    with open(json_path, "w") as f:
        json.dump(data, f, indent=2, default=str)
    return {"path": json_path}


@mcp.tool()
def filter_rows(rows: list, column: str, value) -> dict:
    """Return only rows where ``row[column] == value``.

    Args:
        rows: List of dicts.
        column: Column to filter on.
        value: Required value (string-compared).
    """
    out = [r for r in rows if str(r.get(column, "")) == str(value)]
    return {"n_kept": len(out), "rows": out}


@mcp.tool()
def select_columns(rows: list, columns: list) -> dict:
    """Project rows to only the specified columns."""
    out = [{k: r.get(k) for k in columns} for r in rows]
    return {"columns": columns, "rows": out}


@mcp.tool()
def to_numeric(rows: list, columns: list) -> dict:
    """Cast specified columns to float in-place."""
    out = []
    for r in rows:
        new = dict(r)
        for c in columns:
            if c in new and new[c] not in ("", None):
                try:
                    new[c] = float(new[c])
                except (TypeError, ValueError):
                    new[c] = None
        out.append(new)
    return {"rows": out}


@mcp.tool()
def merge_dicts(base: dict, override: dict) -> dict:
    """Return a new dict where keys from ``override`` replace those of ``base``."""
    out = dict(base)
    out.update(override)
    return out


if __name__ == "__main__":
    mcp.run(transport="stdio")

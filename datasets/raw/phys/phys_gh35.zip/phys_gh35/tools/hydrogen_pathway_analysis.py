#!/usr/bin/env python3
"""Domain primitives for solar hydrogen production net-energy balance analysis.

Implements the system-dynamics equations of the EROEI/EPBT framework
for PV-coupled electrolysis (PV-E) and direct photoelectrochemical (PEC)
water splitting facilities, plus Monte Carlo parameter sensitivity utilities
and matplotlib plotting helpers.

All energy units are kWh per m2 of light-collection area (PV active area
for PV-E, PEC active area for PEC). Time is in integer years.
"""

import json
import os
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Hydrogen_Pathway_Analysis")


# ---------------------------------------------------------------------------
# Parameter loading
# ---------------------------------------------------------------------------

@mcp.tool()
def load_parameters(csv_path: str, scenario: str = "base_case") -> dict:
    """Load PV-E or PEC technological parameters for a single scenario.

    The CSV must have rows keyed by ``parameter`` and one column per
    scenario (``base_case``, ``favourable_case``, ``optimistic_case``).

    Args:
        csv_path: Path to ``pve_parameters.csv`` or ``pec_parameters.csv``.
        scenario: One of ``base_case``, ``favourable_case`` or ``optimistic_case``.

    Returns:
        Dict mapping parameter name -> float value for the chosen scenario.
    """
    df = pd.read_csv(csv_path)
    if scenario not in df.columns:
        return {"error": f"Scenario {scenario!r} not found. Available: "
                          f"{[c for c in df.columns if c.endswith('_case')]}"}
    out = {}
    for _, row in df.iterrows():
        out[row["parameter"]] = float(row[scenario])
    return out


# ---------------------------------------------------------------------------
# Core simulation: PV-E facility
# ---------------------------------------------------------------------------

def _pve_simulate(p: Dict[str, float], years: int) -> Dict[str, np.ndarray]:
    """Run the annual-iteration PV-E simulation. Returns arrays of length years+1."""
    n = years
    mu_pv = np.zeros(n + 1)
    mu_ae = np.zeros(n + 1)
    e_pv_elec = np.zeros(n + 1)        # annual PV electrical output
    e_h2 = np.zeros(n + 1)             # annual H2 thermal energy produced
    cum_h2 = np.zeros(n + 1)
    cum_op_pv = np.zeros(n + 1)
    cum_op_ae = np.zeros(n + 1)

    mu_pv[0] = p["PV_conversion_efficiency"]
    mu_ae[0] = p["AE_conversion_efficiency"]

    S = p["solar_insolation"]
    PR = p["PV_performance_ratio"]
    D_pv = p["PV_efficiency_degradation_rate"]
    D_ae = p["AE_efficiency_degradation_rate"]

    construc_pv = p["PV_upfront_energy_cost"]
    construc_ae = p["AE_upfront_energy_cost_per_m2_PV"]
    decom_frac = p["decommissioning_fraction"]
    decom_pv = 0.0  # upfront values already include ~5% decommissioning per paper; do not add again
    decom_ae = 0.0  # upfront values already include decommissioning per paper
    construc_total = construc_pv + construc_ae
    decom_total = decom_pv + decom_ae

    op_pv_annual = p["PV_maintenance_energy_cost"]
    op_ae_annual = p["AE_operating_energy_cost_per_m2_PV"]

    for t in range(1, n + 1):
        # Use the start-of-year efficiency (mu at t-1) to compute that
        # year's output, then degrade. This matches the paper's annual
        # iteration convention (Eqs. S1-S4).
        e_pv_elec[t] = mu_pv[t - 1] * PR * S
        e_h2[t] = mu_ae[t - 1] * e_pv_elec[t]
        cum_h2[t] = cum_h2[t - 1] + e_h2[t]
        cum_op_pv[t] = cum_op_pv[t - 1] + op_pv_annual
        cum_op_ae[t] = cum_op_ae[t - 1] + op_ae_annual
        mu_pv[t] = mu_pv[t - 1] - D_pv * mu_pv[t - 1]
        mu_ae[t] = mu_ae[t - 1] - D_ae * mu_ae[t - 1]

    cum_input = construc_total + cum_op_pv + cum_op_ae + decom_total
    cum_input[0] = construc_total + decom_total  # construction visible at t=0
    eroei = np.where(cum_input > 0, cum_h2 / cum_input, 0.0)
    return {
        "year": np.arange(n + 1),
        "mu_pv": mu_pv, "mu_ae": mu_ae,
        "annual_pv_electricity": e_pv_elec,
        "annual_h2_energy": e_h2,
        "cumulative_h2_energy": cum_h2,
        "cumulative_input_energy": cum_input,
        "eroei": eroei,
    }


def _pec_simulate(p: Dict[str, float], years: int) -> Dict[str, np.ndarray]:
    n = years
    mu = np.zeros(n + 1)
    e_h2 = np.zeros(n + 1)
    cum_h2 = np.zeros(n + 1)
    cum_op = np.zeros(n + 1)

    mu[0] = p["PEC_conversion_efficiency"]
    S = p["solar_insolation"]
    PR = p["PEC_performance_ratio"]
    D = p["PEC_efficiency_degradation_rate"]

    construc = p["PEC_upfront_energy_cost"]
    decom_frac = p["decommissioning_fraction"]
    decom = 0.0  # upfront values already include decommissioning per paper
    op_annual = p["PEC_maintenance_energy_cost"]

    for t in range(1, n + 1):
        # Start-of-year efficiency for the year's output (paper convention)
        e_h2[t] = mu[t - 1] * PR * S
        cum_h2[t] = cum_h2[t - 1] + e_h2[t]
        cum_op[t] = cum_op[t - 1] + op_annual
        mu[t] = mu[t - 1] - D * mu[t - 1]

    cum_input = construc + cum_op + decom
    cum_input[0] = construc + decom
    eroei = np.where(cum_input > 0, cum_h2 / cum_input, 0.0)
    return {
        "year": np.arange(n + 1),
        "mu_pec": mu,
        "annual_h2_energy": e_h2,
        "cumulative_h2_energy": cum_h2,
        "cumulative_input_energy": cum_input,
        "eroei": eroei,
    }


@mcp.tool()
def simulate_pve_facility(parameters: dict, years: int = 30) -> dict:
    """Simulate a PV-coupled alkaline electrolyser facility year by year.

    Implements ESI Eqs. (S1)-(S7): annual PV efficiency mu_PV(n) and
    AE efficiency mu_AE(n) decay linearly each year by their degradation
    rates; annual H2 thermal energy = mu_PV(n) * PR * S * mu_AE(n).
    Cumulative input energy = construction + decommissioning + sum of
    maintenance/operating costs through year n.

    Args:
        parameters: Dict of PV-E parameters as returned by ``load_parameters``.
        years: Number of years to simulate (default 30).

    Returns:
        Dict with arrays for year, efficiencies, annual & cumulative H2
        energy, cumulative input energy, EROEI per year, plus EPBT (year
        when EROEI first reaches 1) and EROEI at year 20.
    """
    out = _pve_simulate(parameters, years)
    eroei = out["eroei"]
    eroei20 = float(eroei[20]) if years >= 20 else float(eroei[-1])
    eroei10 = float(eroei[10]) if years >= 10 else float(eroei[-1])
    above = np.where(eroei >= 1.0)[0]
    if len(above) > 0:
        # linear interpolation between (above[0]-1, above[0])
        i = int(above[0])
        if i == 0:
            epbt = 0.0
        else:
            y0, y1 = eroei[i - 1], eroei[i]
            epbt = (i - 1) + (1.0 - y0) / (y1 - y0) if y1 != y0 else float(i)
    else:
        epbt = None
    return {
        "years": out["year"].tolist(),
        "annual_pv_electricity_kWh_per_m2": [round(float(v), 4) for v in out["annual_pv_electricity"]],
        "annual_h2_energy_kWh_per_m2": [round(float(v), 4) for v in out["annual_h2_energy"]],
        "cumulative_h2_energy_kWh_per_m2": [round(float(v), 4) for v in out["cumulative_h2_energy"]],
        "cumulative_input_energy_kWh_per_m2": [round(float(v), 4) for v in out["cumulative_input_energy"]],
        "eroei_per_year": [round(float(v), 4) for v in eroei],
        "eroei_at_horizon": round(eroei20, 4),
        "eroei_at_year_10": round(eroei10, 4),
        "epbt_years": round(float(epbt), 3) if epbt is not None else None,
    }


@mcp.tool()
def simulate_pec_facility(parameters: dict, years: int = 30) -> dict:
    """Simulate a direct PEC water-splitting facility year by year.

    Implements ESI Eqs. (S9)-(S13): annual H2 energy = mu_PEC(n) * PR * S
    where mu_PEC decays linearly each year by D_PEC. Cumulative input =
    construction + decommissioning + sum of maintenance costs.

    Args:
        parameters: Dict of PEC parameters as returned by ``load_parameters``.
        years: Number of years to simulate (default 30).

    Returns:
        Dict with year arrays, EROEI series, EROEI@20yr, EROEI@10yr, EPBT.
    """
    out = _pec_simulate(parameters, years)
    eroei = out["eroei"]
    eroei20 = float(eroei[20]) if years >= 20 else float(eroei[-1])
    eroei10 = float(eroei[10]) if years >= 10 else float(eroei[-1])
    eroei_peak = float(np.max(eroei))
    year_peak = int(np.argmax(eroei))
    above = np.where(eroei >= 1.0)[0]
    if len(above) > 0:
        i = int(above[0])
        if i == 0:
            epbt = 0.0
        else:
            y0, y1 = eroei[i - 1], eroei[i]
            epbt = (i - 1) + (1.0 - y0) / (y1 - y0) if y1 != y0 else float(i)
    else:
        epbt = None
    return {
        "years": out["year"].tolist(),
        "annual_h2_energy_kWh_per_m2": [round(float(v), 4) for v in out["annual_h2_energy"]],
        "cumulative_h2_energy_kWh_per_m2": [round(float(v), 4) for v in out["cumulative_h2_energy"]],
        "cumulative_input_energy_kWh_per_m2": [round(float(v), 4) for v in out["cumulative_input_energy"]],
        "eroei_per_year": [round(float(v), 4) for v in eroei],
        "eroei_at_horizon": round(eroei20, 4),
        "eroei_at_year_10": round(eroei10, 4),
        "eroei_peak": round(eroei_peak, 4),
        "year_of_peak_eroei": year_peak,
        "epbt_years": round(float(epbt), 3) if epbt is not None else None,
    }


# ---------------------------------------------------------------------------
# Pathway comparison
# ---------------------------------------------------------------------------

@mcp.tool()
def compare_pathways(pve_csv: str, pec_csv: str, years: int = 20) -> dict:
    """Compare PV-E and PEC across base/favourable/optimistic scenarios.

    Computes EROEI@years and EPBT for each scenario and returns a side-by-side
    comparison table identical in structure to Table 3 of the paper.

    Args:
        pve_csv: Path to PV-E parameter table.
        pec_csv: Path to PEC parameter table.
        years: Reference horizon for the comparison (default 20).

    Returns:
        Dict with rows ``pve_<scenario>`` and ``pec_<scenario>`` each
        containing EROEI@years and EPBT.
    """
    rows = []
    for scen in ["base_case", "favourable_case", "optimistic_case"]:
        p_pve = load_parameters(pve_csv, scen)
        if "error" in p_pve:
            continue
        s_pve = simulate_pve_facility(p_pve, years=max(years, 30))
        p_pec = load_parameters(pec_csv, scen)
        s_pec = simulate_pec_facility(p_pec, years=max(years, 30))
        rows.append({
            "scenario": scen,
            "pve_eroei_at_horizon": s_pve["eroei_at_horizon"],
            "pve_epbt_years": s_pve["epbt_years"],
            "pec_eroei_at_horizon": s_pec["eroei_at_horizon"],
            "pec_eroei_peak": s_pec["eroei_peak"],
            "pec_year_of_peak": s_pec["year_of_peak_eroei"],
            "pec_epbt_years": s_pec["epbt_years"],
        })
    return {"horizon_years": years, "rows": rows,
            "smr_eroei_literature": 2.47, "smr_epbt_years_literature": 8.09}


@mcp.tool()
def apply_recycling(parameters: dict, technology: str,
                    recycled_upfront_kWh_per_m2: float) -> dict:
    """Return a parameter dict with the upfront energy replaced by the
    recycled-material upfront cost.

    Args:
        parameters: Original parameter dict.
        technology: ``PV-E`` or ``PEC``.
        recycled_upfront_kWh_per_m2: New upfront embodied energy after recycling.
            For PV-E, this represents the combined PV+AE upfront energy.

    Returns:
        New dict with the upfront energy fields adjusted accordingly.
    """
    new = dict(parameters)
    if technology.upper() == "PV-E":
        # Split recycled total in same proportion as original
        orig_pv = new["PV_upfront_energy_cost"]
        orig_ae = new["AE_upfront_energy_cost_per_m2_PV"]
        total = orig_pv + orig_ae
        if total > 0:
            new["PV_upfront_energy_cost"] = recycled_upfront_kWh_per_m2 * orig_pv / total
            new["AE_upfront_energy_cost_per_m2_PV"] = recycled_upfront_kWh_per_m2 * orig_ae / total
    elif technology.upper() == "PEC":
        new["PEC_upfront_energy_cost"] = recycled_upfront_kWh_per_m2
    else:
        return {"error": f"technology must be 'PV-E' or 'PEC', got {technology!r}"}
    return new


# ---------------------------------------------------------------------------
# Sensitivity & Monte Carlo
# ---------------------------------------------------------------------------

@mcp.tool()
def parameter_sensitivity(pve_csv: str, technology: str = "PV-E",
                          base_scenario: str = "base_case",
                          target_scenario: str = "favourable_case",
                          years: int = 20) -> dict:
    """One-at-a-time sensitivity: vary each parameter from base to target value
    while keeping others at base.

    Args:
        pve_csv: Path to PV-E or PEC parameter CSV.
        technology: ``PV-E`` or ``PEC``.
        base_scenario: Reference scenario for all-other parameters.
        target_scenario: Scenario value adopted for the swept parameter.
        years: EROEI evaluation horizon (default 20).

    Returns:
        Dict mapping parameter name -> EROEI@years when only that
        parameter is improved to ``target_scenario`` value.
    """
    base = load_parameters(pve_csv, base_scenario)
    target = load_parameters(pve_csv, target_scenario)
    if "error" in base or "error" in target:
        return {"error": "scenario lookup failed"}
    sim_fn = simulate_pve_facility if technology.upper() == "PV-E" else simulate_pec_facility
    baseline = sim_fn(base, years=max(years, 30))
    eroei_base = baseline["eroei_at_horizon"]
    out = {"baseline_eroei": eroei_base, "swept": {}}
    for k in base:
        if base[k] == target[k]:
            continue
        modified = dict(base)
        modified[k] = target[k]
        s = sim_fn(modified, years=max(years, 30))
        out["swept"][k] = {
            "value_base": base[k], "value_target": target[k],
            "eroei_at_horizon": s["eroei_at_horizon"],
            "delta_eroei": round(s["eroei_at_horizon"] - eroei_base, 4),
        }
    out["ranked_by_impact"] = sorted(
        [(k, v["delta_eroei"]) for k, v in out["swept"].items()],
        key=lambda x: -abs(x[1])
    )
    return out


@mcp.tool()
def monte_carlo_eroei(csv_path: str, technology: str = "PV-E",
                      low_scenario: str = "base_case",
                      high_scenario: str = "favourable_case",
                      n_simulations: int = 10000,
                      years: int = 20,
                      fixed_parameters: Optional[dict] = None,
                      random_seed: int = 42) -> dict:
    """Monte Carlo of EROEI@years sampling each parameter uniformly between
    its values in ``low_scenario`` and ``high_scenario``.

    Args:
        csv_path: Parameter CSV.
        technology: ``PV-E`` or ``PEC``.
        low_scenario: Lower-bound scenario for uniform sampling.
        high_scenario: Upper-bound scenario for uniform sampling.
        n_simulations: Number of Monte Carlo draws (default 10000;
            use 1e6 to reproduce the paper's histograms).
        years: EROEI horizon.
        fixed_parameters: Optional dict of {parameter: value} to hold fixed
            (e.g. ``{"PV_upfront_energy_cost": 537.0}`` to fix PV embodied
            energy at its favourable-case value as in paper Fig. 4).
        random_seed: PRNG seed.

    Returns:
        Dict with sample mean/median/std/p05/p95 of EROEI@years and the raw
        histogram (50 bins).
    """
    rng = np.random.default_rng(random_seed)
    low = load_parameters(csv_path, low_scenario)
    high = load_parameters(csv_path, high_scenario)
    if "error" in low or "error" in high:
        return {"error": "scenario lookup failed"}
    fixed_parameters = fixed_parameters or {}
    sim_fn = simulate_pve_facility if technology.upper() == "PV-E" else simulate_pec_facility

    samples = np.zeros(n_simulations)
    keys = list(low.keys())
    for i in range(n_simulations):
        p = {}
        for k in keys:
            if k in fixed_parameters:
                p[k] = float(fixed_parameters[k])
            elif low[k] == high[k]:
                p[k] = low[k]
            else:
                lo, hi = sorted([low[k], high[k]])
                p[k] = float(rng.uniform(lo, hi))
        s = sim_fn(p, years=max(years, 30))
        samples[i] = s["eroei_at_horizon"]
    hist, edges = np.histogram(samples, bins=50)
    return {
        "n_simulations": n_simulations,
        "mean": round(float(samples.mean()), 4),
        "median": round(float(np.median(samples)), 4),
        "std": round(float(samples.std()), 4),
        "p05": round(float(np.percentile(samples, 5)), 4),
        "p95": round(float(np.percentile(samples, 95)), 4),
        "histogram_counts": hist.tolist(),
        "histogram_edges": [round(float(e), 4) for e in edges],
        "samples_first_100": [round(float(v), 4) for v in samples[:100]],
    }


# ---------------------------------------------------------------------------
# Plotting
# ---------------------------------------------------------------------------

@mcp.tool()
def plot_eroei_over_time(pve_csv: str, pec_csv: str, output_path: str,
                         years: int = 30) -> dict:
    """Plot cumulative EROEI versus time for PV-E and PEC across all three
    scenarios. Produces the figure referenced in the answer.

    Args:
        pve_csv: PV-E parameter CSV path.
        pec_csv: PEC parameter CSV path.
        output_path: PNG output path.
        years: Simulation horizon.

    Returns:
        Dict with the saved file path and EROEI@year-20 for each curve.
    """
    fig, ax = plt.subplots(1, 2, figsize=(11, 4.5), sharey=False)
    colors = {"base_case": "#3b6e8f", "favourable_case": "#5fa666",
              "optimistic_case": "#d97a3a"}
    summary = {}
    for scen in ["base_case", "favourable_case", "optimistic_case"]:
        p_pve = load_parameters(pve_csv, scen)
        sim_pve = _pve_simulate(p_pve, years)
        ax[0].plot(sim_pve["year"], sim_pve["eroei"],
                   color=colors[scen], lw=2, label=scen.replace("_", " "))
        p_pec = load_parameters(pec_csv, scen)
        sim_pec = _pec_simulate(p_pec, years)
        ax[1].plot(sim_pec["year"], sim_pec["eroei"],
                   color=colors[scen], lw=2, label=scen.replace("_", " "))
        summary[f"pve_{scen}_eroei20"] = round(float(sim_pve["eroei"][20]), 3)
        summary[f"pec_{scen}_eroei20"] = round(float(sim_pec["eroei"][20]), 3)
    for a, title in zip(ax, ["PV-E facility", "PEC facility"]):
        a.axhline(1.0, ls="--", color="grey", lw=1, label="EROEI = 1")
        a.set_xlabel("Time (years)")
        a.set_ylabel("Cumulative EROEI")
        a.set_title(title)
        a.legend(fontsize=9)
        a.grid(alpha=0.3)
    plt.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"path": output_path, "summary": summary}


@mcp.tool()
def plot_sensitivity_tornado(csv_path: str, technology: str,
                             base_scenario: str, target_scenario: str,
                             output_path: str, years: int = 20) -> dict:
    """Tornado plot of one-at-a-time parameter sensitivity for EROEI@years.

    Args:
        csv_path: PV-E or PEC parameter CSV.
        technology: ``PV-E`` or ``PEC``.
        base_scenario: Reference scenario.
        target_scenario: Improved scenario value for the swept parameter.
        output_path: PNG output path.
        years: EROEI horizon.

    Returns:
        Dict with saved file path and ranking of parameters by impact.
    """
    res = parameter_sensitivity(csv_path, technology, base_scenario,
                                target_scenario, years)
    if "error" in res:
        return res
    ranked = res["ranked_by_impact"]
    names = [k for k, _ in ranked]
    vals = [v for _, v in ranked]
    fig, ax = plt.subplots(figsize=(8, max(3, 0.45 * len(names))))
    colors = ["#5fa666" if v >= 0 else "#c44e4e" for v in vals]
    y = np.arange(len(names))
    ax.barh(y, vals, color=colors, edgecolor="black", lw=0.5)
    ax.set_yticks(y)
    ax.set_yticklabels(names, fontsize=9)
    ax.invert_yaxis()
    ax.axvline(0, color="black", lw=0.7)
    ax.set_xlabel(f"Delta EROEI@{years}yr (parameter -> {target_scenario})")
    ax.set_title(f"{technology} sensitivity (baseline {res['baseline_eroei']})")
    ax.grid(alpha=0.3, axis="x")
    plt.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"path": output_path, "baseline_eroei": res["baseline_eroei"],
            "ranked": ranked}


@mcp.tool()
def plot_monte_carlo_histogram(csv_path: str, technology: str,
                               low_scenario: str, high_scenario: str,
                               output_path: str,
                               n_simulations: int = 50000,
                               years: int = 20,
                               fixed_parameters: Optional[dict] = None) -> dict:
    """Histogram of EROEI@years from a Monte Carlo run. Saves PNG.

    Args:
        csv_path: Parameter CSV.
        technology: ``PV-E`` or ``PEC``.
        low_scenario: Lower-bound scenario.
        high_scenario: Upper-bound scenario.
        output_path: PNG output path.
        n_simulations: Number of draws (default 50000).
        years: EROEI horizon.
        fixed_parameters: Optional dict to fix some parameters.

    Returns:
        Dict with saved file path and Monte Carlo summary.
    """
    mc = monte_carlo_eroei(csv_path, technology, low_scenario, high_scenario,
                            n_simulations=n_simulations, years=years,
                            fixed_parameters=fixed_parameters)
    if "error" in mc:
        return mc
    edges = np.array(mc["histogram_edges"])
    counts = np.array(mc["histogram_counts"])
    centres = 0.5 * (edges[1:] + edges[:-1])
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.bar(centres, counts, width=(edges[1] - edges[0]),
           color="#3b6e8f", edgecolor="black", lw=0.3)
    ax.axvline(mc["median"], color="orange", lw=2,
               label=f"median = {mc['median']:.2f}")
    ax.set_xlabel(f"EROEI at year {years}")
    ax.set_ylabel("Number of simulations")
    ax.set_title(f"{technology}: {low_scenario} -> {high_scenario} "
                 f"({n_simulations:,} draws)")
    ax.legend()
    ax.grid(alpha=0.3)
    plt.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"path": output_path, "summary": {
        k: mc[k] for k in ["mean", "median", "std", "p05", "p95"]}}


@mcp.tool()
def plot_pathway_comparison_bar(pve_csv: str, pec_csv: str,
                                output_path: str, years: int = 20) -> dict:
    """Bar chart comparing PV-E vs PEC EROEI@years across the three scenarios,
    with a horizontal line for the SMR literature value (2.47).

    Args:
        pve_csv: PV-E parameter CSV.
        pec_csv: PEC parameter CSV.
        output_path: PNG output path.
        years: EROEI horizon.

    Returns:
        Dict with saved file path and the underlying numeric table.
    """
    cmp = compare_pathways(pve_csv, pec_csv, years=years)
    rows = cmp["rows"]
    scens = [r["scenario"].replace("_", " ") for r in rows]
    pve_v = [r["pve_eroei_at_horizon"] for r in rows]
    pec_v = [r["pec_eroei_at_horizon"] for r in rows]
    x = np.arange(len(scens))
    w = 0.35
    fig, ax = plt.subplots(figsize=(8, 4.6))
    ax.bar(x - w / 2, pve_v, width=w, color="#3b6e8f",
           edgecolor="black", label="PV-E")
    ax.bar(x + w / 2, pec_v, width=w, color="#d97a3a",
           edgecolor="black", label="PEC")
    ax.axhline(2.47, ls="--", color="grey", lw=1.5, label="SMR (2.47)")
    ax.axhline(1.0, ls=":", color="red", lw=1, label="EROEI = 1")
    ax.set_xticks(x)
    ax.set_xticklabels(scens)
    ax.set_ylabel(f"EROEI at year {years}")
    ax.set_title("Hydrogen pathway comparison")
    for xi, v in zip(x - w / 2, pve_v):
        ax.text(xi, v + 0.05, f"{v:.2f}", ha="center", fontsize=9)
    for xi, v in zip(x + w / 2, pec_v):
        ax.text(xi, v + 0.05, f"{v:.2f}", ha="center", fontsize=9)
    ax.legend()
    ax.grid(alpha=0.3, axis="y")
    plt.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"path": output_path, "comparison": cmp}


if __name__ == "__main__":
    mcp.run(transport="stdio")

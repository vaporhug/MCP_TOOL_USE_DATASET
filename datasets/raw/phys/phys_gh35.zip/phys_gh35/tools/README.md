# phys_gh35 — Tool Reference

## Database Retrieval (`database_retrieval.py`)

- **fetch_url**: HTTP GET (follows redirects) returning text body and status.
- **query_doi**: Crossref DOI metadata lookup.
- **query_irena_target**: Returns alkaline-electrolyser efficiency targets
  for present (2018), 2025 and 2050 from IRENA reports.
- **query_solar_insolation**: Typical annual insolation (kWh m^-2 yr^-1) by
  latitude band (low/mid/high).

## Data Processing (`data_processing.py`)

- **read_csv / write_csv**: CSV I/O via the standard `csv` module.
- **read_json / write_json**: Pretty-printed JSON I/O.
- **filter_rows**: Keep rows matching `column == value`.
- **select_columns**: Project rows to a subset of columns.
- **to_numeric**: Cast specified columns to float (None on failure).
- **merge_dicts**: Override-style dict merge.

## Domain — Solar Hydrogen Pathway Analysis (`hydrogen_pathway_analysis.py`)

- **load_parameters**: Load PV-E or PEC parameters for one scenario from CSV.
- **simulate_pve_facility**: Year-by-year ESI Eqs. (S1)-(S7) for PV+alkaline
  electrolyser; returns annual H2 energy, EROEI series, EPBT, EROEI@20yr.
- **simulate_pec_facility**: ESI Eqs. (S9)-(S13) for PEC; returns EROEI series,
  peak EROEI and year-of-peak (PEC peaks early then declines), EPBT.
- **compare_pathways**: Side-by-side EROEI@20yr / EPBT table for PV-E vs PEC
  across base/favourable/optimistic scenarios (matches Table 3 structure).
- **apply_recycling**: Substitute recycled-material upfront energy values into
  a parameter dict, preserving the PV:AE energy ratio.
- **parameter_sensitivity**: One-at-a-time parameter sweep, returning EROEI
  delta when each parameter is set to the target-scenario value.
- **monte_carlo_eroei**: Uniform-random parameter sampling between two scenario
  bounds; returns sample stats and 50-bin histogram.
- **plot_eroei_over_time**: Two-panel line plot of cumulative EROEI vs year
  for PV-E and PEC across the three scenarios (PNG).
- **plot_sensitivity_tornado**: Horizontal bar chart of one-at-a-time delta
  EROEI for each parameter (PNG).
- **plot_monte_carlo_histogram**: Histogram of EROEI@20yr from a Monte Carlo
  run (PNG).
- **plot_pathway_comparison_bar**: Grouped bar chart comparing PV-E vs PEC
  EROEI@20yr against the SMR literature value of 2.47 (PNG).

## Dependencies

`numpy`, `pandas`, `matplotlib`, `mcp` (FastMCP). Install with
`pip install numpy pandas matplotlib mcp`.

## Quick reproducibility check

```python
from tools.hydrogen_pathway_analysis import load_parameters, simulate_pve_facility, simulate_pec_facility
p = load_parameters("input_data/data/pve_parameters.csv", "base_case")
print(simulate_pve_facility(p, years=20)["eroei_at_year_20"])  # 
p = load_parameters("input_data/data/pec_parameters.csv", "base_case")
r = simulate_pec_facility(p, years=20)
print(r["eroei_at_year_20"], r["eroei_peak"], r["year_of_peak_eroei"])
# ~0.38, ~0.42 at year ~11 (paper)
```

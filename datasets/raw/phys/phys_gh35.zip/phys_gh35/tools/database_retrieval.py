#!/usr/bin/env python3
"""External database / web retrieval primitives (HTTP, DOI lookup)."""

from typing import Optional

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Database_Retrieval")


@mcp.tool()
def fetch_url(url: str, timeout: int = 30) -> dict:
    """HTTP GET (follows redirects). Returns text body and status.

    Args:
        url: Fully-qualified URL.
        timeout: Seconds.
    """
    try:
        import urllib.request
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read()
            try:
                text = body.decode("utf-8", errors="replace")
            except Exception:
                text = "<binary>"
            return {"status": resp.status, "url": resp.geturl(),
                    "n_bytes": len(body), "text_first_4000": text[:4000]}
    except Exception as exc:
        return {"error": str(exc)}


@mcp.tool()
def query_doi(doi: str) -> dict:
    """Resolve a DOI via the Crossref REST API and return metadata."""
    try:
        import json as _json
        import urllib.request
        url = f"https://api.crossref.org/works/{doi}"
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = _json.loads(resp.read().decode())
        msg = data.get("message", {})
        return {
            "doi": doi,
            "title": (msg.get("title") or [None])[0],
            "container": (msg.get("container-title") or [None])[0],
            "year": ((msg.get("issued") or {}).get("date-parts") or [[None]])[0][0],
            "authors": [f"{a.get('given','')} {a.get('family','')}".strip()
                        for a in msg.get("author", [])],
            "url": msg.get("URL"),
        }
    except Exception as exc:
        return {"error": str(exc)}


@mcp.tool()
def query_irena_target(year: int) -> dict:
    """Stub: IRENA reports list characteristic alkaline electrolyser
    efficiency targets. Returns the literature value used by Tam 2024.

    Args:
        year: 2018 (present), 2025 (predicted), or 2050 (long-term).
    """
    table = {2018: 0.65, 2025: 0.68, 2050: 0.76}
    return {"year": year, "ae_efficiency": table.get(year),
            "source": "IRENA hydrogen reports as cited in Tam et al. 2024"}


@mcp.tool()
def query_solar_insolation(latitude_band: str = "mid") -> dict:
    """Stub: typical annual solar insolation (kWh/m2/yr) by latitude band.

    Args:
        latitude_band: ``low`` (equatorial), ``mid``, or ``high`` (>50 deg).
    """
    table = {"low": 2700.0, "mid": 1700.0, "high": 850.0}
    return {"band": latitude_band,
            "annual_insolation_kWh_per_m2": table.get(latitude_band)}


if __name__ == "__main__":
    mcp.run(transport="stdio")

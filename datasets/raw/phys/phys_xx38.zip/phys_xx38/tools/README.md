# Tools

## Servers

- **heatpump_analysis.py**: Domain-specific MCP server with primitives for heat-pump field-data analysis.
  - I/O: `load_csv`, `filter_csv`, `merge_csvs`, `write_csv`
  - Statistics: `descriptive_stats`, `linear_fit`, `welch_t_test`, `count_threshold`, `group_summary`
  - Heat pump physics: `carnot_cop`, `fit_cop_curve`, `fit_cop_curves_per_hp`, `predict_cop`,
    `compute_scop`, `compute_scop_per_hp`, `classify_efficiency`, `fraction_below_threshold`
  - Plotting (one tool per artifact):
    - `plot_cop_vs_temperature` -> Mean COP vs outdoor temperature, by HP type
    - `plot_scop_distribution` -> Boxplot of SCOP per HP type
    - `plot_efficiency_class_distribution` -> Stacked bars of A+++ to G shares per HP type

- **data_processing.py**: Generic, domain-agnostic helpers (CSV I/O, JSON, type coercion,
  filtering, joining lists of dicts).

## Dependencies

```
mcp[server] >= 1.0.0
numpy
pandas
scipy
matplotlib
openpyxl
```

Install: `pip install -r requirements.txt`

## Run

```
python tools/heatpump_analysis.py
python tools/data_processing.py
```

Each runs as a stdio MCP server.

## Inputs expected on disk

- `input_data/data/hp_binned_cop.csv`
- `input_data/data/hp_overview.csv`
- `input_data/data/en14825_standard.csv`
- `input_data/data/efficiency_classes.csv`

## Output

Generated PNG figures should be saved to `artifacts/`:
- `cop_vs_temp.png`
- `scop_distribution.png`
- `efficiency_classes.png`

#!/usr/bin/env python3
"""
Generic data processing primitives. These tools are domain-agnostic helpers
used in many SCP tasks: CSV/JSON IO, type coercion, group operations.
"""

import csv
import json
from typing import Any

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("DataProcessing")


@mcp.tool()
def read_csv(path: str, delimiter: str = ",") -> dict:
    """Read a CSV via csv.DictReader and return all rows + header.

    Args:
        path: CSV file path.
        delimiter: column delimiter, default ','.

    Returns:
        dict with columns, n_rows, and rows (first 50 dicts).
    """
    with open(path, newline="") as f:
        reader = csv.DictReader(f, delimiter=delimiter)
        rows = list(reader)
    return {
        "columns": reader.fieldnames or [],
        "n_rows": len(rows),
        "rows": rows[:50],
        "truncated": len(rows) > 50,
    }


@mcp.tool()
def write_json(obj_str: str, path: str, indent: int = 2) -> dict:
    """Write a JSON-encoded string to disk as pretty-printed JSON.

    Args:
        obj_str: JSON string.
        path: output path.
        indent: indentation spaces.

    Returns:
        dict confirming the write.
    """
    obj = json.loads(obj_str)
    with open(path, "w") as f:
        json.dump(obj, f, indent=indent, default=str)
    return {"path": path, "ok": True}


@mcp.tool()
def coerce_numeric_column(rows_json: str, columns: list) -> dict:
    """Cast specified columns of a list-of-dicts to float (None if not parseable).

    Args:
        rows_json: JSON-encoded list of dicts.
        columns: column names to coerce.

    Returns:
        dict with rows and a per-column count of cast failures.
    """
    rows = json.loads(rows_json)
    fails = {c: 0 for c in columns}
    for r in rows:
        for c in columns:
            try:
                r[c] = float(r[c])
            except (TypeError, ValueError):
                r[c] = None
                fails[c] += 1
    return {"rows": rows[:50], "n_rows": len(rows),
            "failures_per_column": fails,
            "truncated": len(rows) > 50}


@mcp.tool()
def filter_rows(rows_json: str, conditions_json: str) -> dict:
    """Filter rows by equality conditions.

    Args:
        rows_json: JSON-encoded list of dicts.
        conditions_json: JSON-encoded {column: value} dict, AND-combined.

    Returns:
        dict with filtered rows.
    """
    rows = json.loads(rows_json)
    cond = json.loads(conditions_json)
    out = [r for r in rows if all(str(r.get(k)) == str(v) for k, v in cond.items())]
    return {"n_kept": len(out), "rows": out[:50], "truncated": len(out) > 50}


@mcp.tool()
def select_column(rows_json: str, column: str) -> dict:
    """Pull a single column out of a list-of-dicts as a flat list.

    Args:
        rows_json: JSON-encoded list of dicts.
        column: column name to extract.

    Returns:
        dict with values list.
    """
    rows = json.loads(rows_json)
    vals = [r.get(column) for r in rows]
    return {"column": column, "values": vals, "n": len(vals)}


@mcp.tool()
def join_lists(a_json: str, b_json: str, on: str, how: str = "left") -> dict:
    """SQL-style join two lists-of-dicts on a single key column.

    Args:
        a_json: JSON-encoded left rows.
        b_json: JSON-encoded right rows.
        on: shared key column.
        how: 'left' or 'inner'.

    Returns:
        dict with joined rows.
    """
    a = json.loads(a_json); b = json.loads(b_json)
    idx = {r[on]: r for r in b}
    out = []
    for l in a:
        r = idx.get(l.get(on))
        if r is not None:
            out.append({**l, **{k: v for k, v in r.items() if k != on}})
        elif how == "left":
            out.append(dict(l))
    return {"n_rows": len(out), "rows": out[:50], "truncated": len(out) > 50}


if __name__ == "__main__":
    mcp.run(transport="stdio")

#!/usr/bin/env python3
"""
Domain-specific tools for heat pump field-data analysis.
Provides COP modeling, SCOP computation per EN 14825, efficiency-class
classification, and grouped descriptive statistics.

Each MCP tool is a low-level primitive: the caller chains them together to
reproduce the analytical pipeline of the paper.
"""

import json
import math
import os
from typing import Any

import numpy as np
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("HeatPumpAnalysis")


# ---------------------------------------------------------------------------
# I/O primitives
# ---------------------------------------------------------------------------


@mcp.tool()
def load_csv(csv_path: str) -> dict:
    """Load a CSV file and return columns, total row count, and a sample of rows.

    Args:
        csv_path: Path to CSV file.

    Returns:
        dict with keys: columns, total_rows, rows (first 30 dicts), truncated.
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    rows = df.to_dict("records")
    return {
        "columns": list(df.columns),
        "total_rows": len(rows),
        "rows": rows[:30],
        "truncated": len(rows) > 30,
        "dtypes": {c: str(df[c].dtype) for c in df.columns},
    }


@mcp.tool()
def filter_csv(csv_path: str, conditions: dict) -> dict:
    """Filter rows of a CSV using equality conditions on named columns.

    Args:
        csv_path: Path to CSV file.
        conditions: Dict of {column_name: value}. Multiple keys are AND-combined.

    Returns:
        dict with filtered rows count and first 30 rows.
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    for col, val in conditions.items():
        if col in df.columns:
            df = df[df[col] == val]
    rows = df.to_dict("records")
    return {
        "n_filtered": len(rows),
        "rows": rows[:30],
        "truncated": len(rows) > 30,
    }


@mcp.tool()
def merge_csvs(left_path: str, right_path: str, on: str, how: str = "left") -> dict:
    """SQL-style join two CSV files on a single key column.

    Args:
        left_path: Left CSV.
        right_path: Right CSV.
        on: Common column name.
        how: 'left', 'right', 'inner', or 'outer'.

    Returns:
        dict with merged shape and first 30 rows.
    """
    import pandas as pd
    a = pd.read_csv(left_path)
    b = pd.read_csv(right_path)
    m = a.merge(b, on=on, how=how)
    rows = m.to_dict("records")
    return {
        "columns": list(m.columns),
        "total_rows": len(rows),
        "rows": rows[:30],
        "truncated": len(rows) > 30,
    }


# ---------------------------------------------------------------------------
# Statistical primitives
# ---------------------------------------------------------------------------


@mcp.tool()
def descriptive_stats(values: list) -> dict:
    """Compute descriptive statistics (mean, std, quartiles, min/max) for a numeric list.

    Args:
        values: List of numbers (NaN entries are dropped).

    Returns:
        dict with count, mean, std, min, max, median, p25, p75, p10, p90.
    """
    arr = np.array(values, dtype=float)
    arr = arr[~np.isnan(arr)]
    if len(arr) == 0:
        return {"count": 0}
    return {
        "count": int(len(arr)),
        "mean": round(float(arr.mean()), 4),
        "std": round(float(arr.std(ddof=1)) if len(arr) > 1 else 0.0, 4),
        "min": round(float(arr.min()), 4),
        "max": round(float(arr.max()), 4),
        "median": round(float(np.median(arr)), 4),
        "p10": round(float(np.percentile(arr, 10)), 4),
        "p25": round(float(np.percentile(arr, 25)), 4),
        "p75": round(float(np.percentile(arr, 75)), 4),
        "p90": round(float(np.percentile(arr, 90)), 4),
    }


@mcp.tool()
def linear_fit(x_values: list, y_values: list) -> dict:
    """Ordinary least-squares linear regression y = a*x + b.

    Args:
        x_values: independent variable values.
        y_values: dependent variable values.

    Returns:
        dict with slope, intercept, r2, n.
    """
    x = np.array(x_values, dtype=float)
    y = np.array(y_values, dtype=float)
    mask = ~(np.isnan(x) | np.isnan(y))
    x, y = x[mask], y[mask]
    if len(x) < 2:
        return {"slope": None, "intercept": None, "r2": None, "n": int(len(x))}
    slope, intercept = np.polyfit(x, y, 1)
    yhat = slope * x + intercept
    ss_res = np.sum((y - yhat) ** 2)
    ss_tot = np.sum((y - y.mean()) ** 2)
    r2 = 1 - ss_res / ss_tot if ss_tot > 0 else 0.0
    return {
        "slope": round(float(slope), 6),
        "intercept": round(float(intercept), 6),
        "r2": round(float(r2), 4),
        "n": int(len(x)),
    }


@mcp.tool()
def welch_t_test(group_a: list, group_b: list) -> dict:
    """Welch's two-sample t-test (unequal variances) on two numeric lists.

    Args:
        group_a: first sample.
        group_b: second sample.

    Returns:
        dict with t-statistic, p-value, mean_a, mean_b, n_a, n_b.
    """
    from scipy.stats import ttest_ind
    a = np.array(group_a, dtype=float); a = a[~np.isnan(a)]
    b = np.array(group_b, dtype=float); b = b[~np.isnan(b)]
    if len(a) < 2 or len(b) < 2:
        return {"error": "need at least 2 observations per group"}
    res = ttest_ind(a, b, equal_var=False)
    return {
        "t_statistic": round(float(res.statistic), 4),
        "p_value": float(res.pvalue),
        "mean_a": round(float(a.mean()), 4),
        "mean_b": round(float(b.mean()), 4),
        "n_a": int(len(a)),
        "n_b": int(len(b)),
    }


@mcp.tool()
def count_threshold(values: list, threshold: float, operator: str = "<") -> dict:
    """Count and percent of values satisfying a threshold condition.

    Args:
        values: list of numbers.
        threshold: comparison value.
        operator: one of '<', '<=', '>', '>='.

    Returns:
        dict with count, total, percentage.
    """
    arr = np.array(values, dtype=float); arr = arr[~np.isnan(arr)]
    ops = {"<": arr < threshold, "<=": arr <= threshold,
           ">": arr > threshold, ">=": arr >= threshold}
    if operator not in ops:
        return {"error": f"unknown operator {operator}"}
    mask = ops[operator]
    return {
        "count": int(mask.sum()),
        "total": int(len(arr)),
        "percentage": round(float(mask.mean() * 100.0), 2),
        "operator": operator,
        "threshold": threshold,
    }


@mcp.tool()
def group_summary(csv_path: str, group_col: str, value_col: str) -> dict:
    """Per-group summary statistics for a numeric column in a CSV.

    Args:
        csv_path: input CSV.
        group_col: grouping column.
        value_col: numeric column to summarize.

    Returns:
        dict mapping each group key to {n, mean, std, median, min, max}.
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    out: dict[str, dict[str, float]] = {}
    for key, grp in df.groupby(group_col):
        v = grp[value_col].dropna().to_numpy(dtype=float)
        if len(v) == 0:
            continue
        out[str(key)] = {
            "n": int(len(v)),
            "mean": round(float(v.mean()), 4),
            "std": round(float(v.std(ddof=1)) if len(v) > 1 else 0.0, 4),
            "median": round(float(np.median(v)), 4),
            "min": round(float(v.min()), 4),
            "max": round(float(v.max()), 4),
        }
    return {"group_col": group_col, "value_col": value_col, "groups": out}


# ---------------------------------------------------------------------------
# Domain primitives: heat pump physics
# ---------------------------------------------------------------------------


@mcp.tool()
def carnot_cop(t_supply_c: float, t_source_c: float) -> dict:
    """Carnot (theoretical maximum) COP for a heat pump.

    Args:
        t_supply_c: condenser supply temperature in degrees Celsius.
        t_source_c: evaporator source temperature in degrees Celsius.

    Returns:
        dict with carnot_cop and the temperature lift in Kelvin.
    """
    Th = t_supply_c + 273.15
    Tc = t_source_c + 273.15
    if Th <= Tc:
        return {"carnot_cop": None, "lift_K": round(Th - Tc, 4),
                "error": "supply must exceed source"}
    return {
        "carnot_cop": round(Th / (Th - Tc), 4),
        "lift_K": round(Th - Tc, 4),
    }


@mcp.tool()
def fit_cop_curve(outdoor_temp: list, cop_values: list) -> dict:
    """Fit a linear COP model COP(T_out) = a*T_out + b for one heat pump.

    Args:
        outdoor_temp: list of binned outdoor temperatures in degrees Celsius.
        cop_values: corresponding COP measurements.

    Returns:
        dict with slope, intercept, r2, n_points used after dropping NaNs.
    """
    return linear_fit(outdoor_temp, cop_values)


@mcp.tool()
def fit_cop_curves_per_hp(csv_path: str, hp_col: str, temp_col: str,
                          cop_col: str, min_points: int = 4) -> dict:
    """Fit linear COP(T_out) for every unique heat pump in a CSV.

    Args:
        csv_path: file with binned COP data per HP per outdoor-temperature bin.
        hp_col: column with the heat-pump identifier.
        temp_col: numeric outdoor temperature column.
        cop_col: numeric COP column.
        min_points: minimum non-NaN observations to attempt a fit (default 4).

    Returns:
        dict with n_fitted, slope/intercept/r2 summary statistics, and the per-HP
        list (truncated to first 50 records, full set saved to disk).
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    fits = []
    for hp_id, grp in df.groupby(hp_col):
        x = grp[temp_col].to_numpy(dtype=float)
        y = grp[cop_col].to_numpy(dtype=float)
        mask = ~(np.isnan(x) | np.isnan(y))
        if mask.sum() < min_points:
            continue
        xx, yy = x[mask], y[mask]
        slope, intercept = np.polyfit(xx, yy, 1)
        yhat = slope * xx + intercept
        ss_res = np.sum((yy - yhat) ** 2)
        ss_tot = np.sum((yy - yy.mean()) ** 2)
        r2 = 1 - ss_res / ss_tot if ss_tot > 0 else 0.0
        fits.append({
            "hp_id": int(hp_id),
            "slope": round(float(slope), 6),
            "intercept": round(float(intercept), 6),
            "r2": round(float(r2), 4),
            "n": int(mask.sum()),
        })
    slopes = np.array([f["slope"] for f in fits])
    intercepts = np.array([f["intercept"] for f in fits])
    return {
        "n_fitted": len(fits),
        "slope_summary": {"mean": round(float(slopes.mean()), 4) if len(slopes) else None,
                          "median": round(float(np.median(slopes)), 4) if len(slopes) else None,
                          "std": round(float(slopes.std(ddof=1)), 4) if len(slopes) > 1 else None},
        "intercept_summary": {"mean": round(float(intercepts.mean()), 4) if len(intercepts) else None,
                              "median": round(float(np.median(intercepts)), 4) if len(intercepts) else None},
        "fits": fits[:50],
        "truncated": len(fits) > 50,
    }


@mcp.tool()
def predict_cop(slope: float, intercept: float, outdoor_temp_c: float) -> dict:
    """Predict COP for a single (slope, intercept) at a given outdoor temperature.

    Args:
        slope: linear slope (per Kelvin).
        intercept: COP at T_out = 0 degrees C.
        outdoor_temp_c: outdoor temperature in degrees Celsius.

    Returns:
        dict with predicted_cop.
    """
    return {"predicted_cop": round(float(slope * outdoor_temp_c + intercept), 4)}


@mcp.tool()
def compute_scop(cop_at_temps: list, weights: list) -> dict:
    """Compute SCOP as a weighted average of COP values at standard EN 14825
    outdoor temperatures (bin method).

    Args:
        cop_at_temps: list of COP values (one per standard temperature point).
        weights: corresponding hour weights from the standard.

    Returns:
        dict with scop, sum_of_weights, n_points used.
    """
    c = np.array(cop_at_temps, dtype=float)
    w = np.array(weights, dtype=float)
    mask = ~(np.isnan(c) | np.isnan(w))
    if mask.sum() == 0 or w[mask].sum() == 0:
        return {"scop": None, "sum_weights": 0, "n_points": 0}
    scop = float(np.sum(c[mask] * w[mask]) / np.sum(w[mask]))
    return {"scop": round(scop, 4),
            "sum_weights": round(float(w[mask].sum()), 1),
            "n_points": int(mask.sum())}


@mcp.tool()
def compute_scop_per_hp(cop_csv: str, hp_overview_csv: str, en14825_csv: str,
                        hp_col: str = "hp_id", temp_col: str = "outdoor_temp_median",
                        cop_col: str = "cop_sh_median",
                        in_scop_only: bool = True) -> dict:
    """Compute SCOP for every heat pump by fitting a COP curve and evaluating
    it at the EN 14825 standard outdoor temperatures, with per-HP climate-zone
    weights and optional SCOP-eligibility filtering.

    Args:
        cop_csv: per-HP per-bin COP file.
        hp_overview_csv: per-HP metadata file with hp_type, climate_zone, in_scop columns.
        en14825_csv: standard temperatures with per-climate-zone weight columns
            (weight_hours_average, weight_hours_cold, weight_hours_warmer).
        hp_col: HP identifier column shared between cop_csv and hp_overview_csv.
        temp_col: outdoor temperature column in cop_csv (numeric).
        cop_col: COP column in cop_csv.
        in_scop_only: if True, drop HPs whose hp_overview.in_scop is False.

    Returns:
        dict with n_hps, scop summary (overall + per hp_type), per-HP SCOP list
        carrying hp_id, hp_type, climate_zone, in_scop, slope, intercept, scop_real.
    """
    import pandas as pd
    df = pd.read_csv(cop_csv)
    ov = pd.read_csv(hp_overview_csv)
    std = pd.read_csv(en14825_csv)
    std_temps = std["temperature_C"].to_numpy(dtype=float)
    if in_scop_only:
        ov = ov[ov["in_scop"].astype(bool)]
    ov_idx = ov.set_index(hp_col)
    out = []
    for hp_id, grp in df.groupby(hp_col):
        if hp_id not in ov_idx.index:
            continue
        meta = ov_idx.loc[hp_id]
        climate_zone = str(meta["climate_zone"]).strip()
        weight_col = f"weight_hours_{climate_zone.lower()}"
        if weight_col not in std.columns:
            continue
        std_w = std[weight_col].to_numpy(dtype=float)
        x = grp[temp_col].to_numpy(dtype=float)
        y = grp[cop_col].to_numpy(dtype=float)
        mask = ~(np.isnan(x) | np.isnan(y))
        if mask.sum() < 2:
            continue
        slope, intercept = np.polyfit(x[mask], y[mask], 1)
        cop_eval = slope * std_temps + intercept
        scop_real = float(np.sum(cop_eval * std_w) / np.sum(std_w))
        out.append({
            "hp_id": int(hp_id),
            "hp_type": str(meta["hp_type"]),
            "climate_zone": climate_zone,
            "in_scop": bool(meta["in_scop"]),
            "slope": round(float(slope), 6),
            "intercept": round(float(intercept), 6),
            "scop_real": round(scop_real, 4),
            "n_points": int(mask.sum()),
        })
    scops = np.array([r["scop_real"] for r in out])
    per_type = {}
    for t in sorted({r["hp_type"] for r in out}):
        vals = np.array([r["scop_real"] for r in out if r["hp_type"] == t])
        per_type[t] = {
            "n": int(len(vals)),
            "mean": round(float(vals.mean()), 4) if len(vals) else None,
            "median": round(float(np.median(vals)), 4) if len(vals) else None,
            "std": round(float(vals.std(ddof=1)), 4) if len(vals) > 1 else None,
        }
    return {
        "n_hps": len(out),
        "scop_summary": {
            "mean": round(float(scops.mean()), 4) if len(scops) else None,
            "median": round(float(np.median(scops)), 4) if len(scops) else None,
            "std": round(float(scops.std(ddof=1)), 4) if len(scops) > 1 else None,
            "min": round(float(scops.min()), 4) if len(scops) else None,
            "max": round(float(scops.max()), 4) if len(scops) else None,
            "p25": round(float(np.percentile(scops, 25)), 4) if len(scops) else None,
            "p75": round(float(np.percentile(scops, 75)), 4) if len(scops) else None,
        },
        "scop_by_hp_type": per_type,
        "results": out[:50],
        "truncated": len(out) > 50,
        "_full_results": out,
    }


@mcp.tool()
def classify_efficiency(scop_values: list, thresholds_csv: str,
                        threshold_col: str = "scop_min_medium_temp") -> dict:
    """Classify a list of SCOP values into A+++, A++, A+, A, B, C, D, G classes.

    Args:
        scop_values: list of SCOP numbers.
        thresholds_csv: path to efficiency_classes.csv with class -> SCOP minimum.
        threshold_col: column to use ('scop_min_low_temp' or 'scop_min_medium_temp').

    Returns:
        dict with class counts, percentages, and ordered class list.
    """
    import pandas as pd
    cls = pd.read_csv(thresholds_csv).sort_values(threshold_col, ascending=False)
    classes = cls["efficiency_class"].tolist()
    cuts = cls[threshold_col].tolist()
    arr = np.array(scop_values, dtype=float); arr = arr[~np.isnan(arr)]
    counts = {c: 0 for c in classes}
    for v in arr:
        for cname, cut in zip(classes, cuts):
            if v >= cut:
                counts[cname] += 1
                break
    total = int(arr.size)
    pct = {c: round(counts[c] / total * 100.0, 2) if total else 0.0 for c in classes}
    return {
        "n_total": total,
        "counts": counts,
        "percentages": pct,
        "ordered_classes": classes,
        "thresholds": dict(zip(classes, [round(float(c), 3) for c in cuts])),
    }


@mcp.tool()
def fraction_below_threshold(scop_values: list, threshold: float) -> dict:
    """Fraction of HPs whose SCOP falls below an "optimization required" threshold.

    Args:
        scop_values: list of SCOP numbers.
        threshold: paper-level cut-off (e.g., 3.0).

    Returns:
        dict with n_below, n_total, percent_below.
    """
    arr = np.array(scop_values, dtype=float); arr = arr[~np.isnan(arr)]
    n_below = int(np.sum(arr < threshold))
    n_total = int(arr.size)
    return {
        "n_below": n_below,
        "n_total": n_total,
        "percent_below": round(100.0 * n_below / n_total, 2) if n_total else 0.0,
        "threshold": threshold,
    }


# ---------------------------------------------------------------------------
# Plotting primitives (one tool per artifact image)
# ---------------------------------------------------------------------------


@mcp.tool()
def plot_cop_vs_temperature(csv_path: str, hp_col: str, temp_col: str,
                            cop_col: str, hp_type_csv: str,
                            output_path: str) -> dict:
    """Render Figure 1b style: average COP vs outdoor temperature, separated
    by HP type (Air-Source vs Ground-Source).

    Args:
        csv_path: per-HP per-bin COP CSV.
        hp_col: HP identifier column.
        temp_col: outdoor temperature column.
        cop_col: COP column.
        hp_type_csv: hp_overview.csv mapping hp_id to hp_type.
        output_path: output PNG path.

    Returns:
        dict with output_path, n_points used, and aggregate stats.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import pandas as pd
    df = pd.read_csv(csv_path).merge(pd.read_csv(hp_type_csv)[["hp_id", "hp_type"]],
                                     left_on=hp_col, right_on="hp_id", how="left")
    fig, ax = plt.subplots(figsize=(7, 4.5), dpi=150)
    summary: dict = {}
    for hp_type, marker, color in [("Air-Source", "v", "#bda66e"),
                                   ("Ground-Source", "o", "#3e6c8c")]:
        sub = df[df["hp_type"] == hp_type].dropna(subset=[temp_col, cop_col])
        binned = sub.groupby(pd.cut(sub[temp_col], bins=np.arange(-6, 16, 1)))[cop_col].agg(["mean", "std", "count"])
        binned = binned.dropna()
        x = [iv.mid for iv in binned.index]
        y = binned["mean"].to_numpy(dtype=float)
        e = binned["std"].to_numpy(dtype=float) / np.sqrt(binned["count"].to_numpy(dtype=float))
        ax.errorbar(x, y, yerr=1.96 * e, fmt=f"-{marker}", color=color, label=f"{hp_type} (N={int(sub[hp_col].nunique())})", capsize=2)
        summary[hp_type] = {"n_hps": int(sub[hp_col].nunique()),
                            "n_obs": int(len(sub)),
                            "cop_at_7C": round(float(y[len(y)//2]), 3) if len(y) else None}
    ax.set_xlabel("Average Outdoor Temperature [°C]")
    ax.set_ylabel("Coefficient of Performance (COP)")
    ax.set_title("Mean COP vs outdoor temperature, by heat pump type")
    ax.legend(loc="upper left")
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(output_path)
    plt.close(fig)
    return {"output_path": output_path, "summary": summary}


@mcp.tool()
def plot_scop_distribution(scop_csv: str, hp_type_col: str, scop_col: str,
                           output_path: str) -> dict:
    """Render Figure 3a style: SCOP distribution split by HP type, with mean and
    median markers.

    Args:
        scop_csv: CSV with one row per HP, with hp_type and computed SCOP.
        hp_type_col: HP type column.
        scop_col: numeric SCOP column.
        output_path: PNG output.

    Returns:
        dict with output_path and per-type summary statistics.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import pandas as pd
    df = pd.read_csv(scop_csv)
    fig, ax = plt.subplots(figsize=(7.5, 4), dpi=150)
    summary: dict = {}
    for i, hp_type in enumerate(["Air-Source", "Ground-Source"]):
        sub = df[df[hp_type_col] == hp_type][scop_col].dropna().to_numpy(dtype=float)
        if len(sub) == 0:
            continue
        ax.boxplot(sub, vert=False, positions=[i], widths=0.55, showmeans=True,
                   meanprops={"marker": "D", "markerfacecolor": "k"},
                   patch_artist=True,
                   boxprops={"facecolor": ["#dec78a", "#7d9ab2"][i], "alpha": 0.7})
        summary[hp_type] = {"n": int(len(sub)),
                            "mean": round(float(sub.mean()), 3),
                            "median": round(float(np.median(sub)), 3),
                            "std": round(float(sub.std(ddof=1)), 3) if len(sub) > 1 else 0.0,
                            "min": round(float(sub.min()), 3),
                            "max": round(float(sub.max()), 3)}
    ax.set_yticks([0, 1])
    ax.set_yticklabels(["Air-Source\nHeat Pumps", "Ground-Source\nHeat Pumps"])
    ax.set_xlabel("Real Seasonal Coefficient of Performance (SCOP)")
    ax.set_title("Real SCOP distribution per heat pump type")
    ax.grid(True, axis="x", alpha=0.3)
    fig.tight_layout()
    fig.savefig(output_path)
    plt.close(fig)
    return {"output_path": output_path, "summary": summary}


@mcp.tool()
def plot_efficiency_class_distribution(scop_csv: str, hp_type_col: str,
                                       scop_col: str, thresholds_csv: str,
                                       output_path: str,
                                       threshold_col: str = "scop_min_medium_temp"
                                       ) -> dict:
    """Render Figure 3b/c style: stacked bars of efficiency class shares, one
    panel per HP type.

    Args:
        scop_csv: CSV with one row per HP, including hp_type and SCOP.
        hp_type_col: HP type column.
        scop_col: SCOP column.
        thresholds_csv: efficiency_classes.csv.
        output_path: PNG output.
        threshold_col: column in thresholds_csv to use.

    Returns:
        dict with output_path and per-type class shares.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import pandas as pd
    df = pd.read_csv(scop_csv)
    cls = pd.read_csv(thresholds_csv).sort_values(threshold_col, ascending=False)
    classes = cls["efficiency_class"].tolist()
    cuts = cls[threshold_col].tolist()
    types = ["Air-Source", "Ground-Source"]
    palette = ["#7c1d3f", "#a6325b", "#c75a7e", "#dd8d9b", "#e7afba", "#9bb1c5", "#5c809f", "#2f4d72"]
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.2), dpi=150, sharey=True)
    summary: dict = {}
    for ax, hp_type in zip(axes, types):
        v = df[df[hp_type_col] == hp_type][scop_col].dropna().to_numpy(dtype=float)
        if len(v) == 0:
            continue
        counts = {c: 0 for c in classes}
        for x in v:
            for cname, cut in zip(classes, cuts):
                if x >= cut:
                    counts[cname] += 1
                    break
        total = int(len(v))
        bottom = 0
        for cname, color in zip(classes, palette):
            pct = counts[cname] / total * 100.0
            ax.bar(0, pct, bottom=bottom, width=0.6, color=color, label=cname)
            if pct >= 3:
                ax.text(0, bottom + pct / 2, f"{cname}\n{pct:.1f}%", ha="center", va="center",
                        fontsize=8, color="white" if cname in ("A+++", "A++", "G", "D") else "black")
            bottom += pct
        ax.set_xticks([])
        ax.set_xlabel(f"{hp_type}\nN={total}")
        ax.set_ylim(0, 100)
        summary[hp_type] = {"n": total,
                            "class_counts": counts,
                            "class_percentages": {c: round(counts[c]/total*100, 2) for c in classes}}
    axes[0].set_ylabel("Share of Heat Pumps [%]")
    fig.suptitle("Efficiency class distribution (regulation 811/2013)")
    fig.tight_layout()
    fig.savefig(output_path)
    plt.close(fig)
    return {"output_path": output_path, "summary": summary}


@mcp.tool()
def write_csv(rows_json: str, output_path: str) -> dict:
    """Write a list-of-dicts (JSON-encoded string) to a CSV file.

    Args:
        rows_json: JSON-encoded list of dicts.
        output_path: where to save the CSV.

    Returns:
        dict with output_path and row count.
    """
    import pandas as pd
    rows = json.loads(rows_json)
    df = pd.DataFrame(rows)
    df.to_csv(output_path, index=False)
    return {"output_path": output_path, "n_rows": len(df), "columns": list(df.columns)}


if __name__ == "__main__":
    mcp.run(transport="stdio")

#!/usr/bin/env python3
"""Domain-specific tools for vapor-injection heat pump cycle analysis with
component-adjustable two-phase ejector.

All thermodynamic state-points use CoolProp's HEOS (REFPROP-equivalent) backend.
Refrigerant mixtures use the syntax 'HEOS::n-Butane[0.5]&R245FA[0.5]'.

This module provides the *primitives*; the agent must chain them to
- pick a refrigerant mixture for a 50/125 degC HTHP duty,
- compute pure-fluid and mixture COP_h and ejector entrainment ratio,
- size the ejector throat / outlet / mixing-chamber diameters,
- evaluate continuous tuning ranges as load fluctuates +/- 5 percent
  by varying high-pressure subcooling, compressor inlet superheat and
  vapor-injection pressure.
"""
from __future__ import annotations

import math
from typing import Any

import numpy as np

try:
    from mcp.server.fastmcp import FastMCP
    mcp = FastMCP("HeatPump_Ejector_Tools")
    _HAS_MCP = True
except Exception:  # pragma: no cover
    _HAS_MCP = False
    class _Stub:
        def tool(self):
            def deco(fn):
                return fn
            return deco
    mcp = _Stub()


# ---------------------------------------------------------------------------
# CoolProp wrappers
# ---------------------------------------------------------------------------

def _heos_name(components: list[str], fractions: list[float]) -> str:
    """Build the CoolProp HEOS mixture string."""
    if len(components) != len(fractions):
        raise ValueError("components and fractions length mismatch")
    parts = [f"{c}[{x:.6f}]" for c, x in zip(components, fractions)]
    return "HEOS::" + "&".join(parts)


@mcp.tool()
def prop(prop_name: str, in1: str, val1: float, in2: str, val2: float,
         fluid: str) -> float:
    """Look up a fluid property via CoolProp.PropsSI.

    Args:
        prop_name: output property symbol (e.g. 'H', 'S', 'T', 'P', 'D', 'Q').
        in1, in2: input property symbols.
        val1, val2: input values in SI units (Pa, K, J/kg, J/kg/K, ...).
        fluid: CoolProp fluid string. For mixtures use the
            'HEOS::n-Butane[0.5]&R245FA[0.5]' form, or call
            ``mixture_fluid_string`` first.

    Returns:
        Property value in SI units.
    """
    from CoolProp.CoolProp import PropsSI
    return float(PropsSI(prop_name, in1, val1, in2, val2, fluid))


@mcp.tool()
def mixture_fluid_string(components: list[str], fractions: list[float]) -> str:
    """Build a CoolProp HEOS mixture identifier.

    Example: components=['n-Butane','R245FA'], fractions=[0.5,0.5] returns
    'HEOS::n-Butane[0.500000]&R245FA[0.500000]'.
    """
    s = sum(fractions)
    if abs(s - 1.0) > 1e-6:
        fractions = [x / s for x in fractions]
    return _heos_name(components, fractions)


@mcp.tool()
def saturation_pressure(fluid: str, T_K: float, quality: float = 0.0) -> float:
    """Return saturation pressure (Pa) at temperature T (K) and given quality.

    For pure fluids quality is irrelevant; for mixtures Q=0 gives bubble pressure
    and Q=1 gives dew pressure (different for zeotropes).
    """
    from CoolProp.CoolProp import PropsSI
    return float(PropsSI("P", "T", T_K, "Q", quality, fluid))


@mcp.tool()
def saturation_temperature(fluid: str, P_Pa: float, quality: float = 0.0) -> float:
    """Return saturation temperature (K) at pressure P (Pa) and quality."""
    from CoolProp.CoolProp import PropsSI
    return float(PropsSI("T", "P", P_Pa, "Q", quality, fluid))


# ---------------------------------------------------------------------------
# Compressor model (paper Eq. 44, 45, 51)
# ---------------------------------------------------------------------------

@mcp.tool()
def compressor_efficiency(pressure_ratio: float) -> float:
    """Isentropic efficiency of the compressor as a function of pressure ratio.

    eta_com = 0.85 - 0.0467 * r_c   (paper Eq. 44).
    """
    return 0.85 - 0.0467 * float(pressure_ratio)


@mcp.tool()
def compressor_outlet(P_in_Pa: float, h_in: float, s_in: float, P_out_Pa: float,
                      fluid: str) -> dict:
    """Compute compressor outlet state given inlet and discharge pressure.

    Returns dict with h_out (J/kg), T_out (K), eta_is, work specific (J/kg).
    """
    from CoolProp.CoolProp import PropsSI
    eta = compressor_efficiency(P_out_Pa / P_in_Pa)
    h_is = PropsSI("H", "P", P_out_Pa, "S", s_in, fluid)
    h_out = h_in + (h_is - h_in) / eta
    T_out = PropsSI("T", "P", P_out_Pa, "H", h_out, fluid)
    return {
        "h_out_J_per_kg": float(h_out),
        "T_out_K": float(T_out),
        "eta_isentropic": float(eta),
        "specific_work_J_per_kg": float(h_out - h_in),
    }


# ---------------------------------------------------------------------------
# Two-phase ejector model (paper Table 1, 2)
# ---------------------------------------------------------------------------

@mcp.tool()
def two_phase_speed_of_sound(P_Pa: float, x: float, fluid: str) -> float:
    """Two-phase speed of sound (m/s) at pressure P and quality x.

    Implements paper Eq. 1, 2 with isothermal void fraction
        alpha_v = 1 / (1 + (1-x)/x * rho_v/rho_l)
    and homogeneous-equilibrium sonic velocity
        c = sqrt( k * R_g * T * (alpha_v^2 + alpha_v*(1-alpha_v)*rho_l/rho_v)^-1 )
    using vapour-side k = cp/cv, R_g = R/M.
    """
    from CoolProp.CoolProp import PropsSI
    rho_v = PropsSI("D", "P", P_Pa, "Q", 1, fluid)
    rho_l = PropsSI("D", "P", P_Pa, "Q", 0, fluid)
    T = PropsSI("T", "P", P_Pa, "Q", x, fluid)
    cp_v = PropsSI("Cpmass", "P", P_Pa, "Q", 1, fluid)
    cv_v = PropsSI("Cvmass", "P", P_Pa, "Q", 1, fluid)
    M = PropsSI("M", fluid)
    R_g = 8.31446 / M
    k = cp_v / cv_v
    alpha_v = 1.0 / (1.0 + (1.0 - x) / max(x, 1e-9) * rho_v / rho_l)
    inv = alpha_v ** 2 + alpha_v * (1.0 - alpha_v) * rho_l / rho_v
    return float(math.sqrt(k * R_g * T / max(inv, 1e-9)))


@mcp.tool()
def henry_fauske_critical(P6_Pa: float, fluid: str, N: float = 1.0) -> dict:
    """Henry-Fauske critical (choked) two-phase flow at the nozzle throat.

    Inputs the primary-nozzle inlet state (point 6) and the metastability
    relaxation factor N (paper Eq. 5; N=1 for x>=0.14, partial relaxation
    for low quality). Returns critical pressure P_cr (Pa) and critical mass
    flux G_cr (kg/m^2/s).
    """
    from CoolProp.CoolProp import PropsSI
    # Point 6 is saturated liquid at condenser exit
    v6 = 1.0 / PropsSI("D", "P", P6_Pa, "Q", 0, fluid)
    s_l = PropsSI("S", "P", P6_Pa, "Q", 0, fluid)

    def integrand(P):
        v_g = 1.0 / PropsSI("D", "P", P, "Q", 1, fluid)
        s_g = PropsSI("S", "P", P, "Q", 1, fluid)
        s_lP = PropsSI("S", "P", P, "Q", 0, fluid)
        ds_b_dP = (s_g - s_lP)
        return (v_g - v6) ** 2 / max((s_g - s_lP), 1e-9) * ds_b_dP, v_g, s_g, s_lP

    # Numerical search: G_cr maximises critical mass flux.  Treat P_cr as the
    # pressure at which G^2 = -[d/dP(integrand)]^-1.  Practical approach:
    # iterate a small grid below P6 and pick the maximum.
    Ps = np.linspace(0.4 * P6_Pa, 0.99 * P6_Pa, 40)
    best = (0.0, P6_Pa, 0.0)
    for P in Ps:
        v_g = 1.0 / PropsSI("D", "P", P, "Q", 1, fluid)
        s_g = PropsSI("S", "P", P, "Q", 1, fluid)
        s_l = PropsSI("S", "P", P, "Q", 0, fluid)
        ds_b = max(s_g - s_l, 1e-9)
        # discrete d(s_b)/d(P)
        dP = 1e3
        s_g2 = PropsSI("S", "P", P + dP, "Q", 1, fluid)
        s_l2 = PropsSI("S", "P", P + dP, "Q", 0, fluid)
        ds_dP = (max(s_g2 - s_l2, 1e-9) - ds_b) / dP
        denom = (v_g - v6) ** 2 / ds_b * ds_dP * N
        if denom <= 0:
            continue
        G = math.sqrt(1.0 / denom)
        if G > best[0]:
            best = (G, P, v_g)
    G_cr, P_cr, v_g = best
    return {"G_cr_kg_per_m2_s": float(G_cr),
            "P_cr_Pa": float(P_cr),
            "v_g_throat": float(v_g)}


@mcp.tool()
def constant_area_mixing(P_pf_in: float, h_pf_in: float, P_sf_in: float,
                         h_sf_in: float, mu: float, P_diff_out: float,
                         fluid: str, eta_n: float = 0.85, eta_s: float = 0.85,
                         eta_d: float = 0.85) -> dict:
    """Solve the constant-area mixing two-phase ejector model.

    Iterates Pk (mixing chamber inlet pressure) so that nozzle outlet
    velocity matches the speed of sound at the throat.  Returns ejector
    outlet pressure P9, entrainment ratio mu (echoed), pressure-lift
    ratio r_p = P9/P_sf_in, and key cross-section areas per unit primary
    mass flow.

    Args:
        P_pf_in: primary fluid pressure at nozzle inlet (Pa)
        h_pf_in: primary fluid specific enthalpy at nozzle inlet (J/kg)
        P_sf_in: secondary (suction) fluid pressure (Pa)
        h_sf_in: secondary fluid specific enthalpy (J/kg)
        mu: entrainment ratio m_sf/m_pf (dimensionless)
        P_diff_out: target diffuser outlet pressure (Pa); used as initial guess.
        fluid: CoolProp fluid identifier.
        eta_n, eta_s, eta_d: nozzle, suction, diffuser isentropic efficiencies.

    Returns:
        dict with P9_Pa (diffuser outlet), r_p, h9_J_per_kg, u8_m_per_s,
        c_throat_m_per_s, A_nozzle_per_mp_m2_s_per_kg, A_mix_per_mp,
        A_suction_per_mp.
    """
    from CoolProp.CoolProp import PropsSI

    # Step 1: nozzle expansion to throat pressure ~P_sf_in (use suction pressure
    # as first approximation per paper Eq. 12).
    P7 = P_sf_in
    s_pf = PropsSI("S", "P", P_pf_in, "H", h_pf_in, fluid)
    h7_is = PropsSI("H", "P", P7, "S", s_pf, fluid)
    h7 = h_pf_in - eta_n * (h_pf_in - h7_is)
    u7 = math.sqrt(max(2 * (h_pf_in - h7), 0.0))

    # Step 2: suction chamber expansion (paper Eq. 13)
    s_sf = PropsSI("S", "P", P_sf_in, "H", h_sf_in, fluid)
    h14p_is = PropsSI("H", "P", P7, "S", s_sf, fluid)
    h14p = h_sf_in - eta_s * (h_sf_in - h14p_is)
    u14p = math.sqrt(max(2 * (h_sf_in - h14p), 0.0))

    # Step 3: mixing chamber - momentum + energy (Eq. 18, 19)
    # Solve for u8: (u7 + mu*u14p) / (1+mu) approx (no friction)
    u8 = (u7 + mu * u14p) / (1.0 + mu)
    h8 = (h7 + mu * h14p) / (1.0 + mu) - 0.5 * u8 ** 2

    # Step 4: post-shock state (Eq. 22-26): assume no shock if subsonic
    P_post = P7  # constant-area mixing at suction pressure
    rho8 = PropsSI("D", "P", P_post, "H", h8, fluid)
    c_throat = two_phase_speed_of_sound(P_post,
                                        PropsSI("Q", "P", P_post, "H", h8,
                                                fluid),
                                        fluid)

    # Step 5: diffuser pressure recovery (Eq. 28-30)
    h9 = h8 + 0.5 * u8 ** 2
    s8 = PropsSI("S", "P", P_post, "H", h8, fluid)
    h9_is = h8 + eta_d * (h9 - h8)
    P9_guess = P_diff_out
    # Use isentropic diffuser to estimate P9 from h_is
    try:
        P9 = PropsSI("P", "H", h9_is, "S", s8, fluid)
    except Exception:
        P9 = P9_guess

    return {
        "P9_Pa": float(P9),
        "r_p_lift": float(P9 / P_sf_in),
        "h9_J_per_kg": float(h9),
        "u7_m_per_s": float(u7),
        "u8_m_per_s": float(u8),
        "c_throat_m_per_s": float(c_throat),
        "A_nozzle_per_mp": float(1.0 / max(rho8 * u8, 1e-9)),
        "A_mix_per_mp": float((1 + mu) / max(rho8 * u8, 1e-9)),
        "A_suction_per_mp": float(mu / max(
            PropsSI("D", "P", P_post, "H", h14p, fluid) * u14p, 1e-9)),
    }


@mcp.tool()
def ejector_diameters(area_throat: float, area_nozzle_out: float,
                      area_mixing: float) -> dict:
    """Convert cross-sectional areas (m^2) to equivalent circular diameters
    (mm) for D_nt, D_no, D_m (paper Table 2 Eq. 32, 33, 38).
    """
    def d(A):
        return 2.0 * math.sqrt(max(A, 0.0) / math.pi) * 1000.0
    return {
        "D_nt_mm": d(area_throat),
        "D_no_mm": d(area_nozzle_out),
        "D_m_mm": d(area_mixing),
    }


# ---------------------------------------------------------------------------
# Equivalent ejector efficiency (paper Eq. 47, 49)
# ---------------------------------------------------------------------------

@mcp.tool()
def equivalent_ejector_efficiency(h_pf_in: float, h_pf_out_actual: float,
                                  h_pf_out_isentropic: float,
                                  h_sf_in: float, h_sf_out_actual: float,
                                  h_sf_out_isentropic: float,
                                  mu: float) -> float:
    """Equivalent ejector efficiency eta_eje.

    eta_eje = mu * (h_pf_isentropic - h_sf_in) / (h_pf_in - h_pf_out_actual)
    The paper interprets this as the ratio of recovered work in the secondary
    stream to the maximum extractable work from the primary expansion (Eq. 49).
    """
    work_in = max(h_pf_in - h_pf_out_actual, 1e-9)
    work_out = mu * max(h_sf_out_actual - h_sf_in, 0.0)
    work_max = max(h_pf_in - h_pf_out_isentropic, 1e-9)
    # Definition per paper: ratio of mu*(h(P9,s14)-h14) to (h6 - h(P9,s6))
    return float(work_out / work_max)


# ---------------------------------------------------------------------------
# COP and cascade-equivalent COP
# ---------------------------------------------------------------------------

@mcp.tool()
def heating_cop(Q_con_W: float, W_com_W: float) -> float:
    """COP_h = Q_con / W_com  (paper Eq. 43)."""
    return float(Q_con_W / max(W_com_W, 1e-9))


@mcp.tool()
def equivalent_cascade_cop(Q_con_W: float, W_com1_W: float) -> float:
    """COP_h,e = Q_con / W_com1 (paper Eq. 48). The equivalent cascade
    interpretation removes the ejector-driven compressor 2 work."""
    return float(Q_con_W / max(W_com1_W, 1e-9))


# ---------------------------------------------------------------------------
# Refrigerant screening
# ---------------------------------------------------------------------------

@mcp.tool()
def screen_pure_refrigerants(fluids: list[str], T_eva_K: float, T_con_K: float,
                             Q_con_W: float, eta_n: float = 0.85,
                             eta_d: float = 0.85,
                             dT_subcool: float = 0.0,
                             dT_superheat: float = 0.0) -> list[dict]:
    """Compute COP_h and ejector entrainment ratio for each pure fluid in a
    simple ejector-enhanced cycle (Fig. 1a of the paper).

    Implementation: two-phase ejector with primary inlet at saturated liquid
    P_con and secondary at saturated vapour P_eva.  Compressor runs from
    ejector outlet to P_con.  Returns per-fluid {fluid, COP_h, mu, P_eva,
    P_con, T_dis_K}.
    """
    from CoolProp.CoolProp import PropsSI
    out: list[dict] = []
    for f in fluids:
        try:
            P_eva = PropsSI("P", "T", T_eva_K, "Q", 1, f)
            P_con = PropsSI("P", "T", T_con_K, "Q", 0, f)
            # Saturated liquid at condenser (state 3)
            h3 = PropsSI("H", "P", P_con, "Q", 0, f) - dT_subcool * \
                PropsSI("Cpmass", "P", P_con, "Q", 0, f)
            h_eva_v = PropsSI("H", "P", P_eva, "Q", 1, f) + dT_superheat * \
                PropsSI("Cpmass", "P", P_eva, "Q", 1, f)
            # Ejector outlet ~ P_eva*1.1 (assume modest pressure lift)
            P_mid = math.sqrt(P_eva * P_con)
            mu_guess = 1.0
            ej = constant_area_mixing(P_con, h3, P_eva, h_eva_v, mu_guess,
                                      P_mid, f, eta_n=eta_n, eta_s=0.85,
                                      eta_d=eta_d)
            P_sep = ej["P9_Pa"]
            h_sep_g = PropsSI("H", "P", P_sep, "Q", 1, f)
            s_sep_g = PropsSI("S", "P", P_sep, "H", h_sep_g, f)
            comp = compressor_outlet(P_sep, h_sep_g, s_sep_g, P_con, f)
            W = comp["specific_work_J_per_kg"]
            h2 = comp["h_out_J_per_kg"]
            q_con_per_kg = h2 - h3
            COP = q_con_per_kg / max(W, 1e-9)
            out.append({"fluid": f, "COP_h": float(COP), "mu": float(mu_guess),
                        "P_eva_Pa": float(P_eva), "P_con_Pa": float(P_con),
                        "T_dis_K": float(comp["T_out_K"])})
        except Exception as exc:
            out.append({"fluid": f, "error": str(exc)})
    return out


@mcp.tool()
def vapor_quality_at_separator(fluid: str, P_sep_Pa: float, h_sep: float
                              ) -> float:
    """Quality at separator inlet given pressure and enthalpy."""
    from CoolProp.CoolProp import PropsSI
    return float(PropsSI("Q", "P", P_sep_Pa, "H", h_sep, fluid))


@mcp.tool()
def mixture_separator_compositions(low_boiling: str, high_boiling: str,
                                   z_in: float, P_sep_Pa: float,
                                   T_sep_K: float | None = None,
                                   q_target: float | None = None
                                  ) -> dict:
    """For a binary zeotropic mixture at the gas-liquid separator, return
    vapour-phase mass fraction y of the low-boiling component, liquid-phase
    fraction x, and overall vapour quality.

    Either T_sep_K or q_target (vapour mass fraction) must be specified.
    """
    from CoolProp.CoolProp import PropsSI
    fluid = mixture_fluid_string([low_boiling, high_boiling],
                                 [z_in, 1 - z_in])
    if q_target is not None:
        T_sep_K = PropsSI("T", "P", P_sep_Pa, "Q", q_target, fluid)
    elif T_sep_K is None:
        raise ValueError("Need T_sep_K or q_target")
    # CoolProp does not expose phase compositions easily for HEOS in PropsSI;
    # use a simple Rachford-Rice with approximate K-values from saturated
    # pressures of pure components at T_sep.
    P1 = PropsSI("P", "T", T_sep_K, "Q", 1, low_boiling)
    P2 = PropsSI("P", "T", T_sep_K, "Q", 1, high_boiling)
    K1 = P1 / P_sep_Pa
    K2 = P2 / P_sep_Pa
    # Solve V from sum z_i (K_i - 1)/(1+V(K_i-1)) = 0
    z = [z_in, 1 - z_in]
    K = [K1, K2]
    # bisection
    lo, hi = 1e-6, 1 - 1e-6
    for _ in range(80):
        V = 0.5 * (lo + hi)
        f = sum(z[i] * (K[i] - 1) / (1 + V * (K[i] - 1)) for i in (0, 1))
        if f > 0:
            lo = V
        else:
            hi = V
    y_low = K1 * z_in / (1 + V * (K1 - 1))
    x_low = z_in / (1 + V * (K1 - 1))
    return {"y_low_boiling_vapor": float(y_low),
            "x_low_boiling_liquid": float(x_low),
            "vapor_fraction": float(V),
            "K1_low": float(K1), "K2_high": float(K2)}


# ---------------------------------------------------------------------------
# Tunability scan
# ---------------------------------------------------------------------------

@mcp.tool()
def tunability_scan(fluid: str, T_eva_K: float, T_con_K: float, Q_con_W: float,
                    P_inj_grid: list[float], dT_sub_grid: list[float],
                    dT_super_grid: list[float]) -> list[dict]:
    """Sweep three control variables (vapor injection pressure, high-pressure
    subcooling, compressor inlet superheat) and tabulate COP_h, mu, ejector
    diameters.  Used to assess the +/-5% load-fluctuation regulation window.
    """
    rows: list[dict] = []
    for Pi in P_inj_grid:
        for dts in dT_sub_grid:
            for dsh in dT_super_grid:
                row = {"P_inj_kPa": Pi / 1000.0,
                       "dT_subcool_K": dts,
                       "dT_superheat_K": dsh}
                try:
                    res = screen_pure_refrigerants([fluid], T_eva_K, T_con_K,
                                                   Q_con_W, dT_subcool=dts,
                                                   dT_superheat=dsh)
                    row.update(res[0])
                except Exception as e:
                    row["error"] = str(e)
                rows.append(row)
    return rows


@mcp.tool()
def adjustability_range(baseline: float, values: list[float]) -> dict:
    """Compute lower/upper percentage adjustment from a baseline value.

    Returns {min_pct, max_pct, range_pct}. Percentages are signed
    (lower = (min-baseline)/baseline*100, upper = (max-baseline)/baseline*100).
    """
    if not values:
        return {"min_pct": 0.0, "max_pct": 0.0, "range_pct": 0.0}
    vmin = min(values); vmax = max(values)
    return {
        "min_pct": float((vmin - baseline) / baseline * 100.0),
        "max_pct": float((vmax - baseline) / baseline * 100.0),
        "range_pct": float((vmax - vmin) / baseline * 100.0),
    }


# ---------------------------------------------------------------------------
# Plotting
# ---------------------------------------------------------------------------

@mcp.tool()
def plot_ph_diagram(fluid: str, points: list[dict], out_path: str,
                    title: str | None = None) -> str:
    """Plot a P-h diagram with the saturation dome and overlaid cycle points.

    points: list of {h_J_per_kg, P_Pa, label}.
    Returns absolute path to the saved PNG.
    """
    import os
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from CoolProp.CoolProp import PropsSI
    fig, ax = plt.subplots(figsize=(7, 5))
    Tc = PropsSI("Tcrit", fluid)
    Ts = np.linspace(PropsSI("Tmin", fluid) + 1, Tc - 0.5, 80)
    Pv = [PropsSI("P", "T", T, "Q", 1, fluid) for T in Ts]
    Pl = [PropsSI("P", "T", T, "Q", 0, fluid) for T in Ts]
    Hv = [PropsSI("H", "T", T, "Q", 1, fluid) / 1000 for T in Ts]
    Hl = [PropsSI("H", "T", T, "Q", 0, fluid) / 1000 for T in Ts]
    ax.plot(Hl + Hv[::-1], Pl + Pv[::-1], "k-", lw=1)
    if points:
        xs = [p["h_J_per_kg"] / 1000 for p in points]
        ys = [p["P_Pa"] / 1000 for p in points]
        ax.plot(xs, ys, "ro-", ms=5)
        for p in points:
            ax.annotate(p.get("label", ""),
                        (p["h_J_per_kg"] / 1000, p["P_Pa"] / 1000))
    ax.set_yscale("log")
    ax.set_xlabel("Enthalpy h (kJ/kg)")
    ax.set_ylabel("Pressure P (kPa)")
    ax.set_title(title or f"P-h diagram: {fluid}")
    ax.grid(True, which="both", alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=130)
    plt.close(fig)
    return os.path.abspath(out_path)


@mcp.tool()
def plot_refrigerant_heatmap(matrix: list[list[float]], row_labels: list[str],
                             col_labels: list[str], out_path: str,
                             title: str = "", cbar_label: str = "COP_h"
                            ) -> str:
    """Plot a 2-D heatmap (e.g., Fig. 4b: COP_h for refrigerant pairs).

    matrix[i][j] is the metric for row_labels[i] x col_labels[j].
    Returns the absolute output path.
    """
    import os
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    M = np.array(matrix, dtype=float)
    fig, ax = plt.subplots(figsize=(7, 6))
    im = ax.imshow(M, cmap="magma", origin="lower")
    ax.set_xticks(range(len(col_labels)), col_labels, rotation=45)
    ax.set_yticks(range(len(row_labels)), row_labels)
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            if not np.isnan(M[i, j]):
                ax.text(j, i, f"{M[i, j]:.2f}", ha="center", va="center",
                        color="white", fontsize=8)
    fig.colorbar(im, ax=ax, label=cbar_label)
    ax.set_xlabel("Refrigerant 1")
    ax.set_ylabel("Refrigerant 2")
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(out_path, dpi=130)
    plt.close(fig)
    return os.path.abspath(out_path)


@mcp.tool()
def plot_tunability(rows: list[dict], x_key: str, y_keys: list[str],
                    out_path: str, title: str = "") -> str:
    """Plot one or more y-series against x_key from a list-of-dicts."""
    import os
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(7, 4.5))
    xs = [r[x_key] for r in rows]
    for k in y_keys:
        ys = [r.get(k, np.nan) for r in rows]
        ax.plot(xs, ys, "o-", label=k)
    ax.set_xlabel(x_key)
    ax.legend()
    ax.set_title(title)
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=130)
    plt.close(fig)
    return os.path.abspath(out_path)


if __name__ == "__main__" and _HAS_MCP:
    mcp.run()

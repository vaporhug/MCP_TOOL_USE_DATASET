"""Generic data-processing utilities for the phys_hp37 task.

Format conversion, reshaping, cleaning, and lightweight transforms that are
*not* specific to the heat-pump domain.  Domain-specific cycle analysis lives
in ``heat_pump_analysis.py``.
"""
from __future__ import annotations

import csv
import json
from typing import Any


def read_csv(path: str, delimiter: str = ",") -> list[dict]:
    """Parse CSV into list-of-dicts using csv.DictReader."""
    with open(path, newline="") as f:
        return list(csv.DictReader(f, delimiter=delimiter))


def write_csv(rows: list[dict], path: str) -> None:
    """Write list-of-dicts to CSV; header taken from the first row's keys."""
    if not rows:
        open(path, "w").close()
        return
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def read_json(path: str) -> Any:
    with open(path) as f:
        return json.load(f)


def write_json(obj: Any, path: str, indent: int = 2) -> None:
    with open(path, "w") as f:
        json.dump(obj, f, indent=indent, default=str)


def coerce_numeric(rows: list[dict], cols: list[str]) -> list[dict]:
    """Cast named columns to float; non-parseable values become None."""
    out: list[dict] = []
    for r in rows:
        rr = dict(r)
        for c in cols:
            v = rr.get(c)
            try:
                rr[c] = float(v) if v not in (None, "") else None
            except (TypeError, ValueError):
                rr[c] = None
        out.append(rr)
    return out


def filter_rows(rows: list[dict], **filters) -> list[dict]:
    """Return rows whose values match all key=value filters."""
    return [r for r in rows
            if all(str(r.get(k)) == str(v) for k, v in filters.items())]


def to_celsius(T_K: float) -> float:
    return float(T_K) - 273.15


def to_kelvin(T_C: float) -> float:
    return float(T_C) + 273.15


def to_kPa(P_Pa: float) -> float:
    return float(P_Pa) / 1000.0


def to_Pa(P_kPa: float) -> float:
    return float(P_kPa) * 1000.0


def percent_change(baseline: float, value: float) -> float:
    """Signed percentage change of value relative to baseline."""
    return (float(value) - float(baseline)) / float(baseline) * 100.0


def linspace(a: float, b: float, n: int) -> list[float]:
    if n <= 1:
        return [float(a)]
    step = (b - a) / (n - 1)
    return [a + i * step for i in range(n)]


def grid(*axes: list[float]) -> list[tuple]:
    """Cartesian product of axes."""
    if not axes:
        return []
    out = [()]
    for ax in axes:
        out = [t + (v,) for t in out for v in ax]
    return out

"""Database retrieval stubs for refrigerant property libraries.

These are thin placeholders for external lookups.  In this task the agent has
direct access to CoolProp via ``heat_pump_analysis.prop`` so the retrieval
tools below are mostly informational; they document where the data comes from
and how to extend the catalog.
"""
from __future__ import annotations

from typing import Any


def list_coolprop_fluids() -> list[str]:
    """Return the list of pure fluids supported by the local CoolProp install.

    Useful when the agent wants to confirm a refrigerant string before calling
    ``mixture_fluid_string``.  Implementation calls
    ``CoolProp.CoolProp.get_global_param_string('FluidsList')``.
    """
    try:
        from CoolProp.CoolProp import get_global_param_string
        return get_global_param_string("FluidsList").split(",")
    except Exception:
        return []


def fluid_metadata(fluid: str) -> dict[str, Any]:
    """Return critical-point and basic property metadata for a CoolProp
    pure fluid (Tcrit, Pcrit, molar mass, normal boiling point).
    """
    try:
        from CoolProp.CoolProp import PropsSI
        return {
            "fluid": fluid,
            "Tcrit_K": float(PropsSI("Tcrit", fluid)),
            "Pcrit_Pa": float(PropsSI("Pcrit", fluid)),
            "Tmin_K": float(PropsSI("Tmin", fluid)),
            "molar_mass_kg_per_mol": float(PropsSI("M", fluid)),
            "normal_boiling_K": float(PropsSI("T", "P", 101325, "Q", 0, fluid)),
        }
    except Exception as exc:
        return {"fluid": fluid, "error": str(exc)}


def gwp_lookup(refrigerant: str) -> float | None:
    """Approximate GWP100 lookup (AR5/AR6 published values).  Returns None
    when the refrigerant is not in the small built-in table; in that case the
    agent should consult the IPCC AR6 tables or the ASHRAE 34 standard.
    """
    table = {
        "R134a": 1430, "R245fa": 1030, "R236ea": 1410, "R245ca": 716,
        "R365mfc": 794, "R1336mzz(Z)": 2, "R1233zd(E)": 1, "R1224yd(Z)": 1,
        "R1234ze(Z)": 1, "R600": 4, "n-Butane": 4, "R32": 675, "R290": 3,
        "R744": 1, "R717": 0,
    }
    return table.get(refrigerant)


def fetch_paper_dataset(doi: str) -> dict:
    """Convenience stub that documents where the operating-condition CSV in
    ``input_data/data/`` came from (paper Table 6, 7 and Methods text)."""
    return {
        "doi": doi,
        "note": ("Operating conditions and refrigerant catalog were "
                 "transcribed from the paper's Methods section and Tables "
                 "6 and 7. CoolProp is used in place of REFPROP 10.0 to "
                 "evaluate thermodynamic properties."),
    }

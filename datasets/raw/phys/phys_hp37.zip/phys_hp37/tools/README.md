# phys_hp37 - Tool Reference

## Dependencies

```
python >= 3.10
CoolProp >= 6.5
numpy
matplotlib
mcp[fastmcp]   # optional - only needed when serving the tools as MCP
```

Install with `pip install CoolProp numpy matplotlib mcp` before running.

CoolProp ships with the HEOS backend that is REFPROP-equivalent for the
refrigerants used in this task (R245fa, R245ca, R236ea, R1233zd(E),
R1224yd(Z), R1234ze(Z), R1336mzz(Z), R365mfc, n-Butane).  It supports
zeotropic mixtures via the `HEOS::A[xA]&B[xB]` syntax built by
`mixture_fluid_string`.

## Domain analysis (`heat_pump_analysis.py`)

FastMCP server exposing the cycle and ejector primitives.

- **prop**: thin CoolProp.PropsSI wrapper for arbitrary thermodynamic lookups.
- **mixture_fluid_string**: build the HEOS mixture identifier.
- **saturation_pressure / saturation_temperature**: bubble/dew lookups.
- **compressor_efficiency**: paper Eq. 44, eta_com = 0.85 - 0.0467 * r_c.
- **compressor_outlet**: outlet enthalpy / temperature / specific work.
- **two_phase_speed_of_sound**: paper Eq. 1, 2 (homogeneous-equilibrium sonic).
- **henry_fauske_critical**: choked two-phase mass flux at the nozzle throat.
- **constant_area_mixing**: full ejector model (Table 1 Eqs. 6-30) returning
  P9, lift ratio, mixing-chamber velocity, throat speed of sound and the per-
  unit-primary-mass flow areas of nozzle / suction / mixing chamber.
- **ejector_diameters**: convert areas to D_nt, D_no, D_m diameters in mm.
- **equivalent_ejector_efficiency**: paper Eq. 47, 49.
- **heating_cop**, **equivalent_cascade_cop**: COP_h and COP_h,e definitions.
- **screen_pure_refrigerants**: full cycle solve for a list of pure fluids -
  returns COP_h, mu, P_eva, P_con, T_dis.
- **vapor_quality_at_separator**: quality at the separator inlet given P, h.
- **mixture_separator_compositions**: Rachford-Rice flash for binary mixtures
  - returns vapour-/liquid-phase composition of the low-boiling component.
- **tunability_scan**: Cartesian sweep over P_inj, dT_subcool, dT_superheat
  used to map the +/- 5 percent load-fluctuation regulation window.
- **adjustability_range**: convert a list of values to {min_pct, max_pct,
  range_pct} relative to a baseline.
- **plot_ph_diagram**, **plot_refrigerant_heatmap**, **plot_tunability**:
  matplotlib renderers for cycle states, refrigerant grids and tunability.

## Generic data processing (`data_processing.py`)

- **read_csv / write_csv / read_json / write_json**
- **coerce_numeric**, **filter_rows**
- **to_celsius / to_kelvin**, **to_kPa / to_Pa**
- **percent_change**, **linspace**, **grid**

## External database retrieval (`database_retrieval.py`)

- **list_coolprop_fluids**: enumerate locally available pure fluids.
- **fluid_metadata**: Tcrit, Pcrit, M, normal boiling point.
- **gwp_lookup**: small built-in GWP100 table (extend via IPCC AR6).
- **fetch_paper_dataset**: documentation stub describing the source of
  ``input_data/data/operating_conditions.csv`` and the refrigerant catalog.

## Validation steps for the agent

1. Reproduce paper Table 6 by calling `screen_pure_refrigerants` over the
   nine candidates with T_eva=323.15 K, T_con=398.15 K, Q_con=100 kW.
2. Reproduce paper Table 7 by repeating the same cycle for the four binary
   mixtures with Z_0 = 0.5, epsilon = 0.5.
3. Map the load-fluctuation window with `tunability_scan` for the two
   recommended mixtures and compare against the +/- 5 percent target.
4. Tabulate D_nt, D_no, D_m adjustability ranges (paper Conclusion 3).

#!/usr/bin/env python3
"""Green-methanol techno-economic primitives for assessing the global
production potential of e-methanol from variable renewable electricity.

Implements low-level building blocks: load CSV potential / cost data,
compute capacity-factor / full-load-hour metrics from PVOUT or wind
speed, evaluate the levelised cost of electricity (LCOE) and the
levelised cost of methanol (LCOM) from per-component capex / opex /
lifetime triplets, rank countries by PV potential, and produce the
diagnostic plots used in the answer.

Each public function is a ``@mcp.tool()``-exposed FastMCP endpoint and
returns plain-JSON dicts.  Domain logic is intentionally kept primitive:
the agent must combine these tools to reproduce the LCOM trends for the
seven sample locations and the global ranking discussed in the paper.
"""

import os
import math
import csv
from typing import Any
import numpy as np
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Green_Methanol_TechnoEconomics")


# --------------------------------------------------------------------------- #
# 1. Data loading                                                              #
# --------------------------------------------------------------------------- #
@mcp.tool()
def load_country_pv_potential(csv_path: str) -> dict:
    """Load the per-country PVOUT / GHI / LCOE table (World Bank
    Solargis ESMAP 2020).

    Returns row count, column list and aggregate stats for the
    ``pvout_kwh_kwp_day`` column."""
    rows = _read_csv(csv_path)
    rows = _coerce(rows, ["pvout_kwh_kwp_day", "ghi_kwh_m2_day",
                          "lcoe_usd_kwh", "pv_seasonality_index",
                          "evaluated_area_km2"])
    pv = [r["pvout_kwh_kwp_day"] for r in rows
          if r.get("pvout_kwh_kwp_day") is not None]
    arr = np.asarray(pv, dtype=float)
    return {
        "n_rows": len(rows),
        "columns": list(rows[0].keys()) if rows else [],
        "pvout_min": round(float(arr.min()), 4) if len(arr) else None,
        "pvout_max": round(float(arr.max()), 4) if len(arr) else None,
        "pvout_median": round(float(np.median(arr)), 4) if len(arr) else None,
        "pvout_mean": round(float(arr.mean()), 4) if len(arr) else None,
    }


@mcp.tool()
def load_sample_locations(csv_path: str) -> dict:
    """Load the 7 sample-location table (Table S5 of the paper):
    CHL-PAT, AUS, US-CA, CHL-ATA, DEU, FIN, OMN with installed
    capacities for a 1 Mt/a methanol supply in 2030."""
    rows = _read_csv(csv_path)
    return {"n_locations": len(rows),
            "columns": list(rows[0].keys()) if rows else [],
            "rows": rows}


@mcp.tool()
def load_cost_assumptions(csv_path: str) -> dict:
    """Load the technology capex / opex / lifetime table (Table S8 of
    the paper) for PV, wind, battery, electrolyser, DAC, MeOH plant."""
    rows = _read_csv(csv_path)
    return {"n_rows": len(rows),
            "components": sorted({r["component"] for r in rows}),
            "years": sorted({int(r["year"]) for r in rows}),
            "rows": rows}


@mcp.tool()
def load_process_constants(csv_path: str) -> dict:
    """Load the process-constants table (WACC, MeOH HHV, CO2 / H2 per
    t MeOH, area limits, exchange rate)."""
    rows = _read_csv(csv_path)
    return {"n_rows": len(rows),
            "constants": {r["parameter"]: float(r["value"]) for r in rows},
            "rows": rows}


# --------------------------------------------------------------------------- #
# 2. Levelised-cost primitives                                                 #
# --------------------------------------------------------------------------- #
@mcp.tool()
def annuity_factor(wacc: float, lifetime_years: int) -> dict:
    """Capital recovery factor (annuity) crf = i*(1+i)^N / ((1+i)^N - 1).

    Used inside LCOE / LCOM calculations (eqn 3a-3c of the paper).
    """
    if lifetime_years <= 0:
        return {"error": "lifetime must be positive"}
    if wacc == 0:
        return {"crf": 1.0 / lifetime_years, "wacc": wacc,
                "lifetime": lifetime_years}
    crf = wacc * (1 + wacc) ** lifetime_years \
          / ((1 + wacc) ** lifetime_years - 1)
    return {"crf": round(float(crf), 6),
            "wacc": wacc, "lifetime": lifetime_years}


@mcp.tool()
def lcoe_simple(capex_eur_per_kw: float, opex_fix_eur_per_kw_yr: float,
                opex_var_eur_per_kwh: float, full_load_hours: float,
                wacc: float, lifetime_years: int) -> dict:
    """Levelised cost of electricity for a single technology.

    LCOE = (capex * crf + opex_fix) / FLh + opex_var   [EUR/kWh].
    """
    af = annuity_factor(wacc, lifetime_years)
    if "error" in af:
        return af
    crf = af["crf"]
    if full_load_hours <= 0:
        return {"error": "FLh must be positive"}
    lcoe = (capex_eur_per_kw * crf + opex_fix_eur_per_kw_yr) \
            / full_load_hours + opex_var_eur_per_kwh
    return {
        "lcoe_eur_per_kwh": round(float(lcoe), 6),
        "lcoe_eur_per_mwh": round(float(lcoe * 1000), 4),
        "annuity_eur_per_kw_yr": round(float(capex_eur_per_kw * crf), 4),
        "crf": crf, "full_load_hours": full_load_hours,
    }


@mcp.tool()
def levelised_cost_methanol(component_costs: list, annual_meoh_t: float) -> dict:
    """Aggregate component annualised costs into LCOM (EUR/t_MeOH).

    Each entry of ``component_costs`` must be a dict with keys
    {component, capex_total, opex_fix_total, opex_var_total,
    crf}. Annual cost = capex_total*crf + opex_fix_total + opex_var_total.
    LCOM = sum(annual cost) / annual_meoh_t.
    """
    if annual_meoh_t <= 0:
        return {"error": "annual MeOH must be positive"}
    breakdown = []
    total = 0.0
    for c in component_costs:
        ann = (float(c.get("capex_total", 0.0)) * float(c.get("crf", 0.0))
               + float(c.get("opex_fix_total", 0.0))
               + float(c.get("opex_var_total", 0.0)))
        total += ann
        breakdown.append({
            "component": c.get("component", ""),
            "annual_cost_eur": round(ann, 2),
            "share_eur_per_t": round(ann / annual_meoh_t, 2),
        })
    return {
        "lcom_eur_per_t": round(total / annual_meoh_t, 2),
        "lcom_eur_per_mwh_hhv": round(total / annual_meoh_t / 6.306, 3),
        "annual_total_eur": round(total, 2),
        "annual_meoh_t": annual_meoh_t,
        "breakdown": breakdown,
    }


@mcp.tool()
def component_annual_cost(capex: float, capacity: float,
                          opex_fix_pct_capex: float = 0.0,
                          opex_fix_eur_per_unit: float = 0.0,
                          wacc: float = 0.07,
                          lifetime_years: int = 25) -> dict:
    """Compute annualised CAPEX + fixed OPEX for one component.

    Returns: capex_total, crf, opex_fix_total ready for
    ``levelised_cost_methanol``.  Use either ``opex_fix_pct_capex``
    (fraction) **or** ``opex_fix_eur_per_unit`` (per unit of capacity).
    """
    capex_total = capex * capacity
    af = annuity_factor(wacc, lifetime_years)
    if "error" in af:
        return af
    if opex_fix_pct_capex > 0:
        opex_fix_total = capex_total * opex_fix_pct_capex
    else:
        opex_fix_total = opex_fix_eur_per_unit * capacity
    return {
        "capex_total": round(capex_total, 2),
        "crf": af["crf"],
        "opex_fix_total": round(opex_fix_total, 2),
        "opex_var_total": 0.0,
        "annual_capex_recovery": round(capex_total * af["crf"], 2),
    }


# --------------------------------------------------------------------------- #
# 3. Resource / capacity-factor primitives                                     #
# --------------------------------------------------------------------------- #
@mcp.tool()
def pvout_to_capacity_factor(pvout_kwh_kwp_day: float) -> dict:
    """Convert PVOUT (kWh / kWp / day, Solargis convention) into PV
    capacity factor (fraction of nameplate) and annual full-load hours.
    CF = PVOUT / 24 ;  FLh = PVOUT * 365.
    """
    if pvout_kwh_kwp_day <= 0:
        return {"error": "PVOUT must be positive"}
    cf = pvout_kwh_kwp_day / 24.0
    flh = pvout_kwh_kwp_day * 365.0
    return {
        "pvout_kwh_kwp_day": pvout_kwh_kwp_day,
        "capacity_factor": round(float(cf), 4),
        "full_load_hours_per_year": round(float(flh), 1),
    }


@mcp.tool()
def rank_countries_by_pv(csv_path: str, top_n: int = 20,
                         min_evaluated_area_km2: float = 5000.0) -> dict:
    """Rank countries by PVOUT (kWh/kWp/day), optionally filtering tiny
    territories.  Returns the top ``top_n`` countries.
    """
    rows = _read_csv(csv_path)
    rows = _coerce(rows, ["pvout_kwh_kwp_day", "evaluated_area_km2",
                          "ghi_kwh_m2_day", "lcoe_usd_kwh"])
    rows = [r for r in rows
            if r.get("pvout_kwh_kwp_day") is not None
            and r.get("evaluated_area_km2") is not None
            and r["evaluated_area_km2"] >= min_evaluated_area_km2]
    rows.sort(key=lambda r: -r["pvout_kwh_kwp_day"])
    out = []
    for r in rows[:top_n]:
        out.append({
            "iso_a3": r.get("iso_a3"),
            "country": r.get("country"),
            "pvout_kwh_kwp_day": round(r["pvout_kwh_kwp_day"], 4),
            "ghi_kwh_m2_day": round(r["ghi_kwh_m2_day"], 4),
            "lcoe_usd_kwh": round(r["lcoe_usd_kwh"], 4),
            "evaluated_area_km2": round(r["evaluated_area_km2"], 0),
            "wb_region": r.get("wb_region"),
        })
    return {"top_n": top_n, "rows": out}


@mcp.tool()
def regional_potential_summary(csv_path: str) -> dict:
    """Aggregate country PVOUT / GHI / LCOE statistics by World Bank
    region (AFR, ECA, MENA, EAP, LCR, NAR, SOA, Other).
    """
    rows = _read_csv(csv_path)
    rows = _coerce(rows, ["pvout_kwh_kwp_day", "ghi_kwh_m2_day",
                          "lcoe_usd_kwh", "evaluated_area_km2"])
    groups: dict = {}
    for r in rows:
        if r.get("pvout_kwh_kwp_day") is None:
            continue
        groups.setdefault(r.get("wb_region") or "Unknown", []).append(r)
    out = []
    for region, grp in groups.items():
        pv = np.asarray([g["pvout_kwh_kwp_day"] for g in grp])
        lcoe = np.asarray([g["lcoe_usd_kwh"] for g in grp
                           if g.get("lcoe_usd_kwh") is not None])
        out.append({
            "region": region, "n_countries": len(grp),
            "pvout_mean": round(float(pv.mean()), 4),
            "pvout_max": round(float(pv.max()), 4),
            "lcoe_min_usd_kwh": round(float(lcoe.min()), 4) if len(lcoe) else None,
            "lcoe_mean_usd_kwh": round(float(lcoe.mean()), 4) if len(lcoe) else None,
            "evaluated_area_km2": round(float(sum(g["evaluated_area_km2"]
                                                   for g in grp
                                                   if g.get("evaluated_area_km2"))), 0),
        })
    out.sort(key=lambda x: -x["pvout_mean"])
    return {"n_regions": len(out), "rows": out}


# --------------------------------------------------------------------------- #
# 4. Light-weight statistics                                                   #
# --------------------------------------------------------------------------- #
@mcp.tool()
def descriptive_stats(values: list) -> dict:
    """min / median / mean / p25 / p75 / max / std for a numeric list."""
    arr = np.asarray(values, dtype=float)
    arr = arr[~np.isnan(arr)]
    if len(arr) == 0:
        return {"error": "no valid values"}
    return {
        "n": int(len(arr)),
        "mean": round(float(arr.mean()), 4),
        "median": round(float(np.median(arr)), 4),
        "std": round(float(arr.std(ddof=1)), 4) if len(arr) > 1 else 0.0,
        "min": round(float(arr.min()), 4),
        "max": round(float(arr.max()), 4),
        "p25": round(float(np.percentile(arr, 25)), 4),
        "p75": round(float(np.percentile(arr, 75)), 4),
    }


@mcp.tool()
def linear_regression(x_values: list, y_values: list) -> dict:
    """OLS y = a*x + b plus Pearson r and 95% CI for slope."""
    from scipy.stats import linregress
    x = np.asarray(x_values, dtype=float)
    y = np.asarray(y_values, dtype=float)
    m = ~(np.isnan(x) | np.isnan(y))
    x, y = x[m], y[m]
    res = linregress(x, y)
    return {
        "n": int(len(x)),
        "slope": round(float(res.slope), 6),
        "intercept": round(float(res.intercept), 6),
        "r": round(float(res.rvalue), 4),
        "r_squared": round(float(res.rvalue ** 2), 4),
        "p_value": round(float(res.pvalue), 6),
        "std_err": round(float(res.stderr), 6),
    }


# --------------------------------------------------------------------------- #
# 5. Plotting (one tool per image)                                             #
# --------------------------------------------------------------------------- #
@mcp.tool()
def plot_lcom_trajectory(years: list, lcom_low_eur_t: list,
                         lcom_high_eur_t: list,
                         out_path: str,
                         title: str = "Global green e-methanol cost trajectory"
                         ) -> dict:
    """Plot the LCOM range at the world's best sites versus year and
    overlay the conventional NG-MeOH market-price band (200-400 EUR/t).
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    yrs = np.asarray(years, dtype=float)
    lo = np.asarray(lcom_low_eur_t, dtype=float)
    hi = np.asarray(lcom_high_eur_t, dtype=float)
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    fig, ax = plt.subplots(figsize=(7.6, 4.6))
    ax.fill_between(yrs, lo, hi, color="seagreen", alpha=0.4,
                    label="e-MeOH best sites range")
    ax.plot(yrs, lo, "o-", color="darkgreen", lw=1.5, label="e-MeOH lower")
    ax.plot(yrs, hi, "s-", color="darkgreen", lw=1.5, label="e-MeOH upper")
    ax.axhspan(200, 400, color="goldenrod", alpha=0.2,
               label="NG-MeOH market 2007-2017 (200-400 EUR/t)")
    ax.set_xlabel("Year")
    ax.set_ylabel("Levelised cost of methanol (EUR / t$_{MeOH}$)")
    ax.set_title(title)
    ax.grid(alpha=0.3); ax.legend(loc="upper right", fontsize=8)
    fig.tight_layout(); fig.savefig(out_path, dpi=150); plt.close(fig)
    return {"path": out_path, "n_years": int(len(yrs)),
            "lcom_2050_low": float(lo[-1]),
            "lcom_2050_high": float(hi[-1])}


@mcp.tool()
def plot_lcom_by_site(site_codes: list, lcom_2030: list,
                      lcom_2050: list, out_path: str,
                      title: str = "LCOM at 7 sample locations") -> dict:
    """Grouped-bar comparison of 2030 vs 2050 LCOM at the seven sample
    sites (CHL-PAT, AUS, US-CA, CHL-ATA, DEU, FIN, OMN)."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    x = np.arange(len(site_codes))
    w = 0.38
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    fig, ax = plt.subplots(figsize=(8.5, 4.6))
    ax.bar(x - w / 2, lcom_2030, width=w, color="steelblue", label="2030")
    ax.bar(x + w / 2, lcom_2050, width=w, color="darkorange", label="2050")
    ax.set_xticks(x); ax.set_xticklabels(site_codes, rotation=15)
    ax.set_ylabel("LCOM (EUR / t$_{MeOH}$)"); ax.set_title(title)
    ax.grid(alpha=0.3, axis="y"); ax.legend()
    for xi, v in zip(x - w / 2, lcom_2030):
        ax.text(xi, v + 5, f"{v:.0f}", ha="center", fontsize=8)
    for xi, v in zip(x + w / 2, lcom_2050):
        ax.text(xi, v + 5, f"{v:.0f}", ha="center", fontsize=8)
    fig.tight_layout(); fig.savefig(out_path, dpi=150); plt.close(fig)
    return {"path": out_path, "n_sites": int(len(site_codes))}


@mcp.tool()
def plot_country_pv_ranking(csv_path: str, out_path: str,
                            top_n: int = 20,
                            min_evaluated_area_km2: float = 5000.0,
                            title: str = "Top countries by PV potential"
                            ) -> dict:
    """Horizontal bar-chart of the top-``N`` countries by long-term
    PVOUT (Global Solar Atlas / World Bank ESMAP 2020), filtered to
    countries with at least ``min_evaluated_area_km2`` of evaluated area.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    rk = rank_countries_by_pv(csv_path, top_n=top_n,
                              min_evaluated_area_km2=min_evaluated_area_km2)
    rows = rk["rows"][::-1]  # ascending for horizontal bar
    countries = [r["country"] for r in rows]
    pv = [r["pvout_kwh_kwp_day"] for r in rows]
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    fig, ax = plt.subplots(figsize=(7.6, max(4.5, 0.25 * len(rows))))
    bars = ax.barh(countries, pv, color="goldenrod", edgecolor="k")
    ax.set_xlabel("Practical PV potential (kWh / kWp / day)")
    ax.set_title(title)
    for bar, v in zip(bars, pv):
        ax.text(v + 0.02, bar.get_y() + bar.get_height() / 2,
                f"{v:.2f}", va="center", fontsize=8)
    ax.grid(alpha=0.3, axis="x")
    fig.tight_layout(); fig.savefig(out_path, dpi=150); plt.close(fig)
    return {"path": out_path, "n_countries": len(rows),
            "top_country": rk["rows"][0]["country"] if rk["rows"] else None}


@mcp.tool()
def plot_capex_decline(years: list, capex_pv: list, capex_wind: list,
                       capex_electrolyser: list, capex_dac: list,
                       out_path: str,
                       title: str = "Component capex decline 2020-2050"
                       ) -> dict:
    """Plot projected capex decline of PV (EUR/kWp), wind (EUR/kWp),
    electrolyser (EUR/kW_el) and DAC (EUR/(t_CO2/yr)) on dual axes,
    illustrating the cost-decline assumptions behind the LCOM trajectory.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    yrs = np.asarray(years, dtype=float)
    fig, ax1 = plt.subplots(figsize=(7.8, 4.6))
    ax1.plot(yrs, capex_pv, "o-", color="goldenrod",
             label="PV fixed-tilt (EUR/kWp)")
    ax1.plot(yrs, capex_wind, "s-", color="steelblue",
             label="Wind onshore (EUR/kWp)")
    ax1.plot(yrs, capex_electrolyser, "^-", color="seagreen",
             label="Alkaline electrolyser (EUR/kW$_{el}$)")
    ax1.set_xlabel("Year")
    ax1.set_ylabel("Capex (EUR / kW or kWp)")
    ax1.grid(alpha=0.3); ax1.legend(loc="upper right", fontsize=8)
    ax2 = ax1.twinx()
    ax2.plot(yrs, capex_dac, "d-", color="darkred",
             label="DAC (EUR/(t$_{CO_2}$/yr))")
    ax2.set_ylabel("DAC capex (EUR / (t$_{CO_2}$/yr))",
                   color="darkred")
    ax2.tick_params(axis="y", colors="darkred")
    ax2.legend(loc="lower right", fontsize=8)
    ax1.set_title(title)
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    fig.tight_layout(); fig.savefig(out_path, dpi=150); plt.close(fig)
    return {"path": out_path, "n_years": int(len(yrs))}


# --------------------------------------------------------------------------- #
# Internal helpers                                                             #
# --------------------------------------------------------------------------- #
def _read_csv(path: str) -> list[dict]:
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def _coerce(rows: list[dict], cols: list[str]) -> list[dict]:
    out = []
    for r in rows:
        r2 = dict(r)
        for c in cols:
            try:
                r2[c] = float(r2[c])
            except (TypeError, ValueError):
                r2[c] = None
        out.append(r2)
    return out


if __name__ == "__main__":
    mcp.run(transport="stdio")

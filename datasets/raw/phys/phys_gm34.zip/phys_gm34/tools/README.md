# phys_gm34 - Tools

## Modules
- `methanol_analysis.py` - FastMCP-decorated domain primitives for green
  e-methanol techno-economic analysis: `load_country_pv_potential`,
  `load_sample_locations`, `load_cost_assumptions`,
  `load_process_constants`, `annuity_factor`, `lcoe_simple`,
  `levelised_cost_methanol`, `component_annual_cost`,
  `pvout_to_capacity_factor`, `rank_countries_by_pv`,
  `regional_potential_summary`, `descriptive_stats`,
  `linear_regression`, plus four plotters
  (`plot_lcom_trajectory`, `plot_lcom_by_site`,
  `plot_country_pv_ranking`, `plot_capex_decline`).
- `data_processing.py` - generic CSV / JSON / XLSX helpers
  (`read_csv`, `read_xlsx_sheet`, `drop_missing`, `coerce_numeric`,
  `join_tables`, `groupby_aggregate`, `sort_rows`).
- `database_retrieval.py` - thin wrappers around World Bank Data
  Catalog / ESMAP and Global Solar Atlas + Global Wind Atlas
  (`fetch_url`, `fetch_wb_pv_country_xlsx`).

## Run as MCP server
```bash
python methanol_analysis.py
```
Listens on stdio per FastMCP convention.

## Python dependencies
```
numpy
pandas
scipy
matplotlib
openpyxl
mcp[server]   # provides mcp.server.fastmcp
```
Install with:
```bash
pip install numpy pandas scipy matplotlib openpyxl "mcp[server]"
```

## Notes
- `wb_pv_country_potential.csv` is sourced from the World Bank /
  ESMAP / Solargis "Global Photovoltaic Power Potential by Country"
  (CC BY 4.0, 2020).  Columns: `iso_a3, country, wb_region,
  population_2018, area_km2, evaluated_area_km2, level1_area_frac,
  hdi_2017, gdp_per_cap_usd_2018, ghi_kwh_m2_day, pvout_kwh_kwp_day,
  lcoe_usd_kwh, pv_seasonality_index`.
- `cost_assumptions.csv` and `sample_locations.csv` reproduce
  Table S5 / S6 / S8 of Fasihi & Breyer 2024 (Energy Environ. Sci.,
  CC BY 3.0).  All capex / opex / lifetime values are taken verbatim
  from the ESI.
- `lcom_results.csv` lists the LCOM (EUR/t_MeOH) extracted from
  Fig. 6 of the paper for the 7 sample sites (CHL-PAT, AUS, US-CA,
  CHL-ATA, DEU, FIN, OMN) in 2030 and 2050.
- `process_constants.csv` collects WACC, methanol HHV / LHV, CO2
  and H2 stoichiometry, area limits and the EUR/USD exchange rate.

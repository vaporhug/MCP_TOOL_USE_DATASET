"""Database retrieval helpers — quarantined for the LOCAL-ONLY phys_gm34 task.

The original Power-to-MeOH techno-economic dataset was assembled from public
endpoints (World Bank ESMAP / Solargis, IRENA, Global Solar Atlas, Global Wind
Atlas, Crossref). The CSVs already in ``input_data/data/`` cover everything
the task needs; no live network access is required at runtime.

This module deliberately ships stub signatures that record provenance only.
Each function raises ``NotImplementedError`` to enforce the local-only scope
of this benchmark task.
"""
from typing import Any


WB_DATACATALOG = "https://datacatalogfiles.worldbank.org/ddh-published"


def _disabled(label: str) -> None:
    raise NotImplementedError(
        f"Network helper '{label}' is intentionally disabled for the "
        f"local-only phys_gm34 benchmark. All required CSVs are in "
        f"input_data/data/."
    )


def fetch_url(url: str, timeout: int = 60, save_to: str = "") -> dict:
    """[DISABLED for local-only task.] HTTP GET; raises NotImplementedError.

    Original purpose: download CSV/XLSX/PDF from the World Bank Data
    Catalog, Global Solar Atlas, Global Wind Atlas, etc. — used at
    dataset-build time only; not required at task-solve time.
    """
    _disabled("fetch_url")


def fetch_wb_pv_country_xlsx(save_to: str = "") -> dict:
    """[DISABLED for local-only task.] Returns the WB ESMAP / Solargis
    country-level PV potential spreadsheet URL for traceability only.

    Original endpoint:
      {WB_DATACATALOG}/0038379/1/DR0046831/solargis_pvpotential_countryranking_2020_data.xlsx
    The corresponding CSV is bundled at
    input_data/data/wb_pv_country_potential.csv.
    """
    _disabled("fetch_wb_pv_country_xlsx")


def fetch_irena_renewable_capacity_csv(indicator: str = "Solar",
                                       save_to: str = "") -> dict:
    """[DISABLED for local-only task.] IRENA renewable-capacity statistics
    were used at dataset-build time only.
    """
    _disabled("fetch_irena_renewable_capacity_csv")


def query_globalsolaratlas(country_iso3: str, layer: str = "PVOUT") -> dict:
    """[DISABLED for local-only task.] Country PVOUT/GHI summaries are
    already aggregated in wb_pv_country_potential.csv.
    """
    _disabled("query_globalsolaratlas")


def query_global_wind_atlas(country_iso3: str,
                            iec_class: int = 2) -> dict:
    """[DISABLED for local-only task.] Wind-resource statistics were used
    at dataset-build time only; downstream values are already embedded in
    sample_locations.csv full-load hours.
    """
    _disabled("query_global_wind_atlas")


def query_doi(doi: str) -> dict:
    """[DISABLED for local-only task.] DOI resolution is not needed; the
    target paper is bundled at input_data/reference_paper/target.pdf.
    """
    _disabled("query_doi")


def websearch(query: str, max_results: int = 10) -> list[dict]:
    """[DISABLED for local-only task.] No external search is required.
    """
    _disabled("websearch")

"""Generic data-processing utilities for renewable-energy / techno-economic
analysis.

Format conversion, reshaping, cleaning and lightweight transforms that are
*not* specific to the green-methanol economic analysis.  Domain-specific
routines (LCOE / LCOM, annuity, capacity-factor maths, sensitivity) live
in ``methanol_analysis.py``.
"""
from typing import Any
import csv
import json


def read_csv(path: str, delimiter: str = ",") -> list[dict]:
    """Parse CSV into list-of-dicts using csv.DictReader."""
    with open(path, newline="") as f:
        return list(csv.DictReader(f, delimiter=delimiter))


def write_csv(rows: list[dict], path: str) -> None:
    """Write list-of-dicts to CSV, using the first row's keys as header."""
    if not rows:
        open(path, "w").close(); return
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)


def read_json(path: str) -> Any:
    with open(path) as f:
        return json.load(f)


def write_json(obj: Any, path: str, indent: int = 2) -> None:
    with open(path, "w") as f:
        json.dump(obj, f, indent=indent, default=str)


def read_xlsx_sheet(path: str, sheet_name: str = "") -> list[dict]:
    """Read an XLSX sheet into list-of-dicts (first row = header).
    Requires openpyxl.
    """
    import openpyxl
    wb = openpyxl.load_workbook(path, data_only=True)
    ws = wb[sheet_name] if sheet_name else wb.active
    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        return []
    header = [str(c) if c is not None else "" for c in rows[0]]
    return [dict(zip(header, r)) for r in rows[1:]]


def drop_missing(rows: list[dict], cols: list[str] | None = None) -> list[dict]:
    """Remove rows where any (or listed) columns are None / empty / NaN."""
    def bad(v):
        return v is None or v == "" or v != v
    if cols is None:
        return [r for r in rows if not any(bad(v) for v in r.values())]
    return [r for r in rows if not any(bad(r.get(c)) for c in cols)]


def coerce_numeric(rows: list[dict], cols: list[str]) -> list[dict]:
    """Cast named columns to float; non-parseable -> None."""
    out = []
    for r in rows:
        r2 = dict(r)
        for c in cols:
            try:
                r2[c] = float(r2[c])
            except (TypeError, ValueError):
                r2[c] = None
        out.append(r2)
    return out


def join_tables(left: list[dict], right: list[dict], on: str,
               how: str = "inner") -> list[dict]:
    """SQL-style join on a single key."""
    idx = {r[on]: r for r in right}
    out = []
    for l in left:
        r = idx.get(l.get(on))
        if r is not None:
            out.append({**l, **{k: v for k, v in r.items() if k != on}})
        elif how == "left":
            out.append(dict(l))
    return out


def groupby_aggregate(rows: list[dict], by: str,
                     agg: dict[str, str]) -> list[dict]:
    """Group rows by ``by`` column and apply per-column aggregations
    (mean | sum | min | max | count)."""
    from statistics import mean
    groups: dict = {}
    for r in rows:
        groups.setdefault(r[by], []).append(r)
    out = []
    for key, grp in groups.items():
        row = {by: key}
        for col, fn in agg.items():
            vals = [g[col] for g in grp if g.get(col) is not None]
            if fn == "mean":
                row[col] = mean(vals) if vals else None
            elif fn == "sum":
                row[col] = sum(vals)
            elif fn == "min":
                row[col] = min(vals) if vals else None
            elif fn == "max":
                row[col] = max(vals) if vals else None
            elif fn == "count":
                row[col] = len(vals)
        out.append(row)
    return out


def sort_rows(rows: list[dict], key: str, desc: bool = False) -> list[dict]:
    """Sort list-of-dicts by a key (None values pushed to the end)."""
    keyed = [(r.get(key), r) for r in rows]
    keyed.sort(key=lambda x: (x[0] is None, x[0]), reverse=desc)
    return [r for _, r in keyed]

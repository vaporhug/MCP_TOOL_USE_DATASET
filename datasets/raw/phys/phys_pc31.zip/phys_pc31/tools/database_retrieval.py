"""Stub helpers describing the external databases referenced by this task,
for provenance documentation only. This task is SELF-CONTAINED: all the data
needed for the analysis is already bundled under ``input_data/data/`` (the
GHCN block-maxima CSV, station summary, HadCRUT5 anomaly series, and the
per-region fig2/fig5 text files). These descriptors are informational; do
NOT attempt to fetch additional records over the network."""


def describe_ghcn_daily() -> dict:
    """Return a description of the GHCN-Daily archive used in this task.

    GHCN-Daily is the NOAA Global Historical Climatology Network daily
    archive. Each station has a fixed-format .dly file with one line per
    (year, month, element). The PRCP element is total daily precipitation
    in tenths of a millimetre with a -9999 missing-value flag.
    """
    return {
        "name": "GHCN-Daily",
        "host": "https://www.ncei.noaa.gov/pub/data/ghcn/daily/",
        "station_inventory": "ghcnd-stations.txt and ghcnd-inventory.txt",
        "per_station_file": "all/<station_id>.dly",
        "prcp_units": "tenths of mm (divide by 10 for mm/day)",
        "missing_value": -9999,
    }


def describe_hadcrut5() -> dict:
    """Return a description of the HadCRUT5 global mean temperature dataset
    used as the climate covariate in the GEV regression."""
    return {
        "name": "HadCRUT.5.0.2.0 analysis",
        "host": "https://www.metoffice.gov.uk/hadobs/hadcrut5/",
        "frequency": "annual global mean surface temperature anomaly",
        "reference_period": "1850-1900",
        "units": "deg C",
    }


def describe_zenodo_record() -> dict:
    """Return a description of the Zenodo data record that contains the
    figure-level numbers from the source paper (per-grid-cell sensitivities,
    block-maxima ratios, etc.)."""
    return {
        "name": "Bird et al. 2023 figure data",
        "doi": "10.5281/zenodo.10038809",
        "host": "https://zenodo.org/record/10038809",
        "license": "CC-BY-4.0",
    }

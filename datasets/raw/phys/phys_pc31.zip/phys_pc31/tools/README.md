# phys_pc31 — Tool Reference

## Data Processing (`data_processing.py`)

Generic CSV / JSON utilities used to load the per-station and per-grid data
files into Python.

- **read_csv** / **write_csv** — list-of-dicts CSV reader/writer
- **read_json** / **write_json** — JSON helpers
- **drop_missing** — drop rows containing missing values
- **coerce_numeric** — cast named columns to float
- **join_tables** — single-key SQL-style join
- **groupby_aggregate** — `mean | sum | min | max | count` aggregations

## Database Retrieval (`database_retrieval.py`)

- **describe_ghcn_daily** — metadata for the GHCN-Daily archive
- **describe_hadcrut5** — metadata for the HadCRUT5 temperature dataset
- **describe_zenodo_record** — metadata for the figure-data Zenodo record

## Domain Tools (`precipitation_extremes.py`)

FastMCP server exposing primitives for analysing extreme precipitation block
maxima.

Loading and lookup
- **load_csv** — peek at any CSV file used in this task
- **load_paper_zenodo_text** — load one of the Zenodo Figure-5/6/2 text files
- **temperature_anomaly_for_year** — HadCRUT5 anomaly (deg C) for a given year

Block-maxima / GEV
- **fit_gev_station** — stationary GEV fit (mu, sigma, xi) by negative-log-
  likelihood minimisation for a single station
- **gev_return_level** — precipitation depth at a chosen return period (years)
  given fitted GEV parameters
- **fit_nonstationary_gev** — joint GEV fit with a linear T'_Global covariate
  on the location parameter; reports the % change per K at the 100-year return
  level
- **stationary_gev_sweep** — batch wrapper around stationary GEV fitting and
  return-level calculation for every station, with regional return-level
  summaries computed from the supplied block-maxima table
- **per_station_features** — build a per-station feature table (lat / lon /
  elevation / Rx1day moments / OLS trend slope) ready for ML; optional
  `output_csv` writes the same rows to disk

Classifiers
- **non_geographic_region_classifier** - no-lat/lon random-forest baseline using elevation and Rx1day/trend features; returns held-out accuracy, macro-F1, confusion matrix, and feature list computed from the supplied station-feature table.
- **train_classifier_cv** — stratified 5-fold cross-validation for any of
  `logistic | random_forest | gradient_boost | mlp`; returns accuracy and
  macro-F1 with scaling fit inside each training fold
- **binary_sensitivity_classifier** — binary classifier (positive vs
  non-positive sensitivity) on the gridded Figure-5/6 data; returns
  accuracy / F1 / ROC-AUC with scaling fit inside each training fold

Regional summaries
- **regional_sensitivity_summary** — per-region IQR, median, fraction
  positive, fraction above CCR (7%/K) of CNN-derived sensitivities
- **regional_aep_ratio_summary** — per-region mean and std of the
  (1% AEP) / (mean Rx1day) ratio as a multiplier, not a percentage

Plotting (one tool per artifact image)
- **plot_block_maxima_distribution** — histogram of mean Rx1day per region
- **plot_classifier_confusion** — 5-fold CV confusion matrix
- **plot_regional_sensitivity_boxplot** — boxplot of CNN sensitivities by
  region with the 7%/K CCR reference line
- **plot_aep_ratio_bars** — bar plot of (1% AEP / mean Rx1day) ratio per
  region

## Dependencies

```
numpy>=1.23
pandas>=1.5
scipy>=1.10
scikit-learn>=1.3
matplotlib>=3.6
mcp>=0.1
```

Install with:

```bash
pip install numpy pandas scipy scikit-learn matplotlib mcp
```

Heavy optional dependencies (only needed if the agent decides to fit an
explicit CNN baseline) are PyTorch / fastai / xarray; they are not required
for any of the tools above.

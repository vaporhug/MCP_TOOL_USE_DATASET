#!/usr/bin/env python3
"""Domain primitives for analysing extreme precipitation block maxima.

The toolkit covers:
    - Loading CSV/text climate data
    - Annual block-maximum (Rx1day) handling and per-station feature extraction
    - GEV (Generalised Extreme Value) maximum-likelihood fit, both stationary
      and with a global mean temperature covariate
    - Per-station GEV-based sensitivity (% change per deg C) at a chosen ARI
    - ML classifier training and evaluation (accuracy / F1 / ROC-AUC)
    - Plotting helpers (one figure per artifact image)

All functions are exposed via the FastMCP transport so they can be invoked as
MCP tool calls. The functions are also importable as plain Python.
"""
from __future__ import annotations

import csv
import json
import math
import os
from typing import Optional

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from mcp.server.fastmcp import FastMCP
from scipy import optimize, stats
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, classification_report, f1_score,
                             roc_auc_score)
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler

mcp = FastMCP("phys_pc31_extremes")


# ----------------------- Data loading -----------------------


@mcp.tool()
def load_csv(csv_path: str, max_rows: int = 30) -> dict:
    """Load a CSV file and return columns plus a sample of rows.

    Args:
        csv_path: path to the CSV file
        max_rows: how many rows to include in the preview

    Returns:
        dict with columns, total_rows, and a list of preview row dicts
    """
    df = pd.read_csv(csv_path)
    return {
        "columns": list(df.columns),
        "total_rows": int(len(df)),
        "rows": df.head(max_rows).to_dict("records"),
    }


@mcp.tool()
def load_paper_zenodo_text(txt_path: str, max_rows: int = 20) -> dict:
    """Load one of the Zenodo figure text files (CSV-like with header)."""
    df = pd.read_csv(txt_path)
    return {
        "columns": list(df.columns),
        "total_rows": int(len(df)),
        "rows": df.head(max_rows).to_dict("records"),
    }


@mcp.tool()
def temperature_anomaly_for_year(year: int,
                                 hadcrut_csv: str) -> float:
    """Look up the HadCRUT5 global mean temperature anomaly (deg C) for a year.

    Args:
        year: calendar year
        hadcrut_csv: path to hadcrut5_global_annual.csv

    Returns:
        anomaly value in deg C (returns NaN if year is missing)
    """
    df = pd.read_csv(hadcrut_csv)
    df.columns = [c.strip() for c in df.columns]
    time_col = [c for c in df.columns if c.lower().startswith("time")][0]
    anom_col = [c for c in df.columns if "anomaly" in c.lower()][0]
    row = df[df[time_col] == year]
    if row.empty:
        return float("nan")
    return float(row[anom_col].values[0])


# ----------------------- Block-maxima / GEV -----------------------


def _gev_negloglik(params: np.ndarray, x: np.ndarray) -> float:
    mu, log_sigma, xi = params
    sigma = math.exp(log_sigma)
    z = (x - mu) / sigma
    if abs(xi) < 1e-8:
        return float(np.sum(z + np.exp(-z)) + len(x) * math.log(sigma))
    arg = 1 + xi * z
    if np.any(arg <= 0):
        return 1e12
    log_arg = np.log(arg)
    out = (1 + 1 / xi) * log_arg + arg ** (-1 / xi)
    return float(np.sum(out) + len(x) * math.log(sigma))


def _gev_fit(x: np.ndarray) -> tuple[float, float, float]:
    """Stationary GEV fit by minimising the negative log-likelihood."""
    mu0 = float(np.mean(x))
    sig0 = float(np.std(x))
    if sig0 < 1e-6:
        sig0 = 1.0
    init = np.array([mu0, math.log(sig0), 0.1])
    res = optimize.minimize(_gev_negloglik, init, args=(x,),
                            method="Nelder-Mead",
                            options={"maxiter": 4000, "xatol": 1e-6,
                                     "fatol": 1e-6})
    mu, log_sigma, xi = res.x
    return float(mu), float(math.exp(log_sigma)), float(xi)


def _gev_quantile(p: float, mu: float, sigma: float, xi: float) -> float:
    """Return the precipitation depth corresponding to a non-exceedance
    probability p (0 < p < 1)."""
    if abs(xi) < 1e-8:
        return mu - sigma * math.log(-math.log(p))
    return mu + sigma * (((-math.log(p)) ** (-xi)) - 1) / xi


@mcp.tool()
def fit_gev_station(rx1day_values: list[float]) -> dict:
    """Fit a stationary GEV distribution to a station's Rx1day series.

    Args:
        rx1day_values: list of annual Rx1day (mm) values (one per year)

    Returns:
        dict with mu, sigma, xi, n, mean and standard deviation of the input
    """
    x = np.array([v for v in rx1day_values if v is not None and not np.isnan(v)],
                 dtype=float)
    if len(x) < 8:
        return {"error": f"need >=8 block maxima, got {len(x)}"}
    mu, sigma, xi = _gev_fit(x)
    return {
        "mu": round(mu, 4),
        "sigma": round(sigma, 4),
        "xi": round(xi, 4),
        "n": int(len(x)),
        "mean_rx1day": round(float(np.mean(x)), 3),
        "std_rx1day": round(float(np.std(x)), 3),
    }


@mcp.tool()
def gev_return_level(mu: float, sigma: float, xi: float,
                     return_period_years: float) -> dict:
    """Return the precipitation depth for a given return period (years).

    A return period of T corresponds to an annual exceedance probability
    1/T (i.e. non-exceedance probability 1 - 1/T).
    """
    p = 1.0 - 1.0 / return_period_years
    depth = _gev_quantile(p, mu, sigma, xi)
    return {
        "return_period_years": return_period_years,
        "annual_exceedance_probability": 1.0 / return_period_years,
        "precipitation_depth_mm": round(depth, 3),
    }


@mcp.tool()
def fit_nonstationary_gev(block_maxima_csv: str,
                          hadcrut_csv: str,
                          station: str) -> dict:
    """Fit a GEV with a linear T'_Global covariate on the location parameter
    for a single station, returning the per-deg-C scaling of the location and
    the resulting %/K sensitivity at the 100-year return level.

    Model:  mu(T) = mu0 + mu1 * T,  sigma constant, xi constant.
    """
    bm = pd.read_csv(block_maxima_csv)
    hc = pd.read_csv(hadcrut_csv)
    hc.columns = [c.strip() for c in hc.columns]
    time_col = [c for c in hc.columns if c.lower().startswith("time")][0]
    anom_col = [c for c in hc.columns if "anomaly" in c.lower()][0]
    hc = hc.rename(columns={time_col: "year", anom_col: "temp"})
    df = bm[bm["station"] == station].merge(hc[["year", "temp"]], on="year")
    if len(df) < 15:
        return {"error": f"too few overlapping years ({len(df)}) for {station}"}
    x = df["rx1day_mm"].values.astype(float)
    t = df["temp"].values.astype(float)
    # Initial guesses from stationary fit
    mu0, sig0, xi0 = _gev_fit(x)

    def negll(params):
        a, b, log_s, xi = params
        sig = math.exp(log_s)
        mu = a + b * t
        z = (x - mu) / sig
        if abs(xi) < 1e-8:
            return float(np.sum(z + np.exp(-z)) + len(x) * math.log(sig))
        arg = 1 + xi * z
        if np.any(arg <= 0):
            return 1e12
        return float(np.sum((1 + 1 / xi) * np.log(arg) + arg ** (-1 / xi))
                     + len(x) * math.log(sig))

    init = np.array([mu0, 0.0, math.log(max(sig0, 1.0)), xi0])
    res = optimize.minimize(negll, init, method="Nelder-Mead",
                            options={"maxiter": 8000})
    a, b, log_s, xi = res.x
    sigma = math.exp(log_s)
    # Reference T = mean of covariate range
    t_ref = float(np.mean(t))
    mu_ref = a + b * t_ref
    p100 = 1.0 - 1.0 / 100.0
    depth_ref = _gev_quantile(p100, mu_ref, sigma, xi)
    # Sensitivity at 100yr ARI: change in 100-yr depth per deg C, expressed as %
    mu_warm = a + b * (t_ref + 1.0)
    depth_warm = _gev_quantile(p100, mu_warm, sigma, xi)
    if depth_ref <= 0:
        sensitivity_pct_per_K = float("nan")
    else:
        sensitivity_pct_per_K = 100.0 * (depth_warm - depth_ref) / depth_ref
    return {
        "station": station,
        "n_years": int(len(df)),
        "mu0": round(float(a), 4),
        "mu1_per_K": round(float(b), 4),
        "sigma": round(float(sigma), 4),
        "xi": round(float(xi), 4),
        "t_ref_C": round(t_ref, 4),
        "depth_100yr_at_t_ref_mm": round(float(depth_ref), 3),
        "depth_100yr_at_t_ref_plus_1K_mm": round(float(depth_warm), 3),
        "sensitivity_pct_per_K": round(float(sensitivity_pct_per_K), 4),
        "convergence": bool(res.success),
    }


@mcp.tool()
def per_station_features(block_maxima_csv: str,
                         summary_csv: str,
                         output_csv: str | None = None) -> dict:
    """Build a per-station feature table by joining block-maxima statistics with
    the station summary (lat / lon / elevation).

    The returned features are (per station):
        n_years, lat, lon, elev_m,
        rx1day_mean, rx1day_std, rx1day_median, rx1day_max, rx1day_p90,
        trend_slope_mm_per_year (OLS slope of Rx1day vs year)
    Region is preserved for use as a label.
    """
    bm = pd.read_csv(block_maxima_csv)
    summary = pd.read_csv(summary_csv)
    rows = []
    for sid, grp in bm.groupby("station"):
        if len(grp) < 15:
            continue
        years = grp["year"].values.astype(float)
        rx = grp["rx1day_mm"].values.astype(float)
        slope, intercept, r, p, _ = stats.linregress(years, rx)
        st = summary[summary["station"] == sid]
        if st.empty:
            continue
        st = st.iloc[0]
        rows.append({
            "station": sid,
            "region": st["region"],
            "lat": float(st["lat"]),
            "lon": float(st["lon"]),
            "elev_m": float(st["elev_m"]),
            "n_years": int(len(grp)),
            "rx1day_mean": round(float(rx.mean()), 3),
            "rx1day_std": round(float(rx.std()), 3),
            "rx1day_median": round(float(np.median(rx)), 3),
            "rx1day_max": round(float(rx.max()), 3),
            "rx1day_p90": round(float(np.percentile(rx, 90)), 3),
            "trend_slope_mm_per_year": round(float(slope), 4),
            "trend_p_value": round(float(p), 4),
        })
    if output_csv is not None:
        pd.DataFrame(rows).to_csv(output_csv, index=False)
    return {
        "n_stations": len(rows),
        "rows": rows,
        "output_csv": output_csv,
    }


# ----------------------- ML classifier -----------------------


@mcp.tool()
def train_classifier_cv(features_csv: str,
                        label_column: str,
                        feature_columns: list[str],
                        model: str = "random_forest",
                        n_splits: int = 5,
                        random_state: int = 42) -> dict:
    """Train a classifier with stratified K-fold cross-validation.

    Args:
        features_csv: CSV with one row per station; must contain feature_columns
            and the chosen label_column.
        label_column: column to use as target (e.g. region or sensitivity_class)
        feature_columns: list of column names used as model inputs
        model: one of "logistic", "random_forest", "gradient_boost", "mlp"
        n_splits: number of CV folds
        random_state: seed for reproducibility

    Returns:
        dict with mean / std of accuracy and macro-F1 across folds, plus the
        held-out predictions concatenated across folds.
    """
    from sklearn.pipeline import make_pipeline

    df = pd.read_csv(features_csv)
    df = df.dropna(subset=feature_columns + [label_column])
    X = df[feature_columns].values.astype(float)
    y = df[label_column].astype(str).values

    def make_clf():
        # The StandardScaler is wrapped INSIDE a pipeline so it is fit on the
        # training fold only (avoids the leakage of scaling on the full set
        # before splitting).
        if model == "logistic":
            est = LogisticRegression(max_iter=2000, random_state=random_state)
        elif model == "random_forest":
            est = RandomForestClassifier(n_estimators=300,
                                         random_state=random_state, n_jobs=1)
        elif model == "gradient_boost":
            est = GradientBoostingClassifier(random_state=random_state)
        elif model == "mlp":
            est = MLPClassifier(hidden_layer_sizes=(32, 16), max_iter=2000,
                                random_state=random_state)
        else:
            return None
        return make_pipeline(StandardScaler(), est)

    if make_clf() is None:
        return {"error": f"unknown model {model}"}

    skf = StratifiedKFold(n_splits=n_splits, shuffle=True,
                          random_state=random_state)
    accs, f1s = [], []
    all_pred = np.empty_like(y)
    for tr, te in skf.split(X, y):
        clf = make_clf()
        clf.fit(X[tr], y[tr])          # scaler fit on TRAIN fold only
        pred = clf.predict(X[te])
        all_pred[te] = pred
        accs.append(accuracy_score(y[te], pred))
        f1s.append(f1_score(y[te], pred, average="macro"))
    overall_acc = accuracy_score(y, all_pred)
    overall_f1 = f1_score(y, all_pred, average="macro")
    return {
        "model": model,
        "n_samples": int(len(y)),
        "n_features": len(feature_columns),
        "label_classes": sorted(set(y.tolist())),
        "fold_accuracy_mean": round(float(np.mean(accs)), 4),
        "fold_accuracy_std": round(float(np.std(accs)), 4),
        "fold_f1_macro_mean": round(float(np.mean(f1s)), 4),
        "fold_f1_macro_std": round(float(np.std(f1s)), 4),
        "overall_accuracy": round(float(overall_acc), 4),
        "overall_f1_macro": round(float(overall_f1), 4),
        "classification_report": classification_report(y, all_pred,
                                                       output_dict=True,
                                                       zero_division=0),
    }


@mcp.tool()
def non_geographic_region_classifier(features_csv: str,
                                     label_column: str = "region",
                                     model: str = "random_forest",
                                     n_splits: int = 5,
                                     random_state: int = 42) -> dict:
    """Classify station region after excluding latitude and longitude.

    This baseline tests whether Rx1day/elevation features carry regional
    separation without letting the classifier solve the task by coordinate
    lookup.
    """
    df = pd.read_csv(features_csv)
    excluded = {label_column, "station", "lat", "lon"}
    feature_columns = [
        c for c in df.columns
        if c not in excluded and pd.api.types.is_numeric_dtype(df[c])
    ]
    return train_classifier_cv(features_csv, label_column, feature_columns,
                               model=model, n_splits=n_splits,
                               random_state=random_state)


@mcp.tool()
def binary_sensitivity_classifier(grid_csv: str,
                                  ari_column: str = "sensitivity_100",
                                  feature_columns: list[str] | None = None,
                                  model: str = "gradient_boost",
                                  n_splits: int = 5,
                                  random_state: int = 42) -> dict:
    """Train a binary classifier predicting whether a grid point's
    CNN-derived sensitivity is positive (>0) or non-positive.

    The grid CSV should have columns: lat, lon, sensitivity_<ari>.

    Args:
        grid_csv: a Figure 5/6 derived CSV with lat/lon/sensitivity_<ari>
        ari_column: which sensitivity column to threshold (e.g. sensitivity_100)
        feature_columns: input columns (default: ["lat", "lon"])
        model: classifier type
        n_splits: CV folds
        random_state: seed

    Returns:
        dict with accuracy, F1, ROC-AUC averaged across folds.
    """
    if feature_columns is None:
        feature_columns = ["lat", "lon"]
    df = pd.read_csv(grid_csv)
    df = df.dropna(subset=feature_columns + [ari_column])
    y = (df[ari_column].values.astype(float) > 0).astype(int)
    X = df[feature_columns].values.astype(float)

    if model == "logistic":
        clf = LogisticRegression(max_iter=2000, random_state=random_state)
    elif model == "random_forest":
        clf = RandomForestClassifier(n_estimators=300, random_state=random_state,
                                     n_jobs=1)
    elif model == "gradient_boost":
        clf = GradientBoostingClassifier(random_state=random_state)
    elif model == "mlp":
        clf = MLPClassifier(hidden_layer_sizes=(64, 32), max_iter=3000,
                            random_state=random_state)
    else:
        return {"error": f"unknown model {model}"}

    if len(set(y)) < 2:
        return {
            "model": model,
            "n_samples": int(len(y)),
            "positive_class_fraction": round(float(y.mean()), 4),
            "warning": "single-class data, classifier cannot be trained",
        }
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True,
                          random_state=random_state)
    accs, f1s, aucs = [], [], []
    for tr, te in skf.split(X, y):
        scaler = StandardScaler().fit(X[tr])
        clf.fit(scaler.transform(X[tr]), y[tr])
        pred = clf.predict(scaler.transform(X[te]))
        try:
            proba_full = clf.predict_proba(scaler.transform(X[te]))
            if proba_full.shape[1] == 2:
                proba = proba_full[:, 1]
                aucs.append(roc_auc_score(y[te], proba))
        except (ValueError, IndexError):
            pass
        accs.append(accuracy_score(y[te], pred))
        f1s.append(f1_score(y[te], pred, zero_division=0))
    return {
        "model": model,
        "n_samples": int(len(y)),
        "positive_class_fraction": round(float(y.mean()), 4),
        "accuracy_mean": round(float(np.mean(accs)), 4),
        "accuracy_std": round(float(np.std(accs)), 4),
        "f1_mean": round(float(np.mean(f1s)), 4),
        "f1_std": round(float(np.std(f1s)), 4),
        "roc_auc_mean": round(float(np.mean(aucs)), 4) if aucs else None,
        "roc_auc_std": round(float(np.std(aucs)), 4) if aucs else None,
    }


# ----------------------- Regional summary statistics -----------------------


@mcp.tool()
def regional_sensitivity_summary(fig5_files: dict[str, str],
                                 ari_column: str = "sensitivity_100") -> dict:
    """Summarise the CNN-derived per-grid sensitivities by region.

    Args:
        fig5_files: mapping {region_name: path_to_fig5_<region>.txt}
            for the four target regions
        ari_column: which sensitivity column to summarise

    Returns:
        dict with per-region count, mean, median, q25, q75, q05, q95, min,
        max, fraction positive, and fraction above the CCR 7%/K reference.
    """
    out = {}
    for region, path in fig5_files.items():
        df = pd.read_csv(path)
        if ari_column not in df.columns:
            continue
        v = df[ari_column].values.astype(float)
        v = v[~np.isnan(v)]
        out[region] = {
            "n": int(len(v)),
            "mean_pct_per_K": round(float(np.mean(v)), 3),
            "median_pct_per_K": round(float(np.median(v)), 3),
            "q25_pct_per_K": round(float(np.percentile(v, 25)), 3),
            "q75_pct_per_K": round(float(np.percentile(v, 75)), 3),
            "q05_pct_per_K": round(float(np.percentile(v, 5)), 3),
            "q95_pct_per_K": round(float(np.percentile(v, 95)), 3),
            "min": round(float(v.min()), 3),
            "max": round(float(v.max()), 3),
            "frac_positive": round(float((v > 0).mean()), 4),
            "frac_above_ccr_7pct": round(float((v > 7.0).mean()), 4),
        }
    return out


@mcp.tool()
def regional_aep_ratio_summary(meanmax_files: dict[str, str]) -> dict:
    """Summarise the per-region distribution of (1% AEP depth) / (mean Rx1day)
    ratios reported in the Zenodo Figure-2 text files.

    Args:
        meanmax_files: mapping {region: fig2_meanmax_<region>.txt path}

    Returns:
        dict with per-region mean and standard-deviation of the ratio column.
    """
    out = {}
    for region, path in meanmax_files.items():
        df = pd.read_csv(path)
        if "ratio" not in df.columns:
            continue
        # Ratio is already a multiplier of mean (e.g. 2.43 = 243%).
        r = df["ratio"].values.astype(float)
        out[region] = {
            "n": int(len(r)),
            "mean_ratio_to_mean_Rx1day": round(float(np.mean(r)), 3),
            "std_ratio_to_mean_Rx1day": round(float(np.std(r)), 3),
        }
    return out


# ----------------------- Plotting (one tool per artifact) -----------------------


# Canonical region codes used in ghcn_block_maxima_annual.csv:
#   NAM = North America, EUR = Europe, AUS = Australia, NZ = New Zealand.
# The per-grid fig2/fig5 text files use the long names; canonicalise either
# convention so region-keyed tools never silently produce an empty plot.
REGION_CANON = {
    "NAM": "NAM", "NA": "NAM", "north_america": "NAM", "north america": "NAM",
    "EUR": "EUR", "EU": "EUR", "europe": "EUR",
    "AUS": "AUS", "AU": "AUS", "australia": "AUS",
    "NZ": "NZ", "new_zealand": "NZ", "new zealand": "NZ",
}


def canonical_region(label: str) -> str:
    """Map any of the region label conventions (NAM/NA/north_america/...)
    to the canonical short code used in the block-maxima CSV."""
    if label is None:
        return label
    return REGION_CANON.get(str(label).strip(), REGION_CANON.get(str(label).strip().lower(), label))


@mcp.tool()
def plot_block_maxima_distribution(block_maxima_csv: str,
                                   output_path: str) -> dict:
    """Plot the distribution of station Rx1day means across the four regions.

    Saves a PNG to output_path.
    """
    df = pd.read_csv(block_maxima_csv)
    df["region"] = df["region"].map(canonical_region)
    fig, ax = plt.subplots(figsize=(8.5, 5))
    palette = {"NAM": "#1f77b4", "EUR": "#2ca02c", "AUS": "#d62728", "NZ": "#9467bd"}
    means = df.groupby(["station", "region"])["rx1day_mm"].mean().reset_index()
    for region in ["NAM", "EUR", "AUS", "NZ"]:
        sub = means[means["region"] == region]
        if sub.empty:
            continue
        ax.hist(sub["rx1day_mm"], bins=20, alpha=0.55,
                label=f"{region} (n={len(sub)})",
                color=palette.get(region, "grey"), edgecolor="k", linewidth=0.4)
    ax.set_xlabel("Mean annual Rx1day per station (mm/day)")
    ax.set_ylabel("Number of stations")
    ax.set_title("GHCN-Daily mean annual block-maxima by region (1960-2019)")
    ax.legend()
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"output_path": output_path,
            "n_stations": int(means["station"].nunique())}


@mcp.tool()
def plot_classifier_confusion(features_csv: str,
                              label_column: str,
                              feature_columns: list[str],
                              output_path: str,
                              model: str = "random_forest",
                              random_state: int = 42) -> dict:
    """Train a classifier with 5-fold CV and plot the resulting confusion
    matrix (held-out predictions concatenated across folds).
    """
    df = pd.read_csv(features_csv).dropna(subset=feature_columns + [label_column])
    X = df[feature_columns].values.astype(float)
    y = df[label_column].astype(str).values
    if model == "random_forest":
        clf = RandomForestClassifier(n_estimators=300, random_state=random_state,
                                     n_jobs=1)
    elif model == "gradient_boost":
        clf = GradientBoostingClassifier(random_state=random_state)
    elif model == "logistic":
        clf = LogisticRegression(max_iter=2000, random_state=random_state)
    elif model == "mlp":
        clf = MLPClassifier(hidden_layer_sizes=(32, 16), max_iter=2000,
                            random_state=random_state)
    else:
        return {"error": f"unknown model {model}"}
    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=random_state)
    pred = np.empty_like(y)
    for tr, te in skf.split(X, y):
        scaler = StandardScaler().fit(X[tr])
        clf.fit(scaler.transform(X[tr]), y[tr])
        pred[te] = clf.predict(scaler.transform(X[te]))
    classes = sorted(set(y.tolist()))
    cm = np.zeros((len(classes), len(classes)), dtype=int)
    idx = {c: i for i, c in enumerate(classes)}
    for t, p in zip(y, pred):
        cm[idx[t], idx[p]] += 1
    fig, ax = plt.subplots(figsize=(6, 5.2))
    im = ax.imshow(cm, cmap="Blues")
    ax.set_xticks(range(len(classes)))
    ax.set_yticks(range(len(classes)))
    ax.set_xticklabels(classes)
    ax.set_yticklabels(classes)
    ax.set_xlabel("Predicted")
    ax.set_ylabel("True")
    ax.set_title(f"{model}: 5-fold CV confusion matrix\n"
                 f"acc={accuracy_score(y, pred):.3f} "
                 f"F1macro={f1_score(y, pred, average='macro'):.3f}")
    for i in range(len(classes)):
        for j in range(len(classes)):
            ax.text(j, i, str(cm[i, j]),
                    ha="center", va="center",
                    color="white" if cm[i, j] > cm.max() / 2 else "black")
    fig.colorbar(im, ax=ax, fraction=0.046)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {
        "output_path": output_path,
        "accuracy": round(float(accuracy_score(y, pred)), 4),
        "f1_macro": round(float(f1_score(y, pred, average="macro")), 4),
        "confusion_matrix": cm.tolist(),
        "classes": classes,
    }


@mcp.tool()
def plot_regional_sensitivity_boxplot(fig5_files: dict[str, str],
                                      output_path: str,
                                      ari_column: str = "sensitivity_100") -> dict:
    """Produce a boxplot of the CNN-derived sensitivity (%/K) at the chosen
    ARI for each region, with the Clausius-Clapeyron 7%/K reference line."""
    data = {}
    for region, path in fig5_files.items():
        df = pd.read_csv(path)
        if ari_column not in df.columns:
            continue
        data[canonical_region(region)] = df[ari_column].values.astype(float)
    fig, ax = plt.subplots(figsize=(8, 5))
    order = [r for r in ["NAM", "EUR", "AUS", "NZ"] if r in data]
    bp = ax.boxplot([data[r] for r in order], labels=order, patch_artist=True,
                    showfliers=False)
    colors = {"NAM": "#1f77b4", "EUR": "#2ca02c", "AUS": "#d62728", "NZ": "#9467bd"}
    for patch, region in zip(bp["boxes"], order):
        patch.set_facecolor(colors.get(region, "grey"))
        patch.set_alpha(0.65)
    ax.axhline(7.0, color="orange", linestyle="--",
               label="Clausius-Clapeyron expectation 7%/K")
    ax.axhline(0.0, color="black", linewidth=0.6)
    ax.set_ylabel("Sensitivity at 100-yr ARI (%/K)")
    ax.set_title("CNN-derived sensitivity of 1% AEP precipitation to "
                 "global mean temperature, by region")
    ax.legend()
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    summary = {r: {"n": int(len(data[r])),
                   "median": round(float(np.median(data[r])), 3),
                   "q25": round(float(np.percentile(data[r], 25)), 3),
                   "q75": round(float(np.percentile(data[r], 75)), 3)}
               for r in order}
    return {"output_path": output_path, "regional_summary": summary}


@mcp.tool()
def plot_aep_ratio_bars(meanmax_files: dict[str, str],
                        output_path: str) -> dict:
    """Bar plot of the (1% AEP / mean Rx1day) ratio per region with the
    1-sigma scatter as error bars. Reproduces the ratio summary discussed in
    the Results section of the source paper."""
    means, stds, regions = [], [], []
    for region, path in meanmax_files.items():
        df = pd.read_csv(path)
        if "ratio" not in df.columns:
            continue
        r = df["ratio"].values.astype(float)
        means.append(float(np.mean(r)))
        stds.append(float(np.std(r)))
        regions.append(canonical_region(region))
    fig, ax = plt.subplots(figsize=(7, 4.5))
    colors = {"north_america": "#1f77b4", "europe": "#2ca02c",
              "australia": "#d62728", "new_zealand": "#9467bd",
              "NA": "#1f77b4", "NAM": "#1f77b4", "EUR": "#2ca02c",
              "AUS": "#d62728", "NZ": "#9467bd"}
    bars = ax.bar(regions, means, yerr=stds, capsize=6,
                  color=[colors.get(r, "grey") for r in regions],
                  edgecolor="black", alpha=0.75)
    for bar, m in zip(bars, means):
        ax.text(bar.get_x() + bar.get_width() / 2, m + 0.04,
                f"{m:.2f}x", ha="center", va="bottom")
    ax.set_ylabel("1% AEP depth / mean Rx1day (x)")
    ax.set_title("1-in-100 year precipitation depth relative to mean annual\n"
                 "block maximum (per region)")
    ax.grid(alpha=0.25, axis="y")
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"output_path": output_path,
            "regions": regions,
            "means_ratio_to_mean_Rx1day": [round(m, 3) for m in means],
            "std_ratio_to_mean_Rx1day": [round(s, 3) for s in stds]}


if __name__ == "__main__":
    mcp.run(transport="stdio")

Figure 1
The background image was obtained from the 'NaturalEarthFeature’ function of the python Cartopy library (Figure1_background.png). The data required to generate the plots shown in Figure 1 are provided in the Figure1.nc file:
* The latitudes and longitudes for the 10,000 training sites are provided in Training_location_latitudes and Training_location_longitudes variables. 
* The latitudes and longitudes for the 8 sites used to demonstrate the ability of the CNN to generalise spatially are provided in the Validation_location_latitudes and Validation_location_longitudes variables. 
* The block maxima at each of the 8 sites are provided in the Location_1year_block_maxima variable.
* The GEV fits at 0°C are provided in the GEV_fit_at_0.0C variable.
* The GEV fits at 1.5°C are provided in the GEV_fit_at_1.5C variable.

Figure 2
* The 1-in-100 year precipitation fields for values of T'Global from 0.0°C to 2.0°C in 0.1°C increments are provided in netCDF files named Figure2_<region>.nc where <region> is either 'north_america', 'australia', 'europe', or 'new_zealand'.
* The ratios of the 1-in-100 year precipitation depths with respect to the long-term (20 years or more) average of the annual maximum 1-day precipitation are provided in text files named Figure2_Precipitation_mean_block_max_<region>.txt where <region> is either 'north_america', 'australia', 'europe', or 'new_zealand'.

Figure 3
* The cumulative distribution functions (CDFs) shown in the lower four panels are provided as text files listing the ARI in years and the daily total precipitation depth in mm. These files are named CDF_<lat>_<long>.dat where <lat> is the latitude and <long> is the longitude. Files for each region are zipped into .7z files named Figure3_<region>.7z where <region> is either 'north_america', 'australia', 'europe', or 'new_zealand'.
* The latitudes and longitudes for the upper panels can be inferred from the file names for each region.

Figure 4
* The data for each panel are provided in a netCDF file named Figure4_<region>.nc where <region> is either 'north_america', 'australia', 'europe', or 'new_zealand'.

Figure 5
* The data are provided as text files named Figure5_<region> where <region> is either 'north_america', 'australia', 'europe', or 'new_zealand'. Each file lists the sensitivities at ARIs of 10, 20, 50, 100, and 200 years.

Figure 6
* The data are provided as text files named Figure6_<region> where <region> is either 'north_america', 'australia', 'europe', or 'new_zealand'. Each file lists the precipitation depths and the sensitivities at ARIs of 10, 20, 50, 100, and 200 years. 

Figure 7
* The data for each panel are provided in a netCDF file named Figure7_<region>.nc where <region> is either 'north_america', 'australia', 'europe', or 'new_zealand'.

Figure 8
* The data are provided as text files named Figure8_<region>.txt where <region> is either 'north_america', 'australia', 'europe', or 'new_zealand'. Each file lists the global surface temperature anomaly (°C) and the average negative log likelihood.

Figure S1 and Figure S3
* The data are provided as text files named Figure_S1_and_S3_<region>.txt where <region> is either 'north_america', 'australia', 'europe', or 'new_zealand'. A header at the top of each file describes its contents.

Figure S2
* The 1-in-20 year precipitation fields for values of T'Global from 0.0°C to 2.0°C in 0.1°C increments are provided in netCDF files named FigureS2_<region>.nc where <region> is either 'north_america', 'australia', 'europe', or 'new_zealand'.
* The ratios of the 1-in-20 year precipitation depths with respect to the long-term (20 years or more) average of the annual maximum 1-day precipitation are provided in text files named FigureS2_Precipitation_mean_block_max_<region>.txt where <region> is either 'north_america', 'australia', 'europe', or 'new_zealand'.

Figure S4
* The block maxima for each site are provided in text files named FigureS4_blockmaxima_siteA.txt and FigureS4_blockmaxima_siteB.txt. A header at the top of each column described the column contents. 
* The GEV-derived curves for each site are provided in text files named FigureS4_gevcurves_siteA.txt and FigureS4_gevcurves_siteB.txt. A header at the top of each column described the column contents.  

Figure S5
There are no data associated with this figure. This figure was made using Microsoft Powerpoint.

Figure S6
* The data are provided as text files named FigureS6_<region>.txt where <region> is either 'north_america', 'australia', 'europe', or 'new_zealand'. A header at the top of each file describes the files contents.
# Source Data Notes

- `fig2_meanmax_<region>.txt` contains the GHCN-site circle values used to
  reproduce the paper Fig. 2 climatological context: 1% AEP precipitation depth
  divided by mean annual Rx1day. The files are local paper-derived tabulations
  aligned to the paper text summaries: North America 243 +/- 35%, Australia
  268 +/- 45%, Europe 244 +/- 30%, and New Zealand 246 +/- 38%. New Zealand has
  50 sites, matching the paper text; the other regions have 100 sites.
- `fig5_<region>.txt` and `fig6_<region>.txt` are local sampled text exports of
  the paper's CNN-derived gridded sensitivity/depth fields. They support
  regional summaries and plotting in this task, but they are not a replacement
  for the paper's full CNN training pipeline.
- `ghcn_block_maxima_annual.csv` and `hadcrut5_global_annual.csv` support a
  simplified station-level stationary/location-only non-stationary GEV workflow
  for sanity checks. This is not the paper's full six-parameter CNN GEV model.

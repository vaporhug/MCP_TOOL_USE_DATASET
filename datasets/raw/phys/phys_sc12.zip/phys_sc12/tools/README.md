# phys_sc12 — Tool Reference

Tools supporting the supercritical-fluid thermodynamic crossover / 3D Ising
universality task. Two modules:

- `data_processing.py` — format conversion, reshaping, cleaning.
- `supercritical_analysis.py` — domain tools (FastMCP-decorated).

## Susceptibility / compressibility convention

Following the reference paper, the reduced isothermal **susceptibility** is

  kappa_T = (Pc / rho_c) * (d rho / d P)_T,

which in reduced variables (rho_hat = rho/rho_c, P_hat = P/Pc) becomes the
dimensionless `kappa_hat = (1/rho_hat) * (d rho_hat / d P_hat)_T` computed by
`compressibility_from_eos`. The crossover lines L+/L- are the loci of maxima of
this reduced susceptibility kappa_T (kappa_hat). The (dimensional) isothermal
**compressibility** beta_T = (1/rho) * (d rho / d P)_T differs from kappa_T only
by the critical prefactor Pc/rho_c and shares the same maxima loci; this task
uses the reduced susceptibility kappa_T throughout.

## Runtime dependencies

- `numpy` (EOS grid math, finite differences, fitting)
- `matplotlib` (plotting, headless "Agg" backend)
- `CoolProp >= 7` (NIST REFPROP reference equations of state; used by
  `query_coolprop` for off-grid thermodynamic property queries — optional, the
  bundled CSV grids are sufficient for the full pipeline)
- `mcp` (FastMCP server decorators)

Install with:

```
pip install numpy matplotlib CoolProp mcp
```

## Data Processing (`data_processing.py`)

Generic list-of-dict / CSV / JSON helpers — `read_csv`, `write_csv`,
`read_json`, `coerce_numeric`, `drop_missing`, `join_tables`,
`groupby_aggregate`, `pivot_*`, etc.

## Domain-Specific Analysis (`supercritical_analysis.py`)

Data loading:

- **load_eos_csv** — parse an `eos_<Substance>.csv` into row list + axis
  inventories (T_hat, rho_hat).
- **load_critical_constants** — load the critical-constants lookup table.
- **query_coolprop** — query the NIST reference EOS (P, isothermal
  compressibility) at an arbitrary (T, rho) point using CoolProp.

Thermodynamic transforms:

- **build_eos_table** — reshape flat rows into a (T_hat, rho_hat, P_hat)
  regular grid.
- **shift_by_critical_isochore** — compute
  delta_P_hat(rho_hat; T_hat) = P_hat(rho_hat; T_hat) - P_hat(rho_hat=1;T_hat).
- **compressibility_from_eos** — compute the reduced isothermal
  susceptibility kappa_hat by central finite difference.

L+ / L- locus extraction:

- **locate_crossover_lines** — for each fixed shifted pressure
  delta_P_hat, find the T_hat at which kappa_hat peaks along the path
  parallel to the critical isochore (branch = "plus" or "minus").
- **compute_crossover_density** — look up rho_hat (and delta_rho_hat) on
  the shifted EOS surface for the located crossover points.

Power-law fitting:

- **fit_power_law** — generic y = A * x^n least-squares fit (optional
  fixed exponent, optional x-window).
- **ising_scaling_prefactor** — fit |delta_P_hat| = A_P * (T_hat - 1)^(beta+gamma)
  with beta + gamma fixed to the 3D Ising values.

Plotting (one function per answer image):

- **plot_shifted_isotherms** — shifted-EOS figure with L+/L- locus
  overlays (answer image 1).
- **plot_universal_scaling** — log-log collapse of |delta_P_hat|/A+_P vs
  Delta_T_hat for multiple substances, reference slope beta+gamma
  (answer image 2).
- **plot_phase_diagram** — P_hat - T_hat phase diagram with L+/L- lines
  and optional overlay of external experimental crossover points
  (answer image 3).

Each plotting function returns the absolute path of the written PNG.

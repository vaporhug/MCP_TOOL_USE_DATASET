# phys_sc12 — Tool Reference

Tools supporting the supercritical-fluid thermodynamic crossover / 3D Ising
universality task. Two modules:

- `data_processing.py` — format conversion, reshaping, cleaning.
- `supercritical_analysis.py` — domain tools (FastMCP-decorated).

## Susceptibility / compressibility convention

The reference paper defines TWO distinct response functions, and they are NOT
the same quantity:

- **Susceptibility** `kappa_T = (Pc/rho_c) * (d rho / d P)_T`. In reduced
  variables (rho_hat = rho/rho_c, P_hat = P/Pc) this is the dimensionless
  `kappa_hat = (d rho_hat / d P_hat)_T = 1 / (d P_hat / d rho_hat)_T`, i.e. the
  **inverse slope of the (shifted) isothermal EOS** with NO 1/rho_hat factor.
  Computed by `susceptibility_from_eos`.
- **Compressibility** `beta_T = (1/rho) * (d rho / d P)_T`. In reduced variables
  this is `beta_hat = (1/rho_hat) * (d rho_hat / d P_hat)_T`, carrying an extra
  `1/rho_hat` factor. Computed by `compressibility_from_eos`.

Because they differ by the rho_hat-dependent factor `1/rho_hat`, the two
quantities are NOT proportional and their maxima along an isotherm do NOT in
general coincide. The crossover lines L+/L- are defined as the loci of maxima of
the **susceptibility** `kappa_T` (paper Fig. 2C-D), so `locate_crossover_lines`
peaks over `kappa_T = 1/(dP_hat/drho_hat)`, not over the compressibility.
`compressibility_from_eos` is provided only for reference/comparison.

## Runtime dependencies

- `numpy` (EOS grid math, finite differences, fitting)
- `matplotlib` (plotting, headless "Agg" backend)
- `CoolProp >= 7` (NIST REFPROP reference equations of state; used by
  `query_coolprop` for off-grid thermodynamic property queries — optional, the
  bundled CSV grids are sufficient for the full pipeline)
- `mcp` (FastMCP server decorators)

Install with:

```
pip install numpy matplotlib CoolProp mcp
```

## Data Processing (`data_processing.py`)

Generic list-of-dict / CSV / JSON helpers — `read_csv`, `write_csv`,
`read_json`, `coerce_numeric`, `drop_missing`, `join_tables`,
`groupby_aggregate`, `pivot_*`, etc.

## Domain-Specific Analysis (`supercritical_analysis.py`)

Data loading:

- **load_eos_csv** — parse an `eos_<Substance>.csv` into row list + axis
  inventories (T_hat, rho_hat).
- **load_critical_constants** — load the critical-constants lookup table.
- **query_coolprop** — query the NIST reference EOS (P, isothermal
  compressibility) at an arbitrary (T, rho) point using CoolProp.

Thermodynamic transforms:

- **build_eos_table** — reshape flat rows into a (T_hat, rho_hat, P_hat)
  regular grid.
- **shift_by_critical_isochore** — compute
  delta_P_hat(rho_hat; T_hat) = P_hat(rho_hat; T_hat) - P_hat(rho_hat=1;T_hat).
- **susceptibility_from_eos** — compute the reduced isothermal susceptibility
  kappa_hat = 1/(dP_hat/drho_hat) (inverse EOS slope) by central finite
  difference. This is the quantity whose maxima define L+/L-.
- **compressibility_from_eos** — compute the reduced isothermal compressibility
  beta_hat = 1/(rho_hat * dP_hat/drho_hat) by central finite difference
  (reference only; differs from the susceptibility by the 1/rho_hat factor).

L+ / L- locus extraction:

- **locate_crossover_lines** — for each fixed shifted pressure
  delta_P_hat, find the T_hat at which the susceptibility kappa_T =
  1/(dP_hat/drho_hat) peaks along the path parallel to the critical isochore
  (branch = "plus" or "minus").
- **compute_crossover_density** — look up rho_hat (and delta_rho_hat) on
  the shifted EOS surface for the located crossover points.

End-to-end table generation:

- **generate_crossover_tables** — deterministic pipeline that regenerates the
  two bundled artifact CSVs from the bundled EOS data for all eight fluids
  (fixed |delta_P_hat| sample set, Ising slope beta+gamma=1.5635). Writes
  `artifacts/crossover_line_coordinates.csv` (columns
  `fluid, branch, delta_P_hat, T_hat_peak, delta_rho_hat`) and
  `artifacts/crossover_fit_parameters.csv` (columns `fluid, branch, free_slope,
  free_r2, ising_A_P, ising_slope, ising_r2, n_points`). The temperature column
  is named `T_hat_peak` everywhere (matching the `locate_crossover_lines`
  output key) for naming consistency across tools, CSVs and the answer.

Power-law fitting:

- **fit_power_law** — generic y = A * x^n least-squares fit (optional
  fixed exponent, optional x-window).
- **ising_scaling_prefactor** — fit |delta_P_hat| = A_P * (T_hat - 1)^(beta+gamma)
  with beta + gamma fixed to the 3D Ising values.

Plotting (one function per answer image):

- **plot_shifted_isotherms** — shifted-EOS figure with L+/L- locus
  overlays (answer image 1).
- **plot_universal_scaling** — log-log collapse of |delta_P_hat|/A+_P vs
  Delta_T_hat for multiple substances, reference slope beta+gamma
  (answer image 2).
- **plot_phase_diagram** — P_hat - T_hat phase diagram with L+/L- lines
  and optional overlay of external experimental crossover points
  (answer image 3).

Each plotting function returns the absolute path of the written PNG.

#!/usr/bin/env python3
"""Domain tools for supercritical-fluid thermodynamic crossover analysis.

Every function is a low-level primitive: load/interpolate EOS data, compute
isothermal susceptibility kappa_T, locate susceptibility maxima along paths
parallel to the critical isochore (L+ / L- lines), fit power-law scalings, and
render the figures the task asks for. The scientific choices (Ising exponents,
which branch is liquid-like, etc.) are left to the calling agent.
"""

from __future__ import annotations

import csv
import os
from typing import Any, Iterable

import numpy as np
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Supercritical_Crossover_Tools")


# ----------------------------------------------------------------------------
# Data loading
# ----------------------------------------------------------------------------
@mcp.tool()
def load_eos_csv(csv_path: str) -> dict:
    """Load a supercritical EOS CSV (columns T_hat, rho_hat, T_K, rho_kg_per_m3,
    P_Pa, P_hat).

    Args:
        csv_path: absolute path to an eos_<Substance>.csv file.

    Returns:
        dict with keys `columns`, `n_rows`, `T_hat_values` (sorted unique),
        `rho_hat_values` (sorted unique) and `rows` (list-of-dicts, all rows).
    """
    rows: list[dict] = []
    with open(csv_path, newline="") as f:
        reader = csv.DictReader(f)
        cols = reader.fieldnames or []
        for r in reader:
            out = {}
            for k, v in r.items():
                try:
                    out[k] = float(v)
                except (TypeError, ValueError):
                    out[k] = v
            rows.append(out)
    T_vals = sorted({r["T_hat"] for r in rows})
    rho_vals = sorted({r["rho_hat"] for r in rows})
    return {
        "columns": cols,
        "n_rows": len(rows),
        "T_hat_values": T_vals,
        "rho_hat_values": rho_vals,
        "rows": rows,
    }


@mcp.tool()
def load_critical_constants(csv_path: str) -> dict:
    """Load the critical_constants.csv table into a name->dict lookup.

    Args:
        csv_path: absolute path to critical_constants.csv.

    Returns:
        dict mapping substance name to {Tc_K, Pc_Pa, rhoc_kg_per_m3, M_kg_per_mol}.
    """
    out: dict[str, dict] = {}
    with open(csv_path, newline="") as f:
        for r in csv.DictReader(f):
            out[r["substance"]] = {
                "Tc_K": float(r["Tc_K"]),
                "Pc_Pa": float(r["Pc_Pa"]),
                "rhoc_kg_per_m3": float(r["rhoc_kg_per_m3"]),
                "M_kg_per_mol": float(r["M_kg_per_mol"]),
            }
    return out


@mcp.tool()
def query_coolprop(substance: str, T_K: float, rho_kg_per_m3: float) -> dict:
    """Query the CoolProp reference EOS for a single (T, rho) point.

    Use this when the bundled grid does not cover the point of interest. The
    substance name must be a valid CoolProp fluid string (e.g. "Argon",
    "CarbonDioxide", "Water", "Nitrogen", "Neon", "n-Propane",
    "NitrousOxide", "Oxygen").

    Args:
        substance: CoolProp fluid name.
        T_K: temperature in kelvin.
        rho_kg_per_m3: density in kg/m^3.

    Returns:
        dict with P_Pa, compressibility isothermal_compressibility_1_per_Pa,
        Tc_K, Pc_Pa, rhoc_kg_per_m3.
    """
    from CoolProp.CoolProp import PropsSI

    Tc = PropsSI("Tcrit", substance)
    Pc = PropsSI("Pcrit", substance)
    rhoc = PropsSI("rhocrit", substance)
    P = PropsSI("P", "T", T_K, "D", rho_kg_per_m3, substance)
    # CoolProp provides isothermal compressibility directly:
    kappa_T = PropsSI("ISOTHERMAL_COMPRESSIBILITY", "T", T_K, "D", rho_kg_per_m3, substance)
    return {
        "substance": substance,
        "T_K": T_K,
        "rho_kg_per_m3": rho_kg_per_m3,
        "P_Pa": P,
        "isothermal_compressibility_1_per_Pa": kappa_T,
        "Tc_K": Tc,
        "Pc_Pa": Pc,
        "rhoc_kg_per_m3": rhoc,
    }


# ----------------------------------------------------------------------------
# Thermodynamic transforms
# ----------------------------------------------------------------------------
@mcp.tool()
def build_eos_table(rows: list[dict]) -> dict:
    """Reshape a flat EOS row list into a regular (T_hat, rho_hat, P_hat) grid.

    Args:
        rows: list-of-dicts from load_eos_csv().

    Returns:
        dict with keys T_hat (1-D np.ndarray as list), rho_hat (list),
        P_hat_grid (2-D list with shape [nT, nRho]).
    """
    T_vals = sorted({r["T_hat"] for r in rows})
    rho_vals = sorted({r["rho_hat"] for r in rows})
    grid = np.full((len(T_vals), len(rho_vals)), np.nan)
    T_idx = {t: i for i, t in enumerate(T_vals)}
    rho_idx = {r: i for i, r in enumerate(rho_vals)}
    for r in rows:
        grid[T_idx[r["T_hat"]], rho_idx[r["rho_hat"]]] = r["P_hat"]
    return {
        "T_hat": T_vals,
        "rho_hat": rho_vals,
        "P_hat_grid": grid.tolist(),
    }


@mcp.tool()
def shift_by_critical_isochore(eos_table: dict) -> dict:
    """Compute the shifted EOSs delta_P_hat(rho_hat; T_hat) = P_hat(rho_hat; T_hat)
    - P_hat(rho_hat=1; T_hat).

    This follows the Li-Jin construction (paper Fig. 2B): the critical
    isochore plays the role of the H = 0 line in the Ising model.

    Args:
        eos_table: output of build_eos_table().

    Returns:
        dict with T_hat, rho_hat, delta_P_hat_grid.
    """
    T = np.array(eos_table["T_hat"], dtype=float)
    rho = np.array(eos_table["rho_hat"], dtype=float)
    P = np.array(eos_table["P_hat_grid"], dtype=float)
    # P_hat along rho_hat = 1 per isotherm, via linear interpolation.
    P_iso = np.array([np.interp(1.0, rho, P[i]) for i in range(len(T))])
    delta = P - P_iso[:, None]
    return {
        "T_hat": T.tolist(),
        "rho_hat": rho.tolist(),
        "delta_P_hat_grid": delta.tolist(),
    }


@mcp.tool()
def compressibility_from_eos(eos_table: dict) -> dict:
    """Compute the reduced isothermal susceptibility
    kappa_hat = (1/rho_hat) * (d rho_hat / d P_hat)_T on each grid point using
    central finite differences in rho_hat.

    Args:
        eos_table: output of build_eos_table().

    Returns:
        dict with T_hat, rho_hat, kappa_hat_grid (same shape as P_hat_grid).
    """
    T = np.array(eos_table["T_hat"], dtype=float)
    rho = np.array(eos_table["rho_hat"], dtype=float)
    P = np.array(eos_table["P_hat_grid"], dtype=float)
    kappa = np.full_like(P, np.nan)
    for i in range(len(T)):
        dPdrho = np.gradient(P[i], rho)
        with np.errstate(divide="ignore", invalid="ignore"):
            kappa[i] = 1.0 / (rho * dPdrho)
    return {
        "T_hat": T.tolist(),
        "rho_hat": rho.tolist(),
        "kappa_hat_grid": kappa.tolist(),
    }


# ----------------------------------------------------------------------------
# L+ / L- locus extraction
# ----------------------------------------------------------------------------
@mcp.tool()
def locate_crossover_lines(eos_table: dict, delta_P_samples: list[float],
                           branch: str = "plus",
                           T_hat_min: float = 1.001) -> dict:
    """Locate points on the L+ or L- crossover line.

    For each fixed shifted pressure delta_P_hat, find the temperature T_hat at
    which the reduced susceptibility kappa_hat peaks along the parallel-to-
    critical-isochore path. This implements the definition in the paper
    (Fig. 2C-D): L+ is on the liquid-like branch rho_hat > 1, delta_P_hat > 0;
    L- is on the gas-like branch rho_hat < 1, delta_P_hat < 0.

    Args:
        eos_table: output of build_eos_table().
        delta_P_samples: positive values of |delta_P_hat| to evaluate.
        branch: "plus" (delta_P_hat > 0, rho_hat > 1) or "minus"
            (delta_P_hat < 0, rho_hat < 1).
        T_hat_min: lower cutoff on T_hat when searching for the peak (the
            critical isotherm is excluded because kappa_T diverges there).

    Returns:
        dict with lists delta_P_hat (signed) and T_hat_peak (NaN where no peak
        could be located).
    """
    if branch not in ("plus", "minus"):
        raise ValueError("branch must be 'plus' or 'minus'")
    T_full = np.array(eos_table["T_hat"], dtype=float)
    T_mask = T_full >= T_hat_min
    T = T_full[T_mask]
    rho = np.array(eos_table["rho_hat"], dtype=float)
    P_full = np.array(eos_table["P_hat_grid"], dtype=float)
    P = P_full[T_mask]
    # Shifted pressure
    P_iso = np.array([np.interp(1.0, rho, P[i]) for i in range(len(T))])
    delta = P - P_iso[:, None]
    sign = 1.0 if branch == "plus" else -1.0
    mask = rho > 1.0 if branch == "plus" else rho < 1.0
    rho_side = rho[mask]
    delta_side = delta[:, mask]
    # For each T, build a delta_P -> rho_hat interpolator (delta is monotonic
    # in rho on each half away from the isochore, so long as T_hat >= ~1).
    out_delta: list[float] = []
    out_T: list[float] = []
    for dP_abs in delta_P_samples:
        dP_signed = sign * dP_abs
        kappa_vs_T: list[float] = []
        for i in range(len(T)):
            y = delta_side[i]
            x = rho_side
            good = np.isfinite(y)
            x_g, y_g = x[good], y[good]
            if len(x_g) < 3:
                kappa_vs_T.append(np.nan)
                continue
            # Ensure ascending in y for np.interp. For the plus branch, y
            # increases with rho; for minus branch it decreases (negative).
            order = np.argsort(y_g)
            y_sorted, x_sorted = y_g[order], x_g[order]
            if dP_signed < y_sorted[0] or dP_signed > y_sorted[-1]:
                kappa_vs_T.append(np.nan)
                continue
            rho_at = float(np.interp(dP_signed, y_sorted, x_sorted))
            # dP/drho at that rho via finite difference on original ordering
            xo = x_g  # already ascending in rho
            yo = y_g
            # bracket idx
            idx = int(np.searchsorted(xo, rho_at))
            if idx <= 0 or idx >= len(xo) - 1:
                kappa_vs_T.append(np.nan)
                continue
            dPdrho = (yo[idx + 1] - yo[idx - 1]) / (xo[idx + 1] - xo[idx - 1])
            if dPdrho <= 0:
                kappa_vs_T.append(np.nan)
                continue
            kappa = (1.0 / rho_at) / dPdrho
            kappa_vs_T.append(kappa)
        arr = np.array(kappa_vs_T, dtype=float)
        if np.sum(np.isfinite(arr)) < 3:
            out_delta.append(dP_signed)
            out_T.append(float("nan"))
            continue
        ipeak = int(np.nanargmax(arr))
        # refine with parabolic fit around peak if neighbours valid
        Tpeak = float(T[ipeak])
        if 0 < ipeak < len(T) - 1 and all(np.isfinite(arr[ipeak - 1 : ipeak + 2])):
            x0, x1, x2 = T[ipeak - 1], T[ipeak], T[ipeak + 1]
            y0, y1, y2 = arr[ipeak - 1], arr[ipeak], arr[ipeak + 1]
            denom = (x0 - x1) * (x0 - x2) * (x1 - x2)
            if abs(denom) > 0:
                a = (x2 * (y1 - y0) + x1 * (y0 - y2) + x0 * (y2 - y1)) / denom
                b = (x2 ** 2 * (y0 - y1) + x1 ** 2 * (y2 - y0) + x0 ** 2 * (y1 - y2)) / denom
                if a < 0:
                    Tpeak = float(-b / (2 * a))
        out_delta.append(dP_signed)
        out_T.append(Tpeak)
    return {"delta_P_hat": out_delta, "T_hat_peak": out_T, "branch": branch}


@mcp.tool()
def compute_crossover_density(eos_table: dict, line_points: dict) -> dict:
    """Given L+ or L- line points (delta_P_hat, T_hat_peak), compute the
    corresponding rho_hat on the EOS and return delta_rho_hat = rho_hat - 1.

    Args:
        eos_table: output of build_eos_table().
        line_points: output of locate_crossover_lines().

    Returns:
        dict with delta_P_hat, T_hat_peak, rho_hat, delta_rho_hat.
    """
    T_grid = np.array(eos_table["T_hat"], dtype=float)
    rho = np.array(eos_table["rho_hat"], dtype=float)
    P = np.array(eos_table["P_hat_grid"], dtype=float)
    P_iso = np.array([np.interp(1.0, rho, P[i]) for i in range(len(T_grid))])
    delta = P - P_iso[:, None]
    branch = line_points.get("branch", "plus")
    mask = rho > 1.0 if branch == "plus" else rho < 1.0
    rho_side = rho[mask]
    out_rho: list[float] = []
    out_drho: list[float] = []
    for dP, Tp in zip(line_points["delta_P_hat"], line_points["T_hat_peak"]):
        if not (np.isfinite(dP) and np.isfinite(Tp)):
            out_rho.append(float("nan"))
            out_drho.append(float("nan"))
            continue
        # interpolate delta along T onto Tp to get shifted isotherm at that T
        T_below = np.searchsorted(T_grid, Tp)
        if T_below <= 0 or T_below >= len(T_grid):
            out_rho.append(float("nan"))
            out_drho.append(float("nan"))
            continue
        i0, i1 = T_below - 1, T_below
        w = (Tp - T_grid[i0]) / (T_grid[i1] - T_grid[i0])
        isotherm = (1 - w) * delta[i0, mask] + w * delta[i1, mask]
        good = np.isfinite(isotherm)
        if good.sum() < 2:
            out_rho.append(float("nan"))
            out_drho.append(float("nan"))
            continue
        order = np.argsort(isotherm[good])
        y_sorted = isotherm[good][order]
        x_sorted = rho_side[good][order]
        if dP < y_sorted[0] or dP > y_sorted[-1]:
            out_rho.append(float("nan"))
            out_drho.append(float("nan"))
            continue
        rh = float(np.interp(dP, y_sorted, x_sorted))
        out_rho.append(rh)
        out_drho.append(rh - 1.0)
    return {
        "delta_P_hat": list(line_points["delta_P_hat"]),
        "T_hat_peak": list(line_points["T_hat_peak"]),
        "rho_hat": out_rho,
        "delta_rho_hat": out_drho,
        "branch": branch,
    }


# ----------------------------------------------------------------------------
# Power-law fitting
# ----------------------------------------------------------------------------
@mcp.tool()
def fit_power_law(x_values: list[float], y_values: list[float],
                  fix_exponent: float | None = None,
                  xmin: float | None = None, xmax: float | None = None) -> dict:
    """Fit y = A * x^n.

    Args:
        x_values: independent variable (e.g. Delta_T_hat = T/Tc - 1).
        y_values: dependent variable (|delta_P_hat|, |delta_rho_hat|).
        fix_exponent: if provided, the exponent n is fixed and only the
            prefactor A is fitted (least-squares on log y = log A + n log x).
        xmin, xmax: optional range restriction on x.

    Returns:
        dict with A, n (exponent used), r2, n_points_used.
    """
    x = np.asarray(x_values, dtype=float)
    y = np.asarray(y_values, dtype=float)
    mask = np.isfinite(x) & np.isfinite(y) & (x > 0) & (y > 0)
    if xmin is not None:
        mask &= x >= xmin
    if xmax is not None:
        mask &= x <= xmax
    if mask.sum() < 2:
        return {"A": float("nan"), "n": float("nan"), "r2": float("nan"),
                "n_points_used": int(mask.sum())}
    lx = np.log(x[mask])
    ly = np.log(y[mask])
    if fix_exponent is None:
        n, c = np.polyfit(lx, ly, 1)
        A = float(np.exp(c))
    else:
        n = float(fix_exponent)
        A = float(np.exp(np.mean(ly - n * lx)))
    pred = np.log(A) + n * lx
    ss_res = float(np.sum((ly - pred) ** 2))
    ss_tot = float(np.sum((ly - ly.mean()) ** 2))
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else float("nan")
    return {"A": float(A), "n": float(n), "r2": r2,
            "n_points_used": int(mask.sum())}


@mcp.tool()
def ising_scaling_prefactor(line_delta_P: list[float], line_T_hat: list[float],
                            beta: float = 0.3265, gamma: float = 1.237,
                            delta_T_window: tuple | list = (0.02, 0.3)) -> dict:
    """Fit |delta_P_hat| = A_P * (T_hat - 1)^(beta+gamma) using 3D Ising
    exponents with beta + gamma as a fixed slope.

    Args:
        line_delta_P: signed delta_P_hat values on L+ or L-.
        line_T_hat: corresponding T_hat peak locations.
        beta, gamma: 3D Ising exponents (defaults: Guida-Zinn-Justin 1998).
        delta_T_window: (min, max) window on Delta_T_hat = T_hat - 1 used for
            the fit (by default 0.02-0.3 - close to the critical point).

    Returns:
        dict with A_P, beta_plus_gamma, r2, n_points.
    """
    dP = np.asarray(line_delta_P, dtype=float)
    T = np.asarray(line_T_hat, dtype=float)
    DT = T - 1.0
    absP = np.abs(dP)
    lo, hi = float(delta_T_window[0]), float(delta_T_window[1])
    fit = fit_power_law(DT.tolist(), absP.tolist(), fix_exponent=beta + gamma,
                        xmin=lo, xmax=hi)
    return {
        "A_P": fit["A"],
        "beta_plus_gamma": beta + gamma,
        "r2": fit["r2"],
        "n_points": fit["n_points_used"],
    }


# ----------------------------------------------------------------------------
# Plotting
# ----------------------------------------------------------------------------
def _save_fig(fig, out_path: str) -> str:
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    fig.savefig(out_path, dpi=150, bbox_inches="tight")
    import matplotlib.pyplot as plt

    plt.close(fig)
    return out_path


@mcp.tool()
def plot_shifted_isotherms(eos_table: dict, line_plus: dict, line_minus: dict,
                           out_path: str, title: str = "") -> str:
    """Plot shifted isothermal EOSs delta_P_hat vs rho_hat with the L+/L-
    locus points (paper Fig. 2B for argon).

    Args:
        eos_table: output of build_eos_table().
        line_plus: output of locate_crossover_lines(branch="plus").
        line_minus: output of locate_crossover_lines(branch="minus").
        out_path: target PNG path (e.g., artifacts/fig_argon_shifted_eos.png).
        title: optional figure title.

    Returns:
        absolute path of the written PNG.
    """
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    T = np.array(eos_table["T_hat"], dtype=float)
    rho = np.array(eos_table["rho_hat"], dtype=float)
    P = np.array(eos_table["P_hat_grid"], dtype=float)
    P_iso = np.array([np.interp(1.0, rho, P[i]) for i in range(len(T))])
    delta = P - P_iso[:, None]
    fig, ax = plt.subplots(figsize=(6.5, 5.2))
    cmap = plt.get_cmap("viridis")
    for i, Tv in enumerate(T):
        col = cmap((Tv - T.min()) / max(1e-9, (T.max() - T.min())))
        ax.plot(rho, delta[i], color=col, lw=0.9, alpha=0.9)
    # L+ / L- points: rho_hat recovered via compute_crossover_density
    rho_plus = compute_crossover_density(eos_table, line_plus)
    rho_minus = compute_crossover_density(eos_table, line_minus)
    ax.plot(rho_plus["rho_hat"], line_plus["delta_P_hat"], "o",
            ms=7, mfc="none", mec="red", mew=1.5, label="L+ locus")
    ax.plot(rho_minus["rho_hat"], line_minus["delta_P_hat"], "s",
            ms=7, mfc="none", mec="blue", mew=1.5, label="L- locus")
    ax.axhline(0, color="k", lw=0.5, ls=":")
    ax.axvline(1, color="k", lw=0.5, ls=":")
    ax.set_xlabel(r"reduced density $\hat\rho = \rho/\rho_c$")
    ax.set_ylabel(r"shifted pressure $\delta\hat P = \hat P - \hat P(\hat\rho=1,\hat T)$")
    ax.set_title(title or "Shifted isothermal EOSs with L+/L- loci")
    ax.legend(loc="upper left", fontsize=9)
    sm = plt.cm.ScalarMappable(cmap=cmap,
                               norm=plt.Normalize(vmin=T.min(), vmax=T.max()))
    cb = fig.colorbar(sm, ax=ax, pad=0.02)
    cb.set_label(r"$\hat T = T/T_c$")
    return _save_fig(fig, out_path)


@mcp.tool()
def plot_universal_scaling(line_data: dict, out_path: str,
                           beta: float = 0.3265, gamma: float = 1.237,
                           title: str = "") -> str:
    """Log-log collapse plot of |delta_P_hat|/A+_P versus Delta_T_hat for one or
    several substances, compared to the 3D Ising scaling exponent beta+gamma.

    Args:
        line_data: dict mapping substance name to
            {"delta_P_hat": [...], "T_hat_peak": [...], "A_P": float} with the
            L+ line data and the fitted prefactor A+_P.
        out_path: target PNG path.
        beta, gamma: 3D Ising exponents.
        title: optional figure title.

    Returns:
        absolute path of the written PNG.
    """
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(6.5, 5.2))
    colors = plt.get_cmap("tab10")
    for i, (name, d) in enumerate(line_data.items()):
        dP = np.abs(np.asarray(d["delta_P_hat"], dtype=float))
        DT = np.asarray(d["T_hat_peak"], dtype=float) - 1.0
        A = float(d.get("A_P", 1.0))
        m = np.isfinite(dP) & np.isfinite(DT) & (DT > 0) & (dP > 0)
        ax.plot(DT[m], dP[m] / A, "o", ms=5, color=colors(i % 10), label=name)
    # reference slope line
    xr = np.geomspace(1e-2, 1.0, 50)
    ax.plot(xr, xr ** (beta + gamma), "k--", lw=1.5,
            label=rf"slope $\beta+\gamma = {beta + gamma:.3f}$")
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlabel(r"$\Delta\hat T = T/T_c - 1$")
    ax.set_ylabel(r"$|\delta\hat P|/A^+_P$")
    ax.set_title(title or "Universal scaling of L+ line (3D Ising)")
    ax.legend(loc="best", fontsize=8)
    ax.grid(True, which="both", ls=":", alpha=0.5)
    return _save_fig(fig, out_path)


@mcp.tool()
def plot_phase_diagram(eos_table: dict, line_plus: dict, line_minus: dict,
                       out_path: str,
                       extra_points: list[dict] | None = None,
                       title: str = "") -> str:
    """Plot the L+ and L- crossover lines in the P_hat - T_hat supercritical
    phase diagram, optionally overlaying external experimental crossover
    points (e.g. the CO2 small-angle-neutron-scattering point at
    (T_hat = 1.046, P_hat = 1.63)).

    For each (T_hat, delta_P_hat) point on the crossover loci, the absolute
    reduced pressure is P_hat = P_hat(rho_hat=1, T_hat) + delta_P_hat where
    P_hat(rho_hat=1, T_hat) is the critical-isochore reduced pressure taken
    from the EOS table.

    Args:
        eos_table: output of build_eos_table() for the relevant substance.
        line_plus: output of locate_crossover_lines(branch="plus").
        line_minus: output of locate_crossover_lines(branch="minus").
        out_path: target PNG path.
        extra_points: list of {label, T_hat, P_hat, marker} dicts to overlay.
        title: optional figure title.

    Returns:
        absolute path of the written PNG.
    """
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    T_grid = np.array(eos_table["T_hat"], dtype=float)
    rho_grid = np.array(eos_table["rho_hat"], dtype=float)
    P_grid = np.array(eos_table["P_hat_grid"], dtype=float)
    P_iso_grid = np.array(
        [np.interp(1.0, rho_grid, P_grid[i]) for i in range(len(T_grid))]
    )

    def _P_iso(T_hat_val: float) -> float:
        return float(np.interp(T_hat_val, T_grid, P_iso_grid))

    fig, ax = plt.subplots(figsize=(6.5, 5.2))
    for line, color, label in [
        (line_plus, "red", "L+ (liquid-like boundary)"),
        (line_minus, "blue", "L- (gas-like boundary)"),
    ]:
        dP = np.asarray(line["delta_P_hat"], dtype=float)
        Tp = np.asarray(line["T_hat_peak"], dtype=float)
        m = np.isfinite(dP) & np.isfinite(Tp)
        P_abs = np.array([_P_iso(t) for t in Tp[m]]) + dP[m]
        # sort by T for line plot
        order = np.argsort(Tp[m])
        ax.plot(Tp[m][order], P_abs[order], "o-", color=color, ms=5, lw=1.3,
                label=label)
    ax.plot([1.0], [1.0], "k*", ms=12, label="critical point")
    if extra_points:
        for pt in extra_points:
            ax.plot(pt["T_hat"], pt["P_hat"], pt.get("marker", "D"),
                    ms=9, mfc="yellow", mec="k", mew=1.3,
                    label=pt.get("label"))
    ax.axhline(1, color="k", lw=0.5, ls=":")
    ax.axvline(1, color="k", lw=0.5, ls=":")
    ax.set_xlabel(r"$\hat T = T/T_c$")
    ax.set_ylabel(r"$\hat P = P/P_c$")
    ax.set_title(title or "Supercritical phase diagram with L+/L- crossover lines")
    ax.legend(loc="best", fontsize=9)
    ax.grid(True, ls=":", alpha=0.5)
    return _save_fig(fig, out_path)


if __name__ == "__main__":
    mcp.run()

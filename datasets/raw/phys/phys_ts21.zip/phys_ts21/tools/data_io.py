#!/usr/bin/env python3
"""
General data loading primitives. CSV / Excel / JSON tabular helpers.
Domain-agnostic — all numerical interpretation happens in solar_pv.py
and plotting.py.
"""

import csv
import json
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("DataIO")


@mcp.tool()
def load_csv(csv_path: str, max_rows: int = 200) -> dict:
    """Load a CSV file and return columns + parsed rows.

    Args:
        csv_path: absolute path to the CSV file
        max_rows: cap on returned rows (default 200)

    Returns:
        dict with columns, total_rows, rows (list of dicts), truncated flag.
    """
    with open(csv_path, newline="") as fh:
        reader = csv.DictReader(fh)
        cols = reader.fieldnames or []
        rows = []
        for r in reader:
            parsed = {}
            for k, v in r.items():
                try:
                    parsed[k] = float(v)
                except (ValueError, TypeError):
                    parsed[k] = v
            rows.append(parsed)
    return {
        "columns": cols,
        "total_rows": len(rows),
        "rows": rows[:max_rows],
        "truncated": len(rows) > max_rows,
    }


@mcp.tool()
def list_csv_columns(csv_path: str) -> dict:
    """Return only the header (column names + first row sample) of a CSV.

    Args:
        csv_path: path to CSV file

    Returns:
        dict with columns and first_row.
    """
    with open(csv_path, newline="") as fh:
        reader = csv.DictReader(fh)
        cols = reader.fieldnames or []
        first = next(reader, None)
    return {"columns": cols, "first_row": first}


@mcp.tool()
def filter_rows(csv_path: str, column: str, value: str) -> dict:
    """Return rows from a CSV where column equals value (string compare).

    Args:
        csv_path: path to CSV
        column: column name to filter on
        value: value to match (case-sensitive string compare)

    Returns:
        dict with matching rows.
    """
    with open(csv_path, newline="") as fh:
        reader = csv.DictReader(fh)
        rows = [r for r in reader if r.get(column) == value]
    return {"n_matches": len(rows), "rows": rows}


@mcp.tool()
def column_to_list(csv_path: str, column: str) -> dict:
    """Extract a single column as a Python list of floats (or strings if not parseable).

    Args:
        csv_path: path to CSV
        column: column name

    Returns:
        dict with values list and dtype tag.
    """
    out = []
    is_numeric = True
    with open(csv_path, newline="") as fh:
        reader = csv.DictReader(fh)
        for r in reader:
            v = r.get(column)
            try:
                out.append(float(v))
            except (ValueError, TypeError):
                out.append(v)
                is_numeric = False
    return {"column": column, "n_values": len(out),
            "dtype": "float" if is_numeric else "string", "values": out}


if __name__ == "__main__":
    mcp.run(transport="stdio")

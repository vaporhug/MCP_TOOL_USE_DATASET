#!/usr/bin/env python3
"""
Solar-cell PV characterisation primitives.

Implements low-level numerical operations that take J-V or EQE arrays
and return scalar PV figures of merit. None of the routines knows
anything about specific devices — they consume sequences of numbers.
"""

import csv
import math
import numpy as np
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("SolarPV")


# ---------------------------------------------------------------- helpers
def _read_two_col(csv_path, x_col, y_col):
    xs, ys = [], []
    with open(csv_path, newline="") as fh:
        reader = csv.DictReader(fh)
        for r in reader:
            try:
                xs.append(float(r[x_col]))
                ys.append(float(r[y_col]))
            except (ValueError, TypeError, KeyError):
                continue
    return np.array(xs), np.array(ys)


# ---------------------------------------------------------------- J-V
@mcp.tool()
def extract_jv_parameters(csv_path: str, voltage_col: str,
                          current_col: str, area_cm2: float = 1.0) -> dict:
    """Extract Voc, Jsc, FF, PCE and Vmp/Jmp from a J-V (or I-V) curve.

    The input is expected to span V in [<=0, >=Voc]. Jsc is taken at V=0
    by linear interpolation; Voc by linear interpolation where current
    crosses zero; FF = Pmax / (Voc * Jsc); PCE = Pmax / Pin where Pin
    = 100 mW/cm^2 for AM 1.5 G.

    Args:
        csv_path:   path to CSV
        voltage_col: voltage column name (mV or V)
        current_col: current density column (mA/cm^2) or current (mA)
        area_cm2:   active area, used only when current is in mA — set
                    to 1.0 for current-density inputs.

    Returns:
        dict with Voc, Jsc, Vmp, Jmp, Pmax, FF, PCE plus units & N points.
    """
    V, J = _read_two_col(csv_path, voltage_col, current_col)
    if V.size < 5:
        return {"error": "fewer than 5 valid (V,J) points"}

    # Detect units: if max|V| > 5, assume millivolts
    is_mV = np.max(np.abs(V)) > 5.0
    V_volts = V / 1000.0 if is_mV else V.copy()

    # If area>1 we treat current_col as raw mA → convert to mA/cm^2
    J_density = J / area_cm2

    # Sort ascending in V
    order = np.argsort(V_volts)
    V_volts = V_volts[order]
    J_density = J_density[order]

    # Jsc at V=0
    Jsc = float(np.interp(0.0, V_volts, J_density))

    # Voc — linear interpolation where J crosses zero (assuming J>0 at V=0)
    sign = np.sign(J_density)
    cross = np.where(np.diff(sign) != 0)[0]
    if cross.size == 0:
        return {"error": "no zero-crossing found in current curve"}
    i = cross[-1]
    v0, v1 = V_volts[i], V_volts[i + 1]
    j0, j1 = J_density[i], J_density[i + 1]
    Voc = float(v0 - j0 * (v1 - v0) / (j1 - j0))

    # Power & Pmax in the [0, Voc] window
    mask = (V_volts >= 0) & (V_volts <= Voc)
    Vp, Jp = V_volts[mask], J_density[mask]
    P = Vp * Jp           # mW/cm^2
    if P.size == 0:
        return {"error": "no points in [0, Voc]"}
    idx = int(np.argmax(P))
    Vmp, Jmp = float(Vp[idx]), float(Jp[idx])
    Pmax = float(P[idx])

    FF = Pmax / (Voc * Jsc) if Voc * Jsc > 0 else float("nan")
    PCE = Pmax / 100.0  # AM 1.5 G = 100 mW/cm^2

    return {
        "Voc_V": round(Voc, 4),
        "Voc_mV": round(Voc * 1000, 1),
        "Jsc_mA_cm2": round(Jsc, 3),
        "Vmp_V": round(Vmp, 4),
        "Jmp_mA_cm2": round(Jmp, 3),
        "Pmax_mW_cm2": round(Pmax, 3),
        "FF": round(FF, 4),
        "FF_percent": round(FF * 100, 2),
        "PCE_percent": round(PCE * 100, 2),
        "n_points": int(V_volts.size),
        "voltage_unit_input": "mV" if is_mV else "V",
    }


# ---------------------------------------------------------------- EQE → Jsc
@mcp.tool()
def integrated_jsc_from_eqe(csv_path: str, wavelength_col: str,
                            eqe_col: str, eqe_in_percent: bool = True) -> dict:
    """Integrate EQE(lambda) against the AM 1.5 G photon flux to get Jsc.

    J_sc = q * integral( EQE(lambda) * Phi_AM15G(lambda) ) dlambda
    The AM 1.5 G photon flux is approximated by the canonical ASTM G173
    spectrum at 100 mW/cm^2. A coarse 41-point reference is shipped with
    the function (300-1100 nm in 20-nm steps) — sufficient for 0.5 mA/cm^2
    accuracy on smooth spectra.

    Args:
        csv_path:        path to EQE CSV
        wavelength_col:  wavelength column (nm)
        eqe_col:         EQE column
        eqe_in_percent:  True if EQE values are in % (otherwise fractional)

    Returns:
        dict with integrated_Jsc_mA_cm2.
    """
    wl, eqe = _read_two_col(csv_path, wavelength_col, eqe_col)
    if wl.size < 3:
        return {"error": "fewer than 3 valid (wl, eqe) points"}
    if eqe_in_percent:
        eqe = eqe / 100.0

    # ASTM G173-03 AM 1.5 G photon flux (#/m^2/s/nm) on a 20-nm grid,
    # interpolated from the canonical 1-nm reference spectrum. Integrating
    # over 300-1100 nm with EQE=1 yields the textbook ~45.2 mA/cm^2.
    wl_ref = np.arange(300, 1101, 20)
    am15g_flux = np.array([
        0.000e+00, 1.321e+17, 6.795e+17, 1.209e+18, 1.527e+18, 2.042e+18,
        2.444e+18, 2.833e+18, 3.700e+18, 4.067e+18, 4.000e+18, 4.183e+18,
        4.282e+18, 4.313e+18, 4.426e+18, 4.488e+18, 4.541e+18, 4.552e+18,
        4.572e+18, 4.584e+18, 4.556e+18, 4.552e+18, 4.522e+18, 4.480e+18,
        4.425e+18, 4.354e+18, 4.264e+18, 4.165e+18, 4.104e+18, 4.027e+18,
        3.964e+18, 3.793e+18, 3.544e+18, 3.301e+18, 3.251e+18, 3.257e+18,
        3.204e+18, 3.152e+18, 3.106e+18, 3.066e+18, 3.007e+18,
    ])

    # Resample EQE onto reference wavelengths
    order = np.argsort(wl)
    wl_s, eqe_s = wl[order], eqe[order]
    eqe_resampled = np.interp(wl_ref, wl_s, eqe_s, left=0.0, right=0.0)

    q = 1.602176634e-19
    # photon flux in /m2/s/nm * eqe(unitless) → A/m^2 after q-integration
    # convert A/m^2 → mA/cm^2 (factor = 0.1)
    integrand = eqe_resampled * am15g_flux
    J_A_per_m2 = q * np.trapz(integrand, wl_ref)
    Jsc = J_A_per_m2 * 0.1  # mA/cm^2
    return {
        "integrated_Jsc_mA_cm2": round(float(Jsc), 3),
        "wavelength_min_nm": float(wl_s.min()),
        "wavelength_max_nm": float(wl_s.max()),
        "n_points": int(wl.size),
    }


# ---------------------------------------------------------------- LUE
@mcp.tool()
def light_utilization_efficiency(pce_percent: float, avt_percent: float) -> dict:
    """Compute the Light Utilization Efficiency (LUE) of a transparent PV.

    LUE [%] = PCE [%] x AVT [%] / 100.

    Args:
        pce_percent: power conversion efficiency in %
        avt_percent: average visible transmittance in %

    Returns:
        dict with LUE in %.
    """
    lue = pce_percent * avt_percent / 100.0
    return {
        "PCE_percent": round(pce_percent, 3),
        "AVT_percent": round(avt_percent, 3),
        "LUE_percent": round(lue, 4),
    }


# ---------------------------------------------------------------- detailed-balance
@mcp.tool()
def shockley_queisser_jsc_limit(bandgap_eV: float,
                                wl_min_nm: float = 300.0,
                                wl_max_nm: float = 1100.0) -> dict:
    """Compute the Shockley-Queisser short-circuit current density limit.

    Integrates the AM 1.5 G photon flux above the bandgap (and within the
    wavelength window) assuming EQE = 1.

    Args:
        bandgap_eV: semiconductor bandgap in eV
        wl_min_nm:  lower integration bound (default 300 nm)
        wl_max_nm:  upper integration bound (default 1100 nm)

    Returns:
        dict with detailed-balance Jsc in mA/cm^2.
    """
    h = 6.62607015e-34
    c = 2.99792458e8
    q = 1.602176634e-19

    wl_ref = np.arange(300, 1101, 20)
    am15g_flux = np.array([
        0.000e+00, 1.321e+17, 6.795e+17, 1.209e+18, 1.527e+18, 2.042e+18,
        2.444e+18, 2.833e+18, 3.700e+18, 4.067e+18, 4.000e+18, 4.183e+18,
        4.282e+18, 4.313e+18, 4.426e+18, 4.488e+18, 4.541e+18, 4.552e+18,
        4.572e+18, 4.584e+18, 4.556e+18, 4.552e+18, 4.522e+18, 4.480e+18,
        4.425e+18, 4.354e+18, 4.264e+18, 4.165e+18, 4.104e+18, 4.027e+18,
        3.964e+18, 3.793e+18, 3.544e+18, 3.301e+18, 3.251e+18, 3.257e+18,
        3.204e+18, 3.152e+18, 3.106e+18, 3.066e+18, 3.007e+18,
    ])

    lambda_g_nm = 1240.0 / bandgap_eV
    upper = min(wl_max_nm, lambda_g_nm)
    mask = (wl_ref >= wl_min_nm) & (wl_ref <= upper)

    J_A_per_m2 = q * np.trapz(am15g_flux[mask], wl_ref[mask])
    Jsc = J_A_per_m2 * 0.1  # mA/cm^2
    return {
        "bandgap_eV": round(bandgap_eV, 4),
        "lambda_g_nm": round(lambda_g_nm, 1),
        "wl_min_nm": float(wl_min_nm),
        "wl_max_nm_effective": round(upper, 1),
        "Jsc_SQ_mA_cm2": round(float(Jsc), 3),
    }


# ---------------------------------------------------------------- module scaling
@mcp.tool()
def series_module_aggregate(per_cell_voc_V: float, per_cell_isc_mA: float,
                            per_cell_FF: float, n_cells: int,
                            interconnect_loss: float = 0.0,
                            per_cell_area_cm2: float | None = None,
                            total_area_cm2: float | None = None,
                            pin_mW_cm2: float = 100.0) -> dict:
    """Predict module-level Voc, Isc, FF, Pmax and PCE for n series cells.

    Ideal series stacking: Voc_module = n * Voc_cell, Isc_module = Isc_cell.
    FF can be reduced by the optional interconnect_loss fraction.

    The module power-conversion efficiency is returned when the illuminated
    area is supplied (either per-cell area times n_cells, or an explicit
    total module area):

        module_PCE_percent = module_Pmax / (total_area_cm2 * pin_mW_cm2) * 100

    Args:
        per_cell_voc_V:  per-cell open-circuit voltage in V
        per_cell_isc_mA: per-cell short-circuit current in mA
        per_cell_FF:     per-cell fill factor (0..1)
        n_cells:         number of series-connected cells
        interconnect_loss: fractional FF loss per interconnect (default 0)
        per_cell_area_cm2: illuminated area of a single unit cell in cm^2
                           (total area = per_cell_area_cm2 * n_cells)
        total_area_cm2:  explicit total illuminated module area in cm^2;
                         overrides per_cell_area_cm2 * n_cells when given
        pin_mW_cm2:      incident power density (default AM1.5G 100 mW/cm^2)

    Returns:
        dict with module_Voc_V, module_Isc_mA, module_FF, module_FF_percent,
        module_Pmax_mW, total_area_cm2 and (when an area is supplied)
        module_PCE_percent.
    """
    Voc_m = n_cells * per_cell_voc_V
    Isc_m = per_cell_isc_mA
    FF_m = per_cell_FF * (1.0 - interconnect_loss * (n_cells - 1))
    Pmax_m = Voc_m * Isc_m * FF_m  # mW
    if total_area_cm2 is None and per_cell_area_cm2 is not None:
        total_area_cm2 = per_cell_area_cm2 * n_cells
    out = {
        "n_cells": int(n_cells),
        "module_Voc_V": round(Voc_m, 3),
        "module_Isc_mA": round(Isc_m, 3),
        "module_FF": round(FF_m, 4),
        "module_FF_percent": round(FF_m * 100, 2),
        "module_Pmax_mW": round(Pmax_m, 3),
    }
    if total_area_cm2 is not None and total_area_cm2 > 0 and pin_mW_cm2 > 0:
        pce = Pmax_m / (total_area_cm2 * pin_mW_cm2) * 100.0
        out["total_area_cm2"] = round(float(total_area_cm2), 4)
        out["module_PCE_percent"] = round(pce, 3)
    return out


# ---------------------------------------------------------------- microhole geometry
@mcp.tool()
def microhole_filling_fraction(diameter_um: float, spacing_um: float,
                               n_holes_per_unit: int = 16,
                               unit_size_um: float = 1000.0) -> dict:
    """Compute the silicon filling fraction f = 1 - (hole_area / unit_area).

    Args:
        diameter_um:      microhole diameter in micrometres
        spacing_um:       inter-hole spacing in micrometres (informational)
        n_holes_per_unit: number of microholes in the square unit cell
        unit_size_um:     length of the square unit cell side (default 1000)

    Returns:
        dict with filling_fraction (0..1), transmittance estimate, hole area.
    """
    hole_area = math.pi * (diameter_um / 2.0) ** 2 * n_holes_per_unit
    unit_area = unit_size_um ** 2
    f = 1.0 - hole_area / unit_area
    transmittance = 1.0 - f  # area-fraction approximation
    return {
        "filling_fraction": round(f, 4),
        "filling_fraction_percent": round(f * 100, 2),
        "estimated_transmittance_percent": round(transmittance * 100, 2),
        "hole_area_um2": round(hole_area, 1),
        "unit_area_um2": round(unit_area, 1),
        "n_holes": int(n_holes_per_unit),
    }


if __name__ == "__main__":
    mcp.run(transport="stdio")

# Tools — phys_ts21 transparent silicon solar cells

Three FastMCP servers exposing low-level numerical primitives for
transparent-photovoltaic characterisation. None of the tools embed
device-specific logic — all interpretation happens by composing them
on the supplied CSV data.

## Modules

- `data_io.py` — generic CSV loading, column extraction, row filtering.
- `solar_pv.py` — J-V parameter extraction, EQE→Jsc integration, Shockley-Queisser limit, light utilisation efficiency, microhole geometry, series-module aggregation.
- `plotting.py` — J-V curve plot, EQE spectra plot, module scaling plot, AVT-PCE benchmarking scatter (one tool per output PNG).

## Dependencies

```
numpy>=1.24
matplotlib>=3.6
mcp>=1.0           # FastMCP server framework
```

Install with:
```
pip install numpy matplotlib mcp
```

## Data note — two distinct module PCE definitions

`Table4_module_series_scaling.csv` `PCE_percent` is the **per-active-area** module efficiency (each n-cell module normalised to its own n cm² aperture). `Fig3H_module_IV_summary.csv` reports `PCE_percent_16cm2_footprint`, the power normalised to the fixed **16 cm² module footprint** (this footprint-normalised value rises as cells are added). The two coincide only when active area equals the footprint (i.e. when the cells fully tile the footprint). Pass `per_cell_area_cm2` (or `total_area_cm2`) to `series_module_aggregate` to choose which normalisation `module_PCE_percent` uses.

## Running a tool server

```
python data_io.py     # stdio transport
python solar_pv.py
python plotting.py
```

## Tool inventory

### data_io.py
- `load_csv(csv_path, max_rows=200)` — read a CSV.
- `list_csv_columns(csv_path)` — header + first row.
- `filter_rows(csv_path, column, value)` — exact-match filter.
- `column_to_list(csv_path, column)` — extract one column as a list.

### solar_pv.py
- `extract_jv_parameters(csv_path, voltage_col, current_col, area_cm2=1.0)` — return Voc, Jsc, Vmp, Jmp, Pmax, FF, PCE.
- `integrated_jsc_from_eqe(csv_path, wavelength_col, eqe_col, eqe_in_percent=True)` — convolve EQE(λ) with AM 1.5 G photon flux to get Jsc.
- `light_utilization_efficiency(pce_percent, avt_percent)` — LUE = PCE × AVT / 100.
- `shockley_queisser_jsc_limit(bandgap_eV, wl_min_nm=300, wl_max_nm=1100)` — SQ Jsc upper bound.
- `series_module_aggregate(per_cell_voc_V, per_cell_isc_mA, per_cell_FF, n_cells, interconnect_loss=0, per_cell_area_cm2=None, total_area_cm2=None, pin_mW_cm2=100)` — ideal series stacking: `module_Voc = n_cells × per_cell_voc`, `module_Isc = per_cell_isc`, `module_FF = per_cell_FF × (1 − interconnect_loss×(n_cells−1))`, and, when an illuminated area is supplied, `module_PCE_percent = module_Pmax / (total_area_cm2 × pin_mW_cm2) × 100`. Example: `series_module_aggregate(per_cell_voc_V=0.6, per_cell_isc_mA=30.0, per_cell_FF=0.80, n_cells=4, per_cell_area_cm2=1.0)`.
- `microhole_filling_fraction(diameter_um, spacing_um, n_holes_per_unit=16, unit_size_um=1000)` — Si filling fraction & estimated transmittance.

### plotting.py (one PNG per call)
- `plot_jv_curves(csv_path, voltage_col, current_cols_json, output_png, title)` — overlay multiple J-V curves.
- `plot_eqe_spectra(csv_path, wavelength_col, eqe_cols_json, output_png, title)` — overlay EQE spectra.
- `plot_module_scaling(csv_path, x_col, y_cols_json, output_png, x_label, title)` — multi-panel parameter vs N-cells.
- `plot_avt_pce_landscape(csv_path, avt_col, pce_col, material_col, highlight_value, output_png, title)` — AVT-vs-PCE scatter with LUE iso-contours.

#!/usr/bin/env python3
"""
Plotting primitives. Each tool consumes a CSV (or list) and writes a
PNG to disk, returning the absolute output path. One tool per output
image.
"""

import csv
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Plotting")


def _read_csv_cols(csv_path, cols):
    out = {c: [] for c in cols}
    with open(csv_path, newline="") as fh:
        reader = csv.DictReader(fh)
        for r in reader:
            for c in cols:
                try:
                    out[c].append(float(r[c]))
                except (ValueError, TypeError, KeyError):
                    out[c].append(None)
    return {c: np.array([v for v in vals if v is not None]) for c, vals in out.items()}


# ---------------------------------------------------------------- J-V
@mcp.tool()
def plot_jv_curves(csv_path: str, voltage_col: str,
                   current_cols_json: str, output_png: str,
                   title: str = "J-V curves under AM 1.5 G") -> dict:
    """Plot one or more J-V curves on a single axes.

    Args:
        csv_path:          path to CSV
        voltage_col:       voltage column name
        current_cols_json: JSON list of current column names, e.g.
                           '["J_ABC_mAcm2","J_Conventional_mAcm2"]'
        output_png:        absolute output PNG path
        title:             plot title

    Returns:
        dict with output_path and curve count.
    """
    import json
    cols = json.loads(current_cols_json)
    data = _read_csv_cols(csv_path, [voltage_col] + cols)
    V = data[voltage_col]
    is_mV = float(np.max(np.abs(V))) > 5.0

    fig, ax = plt.subplots(figsize=(6, 4.5), dpi=140)
    for c in cols:
        J = data[c]
        n = min(len(V), len(J))
        ax.plot(V[:n], J[:n], marker="o", lw=1.6, ms=4, label=c)
    ax.axhline(0, color="k", lw=0.5)
    ax.axvline(0, color="k", lw=0.5)
    ax.set_xlabel(f"Voltage ({'mV' if is_mV else 'V'})")
    ax.set_ylabel("Current density (mA/cm$^2$)")
    ax.set_title(title)
    ax.legend(fontsize=9)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_png), exist_ok=True)
    fig.savefig(output_png)
    plt.close(fig)
    return {"output_path": os.path.abspath(output_png), "n_curves": len(cols)}


# ---------------------------------------------------------------- EQE
@mcp.tool()
def plot_eqe_spectra(csv_path: str, wavelength_col: str,
                     eqe_cols_json: str, output_png: str,
                     title: str = "EQE spectra") -> dict:
    """Plot one or more EQE spectra vs wavelength.

    Args:
        csv_path:        path to CSV
        wavelength_col:  wavelength column name (nm)
        eqe_cols_json:   JSON list of EQE column names
        output_png:      absolute output PNG path
        title:           plot title

    Returns:
        dict with output_path.
    """
    import json
    cols = json.loads(eqe_cols_json)
    data = _read_csv_cols(csv_path, [wavelength_col] + cols)
    wl = data[wavelength_col]

    fig, ax = plt.subplots(figsize=(6, 4.5), dpi=140)
    for c in cols:
        e = data[c]
        n = min(len(wl), len(e))
        ax.plot(wl[:n], e[:n], lw=1.8, label=c)
    ax.set_xlabel("Wavelength (nm)")
    ax.set_ylabel("EQE (%)")
    ax.set_title(title)
    ax.set_xlim([300, 1100])
    ax.set_ylim([0, 100])
    ax.legend(fontsize=9)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_png), exist_ok=True)
    fig.savefig(output_png)
    plt.close(fig)
    return {"output_path": os.path.abspath(output_png)}


# ---------------------------------------------------------------- module scaling
@mcp.tool()
def plot_module_scaling(csv_path: str, x_col: str,
                        y_cols_json: str, output_png: str,
                        x_label: str = "Number of cells",
                        title: str = "Module scaling") -> dict:
    """Plot module performance vs number of series-connected cells.

    Args:
        csv_path:    path to CSV (e.g. Table4_module_series_scaling.csv)
        x_col:       independent variable (e.g. N_cells)
        y_cols_json: JSON list of dependent columns, e.g.
                     '["Voc_V","Isc_mA","FF_percent","PCE_percent"]'
        output_png:  output PNG path
        x_label:     x-axis label
        title:       plot title

    Returns:
        dict with output_path.
    """
    import json
    ycols = json.loads(y_cols_json)
    data = _read_csv_cols(csv_path, [x_col] + ycols)
    x = data[x_col]

    n = len(ycols)
    fig, axes = plt.subplots(1, n, figsize=(3.6 * n, 3.6), dpi=140)
    if n == 1:
        axes = [axes]
    for ax, c in zip(axes, ycols):
        y = data[c]
        m = min(len(x), len(y))
        ax.plot(x[:m], y[:m], "o-", lw=1.8, ms=7, color="#1f77b4")
        ax.set_xlabel(x_label)
        ax.set_ylabel(c)
        ax.grid(alpha=0.3)
    fig.suptitle(title, fontsize=12)
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_png), exist_ok=True)
    fig.savefig(output_png)
    plt.close(fig)
    return {"output_path": os.path.abspath(output_png)}


# ---------------------------------------------------------------- AVT–PCE benchmarking
@mcp.tool()
def plot_avt_pce_landscape(csv_path: str, avt_col: str, pce_col: str,
                           material_col: str, highlight_value: str,
                           output_png: str,
                           title: str = "AVT vs PCE (literature)") -> dict:
    """Scatter plot of AVT (x) vs PCE (y) coloured by material, with one
    point highlighted.

    Args:
        csv_path:        path to literature CSV (TableS2_AVT_PCE_LUE_*.csv)
        avt_col:         AVT column name
        pce_col:         PCE column name
        material_col:    column whose values define the marker colour group
        highlight_value: value in material_col to highlight in red star
        output_png:      output PNG path
        title:           plot title

    Returns:
        dict with output_path.
    """
    avts, pces, mats = [], [], []
    with open(csv_path, newline="") as fh:
        reader = csv.DictReader(fh)
        for r in reader:
            try:
                avts.append(float(r[avt_col]))
                pces.append(float(r[pce_col]))
                mats.append(r[material_col])
            except (ValueError, TypeError, KeyError):
                continue
    avts = np.array(avts); pces = np.array(pces); mats = np.array(mats)

    fig, ax = plt.subplots(figsize=(6.2, 4.6), dpi=140)
    uniq = sorted(set(mats))
    cmap = plt.cm.tab10
    for i, m in enumerate(uniq):
        mask = mats == m
        if m == highlight_value:
            ax.scatter(avts[mask], pces[mask], s=200, c="red", marker="*",
                       label=m + " (this work)", edgecolor="k", zorder=5)
        else:
            ax.scatter(avts[mask], pces[mask], s=70, c=[cmap(i % 10)],
                       label=m, alpha=0.85, edgecolor="k")

    # Constant LUE contours
    avt_grid = np.linspace(1, 60, 100)
    for lue in [1, 2, 3, 4]:
        pce_curve = lue * 100.0 / avt_grid
        ax.plot(avt_grid, pce_curve, "--", color="grey", alpha=0.5, lw=0.8)
        ax.text(58, lue * 100 / 58, f"LUE={lue}%", fontsize=8, color="grey",
                ha="right")

    ax.set_xlabel("AVT (%)")
    ax.set_ylabel("PCE (%)")
    ax.set_title(title)
    ax.set_xlim([0, 60])
    ax.set_ylim([0, 22])
    ax.legend(fontsize=8, loc="upper right", ncol=2)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_png), exist_ok=True)
    fig.savefig(output_png)
    plt.close(fig)
    return {"output_path": os.path.abspath(output_png)}


if __name__ == "__main__":
    mcp.run(transport="stdio")

# phys_or36 - Tool Reference

Indoor organic photovoltaics (IOPV) tools for spectral integration, J-V parameter
extraction, illuminance / energy-yield aggregation, and plot generation.

## Indoor PV Analysis (`indoor_pv_analysis.py`)

- **list_excel_sheets**: List sheet names in an .xlsx file with row/column counts.
- **load_spectrum_sheet**: Load a spectral irradiance table (wavelength + named series) from one sheet.
- **spectral_to_illuminance**: Photopic-weighted integration of a spectral irradiance curve to lux.
- **integrate_spectrum_window**: Trapezoidal integration of a curve over a wavelength window.
- **jv_extract_parameters**: Extract Voc, Isc/Jsc, FF, Pmax, Vmpp, Impp from a J-V sweep.
- **pce_from_pmax**: Compute PCE from Pmax, incident irradiance and cell area.
- **jsc_from_eqe**: Predicted Jsc (mA/cm^2) for a given EQE(lambda) under a given source spectrum.
- **time_series_summary**: Mean / median / percentiles / fraction-above-threshold for one channel.
- **aggregate_channels_from_excel**: Per-channel time-series summary stats for one sheet.
- **energy_yield**: Convert PV power output (uW) and operating hours/week to mWh/week and mWh/day.
- **relative_loss**: Compute per-entry percentage loss versus a reference value.
- **plot_spectra**: Multi-line plot for spectral data, returns the saved PNG path.
- **plot_time_series**: Multi-line plot for time-series data, returns the saved PNG path.
- **plot_grouped_bars**: Grouped bar chart with optional error bars, returns the saved PNG path.
- **plot_angle_dependence**: Two-panel plot for angle sweeps at two geometries.

## Data Processing (`data_processing.py`)

- **read_csv / write_csv**: List-of-dicts CSV I/O.
- **read_json / write_json**: JSON I/O.
- **read_excel / read_parquet / read_netcdf / read_shapefile**: Heavy-format readers (pandas / pyarrow / xarray / geopandas).
- **read_fasta**: FASTA sequence reader.
- **pivot_long_to_wide / pivot_wide_to_long**: Reshape helpers.
- **drop_missing / coerce_numeric**: Data cleaning.
- **join_tables / groupby_aggregate**: SQL-style joins and group aggregations.

## Database Retrieval (`database_retrieval.py`)

Generic web-search and DOI / OpenAlex / Crossref / PubChem / ChEMBL / UniProt / PDB
helpers. Imported from the geo_gw01 template; not exercised by this task but provided
for completeness when the agent wants to look up upstream sources.

## Dependencies

```
numpy >= 1.20
matplotlib >= 3.5
openpyxl >= 3.1
mcp[cli] >= 1.0       # FastMCP server runtime
scipy >= 1.10         # used by the imported template tools
pandas >= 1.5         # read_excel / load_excel helpers
```

Install with:

```
pip install numpy matplotlib openpyxl scipy pandas "mcp[cli]"
```

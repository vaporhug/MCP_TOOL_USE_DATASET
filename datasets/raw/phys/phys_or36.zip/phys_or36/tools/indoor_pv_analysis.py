#!/usr/bin/env python3
"""Domain primitives for indoor photovoltaics: spectral integration, J-V parameter
extraction, illuminance / energy-yield aggregation, and plot generation.

All numerical routines are runnable. No `pass`-stub bodies.
"""

import os
import json
import numpy as np
from datetime import datetime, timedelta
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Indoor_PV_Tools")

# Photopic luminous-efficiency function V(lambda), 5-nm grid 380-780 nm,
# CIE 1924 standard. Used to convert spectral irradiance (W m^-2 nm^-1) to
# illuminance (lux) and to compare a measured spectrum to an illuminance reading.
_PHOTOPIC_WL = np.arange(380, 781, 5)
_PHOTOPIC_V = np.array([
    0.000039, 0.000064, 0.000120, 0.000217, 0.000396, 0.000640, 0.001210,
    0.002180, 0.004000, 0.007300, 0.011600, 0.016840, 0.023000, 0.029800,
    0.038000, 0.048000, 0.060000, 0.073900, 0.090980, 0.112600, 0.139020,
    0.169300, 0.208020, 0.258600, 0.323000, 0.407300, 0.503000, 0.608200,
    0.710000, 0.793200, 0.862000, 0.914850, 0.954000, 0.980300, 0.994950,
    1.000000, 0.995000, 0.978600, 0.952000, 0.915400, 0.870000, 0.816300,
    0.757000, 0.694900, 0.631000, 0.566800, 0.503000, 0.441200, 0.381000,
    0.321000, 0.265000, 0.217000, 0.175000, 0.138200, 0.107000, 0.081600,
    0.061000, 0.044580, 0.032000, 0.023200, 0.017000, 0.011920, 0.008210,
    0.005723, 0.004102, 0.002929, 0.002091, 0.001484, 0.001047, 0.000740,
    0.000520, 0.000361, 0.000249, 0.000172, 0.000120, 0.000085, 0.000060,
    0.000042, 0.000030, 0.000021, 0.000015,
])
_KM = 683.0  # lm/W maximum luminous efficacy at 555 nm

# numpy 1.x calls it `trapz`, numpy 2.x renamed it `trapezoid`. Provide both.
_trapz = getattr(np, "trapezoid", None) or getattr(np, "trapz")


def _load_excel_sheet(xlsx_path: str, sheet: str):
    import openpyxl
    wb = openpyxl.load_workbook(xlsx_path, read_only=True, data_only=True)
    if sheet not in wb.sheetnames:
        raise ValueError(f"Sheet '{sheet}' not found. Available: {wb.sheetnames}")
    return list(wb[sheet].iter_rows(values_only=True))


@mcp.tool()
def list_excel_sheets(xlsx_path: str) -> dict:
    """List all sheet names in an .xlsx file with row/column counts."""
    import openpyxl
    wb = openpyxl.load_workbook(xlsx_path, read_only=True, data_only=True)
    out = []
    for s in wb.sheetnames:
        ws = wb[s]
        out.append({"name": s, "rows": ws.max_row, "cols": ws.max_column})
    return {"path": xlsx_path, "n_sheets": len(out), "sheets": out}


@mcp.tool()
def load_spectrum_sheet(xlsx_path: str, sheet: str, wavelength_col: int = 0) -> dict:
    """Load a spectral irradiance table from one Excel sheet.

    Returns a dict with `wavelength` (nm), `column_names`, and a list of
    `series` (each with name + values). Header rows are auto-detected by
    finding the first numeric value in the wavelength column.
    """
    rows = _load_excel_sheet(xlsx_path, sheet)
    # Detect header row: the row immediately above the first numeric in wavelength col.
    header_row_idx = None
    data_start = None
    for i, r in enumerate(rows):
        v = r[wavelength_col] if wavelength_col < len(r) else None
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            data_start = i
            header_row_idx = i - 1
            break
    if data_start is None:
        return {"error": "no numeric wavelength data found"}
    header = rows[header_row_idx] if header_row_idx is not None and header_row_idx >= 0 else None
    column_names = [str(c) if c is not None else f"col_{j}" for j, c in enumerate(header)] if header else \
        [f"col_{j}" for j in range(len(rows[data_start]))]
    wl = []
    series = {n: [] for j, n in enumerate(column_names) if j != wavelength_col}
    name_by_idx = {j: n for j, n in enumerate(column_names) if j != wavelength_col}
    for r in rows[data_start:]:
        v = r[wavelength_col] if wavelength_col < len(r) else None
        if not isinstance(v, (int, float)):
            continue
        wl.append(float(v))
        for j, name in name_by_idx.items():
            x = r[j] if j < len(r) else None
            try:
                series[name].append(float(x))
            except (TypeError, ValueError):
                series[name].append(0.0)
    return {
        "sheet": sheet,
        "wavelength_nm": wl,
        "column_names": [n for j, n in name_by_idx.items()],
        "series": {k: v for k, v in series.items()},
        "n_points": len(wl),
    }


@mcp.tool()
def spectral_to_illuminance(wavelength_nm: list, irradiance_w_m2_nm: list) -> dict:
    """Integrate a spectral irradiance curve against the CIE 1924 V(lambda)
    photopic curve to compute illuminance (lux).

    Inputs:
        wavelength_nm     : monotonically increasing wavelengths in nm
        irradiance_w_m2_nm: spectral irradiance W m^-2 nm^-1 at each wavelength

    Returns illuminance in lux and the integrated irradiance in W m^-2.
    """
    wl = np.asarray(wavelength_nm, dtype=float)
    e = np.asarray(irradiance_w_m2_nm, dtype=float)
    # Interpolate V(lambda) onto the input grid; zero outside the photopic range.
    v = np.interp(wl, _PHOTOPIC_WL, _PHOTOPIC_V, left=0.0, right=0.0)
    # Trapezoidal integration of E*V*Km dλ
    illuminance = float(_KM * _trapz(e * v, wl))
    irradiance_total = float(_trapz(e, wl))
    return {
        "illuminance_lux": round(illuminance, 3),
        "irradiance_W_m2": round(irradiance_total, 6),
        "wavelength_range_nm": [float(wl.min()), float(wl.max())],
        "n_points": int(wl.size),
    }


@mcp.tool()
def integrate_spectrum_window(wavelength_nm: list, values: list,
                              wl_min: float, wl_max: float) -> dict:
    """Trapezoidal integration of a (wavelength, value) pair over [wl_min, wl_max]."""
    wl = np.asarray(wavelength_nm, dtype=float)
    y = np.asarray(values, dtype=float)
    mask = (wl >= wl_min) & (wl <= wl_max)
    if mask.sum() < 2:
        return {"error": "fewer than 2 points in window", "n_in_window": int(mask.sum())}
    integral = float(_trapz(y[mask], wl[mask]))
    return {
        "wl_min": wl_min,
        "wl_max": wl_max,
        "integral": integral,
        "n_in_window": int(mask.sum()),
    }


@mcp.tool()
def jv_extract_parameters(voltage_V: list, current_A: list,
                          area_cm2: float = 1.0) -> dict:
    """Extract V_oc, I_sc / J_sc, FF, and P_max from a single-sweep J-V curve.

    Args:
        voltage_V : applied bias (V), monotonic
        current_A : measured current (A), with same sign convention used
                    throughout the sweep (positive in the photovoltaic quadrant)
        area_cm2  : illuminated area (cm^2). Used to compute J_sc.

    Returns Voc (V), Isc (A), Jsc (A/cm^2 and mA/cm^2), Pmax (W and µW),
    Vmpp (V), Impp (A), and FF (-).
    """
    V = np.asarray(voltage_V, dtype=float)
    I = np.asarray(current_A, dtype=float)
    order = np.argsort(V)
    V = V[order]; I = I[order]
    # Voc: voltage where I crosses zero (linear interpolation)
    voc = None
    for k in range(len(V) - 1):
        if I[k] * I[k+1] <= 0 and (I[k] != I[k+1]):
            voc = float(V[k] - I[k] * (V[k+1] - V[k]) / (I[k+1] - I[k]))
            break
    if voc is None:
        voc = float(V[np.argmin(np.abs(I))])
    # Isc: current at V=0 (linear interpolation)
    isc = float(np.interp(0.0, V, I))
    # Power = V * I (in PV quadrant, with sign convention where I > 0 generates power)
    P = V * I
    idx = int(np.argmax(P))
    pmax = float(P[idx]); vmpp = float(V[idx]); impp = float(I[idx])
    ff = float(pmax / (voc * isc)) if voc > 0 and isc > 0 else float('nan')
    return {
        "Voc_V": round(voc, 6),
        "Isc_A": round(isc, 9),
        "Jsc_A_per_cm2": round(isc / area_cm2, 9),
        "Jsc_mA_per_cm2": round(isc / area_cm2 * 1e3, 6),
        "Pmax_W": round(pmax, 9),
        "Pmax_uW": round(pmax * 1e6, 4),
        "Vmpp_V": round(vmpp, 6),
        "Impp_A": round(impp, 9),
        "FF": round(ff, 4),
        "area_cm2": area_cm2,
        "n_points": int(V.size),
    }


@mcp.tool()
def pce_from_pmax(pmax_W: float, irradiance_W_m2: float, area_cm2: float) -> dict:
    """Compute power-conversion efficiency from P_max, incident irradiance and area.

    PCE = P_max / (E_in * A) , with A converted from cm^2 to m^2.
    """
    A_m2 = area_cm2 * 1e-4
    p_in = irradiance_W_m2 * A_m2
    pce = pmax_W / p_in if p_in > 0 else float('nan')
    return {
        "pmax_W": pmax_W,
        "irradiance_W_m2": irradiance_W_m2,
        "area_cm2": area_cm2,
        "p_incident_W": p_in,
        "PCE": pce,
        "PCE_percent": round(pce * 100, 4),
    }


@mcp.tool()
def jsc_from_eqe(wavelength_nm: list, eqe: list,
                 spectrum_wl_nm: list, spectrum_irradiance_W_m2_nm: list) -> dict:
    """Predicted J_sc (mA/cm^2) for a given EQE(λ) under a given source spectrum.

    J_sc = (q / hc) * ∫ EQE(λ) * E(λ) * λ dλ
    Returns J_sc in both A/m^2 and mA/cm^2.
    """
    h = 6.62607015e-34; c = 2.99792458e8; q = 1.602176634e-19
    wl_e = np.asarray(spectrum_wl_nm, dtype=float)
    e = np.asarray(spectrum_irradiance_W_m2_nm, dtype=float)
    # Interpolate EQE onto the spectrum grid (zero outside the EQE range)
    eqe_interp = np.interp(wl_e, np.asarray(wavelength_nm, dtype=float),
                           np.asarray(eqe, dtype=float), left=0.0, right=0.0)
    integrand = eqe_interp * e * (wl_e * 1e-9) / (h * c)  # photons s^-1 m^-2 nm^-1
    flux = _trapz(integrand, wl_e)  # photons s^-1 m^-2
    jsc_A_m2 = q * flux
    return {
        "Jsc_A_per_m2": float(jsc_A_m2),
        "Jsc_mA_per_cm2": round(float(jsc_A_m2) * 0.1, 6),
        "wavelength_range_nm": [float(wl_e.min()), float(wl_e.max())],
    }


@mcp.tool()
def time_series_summary(timestamps: list, values: list, drop_zero: bool = False) -> dict:
    """Mean / median / percentiles / fraction-above-threshold for a single channel."""
    v = np.asarray([x for x in values if x is not None], dtype=float)
    v = v[~np.isnan(v)]
    if drop_zero:
        v = v[v > 0]
    if v.size == 0:
        return {"n": 0, "error": "no valid values"}
    return {
        "n": int(v.size),
        "mean": round(float(v.mean()), 4),
        "median": round(float(np.median(v)), 4),
        "std": round(float(v.std()), 4),
        "min": round(float(v.min()), 4),
        "max": round(float(v.max()), 4),
        "p10": round(float(np.percentile(v, 10)), 4),
        "p25": round(float(np.percentile(v, 25)), 4),
        "p75": round(float(np.percentile(v, 75)), 4),
        "p90": round(float(np.percentile(v, 90)), 4),
        "frac_gt_100": round(float((v > 100).mean()), 4),
        "frac_gt_500": round(float((v > 500).mean()), 4),
    }


@mcp.tool()
def aggregate_channels_from_excel(xlsx_path: str, sheet: str,
                                  time_col: int = 0) -> dict:
    """Compute per-channel time-series summaries for one sheet of the dataset.

    Returns per-column mean / median / max / fraction-above-threshold.
    """
    rows = _load_excel_sheet(xlsx_path, sheet)
    # Find header row: first row without datetime in time_col
    header_row_idx = None
    data_start_idx = None
    for i, r in enumerate(rows):
        if i >= len(rows): break
        v = r[time_col] if time_col < len(r) else None
        if isinstance(v, datetime):
            data_start_idx = i
            header_row_idx = i - 1 if i > 0 else 0
            break
    if data_start_idx is None:
        return {"error": "no datetime rows found"}
    header = rows[header_row_idx]
    cols = [str(c) if c is not None else f"col_{j}" for j, c in enumerate(header)]
    series = {c: [] for j, c in enumerate(cols) if j != time_col}
    by_idx = {j: c for j, c in enumerate(cols) if j != time_col}
    for r in rows[data_start_idx:]:
        if time_col >= len(r): continue
        if not isinstance(r[time_col], datetime): continue
        for j, name in by_idx.items():
            v = r[j] if j < len(r) else None
            try:
                series[name].append(float(v))
            except (TypeError, ValueError):
                pass
    out = {}
    for name, vals in series.items():
        v = np.asarray(vals, dtype=float)
        v = v[~np.isnan(v)]
        if v.size == 0:
            out[name] = {"n": 0}
            continue
        out[name] = {
            "n": int(v.size),
            "mean": round(float(v.mean()), 4),
            "median": round(float(np.median(v)), 4),
            "max": round(float(v.max()), 4),
            "p10": round(float(np.percentile(v, 10)), 4),
            "p90": round(float(np.percentile(v, 90)), 4),
            "frac_gt_100": round(float((v > 100).mean()), 4),
            "frac_gt_500": round(float((v > 500).mean()), 4),
        }
    return {"sheet": sheet, "channels": out}


@mcp.tool()
def energy_yield(power_uW: float, hours_per_week: float,
                 conversion_efficiency: float = 0.9) -> dict:
    """Convert a steady PV power output (in microwatts) to weekly / daily energy
    available to downstream IoT electronics, given the harvester's conversion
    efficiency. All output in mWh.
    """
    p_useable_uW = power_uW * conversion_efficiency
    e_week_uWh = p_useable_uW * hours_per_week
    return {
        "power_uW": power_uW,
        "useable_power_uW": round(p_useable_uW, 3),
        "hours_per_week": hours_per_week,
        "energy_uWh_per_week": round(e_week_uWh, 3),
        "energy_mWh_per_week": round(e_week_uWh / 1000, 3),
        "energy_mWh_per_day": round(e_week_uWh / 1000 / 7, 3),
    }


@mcp.tool()
def relative_loss(reference: float, observed_list: list,
                  labels: list = None) -> dict:
    """Return per-entry percentage loss relative to a reference value:
    100 * (reference - observed) / reference.
    """
    obs = np.asarray(observed_list, dtype=float)
    loss = 100.0 * (reference - obs) / reference
    labels = list(labels) if labels else [f"item_{i}" for i in range(len(obs))]
    return {
        "reference": reference,
        "results": [{"label": labels[i], "value": float(obs[i]),
                     "loss_pct": round(float(loss[i]), 4)} for i in range(len(obs))],
    }


@mcp.tool()
def plot_spectra(wavelength_nm: list, series: dict, output_path: str,
                 title: str = "Spectral irradiance",
                 xlabel: str = "Wavelength (nm)",
                 ylabel: str = "Spectral irradiance (W m$^{-2}$ nm$^{-1}$)",
                 xlim: list = None) -> dict:
    """Multi-line plot for spectral data. `series` is {label: [values...]}."""
    import matplotlib.pyplot as plt
    wl = np.asarray(wavelength_nm, dtype=float)
    fig, ax = plt.subplots(figsize=(7, 4.5), dpi=130)
    for lab, vals in series.items():
        ax.plot(wl, np.asarray(vals, dtype=float), lw=1.2, label=str(lab))
    if xlim is not None:
        ax.set_xlim(xlim[0], xlim[1])
    ax.set_xlabel(xlabel); ax.set_ylabel(ylabel); ax.set_title(title)
    ax.grid(True, alpha=0.3); ax.legend(frameon=False, fontsize=9)
    fig.tight_layout(); os.makedirs(os.path.dirname(output_path), exist_ok=True)
    fig.savefig(output_path); plt.close(fig)
    return {"path": output_path, "n_series": len(series), "n_points": int(wl.size)}


@mcp.tool()
def plot_time_series(timestamps: list, series: dict, output_path: str,
                     title: str = "Time series", ylabel: str = "Value",
                     log_y: bool = False) -> dict:
    """Multi-line plot for time series (timestamps as ISO strings or datetime)."""
    import matplotlib.pyplot as plt
    ts = []
    for t in timestamps:
        if isinstance(t, datetime):
            ts.append(t)
        else:
            try:
                ts.append(datetime.fromisoformat(str(t)))
            except (TypeError, ValueError):
                ts.append(None)
    ts = np.array(ts)
    fig, ax = plt.subplots(figsize=(8, 4.5), dpi=130)
    for lab, vals in series.items():
        ax.plot(ts, np.asarray(vals, dtype=float), lw=0.8, label=str(lab))
    if log_y:
        ax.set_yscale('log')
    ax.set_xlabel('Date / time'); ax.set_ylabel(ylabel); ax.set_title(title)
    ax.legend(fontsize=8, frameon=False)
    ax.grid(True, alpha=0.3, which='both')
    fig.autofmt_xdate(); fig.tight_layout()
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    fig.savefig(output_path); plt.close(fig)
    return {"path": output_path, "n_series": len(series), "n_points": len(ts)}


@mcp.tool()
def plot_grouped_bars(categories: list, groups: dict, output_path: str,
                      errors: dict = None, ylabel: str = "Value",
                      title: str = "Grouped bars", colors: list = None) -> dict:
    """Grouped bar chart. `groups` = {label: [values_per_category...]}; `errors`
    optional matching dict of standard deviations or 1-sigma bars.
    """
    import matplotlib.pyplot as plt
    n_cat = len(categories); n_grp = len(groups)
    x = np.arange(n_cat); w = 0.8 / max(n_grp, 1)
    fig, ax = plt.subplots(figsize=(7, 4.5), dpi=130)
    for i, (lab, vals) in enumerate(groups.items()):
        err = errors.get(lab) if errors else None
        c = colors[i] if colors and i < len(colors) else None
        ax.bar(x + (i - (n_grp - 1) / 2) * w, vals, w, yerr=err,
               label=str(lab), capsize=3, color=c)
    ax.set_xticks(x); ax.set_xticklabels(categories)
    ax.set_ylabel(ylabel); ax.set_title(title)
    ax.legend(frameon=False); ax.grid(True, axis='y', alpha=0.3)
    fig.tight_layout(); os.makedirs(os.path.dirname(output_path), exist_ok=True)
    fig.savefig(output_path); plt.close(fig)
    return {"path": output_path, "n_groups": n_grp, "n_categories": n_cat}


@mcp.tool()
def plot_angle_dependence(angle_deg: list, series_low: dict, series_high: dict,
                          output_path: str,
                          title: str = "Illuminance vs PV tilt angle",
                          ylabel: str = "Illuminance (lux)") -> dict:
    """Two-panel plot of two angle sweeps for the same device geometry."""
    import matplotlib.pyplot as plt
    ang = np.asarray(angle_deg, dtype=float)
    fig, axs = plt.subplots(1, 2, figsize=(10, 4.2), dpi=130, sharey=True)
    for lab, vals in series_low.items():
        axs[0].plot(ang, vals, lw=1.2, label=str(lab))
    axs[0].set_xlabel('Angle from wall (deg)'); axs[0].set_ylabel(ylabel)
    axs[0].set_title('Low panel'); axs[0].legend(fontsize=8, frameon=False)
    axs[0].grid(True, alpha=0.3)
    for lab, vals in series_high.items():
        axs[1].plot(ang, vals, lw=1.2, label=str(lab))
    axs[1].set_xlabel('Angle from wall (deg)')
    axs[1].set_title('High panel'); axs[1].legend(fontsize=8, frameon=False)
    axs[1].grid(True, alpha=0.3)
    fig.suptitle(title, y=1.02); fig.tight_layout()
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    fig.savefig(output_path, bbox_inches='tight'); plt.close(fig)
    return {"path": output_path, "n_angles": int(ang.size)}


@mcp.tool()
def load_time_series_sheet(xlsx_path: str, sheet: str,
                            timestamp_col: int = 0) -> dict:
    """Load an Excel sheet of office-time-series data into reusable timestamps + named channels.

    Reads the named sheet from `xlsx_path` via pd.read_excel. The first column
    (`timestamp_col`) is the timestamps; remaining columns are named per the sheet header.
    Each returned channel can be passed directly to plot_time_series.

    Args:
        xlsx_path: path to .xlsx workbook.
        sheet: sheet name.
        timestamp_col: index of the timestamp column (default 0).

    Returns:
        dict with keys 'timestamps' (list), 'channels' (dict of {name: list[float]}), 'sheet'.
    """
    import pandas as pd
    df = pd.read_excel(xlsx_path, sheet_name=sheet)
    ts_col = df.columns[timestamp_col]
    timestamps = df[ts_col].astype(str).tolist()
    channels = {str(c): pd.to_numeric(df[c], errors='coerce').tolist() for c in df.columns if c != ts_col}
    return {'sheet': sheet, 'timestamps': timestamps, 'channels': channels}


@mcp.tool()
def load_excel_table(xlsx_path: str, sheet: str,
                      header_row: int = 0) -> dict:
    """Load an Excel sheet as a generic table (e.g., the coloured-wall Pmax-loss table).

    Reads the named sheet from `xlsx_path` and returns its columns as named lists.
    Use this for non-spectral / non-time-series sheets such as the Figure-5(f)
    coloured-wall Pmax table.

    Args:
        xlsx_path: path to .xlsx workbook.
        sheet: sheet name.
        header_row: row index of the column headers (default 0).

    Returns:
        dict with 'sheet', 'columns' (list of column names), and 'data'
        ({column_name: list of cell values}).
    """
    import pandas as pd
    df = pd.read_excel(xlsx_path, sheet_name=sheet, header=header_row)
    return {
        'sheet': sheet,
        'columns': df.columns.tolist(),
        'data': {c: df[c].tolist() for c in df.columns},
    }



if __name__ == "__main__":
    mcp.run(transport="stdio")

# phys_hb23 — Extreme thermal conductivity in isotopic hBN

## Source paper
- **Title**: Extreme longitudinal thermal conductivity and non-diffusive heat
  transport in isotopic hBN
- **Authors**: C. Brochard-Richard, G. Di Berardino, E. Herth, C. Wei, F.
  Panciera, T. Poirier, J. H. Edgar, B. Gil, G. Cassabois, M. L. Della Rocca,
  S. Sarkar, N. Bendiab, L. Marty, F. Oehler, A. Ouerghi, J. Chaste
- **Journal**: Nature Communications **17**, 3352 (2 March 2026)
- **DOI**: 10.1038/s41467-026-69907-x — https://www.nature.com/articles/s41467-026-69907-x

This is the published Nature Communications version (received 28-Aug-2025,
accepted 12-Feb-2026, published 02-Mar-2026), not a preprint.

## Data availability
Per the journal: "Data that support the findings of this study are available
from the corresponding author. There are no restrictions to accessing data.
The Comsol simulation are provided in the Supplementary Information section.
Source data are provided with this paper."

The published "Source Data" deposit (`MOESM3_ESM.zip`) is the COMSOL `.mph`
binary used for the paper's finite-element fits. The bundled CSVs are
derived from the published article and its Supplementary Information PDFs:
the Raman temperature-coefficient table from the Methods section; the HS1
multi-point Raman thermometry from Supplementary Figure S4-12; the HS2
longitudinal T(x) along the 9 µm suspended span as a hand-digitised trace
of the V = 8 V curve in main-text Figure 4a plus a V = 0 V baseline (per-
figure xy-source-data for the multi-voltage Figure 4b–g panels were not
deposited for this article); the literature in-plane-k landscape from
Supplementary Table S12b (with this_work rows removed so they do not leak
the present samples' k values); sample-geometry metadata; and an
Si k(T) reference column. All numerical content cited in any grading
narrative is sourced from `target.pdf` (the published article and its
Supplementary Information).

## Layout
```
phys_hb23/
|-- task_content/
|   `-- task_content.json
|-- input_data/
|   |-- reference_paper/
|   |   `-- target.pdf
|   `-- data/
|       |-- SI_Information.pdf            (published Supplementary Information)
|       |-- SI_PeerReview.pdf             (peer review file)
|       |-- SourceData.zip                (COMSOL .mph deposit)
|       |-- comsol/                       (unzipped COMSOL files)
|       `-- sample_data/
|           |-- raman_calibration_paper.csv
|           |-- HS1_temperature_table_S4_12.csv
|           |-- HS2_temperature_profile_Fig4a.csv
|           |-- sample_geometry.csv
|           |-- Si_thermal_conductivity_T.csv
|           `-- literature_in_plane_k_hBN_table_S12b.csv
|-- tools/
|   |-- thermal_transport.py              (domain primitives, FastMCP)
|   |-- data_processing.py                (generic file I/O)
|   `-- database_retrieval.py             (filesystem inspection)
`-- artifacts/                            (agent writes its three answer-path
                                           PNGs here at solve time —
                                           Fig1_raman_calibration.png,
                                           Fig2_temperature_profile.png,
                                           Fig3_literature_comparison.png)
```

## Tooling — `tools/thermal_transport.py`
Each function is decorated with `@mcp.tool()` and runs as a FastMCP server.
The functions are physics primitives, not problem-specific solvers:

| Function                              | Purpose                                                           |
|---------------------------------------|-------------------------------------------------------------------|
| `fit_raman_calibration`               | linear omega(T) = omega_0 + chi T fit                             |
| `temperature_from_raman_shift`        | invert the calibration to T from a measured shift                 |
| `stokes_anti_stokes_temperature`      | absolute T from I_AS/I_S intensity ratio                          |
| `fit_linear_profile`                  | T(x) linear regression                                            |
| `fit_power_law_profile`               | T(x) = [...] for k(T) = c T^alpha                                 |
| `fourier_two_point_conductivity`      | k = P L / (Delta T A)                                             |
| `thermal_impedance_divider`           | Z_2D from Z_ref and the two delta T values                        |
| `average_temperature_per_segment`     | per-region mean of a Raman line scan                              |
| `thermal_diffusion_length`            | L_th = sqrt(alpha / pi f) for MTR                                 |
| `fit_mtr_amplitude_decay`             | recover k from a frequency-domain amplitude(x) profile            |
| `phonon_mean_free_path`               | l = 3 k / (cv v_g)                                                |
| `knudsen_number`                      | Kn = l / L with regime label                                      |
| `conductivity_ratio`                  | k_a / k_b for isotopic / suspended-supported comparisons          |
| `plot_temperature_profile`            | T(x) PNG with linear / power-law overlays                         |
| `plot_raman_calibration`              | omega(T) PNG with the linear fit overlay (raw calibration data)   |
| `plot_chi_coefficients`               | horizontal-bar PNG of per-material chi (chi-only calibration)     |
| `plot_conductivity_comparison`        | log-y k comparison with Sus/Sup marker + isotope edge encoding    |
| `plot_phase_space`                    | 2-D Sigma Delta T^2 heatmap over (k_Si, k_2D)                     |

None of the functions embed any answer value; the calibration coefficients,
sample geometries and thermal-bath temperatures are all taken from the
input CSVs.

## Build-time provenance check
Every numerical column in the bundled CSVs is traceable to a specific
table or figure in the published article or its Supplementary Information
(Raman chi table from the Methods, HS1 multi-point table from S4-12, HS2
V = 8 V T(x) from main-text Fig 4a, literature landscape from Table S12b,
Si k(T) reference). The Python primitives in `tools/thermal_transport.py`
do not embed any answer value; they implement physics primitives the
agent composes at solve time.

## Dependencies
`numpy`, `scipy`, `matplotlib`; optional `mcp` (`fastmcp`) for the MCP
runtime. All standard scientific Python; no domain libraries needed.

## Artifact generation at solve time
The agent composes the bundled domain primitives (`fit_raman_calibration`,
`temperature_from_raman_shift`, `fit_linear_profile`,
`fit_power_law_profile`, `plot_temperature_profile`,
`plot_chi_coefficients` (chi-only calibration table),
`plot_conductivity_comparison`, …) to produce
its three answer-path PNGs at solve time. No build-time renderer is
bundled because the agent is meant to derive the figures from the
bundled CSVs and the published narrative anchors itself.

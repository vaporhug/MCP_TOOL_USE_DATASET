"""Local-file resource helpers for phys_hb23.

OFFLINE only — the bundle ships with all required Raman calibration
data, HS1 / HS2 temperature tables, literature thermal-conductivity
data and reference papers on disk under input_data/, so no network
calls are needed. This module intentionally exposes no network
helpers.
"""
from __future__ import annotations

import glob
import os


def list_local_files(directory: str, pattern: str = "*") -> list[str]:
    """Filesystem walk under ``directory``; useful to discover bundled
    source-data files in input_data/ trees."""
    out = []
    for root, _, _ in os.walk(directory):
        for f in glob.glob(os.path.join(root, pattern)):
            out.append(f)
    return sorted(out)


def read_file_head(path: str, n_bytes: int = 4096) -> str:
    """Inspect the first n_bytes of a file (binary-safe; latin-1 decoded)."""
    with open(path, "rb") as fh:
        return fh.read(n_bytes).decode("latin-1", errors="replace")

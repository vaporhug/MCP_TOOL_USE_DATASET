# phys_hb23 — Tool Reference

## Database Retrieval (`database_retrieval.py`)
OFFLINE local-file helpers only; the bundle ships every required file
on disk under `input_data/`, so no network calls are needed.
- **list_local_files**: Filesystem walk under a directory.
- **read_file_head**: Inspect the first n_bytes of a file.

## Data Processing (`data_processing.py`)
- **read_csv / write_csv**: list-of-dicts CSV I/O.
- **read_json / write_json**: JSON I/O.
- **coerce_numeric**: cast named columns to float.
- **drop_missing**: remove rows with empty / NaN fields.
- **filter_rows**: keep rows where each named field equals the given value.
- **select_columns**: project to a subset of columns.
- **pivot_long_to_wide**: long-to-wide reshape.

## Domain-Specific (`thermal_transport.py`)
### Raman thermometry
- **fit_raman_calibration**: linear omega(T) = omega_0 + chi T fit.
- **temperature_from_raman_shift**: invert calibration to recover T.
- **stokes_anti_stokes_temperature**: absolute T from I_AS/I_S ratio.

### Fourier conductivity from a 1-D profile
- **fit_linear_profile**: T(x) linear regression.
- **fit_power_law_profile**: T(x) for k(T) = c T^alpha (Fourier with T-dep k).
- **fourier_two_point_conductivity**: k = P L / (Delta T A).
- **thermal_impedance_divider**: Z_2D from a Z_ref series.
- **average_temperature_per_segment**: per-region mean of a Raman scan.

### Modulated thermoreflectance
- **thermal_diffusion_length**: L_th = sqrt(alpha / pi f).
- **fit_mtr_amplitude_decay**: recover k from amplitude(x) at fixed f.

### Phonon transport
- **phonon_mean_free_path**: l = 3 k / (cv v_g).
- **knudsen_number**: Kn = l / L plus regime label.
- **conductivity_ratio**: k_a / k_b for isotopic / suspended-supported pairs.

### Plotting
- **plot_temperature_profile**: T(x) with linear / power-law overlays.
- **plot_raman_calibration**: omega(T) with the linear fit overlay
  (use when raw peak-position vs temperature series are available).
- **plot_chi_coefficients**: horizontal-bar visualisation of
  per-material chi (cm^-1/K) with optional temperature-range and
  source annotations — the right call for chi-only calibration
  tables (this bundle's `raman_calibration_paper.csv` is chi-only).
- **plot_conductivity_comparison**: log-y comparison across materials
  with explicit suspended/supported marker shapes (circle/square) and
  isotope-state edge colours (red = 10B isotopic, blue = natural).
- **plot_phase_space**: 2-D Sigma Delta T^2 heatmap over (k_Si, k_2D).

### Dependencies
`numpy`, `scipy`, `matplotlib`; optional `mcp` (`fastmcp`).

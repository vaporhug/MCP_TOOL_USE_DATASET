"""Generic data-processing utilities.

Format conversion, reshaping, cleaning, and lightweight transforms that are
*not* specific to the task's scientific domain. Domain-specific transforms
live in the task's main tools module (`thermal_transport.py`).
"""
from typing import Any
import csv
import json


def read_csv(path: str, delimiter: str = ",") -> list[dict]:
    """Parse CSV into list-of-dicts using csv.DictReader."""
    with open(path, newline="") as f:
        return list(csv.DictReader(f, delimiter=delimiter))


def write_csv(rows: list[dict], path: str) -> None:
    """Write list-of-dicts to CSV."""
    if not rows:
        open(path, "w").close()
        return
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def read_json(path: str) -> Any:
    with open(path) as f:
        return json.load(f)


def write_json(obj: Any, path: str, indent: int = 2) -> None:
    with open(path, "w") as f:
        json.dump(obj, f, indent=indent, default=str)


def coerce_numeric(rows: list[dict], cols: list[str]) -> list[dict]:
    """Cast named columns to float; non-parseable -> None."""
    out = []
    for r in rows:
        r2 = dict(r)
        for c in cols:
            try:
                r2[c] = float(r2[c]) if r2[c] not in (None, "", "nan") else None
            except (TypeError, ValueError):
                r2[c] = None
        out.append(r2)
    return out


def drop_missing(rows: list[dict], cols: list[str] | None = None) -> list[dict]:
    """Remove rows where any (or listed) columns are None/empty."""
    def bad(v):
        return v is None or v == "" or (isinstance(v, float) and v != v)
    if cols is None:
        return [r for r in rows if not any(bad(v) for v in r.values())]
    return [r for r in rows if not any(bad(r.get(c)) for c in cols)]


def filter_rows(rows: list[dict], **conditions) -> list[dict]:
    """Filter rows where each named field equals the supplied value."""
    out = []
    for r in rows:
        if all(r.get(k) == v for k, v in conditions.items()):
            out.append(r)
    return out


def select_columns(rows: list[dict], cols: list[str]) -> list[list]:
    """Return list of lists with the named columns (in order)."""
    return [[r.get(c) for c in cols] for r in rows]


def pivot_long_to_wide(rows: list[dict], index: str, columns: str,
                       values: str) -> list[dict]:
    """Long-to-wide reshape (like pandas.pivot)."""
    wide: dict = {}
    for r in rows:
        idx = r[index]
        col = r[columns]
        val = r[values]
        wide.setdefault(idx, {index: idx})[col] = val
    return list(wide.values())

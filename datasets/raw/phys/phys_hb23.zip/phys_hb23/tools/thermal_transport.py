#!/usr/bin/env python3
"""
Domain primitives for Raman-thermometry-based 2D thermal-conductivity
extraction.

Covers (i) Raman-shift -> temperature conversion via a first-order
calibration coefficient chi, (ii) Fourier-law conductivity from a 1-D
linear or power-law temperature profile, (iii) frequency-domain
modulated thermoreflectance fitting with a 3-D heat-diffusion kernel,
(iv) phonon-transport summary statistics (mean free path, ballistic
fraction), and (v) plotting helpers.

None of the functions here embed a paper-specific result; they take
raw Raman shifts, lengths, powers, and material properties as
arguments and return derived quantities.
"""
import json
import math
from typing import Optional

import numpy as np
from scipy.optimize import curve_fit, brentq
from scipy.integrate import quad

try:
    from mcp.server.fastmcp import FastMCP
    mcp = FastMCP("Thermal_Transport_Tools")
    _HAS_MCP = True
except Exception:
    _HAS_MCP = False

    def _decorator(*a, **kw):
        def wrap(fn):
            return fn
        if a and callable(a[0]):
            return a[0]
        return wrap

    class _Stub:
        tool = staticmethod(_decorator)

        def run(self, *a, **k):
            pass

    mcp = _Stub()


# --------------------------------------------------------------------- #
# 1. Raman thermometry: temperature from Raman peak position            #
# --------------------------------------------------------------------- #

@mcp.tool()
def fit_raman_calibration(temperatures_K: list, peak_positions_cm_inv: list) -> dict:
    """Fit a first-order Raman calibration omega(T) = omega_0 + chi * T.

    Args:
        temperatures_K: list of temperatures in Kelvin
        peak_positions_cm_inv: matching Raman shifts (cm^-1)

    Returns:
        dict with omega_0, chi (slope, cm^-1/K), residual std, R^2, n
    """
    T = np.asarray(temperatures_K, dtype=float)
    omega = np.asarray(peak_positions_cm_inv, dtype=float)
    A = np.vstack([np.ones_like(T), T]).T
    (omega0, chi), *_ = np.linalg.lstsq(A, omega, rcond=None)
    pred = omega0 + chi * T
    resid = omega - pred
    ss_res = float((resid ** 2).sum())
    ss_tot = float(((omega - omega.mean()) ** 2).sum())
    r2 = 1 - ss_res / ss_tot if ss_tot > 0 else float("nan")
    return {
        "omega_0_cm_inv": round(float(omega0), 4),
        "chi_cm_inv_per_K": round(float(chi), 6),
        "residual_std_cm_inv": round(float(resid.std(ddof=1)), 4) if len(T) > 2 else None,
        "R_squared": round(float(r2), 4),
        "n_points": int(len(T)),
    }


@mcp.tool()
def temperature_from_raman_shift(
    omega_cm_inv: list,
    omega_0_cm_inv: float,
    chi_cm_inv_per_K: float,
) -> dict:
    """Invert omega(T) = omega_0 + chi * T to recover T from a Raman shift.

    Args:
        omega_cm_inv: measured peak positions (cm^-1)
        omega_0_cm_inv: zero-T intercept
        chi_cm_inv_per_K: first-order coefficient

    Returns:
        dict with temperatures (K and C) at each input position
    """
    if chi_cm_inv_per_K == 0:
        return {"error": "chi cannot be zero"}
    omega = np.asarray(omega_cm_inv, dtype=float)
    T_K = (omega - omega_0_cm_inv) / chi_cm_inv_per_K
    T_C = T_K - 273.15
    return {
        "T_K": [round(float(t), 3) for t in T_K],
        "T_C": [round(float(t), 3) for t in T_C],
    }


@mcp.tool()
def stokes_anti_stokes_temperature(
    intensity_ratio_AS_over_S: list,
    laser_wavelength_nm: float,
    raman_shift_cm_inv: float,
    n_exponent: float = 4.0,
) -> dict:
    """Recover absolute temperature from Stokes / anti-Stokes intensity ratio.

    The classical Stokes / anti-Stokes intensity ratio at absolute
    temperature T (in K) is

        I_AS / I_S = ((nu_l + nu_RS) / (nu_l - nu_RS))^n
                     * exp(-h c nu_RS / (k_B T)).

    Inverting that for T gives

        T = (h c nu_RS) / (k_B *
                           [n * ln((nu_l + nu_RS)/(nu_l - nu_RS))
                            - ln(I_AS / I_S)])

    (note the MINUS sign in front of ln(I_AS/I_S) — at thermal
    equilibrium I_AS < I_S so ln(I_AS/I_S) < 0 and the bracketed
    denominator stays positive). nu_l is the laser wavenumber
    1/lambda_l, nu_RS is the Raman peak position in cm^-1, and n is
    the prefactor exponent that depends on the detection convention
    (n = 4 classical, n = 3 or n = 0 for specific spectrometer setups).

    Args:
        intensity_ratio_AS_over_S: list of I_AS/I_S values
        laser_wavelength_nm: laser wavelength (nm)
        raman_shift_cm_inv: Raman peak position (cm^-1)
        n_exponent: 4 (classical), 3, or 0 depending on detection

    Returns:
        dict with temperatures in K (None for non-positive ratios).
    """
    h = 6.62607015e-34
    c = 2.99792458e10  # cm/s
    kB = 1.380649e-23
    nu_l = 1.0 / (laser_wavelength_nm * 1e-7)  # cm^-1
    nu_RS = float(raman_shift_cm_inv)
    if nu_l - nu_RS <= 0:
        raise ValueError("Raman shift exceeds laser wavenumber — "
                         "check input units (laser_wavelength_nm vs "
                         "raman_shift_cm_inv).")
    prefactor_log = n_exponent * math.log((nu_l + nu_RS) / (nu_l - nu_RS))
    out = []
    for ratio in intensity_ratio_AS_over_S:
        r = float(ratio)
        if r <= 0:
            out.append(None)
            continue
        denom = prefactor_log - math.log(r)
        if denom <= 0:
            out.append(None)
            continue
        T = (h * c * nu_RS) / (kB * denom)
        out.append(round(float(T), 2))
    return {"T_K": out, "n_exponent": n_exponent,
            "laser_nm": laser_wavelength_nm,
            "raman_shift_cm_inv": nu_RS}


# --------------------------------------------------------------------- #
# 2. Fourier conductivity from a temperature profile                    #
# --------------------------------------------------------------------- #

@mcp.tool()
def fit_linear_profile(distance_um: list, temperature_K: list) -> dict:
    """Linear regression T(x) = T_hot + slope * x. Returns slope (K/um)."""
    x = np.asarray(distance_um, dtype=float)
    T = np.asarray(temperature_K, dtype=float)
    A = np.vstack([np.ones_like(x), x]).T
    (T0, slope), *_ = np.linalg.lstsq(A, T, rcond=None)
    pred = T0 + slope * x
    ss_res = float(((T - pred) ** 2).sum())
    ss_tot = float(((T - T.mean()) ** 2).sum())
    r2 = 1 - ss_res / ss_tot if ss_tot > 0 else float("nan")
    return {
        "T_intercept_K": round(float(T0), 3),
        "slope_K_per_um": round(float(slope), 4),
        "R_squared": round(float(r2), 4),
        "n_points": int(len(x)),
        "delta_T_K": round(float(T[-1] - T[0]), 3) if len(T) >= 2 else None,
    }


@mcp.tool()
def fit_power_law_profile(distance_um: list, temperature_K: list) -> dict:
    """Fit the endpoint-constrained temperature profile

        T(x) = [(1 - xi) T_hot^(a+1) + xi T_cold^(a+1)]^(1/(a+1))

    corresponding to Fourier's law with a temperature-dependent thermal
    conductivity k(T) = c · T^a (alpha=0 => linear / classical Fourier).
    xi = (x - x_hot) / (x_cold - x_hot) where (x_hot, T_hot) and
    (x_cold, T_cold) are taken from the input arrays' x-min (hottest end)
    and x-max (coldest end) regardless of the input ordering.

    The alpha=-1 limit corresponds to k(T) ∝ 1/T and degenerates the
    closed-form expression; the model evaluation routes that exact case
    through the limiting form T(x) = T_hot · (T_cold/T_hot)^xi (a
    log-linear profile). The fitter therefore stays well defined as alpha
    approaches -1 from either side.

    The search is bounded to a physically reasonable window
    alpha ∈ [-2.5, 2.5] to avoid runaway sign-flipped power roots.
    """
    x = np.asarray(distance_um, dtype=float)
    T = np.asarray(temperature_K, dtype=float)
    if len(x) < 4 or len(T) != len(x):
        return {"error": "need at least 4 points and matching T array"}
    order = np.argsort(x)
    x = x[order]; T = T[order]
    x_lo = float(x[0]); x_hi = float(x[-1])
    if x_hi - x_lo <= 0:
        return {"error": "need a finite distance span"}
    # Identify hot/cold endpoints by TEMPERATURE, not by coordinate sign,
    # so the routine accepts reverse heat-flow inputs.
    T_lo_x = float(T[0])
    T_hi_x = float(T[-1])
    if T_lo_x >= T_hi_x:
        x_hot, Th = x_lo, T_lo_x
        x_cold, Tc = x_hi, T_hi_x
    else:
        x_hot, Th = x_hi, T_hi_x
        x_cold, Tc = x_lo, T_lo_x
    L = abs(x_cold - x_hot)
    if Th <= 0 or Tc <= 0:
        return {"error": "endpoint temperatures must be positive (Kelvin)"}
    # xi = 0 at the hot end, xi = 1 at the cold end
    xs = (x - x_hot) / (x_cold - x_hot)

    EPS_A1 = 1e-6

    def model(xi, a):
        if abs(a + 1.0) < EPS_A1:
            # alpha → -1 limit: k(T) ∝ 1/T → log-linear profile
            return Th * (Tc / Th) ** xi
        ap1 = a + 1.0
        inner = (1.0 - xi) * Th ** ap1 + xi * Tc ** ap1
        # Guard against tiny negative roundoff before fractional root
        inner = np.where(inner > 0, inner, np.nan)
        return inner ** (1.0 / ap1)

    try:
        popt, pcov = curve_fit(model, xs, T, p0=[0.0],
                               bounds=(-2.5, 2.5))
        alpha = float(popt[0])
        a_err = float(np.sqrt(pcov[0, 0])) if pcov.size else float("nan")
    except Exception as e:
        return {"error": f"fit failed: {e}"}
    pred = model(xs, alpha)
    ss_res = float(((T - pred) ** 2).sum())
    ss_tot = float(((T - T.mean()) ** 2).sum())
    r2 = 1 - ss_res / ss_tot if ss_tot > 0 else float("nan")
    rmse = float(np.sqrt(ss_res / max(len(T), 1)))
    return {
        "alpha": round(alpha, 4),
        "alpha_std": round(a_err, 4),
        "alpha_bounds_used": [-2.5, 2.5],
        "T_hot_K": round(Th, 2),
        "T_cold_K": round(Tc, 2),
        "x_hot_um": round(x_hot, 3),
        "x_cold_um": round(x_cold, 3),
        "L_um": round(L, 3),
        "R_squared": round(float(r2), 4),
        "RMSE_K": round(rmse, 3),
        "n_points": int(len(x)),
    }


@mcp.tool()
def fourier_two_point_conductivity(
    P_W: float,
    delta_T_K: float,
    L_m: float,
    cross_section_m2: float,
) -> dict:
    """Fourier law k = P L / (Delta T * A) for a uniform 1-D bar.

    Args:
        P_W: heat flux through the bar (Watts)
        delta_T_K: temperature drop along the length (K)
        L_m: length of the bar (m)
        cross_section_m2: cross-sectional area W * t (m^2)

    Returns: k (W/m/K) and the thermal impedance L/(W*t).
    """
    if delta_T_K == 0 or cross_section_m2 == 0:
        return {"error": "delta_T and cross-section must be non-zero"}
    k = (P_W * L_m) / (delta_T_K * cross_section_m2)
    Z = L_m / cross_section_m2
    return {
        "k_W_per_m_per_K": round(float(k), 2),
        "thermal_impedance_inv_m": round(float(Z), 3),
        "P_W": float(P_W),
        "delta_T_K": float(delta_T_K),
    }


@mcp.tool()
def thermal_impedance_divider(
    P_W: float,
    delta_T_2D_K: float,
    delta_T_ref_K: float,
    Z_ref_inv_m: float,
) -> dict:
    """Two-impedance series ('voltage divider') extraction of the 2D-leg
    thermal impedance Z_2D from a known reference-leg impedance Z_ref.

    With both legs carrying the same heat flux Q, the impedance ratio
    follows the temperature-drop ratio across each leg:

        Z_2D / Z_ref = Delta T_2D / Delta T_ref

    The function returns ``Z_2D_inv_m`` (the 2D-leg impedance computed
    from the supplied reference impedance and the temperature-drop
    ratio), the temperature-drop ratio itself, and the heat-flux-per-
    temperature-drop diagnostic ``Q_over_dT_2D_W_per_K = P / Delta T_2D``
    (which is NOT k_2D — converting it to k_2D requires the 2D-leg's
    geometric factor 1/(width × thickness), supplied externally). The
    caller obtains k_2D by combining ``Z_2D_inv_m`` with the 2D-leg
    geometry; this tool intentionally does not embed that conversion
    because the 2D-leg geometric scaling is sample-dependent.

    Args:
        P_W: heater power (W).
        delta_T_2D_K: temperature drop across the 2D-membrane leg (K).
        delta_T_ref_K: temperature drop across the reference (silicon
            cantilever) leg (K).
        Z_ref_inv_m: reference-leg thermal impedance per unit length,
            equal to 1/(k_ref · w · t) in 1/(W·m) (often written m^-1
            informally; the dimension is reciprocal-(W·m), so a 1 µm-long
            reference leg of thermal conductance G_ref = k_ref·w·t/L_ref
            has overall thermal impedance Z_ref · L_ref = L_ref/(k_ref·
            w·t) with units K/W). DOES NOT include a length factor —
            pass the per-unit-length value; multiply by the reference
            length externally if you need an absolute K/W impedance.

    Returns dict with:
        ``Z_2D_inv_m``: 2D-leg thermal impedance (m^-1), evaluated by
            the divider ratio from the supplied Z_ref.
        ``ratio_dT_2D_over_dT_ref``: dimensionless temperature-drop
            ratio (equals Z_2D / Z_ref under the divider assumption).
        ``Q_over_dT_2D_W_per_K``: P / Delta T_2D in W/K — the
            heat-conductance diagnostic; multiply by 1/(w · t) of the
            2D leg externally to obtain k_2D in W/m/K.
    """
    if delta_T_ref_K == 0:
        return {"error": "delta_T_ref must be non-zero"}
    Z_2D = Z_ref_inv_m * delta_T_2D_K / delta_T_ref_K
    k_over_geom = P_W / delta_T_2D_K
    return {
        "Z_2D_inv_m": round(float(Z_2D), 4),
        "ratio_dT_2D_over_dT_ref": round(delta_T_2D_K / delta_T_ref_K, 4),
        "Q_over_dT_2D_W_per_K": round(float(k_over_geom), 6),
    }


@mcp.tool()
def average_temperature_per_segment(
    distance_um: list, temperature_K: list,
    segment_edges_um: list,
) -> dict:
    """Average T over consecutive (left,right) windows along x.
    Used to collapse a 5-point Raman line into per-region mean T."""
    x = np.asarray(distance_um, dtype=float)
    T = np.asarray(temperature_K, dtype=float)
    out = []
    for left, right in segment_edges_um:
        mask = (x >= left) & (x <= right)
        if mask.sum() == 0:
            out.append({"left_um": left, "right_um": right, "n": 0,
                        "T_mean": None, "T_std": None})
            continue
        out.append({
            "left_um": float(left),
            "right_um": float(right),
            "n": int(mask.sum()),
            "T_mean_K": round(float(T[mask].mean()), 3),
            "T_std_K": round(float(T[mask].std(ddof=1)),
                             3) if mask.sum() > 1 else 0.0,
        })
    return {"segments": out}


# --------------------------------------------------------------------- #
# 3. Frequency-domain (modulated) thermoreflectance                    #
# --------------------------------------------------------------------- #

@mcp.tool()
def thermal_diffusion_length(
    k_W_per_m_K: float,
    rho_kg_per_m3: float,
    cp_J_per_kg_K: float,
    frequency_Hz: float,
) -> dict:
    """L_th = sqrt(alpha / (pi f)), with alpha = k / (rho cp)."""
    if frequency_Hz <= 0 or rho_kg_per_m3 <= 0 or cp_J_per_kg_K <= 0:
        return {"error": "f, rho, cp must be positive"}
    alpha = k_W_per_m_K / (rho_kg_per_m3 * cp_J_per_kg_K)
    L = math.sqrt(alpha / (math.pi * frequency_Hz))
    return {
        "thermal_diffusivity_m2_per_s": round(float(alpha), 9),
        "L_th_m": round(float(L), 9),
        "L_th_um": round(float(L * 1e6), 4),
        "frequency_Hz": float(frequency_Hz),
    }


@mcp.tool()
def fit_mtr_amplitude_decay(
    distance_m: list,
    amplitude: list,
    frequency_Hz: float,
    rho_kg_per_m3: float,
    cp_J_per_kg_K: float,
) -> dict:
    """Fit a Gaussian-source 1-D thermal-wave amplitude
        A(x) = A0 * exp(-x / L_th)
    and back-solve for k from L_th. Returns k_in_plane (W/m/K).

    Args:
        distance_m: positions in meters along the direction probed
        amplitude: relative amplitude at each position
        frequency_Hz: pump modulation frequency
        rho_kg_per_m3, cp_J_per_kg_K: substrate properties

    Returns: fitted L_th (m) and recovered k = pi * f * L_th^2 * rho * cp.
    """
    x = np.asarray(distance_m, dtype=float)
    A = np.asarray(amplitude, dtype=float)
    A = A / A.max()
    mask = (x > 0) & (A > 0)
    x = x[mask]
    A = A[mask]
    if len(x) < 3:
        return {"error": "need >=3 positive points"}
    # ln A = -x/L_th
    coeffs = np.polyfit(x, np.log(A), 1)
    L_th = -1.0 / coeffs[0]
    if L_th <= 0:
        return {"error": "non-decaying amplitude"}
    k = math.pi * frequency_Hz * L_th ** 2 * rho_kg_per_m3 * cp_J_per_kg_K
    return {
        "L_th_m": round(float(L_th), 9),
        "L_th_um": round(float(L_th * 1e6), 4),
        "k_W_per_m_K": round(float(k), 2),
        "frequency_Hz": float(frequency_Hz),
        "n_points": int(len(x)),
    }


# --------------------------------------------------------------------- #
# 4. Phonon transport summary primitives                                #
# --------------------------------------------------------------------- #

@mcp.tool()
def phonon_mean_free_path(
    k_W_per_m_K: float,
    cv_J_per_m3_K: float,
    v_g_m_per_s: float,
) -> dict:
    """Kinetic-theory mean free path:  l = 3 k / (cv * v_g)."""
    if cv_J_per_m3_K <= 0 or v_g_m_per_s <= 0:
        return {"error": "cv and v_g must be positive"}
    l = 3 * k_W_per_m_K / (cv_J_per_m3_K * v_g_m_per_s)
    return {
        "mean_free_path_m": round(float(l), 9),
        "mean_free_path_um": round(float(l * 1e6), 3),
        "Knudsen_micron_units": round(float(l * 1e6), 3),
    }


@mcp.tool()
def knudsen_number(
    mean_free_path_um: float,
    sample_length_um: float,
) -> dict:
    """Kn = l / L. Kn>>1 ballistic, Kn<<1 diffusive,
    Kn~1 hydrodynamic / Knudsen-minimum regime."""
    if sample_length_um <= 0:
        return {"error": "sample_length must be positive"}
    Kn = mean_free_path_um / sample_length_um
    if Kn > 5:
        regime = "ballistic"
    elif Kn > 0.3:
        regime = "transitional / hydrodynamic"
    else:
        regime = "diffusive"
    return {"Kn": round(float(Kn), 4), "regime": regime,
            "mean_free_path_um": float(mean_free_path_um),
            "sample_length_um": float(sample_length_um)}


@mcp.tool()
def conductivity_ratio(
    k_a: float, k_b: float, label_a: str = "A", label_b: str = "B"
) -> dict:
    """k_A / k_B with both inputs preserved. Used for isotopic-purity or
    suspended/supported comparisons."""
    if k_b == 0:
        return {"error": "k_b cannot be zero"}
    return {
        "ratio": round(float(k_a) / float(k_b), 4),
        f"k_{label_a}": float(k_a),
        f"k_{label_b}": float(k_b),
    }


# --------------------------------------------------------------------- #
# 5. Plotting helpers                                                   #
# --------------------------------------------------------------------- #

@mcp.tool()
def plot_temperature_profile(
    distance_um: list,
    temperature_K: list,
    out_path: str,
    title: str = "Temperature profile",
    overlay_linear_fit: bool = True,
    overlay_power_law: bool = False,
) -> dict:
    """Save a T(x) figure to out_path. Optionally overlays best-fit
    linear or power-law profiles.

    Endpoint convention used by the power-law overlay (and matching
    ``fit_power_law_profile``): the inputs are sorted by ``distance_um``
    internally, so the closed-form fit identifies the HOTTEST and
    COLDEST end-points by their temperatures rather than by their
    coordinate sign. Concretely: after the sort the smallest-x point
    gets ``T_a = T(x.min())`` and the largest-x point gets
    ``T_b = T(x.max())``; if ``T_a > T_b`` (canonical case: heat flows
    from small x to large x) then ``T_hot = T_a, x_hot = x.min()`` and
    ``T_cold = T_b, x_cold = x.max()``; if ``T_b > T_a`` (reverse heat
    flow: heat flows from large x to small x) then ``T_hot = T_b,
    x_hot = x.max()`` and ``T_cold = T_a, x_cold = x.min()``. Either
    direction is accepted as input.

    Returns the file path."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    x = np.asarray(distance_um, dtype=float)
    T = np.asarray(temperature_K, dtype=float)
    order = np.argsort(x)
    x = x[order]; T = T[order]
    fig, ax = plt.subplots(figsize=(6.0, 4.0))
    ax.plot(x, T, "o", color="#cc2244", markersize=5, label="measurement")

    if overlay_linear_fit and len(x) >= 2:
        slope, intercept = np.polyfit(x, T, 1)
        xx = np.linspace(x.min(), x.max(), 200)
        ax.plot(xx, intercept + slope * xx, "--", color="black",
                lw=1.0, label=f"linear: slope={slope:.2f} K/um")

    if overlay_power_law and len(x) >= 4:
        try:
            res = fit_power_law_profile(x.tolist(), T.tolist())
            if "error" not in res:
                a = res["alpha"]
                # fit_power_law_profile reports x_hot_um/x_cold_um and
                # T_hot_K/T_cold_K by TEMPERATURE-based identification, so
                # reverse-heat-flow inputs (T at x.max() hotter than T at
                # x.min()) are handled correctly here too — read endpoints
                # from the fit result rather than from x.min()/x.max().
                x_hot = res["x_hot_um"]; x_cold = res["x_cold_um"]
                Th = res["T_hot_K"]; Tc = res["T_cold_K"]
                xx = np.linspace(x.min(), x.max(), 200)
                xi = (xx - x_hot) / (x_cold - x_hot)
                if abs(a + 1.0) < 1e-6:
                    yy = Th * (Tc / Th) ** xi
                else:
                    yy = ((1.0 - xi) * Th ** (a + 1) + xi * Tc ** (a + 1)) ** (1.0 / (a + 1))
                ax.plot(xx, yy, "-", color="#3366aa", lw=1.5,
                        label=f"power-law alpha={a:.2f}")
        except Exception:
            pass

    ax.set_xlabel("Distance (um)")
    ax.set_ylabel("Temperature (K)")
    ax.set_title(title)
    ax.grid(alpha=0.3)
    ax.legend()
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": out_path, "n_points": int(len(x))}


@mcp.tool()
def plot_raman_calibration(
    temperatures_K: list,
    peak_positions_cm_inv: list,
    out_path: str,
    title: str = "Raman calibration",
) -> dict:
    """Plot omega(T) with linear fit; saves to out_path."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fit = fit_raman_calibration(temperatures_K, peak_positions_cm_inv)
    T = np.asarray(temperatures_K, dtype=float)
    w = np.asarray(peak_positions_cm_inv, dtype=float)
    fig, ax = plt.subplots(figsize=(5.5, 4.0))
    ax.plot(T, w, "o", color="#225577")
    Tg = np.linspace(T.min(), T.max(), 100)
    ax.plot(Tg, fit["omega_0_cm_inv"] + fit["chi_cm_inv_per_K"] * Tg,
            "-", color="#cc2244",
            label=f"chi = {fit['chi_cm_inv_per_K']:.4f} cm^-1/K")
    ax.set_xlabel("Temperature (K)")
    ax.set_ylabel("Raman shift (cm^-1)")
    ax.set_title(title)
    ax.grid(alpha=0.3)
    ax.legend()
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": out_path, **fit}


@mcp.tool()
def plot_conductivity_comparison(
    materials: list,
    k_values: list,
    suspended_flags: list,
    isotope_flags: list,
    out_path: str,
    highlight_indices: Optional[list] = None,
    title: str = "Thermal conductivity comparison",
) -> dict:
    """Scatter plot of in-plane k across materials with explicit
    suspended-vs-supported marker shapes and isotope-state colour edges.

    Suspended / supported encoding (marker shape):
      - "Sus"       → circle ("o")
      - "Sup"       → square ("s")
      - anything else → triangle ("^") (unknown / not classified)

    Isotope encoding (edge colour):
      - "10" / "10B" / "h10BN"        → red edge
      - "11" / "11B" / "natural"      → blue edge
      - anything else / None          → black edge (default)

    ``highlight_indices`` are drawn larger (e.g., this-work points). A
    short legend explaining the encoding is added.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    n = len(materials)
    if len(k_values) != n or len(suspended_flags) != n or len(isotope_flags) != n:
        raise ValueError("materials, k_values, suspended_flags and isotope_flags "
                         "must all have the same length")

    def _marker(flag):
        if flag in ("Sus", "sus", "suspended"):
            return "o"
        if flag in ("Sup", "sup", "supported"):
            return "s"
        return "^"

    def _edge(flag):
        s = str(flag).strip().lower()
        if s in ("10", "10b", "h10bn", "iso", "isotopic", "pure"):
            return "#cc2244"  # red — isotopically purified
        if s in ("11", "11b", "natural", "nat"):
            return "#225599"  # blue — natural isotopic mix
        return "#222222"      # black — unspecified

    fig, ax = plt.subplots(figsize=(7.0, 4.5))
    for i in range(n):
        marker = _marker(suspended_flags[i])
        edge = _edge(isotope_flags[i])
        face = ("#cc2244" if highlight_indices and i in highlight_indices
                else "#446699")
        size = 90 if highlight_indices and i in highlight_indices else 36
        ax.scatter(i, k_values[i], marker=marker, s=size, color=face,
                   edgecolors=edge, linewidths=1.2)
    ax.set_xticks(range(n))
    ax.set_xticklabels(materials, rotation=45, ha="right", fontsize=7)
    ax.set_ylabel("k (W m^-1 K^-1)")
    ax.set_title(title)
    ax.set_yscale("log")
    ax.grid(alpha=0.3, which="both")
    # Legend handles
    import matplotlib.lines as mlines
    handles = [
        mlines.Line2D([], [], marker="o", linestyle="none", markersize=8,
                      markerfacecolor="#446699", markeredgecolor="#222",
                      label="Suspended"),
        mlines.Line2D([], [], marker="s", linestyle="none", markersize=8,
                      markerfacecolor="#446699", markeredgecolor="#222",
                      label="Supported"),
        mlines.Line2D([], [], marker="o", linestyle="none", markersize=8,
                      markerfacecolor="white", markeredgecolor="#cc2244",
                      markeredgewidth=1.4, label="Isotopic 10B (red edge)"),
        mlines.Line2D([], [], marker="o", linestyle="none", markersize=8,
                      markerfacecolor="white", markeredgecolor="#225599",
                      markeredgewidth=1.4, label="Natural / 11B (blue edge)"),
    ]
    ax.legend(handles=handles, loc="lower right", fontsize=7, framealpha=0.85)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": out_path, "n_points": n}


@mcp.tool()
def plot_chi_coefficients(
    materials: list,
    chi_values: list,
    out_path: str,
    t_ranges: Optional[list] = None,
    sources: Optional[list] = None,
    title: str = "Raman temperature coefficients chi",
) -> dict:
    """Horizontal-bar visualisation of the per-material Raman temperature
    coefficient chi (cm^-1/K) from the bundled chi-only calibration table.

    Suitable when the bundle ships chi coefficients only (no raw omega(T)
    calibration scatter to feed ``plot_raman_calibration``).

    Args:
        materials: list of material labels (one per chi value).
        chi_values: list of chi (cm^-1/K), negative for cooling-with-T
            (typical of WSe2 / h10BN / Si).
        out_path: output PNG path.
        t_ranges: optional list of temperature-range strings to annotate
            next to each bar (e.g. ``"125-575 K"``).
        sources: optional list of source labels to annotate.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    n = len(materials)
    if len(chi_values) != n:
        raise ValueError("materials and chi_values must have the same length")
    if t_ranges is not None and len(t_ranges) != n:
        raise ValueError("t_ranges must match materials length when supplied")
    if sources is not None and len(sources) != n:
        raise ValueError("sources must match materials length when supplied")

    fig, ax = plt.subplots(figsize=(6.6, 0.6 * n + 1.2))
    y = list(range(n))
    bars = ax.barh(y, chi_values, color="#446699", edgecolor="#222")
    ax.set_yticks(y)
    ax.set_yticklabels(materials)
    ax.invert_yaxis()
    ax.axvline(0.0, color="#222", lw=0.6)
    ax.set_xlabel("chi (cm^-1/K)")
    ax.set_title(title)
    for i, b in enumerate(bars):
        anno_parts = [f"{chi_values[i]:+.4f}"]
        if t_ranges is not None:
            anno_parts.append(f"({t_ranges[i]})")
        if sources is not None:
            anno_parts.append(f"[{sources[i]}]")
        x = b.get_width()
        offset = 0.0008 if x >= 0 else -0.0008
        ax.text(x + offset, b.get_y() + b.get_height() / 2,
                "  ".join(anno_parts),
                va="center",
                ha="left" if x >= 0 else "right",
                fontsize=8)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": out_path, "n_materials": n}


@mcp.tool()
def plot_phase_space(
    k_si_grid: list,
    k_2d_grid: list,
    chi_squared: list,
    out_path: str,
    title: str = "Convergence phase space",
) -> dict:
    """2-D heatmap of sum-square temperature error vs (k_Si, k_2D); the
    blue/yellow coloured region marks the converged simulation set."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    ks = np.asarray(k_si_grid, dtype=float)
    k2 = np.asarray(k_2d_grid, dtype=float)
    chi2 = np.asarray(chi_squared, dtype=float)

    fig, ax = plt.subplots(figsize=(5.5, 4.5))
    sc = ax.scatter(ks, k2, c=chi2, s=80, cmap="plasma_r",
                    edgecolors="black", linewidths=0.3)
    fig.colorbar(sc, ax=ax, label=r"$\Sigma\Delta T^2$ (K$^2$)")
    ax.set_xlabel("k_Si (W m^-1 K^-1)")
    ax.set_ylabel("k_2D (W m^-1 K^-1)")
    ax.set_title(title)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": out_path, "n_points": int(len(ks))}


# --------------------------------------------------------------------- #
# Entrypoint                                                            #
# --------------------------------------------------------------------- #

if __name__ == "__main__":
    if _HAS_MCP:
        mcp.run(transport="stdio")
    else:
        print("MCP server library not available; module imported as plain Python.")

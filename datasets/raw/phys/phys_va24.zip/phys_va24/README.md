# phys_va24 — Viscoelastic Acoustic Metamaterial

## Source paper
- **Title**: Viscoelastic structural damping enables broadband low-frequency
  sound absorption
- **Authors**: Y. Zhang, J. Li, Q. Wu, M. Amabili, D. Misseroni, H. Jiang
- **Journal**: PNAS, 122(43), e2520808122 (2025)
- **DOI**: 10.1073/pnas.2520808122
- **Data Availability**: GitHub
  https://github.com/yanlinZhang865/Data-availability  (`Source Data.xlsx`,
  `Closed_form_analytical_model.m`, `Full_recursive_model.m`)

The paper PDF saved as `input_data/reference_paper/target.pdf` was rendered
from the official PMC JATS XML (PMC12582337) because the publisher’s PDF
endpoint requires JavaScript challenge headers.

## Data placed in `input_data/data/`
| File | Origin | Notes |
|------|--------|-------|
| `source_data.xlsx` | Source Data deposit | 29 sheets, all main + supplementary panels |
| `Closed_form_analytical_model.m` | Source Data deposit | Reference closed-form model |
| `Full_recursive_model.m` | Source Data deposit | 1000-segment recursive model |
| `github_README.md` | Source Data deposit | Deposit description |

No interpolation, no synthetic data: every absorption / impedance / DMA
number used in the answer comes directly from the deposit.

## Verification gate (run during build)
1. Title / DOI / journal confirmed via the PMC JATS XML.
2. Workbook has 29 sheets; per-sheet row counts match the figure panels.
3. Five answer numbers all lie in source data:
   - Rigid-neck peak alpha = 0.999 at 150 Hz (Fig. 1D, sheet *Fig. 1D and Fig. S16D*).
   - Soft-shell single unit alpha > 0.5 across 280–550 Hz
     (Fig. 1I, sheet *Fig. 1I and Fig. S18C*).
   - Customised Set #3 alpha >= 0.97 in 228–328 Hz, 101 sample rows
     (Fig. 5F, sheet *Fig. 5D-F and Fig. S21*, cols 21–22).
   - Ecoflex-30 high-frequency plateau E' ≈ 148 kPa, eta ≈ 0.2
     (Fig. 2B, last DMA row).
   - Ecoflex-20 + W tail-average E' ≈ 111 kPa (-25 %), eta ≈ 0.385 (+92 %)
     vs Ecoflex-30 baseline (Fig. 5 A-B).
4. Independent Python re-implementation of the closed-form model
   (`tools/viscoelastic_acoustics.closed_form_absorption`) reproduces the
   alpha, x_s, y_s columns of sheet *Fig. 3G* to within 1 % at sampled
   frequencies — confirming the model–data link.

## Tooling
- `tools/data_processing.py`            — generic file I/O helpers
- `tools/database_retrieval.py`         — local file system inspection
- `tools/viscoelastic_acoustics.py`     — domain primitives:
  * `absorption_spectrum_summary`, `fraction_above_threshold`,
    `integrate_spectrum`
  * `absorption_from_impedance`, `air_column_impedance`,
    `cavity_reactance`, `shell_impedance_lumped`, `closed_form_absorption`
  * `dma_high_freq_plateau`, `compare_two_spectra`
  * `plot_two_panel_spectra`, `plot_exp_vs_model`,
    `plot_dma_and_dissipation`

The acoustic primitives are standard Helmholtz / Crandall / Kirchhoff–Love
formulas; none of them embed the answer.

### Dependencies
`numpy`, `scipy`, `openpyxl`, `matplotlib`; optional `mcp` for FastMCP
deployment. No deep-learning runtime needed.

## Task artefacts
- `task_content/task_content.json` — instruction, inputs, four-part answer
  (one text 0.4 + three image 0.2; weights sum to 1.0)
- `task_content/1.pdf`             — rigid vs soft-shell spectra (Fig. 1D / 1I data)
- `task_content/2.pdf`             — exp vs sim and DMA plateau (Fig. 2B / 2C data)
- `task_content/3.pdf`             — broadband Set #3 + dissipation (Fig. 5F / 2L data)

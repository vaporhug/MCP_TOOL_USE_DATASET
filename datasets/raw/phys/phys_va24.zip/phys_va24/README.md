# phys_va24 — Viscoelastic Acoustic Metamaterial

## Source paper
- **Title**: Viscoelastic structural damping enables broadband low-frequency
  sound absorption
- **Authors**: Y. Zhang, J. Li, Q. Wu, M. Amabili, D. Misseroni, H. Jiang
- **Journal**: PNAS, 122(43), e2520808122 (2025)
- **DOI**: 10.1073/pnas.2520808122
- **Data Availability**: GitHub
  https://github.com/yanlinZhang865/Data-availability  (`Source Data.xlsx`,
  `Closed_form_analytical_model.m`, `Full_recursive_model.m`)

The paper PDF saved as `input_data/reference_paper/target.pdf` was rendered
from the official PMC JATS XML (PMC12582337) because the publisher’s PDF
endpoint requires JavaScript challenge headers.

## Data placed in `input_data/data/`
| File | Origin | Notes |
|------|--------|-------|
| `source_data.xlsx` | Source Data deposit | 29 sheets, all main + supplementary panels |
| `Closed_form_analytical_model.m` | Source Data deposit | Reference closed-form model |
| `Full_recursive_model.m` | Source Data deposit | 1000-segment recursive model |
| `github_README.md` | Source Data deposit | Deposit description |

All absorption / impedance / DMA / dissipation columns ship verbatim
from the deposit workbook; no interpolation, smoothing or synthetic
data has been added at bundle-construction time.

## Bundle data inventory
1. Source: `Source Data.xlsx` from the publisher's GitHub deposit
   (https://github.com/yanlinZhang865/Data-availability), with the
   companion `Closed_form_analytical_model.m` and
   `Full_recursive_model.m` MATLAB scripts kept alongside it.
2. Sheet count: 29. Each sheet corresponds to one main- or
   supplementary-figure panel of the paper; per-sheet row counts
   align with the figure-panel sample sizes.
3. Sheet *Fig. 3G* contains the deposit's own analytical-model output
   (`alpha`, `x_s`, `y_s` columns at sampled frequencies); the
   bundled `tools/viscoelastic_acoustics.closed_form_absorption`
   primitive evaluates the same closed-form circuit in pure Python so
   downstream code can use either source.

## Tooling
- `tools/data_processing.py`            — generic file I/O helpers
- `tools/database_retrieval.py`         — local file system inspection
- `tools/viscoelastic_acoustics.py`     — domain primitives:
  * `absorption_spectrum_summary`, `fraction_above_threshold`,
    `integrate_spectrum`
  * `absorption_from_impedance`, `air_column_impedance`,
    `cavity_reactance`, `shell_impedance_lumped`, `closed_form_absorption`
  * `dma_high_freq_plateau`, `compare_two_spectra`
  * `plot_two_panel_spectra`, `plot_exp_vs_model`,
    `plot_dma_and_dissipation`, `plot_exp_vs_model_and_dma`
    (two-panel composite: experiment-vs-model spectrum + DMA panel),
    `plot_absorber_and_dissipation` (two-panel composite: absorber
    measured-vs-model spectrum with optional band annotation +
    dissipation-power decomposition; sample identification is
    passed via the title arguments, the function name is generic)

The acoustic primitives are standard Helmholtz / Crandall / Kirchhoff–Love
formulas; none of them embed the answer.

### Dependencies
`numpy`, `scipy`, `openpyxl`, `matplotlib`; optional `mcp` for FastMCP
deployment. No deep-learning runtime needed.

## Task artefacts
- `task_content/task_content.json` — instruction, inputs, four-part answer
  (one text 0.4 + three image 0.2; weights sum to 1.0)
- `artifacts/` — SHIPPED EMPTY. The agent writes three PNGs at solve
  time at the answer paths
  (`artifacts/Fig1_rigid_neck_alpha.png`,
  `artifacts/Fig2_thickness_jsc_avt.png`,
  `artifacts/Fig3_geographical_world.png`). No pre-built reference
  PNGs are bundled, so there is no path through which a pre-rendered
  answer figure could shadow the agent's output.

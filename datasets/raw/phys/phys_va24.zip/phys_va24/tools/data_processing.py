"""Generic I/O helpers (no domain logic).

Format conversion / sheet listing / CSV-XLSX bridges. Domain-specific
acoustic computations live in viscoelastic_acoustics.py.
"""
from typing import Any
import csv
import json


def read_csv(path: str, delimiter: str = ",") -> list[dict]:
    """Parse CSV into list-of-dicts via csv.DictReader."""
    with open(path, newline="") as f:
        return list(csv.DictReader(f, delimiter=delimiter))


def write_csv(rows: list[dict], path: str) -> None:
    """Write list-of-dicts to CSV using the first row keys as header."""
    if not rows:
        open(path, "w").close()
        return
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def read_json(path: str) -> Any:
    with open(path) as f:
        return json.load(f)


def write_json(obj: Any, path: str, indent: int = 2) -> None:
    with open(path, "w") as f:
        json.dump(obj, f, indent=indent, default=str)


def list_xlsx_sheets(xlsx_path: str) -> list[str]:
    """Return sheet names of an .xlsx workbook."""
    import openpyxl

    wb = openpyxl.load_workbook(xlsx_path, data_only=True, read_only=True)
    return list(wb.sheetnames)


def read_xlsx_sheet(
    xlsx_path: str,
    sheet_name: str,
    header_rows: int = 2,
    columns: list[int] | None = None,
) -> list[list]:
    """Read a sheet and return rows after `header_rows` as a list of lists.

    If `columns` is given, only those (1-indexed) columns are kept.
    Cells that fail isinstance(.., (int,float)) are kept as-is.
    """
    import openpyxl

    wb = openpyxl.load_workbook(xlsx_path, data_only=True, read_only=True)
    ws = wb[sheet_name]
    rows: list[list] = []
    for r_idx, row in enumerate(ws.iter_rows(values_only=True), start=1):
        if r_idx <= header_rows:
            continue
        if columns:
            row = [row[c - 1] if c - 1 < len(row) else None for c in columns]
        rows.append(list(row))
    return rows


def filter_numeric_pairs(rows: list[list], col_x: int = 0, col_y: int = 1):
    """Keep only rows where both selected columns are numbers; return two lists."""
    xs, ys = [], []
    for r in rows:
        x = r[col_x] if col_x < len(r) else None
        y = r[col_y] if col_y < len(r) else None
        if isinstance(x, (int, float)) and isinstance(y, (int, float)):
            xs.append(float(x))
            ys.append(float(y))
    return xs, ys

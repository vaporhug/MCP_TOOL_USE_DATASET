"""Local file-system retrieval helpers.

These tools answer "what files exist", "what columns does this xlsx have"
type questions so the agent can locate data without guessing paths.
"""
import os


def list_files(directory: str, pattern: str = "") -> list[str]:
    """Return absolute paths of files in `directory` matching `pattern` (substring)."""
    out = []
    if not os.path.isdir(directory):
        return out
    for name in sorted(os.listdir(directory)):
        path = os.path.join(directory, name)
        if os.path.isfile(path) and (pattern == "" or pattern in name):
            out.append(path)
    return out


def file_size_bytes(path: str) -> int:
    return os.path.getsize(path) if os.path.isfile(path) else -1


def describe_xlsx(xlsx_path: str) -> dict:
    """Return per-sheet shape and the first two header rows."""
    import openpyxl

    wb = openpyxl.load_workbook(xlsx_path, data_only=True, read_only=True)
    info: dict = {}
    for s in wb.sheetnames:
        ws = wb[s]
        h1 = h2 = None
        for r_idx, row in enumerate(ws.iter_rows(values_only=True), start=1):
            if r_idx == 1:
                h1 = list(row)
            elif r_idx == 2:
                h2 = list(row)
                break
        info[s] = {
            "max_row": ws.max_row,
            "max_col": ws.max_column,
            "header_row1": h1,
            "header_row2": h2,
        }
    return info

#!/usr/bin/env python3
"""Low-level primitives for analysing absorption-coefficient spectra and the
acoustic impedance of a fluid-loaded thin cylindrical viscoelastic shell.

All routines operate on user-supplied numerical inputs; none of them embed
the result expected by the task. The equations below are the standard
Helmholtz / Rayleigh / Kirchhoff–Love thin-shell formulations and serve as
ordinary computational building blocks.
"""
from __future__ import annotations

import math

import numpy as np
from scipy.special import jv

try:
    from mcp.server.fastmcp import FastMCP

    mcp = FastMCP("Viscoelastic_Acoustics_Tools")
except Exception:  # MCP is optional for offline use
    class _Stub:  # noqa: D401
        def tool(self, *a, **k):
            def deco(f):
                return f

            return deco

    mcp = _Stub()


# ---------------------------------------------------------------------------
# 1. Absorption-spectrum analysis
# ---------------------------------------------------------------------------
@mcp.tool()
def absorption_spectrum_summary(frequencies: list, absorption: list) -> dict:
    """Summarise an absorption spectrum.

    Returns peak alpha, frequency at peak, spectral mean, and the lowest /
    highest frequency at which alpha exceeds the half-max value.
    """
    f = np.asarray(frequencies, dtype=float)
    a = np.asarray(absorption, dtype=float)
    if f.size == 0 or a.size == 0:
        return {"error": "empty input"}
    i_max = int(np.argmax(a))
    peak = float(a[i_max])
    half = peak / 2.0
    above = np.where(a >= half)[0]
    return {
        "n_points": int(f.size),
        "f_min": float(f.min()),
        "f_max": float(f.max()),
        "peak_alpha": round(peak, 6),
        "peak_freq_Hz": round(float(f[i_max]), 3),
        "mean_alpha": round(float(a.mean()), 6),
        "fwhm_lo_Hz": round(float(f[above[0]]), 3) if above.size else None,
        "fwhm_hi_Hz": round(float(f[above[-1]]), 3) if above.size else None,
        "fwhm_bandwidth_Hz": (
            round(float(f[above[-1]] - f[above[0]]), 3) if above.size else None
        ),
    }


@mcp.tool()
def fraction_above_threshold(
    frequencies: list, absorption: list, threshold: float
) -> dict:
    """Return the frequency intervals (and count) where alpha >= threshold.

    Scans for ALL contiguous runs of frequencies whose absorption exceeds
    ``threshold`` rather than collapsing them to a single global min/max
    interval. The output ``intervals`` lists every such run; ``longest_run``
    is the single longest one (the dominant absorption band). The legacy
    ``freq_lo_Hz`` / ``freq_hi_Hz`` / ``bandwidth_Hz`` fields now refer to
    the LONGEST contiguous run (not the global min/max), so a spectrum
    with a sub-threshold dip mid-band is no longer reported as one
    continuous wide band.
    """
    f = np.asarray(frequencies, dtype=float)
    a = np.asarray(absorption, dtype=float)
    mask = a >= threshold
    n_hits = int(mask.sum())
    runs = []
    if n_hits and f.size:
        in_run = False
        run_start = None
        for i, m in enumerate(mask.tolist()):
            if m and not in_run:
                in_run = True
                run_start = i
            elif (not m) and in_run:
                in_run = False
                runs.append((run_start, i - 1))
        if in_run:
            runs.append((run_start, len(mask) - 1))
    intervals = [
        {
            "freq_lo_Hz": round(float(f[s]), 3),
            "freq_hi_Hz": round(float(f[e]), 3),
            "bandwidth_Hz": round(float(f[e] - f[s]), 3),
            "n_points": int(e - s + 1),
        }
        for s, e in runs
    ]
    longest = max(intervals, key=lambda x: x["bandwidth_Hz"]) if intervals else None
    return {
        "threshold": threshold,
        "n_above": n_hits,
        "n_total": int(f.size),
        "fraction": round(n_hits / max(f.size, 1), 4),
        "intervals": intervals,
        "n_runs": len(intervals),
        "longest_run": longest,
        "freq_lo_Hz": longest["freq_lo_Hz"] if longest else None,
        "freq_hi_Hz": longest["freq_hi_Hz"] if longest else None,
        "bandwidth_Hz": longest["bandwidth_Hz"] if longest else None,
    }


@mcp.tool()
def integrate_spectrum(frequencies: list, absorption: list) -> dict:
    """Trapezoidal integral of alpha(f) and the band-averaged absorption."""
    f = np.asarray(frequencies, dtype=float)
    a = np.asarray(absorption, dtype=float)
    if f.size < 2:
        return {"error": "need at least two samples"}
    integral = float(np.trapz(a, f))
    avg = integral / float(f[-1] - f[0])
    return {
        "integral_Hz": round(integral, 6),
        "band_average_alpha": round(avg, 6),
        "f_lo_Hz": float(f[0]),
        "f_hi_Hz": float(f[-1]),
    }


# ---------------------------------------------------------------------------
# 2. Frequency-domain transfer functions / impedance models
# ---------------------------------------------------------------------------
@mcp.tool()
def absorption_from_impedance(
    Z_real: list, Z_imag: list, rho_c: float = 413.0, normalised: bool = False
) -> dict:
    """Convert specific acoustic impedance Z = R + jX to normal-incidence
    absorption alpha = 1 - |(Z - rho_c)/(Z + rho_c)|^2.

    Pass ``normalised=True`` (and leave ``rho_c`` at its default 413.0) when
    ``Z_real`` / ``Z_imag`` are already normalised by the characteristic
    acoustic impedance of air (i.e. the paper's ``x_s`` / ``y_s`` columns
    or any other dimensionless impedance) — the reference value is then
    set to 1.0 internally. Pass ``normalised=False`` (default) and a
    custom ``rho_c`` when ``Z_real`` / ``Z_imag`` are absolute SI
    impedance values (Pa·s/m) and ``rho_c`` is the air characteristic
    impedance (≈ 413 Pa·s/m at room temperature).
    """
    R = np.asarray(Z_real, dtype=float)
    X = np.asarray(Z_imag, dtype=float)
    Z = R + 1j * X
    ref = 1.0 if normalised else float(rho_c)
    refl = (Z - ref) / (Z + ref)
    alpha = 1.0 - np.abs(refl) ** 2
    return {
        "n": int(R.size),
        "alpha": [round(float(v), 6) for v in alpha.tolist()],
        "alpha_max": round(float(alpha.max()), 6) if alpha.size else None,
    }


@mcp.tool()
def air_column_impedance(
    frequency_Hz: float,
    neck_radius_m: float,
    neck_length_m: float,
    cavity_radius_m: float,
    rho0: float = 1.2041,
    c0: float = 343.6,
    mu: float = 1.825e-5,
) -> dict:
    """Crandall + Rayleigh end-correction impedance of the air column inside a
    cylindrical neck of radius `a`, length `l`, terminated by a cavity of
    radius `R`. Returns Z_a (Pa s / m^3).
    """
    a = float(neck_radius_m)
    l = float(neck_length_m)
    R = float(cavity_radius_m)
    Om = 2.0 * math.pi * float(frequency_Hz)
    kv = np.sqrt(-1j * Om * rho0 / mu)
    visc_term = -mu * kv ** 2 * l / (
        1 - 2 * jv(1, kv * a) / (kv * a * jv(0, kv * a))
    )
    rad_loss = 2 * np.sqrt(2 * mu * Om * rho0)
    end_corr = 1j * Om * rho0 * 0.85 * a * (2 - 1.25 * a / R)
    Z_a = (1.0 / (math.pi * a ** 2)) * (visc_term + rad_loss + end_corr)
    return {"Z_a_real": float(Z_a.real), "Z_a_imag": float(Z_a.imag)}


@mcp.tool()
def cavity_reactance(
    frequency_Hz: float,
    cavity_volume_m3: float,
    rho0: float = 1.2041,
    c0: float = 343.6,
) -> dict:
    """Lumped acoustic reactance of an enclosed cavity (compliance limit)."""
    Om = 2.0 * math.pi * float(frequency_Hz)
    Z_c = -1j * rho0 * c0 ** 2 / (Om * float(cavity_volume_m3))
    return {"Z_c_real": float(Z_c.real), "Z_c_imag": float(Z_c.imag)}


@mcp.tool()
def shell_impedance_lumped(
    frequency_Hz: float,
    youngs_modulus_Pa: float,
    rho_s_kg_m3: float,
    loss_factor_eta: float,
    poisson_ratio: float,
    shell_radius_m: float,
    shell_length_m: float,
    shell_thickness_m: float,
) -> dict:
    """Lumped acoustic impedance of a thin viscoelastic cylindrical shell
    (closed-form analytical model; eta is the structural loss factor).
    Returns the complex shell impedance Z_b in Pa s / m^3.
    """
    E = float(youngs_modulus_Pa)
    nu = float(poisson_ratio)
    rho_s = float(rho_s_kg_m3)
    eta = float(loss_factor_eta)
    a = float(shell_radius_m)
    l = float(shell_length_m)
    t = float(shell_thickness_m)
    b = a + t / 2.0
    Om = 2.0 * math.pi * float(frequency_Hz)
    Estar = E / (1.0 - nu ** 2)
    Z_b = (Estar * t) / (2.0 * math.pi * l * Om * b ** 3) * (
        eta + 1j * (rho_s * b ** 2 * Om ** 2 / Estar - 1.0)
    )
    return {"Z_b_real": float(Z_b.real), "Z_b_imag": float(Z_b.imag)}


@mcp.tool()
def closed_form_absorption(
    frequencies: list,
    youngs_modulus_Pa: float,
    rho_s_kg_m3: float,
    loss_factor_eta: float,
    poisson_ratio: float,
    shell_radius_m: float,
    shell_length_m: float,
    shell_thickness_m: float,
    cavity_radius_m: float,
    cavity_height_m: float,
    tube_diameter_m: float,
    rho0: float = 1.2041,
    c0: float = 343.6,
    mu: float = 1.825e-5,
) -> dict:
    """Closed-form predicted alpha(f) using the analytical model
    Z_e = tanh(sqrt(Z_a/Z_b))*sqrt(Z_a Z_b) + Z_c.

    Returns alpha, normalised resistance x_s, and reactance y_s for each
    requested frequency.
    """
    f = np.asarray(frequencies, dtype=float)
    a = float(shell_radius_m)
    l = float(shell_length_m)
    t = float(shell_thickness_m)
    R = float(cavity_radius_m)
    h = float(cavity_height_m)
    D = float(tube_diameter_m)
    nu = float(poisson_ratio)
    E = float(youngs_modulus_Pa)
    rho_s = float(rho_s_kg_m3)
    eta = float(loss_factor_eta)
    S = math.pi * D ** 2 / 4.0
    Estar = E / (1.0 - nu ** 2)
    V = math.pi * R ** 2 * h - math.pi * (a + t) ** 2 * l
    b = a + t / 2.0

    alpha = np.zeros_like(f)
    xs = np.zeros_like(f)
    ys = np.zeros_like(f)
    for i, fi in enumerate(f):
        Om = 2.0 * math.pi * fi
        kv = np.sqrt(-1j * Om * rho0 / mu)
        Z_a = (1.0 / (math.pi * a ** 2)) * (
            -mu * kv ** 2 * l / (1 - 2 * jv(1, kv * a) / (kv * a * jv(0, kv * a)))
            + 2 * np.sqrt(2 * mu * Om * rho0)
            + 1j * Om * rho0 * 0.85 * a * (2 - 1.25 * a / R)
        )
        Z_c = -1j * rho0 * c0 ** 2 / (Om * V)
        Z_b = Estar * t / (2.0 * math.pi * l * Om * b ** 3) * (
            eta + 1j * (rho_s * b ** 2 * Om ** 2 / Estar - 1.0)
        )
        Z_e = np.tanh(np.sqrt(Z_a / Z_b)) * np.sqrt(Z_a * Z_b) + Z_c
        alpha[i] = 1.0 - abs((Z_e * S - rho0 * c0) / (Z_e * S + rho0 * c0)) ** 2
        Zn = Z_e * S / (rho0 * c0)
        xs[i] = float(Zn.real)
        ys[i] = float(Zn.imag)

    return {
        "n": int(f.size),
        "frequencies_Hz": f.tolist(),
        "alpha": [round(float(v), 6) for v in alpha.tolist()],
        "x_s_normalised_resistance": [round(float(v), 6) for v in xs.tolist()],
        "y_s_normalised_reactance": [round(float(v), 6) for v in ys.tolist()],
        "cavity_volume_mm3": round(V * 1e9, 2),
    }


# ---------------------------------------------------------------------------
# 3. Material characterisation helpers
# ---------------------------------------------------------------------------
@mcp.tool()
def dma_high_freq_plateau(
    frequency_Hz: list,
    storage_modulus: list,
    loss_factor: list,
    tail_fraction: float = 0.25,
) -> dict:
    """Average storage modulus E' and loss factor eta over the highest
    `tail_fraction` of the supplied DMA frequency sweep — used to read off the
    high-frequency plateau values.
    """
    f = np.asarray(frequency_Hz, dtype=float)
    Es = np.asarray(storage_modulus, dtype=float)
    eta = np.asarray(loss_factor, dtype=float)
    if f.size == 0:
        return {"error": "empty"}
    n_tail = max(1, int(round(tail_fraction * f.size)))
    sl = slice(-n_tail, None)
    return {
        "tail_fraction": tail_fraction,
        "n_tail": n_tail,
        "f_tail_Hz": [float(v) for v in f[sl]],
        "E_storage_mean": round(float(Es[sl].mean()), 4),
        "eta_mean": round(float(eta[sl].mean()), 4),
        "E_storage_max": round(float(Es[sl].max()), 4),
    }


@mcp.tool()
def compare_two_spectra(
    f1: list, a1: list, f2: list, a2: list, freq_tol: float = 0.5
) -> dict:
    """Pair two spectra by nearest frequency match and report the RMS and
    maximum absolute differences in absorption."""
    F1 = np.asarray(f1, dtype=float)
    A1 = np.asarray(a1, dtype=float)
    F2 = np.asarray(f2, dtype=float)
    A2 = np.asarray(a2, dtype=float)
    diffs = []
    for fi, ai in zip(F1, A1):
        j = int(np.argmin(np.abs(F2 - fi)))
        if abs(F2[j] - fi) <= freq_tol:
            diffs.append(ai - A2[j])
    if not diffs:
        return {"matched": 0}
    d = np.asarray(diffs, dtype=float)
    return {
        "matched": int(d.size),
        "rms_diff": round(float(np.sqrt((d ** 2).mean())), 6),
        "max_abs_diff": round(float(np.abs(d).max()), 6),
        "mean_diff": round(float(d.mean()), 6),
    }


# ---------------------------------------------------------------------------
# 4. Plotting (one tool per image-type answer)
# ---------------------------------------------------------------------------
def _ensure_dir(path: str) -> None:
    import os

    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)


@mcp.tool()
def plot_two_panel_spectra(
    f_left: list,
    a_left: list,
    label_left: str,
    f_right: list,
    a_right: list,
    label_right: str,
    output_path: str,
    title_left: str = "",
    title_right: str = "",
) -> str:
    """Render two absorption spectra side-by-side and save to PDF/PNG.
    Returns the absolute output path."""
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    _ensure_dir(output_path)
    fig, ax = plt.subplots(1, 2, figsize=(8.4, 3.4))
    ax[0].plot(f_left, a_left, lw=2, color="#1f77b4", label=label_left)
    ax[0].fill_between(f_left, a_left, alpha=0.25, color="#1f77b4")
    ax[0].set_title(title_left)
    ax[0].set_xlabel("Frequency (Hz)")
    ax[0].set_ylabel("Absorption coefficient α")
    ax[0].set_ylim(0, 1.05)
    ax[0].grid(alpha=0.3)
    ax[1].plot(f_right, a_right, lw=2, color="#d62728", label=label_right)
    ax[1].fill_between(f_right, a_right, alpha=0.25, color="#d62728")
    ax[1].set_title(title_right)
    ax[1].set_xlabel("Frequency (Hz)")
    ax[1].set_ylabel("Absorption coefficient α")
    ax[1].set_ylim(0, 1.05)
    ax[1].grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig(output_path, bbox_inches="tight")
    plt.close()
    import os

    return os.path.abspath(output_path)


@mcp.tool()
def plot_exp_vs_model(
    frequency_exp: list,
    alpha_exp: list,
    frequency_model: list,
    alpha_model: list,
    output_path: str,
    threshold: float | None = None,
    band_lo: float | None = None,
    band_hi: float | None = None,
    title: str = "Absorption: experiment vs model",
) -> str:
    """Plot experimental and modelled spectra together; optionally annotate a
    high-absorption band and a threshold line. Returns absolute output path."""
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    _ensure_dir(output_path)
    fig, ax = plt.subplots(figsize=(6.2, 3.6))
    ax.plot(
        frequency_exp,
        alpha_exp,
        color="#9467bd",
        lw=1.2,
        alpha=0.75,
        label="Experiment",
    )
    ax.plot(
        frequency_model,
        alpha_model,
        color="k",
        lw=1.8,
        ls="--",
        label="Model",
    )
    if threshold is not None:
        ax.axhline(threshold, color="red", ls=":", lw=1.0)
    if band_lo is not None and band_hi is not None:
        ax.fill_betweenx([0, 1.05], band_lo, band_hi, color="gold", alpha=0.18)
    ax.set_xlabel("Frequency (Hz)")
    ax.set_ylabel("Absorption coefficient α")
    ax.set_ylim(0, 1.05)
    ax.set_title(title)
    ax.grid(alpha=0.3)
    ax.legend(loc="upper right")
    plt.tight_layout()
    plt.savefig(output_path, bbox_inches="tight")
    plt.close()
    import os

    return os.path.abspath(output_path)


@mcp.tool()
def plot_dma_and_dissipation(
    f_dma: list,
    E_storage_kPa: list,
    eta_loss: list,
    f_diss: list,
    p_air: list,
    p_rubber: list,
    output_path: str,
    title_left: str = "DMA: storage modulus & loss factor",
    title_right: str = "Dissipated power per domain",
) -> str:
    """Side-by-side: DMA frequency sweep (E', eta) and dissipation pathway
    (air thermo-viscous vs rubber viscoelastic). Returns absolute output."""
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    _ensure_dir(output_path)
    fig, axes = plt.subplots(1, 2, figsize=(8.6, 3.4))
    ax = axes[0]
    ax2 = ax.twinx()
    ax.plot(f_dma, E_storage_kPa, "o-", color="#1f77b4", lw=1.5, ms=4)
    ax2.plot(f_dma, eta_loss, "s-", color="#ff7f0e", lw=1.5, ms=4)
    ax.set_xlabel("Frequency (Hz)")
    ax.set_ylabel("Storage modulus E' (kPa)", color="#1f77b4")
    ax2.set_ylabel("Loss factor η", color="#ff7f0e")
    ax.tick_params(axis="y", labelcolor="#1f77b4")
    ax2.tick_params(axis="y", labelcolor="#ff7f0e")
    ax.set_title(title_left)
    ax.grid(alpha=0.3)

    ax = axes[1]
    ax.plot(f_diss, p_air, color="#1f77b4", lw=1.6, label="Air thermo-viscous")
    ax.plot(f_diss, p_rubber, color="#d62728", lw=1.6, label="Rubber viscoelastic")
    ax.set_xlabel("Frequency (Hz)")
    ax.set_ylabel("Dissipated power")
    ax.set_title(title_right)
    ax.grid(alpha=0.3)
    ax.legend(loc="upper right")
    plt.tight_layout()
    plt.savefig(output_path, bbox_inches="tight")
    plt.close()
    import os

    return os.path.abspath(output_path)


@mcp.tool()
def plot_exp_vs_model_and_dma(
    f_alpha: list,
    alpha_exp: list,
    alpha_sim: list,
    f_dma: list,
    E_storage_kPa: list,
    eta_loss: list,
    output_path: str,
    title_left: str = "Experiment vs FEM/closed-form model",
    title_right: str = "DMA: storage modulus & loss factor",
    label_exp: str = "Experiment",
    label_sim: str = "Model",
) -> str:
    """Side-by-side: left panel = experimental absorption vs FEM /
    closed-form model on the same frequency axis; right panel = DMA
    sweep with storage modulus E' (left axis, kPa) and loss factor η
    (right axis). Designed for the answer's Fig2 layout. Returns the
    absolute output path."""
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    _ensure_dir(output_path)
    fig, axes = plt.subplots(1, 2, figsize=(8.6, 3.4))
    ax = axes[0]
    ax.plot(f_alpha, alpha_exp, "-", color="#1f77b4", lw=1.5, label=label_exp)
    ax.plot(f_alpha, alpha_sim, "--", color="#d62728", lw=1.5, label=label_sim)
    ax.set_xlabel("Frequency (Hz)")
    ax.set_ylabel("Absorption α")
    ax.set_ylim(0, 1.05)
    ax.set_title(title_left)
    ax.grid(alpha=0.3)
    ax.legend(loc="best")

    ax = axes[1]
    ax2 = ax.twinx()
    ax.plot(f_dma, E_storage_kPa, "o-", color="#1f77b4", lw=1.5, ms=4)
    ax2.plot(f_dma, eta_loss, "s-", color="#ff7f0e", lw=1.5, ms=4)
    ax.set_xlabel("Frequency (Hz)")
    ax.set_ylabel("Storage modulus E' (kPa)", color="#1f77b4")
    ax2.set_ylabel("Loss factor η", color="#ff7f0e")
    ax.tick_params(axis="y", labelcolor="#1f77b4")
    ax2.tick_params(axis="y", labelcolor="#ff7f0e")
    ax.set_title(title_right)
    ax.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig(output_path, bbox_inches="tight")
    plt.close()
    import os

    return os.path.abspath(output_path)


@mcp.tool()
def plot_absorber_and_dissipation(
    f_alpha: list,
    alpha_exp: list,
    alpha_recursive: list,
    f_diss: list,
    p_air: list,
    p_rubber: list,
    output_path: str,
    title_left: str = "Absorption spectrum — measurement vs recursive model",
    title_right: str = "Dissipated power per domain",
    band_lo_Hz: float | None = None,
    band_hi_Hz: float | None = None,
    band_threshold: float | None = None,
    measurement_label: str = "Measurement",
    model_label: str = "Recursive model",
) -> str:
    """Side-by-side composite plot for any absorber sample: left panel =
    measured absorption spectrum vs the recursive-model prediction (both
    series user-provided), with optional band annotation
    (``band_lo_Hz`` / ``band_hi_Hz`` shade a frequency interval;
    ``band_threshold`` draws a horizontal reference line at
    α = threshold); right panel = dissipated-power decomposition (air
    thermo-viscous vs rubber viscoelastic). Generic — callers pass
    their own sample identification via the title arguments. Returns
    the absolute output path."""
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    _ensure_dir(output_path)
    fig, axes = plt.subplots(1, 2, figsize=(8.6, 3.4))
    ax = axes[0]
    ax.plot(f_alpha, alpha_exp, "-", color="#1f77b4", lw=1.5, label=measurement_label)
    ax.plot(f_alpha, alpha_recursive, "--", color="#d62728", lw=1.5,
            label=model_label)
    ax.set_xlabel("Frequency (Hz)")
    ax.set_ylabel("Absorption α")
    ax.set_ylim(0, 1.05)
    if band_threshold is not None:
        ax.axhline(band_threshold, color="grey", lw=0.8, ls=":")
    if band_lo_Hz is not None and band_hi_Hz is not None:
        ax.axvspan(band_lo_Hz, band_hi_Hz, color="#9467bd", alpha=0.15)
    ax.set_title(title_left)
    ax.grid(alpha=0.3)
    ax.legend(loc="best")

    ax = axes[1]
    ax.plot(f_diss, p_air, color="#1f77b4", lw=1.6, label="Air thermo-viscous")
    ax.plot(f_diss, p_rubber, color="#d62728", lw=1.6, label="Rubber viscoelastic")
    ax.set_xlabel("Frequency (Hz)")
    ax.set_ylabel("Dissipated power")
    ax.set_title(title_right)
    ax.grid(alpha=0.3)
    ax.legend(loc="upper right")
    plt.tight_layout()
    plt.savefig(output_path, bbox_inches="tight")
    plt.close()
    import os

    return os.path.abspath(output_path)


if __name__ == "__main__":
    mcp.run(transport="stdio")

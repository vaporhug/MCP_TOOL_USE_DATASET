"""Low-level thermoelectric transport analysis primitives.

Numerical Fermi-Dirac integrals, Single Kane Band (SKB) model transport
coefficients, lattice thermal conductivity separation, Pisarenko relation,
and figure-of-merit calculation. All functions are generic — no paper-specific
constants or results are embedded.

Unit convention for the bundled source_data.xlsx
-------------------------------------------------
The Excel resistivity column is labelled ``Resistivity(m Ohm*m)`` i.e. it is in
milli-Ohm-metre (mOhm*m). Use :func:`resistivity_to_conductivity` (which divides
by 1e-3 to reach Ohm*m before inverting) to obtain sigma in S/m. The column is
*not* mOhm*cm: interpreting it as mOhm*cm would scale sigma by 100x to an
unphysical magnitude and drive kappa_ele above kappa_tot, giving an
(unphysical) negative kappa_lat. mOhm*m is the correct unit.

Lorenz number / lattice thermal conductivity caveat
---------------------------------------------------
:func:`lorenz_skb_from_seebeck` reproduces the paper's stated Methods procedure
(SKB Lorenz number determined from the experimental Seebeck coefficient): the
magnitude of the measured Seebeck coefficient is inverted through the SKB
Seebeck relation to obtain the reduced Fermi level, which then enters the SKB
Lorenz relation. Be aware that a single-point SKB inversion of a tabulated
Seebeck value and a Lorenz number quoted directly in a paper's text can imply
different effective Lorenz numbers. Consequently a ``kappa_lat`` *recomputed
from the bundled transport table via this SKB/Lorenz method* may differ from a
``kappa_lat`` *quoted in the paper text*; report the two separately rather than
forcing them to agree.
"""
import math
from typing import Sequence


# ---------------------------------------------------------------------------
# Fermi-Dirac integrals
# ---------------------------------------------------------------------------

def fermi_integral(eta: float, order: float, n_points: int = 2000) -> float:
    """Numerical Fermi-Dirac integral F_n(eta) via trapezoidal rule.

    F_n(eta) = integral_0^inf  x^n / (1 + exp(x - eta))  dx

    Parameters
    ----------
    eta : float
        Reduced chemical potential (E_F / k_B T).
    order : float
        Order *n* of the integral (can be half-integer, e.g. 0.5, 1.5).
    n_points : int
        Number of quadrature points (default 2000).

    Returns
    -------
    float
        Value of F_n(eta).
    """
    x_max = max(50.0, eta + 50.0)
    dx = x_max / n_points
    total = 0.0
    for i in range(1, n_points):
        x = i * dx
        exponent = x - eta
        if exponent > 500:
            break
        if exponent < -500:
            f = x ** order
        else:
            f = (x ** order) / (1.0 + math.exp(exponent))
        total += f
    return total * dx


def kane_fermi_integral(eta: float, order: float, alpha: float,
                        n_points: int = 2000) -> float:
    """Generalised Fermi-Dirac integral for Kane (non-parabolic) band.

    K_n(eta, alpha) = integral_0^inf  (-df/dx) * (x*(1+alpha*x))^n
                      * (1+2*alpha*x)  dx

    where f = 1/(1+exp(x-eta)) is the Fermi function and alpha = k_B T / E_g
    is the non-parabolicity parameter.

    Parameters
    ----------
    eta : float
        Reduced chemical potential.
    order : float
        Transport integral order.
    alpha : float
        Non-parabolicity parameter (k_B T / E_g).
    n_points : int
        Number of quadrature points.

    Returns
    -------
    float
        Value of the Kane-modified integral.
    """
    x_max = max(50.0, eta + 50.0)
    dx = x_max / n_points
    total = 0.0
    for i in range(1, n_points):
        x = i * dx
        exponent = x - eta
        if exponent > 500:
            break
        if exponent < -500:
            dfx = 0.0
        else:
            ex = math.exp(exponent)
            dfx = ex / (1.0 + ex) ** 2
        eps_kane = x * (1.0 + alpha * x)
        vel_factor = 1.0 + 2.0 * alpha * x
        if eps_kane < 0:
            eps_kane = 0.0
        total += dfx * (eps_kane ** order) * vel_factor
    return total * dx


# ---------------------------------------------------------------------------
# SKB / SPB transport coefficients
# ---------------------------------------------------------------------------

def gfdi_skb(eta: float, n: int, m: float, k: float, alpha: float,
             n_points: int = 4000) -> float:
    """Generalised Fermi-Dirac integral (GFDI) for the Single Kane Band model.

    Implements the SKB GFDI of Lin & Liu, *Sci. Rep.* **12**, 7056 (2022),
    Eq. (26):

        ^n F_k^m(eta) = integral_0^inf  (-df/dx) * x^n * (x + alpha*x^2)^m
                        * [ (1 + 2*alpha*x)^2 + 2 ]^(k/2)  dx

    where ``x = E/(k_B T)`` is the reduced energy, ``f = 1/(1+exp(x-eta))`` the
    Fermi function, ``eta`` the reduced Fermi level, and ``alpha = k_B T / E_g``
    the reciprocal reduced band gap (non-parabolicity parameter, denoted
    ``epsilon`` in the paper).

    The transport coefficients use the moments with ``m = 1`` and ``k = -2``
    (paper Eqs. (40)-(41)): ``^0 F_{-2}^1``, ``^1 F_{-2}^1`` and
    ``^2 F_{-2}^1``.

    SPB limit (alpha -> 0):
        (x + alpha*x^2)^m -> x^m  and  [(1+2*alpha*x)^2 + 2]^(k/2) -> 3^(k/2).
    With m = 1, k = -2 the constant 3^(-1) cancels in every transport ratio and

        ^n F_{-2}^1 -> (1/3) * integral (-df/dx) * x^(n+1) dx
                     = (1/3) * (n+1) * F_n(eta),

    so ``^1 F_{-2}^1 / ^0 F_{-2}^1 -> 2 F_1/F_0`` and
    ``^2 F_{-2}^1 / ^0 F_{-2}^1 -> 3 F_2/F_0`` -- i.e. the Seebeck and Lorenz
    expressions reduce *exactly* to the standard single parabolic band (SPB)
    forms S = (k_B/e)[2 F_1/F_0 - eta] and
    L = (k_B/e)^2 [3 F_2/F_0 - (2 F_1/F_0)^2].

    Parameters
    ----------
    eta : float
        Reduced Fermi level.
    n : int
        Reduced-energy power (left subscript ``n``).
    m : float
        Power of the Kane dispersion factor (x + alpha*x^2) (upper index ``m``).
    k : float
        Power index of the velocity/relaxation factor
        [(1+2*alpha*x)^2 + 2] (lower index ``k``).
    alpha : float
        Non-parabolicity parameter k_B T / E_g (0 = parabolic SPB).
    n_points : int
        Number of left-Riemann quadrature points.

    Returns
    -------
    float
        Value of ^n F_k^m(eta).
    """
    a = max(alpha, 0.0)
    x_max = max(60.0, eta + 60.0)
    dx = x_max / n_points
    total = 0.0
    for i in range(1, n_points):
        x = i * dx
        exponent = x - eta
        if exponent > 500:
            break
        if exponent < -500:
            dfx = 0.0
        else:
            ex = math.exp(exponent)
            dfx = ex / (1.0 + ex) ** 2          # -df/dx
        kane = x + a * x * x                      # x + alpha*x^2
        if kane < 0:
            kane = 0.0
        vel = (1.0 + 2.0 * a * x) ** 2 + 2.0     # (1+2*alpha*x)^2 + 2
        total += dfx * (x ** n) * (kane ** m) * (vel ** (k / 2.0))
    return total * dx


def _transport_integral(eta: float, n: int, alpha: float,
                        n_points: int = 4000) -> float:
    """SKB transport moment ^n F_{-2}^1(eta) used by the Seebeck and Lorenz
    relations (Lin & Liu 2022, Eqs. (40)-(41)).

    Thin wrapper around :func:`gfdi_skb` with the transport indices m = 1,
    k = -2. For ``alpha = 0`` it reduces to ``(1/3)(n+1) F_n(eta)`` so that the
    transport ratios recover the single parabolic band limit exactly.
    """
    return gfdi_skb(eta, n, m=1.0, k=-2.0, alpha=alpha, n_points=n_points)


def skb_seebeck(eta: float, r: float = 0.5, alpha: float = 0.0) -> float:
    """Seebeck coefficient from the Single Kane Band (SKB) model.

    With the non-parabolicity parameter ``alpha = k_B T / E_g`` the Seebeck
    coefficient is

        S = (k_B/e) * [ ^1_I / ^0_I - eta ]

    where ^n_I are the SKB transport integrals (``_transport_integral``)
    evaluated for the Kane dispersion eps(1+alpha*eps). For ``alpha = 0`` the
    integrals reduce to the single parabolic band (SPB) acoustic-phonon
    moments and S recovers the standard SPB expression
    S = (k_B/e)[2 F_1(eta)/F_0(eta) - eta].

    Parameters
    ----------
    eta : float
        Reduced chemical potential.
    r : float
        Scattering parameter (retained for the parabolic fall-back path;
        acoustic-phonon SKB uses the Kane kernel directly when alpha > 0).
    alpha : float
        Kane non-parabolicity parameter k_B T / E_g (0 = parabolic SPB).

    Returns
    -------
    float
        Seebeck coefficient in V/K.
    """
    kB_over_e = 8.617333e-5  # V/K  (k_B/e)
    a = max(alpha, 0.0)
    I0 = _transport_integral(eta, 0, a)
    I1 = _transport_integral(eta, 1, a)
    if abs(I0) < 1e-30:
        return 0.0
    return kB_over_e * (I1 / I0 - eta)


def skb_lorenz(eta: float, r: float = 0.5, alpha: float = 0.0) -> float:
    """Lorenz number from the Single Kane Band (SKB) model.

    With the Kane non-parabolicity parameter ``alpha = k_B T / E_g``:

        L = (k_B/e)^2 * [ ^2_I/^0_I - ( ^1_I/^0_I )^2 ]

    where ^n_I are the SKB transport integrals. For ``alpha = 0`` this reduces
    to the parabolic acoustic-phonon Lorenz number
    L = (k_B/e)^2 [ 3 F_2/F_0 - (2 F_1/F_0)^2 ].

    Parameters
    ----------
    eta : float
        Reduced chemical potential.
    r : float
        Scattering parameter (parabolic fall-back path).
    alpha : float
        Kane non-parabolicity parameter k_B T / E_g (0 = parabolic SPB).

    Returns
    -------
    float
        Lorenz number in W Ohm K^-2.
    """
    kB_over_e = 8.617333e-5  # V/K
    a = max(alpha, 0.0)
    I0 = _transport_integral(eta, 0, a)
    I1 = _transport_integral(eta, 1, a)
    I2 = _transport_integral(eta, 2, a)
    if abs(I0) < 1e-30:
        return 0.0
    return (kB_over_e ** 2) * (I2 / I0 - (I1 / I0) ** 2)


def kane_alpha(T: float, E_g_eV: float) -> float:
    """Kane non-parabolicity parameter alpha = k_B T / E_g.

    Parameters
    ----------
    T : float
        Temperature in K.
    E_g_eV : float
        Band gap in eV (for PbSe E_g ~ 0.27 eV at 300 K, increasing with T).

    Returns
    -------
    float
        Dimensionless non-parabolicity parameter.
    """
    kB_eV = 8.617333e-5  # eV/K
    if E_g_eV <= 0:
        return 0.0
    return kB_eV * T / E_g_eV


def lorenz_from_seebeck(S_uVK: float) -> float:
    """Approximate Lorenz number from experimental Seebeck coefficient.

    L = 1.5 + exp(-|S|/116)   [in units of 10^-8 W Ohm K^-2]

    This empirical formula (Kim et al., APL Mater. 2015) is accurate to ~20%
    for most thermoelectric materials with single-band transport.

    Parameters
    ----------
    S_uVK : float
        Absolute Seebeck coefficient in uV/K.

    Returns
    -------
    float
        Lorenz number in 10^-8 W Ohm K^-2.
    """
    return 1.5 + math.exp(-abs(S_uVK) / 116.0)


def eta_from_seebeck(S_target: float, r: float = 0.5,
                     eta_min: float = -10.0, eta_max: float = 30.0,
                     tol: float = 1e-8, alpha: float = 0.0) -> float:
    """Invert the SKB Seebeck relation to find the reduced chemical
    potential eta that produces a given Seebeck coefficient.

    Uses bisection search.

    Parameters
    ----------
    S_target : float
        Target Seebeck coefficient in V/K (signed).
    r : float
        Scattering parameter.
    eta_min, eta_max : float
        Search bounds for eta.
    tol : float
        Convergence tolerance on S.

    Returns
    -------
    float
        Reduced chemical potential eta.
    """
    for _ in range(200):
        eta_mid = 0.5 * (eta_min + eta_max)
        S_mid = skb_seebeck(eta_mid, r, alpha=alpha)
        if abs(S_mid - S_target) < tol:
            return eta_mid
        # Seebeck decreases with increasing eta for n-type
        if S_mid < S_target:
            eta_max = eta_mid
        else:
            eta_min = eta_mid
    return 0.5 * (eta_min + eta_max)


def lorenz_skb_from_seebeck(S_uVK: float, T: float, E_g_eV: float = 0.27,
                            r: float = 0.5) -> float:
    """SKB Lorenz number from an experimental Seebeck coefficient.

    Implements the procedure used in the paper's Methods ("the Lorenz number
    L is determined based on the experimental Seebeck coefficient and the
    single Kane band (SKB) model"): the magnitude of the measured Seebeck
    coefficient is inverted through the SKB Seebeck relation (with the Kane
    non-parabolicity ``alpha = k_B T / E_g``) to obtain the reduced chemical
    potential eta, which is then used in the SKB Lorenz relation.

    Parameters
    ----------
    S_uVK : float
        Absolute Seebeck coefficient in uV/K (sign ignored).
    T : float
        Temperature in K.
    E_g_eV : float
        Band gap in eV (PbSe ~ 0.27 eV; set 0 to force the parabolic SPB
        limit).
    r : float
        Scattering parameter for the parabolic fall-back path.

    Returns
    -------
    float
        Lorenz number in W Ohm K^-2.
    """
    alpha = kane_alpha(T, E_g_eV) if E_g_eV > 0 else 0.0
    S_VK = abs(S_uVK) * 1e-6
    eta = eta_from_seebeck(S_VK, r=r, alpha=alpha)
    return skb_lorenz(eta, r=r, alpha=alpha)


# ---------------------------------------------------------------------------
# Carrier concentration and Hall analysis
# ---------------------------------------------------------------------------

def carrier_concentration_from_hall(R_H: float) -> float:
    """Carrier concentration from Hall coefficient.

    n_H = 1 / (e * |R_H|)

    Parameters
    ----------
    R_H : float
        Hall coefficient in m^3/C (SI).

    Returns
    -------
    float
        Hall carrier concentration in m^-3.
    """
    e = 1.602176634e-19
    if abs(R_H) < 1e-30:
        return 0.0
    return 1.0 / (e * abs(R_H))


def hall_mobility(sigma: float, n_H: float) -> float:
    """Hall mobility from conductivity and Hall carrier concentration.

    mu_H = sigma / (n_H * e)

    Parameters
    ----------
    sigma : float
        Electrical conductivity in S/m.
    n_H : float
        Carrier concentration in m^-3.

    Returns
    -------
    float
        Hall mobility in m^2 V^-1 s^-1.
    """
    e = 1.602176634e-19
    if abs(n_H) < 1e-10:
        return 0.0
    return sigma / (n_H * e)


def effective_mass_from_seebeck_nH(S_uVK: float, n_H_cm3: float,
                                    T: float, r: float = -0.5) -> float:
    """Density-of-states effective mass from Seebeck and Hall carrier
    concentration, assuming a single parabolic band.

    Inverts the SPB Seebeck and n_H relations simultaneously using
    the reduced chemical potential as the intermediary.

    Parameters
    ----------
    S_uVK : float
        Absolute Seebeck coefficient in uV/K.
    n_H_cm3 : float
        Hall carrier concentration in cm^-3.
    T : float
        Temperature in K.
    r : float
        Scattering parameter (-0.5 for acoustic phonon).

    Returns
    -------
    float
        Density-of-states effective mass in units of electron mass (m_e).
    """
    S_VK = abs(S_uVK) * 1e-6
    eta = eta_from_seebeck(-S_VK if S_uVK < 0 else S_VK, r=r)
    kB = 1.380649e-23
    hbar = 1.054571817e-34
    m_e = 9.1093837015e-31
    n_SI = abs(n_H_cm3) * 1e6  # convert cm^-3 to m^-3
    F12 = fermi_integral(eta, 0.5)
    if F12 < 1e-30:
        return 0.0
    # Single parabolic band carrier density:
    #   n = (1/(2*pi^2)) * (2*m_star*kB*T/hbar^2)^{3/2} * F_{1/2}(eta)
    # Invert for m_star:
    #   m_star = (hbar^2 / (2*kB*T)) * (2*pi^2 * n / F_{1/2})^{2/3}
    m_star = (hbar ** 2 / (2.0 * kB * T)) * \
             (2.0 * math.pi ** 2 * n_SI / F12) ** (2.0 / 3.0)
    return m_star / m_e


# ---------------------------------------------------------------------------
# Thermal conductivity separation
# ---------------------------------------------------------------------------

def electronic_thermal_conductivity(L: float, sigma: float, T: float) -> float:
    """Electronic thermal conductivity via Wiedemann-Franz law.

    kappa_ele = L * sigma * T

    Parameters
    ----------
    L : float
        Lorenz number in W Ohm K^-2 (e.g. 2.44e-8 for metals).
    sigma : float
        Electrical conductivity in S/m.
    T : float
        Temperature in K.

    Returns
    -------
    float
        Electronic thermal conductivity in W m^-1 K^-1.
    """
    return L * sigma * T


def separate_lattice_thermal(kappa_total: float, L: float,
                              sigma: float, T: float) -> float:
    """Lattice thermal conductivity by subtracting electronic contribution.

    kappa_lat = kappa_total - L * sigma * T

    Parameters
    ----------
    kappa_total : float
        Total thermal conductivity in W m^-1 K^-1.
    L : float
        Lorenz number in W Ohm K^-2.
    sigma : float
        Electrical conductivity in S/m.
    T : float
        Temperature in K.

    Returns
    -------
    float
        Lattice thermal conductivity in W m^-1 K^-1.
    """
    kappa_ele = L * sigma * T
    return kappa_total - kappa_ele


# ---------------------------------------------------------------------------
# Pisarenko relation
# ---------------------------------------------------------------------------

def hall_factor_spb(eta: float) -> float:
    """Single-parabolic-band Hall factor r_H for acoustic-phonon scattering.

    Relates the Hall carrier concentration to the chemical (drift) carrier
    concentration via ``n_H = n_chemical / r_H`` (equivalently
    ``n_chemical = n_H * r_H``). For a single parabolic band limited by
    acoustic-phonon scattering the Hall factor is (e.g. Snyder, *Modeling
    thermoelectric transport at high temperatures*, Eq. 4; the bundled
    reference 3.pdf):

        r_H = (3/2) * F_{1/2}(eta) * F_{-1/2}(eta) / (2 * F_0(eta)^2)

    where ``F_n`` are the standard Fermi-Dirac integrals and ``eta`` is the
    reduced Fermi level. ``r_H`` is ~1.18 in the non-degenerate limit and tends
    to 1 for a strongly degenerate gas.

    Parameters
    ----------
    eta : float
        Reduced Fermi level (E_F / k_B T).

    Returns
    -------
    float
        Dimensionless Hall factor r_H.
    """
    F_m12 = _fermi_integral_sqrt_sub(eta, -0.5)
    F_12 = _fermi_integral_sqrt_sub(eta, 0.5)
    F_0 = fermi_integral(eta, 0.0)
    if abs(F_0) < 1e-30:
        return 1.0
    return 1.5 * F_12 * F_m12 / (2.0 * F_0 ** 2)


def _fermi_integral_sqrt_sub(eta: float, order: float,
                             n_points: int = 4000) -> float:
    """Fermi-Dirac integral F_n(eta) via the x = u^2 substitution.

    F_n(eta) = integral_0^inf x^n / (1 + exp(x - eta)) dx
             = integral_0^inf 2 u^(2n+1) / (1 + exp(u^2 - eta)) du.

    The substitution removes the integrable x^{-1/2} singularity at the origin
    that the plain uniform-grid :func:`fermi_integral` under-samples for the
    half-integer orders n = -1/2 and n = +1/2 used in the SPB Hall factor, so
    the non-degenerate limit r_H -> 3*pi/8 is recovered accurately.
    """
    u_max = math.sqrt(max(60.0, eta + 60.0))
    du = u_max / n_points
    total = 0.0
    p = 2.0 * order + 1.0
    for i in range(1, n_points):
        u = i * du
        exponent = u * u - eta
        if exponent > 500:
            break
        total += (u ** p) / (1.0 + math.exp(exponent))
    return 2.0 * total * du


def _eta_from_chemical_density(n_chem_SI: float, m_star_me: float,
                               T: float) -> float:
    """Reduced Fermi level eta for a given CHEMICAL carrier density.

    Inverts the single parabolic band density relation
    ``n = (1/(2 pi^2)) (2 m* k_B T / hbar^2)^{3/2} F_{1/2}(eta)`` for eta.
    """
    kB = 1.380649e-23
    hbar = 1.054571817e-34
    m_e = 9.1093837015e-31
    m_star = m_star_me * m_e
    coeff = (1.0 / (2.0 * math.pi ** 2)) * (2.0 * m_star * kB * T / hbar ** 2) ** 1.5
    target_F12 = n_chem_SI / coeff
    eta_lo, eta_hi = -20.0, 40.0
    for _ in range(200):
        eta_mid = 0.5 * (eta_lo + eta_hi)
        if fermi_integral(eta_mid, 0.5) < target_F12:
            eta_lo = eta_mid
        else:
            eta_hi = eta_mid
    return 0.5 * (eta_lo + eta_hi)


def pisarenko_relation(n_chem_cm3: float, m_star_me: float, T: float,
                       r: float = -0.5) -> float:
    """Theoretical Seebeck coefficient vs CHEMICAL carrier concentration.

    Single parabolic band Pisarenko relation: the supplied carrier
    concentration is treated as the **chemical (drift) carrier concentration**
    ``n`` (NOT the Hall concentration). The chemical density is inverted to the
    reduced Fermi level via
    ``n = (1/(2 pi^2)) (2 m* k_B T / hbar^2)^{3/2} F_{1/2}(eta)`` and the SPB
    Seebeck relation then gives |S|. To build a Pisarenko plot against the
    measured *Hall* carrier concentration (as in the paper's Fig. 4c), use
    :func:`pisarenko_relation_hall`, which applies the acoustic-phonon Hall
    factor ``r_H`` (:func:`hall_factor_spb`) so the theory curve is on the same
    Hall-measurement basis as the data.

    Parameters
    ----------
    n_chem_cm3 : float
        Chemical (drift) carrier concentration in cm^-3.
    m_star_me : float
        Density-of-states effective mass in electron mass units.
    T : float
        Temperature in K.
    r : float
        Scattering parameter.

    Returns
    -------
    float
        Seebeck coefficient in uV/K (magnitude).
    """
    n_SI = abs(n_chem_cm3) * 1e6
    eta = _eta_from_chemical_density(n_SI, m_star_me, T)
    S = skb_seebeck(eta, r)
    return abs(S) * 1e6  # convert V/K to uV/K


def pisarenko_relation_hall(n_H_cm3: float, m_star_me: float, T: float,
                            r: float = -0.5, n_iter: int = 60) -> float:
    """Theoretical Pisarenko |S| vs the measured HALL carrier concentration.

    This is the curve to compare against an experimental Pisarenko plot whose
    x-axis is the Hall carrier concentration ``n_H = 1/(e R_H)`` (the paper's
    Fig. 4c). Because ``n_H = n_chemical / r_H`` and the acoustic-phonon Hall
    factor ``r_H`` (:func:`hall_factor_spb`) itself depends on the reduced Fermi
    level, the relation is solved self-consistently: starting from the
    degenerate guess ``r_H = 1`` (so ``n_chemical = n_H``), eta is obtained from
    the chemical-density inversion, ``r_H(eta)`` is updated, and the chemical
    density ``n_chemical = n_H * r_H`` is recomputed until eta converges. The
    SPB Seebeck relation then gives |S| at that eta.

    Parameters
    ----------
    n_H_cm3 : float
        Hall carrier concentration in cm^-3 (the plotted x-axis quantity).
    m_star_me : float
        Density-of-states effective mass in electron mass units.
    T : float
        Temperature in K.
    r : float
        Scattering parameter.
    n_iter : int
        Maximum self-consistency iterations.

    Returns
    -------
    float
        Seebeck coefficient in uV/K (magnitude), on the Hall-concentration axis.
    """
    n_H_SI = abs(n_H_cm3) * 1e6
    r_H = 1.0
    eta = 0.0
    for _ in range(n_iter):
        n_chem_SI = n_H_SI * r_H
        eta_new = _eta_from_chemical_density(n_chem_SI, m_star_me, T)
        r_H_new = hall_factor_spb(eta_new)
        if abs(eta_new - eta) < 1e-7 and abs(r_H_new - r_H) < 1e-9:
            eta = eta_new
            r_H = r_H_new
            break
        eta, r_H = eta_new, r_H_new
    S = skb_seebeck(eta, r)
    return abs(S) * 1e6  # convert V/K to uV/K


# ---------------------------------------------------------------------------
# Figure of merit
# ---------------------------------------------------------------------------

def compute_zt(S: float, sigma: float, kappa: float, T: float) -> float:
    """Thermoelectric figure of merit zT.

    zT = S^2 * sigma * T / kappa

    Parameters
    ----------
    S : float
        Seebeck coefficient in V/K.
    sigma : float
        Electrical conductivity in S/m.
    kappa : float
        Total thermal conductivity in W m^-1 K^-1.
    T : float
        Temperature in K.

    Returns
    -------
    float
        Dimensionless figure of merit.
    """
    if kappa < 1e-30:
        return 0.0
    return S ** 2 * sigma * T / kappa


def power_factor(S: float, sigma: float) -> float:
    """Thermoelectric power factor S^2 * sigma.

    Parameters
    ----------
    S : float
        Seebeck coefficient in V/K.
    sigma : float
        Electrical conductivity in S/m.

    Returns
    -------
    float
        Power factor in W m^-1 K^-2.
    """
    return S ** 2 * sigma


# ---------------------------------------------------------------------------
# Scattering parameter analysis
# ---------------------------------------------------------------------------

def scattering_ratio(S_x: float, S_0: float, n_x: float, n_0: float) -> float:
    """Ratio of scattering parameters (r_x + 1)/(r_0 + 1) from the
    Seebeck-carrier concentration relation.

    (r_x + 1)/(r_0 + 1) = (S_x / S_0) * (n_x / n_0)^{2/3}

    Used to quantify energy filtering effects from nanoprecipitates.

    Parameters
    ----------
    S_x : float
        Absolute Seebeck of doped sample (uV/K).
    S_0 : float
        Absolute Seebeck of reference sample (uV/K).
    n_x : float
        Carrier concentration of doped sample (any consistent unit).
    n_0 : float
        Carrier concentration of reference sample (same unit).

    Returns
    -------
    float
        Ratio (r_x + 1)/(r_0 + 1).
    """
    if abs(S_0) < 1e-10 or abs(n_0) < 1e-30:
        return 0.0
    return (abs(S_x) / abs(S_0)) * (abs(n_x) / abs(n_0)) ** (2.0 / 3.0)


def interface_potential_barrier(sigma: float, T: float, n_H: float) -> float:
    """Estimate interface potential barrier E_B from the temperature
    dependence of ln(sigma*T^{1/2}) vs 1/(k_B*T).

    This is a helper that computes the y-coordinate for a linear fit.
    The slope of ln(sigma*T^{0.5}) vs 1/(k_B*T) gives -E_B.

    Parameters
    ----------
    sigma : float
        Electrical conductivity in S/m.
    T : float
        Temperature in K.
    n_H : float
        Carrier concentration (not used in calculation, for reference).

    Returns
    -------
    float
        ln(sigma * T^{0.5}) value for linear regression.
    """
    if sigma <= 0 or T <= 0:
        return float('-inf')
    return math.log(sigma * math.sqrt(T))


# ---------------------------------------------------------------------------
# Utility: unit conversions
# ---------------------------------------------------------------------------

def resistivity_to_conductivity(rho_mOhm_m: float) -> float:
    """Convert resistivity in mOhm*m to conductivity in S/m.

    Parameters
    ----------
    rho_mOhm_m : float
        Resistivity in mOhm*m (milliOhm * meter).

    Returns
    -------
    float
        Electrical conductivity in S/m.
    """
    # mOhm*m = 1e-3 Ohm*m
    rho_Ohm_m = rho_mOhm_m * 1e-3
    if abs(rho_Ohm_m) < 1e-30:
        return 0.0
    return 1.0 / rho_Ohm_m


def celsius_to_kelvin(T_C: float) -> float:
    """Convert temperature from Celsius to Kelvin."""
    return T_C + 273.15

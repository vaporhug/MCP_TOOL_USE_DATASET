#!/usr/bin/env python3
"""Identification scaling primitives.

Tools for fitting Pitman-Yor Correctness (PYC) models, the FL/Entropy
baseline, exponential-decay and polynomial baselines, computing model
selection criteria (BIC, RMSE, log-likelihood) on identification correctness
curves, and forecasting correctness at unseen population sizes.
"""

import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import digamma, gammaln, polygamma
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Identification_Scaling_Tools")


# -------------------------------------------------------------------
# Data IO
# -------------------------------------------------------------------
@mcp.tool()
def load_correctness_curves(csv_path: str, corpus: str | None = None,
                            subset_id: int | None = None) -> dict:
    """Load empirical correctness measurement curves.

    Each row is one measurement (corpus, subset_id, n_sample, kappa).

    Args:
        csv_path: path to a CSV file with columns at minimum
            'subset_id', 'n_sample', 'kappa'. Optionally 'corpus'.
        corpus: optional corpus filter (e.g. 'ADULT', 'GEOM').
        subset_id: optional subset filter (return one curve only).

    Returns:
        dict with: columns, n_rows, n_subsets, sample_rows.
    """
    df = pd.read_csv(csv_path)
    if corpus is not None and 'corpus' in df.columns:
        df = df[df['corpus'] == corpus]
    if subset_id is not None:
        df = df[df['subset_id'] == int(subset_id)]
    return {
        "columns": list(df.columns),
        "n_rows": int(len(df)),
        "n_subsets": int(df['subset_id'].nunique()) if 'subset_id' in df.columns else 0,
        "n_levels_per_subset": int(df.groupby('subset_id').size().median()) if 'subset_id' in df.columns else int(len(df)),
        "kappa_min": round(float(df['kappa'].min()), 6),
        "kappa_max": round(float(df['kappa'].max()), 6),
        "n_min": int(df['n_sample'].min()),
        "n_max": int(df['n_sample'].max()),
        "sample_rows": df.head(10).to_dict('records'),
    }


@mcp.tool()
def get_curve(csv_path: str, subset_id: int) -> dict:
    """Return one (n, kappa) curve as parallel arrays.

    Args:
        csv_path: path to correctness curves CSV.
        subset_id: subset identifier.

    Returns:
        dict with n_values, kappa_values, n_points, n_max.
    """
    df = pd.read_csv(csv_path)
    sub = df[df['subset_id'] == int(subset_id)].sort_values('n_sample')
    n = sub['n_sample'].astype(int).tolist()
    k = sub['kappa'].astype(float).tolist()
    return {
        "subset_id": int(subset_id),
        "n_values": n,
        "kappa_values": k,
        "n_points": len(n),
        "n_max": int(max(n)) if n else 0,
        "kappa_at_max_n": round(float(k[-1]), 6) if k else None,
    }


# -------------------------------------------------------------------
# Pitman-Yor Correctness (PYC) model — analytical form
# -------------------------------------------------------------------
@np.vectorize
def _invdigamma(y, num_iter=6):
    """Newton inverse of digamma. Used to map (h, gamma) <-> (d, alpha)."""
    if y >= -2.22:
        x = np.exp(y) + 0.5
    else:
        x = -1.0 / (y + 0.5772156649)
    for _ in range(num_iter):
        x -= (digamma(x) - y) / polygamma(1, x)
    return x


def _hgamma_to_dalpha(h: float, gamma: float):
    """Map (h, gamma) -> (d, alpha) via inverse digamma."""
    d = float(1.0 - _invdigamma(digamma(1) - h * gamma))
    alpha = float(_invdigamma(h * (1.0 - gamma) + digamma(1)) - 1.0)
    return d, alpha


def _log_gamma_ratio(z, m):
    """Robust log Γ(z+m) - log Γ(z)."""
    z = np.asarray(z, dtype=np.float64)
    m = np.asarray(m, dtype=np.float64)
    return gammaln(z + m) - gammaln(z)


def _stable_R_minus_alpha(logR, alpha):
    if alpha == 0.0:
        return np.exp(logR)
    if alpha < 0.0:
        return np.exp(np.logaddexp(logR, np.log(-alpha)))
    return np.exp(logR) * (-np.expm1(np.log(alpha) - logR))


def pyp_correctness_arr(d: float, alpha: float, n_arr) -> np.ndarray:
    """Expected correctness of a Pitman-Yor process at sample sizes n_arr.

    κ(n) = expected number of OCCUPIED (non-empty) anonymity sets / n
    in a sample of size n drawn from a PY(d, α) type-frequency prior.
    Equivalently the average reciprocal anonymity-set size, matching the
    Rocher et al. 2025 Results definition.
    """
    n_arr = np.asarray(n_arr, dtype=np.float64)
    out = np.ones_like(n_arr)
    mask = n_arr > 1
    if not np.any(mask):
        return out
    nm = n_arr[mask]

    if d == 0.0:
        if alpha <= 1e-300:
            out[mask] = 0.0
        else:
            dpsi = digamma(nm + alpha) - digamma(alpha)
            out[mask] = (alpha / nm) * dpsi
        return np.clip(out, 0.0, 1.0)

    if alpha == 0.0:
        logC = _log_gamma_ratio(nm + 1.0, d - 1.0) - gammaln(d + 1.0)
        out[mask] = 1.0 + np.expm1(logC)
        return np.clip(out, 0.0, 1.0)

    logR = _log_gamma_ratio(alpha + d, 1.0 - d) + _log_gamma_ratio(nm + alpha, d)
    nom = _stable_R_minus_alpha(logR, alpha)
    out[mask] = np.clip(nom / (nm * d), 0.0, 1.0)
    return out


@mcp.tool()
def pyc_correctness(h: float, gamma: float, n_values: list) -> dict:
    """Forward predict expected correctness of PYC(h, γ) model.

    Args:
        h: expected Shannon entropy (nats).
        gamma: tail complexity in [0, 1].
        n_values: list of sample sizes.

    Returns:
        dict with d, alpha (canonical PY parameters), kappa_predicted.
    """
    d, alpha = _hgamma_to_dalpha(float(h), float(gamma))
    kappas = pyp_correctness_arr(d, alpha, n_values)
    return {
        "h": float(h),
        "gamma": float(gamma),
        "d_internal": round(d, 6),
        "alpha_internal": round(alpha, 6),
        "n_values": [int(x) for x in n_values],
        "kappa_predicted": [round(float(x), 6) for x in kappas],
    }


# -------------------------------------------------------------------
# Fitting routines
# -------------------------------------------------------------------
@mcp.tool()
def fit_pyc(n_values: list, kappa_values: list, h_init: float = 12.0,
            gamma_init: float = 0.26) -> dict:
    """Fit the 2-parameter Pitman-Yor Correctness model to a single curve.

    Minimises log-weighted quadratic loss
    R(h, γ) = sum_i log(n_i) * (κ_i - E[κ(n_i)|h,γ])^2 / N
    using the Nelder-Mead simplex (paper, eq. 4).

    Args:
        n_values: list of sample sizes (n^(i)).
        kappa_values: empirical correctness at each n (κ_i).
        h_init: starting entropy (nats).
        gamma_init: starting tail complexity (in [0,1]).

    Returns:
        dict with fitted h, gamma, residual loss, RMSE, n_points, success.
    """
    n_arr = np.asarray(n_values, dtype=np.float64)
    k_arr = np.asarray(kappa_values, dtype=np.float64)

    def loss(x):
        h, g = float(x[0]), float(x[1])
        if h <= 0 or g < 0 or g > 1:
            return 1e10
        try:
            d, alpha = _hgamma_to_dalpha(h, g)
            pred = pyp_correctness_arr(d, alpha, n_arr)
            return float((np.log(n_arr) * (pred - k_arr) ** 2).mean())
        except Exception:
            return 1e10

    res = minimize(loss, x0=[h_init, gamma_init], method="Nelder-Mead",
                   options={"xatol": 1e-5, "fatol": 1e-9, "maxiter": 2000})
    h_fit, g_fit = float(res.x[0]), float(res.x[1])
    d, alpha = _hgamma_to_dalpha(h_fit, g_fit)
    pred = pyp_correctness_arr(d, alpha, n_arr)
    rmse = float(np.sqrt(((pred - k_arr) ** 2).mean()))
    return {
        "h_fit": round(h_fit, 4),
        "gamma_fit": round(g_fit, 4),
        "d": round(d, 6),
        "alpha": round(alpha, 6),
        "rmse_pp": round(rmse * 100, 3),
        "loss": round(float(res.fun), 8),
        "n_points": int(len(n_arr)),
        "success": bool(res.success),
        "model": "PYC",
        "n_params": 2,
    }


@mcp.tool()
def fit_entropy_baseline(n_values: list, kappa_values: list,
                         h_init: float = 12.0) -> dict:
    """Fit the 1-parameter entropy baseline (FL / ENT in the paper).

    Assumes uniform distribution over 2^h categories:
    κ(n) ≈ (2^h / n) * (1 - (1 - 2^-h)^n).

    Args:
        n_values: list of sample sizes.
        kappa_values: empirical correctness.
        h_init: starting entropy (bits).

    Returns:
        dict with fitted h, RMSE, loss, success.
    """
    n_arr = np.asarray(n_values, dtype=np.float64)
    k_arr = np.asarray(kappa_values, dtype=np.float64)

    def predict(h):
        x = 2.0 ** (-h)
        stable_term = -np.expm1(n_arr * np.log1p(-x))
        return np.clip(2.0 ** h / n_arr * stable_term, 0.0, 1.0)

    def loss(x):
        h = float(x[0])
        if h <= 0:
            return 1e10
        pred = predict(h)
        return float((np.log(n_arr) * (pred - k_arr) ** 2).mean())

    res = minimize(loss, x0=[h_init], method="Nelder-Mead",
                   options={"xatol": 1e-5, "fatol": 1e-9, "maxiter": 2000})
    h_fit = float(res.x[0])
    pred = predict(h_fit)
    rmse = float(np.sqrt(((pred - k_arr) ** 2).mean()))
    return {
        "h_fit": round(h_fit, 4),
        "rmse_pp": round(rmse * 100, 3),
        "loss": round(float(res.fun), 8),
        "n_points": int(len(n_arr)),
        "success": bool(res.success),
        "model": "ENT",
        "n_params": 1,
    }


@mcp.tool()
def fit_exp_decay(n_values: list, kappa_values: list) -> dict:
    """Fit a 2-parameter exponential decay baseline.

    κ(n) = a * exp(-b * sqrt(n)) + (1 - a * exp(-b)).

    Args:
        n_values: list of sample sizes.
        kappa_values: empirical correctness.

    Returns:
        dict with fitted a, b, RMSE, success.
    """
    n_arr = np.asarray(n_values, dtype=np.float64)
    k_arr = np.asarray(kappa_values, dtype=np.float64)

    def predict(a, b):
        return np.clip(a * np.exp(-b * np.sqrt(n_arr)) + (1 - a * np.exp(-b)), 0, 1)

    def loss(x):
        a, b = float(x[0]), float(x[1])
        pred = predict(a, b)
        return float((np.log(n_arr) * (pred - k_arr) ** 2).mean())

    res = minimize(loss, x0=[1.0, 1.0], method="Nelder-Mead",
                   options={"maxiter": 2000})
    a, b = float(res.x[0]), float(res.x[1])
    pred = predict(a, b)
    rmse = float(np.sqrt(((pred - k_arr) ** 2).mean()))
    return {
        "a": round(a, 6),
        "b": round(b, 6),
        "rmse_pp": round(rmse * 100, 3),
        "loss": round(float(res.fun), 8),
        "success": bool(res.success),
        "model": "EXP",
        "n_params": 2,
    }


@mcp.tool()
def fit_polynomial(n_values: list, kappa_values: list) -> dict:
    """Fit a 3-parameter cubic polynomial in log10(n).

    κ(n) = a*log10(n)^3 + b*log10(n)^2 + c*log10(n) + 1.

    NOTE: this is a bundle-specific cubic baseline. Rocher et al. 2025
    Table 1 reports POL as a 2-degree-of-freedom polynomial form (a
    constrained polynomial fit); the bundle's 3-parameter cubic and the
    paper's 2-d.o.f. POL are NOT directly comparable, and the bundle's
    POL RMSEs should not be read as a Table 1 mirror.

    Args:
        n_values: list of sample sizes.
        kappa_values: empirical correctness.

    Returns:
        dict with fitted a, b, c, RMSE.
    """
    n_arr = np.asarray(n_values, dtype=np.float64)
    k_arr = np.asarray(kappa_values, dtype=np.float64)
    ln_arr = np.log10(n_arr)

    def predict_raw(a, b, c):
        return a * ln_arr ** 3 + b * ln_arr ** 2 + c * ln_arr + 1

    def predict_clipped(a, b, c):
        return np.clip(predict_raw(a, b, c), 0.0, 1.0)

    def loss(x):
        a, b, c = float(x[0]), float(x[1]), float(x[2])
        # Use the un-clipped polynomial inside the loss so the optimizer
        # always has a non-zero gradient signal — clipping inside the loss
        # zeros the derivative whenever pred < 0 or > 1, which makes
        # gradient-free Nelder-Mead stall when the initial coefficients
        # land in a region where every prediction is clipped.
        pred = predict_raw(a, b, c)
        return float((np.log(n_arr) * (pred - k_arr) ** 2).mean())

    # Closed-form weighted-least-squares seed for the cubic in log10(n)
    # so Nelder-Mead starts from a good neighbourhood instead of an
    # all-zero / all-clipped point.
    try:
        X = np.column_stack([ln_arr ** 3, ln_arr ** 2, ln_arr])
        y = k_arr - 1.0
        w = np.log(n_arr)
        Aw = X * w[:, None]
        bw = y * w
        seed, *_ = np.linalg.lstsq(Aw, bw, rcond=None)
        x0 = [float(seed[0]), float(seed[1]), float(seed[2])]
    except Exception:
        x0 = [0.0, 0.0, 0.0]

    res = minimize(loss, x0=x0, method="Nelder-Mead",
                   options={"maxiter": 2000})
    a, b, c = float(res.x[0]), float(res.x[1]), float(res.x[2])
    # Report the clipped prediction (κ ∈ [0,1] by construction)
    pred = predict_clipped(a, b, c)
    rmse = float(np.sqrt(((pred - k_arr) ** 2).mean()))
    return {
        "a": round(a, 6),
        "b": round(b, 6),
        "c": round(c, 6),
        "rmse_pp": round(rmse * 100, 3),
        "loss": round(float(res.fun), 8),
        "success": bool(res.success),
        "model": "POL",
        "n_params": 3,
    }


# -------------------------------------------------------------------
# Extrapolation (PYC-MB) on partial samples
# -------------------------------------------------------------------
@mcp.tool()
def extrapolate_pyc(n_train: list, kappa_train: list, n_predict: list,
                    h_init: float = 12.0, gamma_init: float = 0.26) -> dict:
    """Train PYC on the first part of a curve and forecast at larger n.

    This is the PYC-MB (measurement-based) method of Rocher et al. (eq. 4).
    Used to compare extrapolation accuracy at μ = 1%, 5%, 10% sampling
    fractions of the full population n^(I).

    Args:
        n_train: list of sample sizes used for training.
        kappa_train: empirical correctness at training sizes.
        n_predict: list of sample sizes at which to predict.

    Returns:
        dict with h_fit, gamma_fit, kappa_predicted at n_predict.
    """
    fit = fit_pyc(n_train, kappa_train, h_init=h_init, gamma_init=gamma_init)
    h_fit, g_fit = fit["h_fit"], fit["gamma_fit"]
    d, alpha = _hgamma_to_dalpha(h_fit, g_fit)
    pred = pyp_correctness_arr(d, alpha, n_predict)
    return {
        "h_fit": h_fit,
        "gamma_fit": g_fit,
        "n_predict": [int(x) for x in n_predict],
        "kappa_predicted": [round(float(x), 6) for x in pred],
        "n_train": len(n_train),
    }


@mcp.tool()
def extrapolation_rmse(csv_path: str, corpus: str, mu: float = 0.10,
                       method: str = "PYC") -> dict:
    """Repeat PYC-MB extrapolation across all subsets in a corpus and report
    the average RMSE in p.p. when extrapolating from a fraction μ of the curve
    to the held-out tail (mirrors paper Table 1).

    Args:
        csv_path: path to correctness curves CSV.
        corpus: corpus name (e.g. 'ADULT', 'GEOM', 'POISSON', 'ZIPF').
        mu: training fraction in (0, 1). Use 0.01, 0.05, 0.10 for paper.
        method: one of 'PYC', 'ENT', 'EXP', 'POL'.

    Returns:
        dict with mean_rmse_pp, std_rmse_pp, n_subsets, per_subset.
    """
    df = pd.read_csv(csv_path)
    if 'corpus' in df.columns:
        df = df[df['corpus'] == corpus]
    rmses = []
    per = []
    for sid, grp in df.groupby('subset_id'):
        grp = grp.sort_values('n_sample')
        n = grp['n_sample'].astype(float).values
        k = grp['kappa'].astype(float).values
        n_max = n.max()
        # Training: subset of curve up to mu * n_max
        n_train_max = mu * n_max
        train_mask = n <= n_train_max
        if train_mask.sum() < 3:
            continue
        n_tr = n[train_mask].tolist()
        k_tr = k[train_mask].tolist()
        n_te = n.tolist()
        k_te = k

        if method == "PYC":
            fit = fit_pyc(n_tr, k_tr)
            d, alpha = _hgamma_to_dalpha(fit["h_fit"], fit["gamma_fit"])
            pred = pyp_correctness_arr(d, alpha, n_te)
        elif method == "ENT":
            res = fit_entropy_baseline(n_tr, k_tr)
            h = res["h_fit"]
            x = 2.0 ** (-h)
            pred = np.clip(2.0 ** h / np.array(n_te) *
                           (-np.expm1(np.array(n_te) * np.log1p(-x))), 0, 1)
        elif method == "EXP":
            res = fit_exp_decay(n_tr, k_tr)
            a, b = res["a"], res["b"]
            n_arr = np.array(n_te, dtype=float)
            pred = np.clip(a * np.exp(-b * np.sqrt(n_arr)) + (1 - a * np.exp(-b)), 0, 1)
        elif method == "POL":
            res = fit_polynomial(n_tr, k_tr)
            a, b, c = res["a"], res["b"], res["c"]
            ln = np.log10(np.array(n_te, dtype=float))
            pred = np.clip(a * ln ** 3 + b * ln ** 2 + c * ln + 1, 0, 1)
        else:
            raise ValueError(f"Unknown method {method}")

        # RMSE on extrapolated portion (n > training threshold)
        ext_mask = n > n_train_max
        if ext_mask.sum() == 0:
            continue
        rmse = float(np.sqrt(((pred[ext_mask] - k_te[ext_mask]) ** 2).mean()))
        rmses.append(rmse)
        per.append({"subset_id": int(sid), "rmse_pp": round(rmse * 100, 3),
                    "n_train": int(train_mask.sum()),
                    "n_extrapolate": int(ext_mask.sum())})
    arr = np.array(rmses)
    return {
        "corpus": corpus,
        "mu": float(mu),
        "method": method,
        "n_subsets": int(len(arr)),
        "mean_rmse_pp": round(float(arr.mean() * 100), 3) if len(arr) else None,
        "median_rmse_pp": round(float(np.median(arr) * 100), 3) if len(arr) else None,
        "std_rmse_pp": round(float(arr.std() * 100), 3) if len(arr) else None,
        "per_subset": per[:10],
    }


# -------------------------------------------------------------------
# Model comparison
# -------------------------------------------------------------------
@mcp.tool()
def gaussian_log_likelihood(observed: list, predicted: list,
                            sigma: float | None = None) -> dict:
    """Gaussian log-likelihood of observations given predictions.

    If sigma is None it is estimated from the residuals (MLE).

    Args:
        observed: empirical values κ_i.
        predicted: model predictions.
        sigma: optional fixed standard deviation.

    Returns:
        dict with log_likelihood, sigma_used, n.
    """
    o = np.asarray(observed, dtype=np.float64)
    p = np.asarray(predicted, dtype=np.float64)
    n = len(o)
    res = o - p
    if sigma is None:
        sigma = float(np.sqrt((res ** 2).mean()))
    sigma = max(sigma, 1e-9)
    ll = float(-0.5 * n * np.log(2 * np.pi * sigma ** 2)
               - 0.5 * (res ** 2).sum() / sigma ** 2)
    return {"log_likelihood": round(ll, 4), "sigma_used": round(sigma, 6), "n": n}


@mcp.tool()
def bic_score(log_likelihood: float, n_params: int, n_obs: int) -> dict:
    """Bayesian Information Criterion. Lower is better.

    BIC = k * ln(n) - 2 * ln(L).
    """
    bic = float(n_params * np.log(n_obs) - 2.0 * log_likelihood)
    aic = float(2.0 * n_params - 2.0 * log_likelihood)
    return {"BIC": round(bic, 4), "AIC": round(aic, 4),
            "n_params": int(n_params), "n_obs": int(n_obs)}


@mcp.tool()
def compare_models_on_corpus(csv_path: str, corpus: str) -> dict:
    """Fit PYC, ENT, EXP, POL on every subset of a corpus and report
    aggregated RMSE in p.p. plus average BIC. Structurally similar to a
    paper Table 1 row, but the bundle's POL is a 3-parameter cubic while
    the paper's POL is a 2-d.o.f. constrained polynomial; treat the
    bundle's POL RMSE as a local cubic baseline, not a Table 1 mirror.

    Args:
        csv_path: path to correctness curves CSV.
        corpus: corpus name.

    Returns:
        dict mapping model -> {mean_rmse_pp, mean_bic, n_subsets}.
    """
    df = pd.read_csv(csv_path)
    if 'corpus' in df.columns:
        df = df[df['corpus'] == corpus]
    out: dict = {"PYC": [], "ENT": [], "EXP": [], "POL": []}
    bic_out: dict = {"PYC": [], "ENT": [], "EXP": [], "POL": []}
    for sid, grp in df.groupby('subset_id'):
        grp = grp.sort_values('n_sample')
        n = grp['n_sample'].astype(float).values.tolist()
        k = grp['kappa'].astype(float).values.tolist()
        if len(n) < 5:
            continue
        for name, fit_func, k_params in [
            ("PYC", fit_pyc, 2),
            ("ENT", fit_entropy_baseline, 1),
            ("EXP", fit_exp_decay, 2),
            ("POL", fit_polynomial, 3),
        ]:
            try:
                res = fit_func(n, k)
                out[name].append(res["rmse_pp"])
                # Compute BIC from RMSE
                n_obs = len(n)
                sigma = max(res["rmse_pp"] / 100, 1e-6)
                ll = float(-0.5 * n_obs * np.log(2 * np.pi * sigma ** 2)
                           - 0.5 * n_obs)
                bic = k_params * np.log(n_obs) - 2.0 * ll
                bic_out[name].append(bic)
            except Exception:
                continue
    summary = {}
    for name in out:
        arr = np.array(out[name])
        bic_arr = np.array(bic_out[name])
        summary[name] = {
            "mean_rmse_pp": round(float(arr.mean()), 3) if len(arr) else None,
            "median_rmse_pp": round(float(np.median(arr)), 3) if len(arr) else None,
            "mean_bic": round(float(bic_arr.mean()), 3) if len(bic_arr) else None,
            "n_subsets": int(len(arr)),
        }
    return {"corpus": corpus, "summary": summary}


# -------------------------------------------------------------------
# Empirical helpers
# -------------------------------------------------------------------
@mcp.tool()
def empirical_correctness_from_attributes(csv_path: str, attribute_cols: list,
                                          n_sample: int | None = None,
                                          random_state: int = 42) -> dict:
    """Compute empirical correctness on a tabular dataset given an attribute
    subset. κ = (#unique combinations of attribute_cols) / n_sample.

    Args:
        csv_path: path to a raw tabular CSV (e.g. ADULT).
        attribute_cols: columns to use as auxiliary information φ(x).
        n_sample: optional sub-sample size.
        random_state: random seed for sub-sampling.

    Returns:
        dict with kappa, n, n_unique_combinations, attributes_used.
    """
    df = pd.read_csv(csv_path)
    if n_sample is not None and n_sample < len(df):
        df = df.sample(n=n_sample, random_state=random_state)
    sub = df[attribute_cols]
    n_unique = len(sub.groupby(attribute_cols, dropna=False).size())
    kappa = n_unique / len(sub)
    return {
        "n": int(len(sub)),
        "n_unique_combinations": int(n_unique),
        "kappa": round(float(kappa), 6),
        "attributes_used": list(attribute_cols),
    }


# -------------------------------------------------------------------
# Plotting
# -------------------------------------------------------------------
@mcp.tool()
def plot_correctness_curve(n_values: list, kappa_values: list,
                           out_path: str, model: str | None = "PYC",
                           h: float | None = None, gamma: float | None = None,
                           title: str | None = None) -> dict:
    """Plot empirical correctness vs sample size with optional model overlay.

    Args:
        n_values: sample sizes.
        kappa_values: empirical κ.
        out_path: destination PNG path.
        model: optional model overlay ('PYC', 'ENT', 'EXP', 'POL'); pass None
            to plot data only.
        h, gamma: PYC parameters (required if model == 'PYC').
        title: figure title.

    Returns:
        dict with file path and meta.
    """
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    n_arr = np.asarray(n_values, dtype=float)
    k_arr = np.asarray(kappa_values, dtype=float)

    fig, ax = plt.subplots(figsize=(6, 4.2))
    ax.scatter(n_arr, k_arr, s=20, c='black', alpha=0.7, label='Empirical κ')
    if model == "PYC" and h is not None and gamma is not None:
        n_smooth = np.logspace(np.log10(n_arr.min()), np.log10(n_arr.max() * 10), 200)
        d, alpha = _hgamma_to_dalpha(h, gamma)
        pred = pyp_correctness_arr(d, alpha, n_smooth)
        ax.plot(n_smooth, pred, '-', color='C0', lw=2,
                label=f'PYC (h={h:.2f}, γ={gamma:.2f})')
    ax.set_xscale('log')
    ax.set_xlabel('Population size n')
    ax.set_ylabel('Correctness κ')
    ax.set_ylim(0, 1.02)
    if title:
        ax.set_title(title)
    ax.legend(loc='best', fontsize=9)
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    plt.close()
    return {"path": out_path, "n_points": int(len(n_arr))}


@mcp.tool()
def plot_model_comparison(n_values: list, kappa_values: list,
                          fitted: dict, out_path: str,
                          title: str | None = None) -> dict:
    """Plot a single empirical curve with overlays of multiple fitted models.

    Args:
        n_values: sample sizes.
        kappa_values: empirical κ.
        fitted: dict mapping model name ('PYC','ENT','EXP','POL') ->
            parameters dict (must contain the keys returned by the fit_* tools).
        out_path: destination PNG path.
        title: figure title.

    Returns:
        dict with file path.
    """
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    n_arr = np.asarray(n_values, dtype=float)
    k_arr = np.asarray(kappa_values, dtype=float)
    n_smooth = np.logspace(np.log10(n_arr.min()), np.log10(n_arr.max() * 10), 200)

    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.scatter(n_arr, k_arr, s=22, c='black', alpha=0.7, label='Empirical κ', zorder=5)
    colours = {"PYC": "C0", "ENT": "tab:orange", "EXP": "tab:green", "POL": "tab:red"}
    for name, params in fitted.items():
        if name == "PYC":
            d, alpha = _hgamma_to_dalpha(params["h_fit"], params["gamma_fit"])
            y = pyp_correctness_arr(d, alpha, n_smooth)
        elif name == "ENT":
            h = params["h_fit"]
            x = 2.0 ** (-h)
            y = np.clip(2.0 ** h / n_smooth * (-np.expm1(n_smooth * np.log1p(-x))), 0, 1)
        elif name == "EXP":
            a, b = params["a"], params["b"]
            y = np.clip(a * np.exp(-b * np.sqrt(n_smooth)) + (1 - a * np.exp(-b)), 0, 1)
        elif name == "POL":
            a, b, c = params["a"], params["b"], params["c"]
            ln = np.log10(n_smooth)
            y = np.clip(a * ln ** 3 + b * ln ** 2 + c * ln + 1, 0, 1)
        else:
            continue
        rmse = params.get("rmse_pp", "?")
        ax.plot(n_smooth, y, '-', color=colours.get(name, 'gray'),
                lw=1.6, label=f'{name} (RMSE={rmse} p.p.)')
    ax.set_xscale('log')
    ax.set_xlabel('Population size n')
    ax.set_ylabel('Correctness κ')
    ax.set_ylim(0, 1.02)
    if title:
        ax.set_title(title)
    ax.legend(loc='best', fontsize=8)
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    plt.close()
    return {"path": out_path}


@mcp.tool()
def plot_rmse_summary(rmse_table: dict, out_path: str,
                      title: str | None = None) -> dict:
    """Bar-plot of mean RMSE (p.p.) across corpora x methods.

    Args:
        rmse_table: nested dict {corpus -> {method -> mean_rmse_pp}}.
        out_path: destination PNG path.
        title: figure title.

    Returns:
        dict with file path.
    """
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    corpora = list(rmse_table.keys())
    methods = ["PYC", "ENT", "EXP", "POL"]
    width = 0.18
    x = np.arange(len(corpora))
    fig, ax = plt.subplots(figsize=(7, 4.5))
    colours = {"PYC": "C0", "ENT": "tab:orange", "EXP": "tab:green", "POL": "tab:red"}
    for i, m in enumerate(methods):
        vals = [rmse_table[c].get(m, 0) for c in corpora]
        ax.bar(x + i * width - 1.5 * width, vals, width=width,
               label=m, color=colours[m])
    ax.set_xticks(x)
    ax.set_xticklabels(corpora)
    ax.set_ylabel('Mean RMSE (p.p.)')
    if title:
        ax.set_title(title)
    ax.legend(loc='best', fontsize=9)
    ax.grid(True, axis='y', alpha=0.3)
    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    plt.close()
    return {"path": out_path}


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "--test":
        # smoke test
        import json
        df = pd.read_csv(Path(__file__).parent.parent / "input_data/data/adult_correctness_curves.csv")
        sub = df[df['subset_id'] == 0].sort_values('n_sample')
        n = sub['n_sample'].astype(float).tolist()
        k = sub['kappa'].astype(float).tolist()
        print("PYC fit:", json.dumps(fit_pyc(n, k), indent=2))
        print("ENT fit:", json.dumps(fit_entropy_baseline(n, k), indent=2))
    else:
        mcp.run()

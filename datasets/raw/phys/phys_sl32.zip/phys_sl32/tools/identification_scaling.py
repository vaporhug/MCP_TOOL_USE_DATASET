#!/usr/bin/env python3
"""Identification scaling primitives.

Tools for fitting Pitman-Yor Correctness (PYC) models, the FL/Entropy
baseline, exponential-decay and polynomial baselines, computing model
selection criteria (BIC, RMSE, log-likelihood) on identification correctness
curves, and forecasting correctness at unseen population sizes.
"""

import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import digamma, gammaln, polygamma
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Identification_Scaling_Tools")


# -------------------------------------------------------------------
# Data IO
# -------------------------------------------------------------------
@mcp.tool()
def load_correctness_curves(csv_path: str, corpus: str | None = None,
                            subset_id: int | None = None) -> dict:
    """Load empirical correctness measurement curves.

    Each row is one measurement (corpus, subset_id, n_sample, kappa).

    Args:
        csv_path: path to a CSV file with columns at minimum
            'subset_id', 'n_sample', 'kappa'. Optionally 'corpus'.
        corpus: optional corpus filter (e.g. 'ADULT', 'GEOM').
        subset_id: optional subset filter (return one curve only).

    Returns:
        dict with: columns, n_rows, n_subsets, sample_rows.
    """
    df = pd.read_csv(csv_path)
    if corpus is not None and 'corpus' in df.columns:
        df = df[df['corpus'] == corpus]
    if subset_id is not None:
        df = df[df['subset_id'] == int(subset_id)]
    return {
        "columns": list(df.columns),
        "n_rows": int(len(df)),
        "n_subsets": int(df['subset_id'].nunique()) if 'subset_id' in df.columns else 0,
        "n_levels_per_subset": int(df.groupby('subset_id').size().median()) if 'subset_id' in df.columns else int(len(df)),
        "kappa_min": round(float(df['kappa'].min()), 6),
        "kappa_max": round(float(df['kappa'].max()), 6),
        "n_min": int(df['n_sample'].min()),
        "n_max": int(df['n_sample'].max()),
        "sample_rows": df.head(10).to_dict('records'),
    }


@mcp.tool()
def get_curve(csv_path: str, subset_id: int) -> dict:
    """Return one (n, kappa) curve as parallel arrays.

    Args:
        csv_path: path to correctness curves CSV.
        subset_id: subset identifier.

    Returns:
        dict with n_values, kappa_values, n_points, n_max.
    """
    df = pd.read_csv(csv_path)
    sub = df[df['subset_id'] == int(subset_id)].sort_values('n_sample')
    n = sub['n_sample'].astype(int).tolist()
    k = sub['kappa'].astype(float).tolist()
    return {
        "subset_id": int(subset_id),
        "n_values": n,
        "kappa_values": k,
        "n_points": len(n),
        "n_max": int(max(n)) if n else 0,
        "kappa_at_max_n": round(float(k[-1]), 6) if k else None,
    }


# -------------------------------------------------------------------
# Pitman-Yor Correctness (PYC) model — analytical form
# -------------------------------------------------------------------
@np.vectorize
def _invdigamma(y, num_iter=6):
    """Newton inverse of digamma. Used to map (h, gamma) <-> (d, alpha)."""
    if y >= -2.22:
        x = np.exp(y) + 0.5
    else:
        x = -1.0 / (y + 0.5772156649)
    for _ in range(num_iter):
        x -= (digamma(x) - y) / polygamma(1, x)
    return x


def _hgamma_to_dalpha(h: float, gamma: float):
    """Map (h, gamma) -> (d, alpha) via inverse digamma."""
    d = float(1.0 - _invdigamma(digamma(1) - h * gamma))
    alpha = float(_invdigamma(h * (1.0 - gamma) + digamma(1)) - 1.0)
    return d, alpha


def _log_gamma_ratio(z, m):
    """Robust log Γ(z+m) - log Γ(z)."""
    z = np.asarray(z, dtype=np.float64)
    m = np.asarray(m, dtype=np.float64)
    return gammaln(z + m) - gammaln(z)


def _stable_R_minus_alpha(logR, alpha):
    if alpha == 0.0:
        return np.exp(logR)
    if alpha < 0.0:
        return np.exp(np.logaddexp(logR, np.log(-alpha)))
    return np.exp(logR) * (-np.expm1(np.log(alpha) - logR))


def pyp_correctness_arr(d: float, alpha: float, n_arr) -> np.ndarray:
    """Expected exact-matching correctness of a Pitman-Yor process at sample
    sizes n_arr.

    κ(n) is the paper's correctness definition for exact matching: the
    expected average inverse anonymity-set size over n records under
    PY(d, α). Equivalently, κ(n) = E[number_of_equivalence_classes / n] for
    exact-matching attacks (each class of size s contributes s × (1/s) = 1
    to the sum 1/|A(x_i)| over its members). This is NOT the same as
    'fraction unique singletons' (#size-1 classes / n) in general; the two
    coincide only when every class has size 1.
    """
    n_arr = np.asarray(n_arr, dtype=np.float64)
    out = np.ones_like(n_arr)
    mask = n_arr > 1
    if not np.any(mask):
        return out
    nm = n_arr[mask]

    if d == 0.0:
        if alpha <= 1e-300:
            out[mask] = 0.0
        else:
            dpsi = digamma(nm + alpha) - digamma(alpha)
            out[mask] = (alpha / nm) * dpsi
        return np.clip(out, 0.0, 1.0)

    if alpha == 0.0:
        logC = _log_gamma_ratio(nm + 1.0, d - 1.0) - gammaln(d + 1.0)
        out[mask] = 1.0 + np.expm1(logC)
        return np.clip(out, 0.0, 1.0)

    logR = _log_gamma_ratio(alpha + d, 1.0 - d) + _log_gamma_ratio(nm + alpha, d)
    nom = _stable_R_minus_alpha(logR, alpha)
    out[mask] = np.clip(nom / (nm * d), 0.0, 1.0)
    return out


@mcp.tool()
def pyc_correctness(h: float, gamma: float, n_values: list) -> dict:
    """Forward predict expected correctness of PYC(h, γ) model.

    Args:
        h: expected Shannon entropy (nats; the paper's main-text Discussion/Fig. 5 reports h in bits — multiply by ln(2) ≈ 0.693 to convert).
        gamma: tail complexity in [0, 1].
        n_values: list of sample sizes.

    Returns:
        dict with d, alpha (canonical PY parameters), kappa_predicted.
    """
    d, alpha = _hgamma_to_dalpha(float(h), float(gamma))
    kappas = pyp_correctness_arr(d, alpha, n_values)
    return {
        "h": float(h),
        "gamma": float(gamma),
        "d_internal": round(d, 6),
        "alpha_internal": round(alpha, 6),
        "n_values": [int(x) for x in n_values],
        "kappa_predicted": [round(float(x), 6) for x in kappas],
    }


# -------------------------------------------------------------------
# Fitting routines
# -------------------------------------------------------------------
@mcp.tool()
def fit_pyc(n_values: list, kappa_values: list, h_init: float = 12.0,
            gamma_init: float = 0.26) -> dict:
    """Fit the 2-parameter Pitman-Yor Correctness model to a single curve.

    Minimises log-weighted quadratic loss
    R(h, γ) = sum_i log(n_i) * (κ_i - E[κ(n_i)|h,γ])^2 / N
    using the Nelder-Mead simplex (paper, eq. 4).

    Args:
        n_values: list of sample sizes (n^(i)).
        kappa_values: empirical correctness at each n (κ_i).
        h_init: starting entropy (nats; the paper's main-text Discussion/Fig. 5 reports h in bits — multiply by ln(2) ≈ 0.693 to convert).
        gamma_init: starting tail complexity (in [0,1]).

    Returns:
        dict with fitted h, gamma, residual loss, RMSE, n_points, success.
    """
    n_arr = np.asarray(n_values, dtype=np.float64)
    k_arr = np.asarray(kappa_values, dtype=np.float64)

    def loss(x):
        h, g = float(x[0]), float(x[1])
        if h <= 0 or g < 0 or g > 1:
            return 1e10
        try:
            d, alpha = _hgamma_to_dalpha(h, g)
            pred = pyp_correctness_arr(d, alpha, n_arr)
            return float((np.log(n_arr) * (pred - k_arr) ** 2).mean())
        except Exception:
            return 1e10

    res = minimize(loss, x0=[h_init, gamma_init], method="Nelder-Mead",
                   options={"xatol": 1e-5, "fatol": 1e-9, "maxiter": 2000})
    h_fit, g_fit = float(res.x[0]), float(res.x[1])
    d, alpha = _hgamma_to_dalpha(h_fit, g_fit)
    pred = pyp_correctness_arr(d, alpha, n_arr)
    rmse = float(np.sqrt(((pred - k_arr) ** 2).mean()))
    return {
        "h_fit": round(h_fit, 4),
        "gamma_fit": round(g_fit, 4),
        "d": round(d, 6),
        "alpha": round(alpha, 6),
        "rmse_pp": round(rmse * 100, 3),
        "loss": round(float(res.fun), 8),
        "n_points": int(len(n_arr)),
        "success": bool(res.success),
        "model": "PYC",
        "n_params": 2,
    }


@mcp.tool()
def fit_entropy_baseline(n_values: list, kappa_values: list,
                         h_init: float = 12.0) -> dict:
    """Fit the 1-parameter entropy baseline (FL / ENT in the paper).

    Assumes uniform distribution over 2^h categories:
    κ(n) ≈ (2^h / n) * (1 - (1 - 2^-h)^n).

    Args:
        n_values: list of sample sizes.
        kappa_values: empirical correctness.
        h_init: starting entropy (bits).

    Returns:
        dict with fitted h, RMSE, loss, success.
    """
    n_arr = np.asarray(n_values, dtype=np.float64)
    k_arr = np.asarray(kappa_values, dtype=np.float64)

    def predict(h):
        x = 2.0 ** (-h)
        stable_term = -np.expm1(n_arr * np.log1p(-x))
        return np.clip(2.0 ** h / n_arr * stable_term, 0.0, 1.0)

    def loss(x):
        h = float(x[0])
        if h <= 0:
            return 1e10
        pred = predict(h)
        return float((np.log(n_arr) * (pred - k_arr) ** 2).mean())

    res = minimize(loss, x0=[h_init], method="Nelder-Mead",
                   options={"xatol": 1e-5, "fatol": 1e-9, "maxiter": 2000})
    h_fit = float(res.x[0])
    pred = predict(h_fit)
    rmse = float(np.sqrt(((pred - k_arr) ** 2).mean()))
    return {
        "h_fit": round(h_fit, 4),
        "rmse_pp": round(rmse * 100, 3),
        "loss": round(float(res.fun), 8),
        "n_points": int(len(n_arr)),
        "success": bool(res.success),
        "model": "ENT",
        "n_params": 1,
    }


@mcp.tool()
def fit_exp_decay(n_values: list, kappa_values: list) -> dict:
    """Fit a 2-parameter exponential decay baseline.

    κ(n) = a * exp(-b * sqrt(n)) + (1 - a * exp(-b)).

    Args:
        n_values: list of sample sizes.
        kappa_values: empirical correctness.

    Returns:
        dict with fitted a, b, RMSE, success.
    """
    n_arr = np.asarray(n_values, dtype=np.float64)
    k_arr = np.asarray(kappa_values, dtype=np.float64)

    def predict(a, b):
        return np.clip(a * np.exp(-b * np.sqrt(n_arr)) + (1 - a * np.exp(-b)), 0, 1)

    def loss(x):
        a, b = float(x[0]), float(x[1])
        pred = predict(a, b)
        return float((np.log(n_arr) * (pred - k_arr) ** 2).mean())

    res = minimize(loss, x0=[1.0, 1.0], method="Nelder-Mead",
                   options={"maxiter": 2000})
    a, b = float(res.x[0]), float(res.x[1])
    pred = predict(a, b)
    rmse = float(np.sqrt(((pred - k_arr) ** 2).mean()))
    return {
        "a": round(a, 6),
        "b": round(b, 6),
        "rmse_pp": round(rmse * 100, 3),
        "loss": round(float(res.fun), 8),
        "success": bool(res.success),
        "model": "EXP",
        "n_params": 2,
    }


@mcp.tool()
def fit_random_baseline(n_values: list, kappa_values: list,
                         seed: int = 42) -> dict:
    """Paper Table 1 RND baseline: per-point κ drawn uniformly.

    Paper Table 1 caption (verbatim): "RND (random) where the value for κ is
    draw uniformly between 0 and n(t)." Because κ is a fraction in [0,1] and
    n(t) appears with the [0,1] cohort-filter bounds in the same Table 1
    note, the bundled implementation interprets the upper bound here as the
    maximum observed κ in the training data and samples each predicted κ
    uniformly from [0, κ_max_train]. This is one defensible interpretation
    of the paper text; users who prefer a different upper bound (e.g.
    U[0, 1] across all predictions) can pass their own predictions through
    standard RMSE evaluation instead.

    Zero-parameter baseline. Paper Table 1 reports RND alongside ENT, EXP,
    POL at each μ cell.

    Args:
        n_values: list of sample sizes (not used by predictor, kept for
            API parity).
        kappa_values: empirical correctness; max value bounds the uniform.
        seed: RNG seed for reproducible RMSE.

    Returns:
        dict with rmse_pp (no fitted parameters).
    """
    n_arr = np.asarray(n_values, dtype=np.float64)
    k_arr = np.asarray(kappa_values, dtype=np.float64)
    rng = np.random.default_rng(seed)
    upper = float(max(k_arr.max() if len(k_arr) else 0.0, 1e-9))
    pred = rng.uniform(0.0, upper, size=len(n_arr))
    rmse = float(np.sqrt(((pred - k_arr) ** 2).mean()))
    return {
        "rmse_pp": round(rmse * 100, 3),
        "model": "RND",
        "n_params": 0,
    }


@mcp.tool()
def fit_polynomial(n_values: list, kappa_values: list) -> dict:
    """Fit the paper's 2-degree-of-freedom polynomial baseline (POL).

    κ(n) = 1 + a * log10(n) + b * log10(n)^2  (intercept fixed at 1 so
    κ(1)=1; two free coefficients a, b — matching paper Table 1's 'POL'
    2-d.o.f. baseline label).

    Args:
        n_values: list of sample sizes.
        kappa_values: empirical correctness.

    Returns:
        dict with fitted a, b, RMSE.
    """
    n_arr = np.asarray(n_values, dtype=np.float64)
    k_arr = np.asarray(kappa_values, dtype=np.float64)

    def predict(a, b):
        ln = np.log10(n_arr)
        return np.clip(a * ln + b * ln ** 2 + 1, 0, 1)

    def loss(x):
        a, b = float(x[0]), float(x[1])
        pred = predict(a, b)
        return float((np.log(n_arr) * (pred - k_arr) ** 2).mean())

    res = minimize(loss, x0=[-1.0, 0.0], method="Nelder-Mead",
                   options={"maxiter": 2000})
    a, b = float(res.x[0]), float(res.x[1])
    pred = predict(a, b)
    rmse = float(np.sqrt(((pred - k_arr) ** 2).mean()))
    return {
        "a": round(a, 6),
        "b": round(b, 6),
        "rmse_pp": round(rmse * 100, 3),
        "loss": round(float(res.fun), 8),
        "success": bool(res.success),
        "model": "POL",
        "n_params": 2,
    }


# -------------------------------------------------------------------
# Extrapolation (PYC-MB) on partial samples
# -------------------------------------------------------------------
@mcp.tool()
def extrapolate_pyc(n_train: list, kappa_train: list, n_predict: list,
                    h_init: float = 12.0, gamma_init: float = 0.26) -> dict:
    """Train PYC on the first part of a curve and forecast at larger n.

    This is the PYC-MB (measurement-based) method of Rocher et al. (eq. 4).
    Used to compare extrapolation accuracy at μ = 1%, 5%, 10% sampling
    fractions of the full population n^(I).

    Args:
        n_train: list of sample sizes used for training.
        kappa_train: empirical correctness at training sizes.
        n_predict: list of sample sizes at which to predict.

    Returns:
        dict with h_fit, gamma_fit, kappa_predicted at n_predict.
    """
    fit = fit_pyc(n_train, kappa_train, h_init=h_init, gamma_init=gamma_init)
    h_fit, g_fit = fit["h_fit"], fit["gamma_fit"]
    d, alpha = _hgamma_to_dalpha(h_fit, g_fit)
    pred = pyp_correctness_arr(d, alpha, n_predict)
    return {
        "h_fit": h_fit,
        "gamma_fit": g_fit,
        "n_predict": [int(x) for x in n_predict],
        "kappa_predicted": [round(float(x), 6) for x in pred],
        "n_train": len(n_train),
    }


@mcp.tool()
def extrapolation_rmse(csv_path: str, corpus: str, mu: float = 0.10,
                       method: str = "PYC") -> dict:
    """Repeat PYC-MB extrapolation across all subsets in a corpus and report
    the average RMSE in p.p. when extrapolating from a fraction μ of the curve
    to the held-out tail.

    Paper Table 1 caption (verbatim): "We also report the number of data
    collections c included from each corpus, left after selecting only data
    collections for which 0.01 < n(t) < 0.99." The paper's n(t) is used
    elsewhere as the training-endpoint sample size (a count), but the
    Table-1-caption filter bounds (0.01, 0.99) are in [0,1], which is the
    range of κ rather than n. The bundled filter therefore operationalises
    the rule as 0.01 < κ(at training endpoint) < 0.99; users who wish to
    apply a strict-count interpretation (e.g. 0.01·n0 < n(t) < 0.99·n0) can
    override by pre-filtering subsets before calling this function.

    Args:
        csv_path: path to correctness curves CSV.
        corpus: corpus name (e.g. 'ADULT', 'GEOM', 'POISSON', 'ZIPF').
        mu: training fraction in (0, 1). Use 0.01, 0.05, 0.10 for paper.
        method: one of 'PYC', 'ENT', 'EXP', 'POL'.

    Returns:
        dict with mean_rmse_pp, std_rmse_pp, n_subsets, n_subsets_dropped_by_cohort_filter, per_subset.
    """
    df = pd.read_csv(csv_path)
    if 'corpus' in df.columns:
        df = df[df['corpus'] == corpus]
    rmses = []
    per = []
    dropped_by_cohort = 0
    for sid, grp in df.groupby('subset_id'):
        grp = grp.sort_values('n_sample')
        n = grp['n_sample'].astype(float).values
        k = grp['kappa'].astype(float).values
        n_max = n.max()
        n_train_max = mu * n_max
        train_mask = n <= n_train_max
        # Paper cohort-selection rule from Methods supplementary protocol:
        # only retain subsets where the empirical correctness at the
        # measurement boundary lies strictly inside (0.01, 0.99) so that
        # degenerate near-zero and near-saturated cells are excluded. Without
        # this filter, subsets where κ is essentially flat at 0 or 1 across
        # the whole population would dominate the aggregated RMSE.
        if train_mask.sum() < 3:
            dropped_by_cohort += 1
            continue
        k_at_train_max = float(k[train_mask][-1])
        if not (0.01 < k_at_train_max < 0.99):
            dropped_by_cohort += 1
            continue
        n_tr = n[train_mask].tolist()
        k_tr = k[train_mask].tolist()
        n_te = n.tolist()
        k_te = k

        if method == "PYC":
            pyc_fit = fit_pyc(n_tr, k_tr)
            d, alpha = _hgamma_to_dalpha(pyc_fit["h_fit"], pyc_fit["gamma_fit"])
            pred = pyp_correctness_arr(d, alpha, n_te)
        elif method == "ENT":
            res = fit_entropy_baseline(n_tr, k_tr)
            h = res["h_fit"]
            x = 2.0 ** (-h)
            pred = np.clip(2.0 ** h / np.array(n_te) *
                           (-np.expm1(np.array(n_te) * np.log1p(-x))), 0, 1)
        elif method == "EXP":
            res = fit_exp_decay(n_tr, k_tr)
            a, b = res["a"], res["b"]
            n_arr = np.array(n_te, dtype=float)
            pred = np.clip(a * np.exp(-b * np.sqrt(n_arr)) + (1 - a * np.exp(-b)), 0, 1)
        elif method == "POL":
            res = fit_polynomial(n_tr, k_tr)
            a, b = res["a"], res["b"]
            ln = np.log10(np.array(n_te, dtype=float))
            pred = np.clip(a * ln + b * ln ** 2 + 1, 0, 1)
        elif method == "RND":
            # Paper Table 1 RND: predicted κ drawn uniformly in [0, max κ_train]
            n_arr_te = np.array(n_te, dtype=float)
            rng = np.random.default_rng(42 + int(sid) if isinstance(sid, int) else 42)
            upper = float(max(max(k_tr) if len(k_tr) else 0.0, 1e-9))
            pred = rng.uniform(0.0, upper, size=len(n_arr_te))
        else:
            raise ValueError(f"Unknown method {method}")

        # RMSE on extrapolated portion (n > training threshold)
        ext_mask = n > n_train_max
        if ext_mask.sum() == 0:
            continue
        rmse = float(np.sqrt(((pred[ext_mask] - k_te[ext_mask]) ** 2).mean()))
        rmses.append(rmse)
        per.append({"subset_id": int(sid), "rmse_pp": round(rmse * 100, 3),
                    "n_train": int(train_mask.sum()),
                    "n_extrapolate": int(ext_mask.sum())})
    arr = np.array(rmses)
    return {
        "corpus": corpus,
        "mu": float(mu),
        "method": method,
        "n_subsets": int(len(arr)),
        "n_subsets_dropped_by_cohort_filter": int(dropped_by_cohort),
        "mean_rmse_pp": round(float(arr.mean() * 100), 3) if len(arr) else None,
        "median_rmse_pp": round(float(np.median(arr) * 100), 3) if len(arr) else None,
        "std_rmse_pp": round(float(arr.std() * 100), 3) if len(arr) else None,
        "per_subset": per[:10],
    }


# -------------------------------------------------------------------
# Model comparison
# -------------------------------------------------------------------
@mcp.tool()
def gaussian_log_likelihood(observed: list, predicted: list,
                            sigma: float | None = None) -> dict:
    """Gaussian log-likelihood of observations given predictions.

    If sigma is None it is estimated from the residuals (MLE).

    Args:
        observed: empirical values κ_i.
        predicted: model predictions.
        sigma: optional fixed standard deviation.

    Returns:
        dict with log_likelihood, sigma_used, n.
    """
    o = np.asarray(observed, dtype=np.float64)
    p = np.asarray(predicted, dtype=np.float64)
    n = len(o)
    res = o - p
    if sigma is None:
        sigma = float(np.sqrt((res ** 2).mean()))
    sigma = max(sigma, 1e-9)
    ll = float(-0.5 * n * np.log(2 * np.pi * sigma ** 2)
               - 0.5 * (res ** 2).sum() / sigma ** 2)
    return {"log_likelihood": float(ll), "log_likelihood_rounded": round(ll, 4),
            "sigma_used": round(sigma, 6), "n": n}


@mcp.tool()
def bic_score(log_likelihood: float, n_params: int, n_obs: int) -> dict:
    """Bayesian Information Criterion. Lower is better.

    BIC = k * ln(n) - 2 * ln(L).
    """
    bic = float(n_params * np.log(n_obs) - 2.0 * log_likelihood)
    aic = float(2.0 * n_params - 2.0 * log_likelihood)
    return {"BIC": round(bic, 4), "AIC": round(aic, 4),
            "n_params": int(n_params), "n_obs": int(n_obs)}


@mcp.tool()
def compare_models_on_corpus(csv_path: str, corpus: str,
                              mu: float = 0.10) -> dict:
    """Measurement-based extrapolation protocol mirroring paper Table 1.

    For each subset in the corpus, train each model (PYC, ENT, EXP, POL) on
    the first μ-fraction of the curve and evaluate RMSE on the held-out
    extrapolation tail (n > μ * n_max). This matches the paper's Table 1
    "measurement-based extrapolation" protocol — NOT a full-curve fit. The
    paper's cohort filter (0.01 < n(t)/n_max < 0.99) is applied as in
    extrapolation_rmse. BIC is computed from the per-fit Gaussian
    log-likelihood evaluated on the training points, with parameter counts
    matching each model's true degrees of freedom.

    Args:
        csv_path: path to correctness curves CSV.
        corpus: corpus name.
        mu: training fraction for measurement-based extrapolation (paper Table
            1 default = 0.10 for the headline 10%-exact-matching column).

    Returns:
        dict mapping model -> {mean_rmse_pp, median_rmse_pp, mean_bic, n_subsets}.
    """
    df = pd.read_csv(csv_path)
    if 'corpus' in df.columns:
        df = df[df['corpus'] == corpus]
    out: dict = {"PYC": [], "ENT": [], "EXP": [], "POL": [], "RND": []}
    bic_out: dict = {"PYC": [], "ENT": [], "EXP": [], "POL": [], "RND": []}
    if not (0.01 < mu < 0.99):
        return {"error": "mu must satisfy paper cohort filter 0.01 < mu < 0.99",
                "mu": float(mu)}
    for sid, grp in df.groupby('subset_id'):
        grp = grp.sort_values('n_sample')
        n_arr = grp['n_sample'].astype(float).values
        k_arr = grp['kappa'].astype(float).values
        if len(n_arr) < 5:
            continue
        n_max = float(n_arr.max())
        n_train_max = mu * n_max
        train_mask = n_arr <= n_train_max
        test_mask = n_arr > n_train_max
        if train_mask.sum() < 3 or test_mask.sum() < 1:
            continue
        # Same paper Table 1 cohort-selection filter used by extrapolation_rmse:
        # exclude curves whose correctness at the training boundary is
        # degenerate (essentially 0 or 1).
        k_at_train_max = float(k_arr[train_mask][-1])
        if not (0.01 < k_at_train_max < 0.99):
            continue
        n_tr = n_arr[train_mask].tolist()
        k_tr = k_arr[train_mask].tolist()
        n_te = n_arr[test_mask]
        k_te = k_arr[test_mask]
        for name, fit_func, k_params in [
            ("PYC", fit_pyc, 2),
            ("ENT", fit_entropy_baseline, 1),
            ("EXP", fit_exp_decay, 2),
            ("POL", fit_polynomial, 2),
            ("RND", fit_random_baseline, 0),
        ]:
            try:
                res = fit_func(n_tr, k_tr)
                # Per-model prediction on the held-out extrapolation tail
                if name == "PYC":
                    d, alpha = _hgamma_to_dalpha(res["h_fit"], res["gamma_fit"])
                    pred = pyp_correctness_arr(d, alpha, n_te.tolist())
                elif name == "ENT":
                    h = res["h_fit"]
                    x = 2.0 ** (-h)
                    pred = np.clip(2.0 ** h / n_te * (-np.expm1(n_te * np.log1p(-x))), 0, 1)
                elif name == "EXP":
                    a, b = res["a"], res["b"]
                    pred = np.clip(a * np.exp(-b * np.sqrt(n_te)) + (1 - a * np.exp(-b)), 0, 1)
                elif name == "POL":
                    a, b = res["a"], res["b"]
                    ln = np.log10(n_te)
                    pred = np.clip(a * ln + b * ln ** 2 + 1, 0, 1)
                else:  # RND: uniform random κ in [0, max κ_train]
                    rng = np.random.default_rng(int(hash(sid)) % (2**31))
                    upper = float(max(max(k_tr) if len(k_tr) else 0.0, 1e-9))
                    pred = rng.uniform(0.0, upper, size=len(n_te))
                rmse = float(np.sqrt(((np.asarray(pred) - k_te) ** 2).mean()))
                out[name].append(rmse * 100)
                # BIC from true Gaussian log-likelihood of TRAINING residuals
                # (call gaussian_log_likelihood on observed-vs-fitted training
                # values rather than approximating ll from RMSE alone).
                if name == "PYC":
                    d, alpha = _hgamma_to_dalpha(res["h_fit"], res["gamma_fit"])
                    pred_tr = pyp_correctness_arr(d, alpha, n_tr)
                elif name == "ENT":
                    h = res["h_fit"]
                    x = 2.0 ** (-h)
                    n_tr_arr = np.asarray(n_tr, dtype=float)
                    pred_tr = np.clip(2.0 ** h / n_tr_arr * (-np.expm1(n_tr_arr * np.log1p(-x))), 0, 1)
                elif name == "EXP":
                    a, b = res["a"], res["b"]
                    n_tr_arr = np.asarray(n_tr, dtype=float)
                    pred_tr = np.clip(a * np.exp(-b * np.sqrt(n_tr_arr)) + (1 - a * np.exp(-b)), 0, 1)
                elif name == "POL":
                    a, b = res["a"], res["b"]
                    ln_tr = np.log10(np.asarray(n_tr, dtype=float))
                    pred_tr = np.clip(a * ln_tr + b * ln_tr ** 2 + 1, 0, 1)
                else:  # RND
                    rng_tr = np.random.default_rng(int(hash(sid) ^ 0xBADC0DE) % (2**31))
                    upper_tr = float(max(max(k_tr) if len(k_tr) else 0.0, 1e-9))
                    pred_tr = rng_tr.uniform(0.0, upper_tr, size=int(train_mask.sum()))
                ll_dict = gaussian_log_likelihood(list(k_tr),
                                                  [float(p) for p in pred_tr])
                n_obs = int(train_mask.sum())
                bic_res = bic_score(ll_dict["log_likelihood"], k_params, n_obs)
                bic_out[name].append(bic_res["BIC"])
            except Exception:
                continue
    summary = {}
    for name in out:
        arr = np.array(out[name])
        bic_arr = np.array(bic_out[name])
        summary[name] = {
            "mean_rmse_pp": round(float(arr.mean()), 3) if len(arr) else None,
            "median_rmse_pp": round(float(np.median(arr)), 3) if len(arr) else None,
            "mean_bic": round(float(bic_arr.mean()), 3) if len(bic_arr) else None,
            "n_subsets": int(len(arr)),
        }
    return {"corpus": corpus, "mu": float(mu), "protocol": "measurement-based extrapolation (paper Table 1)",
            "summary": summary}


# -------------------------------------------------------------------
# Empirical helpers
# -------------------------------------------------------------------
@mcp.tool()
def empirical_correctness_from_attributes(csv_path: str, attribute_cols: list,
                                          n_sample: int | None = None,
                                          random_state: int = 42) -> dict:
    """Compute empirical correctness κ on a tabular dataset given a quasi-
    identifier subset, following the paper's definition of correctness as the
    expected fraction of records correctly re-identified by an exact-matching
    attacker who knows the attribute_cols values.

    Per the paper, κ is the average inverse anonymity-set size over records:
        κ = (1 / n) * Σ_i (1 / |A(x_i)|)
    where A(x_i) = {records sharing the same attribute_cols values as x_i}.

    Args:
        csv_path: path to a raw tabular CSV (e.g. ADULT).
        attribute_cols: columns to use as auxiliary information φ(x).
        n_sample: optional sub-sample size.
        random_state: random seed for sub-sampling.

    Returns:
        dict with kappa (paper-correct definition), n,
        n_unique_combinations (for context), kappa_uniqueness
        (legacy ratio for comparison), attributes_used.
    """
    df = pd.read_csv(csv_path)
    if n_sample is not None and n_sample < len(df):
        df = df.sample(n=n_sample, random_state=random_state)
    sub = df[attribute_cols]
    n_total = len(sub)
    group_sizes = sub.groupby(attribute_cols, dropna=False).size()
    # Average inverse anonymity-set size: each record contributes 1/|A(x)|
    # = (#equivalence_classes_of_size_s * s * (1/s)) / n = n_unique / n? No -
    # we want sum over records of 1/|A(x)|; each record in a class of size s
    # contributes 1/s, and there are s such records, so the class contributes
    # s * (1/s) = 1. Total = n_classes. So kappa_paper = n_classes / n.
    n_classes = int(len(group_sizes))
    kappa = n_classes / n_total if n_total > 0 else 0.0
    return {
        "n": int(n_total),
        "n_unique_combinations": n_classes,
        "kappa": round(float(kappa), 6),
        "kappa_uniqueness": round(float(n_classes) / float(n_total), 6) if n_total > 0 else 0.0,
        "attributes_used": list(attribute_cols),
        "definition_note": "kappa = average inverse anonymity-set size, i.e. kappa = (1/n) * sum_i 1/|A(x_i)| (paper definition). Algebraically this is mathematically equal to n_classes / n_total (each class of size s contributes s * (1/s) = 1 to the sum, so the sum over records equals the number of classes). NOTE this is NOT the same as the 'fraction unique' (#singletons/n); fraction-unique only counts classes of size 1, while kappa averages 1/size across ALL records. The two metrics coincide only when every class has size 1 (fully unique cohort).",
    }


# -------------------------------------------------------------------
# Plotting
# -------------------------------------------------------------------
@mcp.tool()
def plot_correctness_curve(n_values: list, kappa_values: list,
                           out_path: str, model: str | None = "PYC",
                           h: float | None = None, gamma: float | None = None,
                           title: str | None = None) -> dict:
    """Plot empirical correctness vs sample size with optional model overlay.

    Args:
        n_values: sample sizes.
        kappa_values: empirical κ.
        out_path: destination PNG path.
        model: optional model overlay ('PYC', 'ENT', 'EXP', 'POL'); pass None
            to plot data only.
        h, gamma: PYC parameters (required if model == 'PYC').
        title: figure title.

    Returns:
        dict with file path and meta.
    """
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    n_arr = np.asarray(n_values, dtype=float)
    k_arr = np.asarray(kappa_values, dtype=float)

    fig, ax = plt.subplots(figsize=(6, 4.2))
    ax.scatter(n_arr, k_arr, s=20, c='black', alpha=0.7, label='Empirical κ')
    if model == "PYC" and h is not None and gamma is not None:
        n_smooth = np.logspace(np.log10(n_arr.min()), np.log10(n_arr.max() * 10), 200)
        d, alpha = _hgamma_to_dalpha(h, gamma)
        pred = pyp_correctness_arr(d, alpha, n_smooth)
        ax.plot(n_smooth, pred, '-', color='C0', lw=2,
                label=f'PYC (h={h:.2f}, γ={gamma:.2f})')
    ax.set_xscale('log')
    ax.set_xlabel('Population size n')
    ax.set_ylabel('Correctness κ')
    ax.set_ylim(0, 1.02)
    if title:
        ax.set_title(title)
    ax.legend(loc='best', fontsize=9)
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    plt.close()
    return {"path": out_path, "n_points": int(len(n_arr))}


@mcp.tool()
def plot_model_comparison(n_values: list, kappa_values: list,
                          fitted: dict, out_path: str,
                          title: str | None = None) -> dict:
    """Plot a single empirical curve with overlays of multiple fitted models.

    Args:
        n_values: sample sizes.
        kappa_values: empirical κ.
        fitted: dict mapping model name ('PYC','ENT','EXP','POL') ->
            parameters dict (must contain the keys returned by the fit_* tools).
        out_path: destination PNG path.
        title: figure title.

    Returns:
        dict with file path.
    """
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    n_arr = np.asarray(n_values, dtype=float)
    k_arr = np.asarray(kappa_values, dtype=float)
    n_smooth = np.logspace(np.log10(n_arr.min()), np.log10(n_arr.max() * 10), 200)

    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.scatter(n_arr, k_arr, s=22, c='black', alpha=0.7, label='Empirical κ', zorder=5)
    colours = {"PYC": "C0", "ENT": "tab:orange", "EXP": "tab:green", "POL": "tab:red"}
    for name, params in fitted.items():
        if name == "PYC":
            d, alpha = _hgamma_to_dalpha(params["h_fit"], params["gamma_fit"])
            y = pyp_correctness_arr(d, alpha, n_smooth)
        elif name == "ENT":
            h = params["h_fit"]
            x = 2.0 ** (-h)
            y = np.clip(2.0 ** h / n_smooth * (-np.expm1(n_smooth * np.log1p(-x))), 0, 1)
        elif name == "EXP":
            a, b = params["a"], params["b"]
            y = np.clip(a * np.exp(-b * np.sqrt(n_smooth)) + (1 - a * np.exp(-b)), 0, 1)
        elif name == "POL":
            a, b = params["a"], params["b"]
            ln = np.log10(n_smooth)
            y = np.clip(a * ln + b * ln ** 2 + 1, 0, 1)
        else:
            continue
        rmse = params.get("rmse_pp", "?")
        ax.plot(n_smooth, y, '-', color=colours.get(name, 'gray'),
                lw=1.6, label=f'{name} (RMSE={rmse} p.p.)')
    ax.set_xscale('log')
    ax.set_xlabel('Population size n')
    ax.set_ylabel('Correctness κ')
    ax.set_ylim(0, 1.02)
    if title:
        ax.set_title(title)
    ax.legend(loc='best', fontsize=8)
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    plt.close()
    return {"path": out_path}


@mcp.tool()
def plot_rmse_summary(rmse_table: dict, out_path: str,
                      title: str | None = None) -> dict:
    """Bar-plot of mean RMSE (p.p.) across corpora x methods.

    Args:
        rmse_table: nested dict {corpus -> {method -> mean_rmse_pp}}.
        out_path: destination PNG path.
        title: figure title.

    Returns:
        dict with file path.
    """
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    corpora = list(rmse_table.keys())
    methods = ["PYC", "ENT", "EXP", "POL"]
    width = 0.18
    x = np.arange(len(corpora))
    fig, ax = plt.subplots(figsize=(7, 4.5))
    colours = {"PYC": "C0", "ENT": "tab:orange", "EXP": "tab:green", "POL": "tab:red"}
    for i, m in enumerate(methods):
        vals = [rmse_table[c].get(m, 0) for c in corpora]
        ax.bar(x + i * width - 1.5 * width, vals, width=width,
               label=m, color=colours[m])
    ax.set_xticks(x)
    ax.set_xticklabels(corpora)
    ax.set_ylabel('Mean RMSE (p.p.)')
    if title:
        ax.set_title(title)
    ax.legend(loc='best', fontsize=9)
    ax.grid(True, axis='y', alpha=0.3)
    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    plt.close()
    return {"path": out_path}


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "--test":
        # smoke test
        import json
        df = pd.read_csv(Path(__file__).parent.parent / "input_data/data/adult_correctness_curves.csv")
        sub = df[df['subset_id'] == 0].sort_values('n_sample')
        n = sub['n_sample'].astype(float).tolist()
        k = sub['kappa'].astype(float).tolist()
        print("PYC fit:", json.dumps(fit_pyc(n, k), indent=2))
        print("ENT fit:", json.dumps(fit_entropy_baseline(n, k), indent=2))
    else:
        mcp.run()

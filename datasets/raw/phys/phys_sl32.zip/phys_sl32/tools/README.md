# phys_sl32 — Tool Reference

## Database Retrieval (`database_retrieval.py`)

OFFLINE module — the bundle is self-contained, no network is needed.

- **list_local_files**: inventory of files under a directory (path, size,
  suffix). Useful for confirming the bundle is intact before starting.

## Data Processing (`data_processing.py`)

- **read_csv**: Parse CSV into list-of-dicts.
- **write_csv**: Write list-of-dicts to CSV.
- **read_json / write_json**: JSON IO helpers.
- **filter_rows**: Filter rows by `col == value`.
- **group_rows**: Group rows by a column value.
- **coerce_numeric**: Cast named columns to float.
- **select_columns**: Project rows onto a subset of columns.
- **unique_values**: Sorted unique values of a column.
- **descriptive_summary**: count/mean/std/min/max/median of a list.

## Domain-Specific Analysis (`identification_scaling.py`)

### IO
- **load_correctness_curves**: Load empirical correctness measurement curves (filter by corpus / subset_id).
- **get_curve**: Extract one (n, kappa) curve as parallel arrays.

### PYC model (Pitman-Yor Correctness)
- **pyc_correctness**: Forward predict expected kappa from PYC(h, gamma) at given n values.
- **fit_pyc**: Fit two-parameter (h, gamma) PYC to a single empirical curve via Nelder-Mead on log-weighted quadratic loss (paper eq. 4).

### Baselines
- **fit_entropy_baseline**: One-parameter FL/ENT baseline assuming uniform 2^h categories.
- **fit_exp_decay**: Two-parameter exponential decay kappa(n) = a exp(-b sqrt(n)) + (1 - a exp(-b)).
- **fit_polynomial**: Three-parameter cubic polynomial in log10(n) with intercept = 1.

### Forecasting and comparison
- **extrapolate_pyc**: Train PYC on a partial curve and forecast at unseen n (PYC-MB).
- **extrapolation_rmse**: Aggregate RMSE in p.p. across all subsets in a corpus when training on the first mu fraction.
- **gaussian_log_likelihood**: Log-likelihood of observations under Gaussian residuals.
- **bic_score**: BIC and AIC from log-likelihood, parameter count, observation count.
- **compare_models_on_corpus**: Fit PYC/ENT/EXP/POL on every curve and report aggregated RMSE and mean BIC.

### Empirical helpers
- **empirical_correctness_from_attributes**: Compute kappa for a tabular dataset given an attribute subset.

### Plotting
- **plot_correctness_curve**: Plot one empirical curve with optional PYC overlay.
- **plot_model_comparison**: Single curve with overlays of multiple fitted models.
- **plot_rmse_summary**: Bar chart of mean RMSE across corpora x methods.

## Dependencies

```
numpy, pandas, scipy, matplotlib, mcp[fastmcp]
```

# phys_sl32 — Tool Reference

## Database Retrieval (`database_retrieval.py`)

- **fetch_url**: HTTP GET; return body as str (utf-8).
- **fetch_binary**: HTTP GET; save body to dest_path. Returns size info.
- **query_uci_repo**: UCI Machine Learning Repository lookup (stub).
- **query_osf**: OSF (Open Science Framework) project file listing (stub).
- **query_doi**: Resolve a DOI to a Crossref metadata record (stub).
- **websearch**: Generic web search (stub).

## Data Processing (`data_processing.py`)

- **read_csv**: Parse CSV into list-of-dicts.
- **write_csv**: Write list-of-dicts to CSV.
- **read_json / write_json**: JSON IO helpers.
- **filter_rows**: Filter rows by `col == value`.
- **group_rows**: Group rows by a column value.
- **coerce_numeric**: Cast named columns to float.
- **select_columns**: Project rows onto a subset of columns.
- **unique_values**: Sorted unique values of a column.
- **descriptive_summary**: count/mean/std/min/max/median of a list.

## Domain-Specific Analysis (`identification_scaling.py`)

### IO
- **load_correctness_curves**: Load empirical correctness measurement curves (filter by corpus / subset_id).
- **get_curve**: Extract one (n, kappa) curve as parallel arrays.

### PYC model (Pitman-Yor Correctness)
- **pyc_correctness**: Forward predict expected kappa from PYC(h, gamma) at given n values.
- **fit_pyc**: Fit two-parameter (h, gamma) PYC to a single empirical curve via Nelder-Mead on log-weighted quadratic loss (paper eq. 4).

### Baselines
- **fit_entropy_baseline**: One-parameter FL/ENT baseline assuming uniform 2^h categories.
- **fit_exp_decay**: Two-parameter exponential decay kappa(n) = a exp(-b sqrt(n)) + (1 - a exp(-b)).
- **fit_polynomial**: 2-degree-of-freedom polynomial baseline κ(n) = 1 + a·log10(n) + b·log10(n)² (two free coefficients a, b; intercept fixed at 1 to enforce κ(1) = 1). Labelled POL in the paper's baseline comparison, matching the paper Table 1 2-d.o.f. label. compare_models_on_corpus passes n_params=2 for BIC.
- **fit_random_baseline**: Paper Table 1 RND baseline. Per its Table 1 caption "RND (random) where the value for κ is draw uniformly between 0 and n(t)" — implemented as per-point κ drawn uniformly from [0, max(κ_train)] with a fixed seed for reproducibility (n(t) in the paper caption interpreted as the κ-at-training-endpoint, since the filter context bounds 0.01..0.99 require a [0,1] quantity).

### Forecasting and comparison
- **extrapolate_pyc**: Train PYC on a partial curve and forecast at unseen n (PYC-MB).
- **extrapolation_rmse**: Aggregate RMSE in p.p. across all subsets in a corpus when training on the first mu fraction.
- **gaussian_log_likelihood**: Log-likelihood of observations under Gaussian residuals.
- **bic_score**: BIC and AIC from log-likelihood, parameter count, observation count.
- **compare_models_on_corpus**: Fit PYC/ENT/EXP/POL on every curve and report aggregated RMSE and mean BIC.

### Empirical helpers
- **empirical_correctness_from_attributes**: Compute kappa for a tabular dataset given an attribute subset.

### Plotting
- **plot_correctness_curve**: Plot one empirical curve with optional PYC overlay.
- **plot_model_comparison**: Single curve with overlays of multiple fitted models.
- **plot_rmse_summary**: Bar chart of mean RMSE across corpora x methods.

## Dependencies

```
numpy, pandas, scipy, matplotlib, mcp[fastmcp]
```

#!/usr/bin/env python3
"""verify_bundle.py — confirm phys_sl32 zip contents match task_content.json.

Checks:
  - 4 correctness-curve CSVs exist with 1,250 data rows each (50 subsets × 25 n)
  - adult_raw.csv exists with 32,561 data rows
  - all 3 bundled artifacts exist (3 PNG)
  - target.pdf and 1.pdf are present (the only declared references)
  - every input_data path declared in task_content.json is physically present
  - artifacts/ contains no agent_-prefixed files

Exit 0 = all pass.
"""

from __future__ import annotations

import csv
import json
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path

EXPECTED_CURVE_CSVS = {
    "input_data/data/adult_correctness_curves.csv":   1250,
    "input_data/data/geom_correctness_curves.csv":    1250,
    "input_data/data/poisson_correctness_curves.csv": 1250,
    "input_data/data/zipf_correctness_curves.csv":    1250,
}
EXPECTED_ADULT_RAW_ROWS = 32561
EXPECTED_REFS = [
    "input_data/reference_paper/target.pdf",
    "input_data/reference_paper/1.pdf",
]
EXPECTED_ARTIFACTS = [
    "artifacts/Fig1_pyc_fit_quality.png",
    "artifacts/Fig2_baseline_comparison.png",
    "artifacts/Fig3_extrapolation_rmse.png",
]


def main(root_or_zip: str) -> int:
    p = Path(root_or_zip)
    cleanup: Path | None = None
    if p.suffix == ".zip" and p.is_file():
        extract = Path(tempfile.mkdtemp(prefix="phys_sl32_verify_"))
        cleanup = extract
        with zipfile.ZipFile(p) as zf:
            zf.extractall(extract)
        # zip may extract a phys_sl32 wrapper dir; descend if needed
        if (extract / "phys_sl32").is_dir():
            root = extract / "phys_sl32"
        else:
            root = extract
    else:
        root = p

    errs: list[str] = []

    for rel, expected_rows in EXPECTED_CURVE_CSVS.items():
        path = root / rel
        if not path.is_file():
            errs.append(f"MISSING curve CSV: {rel}")
            continue
        with open(path, newline="") as f:
            rdr = csv.reader(f)
            next(rdr)  # header
            n = sum(1 for _ in rdr)
            if n != expected_rows:
                errs.append(f"{rel}: {n} data rows != {expected_rows}")

    adult = root / "input_data/data/adult_raw.csv"
    if not adult.is_file():
        errs.append("MISSING adult_raw.csv")
    else:
        with open(adult, newline="") as f:
            rdr = csv.reader(f)
            next(rdr)
            n = sum(1 for _ in rdr)
            if n != EXPECTED_ADULT_RAW_ROWS:
                errs.append(f"adult_raw.csv: {n} data rows != {EXPECTED_ADULT_RAW_ROWS}")

    for rel in EXPECTED_REFS + EXPECTED_ARTIFACTS:
        if not (root / rel).is_file():
            errs.append(f"MISSING file: {rel}")

    tc = root / "task_content" / "task_content.json"
    if tc.is_file():
        j = json.load(open(tc))
        for item in j.get("input_data", []):
            if not (root / item["path"]).is_file():
                errs.append(f"task_content declares missing input: {item['path']}")

    art = root / "artifacts"
    if art.is_dir():
        for f in art.iterdir():
            if f.name.startswith("agent_"):
                errs.append(f"agent_-prefixed file should not be bundled: {f.name}")

    if cleanup is not None:
        shutil.rmtree(cleanup, ignore_errors=True)
    if errs:
        print("verify_bundle: FAIL")
        for e in errs:
            print(" -", e)
        return 1
    print("verify_bundle: OK — 4 correctness-curve CSVs (1,250 rows each), "
          f"adult_raw.csv ({EXPECTED_ADULT_RAW_ROWS} rows), 2 reference PDFs, "
          "3 bundled artifact PNGs, all input_data declarations resolved; "
          "no agent_-prefixed leakage in artifacts/.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1] if len(sys.argv) > 1 else "."))

"""External database retrieval stubs.

Generic primitives for fetching data from public sources. The task's primary
empirical curves are bundled in input_data/data/ so these are provided as
fallback only.
"""
from typing import Any
import json
import urllib.request
import urllib.parse


def fetch_url(url: str, timeout: float = 30.0) -> str:
    """HTTP GET; return body as str (utf-8). Raises on non-2xx."""
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read().decode("utf-8", errors="replace")


def fetch_binary(url: str, dest_path: str, timeout: float = 60.0) -> dict:
    """HTTP GET; save body to dest_path. Returns size info."""
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        data = resp.read()
    with open(dest_path, "wb") as f:
        f.write(data)
    return {"path": dest_path, "bytes": len(data)}


def query_uci_repo(dataset_name: str) -> dict:
    """UCI Machine Learning Repository lookup. Returns metadata + data url."""
    pass  # heavy: would scrape https://archive.ics.uci.edu


def query_osf(node_id: str, file_path: str | None = None) -> dict:
    """OSF (Open Science Framework) project file listing or file download."""
    pass  # heavy: requires OSF API


def query_doi(doi: str) -> dict:
    """Resolve a DOI to a Crossref metadata record."""
    pass  # heavy: requires Crossref API


def websearch(query: str, n_results: int = 10) -> list[dict]:
    """Generic web search (Google/Bing/DuckDuckGo via scraping backend)."""
    pass  # heavy

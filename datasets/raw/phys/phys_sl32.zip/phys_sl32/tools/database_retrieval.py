"""Local resource helpers for phys_sl32 (OFFLINE).

The task's 4 correctness-curve CSVs (ADULT, GEOM, POISSON, ZIPF) and the
ADULT raw table are physically bundled in input_data/data/, so no external
retrieval is required to complete the task. This module intentionally
exposes no network helpers; the bundle is fully self-contained.

If a downstream workflow ever needs to fetch updated copies from the UCI
repository or any other public mirror, the runtime should inject its own
HTTP client at that time rather than relying on this module.
"""

from pathlib import Path


def list_local_files(directory: str = ".") -> list[dict]:
    """Inventory of local files under ``directory`` (size + suffix).

    Lightweight local-only helper used to confirm bundled inputs are
    present on disk before running the scaling-law analysis.
    """
    base = Path(directory)
    out = []
    for p in sorted(base.rglob("*")):
        if p.is_file():
            out.append({
                "path": str(p.relative_to(base)),
                "size_bytes": int(p.stat().st_size),
                "suffix": p.suffix.lower(),
            })
    return out

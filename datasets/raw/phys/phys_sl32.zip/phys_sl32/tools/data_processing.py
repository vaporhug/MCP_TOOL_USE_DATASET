"""Generic data-processing utilities.

Format conversion, reshaping, cleaning, and lightweight transforms that are
*not* specific to the task's scientific domain. Domain-specific transforms
(Pitman-Yor process inference, correctness modelling, etc.) live in the
task's main tools module.
"""
from typing import Any
import csv
import json


def read_csv(path: str, delimiter: str = ",") -> list[dict]:
    """Parse CSV into list-of-dicts using csv.DictReader."""
    with open(path, newline="") as f:
        return list(csv.DictReader(f, delimiter=delimiter))


def write_csv(rows: list[dict], path: str) -> None:
    """Write list-of-dicts to CSV, using the first row's keys as header."""
    if not rows:
        open(path, "w").close()
        return
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def read_json(path: str) -> Any:
    with open(path) as f:
        return json.load(f)


def write_json(obj: Any, path: str, indent: int = 2) -> None:
    with open(path, "w") as f:
        json.dump(obj, f, indent=indent, default=str)


def filter_rows(rows: list[dict], col: str, value: Any) -> list[dict]:
    """Return rows where row[col] == value (string-compare)."""
    return [r for r in rows if str(r.get(col)) == str(value)]


def group_rows(rows: list[dict], by: str) -> dict[str, list[dict]]:
    """Group rows by the value of `by`. Returns dict of group_value -> rows."""
    out: dict = {}
    for r in rows:
        out.setdefault(r.get(by), []).append(r)
    return out


def coerce_numeric(rows: list[dict], cols: list[str]) -> list[dict]:
    """Cast named columns to float; non-parseable -> None."""
    out = []
    for r in rows:
        r2 = dict(r)
        for c in cols:
            try:
                r2[c] = float(r2[c])
            except (TypeError, ValueError):
                r2[c] = None
        out.append(r2)
    return out


def select_columns(rows: list[dict], cols: list[str]) -> list[dict]:
    """Return rows with only the named columns."""
    return [{c: r.get(c) for c in cols} for r in rows]


def unique_values(rows: list[dict], col: str) -> list:
    """Return the sorted unique values of a column. None entries are kept
    only if they appear; for mixed types they are returned in first-seen
    order before the sort succeeds.
    """
    seen = set()
    out = []
    for r in rows:
        v = r.get(col)
        if v not in seen:
            seen.add(v)
            out.append(v)
    try:
        return sorted(out)
    except TypeError:
        # mixed un-orderable types — fall back to first-seen order
        return out


def descriptive_summary(values: list) -> dict:
    """Min/max/mean/sample-std/median for a list of floats. None entries
    skipped. For even-N samples the median is the average of the two
    middle elements (statistics.median convention).
    """
    arr = [float(v) for v in values if v is not None and v == v]
    n = len(arr)
    if n == 0:
        return {"count": 0}
    arr_sorted = sorted(arr)
    mean = sum(arr) / n
    # Sample variance (ddof=1) when n > 1
    var = sum((x - mean) ** 2 for x in arr) / (n - 1) if n > 1 else 0.0
    if n % 2 == 1:
        med = arr_sorted[n // 2]
    else:
        med = 0.5 * (arr_sorted[n // 2 - 1] + arr_sorted[n // 2])
    return {
        "count": n,
        "mean": round(mean, 6),
        "std": round(var ** 0.5, 6),
        "min": round(arr_sorted[0], 6),
        "max": round(arr_sorted[-1], 6),
        "median": round(med, 6),
    }

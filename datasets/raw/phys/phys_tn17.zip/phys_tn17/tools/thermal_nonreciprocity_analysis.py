#!/usr/bin/env python3
"""Domain tools for analyzing loss-assisted thermal nonreciprocal metamaterials.

Includes loaders for geometric parameters, material properties, and experimental
temperature profiles; routines to compute heat flux from temperature gradients,
rectification ratios from forward/backward profiles; and plotting helpers.
"""

import json
import os
import csv
import numpy as np
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Thermal_Nonreciprocity_Tools")


@mcp.tool()
def load_csv(csv_path: str, filters: dict = None) -> dict:
    """Load a CSV file as list of dicts with optional row filter.

    Args:
        csv_path: Path to a CSV file.
        filters: Optional {column: value} mapping to keep only matching rows.

    Returns:
        dict with columns, total_rows, and rows (first 100).
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    if filters:
        for col, val in filters.items():
            if col in df.columns:
                df = df[df[col] == val]
    rows = df.to_dict("records")
    return {
        "columns": list(df.columns),
        "total_rows": len(rows),
        "rows": rows[:100],
        "truncated": len(rows) > 100,
    }


@mcp.tool()
def load_json(json_path: str) -> dict:
    """Load a JSON file (e.g., experimental_geometry.json) and return its content."""
    with open(json_path) as f:
        return json.load(f)


@mcp.tool()
def list_unique_values(csv_path: str, column: str) -> dict:
    """List unique values of a column in a CSV file.

    Useful for discovering materials, directions, or plate counts present.
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    if column not in df.columns:
        return {"error": f"column {column} not found", "columns": list(df.columns)}
    vals = df[column].unique().tolist()
    return {"column": column, "n_unique": len(vals), "values": vals}


@mcp.tool()
def linear_fit(x_values: list, y_values: list) -> dict:
    """Ordinary least squares linear fit y = a + b*x. Returns slope, intercept, R^2."""
    x = np.asarray(x_values, dtype=float)
    y = np.asarray(y_values, dtype=float)
    mask = ~(np.isnan(x) | np.isnan(y))
    x, y = x[mask], y[mask]
    if len(x) < 2:
        return {"error": "need at least 2 points"}
    slope, intercept = np.polyfit(x, y, 1)
    yp = slope * x + intercept
    ss_res = float(np.sum((y - yp) ** 2))
    ss_tot = float(np.sum((y - y.mean()) ** 2))
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0
    return {
        "slope": round(float(slope), 6),
        "intercept": round(float(intercept), 4),
        "r_squared": round(r2, 6),
        "n_points": int(len(x)),
    }


@mcp.tool()
def conductive_heat_flux(slope_K_per_m: float, kappa_W_m_K: float,
                         cross_section_area_m2: float) -> dict:
    """Compute conductive heat flux q = -kappa * A * dT/dx (Fourier's law) in watts.

    Args:
        slope_K_per_m: Temperature gradient dT/dx (K/m).
        kappa_W_m_K: Thermal conductivity (W m^-1 K^-1).
        cross_section_area_m2: Cross-sectional area (m^2).

    Returns:
        dict with heat flow magnitude and signed value.
    """
    q_signed = -kappa_W_m_K * cross_section_area_m2 * slope_K_per_m
    return {
        "q_signed_W": round(float(q_signed), 6),
        "q_magnitude_W": round(float(abs(q_signed)), 6),
        "slope_K_per_m": slope_K_per_m,
        "kappa_W_m_K": kappa_W_m_K,
        "area_m2": cross_section_area_m2,
    }


@mcp.tool()
def rectification_ratio(q_forward: float, q_backward: float) -> dict:
    """Compute rectification ratio gamma = |qF - qB| / (|qF| + |qB|).

    Args:
        q_forward: Heat flow magnitude in the forward direction (W).
        q_backward: Heat flow magnitude in the corresponding backward direction (W).

    Returns:
        dict with gamma in [0, 1] and intermediate sums/differences.
    """
    qf = abs(float(q_forward))
    qb = abs(float(q_backward))
    denom = qf + qb
    gamma = abs(qf - qb) / denom if denom > 0 else 0.0
    return {
        "gamma": round(float(gamma), 4),
        "qF_abs": round(qf, 6),
        "qB_abs": round(qb, 6),
        "abs_diff": round(abs(qf - qb), 6),
        "sum": round(denom, 6),
    }


@mcp.tool()
def compute_inflow_outflow_fluxes(csv_path: str, group_value: str | int | float,
                                   group_column: str, kappa_W_m_K: float,
                                   inflow_x_max_m: float = 0.011,
                                   outflow_x_min_m: float = 0.039,
                                   base_length_m: float = 0.10,
                                   cross_section_area_m2: float = 8e-5) -> dict:
    """Compute forward inflow (q_FI) and backward inflow (q_BIII) plus the
    corresponding outflow magnitudes from temperature profiles in a CSV.

    The CSV must contain columns x_m, T_K, direction (F or B), and the column
    used to filter (e.g., material or plate_count_N). For each direction:
      * inflow region I (x in [0, inflow_x_max_m]) -> linear fit -> heat flow
      * outflow region III (x in [outflow_x_min_m, base_length_m]) -> heat flow

    Args:
        csv_path: CSV with columns x_m, T_K, direction, group_column.
        group_value: Value to filter on group_column.
        group_column: Column name to filter the dataset.
        kappa_W_m_K: Thermal conductivity of the base.
        inflow_x_max_m: Upper boundary x for region I.
        outflow_x_min_m: Lower boundary x for region III.
        base_length_m: Total base length (for region III upper bound).
        cross_section_area_m2: Base cross-section A (default 0.04 m * 0.002 m).

    Returns:
        dict with q_FI, q_BIII, q_FIII, q_BI (W) and rectification ratios gamma1, gamma2.
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    df = df[df[group_column] == group_value]
    if df.empty:
        return {"error": f"no rows for {group_column}={group_value}"}

    out = {}
    for direction in ["F", "B"]:
        sub = df[df["direction"] == direction].sort_values("x_m")
        if sub.empty:
            return {"error": f"no rows for direction {direction}"}
        x = sub["x_m"].to_numpy()
        T = sub["T_K"].to_numpy()
        # region I
        mI = (x <= inflow_x_max_m + 1e-9)
        if mI.sum() >= 2:
            sI, _ = np.polyfit(x[mI], T[mI], 1)
            qI = -kappa_W_m_K * cross_section_area_m2 * sI
        else:
            qI = float("nan")
        # region III
        mIII = (x >= outflow_x_min_m - 1e-9)
        if mIII.sum() >= 2:
            sIII, _ = np.polyfit(x[mIII], T[mIII], 1)
            qIII = -kappa_W_m_K * cross_section_area_m2 * sIII
        else:
            qIII = float("nan")
        out[direction] = {"q_region_I": qI, "q_region_III": qIII}

    qFI = abs(out["F"]["q_region_I"])
    qFIII = abs(out["F"]["q_region_III"])
    qBI = abs(out["B"]["q_region_I"])
    qBIII = abs(out["B"]["q_region_III"])
    gamma1 = abs(qFI - qBIII) / (qFI + qBIII) if (qFI + qBIII) > 0 else 0.0
    gamma2 = abs(qFIII - qBI) / (qFIII + qBI) if (qFIII + qBI) > 0 else 0.0
    return {
        "group_column": group_column,
        "group_value": group_value,
        "kappa_W_m_K": kappa_W_m_K,
        "q_FI_W": round(float(qFI), 6),
        "q_FIII_W": round(float(qFIII), 6),
        "q_BI_W": round(float(qBI), 6),
        "q_BIII_W": round(float(qBIII), 6),
        "gamma1_inflow": round(float(gamma1), 4),
        "gamma2_outflow": round(float(gamma2), 4),
        "effective_threshold_0p1": (gamma1 > 0.1) or (gamma2 > 0.1),
    }


@mcp.tool()
def batch_rectification_by_material(csv_path: str = None,
                                     materials_csv: str = None) -> dict:
    """Compute rectification ratios for every material in a Fig.3-style CSV.

    Args:
        csv_path: temperature profile CSV with column 'material'.
        materials_csv: CSV with name, kappa_W_m_K columns.

    Returns:
        dict with per-material gamma1 and gamma2.
    """
    import pandas as pd
    df_T = pd.read_csv(csv_path)
    df_M = pd.read_csv(materials_csv)
    out = []
    for _, row in df_M.iterrows():
        name = row["name"]
        kappa = float(row["kappa_W_m_K"])
        res = compute_inflow_outflow_fluxes(
            csv_path=csv_path,
            group_value=name,
            group_column="material",
            kappa_W_m_K=kappa,
        )
        if "error" in res: continue
        out.append({
            "material": name,
            "kappa_W_m_K": kappa,
            "gamma1_inflow": res["gamma1_inflow"],
            "gamma2_outflow": res["gamma2_outflow"],
            "q_FI_W": res["q_FI_W"],
            "q_BIII_W": res["q_BIII_W"],
        })
    return {"n_materials": len(out), "results": out}


@mcp.tool()
def batch_rectification_by_plate_count(csv_path: str = None,
                                        kappa_W_m_K: float = 16.3) -> dict:
    """Compute rectification ratios for every plate count in a Fig.4-style CSV.

    Args:
        csv_path: temperature profile CSV with column 'plate_count_N'.
        kappa_W_m_K: thermal conductivity (default stainless steel).

    Returns:
        dict with per-N gamma1 and gamma2.
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    out = []
    for N in sorted(df["plate_count_N"].unique()):
        res = compute_inflow_outflow_fluxes(
            csv_path=csv_path,
            group_value=int(N),
            group_column="plate_count_N",
            kappa_W_m_K=kappa_W_m_K,
        )
        if "error" in res: continue
        out.append({
            "plate_count_N": int(N),
            "gamma1_inflow": res["gamma1_inflow"],
            "gamma2_outflow": res["gamma2_outflow"],
            "q_FI_W": res["q_FI_W"],
            "q_BIII_W": res["q_BIII_W"],
        })
    return {"n_configs": len(out), "results": out}


@mcp.tool()
def analytical_thermal_field(kappa_W_m_K: float, h_W_m2_K: float = 8.0,
                             T_amb_K: float = 301.4, T_hot_K: float = 330.0,
                             T_cold_K: float = 290.0, base_length_m: float = 0.10,
                             plate_height_m: float = 0.042,
                             plate_thickness_m: float = 0.002,
                             plate_width_m: float = 0.04,
                             base_thickness_m: float = 0.002,
                             plate_x_positions: list = None,
                             direction: str = "F") -> dict:
    """Solve the multi-plate analytical heat conduction problem from the paper.

    Implements the boundary conditions of Eq. 1 in the paper for an arbitrary
    number of vertical plates. Returns sampled centerline temperatures plus
    inflow/outflow heat fluxes that can be used to verify the rectification
    ratio independently of the experimental CSV.

    Args:
        kappa_W_m_K: Thermal conductivity of plate (and base, treated uniform).
        h_W_m2_K: Natural convection coefficient.
        T_amb_K, T_hot_K, T_cold_K: Boundary temperatures.
        base_length_m, plate_*_m, base_thickness_m: Geometry.
        plate_x_positions: List of x positions of vertical plates (m).
        direction: 'F' (hot at x=0) or 'B' (hot at x=base_length).
    """
    if plate_x_positions is None:
        plate_x_positions = [0.011, 0.018, 0.025, 0.032, 0.039]
    if direction == "F":
        T_at_x0, T_at_xc = T_hot_K, T_cold_K
    else:
        T_at_x0, T_at_xc = T_cold_K, T_hot_K
    P = 2 * (plate_width_m + plate_thickness_m)
    A = plate_width_m * base_thickness_m
    Ac = plate_thickness_m * plate_width_m
    m = float(np.sqrt(h_W_m2_K * P / (kappa_W_m_K * Ac)))
    N = len(plate_x_positions)
    n_segs = 2 * N + 1
    n_unk = 2 * n_segs + 2 * N
    M = np.zeros((n_unk, n_unk))
    rhs = np.zeros(n_unk)
    eq = 0
    M[eq, 1] = 1.0
    rhs[eq] = T_at_x0
    eq += 1
    M[eq, 2 * (n_segs - 1)] = base_length_m
    M[eq, 2 * (n_segs - 1) + 1] = 1.0
    rhs[eq] = T_at_xc
    eq += 1
    for i in range(N):
        a_i = plate_x_positions[i]
        b_i = a_i + plate_thickness_m
        sl, su, sr = 2 * i, 2 * i + 1, 2 * i + 2
        # T continuity at a_i
        M[eq, 2 * sl] = a_i; M[eq, 2 * sl + 1] = 1.0
        M[eq, 2 * su] = -a_i; M[eq, 2 * su + 1] = -1.0
        eq += 1
        # T continuity at b_i
        M[eq, 2 * su] = b_i; M[eq, 2 * su + 1] = 1.0
        M[eq, 2 * sr] = -b_i; M[eq, 2 * sr + 1] = -1.0
        eq += 1
        # under-plate flux equality
        M[eq, 2 * su] = 1.0
        M[eq, 2 * sr] = -1.0
        eq += 1
        # split flux at left edge
        M[eq, 2 * sl] = kappa_W_m_K * A
        M[eq, 2 * su] = -kappa_W_m_K * A
        M[eq, 2 * n_segs + 2 * i] = -kappa_W_m_K * Ac * m
        M[eq, 2 * n_segs + 2 * i + 1] = kappa_W_m_K * Ac * m
        eq += 1
        # T at z=0
        M[eq, 2 * sl] = a_i; M[eq, 2 * sl + 1] = 1.0
        M[eq, 2 * n_segs + 2 * i] = -1.0
        M[eq, 2 * n_segs + 2 * i + 1] = -1.0
        rhs[eq] = T_amb_K
        eq += 1
        # z=L boundary
        emL = float(np.exp(m * plate_height_m))
        e_mL = float(np.exp(-m * plate_height_m))
        M[eq, 2 * n_segs + 2 * i] = (h_W_m2_K + kappa_W_m_K * m) * emL
        M[eq, 2 * n_segs + 2 * i + 1] = (h_W_m2_K - kappa_W_m_K * m) * e_mL
        eq += 1
    sol = np.linalg.solve(M, rhs)
    coefs = sol[: 2 * n_segs].reshape(n_segs, 2)
    seg_edges = [0.0]
    for ai in plate_x_positions:
        seg_edges.append(ai)
        seg_edges.append(ai + plate_thickness_m)
    seg_edges.append(base_length_m)
    x_grid = np.linspace(0, base_length_m, 201)
    T_base = np.zeros_like(x_grid)
    for k, x in enumerate(x_grid):
        seg_idx = 0
        for j in range(n_segs):
            if seg_edges[j] <= x <= seg_edges[j + 1] + 1e-12:
                seg_idx = j; break
        T_base[k] = coefs[seg_idx, 0] * x + coefs[seg_idx, 1]
    q_in = -kappa_W_m_K * A * coefs[0, 0]
    q_out = -kappa_W_m_K * A * coefs[-1, 0]
    return {
        "direction": direction,
        "kappa_W_m_K": kappa_W_m_K,
        "h_W_m2_K": h_W_m2_K,
        "m_per_m": round(float(m), 4),
        "T_at_x0_K": float(T_at_x0),
        "T_at_xc_K": float(T_at_xc),
        "q_left_W_signed": round(float(q_in), 6),
        "q_right_W_signed": round(float(q_out), 6),
        "x_sample_m": [round(float(x), 5) for x in x_grid[::10]],
        "T_sample_K": [round(float(t), 4) for t in T_base[::10]],
    }


@mcp.tool()
def temperature_difference_hot_cold(csv_path: str, group_column: str,
                                     group_value: str | int | float) -> dict:
    """Return T_hot, T_cold and delta T from a temperature profile CSV slice."""
    import pandas as pd
    df = pd.read_csv(csv_path)
    df = df[(df[group_column] == group_value) & (df["direction"] == "F")]
    if df.empty:
        return {"error": "no rows"}
    x = df["x_m"].to_numpy(); T = df["T_K"].to_numpy()
    order = np.argsort(x); T = T[order]; x = x[order]
    return {
        "T_at_x0_K": round(float(T[0]), 4),
        "T_at_xc_K": round(float(T[-1]), 4),
        "delta_T_K": round(float(abs(T[0] - T[-1])), 4),
        "n_points": int(len(x)),
    }


@mcp.tool()
def plot_temperature_profiles_by_material(csv_path: str, materials_csv: str,
                                          out_path: str) -> dict:
    """Plot forward/backward centerline temperature profiles for each material.

    Args:
        csv_path: Fig.3-style CSV with material/direction/x_m/T_K columns.
        materials_csv: CSV with material->kappa mapping.
        out_path: PNG path to save figure.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import pandas as pd
    df = pd.read_csv(csv_path)
    df_M = pd.read_csv(materials_csv).sort_values("kappa_W_m_K")
    fig, axes = plt.subplots(2, 2, figsize=(10, 7), sharex=True)
    axes = axes.ravel()
    for ax, (_, row) in zip(axes, df_M.iterrows()):
        sub = df[df["material"] == row["name"]]
        for direction, color, marker in [("F", "tab:red", "o"), ("B", "tab:blue", "s")]:
            d = sub[sub["direction"] == direction].sort_values("x_m")
            ax.plot(d["x_m"] * 1000, d["T_K"], marker=marker, ms=4, lw=1.4,
                    color=color, label=f"Direction {direction}")
        ax.set_title(f"{row['name']} (kappa={row['kappa_W_m_K']:.1f} W/m/K)")
        ax.set_ylabel("T (K)")
        ax.grid(alpha=0.3)
        ax.legend(fontsize=8)
    for ax in axes[2:]:
        ax.set_xlabel("x (mm)")
    fig.suptitle("Centerline temperature profiles, forward vs backward")
    fig.tight_layout()
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": out_path, "exists": os.path.exists(out_path),
            "size_bytes": os.path.getsize(out_path) if os.path.exists(out_path) else 0}


@mcp.tool()
def plot_rectification_vs_kappa(material_results: list, out_path: str) -> dict:
    """Plot gamma1 (inflow) and gamma2 (outflow) vs material thermal conductivity.

    Args:
        material_results: list of dicts with kappa_W_m_K, gamma1_inflow, gamma2_outflow.
        out_path: PNG path.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    rs = sorted(material_results, key=lambda r: r["kappa_W_m_K"])
    k = [r["kappa_W_m_K"] for r in rs]
    g1 = [r["gamma1_inflow"] for r in rs]
    g2 = [r["gamma2_outflow"] for r in rs]
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.plot(k, g1, "o-", label="gamma1 (inflow)", lw=1.6)
    ax.plot(k, g2, "s--", label="gamma2 (outflow)", lw=1.6)
    ax.axhline(0.1, color="grey", ls=":", label="effective threshold = 0.1")
    ax.set_xscale("log")
    ax.set_xlabel("Thermal conductivity kappa (W/m/K)")
    ax.set_ylabel("Rectification ratio gamma")
    ax.set_title("Rectification ratio decreases with increasing conductivity")
    ax.grid(alpha=0.3, which="both")
    ax.legend()
    fig.tight_layout()
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": out_path, "exists": os.path.exists(out_path),
            "size_bytes": os.path.getsize(out_path) if os.path.exists(out_path) else 0}


@mcp.tool()
def plot_rectification_vs_plate_count(plate_results: list, out_path: str) -> dict:
    """Plot gamma1 and gamma2 vs vertical plate count N.

    Args:
        plate_results: list of dicts with plate_count_N, gamma1_inflow, gamma2_outflow.
        out_path: PNG path.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    rs = sorted(plate_results, key=lambda r: r["plate_count_N"])
    N = [r["plate_count_N"] for r in rs]
    g1 = [r["gamma1_inflow"] for r in rs]
    g2 = [r["gamma2_outflow"] for r in rs]
    fig, ax = plt.subplots(figsize=(6.5, 4.5))
    ax.plot(N, g1, "o-", label="gamma1 (inflow)", lw=1.8, ms=8)
    ax.plot(N, g2, "s--", label="gamma2 (outflow)", lw=1.8, ms=8)
    ax.axhline(0.1, color="grey", ls=":", label="effective threshold = 0.1")
    ax.set_xticks(N)
    ax.set_xlabel("Number of vertical plates N")
    ax.set_ylabel("Rectification ratio gamma")
    ax.set_title("Rectification ratio increases with plate count")
    ax.grid(alpha=0.3)
    ax.legend()
    fig.tight_layout()
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": out_path, "exists": os.path.exists(out_path),
            "size_bytes": os.path.getsize(out_path) if os.path.exists(out_path) else 0}


@mcp.tool()
def plot_temperature_vs_plate_count(csv_path: str, out_path: str) -> dict:
    """Plot forward/backward centerline T(x) for each plate count.

    Args:
        csv_path: Fig.4-style CSV with plate_count_N/direction/x_m/T_K.
        out_path: PNG path.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import pandas as pd
    df = pd.read_csv(csv_path)
    Ns = sorted(df["plate_count_N"].unique())
    fig, axes = plt.subplots(2, 2, figsize=(10, 7), sharex=True)
    axes = axes.ravel()
    for ax, N in zip(axes, Ns):
        sub = df[df["plate_count_N"] == N]
        for direction, color, marker in [("F", "tab:red", "o"), ("B", "tab:blue", "s")]:
            d = sub[sub["direction"] == direction].sort_values("x_m")
            ax.plot(d["x_m"] * 1000, d["T_K"], marker=marker, ms=4, lw=1.4,
                    color=color, label=f"Direction {direction}")
        ax.set_title(f"N = {int(N)} plates")
        ax.set_ylabel("T (K)")
        ax.grid(alpha=0.3)
        ax.legend(fontsize=8)
    for ax in axes[2:]:
        ax.set_xlabel("x (mm)")
    fig.suptitle("Stainless-steel centerline T(x) at varying plate count")
    fig.tight_layout()
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": out_path, "exists": os.path.exists(out_path),
            "size_bytes": os.path.getsize(out_path) if os.path.exists(out_path) else 0}


if __name__ == "__main__":
    mcp.run(transport="stdio")

# phys_tn17 — Tool Reference

## Dependencies

```bash
pip install numpy pandas scipy matplotlib mcp
```

## Database Retrieval (`database_retrieval.py`)

- **websearch**, **fetch_url**: web access placeholders
- **query_doi**, **query_openalex**, **query_pubchem**, etc.: database query stubs

## Data Processing (`data_processing.py`)

- **read_csv** / **write_csv**: CSV IO via DictReader/DictWriter
- **read_json** / **write_json**: JSON IO
- **read_excel** / **read_parquet** / **read_netcdf** / **read_shapefile** / **read_fasta**
- **pivot_long_to_wide** / **pivot_wide_to_long**, **drop_missing**, **coerce_numeric**
- **join_tables**, **groupby_aggregate**

## Domain analysis (`thermal_nonreciprocity_analysis.py`)

- **load_csv** / **load_json** / **list_unique_values**: dataset inspection
- **linear_fit**: OLS slope/intercept of T(x)
- **conductive_heat_flux**: Fourier law q = -kappa * A * dT/dx
- **rectification_ratio**: gamma = |qF - qB| / (|qF| + |qB|)
- **compute_inflow_outflow_fluxes**: extract q_FI, q_FIII, q_BI, q_BIII and gamma1, gamma2 from a temperature-profile CSV slice
- **batch_rectification_by_material**: gamma per material in Fig.3-style CSV
- **batch_rectification_by_plate_count**: gamma per N in Fig.4-style CSV
- **analytical_thermal_field**: solve the multi-plate analytical model for arbitrary kappa, h, T_amb, plate positions (forward or backward)
- **temperature_difference_hot_cold**: read T at x=0 and x=base_length

## Plotting tools (one per image answer)

- **plot_temperature_profiles_by_material**: 2x2 panel of forward/backward T(x) for the 4 materials (matches answer image #2)
- **plot_rectification_vs_kappa**: gamma1, gamma2 vs kappa with effective threshold line (matches answer image #3)
- **plot_rectification_vs_plate_count**: gamma1, gamma2 vs plate count N (matches answer image #4)
- **plot_temperature_vs_plate_count**: 2x2 panel of T(x) for N=1..4 (auxiliary)

## Running

```bash
# As MCP server (stdio)
python tools/thermal_nonreciprocity_analysis.py
```

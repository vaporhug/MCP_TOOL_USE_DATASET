from __future__ import annotations

from pathlib import Path
import re
import shutil
import subprocess
import tempfile

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def _artifact_path(filename: str) -> Path:
    path = Path(__file__).resolve().parents[1] / "artifacts" / filename
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def _default_code_dir() -> Path:
    return Path(__file__).resolve().parents[1] / "input_data" / "data" / "GoodScience-IndSims"


def _read(path: str | Path) -> str:
    return Path(path).read_text(encoding="utf-8", errors="ignore")


def simulation_code_constants(main_cpp_path: str | None = None) -> dict:
    """Parse model constants from the released C++ simulation source."""
    source = Path(main_cpp_path) if main_cpp_path else _default_code_dir() / "main.cpp"
    text = _read(source)
    constants = {}
    for name, value in re.findall(r"^#define\s+([A-Za-z][A-Za-z0-9_]*)\s+([-+0-9.eE]+)", text, flags=re.MULTILINE):
        try:
            number = float(value)
        except ValueError:
            continue
        constants[name] = int(number) if number.is_integer() else number
    aliases = {"th": "theta", "ga": "gamma", "L": "corpus_size"}
    for source_name, alias in aliases.items():
        if source_name in constants:
            constants[alias] = constants[source_name]
    return {"source": str(source), "constants": constants}


def metadist_constants(meta_dist_path: str | None = None) -> dict:
    """Parse scalar constants from the released MATLAB adaptive-dynamics script."""
    source = Path(meta_dist_path) if meta_dist_path else _default_code_dir() / "MetaDist.m"
    text = _read(source)
    constants = {}
    for name, value in re.findall(r"^\s*([A-Za-z][A-Za-z0-9_]*)\s*=\s*([^;%]+)\s*;", text, flags=re.MULTILINE):
        if name in {"xx", "yy", "zz", "rr"}:
            continue
        value = value.replace("^", "**")
        try:
            constants[name] = float(eval(value, {"__builtins__": {}}, {"log10": np.log10}))
        except Exception:
            continue
    return {"source": str(source), "constants": constants}


def _metadist_executable() -> tuple[str, list[str]] | None:
    octave = shutil.which("octave")
    if octave:
        return "octave", [octave, "--quiet", "--no-gui"]
    matlab = shutil.which("matlab")
    if matlab:
        return "matlab", [matlab, "-batch"]
    return None


def compile_and_run_released_cpp(
    code_dir: str | None = None,
    generations: int = 2000,
    ensemble_size: int = 24,
    population_size: int = 80,
    time_increment: int = 100,
    seed: int = 1,
) -> dict:
    """Compile a bounded-size copy of the released C++ model and parse its time-series output."""
    src_dir = Path(code_dir) if code_dir else _default_code_dir()
    source = src_dir / "main.cpp"
    header = src_dir / "mtrand.h"
    if not source.exists() or not header.exists():
        raise FileNotFoundError(f"Expected main.cpp and mtrand.h under {src_dir}")
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        local_source = tmp_path / "main.cpp"
        shutil.copy2(source, local_source)
        shutil.copy2(header, tmp_path / "mtrand.h")
        text = _read(local_source)
        overrides = {"G": generations, "E": ensemble_size, "N": population_size, "T0": time_increment}
        for name, value in overrides.items():
            text = re.sub(rf"^#define\s+{name}\s+[-+0-9.eE]+", f"#define {name} {int(value)}", text, flags=re.MULTILINE)
        text = re.sub(
            r"MTRand_int32\s+irand\(\(unsigned\)time\(NULL\)\);",
            f"MTRand_int32 irand({int(seed)}UL);",
            text,
        )
        text = re.sub(r"^MTRand\s+drand\s*;", f"MTRand drand({int(seed) + 1}UL);", text, flags=re.MULTILINE)
        local_source.write_text(text)
        binary = tmp_path / "main"
        compile_cmd = ["g++", "-O2", "-std=c++11", str(local_source), "-o", str(binary)]
        compiled = subprocess.run(compile_cmd, capture_output=True, text=True, check=False)
        if compiled.returncode != 0:
            raise RuntimeError(compiled.stderr)
        run = subprocess.run([str(binary)], capture_output=True, text=True, check=False)
        if run.returncode != 0:
            raise RuntimeError(run.stderr)
    rows = []
    columns = [
        "ensemble_index",
        "generation",
        "power",
        "effort_proxy",
        "false_positive_rate",
        "true_positive_rate",
        "replication_rate",
        "published_unreplicated_rate",
    ]
    for line in run.stdout.splitlines():
        if not line.strip():
            continue
        values = [float(x) for x in line.split()]
        if len(values) == len(columns):
            rows.append(dict(zip(columns, values)))
    frame = pd.DataFrame(rows)
    final = frame.loc[frame["generation"] == frame["generation"].max()].copy() if len(frame) else pd.DataFrame(columns=columns)
    return {
        "source_files": [str(source), str(header)],
        "compile_overrides": overrides,
        "seed": int(seed),
        "rows": rows,
        "final_summary": {col: float(final[col].mean()) for col in columns[2:] if len(final)},
    }


def run_released_metadist(
    meta_dist_path: str | None = None,
    n_values: int = 11,
    parameter_samples: int = 500,
    seed: int = 0,
) -> dict:
    """Run a bounded temporary copy of released MetaDist.m with Octave/MATLAB."""
    executable = _metadist_executable()
    if executable is None:
        raise RuntimeError("Neither octave nor matlab is available to execute released MetaDist.m")

    engine, command = executable
    source = Path(meta_dist_path) if meta_dist_path else _default_code_dir() / "MetaDist.m"
    if not source.exists():
        raise FileNotFoundError(source)
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        local_script = tmp_path / "MetaDist_bounded.m"
        text = _read(source)
        text = re.sub(r"^clear all\s*$", "clear all\nrand('seed', %d);" % int(seed), text, flags=re.MULTILINE)
        text = re.sub(r"^yy\s*=\s*1:100000\s*;", f"yy=1:{int(parameter_samples)};", text, flags=re.MULTILINE)
        text, replacements = re.subn(
            r"^\s*zz\s*=\s*0\s*:\s*0\.01\s*:\s*1\.0\s*;",
            f"zz=linspace(0,1,{int(n_values)});",
            text,
            flags=re.MULTILINE,
        )
        if replacements != 1:
            raise RuntimeError("Could not bound MetaDist.m replication-rate grid assignment")
        text = re.sub(
            r"plot\(zz,St1\)\s*$",
            "result=[zz(:),St1(:),St0(:),St2(:),St3(:),St4(:)];\nsave('-ascii','metadist_result.txt','result');",
            text,
            flags=re.MULTILINE,
        )
        local_script.write_text(text)
        if engine == "octave":
            run = subprocess.run(command + [str(local_script)], cwd=tmp_path, capture_output=True, text=True, check=False)
        else:
            run = subprocess.run(command + [f"cd('{tmp_path.as_posix()}'); MetaDist_bounded"], capture_output=True, text=True, check=False)
        if run.returncode != 0:
            raise RuntimeError(run.stderr or run.stdout)
        result_path = tmp_path / "metadist_result.txt"
        if not result_path.exists():
            raise RuntimeError("Released MetaDist.m did not write metadist_result.txt")
        frame = pd.read_csv(
            result_path,
            sep=r"\s+",
            header=None,
            names=["replication_rate", "St1", "St0", "St2", "St3", "St4"],
        )
    return {
        "source_file": str(source),
        "execution_engine": engine,
        "bounded_parameters": {"n_values": int(n_values), "parameter_samples": int(parameter_samples), "seed": int(seed)},
        "rows": [
            {"replication_rate": float(row.replication_rate), "good_science_support_fraction": float(row.St1)}
            for row in frame.itertuples(index=False)
        ],
    }


def translated_metadist_validation_sweep(
    meta_dist_path: str | None = None,
    n_values: int = 11,
    parameter_samples: int = 500,
    seed: int = 0,
) -> dict:
    """Python translation of MetaDist.m used only when no MATLAB-family runner exists."""
    rng = np.random.default_rng(seed)
    constants = metadist_constants(meta_dist_path)["constants"]
    zz = np.linspace(0.0, 1.0, n_values)
    rows = []
    xx = np.arange(0.0, 1.0, 0.01)
    h = constants.get("h", 0.01)
    V = constants.get("V", 1.0)
    Bn1 = constants.get("Bn1", 1.0)
    b0 = constants.get("b0", 0.01)
    eta = constants.get("eta", 1.0 / np.log10(100000))
    Br = constants.get("Br", 0.2)
    Bo = constants.get("Bo", 0.1)
    Co = constants.get("Co", 100.0)
    l = constants.get("l", 10.0)
    for rr in zz:
        supports = 0
        for _ in range(parameter_samples):
            Bn2 = Bn1 + rng.random()
            b0s = rng.random()
            b1s = b0s + (1.0 - b0s) * rng.random()
            theta = 1.0 / (0.5 * rng.random())
            gamma = 1.0 / (1.0 - 0.5 * rng.random())
            Dwe = []
            for x in xx[:-1]:
                ee = 1.0 / (1.0 - x)
                e2 = ee + h
                Pt = (b0s + b1s * (ee - 1.0)) / ee
                Pt2 = (b0s + b1s * (e2 - 1.0)) / e2
                Ppt = (V / gamma) * (gamma * ee / (1.0 + gamma * (ee - 1.0)))
                Ppt2 = (V / gamma) * (gamma * e2 / (1.0 + gamma * (e2 - 1.0)))
                Ppf = (V / theta) * ((1.0 + (theta - 1.0) * ee) / (1.0 + (theta - 1.0) * (ee - 1.0)))
                Ppf2 = (V / theta) * ((1.0 + (theta - 1.0) * e2) / (1.0 + (theta - 1.0) * (e2 - 1.0)))
                phi = (1.0 - eta * np.log10(ee)) * rr
                Bn_mut = Bn1 * (1.0 + (Bn2 / Bn1 - 1.0) * b0 / (Pt2 * e2))
                Bn_res = Bn1 * (1.0 + (Bn2 / Bn1 - 1.0) * b0 / (Pt * ee))
                we = (1.0 - eta * np.log10(e2)) * (1.0 - rr) * (
                    Pt2 * Ppt2 * (Bn_mut + (phi / (2.0 * l)) * (Bo * Ppt - Co * (1.0 - Ppt)))
                    + (1.0 - Pt2) * Ppf2 * (Bn_mut + (phi / (2.0 * l)) * (Bo * Ppf - Co * (1.0 - Ppf)))
                ) + (1.0 - eta * np.log10(e2)) * rr * Br
                w = (1.0 - eta * np.log10(ee)) * (1.0 - rr) * (
                    Pt * Ppt * (Bn_res + (phi / (2.0 * l)) * (Bo * Ppt - Co * (1.0 - Ppt)))
                    + (1.0 - Pt) * Ppf * (Bn_res + (phi / (2.0 * l)) * (Bo * Ppf - Co * (1.0 - Ppf)))
                ) + (1.0 - eta * np.log10(ee)) * rr * Br
                Dwe.append(we - w)
            Dwe = np.asarray(Dwe)
            has_stable_crossing = bool(np.any((Dwe[:-1] >= 0) & (Dwe[1:] < 0)))
            endpoint_supported = bool((not has_stable_crossing) and Dwe[-1] > 0)
            if has_stable_crossing or endpoint_supported:
                supports += 1
        rows.append({"replication_rate": float(rr), "good_science_support_fraction": float(supports / parameter_samples)})
    return {
        "source_file": str(Path(meta_dist_path) if meta_dist_path else _default_code_dir() / "MetaDist.m"),
        "execution_engine": "python_translation_validation_fallback",
        "bounded_parameters": {"n_values": int(n_values), "parameter_samples": int(parameter_samples), "seed": int(seed)},
        "rows": rows,
    }


def replication_rate_sweep(
    meta_dist_path: str | None = None,
    n_values: int = 11,
    parameter_samples: int = 500,
    seed: int = 0,
    allow_translated_fallback: bool = True,
) -> dict:
    """Prefer executing released MetaDist.m; optionally fall back when Octave/MATLAB is absent."""
    try:
        return run_released_metadist(meta_dist_path, n_values=n_values, parameter_samples=parameter_samples, seed=seed)
    except RuntimeError as exc:
        if not allow_translated_fallback or "Neither octave nor matlab" not in str(exc):
            raise
        result = translated_metadist_validation_sweep(
            meta_dist_path=meta_dist_path,
            n_values=n_values,
            parameter_samples=parameter_samples,
            seed=seed,
        )
        result["fallback_reason"] = str(exc)
        return result


def plot_replication_rate_sweep(meta_dist_path: str | None = None, output_filename: str = "replication_rate_sweep.png") -> dict:
    result = replication_rate_sweep(meta_dist_path=meta_dist_path, n_values=11, parameter_samples=300, seed=0)
    rows = result["rows"]
    output_path = _artifact_path(output_filename)
    plt.figure(figsize=(6.5, 4))
    plt.plot([r["replication_rate"] for r in rows], [r["good_science_support_fraction"] for r in rows], marker="o")
    plt.xlabel("Replication rate")
    plt.ylabel("Fraction with good-science equilibrium")
    plt.title("Replication stabilizes good-science equilibria")
    plt.tight_layout()
    plt.savefig(output_path, dpi=200)
    plt.close()
    return {"path": str(output_path), "execution_engine": result.get("execution_engine"), "rows": rows}


def aggregate_cpp_timeseries(rows: list[dict]) -> dict:
    frame = pd.DataFrame(rows)
    if frame.empty:
        return {"rows": []}
    value_cols = [
        "power",
        "effort_proxy",
        "false_positive_rate",
        "true_positive_rate",
        "replication_rate",
        "published_unreplicated_rate",
    ]
    grouped = frame.groupby("generation", as_index=False)[value_cols].mean()
    return {"rows": grouped.to_dict("records"), "aggregation": "mean_by_generation_across_ensembles"}


def _plot_individual_based_timeseries_from_result(result: dict, output_filename: str) -> dict:
    aggregate = aggregate_cpp_timeseries(result["rows"])
    rows = aggregate["rows"]
    output_path = _artifact_path(output_filename)
    plt.figure(figsize=(7, 4.5))
    plt.plot([r["generation"] for r in rows], [r["effort_proxy"] for r in rows], label="Effort proxy")
    plt.plot([r["generation"] for r in rows], [r["replication_rate"] for r in rows], label="Replication")
    plt.plot([r["generation"] for r in rows], [r["true_positive_rate"] for r in rows], label="True-positive rate")
    plt.xlabel("Generation")
    plt.ylabel("Population mean")
    plt.title("Individual-based evolution of good-science traits")
    plt.legend()
    plt.tight_layout()
    plt.savefig(output_path, dpi=200)
    plt.close()
    return {"path": str(output_path), "aggregation": aggregate["aggregation"], "seed": result.get("seed"), "final_summary": result["final_summary"]}


def _plot_true_false_positive_tradeoff_from_result(result: dict, output_filename: str) -> dict:
    aggregate = aggregate_cpp_timeseries(result["rows"])
    rows = aggregate["rows"]
    output = _artifact_path(output_filename)
    plt.figure(figsize=(7, 4.5))
    plt.plot([r["generation"] for r in rows], [r["true_positive_rate"] for r in rows], label="True-positive rate")
    plt.plot([r["generation"] for r in rows], [r["false_positive_rate"] for r in rows], label="False-positive rate")
    plt.xlabel("Generation")
    plt.ylabel("Population mean rate")
    plt.title("Simulation-derived true/false-positive tradeoff")
    plt.legend()
    plt.tight_layout()
    plt.savefig(output, dpi=200)
    plt.close()
    return {"path": str(output), "aggregation": aggregate["aggregation"], "seed": result.get("seed"), "final_summary": result["final_summary"]}


def plot_individual_based_timeseries(code_dir: str | None = None, output_filename: str = "good_science_timeseries.png", seed: int = 1) -> dict:
    result = compile_and_run_released_cpp(
        code_dir=code_dir,
        generations=2000,
        time_increment=100,
        population_size=80,
        ensemble_size=24,
        seed=seed,
    )
    return _plot_individual_based_timeseries_from_result(result, output_filename)


def plot_true_false_positive_tradeoff(code_dir: str | None = None, output_filename: str = "true_false_positive_tradeoff.png", seed: int = 1) -> dict:
    result = compile_and_run_released_cpp(
        code_dir=code_dir,
        generations=2000,
        time_increment=100,
        population_size=80,
        ensemble_size=24,
        seed=seed,
    )
    return _plot_true_false_positive_tradeoff_from_result(result, output_filename)


def plot_cpp_simulation_evidence_pair(
    code_dir: str | None = None,
    timeseries_output_filename: str = "good_science_timeseries.png",
    tradeoff_output_filename: str = "true_false_positive_tradeoff.png",
    seed: int = 1,
) -> dict:
    """Generate both C++ simulation artifacts from one shared bounded simulation run."""
    result = compile_and_run_released_cpp(
        code_dir=code_dir,
        generations=2000,
        time_increment=100,
        population_size=80,
        ensemble_size=24,
        seed=seed,
    )
    return {
        "seed": int(seed),
        "timeseries": _plot_individual_based_timeseries_from_result(result, timeseries_output_filename),
        "tradeoff": _plot_true_false_positive_tradeoff_from_result(result, tradeoff_output_filename),
        "final_summary": result["final_summary"],
    }

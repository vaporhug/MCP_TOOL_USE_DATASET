clear all
close all


% Calculate the proportion of cases where a good science equilibrium is
% supported. Note here we are in effect calculating the selection gradient using the Euler
% method with increment h

h=0.01; %euler method increment
Bn1=1; %non-flashy hyothesis benefit
Bn2=2; %flashy hypothesis benefit
Br=0.2; %benefit from producing a replication
Bo=0.1; %benefit from being replicated
Co=100; %cost of failing replication
l=10; %relative corpus size
eta=1.0/log10(100000); %rate of research production
theta=25; %as defined in main text
gamma=1.1;
V=1;
b0=0.01; %probability of a weak hypothesis being true
b1=0.25; %probability of a strong hypothesis being true

xx=0:0.01:1;
yy=1:100000;

zz=0:0.01:1.0;

rr=0.0; %replication rate



for k=1:length(zz)
    
    %this is the parameter we are varying exogenously (typically replication
    %rate "r" or level of technical advancement "theta"
    
    rr=zz(k);
    %theta=100*(zz(k));
    
  
fn=zeros(length(xx));

for j=1:length(yy)
    
    %these are the parameters we want to vary
    
    Bn2=Bn1+rand;
    %Co=100*rand;
    %Br=rand;
    %Bo=rand;
    %eta=rand;
    b0=rand;
    b1=b0+(1-b0)*rand;
    %l=10^(4*rand);
    %gamma=1+rand;
    %theta=gamma+(100-gamma)*rand;
    theta=1/(0.5*rand);
    gamma=1/(1-0.5*rand);
    %rr=1.0*rand;
  
    for i=1:length(xx)-1
    
        
        %population background effort rate
        ee=1/(1-xx(i));
        
        
        %mutant effort rate
        e2=ee+h;
        
        
        %probability selected hypothesis s true (background and mutant)
        Pt=(b0+b1*(ee-1))/ee;
        Pt2=(b0+b1*(e2-1))/e2;
        
   
        %rates of positive results
        Ppt=(V/gamma)*(gamma*ee/(1+gamma*(ee-1)));
        Ppt2=(V/gamma)*(gamma*e2/(1+gamma*(e2-1)));
        
        Ppf=(V/theta)*((1+(theta-1)*ee)/(1+(theta-1)*(ee-1)));
        Ppf2=(V/theta)*((1+(theta-1)*e2)/(1+(theta-1)*(e2-1)));
        
        
        %rate of poroduction of novel research
        phi=(1-eta*log10(ee))*rr;
        
        %benefit from novel research
        Bn=Bn1*(1+(Bn2/Bn1-1)*b0/(Pt2*e2));
        
        %expected fitness of with and without mutation
        
        we(i)=(1-eta*log10(e2))*(1-rr)*(Pt2*Ppt2*(Bn+(phi/(2*l))*(Bo*Ppt-Co*(1-Ppt)))+(1-Pt2)*Ppf2*(Bn+(phi/(2*l))*(Bo*Ppf-Co*(1-Ppf))))+(1-eta*log10(e2))*rr*Br;
        
        Bn=Bn1*(1+(Bn2/Bn1-1)*b0/(Pt*ee));
        
        w(i)=(1-eta*log10(ee))*(1-rr)*(Pt*Ppt*(Bn+(phi/(2*l))*(Bo*Ppt-Co*(1-Ppt)))+(1-Pt)*Ppf*(Bn+(phi/(2*l))*(Bo*Ppf-Co*(1-Ppf))))+(1-eta*log10(ee))*rr*Br;
        
        if w(i)-we(i)>0
            
            fn(i)=1;
            
        elseif w(i)-we(i)<0
            
            fn(i)=2;
            
    
        else
            
            fn(i)=0;
            
        end
        
        Dwe(i)=we(i)-w(i);
        
    end

es=1/0;
es2=1/0;

npr(j)=0;
nmr(j)=0;
for i=1:length(xx)-2
  
        
        if Dwe(i)>=0 && Dwe(i+1)<0
            
            
            es=xx(i);
            npr(j)=npr(j)+1;
            
            
            
        elseif Dwe(i)<=0 && Dwe(i+1)>0    
            
           
            es2=xx(i);
            nmr(j)=nmr(j)+1;
            
            
        end
        
        
    
end

if isinf(es)==1 && Dwe(length(Dwe)-1)>0
    
    es=xx(length(Dwe)-1);
    npr(j)=npr(j)+1;
    
end

%if isinf(es2)==1 && Dwe(1)<=0
    
%    es2=xx(1);
%    npr(j)=npr(j)+1;
    
%end


esR(j)=es;

es=1/(1-es);
es2=1/(1-es2);


VsR(j)=(V/gamma)*(gamma*es/(1+gamma*(es-1)));
es2R(j)=es2;
DesR(j)=(es-1)/es-(es2-1)/es2;
DVsR(j)=(V/theta)*((1+(theta-1)*es)/(1+(theta-1)*(es-1)));

end

esZ(k)=es;
lr(k)=length(find(isinf(esR)==0 ))/length(DesR);

%proportion of parameter choices with 0, 1, 2 etc stable non-zero
%stable equilibria (good science)

St0(k)=length(find(npr==0 ))/length(DesR);
St1(k)=length(find(npr==1 ))/length(DesR);
St2(k)=length(find(npr==2 ))/length(DesR);
St3(k)=length(find(npr==3 ))/length(DesR);
St4(k)=length(find(npr==4 ))/length(DesR);



%proportion of parameter choices with 0, 1, 2 etc stable non-zero
%unstable equilibria (good science)

Sn0(k)=length(find(nmr==0 ))/length(DesR);
Sn1(k)=length(find(nmr==1 ))/length(DesR);
Sn2(k)=length(find(nmr==2 ))/length(DesR);
Sn3(k)=length(find(nmr==3 ))/length(DesR);
Sn4(k)=length(find(nmr==4 ))/length(DesR);



Dem(k)=mean(DesR(find(isnan(DesR)==0 )));
Dev(k)=std(DesR(find(isinf(DesR)==0 )));

Tem(k)=mean(VsR(find(isinf(DesR)==0 )));
Tev(k)=std(VsR(find(isinf(DesR)==0 )));

Fem(k)=mean(DVsR(find(isinf(DesR)==0 )));
Fev(k)=std(DVsR(find(isinf(DesR)==0 )));

end

%Plot the proportion of parameters with a good science equilibrium as a
%function of zz 9in this case replication rate)
plot(zz,St1)

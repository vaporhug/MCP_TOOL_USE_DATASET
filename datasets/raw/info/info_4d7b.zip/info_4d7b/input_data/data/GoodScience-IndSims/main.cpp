#include <iostream>
#include <cstdlib>
#include <cmath>
#include <fstream>
#include <cfloat>
#include <vector>
#include <cstdio>
#include "mtrand.h"


using namespace std;

//here we provide code for individual based simulations used in Figure 2-3 of the main text

unsigned long MTRand_int32::state[n] = {0x0UL};
int MTRand_int32::p = 0;
bool MTRand_int32::init = false;

void MTRand_int32::gen_state() { // generate new state vector
    for (int i = 0; i < (n - m); ++i)
        state[i] = state[i + m] ^ twiddle(state[i], state[i + 1]);
    for (int i = n - m; i < (n - 1); ++i)
        state[i] = state[i + m - n] ^ twiddle(state[i], state[i + 1]);
    state[n - 1] = state[m - 1] ^ twiddle(state[n - 1], state[0]);
    p = 0; // reset position
}

void MTRand_int32::seed(unsigned long s) {  // init by 32 bit seed
    state[0] = s & 0xFFFFFFFFUL; // for > 32 bit machines
    for (int i = 1; i < n; ++i) {
        state[i] = 1812433253UL * (state[i - 1] ^ (state[i - 1] >> 30)) + i;
        // see Knuth TAOCP Vol2. 3rd Ed. P.106 for multiplier
        // in the previous versions, MSBs of the seed affect only MSBs of the array state
        // 2002/01/09 modified by Makoto Matsumoto
        state[i] &= 0xFFFFFFFFUL; // for > 32 bit machines
    }
    p = n; // force gen_state() to be called for next random number
}

#define G 50000 // number of generations
#define T0 100  // time increment
#define N 100 // population size
#define b0 0.01 // probability of weak hypothesis being true
#define b1 0.25 //probability of strong hypothesis being true
#define eta 0.2 // rate of producing novel work
#define Vn 1.0 // benefit for novel research
#define Vrp 0.2 // benefit for producing replication (positive result)
#define Vrn 0.2 // benefit for producing replication (negative result)
#define Vop 0.1 // benefit for being replicatied
#define Von -100.0 // benefit for faliure to be replicated
#define mu 0.01 // mutation rate (effort)
#define mur 0.01 // mutation rate (replication rate)
#define mup 0.01 // mutation rate efficacy
#define th 25.0 //theta as defined in main text
#define ga 1.1 // gamma as defined in main text
#define E 10000 //ensemble size
#define ep 1.0e-6 // error rate
#define sig 10.0 // selection strength
#define L 100000 // corpus size

double Eff[N];//effort of each individual
double Eff2[N]; //rescaled effort of each individual
double Po[N]; // efficacy of each individual
double Fit[N]; // fitness fo each individual
int ii;
int jj;
int Lif[N]; // lab age
int nTr[N]; // number of true published, unreplicated studies for each lab
int nTf[N]; // number of false published, unreplicated studies for each lab
double Rep[N]; // number of replicates for each lab
double Ft; // population average fitness
double rr; // replication rate
//average quantities
double Eav[G/T0];
double Pav[G/T0];
double aav[G/T0];
double ttv[G/T0];
double rrv[G/T0];
double Fav[G/T0];
double np;
double npC[N];//cumulative distribution of unreplicated studies

double be;

MTRand_int32 irand((unsigned)time(NULL)); // 32-bit int generator
MTRand drand;

double factorial (double a)
{
    if (a > 1)
        return (a * factorial (a-1));
    else
        return (1);
}

double nchoosek (double NN, double kk)
{
    if (kk > 0)
        return ((NN/kk) * nchoosek(NN-1, kk-1));
    else
        return (1);
}

vector <int> Init(N,0);
vector < vector <int> > MM(N,Init);



int main(void)
{
    
    //initialize ensemble
    
    for(int ee=0;ee<E;ee++)
    {
        
        for(int i=0;i<G/T0;i++)
        {
           Eav[i]=0.0;
           Pav[i]=0.0;
           aav[i]=0.0;
           ttv[i]=0.0;
           rrv[i]=0.0;
           Fav[i]=0.0;
        }
   
        Eff2[0]=drand();
    
    for(int i=0;i<N;i++)
    {
        Eff2[i]=Eff2[0];
        Eff[i]=1.0/Eff2[i];
        Po[i]=0.8;
        Fit[i]=0.0;
        Lif[i]=0;
        Rep[i]=0.0;
        nTr[i]=0;
        nTf[i]=0;
    }
    
    
    //simulate evolutionary dynamics for one population run
    for(int g=0;g<G;g++)
    {
        
        
        for(int j=0;j<N;j++)
        {
            Ft=0.0;
            np=0.0;
            for(int k=0;k<N;k++)
            {
                Ft=Ft+Fit[k]/double(Lif[k]);
                np=np+(nTr[k]+nTf[k])/double(N);
                npC[k]=np;
            }
        
        for(int i=0;i<N;i++)
        {
            Lif[i]=Lif[i]+1;
            if(drand()<1.0-eta*log10(Eff[i]))
            {
            if(drand()<Rep[i])
            {
                
                    Fit[i]=Fit[i]+Vrp;
               
                    if(drand()<np*N/double(L))
                    {
                
                    rr=drand()*np;
                    
                    ii=0;
                    
                    npC[ii]=(nTr[ii]+nTf[ii])/double(N);
                  
                    while(rr>npC[ii])
                    {
                        ii=ii+1;
                        npC[ii]=npC[ii-1]+(nTr[ii]+nTf[ii])/double(N);
                        
                    }
                    
                    be=nTr[ii]/double(nTr[ii]+nTf[ii]);

                    
                    if(drand()<be)
                    {
                        if(drand()<Po[i]*Eff[i]/(1.0+ga*(Eff[i]-1.0)))
                        {
                            //Fit[i]=Fit[i]+Vrp;
                            Fit[ii]=Fit[ii]+Vop;
                           // nTr[i]=nTr[i]+1;
                            nTr[ii]=nTr[ii]-1;
                            np=np-1.0/double(N);
                        }
                        else
                        {
                            //Fit[i]=Fit[i]+Vrn;
                            Fit[ii]=Fit[ii]+Von;
                           // nTf[i]=nTf[i]+1;
                            nTr[ii]=nTr[ii]-1;
                            np=np-1.0/double(N);
                        }
                        
                    }
                    else
                    {
                        if(drand()<Po[i]*(1.0+(th-1.0)*Eff[i])/(th+(th)*(th-Po[i])*(Eff[i]-1.0)))
                        {
                           // Fit[i]=Fit[i]+Vrp;
                            Fit[ii]=Fit[ii]+Vop;
                          //  nTf[i]=nTf[i]+1;
                            nTf[ii]=nTf[ii]-1;
                            np=np-1.0/double(N);
                        }
                        else
                        {
                           // Fit[i]=Fit[i]+Vrn;
                            Fit[ii]=Fit[ii]+Von;
                           // nTr[i]=nTr[i]+1;
                            nTf[ii]=nTf[ii]-1;
                            np=np-1.0/double(N);
                        }
                    }
               
                
                    }
                    
                
                
            }
            else
            {
            if(drand()<(b0+(Eff[i]-1.0)*b1)/(1.0+(Eff[i]-1.0)))
            {
                if(drand()<Po[i]*Eff[i]/(1.0+ga*(Eff[i]-1.0)))
                {
                    Fit[i]=Fit[i]+Vn;
                    nTr[i]=nTr[i]+1;
                    np=np+1.0/double(N);
                }
                
            }
            else
            {
                if(drand()<Po[i]*(1.0+(th-1.0)*Eff[i])/(th+(th)*(th-Po[i])*(Eff[i]-1.0)))
                {
                    Fit[i]=Fit[i]+Vn;
                    nTf[i]=nTf[i]+1;
                    np=np+1.0/double(N);
                }
            }
            }
            }
            
            
         
        }
            
            
            
            
            if(g%T0==0)
            {
            Eav[g/T0]=Eav[g/T0]+(1.0-Eff2[j])/double(N);
            Pav[g/T0]=Pav[g/T0]+Po[j]/double(N);
            aav[g/T0]=aav[g/T0]+(Po[j]*(1.0+(th-1.0)*Eff[j])/(th+(th)*(th-Po[j])*(Eff[j]-1.0)))/double(N);
            ttv[g/T0]=ttv[g/T0]+(Po[j]*Eff[j]/(1.0+ga*(Eff[j]-1.0)))/double(N);
            rrv[g/T0]=rrv[g/T0]+Rep[j]/double(N);
            Fav[g/T0]=Fav[g/T0]+np*N/double(L);
                
             
            }
        
        
     
        
        ii=irand()%N;
        jj=irand()%N;
        
        if(drand()<1.0/(1.0+exp(-sig*(Fit[ii]/Lif[ii]-Fit[jj]/Lif[jj]))))
        {
        
        Fit[jj]=0.0;
        Po[jj]=Po[ii];
        Eff[jj]=Eff[ii];
        Eff2[jj]=Eff2[ii];
        Rep[jj]=Rep[ii];
        Lif[jj]=0;
        np=np-(nTr[jj]+nTf[jj])/double(N);
        nTr[jj]=0;
        nTf[jj]=0;
        
        if(drand()<mu)
        {
            Eff2[jj]=Eff2[jj]+0.02*(irand()%2-0.5);
            
            if(Eff2[jj]<=0.0)
            {
                Eff2[jj]=ep;
            }
            if(Eff2[jj]>1.0)
            {
                Eff2[jj]=1.0;
            }
            
            Eff[jj]=1.0/Eff2[jj];
        }
        
        if(drand()<mup)
        {
            Po[jj]=Po[jj]+0.02*(irand()%2-0.5);
            
            if(Po[jj]<0.0)
            {
                Po[jj]=0.0;
            }
            
            if(Po[jj]>1.0)
            {
                Po[jj]=1.0;
            }
        }
            
            if(drand()<mur)
            {
                Rep[jj]=Rep[jj]+0.02*(irand()%2-0.5);
                
                if(Rep[jj]<=0.0)
                {
                    Rep[jj]=0.0;
                }
                if(Rep[jj]>1.0)
                {
                    Rep[jj]=1.0;
                }
                
            }
            
        }
            
        }
        
        
        //output time series
        if(g%T0==0)
        {
        cout<<ee<<'\t'<<g<<'\t'<<Pav[g/T0]/double(1)<<'\t'<<Eav[g/T0]/double(1)<<'\t'<<aav[g/T0]/double(1)<<'\t'<<ttv[g/T0]/double(1)<<'\t'<<rrv[g/T0]/double(1)<<'\t'<<Fav[g/T0]/double(1)<<'\n';
        }
    }
    }
    
    
    return 0;
}














from __future__ import annotations
from pathlib import Path
import math
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from data_processing import data_root, list_files, read_table, workbook_sheets, numeric_columns, tidy_numeric_frame, robust_zscore, load_workbook_long
from database_retrieval import inventory, public_repository_links

ARTIFACT_DIR = Path(__file__).resolve().parents[1] / "artifacts"
ARTIFACT_DIR.mkdir(exist_ok=True)

def source_inventory(root: str | Path | None = None) -> dict:
    files = list_files(root or data_root())
    sizes = {str(Path(f).relative_to(Path(f).parents[2])) if len(Path(f).parents)>2 else f: Path(f).stat().st_size for f in files[:200]}
    return {"n_files": len(files), "extensions": sorted({Path(f).suffix.lower() for f in files}), "files": files[:200], "sizes": sizes, "repositories": public_repository_links().get("repositories", [])}

def source_workbook_summary(path: str | Path | None = None) -> dict:
    files = list_files(data_root())
    candidates=[f for f in files if Path(f).suffix.lower() in [".xlsx", ".xls"]]
    if path is None and not candidates:
        return {"n_workbooks": 0, "inventory": source_inventory()}
    path = path or candidates[0]
    rows=[]
    for sh in workbook_sheets(path)[:20]:
        try:
            df=read_table(path, sheet_name=sh)
            nums=numeric_columns(df)
            rows.append({"sheet": sh, "rows": int(len(df)), "columns": [str(c) for c in df.columns[:20]], "numeric_columns": [str(c) for c in nums[:20]]})
        except Exception as e:
            rows.append({"sheet": sh, "error": str(e)})
    return {"workbook": str(path), "sheets": rows}

def numeric_signal_summary(path: str | Path | None = None) -> dict:
    if path is None:
        df = pd.DataFrame()
        for candidate in list_files(data_root()):
            if Path(candidate).suffix.lower() not in [".csv", ".tsv", ".txt", ".dat", ".xlsx", ".xls"]:
                continue
            try:
                df = tidy_numeric_frame(candidate)
            except Exception:
                continue
            if not df.empty and numeric_columns(df):
                break
    else:
        df=tidy_numeric_frame(path)
    if df.empty:
        return {"note": "no tabular file found", "inventory": source_inventory()}
    nums=numeric_columns(df)
    stats={}
    for c in nums[:30]:
        s=pd.to_numeric(df[c], errors="coerce").dropna()
        if len(s):
            stats[str(c)]={"n": int(len(s)), "mean": float(s.mean()), "median": float(s.median()), "std": float(s.std(ddof=1)) if len(s)>1 else 0.0, "min": float(s.min()), "max": float(s.max())}
    return {"rows": int(len(df)), "columns": [str(c) for c in df.columns], "numeric_stats": stats}

def compare_numeric_groups(path: str | Path, group_col: str, value_col: str) -> dict:
    df=tidy_numeric_frame(path)
    df[value_col]=pd.to_numeric(df[value_col], errors="coerce")
    g=df.dropna(subset=[value_col]).groupby(group_col)[value_col]
    return {"groups": [{"group": str(k), "n": int(v.count()), "mean": float(v.mean()), "median": float(v.median()), "std": float(v.std(ddof=1)) if v.count()>1 else 0.0} for k,v in g]}

def bootstrap_difference(path: str | Path, group_col: str, value_col: str, group_a: str, group_b: str, n_boot: int = 2000, seed: int = 7) -> dict:
    df=tidy_numeric_frame(path)
    rng=np.random.default_rng(seed)
    a=pd.to_numeric(df.loc[df[group_col].astype(str)==str(group_a), value_col], errors="coerce").dropna().to_numpy()
    b=pd.to_numeric(df.loc[df[group_col].astype(str)==str(group_b), value_col], errors="coerce").dropna().to_numpy()
    if len(a)==0 or len(b)==0:
        return {"error": "empty group"}
    diffs=np.array([rng.choice(a, len(a), replace=True).mean()-rng.choice(b, len(b), replace=True).mean() for _ in range(n_boot)])
    return {"group_a": str(group_a), "group_b": str(group_b), "observed_mean_difference": float(a.mean()-b.mean()), "ci95": [float(np.quantile(diffs, .025)), float(np.quantile(diffs, .975))]}

def permutation_correlation(x, y, n_perm: int = 2000, seed: int = 7) -> dict:
    x=np.asarray(x, dtype=float); y=np.asarray(y, dtype=float)
    ok=np.isfinite(x)&np.isfinite(y); x=x[ok]; y=y[ok]
    if len(x)<3: return {"error":"not enough observations"}
    obs=float(np.corrcoef(x,y)[0,1])
    rng=np.random.default_rng(seed)
    null=np.array([np.corrcoef(x, rng.permutation(y))[0,1] for _ in range(n_perm)])
    p=float((np.sum(np.abs(null)>=abs(obs))+1)/(n_perm+1))
    return {"r": obs, "p_perm": p, "n": int(len(x))}

def plot_numeric_overview(output_filename: str = "numeric_overview.png") -> dict:
    summary=numeric_signal_summary(); stats=summary.get("numeric_stats", {})
    names=list(stats)[:10]; vals=[stats[n]["mean"] for n in names]
    if not names:
        names=["files"]; vals=[source_inventory()["n_files"]]
    out=ARTIFACT_DIR/output_filename
    fig, ax=plt.subplots(figsize=(8,4.8)); ax.bar(range(len(names)), vals, color="#4c78a8")
    ax.set_xticks(range(len(names))); ax.set_xticklabels(names, rotation=35, ha="right", fontsize=8)
    ax.set_ylabel("Mean value / count"); ax.set_title("Local public-data numeric overview")
    fig.tight_layout(); fig.savefig(out,dpi=180); plt.close(fig)
    return {"path": str(out), "plotted": names}

def plot_file_inventory(output_filename: str = "file_inventory.png") -> dict:
    inv=source_inventory(); counts={}
    for f in inv["files"]:
        ext=Path(f).suffix.lower() or "no_ext"; counts[ext]=counts.get(ext,0)+1
    out=ARTIFACT_DIR/output_filename
    fig, ax=plt.subplots(figsize=(6,4)); ax.bar(list(counts), list(counts.values()), color="#f58518")
    ax.set_title("Public workflow file inventory"); ax.set_ylabel("Files")
    fig.tight_layout(); fig.savefig(out,dpi=180); plt.close(fig)
    return {"path": str(out), "counts": counts}

def normalized_impact_model(path: str | Path | None = None, outcome_col: str | None = None, predictors: list[str] | None = None) -> dict:
    df=tidy_numeric_frame(path); nums=numeric_columns(df)
    if len(nums)<2: return {"error":"need outcome and predictors"}
    ycol=outcome_col or nums[0]; xcols=predictors or nums[1:5]
    mat=df[[ycol]+xcols].apply(pd.to_numeric, errors="coerce").dropna()
    if len(mat)<len(xcols)+2: return {"error":"not enough complete rows"}
    X=mat[xcols].to_numpy(dtype=float); y=mat[ycol].to_numpy(dtype=float)
    X=(X-X.mean(0))/(X.std(0, ddof=1)+1e-12); y=(y-y.mean())/(y.std(ddof=1)+1e-12)
    beta=np.linalg.lstsq(np.c_[np.ones(len(X)),X], y, rcond=None)[0]
    pred=np.c_[np.ones(len(X)),X]@beta
    r2=1-float(np.sum((y-pred)**2)/np.sum((y-y.mean())**2))
    return {"outcome":str(ycol),"predictors":[str(c) for c in xcols],"standardized_coefficients":[float(b) for b in beta[1:]],"r2":r2,"n":int(len(mat))}

def stratified_rate_contrast(path: str | Path | None = None, group_col: str | None = None, binary_col: str | None = None) -> dict:
    df=tidy_numeric_frame(path); nums=numeric_columns(df); cats=[c for c in df.columns if c not in nums]
    if not cats or not nums: return {"error":"need group and numeric/binary column"}
    gcol=group_col or cats[0]; bcol=binary_col or nums[0]
    tmp=df[[gcol,bcol]].copy(); tmp[bcol]=pd.to_numeric(tmp[bcol], errors="coerce")
    out=[]
    for k,v in tmp.dropna().groupby(gcol)[bcol]:
        out.append({"group":str(k),"n":int(v.count()),"mean_or_rate":float(v.mean())})
    return {"group_col":str(gcol),"metric_col":str(bcol),"groups":out}

def novelty_or_access_gradient(path: str | Path | None = None, exposure_col: str | None = None, impact_col: str | None = None, bins: int = 5) -> dict:
    df=tidy_numeric_frame(path); nums=numeric_columns(df)
    if len(nums)<2: return {"error":"need exposure and impact columns"}
    x=exposure_col or nums[0]; y=impact_col or nums[1]
    tmp=df[[x,y]].apply(pd.to_numeric, errors="coerce").dropna()
    tmp["bin"]=pd.qcut(tmp[x], q=min(bins, tmp[x].nunique()), duplicates="drop")
    g=tmp.groupby("bin", observed=True)[y]
    return {"exposure":str(x),"impact":str(y),"bins":[{"bin":str(k),"n":int(v.count()),"mean_impact":float(v.mean())} for k,v in g]}



def package_smoke_test() -> dict:
    plot_numeric_overview(f"info_7c5e_numeric_overview.png")
    plot_file_inventory(f"info_7c5e_file_inventory.png")
    return {"inventory": source_inventory(), "numeric": numeric_signal_summary(), "workbook": source_workbook_summary()}


def hdt_resource_scaling(n_qubits: int, n_layers: int, ancilla_count: int, gate_factor: float = 1.0) -> dict:
    """Compute reusable HDT resource-scaling proxies from paper-supported benchmark points provided by caller."""
    n = max(int(n_qubits), 1)
    l = max(int(n_layers), 1)
    a = max(int(ancilla_count), 0)
    logical_ops = gate_factor * n * l
    space_time = logical_ops * max(a, 1)
    return {
        "n_qubits": n,
        "n_layers": l,
        "ancilla_count": a,
        "logical_ops_proxy": float(logical_ops),
        "space_time_proxy": float(space_time),
    }


def hdt_benchmark_points(path: str | Path | None = None) -> dict:
    """Extract numeric benchmark points from bundled local tables when available."""
    df = tidy_numeric_frame(path)
    if df.empty:
        return {"error": "no numeric benchmark table found"}
    cols = numeric_columns(df)
    if len(cols) < 2:
        return {"error": "need at least two numeric columns for benchmark points"}
    out = df[cols[:4]].apply(pd.to_numeric, errors='coerce').dropna(how='all').head(200)
    return {"columns": [str(c) for c in out.columns], "points": out.to_dict(orient='records')}


def plot_hdt_security_efficiency(output_filename: str = 'info_7c5e_security_efficiency.png',
                                 security_col: str | None = None,
                                 efficiency_col: str | None = None,
                                 path: str | Path | None = None) -> dict:
    """Generate a composable HDT security-versus-efficiency figure from bundled benchmark points."""
    df = tidy_numeric_frame(path)
    if df.empty:
        return {"error": "no numeric table found for plotting"}
    cols = numeric_columns(df)
    if len(cols) < 2:
        return {"error": "need >=2 numeric columns"}
    xcol = security_col or cols[0]
    ycol = efficiency_col or cols[1]
    x = pd.to_numeric(df[xcol], errors='coerce')
    y = pd.to_numeric(df[ycol], errors='coerce')
    ok = x.notna() & y.notna()
    if ok.sum() < 2:
        return {"error": "insufficient points"}
    out = ARTIFACT_DIR / output_filename
    fig, ax = plt.subplots(figsize=(7.0, 5.0))
    ax.scatter(x[ok], y[ok], s=28, c='#4c78a8', alpha=0.85)
    ax.set_xlabel(str(xcol))
    ax.set_ylabel(str(ycol))
    ax.set_title('HDT security-efficiency benchmark context')
    fig.tight_layout(); fig.savefig(out, dpi=180); plt.close(fig)
    return {"path": str(out), "n_points": int(ok.sum()), "x": str(xcol), "y": str(ycol)}

from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

try:
    from .data_processing import data_root
except ImportError:
    from data_processing import data_root


ARTIFACT_DIR = Path(__file__).resolve().parents[1] / "artifacts"
ARTIFACT_DIR.mkdir(exist_ok=True)


def _table_path(path: str | Path | None = None) -> Path:
    p = Path(path) if path else (data_root() / "derived_table_s1_performance.csv")
    if not p.exists():
        raise FileNotFoundError(f"missing {p}")
    return p


def _load_table(path: str | Path | None = None) -> pd.DataFrame:
    df = pd.read_csv(_table_path(path))
    expected = {"metric", "model"}
    if not expected.issubset(df.columns):
        raise ValueError("derived_table_s1_performance.csv missing metric/model columns")
    for c in df.columns:
        if c not in {"metric", "model"}:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    return df


def supplementary_table1_matrix(path: str | Path | None = None) -> dict:
    df = _load_table(path)
    datasets = [c for c in df.columns if c not in {"metric", "model"}]
    return {
        "path": str(_table_path(path)),
        "n_rows": int(len(df)),
        "metrics": sorted(df["metric"].astype(str).unique().tolist()),
        "models": sorted(df["model"].astype(str).unique().tolist()),
        "datasets": datasets,
    }


def _delta_vs_vann(metric: str, path: str | Path | None = None) -> pd.DataFrame:
    df = _load_table(path)
    sub = df[df["metric"] == metric].copy()
    if sub.empty:
        raise ValueError(f"metric {metric} not found")

    datasets = [c for c in sub.columns if c not in {"metric", "model"}]
    vann = sub[sub["model"] == "vANN"]
    if vann.empty:
        raise ValueError("vANN baseline missing")

    base = vann.iloc[0]
    rows = []
    for _, r in sub.iterrows():
        if r["model"] == "vANN":
            continue
        for d in datasets:
            value = float(r[d])
            base_value = float(base[d])
            if metric == "loss":
                delta = base_value - value
                better = value < base_value
            else:
                delta = value - base_value
                better = value > base_value
            rows.append(
                {
                    "model": str(r["model"]),
                    "dataset": str(d),
                    "model_value": value,
                    "vann_value": base_value,
                    "delta_vs_vann": delta,
                    "better_than_vann": int(better),
                }
            )
    return pd.DataFrame(rows)


def loss_comparison_summary(path: str | Path | None = None) -> dict:
    delta = _delta_vs_vann("loss", path)
    per_model = (
        delta.groupby("model", as_index=False)
        .agg(
            wins=("better_than_vann", "sum"),
            n_datasets=("better_than_vann", "count"),
            mean_loss_reduction=("delta_vs_vann", "mean"),
            median_loss_reduction=("delta_vs_vann", "median"),
        )
        .sort_values("mean_loss_reduction", ascending=False)
    )
    return {
        "metric": "loss",
        "all_pairs_better": int(delta["better_than_vann"].sum()),
        "all_pairs_total": int(len(delta)),
        "per_model": [
            {
                "model": str(r["model"]),
                "wins": int(r["wins"]),
                "n_datasets": int(r["n_datasets"]),
                "mean_loss_reduction": float(r["mean_loss_reduction"]),
                "median_loss_reduction": float(r["median_loss_reduction"]),
            }
            for _, r in per_model.iterrows()
        ],
    }


def accuracy_comparison_summary(path: str | Path | None = None) -> dict:
    delta = _delta_vs_vann("accuracy", path)
    per_model = (
        delta.groupby("model", as_index=False)
        .agg(
            wins=("better_than_vann", "sum"),
            n_datasets=("better_than_vann", "count"),
            mean_accuracy_gain=("delta_vs_vann", "mean"),
            median_accuracy_gain=("delta_vs_vann", "median"),
        )
        .sort_values("mean_accuracy_gain", ascending=False)
    )
    return {
        "metric": "accuracy",
        "all_pairs_better": int(delta["better_than_vann"].sum()),
        "all_pairs_total": int(len(delta)),
        "per_model": [
            {
                "model": str(r["model"]),
                "wins": int(r["wins"]),
                "n_datasets": int(r["n_datasets"]),
                "mean_accuracy_gain": float(r["mean_accuracy_gain"]),
                "median_accuracy_gain": float(r["median_accuracy_gain"]),
            }
            for _, r in per_model.iterrows()
        ],
    }


def kmnist_exception_profile(path: str | Path | None = None) -> dict:
    df = _load_table(path)
    sub = df[df["metric"] == "accuracy"].copy()
    if "kmnist" not in sub.columns:
        raise ValueError("kmnist column missing")

    sub = sub[["model", "kmnist"]].dropna().sort_values("kmnist", ascending=False)
    best = sub.iloc[0]
    return {
        "dataset": "kmnist",
        "ranked_accuracy": [
            {"model": str(r["model"]), "accuracy": float(r["kmnist"])} for _, r in sub.iterrows()
        ],
        "top_model": str(best["model"]),
        "top_accuracy": float(best["kmnist"]),
    }


def model_rank_profile(path: str | Path | None = None) -> dict:
    df = _load_table(path)
    datasets = [c for c in df.columns if c not in {"metric", "model"}]
    rows = []

    for metric in ["loss", "accuracy"]:
        sub = df[df["metric"] == metric].copy()
        for d in datasets:
            if metric == "loss":
                ranked = sub[["model", d]].sort_values(d, ascending=True)
            else:
                ranked = sub[["model", d]].sort_values(d, ascending=False)
            for i, (_, r) in enumerate(ranked.iterrows(), start=1):
                rows.append({"metric": metric, "dataset": d, "model": str(r["model"]), "rank": i})

    rank_df = pd.DataFrame(rows)
    out = rank_df.groupby(["metric", "model"], as_index=False)["rank"].mean()
    return {
        "average_rank": [
            {
                "metric": str(r["metric"]),
                "model": str(r["model"]),
                "avg_rank": float(r["rank"]),
            }
            for _, r in out.sort_values(["metric", "rank"]).iterrows()
        ]
    }


def plot_loss_delta_heatmap(output_filename: str = "info_6c4d_loss_delta_vs_vann.png") -> dict:
    delta = _delta_vs_vann("loss")
    pivot = delta.pivot(index="model", columns="dataset", values="delta_vs_vann")

    fig, ax = plt.subplots(figsize=(7.8, 4.6))
    im = ax.imshow(pivot.values, cmap="YlGn", aspect="auto")
    ax.set_xticks(np.arange(pivot.shape[1]))
    ax.set_xticklabels(pivot.columns, rotation=30, ha="right")
    ax.set_yticks(np.arange(pivot.shape[0]))
    ax.set_yticklabels(pivot.index)
    ax.set_title("Loss Reduction vs vANN (positive = better)")
    for i in range(pivot.shape[0]):
        for j in range(pivot.shape[1]):
            ax.text(j, i, f"{pivot.values[i, j]:.3f}", ha="center", va="center", fontsize=8)
    fig.colorbar(im, ax=ax, label="vANN loss - model loss")

    out = ARTIFACT_DIR / output_filename
    fig.tight_layout()
    fig.savefig(out, dpi=220)
    plt.close(fig)
    return {"path": str(out)}


def plot_accuracy_delta_heatmap(output_filename: str = "info_6c4d_accuracy_delta_vs_vann.png") -> dict:
    delta = _delta_vs_vann("accuracy")
    pivot = delta.pivot(index="model", columns="dataset", values="delta_vs_vann")

    fig, ax = plt.subplots(figsize=(7.8, 4.6))
    im = ax.imshow(pivot.values, cmap="Blues", aspect="auto")
    ax.set_xticks(np.arange(pivot.shape[1]))
    ax.set_xticklabels(pivot.columns, rotation=30, ha="right")
    ax.set_yticks(np.arange(pivot.shape[0]))
    ax.set_yticklabels(pivot.index)
    ax.set_title("Accuracy Gain vs vANN (positive = better)")
    for i in range(pivot.shape[0]):
        for j in range(pivot.shape[1]):
            ax.text(j, i, f"{pivot.values[i, j]:.2f}", ha="center", va="center", fontsize=8)
    fig.colorbar(im, ax=ax, label="model accuracy - vANN accuracy")

    out = ARTIFACT_DIR / output_filename
    fig.tight_layout()
    fig.savefig(out, dpi=220)
    plt.close(fig)
    return {"path": str(out)}


def plot_model_win_counts(output_filename: str = "info_6c4d_model_win_counts.png") -> dict:
    loss = _delta_vs_vann("loss").groupby("model")["better_than_vann"].sum()
    acc = _delta_vs_vann("accuracy").groupby("model")["better_than_vann"].sum()

    models = sorted(set(loss.index.tolist()) | set(acc.index.tolist()))
    loss_counts = [int(loss.get(m, 0)) for m in models]
    acc_counts = [int(acc.get(m, 0)) for m in models]

    x = np.arange(len(models))
    w = 0.35

    fig, ax = plt.subplots(figsize=(7.6, 4.5))
    ax.bar(x - w / 2, loss_counts, width=w, label="Loss wins", color="#54a24b")
    ax.bar(x + w / 2, acc_counts, width=w, label="Accuracy wins", color="#4c78a8")
    ax.set_xticks(x)
    ax.set_xticklabels(models)
    ax.set_ylabel("Datasets beating vANN")
    ax.set_title("Per-model Wins vs vANN Across 5 Datasets")
    ax.set_ylim(0, 5.2)
    ax.grid(axis="y", alpha=0.2)
    ax.legend(frameon=False)

    out = ARTIFACT_DIR / output_filename
    fig.tight_layout()
    fig.savefig(out, dpi=220)
    plt.close(fig)
    return {"path": str(out)}


def _safe_call(fn):
    try:
        return fn()
    except TypeError:
        return {"note": "call requires explicit args"}
    except Exception as exc:
        return {"error": str(exc)}


def package_smoke_test() -> dict:
    return {
        "supplementary_table1_matrix": _safe_call(supplementary_table1_matrix),
        "loss_comparison_summary": _safe_call(loss_comparison_summary),
        "accuracy_comparison_summary": _safe_call(accuracy_comparison_summary),
        "kmnist_exception_profile": _safe_call(kmnist_exception_profile),
        "model_rank_profile": _safe_call(model_rank_profile),
    }

# Tools

Three-layer package:

- `data_processing.py`: robust local file I/O and schema-friendly table loading.
- `database_retrieval.py`: local source/repository discovery helpers.
- `information_tools.py`: Supplementary Table 1 analysis primitives for
  - loss/accuracy contrasts versus vANN,
  - KMNIST exception profiling,
  - rank aggregation,
  - artifact generation (`plot_loss_delta_heatmap`, `plot_accuracy_delta_heatmap`, `plot_model_win_counts`).

These functions expose reusable paper-method checks rather than one-click final answers.

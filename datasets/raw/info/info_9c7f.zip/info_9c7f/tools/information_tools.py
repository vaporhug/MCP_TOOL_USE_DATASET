from __future__ import annotations

from pathlib import Path
import re

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from pypdf import PdfReader

try:
    from .data_processing import data_root, list_files
except ImportError:
    import importlib.util
    import sys

    tools_dir = Path(__file__).resolve().parent
    module_path = tools_dir / "data_processing.py"
    spec = importlib.util.spec_from_file_location("_info_9c7f_data_processing", module_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load {module_path}")
    _dp = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = _dp
    spec.loader.exec_module(_dp)
    data_root = _dp.data_root
    list_files = _dp.list_files

ARTIFACT_DIR = Path(__file__).resolve().parents[1] / "artifacts"
ARTIFACT_DIR.mkdir(exist_ok=True)
SUPPLEMENT = "41467_2026_70035_MOESM2_ESM.pdf"


def source_inventory(root: str | Path | None = None) -> dict:
    root_path = Path(root) if root else data_root()
    files = list_files(root_path)
    return {"n_files": len(files), "files": [str(Path(f).relative_to(root_path)) for f in files]}


def _supplement_text() -> str:
    path = data_root() / SUPPLEMENT
    if not path.exists():
        raise FileNotFoundError(path)
    reader = PdfReader(str(path))
    return "\n".join(page.extract_text() or "" for page in reader.pages)


def database_coordinate_gap_table() -> pd.DataFrame:
    text = _supplement_text()
    rows = []
    for prefix, source, total, missing, percent in re.findall(r"(?m)^\s*(00|01)\s+(ICDD|ICSD)\s+(\d+)\s+(\d+)\s+(\d+\.\d+)%", text):
        rows.append({
            "prefix": prefix,
            "source": source,
            "entries_total": int(total),
            "entries_without_atomic_coordinates": int(missing),
            "percentage_without_atomic_coordinates": float(percent),
        })
    if not rows:
        raise ValueError("Supplementary Table 1 not found")
    return pd.DataFrame(rows)


def icsd_repair_funnel_table() -> pd.DataFrame:
    return pd.DataFrame([
        {"stage": "ordered ICSD structures", "number": 49283},
        {"stage": "Ehull > 0.1 eV/atom, <=20 atoms", "number": 3122},
        {"stage": "XRDSol structures differ", "number": 1429},
        {"stage": "good XRD match (Rcos > 0.9)", "number": 588},
        {"stage": "low energy (Ehull < 0.1 eV/atom)", "number": 39},
    ])


def ehull_repair_table() -> pd.DataFrame:
    text = _supplement_text()
    start = text.find("Supplementary Table 3")
    end = text.find("GeI2:", start)
    if start < 0 or end < 0:
        raise ValueError("Supplementary Table 3 bounds not found")
    section = text[start:end]
    pattern = re.compile(r"(?m)^\s*(\d{1,2})\s+([A-Za-z0-9()\.]+)\s+(\d+)\s+(\d+\.\d+)\s+(\d+\.\d+)")
    rows = []
    for no, name, icsd_id, original, solved in pattern.findall(section):
        rows.append({
            "no": int(no),
            "name": name,
            "icsd_id": int(icsd_id),
            "original_ehull_ev_per_atom": float(original),
            "solved_ehull_ev_per_atom": float(solved),
            "ehull_drop_ev_per_atom": float(original) - float(solved),
        })
    if len(rows) != 39:
        raise ValueError(f"Expected 39 Ehull rows from Supplementary Table 3, parsed {len(rows)}")
    return pd.DataFrame(rows).sort_values("no").reset_index(drop=True)


def repair_summary() -> dict:
    ehull = ehull_repair_table()
    funnel = icsd_repair_funnel_table()
    return {
        "ehull_rows": int(len(ehull)),
        "median_original_ehull": float(ehull["original_ehull_ev_per_atom"].median()),
        "median_solved_ehull": float(ehull["solved_ehull_ev_per_atom"].median()),
        "low_energy_count": int(funnel.loc[funnel["stage"].str.contains("low energy"), "number"].iloc[0]),
    }


def plot_coordinate_gap(output_filename: str = "Fig1_info_9c7f_feature_profile.png") -> dict:
    df = database_coordinate_gap_table()
    out = ARTIFACT_DIR / output_filename
    fig, ax = plt.subplots(figsize=(8.2, 4.8))
    x = np.arange(len(df))
    ax.bar(x - 0.18, df["entries_total"], width=0.36, label="total entries")
    ax.bar(x + 0.18, df["entries_without_atomic_coordinates"], width=0.36, label="without coordinates")
    ax.set_xticks(x)
    ax.set_xticklabels(df["source"])
    ax.set_ylabel("entries")
    ax.set_title("Database entries lacking atomic coordinates")
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(out, dpi=180)
    plt.close(fig)
    return {"path": str(out), "source": f"{SUPPLEMENT}::Supplementary Table 1", "rows": int(len(df))}


def plot_icsd_repair_funnel(output_filename: str = "Fig2_info_9c7f_workflow_contrast.png") -> dict:
    df = icsd_repair_funnel_table()
    out = ARTIFACT_DIR / output_filename
    fig, ax = plt.subplots(figsize=(8.2, 4.8))
    ax.barh(df["stage"], df["number"], color="#7b4f9e")
    ax.set_xscale("log")
    ax.set_xlabel("structures (log scale)")
    ax.set_title("ICSD reassessment funnel from Supplementary Table 2")
    fig.tight_layout()
    fig.savefig(out, dpi=180)
    plt.close(fig)
    return {"path": str(out), "source": f"{SUPPLEMENT}::Supplementary Table 2", "rows": int(len(df))}


def plot_ehull_repair_relationship(output_filename: str = "Fig3_info_9c7f_signal_relationship.png") -> dict:
    df = ehull_repair_table()
    out = ARTIFACT_DIR / output_filename
    fig, ax = plt.subplots(figsize=(8.2, 4.8))
    ax.scatter(df["original_ehull_ev_per_atom"], df["solved_ehull_ev_per_atom"], s=38, alpha=0.8, color="#356f8c")
    lim = max(df["original_ehull_ev_per_atom"].max(), df["solved_ehull_ev_per_atom"].max()) * 1.05
    ax.plot([0, lim], [0, lim], color="black", lw=1, linestyle="--", label="no improvement")
    ax.axhline(0.1, color="#c75146", lw=1, linestyle=":", label="0.1 eV/atom threshold")
    ax.set_xlabel("original ICSD Ehull (eV/atom)")
    ax.set_ylabel("XRDSol solved Ehull (eV/atom)")
    ax.set_title("Energy reduction for 39 revisited ICSD structures")
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(out, dpi=180)
    plt.close(fig)
    return {"path": str(out), "source": f"{SUPPLEMENT}::Supplementary Table 3", "rows": int(len(df))}


def package_smoke_test() -> dict:
    return {
        "inventory": source_inventory(),
        "coordinate_gap_rows": int(len(database_coordinate_gap_table())),
        "repair_summary": repair_summary(),
        "plots": [plot_coordinate_gap(), plot_icsd_repair_funnel(), plot_ehull_repair_relationship()],
    }

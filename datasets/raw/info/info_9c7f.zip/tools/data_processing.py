from __future__ import annotations
from pathlib import Path
import zipfile
import pandas as pd
import numpy as np

def package_root() -> Path:
    return Path(__file__).resolve().parents[1]

def data_root() -> Path:
    return package_root() / "input_data" / "data"

def list_files(root: str | Path | None = None) -> list[str]:
    root = Path(root) if root else data_root()
    return [str(p) for p in sorted(root.rglob("*")) if p.is_file()]

def archive_inventory(path: str | Path) -> list[str]:
    p = Path(path)
    if p.suffix.lower() != ".zip":
        return []
    with zipfile.ZipFile(p) as zf:
        return sorted(zf.namelist())

def read_table(path: str | Path, **kwargs) -> pd.DataFrame:
    p = Path(path)
    if p.suffix.lower() in [".xlsx", ".xls"]:
        return pd.read_excel(p, **kwargs)
    if p.suffix.lower() in [".tsv", ".tab"]:
        return pd.read_csv(p, sep="\t", on_bad_lines="skip", **kwargs)
    return pd.read_csv(p, on_bad_lines="skip", **kwargs)

def workbook_sheets(path: str | Path) -> list[str]:
    return pd.ExcelFile(path).sheet_names

def load_workbook_long(path: str | Path, max_sheets: int | None = None) -> pd.DataFrame:
    sheets = workbook_sheets(path)
    frames = []
    for sheet in sheets[:max_sheets]:
        try:
            df = pd.read_excel(path, sheet_name=sheet)
            df.insert(0, "source_sheet", sheet)
            frames.append(df)
        except Exception:
            continue
    return pd.concat(frames, ignore_index=True, sort=False) if frames else pd.DataFrame()

def numeric_columns(df: pd.DataFrame) -> list[str]:
    out=[]
    for c in df.columns:
        if pd.to_numeric(df[c], errors="coerce").notna().sum() > max(2, 0.1 * len(df)):
            out.append(c)
    return out

def tidy_numeric_frame(path: str | Path | None = None, sheet_name: str | int | None = 0) -> pd.DataFrame:
    files = list_files(data_root())
    if path is None:
        candidates=[f for f in files if Path(f).suffix.lower() in [".csv", ".tsv", ".txt", ".xlsx", ".xls"]]
        if not candidates:
            return pd.DataFrame()
        path=candidates[0]
    if str(path).lower().endswith((".xlsx", ".xls")):
        df = read_table(path, sheet_name=sheet_name)
    else:
        try:
            df = read_table(path)
        except Exception:
            df = pd.read_csv(path, sep=None, engine="python", on_bad_lines="skip")
    for c in df.columns:
        converted = pd.to_numeric(df[c], errors="coerce")
        if converted.notna().sum() > 0:
            df[c] = converted
    return df

def robust_zscore(values) -> np.ndarray:
    x=np.asarray(values, dtype=float)
    med=np.nanmedian(x); mad=np.nanmedian(np.abs(x-med))
    scale=1.4826*mad if mad and np.isfinite(mad) else np.nanstd(x)
    return (x-med)/(scale if scale else 1.0)

# Strict 5.9 embedded-source numeric discovery


def _read_text_table_bytes(raw: bytes, name: str) -> pd.DataFrame:
    import io
    suffix = Path(name).suffix.lower()
    common = {"comment": "#", "on_bad_lines": "skip"}
    if suffix in [".tsv", ".tab"]:
        return pd.read_csv(io.BytesIO(raw), sep="\t", **common)
    if suffix in [".txt", ".dat"]:
        try:
            return pd.read_csv(io.BytesIO(raw), sep=r"\s+", engine="python", header=0, **common)
        except Exception:
            return pd.read_csv(io.BytesIO(raw), sep=None, engine="python", **common)
    try:
        return pd.read_csv(io.BytesIO(raw), sep=None, engine="python", **common)
    except Exception:
        return pd.read_csv(io.BytesIO(raw), sep=r"\s+", engine="python", header=0, **common)


def _numeric_df_from_npz_bytes(raw: bytes, max_cols: int = 24) -> pd.DataFrame:
    import io
    with np.load(io.BytesIO(raw), allow_pickle=False) as data:
        for key in data.files:
            arr = np.asarray(data[key])
            if arr.size < 3 or not np.issubdtype(arr.dtype, np.number):
                continue
            if arr.ndim == 1:
                return pd.DataFrame({str(key): arr})
            if arr.ndim >= 2:
                flat = arr.reshape(arr.shape[0], -1)
                cols = min(max_cols, flat.shape[1])
                return pd.DataFrame(flat[:, :cols], columns=[f"{key}_{i}" for i in range(cols)])
    return pd.DataFrame()


def _numeric_df_from_pdf(path: str | Path, max_pages: int = 8, max_numbers_per_line: int = 12) -> pd.DataFrame:
    import re
    try:
        from pypdf import PdfReader
    except Exception:
        return pd.DataFrame()
    rows = []
    try:
        reader = PdfReader(str(path))
        for page in reader.pages[:max_pages]:
            text = page.extract_text() or ""
            for line in text.splitlines():
                nums = re.findall(r"[-+]?(?:\d+\.\d+|\d+)(?:[eE][-+]?\d+)?", line)
                if len(nums) >= 2:
                    row = [float(x) for x in nums[:max_numbers_per_line]]
                    rows.append(row)
    except Exception:
        return pd.DataFrame()
    if not rows:
        return pd.DataFrame()
    width = max(len(r) for r in rows)
    padded = [r + [np.nan] * (width - len(r)) for r in rows]
    return pd.DataFrame(padded, columns=[f"number_{i+1}" for i in range(width)])


def _coerce_numeric_frame(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    for col in out.columns:
        converted = pd.to_numeric(out[col], errors="coerce")
        if converted.notna().sum() > 0:
            out[col] = converted
    return out


def iter_numeric_sources(root: str | Path | None = None, min_numeric_cols: int = 1, max_sources: int = 120):
    root = Path(root) if root else data_root()
    yielded = 0
    files = sorted(p for p in root.rglob("*") if p.is_file())

    def priority(path: Path) -> int:
        suffix = path.suffix.lower()
        name = path.name.lower()
        if suffix in [".xlsx", ".xls"]:
            return 0
        if suffix == ".zip":
            return 1
        if suffix in [".csv", ".tsv", ".tab", ".dat", ".npz"]:
            return 2
        if suffix == ".txt" and name not in {"source_links.txt", "public_repository_links.txt"}:
            return 3
        if suffix == ".pdf":
            return 4
        return 9

    for path in sorted(files, key=lambda p: (priority(p), str(p))):
        if priority(path) >= 9:
            continue
        suffix = path.suffix.lower()
        candidates = []
        if suffix in [".xlsx", ".xls"]:
            try:
                for sheet in workbook_sheets(path)[:20]:
                    try:
                        candidates.append((read_table(path, sheet_name=sheet), f"{path}::{sheet}"))
                    except Exception:
                        continue
            except Exception:
                pass
        elif suffix in [".csv", ".tsv", ".tab", ".txt", ".dat"]:
            try:
                candidates.append((tidy_numeric_frame(path), str(path)))
            except Exception:
                pass
        elif suffix == ".npz":
            try:
                candidates.append((_numeric_df_from_npz_bytes(path.read_bytes()), str(path)))
            except Exception:
                pass
        elif suffix == ".zip":
            try:
                with zipfile.ZipFile(path) as zf:
                    members = sorted(zf.namelist())[:600]
                    member_priority = {".xlsx": 0, ".xls": 0, ".csv": 1, ".tsv": 1, ".tab": 1, ".dat": 1, ".txt": 2, ".npz": 3}
                    members = sorted(members, key=lambda m: (member_priority.get(Path(m).suffix.lower(), 9), m))
                    for member in members:
                        if member.endswith("/") or "__MACOSX" in member:
                            continue
                        msuffix = Path(member).suffix.lower()
                        if member_priority.get(msuffix, 9) >= 9:
                            continue
                        try:
                            raw = zf.read(member)
                        except Exception:
                            continue
                        if msuffix in [".csv", ".tsv", ".tab", ".txt", ".dat"]:
                            try:
                                candidates.append((_read_text_table_bytes(raw, member), f"{path}::{member}"))
                            except Exception:
                                continue
                        elif msuffix == ".npz":
                            try:
                                candidates.append((_numeric_df_from_npz_bytes(raw), f"{path}::{member}"))
                            except Exception:
                                continue
                        elif msuffix in [".xlsx", ".xls"]:
                            # Zip-contained workbooks are rare here; expose them via inventory rather than
                            # silently depending on an in-memory Excel engine path.
                            continue
            except Exception:
                pass
        elif suffix == ".pdf":
            candidates.append((_numeric_df_from_pdf(path), str(path)))
        for df, label in candidates:
            df = _coerce_numeric_frame(df)
            if not df.empty and len(numeric_columns(df)) >= min_numeric_cols:
                yield df, label
                yielded += 1
                if yielded >= max_sources:
                    return

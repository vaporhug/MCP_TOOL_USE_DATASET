# Tools

This directory follows the three-layer task-tool structure.

- `data_processing.py`: local file discovery, table helpers, archive inspection, numeric coercion, and import fallback support.
- `database_retrieval.py`: local inventory, article-link extraction, and public repository discovery from bundled article HTML.
- `information_tools.py`: paper-scoped analysis primitives that read bundled local source/supplementary data, expose reusable benchmark or table transformations, and generate the three scored workflow-evidence artifacts.

The tools are scoped to the public local evidence bundled with this task. They do not call external APIs and do not attempt full model retraining, hardware remeasurement, full-wave simulation, or database-scale inference that is not present locally. Final scientific wording should be checked against `input_data/reference_paper/target.pdf`.

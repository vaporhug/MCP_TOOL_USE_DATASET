from __future__ import annotations
from pathlib import Path
import re, urllib.parse
try:
    from .data_processing import data_root, list_files, archive_inventory
except ImportError:
    import importlib.util
    import re
    import sys
    tools_dir = Path(__file__).resolve().parent
    task_name = re.sub(r"[^0-9A-Za-z_]", "_", Path(__file__).resolve().parents[1].name)
    module_path = tools_dir / "data_processing.py"
    module_name = f"_strict59_{task_name}_data_processing_for_db"
    spec = importlib.util.spec_from_file_location(module_name, module_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load {module_path}")
    _dp = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = _dp
    spec.loader.exec_module(_dp)
    data_root = _dp.data_root
    list_files = _dp.list_files
    archive_inventory = _dp.archive_inventory

def locate(pattern: str, root: str | Path | None = None) -> list[str]:
    root = Path(root) if root else data_root()
    return [str(p) for p in sorted(root.rglob(pattern))]

def inventory(root: str | Path | None = None) -> dict:
    files = list_files(root)
    archives = {f: archive_inventory(f)[:50] for f in files if Path(f).suffix.lower() == ".zip"}
    return {"n_files": len(files), "files": files[:200], "archives": archives}

def extract_article_links(article_html: str | Path | None = None, pattern: str | None = None) -> list[str]:
    html_path = Path(article_html) if article_html else data_root() / "article_page.html"
    text = html_path.read_text(errors="ignore") if html_path.exists() else ""
    links = sorted(set(re.findall(r'https?://[^"\s<>]+', text)))
    if pattern:
        links = [u for u in links if re.search(pattern, u, re.I)]
    return links

def public_repository_links() -> dict:
    links = extract_article_links(pattern=r'(github|zenodo|dryad|osf|figshare|dataverse)')
    return {"repositories": links}

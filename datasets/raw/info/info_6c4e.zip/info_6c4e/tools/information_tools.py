from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

try:
    from .data_processing import data_root
except ImportError:
    from data_processing import data_root


ARTIFACT_DIR = Path(__file__).resolve().parents[1] / "artifacts"
ARTIFACT_DIR.mkdir(exist_ok=True)


def _metric_path(path: str | Path | None = None) -> Path:
    p = Path(path) if path else (data_root() / "paper_headline_metrics.csv")
    if not p.exists():
        raise FileNotFoundError(f"missing {p}")
    return p


def _load_metrics(path: str | Path | None = None) -> pd.DataFrame:
    df = pd.read_csv(_metric_path(path))
    required = {"metric_name", "domain", "value", "unit", "source_citation"}
    if not required.issubset(df.columns):
        raise ValueError("paper_headline_metrics.csv missing required columns")
    df["value"] = pd.to_numeric(df["value"], errors="coerce")
    df = df.dropna(subset=["value"]).copy()
    return df


def source_anchor_manifest(path: str | Path | None = None) -> dict:
    df = _load_metrics(path)
    rows = []
    for _, r in df.iterrows():
        citation = str(r.get("source_citation", "") or "")
        rows.append(
            {
                "metric_name": str(r["metric_name"]),
                "unit": str(r["unit"]),
                "source_citation": citation,
                "has_paper_anchor": ("PAPER" in citation.upper()),
            }
        )
    return {
        "n_rows": int(len(rows)),
        "n_rows_with_paper_anchor": int(sum(int(r["has_paper_anchor"]) for r in rows)),
        "rows": rows,
    }


def headline_consistency_checks(path: str | Path | None = None) -> dict:
    df = _load_metrics(path)
    issues = []
    for _, r in df.iterrows():
        metric = str(r["metric_name"])
        unit = str(r["unit"]).lower()
        value = float(r["value"])
        if unit == "auc" and not (0.0 <= value <= 1.0):
            issues.append(f"{metric}: auc out of [0,1] -> {value}")
        if unit == "percent" and not (0.0 <= value <= 100.0):
            issues.append(f"{metric}: percent out of [0,100] -> {value}")
        if unit == "count" and value < 0.0:
            issues.append(f"{metric}: count < 0 -> {value}")

    idx = {str(r["metric_name"]): float(r["value"]) for _, r in df.iterrows()}
    if "top100_precision" in idx and "marketplace_scale_auc" in idx:
        precision_pp = idx["top100_precision"]
        auc_pp = idx["marketplace_scale_auc"] * 100.0
        if precision_pp < auc_pp:
            issues.append(
                f"top100_precision ({precision_pp}) is below marketplace_scale_auc*100 ({auc_pp})"
            )

    return {
        "n_metrics": int(len(df)),
        "n_issues": int(len(issues)),
        "issues": issues,
    }


def paper_headline_metric_table(path: str | Path | None = None) -> dict:
    df = _load_metrics(path)
    return {
        "path": str(_metric_path(path)),
        "n_metrics": int(len(df)),
        "metric_names": sorted(df["metric_name"].astype(str).unique().tolist()),
        "domains": sorted(df["domain"].astype(str).unique().tolist()),
        "units": sorted(df["unit"].astype(str).unique().tolist()),
    }


def cross_domain_auc_summary(path: str | Path | None = None) -> dict:
    df = _load_metrics(path)
    auc = df[df["unit"].str.lower() == "auc"].copy()
    auc = auc.sort_values("value", ascending=False)
    return {
        "auc_metrics": [
            {
                "metric_name": str(r["metric_name"]),
                "domain": str(r["domain"]),
                "auc": float(r["value"]),
                "source_citation": str(r.get("source_citation", "")),
            }
            for _, r in auc.iterrows()
        ],
        "best_auc": float(auc["value"].max()),
        "worst_auc": float(auc["value"].min()),
        "auc_span": float(auc["value"].max() - auc["value"].min()),
    }


def temporal_retention_summary(path: str | Path | None = None) -> dict:
    df = _load_metrics(path)
    row = df[df["metric_name"] == "yearly_identification_rate"]
    if row.empty:
        raise ValueError("yearly_identification_rate missing")
    val = float(row.iloc[0]["value"])
    return {
        "yearly_identification_rate_percent": val,
        "retention_fraction": val / 100.0,
        "non_retained_fraction": 1.0 - (val / 100.0),
        "source_citation": str(row.iloc[0].get("source_citation", "")),
    }


def marketplace_scale_summary(path: str | Path | None = None) -> dict:
    df = _load_metrics(path)

    def pick(metric: str) -> float:
        r = df[df["metric_name"] == metric]
        if r.empty:
            raise ValueError(f"missing {metric}")
        return float(r.iloc[0]["value"])

    auc = pick("marketplace_scale_auc")
    traders = pick("marketplace_daily_traders")
    precision = pick("top100_precision")
    return {
        "marketplace_scale_auc": auc,
        "marketplace_daily_traders": traders,
        "top100_precision_percent": precision,
        "precision_minus_auc_percent_points": (precision / 100.0 - auc) * 100.0,
        "consistency_check": {
            "top100_precision_ge_auc_percent": bool(precision >= auc * 100.0),
            "auc_percent": auc * 100.0,
        },
    }


def cross_domain_delta_profile(path: str | Path | None = None) -> dict:
    auc = cross_domain_auc_summary(path)["auc_metrics"]
    df = pd.DataFrame(auc)
    baseline = df.loc[df["metric_name"] == "financial_cross_market_auc", "auc"]
    if baseline.empty:
        raise ValueError("financial_cross_market_auc missing")
    base = float(baseline.iloc[0])
    df["delta_from_financial_auc"] = df["auc"] - base
    return {
        "baseline_financial_auc": base,
        "delta_rows": [
            {
                "metric_name": str(r["metric_name"]),
                "domain": str(r["domain"]),
                "auc": float(r["auc"]),
                "delta_from_financial_auc": float(r["delta_from_financial_auc"]),
            }
            for _, r in df.sort_values("delta_from_financial_auc", ascending=False).iterrows()
        ],
    }


def plot_auc_landscape(output_filename: str = "info_6c4e_auc_landscape.png") -> dict:
    auc_rows = cross_domain_auc_summary()["auc_metrics"]
    df = pd.DataFrame(auc_rows)

    fig, ax = plt.subplots(figsize=(8.2, 4.6))
    ax.bar(df["metric_name"], df["auc"], color="#4c78a8")
    ax.set_ylim(0.0, 1.0)
    ax.set_ylabel("AUC")
    ax.set_title("Cross-Domain Identity-Matching AUC")
    ax.grid(axis="y", alpha=0.2)
    ax.tick_params(axis="x", rotation=30)

    out = ARTIFACT_DIR / output_filename
    fig.tight_layout()
    fig.savefig(out, dpi=220)
    plt.close(fig)
    return {"path": str(out)}


def plot_marketplace_scale(output_filename: str = "info_6c4e_marketplace_scale.png") -> dict:
    s = marketplace_scale_summary()
    values = [s["marketplace_scale_auc"] * 100.0, s["top100_precision_percent"], s["marketplace_daily_traders"] / 1000.0]
    labels = ["AUC (%)", "Top-100 precision (%)", "Daily traders (thousands)"]

    fig, ax = plt.subplots(figsize=(7.8, 4.6))
    bars = ax.bar(labels, values, color=["#54a24b", "#f58518", "#b279a2"])
    ax.set_title("Marketplace-Scale Performance Headlines")
    ax.grid(axis="y", alpha=0.2)
    for bar, val in zip(bars, values):
        ax.text(bar.get_x() + bar.get_width() / 2.0, bar.get_height(), f"{val:.2f}", ha="center", va="bottom", fontsize=8)

    out = ARTIFACT_DIR / output_filename
    fig.tight_layout()
    fig.savefig(out, dpi=220)
    plt.close(fig)
    return {"path": str(out)}


def plot_auc_delta_from_financial(output_filename: str = "info_6c4e_auc_delta_from_financial.png") -> dict:
    rows = cross_domain_delta_profile()["delta_rows"]
    df = pd.DataFrame(rows)

    fig, ax = plt.subplots(figsize=(8.0, 4.6))
    colors = ["#4c78a8" if v >= 0 else "#e45756" for v in df["delta_from_financial_auc"]]
    ax.bar(df["metric_name"], df["delta_from_financial_auc"], color=colors)
    ax.axhline(0.0, color="black", linestyle="--", linewidth=1)
    ax.set_ylabel("AUC difference vs financial_cross_market_auc")
    ax.set_title("AUC Delta Relative to Financial Baseline")
    ax.grid(axis="y", alpha=0.2)
    ax.tick_params(axis="x", rotation=30)

    out = ARTIFACT_DIR / output_filename
    fig.tight_layout()
    fig.savefig(out, dpi=220)
    plt.close(fig)
    return {"path": str(out)}


def _safe_call(fn):
    try:
        return fn()
    except TypeError:
        return {"note": "call requires explicit args"}
    except Exception as exc:
        return {"error": str(exc)}


def package_smoke_test() -> dict:
    return {
        "paper_headline_metric_table": _safe_call(paper_headline_metric_table),
        "source_anchor_manifest": _safe_call(source_anchor_manifest),
        "headline_consistency_checks": _safe_call(headline_consistency_checks),
        "cross_domain_auc_summary": _safe_call(cross_domain_auc_summary),
        "temporal_retention_summary": _safe_call(temporal_retention_summary),
        "marketplace_scale_summary": _safe_call(marketplace_scale_summary),
        "cross_domain_delta_profile": _safe_call(cross_domain_delta_profile),
    }

# Tools

Three-layer package:

- `data_processing.py`: robust local file I/O and schema-aware parsing.
- `database_retrieval.py`: source/repository link discovery helpers.
- `information_tools.py`: paper-headline metric primitives for
  - cross-domain AUC profiling,
  - temporal-retention and marketplace-scale summaries,
  - delta analysis relative to the financial baseline,
  - artifact generation (`plot_auc_landscape`, `plot_marketplace_scale`, `plot_auc_delta_from_financial`).

The workflow is constrained to paper-cited values and reproducible local summaries.

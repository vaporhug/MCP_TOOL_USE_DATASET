				*** Religion, Parochialism and Intuitive Cooperation ***
				     *** Ozan Isler, Onurcan Yilmaz, John Maule ***
				    *** Stata/SE 16.1 data analysis command file ***
					
** OUTLINE
** A) Variable Transformations
** B) Descriptive Statistics			
** C) Manipulation Checks
** D) Preregistered Analysis
** E) Exploratory Analysis
** F) Supplementary Information

	
** A) Variable Transformations

    * Note: to be run on the raw data file before analysis

	* Group idenity (ID) treatment
label define ID_manipulation_label 0 "NoID" 1 "Believer" 2 "Atheist"
label values ID_manipulation ID_manipulation_label

	* Time limit (TL) treatments (TD: time-delay; TP: time-pressure)
label define Time_manipulation_label 0 "TD" 1 "TP"
label values Time_manipulation Time_manipulation_label

	* Treatments
gen Treatment = "."
replace Treatment = "In_TP" if ID_manipulation==1 & Time_manipulation==1 
replace Treatment = "In_TD" if ID_manipulation==1 & Time_manipulation==0 
replace Treatment = "Out_TP" if ID_manipulation==2 & Time_manipulation==1 
replace Treatment = "Out_TD" if ID_manipulation==2 & Time_manipulation==0
replace Treatment = "No_TP" if ID_manipulation==0 & Time_manipulation==1 
replace Treatment = "No_TD" if ID_manipulation==0 & Time_manipulation==0

	* Gender
label define Genderlabel  1 "Female" 2 "Male" 3 "Other"
label values Gender Genderlabel

	* Female
gen Female = 0
replace Female = 1 if Gender==1

	* Religious Affliation Numeric
label define Religious_Affliationlabel 1 "Christianity" 2 "Islam" 3 "Judaism" 4 "Agnostic" 5 "Atheist" 6 "Other"
label values Religious_Affliation Religious_Affliationlabel

	* Religious Practice
label define Practicing_Religiouslabel 1 "Yes. Public and private." 2 "Yes. Public only." 3 "Yes. Private only." 4 "No." 
label values Practicing_Religious Practicing_Religiouslabel

	* Experience with the PD game
label define Experiencelabel 0 "No" 1 "Yes"
label values Experience Experiencelabel

	* Current Christian believer
gen Current_Christian_believer = 0 if Believer
replace Current_Christian_believer = 1 if Believer & Religious_Affliation==1

	* Current publicly practicing
gen Current_publicly_practicing = 0 if Believer
replace Current_publicly_practicing = 1 if Believer & Practicing_Religious!=3 & Practicing_Religious!=4

	* Current Christian believer and publicly practicing 
gen Current_practicing_believer = 0 if Believer
replace Current_practicing_believer = 1 if Believer & Current_Christian_believer & Current_publicly_practicing

	* Current atheist
gen Current_atheist = 0 if Believer==0
replace Current_atheist = 1 if Believer==0 & Religious_Affliation==5
	
	* Current_belief
gen Current_belief = 0
replace Current_belief = 1 if Current_practicing_believer==1 | Current_atheist==1

	* Comprehension self-gain maximization
gen Comprehension_Self_Correct = 0 
replace Comprehension_Self_Correct = 1 if Comprehension_Self==0

label define Comprehension_Self_Correctlabel 0 "No" 1 "Yes"
label values Comprehension_Self_Correct Comprehension_Self_Correctlabel

	* Comprehension group-gain maximization
gen Comprehension_Group_Correct = 0 
replace Comprehension_Group_Correct = 1 if Comprehension_Other==50

label define Comprehension_Group_Correctlabel 0 "No" 1 "Yes"
label values Comprehension_Group_Correct Comprehension_Group_Correctlabel

	* Comprehension
gen Comprehension = 0 
replace Comprehension = 1 if Comprehension_Self==0 & Comprehension_Other==50

label define Comprehensionlabel 0 "No" 1 "Yes"
label values Comprehension Comprehensionlabel

	* Compliance with time limits
gen Compliance = 0 
replace Compliance = 1 if Time_manipulation==0 & Cooperation_T>20
replace Compliance = 1 if Time_manipulation==1 & Cooperation_T<10
	
	* Time limit (TL) manipulation check composite variable
gen Man_Check_TL = (Man_Check_TL_Q1_No_Time+Man_Check_TL_Q2_Gut)/2

	* Freeriding behaviour (i.e., zero Cooperations in the PD)
gen Freeriding = 0 
replace Freeriding = 1 if Cooperation==0


** B) Descriptive Statistics

	* Gender and age
tab Gender if Believer
tabstat Age if Believer, stat(mean sd min max)

	* Previous participation in lab or online experiment with PD game
tab Experience if Believer

	* Compliance with time-limit
tab Time_manipulation Compliance if Believer, row

	* Test of normal distribution of cooperation
swilk Cooperation if Believer

	* Number of observations across treatments
tab Time_manipulation ID_manipulation if Believer, row chi2

** C) Manipulation Checks

	* Time-limit manipulation check, behavioural (Cooperation_T: response times for Cooperation decisions)
tabstat  Cooperation_T if Believer, by(Time_manipulation) stat(mean n sd min max p50)
ranksum Cooperation_T if Believer, by(Time_manipulation)
esize twosample Cooperation_T if Believer, by(Time_manipulation)

	* Time-limit manipulation check, self-report (Man_Check_TL: average of the two self-report questions)
ttest Man_Check_TL if Believer, by(Time_manipulation) 
esize twosample Man_Check_TL if Believer, by(Time_manipulation)

	* Group identity manipulation check (Man_Check_Group: self-in-other measure)
ttest Man_Check_Group if Believer & ID_manipulation!=0, by(ID_manipulation)
esize twosample Man_Check_Group if Believer & ID_manipulation!=0, by(ID_manipulation)

	
** D) Preregistered Analysis

	* Cooperation by treatment (amount transferred in the PD game by Christian believers) summarized in Fig. 2.
ci means Cooperation if Believer & Treatment=="In_TP"
ci means Cooperation if Believer & Treatment=="In_TD"
ci means Cooperation if Believer & Treatment=="Out_TP"
ci means Cooperation if Believer & Treatment=="Out_TD"
ci means Cooperation if Believer & Treatment=="No_TP"
ci means Cooperation if Believer & Treatment=="No_TD"

	* Test of SHH in the group identity conditions
tabstat Cooperation if Believer & ID_manipulation!=0, by(ID_manipulation) stat(mean n sd min max p50)
tabstat Cooperation if Believer & ID_manipulation!=0, by(Time_manipulation) stat(mean n sd min max p50)
anova Cooperation ID_manipulation##Time_manipulation if Believer & ID_manipulation!=0
estat esize, level(95)

	* Point estimate of the main effect of group identity (In-Out)
lincom 1.ID_manipulation - 2.ID_manipulation

	* Point estimate of the main effect of time-limits (TD-TP)
lincom 0.Time_manipulation - 1.Time_manipulation

	* Test of SHH in the NoID condition
ttest Cooperation if Believer & ID_manipulation==0, by(Time_manipulation)
esize twosample Cooperation if Believer & ID_manipulation==0, by(Time_manipulation)

	* Equivalence test
anova Cooperation ID_manipulation##Time_manipulation if Believer & ID_manipulation!=0
estat esize, level(90)

	* Note: Bayesian ANOVA analysis was conducted on JASP 0.13.1.0 and can be found on the OSF study registration site

** E) Exploratory Analysis

* Religious believers

	* Description of models
		
		* Correlation between cooperation and control variables in the complete sample (PD experience and comprehension)
ci2 Cooperation Comprehension_Self_Correct if Believer, corr
ci2 Cooperation Comprehension_Group_Correct if Believer, corr
ci2 Cooperation Experience if Believer, corr


		* Experience with PD game experiments in the complete sample
tab Experience if Believer

		* Comprehension of the PD game in the complete sample
tab Comprehension_Self_Correct if Believer
tab Comprehension_Group_Correct if Believer		
tab Time_manipulation Comprehension if Believer, row chi2

		* Current Christian believers in the overall sample
tab Current_Christian_believer Current_publicly_practicing if Believer

	* Exploratory Models
		
		* Model 1a: Complete
tabstat Cooperation, by(Treatment) stat(mean sd n)
anova Cooperation ID_manipulation##Time_manipulation Comprehension_Self_Correct Comprehension_Group_Correct Experience if Believer
estat esize, level(95)

		* Model 2a: Inexperienced
tabstat Cooperation if Experience==0, by(Treatment) stat(mean sd n)
anova Cooperation ID_manipulation##Time_manipulation Comprehension_Self_Correct Comprehension_Group_Correct  if Believer & Experience==0
estat esize, level(95)

		* Model 3a: Comprehended
tabstat Cooperation if Comprehension_Self_Correct & Comprehension_Group_Correct, by(Treatment) stat(mean sd n)
anova Cooperation ID_manipulation##Time_manipulation Experience if Believer & Comprehension_Self_Correct & Comprehension_Group_Correct
estat esize, level(95)

		* Model 4a: Current
tabstat Cooperation if Current_Christian_believer & Current_publicly_practicing, by(Treatment) stat(mean sd n)	
anova Cooperation ID_manipulation##Time_manipulation Comprehension_Self_Correct Comprehension_Group_Correct Experience if Believer & Current_Christian_believer & Current_publicly_practicing
estat esize, level(95)

	* Decision Conflict 
ci2 Cooperation Conflict if Believer & ID_manipulation==1, corr
ci2 Cooperation Conflict if Believer & ID_manipulation==2, corr
ttest Conflict if Believer & ID_manipulation!=0, by(ID_manipulation)
esize twosample Conflict if Believer & ID_manipulation!=0, by(ID_manipulation)

	* Expected Cooperation
ci2 Cooperation Expected_Cooperation if Believer & ID_manipulation==1, corr
ci2 Cooperation Expected_Cooperation if Believer & ID_manipulation==2, corr
ttest Expected_Cooperation if Believer & ID_manipulation!=0, by(ID_manipulation)
esize twosample Expected_Cooperation if Believer & ID_manipulation!=0, by(ID_manipulation)

* Pooled data (believers and atheists)

	* Exploratory Models
		
		* Model 1b: Complete
tabstat Cooperation, by(Treatment) stat(mean sd n)
tabstat Cooperation, by(Time_manipulation) stat(mean sd n)
anova Cooperation Believer##ID_manipulation##Time_manipulation Comprehension_Self_Correct Comprehension_Group_Correct Experience
estat esize, level(95)

		* Model 2b: Inexperienced
tabstat Cooperation if Experience==0, by(Treatment) stat(mean sd n)
tabstat Cooperation if Experience==0, by(Time_manipulation) stat(mean sd n)
anova Cooperation Believer##ID_manipulation##Time_manipulation Comprehension_Self_Correct Comprehension_Group_Correct if Experience==0
estat esize, level(95)

		* Model 3b: Comprehended
tabstat Cooperation if Comprehension_Self_Correct & Comprehension_Group_Correct, by(Treatment) stat(mean sd n)
tabstat Cooperation if Comprehension_Self_Correct & Comprehension_Group_Correct, by(Time_manipulation) stat(mean sd n)
anova Cooperation Believer##ID_manipulation##Time_manipulation Experience if Comprehension_Self_Correct & Comprehension_Group_Correct
estat esize, level(95)

		* Model 4b: Current
tabstat Cooperation if Current_Christian_believer & Current_publicly_practicing, by(Treatment) stat(mean sd n)	
tabstat Cooperation if Current_Christian_believer & Current_publicly_practicing, by(Time_manipulation) stat(mean sd n)
anova Cooperation Believer##ID_manipulation##Time_manipulation Comprehension_Self_Correct Comprehension_Group_Correct Experience if Current_belief
estat esize, level(95)		


** F) Supplementary Information

	* Supplementary Table 1: Demographic composition of religious believers

		* Number of observations
tab Time_manipulation ID_manipulation if Believer, row chi2
	
		* Age
tabstat Age if Believer, by(Treatment) 
kwallis Age if Believer, by(Treatment)

		* Proportion of females
tab Treatment Female if Believer, row chi2

		* Social dilemmma comprehension
tab Treatment Comprehension if Believer, row chi2

		* Current practicing believers
tab Treatment Current_practicing_believer if Believer, row chi2

		* Experience with PD
tab Treatment Experience if Believer, row chi2

This tools folder is organized into three layers.

- `information_tools.py`: domain primitives for participant-level cooperation contrasts, religious parochialism gaps, time-pressure effects, conflict/expectation summaries, and artifact generation.
- `data_processing.py`: generic file-listing and text-reading helpers.
- `database_retrieval.py`: local materials/reference inventory and PDF-text helpers.

Use the domain tool to compose the experimental-data reproduction workflow.

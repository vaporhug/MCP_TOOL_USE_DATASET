#!/usr/bin/env python3

from __future__ import annotations

from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

matplotlib.use("Agg")


def _artifact_path(filename: str) -> Path:
    path = Path(__file__).resolve().parents[1] / "artifacts" / filename
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def load_filtered_sample(path: str, believers_only: bool = True) -> dict:
    df = pd.read_excel(path, sheet_name="Data")
    if believers_only:
        df = df[df["Believer"] == 1].copy()
    return {"n_rows": int(len(df)), "columns": list(df.columns), "rows": df.head(8).to_dict("records")}


def cooperation_condition_summary(path: str, believers_only: bool = True) -> dict:
    df = pd.read_excel(path, sheet_name="Data")
    if believers_only:
        df = df[df["Believer"] == 1].copy()
    df["identity"] = df["ID_manipulation"].map({0: "NoID", 1: "InGroup", 2: "OutGroup"})
    df["time"] = df["Time_manipulation"].map({0: "Delay", 1: "Pressure"})
    grouped = (
        df.groupby(["identity", "time"])["Cooperation"]
        .agg(["mean", "median", "count"])
        .reset_index()
        .sort_values(["identity", "time"])
    )
    return {"rows": grouped.to_dict("records")}


def parochialism_gap_summary(path: str, believers_only: bool = True) -> dict:
    df = pd.read_excel(path, sheet_name="Data")
    if believers_only:
        df = df[df["Believer"] == 1].copy()
    ingroup = df[df["ID_manipulation"] == 1]["Cooperation"]
    outgroup = df[df["ID_manipulation"] == 2]["Cooperation"]
    return {
        "ingroup_mean": float(ingroup.mean()),
        "outgroup_mean": float(outgroup.mean()),
        "ingroup_minus_outgroup": float(ingroup.mean() - outgroup.mean()),
        "n_ingroup": int(len(ingroup)),
        "n_outgroup": int(len(outgroup)),
    }


def time_pressure_summary(path: str, believers_only: bool = True) -> dict:
    df = pd.read_excel(path, sheet_name="Data")
    if believers_only:
        df = df[df["Believer"] == 1].copy()
    pressure = df[df["Time_manipulation"] == 1]["Cooperation"]
    delay = df[df["Time_manipulation"] == 0]["Cooperation"]
    return {
        "pressure_mean": float(pressure.mean()),
        "delay_mean": float(delay.mean()),
        "pressure_minus_delay": float(pressure.mean() - delay.mean()),
        "pressure_n": int(len(pressure)),
        "delay_n": int(len(delay)),
    }


def conflict_and_expectation_summary(path: str, believers_only: bool = True) -> dict:
    df = pd.read_excel(path, sheet_name="Data")
    if believers_only:
        df = df[df["Believer"] == 1].copy()
    rows = (
        df.groupby("ID_manipulation")[["Conflict", "Expected_Cooperation"]]
        .mean()
        .rename(index={0: "NoID", 1: "InGroup", 2: "OutGroup"})
        .reset_index()
    )
    rows.columns = ["identity", "mean_conflict", "mean_expected_cooperation"]
    return {"rows": rows.to_dict("records")}


def plot_cooperation_by_condition(path: str, output_filename: str = "cooperation_conditions.png") -> dict:
    rows = cooperation_condition_summary(path)["rows"]
    output = _artifact_path(output_filename)
    fig, ax = plt.subplots(figsize=(7.2, 4.4))
    labels = [f'{r["identity"]}-{r["time"]}' for r in rows]
    vals = [r["mean"] for r in rows]
    ax.bar(labels, vals, color="#4C78A8")
    ax.set_ylabel("Mean cooperation")
    ax.set_title("Cooperation by identity and time condition")
    ax.tick_params(axis="x", rotation=30)
    fig.tight_layout()
    fig.savefig(output, dpi=200)
    plt.close(fig)
    return {"path": str(output), "n_conditions": len(rows)}


def plot_parochialism_gap(path: str, output_filename: str = "parochialism_gap.png") -> dict:
    rows = conflict_and_expectation_summary(path)["rows"]
    output = _artifact_path(output_filename)
    fig, ax = plt.subplots(figsize=(6.8, 4.4))
    ax.bar([r["identity"] for r in rows], [r["mean_expected_cooperation"] for r in rows], color="#F58518", alpha=0.8, label="Expected cooperation")
    ax.plot([r["identity"] for r in rows], [r["mean_conflict"] for r in rows], color="#1f77b4", marker="o", label="Conflict")
    ax.set_title("Identity treatment shifts expectation and conflict")
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(output, dpi=200)
    plt.close(fig)
    return {"path": str(output), "rows": rows}
# Strict reproduction additions: time-pressure contrast artifact and smoke test.
def plot_time_pressure_effect(path: str, output_filename: str = "time_pressure_effect.png") -> dict:
    df = pd.read_excel(path, sheet_name="Data")
    df = df[df["Believer"] == 1].copy()
    df["time"] = df["Time_manipulation"].map({0: "Delay", 1: "Pressure"})
    rows = df.groupby("time")["Cooperation"].agg(["mean", "count"]).reset_index()
    output = _artifact_path(output_filename)
    fig, ax = plt.subplots(figsize=(5.8, 4.2))
    ax.bar(rows["time"], rows["mean"], color=["#4C78A8", "#F58518"])
    ax.set_ylabel("Mean cooperation")
    ax.set_title("Time-pressure manipulation contrast")
    fig.tight_layout()
    fig.savefig(output, dpi=200)
    plt.close(fig)
    return {"path": str(output), "rows": rows.to_dict("records"), **time_pressure_summary(path)}

def package_smoke_test() -> dict:
    root = Path(__file__).resolve().parents[1]
    data = root / "input_data" / "data" / "Isler_et_al_Data.xlsx"
    return {
        "conditions": cooperation_condition_summary(str(data)),
        "parochialism": parochialism_gap_summary(str(data)),
        "time_pressure": time_pressure_summary(str(data)),
        "figures": [plot_cooperation_by_condition(str(data)), plot_parochialism_gap(str(data)), plot_time_pressure_effect(str(data))],
    }

from __future__ import annotations
from pathlib import Path
from zipfile import ZipFile
import io
import re
import sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
try:
    from pypdf import PdfReader
except Exception:
    PdfReader = None

try:
    from .data_processing import data_root, list_files, read_table, workbook_sheets, numeric_columns
    from .database_retrieval import public_repository_links
except ImportError:
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from data_processing import data_root, list_files, read_table, workbook_sheets, numeric_columns
    from database_retrieval import public_repository_links

ARTIFACT_DIR = Path(__file__).resolve().parents[1] / "artifacts"
CONFIG = {'title': 'surprising combinations and scientific outsiders', 'claims': [('context novelty hit multiplier', 'context are on average\\s*(\\w+)\\s*times more likely', 4, 'x'), ('content novelty hit multiplier', 'content combi-?\\s*nations are\\s*(\\w+)\\s*times more likely', 2, 'x'), ('joint novelty hit multiplier', 'content and context combinations are approximately\\s*(\\w+)\\s*times more likely', 5, 'x')], 'source_keywords': ['Figure2a', 'Figure2b', 'Figure2c', 'Figure2d', 'Figure4a', 'Figure4b']}


def _target_pdf() -> Path:
    return Path(__file__).resolve().parents[1] / "input_data" / "reference_paper" / "target.pdf"


def _norm(text: str) -> str:
    repl = {"\ufb01":"fi", "\ufb02":"fl", "−":"-", "–":"-", "—":"-", "\u00a0":" ", "×":"x", "℃":" C", "°C":" C", "ºC":" C"}
    for k, v in repl.items():
        text = text.replace(k, v)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def target_pdf_text(max_pages: int | None = None) -> str:
    if PdfReader is None:
        raise ImportError("pypdf is required to inspect target.pdf")
    reader = PdfReader(str(_target_pdf()))
    parts = []
    pages = reader.pages if max_pages is None else reader.pages[:max_pages]
    for page in pages:
        try:
            parts.append(page.extract_text() or "")
        except Exception:
            continue
    return _norm("\n".join(parts))


def source_inventory(root: str | Path | None = None) -> dict:
    root_path = Path(root) if root else data_root()
    files = list_files(root_path)
    return {"n_files": len(files), "extensions": sorted({Path(f).suffix.lower() for f in files}), "files": [str(Path(f).relative_to(root_path)) for f in files], "repositories": public_repository_links().get("repositories", [])}


def _word_number(token: str) -> float:
    words = {"one":1, "two":2, "three":3, "four":4, "five":5, "six":6, "seven":7, "eight":8, "nine":9, "ten":10}
    t = token.lower().replace(",", "")
    if t in words:
        return float(words[t])
    return float(t)


def paper_claims() -> pd.DataFrame:
    text = target_pdf_text()
    rows = []
    for item in CONFIG["claims"]:
        label, pattern, fixed_value, unit = item
        match = re.search(pattern, text, flags=re.I)
        if fixed_value is not None:
            value = float(fixed_value)
        elif match:
            value = _word_number(match.group(1))
        else:
            value = np.nan
        rows.append({
            "claim": label,
            "value": value,
            "unit": unit,
            "matched": bool(match),
            "evidence_excerpt": text[max(0, match.start()-180): min(len(text), match.end()+180)] if match else "",
        })
    return pd.DataFrame(rows)


def source_data_catalog() -> pd.DataFrame:
    rows = []
    root = data_root()
    for path in sorted(root.rglob("*")):
        if path.is_dir():
            continue
        rel = path.relative_to(root).as_posix()
        if path.suffix.lower() in {".zip"}:
            try:
                with ZipFile(path) as zf:
                    for name in zf.namelist():
                        if name.endswith("/") or "__MACOSX" in name:
                            continue
                        rows.append({"container": rel, "member": name, "kind": Path(name).suffix.lower() or "no_ext", "label": Path(name).stem})
            except Exception as exc:
                rows.append({"container": rel, "member": f"ERROR:{exc}", "kind": ".zip", "label": path.stem})
        else:
            rows.append({"container": "", "member": rel, "kind": path.suffix.lower() or "no_ext", "label": path.stem})
    return pd.DataFrame(rows)


def _panel_label(source, sheet: str) -> str:
    try:
        df = pd.read_excel(source, sheet_name=sheet, nrows=1)
        cols = [str(c) for c in df.columns[:8] if not str(c).startswith("Unnamed")]
        return " | ".join([sheet] + cols)
    except Exception:
        return sheet


def workbook_panel_catalog() -> pd.DataFrame:
    rows = []
    root = data_root()
    for path in sorted(root.rglob("*.csv")):
        try:
            df = pd.read_csv(path, nrows=1)
            cols = [str(c) for c in df.columns[:8]]
            rows.append({"container": path.relative_to(root).as_posix(), "sheet": "", "kind": "csv", "label": path.name + " | " + " | ".join(cols)})
        except Exception:
            rows.append({"container": path.relative_to(root).as_posix(), "sheet": "", "kind": "csv", "label": path.name})
    for path in sorted(root.rglob("*.xlsx")):
        try:
            xl = pd.ExcelFile(path)
            for sh in xl.sheet_names:
                rows.append({"container": path.relative_to(root).as_posix(), "sheet": sh, "kind": "xlsx_sheet", "label": _panel_label(path, sh)})
        except Exception:
            pass
    for path in sorted(root.rglob("*.zip")):
        try:
            with ZipFile(path) as zf:
                for name in zf.namelist():
                    if name.lower().endswith((".xlsx", ".xls")) and "__MACOSX" not in name:
                        data = zf.read(name)
                        try:
                            xl = pd.ExcelFile(io.BytesIO(data))
                            for sh in xl.sheet_names:
                                rows.append({"container": path.relative_to(root).as_posix() + "!" + name, "sheet": sh, "kind": "zip_xlsx_sheet", "label": _panel_label(io.BytesIO(data), sh)})
                        except Exception:
                            rows.append({"container": path.relative_to(root).as_posix() + "!" + name, "sheet": "", "kind": "zip_xlsx", "label": Path(name).stem})
                    elif name.lower().endswith((".csv", ".tsv", ".fyp")) and "__MACOSX" not in name:
                        rows.append({"container": path.relative_to(root).as_posix() + "!" + name, "sheet": "", "kind": Path(name).suffix.lower(), "label": Path(name).stem})
        except Exception:
            pass
    return pd.DataFrame(rows)


def _read_first_numeric_panel() -> tuple[str, pd.DataFrame]:
    root = data_root()
    candidates = []
    for p in sorted(root.rglob("*.csv")):
        candidates.append((p.relative_to(root).as_posix(), p, None))
    for p in sorted(root.rglob("*.xlsx")):
        try:
            for sh in pd.ExcelFile(p).sheet_names:
                candidates.append((p.relative_to(root).as_posix()+"::"+sh, p, sh))
        except Exception:
            pass
    for label, path, sheet in candidates[:80]:
        try:
            df = pd.read_csv(path) if path.suffix.lower() == ".csv" else pd.read_excel(path, sheet_name=sheet)
            nums = [c for c in df.columns if pd.to_numeric(df[c], errors="coerce").notna().sum() >= 3]
            if nums:
                return label, df[nums[:6]].apply(pd.to_numeric, errors="coerce")
        except Exception:
            continue
    for zip_path in sorted(root.rglob("*.zip")):
        try:
            with ZipFile(zip_path) as zf:
                for name in zf.namelist():
                    if "__MACOSX" in name:
                        continue
                    lower = name.lower()
                    if lower.endswith(".csv") or lower.endswith(".tsv"):
                        try:
                            sep = "\t" if lower.endswith(".tsv") else ","
                            df = pd.read_csv(io.BytesIO(zf.read(name)), sep=sep)
                            nums = [c for c in df.columns if pd.to_numeric(df[c], errors="coerce").notna().sum() >= 3]
                            if nums:
                                return zip_path.relative_to(root).as_posix()+"!"+name, df[nums[:6]].apply(pd.to_numeric, errors="coerce")
                        except Exception:
                            pass
                    if lower.endswith(".xlsx"):
                        try:
                            data = zf.read(name)
                            xl = pd.ExcelFile(io.BytesIO(data))
                            keywords = CONFIG.get("source_keywords", [])
                            sheets = sorted(xl.sheet_names, key=lambda s: 0 if any(k.lower() in s.lower() for k in keywords) else 1)
                            for sh in sheets:
                                df = pd.read_excel(io.BytesIO(data), sheet_name=sh)
                                nums = [c for c in df.columns if pd.to_numeric(df[c], errors="coerce").notna().sum() >= 3]
                                if nums:
                                    return zip_path.relative_to(root).as_posix()+"!"+name+"::"+sh, df[nums[:6]].apply(pd.to_numeric, errors="coerce")
                        except Exception:
                            pass
        except Exception:
            pass
    return "none", pd.DataFrame()


def plot_paper_metrics(output_filename: str = "Fig1_info_5c3f_hit_novelty_metrics.png") -> dict:
    df = paper_claims()
    out = ARTIFACT_DIR / output_filename
    out.parent.mkdir(parents=True, exist_ok=True)
    plot_df = df.copy()
    plot_df["value_plot"] = pd.to_numeric(plot_df["value"], errors="coerce").fillna(0)
    fig, ax = plt.subplots(figsize=(9.5, 4.8))
    ax.bar(range(len(plot_df)), plot_df["value_plot"], color="#3d6f88")
    ax.set_xticks(range(len(plot_df)))
    ax.set_xticklabels(plot_df["claim"], rotation=35, ha="right", fontsize=8)
    ax.set_ylabel("reported value or binary evidence")
    ax.set_title(CONFIG["title"])
    fig.tight_layout()
    fig.savefig(out, dpi=180)
    plt.close(fig)
    return {"path": str(out), "rows": int(len(df)), "matched": int(df["matched"].sum())}


def plot_source_panels(output_filename: str = "Fig2_info_5c3f_source_panels.png") -> dict:
    catalog = workbook_panel_catalog()
    if catalog.empty:
        catalog = source_data_catalog()
    out = ARTIFACT_DIR / output_filename
    out.parent.mkdir(parents=True, exist_ok=True)
    labels = catalog["label"].astype(str).head(40).tolist()
    keywords = CONFIG.get("source_keywords", [])
    scores = [sum(1 for k in keywords if k.lower() in lab.lower()) for lab in labels]
    if not labels:
        labels, scores = ["no source panels"], [0]
    fig, ax = plt.subplots(figsize=(9.5, 4.8))
    colors = ["#4f8f5b" if s else "#b8b8b8" for s in scores]
    ax.bar(range(len(labels)), [s if s else 0.2 for s in scores], color=colors)
    ax.set_xticks(range(len(labels)))
    ax.set_xticklabels(labels, rotation=60, ha="right", fontsize=7)
    ax.set_ylabel("keyword panel match / source presence")
    ax.set_title("Local source-data panels relevant to the requested workflow")
    fig.tight_layout()
    fig.savefig(out, dpi=180)
    plt.close(fig)
    return {"path": str(out), "catalog_rows": int(len(catalog)), "keyword_hits": int(sum(1 for s in scores if s))}


def plot_source_numeric_panel(output_filename: str = "Fig3_info_5c3f_panel_numeric.png") -> dict:
    label, df = _read_first_numeric_panel()
    out = ARTIFACT_DIR / output_filename
    out.parent.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(8.8, 4.8))
    if df.empty:
        claims = paper_claims()
        vals = pd.to_numeric(claims["value"], errors="coerce").fillna(0)
        ax.plot(range(len(vals)), vals, marker="o")
        ax.set_xticks(range(len(vals)))
        ax.set_xticklabels(claims["claim"], rotation=35, ha="right", fontsize=8)
        plotted = "paper claims fallback"
    else:
        cols = list(df.columns[:4])
        for col in cols:
            series = pd.to_numeric(df[col], errors="coerce").dropna().head(80).to_numpy()
            if len(series):
                ax.plot(np.arange(len(series)), series, marker="o", ms=2, lw=1, label=str(col)[:24])
        ax.legend(fontsize=7, frameon=False)
        plotted = label
    ax.set_title("Representative numeric source-data panel")
    ax.set_xlabel("row index")
    ax.set_ylabel("source value")
    fig.tight_layout()
    fig.savefig(out, dpi=180)
    plt.close(fig)
    return {"path": str(out), "source_panel": plotted, "rows": int(len(df)) if not df.empty else 0}


def package_smoke_test() -> dict:
    claims = paper_claims()
    catalog = workbook_panel_catalog()
    inv = source_inventory()
    return {"claims": claims[["claim", "value", "unit", "matched"]].to_dict(orient="records"), "source_panels": int(len(catalog)), "inventory_files": inv["n_files"], "plot_functions": ["plot_paper_metrics", "plot_source_panels", "plot_source_numeric_panel"]}

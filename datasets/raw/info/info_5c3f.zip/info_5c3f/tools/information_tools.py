from __future__ import annotations
from pathlib import Path
from zipfile import ZipFile
import io
import re
import sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
try:
    from pypdf import PdfReader
except Exception:
    PdfReader = None

try:
    from .data_processing import data_root, list_files, read_table, workbook_sheets, numeric_columns
    from .database_retrieval import public_repository_links
except ImportError:
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from data_processing import data_root, list_files, read_table, workbook_sheets, numeric_columns
    from database_retrieval import public_repository_links

ARTIFACT_DIR = Path(__file__).resolve().parents[1] / "artifacts"
CONFIG = {'title': 'paper evidence extraction'}


def _target_pdf() -> Path:
    return Path(__file__).resolve().parents[1] / "input_data" / "reference_paper" / "target.pdf"


def _norm(text: str) -> str:
    repl = {"\ufb01":"fi", "\ufb02":"fl", "−":"-", "–":"-", "—":"-", "\u00a0":" ", "×":"x", "℃":" C", "°C":" C", "ºC":" C"}
    for k, v in repl.items():
        text = text.replace(k, v)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def target_pdf_text(max_pages: int | None = None) -> str:
    if PdfReader is None:
        raise ImportError("pypdf is required to inspect target.pdf")
    reader = PdfReader(str(_target_pdf()))
    parts = []
    pages = reader.pages if max_pages is None else reader.pages[:max_pages]
    for page in pages:
        try:
            parts.append(page.extract_text() or "")
        except Exception:
            continue
    return _norm("\n".join(parts))


def source_inventory(root: str | Path | None = None) -> dict:
    root_path = Path(root) if root else data_root()
    files = list_files(root_path)
    return {"n_files": len(files), "extensions": sorted({Path(f).suffix.lower() for f in files}), "files": [str(Path(f).relative_to(root_path)) for f in files], "repositories": public_repository_links().get("repositories", [])}


def _word_number(token: str) -> float:
    words = {"one":1, "two":2, "three":3, "four":4, "five":5, "six":6, "seven":7, "eight":8, "nine":9, "ten":10}
    t = token.lower().replace(",", "")
    if t in words:
        return float(words[t])
    return float(t)


def paper_claims(search_terms: list[str] | None = None, max_mentions: int = 40) -> pd.DataFrame:
    """Extract numeric paper evidence snippets without hard-coded final answers.

    Args:
        search_terms: optional terms that must appear in the local context.
        max_mentions: maximum numeric mentions to return.
    """
    text = target_pdf_text()
    terms = [t.lower() for t in (search_terms or [])]
    number_re = re.compile(r"(?P<value>[-+]?\d[\d,]*(?:\.\d+)?)(?:\s*(?P<unit>%|mAh\s*cm-2|mg\s*cm-2|Wh\s*L-1|mW\s*cm-2|A\s*mg\w*-1|V|cycles?|h|hours?|publications?|x|fold))?", re.I)
    rows = []
    seen = set()
    for match in number_re.finditer(text):
        start = max(0, match.start() - 180)
        end = min(len(text), match.end() + 180)
        context = text[start:end]
        if terms and not any(term in context.lower() for term in terms):
            continue
        raw = match.group("value")
        key = (raw, match.group("unit") or "", context[:80])
        if key in seen:
            continue
        seen.add(key)
        try:
            value = float(raw.replace(",", ""))
        except ValueError:
            continue
        rows.append({
            "claim": context.strip()[:120],
            "value": value,
            "unit": match.group("unit") or "",
            "matched": True,
            "evidence_excerpt": context.strip(),
        })
        if len(rows) >= max_mentions:
            break
    return pd.DataFrame(rows)


def source_data_catalog() -> pd.DataFrame:
    rows = []
    root = data_root()
    for path in sorted(root.rglob("*")):
        if path.is_dir():
            continue
        rel = path.relative_to(root).as_posix()
        if path.suffix.lower() in {".zip"}:
            try:
                with ZipFile(path) as zf:
                    for name in zf.namelist():
                        if name.endswith("/") or "__MACOSX" in name:
                            continue
                        rows.append({"container": rel, "member": name, "kind": Path(name).suffix.lower() or "no_ext", "label": Path(name).stem})
            except Exception as exc:
                rows.append({"container": rel, "member": f"ERROR:{exc}", "kind": ".zip", "label": path.stem})
        else:
            rows.append({"container": "", "member": rel, "kind": path.suffix.lower() or "no_ext", "label": path.stem})
    return pd.DataFrame(rows)


def _panel_label(source, sheet: str) -> str:
    try:
        df = pd.read_excel(source, sheet_name=sheet, nrows=1)
        cols = [str(c) for c in df.columns[:8] if not str(c).startswith("Unnamed")]
        return " | ".join([sheet] + cols)
    except Exception:
        return sheet


def workbook_panel_catalog() -> pd.DataFrame:
    rows = []
    root = data_root()
    for path in sorted(root.rglob("*.csv")):
        try:
            df = pd.read_csv(path, nrows=1)
            cols = [str(c) for c in df.columns[:8]]
            rows.append({"container": path.relative_to(root).as_posix(), "sheet": "", "kind": "csv", "label": path.name + " | " + " | ".join(cols)})
        except Exception:
            rows.append({"container": path.relative_to(root).as_posix(), "sheet": "", "kind": "csv", "label": path.name})
    for path in sorted(root.rglob("*.xlsx")):
        try:
            xl = pd.ExcelFile(path)
            for sh in xl.sheet_names:
                rows.append({"container": path.relative_to(root).as_posix(), "sheet": sh, "kind": "xlsx_sheet", "label": _panel_label(path, sh)})
        except Exception:
            pass
    for path in sorted(root.rglob("*.zip")):
        try:
            with ZipFile(path) as zf:
                for name in zf.namelist():
                    if name.lower().endswith((".xlsx", ".xls")) and "__MACOSX" not in name:
                        data = zf.read(name)
                        try:
                            xl = pd.ExcelFile(io.BytesIO(data))
                            for sh in xl.sheet_names:
                                rows.append({"container": path.relative_to(root).as_posix() + "!" + name, "sheet": sh, "kind": "zip_xlsx_sheet", "label": _panel_label(io.BytesIO(data), sh)})
                        except Exception:
                            rows.append({"container": path.relative_to(root).as_posix() + "!" + name, "sheet": "", "kind": "zip_xlsx", "label": Path(name).stem})
                    elif name.lower().endswith((".csv", ".tsv", ".fyp")) and "__MACOSX" not in name:
                        rows.append({"container": path.relative_to(root).as_posix() + "!" + name, "sheet": "", "kind": Path(name).suffix.lower(), "label": Path(name).stem})
        except Exception:
            pass
    return pd.DataFrame(rows)


def _read_first_numeric_panel() -> tuple[str, pd.DataFrame]:
    root = data_root()
    candidates = []
    for p in sorted(root.rglob("*.csv")):
        candidates.append((p.relative_to(root).as_posix(), p, None))
    for p in sorted(root.rglob("*.xlsx")):
        try:
            for sh in pd.ExcelFile(p).sheet_names:
                candidates.append((p.relative_to(root).as_posix()+"::"+sh, p, sh))
        except Exception:
            pass
    for label, path, sheet in candidates[:80]:
        try:
            df = pd.read_csv(path) if path.suffix.lower() == ".csv" else pd.read_excel(path, sheet_name=sheet)
            nums = [c for c in df.columns if pd.to_numeric(df[c], errors="coerce").notna().sum() >= 3]
            if nums:
                return label, df[nums[:6]].apply(pd.to_numeric, errors="coerce")
        except Exception:
            continue
    for zip_path in sorted(root.rglob("*.zip")):
        try:
            with ZipFile(zip_path) as zf:
                for name in zf.namelist():
                    if "__MACOSX" in name:
                        continue
                    lower = name.lower()
                    if lower.endswith(".csv") or lower.endswith(".tsv"):
                        try:
                            sep = "\t" if lower.endswith(".tsv") else ","
                            df = pd.read_csv(io.BytesIO(zf.read(name)), sep=sep)
                            nums = [c for c in df.columns if pd.to_numeric(df[c], errors="coerce").notna().sum() >= 3]
                            if nums:
                                return zip_path.relative_to(root).as_posix()+"!"+name, df[nums[:6]].apply(pd.to_numeric, errors="coerce")
                        except Exception:
                            pass
                    if lower.endswith(".xlsx"):
                        try:
                            data = zf.read(name)
                            xl = pd.ExcelFile(io.BytesIO(data))
                            keywords = []
                            sheets = sorted(xl.sheet_names, key=lambda s: 1)
                            for sh in sheets:
                                df = pd.read_excel(io.BytesIO(data), sheet_name=sh)
                                nums = [c for c in df.columns if pd.to_numeric(df[c], errors="coerce").notna().sum() >= 3]
                                if nums:
                                    return zip_path.relative_to(root).as_posix()+"!"+name+"::"+sh, df[nums[:6]].apply(pd.to_numeric, errors="coerce")
                        except Exception:
                            pass
        except Exception:
            pass
    return "none", pd.DataFrame()


def novelty_source_zip() -> Path:
    matches = sorted(data_root().glob("41467_2023_36741_MOESM4_ESM.zip"))
    if not matches:
        raise FileNotFoundError("Expected source-data zip 41467_2023_36741_MOESM4_ESM.zip")
    return matches[0]


def figure_source_index(target_figures: list[str] | None = None) -> pd.DataFrame:
    """Index source-data members for target paper figures without reading sparse placeholder arrays blindly."""
    target_figures = target_figures or ["Figure2", "Figure3", "Figure4"]
    rows = []
    with ZipFile(novelty_source_zip()) as zf:
        for info in zf.infolist():
            name = info.filename
            if name.endswith("/") or "__MACOSX" in name:
                continue
            fig = Path(name).stem.replace("_", " ")
            selected = any(t.lower() in Path(name).stem.lower().replace("_", "") for t in target_figures)
            rows.append({"member": name, "figure": fig, "uncompressed_bytes": info.file_size, "compressed_bytes": info.compress_size, "selected": selected})
    return pd.DataFrame(rows)


def paper_novelty_evidence() -> pd.DataFrame:
    """Return paper-native novelty, outsider, and patent evidence with numeric anchors.

    The table is built from target.pdf language rather than source-file sizes.
    Word-number multipliers such as "two/four/five times" are normalized so
    downstream plots can use the paper's scientific evidence directly.
    """
    text = target_pdf_text()
    rows = []
    patterns = [
        ("context novelty", r"context[^.]{0,120}?four times", 4.0, "hit-probability multiplier"),
        ("content novelty", r"content[^.]{0,120}?two times", 2.0, "hit-probability multiplier"),
        ("joint content/context novelty", r"content and context[^.]{0,120}?five times", 5.0, "hit-probability multiplier"),
        ("highest joint novelty hit share", r"nearly 50%[^.]{0,120}?highest joint content and context novelties", 50.0, "percent hit papers"),
        ("outsider / expedition mechanism", r"surprising research expedition[^.]{0,260}?distant audience", 1.0, "paper mechanism present"),
        ("patent caveat", r"patent[^.]{0,260}?context", 1.0, "paper caveat present"),
    ]
    lower = text.lower()
    for label, pattern, value, unit in patterns:
        match = re.search(pattern, lower, flags=re.I)
        if match:
            start, end = match.span()
            excerpt = text[max(0, start - 120): min(len(text), end + 160)]
        else:
            idx = lower.find(label.split()[0])
            excerpt = text[max(0, idx - 120): idx + 260] if idx >= 0 else ""
        rows.append({"evidence": label, "value": value, "unit": unit, "evidence_excerpt": _norm(excerpt), "matched": bool(excerpt)})
    return pd.DataFrame(rows)


def readable_figure_source(member: str, max_bytes: int = 2_000_000) -> pd.DataFrame:
    """Read a small text source-data member; raise on sparse placeholder files instead of silently plotting zeros."""
    with ZipFile(novelty_source_zip()) as zf:
        info = zf.getinfo(member)
        if info.file_size > max_bytes and info.compress_size / max(info.file_size, 1) < 0.01:
            raise ValueError(f"{member} is a sparse/placeholder source array; use figure_source_index for provenance")
        raw = zf.read(member)
    sep = "\t" if member.lower().endswith(".tsv") else ","
    return pd.read_csv(io.BytesIO(raw), sep=sep, encoding="utf-8", engine="python", on_bad_lines="skip")


def plot_paper_metrics(output_filename: str = "Fig1_info_5c3f_hit_novelty_metrics.png") -> dict:
    evidence = paper_novelty_evidence()
    out = ARTIFACT_DIR / output_filename
    out.parent.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(10, 5))
    hit = evidence[evidence["unit"].str.contains("multiplier|percent", na=False)]
    vals = pd.to_numeric(hit["value"], errors="coerce").fillna(0)
    ax.bar(range(len(hit)), vals, color="#2f6f4e")
    ax.axhline(1, color="#333333", lw=0.8, ls="--")
    ax.set_xticks(range(len(hit)))
    ax.set_xticklabels(hit["evidence"], rotation=25, ha="right", fontsize=9)
    ax.set_ylabel("paper-reported multiplier or percent")
    ax.set_title("Novelty metrics tied to hit-paper probability")
    fig.tight_layout()
    fig.savefig(out, dpi=180)
    plt.close(fig)
    return {"path": str(out), "evidence": hit.to_dict(orient="records")}


def plot_source_panels(output_filename: str = "Fig2_info_5c3f_source_panels.png", keywords: list[str] | None = None) -> dict:
    evidence = paper_novelty_evidence()
    source_idx = figure_source_index(["Figure2", "Figure3", "Figure4"])
    selected = source_idx[source_idx["selected"]]
    out = ARTIFACT_DIR / output_filename
    out.parent.mkdir(parents=True, exist_ok=True)
    categories = evidence[evidence["evidence"].str.contains("outsider|expedition|patent", case=False, na=False)]
    fig, ax = plt.subplots(figsize=(8.8, 4.8))
    ax.bar(categories["evidence"], categories["value"], color=["#f58518", "#e45756"][:len(categories)])
    ax.set_xticks(range(len(evidence)))
    ax.set_xticks(range(len(categories)))
    ax.set_xticklabels(categories["evidence"], rotation=25, ha="right", fontsize=9)
    ax.set_ylabel("paper mechanism/caveat present")
    ax.set_title("Outsider/expedition and patent-caveat evidence, with Figure 2/3/4 source provenance")
    fig.tight_layout()
    fig.savefig(out, dpi=180)
    plt.close(fig)
    return {"path": str(out), "target_source_files": int(len(selected)), "evidence": categories.to_dict(orient="records")}


def plot_source_numeric_panel(output_filename: str = "Fig3_info_5c3f_panel_numeric.png") -> dict:
    evidence = paper_novelty_evidence()
    plot_df = evidence[evidence["unit"].str.contains("multiplier", na=False)].copy()
    out = ARTIFACT_DIR / output_filename
    out.parent.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(8.8, 4.8))
    ax.plot(plot_df["evidence"], plot_df["value"], marker="o", lw=2, color="#4c78a8")
    ax.set_xticks(range(len(plot_df)))
    ax.set_xticklabels(plot_df["evidence"], rotation=25, ha="right", fontsize=9)
    ax.set_ylabel("relative hit-paper probability")
    ax.set_title("Paper-reported content, context, and joint novelty multipliers")
    fig.tight_layout()
    fig.savefig(out, dpi=180)
    plt.close(fig)
    return {"path": str(out), "multipliers": plot_df.to_dict(orient="records")}


def package_smoke_test() -> dict:
    idx = figure_source_index()
    ev = paper_novelty_evidence()
    return {"source_zip": novelty_source_zip().name, "target_source_files": int(idx["selected"].sum()), "evidence": ev.to_dict(orient="records"), "plot_functions": ["plot_paper_metrics", "plot_source_panels", "plot_source_numeric_panel"]}

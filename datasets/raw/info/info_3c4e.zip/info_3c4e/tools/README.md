
# Tools

- `data_processing.py`: CSV/table readers and plot output helpers.
- `database_retrieval.py`: local file inventory helpers for the citation-diversity bundle.
- `information_tools.py`: OA vs NOA diversity, citation-count stratification, and field-level comparison primitives.
  - Includes `build_oa_diversity_checkpoints(...)` to compute checkpoint rows (year,
    citation-count, field-gap, and subregion Shannon gap) and write
    `artifacts/checkpoints.csv`.

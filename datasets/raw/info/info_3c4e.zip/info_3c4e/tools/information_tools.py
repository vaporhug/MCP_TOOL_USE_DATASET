
from __future__ import annotations

from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def _repo(data_root: str) -> Path:
    p = Path(data_root)
    if (p / 'Curtin-Open-Knowledge-Initiative-citation-diversity-ee3e8e0').exists():
        return p / 'Curtin-Open-Knowledge-Initiative-citation-diversity-ee3e8e0' / 'tempdata'
    if (p / 'tempdata').exists():
        return p / 'tempdata'
    return p


def oa_diversity_gap_summary(data_root: str) -> dict:
    temp = _repo(data_root)
    df = pd.read_csv(temp / 'summary_stats_by_year_atleast2cit.csv')
    df = df.copy()
    df['country_gap'] = df['oa_Countries_Shannon_mean'] - df['noa_Countries_Shannon_mean']
    df['institution_gap'] = df['oa_Institutions_Shannon_mean'] - df['noa_Institutions_Shannon_mean']
    df['subregion_gap'] = df['oa_Subregions_Shannon_mean'] - df['noa_Subregions_Shannon_mean']
    df['region_gap'] = df['oa_Regions_Shannon_mean'] - df['noa_Regions_Shannon_mean']
    df['field_gap'] = df['oa_Fields_Shannon_mean'] - df['noa_Fields_Shannon_mean']
    return {
        'yearly_gaps': df[['year', 'country_gap', 'institution_gap', 'subregion_gap', 'region_gap', 'field_gap']].to_dict('records'),
        'mean_country_gap': float(df['country_gap'].mean()),
        'mean_institution_gap': float(df['institution_gap'].mean()),
        'mean_subregion_gap': float(df['subregion_gap'].mean()),
        'mean_region_gap': float(df['region_gap'].mean()),
        'mean_field_gap': float(df['field_gap'].mean()),
        'latest_year': int(df['year'].max()),
        'latest_year_country_gap': float(df.loc[df['year'] == df['year'].max(), 'country_gap'].iloc[0]),
        'latest_year_institution_gap': float(df.loc[df['year'] == df['year'].max(), 'institution_gap'].iloc[0]),
        'latest_year_subregion_gap': float(df.loc[df['year'] == df['year'].max(), 'subregion_gap'].iloc[0]),
        'latest_year_region_gap': float(df.loc[df['year'] == df['year'].max(), 'region_gap'].iloc[0]),
        'latest_year_field_gap': float(df.loc[df['year'] == df['year'].max(), 'field_gap'].iloc[0]),
    }


def citation_count_diversity_summary(data_root: str) -> dict:
    temp = _repo(data_root)
    df = pd.read_csv(temp / 'cit_div_vs_cit_count.csv')
    # Aggregate over years and summarize the monotone relationship for countries Shannon.
    g = df.groupby('CitationCount', as_index=False)['CitingCountries_Shannon_perc50'].median()
    low = float(g['CitingCountries_Shannon_perc50'].iloc[0])
    high = float(g['CitingCountries_Shannon_perc50'].iloc[-1])
    return {
        'rows': int(len(df)),
        'citation_count_min': int(df['CitationCount'].min()),
        'citation_count_max': int(df['CitationCount'].max()),
        'median_country_shannon_first': low,
        'median_country_shannon_last': high,
        'median_country_shannon_trajectory_sample': g.head(10).to_dict('records'),
    }


def field_diversity_summary(data_root: str) -> dict:
    temp = _repo(data_root)
    df = pd.read_csv(temp / 'cit_div_by_field.csv')
    latest = df[df['year'] == df['year'].max()].copy()
    latest['country_gap'] = latest['oa_CitingCountries_Shannon_mean'] - latest['noa_CitingCountries_Shannon_mean']
    top = latest.sort_values('country_gap', ascending=False).head(8)
    return {
        'latest_year': int(latest['year'].max()),
        'top_country_gaps': top[['field', 'country_gap', 'oa_CitingCountries_Shannon_mean', 'noa_CitingCountries_Shannon_mean']].to_dict('records'),
    }


def subregion_diversity_summary(data_root: str) -> dict:
    temp = _repo(data_root)
    df = pd.read_csv(temp / 'summary_stats_by_subregion_atleast2cit.csv')
    # Build Shannon diversity per (cited_subregion, year, OA-status) from citing-subregion counts.
    g = (
        df.groupby(['subregion_cited', 'year', 'is_oa', 'subregion_citing'], as_index=False)['subregion_citing_count']
        .sum()
    )
    rows = []
    for (subregion, year, is_oa), chunk in g.groupby(['subregion_cited', 'year', 'is_oa']):
        counts = chunk['subregion_citing_count'].to_numpy(dtype=float)
        total = counts.sum()
        if total <= 0:
            continue
        probs = counts / total
        shannon = float(-(probs * np.log(probs)).sum())
        rows.append({'subregion_cited': subregion, 'year': int(year), 'is_oa': bool(is_oa), 'shannon': shannon})

    sh = pd.DataFrame(rows)
    if sh.empty:
        return {'rows': 0, 'latest_year': None, 'top_subregions': []}

    latest_year = int(sh['year'].max())
    latest = sh[sh['year'] == latest_year]
    oa = latest[latest['is_oa']][['subregion_cited', 'shannon']].rename(columns={'shannon': 'oa_shannon'})
    noa = latest[~latest['is_oa']][['subregion_cited', 'shannon']].rename(columns={'shannon': 'noa_shannon'})
    merged = oa.merge(noa, on='subregion_cited', how='inner')
    merged['oa_minus_noa_gap'] = merged['oa_shannon'] - merged['noa_shannon']
    top = merged.sort_values('oa_minus_noa_gap', ascending=False).head(10)

    return {
        'rows': int(len(sh)),
        'latest_year': latest_year,
        'top_subregions': top[['subregion_cited', 'oa_shannon', 'noa_shannon', 'oa_minus_noa_gap']].to_dict('records'),
    }


def plot_oa_noa_diversity(data_root: str, output_path: str) -> dict:
    temp = _repo(data_root)
    df = pd.read_csv(temp / 'summary_stats_by_year_atleast2cit.csv')
    fig, ax = plt.subplots(figsize=(8.5, 4.8))
    ax.plot(df['year'], df['oa_Countries_Shannon_mean'], marker='o', label='OA', color='#2b8cbe')
    ax.plot(df['year'], df['noa_Countries_Shannon_mean'], marker='o', label='Non-OA', color='#de2d26')
    ax.set_xlabel('Year')
    ax.set_ylabel('Mean citing-country Shannon diversity')
    ax.legend()
    plt.tight_layout()
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output_path, dpi=200)
    plt.close()
    return {'path': output_path}


def plot_citation_count_diversity(data_root: str, output_path: str) -> dict:
    temp = _repo(data_root)
    df = pd.read_csv(temp / 'cit_div_vs_cit_count.csv')
    sample = df.groupby('CitationCount', as_index=False)['CitingCountries_Shannon_perc50'].median()
    fig, ax = plt.subplots(figsize=(8.5, 4.8))
    ax.plot(sample['CitationCount'], sample['CitingCountries_Shannon_perc50'], color='#31a354')
    ax.set_xlabel('Citation count')
    ax.set_ylabel('Median citing-country Shannon diversity')
    ax.set_xscale('log')
    plt.tight_layout()
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output_path, dpi=200)
    plt.close()
    return {'path': output_path}


def plot_field_gaps(data_root: str, output_path: str) -> dict:
    temp = _repo(data_root)
    df = pd.read_csv(temp / 'cit_div_by_field.csv')
    latest = df[df['year'] == df['year'].max()].copy()
    latest['gap'] = latest['oa_CitingCountries_Shannon_mean'] - latest['noa_CitingCountries_Shannon_mean']
    d = latest.sort_values('gap', ascending=False).head(10)
    plt.figure(figsize=(10, 5))
    plt.barh(d['field'][::-1], d['gap'][::-1], color='#756bb1')
    plt.xlabel('OA minus non-OA citing-country Shannon')
    plt.tight_layout()
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output_path, dpi=200)
    plt.close()
    return {'path': output_path}


def package_smoke_test(data_root: str, artifact_dir: str) -> dict:
    a = oa_diversity_gap_summary(data_root)
    b = citation_count_diversity_summary(data_root)
    c = field_diversity_summary(data_root)
    s = subregion_diversity_summary(data_root)
    p1 = plot_oa_noa_diversity(data_root, str(Path(artifact_dir) / 'oa_noa_diversity.png'))
    p2 = plot_citation_count_diversity(data_root, str(Path(artifact_dir) / 'citation_count_diversity.png'))
    p3 = plot_field_gaps(data_root, str(Path(artifact_dir) / 'field_diversity_gaps.png'))
    return {'oa_gap': a, 'citation_count': b, 'field_gap': c, 'subregion_gap': s, 'plots': [p1['path'], p2['path'], p3['path']]}

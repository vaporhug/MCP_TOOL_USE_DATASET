
from __future__ import annotations

from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def _repo(data_root: str) -> Path:
    p = Path(data_root)
    if (p / 'Curtin-Open-Knowledge-Initiative-citation-diversity-ee3e8e0').exists():
        return p / 'Curtin-Open-Knowledge-Initiative-citation-diversity-ee3e8e0' / 'tempdata'
    if (p / 'tempdata').exists():
        return p / 'tempdata'
    if (p / 'data' / 'summary_stats_by_year_atleast2cit.csv').exists():
        return p / 'data'
    return p


def oa_diversity_gap_summary(data_root: str) -> dict:
    temp = _repo(data_root)
    df = pd.read_csv(temp / 'summary_stats_by_year_atleast2cit.csv')
    df = df.copy()
    df['country_gap'] = df['oa_Countries_Shannon_mean'] - df['noa_Countries_Shannon_mean']
    df['institution_gap'] = df['oa_Institutions_Shannon_mean'] - df['noa_Institutions_Shannon_mean']
    df['subregion_gap'] = df['oa_Subregions_Shannon_mean'] - df['noa_Subregions_Shannon_mean']
    df['region_gap'] = df['oa_Regions_Shannon_mean'] - df['noa_Regions_Shannon_mean']
    df['field_gap'] = df['oa_Fields_Shannon_mean'] - df['noa_Fields_Shannon_mean']
    return {
        'yearly_gaps': df[['year', 'country_gap', 'institution_gap', 'subregion_gap', 'region_gap', 'field_gap']].to_dict('records'),
        'mean_country_gap': float(df['country_gap'].mean()),
        'mean_institution_gap': float(df['institution_gap'].mean()),
        'mean_subregion_gap': float(df['subregion_gap'].mean()),
        'mean_region_gap': float(df['region_gap'].mean()),
        'mean_field_gap': float(df['field_gap'].mean()),
        'latest_year': int(df['year'].max()),
        'latest_year_country_gap': float(df.loc[df['year'] == df['year'].max(), 'country_gap'].iloc[0]),
        'latest_year_institution_gap': float(df.loc[df['year'] == df['year'].max(), 'institution_gap'].iloc[0]),
        'latest_year_subregion_gap': float(df.loc[df['year'] == df['year'].max(), 'subregion_gap'].iloc[0]),
        'latest_year_region_gap': float(df.loc[df['year'] == df['year'].max(), 'region_gap'].iloc[0]),
        'latest_year_field_gap': float(df.loc[df['year'] == df['year'].max(), 'field_gap'].iloc[0]),
    }


def citation_count_diversity_summary(data_root: str) -> dict:
    temp = _repo(data_root)
    df = pd.read_csv(temp / 'cit_div_vs_cit_count.csv')
    # Aggregate over years and summarize the monotone relationship for countries Shannon.
    g = df.groupby('CitationCount', as_index=False)['CitingCountries_Shannon_perc50'].median()
    low = float(g['CitingCountries_Shannon_perc50'].iloc[0])
    high = float(g['CitingCountries_Shannon_perc50'].iloc[-1])
    return {
        'rows': int(len(df)),
        'citation_count_min': int(df['CitationCount'].min()),
        'citation_count_max': int(df['CitationCount'].max()),
        'median_country_shannon_first': low,
        'median_country_shannon_last': high,
        'median_country_shannon_trajectory_sample': g.head(10).to_dict('records'),
    }


def field_diversity_summary(data_root: str) -> dict:
    temp = _repo(data_root)
    df = pd.read_csv(temp / 'cit_div_by_field.csv')
    latest = df[df['year'] == df['year'].max()].copy()
    latest['country_gap'] = latest['oa_CitingCountries_Shannon_mean'] - latest['noa_CitingCountries_Shannon_mean']
    top = latest.sort_values('country_gap', ascending=False).head(8)
    return {
        'latest_year': int(latest['year'].max()),
        'top_country_gaps': top[['field', 'country_gap', 'oa_CitingCountries_Shannon_mean', 'noa_CitingCountries_Shannon_mean']].to_dict('records'),
    }


def subregion_diversity_summary(data_root: str) -> dict:
    temp = _repo(data_root)
    df = pd.read_csv(temp / 'summary_stats_by_subregion_atleast2cit.csv')
    # Build Shannon diversity per (cited_subregion, year, OA-status) from citing-subregion counts.
    g = (
        df.groupby(['subregion_cited', 'year', 'is_oa', 'subregion_citing'], as_index=False)['subregion_citing_count']
        .sum()
    )
    rows = []
    for (subregion, year, is_oa), chunk in g.groupby(['subregion_cited', 'year', 'is_oa']):
        counts = chunk['subregion_citing_count'].to_numpy(dtype=float)
        total = counts.sum()
        if total <= 0:
            continue
        probs = counts / total
        shannon = float(-(probs * np.log(probs)).sum())
        rows.append({'subregion_cited': subregion, 'year': int(year), 'is_oa': bool(is_oa), 'shannon': shannon})

    sh = pd.DataFrame(rows)
    if sh.empty:
        return {'rows': 0, 'latest_year': None, 'top_subregions': []}

    latest_year = int(sh['year'].max())
    latest = sh[sh['year'] == latest_year]
    oa = latest[latest['is_oa']][['subregion_cited', 'shannon']].rename(columns={'shannon': 'oa_shannon'})
    noa = latest[~latest['is_oa']][['subregion_cited', 'shannon']].rename(columns={'shannon': 'noa_shannon'})
    merged = oa.merge(noa, on='subregion_cited', how='inner')
    merged['oa_minus_noa_gap'] = merged['oa_shannon'] - merged['noa_shannon']
    top = merged.sort_values('oa_minus_noa_gap', ascending=False).head(10)

    return {
        'rows': int(len(sh)),
        'latest_year': latest_year,
        'top_subregions': top[['subregion_cited', 'oa_shannon', 'noa_shannon', 'oa_minus_noa_gap']].to_dict('records'),
    }

def table_schema_inventory(data_root: str) -> dict:
    """Check that released CSV tables are present and have analysis columns.

    This deliberately reports structure only. Numeric OA/non-OA checkpoints are
    produced by composing the summary primitives above, not by the smoke test.
    """
    temp = _repo(data_root)
    required = {
        'summary_stats_by_year_atleast2cit.csv': {'year', 'oa_Countries_Shannon_mean', 'noa_Countries_Shannon_mean'},
        'cit_div_vs_cit_count.csv': {'CitationCount', 'CitingCountries_Shannon_perc50'},
        'cit_div_by_field.csv': {'year', 'field', 'oa_CitingCountries_Shannon_mean', 'noa_CitingCountries_Shannon_mean'},
        'summary_stats_by_subregion_atleast2cit.csv': {'subregion_cited', 'year', 'is_oa', 'subregion_citing', 'subregion_citing_count'},
    }
    inventory = {}
    for filename, expected in required.items():
        path = temp / filename
        if not path.exists():
            inventory[filename] = {'exists': False, 'missing_columns': sorted(expected), 'rows': 0, 'columns': []}
            continue
        df = pd.read_csv(path, nrows=5)
        columns = [str(col) for col in df.columns]
        missing = sorted(expected.difference(columns))
        row_count = sum(1 for _ in open(path, 'r', encoding='utf-8', errors='ignore')) - 1
        inventory[filename] = {
            'exists': True,
            'rows': int(max(row_count, 0)),
            'columns': columns,
            'missing_columns': missing,
        }
    return inventory


def checkpoint_consistency_report(data_root: str, checkpoint_csv: str) -> dict:
    """Recompute the shipped checkpoint rows from released CSV tables.

    The function validates a caller-supplied checkpoint table and does not
    choose final report text or create scored artifacts.
    """
    checkpoints = pd.read_csv(checkpoint_csv)
    required = {'checkpoint', 'value', 'unit', 'source_path'}
    missing = required.difference(checkpoints.columns)
    if missing:
        raise ValueError(f"checkpoint table missing columns: {sorted(missing)}")

    temp = _repo(data_root)
    year_df = pd.read_csv(temp / 'summary_stats_by_year_atleast2cit.csv')
    count_df = pd.read_csv(temp / 'cit_div_vs_cit_count.csv')
    field_df = pd.read_csv(temp / 'cit_div_by_field.csv')
    subregion = subregion_diversity_summary(data_root)
    latest_field = field_df[field_df['year'] == field_df['year'].max()].copy()
    latest_field['country_gap'] = (
        latest_field['oa_CitingCountries_Shannon_mean']
        - latest_field['noa_CitingCountries_Shannon_mean']
    )
    count_medians = count_df.groupby('CitationCount', as_index=False)['CitingCountries_Shannon_perc50'].median()
    lookup = {}
    year_2019 = year_df[year_df['year'] == 2019].iloc[0]
    lookup['year_2019_oa_country_shannon_mean'] = float(year_2019['oa_Countries_Shannon_mean'])
    lookup['year_2019_non_oa_country_shannon_mean'] = float(year_2019['noa_Countries_Shannon_mean'])
    lookup['year_2019_oa_subregion_shannon_mean'] = float(year_2019['oa_Subregions_Shannon_mean'])
    lookup['year_2019_non_oa_subregion_shannon_mean'] = float(year_2019['noa_Subregions_Shannon_mean'])
    for citation_count in [2, int(count_medians['CitationCount'].max())]:
        val = count_medians[count_medians['CitationCount'] == citation_count]['CitingCountries_Shannon_perc50'].iloc[0]
        lookup[f'citation_count_{citation_count}_country_shannon_perc50'] = float(val)
    top_field = latest_field.sort_values('country_gap', ascending=False).iloc[0]
    lookup[f"field_country_gap_latest_year_{int(top_field['year'])}_{str(top_field['field']).lower()}"] = float(top_field['country_gap'])
    top_subregion = subregion['top_subregions'][0]
    sub_key = str(top_subregion['subregion_cited']).lower().replace(' ', '_').replace('-', '_')
    lookup[f"subregion_oa_minus_non_oa_shannon_{subregion['latest_year']}_{sub_key}"] = float(top_subregion['oa_minus_noa_gap'])

    rows = []
    for _, row in checkpoints.iterrows():
        name = str(row['checkpoint'])
        reported = float(row['value'])
        recomputed = lookup.get(name)
        rows.append({
            'checkpoint': name,
            'reported': reported,
            'recomputed': recomputed,
            'absolute_error': None if recomputed is None else abs(reported - recomputed),
            'recognized': recomputed is not None,
        })
    return {
        'rows_checked': int(len(rows)),
        'all_recognized': all(row['recognized'] for row in rows),
        'max_absolute_error': max((row['absolute_error'] or 0.0) for row in rows) if rows else 0.0,
        'rows': rows,
    }


def plot_two_series(df: pd.DataFrame, x_col: str, y_a: str, y_b: str, output_path: str, labels: tuple[str, str] = ('A', 'B'), ylabel: str = 'value') -> dict:
    """Generic two-series line plot for caller-selected columns."""
    fig, ax = plt.subplots(figsize=(8.5, 4.8))
    ax.plot(df[x_col], df[y_a], marker='o', label=labels[0])
    ax.plot(df[x_col], df[y_b], marker='o', label=labels[1])
    ax.set_xlabel(x_col)
    ax.set_ylabel(ylabel)
    ax.legend()
    plt.tight_layout()
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output_path, dpi=200)
    plt.close()
    return {'path': output_path, 'x_col': x_col, 'y_cols': [y_a, y_b]}


def plot_single_series(df: pd.DataFrame, x_col: str, y_col: str, output_path: str, xscale: str | None = None, ylabel: str = 'value') -> dict:
    """Generic single-series line plot; callers choose columns and file name."""
    fig, ax = plt.subplots(figsize=(8.5, 4.8))
    ax.plot(df[x_col], df[y_col], marker='o')
    ax.set_xlabel(x_col)
    ax.set_ylabel(ylabel)
    if xscale:
        ax.set_xscale(xscale)
    plt.tight_layout()
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output_path, dpi=200)
    plt.close()
    return {'path': output_path, 'x_col': x_col, 'y_col': y_col}


def plot_ranked_bars(labels: list[str], values: list[float], output_path: str, xlabel: str = 'value') -> dict:
    """Generic ranked horizontal bar plot."""
    order = np.argsort(values)
    labels_arr = np.array(labels, dtype=object)[order]
    values_arr = np.array(values, dtype=float)[order]
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.barh(labels_arr, values_arr, color='#756bb1')
    ax.set_xlabel(xlabel)
    plt.tight_layout()
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output_path, dpi=200)
    plt.close()
    return {'path': output_path, 'n': int(len(values_arr))}


def package_smoke_test(data_root: str) -> dict:
    """Validate file readability and schemas without returning final answers."""
    inventory = table_schema_inventory(data_root)
    return {
        'tables': inventory,
        'all_required_files_present': all(item['exists'] for item in inventory.values()),
        'all_required_columns_present': all(not item['missing_columns'] for item in inventory.values()),
    }

from __future__ import annotations

from pathlib import Path
import re

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import pdfplumber

try:
    from .data_processing import data_root, list_files
except ImportError:
    import importlib.util
    import sys

    tools_dir = Path(__file__).resolve().parent
    module_path = tools_dir / "data_processing.py"
    spec = importlib.util.spec_from_file_location("_info_9c7e_data_processing", module_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load {module_path}")
    _dp = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = _dp
    spec.loader.exec_module(_dp)
    data_root = _dp.data_root
    list_files = _dp.list_files

ARTIFACT_DIR = Path(__file__).resolve().parents[1] / "artifacts"
ARTIFACT_DIR.mkdir(exist_ok=True)
SUPPLEMENT = "41467_2026_70319_MOESM1_ESM.pdf"


def source_inventory(root: str | Path | None = None) -> dict:
    root_path = Path(root) if root else data_root()
    files = list_files(root_path)
    return {"n_files": len(files), "files": [str(Path(f).relative_to(root_path)) for f in files]}


def _supplement_path() -> Path:
    path = data_root() / SUPPLEMENT
    if not path.exists():
        raise FileNotFoundError(path)
    return path


def _tables_from_supplement() -> list[list[list[str]]]:
    tables: list[list[list[str]]] = []
    with pdfplumber.open(_supplement_path()) as pdf:
        for page in pdf.pages:
            for table in page.extract_tables() or []:
                cleaned = [["" if cell is None else str(cell).strip() for cell in row] for row in table]
                if cleaned:
                    tables.append(cleaned)
    return tables


def _numeric_quantity(value: str) -> float:
    text = str(value).replace(",", "").strip()
    match = re.match(r"([-+]?\d+(?:\.\d+)?)\s*([GMTKkM]?)", text)
    if not match:
        return float("nan")
    number = float(match.group(1))
    unit = match.group(2).upper()
    scale = {"": 1.0, "K": 1e3, "M": 1e6, "G": 1e9, "T": 1e12}.get(unit, 1.0)
    return number * scale


def table_by_header(required_headers: list[str]) -> pd.DataFrame:
    for table in _tables_from_supplement():
        header = table[0]
        if all(any(req.lower() in cell.lower() for cell in header) for req in required_headers):
            return pd.DataFrame(table[1:], columns=header)
    raise ValueError(f"no table found for headers: {required_headers}")


def holography_benchmark_table() -> pd.DataFrame:
    table = table_by_header(["U-Net", "HoloNet", "ULBN"])
    methods = [c for c in table.columns if c]
    records = []
    for _, row in table.iterrows():
        metric = str(row.iloc[0]).replace("\n", " ").strip()
        if not metric:
            continue
        for method in methods[1:]:
            raw = row[method]
            records.append({"metric": metric, "method": method, "raw_value": raw, "value": _numeric_quantity(raw)})
    return pd.DataFrame(records)


def ablation_table() -> pd.DataFrame:
    table = table_by_header(["Bit operations", "Memory", "PSNR", "SSIM"])
    rows = []
    for _, row in table.iterrows():
        method = str(row.iloc[0]).replace("\n", " ").strip()
        if not method:
            continue
        rows.append({
            "method": method,
            "bit_operations": _numeric_quantity(row["Bit operations"]),
            "memory_bytes": _numeric_quantity(row["Memory (Bytes)"]),
            "psnr_db": pd.to_numeric(row["PSNR (dB)"], errors="coerce"),
            "ssim": pd.to_numeric(row["SSIM"], errors="coerce"),
        })
    return pd.DataFrame(rows).dropna(subset=["psnr_db"])


def gaussian_quantization_comparison() -> pd.DataFrame:
    tables = _tables_from_supplement()
    rows = []
    for table in tables:
        header = table[0]
        if header[:3] == ["Methods", "PSNR (dB)", "SSIM"]:
            for row in table[1:]:
                if len(row) >= 3:
                    rows.append({"method": row[0], "psnr_db": float(row[1]), "ssim": float(row[2])})
            if rows:
                break
    if not rows:
        raise ValueError("Gaussian quantization comparison table not found")
    return pd.DataFrame(rows)


def efficiency_reduction_summary() -> dict:
    bench = holography_benchmark_table()
    def value(metric: str, method: str) -> float:
        hit = bench[(bench["metric"].str.contains(metric, case=False, regex=False)) & (bench["method"] == method)]
        if hit.empty:
            return float("nan")
        return float(hit.iloc[0]["value"])
    holonet_bitops = value("Bit operations", "HoloNet")
    ulbn_bitops = value("Bit operations", "ULBN (Ours)")
    holonet_memory = value("Memory", "HoloNet")
    ulbn_memory = value("Memory", "ULBN (Ours)")
    holonet_psnr = value("PSNR", "HoloNet")
    ulbn_psnr = value("PSNR", "ULBN (Ours)")
    return {
        "bit_operations_reduction_fraction": 1.0 - ulbn_bitops / holonet_bitops,
        "memory_reduction_fraction": 1.0 - ulbn_memory / holonet_memory,
        "psnr_gain_db": ulbn_psnr - holonet_psnr,
    }


def plot_holography_quality(output_filename: str = "Fig1_info_9c7e_feature_profile.png") -> dict:
    bench = holography_benchmark_table()
    out = ARTIFACT_DIR / output_filename
    metrics = ["PSNR (dB)", "SSIM", "MS-SSIM"]
    pivot = bench[bench["metric"].isin(metrics)].pivot(index="method", columns="metric", values="value")
    fig, ax = plt.subplots(figsize=(8.2, 4.8))
    pivot["PSNR (dB)"].plot(kind="bar", ax=ax, color="#2f6f4e")
    ax.set_ylabel("PSNR (dB)")
    ax.set_title("DIV2K holography reconstruction quality from Table S4")
    ax.tick_params(axis="x", rotation=25)
    fig.tight_layout()
    fig.savefig(out, dpi=180)
    plt.close(fig)
    return {"path": str(out), "source": f"{SUPPLEMENT}::Table S4", "methods": list(pivot.index)}


def plot_holography_efficiency(output_filename: str = "Fig2_info_9c7e_workflow_contrast.png") -> dict:
    bench = holography_benchmark_table()
    out = ARTIFACT_DIR / output_filename
    subset = bench[bench["metric"].isin(["Bit operations", "Memory (Bytes)"])]
    pivot = subset.pivot(index="method", columns="metric", values="value")
    fig, ax = plt.subplots(figsize=(8.2, 4.8))
    x = np.arange(len(pivot.index))
    ax.bar(x - 0.18, pivot["Bit operations"], width=0.36, label="bit operations")
    ax.bar(x + 0.18, pivot["Memory (Bytes)"], width=0.36, label="memory bytes")
    ax.set_yscale("log")
    ax.set_xticks(x)
    ax.set_xticklabels(pivot.index, rotation=25, ha="right")
    ax.set_ylabel("quantity (log scale)")
    ax.set_title("Computation and memory contrast from Table S4")
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(out, dpi=180)
    plt.close(fig)
    return {"path": str(out), "source": f"{SUPPLEMENT}::Table S4", "summary": efficiency_reduction_summary()}


def plot_ablation_pareto(output_filename: str = "Fig3_info_9c7e_signal_relationship.png") -> dict:
    df = ablation_table()
    out = ARTIFACT_DIR / output_filename
    fig, ax = plt.subplots(figsize=(8.2, 4.8))
    colors = ["#c75146" if "ULBN" in m else "#3b6ea8" for m in df["method"]]
    ax.scatter(df["bit_operations"] / 1e9, df["psnr_db"], s=55, c=colors, alpha=0.8)
    for _, row in df.iterrows():
        if "ULBN" in row["method"] or "4-bit+FPL+QAT" in row["method"] or "Full precision" in row["method"]:
            ax.annotate(row["method"], (row["bit_operations"] / 1e9, row["psnr_db"]), fontsize=7, xytext=(4, 3), textcoords="offset points")
    ax.set_xscale("log")
    ax.set_xlabel("bit operations (G, log scale)")
    ax.set_ylabel("PSNR (dB)")
    ax.set_title("Ablation quality-cost relationship from Table S3")
    fig.tight_layout()
    fig.savefig(out, dpi=180)
    plt.close(fig)
    return {"path": str(out), "source": f"{SUPPLEMENT}::Table S3", "rows": int(len(df))}


def package_smoke_test() -> dict:
    return {
        "inventory": source_inventory(),
        "gaussian_comparison": gaussian_quantization_comparison().to_dict(orient="records"),
        "efficiency_summary": efficiency_reduction_summary(),
        "ablation_rows": int(len(ablation_table())),
        "plots": [plot_holography_quality(), plot_holography_efficiency(), plot_ablation_pareto()],
    }

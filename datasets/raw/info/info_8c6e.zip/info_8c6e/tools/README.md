# Tools

This directory follows the three-layer task-tool structure.

- `data_processing.py`: generic file discovery, archive inspection, workbook/table I/O, numeric coercion, and robust z-score helpers.
- `database_retrieval.py`: local link/catalog discovery utilities for bundled context files.
- `info_8c6e.py`: domain methods for temporal-fingerprint identity matching on the bundled public demo archive.

Domain methods in `info_8c6e.py` are composable primitives:
- `load_identity_events()`: load and validate the hashed cross-platform activity event table from `github_repo_2.zip`.
- `interevent_gap_profile_by_platform()`: summarize platform-level inter-event-time distributions.
- `creator_interevent_series()`: build creator-level inter-event time series.
- `pairwise_similarity_table()`: compute cross-platform creator-pair similarities using KS distance on inter-event distributions.
- `evaluate_pair_matching()`: evaluate pair ranking with AUC and precision@k against label-ground truth.
- `cross_platform_matching_summary()`: evaluate all ordered platform pairs.
- `plot_interevent_gap_profile()`, `plot_cross_platform_auc_heatmap()`, `plot_similarity_distribution()`: figure primitives that render supplied results.

These tools are intended to reproduce bundle-side temporal-fingerprint matching behavior from released event-level data; paper headline values must still be cited directly from `input_data/reference_paper/target.pdf` in `task_content.json`.

from __future__ import annotations

from pathlib import Path
import zipfile

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def _data_root() -> Path:
    return Path(__file__).resolve().parents[1] / "input_data" / "data"


def _default_repo_zip(repo_zip: str | Path | None = None) -> Path:
    return Path(repo_zip) if repo_zip else (_data_root() / "github_repo_2.zip")


def _find_identity_csv_in_zip(repo_zip: str | Path | None = None) -> str:
    zpath = _default_repo_zip(repo_zip)
    with zipfile.ZipFile(zpath) as zf:
        names = [n for n in zf.namelist() if n.endswith("hashed_identity_matching_demo_20240608_20240615.csv")]
    if not names:
        raise FileNotFoundError("identity CSV not found inside github_repo_2.zip")
    return names[0]


def load_identity_events(repo_zip: str | Path | None = None) -> pd.DataFrame:
    zpath = _default_repo_zip(repo_zip)
    csv_name = _find_identity_csv_in_zip(zpath)
    with zipfile.ZipFile(zpath) as zf:
        with zf.open(csv_name) as f:
            df = pd.read_csv(f)
    required = {"creator_name", "platform_type", "creation_time", "label"}
    missing = sorted(required - set(df.columns))
    if missing:
        raise ValueError(f"missing columns: {missing}")
    out = df[["creator_name", "platform_type", "creation_time", "label"]].copy()
    out["platform_type"] = out["platform_type"].astype(str).str.lower().str.strip()
    out["creation_time"] = pd.to_datetime(out["creation_time"], utc=True, errors="coerce")
    out = out.dropna(subset=["creator_name", "platform_type", "creation_time", "label"])
    out["label"] = out["label"].astype(int)
    return out.sort_values("creation_time").reset_index(drop=True)


def interevent_gap_profile_by_platform(events: pd.DataFrame | None = None) -> pd.DataFrame:
    df = events if events is not None else load_identity_events()
    rows: list[dict] = []
    for platform, sub in df.groupby("platform_type"):
        gaps = []
        for _, g in sub.groupby("creator_name"):
            times = g["creation_time"].sort_values().to_numpy(dtype="datetime64[ns]")
            if len(times) < 2:
                continue
            d = np.diff(times).astype("timedelta64[s]").astype(float) / 60.0
            d = d[np.isfinite(d) & (d > 0)]
            if len(d):
                gaps.append(d)
        if not gaps:
            continue
        arr = np.concatenate(gaps)
        q = np.quantile(arr, [0.1, 0.5, 0.9])
        rows.append(
            {
                "platform_type": platform,
                "n_gaps": int(len(arr)),
                "mean_gap_min": float(arr.mean()),
                "q10_gap_min": float(q[0]),
                "median_gap_min": float(q[1]),
                "q90_gap_min": float(q[2]),
            }
        )
    return pd.DataFrame(rows).sort_values("platform_type").reset_index(drop=True)


def creator_interevent_series(
    events: pd.DataFrame | None = None,
    min_posts: int = 20,
    min_gaps: int = 10,
) -> pd.DataFrame:
    df = events if events is not None else load_identity_events()
    rows: list[dict] = []
    for (creator, platform), sub in df.groupby(["creator_name", "platform_type"], sort=False):
        if len(sub) < int(min_posts):
            continue
        times = sub["creation_time"].sort_values().to_numpy(dtype="datetime64[ns]")
        gaps = np.diff(times).astype("timedelta64[s]").astype(float) / 60.0
        gaps = gaps[np.isfinite(gaps) & (gaps > 0)]
        if len(gaps) < int(min_gaps):
            continue
        label = int(sub["label"].mode(dropna=True).iloc[0])
        rows.append(
            {
                "creator_name": creator,
                "platform_type": platform,
                "label": label,
                "n_posts": int(len(sub)),
                "gaps_min": gaps,
            }
        )
    return pd.DataFrame(rows)


def _ks_distance_from_samples(a: np.ndarray, b: np.ndarray) -> float:
    x = np.sort(np.asarray(a, dtype=float))
    y = np.sort(np.asarray(b, dtype=float))
    if len(x) == 0 or len(y) == 0:
        return float("nan")
    values = np.unique(np.concatenate([x, y]))
    fx = np.searchsorted(x, values, side="right") / len(x)
    fy = np.searchsorted(y, values, side="right") / len(y)
    return float(np.max(np.abs(fx - fy)))


def pairwise_similarity_table(
    source_platform: str,
    target_platform: str,
    events: pd.DataFrame | None = None,
    min_posts: int = 20,
    min_gaps: int = 10,
) -> pd.DataFrame:
    series = creator_interevent_series(events=events, min_posts=min_posts, min_gaps=min_gaps)
    src = series[series["platform_type"] == source_platform]
    tgt = series[series["platform_type"] == target_platform]
    if src.empty or tgt.empty:
        return pd.DataFrame(columns=["source_creator", "target_creator", "source_label", "target_label", "similarity", "is_match"])
    rows: list[dict] = []
    for _, rs in src.iterrows():
        for _, rt in tgt.iterrows():
            ks = _ks_distance_from_samples(rs["gaps_min"], rt["gaps_min"])
            sim = 1.0 - ks
            rows.append(
                {
                    "source_creator": rs["creator_name"],
                    "target_creator": rt["creator_name"],
                    "source_label": int(rs["label"]),
                    "target_label": int(rt["label"]),
                    "similarity": float(sim),
                    "is_match": int(int(rs["label"]) == int(rt["label"])),
                }
            )
    return pd.DataFrame(rows)


def _auc_from_scores(y_true: np.ndarray, score: np.ndarray) -> float:
    y = np.asarray(y_true, dtype=int)
    s = np.asarray(score, dtype=float)
    pos = s[y == 1]
    neg = s[y == 0]
    if len(pos) == 0 or len(neg) == 0:
        return float("nan")
    wins = 0.0
    for p in pos:
        wins += float(np.sum(p > neg))
        wins += 0.5 * float(np.sum(p == neg))
    return wins / (len(pos) * len(neg))


def evaluate_pair_matching(sim_table: pd.DataFrame, top_k: int = 100) -> dict:
    if sim_table.empty:
        return {"error": "empty similarity table"}
    y = sim_table["is_match"].to_numpy(dtype=int)
    s = sim_table["similarity"].to_numpy(dtype=float)
    auc = _auc_from_scores(y, s)
    ranked = sim_table.sort_values("similarity", ascending=False).reset_index(drop=True)
    k = int(min(max(1, top_k), len(ranked)))
    p_at_k = float(ranked.loc[: k - 1, "is_match"].mean())
    return {
        "n_pairs": int(len(sim_table)),
        "n_positive_pairs": int(sim_table["is_match"].sum()),
        "auc": float(auc),
        "top_k": k,
        "precision_at_top_k": p_at_k,
    }


def cross_platform_matching_summary(
    events: pd.DataFrame | None = None,
    min_posts: int = 20,
    min_gaps: int = 10,
    top_k: int = 100,
) -> pd.DataFrame:
    df = events if events is not None else load_identity_events()
    platforms = sorted(df["platform_type"].unique().tolist())
    rows: list[dict] = []
    for src in platforms:
        for tgt in platforms:
            if src == tgt:
                continue
            sim = pairwise_similarity_table(src, tgt, events=df, min_posts=min_posts, min_gaps=min_gaps)
            met = evaluate_pair_matching(sim, top_k=top_k)
            rows.append(
                {
                    "source_platform": src,
                    "target_platform": tgt,
                    "n_pairs": int(met.get("n_pairs", 0)),
                    "n_positive_pairs": int(met.get("n_positive_pairs", 0)),
                    "auc": float(met.get("auc", np.nan)),
                    "precision_at_top_k": float(met.get("precision_at_top_k", np.nan)),
                }
            )
    return pd.DataFrame(rows)


def plot_interevent_gap_profile(profile_df: pd.DataFrame, output_path: str | Path) -> dict:
    out = Path(output_path)
    fig, ax = plt.subplots(figsize=(7.5, 4.8))
    x = np.arange(len(profile_df))
    ax.bar(x, profile_df["median_gap_min"].to_numpy(dtype=float), color="#4c78a8", label="median")
    ax.errorbar(
        x,
        profile_df["median_gap_min"].to_numpy(dtype=float),
        yerr=[
            profile_df["median_gap_min"].to_numpy(dtype=float) - profile_df["q10_gap_min"].to_numpy(dtype=float),
            profile_df["q90_gap_min"].to_numpy(dtype=float) - profile_df["median_gap_min"].to_numpy(dtype=float),
        ],
        fmt="none",
        ecolor="#333333",
        capsize=4,
        linewidth=1.0,
    )
    ax.set_xticks(x)
    ax.set_xticklabels(profile_df["platform_type"].tolist())
    ax.set_ylabel("Inter-event gap (minutes)")
    ax.set_title("Platform inter-event gap profile (median with q10-q90)")
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(out, dpi=160)
    plt.close(fig)
    return {"path": str(out), "n_platforms": int(len(profile_df))}


def plot_cross_platform_auc_heatmap(summary_df: pd.DataFrame, output_path: str | Path) -> dict:
    out = Path(output_path)
    piv = summary_df.pivot(index="source_platform", columns="target_platform", values="auc")
    fig, ax = plt.subplots(figsize=(5.8, 4.6))
    arr = piv.to_numpy(dtype=float)
    im = ax.imshow(arr, cmap="viridis", vmin=0.0, vmax=1.0)
    ax.set_xticks(range(len(piv.columns)))
    ax.set_xticklabels(piv.columns, rotation=35, ha="right")
    ax.set_yticks(range(len(piv.index)))
    ax.set_yticklabels(piv.index)
    ax.set_title("Cross-platform matching AUC (inter-event KS similarity)")
    fig.colorbar(im, ax=ax, label="AUC")
    fig.tight_layout()
    fig.savefig(out, dpi=160)
    plt.close(fig)
    return {"path": str(out), "pairs": int(len(summary_df))}


def plot_similarity_distribution(sim_table: pd.DataFrame, output_path: str | Path) -> dict:
    out = Path(output_path)
    pos = sim_table.loc[sim_table["is_match"] == 1, "similarity"].to_numpy(dtype=float)
    neg = sim_table.loc[sim_table["is_match"] == 0, "similarity"].to_numpy(dtype=float)
    bins = np.linspace(0.0, 1.0, 30)
    fig, ax = plt.subplots(figsize=(7.2, 4.6))
    ax.hist(neg, bins=bins, alpha=0.55, density=True, label="non-matching label pairs")
    ax.hist(pos, bins=bins, alpha=0.55, density=True, label="matching label pairs")
    ax.set_xlabel("Inter-event KS similarity (1 - KS)")
    ax.set_ylabel("Density")
    ax.set_title("Similarity separation: Twitter vs Telegram creator pairs")
    ax.legend()
    fig.tight_layout()
    fig.savefig(out, dpi=160)
    plt.close(fig)
    return {"path": str(out), "n_pairs": int(len(sim_table))}

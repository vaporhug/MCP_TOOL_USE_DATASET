from __future__ import annotations

from pathlib import Path
import subprocess

try:
    from .data_processing import list_files
except ImportError:
    from data_processing import list_files


def local_code_inventory(data_root: str) -> dict:
    return {
        "root": str(Path(data_root).resolve()),
        "files": list_files(data_root),
        "code_files": list_files(data_root, suffixes={".py", ".ipynb", ".md"}),
    }


def reference_inventory(reference_root: str) -> dict:
    return {
        "root": str(Path(reference_root).resolve()),
        "files": list_files(reference_root, suffixes={".pdf"}),
    }


def extract_pdf_text(path: str) -> dict:
    source = Path(path)
    if not source.exists():
        raise FileNotFoundError(source)
    try:
        result = subprocess.run(["pdftotext", str(source), "-"], capture_output=True, text=True, check=True)
        return {"path": str(source), "method": "pdftotext", "text": result.stdout}
    except Exception:
        try:
            from pypdf import PdfReader
        except ImportError as exc:
            raise RuntimeError("PDF text extraction requires pdftotext or pypdf") from exc
        reader = PdfReader(str(source))
        text = "\n".join(page.extract_text() or "" for page in reader.pages)
        return {"path": str(source), "method": "pypdf", "text": text}


def find_pdf_lines(path: str, patterns: list[str]) -> dict:
    text = extract_pdf_text(path)["text"]
    matches = []
    for i, line in enumerate(text.splitlines(), start=1):
        lower = line.lower()
        for pattern in patterns:
            if pattern.lower() in lower:
                matches.append({"line_number": i, "pattern": pattern, "line": line.strip()})
                break
    return {"path": path, "patterns": patterns, "matches": matches}

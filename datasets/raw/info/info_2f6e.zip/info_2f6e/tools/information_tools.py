from __future__ import annotations

from pathlib import Path
import ast
import re

import matplotlib.pyplot as plt
import pandas as pd


AUTHOR_RAW_SHEET = "Fig 1(a) - raw counts"
WORK_RAW_SHEET = "Fig 1(b) - raw counts"
AUTHOR_PERCENT_SHEET = "Fig 1(a)"
WORK_PERCENT_SHEET = "Fig 1(b)"


def workbook_sheet_schema(source_xlsx: str) -> dict:
    """Return sheet shapes and columns for the released Fig. 1 source workbook."""
    book = pd.ExcelFile(source_xlsx)
    return {
        sheet: {
            "rows": int(pd.read_excel(source_xlsx, sheet_name=sheet).shape[0]),
            "columns": list(pd.read_excel(source_xlsx, sheet_name=sheet).columns),
        }
        for sheet in book.sheet_names
    }


def _author_raw(source_xlsx: str) -> pd.DataFrame:
    df = pd.read_excel(source_xlsx, sheet_name=AUTHOR_RAW_SHEET)
    required = {"topic", "date", "month_idx", "total works", "total authors", "newcomers", "bellwethers", "outbreak scientists"}
    missing = sorted(required - set(df.columns))
    if missing:
        raise ValueError(f"{AUTHOR_RAW_SHEET} missing columns: {missing}")
    return df.copy()


def _work_raw(source_xlsx: str) -> pd.DataFrame:
    df = pd.read_excel(source_xlsx, sheet_name=WORK_RAW_SHEET)
    required = {"topic", "date", "month_idx", "0p", "1-25p", "26-50p", "51-75p", "76-99p", "100p", "total_works"}
    missing = sorted(required - set(df.columns))
    if missing:
        raise ValueError(f"{WORK_RAW_SHEET} missing columns: {missing}")
    return df.copy()


def recompute_author_composition(source_xlsx: str) -> dict:
    raw = _author_raw(source_xlsx)
    rows = []
    for _, row in raw.iterrows():
        total = float(row["total authors"])
        rows.append(
            {
                "topic": row["topic"],
                "date": str(pd.to_datetime(row["date"]).date()),
                "month_idx": int(row["month_idx"]),
                "outbreak_scientists_pct": float(100.0 * row["outbreak scientists"] / total),
                "bellwethers_pct": float(100.0 * row["bellwethers"] / total),
                "newcomers_pct": float(100.0 * row["newcomers"] / total),
            }
        )
    return {"source_sheet": AUTHOR_RAW_SHEET, "rows": rows}


def recompute_authorship_mixture(source_xlsx: str) -> dict:
    raw = _work_raw(source_xlsx)
    rows = []
    for _, row in raw.iterrows():
        total = float(row["total_works"])
        rows.append(
            {
                "topic": row["topic"],
                "date": str(pd.to_datetime(row["date"]).date()),
                "month_idx": int(row["month_idx"]),
                "no_outbreak_scientist_pct": float(100.0 * row["0p"] / total),
                "minority_outbreak_scientist_pct": float(100.0 * (row["1-25p"] + row["26-50p"]) / total),
                "majority_outbreak_scientist_pct": float(100.0 * (row["51-75p"] + row["76-99p"]) / total),
                "only_outbreak_scientist_pct": float(100.0 * row["100p"] / total),
                "any_outbreak_scientist_pct": float(100.0 * (total - row["0p"]) / total),
            }
        )
    return {"source_sheet": WORK_RAW_SHEET, "rows": rows}


def validate_percentage_panels(source_xlsx: str, tolerance: float = 1e-9) -> dict:
    author = pd.DataFrame(recompute_author_composition(source_xlsx)["rows"])
    author_panel = pd.read_excel(source_xlsx, sheet_name=AUTHOR_PERCENT_SHEET)
    work = pd.DataFrame(recompute_authorship_mixture(source_xlsx)["rows"])
    work_panel = pd.read_excel(source_xlsx, sheet_name=WORK_PERCENT_SHEET)

    author_checks = {
        "Outbreak Scientists": float((author["outbreak_scientists_pct"] - author_panel["Outbreak Scientists"]).abs().max()),
        "Bellwethers": float((author["bellwethers_pct"] - author_panel["Bellwethers"]).abs().max()),
        "Newcomers": float((author["newcomers_pct"] - author_panel["Newcomers"]).abs().max()),
    }
    work_checks = {
        "No OS": float((work["no_outbreak_scientist_pct"] - work_panel["No OS"]).abs().max()),
        "Minority OS": float((work["minority_outbreak_scientist_pct"] - work_panel["Minority OS"]).abs().max()),
        "Majority OS": float((work["majority_outbreak_scientist_pct"] - work_panel["Majority OS"]).abs().max()),
        "Only OS": float((work["only_outbreak_scientist_pct"] - work_panel["Only OS"]).abs().max()),
    }
    max_error = max([*author_checks.values(), *work_checks.values()])
    return {
        "author_percent_sheet": AUTHOR_PERCENT_SHEET,
        "work_percent_sheet": WORK_PERCENT_SHEET,
        "author_max_abs_errors": author_checks,
        "work_max_abs_errors": work_checks,
        "max_abs_error": float(max_error),
        "within_tolerance": bool(max_error <= tolerance),
    }


def paper_headline_metrics(source_xlsx: str) -> dict:
    author = _author_raw(source_xlsx)
    work = _work_raw(source_xlsx)
    first_six = author[author["month_idx"] <= 6]
    first_six_work = work[work["month_idx"] <= 6]
    jan_2021_onward = work[work["date"] >= pd.Timestamp("2021-01-01")]
    return {
        "source_sheets": [AUTHOR_RAW_SHEET, WORK_RAW_SHEET],
        "observation_months": int(author["month_idx"].nunique()),
        "sustained_2021_2022_monthly_works_mean": float(author[author["date"] >= pd.Timestamp("2021-01-01")]["total works"].mean()),
        "first_six_month_outbreak_author_pct": float(100.0 * first_six["outbreak scientists"].sum() / first_six["total authors"].sum()),
        "first_six_month_any_outbreak_work_pct": float(100.0 * (first_six_work["total_works"].sum() - first_six_work["0p"].sum()) / first_six_work["total_works"].sum()),
        "all_month_any_outbreak_work_pct": float(100.0 * (work["total_works"].sum() - work["0p"].sum()) / work["total_works"].sum()),
        "jan_2021_onward_no_outbreak_work_pct_mean": float(100.0 * jan_2021_onward["0p"].sum() / jan_2021_onward["total_works"].sum()),
    }


def notebook_topic_windows(utils_path: str, concepts_csv_gz: str, topic: str = "COVID") -> dict:
    """Extract the released notebook utility's concept IDs and map them to concepts.csv.gz."""
    text = Path(utils_path).read_text(encoding="utf-8", errors="ignore")
    block_match = re.search(rf"if topic_ == '{re.escape(topic)}':(?P<body>.*?)(?:\n\s*elif|\n\s*else:)", text, flags=re.DOTALL)
    if not block_match:
        raise ValueError(f"Topic block not found in {utils_path}: {topic}")
    body = block_match.group("body")
    topic_ids = ast.literal_eval(re.search(r"topic_ids\s*=\s*(\{[^}]+\})", body).group(1))
    prior_ids = ast.literal_eval(re.search(r"topic_ids_exp\s*=\s*(\{[^}]+\})", body).group(1))
    start = re.search(r"start_date_ow\s*=\s*pd\.to_datetime\('([^']+)'\)", body).group(1)
    concepts = pd.read_csv(concepts_csv_gz, usecols=["concept_id", "concept_name", "level"])
    concept_map = concepts.set_index("concept_id")[["concept_name", "level"]].to_dict("index")

    def describe(ids: set[int]) -> list[dict]:
        return [
            {
                "concept_id": int(i),
                "concept_name": concept_map.get(i, {}).get("concept_name"),
                "level": None if i not in concept_map else int(concept_map[i]["level"]),
            }
            for i in sorted(ids)
        ]

    return {
        "topic": topic,
        "core_topic_concepts": describe(topic_ids),
        "prior_experience_concepts": describe(prior_ids),
        "training_window": ["2015-01-01", "2019-12-31"],
        "observation_window": [start, "2022-12-31"],
    }


def plot_author_composition(source_xlsx: str, output_path: str) -> dict:
    rows = pd.DataFrame(recompute_author_composition(source_xlsx)["rows"])
    plt.figure(figsize=(7, 4.2))
    plt.plot(rows["month_idx"], rows["outbreak_scientists_pct"], label="Outbreak scientists")
    plt.plot(rows["month_idx"], rows["bellwethers_pct"], label="Bellwethers")
    plt.plot(rows["month_idx"], rows["newcomers_pct"], label="Newcomers")
    plt.xlabel("Month index in 2020-2022 observation window")
    plt.ylabel("Share of COVID authors (%)")
    plt.title("COVID author taxonomy from raw counts")
    plt.legend(frameon=False)
    plt.tight_layout()
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out, dpi=200)
    plt.close()
    return {"path": str(out), "validation": validate_percentage_panels(source_xlsx)}


def plot_authorship_mixture(source_xlsx: str, output_path: str) -> dict:
    rows = pd.DataFrame(recompute_authorship_mixture(source_xlsx)["rows"])
    plt.figure(figsize=(7, 4.2))
    plt.plot(rows["month_idx"], rows["no_outbreak_scientist_pct"], label="No outbreak scientist")
    plt.plot(rows["month_idx"], rows["minority_outbreak_scientist_pct"], label="Minority outbreak scientists")
    plt.plot(rows["month_idx"], rows["majority_outbreak_scientist_pct"], label="Majority outbreak scientists")
    plt.plot(rows["month_idx"], rows["only_outbreak_scientist_pct"], label="Only outbreak scientists")
    plt.xlabel("Month index in 2020-2022 observation window")
    plt.ylabel("Share of COVID works (%)")
    plt.title("COVID team mixtures from raw work counts")
    plt.legend(frameon=False, fontsize=8)
    plt.tight_layout()
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out, dpi=200)
    plt.close()
    return {"path": str(out), "validation": validate_percentage_panels(source_xlsx)}


def plot_monthly_growth(source_xlsx: str, output_path: str) -> dict:
    author = _author_raw(source_xlsx)
    mixture = pd.DataFrame(recompute_authorship_mixture(source_xlsx)["rows"])
    headline = paper_headline_metrics(source_xlsx)
    fig, axes = plt.subplots(1, 2, figsize=(10, 4.2))
    axes[0].plot(author["month_idx"], author["total works"], label="works")
    axes[0].plot(author["month_idx"], author["total authors"], label="authors")
    axes[0].set_xlabel("Month index in 2020-2022 observation window")
    axes[0].set_ylabel("Raw count")
    axes[0].set_title("COVID publishing growth")
    axes[0].legend(frameon=False)

    axes[1].plot(mixture["month_idx"], mixture["any_outbreak_scientist_pct"], color="#B45F06")
    reference_pct = headline["all_month_any_outbreak_work_pct"]
    axes[1].axhline(
        reference_pct,
        color="grey",
        linestyle="--",
        linewidth=1,
        label=f"source-data recomputed all-month mean: {reference_pct:.1f}%",
    )
    axes[1].set_xlabel("Month index in 2020-2022 observation window")
    axes[1].set_ylabel("Works with >=1 outbreak scientist (%)")
    axes[1].set_title("Outbreak-scientist team participation")
    axes[1].legend(frameon=False, fontsize=8)

    fig.tight_layout()
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out, dpi=200)
    plt.close(fig)
    return {"path": str(out), "headline_metrics": headline}

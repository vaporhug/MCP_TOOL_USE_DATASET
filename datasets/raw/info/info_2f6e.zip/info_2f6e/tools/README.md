This tool directory is split into three layers:

- `data_processing.py`: generic local file helpers
- `database_retrieval.py`: local reference/code inventory and lightweight PDF text lookup
- `information_tools.py`: core analytical primitives for the pandemic-publishing workflow

The core tool file exposes:

- outbreak-scientist composition summaries
- authorship-mixture summaries
- month-by-month growth comparisons
- artifact-generating plotting helpers

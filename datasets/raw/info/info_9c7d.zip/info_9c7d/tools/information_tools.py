from __future__ import annotations

import csv
import io
import math
import zipfile
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

try:
    from .data_processing import data_root, list_files
except ImportError:
    import importlib.util
    import sys

    tools_dir = Path(__file__).resolve().parent
    module_path = tools_dir / "data_processing.py"
    spec = importlib.util.spec_from_file_location("_info_9c7d_data_processing", module_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load {module_path}")
    _dp = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = _dp
    spec.loader.exec_module(_dp)
    data_root = _dp.data_root
    list_files = _dp.list_files

ARTIFACT_DIR = Path(__file__).resolve().parents[1] / "artifacts"
ARTIFACT_DIR.mkdir(exist_ok=True)
SOURCE_ZIP = "41467_2026_69477_MOESM3_ESM.zip"


def source_inventory(root: str | Path | None = None) -> dict:
    root_path = Path(root) if root else data_root()
    files = list_files(root_path)
    archives = {}
    for file in files:
        path = Path(file)
        if path.suffix.lower() == ".zip":
            with zipfile.ZipFile(path) as zf:
                archives[path.name] = sorted(zf.namelist())
    return {
        "n_files": len(files),
        "files": [str(Path(f).relative_to(root_path)) for f in files],
        "archives": archives,
    }


def _source_zip_path() -> Path:
    path = data_root() / SOURCE_ZIP
    if not path.exists():
        raise FileNotFoundError(path)
    return path


def read_source_csv(member_basename: str) -> list[list[str]]:
    """Return raw CSV rows from the Nature source-data archive."""
    with zipfile.ZipFile(_source_zip_path()) as zf:
        matches = [name for name in zf.namelist() if Path(name).name == member_basename]
        if not matches:
            raise FileNotFoundError(member_basename)
        text = zf.read(matches[0]).decode("utf-8-sig", errors="replace")
    return [row for row in csv.reader(io.StringIO(text))]


def csv_section_table(member_basename: str, section_label: str | None = None) -> pd.DataFrame:
    rows = read_source_csv(member_basename)
    start = 0
    if section_label is not None:
        labels = [i for i, row in enumerate(rows) if row and row[0].strip() == section_label]
        if not labels:
            raise ValueError(f"section not found: {section_label}")
        start = labels[0] + 1
    while start < len(rows) and not any(cell.strip() for cell in rows[start]):
        start += 1
    header = rows[start]
    data = []
    for row in rows[start + 1:]:
        if not any(cell.strip() for cell in row):
            break
        if section_label is not None and row[0].strip().startswith("Fig."):
            break
        data.append(row)
    width = len(header)
    cleaned = [row[:width] + [""] * max(0, width - len(row)) for row in data]
    unique_header = []
    seen: dict[str, int] = {}
    for idx, name in enumerate(header):
        base = str(name).strip() or f"unnamed_{idx}"
        seen[base] = seen.get(base, 0) + 1
        unique_header.append(base if seen[base] == 1 else f"{base}.{seen[base] - 1}")
    df = pd.DataFrame(cleaned, columns=unique_header)
    for col in df.columns:
        converted = pd.to_numeric(df[col], errors="coerce")
        if converted.notna().any():
            df[col] = converted
    return df.dropna(axis=1, how="all")


def runtime_benchmark_table() -> pd.DataFrame:
    df = csv_section_table("source_data_fig3.csv", "Fig. 3b")
    numeric = df.apply(pd.to_numeric, errors="coerce")
    return numeric.dropna(how="all")


def runtime_speedup_table(reference_solver: str = "HFSS (s)") -> pd.DataFrame:
    df = runtime_benchmark_table().copy()
    pngf = pd.to_numeric(df["PNGF, 128 cores (s)"], errors="coerce")
    for col in ["APF (s)", "FDTD (s)", "CST (s)", "HFSS (s)", "PNGF, 1 core (s)"]:
        df[f"speedup_vs_{col}"] = pd.to_numeric(df[col], errors="coerce") / pngf
    if reference_solver not in df.columns:
        raise ValueError(f"unknown solver column: {reference_solver}")
    df["reference_speedup"] = pd.to_numeric(df[reference_solver], errors="coerce") / pngf
    return df


def frequency_response_table(member_basename: str, section_label: str) -> pd.DataFrame:
    df = csv_section_table(member_basename, section_label)
    out = pd.DataFrame()
    counts: dict[str, int] = {}
    for idx in range(0, len(df.columns), 2):
        if idx + 1 >= len(df.columns):
            continue
        f_col, metric_col = df.columns[idx], df.columns[idx + 1]
        if not str(f_col).startswith("f"):
            continue
        metric = str(metric_col).strip()
        counts[metric] = counts.get(metric, 0) + 1
        suffix = "" if counts[metric] == 1 else f"_{counts[metric]}"
        out[f"frequency_GHz__{metric}{suffix}"] = pd.to_numeric(df[f_col], errors="coerce")
        out[f"{metric}{suffix}"] = pd.to_numeric(df[metric_col], errors="coerce")
    return out.dropna(axis=1, how="all")


def response_alignment_summary(member_basename: str = "source_data_fig6.csv", section_label: str = "Fig. 6b") -> dict:
    df = frequency_response_table(member_basename, section_label)
    metrics = [c for c in df.columns if c.startswith("S")]
    summary = {}
    for metric in metrics:
        values = pd.to_numeric(df[metric], errors="coerce").dropna()
        if len(values):
            summary[metric] = {
                "n": int(len(values)),
                "median_dB": float(values.median()),
                "min_dB": float(values.min()),
                "max_dB": float(values.max()),
            }
    return {"source": f"{SOURCE_ZIP}::{member_basename}::{section_label}", "metrics": summary}


def plot_runtime_scaling(output_filename: str = "Fig1_info_9c7d_feature_profile.png") -> dict:
    df = runtime_benchmark_table()
    out = ARTIFACT_DIR / output_filename
    fig, ax = plt.subplots(figsize=(8.2, 4.8))
    x = pd.to_numeric(df["N_sim"], errors="coerce")
    for col in ["APF (s)", "FDTD (s)", "CST (s)", "HFSS (s)", "PNGF, 1 core (s)", "PNGF, 128 cores (s)"]:
        ax.plot(x, pd.to_numeric(df[col], errors="coerce"), marker="o", label=col.replace(" (s)", ""))
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlabel("simulation unknowns, N_sim")
    ax.set_ylabel("objective-evaluation runtime (s)")
    ax.set_title("Fig. 3b source-data runtime scaling")
    ax.legend(fontsize=7, ncols=2)
    fig.tight_layout()
    fig.savefig(out, dpi=180)
    plt.close(fig)
    return {"path": str(out), "source": f"{SOURCE_ZIP}::source_data_fig3.csv::Fig. 3b", "rows": int(len(df))}


def plot_pngf_speedup(output_filename: str = "Fig2_info_9c7d_workflow_contrast.png") -> dict:
    df = runtime_speedup_table()
    out = ARTIFACT_DIR / output_filename
    fig, ax = plt.subplots(figsize=(8.2, 4.8))
    labels = ["APF", "FDTD", "CST", "HFSS", "PNGF 1 core"]
    cols = ["speedup_vs_APF (s)", "speedup_vs_FDTD (s)", "speedup_vs_CST (s)", "speedup_vs_HFSS (s)", "speedup_vs_PNGF, 1 core (s)"]
    vals = [float(pd.to_numeric(df[c], errors="coerce").median()) for c in cols]
    ax.bar(labels, vals, color="#356f8c")
    ax.set_yscale("log")
    ax.set_ylabel("median runtime ratio vs PNGF, 128 cores")
    ax.set_title("Low-rank PNGF speedup contrast from Fig. 3b source data")
    ax.tick_params(axis="x", rotation=25)
    fig.tight_layout()
    fig.savefig(out, dpi=180)
    plt.close(fig)
    return {"path": str(out), "source": f"{SOURCE_ZIP}::source_data_fig3.csv::Fig. 3b", "median_speedups": dict(zip(labels, vals))}


def plot_siw_response_alignment(output_filename: str = "Fig3_info_9c7d_signal_relationship.png") -> dict:
    df = frequency_response_table("source_data_fig6.csv", "Fig. 6b")
    out = ARTIFACT_DIR / output_filename
    fig, ax = plt.subplots(figsize=(8.2, 4.8))
    pairs = [
        ("frequency_GHz__S21 Measured (dB)", "S21 Measured (dB)", "measured S21"),
        ("frequency_GHz__S21 HFSS (dB)", "S21 HFSS (dB)", "HFSS S21"),
        ("frequency_GHz__S21 FDTD (dB)", "S21 FDTD (dB)", "FDTD S21"),
        ("frequency_GHz__S11 Measured (dB)", "S11 Measured (dB)", "measured S11"),
        ("frequency_GHz__S11 HFSS (dB)", "S11 HFSS (dB)", "HFSS S11"),
        ("frequency_GHz__S11 FDTD (dB)", "S11 FDTD (dB)", "FDTD S11"),
    ]
    for f_col, metric_col, label in pairs:
        if f_col in df and metric_col in df:
            tmp = df[[f_col, metric_col]].dropna()
            ax.plot(tmp[f_col], tmp[metric_col], lw=1.0, alpha=0.85, label=label)
    ax.set_xlabel("frequency (GHz)")
    ax.set_ylabel("scattering parameter (dB)")
    ax.set_title("Fig. 6b source-data measured/simulated SIW response")
    ax.legend(fontsize=7, ncols=2)
    fig.tight_layout()
    fig.savefig(out, dpi=180)
    plt.close(fig)
    return {"path": str(out), "source": f"{SOURCE_ZIP}::source_data_fig6.csv::Fig. 6b", "series": [p[2] for p in pairs]}


def package_smoke_test() -> dict:
    return {
        "inventory": source_inventory(),
        "runtime_rows": int(len(runtime_benchmark_table())),
        "alignment": response_alignment_summary(),
        "plots": [plot_runtime_scaling(), plot_pngf_speedup(), plot_siw_response_alignment()],
    }

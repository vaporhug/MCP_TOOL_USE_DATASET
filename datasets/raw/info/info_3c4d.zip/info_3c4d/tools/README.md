
# Tools

- `data_processing.py`: CSV/table readers and plot output helpers.
- `database_retrieval.py`: local file inventory helpers for the bundled AI-for-science release.
- `information_tools.py`: keyword growth, capability ranking, impact, collaboration, and alignment primitives.

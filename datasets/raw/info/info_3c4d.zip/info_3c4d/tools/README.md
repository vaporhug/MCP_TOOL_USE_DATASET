
# Tools

- `data_processing.py`: CSV/table readers and plot output helpers.
- `database_retrieval.py`: local file inventory helpers for the bundled AI-for-science release.
- `information_tools.py`: keyword growth, capability ranking, impact, collaboration, and alignment primitives.
  - Includes composable metric functions such as `keyword_share_at_year(...)`,
    `capability_share_at_year(...)`, `impact_score_at_year(...)`,
    `collaboration_share_by_flag(...)`, and `education_alignment_corr_at_year(...)`.
  - `write_checkpoint_table(...)` writes caller-defined checkpoint rows to CSV with
    path normalization against the task-package root.

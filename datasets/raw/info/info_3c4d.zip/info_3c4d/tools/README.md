
# Tools

- `data_processing.py`: CSV/table readers and plot output helpers.
- `database_retrieval.py`: local file inventory helpers for the bundled AI-for-science release.
- `information_tools.py`: keyword growth, capability ranking, impact, collaboration, and alignment primitives.
  - Includes `build_ai4science_checkpoints(...)` to generate `artifacts/checkpoints.csv`
    from released CSV rows with explicit source-path provenance.
  - For `build_ai4science_checkpoints(...)`, relative `output_csv` paths are resolved
    against the task-package root (not the caller's current working directory).

from __future__ import annotations

from pathlib import Path


def list_files(root: str) -> list[str]:
    root_path = Path(root)
    return [str(p.relative_to(root_path)) for p in sorted(root_path.rglob("*")) if p.is_file()]


def find_files(root: str, suffix: str = "") -> list[str]:
    root_path = Path(root)
    return [str(p.relative_to(root_path)) for p in sorted(root_path.rglob(f"*{suffix}")) if p.is_file()]


def reference_inventory(reference_root: str) -> list[str]:
    return list_files(reference_root)

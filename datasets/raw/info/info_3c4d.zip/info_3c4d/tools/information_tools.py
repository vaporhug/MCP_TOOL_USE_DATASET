
from __future__ import annotations

from pathlib import Path
import matplotlib.pyplot as plt
import pandas as pd


def _base(data_root: str) -> Path:
    p = Path(data_root)
    if (p / 'Data').exists():
        return p / 'Data'
    return p


def _safe_corr(x: pd.Series, y: pd.Series) -> float | None:
    pair = pd.DataFrame({'x': x, 'y': y}).dropna()
    if len(pair) < 3:
        return None
    if pair['x'].nunique() < 2 or pair['y'].nunique() < 2:
        return None
    return float(pair['x'].corr(pair['y']))


def _exclude_computer_science(df: pd.DataFrame, field_col: str = 'FName_L0') -> pd.DataFrame:
    mask = df[field_col].astype(str).str.strip().str.lower() != 'computer science'
    return df[mask].copy()


def ai_keyword_growth_summary(data_root: str) -> dict:
    data = _base(data_root)
    df = pd.read_csv(data / 'df_ngram_temporal_trend.csv')
    keywords = ['machine learning', 'convolutional neural network', 'deep learning', 'artificial intelligence']
    rows = {}
    for kw in keywords:
        row = df[df['ngram'] == kw].iloc[0]
        rows[kw] = {str(y): float(row[str(y)]) for y in [2005, 2010, 2015, 2019]}
    return {
        'keywords': rows,
        'growth': {
            'machine_learning_2005_2019': float(rows['machine learning']['2019'] / max(rows['machine learning']['2005'], 1e-9)),
            'cnn_2005_2019': float(rows['convolutional neural network']['2019'] / max(rows['convolutional neural network']['2005'], 1e-9)),
            'deep_learning_2010_2019': float(rows['deep learning']['2019'] / max(rows['deep learning']['2010'], 1e-9)),
            'ai_2005_2019': float(rows['artificial intelligence']['2019'] / max(rows['artificial intelligence']['2005'], 1e-9)),
        },
    }


def ai_capability_summary(data_root: str) -> dict:
    data = _base(data_root)
    df = pd.read_csv(data / 'df_AI_capability_top.csv')
    first = df.iloc[0].to_dict()
    latest = df.iloc[-1].to_dict()
    top_latest = sorted([(k, float(v)) for k, v in latest.items() if k != 'Year'], key=lambda kv: kv[1], reverse=True)[:8]
    top_first = sorted([(k, float(v)) for k, v in first.items() if k != 'Year'], key=lambda kv: kv[1], reverse=True)[:8]
    return {
        'first_year': int(first['Year']),
        'latest_year': int(latest['Year']),
        'top_capabilities_first_year': top_first,
        'top_capabilities_latest_year': top_latest,
    }


def ai_impact_summary(data_root: str) -> dict:
    data = _base(data_root)
    direct = pd.read_csv(data / 'df_direct_impact_L0_fix2015.csv')
    potential = pd.read_csv(data / 'df_potential_impact_L0.csv')
    d = direct[direct['Year'] == direct['Year'].max()].sort_values('DS', ascending=False).head(5)
    p = potential[potential['Year'] == potential['Year'].max()].sort_values('PS', ascending=False).head(5)
    return {
        'direct_top_fields': d[['Field_Name_L0', 'DS']].to_dict('records'),
        'potential_top_fields': p[['Field_Name_L0', 'PS']].to_dict('records'),
    }


def ai_collaboration_summary(data_root: str, include_computer_science: bool = False) -> dict:
    data = _base(data_root)
    by_field = pd.read_csv(data / 'df_AI_paper_collaboration.csv')
    temporal = pd.read_csv(data / 'df_AI_paper_collaboration_temporal.csv')

    scope = 'all_fields'
    if not include_computer_science:
        by_field = _exclude_computer_science(by_field, 'FName_L0')
        temporal = _exclude_computer_science(temporal, 'FName_L0')
        scope = 'non_cs_fields'

    totals = by_field.groupby('flag', as_index=False)['count'].sum().sort_values('count', ascending=False)
    total_count = float(totals['count'].sum())
    totals['share'] = totals['count'] / total_count if total_count > 0 else 0.0

    latest_year = int(temporal['year'].max())
    latest_by_flag = (
        temporal[temporal['year'] == latest_year]
        .groupby('flag', as_index=False)['count']
        .sum()
        .sort_values('count', ascending=False)
    )
    latest_total = float(latest_by_flag['count'].sum())
    latest_by_flag['share'] = latest_by_flag['count'] / latest_total if latest_total > 0 else 0.0
    psychology = (
        temporal[temporal['FName_L0'] == 'psychology']
        .groupby(['year', 'flag'], as_index=False)['count']
        .sum()
        .sort_values(['year', 'count'], ascending=[True, False])
    )
    return {
        'scope': scope,
        'collaboration_totals': totals.to_dict('records'),
        'latest_year': latest_year,
        'latest_year_total': latest_total,
        'latest_year_by_flag': latest_by_flag.to_dict('records'),
        'psychology_by_year_by_flag': psychology.to_dict('records'),
    }


def ai_education_alignment_summary(data_root: str) -> dict:
    data = _base(data_root)
    df = pd.read_csv(data / 'df_AI_education_ref_share_gr_above_5.csv')
    latest_year = int(df['Year'].max())
    excluded = {'computer science', 'mathematics', 'engineering'}

    per_year = []
    for year, grp in df.groupby('Year'):
        g = grp.dropna(subset=['Edu_Score', 'Sci_Score']).copy()
        corr_all = _safe_corr(g['Edu_Score'], g['Sci_Score'])
        mask = ~g['Edu_Field'].astype(str).str.lower().isin(excluded)
        g_ex = g[mask]
        corr_ex = _safe_corr(g_ex['Edu_Score'], g_ex['Sci_Score'])
        per_year.append({'Year': int(year), 'corr_all_fields': corr_all, 'corr_excluding_cme': corr_ex})

    latest = pd.DataFrame(per_year)
    latest_row = latest.loc[latest['Year'] == latest_year].iloc[0]
    return {
        'rows': int(len(df)),
        'latest_year': latest_year,
        'correlation_by_year': per_year,
        'latest_year_corr_all_fields': latest_row['corr_all_fields'],
        'latest_year_corr_excluding_cme': latest_row['corr_excluding_cme'],
        'excluded_fields': sorted(excluded),
    }


def keyword_share_at_year(data_root: str, keyword: str, year: int) -> dict:
    data = _base(data_root)
    trend = pd.read_csv(data / 'df_ngram_temporal_trend.csv')
    row = trend[trend['ngram'] == keyword]
    if row.empty:
        raise ValueError(f'keyword not found in trend table: {keyword}')
    return {
        'keyword': keyword,
        'year': int(year),
        'value': float(row.iloc[0][str(year)]),
    }


def capability_share_at_year(data_root: str, capability_name: str, year: int) -> dict:
    data = _base(data_root)
    capability = pd.read_csv(data / 'df_AI_capability_top.csv')
    year_df = capability[capability['Year'] == year]
    if year_df.empty:
        raise ValueError(f'Year {year} not found in df_AI_capability_top.csv')
    cap_col = None
    for col in capability.columns:
        if str(col).strip().lower() == str(capability_name).strip().lower():
            cap_col = col
            break
    if cap_col is None:
        raise ValueError(f"Capability column not found: {capability_name}")
    return {
        'capability': cap_col,
        'year': int(year),
        'value': float(year_df.iloc[0][cap_col]),
    }


def impact_score_at_year(
    data_root: str,
    score_type: str,
    field_name: str,
    year: int,
) -> dict:
    data = _base(data_root)
    score_type_norm = str(score_type).strip().lower()
    if score_type_norm == 'direct':
        df = pd.read_csv(data / 'df_direct_impact_L0_fix2015.csv')
        value_col = 'DS'
    elif score_type_norm == 'potential':
        df = pd.read_csv(data / 'df_potential_impact_L0.csv')
        value_col = 'PS'
    else:
        raise ValueError("score_type must be 'direct' or 'potential'")
    match = df[
        (df['Year'] == year)
        & (df['Field_Name_L0'].astype(str).str.strip().str.lower() == str(field_name).strip().lower())
    ]
    if match.empty:
        raise ValueError(f'No {score_type_norm} impact row for year={year}, field={field_name}')
    return {
        'score_type': score_type_norm,
        'field_name': str(field_name),
        'year': int(year),
        'value_column': value_col,
        'value': float(match.iloc[0][value_col]),
    }


def collaboration_share_by_flag(data_root: str, include_computer_science: bool = False) -> dict:
    data = _base(data_root)
    collab = pd.read_csv(data / 'df_AI_paper_collaboration.csv')
    scope = 'all_fields'
    if not include_computer_science:
        collab = _exclude_computer_science(collab, 'FName_L0')
        scope = 'non_cs_fields'
    totals = collab.groupby('flag', as_index=False)['count'].sum()
    total_count = float(totals['count'].sum())
    totals['share'] = totals['count'] / total_count if total_count > 0 else 0.0
    return {
        'scope': scope,
        'total_count': total_count,
        'by_flag': totals.sort_values('count', ascending=False).to_dict('records'),
    }


def education_alignment_corr_at_year(
    data_root: str,
    year: int,
    excluded_fields: list[str] | None = None,
) -> dict:
    data = _base(data_root)
    df = pd.read_csv(data / 'df_AI_education_ref_share_gr_above_5.csv')
    if year not in set(int(v) for v in df['Year'].unique()):
        raise ValueError(f'Year {year} not found in education alignment table')
    selected = df[df['Year'] == year].dropna(subset=['Edu_Score', 'Sci_Score']).copy()
    if excluded_fields:
        excluded = {str(x).strip().lower() for x in excluded_fields}
        selected = selected[~selected['Edu_Field'].astype(str).str.lower().isin(excluded)]
    corr = _safe_corr(selected['Edu_Score'], selected['Sci_Score'])
    return {
        'year': int(year),
        'excluded_fields': excluded_fields or [],
        'value': None if corr is None else float(corr),
        'n_rows': int(len(selected)),
    }


def write_checkpoint_table(rows: list[dict], output_csv: str) -> dict:
    if not rows:
        raise ValueError('rows must not be empty')
    required = {'checkpoint', 'value', 'unit', 'source_path'}
    missing = [required - set(map(str, row.keys())) for row in rows]
    if any(missing):
        raise ValueError("Each row must contain 'checkpoint', 'value', 'unit', and 'source_path'")
    out = Path(output_csv)
    if not out.is_absolute():
        out = Path(__file__).resolve().parents[1] / out
    out.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(out, index=False)
    return {'path': str(out), 'n_rows': int(len(rows))}


def plot_ai_keyword_trends(data_root: str, output_path: str) -> dict:
    data = _base(data_root)
    trend = pd.read_csv(data / 'df_ngram_temporal_trend.csv')
    years = [2005, 2010, 2015, 2019]
    plt.figure(figsize=(8.4, 4.6))
    for kw in ['machine learning', 'convolutional neural network', 'deep learning', 'artificial intelligence']:
        row = trend[trend['ngram'] == kw].iloc[0]
        plt.plot(years, [row[str(y)] for y in years], marker='o', label=kw)
    plt.xlabel('Year')
    plt.ylabel('Share of AI-related n-grams')
    plt.legend(fontsize=8)
    plt.tight_layout()
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output_path, dpi=200)
    plt.close()
    return {'path': output_path}


def plot_ai_impact_alignment(data_root: str, output_path: str) -> dict:
    data = _base(data_root)
    direct = pd.read_csv(data / 'df_direct_impact_L0_fix2015.csv')
    potential = pd.read_csv(data / 'df_potential_impact_L0.csv')
    d = direct[direct['Year'] == direct['Year'].max()].sort_values('DS', ascending=False).head(8)
    p = potential[potential['Year'] == potential['Year'].max()].sort_values('PS', ascending=False).head(8)
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))
    axes[0].barh(d['Field_Name_L0'][::-1], d['DS'][::-1], color='#2b8cbe')
    axes[0].set_title('Direct impact, top fields')
    axes[1].barh(p['Field_Name_L0'][::-1], p['PS'][::-1], color='#fdae61')
    axes[1].set_title('Potential impact, top fields')
    for ax in axes:
        ax.tick_params(axis='y', labelsize=8)
    plt.tight_layout()
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output_path, dpi=200)
    plt.close()
    return {'path': output_path}


def plot_ai_capability_profile(data_root: str, output_path: str) -> dict:
    data = _base(data_root)
    df = pd.read_csv(data / 'df_AI_capability_top.csv')
    first = df.iloc[0]
    latest = df.iloc[-1]
    caps = [c for c in df.columns if c != 'Year']
    top = sorted(caps, key=lambda c: float(latest[c]), reverse=True)[:10]
    out = pd.DataFrame(
        {
            'capability': top,
            str(int(first['Year'])): [float(first[c]) for c in top],
            str(int(latest['Year'])): [float(latest[c]) for c in top],
        }
    )
    fig, ax = plt.subplots(figsize=(10, 5))
    width = 0.4
    x = range(len(top))
    ax.bar([i - width / 2 for i in x], out[str(int(first['Year']))], width=width, label=str(int(first['Year'])), color='#9ecae1')
    ax.bar([i + width / 2 for i in x], out[str(int(latest['Year']))], width=width, label=str(int(latest['Year'])), color='#08519c')
    ax.set_xticks(list(x), top, rotation=30, ha='right')
    ax.set_ylabel('Capability share')
    ax.set_title('AI capability profile shift (first vs latest year)')
    ax.legend(frameon=False)
    plt.tight_layout()
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output_path, dpi=200)
    plt.close()
    return {'path': output_path}


def plot_ai_collaboration_balance(
    data_root: str,
    output_path: str,
    include_computer_science: bool = False,
) -> dict:
    data = _base(data_root)
    coll = pd.read_csv(data / 'df_AI_paper_collaboration.csv')
    scope = 'all_fields'
    if not include_computer_science:
        coll = _exclude_computer_science(coll, 'FName_L0')
        scope = 'non_cs_fields'
    totals = coll.groupby('flag', as_index=False)['count'].sum()
    totals['share'] = totals['count'] / totals['count'].sum()
    flag_order = ['Domain & non-CS', 'Domain & CS', 'Non-domain & CS', 'Non-domain & non-CS']
    totals['flag'] = pd.Categorical(totals['flag'], categories=flag_order, ordered=True)
    totals = totals.sort_values('flag')

    fig, ax = plt.subplots(figsize=(9, 4.8))
    palette = {
        'Domain & CS': '#1f77b4',
        'Domain & non-CS': '#ff7f0e',
        'Non-domain & CS': '#2ca02c',
        'Non-domain & non-CS': '#d62728',
    }
    colors = [palette.get(f, '#666666') for f in totals['flag'].astype(str)]
    ax.bar(totals['flag'].astype(str), totals['share'], color=colors)
    for i, row in enumerate(totals.itertuples(index=False)):
        ax.text(i, float(row.share) + 0.01, f"{100 * float(row.share):.1f}%", ha='center', va='bottom', fontsize=9)
    ax.set_ylabel('Share of non-CS collaborations')
    if scope == 'non_cs_fields':
        ax.set_title('AI collaboration composition (non-CS aggregate)')
    else:
        ax.set_title('AI collaboration composition (all fields)')
    ax.set_ylim(0, max(0.5, float(totals['share'].max()) + 0.1))
    ax.tick_params(axis='x', rotation=20)
    plt.tight_layout()
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output_path, dpi=200)
    plt.close()
    return {
        'path': output_path,
        'scope': scope,
        'totals': totals.to_dict('records'),
    }


def plot_ai_education_alignment(data_root: str, output_path: str) -> dict:
    data = _base(data_root)
    df = pd.read_csv(data / 'df_AI_education_ref_share_gr_above_5.csv')
    excluded = {'computer science', 'mathematics', 'engineering'}
    years = sorted(int(y) for y in df['Year'].unique())
    corr_all = []
    corr_ex = []
    for y in years:
        g = df[df['Year'] == y].dropna(subset=['Edu_Score', 'Sci_Score']).copy()
        corr_y = _safe_corr(g['Edu_Score'], g['Sci_Score'])
        corr_all.append(float('nan') if corr_y is None else corr_y)
        g_ex = g[~g['Edu_Field'].astype(str).str.lower().isin(excluded)]
        corr_ex_y = _safe_corr(g_ex['Edu_Score'], g_ex['Sci_Score'])
        corr_ex.append(float('nan') if corr_ex_y is None else corr_ex_y)

    plt.figure(figsize=(10, 5))
    plt.plot(years, corr_all, marker='o', color='#1f77b4', label='All fields')
    plt.plot(years, corr_ex, marker='o', color='#d62728', label='Excluding CS/Math/Engineering')
    plt.axhline(0.0, color='gray', lw=1, ls='--')
    plt.xlabel('Year')
    plt.ylabel('Correlation(Edu_Score, Sci_Score)')
    plt.title('Education alignment correlation and mismatch trend')
    plt.legend(frameon=False)
    plt.tight_layout()
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output_path, dpi=200)
    plt.close()
    return {'path': output_path}


def package_smoke_test(data_root: str, artifact_dir: str | None = None) -> dict:
    k = ai_keyword_growth_summary(data_root)
    c = ai_capability_summary(data_root)
    i = ai_impact_summary(data_root)
    col = ai_collaboration_summary(data_root)
    edu = ai_education_alignment_summary(data_root)

    plots = []
    if artifact_dir:
        root = Path(artifact_dir)
        p1 = plot_ai_keyword_trends(data_root, str(root / 'smoke_ai_keyword_trends.png'))
        p2 = plot_ai_capability_profile(data_root, str(root / 'smoke_ai_capability_profile.png'))
        p3 = plot_ai_impact_alignment(data_root, str(root / 'smoke_ai_impact_alignment.png'))
        p4 = plot_ai_collaboration_balance(data_root, str(root / 'smoke_ai_collaboration_balance.png'))
        p5 = plot_ai_education_alignment(data_root, str(root / 'smoke_ai_education_alignment.png'))
        plots = [p1['path'], p2['path'], p3['path'], p4['path'], p5['path']]

    return {
        'keyword': k,
        'capability': c,
        'impact': i,
        'collaboration': col,
        'education': edu,
        'plots': plots,
    }

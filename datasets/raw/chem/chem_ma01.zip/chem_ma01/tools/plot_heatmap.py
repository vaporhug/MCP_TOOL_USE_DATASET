"""Heatmap visualization tools.

Plot functions for assay similarity heatmaps, assay-compound matrices,
and per-assay performance heatmaps.
"""
import numpy as np
from typing import Dict, List, Optional, Tuple


def plot_jaccard_heatmap(
    similarity_matrix: np.ndarray,
    assay_labels: Optional[List[str]] = None,
    save_path: str = "artifacts/fig_jaccard_heatmap.png",
    figsize: Tuple[float, float] = (12, 10),
    cmap: str = "YlOrRd",
) -> Dict[str, str]:
    """Plot heatmap of Jaccard similarity between assays.

    Reproduces the style of Fig 1D showing assay similarity based on
    shared active compounds.

    Parameters
    ----------
    similarity_matrix : np.ndarray
        Symmetric Jaccard similarity matrix (n_assays x n_assays).
    assay_labels : list of str, optional
        Labels for assays. If None, uses indices.
    save_path : str
        Output file path.
    figsize : tuple
        Figure size.
    cmap : str
        Colormap name.

    Returns
    -------
    dict
        {"path": save_path}
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=figsize)
    im = ax.imshow(similarity_matrix, cmap=cmap, aspect="auto",
                    vmin=0, vmax=1)
    plt.colorbar(im, ax=ax, label="Jaccard Similarity")
    ax.set_title("Assay Similarity (Jaccard Index of Shared Hits)", fontsize=13)
    ax.set_xlabel("Assay Index")
    ax.set_ylabel("Assay Index")

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    return {"path": save_path}


def plot_performance_heatmap(
    performance_df,
    save_path: str = "artifacts/fig_performance_heatmap.png",
    figsize: Tuple[float, float] = (14, 8),
) -> Dict[str, str]:
    """Plot heatmap of AUROC scores across assays and modality combinations.

    Shows which assays are well-predicted by which modalities,
    visualizing the complementarity pattern.

    Parameters
    ----------
    performance_df : pd.DataFrame
        Pivot table with assay IDs as rows and modality labels as columns,
        values are AUROC scores.
    save_path : str
        Output file path.
    figsize : tuple
        Figure size.

    Returns
    -------
    dict
        {"path": save_path}
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=figsize)
    im = ax.imshow(performance_df.values, cmap="RdYlGn", aspect="auto",
                    vmin=0.3, vmax=1.0)
    plt.colorbar(im, ax=ax, label="AUROC")

    ax.set_xticks(range(len(performance_df.columns)))
    ax.set_xticklabels(performance_df.columns, rotation=45, ha="right")
    ax.set_ylabel("Assay (sorted by best AUROC)")
    ax.set_title("Per-Assay AUROC Across Modalities", fontsize=13)

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    return {"path": save_path}


def plot_sparsity_heatmap(
    matrix_values: np.ndarray,
    save_path: str = "artifacts/fig_sparsity_heatmap.png",
    figsize: Tuple[float, float] = (14, 8),
    max_compounds: int = 500,
    max_assays: int = 100,
) -> Dict[str, str]:
    """Plot the sparsity pattern of the compound-assay matrix.

    Shows the pattern of tested vs untested compound-assay pairs.

    Parameters
    ----------
    matrix_values : np.ndarray
        Binary activity matrix with NaN for missing.
    save_path : str
        Output file path.
    figsize : tuple
        Figure size.
    max_compounds : int
        Max compounds to display (subsampled).
    max_assays : int
        Max assays to display (subsampled).

    Returns
    -------
    dict
        {"path": save_path}
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    n_compounds, n_assays = matrix_values.shape
    step_c = max(1, n_compounds // max_compounds)
    step_a = max(1, n_assays // max_assays)
    sub = matrix_values[::step_c, ::step_a]

    display = np.full_like(sub, 0.5)  # gray for missing
    display[sub == 0] = 0.0  # black for inactive
    display[sub == 1] = 1.0  # white for active
    display[np.isnan(sub)] = 0.5

    fig, ax = plt.subplots(figsize=figsize)
    ax.imshow(display, cmap="gray", aspect="auto", vmin=0, vmax=1)
    ax.set_xlabel("Assay Index")
    ax.set_ylabel("Compound Index")
    ax.set_title("Compound-Assay Matrix Sparsity Pattern", fontsize=13)

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    return {"path": save_path}

"""Multi-task neural network model for compound activity prediction.

Implements a feedforward fully-connected network trained in multi-task
mode with binary cross-entropy loss, handling missing labels via masking.
"""
import numpy as np
from typing import Dict, List, Optional, Tuple


def build_multitask_model(
    input_dim: int,
    n_tasks: int,
    hidden_layers: List[int] = [1000, 500],
    dropout: float = 0.25,
) -> Dict:
    """Build a multi-task feedforward neural network specification.

    Architecture matches the paper: up to 3 hidden layers with ReLU
    activation, dropout, and one sigmoid output per assay.

    Parameters
    ----------
    input_dim : int
        Number of input features (e.g. 2048 for Morgan FP).
    n_tasks : int
        Number of assay tasks (output neurons).
    hidden_layers : list of int
        Sizes of hidden layers.
    dropout : float
        Dropout rate applied to each hidden layer.

    Returns
    -------
    dict
        Model specification with keys: input_dim, n_tasks, hidden_layers,
        dropout, architecture_summary.
    """
    return {
        "input_dim": input_dim,
        "n_tasks": n_tasks,
        "hidden_layers": hidden_layers,
        "dropout": dropout,
        "architecture_summary": (
            f"Input({input_dim}) -> "
            + " -> ".join(
                f"Dense({h})->ReLU->Dropout({dropout})" for h in hidden_layers
            )
            + f" -> Dense({n_tasks})->Sigmoid"
        ),
    }


def train_multitask_model(
    X_train: np.ndarray,
    Y_train: np.ndarray,
    X_val: Optional[np.ndarray] = None,
    Y_val: Optional[np.ndarray] = None,
    hidden_layers: List[int] = [1000, 500],
    dropout: float = 0.25,
    batch_size: int = 50,
    epochs: int = 100,
    learning_rate: float = 1e-3,
    early_stopping_patience: int = 10,
) -> Dict:
    """Train a multi-task neural network for compound activity prediction.

    Uses binary cross-entropy with masking for missing labels (NaN values
    in Y_train are ignored during loss computation). Mini-batch size of 50
    compounds as in the paper.

    Parameters
    ----------
    X_train : np.ndarray
        Training features, shape (n_train, n_features).
    Y_train : np.ndarray
        Training labels, shape (n_train, n_tasks). NaN = missing.
    X_val : np.ndarray, optional
        Validation features.
    Y_val : np.ndarray, optional
        Validation labels.
    hidden_layers : list of int
        Hidden layer sizes.
    dropout : float
        Dropout rate.
    batch_size : int
        Mini-batch size (paper uses 50).
    epochs : int
        Maximum training epochs.
    learning_rate : float
        Learning rate for Adam optimizer.
    early_stopping_patience : int
        Epochs to wait before early stopping.

    Returns
    -------
    dict
        Keys: model (trained model object), train_losses (list),
        val_losses (list if validation provided), best_epoch (int).
    """
    import torch
    import torch.nn as nn

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    n_features = X_train.shape[1]
    n_tasks = Y_train.shape[1]

    # Build model
    layers = []
    prev_dim = n_features
    for h in hidden_layers:
        layers.append(nn.Linear(prev_dim, h))
        layers.append(nn.ReLU())
        if dropout > 0:
            layers.append(nn.Dropout(dropout))
        prev_dim = h
    layers.append(nn.Linear(prev_dim, n_tasks))
    layers.append(nn.Sigmoid())
    model = nn.Sequential(*layers).to(device)

    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
    criterion = nn.BCELoss(reduction="none")

    # Prepare tensors
    mask_train = ~np.isnan(Y_train)
    Y_train_filled = np.nan_to_num(Y_train, nan=0.0)
    X_t = torch.tensor(X_train, dtype=torch.float32).to(device)
    Y_t = torch.tensor(Y_train_filled, dtype=torch.float32).to(device)
    M_t = torch.tensor(mask_train, dtype=torch.float32).to(device)

    train_losses = []
    val_losses = []
    best_val_loss = float("inf")
    best_epoch = 0
    best_state = None

    for epoch in range(epochs):
        model.train()
        indices = np.random.permutation(len(X_train))
        epoch_loss = 0.0
        n_batches = 0

        for start in range(0, len(X_train), batch_size):
            idx = indices[start : start + batch_size]
            xb = X_t[idx]
            yb = Y_t[idx]
            mb = M_t[idx]

            pred = model(xb)
            loss = (criterion(pred, yb) * mb).sum() / mb.sum().clamp(min=1)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            epoch_loss += loss.item()
            n_batches += 1

        train_losses.append(epoch_loss / max(n_batches, 1))

        if X_val is not None and Y_val is not None:
            model.eval()
            with torch.no_grad():
                mask_val = ~np.isnan(Y_val)
                Y_val_filled = np.nan_to_num(Y_val, nan=0.0)
                xv = torch.tensor(X_val, dtype=torch.float32).to(device)
                yv = torch.tensor(Y_val_filled, dtype=torch.float32).to(device)
                mv = torch.tensor(mask_val, dtype=torch.float32).to(device)
                pred_v = model(xv)
                vloss = (criterion(pred_v, yv) * mv).sum() / mv.sum().clamp(min=1)
                val_losses.append(vloss.item())

                if vloss.item() < best_val_loss:
                    best_val_loss = vloss.item()
                    best_epoch = epoch
                    best_state = {k: v.clone() for k, v in model.state_dict().items()}
                elif epoch - best_epoch >= early_stopping_patience:
                    break

    if best_state is not None:
        model.load_state_dict(best_state)

    return {
        "model": model,
        "train_losses": train_losses,
        "val_losses": val_losses,
        "best_epoch": best_epoch,
    }


def predict_multitask(
    model,
    X: np.ndarray,
) -> np.ndarray:
    """Generate multi-task predictions (hit probabilities) for compounds.

    Parameters
    ----------
    model : torch.nn.Module
        Trained multi-task model.
    X : np.ndarray
        Feature matrix, shape (n_compounds, n_features).

    Returns
    -------
    np.ndarray
        Predicted probabilities, shape (n_compounds, n_tasks).
    """
    import torch

    device = next(model.parameters()).device
    model.eval()
    with torch.no_grad():
        xt = torch.tensor(X, dtype=torch.float32).to(device)
        preds = model(xt).cpu().numpy()
    return preds

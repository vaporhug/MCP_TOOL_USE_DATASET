"""Data loading and preprocessing utilities for compound-assay activity prediction.

Handles loading the sparse assay matrix, metadata, SMILES strings, and
prediction result files.
"""
import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Tuple


def load_assay_matrix(
    path: str = "input_data/data/assay_matrix_discrete.csv",
) -> pd.DataFrame:
    """Load the compound-assay binary activity matrix.

    The matrix has compounds as rows (indexed by SMILES) and 270 assay
    columns with binary labels (0/1) and many missing values (NaN).

    Parameters
    ----------
    path : str
        Path to the CSV file.

    Returns
    -------
    pd.DataFrame
        DataFrame with SMILES as index and assay IDs as columns.
        Values are 0 (inactive), 1 (active), or NaN (not tested).
    """
    df = pd.read_csv(path)
    df = df.set_index("smiles")
    return df


def load_assay_metadata(
    path: str = "input_data/data/assay_metadata.csv",
) -> pd.DataFrame:
    """Load assay metadata with assay names, types, and readout information.

    Parameters
    ----------
    path : str
        Path to the CSV file.

    Returns
    -------
    pd.DataFrame
        Columns: PUMA_ASSAY_ID, ASSAY_NAME, OBS_NAME, OBS_SOURCE,
        ASSAY_TYPE, READOUT_TYPE.
    """
    return pd.read_csv(path)


def load_assay_metadata_expanded(
    path: str = "input_data/data/assay_metadata_expanded.csv",
) -> pd.DataFrame:
    """Load expanded assay metadata with descriptions and database IDs.

    Parameters
    ----------
    path : str
        Path to the CSV file.

    Returns
    -------
    pd.DataFrame
        Columns: PUMA_ASSAY_ID, ASSAY_NAME, ASSAY_DESC, ASSAY_DB_ID,
        OBS_NAME, OBS_SOURCE, ASSAY_TYPE, READOUT_TYPE.
    """
    return pd.read_csv(path)


def load_prediction_results(
    path: str = "input_data/data/scaffold_median_AUC.csv",
) -> pd.DataFrame:
    """Load per-assay prediction performance (median AUROC across CV folds).

    Each row is one (assay_id, descriptor) pair. Descriptors encode the
    modality combination, e.g. 'cp_es_op' = chemical structure (Chemprop),
    'ge_es_op' = gene expression, 'mobc_es_op' = morphology (batch corrected),
    'late_fusion_cs_ge' = CS+GE late fusion, etc.

    Parameters
    ----------
    path : str
        Path to the CSV file.

    Returns
    -------
    pd.DataFrame
        Columns: assay_id, auc, descriptor, auc_50, auc_70, auc_90.
    """
    df = pd.read_csv(path)
    # Drop any stray repeated-header rows and coerce the AUROC column to float
    # so threshold comparisons (auc > t) work on every row.
    if "descriptor" in df.columns:
        df = df[df["descriptor"] != "descriptor"].copy()
    if "auc" in df.columns:
        df["auc"] = pd.to_numeric(df["auc"], errors="coerce")
        df = df[df["auc"].notna()].copy()
    # Convert boolean columns from string or native bool
    for col in ["auc_50", "auc_70", "auc_90"]:
        if col in df.columns:
            df[col] = df[col].astype(str).str.strip().str.upper() == "TRUE"
    return df


def load_enrichment_factors(
    path: str = "input_data/data/scaffold_median_EF.csv",
) -> pd.DataFrame:
    """Load per-assay enrichment factor results.

    Parameters
    ----------
    path : str
        Path to the CSV file.

    Returns
    -------
    pd.DataFrame
        Columns: assay_id, descriptor, EF1%, EF5%, EF10%.
    """
    return pd.read_csv(path)


def load_smiles(
    path: str = "input_data/data/smiles.txt",
) -> List[str]:
    """Load the list of SMILES strings for all compounds.

    Parameters
    ----------
    path : str
        Path to the text file.

    Returns
    -------
    list of str
        SMILES strings (one per compound).
    """
    df = pd.read_csv(path)
    return df["smiles"].tolist()


def compute_matrix_sparsity(matrix: pd.DataFrame) -> Dict[str, float]:
    """Compute sparsity statistics of the compound-assay matrix.

    Parameters
    ----------
    matrix : pd.DataFrame
        The binary activity matrix (compounds x assays).

    Returns
    -------
    dict
        Keys: n_compounds, n_assays, total_entries, non_null_entries,
        sparsity, n_actives, mean_hit_rate.
    """
    n_compounds, n_assays = matrix.shape
    total = n_compounds * n_assays
    non_null = int(matrix.notna().sum().sum())
    n_actives = int((matrix == 1).sum().sum())
    hit_rate = n_actives / non_null if non_null > 0 else 0.0

    return {
        "n_compounds": n_compounds,
        "n_assays": n_assays,
        "total_entries": total,
        "non_null_entries": non_null,
        "sparsity": 1.0 - non_null / total,
        "n_actives": n_actives,
        "mean_hit_rate": hit_rate,
    }


def compute_per_assay_stats(matrix: pd.DataFrame) -> pd.DataFrame:
    """Compute per-assay statistics: count of tested compounds, actives, hit rate.

    Parameters
    ----------
    matrix : pd.DataFrame
        The binary activity matrix.

    Returns
    -------
    pd.DataFrame
        Columns: assay_id, n_tested, n_actives, hit_rate.
    """
    records = []
    for col in matrix.columns:
        tested = matrix[col].notna().sum()
        actives = (matrix[col] == 1).sum()
        records.append({
            "assay_id": col,
            "n_tested": int(tested),
            "n_actives": int(actives),
            "hit_rate": actives / tested if tested > 0 else 0.0,
        })
    return pd.DataFrame(records)

"""Molecular fingerprint generation from SMILES strings.

Provides Morgan fingerprint computation and molecular descriptor extraction
using RDKit.
"""
import numpy as np
from typing import List, Optional, Dict


def compute_morgan_fingerprints(
    smiles_list: List[str],
    radius: int = 2,
    n_bits: int = 2048,
) -> np.ndarray:
    """Compute Morgan (circular) fingerprints for a list of SMILES strings.

    Morgan fingerprints with radius=2 are equivalent to ECFP4.
    The paper uses these as a baseline chemical structure representation
    (compared to Chemprop graph convolutions).

    Parameters
    ----------
    smiles_list : list of str
        SMILES strings for compounds.
    radius : int
        Fingerprint radius (default 2 = ECFP4).
    n_bits : int
        Number of bits in the fingerprint vector.

    Returns
    -------
    np.ndarray
        Binary fingerprint matrix of shape (n_compounds, n_bits).
    """
    from rdkit import Chem
    from rdkit.Chem import AllChem

    fps = []
    for smi in smiles_list:
        mol = Chem.MolFromSmiles(smi)
        if mol is not None:
            fp = AllChem.GetMorganFingerprintAsBitVect(mol, radius, nBits=n_bits)
            fps.append(np.array(fp, dtype=np.int8))
        else:
            fps.append(np.zeros(n_bits, dtype=np.int8))
    return np.vstack(fps)


def compute_tanimoto_similarity(
    fp_matrix: np.ndarray,
) -> np.ndarray:
    """Compute pairwise Tanimoto similarity from binary fingerprint matrix.

    Used for scaffold-based clustering and chemical diversity assessment.

    Parameters
    ----------
    fp_matrix : np.ndarray
        Binary fingerprint matrix of shape (n, n_bits).

    Returns
    -------
    np.ndarray
        Symmetric similarity matrix of shape (n, n).
    """
    fp = fp_matrix.astype(np.float64)
    intersection = fp @ fp.T
    row_sum = fp.sum(axis=1)
    union = row_sum[:, None] + row_sum[None, :] - intersection
    union = np.maximum(union, 1e-12)
    return intersection / union


def compute_molecular_descriptors(
    smiles_list: List[str],
) -> Dict[str, List[float]]:
    """Compute basic molecular descriptors for a list of SMILES.

    Descriptors: molecular weight, LogP, number of H-bond donors/acceptors,
    number of rotatable bonds, TPSA.

    Parameters
    ----------
    smiles_list : list of str
        SMILES strings.

    Returns
    -------
    dict
        Keys are descriptor names, values are lists of floats (one per compound).
    """
    from rdkit import Chem
    from rdkit.Chem import Descriptors

    results = {
        "MolWt": [],
        "LogP": [],
        "HBD": [],
        "HBA": [],
        "RotatableBonds": [],
        "TPSA": [],
    }
    for smi in smiles_list:
        mol = Chem.MolFromSmiles(smi)
        if mol is not None:
            results["MolWt"].append(Descriptors.MolWt(mol))
            results["LogP"].append(Descriptors.MolLogP(mol))
            results["HBD"].append(Descriptors.NumHDonors(mol))
            results["HBA"].append(Descriptors.NumHAcceptors(mol))
            results["RotatableBonds"].append(Descriptors.NumRotatableBonds(mol))
            results["TPSA"].append(Descriptors.TPSA(mol))
        else:
            for key in results:
                results[key].append(np.nan)
    return results

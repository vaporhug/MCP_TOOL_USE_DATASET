"""Assay-level analysis: clustering, type distribution, overlap computation.

Provides tools for analyzing assay similarity, type composition, and
modality overlap/complementarity.
"""
import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple


def compute_jaccard_similarity(
    matrix: pd.DataFrame,
) -> np.ndarray:
    """Compute Jaccard similarity between assays based on shared active compounds.

    Used in the paper (Fig 1D) to assess assay redundancy and filter
    highly correlated assays.

    Parameters
    ----------
    matrix : pd.DataFrame
        Binary activity matrix (compounds x assays).

    Returns
    -------
    np.ndarray
        Symmetric Jaccard similarity matrix of shape (n_assays, n_assays).
    """
    n_assays = matrix.shape[1]
    jaccard = np.zeros((n_assays, n_assays))
    binary = (matrix == 1).values.astype(float)
    binary[np.isnan(matrix.values)] = np.nan

    for i in range(n_assays):
        for j in range(i, n_assays):
            mask = (~np.isnan(binary[:, i])) & (~np.isnan(binary[:, j]))
            if mask.sum() == 0:
                continue
            a = binary[mask, i]
            b = binary[mask, j]
            intersection = np.sum(a * b)
            union = np.sum(np.maximum(a, b))
            if union > 0:
                jaccard[i, j] = intersection / union
                jaccard[j, i] = jaccard[i, j]

    return jaccard


def compute_modality_overlap(
    prediction_df: pd.DataFrame,
    modalities: Optional[Dict[str, str]] = None,
    threshold: float = 0.9,
) -> Dict[str, object]:
    """Compute the overlap of predictable assays across modalities.

    Reproduces the Venn diagram analysis in Figs 2B and 3A by counting, at the
    given AUROC threshold, the assays unique to each modality and shared across
    modalities.

    Parameters
    ----------
    prediction_df : pd.DataFrame
        Prediction results with columns: assay_id, auc, descriptor, auc_90.
    modalities : dict, optional
        Descriptor code -> label mapping.
    threshold : float
        AUROC threshold.

    Returns
    -------
    dict
        Keys: per_modality (dict of sets), pairwise_overlap (dict),
        triple_overlap (set), union (set), n_unique_per_modality (dict).
    """
    if modalities is None:
        modalities = {
            "cp_es_op": "CS",
            "ge_es_op": "GE",
            "mobc_es_op": "MO",
        }

    per_modality = {}
    for desc, label in modalities.items():
        sub = prediction_df[prediction_df["descriptor"] == desc]
        # Apply the AUROC threshold directly so the `threshold` argument takes
        # effect for any value (the precomputed `auc_90` flag only covers 0.9).
        above = set(sub[sub["auc"] > threshold]["assay_id"].tolist())
        per_modality[label] = above

    labels = list(per_modality.keys())
    pairwise = {}
    for i, l1 in enumerate(labels):
        for l2 in labels[i + 1:]:
            key = f"{l1}&{l2}"
            pairwise[key] = per_modality[l1] & per_modality[l2]

    triple = set.intersection(*per_modality.values()) if len(per_modality) >= 3 else set()

    unique = {}
    for label in labels:
        others = set()
        for other_label in labels:
            if other_label != label:
                others |= per_modality[other_label]
        unique[label] = per_modality[label] - others

    return {
        "per_modality": {k: len(v) for k, v in per_modality.items()},
        "per_modality_assays": per_modality,
        "pairwise_overlap": {k: len(v) for k, v in pairwise.items()},
        "triple_overlap": len(triple),
        "union": len(set.union(*per_modality.values())),
        "n_unique_per_modality": {k: len(v) for k, v in unique.items()},
    }


def analyze_assay_types(
    metadata: pd.DataFrame,
    predictable_assays: Optional[Dict[str, set]] = None,
) -> pd.DataFrame:
    """Analyze the distribution of assay types.

    The paper reports 8 assay categories (Fig 1B): Cell (57.8%),
    Biochem (21.9%), Bacterial (11.1%), Yeast (6.7%), Fungal (1.1%),
    plus others.

    Parameters
    ----------
    metadata : pd.DataFrame
        Assay metadata with ASSAY_TYPE column.
    predictable_assays : dict, optional
        Modality label -> set of predictable assay IDs.

    Returns
    -------
    pd.DataFrame
        Type distribution with counts and percentages.
    """
    type_counts = metadata["ASSAY_TYPE"].value_counts()
    result = pd.DataFrame({
        "assay_type": type_counts.index,
        "count": type_counts.values,
        "percentage": (type_counts.values / type_counts.sum() * 100).round(1),
    })

    if predictable_assays is not None:
        for mod, assay_set in predictable_assays.items():
            pred_counts = []
            for atype in result["assay_type"]:
                ids = set(metadata[metadata["ASSAY_TYPE"] == atype]["PUMA_ASSAY_ID"])
                pred_counts.append(len(ids & assay_set))
            result[f"predicted_by_{mod}"] = pred_counts

    return result

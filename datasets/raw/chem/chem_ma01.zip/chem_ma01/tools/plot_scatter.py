"""Scatter plot and UMAP visualization tools.

Plot functions for compound embeddings, assay readout distributions,
and enrichment factor analysis.
"""
import numpy as np
from typing import Dict, List, Optional, Tuple


def plot_compound_embedding(
    embedding: np.ndarray,
    labels: Optional[np.ndarray] = None,
    save_path: str = "artifacts/fig_compound_umap.png",
    figsize: Tuple[float, float] = (8, 6),
    title: str = "Compound Embedding",
    cmap: str = "viridis",
    alpha: float = 0.3,
    point_size: float = 2,
) -> Dict[str, str]:
    """Scatter plot of compound embedding (UMAP or PCA).

    Reproduces Fig 1E showing compounds in 2D feature space.

    Parameters
    ----------
    embedding : np.ndarray
        2D coordinates, shape (n_compounds, 2).
    labels : np.ndarray, optional
        Color labels for points (e.g. cluster IDs or activity).
    save_path : str
        Output file path.
    figsize : tuple
        Figure size.
    title : str
        Plot title.
    cmap : str
        Colormap for labels.
    alpha : float
        Point transparency.
    point_size : float
        Point size.

    Returns
    -------
    dict
        {"path": save_path}
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=figsize)
    scatter = ax.scatter(embedding[:, 0], embedding[:, 1],
                          c=labels, s=point_size, alpha=alpha,
                          cmap=cmap)
    if labels is not None:
        plt.colorbar(scatter, ax=ax)

    ax.set_xlabel("UMAP 1")
    ax.set_ylabel("UMAP 2")
    ax.set_title(title, fontsize=13)

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    return {"path": save_path}


def plot_assay_readout_distribution(
    per_assay_stats,
    save_path: str = "artifacts/fig_readout_distribution.png",
    figsize: Tuple[float, float] = (10, 5),
) -> Dict[str, str]:
    """Bar plot of assay readout counts (hits vs non-hits) sorted by count.

    Reproduces Fig 1F showing the long-tail distribution of readouts
    across assays.

    Parameters
    ----------
    per_assay_stats : pd.DataFrame
        DataFrame with columns: assay_id, n_tested, n_actives.
    save_path : str
        Output file path.
    figsize : tuple
        Figure size.

    Returns
    -------
    dict
        {"path": save_path}
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    sorted_stats = per_assay_stats.sort_values("n_tested", ascending=False).reset_index(drop=True)

    fig, ax = plt.subplots(figsize=figsize)
    ax.bar(range(len(sorted_stats)), sorted_stats["n_actives"],
           color="red", alpha=0.7, label="Hits")
    ax.bar(range(len(sorted_stats)),
           sorted_stats["n_tested"] - sorted_stats["n_actives"],
           bottom=sorted_stats["n_actives"],
           color="steelblue", alpha=0.7, label="No hits")

    ax.set_xlabel("Assay (sorted by readout count)")
    ax.set_ylabel("Readout Count")
    ax.set_title("Distribution of Assay Readouts", fontsize=13)
    ax.legend()

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    return {"path": save_path}


def plot_enrichment_scatter(
    ef_values: Dict[str, float],
    hit_rates: Dict[str, float],
    save_path: str = "artifacts/fig_enrichment_scatter.png",
    figsize: Tuple[float, float] = (8, 6),
) -> Dict[str, str]:
    """Scatter plot of enrichment factor vs baseline hit rate.

    Assays with low hit rates (<1%) achieve enrichment factors of 26-48x.

    Parameters
    ----------
    ef_values : dict
        Assay index -> enrichment factor.
    hit_rates : dict
        Assay index -> baseline hit rate.
    save_path : str
        Output file path.
    figsize : tuple
        Figure size.

    Returns
    -------
    dict
        {"path": save_path}
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    common = set(ef_values.keys()) & set(hit_rates.keys())
    x = [hit_rates[k] for k in common]
    y = [ef_values[k] for k in common]

    fig, ax = plt.subplots(figsize=figsize)
    ax.scatter(x, y, alpha=0.6, s=20)
    ax.set_xlabel("Baseline Hit Rate", fontsize=12)
    ax.set_ylabel("Enrichment Factor (top 1%)", fontsize=12)
    ax.set_title("Enrichment Factor vs Hit Rate", fontsize=13)
    ax.axvline(x=0.01, color="red", linestyle="--", alpha=0.5, label="1% hit rate")
    ax.legend()

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    return {"path": save_path}

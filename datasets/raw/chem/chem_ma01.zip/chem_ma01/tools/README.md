# Tools for Multimodal Activity Prediction (chem_ma01)

## Data Processing
- `data_processing.py` — Load assay matrix, metadata, prediction results, SMILES; compute matrix sparsity and per-assay statistics

## Molecular Representation
- `fingerprint_generation.py` — Morgan fingerprint computation, Tanimoto similarity, molecular descriptors
- `compound_embedding.py` — UMAP and PCA dimensionality reduction for compound visualization

## Model Training
- `multitask_model.py` — Multi-task feedforward neural network with masked BCE loss for sparse labels
- `cross_validation.py` — Bemis-Murcko scaffold extraction and scaffold-based k-fold splitting

## Prediction Analysis
- `evaluation_metrics.py` — Per-assay AUROC, AUPRC, enrichment factor; modality performance summary
- `data_fusion.py` — Late fusion (max-pooling), early fusion (concatenation), retrospective oracle analysis
- `modality_comparison.py` — Threshold curves, Venn counts, fusion gain computation
- `missing_value_analysis.py` — Sparsity pattern analysis, imputation, missing-value masks

## Statistical Testing
- `statistical_tests.py` — Wilcoxon signed-rank, Mann-Whitney U, bootstrap confidence intervals

## Visualization
- `plot_performance.py` — AUROC boxplots, threshold curves
- `plot_heatmap.py` — Jaccard similarity heatmap, performance heatmap, sparsity pattern
- `plot_scatter.py` — Compound embedding scatter, readout distribution, enrichment scatter
- `plot_venn.py` — Three-modality Venn diagrams for overlap analysis
- `plot_roc.py` — ROC curves for individual assays and multi-modality comparison grid
- `plot_assay_types.py` — Assay type pie chart, predictability by type bar chart

## Database Retrieval
- `database_retrieval.py` — Compound lookup by SMILES, Broad ID mapping

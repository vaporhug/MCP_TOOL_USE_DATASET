"""Evaluation metrics for assay prediction performance.

Implements AUROC, AUPRC, and enrichment factor computation on a per-assay
basis, matching the paper's evaluation protocol.
"""
import numpy as np
from typing import Dict, List, Optional, Tuple


def compute_auroc_per_assay(
    y_true: np.ndarray,
    y_pred: np.ndarray,
) -> Dict[str, float]:
    """Compute AUROC for each assay, ignoring missing labels.

    Parameters
    ----------
    y_true : np.ndarray
        Ground truth labels, shape (n_compounds, n_assays). NaN = missing.
    y_pred : np.ndarray
        Predicted probabilities, shape (n_compounds, n_assays).

    Returns
    -------
    dict
        Keys are assay indices (int), values are AUROC scores.
        Assays with fewer than 2 positive or 2 negative samples are skipped.
    """
    from sklearn.metrics import roc_auc_score

    n_assays = y_true.shape[1]
    results = {}
    for j in range(n_assays):
        mask = ~np.isnan(y_true[:, j])
        yt = y_true[mask, j]
        yp = y_pred[mask, j]
        if len(yt) < 4 or yt.sum() < 2 or (1 - yt).sum() < 2:
            continue
        try:
            results[j] = roc_auc_score(yt, yp)
        except ValueError:
            continue
    return results


def compute_auprc_per_assay(
    y_true: np.ndarray,
    y_pred: np.ndarray,
) -> Dict[str, float]:
    """Compute AUPRC (Average Precision) for each assay.

    Parameters
    ----------
    y_true : np.ndarray
        Ground truth labels with NaN for missing.
    y_pred : np.ndarray
        Predicted probabilities.

    Returns
    -------
    dict
        Keys are assay indices, values are AUPRC scores.
    """
    from sklearn.metrics import average_precision_score

    n_assays = y_true.shape[1]
    results = {}
    for j in range(n_assays):
        mask = ~np.isnan(y_true[:, j])
        yt = y_true[mask, j]
        yp = y_pred[mask, j]
        if len(yt) < 4 or yt.sum() < 1:
            continue
        try:
            results[j] = average_precision_score(yt, yp)
        except ValueError:
            continue
    return results


def compute_enrichment_factor(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    top_fraction: float = 0.01,
) -> Dict[str, float]:
    """Compute enrichment factor at a given top fraction per assay.

    EF measures the ratio of hits in the top-ranked fraction vs the
    expected hit rate. An EF of 26-48x was reported for assays with
    <1% baseline hit rate.

    Parameters
    ----------
    y_true : np.ndarray
        Ground truth labels with NaN for missing.
    y_pred : np.ndarray
        Predicted probabilities.
    top_fraction : float
        Fraction of top-ranked compounds to consider (default 1%).

    Returns
    -------
    dict
        Keys are assay indices, values are enrichment factors.
    """
    n_assays = y_true.shape[1]
    results = {}
    for j in range(n_assays):
        mask = ~np.isnan(y_true[:, j])
        yt = y_true[mask, j]
        yp = y_pred[mask, j]
        if len(yt) < 10 or yt.sum() < 1:
            continue

        n_top = max(1, int(len(yt) * top_fraction))
        top_idx = np.argsort(yp)[-n_top:]
        hits_in_top = yt[top_idx].sum()
        expected_hits = yt.sum() * top_fraction
        if expected_hits > 0:
            results[j] = float(hits_in_top / expected_hits)
        else:
            results[j] = 0.0
    return results


def count_predictable_assays(
    auroc_dict: Dict,
    threshold: float = 0.9,
) -> int:
    """Count assays with AUROC above the given threshold.

    The paper defines "accurately predicted" as AUROC > 0.9.

    Parameters
    ----------
    auroc_dict : dict
        Assay index -> AUROC value.
    threshold : float
        AUROC threshold (default 0.9).

    Returns
    -------
    int
        Number of assays above threshold.
    """
    return sum(1 for v in auroc_dict.values() if v > threshold)


def summarize_modality_performance(
    prediction_df,
    modality_map: Optional[Dict[str, str]] = None,
    threshold: float = 0.9,
) -> Dict[str, Dict]:
    """Summarize prediction performance per modality from the results file.

    Maps descriptor codes to readable modality names and counts assays
    above the AUROC threshold.

    Parameters
    ----------
    prediction_df : pd.DataFrame
        DataFrame with columns: assay_id, auc, descriptor, auc_90.
    modality_map : dict, optional
        Mapping from descriptor codes to readable names.
        Default maps the key descriptors from the paper.
    threshold : float
        AUROC threshold for counting predictable assays.

    Returns
    -------
    dict
        Modality name -> {n_assays_above_threshold, mean_auc, median_auc}.
    """
    if modality_map is None:
        modality_map = {
            "cp_es_op": "CS (Chemical Structure)",
            "ge_es_op": "GE (Gene Expression)",
            "mobc_es_op": "MO (Morphology)",
            "late_fusion_cs_ge": "CS+GE (Late Fusion)",
            "late_fusion_cs_mobc": "CS+MO (Late Fusion)",
            "late_fusion_ge_mobc": "GE+MO (Late Fusion)",
            "late_fusion_cs_ge_mobc": "CS+GE+MO (Late Fusion)",
        }

    results = {}
    for desc, name in modality_map.items():
        sub = prediction_df[prediction_df["descriptor"] == desc]
        if len(sub) == 0:
            continue
        # Always recompute the count from the live ``auc`` column at the
        # requested ``threshold`` so the argument is honored for any cutoff.
        # The precomputed ``auc_90`` boolean column equals (auc > 0.9) and is
        # only used as a sanity check when threshold == 0.9.
        n_above = int((sub["auc"] > threshold).sum())
        results[name] = {
            "n_assays_above_threshold": n_above,
            "mean_auc": float(sub["auc"].mean()),
            "median_auc": float(sub["auc"].median()),
            "descriptor_code": desc,
        }
    return results

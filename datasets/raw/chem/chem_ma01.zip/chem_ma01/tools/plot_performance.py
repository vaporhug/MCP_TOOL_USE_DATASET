"""Performance visualization tools.

Plot functions for AUROC distributions, modality comparisons, and
threshold curves. All functions save to file and return the path.
"""
import numpy as np
from typing import Dict, List, Optional, Tuple


def plot_auroc_boxplot(
    auroc_per_modality: Dict[str, np.ndarray],
    save_path: str = "artifacts/fig_auroc_boxplot.png",
    figsize: Tuple[float, float] = (10, 6),
    threshold_lines: Optional[List[float]] = None,
) -> Dict[str, str]:
    """Box plot of AUROC distributions across modalities.

    Reproduces the style of Fig 2C and Fig 3E from the paper, showing
    the distribution of median AUROC scores across all 270 assays for
    each modality/combination.

    Parameters
    ----------
    auroc_per_modality : dict
        Modality label -> array of AUROC values (one per assay).
    save_path : str
        Output file path.
    figsize : tuple
        Figure size.
    threshold_lines : list of float, optional
        Horizontal lines for AUROC thresholds (default [0.7, 0.9]).

    Returns
    -------
    dict
        {"path": save_path}
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    if threshold_lines is None:
        threshold_lines = [0.7, 0.9]

    labels = list(auroc_per_modality.keys())
    data = [auroc_per_modality[l] for l in labels]

    fig, ax = plt.subplots(figsize=figsize)
    bp = ax.boxplot(data, labels=labels, patch_artist=True, showfliers=True)

    colors = ["#FFD700", "#4169E1", "#32CD32", "#FF6347", "#9370DB", "#FF8C00", "#808080"]
    for patch, color in zip(bp["boxes"], colors[: len(labels)]):
        patch.set_facecolor(color)
        patch.set_alpha(0.6)

    for thr in threshold_lines:
        ax.axhline(y=thr, color="gray", linestyle="--", alpha=0.5, label=f"AUROC={thr}")

    ax.set_ylabel("AUROC", fontsize=12)
    ax.set_title("Distribution of Prediction Performance Across Assays", fontsize=13)
    ax.tick_params(axis="x", rotation=30)

    # Annotate counts above 0.9
    for i, (label, vals) in enumerate(zip(labels, data)):
        n_above = int((np.array(vals) > 0.9).sum())
        ax.annotate(f"n>{0.9}: {n_above}", xy=(i + 1, 0.95),
                    fontsize=8, ha="center", color="red")

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    return {"path": save_path}


def plot_threshold_curve(
    prediction_df,
    descriptors: Optional[Dict[str, str]] = None,
    save_path: str = "artifacts/fig_threshold_curve.png",
    figsize: Tuple[float, float] = (8, 6),
) -> Dict[str, str]:
    """Plot number of predictable assays vs AUROC threshold per modality.

    Reproduces Fig 2A: as threshold increases, fewer assays are predictable,
    but the curves diverge showing modality-specific strengths.

    Parameters
    ----------
    prediction_df : pd.DataFrame
        Prediction results with columns: assay_id, auc, descriptor.
    descriptors : dict, optional
        Descriptor code -> label mapping.
    save_path : str
        Output file path.
    figsize : tuple
        Figure size.

    Returns
    -------
    dict
        {"path": save_path}
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    if descriptors is None:
        descriptors = {
            "cp_es_op": "CS",
            "ge_es_op": "GE",
            "mobc_es_op": "MO",
        }

    thresholds = np.arange(0.5, 1.01, 0.02)
    colors = {"CS": "#FFD700", "GE": "#4169E1", "MO": "#32CD32"}

    fig, ax = plt.subplots(figsize=figsize)
    for desc, label in descriptors.items():
        sub = prediction_df[prediction_df["descriptor"] == desc]
        counts = [int((sub["auc"] > t).sum()) for t in thresholds]
        ax.plot(thresholds, counts, label=label,
                color=colors.get(label, None), linewidth=2)

    ax.axvline(x=0.9, color="blue", linestyle="--", alpha=0.5, label="Threshold=0.9")
    ax.axvline(x=0.7, color="gray", linestyle="--", alpha=0.5, label="Threshold=0.7")
    ax.set_xlabel("AUROC Threshold", fontsize=12)
    ax.set_ylabel("Number of Assays", fontsize=12)
    ax.set_title("Predictable Assays vs AUROC Threshold", fontsize=13)
    ax.legend()
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    return {"path": save_path}

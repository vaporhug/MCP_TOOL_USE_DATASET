"""Compound embedding and dimensionality reduction.

Provides UMAP and PCA for visualizing compound distributions in
different feature spaces (chemical structure, gene expression, morphology).
"""
import numpy as np
from typing import Dict, Optional, Tuple


def compute_umap_embedding(
    features: np.ndarray,
    n_components: int = 2,
    n_neighbors: int = 15,
    min_dist: float = 0.1,
    metric: str = "euclidean",
    random_state: int = 42,
) -> np.ndarray:
    """Compute UMAP embedding for compound feature visualization.

    The paper shows UMAP visualizations for all compounds in the three
    feature spaces (CS, GE, MO) in Fig 1E.

    Parameters
    ----------
    features : np.ndarray
        Feature matrix, shape (n_compounds, n_features).
    n_components : int
        Number of UMAP dimensions (default 2).
    n_neighbors : int
        UMAP n_neighbors parameter.
    min_dist : float
        UMAP min_dist parameter.
    metric : str
        Distance metric.
    random_state : int
        Random seed.

    Returns
    -------
    np.ndarray
        Embedding coordinates, shape (n_compounds, n_components).
    """
    from umap import UMAP

    reducer = UMAP(
        n_components=n_components,
        n_neighbors=n_neighbors,
        min_dist=min_dist,
        metric=metric,
        random_state=random_state,
    )
    return reducer.fit_transform(features)


def compute_pca_embedding(
    features: np.ndarray,
    n_components: int = 2,
) -> Dict[str, object]:
    """Compute PCA embedding with explained variance.

    Parameters
    ----------
    features : np.ndarray
        Feature matrix, shape (n_compounds, n_features).
    n_components : int
        Number of PCA components.

    Returns
    -------
    dict
        Keys: embedding (np.ndarray), explained_variance_ratio (list).
    """
    from sklearn.decomposition import PCA

    pca = PCA(n_components=n_components)
    embedding = pca.fit_transform(features)
    return {
        "embedding": embedding,
        "explained_variance_ratio": pca.explained_variance_ratio_.tolist(),
    }

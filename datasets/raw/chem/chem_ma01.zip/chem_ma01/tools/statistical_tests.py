"""Statistical tests for comparing modality and model performance.

Provides paired tests and confidence intervals for evaluating whether
differences between modalities are significant.
"""
import numpy as np
from typing import Dict, List, Optional, Tuple


def paired_wilcoxon_test(
    scores_a: np.ndarray,
    scores_b: np.ndarray,
) -> Dict[str, float]:
    """Wilcoxon signed-rank test for paired AUROC comparison.

    Tests whether one modality significantly outperforms another across
    the same set of assays.

    Parameters
    ----------
    scores_a : np.ndarray
        AUROC scores for modality A (one per assay).
    scores_b : np.ndarray
        AUROC scores for modality B (same assays).

    Returns
    -------
    dict
        Keys: statistic, p_value, mean_diff, median_diff.
    """
    from scipy.stats import wilcoxon

    diff = scores_a - scores_b
    mask = diff != 0
    if mask.sum() < 3:
        return {"statistic": np.nan, "p_value": 1.0,
                "mean_diff": float(diff.mean()), "median_diff": float(np.median(diff))}

    stat, pval = wilcoxon(scores_a[mask], scores_b[mask])
    return {
        "statistic": float(stat),
        "p_value": float(pval),
        "mean_diff": float(diff.mean()),
        "median_diff": float(np.median(diff)),
    }


def mann_whitney_test(
    scores_a: np.ndarray,
    scores_b: np.ndarray,
) -> Dict[str, float]:
    """Mann-Whitney U test for unpaired comparison of AUROC distributions.

    Parameters
    ----------
    scores_a : np.ndarray
        AUROC scores for group A.
    scores_b : np.ndarray
        AUROC scores for group B.

    Returns
    -------
    dict
        Keys: statistic, p_value.
    """
    from scipy.stats import mannwhitneyu

    stat, pval = mannwhitneyu(scores_a, scores_b, alternative="two-sided")
    return {"statistic": float(stat), "p_value": float(pval)}


def bootstrap_confidence_interval(
    scores: np.ndarray,
    stat_func=np.mean,
    n_bootstrap: int = 1000,
    ci: float = 0.95,
    random_state: int = 42,
) -> Tuple[float, float, float]:
    """Compute bootstrap confidence interval for a statistic.

    Parameters
    ----------
    scores : np.ndarray
        Array of scores.
    stat_func : callable
        Statistic to compute (default: mean).
    n_bootstrap : int
        Number of bootstrap iterations.
    ci : float
        Confidence level.
    random_state : int
        Random seed.

    Returns
    -------
    tuple
        (point_estimate, lower_bound, upper_bound).
    """
    rng = np.random.RandomState(random_state)
    point = stat_func(scores)
    boot_stats = []
    for _ in range(n_bootstrap):
        sample = rng.choice(scores, size=len(scores), replace=True)
        boot_stats.append(stat_func(sample))

    alpha = 1 - ci
    lower = np.percentile(boot_stats, 100 * alpha / 2)
    upper = np.percentile(boot_stats, 100 * (1 - alpha / 2))
    return float(point), float(lower), float(upper)

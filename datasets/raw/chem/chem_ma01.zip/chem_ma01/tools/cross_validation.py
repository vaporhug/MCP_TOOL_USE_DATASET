"""Cross-validation utilities with scaffold-based splitting.

Implements Bemis-Murcko scaffold extraction and scaffold-based k-fold
splitting to evaluate model generalization to novel chemical scaffolds.
"""
import numpy as np
from typing import List, Tuple, Dict, Optional


def extract_bemis_murcko_scaffolds(
    smiles_list: List[str],
) -> List[str]:
    """Extract Bemis-Murcko scaffolds from SMILES strings.

    The paper uses scaffold-based splitting to ensure training and test sets
    contain structurally dissimilar compounds.

    Parameters
    ----------
    smiles_list : list of str
        SMILES strings.

    Returns
    -------
    list of str
        Scaffold SMILES for each compound. Empty string if parsing fails.
    """
    from rdkit import Chem
    from rdkit.Chem.Scaffolds import MurckoScaffold

    scaffolds = []
    for smi in smiles_list:
        mol = Chem.MolFromSmiles(smi)
        if mol is not None:
            try:
                core = MurckoScaffold.GetScaffoldForMol(mol)
                scaffolds.append(Chem.MolToSmiles(core))
            except Exception:
                scaffolds.append("")
        else:
            scaffolds.append("")
    return scaffolds


def scaffold_kfold_split(
    smiles_list: List[str],
    n_folds: int = 5,
    random_seed: int = 42,
) -> List[Tuple[np.ndarray, np.ndarray]]:
    """Create scaffold-based k-fold cross-validation splits.

    Groups compounds by their Bemis-Murcko scaffold and assigns
    entire scaffold groups to folds to prevent data leakage from
    structurally similar compounds.

    Parameters
    ----------
    smiles_list : list of str
        SMILES strings for all compounds.
    n_folds : int
        Number of folds (default 5, as in the paper).
    random_seed : int
        Random seed for reproducibility.

    Returns
    -------
    list of (train_indices, test_indices) tuples
        Each element is a tuple of numpy arrays with compound indices.
    """
    scaffolds = extract_bemis_murcko_scaffolds(smiles_list)

    # Group compound indices by scaffold
    scaffold_to_indices = {}
    for i, scaf in enumerate(scaffolds):
        if scaf not in scaffold_to_indices:
            scaffold_to_indices[scaf] = []
        scaffold_to_indices[scaf].append(i)

    # Shuffle the scaffold groups with the seeded RNG, then sort by size
    # (largest first) using a stable sort. The seed therefore controls the
    # order in which equal-sized groups are allocated, making the split
    # deterministic for a given seed yet seed-dependent (a fixed sort alone
    # ignored `random_seed` entirely).
    rng = np.random.RandomState(random_seed)
    groups = list(scaffold_to_indices.values())
    perm = rng.permutation(len(groups))
    shuffled_groups = [groups[k] for k in perm]
    scaffold_groups = sorted(shuffled_groups, key=len, reverse=True)

    fold_indices = [[] for _ in range(n_folds)]
    fold_sizes = [0] * n_folds

    # Greedy allocation: assign each scaffold group to the smallest fold
    for group in scaffold_groups:
        smallest_fold = int(np.argmin(fold_sizes))
        fold_indices[smallest_fold].extend(group)
        fold_sizes[smallest_fold] += len(group)

    # Create train/test splits
    splits = []
    for i in range(n_folds):
        test_idx = np.array(fold_indices[i])
        train_idx = np.concatenate(
            [np.array(fold_indices[j]) for j in range(n_folds) if j != i]
        )
        splits.append((train_idx, test_idx))

    return splits


def random_kfold_split(
    n_samples: int,
    n_folds: int = 5,
    random_seed: int = 42,
) -> List[Tuple[np.ndarray, np.ndarray]]:
    """Create random k-fold cross-validation splits (baseline control).

    Parameters
    ----------
    n_samples : int
        Total number of samples.
    n_folds : int
        Number of folds.
    random_seed : int
        Random seed.

    Returns
    -------
    list of (train_indices, test_indices) tuples
    """
    rng = np.random.RandomState(random_seed)
    indices = rng.permutation(n_samples)
    fold_size = n_samples // n_folds
    splits = []

    for i in range(n_folds):
        start = i * fold_size
        end = start + fold_size if i < n_folds - 1 else n_samples
        test_idx = indices[start:end]
        train_idx = np.concatenate([indices[:start], indices[end:]])
        splits.append((train_idx, test_idx))

    return splits

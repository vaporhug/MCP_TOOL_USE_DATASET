"""Database retrieval stubs for external data sources.

Provides lookup functions for compound identifiers and assay metadata
from PubChem and ChEMBL databases.
"""
from typing import Dict, List, Optional


def lookup_compound_by_smiles(
    smiles: str,
) -> Dict[str, str]:
    """Look up compound information from SMILES string.

    Returns available identifiers and basic properties.

    Parameters
    ----------
    smiles : str
        SMILES string of the compound.

    Returns
    -------
    dict
        Keys: smiles, inchi_key (if available), molecular_formula.
    """
    from rdkit import Chem
    from rdkit.Chem import Descriptors

    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return {"smiles": smiles, "error": "Invalid SMILES"}

    return {
        "smiles": smiles,
        "molecular_formula": Chem.rdMolDescriptors.CalcMolFormula(mol),
        "molecular_weight": float(Descriptors.MolWt(mol)),
        "num_atoms": mol.GetNumAtoms(),
        "num_bonds": mol.GetNumBonds(),
    }


def lookup_broad_id_mapping(
    broad_ids_path: str = "input_data/data/broad_ids.txt",
    smiles_path: str = "input_data/data/smiles.txt",
) -> Dict[str, str]:
    """Create mapping between Broad Institute compound IDs and SMILES.

    Parameters
    ----------
    broad_ids_path : str
        Path to broad_ids.txt file.
    smiles_path : str
        Path to smiles.txt file.

    Returns
    -------
    dict
        Broad ID -> SMILES mapping.
    """
    import pandas as pd

    ids = pd.read_csv(broad_ids_path)["broad_id"].tolist()
    smiles = pd.read_csv(smiles_path)["smiles"].tolist()
    return dict(zip(ids, smiles))

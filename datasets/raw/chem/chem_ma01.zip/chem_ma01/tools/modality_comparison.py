"""Modality comparison and complementarity analysis.

Tools for comparing prediction performance across chemical structure,
gene expression, and morphology modalities, and quantifying their
complementarity.
"""
import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Set, Tuple


def compute_predictability_by_threshold(
    prediction_df: pd.DataFrame,
    descriptors: Optional[List[str]] = None,
    thresholds: Optional[List[float]] = None,
) -> pd.DataFrame:
    """Count predictable assays at multiple AUROC thresholds per modality.

    Reproduces the analysis in Fig 2A of the paper, showing that as the
    AUROC threshold increases, the number of predictable assays decreases
    differently for each modality.

    Parameters
    ----------
    prediction_df : pd.DataFrame
        Prediction results with columns: assay_id, auc, descriptor.
    descriptors : list of str, optional
        Descriptor codes to analyze. Defaults to CS, GE, MO single modalities.
    thresholds : list of float, optional
        AUROC thresholds to evaluate. Defaults to [0.5, 0.6, 0.7, 0.8, 0.9, 1.0].

    Returns
    -------
    pd.DataFrame
        Columns: threshold, descriptor, n_predictable.
    """
    if descriptors is None:
        descriptors = ["cp_es_op", "ge_es_op", "mobc_es_op"]
    if thresholds is None:
        thresholds = [0.5, 0.55, 0.6, 0.65, 0.7, 0.75, 0.8, 0.85, 0.9, 0.95, 1.0]

    records = []
    for desc in descriptors:
        sub = prediction_df[prediction_df["descriptor"] == desc]
        for thr in thresholds:
            n = int((sub["auc"] > thr).sum())
            records.append({
                "threshold": thr,
                "descriptor": desc,
                "n_predictable": n,
            })
    return pd.DataFrame(records)


def compute_venn_counts(
    prediction_df: pd.DataFrame,
    descriptors: Optional[Dict[str, str]] = None,
    threshold: float = 0.9,
) -> Dict[str, int]:
    """Compute Venn diagram counts for modality overlap.

    Returns the number of assays uniquely predicted by each modality,
    by each pair, and by all three, matching Fig 2B.

    Parameters
    ----------
    prediction_df : pd.DataFrame
        Prediction results.
    descriptors : dict, optional
        Descriptor code -> label. Defaults to CS, GE, MO.
    threshold : float
        AUROC threshold.

    Returns
    -------
    dict
        Keys like 'CS_only', 'GE_only', 'MO_only', 'CS_GE', 'CS_MO',
        'GE_MO', 'CS_GE_MO', 'total_union'.
    """
    if descriptors is None:
        descriptors = {"cp_es_op": "CS", "ge_es_op": "GE", "mobc_es_op": "MO"}

    sets = {}
    for desc, label in descriptors.items():
        sub = prediction_df[prediction_df["descriptor"] == desc]
        sets[label] = set(sub[sub["auc"] > threshold]["assay_id"].tolist())

    labels = list(sets.keys())
    result = {}

    if len(labels) >= 3:
        a, b, c = sets[labels[0]], sets[labels[1]], sets[labels[2]]
        abc = a & b & c
        ab = (a & b) - abc
        ac = (a & c) - abc
        bc = (b & c) - abc
        a_only = a - b - c
        b_only = b - a - c
        c_only = c - a - b

        result[f"{labels[0]}_only"] = len(a_only)
        result[f"{labels[1]}_only"] = len(b_only)
        result[f"{labels[2]}_only"] = len(c_only)
        result[f"{labels[0]}_{labels[1]}"] = len(ab)
        result[f"{labels[0]}_{labels[2]}"] = len(ac)
        result[f"{labels[1]}_{labels[2]}"] = len(bc)
        result[f"{labels[0]}_{labels[1]}_{labels[2]}"] = len(abc)
        result["total_union"] = len(a | b | c)

    return result


def compute_fusion_gain(
    prediction_df: pd.DataFrame,
    single_descriptors: Optional[Dict[str, str]] = None,
    fusion_descriptors: Optional[Dict[str, str]] = None,
    threshold: float = 0.9,
) -> pd.DataFrame:
    """Compute the gain from data fusion vs single modalities.

    Shows how many additional assays become predictable when combining
    modalities via late fusion, matching Fig 3C/D analysis.

    Parameters
    ----------
    prediction_df : pd.DataFrame
        Prediction results.
    single_descriptors : dict, optional
        Single modality descriptor -> label.
    fusion_descriptors : dict, optional
        Fusion descriptor -> label.
    threshold : float
        AUROC threshold.

    Returns
    -------
    pd.DataFrame
        Comparison table with columns: modality, n_predictable,
        gain_over_best_single.
    """
    if single_descriptors is None:
        single_descriptors = {
            "cp_es_op": "CS",
            "ge_es_op": "GE",
            "mobc_es_op": "MO",
        }
    if fusion_descriptors is None:
        fusion_descriptors = {
            "late_fusion_cs_ge": "CS+GE",
            "late_fusion_cs_mobc": "CS+MO",
            "late_fusion_ge_mobc": "GE+MO",
            "late_fusion_cs_ge_mobc": "CS+GE+MO",
        }

    all_desc = {**single_descriptors, **fusion_descriptors}
    records = []
    for desc, label in all_desc.items():
        sub = prediction_df[prediction_df["descriptor"] == desc]
        # Count from the live ``auc`` column at the requested ``threshold`` so
        # the argument is honored for any cutoff (not just 0.9). The bundled
        # ``auc_90`` boolean column equals (auc > 0.9) and would silently pin
        # the count to 0.9 regardless of ``threshold`` if used directly.
        n = int((sub["auc"] > threshold).sum())
        records.append({"modality": label, "descriptor": desc, "n_predictable": n})

    df = pd.DataFrame(records)
    best_single = max(r["n_predictable"] for r in records if r["descriptor"] in single_descriptors)
    df["gain_over_best_single"] = df["n_predictable"] - best_single
    return df

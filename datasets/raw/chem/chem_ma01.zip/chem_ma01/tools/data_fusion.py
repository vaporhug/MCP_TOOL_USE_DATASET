"""Data fusion strategies for combining predictions from multiple modalities.

Implements late fusion (max-pooling) and early fusion (feature concatenation)
as described in the paper.
"""
import numpy as np
from typing import Dict, List, Optional


def late_fusion_max(
    predictions: Dict[str, np.ndarray],
) -> np.ndarray:
    """Combine predictions from multiple modalities via max-pooling (late fusion).

    Late fusion builds separate models per modality and aggregates their
    output probabilities using the maximum operator. This is the primary
    fusion method in the paper and outperformed early fusion.

    Parameters
    ----------
    predictions : dict
        Modality name -> predicted probability matrix (n_compounds, n_tasks).

    Returns
    -------
    np.ndarray
        Fused predictions, shape (n_compounds, n_tasks).
    """
    pred_arrays = list(predictions.values())
    stacked = np.stack(pred_arrays, axis=0)  # (n_modalities, n_compounds, n_tasks)
    return np.max(stacked, axis=0)


def late_fusion_mean(
    predictions: Dict[str, np.ndarray],
) -> np.ndarray:
    """Combine predictions from multiple modalities via averaging.

    Parameters
    ----------
    predictions : dict
        Modality name -> predicted probability matrix.

    Returns
    -------
    np.ndarray
        Averaged predictions.
    """
    pred_arrays = list(predictions.values())
    stacked = np.stack(pred_arrays, axis=0)
    return np.mean(stacked, axis=0)


def early_fusion_concatenate(
    features: Dict[str, np.ndarray],
) -> np.ndarray:
    """Combine features from multiple modalities via concatenation (early fusion).

    Early fusion concatenates feature vectors before training a single model.
    The paper found this performed worse than late fusion for all modality
    combinations.

    Parameters
    ----------
    features : dict
        Modality name -> feature matrix (n_compounds, n_features_i).

    Returns
    -------
    np.ndarray
        Concatenated feature matrix, shape (n_compounds, sum(n_features_i)).
    """
    return np.hstack(list(features.values()))


def retrospective_best_single(
    auroc_per_modality: Dict[str, Dict[int, float]],
    threshold: float = 0.9,
) -> Dict[str, object]:
    """Compute the retrospective oracle analysis (choose best modality per assay).

    For each assay, picks the configuration with the highest AUROC among the
    configurations supplied in ``auroc_per_modality``. This simulates a perfect
    oracle that always selects the best predictor, i.e. the union of the
    assays each configuration can predict above ``threshold``.

    With the three single modalities (CS, GE, MO) supplied, the bundled data
    yields 52 unique assays above AUROC > 0.9 (the "single best of any single
    modality" oracle, matching the Venn union in Fig 2B). Supplying the late
    fusion configurations as well enlarges this union to 63 unique assays.
    Both are larger than any single configuration alone.

    Parameters
    ----------
    auroc_per_modality : dict
        Modality name -> {assay_index: auroc}.
    threshold : float
        AUROC threshold for counting as "predictable".

    Returns
    -------
    dict
        Keys: n_predictable (int), predictable_assays (set of assay indices),
        best_modality_per_assay (dict assay_idx -> modality_name).
    """
    all_assays = set()
    for aucs in auroc_per_modality.values():
        all_assays.update(aucs.keys())

    best_modality = {}
    best_auc = {}
    for assay in all_assays:
        for mod, aucs in auroc_per_modality.items():
            if assay in aucs:
                if assay not in best_auc or aucs[assay] > best_auc[assay]:
                    best_auc[assay] = aucs[assay]
                    best_modality[assay] = mod

    predictable = {a for a, v in best_auc.items() if v > threshold}

    return {
        "n_predictable": len(predictable),
        "predictable_assays": predictable,
        "best_modality_per_assay": best_modality,
    }

"""ROC curve visualization tools.

Plot ROC curves for individual assays and multi-modality comparison,
reproducing the style of Fig 4 from the paper.
"""
import numpy as np
from typing import Dict, List, Optional, Tuple


def plot_roc_curves_multi_modality(
    y_true: np.ndarray,
    predictions_per_modality: Dict[str, np.ndarray],
    assay_index: int,
    assay_name: str = "",
    save_path: str = "artifacts/fig_roc_example.png",
    figsize: Tuple[float, float] = (6, 6),
) -> Dict[str, str]:
    """Plot ROC curves for multiple modalities on a single assay.

    Reproduces the ROC curve panels in Fig 4A/B, showing how different
    modalities and their fusions perform on specific example assays.

    Parameters
    ----------
    y_true : np.ndarray
        Ground truth labels for one assay (1D array with NaN for missing).
    predictions_per_modality : dict
        Modality label -> predicted probabilities for this assay (1D array).
    assay_index : int
        Index of the assay being plotted.
    assay_name : str
        Name of the assay for the title.
    save_path : str
        Output file path.
    figsize : tuple
        Figure size.

    Returns
    -------
    dict
        {"path": save_path}
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from sklearn.metrics import roc_curve, auc

    mask = ~np.isnan(y_true)
    yt = y_true[mask]

    colors = {
        "MO": "#32CD32", "CS": "#FFD700", "GE": "#4169E1",
        "CS+GE": "#FF6347", "CS+MO": "#9370DB", "GE+MO": "#FF8C00",
        "CS+GE+MO": "#808080",
    }

    fig, ax = plt.subplots(figsize=figsize)
    for label, preds in predictions_per_modality.items():
        yp = preds[mask]
        fpr, tpr, _ = roc_curve(yt, yp)
        auroc = auc(fpr, tpr)
        color = colors.get(label, None)
        ax.plot(fpr, tpr, label=f"{label} (AUROC={auroc:.4f})",
                color=color, linewidth=1.5)

    ax.plot([0, 1], [0, 1], "k--", alpha=0.3)
    ax.set_xlabel("False Positive Rate", fontsize=11)
    ax.set_ylabel("True Positive Rate", fontsize=11)
    title = f"ROC Curves: {assay_name}" if assay_name else f"ROC Curves: Assay {assay_index}"
    ax.set_title(title, fontsize=12)
    ax.legend(fontsize=9, loc="lower right")
    ax.set_xlim([0, 1])
    ax.set_ylim([0, 1.05])

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    return {"path": save_path}


def plot_roc_grid(
    assay_results: List[Dict],
    save_path: str = "artifacts/fig_roc_grid.png",
    figsize: Tuple[float, float] = (16, 4),
) -> Dict[str, str]:
    """Plot a grid of ROC curves for multiple example assays.

    Reproduces Fig 4 layout: 4 example assays side by side.

    Parameters
    ----------
    assay_results : list of dict
        Each dict has keys: assay_name, y_true, predictions (dict of
        modality -> scores).
    save_path : str
        Output file path.
    figsize : tuple
        Figure size.

    Returns
    -------
    dict
        {"path": save_path}
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from sklearn.metrics import roc_curve, auc

    n = len(assay_results)
    fig, axes = plt.subplots(1, n, figsize=figsize)
    if n == 1:
        axes = [axes]

    colors = {
        "MO": "#32CD32", "CS": "#FFD700", "GE": "#4169E1",
        "CS+GE": "#FF6347", "CS+MO": "#9370DB", "GE+MO": "#FF8C00",
        "CS+GE+MO": "#808080",
    }

    for ax, res in zip(axes, assay_results):
        mask = ~np.isnan(res["y_true"])
        yt = res["y_true"][mask]
        for label, preds in res["predictions"].items():
            yp = preds[mask]
            fpr, tpr, _ = roc_curve(yt, yp)
            auroc_val = auc(fpr, tpr)
            ax.plot(fpr, tpr, label=f"{label}: {auroc_val:.2f}",
                    color=colors.get(label, None), linewidth=1.2)
        ax.plot([0, 1], [0, 1], "k--", alpha=0.3)
        ax.set_title(res.get("assay_name", ""), fontsize=10)
        ax.legend(fontsize=7, loc="lower right")
        ax.set_xlabel("FPR", fontsize=9)
        ax.set_ylabel("TPR", fontsize=9)

    plt.suptitle("Example Assays: Data Fusion Improves Prediction", fontsize=13, y=1.02)
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    return {"path": save_path}

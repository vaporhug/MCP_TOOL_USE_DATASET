"""Assay type distribution visualization.

Pie chart and bar chart tools for visualizing the composition of
assay types and their predictability across modalities.
"""
import numpy as np
from typing import Dict, List, Optional, Tuple


def plot_assay_type_pie(
    type_counts: Dict[str, int],
    save_path: str = "artifacts/fig_assay_type_pie.png",
    figsize: Tuple[float, float] = (8, 6),
) -> Dict[str, str]:
    """Pie chart of assay type distribution.

    Reproduces Fig 1B: Cell (57.8%), Biochem (21.9%), Bacterial (11.1%),
    Yeast (6.7%), Fungal (1.1%).

    Parameters
    ----------
    type_counts : dict
        Assay type -> count.
    save_path : str
        Output file path.
    figsize : tuple
        Figure size.

    Returns
    -------
    dict
        {"path": save_path}
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    labels = list(type_counts.keys())
    sizes = list(type_counts.values())
    total = sum(sizes)
    pct = [s / total * 100 for s in sizes]

    colors = plt.cm.Set3(np.linspace(0, 1, len(labels)))

    fig, ax = plt.subplots(figsize=figsize)
    wedges, texts, autotexts = ax.pie(
        sizes, labels=labels, autopct="%1.1f%%",
        colors=colors, startangle=90
    )
    ax.set_title("Distribution of Assay Types", fontsize=13)

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    return {"path": save_path}


def plot_predictability_by_type(
    type_pred_df,
    save_path: str = "artifacts/fig_pred_by_type.png",
    figsize: Tuple[float, float] = (10, 6),
) -> Dict[str, str]:
    """Grouped bar chart of predictable assays by type and modality.

    Shows which assay types (Cell, Biochem, Bacterial, etc.) are best
    predicted by each modality (CS, GE, MO).

    Parameters
    ----------
    type_pred_df : pd.DataFrame
        DataFrame with assay_type column and predicted_by_CS/GE/MO columns.
    save_path : str
        Output file path.
    figsize : tuple
        Figure size.

    Returns
    -------
    dict
        {"path": save_path}
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=figsize)

    pred_cols = [c for c in type_pred_df.columns if c.startswith("predicted_by_")]
    n_groups = len(type_pred_df)
    n_bars = len(pred_cols)
    width = 0.8 / n_bars
    x = np.arange(n_groups)

    colors = ["#FFD700", "#4169E1", "#32CD32", "#FF6347", "#9370DB"]
    for i, col in enumerate(pred_cols):
        label = col.replace("predicted_by_", "")
        ax.bar(x + i * width, type_pred_df[col], width,
               label=label, color=colors[i % len(colors)], alpha=0.8)

    ax.set_xticks(x + width * (n_bars - 1) / 2)
    ax.set_xticklabels(type_pred_df["assay_type"], rotation=30, ha="right")
    ax.set_ylabel("Number of Predictable Assays")
    ax.set_title("Predictable Assays by Type and Modality", fontsize=13)
    ax.legend()

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    return {"path": save_path}

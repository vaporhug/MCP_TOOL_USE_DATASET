"""Missing value analysis and imputation for the sparse assay matrix.

The compound-assay matrix has 86.6% sparsity (missing values).
These tools analyze and handle the missing data patterns.
"""
import numpy as np
import pandas as pd
from typing import Dict, List, Optional


def analyze_missing_patterns(
    matrix: pd.DataFrame,
) -> Dict[str, object]:
    """Analyze the pattern of missing values in the assay matrix.

    Parameters
    ----------
    matrix : pd.DataFrame
        Binary activity matrix (compounds x assays) with NaN for missing.

    Returns
    -------
    dict
        Keys: per_compound_tested (array of counts per compound),
        per_assay_tested (array of counts per assay),
        per_compound_stats (dict with mean/median/min/max),
        per_assay_stats (dict with mean/median/min/max).
    """
    per_compound = matrix.notna().sum(axis=1).values
    per_assay = matrix.notna().sum(axis=0).values

    return {
        "per_compound_tested": per_compound,
        "per_assay_tested": per_assay,
        "per_compound_stats": {
            "mean": float(per_compound.mean()),
            "median": float(np.median(per_compound)),
            "min": int(per_compound.min()),
            "max": int(per_compound.max()),
        },
        "per_assay_stats": {
            "mean": float(per_assay.mean()),
            "median": float(np.median(per_assay)),
            "min": int(per_assay.min()),
            "max": int(per_assay.max()),
        },
    }


def impute_missing_values(
    matrix: pd.DataFrame,
    method: str = "zero",
) -> np.ndarray:
    """Impute missing values in the assay matrix.

    The paper does NOT impute missing values during training; instead it
    masks them in the loss function. This tool is provided for analysis
    and baseline comparison.

    Parameters
    ----------
    matrix : pd.DataFrame
        Binary activity matrix with NaN for missing.
    method : str
        Imputation method: 'zero' (fill with 0), 'mean' (per-assay mean),
        'median' (per-assay median).

    Returns
    -------
    np.ndarray
        Imputed matrix (no NaN values).
    """
    values = matrix.values.copy().astype(float)

    if method == "zero":
        values = np.nan_to_num(values, nan=0.0)
    elif method == "mean":
        for j in range(values.shape[1]):
            col = values[:, j]
            mask = ~np.isnan(col)
            if mask.sum() > 0:
                col[~mask] = np.nanmean(col)
            else:
                col[~mask] = 0.0
    elif method == "median":
        for j in range(values.shape[1]):
            col = values[:, j]
            mask = ~np.isnan(col)
            if mask.sum() > 0:
                col[~mask] = np.nanmedian(col)
            else:
                col[~mask] = 0.0

    return values


def compute_missing_mask(
    matrix: pd.DataFrame,
) -> np.ndarray:
    """Create a binary mask where True = value is available (not missing).

    Used during multi-task training to mask the loss for compounds
    not tested in a given assay.

    Parameters
    ----------
    matrix : pd.DataFrame
        Binary activity matrix.

    Returns
    -------
    np.ndarray
        Boolean mask, shape (n_compounds, n_assays).
    """
    return ~np.isnan(matrix.values.astype(float))

# Dataset for chem_xr01

## oqmd_subset.csv
  rows=1500, columns=[formula, n_elements, formation_energy_eV_per_atom, band_gap_eV]
  This is an OQMD-style subset of binary/ternary/quaternary
  inorganic compositions with DFT-computed formation energy
  and band gap. Ward et al. 2016 (target.pdf, Table 1) trained
  their reference RandomSubspace+REPTree models on a comparable
  subset of 228,676 OQMD compounds and reported 10-fold-CV
  MAE = 0.0882 eV/atom for formation energy and 0.0645 eV for
  band gap. The synthetic distribution here is constructed so
  the same composition-only Magpie pipeline reproduces Ward's
  qualitative scaling.

## icsd_bandgap_subset.csv
  rows=292, columns=[formula, n_elements, formation_energy_eV_per_atom, band_gap_eV]
  Restricted to compositions containing at least one nonmetal
  and a positive band gap, mirroring the 25,085 ICSD-only
  subset Ward et al. used for the solar-cell screening test
  (target.pdf, p.3 'Training data').

## solar_cell_candidates.csv
  The five ternary-halide candidate compositions reported in
  Ward et al. 2016 Table 2 (target.pdf, p.4). The agent should
  predict their band gaps with the trained model and compare
  against these published values.

## element_properties.csv
  Per-element table (Z, symbol, mass, electronegativity,
  covalent radius, first ionization energy, melting point,
  boiling point, density, row, column, n_s/p/d/f, n_valence,
  group, is_metal). Source values are widely tabulated.

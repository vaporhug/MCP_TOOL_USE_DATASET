"""Regression model primitives and cross-validation helpers.

These wrap scikit-learn so the agent's analysis code never needs to
import scikit-learn directly. The supported algorithms are:

  - ``"linear"``    : ordinary least squares
  - ``"ridge"``     : L2-penalised linear regression
  - ``"rf"``        : random forest of decision trees
  - ``"gbm"``       : gradient-boosted regression trees

All return functions yield a fitted estimator object that responds to
``predict(X)`` so the agent can re-use the same downstream code.
"""
from __future__ import annotations

from typing import Any, Dict, Iterable, List, Tuple

import numpy as np
import pandas as pd

from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.model_selection import KFold


def _make_estimator(name: str, **kwargs: Any):
    """Return a fresh scikit-learn estimator for ``name``."""
    name = name.lower()
    if name == "linear":
        return LinearRegression(**kwargs)
    if name == "ridge":
        alpha = float(kwargs.pop("alpha", 1.0))
        return Ridge(alpha=alpha, **kwargs)
    if name == "rf":
        return RandomForestRegressor(
            n_estimators=int(kwargs.pop("n_estimators", 100)),
            random_state=int(kwargs.pop("random_state", 0)),
            n_jobs=int(kwargs.pop("n_jobs", -1)),
            **kwargs,
        )
    if name == "gbm":
        return GradientBoostingRegressor(
            n_estimators=int(kwargs.pop("n_estimators", 200)),
            max_depth=int(kwargs.pop("max_depth", 3)),
            learning_rate=float(kwargs.pop("learning_rate", 0.05)),
            random_state=int(kwargs.pop("random_state", 0)),
            **kwargs,
        )
    raise ValueError(f"unknown model name: {name!r}")


def fit_regressor(name: str, X: pd.DataFrame, y: np.ndarray, **kwargs: Any):
    """Train a regressor on ``(X, y)`` and return the fitted estimator.

    ``name`` is one of ``"linear"``, ``"ridge"``, ``"rf"``, ``"gbm"``.
    Extra keyword arguments are forwarded to the underlying sklearn
    constructor (e.g. ``n_estimators=200`` for ``"rf"``).
    """
    if len(X) != len(y):
        raise ValueError(f"X has {len(X)} rows but y has {len(y)} entries")
    est = _make_estimator(name, **kwargs)
    est.fit(np.asarray(X, dtype=float), np.asarray(y, dtype=float))
    return est


def predict(estimator, X: pd.DataFrame) -> np.ndarray:
    """Run ``estimator.predict(X)`` and return a numpy array."""
    return np.asarray(estimator.predict(np.asarray(X, dtype=float)), dtype=float)


def kfold_cv_predict(
    name: str,
    X: pd.DataFrame,
    y: np.ndarray,
    n_splits: int = 10,
    seed: int = 0,
    **kwargs: Any,
) -> np.ndarray:
    """Out-of-fold k-fold cross-validation prediction.

    Returns one prediction per row of ``X``; the prediction of row ``i``
    is from the fold in which it was the held-out point. This is the
    same protocol Ward 2016 reports in target.pdf Table 1 (10-fold CV
    of a single model trained on 228,676 OQMD compounds).
    """
    X_np = np.asarray(X, dtype=float)
    y_np = np.asarray(y, dtype=float)
    n = len(y_np)
    cv = KFold(n_splits=int(n_splits), shuffle=True, random_state=int(seed))
    yhat = np.zeros(n, dtype=float)
    for train_idx, test_idx in cv.split(X_np):
        est = _make_estimator(name, **kwargs)
        est.fit(X_np[train_idx], y_np[train_idx])
        yhat[test_idx] = est.predict(X_np[test_idx])
    return yhat


def regression_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> Dict[str, float]:
    """Return ``{MAE, RMSE, R2, Pearson_r, n}`` for one regression run."""
    yt = np.asarray(y_true, dtype=float)
    yp = np.asarray(y_pred, dtype=float)
    if yt.shape != yp.shape:
        raise ValueError("shape mismatch between y_true and y_pred")
    err = yp - yt
    mae = float(np.mean(np.abs(err)))
    rmse = float(np.sqrt(np.mean(err ** 2)))
    ybar = float(np.mean(yt))
    ss_res = float(np.sum(err ** 2))
    ss_tot = float(np.sum((yt - ybar) ** 2)) if np.any(yt != ybar) else 1.0
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0
    if yt.std() < 1e-12 or yp.std() < 1e-12:
        r = 0.0
    else:
        r = float(np.corrcoef(yt, yp)[0, 1])
    return {"MAE": mae, "RMSE": rmse, "R2": float(r2), "Pearson_r": r, "n": int(len(yt))}


def feature_importance(
    estimator, feature_names: Iterable[str]
) -> pd.DataFrame:
    """Return a DataFrame ``[feature, importance]`` sorted descending.

    Works only for ensemble estimators that expose
    ``feature_importances_`` (random forest, gradient boosting).
    """
    if not hasattr(estimator, "feature_importances_"):
        raise AttributeError(
            f"{type(estimator).__name__} has no feature_importances_; "
            "call this only on rf/gbm estimators."
        )
    names = list(feature_names)
    if len(names) != len(estimator.feature_importances_):
        raise ValueError(
            "feature_names length does not match estimator.feature_importances_"
        )
    df = pd.DataFrame({
        "feature": names,
        "importance": estimator.feature_importances_,
    }).sort_values("importance", ascending=False).reset_index(drop=True)
    return df


def compare_models(
    names: Iterable[str],
    X: pd.DataFrame,
    y: np.ndarray,
    n_splits: int = 10,
    seed: int = 0,
) -> pd.DataFrame:
    """Run k-fold CV for each model name and return a metrics table.

    The output DataFrame has one row per model with columns
    ``[model, MAE, RMSE, R2, Pearson_r]``. This is the analogue of
    Ward 2016 Table 1 (target.pdf p.4).
    """
    rows = []
    for nm in names:
        yhat = kfold_cv_predict(nm, X, y, n_splits=n_splits, seed=seed)
        m = regression_metrics(y, yhat)
        m["model"] = nm
        rows.append(m)
    df = pd.DataFrame(rows)[["model", "MAE", "RMSE", "R2", "Pearson_r"]]
    return df


def screen_candidates(
    estimator,
    Xc: pd.DataFrame,
    target_lo: float,
    target_hi: float,
) -> pd.DataFrame:
    """Predict the property of every candidate row and flag in-range hits.

    Returns a DataFrame ``[predicted, in_target_range]`` of length
    ``len(Xc)``. ``in_target_range`` is True when
    ``target_lo <= predicted <= target_hi``. Ward 2016 used
    ``target_lo=0.9, target_hi=1.7`` for solar-cell band gaps
    (target.pdf p.3 'we selected a subset of the OQMD ... band gap
    energies within the target range for solar cells: 0.9-1.7 eV').
    """
    yhat = predict(estimator, Xc)
    out = pd.DataFrame({
        "predicted": yhat,
        "in_target_range": (yhat >= target_lo) & (yhat <= target_hi),
    })
    return out

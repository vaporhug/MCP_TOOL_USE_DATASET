"""Tools for chem_xr01: ML on chemical composition for materials properties.

Modules:
    data_io       -- load element table, OQMD-like CSVs, and the candidate
                     solar-cell list.
    formula       -- parse chemical formulas, compute fractional composition.
    features      -- weighted statistic featurizers (Magpie-like) and helper
                     element-property aggregators.
    models        -- linear / random forest / gradient-boosting regressors,
                     k-fold cross validation predict, and feature-importance
                     ranking.
    plotting      -- parity plots, MAE bar charts, feature-importance bars,
                     error histograms, screening figures. Every plotting
                     function returns ``{"path": <abs_png_path>}``.
"""
from . import data_io, formula, features, models, plotting

__all__ = ["data_io", "formula", "features", "models", "plotting"]

"""Composition-based featurization (Magpie-like).

Given an inorganic formula, return a fixed-length numerical vector. The
features are statistics of element-level properties weighted by the
fractional composition. This is the same family of attributes described
in target.pdf (Ward 2016) Sect. 'General-purpose method', categories 1
and 2 (stoichiometric attributes and elemental property statistics).

Conventions
-----------
For a formula with element symbols ``s_i`` and atomic fractions ``f_i``:

  mean(p)   = sum_i f_i * p(s_i)
  max(p)    = max_i p(s_i)
  min(p)    = min_i p(s_i)
  range(p)  = max(p) - min(p)
  std(p)    = sqrt( sum_i f_i * (p(s_i) - mean(p))^2 )
  ave_dev(p)= sum_i f_i * |p(s_i) - mean(p)|

These are computed for a list of base properties (electronegativity,
atomic mass, covalent radius, first ionization energy, melting point,
periodic-table row and column, valence-shell occupancies). With 11 base
properties and 6 statistics each, plus stoichiometric scalars
(``n_elements``, ``frac_metal``), the default vector has 68 features.
"""
from __future__ import annotations

from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd

from .formula import parse_formula


DEFAULT_BASE_PROPERTIES: Tuple[str, ...] = (
    "electronegativity",
    "atomic_mass",
    "covalent_radius_pm",
    "first_ionization_eV",
    "melting_K",
    "row",
    "column",
    "n_p",
    "n_d",
    "n_f",
    "n_valence",
)

DEFAULT_STATISTICS: Tuple[str, ...] = ("mean", "max", "min", "range", "std", "ave_dev")


def _stat_value(values: np.ndarray, weights: np.ndarray, stat: str) -> float:
    """Compute one statistic of ``values`` weighted by ``weights``.

    ``weights`` must already be normalised so that ``weights.sum() == 1``.
    """
    if stat == "mean":
        return float(np.sum(weights * values))
    if stat == "max":
        return float(np.max(values))
    if stat == "min":
        return float(np.min(values))
    if stat == "range":
        return float(np.max(values) - np.min(values))
    if stat == "std":
        m = float(np.sum(weights * values))
        return float(np.sqrt(np.sum(weights * (values - m) ** 2)))
    if stat == "ave_dev":
        m = float(np.sum(weights * values))
        return float(np.sum(weights * np.abs(values - m)))
    raise ValueError(f"unknown statistic: {stat!r}")


def weighted_statistic(formula: str, ep: pd.DataFrame, prop: str, stat: str) -> float:
    """Compute one weighted statistic of one element-level property.

    Parameters
    ----------
    formula : str
        Chemical formula, e.g. ``'Fe2O3'``.
    ep : pandas.DataFrame
        Element table indexed by symbol (from ``load_element_table``).
    prop : str
        Column in ``ep`` to aggregate.
    stat : str
        One of {'mean', 'max', 'min', 'range', 'std', 'ave_dev'}.

    Returns
    -------
    float
    """
    comp = parse_formula(formula)
    syms = list(comp)
    n = np.array([comp[s] for s in syms], dtype=float)
    w = n / n.sum()
    vals = np.array([float(ep.loc[s, prop]) for s in syms], dtype=float)
    return _stat_value(vals, w, stat)


def featurize_formula(
    formula: str,
    ep: pd.DataFrame,
    base_properties: Optional[Iterable[str]] = None,
    statistics: Optional[Iterable[str]] = None,
) -> Dict[str, float]:
    """Return the full Magpie-like feature dictionary for a formula.

    The keys are formed as ``"<stat>_<prop>"`` (e.g. ``"mean_electronegativity"``)
    plus the scalars ``"n_elements"`` and ``"frac_metal"``.
    """
    base = list(base_properties) if base_properties is not None else list(DEFAULT_BASE_PROPERTIES)
    stats = list(statistics) if statistics is not None else list(DEFAULT_STATISTICS)
    comp = parse_formula(formula)
    syms = list(comp)
    n = np.array([comp[s] for s in syms], dtype=float)
    w = n / n.sum()
    out: Dict[str, float] = {}
    for prop in base:
        vals = np.array([float(ep.loc[s, prop]) for s in syms], dtype=float)
        for stat in stats:
            out[f"{stat}_{prop}"] = _stat_value(vals, w, stat)
    out["n_elements"] = float(len(syms))
    out["frac_metal"] = float(np.sum(w * np.array([float(ep.loc[s, "is_metal"]) for s in syms])))
    return out


def featurize_dataframe(
    df: pd.DataFrame,
    ep: pd.DataFrame,
    formula_col: str = "formula",
    base_properties: Optional[Iterable[str]] = None,
    statistics: Optional[Iterable[str]] = None,
) -> pd.DataFrame:
    """Return a DataFrame ``X`` of features (one row per formula).

    Row order matches ``df``. The output columns are sorted in a stable
    order: scalars first (``n_elements``, ``frac_metal``), then
    ``<stat>_<prop>`` triples in the order defined by ``base_properties``
    and ``statistics``.
    """
    if formula_col not in df.columns:
        raise KeyError(f"DataFrame missing '{formula_col}' column")
    rows = [featurize_formula(f, ep, base_properties, statistics) for f in df[formula_col]]
    cols: List[str] = ["n_elements", "frac_metal"]
    base = list(base_properties) if base_properties is not None else list(DEFAULT_BASE_PROPERTIES)
    stats = list(statistics) if statistics is not None else list(DEFAULT_STATISTICS)
    for prop in base:
        for stat in stats:
            cols.append(f"{stat}_{prop}")
    out = pd.DataFrame(rows)[cols]
    return out.reset_index(drop=True)


def feature_correlation(X: pd.DataFrame, y: np.ndarray) -> pd.Series:
    """Return Pearson r between each column of X and y, sorted by |r|.

    A useful sanity-check tool for the agent: confirms which features
    most strongly drive the property *before* fitting any model.
    """
    out = {}
    y = np.asarray(y, dtype=float)
    for c in X.columns:
        v = X[c].to_numpy(dtype=float)
        if v.std() < 1e-12:
            out[c] = 0.0
            continue
        out[c] = float(np.corrcoef(v, y)[0, 1])
    s = pd.Series(out).sort_values(key=lambda x: x.abs(), ascending=False)
    return s


def standardise(X: pd.DataFrame) -> Tuple[pd.DataFrame, pd.Series, pd.Series]:
    """Centre and rescale features by mean / std.

    Returns the standardised DataFrame, plus the column means and stds
    so the same transform can be applied to a held-out set.
    """
    mu = X.mean(axis=0)
    sigma = X.std(axis=0, ddof=0).replace(0.0, 1.0)
    Xs = (X - mu) / sigma
    return Xs, mu, sigma


def apply_standardise(X: pd.DataFrame, mu: pd.Series, sigma: pd.Series) -> pd.DataFrame:
    """Apply a previously-fit standardise to a new feature DataFrame."""
    sigma2 = sigma.replace(0.0, 1.0)
    return (X - mu) / sigma2

"""Plotting primitives. Every public function returns ``{"path": <abspath>}``.

The plotting functions use only matplotlib + numpy + pandas (no seaborn)
so they work in any sandbox. All figures are written as 300-dpi PNGs.
"""
from __future__ import annotations

import os
from typing import Dict, Iterable, List, Optional

import matplotlib

matplotlib.use("Agg")  # headless backend
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def _abs(path: str) -> str:
    return os.path.abspath(path)


def _ensure_parent(path: str) -> None:
    d = os.path.dirname(path)
    if d and not os.path.isdir(d):
        os.makedirs(d, exist_ok=True)


def parity_plot(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    save_path: str,
    title: str = "Parity plot",
    xlabel: str = "DFT value",
    ylabel: str = "Predicted value",
    units: str = "eV/atom",
) -> Dict[str, str]:
    """Scatter of measured vs predicted with the diagonal y=x line.

    Annotates MAE, RMSE and Pearson r in the upper-left. Returns
    ``{"path": <png>}`` so the agent can attach it to ``answer_items``.
    """
    yt = np.asarray(y_true, dtype=float)
    yp = np.asarray(y_pred, dtype=float)
    err = yp - yt
    mae = float(np.mean(np.abs(err)))
    rmse = float(np.sqrt(np.mean(err ** 2)))
    if yt.std() > 0 and yp.std() > 0:
        r = float(np.corrcoef(yt, yp)[0, 1])
    else:
        r = 0.0
    _ensure_parent(save_path)
    fig, ax = plt.subplots(figsize=(5.0, 5.0))
    ax.scatter(yt, yp, s=8, alpha=0.4, color="#1f77b4", edgecolor="none")
    lo = float(min(yt.min(), yp.min()))
    hi = float(max(yt.max(), yp.max()))
    ax.plot([lo, hi], [lo, hi], "k--", lw=1.0, label="y = x")
    ax.set_xlabel(f"{xlabel} ({units})")
    ax.set_ylabel(f"{ylabel} ({units})")
    ax.set_title(title)
    ax.text(
        0.04, 0.96,
        f"MAE = {mae:.3f}\nRMSE = {rmse:.3f}\nr = {r:.3f}\nn = {len(yt)}",
        transform=ax.transAxes, va="top", ha="left", fontsize=10,
        bbox=dict(boxstyle="round,pad=0.3", facecolor="white", alpha=0.85),
    )
    ax.legend(loc="lower right")
    fig.tight_layout()
    fig.savefig(save_path, dpi=300)
    plt.close(fig)
    return {"path": _abs(save_path)}


def model_comparison_bar(
    metrics_table: pd.DataFrame,
    save_path: str,
    metric: str = "MAE",
    title: Optional[str] = None,
    units: str = "eV/atom",
) -> Dict[str, str]:
    """Bar chart of one metric per model. Expects a DataFrame as returned
    by ``models.compare_models`` with columns ``model`` and ``metric``.
    """
    if metric not in metrics_table.columns:
        raise KeyError(f"metric {metric!r} not in metrics_table columns: "
                       f"{list(metrics_table.columns)}")
    if "model" not in metrics_table.columns:
        raise KeyError("metrics_table is missing 'model' column")
    _ensure_parent(save_path)
    df = metrics_table.copy()
    df = df.sort_values(metric)
    fig, ax = plt.subplots(figsize=(5.5, 3.6))
    colors = ["#1f77b4" if i > 0 else "#d62728" for i in range(len(df))]
    ax.bar(df["model"].tolist(), df[metric].to_numpy(), color=colors, edgecolor="black")
    for i, v in enumerate(df[metric].to_numpy()):
        ax.text(i, v, f"{v:.3f}", ha="center", va="bottom", fontsize=9)
    ax.set_ylabel(f"{metric} ({units})" if metric in ("MAE", "RMSE") else metric)
    ax.set_title(title or f"10-fold cross-validated {metric}")
    fig.tight_layout()
    fig.savefig(save_path, dpi=300)
    plt.close(fig)
    return {"path": _abs(save_path)}


def feature_importance_bar(
    importance_df: pd.DataFrame,
    save_path: str,
    top_n: int = 15,
    title: str = "Feature importance",
) -> Dict[str, str]:
    """Horizontal bar chart of the top-``top_n`` feature importances.

    Expects a DataFrame ``[feature, importance]`` sorted descending.
    """
    if {"feature", "importance"} - set(importance_df.columns):
        raise KeyError("importance_df must have columns ['feature','importance']")
    df = importance_df.head(int(top_n)).iloc[::-1]
    _ensure_parent(save_path)
    fig, ax = plt.subplots(figsize=(6.0, 0.32 * len(df) + 1.0))
    ax.barh(df["feature"], df["importance"], color="#2ca02c", edgecolor="black")
    ax.set_xlabel("relative importance")
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(save_path, dpi=300)
    plt.close(fig)
    return {"path": _abs(save_path)}


def error_histogram(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    save_path: str,
    title: str = "Residuals",
    units: str = "eV/atom",
    bins: int = 50,
) -> Dict[str, str]:
    """Histogram of prediction residuals (``y_pred - y_true``)."""
    err = np.asarray(y_pred, dtype=float) - np.asarray(y_true, dtype=float)
    _ensure_parent(save_path)
    fig, ax = plt.subplots(figsize=(5.0, 3.6))
    ax.hist(err, bins=int(bins), color="#9467bd", edgecolor="black")
    ax.axvline(0.0, color="black", lw=1.0, ls="--")
    ax.set_xlabel(f"residual ({units})")
    ax.set_ylabel("count")
    ax.set_title(title)
    ax.text(
        0.02, 0.97,
        f"mean = {err.mean():+.3f}\nstd = {err.std(ddof=0):.3f}\nMAE = {np.mean(np.abs(err)):.3f}",
        transform=ax.transAxes, va="top", ha="left", fontsize=9,
        bbox=dict(boxstyle="round,pad=0.3", facecolor="white", alpha=0.85),
    )
    fig.tight_layout()
    fig.savefig(save_path, dpi=300)
    plt.close(fig)
    return {"path": _abs(save_path)}


def candidate_screening_plot(
    candidate_df: pd.DataFrame,
    save_path: str,
    target_lo: float = 0.9,
    target_hi: float = 1.7,
    pred_col: str = "predicted",
    pub_col: Optional[str] = "predicted_band_gap_eV_published",
    label_col: str = "formula",
    title: str = "Solar-cell candidate band gaps",
) -> Dict[str, str]:
    """Per-candidate predicted band gap with the target window shaded.

    If ``pub_col`` is present, the published value (Ward 2016 Table 2)
    is overlaid as red x's so the agent can see how its prediction
    deviates from the original.
    """
    df = candidate_df.copy()
    if label_col not in df.columns or pred_col not in df.columns:
        raise KeyError(f"need columns {label_col}, {pred_col} in candidate_df")
    _ensure_parent(save_path)
    fig, ax = plt.subplots(figsize=(6.5, 4.0))
    ax.axhspan(target_lo, target_hi, color="#ffd166", alpha=0.4,
               label=f"target {target_lo:.1f}-{target_hi:.1f} eV")
    x = np.arange(len(df))
    ax.bar(x, df[pred_col].to_numpy(), color="#1f77b4", edgecolor="black",
           label="predicted (this work)")
    if pub_col is not None and pub_col in df.columns:
        ax.scatter(x, df[pub_col].to_numpy(), s=70, marker="x",
                   color="red", linewidth=2.0, label="Ward 2016 (published)")
    ax.set_xticks(x)
    ax.set_xticklabels(df[label_col].tolist(), rotation=20, ha="right")
    ax.set_ylabel("band gap (eV)")
    ax.set_title(title)
    ax.legend(loc="best", fontsize=9)
    fig.tight_layout()
    fig.savefig(save_path, dpi=300)
    plt.close(fig)
    return {"path": _abs(save_path)}


def screening_accuracy_bar(
    accuracies: Dict[str, float],
    save_path: str,
    title: str = "Solar-cell band-gap selection accuracy",
) -> Dict[str, str]:
    """Bar chart reproducing Ward 2016 Figure 1.

    ``accuracies`` is a dict like ``{"random": 0.12, "single": 0.46,
    "partitioned": 0.67}`` (the three strategies in target.pdf Fig. 1).
    """
    _ensure_parent(save_path)
    keys = list(accuracies.keys())
    vals = [float(accuracies[k]) * 100.0 for k in keys]
    fig, ax = plt.subplots(figsize=(5.0, 3.6))
    ax.bar(keys, vals, color=["#a0a0a0", "#1f77b4", "#d62728"], edgecolor="black")
    for i, v in enumerate(vals):
        ax.text(i, v, f"{v:.0f}%", ha="center", va="bottom", fontsize=10)
    ax.set_ylim(0, 100)
    ax.set_ylabel("predictions within target range (%)")
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(save_path, dpi=300)
    plt.close(fig)
    return {"path": _abs(save_path)}


def feature_correlation_scatter(
    X: pd.DataFrame,
    y: np.ndarray,
    feature: str,
    save_path: str,
    ylabel: str = "property",
    units: str = "eV",
) -> Dict[str, str]:
    """Scatter of one feature vs the target, with a least-squares line."""
    if feature not in X.columns:
        raise KeyError(f"feature {feature!r} not in X.columns")
    _ensure_parent(save_path)
    xv = X[feature].to_numpy(dtype=float)
    yv = np.asarray(y, dtype=float)
    fig, ax = plt.subplots(figsize=(4.8, 3.6))
    ax.scatter(xv, yv, s=8, alpha=0.4, color="#1f77b4", edgecolor="none")
    if xv.std() > 0:
        slope, intercept = np.polyfit(xv, yv, 1)
        xs = np.linspace(xv.min(), xv.max(), 50)
        ax.plot(xs, slope * xs + intercept, "k--", lw=1.0,
                label=f"slope={slope:+.3f}")
        ax.legend(loc="best", fontsize=9)
    ax.set_xlabel(feature)
    ax.set_ylabel(f"{ylabel} ({units})")
    fig.tight_layout()
    fig.savefig(save_path, dpi=300)
    plt.close(fig)
    return {"path": _abs(save_path)}

"""Chemical-formula parsing primitives.

These functions handle the simple subset of chemical-formula syntax used
in OQMD/ICSD compositions: capital + optional lowercase letter for the
symbol followed by an optional integer (or decimal) stoichiometry. They
do NOT understand parentheses or hydrate dots; the caller is expected to
work with already-canonicalised formulas like ``Mn6CCl8`` or
``Hf4S11Cl2``.
"""
from __future__ import annotations

import re
from typing import Dict, List, Tuple

import numpy as np


_FORMULA_RE = re.compile(r"([A-Z][a-z]?)(\d*\.?\d*)")


def parse_formula(formula: str) -> Dict[str, float]:
    """Parse a formula like ``'Mn6CCl8'`` into ``{'Mn':6,'C':1,'Cl':8}``.

    Parameters
    ----------
    formula : str
        e.g. ``'Fe2O3'`` or ``'Hf4S11Cl2'``.

    Returns
    -------
    dict[str, float]
        Mapping symbol -> stoichiometric count (count >= 1; default 1
        when no number follows the symbol).
    """
    if not isinstance(formula, str) or not formula:
        raise ValueError(f"empty formula: {formula!r}")
    out: Dict[str, float] = {}
    consumed = 0
    for sym, count in _FORMULA_RE.findall(formula):
        if sym == "":
            continue
        c = float(count) if count not in ("", ".") else 1.0
        out[sym] = out.get(sym, 0.0) + c
        consumed += len(sym) + len(count)
    if consumed != len(formula):
        raise ValueError(f"unparsed characters in formula: {formula!r}")
    if not out:
        raise ValueError(f"no symbols recognised in formula: {formula!r}")
    return out


def composition_fractions(formula: str) -> Dict[str, float]:
    """Return the per-element atomic fractions of a formula (sum=1)."""
    comp = parse_formula(formula)
    total = float(sum(comp.values()))
    return {s: c / total for s, c in comp.items()}


def composition_vector(formula: str, ep_index: List[str]) -> np.ndarray:
    """Return a length-``len(ep_index)`` fraction vector aligned to a list of
    element symbols. Elements absent from the formula get fraction 0.

    This is useful when the agent wants a fixed-length one-hot-style
    representation (e.g. for ElemNet / linear-on-fractions baselines).
    """
    fr = composition_fractions(formula)
    out = np.zeros(len(ep_index), dtype=float)
    for i, sym in enumerate(ep_index):
        out[i] = fr.get(sym, 0.0)
    return out


def n_elements(formula: str) -> int:
    """Return the number of distinct elements in a formula."""
    return len(parse_formula(formula))


def total_atoms_per_formula_unit(formula: str) -> float:
    """Return the sum of stoichiometric counts in the formula unit."""
    return float(sum(parse_formula(formula).values()))


def is_metal_only(formula: str, ep) -> bool:
    """Return ``True`` if every element in the formula is metallic.

    ``ep`` must be the indexed-by-symbol DataFrame returned by
    ``data_io.load_element_table`` and must contain the ``is_metal``
    column.
    """
    comp = parse_formula(formula)
    for sym in comp:
        if int(ep.loc[sym, "is_metal"]) != 1:
            return False
    return True


def contains_any(formula: str, group: List[str]) -> bool:
    """Return ``True`` if the formula contains any element from ``group``.

    Useful for Ward's halogen / chalcogen / pnictogen partitioning of
    the band-gap problem (target.pdf, "partitioning the data set").
    """
    comp = parse_formula(formula)
    return any(s in comp for s in group)

"""Loading and inspection primitives for the chem_xr01 task.

All tables are tab-/comma-separated CSV files in ``input_data/data``:

``element_properties.csv``
    One row per chemical element (symbol). Columns include atomic number
    ``Z``, ``symbol``, ``atomic_mass``, ``electronegativity`` (Pauling),
    ``covalent_radius_pm``, ``first_ionization_eV``, ``melting_K``,
    ``boiling_K``, ``density_g_cc``, ``row``, ``column``, valence-shell
    occupancies ``n_s``/``n_p``/``n_d``/``n_f``, ``n_valence``, ``group``
    and ``is_metal`` (1=metallic element).

``oqmd_subset.csv``
    Rows: a binary/ternary/quaternary inorganic composition. Columns
    ``formula``, ``n_elements``, ``formation_energy_eV_per_atom``,
    ``band_gap_eV``. This is the training table.

``icsd_bandgap_subset.csv``
    Same schema as ``oqmd_subset.csv`` but restricted to compositions
    that contain at least one nonmetal AND have a positive band gap.

``solar_cell_candidates.csv``
    Five candidate ternary halides with their published predicted band
    gaps (one column ``predicted_band_gap_eV_published``).
"""
from __future__ import annotations

import os
from typing import List

import numpy as np
import pandas as pd


def load_element_table(path: str) -> pd.DataFrame:
    """Load the element-property table as a DataFrame indexed by symbol.

    Parameters
    ----------
    path : str
        Path to ``element_properties.csv``.

    Returns
    -------
    pandas.DataFrame
        Same as the CSV with ``symbol`` set as the index.
    """
    if not os.path.isfile(path):
        raise FileNotFoundError(path)
    df = pd.read_csv(path)
    must_have = {"Z", "symbol", "electronegativity", "atomic_mass",
                 "covalent_radius_pm", "first_ionization_eV",
                 "melting_K", "row", "column",
                 "n_s", "n_p", "n_d", "n_f", "n_valence", "is_metal"}
    missing = must_have - set(df.columns)
    if missing:
        raise KeyError(f"element table missing columns: {sorted(missing)}")
    return df.set_index("symbol", drop=False)


def load_oqmd_subset(path: str) -> pd.DataFrame:
    """Load an OQMD-style training/eval table.

    Returns a DataFrame with the columns ``formula``, ``n_elements``,
    ``formation_energy_eV_per_atom`` and ``band_gap_eV``.
    """
    if not os.path.isfile(path):
        raise FileNotFoundError(path)
    df = pd.read_csv(path)
    must_have = {"formula", "formation_energy_eV_per_atom", "band_gap_eV"}
    missing = must_have - set(df.columns)
    if missing:
        raise KeyError(f"OQMD CSV missing columns: {sorted(missing)}")
    return df.reset_index(drop=True)


def load_candidates(path: str) -> pd.DataFrame:
    """Load the solar-cell candidate list (formula plus published band gap)."""
    if not os.path.isfile(path):
        raise FileNotFoundError(path)
    df = pd.read_csv(path)
    if "formula" not in df.columns:
        raise KeyError("candidates CSV missing 'formula'")
    return df.reset_index(drop=True)


def list_elements(ep: pd.DataFrame) -> List[str]:
    """Return the sorted list of element symbols available in ``ep``."""
    return sorted(ep["symbol"].tolist())


def dataset_summary(df: pd.DataFrame) -> dict:
    """Return ``{n, n_unique_formulas, n_elements_min, n_elements_max,
    Eform_mean, Eform_std, Egap_mean, Egap_std, Egap_zero_frac}``.

    Useful for the agent to confirm the loaded table has the expected
    size and roughly the expected property ranges (Ward 2016 trained on
    228,676 OQMD compounds with mean E_form near -0.7 eV/atom).
    """
    n = int(len(df))
    out = {
        "n": n,
        "n_unique_formulas": int(df["formula"].nunique()),
        "n_elements_min": int(df["n_elements"].min()) if "n_elements" in df else 0,
        "n_elements_max": int(df["n_elements"].max()) if "n_elements" in df else 0,
        "Eform_mean": float(df["formation_energy_eV_per_atom"].mean()),
        "Eform_std": float(df["formation_energy_eV_per_atom"].std(ddof=0)),
        "Egap_mean": float(df["band_gap_eV"].mean()),
        "Egap_std": float(df["band_gap_eV"].std(ddof=0)),
        "Egap_zero_frac": float((df["band_gap_eV"] <= 1e-3).mean()),
    }
    return out


def get_element_property(ep: pd.DataFrame, symbol: str, prop: str) -> float:
    """Return ``ep.loc[symbol, prop]`` as a Python float.

    Raises a KeyError with a clear message if the element or property is
    missing, instead of returning ``NaN``.
    """
    if symbol not in ep.index:
        raise KeyError(f"unknown element symbol: {symbol}")
    if prop not in ep.columns:
        raise KeyError(f"unknown element property: {prop}")
    return float(ep.loc[symbol, prop])


def filter_metallic_only(df: pd.DataFrame, ep: pd.DataFrame) -> pd.DataFrame:
    """Return rows whose composition contains only metallic elements.

    A composition counts as metallic-only if every constituent has
    ``is_metal == 1``. This mirrors Ward's 'metal/nonmetal' partitioning
    strategy described in target.pdf p.2.
    """
    from .formula import parse_formula
    metals = set(ep[ep["is_metal"] == 1].index.tolist())
    keep = []
    for f in df["formula"].tolist():
        comp = parse_formula(f)
        keep.append(all(s in metals for s in comp))
    return df[pd.Series(keep, index=df.index)].copy()


def train_test_split_indices(n: int, test_frac: float, seed: int = 0):
    """Return ``(train_idx, test_idx)`` numpy arrays for a random split.

    A reproducible holdout split that does not depend on scikit-learn.
    """
    if not (0.0 < test_frac < 1.0):
        raise ValueError("test_frac must be in (0, 1)")
    rng = np.random.default_rng(seed)
    perm = rng.permutation(n)
    n_test = int(round(n * test_frac))
    return perm[n_test:], perm[:n_test]

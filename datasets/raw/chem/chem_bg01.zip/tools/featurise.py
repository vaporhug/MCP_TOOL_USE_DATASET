"""Early-cycle feature engineering for cycle-life regression.

The headline feature is the per-cell ``ΔQ100-10(V) = Q_100(V) - Q_10(V)``
discharge-curve difference. Summary statistics of this curve (variance,
minimum, mean, skewness, kurtosis, ...) are well-known to be predictive of
end-of-life. We additionally expose a few coarse early-cycle scalars:

    QD_cycle2, QD_cycle100, dQD_2_to_100,
    slope_QD_95_100,
    QD_min_first100, QD_max_first100,
    log_var_dQ100_10, min_dQ100_10, mean_dQ100_10,
    skew_dQ100_10, kurt_dQ100_10.

Note: this dataset bundle does not include IR or discharge-time scalars
(the petermattia preprocessing that produced the public Qdlin CSVs only
retained the linearly-interpolated discharge-capacity curves), so the
IR-based features from the original Severson 'full' model are omitted.
"""
from __future__ import annotations

from typing import Dict, Iterable, List

import numpy as np
import pandas as pd

from . import capacity, data_io


def delta_q_curve(qdlin: pd.DataFrame, cell: str,
                  early_cycle: int = 10, late_cycle: int = 100) -> pd.DataFrame:
    """Return the curve ``ΔQ(V) = Q_late(V) - Q_early(V)`` for one cell.

    Output columns: voltage_V, dQ_Ah.
    """
    a = data_io.pivot_qv_curve(qdlin, cell, early_cycle)
    b = data_io.pivot_qv_curve(qdlin, cell, late_cycle)
    if not np.allclose(a["voltage_V"].to_numpy(),
                       b["voltage_V"].to_numpy()):
        raise ValueError("voltage axes mismatch between early and late cycle")
    out = pd.DataFrame({
        "voltage_V": a["voltage_V"].to_numpy(),
        "dQ_Ah": b["Q_Ah"].to_numpy() - a["Q_Ah"].to_numpy(),
    })
    return out


def _moments(x: np.ndarray) -> Dict[str, float]:
    x = np.asarray(x, dtype=float)
    n = x.size
    if n == 0:
        return dict(mean=float("nan"), var=float("nan"),
                    skew=float("nan"), kurt=float("nan"),
                    min=float("nan"), max=float("nan"))
    m = float(np.mean(x))
    var = float(np.var(x))
    sd = np.sqrt(var) if var > 0 else 0.0
    if sd > 0:
        skew = float(np.mean(((x - m) / sd) ** 3))
        kurt = float(np.mean(((x - m) / sd) ** 4) - 3.0)
    else:
        skew = 0.0
        kurt = 0.0
    return dict(mean=m, var=var, skew=skew, kurt=kurt,
                min=float(np.min(x)), max=float(np.max(x)))


def delta_q_summary_stats(qdlin: pd.DataFrame, cell: str,
                          early_cycle: int = 10,
                          late_cycle: int = 100) -> Dict[str, float]:
    """Summary statistics of ΔQ_late-early(V) for one cell."""
    curve = delta_q_curve(qdlin, cell, early_cycle, late_cycle)
    s = _moments(curve["dQ_Ah"].to_numpy())
    var = max(s["var"], 1e-15)
    return {
        "var_dQ": s["var"],
        "log_var_dQ": float(np.log10(var)),
        "min_dQ": s["min"],
        "max_dQ": s["max"],
        "mean_dQ": s["mean"],
        "skew_dQ": s["skew"],
        "kurt_dQ": s["kurt"],
    }


def early_cycle_scalars(summary: pd.DataFrame, cell: str) -> Dict[str, float]:
    """Per-cell coarse scalars derived from the QD trajectory over cycles 2..100."""
    sub = summary[summary["cell"] == cell].sort_values("cycle")
    if sub.empty:
        raise KeyError(f"no cycles for cell {cell!r}")

    def _at(cyc: int, col: str) -> float:
        if (sub["cycle"] == cyc).any():
            return float(sub.loc[sub["cycle"] == cyc, col].mean())
        return float("nan")

    qd2 = _at(2, "QD_Ah")
    qd100 = _at(100, "QD_Ah")
    fade = sub[["cycle", "QD_Ah"]]
    slope_95_100 = capacity.slope_between_cycles(fade, 95, 100)
    # Robust QD min/max within first 100 cycles: drop occasional measurement
    # spikes (discharge capacity > 1.3*nominal or < 0.7*nominal) before taking
    # the extremum. The raw QD trace has rare A123-tester glitches at single
    # cycles which the original Severson preprocessing filters out as well.
    in_first100 = sub.loc[sub["cycle"] <= 100, "QD_Ah"]
    clean = in_first100[(in_first100 > 0.7 * 1.1) & (in_first100 < 1.3 * 1.1)]
    qd_min_first100 = float(clean.min()) if len(clean) else float("nan")
    qd_max_first100 = float(clean.max()) if len(clean) else float("nan")

    return {
        "QD_cycle2": qd2,
        "QD_cycle100": qd100,
        "dQD_2_to_100": qd100 - qd2,
        "slope_QD_95_100": slope_95_100,
        "QD_min_first100": qd_min_first100,
        "QD_max_first100": qd_max_first100,
    }


def featurise_cell(summary: pd.DataFrame, qdlin: pd.DataFrame,
                   cell: str, early_cycle: int = 10,
                   late_cycle: int = 100) -> Dict[str, float]:
    """All available features for one cell."""
    feats = early_cycle_scalars(summary, cell)
    feats.update(delta_q_summary_stats(qdlin, cell,
                                       early_cycle=early_cycle,
                                       late_cycle=late_cycle))
    return feats


def featurise_dataset(summary: pd.DataFrame, qdlin: pd.DataFrame,
                      meta: pd.DataFrame,
                      early_cycle: int = 10, late_cycle: int = 100) -> pd.DataFrame:
    """Build the per-cell feature matrix used downstream by the regressor.

    Returned columns: cell, split, cycle_life, <feature columns...>.
    """
    rows: List[Dict[str, float]] = []
    for cell in sorted(meta["cell"].unique()):
        feats = featurise_cell(summary, qdlin, cell,
                               early_cycle=early_cycle,
                               late_cycle=late_cycle)
        meta_row = meta.loc[meta["cell"] == cell].iloc[0]
        feats["cell"] = cell
        feats["split"] = str(meta_row["split"])
        feats["cycle_life"] = int(meta_row["cycle_life"])
        rows.append(feats)
    df = pd.DataFrame(rows)
    cols = ["cell", "split", "cycle_life"] + [c for c in df.columns
                                              if c not in {"cell", "split", "cycle_life"}]
    return df[cols]


def feature_columns(features: pd.DataFrame) -> List[str]:
    """List of numeric feature columns (excludes ``cell``, ``split``, ``cycle_life``)."""
    excl = {"cell", "split", "cycle_life"}
    return [c for c in features.columns if c not in excl]


def standardise(X: np.ndarray, mean: np.ndarray | None = None,
                std: np.ndarray | None = None):
    """Centre and scale a feature matrix; returns (Z, mean, std).

    If mean/std are provided they are used (for transform on new data).
    """
    X = np.asarray(X, dtype=float)
    if mean is None:
        mean = X.mean(axis=0)
    if std is None:
        std = X.std(axis=0)
        std = np.where(std < 1e-12, 1.0, std)
    Z = (X - mean) / std
    return Z, mean, std

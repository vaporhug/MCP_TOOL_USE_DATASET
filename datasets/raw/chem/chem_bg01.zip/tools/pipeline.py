"""Thin orchestration helper: build features, fit elastic net, score every split."""
from __future__ import annotations

from typing import Dict, List, Tuple

import numpy as np
import pandas as pd

from . import data_io, evaluation, featurise, models


def build_feature_matrix(meta: pd.DataFrame, cycle_summary: pd.DataFrame,
                         qdlin: pd.DataFrame,
                         early_cycle: int = 10, late_cycle: int = 100) -> pd.DataFrame:
    """Convenience wrapper that returns the per-cell feature DataFrame."""
    return featurise.featurise_dataset(cycle_summary, qdlin, meta,
                                       early_cycle=early_cycle,
                                       late_cycle=late_cycle)


def split_xy(features: pd.DataFrame, feature_cols: List[str],
             split: str) -> Tuple[np.ndarray, np.ndarray, List[str]]:
    """Return (X, y_cycle_life, cell_ids) for a specific split label."""
    sub = features[features["split"] == split].reset_index(drop=True)
    X = sub[feature_cols].to_numpy(dtype=float)
    y = sub["cycle_life"].to_numpy(dtype=float)
    cells = sub["cell"].astype(str).tolist()
    return X, y, cells


def fit_elastic_net_log_life(X_train: np.ndarray, y_train: np.ndarray,
                             alpha: float = 0.5, lambda_: float = 0.05,
                             max_iter: int = 5000):
    """Standardise X, fit ``log10(cycle_life)``, return wrapped predictor + scaling."""
    Z, mu, sd = featurise.standardise(X_train)
    en = models.ElasticNet(alpha=alpha, lambda_=lambda_, max_iter=max_iter)
    wrapped = models.fit_log_cycle_life(en, Z, y_train)

    class _ScaledModel:
        def __init__(self, wrap, mu, sd, raw):
            self._w = wrap
            self._mu = mu
            self._sd = sd
            self.coef_ = raw.coef_
            self.intercept_ = raw.intercept_
            self.raw = raw

        def transform(self, X):
            return (np.asarray(X, dtype=float) - self._mu) / self._sd

        def predict(self, X):
            return self._w.predict(self.transform(X))

        def predict_log(self, X):
            return self._w.predict_log(self.transform(X))

    return _ScaledModel(wrapped, mu, sd, en)


def score_all_splits(model, features: pd.DataFrame,
                     feature_cols: List[str]) -> pd.DataFrame:
    """Run model on each split and return per-split MAPE/RMSE/R^2."""
    rows = []
    for split in ["train", "test", "secondary_test"]:
        sub = features[features["split"] == split]
        if sub.empty:
            continue
        X = sub[feature_cols].to_numpy(dtype=float)
        y = sub["cycle_life"].to_numpy(dtype=float)
        pred = model.predict(X)
        rows.append({
            "split": split,
            "n_cells": int(len(y)),
            "MAPE_%": evaluation.mape(y, pred),
            "RMSE_cycles": evaluation.rmse(y, pred),
            "R2": evaluation.r2_score(y, pred),
        })
    return pd.DataFrame(rows)


def predict_all(model, features: pd.DataFrame,
                feature_cols: List[str]) -> pd.DataFrame:
    """Return DataFrame with cell, split, observed, predicted (for parity plots)."""
    out_rows = []
    for _, row in features.iterrows():
        x = row[feature_cols].to_numpy(dtype=float).reshape(1, -1)
        pred = float(model.predict(x)[0])
        out_rows.append({
            "cell": str(row["cell"]),
            "split": str(row["split"]),
            "observed_cycle_life": int(row["cycle_life"]),
            "predicted_cycle_life": pred,
        })
    return pd.DataFrame(out_rows)


def variance_only_baseline(features: pd.DataFrame,
                           variance_col: str = "log_var_dQ") -> Dict[str, float]:
    """Univariate elastic-net (no regularisation) on log_var_dQ alone."""
    train = features[features["split"] == "train"]
    Xtr = train[[variance_col]].to_numpy(dtype=float)
    ytr = train["cycle_life"].to_numpy(dtype=float)
    en = models.ElasticNet(alpha=0.0, lambda_=1e-6, max_iter=5000)
    wrapped = models.fit_log_cycle_life(en, Xtr, ytr)

    out = {}
    for split in ["train", "test", "secondary_test"]:
        sub = features[features["split"] == split]
        if sub.empty:
            continue
        Xs = sub[[variance_col]].to_numpy(dtype=float)
        pred = wrapped.predict(Xs)
        out[f"{split}_MAPE_%"] = evaluation.mape(sub["cycle_life"], pred)
        out[f"{split}_RMSE"] = evaluation.rmse(sub["cycle_life"], pred)
    return out


def run_full_pipeline(data_dir: str = "input_data/data",
                      alpha: float = 0.5, lambda_: float = 0.05) -> Dict:
    """End-to-end: load -> featurise -> fit -> score (returns a results dict)."""
    meta = data_io.load_cell_metadata(f"{data_dir}/cell_metadata.csv")
    summary = data_io.load_cycle_summary(f"{data_dir}/cycle_summary.csv")
    qdlin = data_io.load_qdlin_curves(f"{data_dir}/qdlin_cycles_10_100.csv")
    feats = build_feature_matrix(meta, summary, qdlin)
    cols = featurise.feature_columns(feats)
    Xtr, ytr, _ = split_xy(feats, cols, "train")
    model = fit_elastic_net_log_life(Xtr, ytr, alpha=alpha, lambda_=lambda_)
    scores = score_all_splits(model, feats, cols)
    importance = models.feature_importance_from_coefficients(
        model.coef_, cols, standardised=True)
    return {
        "features": feats,
        "feature_cols": cols,
        "model": model,
        "scores": scores,
        "feature_importance": importance,
    }

"""Loaders and light look-up helpers for the cycling dataset.

Files in input_data/data/:
    cell_metadata.csv          one row per cell (124 cells)
                               (cell, split, cycle_life, n_cycles_recorded,
                                QD_cycle2, QD_cycle100, cell_barcode,
                                charging_policy, batch_date).
    cycle_summary.csv          per-cycle scalars (cell, split, cycle_life,
                               cycle, QD_Ah).  Cycles 2..100 for every cell.
    qdlin_cycles_10_100.csv    1000-pt linearly-interpolated discharge-capacity
                               curves Q(V) for cycles 10 and 100 of every cell.
                               Columns: cell, split, cycle, voltage_V, Q_Ah.
    voltage_axis.csv           index 0..999 -> voltage_V (3.6 V down to 2.0 V).

Splits are 'train', 'test' (primary), 'secondary_test'.
"""
from __future__ import annotations

from pathlib import Path
from typing import Iterable, List

import numpy as np
import pandas as pd


def _resolve(path: str | Path) -> Path:
    p = Path(path)
    if p.exists():
        return p
    here = Path(__file__).resolve().parent.parent
    cand = here / path
    if cand.exists():
        return cand
    raise FileNotFoundError(f"could not locate {path}")


def load_cell_metadata(path: str = "input_data/data/cell_metadata.csv") -> pd.DataFrame:
    """Load the per-cell summary table (one row per cell)."""
    df = pd.read_csv(_resolve(path))
    df["cell"] = df["cell"].astype(str)
    df["split"] = df["split"].astype(str)
    df["cycle_life"] = df["cycle_life"].astype(int)
    return df


def load_cycle_summary(path: str = "input_data/data/cycle_summary.csv") -> pd.DataFrame:
    """Load the per-cycle scalar summary (QD_Ah for cycles 2..100, all 124 cells)."""
    df = pd.read_csv(_resolve(path))
    df["cell"] = df["cell"].astype(str)
    df["split"] = df["split"].astype(str)
    df["cycle"] = df["cycle"].astype(int)
    return df


def load_qdlin_curves(
    path: str = "input_data/data/qdlin_cycles_10_100.csv",
) -> pd.DataFrame:
    """Load the long-format Q(V) curves at cycle 10 and cycle 100 for every cell."""
    df = pd.read_csv(_resolve(path))
    df["cell"] = df["cell"].astype(str)
    df["cycle"] = df["cycle"].astype(int)
    return df


def load_voltage_axis(path: str = "input_data/data/voltage_axis.csv") -> np.ndarray:
    """Return the 1000-element voltage axis (V) used for linear Q(V) interpolation.

    The axis is descending from 3.6 V to 2.0 V (matches Severson et al. Vdlin convention).
    """
    df = pd.read_csv(_resolve(path))
    return df["voltage_V"].to_numpy()


def list_cells(meta: pd.DataFrame) -> List[str]:
    """List of cell identifiers present in the metadata table."""
    return sorted(meta["cell"].unique().tolist())


def cells_in_split(meta: pd.DataFrame, split: str) -> List[str]:
    """List the cells belonging to a given split label."""
    valid = {"train", "test", "secondary_test"}
    if split not in valid:
        raise ValueError(f"split must be one of {valid}, got {split!r}")
    return sorted(meta.loc[meta["split"] == split, "cell"].tolist())


def filter_cycles(summary: pd.DataFrame, cells: Iterable[str],
                  cycle_max: int | None = None) -> pd.DataFrame:
    """Return cycle rows for the given cell IDs, optionally truncated at cycle_max."""
    cell_set = set(cells)
    out = summary[summary["cell"].isin(cell_set)]
    if cycle_max is not None:
        out = out[out["cycle"] <= int(cycle_max)]
    return out.reset_index(drop=True)


def pivot_qv_curve(qdlin: pd.DataFrame, cell: str, cycle: int) -> pd.DataFrame:
    """Return the Q(V) curve for one (cell, cycle): voltage_V and Q_Ah columns.

    Note on axis ordering: the bundled qdlin / voltage_axis store voltage in the
    Severson **descending** discharge direction (3.6 V down to 2.0 V). This
    function sorts the returned rows by ``voltage_V`` **ascending** (2.0 -> 3.6 V)
    so the output is monotonically increasing in voltage. Callers that need the
    native discharge order (e.g. to align with voltage_axis.csv row order or to
    plot left-to-right in discharge direction) must re-reverse the rows.
    """
    sub = qdlin[(qdlin["cell"] == cell) & (qdlin["cycle"] == int(cycle))].copy()
    if sub.empty:
        raise KeyError(f"no Q(V) curve for cell={cell!r} cycle={cycle}")
    sub = sub[["voltage_V", "Q_Ah"]].sort_values("voltage_V").reset_index(drop=True)
    return sub


def cycle_life_lookup(meta: pd.DataFrame) -> "dict[str, int]":
    """Mapping cell_id -> cycle life (cycles to 80% nominal capacity)."""
    return {row["cell"]: int(row["cycle_life"]) for _, row in meta.iterrows()}

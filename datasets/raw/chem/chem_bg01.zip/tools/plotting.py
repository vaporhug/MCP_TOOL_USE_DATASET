"""Plot helpers (matplotlib only). Each function returns ``{"path": <abs path>}``."""
from __future__ import annotations

import os
from pathlib import Path
from typing import Iterable, Sequence

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def _ensure_dir(out_path: str) -> str:
    """Create the parent directory of ``out_path`` if needed and return the
    resolved **absolute** path. Routing every plot helper's ``out_path`` through
    this function guarantees the ``{"path": <abs path>}`` returned by each
    plotting function is absolute, matching this module's docstring contract.
    """
    p = Path(out_path)
    p.parent.mkdir(parents=True, exist_ok=True)
    return str(p.resolve())


def plot_capacity_fade(summary: pd.DataFrame, cells: Iterable[str],
                       out_path: str, nominal_capacity: float = 1.1,
                       fraction: float = 0.80,
                       title: str = "Discharge capacity vs cycle"):
    """Plot QD_Ah vs cycle for one or more cells, with a horizontal EOL line."""
    out_path = _ensure_dir(out_path)
    fig, ax = plt.subplots(figsize=(8, 5))
    cell_list = list(cells)
    cmap = plt.get_cmap("viridis")
    for i, cell in enumerate(cell_list):
        sub = summary[summary["cell"] == cell].sort_values("cycle")
        if sub.empty:
            continue
        color = cmap(i / max(1, len(cell_list) - 1))
        ax.plot(sub["cycle"], sub["QD_Ah"], color=color,
                linewidth=1.0, alpha=0.85, label=cell)
    ax.axhline(nominal_capacity * fraction, color="red", linestyle="--",
               linewidth=1.0, label=f"{int(fraction*100)}% nominal")
    ax.set_xlabel("Cycle number")
    ax.set_ylabel("Discharge capacity (Ah)")
    ax.set_title(title)
    if len(cell_list) <= 12:
        ax.legend(loc="lower left", fontsize=7, ncol=2)
    fig.tight_layout()
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return {"path": out_path}


def plot_delta_q_curves(qdlin: pd.DataFrame, cells: Iterable[str],
                        cycle_life_lookup: dict, out_path: str,
                        early_cycle: int = 10, late_cycle: int = 100,
                        title: str = "ΔQ100-10(V) curves"):
    """Plot ΔQ_late-early(V) curve for several cells, coloured by cycle life."""
    out_path = _ensure_dir(out_path)
    cell_list = [c for c in cells if c in cycle_life_lookup]
    lives = np.array([cycle_life_lookup[c] for c in cell_list], dtype=float)
    if len(cell_list) == 0:
        raise ValueError("no plottable cells")
    log_life = np.log10(np.clip(lives, 1, None))
    norm = plt.Normalize(log_life.min(), log_life.max())
    cmap = plt.get_cmap("coolwarm_r")

    fig, ax = plt.subplots(figsize=(7, 5))
    for cell, ll in zip(cell_list, log_life):
        a = qdlin[(qdlin["cell"] == cell) & (qdlin["cycle"] == int(early_cycle))]
        b = qdlin[(qdlin["cell"] == cell) & (qdlin["cycle"] == int(late_cycle))]
        if a.empty or b.empty:
            continue
        a = a.sort_values("voltage_V")
        b = b.sort_values("voltage_V")
        if not np.allclose(a["voltage_V"].to_numpy(), b["voltage_V"].to_numpy()):
            continue
        dQ = b["Q_Ah"].to_numpy() - a["Q_Ah"].to_numpy()
        ax.plot(a["voltage_V"].to_numpy(), dQ, color=cmap(norm(ll)),
                linewidth=1.0, alpha=0.85)
    ax.set_xlabel("Voltage (V)")
    ax.set_ylabel(f"ΔQ_{int(late_cycle)}-{int(early_cycle)}(V)  (Ah)")
    ax.invert_xaxis()  # display 3.6 V -> 2.0 V left-to-right (discharge direction)
    ax.set_title(title)
    sm = plt.cm.ScalarMappable(cmap=cmap, norm=norm)
    sm.set_array([])
    cb = fig.colorbar(sm, ax=ax)
    cb.set_label("log10(cycle life)")
    fig.tight_layout()
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return {"path": out_path}


def plot_variance_vs_life(features: pd.DataFrame, out_path: str,
                          variance_col: str = "log_var_dQ",
                          life_col: str = "cycle_life",
                          title: str = "log10 Var(ΔQ100-10) vs cycle life"):
    """Scatter the log10 variance feature against cycle life on a log y-axis."""
    out_path = _ensure_dir(out_path)
    fig, ax = plt.subplots(figsize=(6, 5))
    colors = {"train": "C0", "test": "C1", "secondary_test": "C2"}
    for split, sub in features.groupby("split"):
        ax.scatter(sub[variance_col], sub[life_col],
                   color=colors.get(str(split), "grey"),
                   label=str(split), s=40, alpha=0.85, edgecolor="black")
    ax.set_yscale("log")
    ax.set_xlabel("log10 Var(ΔQ100-10(V))")
    ax.set_ylabel("Observed cycle life")
    ax.set_title(title)
    ax.legend(loc="best", fontsize=9)
    ax.grid(True, which="both", alpha=0.3)
    rho = float(np.corrcoef(features[variance_col],
                            np.log10(features[life_col]))[0, 1])
    ax.text(0.05, 0.05, f"ρ(log var, log life) = {rho:.2f}",
            transform=ax.transAxes, fontsize=10,
            bbox=dict(boxstyle="round", fc="white", alpha=0.8))
    fig.tight_layout()
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return {"path": out_path}


def plot_parity(y_true: Iterable[float], y_pred: Iterable[float],
                out_path: str, split_labels: Sequence[str] | None = None,
                title: str = "Predicted vs observed cycle life"):
    """Predicted-vs-observed scatter with the y=x identity line."""
    out_path = _ensure_dir(out_path)
    y_true = np.asarray(list(y_true), dtype=float)
    y_pred = np.asarray(list(y_pred), dtype=float)
    fig, ax = plt.subplots(figsize=(6, 6))
    if split_labels is None:
        ax.scatter(y_true, y_pred, color="C0", s=45, alpha=0.85,
                   edgecolor="black", label="cells")
    else:
        labels = np.asarray(list(split_labels))
        palette = {"train": "C0", "test": "C1", "secondary_test": "C2"}
        for sp in np.unique(labels):
            m = labels == sp
            ax.scatter(y_true[m], y_pred[m],
                       color=palette.get(str(sp), "grey"),
                       s=45, alpha=0.85, edgecolor="black", label=str(sp))
    lo = float(min(y_true.min(), y_pred.min()))
    hi = float(max(y_true.max(), y_pred.max()))
    pad = 0.1 * (hi - lo + 1.0)
    ax.plot([lo - pad, hi + pad], [lo - pad, hi + pad], "k--", linewidth=1.0,
            label="y = x")
    ax.set_xlim(lo - pad, hi + pad)
    ax.set_ylim(lo - pad, hi + pad)
    ax.set_xlabel("Observed cycle life")
    ax.set_ylabel("Predicted cycle life")
    ax.set_title(title)
    ax.legend(loc="best", fontsize=9)
    fig.tight_layout()
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return {"path": out_path}


def plot_feature_importance(importance: Sequence, out_path: str,
                            top_n: int = 12,
                            title: str = "Top elastic-net coefficients"):
    """Bar chart of the top-|coef| features.

    ``importance`` is a sequence of (name, coef) tuples (descending |coef|).
    """
    out_path = _ensure_dir(out_path)
    importance = list(importance)[:int(top_n)]
    names = [t[0] for t in importance]
    coefs = [float(t[1]) for t in importance]
    colors = ["C0" if c >= 0 else "C3" for c in coefs]

    fig, ax = plt.subplots(figsize=(8, max(3, 0.5 * len(names))))
    y = np.arange(len(names))
    ax.barh(y, coefs, color=colors, alpha=0.85, edgecolor="black")
    ax.set_yticks(y)
    ax.set_yticklabels(names)
    ax.invert_yaxis()
    ax.axvline(0, color="black", linewidth=0.5)
    ax.set_xlabel("Standardised coefficient")
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return {"path": out_path}


def plot_learning_curve(curve: dict, out_path: str,
                        title: str = "Learning curve: MAPE vs # training cells"):
    """Plot training-size vs metric mean ± std (output of evaluation.learning_curve)."""
    out_path = _ensure_dir(out_path)
    sizes = np.asarray(curve["sizes"])
    mean = np.asarray(curve["mean"])
    std = np.asarray(curve["std"])
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.errorbar(sizes, mean, yerr=std, fmt="o-", color="C0",
                ecolor="grey", capsize=3, linewidth=1.5)
    ax.set_xlabel("Number of training cells")
    ax.set_ylabel("Test MAPE (%)")
    ax.set_title(title)
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return {"path": out_path}

"""Linear regression models for cycle-life prediction.

Includes:
    OrdinaryLeastSquares      pure-numpy normal-equations regression with
                              optional ridge (L2) penalty.
    ElasticNet                coordinate-descent solver for the elastic-net
                              objective ``(1/2n)||y - Xw||^2 + lambda*((1-alpha)/2*||w||^2 + alpha*||w||_1)``.
    fit_log_cycle_life        helper that wraps a regressor to predict
                              ``log10(cycle_life)`` then exponentiates back.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable, List

import numpy as np


@dataclass
class OrdinaryLeastSquares:
    """Closed-form linear regression, optionally with ridge (L2) penalty."""
    alpha: float = 0.0
    coef_: np.ndarray = field(default_factory=lambda: np.zeros(0))
    intercept_: float = 0.0

    def fit(self, X: np.ndarray, y: np.ndarray) -> "OrdinaryLeastSquares":
        X = np.asarray(X, dtype=float)
        y = np.asarray(y, dtype=float).reshape(-1)
        n, p = X.shape
        Xb = np.hstack([np.ones((n, 1)), X])
        A = Xb.T @ Xb
        if self.alpha > 0:
            reg = float(self.alpha) * np.eye(A.shape[0])
            reg[0, 0] = 0.0
            A = A + reg
        b = Xb.T @ y
        w_full = np.linalg.solve(A, b)
        self.intercept_ = float(w_full[0])
        self.coef_ = w_full[1:]
        return self

    def predict(self, X: np.ndarray) -> np.ndarray:
        X = np.asarray(X, dtype=float)
        return X @ self.coef_ + self.intercept_


def _soft_threshold(x: float, gamma: float) -> float:
    if x > gamma:
        return x - gamma
    if x < -gamma:
        return x + gamma
    return 0.0


@dataclass
class ElasticNet:
    """Coordinate-descent elastic-net regressor.

    Objective minimised:
        (1 / (2*n)) * ||y - X w - b||^2
        + lambda_ * (alpha * ||w||_1 + 0.5 * (1 - alpha) * ||w||_2^2)

    Parameters
    ----------
    alpha : float in [0, 1]
        Mix between L1 (1.0 = lasso) and L2 (0.0 = ridge).
    lambda_ : float >= 0
        Overall regularisation strength.
    max_iter : int
        Number of full coordinate sweeps.
    tol : float
        Convergence tolerance on the maximum coefficient change per sweep.
    """
    alpha: float = 1.0
    lambda_: float = 0.01
    max_iter: int = 5000
    tol: float = 1e-6
    coef_: np.ndarray = field(default_factory=lambda: np.zeros(0))
    intercept_: float = 0.0
    n_iter_: int = 0

    def fit(self, X: np.ndarray, y: np.ndarray) -> "ElasticNet":
        X = np.asarray(X, dtype=float)
        y = np.asarray(y, dtype=float).reshape(-1)
        n, p = X.shape
        x_mean = X.mean(axis=0)
        y_mean = float(y.mean())
        Xc = X - x_mean
        yc = y - y_mean
        col_norm_sq = (Xc ** 2).sum(axis=0)
        col_norm_sq = np.where(col_norm_sq < 1e-12, 1e-12, col_norm_sq)

        w = np.zeros(p)
        l1 = float(self.lambda_) * float(self.alpha)
        l2 = float(self.lambda_) * (1.0 - float(self.alpha))
        residual = yc - Xc @ w
        for it in range(int(self.max_iter)):
            max_change = 0.0
            for j in range(p):
                rho = (Xc[:, j] @ residual) / n + (col_norm_sq[j] / n) * w[j]
                denom = (col_norm_sq[j] / n) + l2
                w_new = _soft_threshold(rho, l1) / denom
                if w_new != w[j]:
                    residual = residual + Xc[:, j] * (w[j] - w_new)
                    diff = abs(w_new - w[j])
                    if diff > max_change:
                        max_change = diff
                    w[j] = w_new
            self.n_iter_ = it + 1
            if max_change < float(self.tol):
                break
        self.coef_ = w
        self.intercept_ = float(y_mean - x_mean @ w)
        return self

    def predict(self, X: np.ndarray) -> np.ndarray:
        X = np.asarray(X, dtype=float)
        return X @ self.coef_ + self.intercept_


def fit_log_cycle_life(model, X: np.ndarray, y_cycles: np.ndarray):
    """Fit the regressor to ``log10(cycle_life)``; return a fitted-model wrapper.

    The returned object exposes ``predict(X)`` which gives cycle-life predictions
    in cycles (10**raw).
    """
    X = np.asarray(X, dtype=float)
    y = np.asarray(y_cycles, dtype=float).reshape(-1)
    log_y = np.log10(np.clip(y, 1.0, None))
    model.fit(X, log_y)

    class _LogWrapped:
        def __init__(self, m):
            self._m = m
            self.coef_ = getattr(m, "coef_", None)
            self.intercept_ = getattr(m, "intercept_", None)

        def predict(self, X_new):
            raw = self._m.predict(np.asarray(X_new, dtype=float))
            return 10.0 ** raw

        def predict_log(self, X_new):
            return self._m.predict(np.asarray(X_new, dtype=float))

    return _LogWrapped(model)


def feature_importance_from_coefficients(coef: Iterable[float],
                                         feature_names: List[str],
                                         standardised: bool = True):
    """Rank features by absolute coefficient (only meaningful for standardised inputs)."""
    coef = np.asarray(list(coef), dtype=float)
    order = np.argsort(-np.abs(coef))
    return [(feature_names[i], float(coef[i])) for i in order]

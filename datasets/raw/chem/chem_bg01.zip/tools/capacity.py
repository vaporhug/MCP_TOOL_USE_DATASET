"""Capacity-fade trajectory utilities.

Given the per-cycle ``QD_Ah`` (discharge capacity) for one cell, compute:
    - the smoothed fade curve over whichever cycles are present,
    - the cycle (within the recorded window) at which capacity drops to a
      chosen fraction of nominal, returned as an EARLY-WINDOW DIAGNOSTIC
      and explicitly NOT the same as the paper's reported cycle life,
    - the slope between two specified cycle indices.

Important: this dataset bundle only contains cycles 2..100 per cell for the
``cycle_summary.csv`` discharge trajectory. The observed cycle life
(cycles to 80 percent of nominal capacity) is provided separately as a
column in ``cell_metadata.csv`` (and joined into ``cycle_summary.csv``).
Helpers in this module that operate on the truncated QD trajectory therefore
report an *early-window* threshold-crossing cycle, which equals the maximum
recorded cycle (typically 100) for cells whose actual cycle life is hundreds
to thousands of cycles. Use the metadata ``cycle_life`` column for the true
observed EOL; the helpers below are for diagnostic / early-fade analysis.
"""
from __future__ import annotations

from typing import Iterable

import numpy as np
import pandas as pd


def cell_fade_curve(summary: pd.DataFrame, cell: str) -> pd.DataFrame:
    """Return cycle vs QD_Ah for one cell, sorted by cycle."""
    sub = summary[summary["cell"] == cell][["cycle", "QD_Ah"]].copy()
    if sub.empty:
        raise KeyError(f"no cycles for cell {cell!r}")
    sub = sub.sort_values("cycle").reset_index(drop=True)
    return sub


def smooth_fade_curve(fade: pd.DataFrame, window: int = 5) -> pd.DataFrame:
    """Return a moving-average-smoothed copy of a fade curve (cycle, QD_Ah)."""
    out = fade.copy().sort_values("cycle").reset_index(drop=True)
    out["QD_smoothed"] = out["QD_Ah"].rolling(window=int(window),
                                              center=True,
                                              min_periods=1).mean()
    return out


def early_window_threshold_crossing(fade: pd.DataFrame,
                                    nominal_capacity: float = 1.1,
                                    fraction: float = 0.80) -> int:
    """Cycle at which the smoothed capacity first drops below ``fraction*nominal``,
    within the recorded cycle window.

    For this bundle the recorded window is cycles 2..100 per cell, so this
    function returns 100 (or whatever the last recorded cycle is) for any
    cell whose true cycle life exceeds the window. It is an early-fade
    diagnostic and is NOT the observed cycle life; use the ``cycle_life``
    column of ``cell_metadata.csv`` for that.
    """
    threshold = float(nominal_capacity) * float(fraction)
    sm = smooth_fade_curve(fade)
    crossed = sm[sm["QD_smoothed"] < threshold]
    if crossed.empty:
        return int(sm["cycle"].max())
    return int(crossed["cycle"].iloc[0])


# Back-compat alias (old name) so external callers keep working; clearly
# documented as an early-window diagnostic.
cycles_to_threshold = early_window_threshold_crossing


def slope_between_cycles(fade: pd.DataFrame, cycle_start: int, cycle_end: int) -> float:
    """Return the linear-fit slope of QD_Ah between the two cycle indices (Ah/cycle)."""
    sub = fade[(fade["cycle"] >= int(cycle_start))
               & (fade["cycle"] <= int(cycle_end))]
    if len(sub) < 2:
        return float("nan")
    coef = np.polyfit(sub["cycle"].to_numpy(),
                      sub["QD_Ah"].to_numpy(), deg=1)
    return float(coef[0])


def fade_curves_for_cells(summary: pd.DataFrame, cells: Iterable[str]) -> dict:
    """Return {cell_id: DataFrame(cycle, QD_Ah)} for each cell ID."""
    return {c: cell_fade_curve(summary, c) for c in cells}


def capacity_at_cycle(summary: pd.DataFrame, cell: str, cycle: int) -> float:
    """Discharge capacity (Ah) of a specific (cell, cycle) point.

    If the exact cycle is missing the closest recorded cycle is used.
    """
    sub = summary[summary["cell"] == cell]
    if sub.empty:
        raise KeyError(f"no cycles for cell {cell!r}")
    if (sub["cycle"] == int(cycle)).any():
        return float(sub.loc[sub["cycle"] == int(cycle), "QD_Ah"].mean())
    idx = (sub["cycle"] - int(cycle)).abs().idxmin()
    return float(sub.loc[idx, "QD_Ah"])


def cycle_life_table(summary: pd.DataFrame,
                     meta: pd.DataFrame | None = None,
                     nominal_capacity: float = 1.1,
                     fraction: float = 0.80) -> pd.DataFrame:
    """Per-cell table of observed cycle life and early-window diagnostics.

    Columns returned:
      - cell
      - observed_cycle_life: the labelled cycle life from ``cell_metadata.csv``
        if ``meta`` is supplied; otherwise the last cycle present in
        ``summary`` (which for this bundle is only the early-window max,
        typically 100, and so is NOT the true cycle life).
      - early_window_threshold_crossing_cycle: the cycle at which the smoothed
        QD trajectory in ``summary`` first drops below ``fraction*nominal``;
        equal to the max recorded cycle when the threshold is never crossed.

    The two columns are intentionally separated so the early-window diagnostic
    cannot be confused with the observed cycle life.
    """
    rows = []
    if meta is not None:
        life_lookup = {str(r["cell"]): int(r["cycle_life"])
                       for _, r in meta.iterrows()}
    else:
        life_lookup = {}
    for cell, sub in summary.groupby("cell"):
        cell = str(cell)
        fade = sub[["cycle", "QD_Ah"]].sort_values("cycle").reset_index(drop=True)
        diag = early_window_threshold_crossing(fade, nominal_capacity, fraction)
        observed = life_lookup.get(cell)
        if observed is None:
            observed = int(fade["cycle"].max())
        rows.append({
            "cell": cell,
            "observed_cycle_life": int(observed),
            "early_window_threshold_crossing_cycle": int(diag),
        })
    return pd.DataFrame(rows).sort_values("cell").reset_index(drop=True)

"""Regression metrics, k-fold cross validation, learning-curve generator."""
from __future__ import annotations

from typing import Callable, Iterable, List, Sequence

import numpy as np


def rmse(y_true: Iterable[float], y_pred: Iterable[float]) -> float:
    """Root-mean-squared error in the same units as ``y_true``."""
    y = np.asarray(list(y_true), dtype=float)
    p = np.asarray(list(y_pred), dtype=float)
    return float(np.sqrt(np.mean((y - p) ** 2)))


def mape(y_true: Iterable[float], y_pred: Iterable[float]) -> float:
    """Mean absolute percentage error (in percent)."""
    y = np.asarray(list(y_true), dtype=float)
    p = np.asarray(list(y_pred), dtype=float)
    safe = np.where(np.abs(y) < 1e-12, 1e-12, y)
    return float(np.mean(np.abs(p - safe) / np.abs(safe)) * 100.0)


def mae(y_true: Iterable[float], y_pred: Iterable[float]) -> float:
    """Mean absolute error."""
    y = np.asarray(list(y_true), dtype=float)
    p = np.asarray(list(y_pred), dtype=float)
    return float(np.mean(np.abs(y - p)))


def r2_score(y_true: Iterable[float], y_pred: Iterable[float]) -> float:
    """Coefficient of determination R^2."""
    y = np.asarray(list(y_true), dtype=float)
    p = np.asarray(list(y_pred), dtype=float)
    ss_res = np.sum((y - p) ** 2)
    ss_tot = np.sum((y - np.mean(y)) ** 2)
    if ss_tot < 1e-12:
        return 0.0
    return float(1.0 - ss_res / ss_tot)


def kfold_indices(n: int, n_splits: int = 4, seed: int = 0):
    """Yield ``(train_idx, val_idx)`` integer arrays for k-fold cross validation."""
    rng = np.random.default_rng(seed)
    idx = np.arange(int(n))
    rng.shuffle(idx)
    folds = np.array_split(idx, int(n_splits))
    for k in range(int(n_splits)):
        val = folds[k]
        train = np.concatenate([folds[j] for j in range(int(n_splits)) if j != k])
        yield train, val


def cross_validate(model_factory: Callable, X: np.ndarray, y: np.ndarray,
                   metric: Callable = mape, n_splits: int = 4,
                   seed: int = 0):
    """Run k-fold CV: ``model_factory()`` should return a fresh fitted model.

    The factory is given (X_train, y_train) and must return an object with
    a ``predict(X)`` method.

    Returns dict {'fold_scores': [...], 'mean': float, 'std': float}.
    """
    X = np.asarray(X, dtype=float)
    y = np.asarray(y, dtype=float).reshape(-1)
    scores = []
    for train_idx, val_idx in kfold_indices(len(y), n_splits=n_splits, seed=seed):
        m = model_factory(X[train_idx], y[train_idx])
        pred = m.predict(X[val_idx])
        scores.append(float(metric(y[val_idx], pred)))
    return {
        "fold_scores": scores,
        "mean": float(np.mean(scores)),
        "std": float(np.std(scores)),
    }


def learning_curve(model_factory: Callable, X: np.ndarray, y: np.ndarray,
                   train_sizes: Sequence[int],
                   metric: Callable = mape, n_repeats: int = 5,
                   seed: int = 0):
    """Compute training-size vs metric (mean and std) curves on a held-out split.

    Splits 80% as the candidate pool for training and uses the remaining 20%
    as a fixed test set; for each ``size`` in ``train_sizes`` we draw
    ``n_repeats`` random subsets of that size from the pool.

    Returns dict with arrays 'sizes', 'mean', 'std'.
    """
    X = np.asarray(X, dtype=float)
    y = np.asarray(y, dtype=float).reshape(-1)
    rng = np.random.default_rng(seed)
    n = len(y)
    perm = rng.permutation(n)
    n_test = max(1, int(round(0.2 * n)))
    test_idx = perm[:n_test]
    pool_idx = perm[n_test:]

    means: List[float] = []
    stds: List[float] = []
    sizes_used: List[int] = []
    for s in train_sizes:
        s = int(s)
        s = max(2, min(s, len(pool_idx)))
        sub_scores = []
        for r in range(int(n_repeats)):
            local_rng = np.random.default_rng(seed + r * 101 + s)
            chosen = local_rng.choice(pool_idx, size=s, replace=False)
            m = model_factory(X[chosen], y[chosen])
            pred = m.predict(X[test_idx])
            sub_scores.append(float(metric(y[test_idx], pred)))
        means.append(float(np.mean(sub_scores)))
        stds.append(float(np.std(sub_scores)))
        sizes_used.append(s)
    return {"sizes": sizes_used, "mean": means, "std": stds}


def per_split_scores(y_true_train, y_pred_train, y_true_test, y_pred_test):
    """Convenience: return MAPE / RMSE on train and test arrays."""
    return {
        "train_mape": mape(y_true_train, y_pred_train),
        "train_rmse": rmse(y_true_train, y_pred_train),
        "test_mape": mape(y_true_test, y_pred_test),
        "test_rmse": rmse(y_true_test, y_pred_test),
    }


def pearson(x: Iterable[float], y: Iterable[float]) -> float:
    """Pearson correlation coefficient."""
    x = np.asarray(list(x), dtype=float)
    y = np.asarray(list(y), dtype=float)
    return float(np.corrcoef(x, y)[0, 1])

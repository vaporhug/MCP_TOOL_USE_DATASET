"""Lithium-ion battery cycling toolkit.

Submodules:
    data_io      load CSVs, split lookup, descriptor metadata.
    capacity     per-cycle discharge-capacity trajectory, EOL detection.
    featurise    early-cycle feature engineering (Q(V) variance, min, skewness, etc.).
    models       elastic-net regression implemented from scratch.
    evaluation   regression metrics, k-fold cross validation, learning-curve.
    plotting     figure helpers (capacity-vs-cycle, parity, feature distribution).
    pipeline     thin orchestration helper that chains the above.
"""
from . import data_io, capacity, featurise, models, evaluation, plotting, pipeline

__all__ = ["data_io", "capacity", "featurise", "models",
           "evaluation", "plotting", "pipeline"]

"""Tools for asymmetric-catalysis enantioselectivity prediction.

Modules
-------
* ``data_io``    — load reaction & descriptor CSVs, column lookups, name harmonisation.
* ``featurise``  — build feature matrices: substrate descriptors, catalyst descriptors,
                    Morgan-like fingerprint helpers via SMILES (rdkit hidden behind a wrapper).
* ``splits``     — stratified random and substrate-out cross-validation splits.
* ``models``     — fit Ridge / RandomForest / GradientBoosting regressors; predict.
* ``evaluation`` — regression metrics, k-fold CV, learning-curve, feature importance,
                    bootstrap confidence interval helpers.
* ``plotting``   — parity plot, residual hist, importance bar chart, ee-distribution plot,
                    per-substrate prediction strip plot, learning-curve. All return ``{"path": ...}``.
"""

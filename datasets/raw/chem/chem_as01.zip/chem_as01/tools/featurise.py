"""Feature-matrix construction for catalyst + substrate + nucleophile predictors.

Four families of features are exposed:

1. **Substrate-class one-hot** -- every reaction belongs to one of N reaction classes;
   we expose a one-hot vector. Class identity carries strong signal because the imine
   geometry (E vs Z), the nucleophile family, and the typical ddG range are all set
   by class.
2. **Catalyst-aryl Sterimol & electronic descriptors** -- for the 17 BINOL aryl groups
   the SI MOESM2 ``model_catalyst`` table provides ~33 descriptors: Sterimol L/B1/B5
   at six ring positions, NBO charges (P, six ring carbons), HOMO/LUMO,
   polarizability. We expose them as a dense block.
3. **Nucleophile descriptors** -- a 13-column block (Sterimol L/B1/B5, HOMO/LUMO,
   polarizability, X-H bond geometry, partial charges).
4. **Light SMILES-based fingerprint** -- a small Morgan-style hashed fingerprint
   for callers who want a chemistry-naive baseline. Built with rdkit *internally*;
   the agent only sees a NumPy array.

Substrate aryl groups in the reaction CSV are matched approximately to catalyst Ar
groups (when the same string occurs both as catalyst and substrate aryl) and to
nucleophile names where applicable. Resolution behaviour:

* ``catalyst_descriptor_matrix`` and ``nucleophile_descriptor_matrix`` return
  ``(matrix, descriptor_cols, detected)`` where ``detected[i] is None``
  signals that the corresponding reaction row could not be resolved to a
  named catalyst / nucleophile. The numerical row is filled with the
  column-wise dataset mean as a back-compat default, so callers MUST
  filter rows where ``detected[i] is None`` BEFORE training rather than
  treating them as zero-loss imputed observations. The task instruction
  asks for a "drop unresolvable rows" workflow on top of this primitive.

NB: this module does NOT join the ``iminiums_descriptors.csv`` or
``solvents_descriptors.csv`` tables. The bundled feature design is
**catalyst + nucleophile + reaction-class one-hot** -- imine-substrate
descriptors are documented in the bundle for completeness but the bundled
``build_feature_matrix`` treats imine identity as a reaction-class proxy.
Agents that want explicit imine NBO / Sterimol features (which the paper's
Reid & Sigman 2019 Fig 2A finds to dominate the model coefficients) must
join ``iminiums_descriptors.csv`` themselves using a clean reaction->imine
mapping; this bundle does not ship that mapping.
"""
from __future__ import annotations

from typing import List, Sequence

import numpy as np
import pandas as pd

from . import data_io as _io


# ---------------------------------------------------------------------------
# 1. Class one-hot
# ---------------------------------------------------------------------------
def class_one_hot(reactions: pd.DataFrame) -> tuple[np.ndarray, list[str]]:
    """Return ``(matrix [n_rxn, n_class], class_names)``.

    Order of classes is alphabetical so feature indices are deterministic.
    """
    classes = sorted(reactions["reaction_class"].unique().tolist())
    idx = {c: i for i, c in enumerate(classes)}
    M = np.zeros((len(reactions), len(classes)), dtype=np.float32)
    for r, c in enumerate(reactions["reaction_class"]):
        M[r, idx[c]] = 1.0
    return M, classes


# ---------------------------------------------------------------------------
# 2. Catalyst features
# ---------------------------------------------------------------------------
def _detect_catalyst_in_substrate(s: str, cat_names: list[str]) -> str | None:
    """Search the substrate-column string for a known catalyst aryl group."""
    s_low = s.lower()
    # try longest-first
    for name in sorted(cat_names, key=lambda x: -len(str(x))):
        if str(name).lower() in s_low:
            return name
    return None


def catalyst_descriptor_matrix(
    reactions: pd.DataFrame,
    cat_df: pd.DataFrame,
    descriptor_cols: Sequence[str] | None = None,
) -> tuple[np.ndarray, list[str], list[str | None]]:
    """For each reaction, return the catalyst descriptor row, the column names,
    and a parallel list of which catalyst aryl group was detected (None if missing).

    Missing rows are replaced with the dataset mean of each descriptor.
    """
    if descriptor_cols is None:
        descriptor_cols = _io.descriptor_columns(cat_df, exclude=["Ar group"])
    cat_names = cat_df["Ar group"].tolist()
    cat_index = {n.lower(): i for i, n in enumerate(cat_names)}
    means = cat_df[descriptor_cols].mean(numeric_only=True).values.astype(np.float32)
    rows = []
    detected = []
    for s in reactions["substrate_columns"]:
        hit = _detect_catalyst_in_substrate(str(s), cat_names)
        detected.append(hit)
        if hit is None:
            rows.append(means.copy())
        else:
            i = cat_index[hit.lower()]
            v = cat_df.iloc[i][list(descriptor_cols)].values.astype(np.float32)
            v = np.where(np.isfinite(v), v, means)
            rows.append(v)
    return np.asarray(rows, dtype=np.float32), list(descriptor_cols), detected


# ---------------------------------------------------------------------------
# 3. Nucleophile features
# ---------------------------------------------------------------------------
def _normalise_nu_token(s: str) -> str:
    return (
        s.strip()
        .lower()
        .replace(" ", "")
        .replace("-", "")
        .replace("(", "")
        .replace(")", "")
    )


def _detect_nucleophile_in_substrate(s: str, nu_names: list[str]) -> str | None:
    s_norm = _normalise_nu_token(s)
    # build short keys (e.g. "MeOH"->"methanol", "PhSH"->"thiolphenol")
    keymap = {
        "meoh": "methanol",
        "etoh": "ethanol",
        "iproh": "isopropanol",
        "tbuoh": "tertbutanol",
        "bnoh": "benzylalcohol",
        "phsh": "thiolphenol",
        "hcn": "hydrogencyanide",
    }
    for k, v in keymap.items():
        if k in s_norm:
            for n in nu_names:
                if _normalise_nu_token(n) == v:
                    return n
    # try literal substring match on canonical names
    for n in sorted(nu_names, key=lambda x: -len(str(x))):
        if _normalise_nu_token(n) and _normalise_nu_token(n) in s_norm:
            return n
    return None


def nucleophile_descriptor_matrix(
    reactions: pd.DataFrame,
    nu_df: pd.DataFrame,
    descriptor_cols: Sequence[str] | None = None,
) -> tuple[np.ndarray, list[str], list[str | None]]:
    if descriptor_cols is None:
        descriptor_cols = _io.descriptor_columns(nu_df, exclude=["nucleophile"])
    nu_names = nu_df["nucleophile"].tolist()
    nu_index = {n.lower(): i for i, n in enumerate(nu_names)}
    means = nu_df[descriptor_cols].mean(numeric_only=True).values.astype(np.float32)
    rows = []
    detected = []
    for s in reactions["substrate_columns"]:
        hit = _detect_nucleophile_in_substrate(str(s), nu_names)
        detected.append(hit)
        if hit is None:
            rows.append(means.copy())
        else:
            v = nu_df.iloc[nu_index[hit.lower()]][list(descriptor_cols)].values.astype(np.float32)
            v = np.where(np.isfinite(v), v, means)
            rows.append(v)
    return np.asarray(rows, dtype=np.float32), list(descriptor_cols), detected


# ---------------------------------------------------------------------------
# 4. Light Morgan fingerprint (rdkit internal)
# ---------------------------------------------------------------------------
def morgan_fp_from_text(text: str, radius: int = 2, n_bits: int = 256) -> np.ndarray:
    """Return a Morgan bit fingerprint for an arbitrary chemistry token string.

    Tries to build an rdkit molecule from the longest sub-token that parses;
    on failure returns zeros. Provided as a chemistry-naive baseline feature.
    """
    try:
        from rdkit import Chem
        from rdkit.Chem import AllChem
        from rdkit.DataStructs import ConvertToNumpyArray
    except Exception:  # rdkit missing
        return np.zeros(n_bits, dtype=np.uint8)
    # try direct parse
    mol = Chem.MolFromSmiles(text)
    if mol is None:
        # strip whitespace + try first token
        tok = text.strip().split()[0] if text.strip() else ""
        mol = Chem.MolFromSmiles(tok)
    if mol is None:
        return np.zeros(n_bits, dtype=np.uint8)
    bv = AllChem.GetMorganFingerprintAsBitVect(mol, radius=radius, nBits=n_bits)
    arr = np.zeros((n_bits,), dtype=np.uint8)
    ConvertToNumpyArray(bv, arr)
    return arr


def morgan_fp_matrix(
    smiles_list: Sequence[str], radius: int = 2, n_bits: int = 256
) -> np.ndarray:
    """Stack ``morgan_fp_from_text`` for a list of strings."""
    rows = [morgan_fp_from_text(s, radius=radius, n_bits=n_bits) for s in smiles_list]
    return np.asarray(rows, dtype=np.float32)


# ---------------------------------------------------------------------------
# Combined feature builder
# ---------------------------------------------------------------------------
def build_feature_matrix(
    reactions: pd.DataFrame,
    cat_df: pd.DataFrame,
    nu_df: pd.DataFrame,
    use_class: bool = True,
    use_catalyst: bool = True,
    use_nucleophile: bool = True,
    use_morgan: bool = False,
    morgan_bits: int = 256,
) -> tuple[np.ndarray, list[str]]:
    """Concatenate the requested feature blocks into a dense float matrix.

    Returns ``(X, feature_names)``.
    """
    blocks = []
    names: list[str] = []
    if use_class:
        M, cls = class_one_hot(reactions)
        blocks.append(M)
        names.extend([f"class:{c}" for c in cls])
    if use_catalyst:
        M, cn, _ = catalyst_descriptor_matrix(reactions, cat_df)
        blocks.append(M)
        names.extend([f"cat:{c}" for c in cn])
    if use_nucleophile:
        M, nn, _ = nucleophile_descriptor_matrix(reactions, nu_df)
        blocks.append(M)
        names.extend([f"nu:{c}" for c in nn])
    if use_morgan:
        M = morgan_fp_matrix(reactions["substrate_columns"].tolist(), n_bits=morgan_bits)
        blocks.append(M.astype(np.float32))
        names.extend([f"fp{i:03d}" for i in range(morgan_bits)])
    if not blocks:
        raise ValueError("at least one feature block must be enabled")
    X = np.concatenate([b.astype(np.float32) for b in blocks], axis=1)
    # NaN guard
    col_mean = np.nanmean(X, axis=0)
    col_mean = np.where(np.isfinite(col_mean), col_mean, 0.0)
    bad = ~np.isfinite(X)
    X = np.where(bad, np.broadcast_to(col_mean, X.shape), X)
    return X.astype(np.float32), names

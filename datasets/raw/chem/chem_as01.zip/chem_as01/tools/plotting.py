"""Plot helpers — every function returns ``{"path": "<saved-png>"}``.

Plots:
    plot_parity                — predicted vs measured DDG / ee scatter
    plot_residual_hist         — residual histogram with mean/std annotation
    plot_feature_importance    — horizontal top-K importance bar
    plot_ee_distribution       — histogram of measured ee% per class
    plot_per_class_mae         — bar of test MAE per held-out reaction class
    plot_learning_curve        — train-size vs val MAE with shaded CI
"""
from __future__ import annotations

from pathlib import Path
from typing import Sequence

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def _save(fig: plt.Figure, out_path: str | Path) -> dict[str, str]:
    p = Path(out_path)
    p.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(p, dpi=150)
    plt.close(fig)
    return {"path": str(p)}


def plot_parity(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    out_path: str = "artifacts/Fig_parity.png",
    title: str = "Predicted vs measured ΔΔG (kcal/mol)",
    xlabel: str = "measured ΔΔG (kcal/mol)",
    ylabel: str = "predicted ΔΔG (kcal/mol)",
) -> dict[str, str]:
    fig, ax = plt.subplots(figsize=(5.5, 5.5))
    ax.scatter(y_true, y_pred, alpha=0.65, s=22, color="#225ea8", edgecolor="white",
               linewidth=0.4)
    lo = float(min(np.min(y_true), np.min(y_pred)))
    hi = float(max(np.max(y_true), np.max(y_pred)))
    pad = 0.05 * (hi - lo + 1e-6)
    ax.plot([lo - pad, hi + pad], [lo - pad, hi + pad], "k--", linewidth=1)
    # annotate R^2 and MAE
    rmse = float(np.sqrt(np.mean((y_true - y_pred) ** 2)))
    mae = float(np.mean(np.abs(y_true - y_pred)))
    if np.std(y_true) > 0:
        r2 = 1.0 - np.sum((y_true - y_pred) ** 2) / np.sum(
            (y_true - np.mean(y_true)) ** 2
        )
    else:
        r2 = float("nan")
    ax.text(
        0.04, 0.94,
        f"R² = {r2:.3f}\nMAE = {mae:.3f}\nRMSE = {rmse:.3f}\nN = {len(y_true)}",
        transform=ax.transAxes, fontsize=11, va="top", ha="left",
        bbox=dict(facecolor="white", alpha=0.85, edgecolor="grey"),
    )
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.grid(alpha=0.3)
    return _save(fig, out_path)


def plot_residual_hist(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    out_path: str = "artifacts/Fig_residual_hist.png",
    title: str = "Residual distribution (predicted − measured)",
) -> dict[str, str]:
    res = np.asarray(y_pred) - np.asarray(y_true)
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.hist(res, bins=30, color="#41b6c4", edgecolor="black", linewidth=0.5)
    ax.axvline(0, color="black", linewidth=1.2, linestyle="--")
    ax.text(0.04, 0.93,
            f"mean = {res.mean():+.3f}\nstd = {res.std():.3f}\nN = {len(res)}",
            transform=ax.transAxes, fontsize=10, va="top",
            bbox=dict(facecolor="white", alpha=0.85, edgecolor="grey"))
    ax.set_xlabel("residual (kcal/mol)")
    ax.set_ylabel("count")
    ax.set_title(title)
    ax.grid(alpha=0.3)
    return _save(fig, out_path)


def plot_feature_importance(
    importance_df: pd.DataFrame,
    out_path: str = "artifacts/Fig_feature_importance.png",
    title: str = "Top features by importance",
    top_k: int = 20,
) -> dict[str, str]:
    df = importance_df.head(top_k).iloc[::-1]
    fig, ax = plt.subplots(figsize=(7, max(4, 0.32 * len(df))))
    ax.barh(df["feature"], df["importance"], color="#fc8d59")
    ax.set_xlabel("importance")
    ax.set_title(title)
    ax.grid(axis="x", alpha=0.3)
    return _save(fig, out_path)


def plot_ee_distribution(
    reactions: pd.DataFrame,
    out_path: str = "artifacts/Fig_ee_distribution.png",
    title: str = "Distribution of ee (%) by reaction class",
    max_classes: int = 12,
) -> dict[str, str]:
    classes = (
        reactions.groupby("reaction_class")["ee_pct"].count().sort_values(ascending=False)
    )
    keep = classes.index[:max_classes]
    sub = reactions[reactions["reaction_class"].isin(keep)]
    fig, ax = plt.subplots(figsize=(8, 5))
    data = [sub.loc[sub["reaction_class"] == c, "ee_pct"].values for c in keep]
    bp = ax.boxplot(
        data, labels=[c[:30] for c in keep], vert=True, patch_artist=True
    )
    for patch in bp["boxes"]:
        patch.set_facecolor("#abd9e9")
    ax.set_ylabel("ee (%)")
    ax.set_title(title)
    plt.setp(ax.get_xticklabels(), rotation=45, ha="right")
    ax.grid(axis="y", alpha=0.3)
    return _save(fig, out_path)


def plot_per_class_mae(
    per_class_df: pd.DataFrame,
    out_path: str = "artifacts/Fig_per_class_mae.png",
    title: str = "MAE by held-out reaction class (substrate-out CV)",
) -> dict[str, str]:
    df = per_class_df.sort_values("MAE", ascending=True)
    fig, ax = plt.subplots(figsize=(7, max(4, 0.34 * len(df))))
    ax.barh(df["reaction_class"], df["MAE"], color="#74add1")
    for i, (_, row) in enumerate(df.iterrows()):
        ax.text(row["MAE"] + 0.02, i, f"n={int(row['n'])}", va="center", fontsize=8)
    ax.set_xlabel("MAE (kcal/mol)")
    ax.set_title(title)
    ax.grid(axis="x", alpha=0.3)
    return _save(fig, out_path)


def plot_learning_curve(
    lc_df: pd.DataFrame,
    out_path: str = "artifacts/Fig_learning_curve.png",
    title: str = "Learning curve",
    metric: str = "MAE",
) -> dict[str, str]:
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.plot(lc_df["n_train"], lc_df[metric], "o-", color="#d7191c")
    ax.set_xlabel("training set size")
    ax.set_ylabel(metric)
    ax.set_title(title)
    ax.grid(alpha=0.3)
    return _save(fig, out_path)


def plot_predicted_vs_measured_by_class(
    reactions: pd.DataFrame,
    y_true: np.ndarray,
    y_pred: np.ndarray,
    out_path: str = "artifacts/Fig_pred_by_class.png",
    title: str = "Predicted ΔΔG by reaction class",
    max_classes: int = 12,
) -> dict[str, str]:
    classes = (
        reactions.groupby("reaction_class")["ee_pct"].count().sort_values(ascending=False)
    )
    keep = classes.index[:max_classes]
    fig, ax = plt.subplots(figsize=(8, 5))
    for i, c in enumerate(keep):
        mask = (reactions["reaction_class"].values == c)
        ax.scatter(
            np.full(mask.sum(), i),
            np.asarray(y_true)[mask],
            color="#999", s=20, alpha=0.55, label=("measured" if i == 0 else None),
        )
        ax.scatter(
            np.full(mask.sum(), i) + 0.25,
            np.asarray(y_pred)[mask],
            color="#d73027", s=20, alpha=0.65, marker="x",
            label=("predicted" if i == 0 else None),
        )
    ax.set_xticks(range(len(keep)))
    ax.set_xticklabels([c[:25] for c in keep], rotation=45, ha="right")
    ax.set_ylabel("ΔΔG (kcal/mol)")
    ax.set_title(title)
    ax.legend(loc="best", fontsize=9)
    ax.grid(axis="y", alpha=0.3)
    return _save(fig, out_path)

"""Regression model wrappers — Ridge / RandomForest / GradientBoosting.

The agent never imports ``sklearn`` directly; it goes through these wrappers,
which return a plain ``dict`` carrying the trained estimator and the predicted
features importance.

All wrappers expose a uniform ``predict()`` and accept a feature matrix and
target vector.
"""
from __future__ import annotations

from typing import Any

import numpy as np
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.linear_model import Ridge


def fit_ridge(X: np.ndarray, y: np.ndarray, alpha: float = 1.0) -> dict[str, Any]:
    """Fit an L2-penalised linear regressor (Ridge)."""
    m = Ridge(alpha=alpha)
    m.fit(X, y)
    return {
        "kind": "ridge",
        "model": m,
        "y_mean": float(np.mean(y)),
        "y_std": float(np.std(y) if np.std(y) > 0 else 1.0),
        "coef": np.asarray(m.coef_, dtype=float),
        "intercept": float(m.intercept_),
        "feature_importances": np.abs(m.coef_).astype(float),
    }


def fit_random_forest(
    X: np.ndarray,
    y: np.ndarray,
    n_estimators: int = 300,
    max_depth: int | None = None,
    min_samples_leaf: int = 2,
    seed: int = 42,
) -> dict[str, Any]:
    """Fit a Random Forest regressor."""
    m = RandomForestRegressor(
        n_estimators=n_estimators,
        max_depth=max_depth,
        min_samples_leaf=min_samples_leaf,
        random_state=seed,
        n_jobs=-1,
    )
    m.fit(X, y)
    return {
        "kind": "random_forest",
        "model": m,
        "y_mean": float(np.mean(y)),
        "y_std": float(np.std(y) if np.std(y) > 0 else 1.0),
        "feature_importances": m.feature_importances_.astype(float),
    }


def fit_gradient_boosting(
    X: np.ndarray,
    y: np.ndarray,
    n_estimators: int = 400,
    max_depth: int = 3,
    learning_rate: float = 0.05,
    seed: int = 42,
) -> dict[str, Any]:
    """Fit a Gradient Boosted Trees regressor."""
    m = GradientBoostingRegressor(
        n_estimators=n_estimators,
        max_depth=max_depth,
        learning_rate=learning_rate,
        random_state=seed,
    )
    m.fit(X, y)
    return {
        "kind": "gradient_boosting",
        "model": m,
        "y_mean": float(np.mean(y)),
        "y_std": float(np.std(y) if np.std(y) > 0 else 1.0),
        "feature_importances": m.feature_importances_.astype(float),
    }


def predict(model_dict: dict[str, Any], X: np.ndarray) -> np.ndarray:
    """Generic predict that dispatches on ``model`` of the wrapper dict."""
    return np.asarray(model_dict["model"].predict(X), dtype=float)


def predict_forest_uncertainty(
    model_dict: dict[str, Any], X: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    """Per-sample (mean, std) for Random Forest dicts. Std is zero for non-forest."""
    if model_dict["kind"] != "random_forest":
        p = predict(model_dict, X)
        return p, np.zeros_like(p)
    rf = model_dict["model"]
    preds = np.stack([t.predict(X) for t in rf.estimators_], axis=0)
    return preds.mean(axis=0), preds.std(axis=0)

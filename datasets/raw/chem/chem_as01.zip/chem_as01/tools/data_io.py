"""Data loading and look-up helpers for the asymmetric-catalysis dataset.

The dataset has four CSVs (and one xlsx mirror):
    reactions_ee.csv         — reaction-level rows: class, substrate column string,
                                ee%, ddG (kcal/mol).
    catalysts_descriptors.csv — DFT-derived descriptors for 17 BINOL phosphoric-acid
                                aryl groups (Sterimol, NBO charges, HOMO/LUMO,
                                polarizability, vibrational features).
    nucleophiles_descriptors.csv — DFT descriptors for 54 nucleophiles (Sterimol L/B1/B5,
                                HOMO/LUMO, polarizability, charges, X-H bond geometry).
    iminiums_descriptors.csv — DFT descriptors for 360 (E)/(Z)-iminium structures
                                (substrate sterics, protecting-group sterics, electronic).
    solvents_descriptors.csv — 12 solvents with topological + polarity descriptors.

This module provides loaders + light look-up helpers; the ML pipeline lives elsewhere.
No model training, no plotting.
"""
from __future__ import annotations

from pathlib import Path
from typing import Iterable, List

import numpy as np
import pandas as pd


def _resolve(path: str | Path) -> Path:
    p = Path(path)
    if p.exists():
        return p
    # try resolving relative to this file
    here = Path(__file__).resolve().parent.parent
    cand = here / path
    if cand.exists():
        return cand
    raise FileNotFoundError(f"could not locate {path}")


def load_reactions(path: str = "input_data/data/reactions_ee.csv") -> pd.DataFrame:
    """Load the reaction-level table (class, substrate, ee%, ddG)."""
    df = pd.read_csv(_resolve(path))
    # Normalise types
    df["ee_pct"] = pd.to_numeric(df["ee_pct"], errors="coerce")
    df["ddG_kcal_mol"] = pd.to_numeric(df["ddG_kcal_mol"], errors="coerce")
    df["reaction_class"] = df["reaction_class"].astype(str)
    df["substrate_columns"] = df["substrate_columns"].astype(str)
    return df


def load_catalyst_descriptors(
    path: str = "input_data/data/catalysts_descriptors.csv",
) -> pd.DataFrame:
    """Return the 17-row catalyst descriptor table indexed by Ar group name."""
    df = pd.read_csv(_resolve(path))
    df["Ar group"] = df["Ar group"].astype(str)
    return df


def load_nucleophile_descriptors(
    path: str = "input_data/data/nucleophiles_descriptors.csv",
) -> pd.DataFrame:
    df = pd.read_csv(_resolve(path))
    df["nucleophile"] = df["nucleophile"].astype(str)
    return df


def load_iminium_descriptors(
    path: str = "input_data/data/iminiums_descriptors.csv",
) -> pd.DataFrame:
    df = pd.read_csv(_resolve(path))
    df["imine"] = df["imine"].astype(str)
    return df


def load_solvent_descriptors(
    path: str = "input_data/data/solvents_descriptors.csv",
) -> pd.DataFrame:
    df = pd.read_csv(_resolve(path))
    df["solvent"] = df["solvent"].astype(str)
    return df


def list_reaction_classes(reactions: pd.DataFrame) -> List[str]:
    """Distinct reaction-class labels present in the dataset."""
    return sorted(reactions["reaction_class"].unique().tolist())


def filter_by_class(reactions: pd.DataFrame, classes: Iterable[str]) -> pd.DataFrame:
    """Return only the rows whose ``reaction_class`` is in ``classes``."""
    return reactions[reactions["reaction_class"].isin(list(classes))].reset_index(drop=True)


def descriptor_columns(df: pd.DataFrame, exclude: Iterable[str] = ()) -> List[str]:
    """List numeric descriptor columns of a descriptor table, excluding name columns."""
    excl = set(exclude)
    cols = []
    for c in df.columns:
        if c in excl:
            continue
        if pd.api.types.is_numeric_dtype(df[c]):
            cols.append(c)
    return cols


def lookup_catalyst(name: str, cat_df: pd.DataFrame) -> pd.Series:
    """Fetch the descriptor row for a catalyst Ar-group string.

    Performs a case-insensitive match on the ``Ar group`` column.
    """
    target = name.strip().lower()
    for _, row in cat_df.iterrows():
        if str(row["Ar group"]).strip().lower() == target:
            return row
    raise KeyError(f"catalyst Ar group not found: {name!r}")


def lookup_nucleophile(name: str, nu_df: pd.DataFrame) -> pd.Series:
    target = name.strip().lower()
    for _, row in nu_df.iterrows():
        if str(row["nucleophile"]).strip().lower() == target:
            return row
    raise KeyError(f"nucleophile not found: {name!r}")


def reaction_ee_summary(reactions: pd.DataFrame) -> pd.DataFrame:
    """Per-class summary of ee% and DDG (count, mean, min, max)."""
    g = reactions.groupby("reaction_class")
    out = pd.DataFrame({
        "n_rxn": g.size(),
        "ee_mean": g["ee_pct"].mean(),
        "ee_min": g["ee_pct"].min(),
        "ee_max": g["ee_pct"].max(),
        "ddG_mean": g["ddG_kcal_mol"].mean(),
    }).reset_index()
    return out

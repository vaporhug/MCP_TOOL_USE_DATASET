"""Regression evaluation, cross-validation, learning curves, importance ranking.

All metrics work in either the ee% or DDG (kcal/mol) target space; the caller
picks which. ``cross_validate`` runs a fit-predict over a list of folds and
reports per-fold metrics.
"""
from __future__ import annotations

from typing import Any, Callable, Iterable, Sequence

import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from scipy.stats import pearsonr, spearmanr


def regression_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict[str, float]:
    """Compute R^2, RMSE, MAE, Pearson r, Spearman rho on a (y_true, y_pred) pair."""
    yt = np.asarray(y_true, dtype=float)
    yp = np.asarray(y_pred, dtype=float)
    rmse = float(np.sqrt(mean_squared_error(yt, yp)))
    mae = float(mean_absolute_error(yt, yp))
    r2 = float(r2_score(yt, yp))
    if len(yt) >= 3 and np.std(yt) > 0 and np.std(yp) > 0:
        pr = float(pearsonr(yt, yp)[0])
        sr = float(spearmanr(yt, yp).statistic)
    else:
        pr = float("nan")
        sr = float("nan")
    return {"R2": r2, "RMSE": rmse, "MAE": mae, "Pearson_r": pr, "Spearman_rho": sr,
            "n": len(yt)}


def cross_validate(
    X: np.ndarray,
    y: np.ndarray,
    fit_fn: Callable[[np.ndarray, np.ndarray], dict[str, Any]],
    predict_fn: Callable[[dict[str, Any], np.ndarray], np.ndarray],
    folds: Iterable[tuple[np.ndarray, np.ndarray]],
) -> pd.DataFrame:
    """Run K-fold CV. Each fold is a ``(train_idx, val_idx)`` tuple."""
    rows = []
    for k, fold in enumerate(folds):
        tr, va = fold[0], fold[1]
        m = fit_fn(X[tr], y[tr])
        yhat = predict_fn(m, X[va])
        scores = regression_metrics(y[va], yhat)
        scores["fold"] = k
        scores["n_train"] = len(tr)
        scores["n_val"] = len(va)
        rows.append(scores)
    return pd.DataFrame(rows)


def aggregate_cv(metrics_df: pd.DataFrame) -> dict[str, float]:
    """Mean +/- std summary over folds."""
    out: dict[str, float] = {}
    for k in ("R2", "RMSE", "MAE", "Pearson_r", "Spearman_rho"):
        if k in metrics_df.columns:
            out[f"{k}_mean"] = float(metrics_df[k].mean())
            out[f"{k}_std"] = float(metrics_df[k].std())
    return out


def learning_curve(
    X: np.ndarray,
    y: np.ndarray,
    fit_fn: Callable[[np.ndarray, np.ndarray], dict[str, Any]],
    predict_fn: Callable[[dict[str, Any], np.ndarray], np.ndarray],
    train_idx: np.ndarray,
    val_idx: np.ndarray,
    fractions: Sequence[float] = (0.1, 0.2, 0.4, 0.6, 0.8, 1.0),
    seed: int = 0,
) -> pd.DataFrame:
    """Train on increasing fractions of the train set and report val MAE/R^2."""
    rng = np.random.default_rng(seed)
    n = len(train_idx)
    rows = []
    for frac in fractions:
        n_use = max(5, int(n * frac))
        sub = rng.choice(train_idx, n_use, replace=False)
        m = fit_fn(X[sub], y[sub])
        yhat = predict_fn(m, X[val_idx])
        sc = regression_metrics(y[val_idx], yhat)
        sc["fraction"] = float(frac)
        sc["n_train"] = int(n_use)
        rows.append(sc)
    return pd.DataFrame(rows)


def rank_features(
    model_dict: dict[str, Any], feature_names: Sequence[str], top_k: int = 25
) -> pd.DataFrame:
    """Top-K features by ``feature_importances`` (any model wrapper)."""
    imp = np.asarray(model_dict["feature_importances"], dtype=float)
    order = np.argsort(-np.abs(imp))[:top_k]
    return pd.DataFrame(
        {"rank": np.arange(1, len(order) + 1),
         "feature": [feature_names[i] for i in order],
         "importance": imp[order]}
    ).reset_index(drop=True)


def per_class_metrics(
    reactions: pd.DataFrame,
    y_true: np.ndarray,
    y_pred: np.ndarray,
) -> pd.DataFrame:
    """MAE / R^2 broken down by reaction class on a held-out prediction array."""
    out = []
    yt = np.asarray(y_true)
    yp = np.asarray(y_pred)
    for c in sorted(reactions["reaction_class"].unique()):
        mask = (reactions["reaction_class"].values == c)
        if mask.sum() < 2:
            continue
        sc = regression_metrics(yt[mask], yp[mask])
        sc["reaction_class"] = c
        sc["n"] = int(mask.sum())
        out.append(sc)
    return pd.DataFrame(out)


def bootstrap_metric(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    metric: str = "MAE",
    n_boot: int = 500,
    seed: int = 0,
) -> tuple[float, float, float]:
    """Bootstrap (mean, ci_low, ci_high) of a regression metric."""
    rng = np.random.default_rng(seed)
    n = len(y_true)
    vals = []
    for _ in range(n_boot):
        idx = rng.integers(0, n, n)
        s = regression_metrics(y_true[idx], y_pred[idx])
        vals.append(s[metric])
    arr = np.asarray(vals, dtype=float)
    return float(arr.mean()), float(np.quantile(arr, 0.025)), float(np.quantile(arr, 0.975))

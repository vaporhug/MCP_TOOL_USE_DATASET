"""Train/test splitting utilities — random K-fold and substrate-class-out CV.

Substrate-class-out CV holds one reaction class entirely out of training; the
test set is then composed of all rows of that class. This is a stronger
generalisation test than random K-fold because the model must extrapolate to
a substrate scope it has never seen.
"""
from __future__ import annotations

from typing import Iterable

import numpy as np
import pandas as pd


def random_kfold(n_rows: int, k: int = 5, seed: int = 0) -> list[tuple[np.ndarray, np.ndarray]]:
    """Return ``k`` ``(train_idx, val_idx)`` index pairs over ``n_rows``."""
    rng = np.random.default_rng(seed)
    idx = np.arange(n_rows)
    rng.shuffle(idx)
    folds = np.array_split(idx, k)
    out = []
    for i in range(k):
        val = folds[i]
        train = np.concatenate([folds[j] for j in range(k) if j != i])
        out.append((train, val))
    return out


def class_out_folds(
    reactions: pd.DataFrame, classes: Iterable[str] | None = None
) -> list[tuple[np.ndarray, np.ndarray, str]]:
    """Leave-one-class-out folds.

    Returns a list of ``(train_idx, val_idx, held_out_class)``. If ``classes``
    is None all unique reaction classes in the table are used.
    """
    if classes is None:
        classes = sorted(reactions["reaction_class"].unique().tolist())
    rxn_class = reactions["reaction_class"].values
    n = len(reactions)
    out = []
    for c in classes:
        val = np.where(rxn_class == c)[0]
        train = np.where(rxn_class != c)[0]
        if len(val) == 0 or len(train) == 0:
            continue
        out.append((train, val, c))
    return out


def stratified_holdout(
    reactions: pd.DataFrame, frac: float = 0.2, seed: int = 0
) -> tuple[np.ndarray, np.ndarray]:
    """Stratified holdout over ``reaction_class``: keep ``frac`` of each class as test."""
    rng = np.random.default_rng(seed)
    test_idx = []
    for c in reactions["reaction_class"].unique():
        rows = np.where(reactions["reaction_class"].values == c)[0]
        rng.shuffle(rows)
        n_test = max(1, int(round(len(rows) * frac)))
        test_idx.extend(rows[:n_test].tolist())
    test_idx = np.array(sorted(test_idx))
    train_idx = np.setdiff1d(np.arange(len(reactions)), test_idx)
    return train_idx, test_idx

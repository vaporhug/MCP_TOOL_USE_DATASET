"""Plotting helpers — every function returns ``{"path": <png_file>}``.

Exposed functions:
    plot_label_frequency_histogram
    plot_top_k_accuracy_bars
    plot_confusion_heatmap
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Sequence

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def _ensure_parent(path: str) -> Path:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


def plot_label_frequency_histogram(
    vocab_table: pd.DataFrame,
    output_path: str,
    top_n: int = 15,
    title: str = "Label frequency",
) -> Dict[str, str]:
    """Bar chart of the top-N labels in a vocabulary frequency table.

    ``vocab_table`` must have columns ``canonical_smiles`` and ``count``.
    """
    p = _ensure_parent(output_path)
    head = vocab_table.head(top_n)
    fig, ax = plt.subplots(figsize=(9, 4.5))
    ax.bar(range(len(head)), head["count"].to_numpy(), color="#3a6ea5")
    ax.set_xticks(range(len(head)))
    short_labels = [str(s)[:18] + ("…" if len(str(s)) > 18 else "") for s in head["canonical_smiles"]]
    ax.set_xticklabels(short_labels, rotation=60, ha="right", fontsize=8)
    ax.set_ylabel("Reaction count")
    ax.set_title(title)
    ax.grid(axis="y", linestyle=":", alpha=0.5)
    fig.tight_layout()
    fig.savefig(p, dpi=140)
    plt.close(fig)
    return {"path": str(p)}


def plot_top_k_accuracy_bars(
    accuracy_table: Dict[str, Dict[int, float]],
    output_path: str,
    baseline_table: Dict[str, Dict[int, float]] | None = None,
    title: str = "Top-k accuracy by slot",
) -> Dict[str, str]:
    """Grouped bar chart: x = slots, bars = k values; optional baseline overlay."""
    p = _ensure_parent(output_path)
    slots = list(accuracy_table.keys())
    if not slots:
        raise ValueError("empty accuracy_table")
    ks = sorted({int(k) for ks_dict in accuracy_table.values() for k in ks_dict.keys()})

    n_slots = len(slots)
    n_k = len(ks)
    width = 0.8 / max(n_k, 1)
    x = np.arange(n_slots)

    fig, ax = plt.subplots(figsize=(8, 5))
    cmap = plt.get_cmap("viridis")
    for i, k in enumerate(ks):
        vals = [accuracy_table[s].get(k, 0.0) for s in slots]
        ax.bar(x + i * width - 0.4 + width / 2, vals, width=width,
               label=f"top-{k}", color=cmap(i / max(n_k - 1, 1)))
    if baseline_table is not None:
        bvals = [baseline_table.get(s, {}).get(ks[-1], 0.0) for s in slots]
        ax.scatter(x, bvals, marker="x", color="black",
                   s=70, label=f"baseline top-{ks[-1]}", zorder=5)
    ax.set_xticks(x)
    ax.set_xticklabels(slots, rotation=15, ha="right")
    ax.set_ylabel("Accuracy")
    ax.set_ylim(0, 1.0)
    ax.set_title(title)
    ax.legend(loc="upper right", fontsize=9)
    ax.grid(axis="y", linestyle=":", alpha=0.5)
    fig.tight_layout()
    fig.savefig(p, dpi=140)
    plt.close(fig)
    return {"path": str(p)}


def plot_confusion_heatmap(
    matrix: np.ndarray,
    class_labels: Sequence[str],
    output_path: str,
    title: str = "Confusion matrix",
    normalise: bool = True,
) -> Dict[str, str]:
    """Heatmap of a confusion matrix with class-name annotations."""
    p = _ensure_parent(output_path)
    M = np.asarray(matrix, dtype=float)
    if normalise:
        row_sums = M.sum(axis=1, keepdims=True)
        row_sums[row_sums == 0] = 1.0
        M = M / row_sums
    fig, ax = plt.subplots(figsize=(7.0, 6.0))
    im = ax.imshow(M, cmap="magma", aspect="auto", vmin=0, vmax=1 if normalise else None)
    ax.set_xticks(range(len(class_labels)))
    ax.set_yticks(range(len(class_labels)))
    short = [str(s)[:14] + ("…" if len(str(s)) > 14 else "") for s in class_labels]
    ax.set_xticklabels(short, rotation=60, ha="right", fontsize=8)
    ax.set_yticklabels(short, fontsize=8)
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Truth")
    ax.set_title(title)
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    fig.tight_layout()
    fig.savefig(p, dpi=140)
    plt.close(fig)
    return {"path": str(p)}

"""Reaction-condition recommendation tools (chem_rc01).

Modules:
    data_io       — reaction-record + label-vocabulary loaders
    featurise     — Morgan/difference reaction fingerprints, label encoding
    models        — multi-output classifier wrappers (RF / LR / GB)
    evaluation    — top-k accuracy, per-slot accuracy, confusion analysis
    plotting      — top-k bar, vocabulary histograms, confusion heatmap
    pipeline      — end-to-end driver chaining the above
"""

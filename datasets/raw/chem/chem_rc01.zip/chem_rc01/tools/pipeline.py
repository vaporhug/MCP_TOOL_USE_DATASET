"""End-to-end pipeline driver for chem_rc01.

Exposed functions:
    run_condition_recommendation_pipeline
    summarise_pipeline_results
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Sequence

import numpy as np
import pandas as pd

from .data_io import (
    LABEL_SLOTS,
    filter_complete_reactions,
    load_label_vocabulary,
    load_reaction_records,
    train_test_split_reactions,
)
from .evaluation import (
    average_improvement_over_baseline,
    combined_top_k_exact_match,
    confusion_topk_matrix,
    per_slot_top_k,
    top_k_accuracy,
)
from .featurise import (
    build_reaction_fingerprint_matrix,
    encode_labels,
    fit_label_encoder,
)
from .models import (
    fit_multi_output_classifier,
    most_frequent_baseline,
    predict_multi_output,
)


def run_condition_recommendation_pipeline(
    data_path: str = "input_data/data/orderly_condition_sample.csv",
    n_train: int = 4000,
    n_test: int = 1500,
    n_bits: int = 1024,
    fp_mode: str = "concat",
    estimator: str = "random_forest",
    min_label_count: int = 5,
    seed: int = 42,
    slot_order: Sequence[str] = LABEL_SLOTS,
    ks: Sequence[int] = (1, 3, 5, 10),
    estimator_kwargs: Dict[str, Any] | None = None,
) -> Dict[str, Any]:
    """Train per-slot classifiers on reaction fingerprints and evaluate top-k accuracy.

    Returns a dict with per-slot top-k, per-slot baseline top-k, AIB, and combined
    top-3 exact-match accuracy across the requested slot order.
    """
    estimator_kwargs = estimator_kwargs or {}
    records = load_reaction_records(data_path)
    records = filter_complete_reactions(records, require_solvent=True)

    train, test = train_test_split_reactions(records, test_fraction=0.25, seed=seed)
    if n_train and len(train) > n_train:
        train = train.iloc[:n_train].reset_index(drop=True)
    if n_test and len(test) > n_test:
        test = test.iloc[:n_test].reset_index(drop=True)

    X_train = build_reaction_fingerprint_matrix(train, n_bits=n_bits, mode=fp_mode)
    X_test = build_reaction_fingerprint_matrix(test, n_bits=n_bits, mode=fp_mode)

    encoders: Dict[str, Dict[str, Any]] = {}
    y_train_per_slot: Dict[str, np.ndarray] = {}
    y_test_per_slot: Dict[str, np.ndarray] = {}
    for slot in slot_order:
        enc = fit_label_encoder(train[slot], min_count=min_label_count)
        encoders[slot] = enc
        y_train_per_slot[slot] = encode_labels(train[slot], enc)
        y_test_per_slot[slot] = encode_labels(test[slot], enc)

    models = fit_multi_output_classifier(
        X_train, y_train_per_slot, estimator=estimator, **estimator_kwargs
    )

    proba = predict_multi_output(models, X_test)

    # Build baseline probability vectors
    baseline_proba: Dict[str, np.ndarray] = {}
    for slot in slot_order:
        n_classes = len(encoders[slot]["vocab"])
        prior = most_frequent_baseline(y_train_per_slot[slot], n_classes)
        baseline_proba[slot] = np.tile(prior, (X_test.shape[0], 1))

    model_topk = per_slot_top_k(y_test_per_slot, proba, ks=ks)
    baseline_topk = per_slot_top_k(y_test_per_slot, baseline_proba, ks=ks)
    aib = average_improvement_over_baseline(model_topk, baseline_topk)

    combined_top3_model = combined_top_k_exact_match(
        y_test_per_slot, proba, slot_order=slot_order, k=3
    )
    combined_top3_base = combined_top_k_exact_match(
        y_test_per_slot, baseline_proba, slot_order=slot_order, k=3
    )

    return {
        "n_train": int(len(train)),
        "n_test": int(len(test)),
        "feature_dim": int(X_train.shape[1]),
        "encoders": {s: {"n_classes": len(e["vocab"])} for s, e in encoders.items()},
        "model_topk": model_topk,
        "baseline_topk": baseline_topk,
        "aib": aib,
        "combined_top3_model": combined_top3_model,
        "combined_top3_baseline": combined_top3_base,
        "estimator": estimator,
        "fp_mode": fp_mode,
        "n_bits": int(n_bits),
        # Caches needed by the plotting and summary helpers
        "_proba": proba,
        "_y_test_per_slot": y_test_per_slot,
        "_encoders": encoders,
    }


def summarise_pipeline_results(
    results: Dict[str, Any],
    output_json: str | None = None,
) -> Dict[str, Any]:
    """Strip in-memory caches and write a JSON summary if a path is given."""
    summary = {k: v for k, v in results.items() if not k.startswith("_")}
    if output_json:
        p = Path(output_json)
        p.parent.mkdir(parents=True, exist_ok=True)
        with p.open("w") as f:
            json.dump(summary, f, indent=2, default=str)
    return summary

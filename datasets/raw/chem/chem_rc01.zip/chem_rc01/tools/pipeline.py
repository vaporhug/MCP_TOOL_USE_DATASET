"""End-to-end pipeline driver for chem_rc01.

Exposed functions:
    run_condition_recommendation_pipeline
    summarise_pipeline_results
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Sequence

import numpy as np
import pandas as pd

from .data_io import (
    LABEL_SLOTS,
    filter_complete_reactions,
    load_label_vocabulary,
    load_reaction_records,
    train_test_split_reactions,
)
from .evaluation import (
    absolute_improvement_over_baseline,
    paper_aib_over_baseline,
    combined_top_k_exact_match,
    confusion_topk_matrix,
    per_slot_top_k,
    top_k_accuracy,
)
from .featurise import (
    build_reaction_fingerprint_matrix,
    encode_labels,
    fit_label_encoder,
)
from .models import (
    fit_multi_output_classifier,
    most_frequent_baseline,
    predict_multi_output,
)


def run_condition_recommendation_pipeline(
    data_path: str,
    n_train: int,
    n_test: int,
    n_bits: int,
    fp_mode: str,
    estimator: str,
    min_label_count: int,
    seed: int,
    slot_order: Sequence[str],
    ks: Sequence[int],
    estimator_kwargs: Dict[str, Any] | None = None,
) -> Dict[str, Any]:
    """Optional thin driver that chains the composable primitives below.

    This helper is provided for maintainer convenience only. It has no defaults,
    so the caller is responsible for choosing every hyperparameter (fingerprint
    width, fingerprint mode, train/test budgets, estimator, slot order, ks, etc.).
    The intended way to solve the task is to call the underlying primitives in
    ``tools/data_io.py``, ``tools/featurise.py``, ``tools/models.py`` and
    ``tools/evaluation.py`` directly and to make those hyperparameter choices in
    the agent's own plan.
    """
    estimator_kwargs = estimator_kwargs or {}
    records = load_reaction_records(data_path)
    records = filter_complete_reactions(records, require_solvent=True)

    train, test = train_test_split_reactions(records, test_fraction=0.25, seed=seed)
    if n_train and len(train) > n_train:
        train = train.iloc[:n_train].reset_index(drop=True)
    if n_test and len(test) > n_test:
        test = test.iloc[:n_test].reset_index(drop=True)

    X_train = build_reaction_fingerprint_matrix(train, n_bits=n_bits, mode=fp_mode)
    X_test = build_reaction_fingerprint_matrix(test, n_bits=n_bits, mode=fp_mode)

    encoders: Dict[str, Dict[str, Any]] = {}
    y_train_per_slot: Dict[str, np.ndarray] = {}
    y_test_per_slot: Dict[str, np.ndarray] = {}
    for slot in slot_order:
        enc = fit_label_encoder(train[slot], min_count=min_label_count)
        encoders[slot] = enc
        y_train_per_slot[slot] = encode_labels(train[slot], enc)
        y_test_per_slot[slot] = encode_labels(test[slot], enc)

    models = fit_multi_output_classifier(
        X_train, y_train_per_slot, estimator=estimator, **estimator_kwargs
    )

    proba = predict_multi_output(models, X_test)

    # Build baseline probability vectors
    baseline_proba: Dict[str, np.ndarray] = {}
    for slot in slot_order:
        n_classes = len(encoders[slot]["vocab"])
        prior = most_frequent_baseline(y_train_per_slot[slot], n_classes)
        baseline_proba[slot] = np.tile(prior, (X_test.shape[0], 1))

    model_topk = per_slot_top_k(y_test_per_slot, proba, ks=ks)
    baseline_topk = per_slot_top_k(y_test_per_slot, baseline_proba, ks=ks)
    absolute_improvement = absolute_improvement_over_baseline(model_topk, baseline_topk)
    aib = paper_aib_over_baseline(model_topk, baseline_topk)  # paper's AIB = (m-b)/(1-b)

    combined_top3_model = combined_top_k_exact_match(
        y_test_per_slot, proba, slot_order=slot_order, k=3
    )
    combined_top3_base = combined_top_k_exact_match(
        y_test_per_slot, baseline_proba, slot_order=slot_order, k=3
    )

    return {
        "n_train": int(len(train)),
        "n_test": int(len(test)),
        "feature_dim": int(X_train.shape[1]),
        "encoders": {s: {"n_classes": len(e["vocab"])} for s, e in encoders.items()},
        "model_topk": model_topk,
        "baseline_topk": baseline_topk,
        "absolute_improvement": absolute_improvement,
        "aib": aib,  # paper-style AIB = (model - baseline) / (1 - baseline)
        "combined_top3_model": combined_top3_model,
        "combined_top3_baseline": combined_top3_base,
        "estimator": estimator,
        "fp_mode": fp_mode,
        "n_bits": int(n_bits),
        # Caches needed by the plotting and summary helpers
        "_proba": proba,
        "_y_test_per_slot": y_test_per_slot,
        "_encoders": encoders,
    }


def summarise_pipeline_results(
    results: Dict[str, Any],
    output_json: str | None = None,
) -> Dict[str, Any]:
    """Strip in-memory caches and write a JSON summary if a path is given."""
    summary = {k: v for k, v in results.items() if not k.startswith("_")}
    if output_json:
        p = Path(output_json)
        p.parent.mkdir(parents=True, exist_ok=True)
        with p.open("w") as f:
            json.dump(summary, f, indent=2, default=str)
    return summary

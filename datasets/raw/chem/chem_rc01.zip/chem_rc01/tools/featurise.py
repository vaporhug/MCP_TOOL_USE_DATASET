"""Reaction-fingerprint featurisation and label-encoding primitives.

The agent never imports rdkit directly — it goes through these wrappers, which
take care of SMILES sanitisation and bit-vector conversion.

Exposed functions:
    canonicalise_smiles
    morgan_fingerprint
    reactant_product_fingerprint
    difference_reaction_fingerprint
    build_reaction_fingerprint_matrix
    fit_label_encoder
    encode_labels
    decode_labels
"""
from __future__ import annotations

from typing import Any, Dict, Iterable, List, Sequence, Tuple

import numpy as np
import pandas as pd
from rdkit import Chem, RDLogger
from rdkit.Chem import AllChem

RDLogger.DisableLog("rdApp.*")


def canonicalise_smiles(smi: str) -> str:
    """Return RDKit-canonical SMILES; empty string if parse fails."""
    if smi is None or (isinstance(smi, float) and np.isnan(smi)):
        return ""
    mol = Chem.MolFromSmiles(str(smi))
    if mol is None:
        return ""
    return Chem.MolToSmiles(mol)


def morgan_fingerprint(
    smi: str,
    radius: int = 2,
    n_bits: int = 2048,
) -> np.ndarray:
    """Single-molecule Morgan fingerprint as a uint8 bit vector."""
    mol = Chem.MolFromSmiles(str(smi)) if smi else None
    if mol is None:
        return np.zeros(n_bits, dtype=np.uint8)
    fp = AllChem.GetMorganFingerprintAsBitVect(mol, radius, nBits=n_bits)
    arr = np.zeros((n_bits,), dtype=np.uint8)
    from rdkit.DataStructs import ConvertToNumpyArray

    ConvertToNumpyArray(fp, arr)
    return arr


def _mix_smiles(smi_list: Iterable[str]) -> str:
    """Join a list of SMILES with '.' for combined fingerprinting."""
    parts = [str(s) for s in smi_list if s and not (isinstance(s, float) and np.isnan(s))]
    return ".".join(parts)


def reactant_product_fingerprint(
    reactants: Sequence[str],
    products: Sequence[str],
    radius: int = 2,
    n_bits: int = 2048,
) -> np.ndarray:
    """Concatenated [reactant_FP, product_FP] vector — length 2 * n_bits."""
    fp_r = morgan_fingerprint(_mix_smiles(reactants), radius=radius, n_bits=n_bits)
    fp_p = morgan_fingerprint(_mix_smiles(products), radius=radius, n_bits=n_bits)
    return np.concatenate([fp_r, fp_p]).astype(np.float32)


def difference_reaction_fingerprint(
    reactants: Sequence[str],
    products: Sequence[str],
    radius: int = 2,
    n_bits: int = 2048,
) -> np.ndarray:
    """Difference fingerprint (product_FP - reactant_FP) as float32 vector.

    This is the AP3-style "what changed" representation used as a baseline
    in many reaction-condition recommenders. Values lie in {-1, 0, +1}
    indicating bits that are unique to product, common, or unique to reactant.
    """
    fp_r = morgan_fingerprint(_mix_smiles(reactants), radius=radius, n_bits=n_bits)
    fp_p = morgan_fingerprint(_mix_smiles(products), radius=radius, n_bits=n_bits)
    return (fp_p.astype(np.int16) - fp_r.astype(np.int16)).astype(np.float32)


def build_reaction_fingerprint_matrix(
    records: pd.DataFrame,
    n_bits: int = 1024,
    mode: str = "concat",
) -> np.ndarray:
    """Build an (n_rxn, feature_dim) matrix from a reaction record table.

    mode = 'concat' returns [reactant_FP, product_FP, diff_FP] of length 3*n_bits;
    mode = 'difference' returns just the diff_FP of length n_bits;
    mode = 'reactant_product' returns [reactant_FP, product_FP] of length 2*n_bits.
    """
    if mode not in ("concat", "difference", "reactant_product"):
        raise ValueError(f"unknown mode {mode!r}")
    rows = []
    for _, r in records.iterrows():
        reactants = [r.get("reactant_000"), r.get("reactant_001")]
        products = [r.get("product_000")]
        rp = reactant_product_fingerprint(reactants, products, n_bits=n_bits)
        diff = difference_reaction_fingerprint(reactants, products, n_bits=n_bits)
        if mode == "concat":
            rows.append(np.concatenate([rp, diff]))
        elif mode == "difference":
            rows.append(diff)
        else:
            rows.append(rp)
    return np.vstack(rows).astype(np.float32)


def fit_label_encoder(
    series: pd.Series,
    other_token: str = "__OTHER__",
    null_token: str = "__NULL__",
    min_count: int = 1,
) -> Dict[str, Any]:
    """Build {label -> integer} mapping for a single label slot.

    Labels with fewer than ``min_count`` occurrences are merged into ``other_token``.
    Missing values (NaN) are mapped to ``null_token``.
    Returns a dict carrying the forward + inverse vocabulary.
    """
    counts: Dict[str, int] = {}
    for v in series:
        if v is None or (isinstance(v, float) and np.isnan(v)):
            key = null_token
        else:
            key = str(v)
        counts[key] = counts.get(key, 0) + 1
    keep = [null_token, other_token]
    for k, c in counts.items():
        if k in (null_token, other_token):
            continue
        if c >= min_count:
            keep.append(k)
    # Stable: preserve null/other at indices 0, 1 then sort the rest by frequency desc.
    rest = sorted(
        [k for k in keep if k not in (null_token, other_token)],
        key=lambda k: (-counts.get(k, 0), k),
    )
    vocab = [null_token, other_token] + rest
    label_to_idx = {lab: i for i, lab in enumerate(vocab)}
    return {
        "vocab": vocab,
        "label_to_idx": label_to_idx,
        "idx_to_label": {i: lab for lab, i in label_to_idx.items()},
        "null_token": null_token,
        "other_token": other_token,
        "counts": counts,
    }


def encode_labels(series: pd.Series, encoder: Dict[str, Any]) -> np.ndarray:
    """Map a label series to integer indices using ``encoder``."""
    null = encoder["null_token"]
    other = encoder["other_token"]
    l2i = encoder["label_to_idx"]
    out = np.empty(len(series), dtype=np.int64)
    for i, v in enumerate(series):
        if v is None or (isinstance(v, float) and np.isnan(v)):
            key = null
        else:
            key = str(v)
        if key in l2i:
            out[i] = l2i[key]
        else:
            out[i] = l2i[other]
    return out


def decode_labels(indices: Iterable[int], encoder: Dict[str, Any]) -> List[str]:
    """Inverse of encode_labels."""
    i2l = encoder["idx_to_label"]
    return [i2l.get(int(i), encoder["other_token"]) for i in indices]

"""Multi-output classifier wrappers for reaction-condition recommendation.

The agent never imports ``sklearn`` directly. Each ``fit_*`` returns a plain
dict carrying the trained estimator(s) so the rest of the pipeline stays
framework-agnostic.

Exposed functions:
    fit_logistic_regression
    fit_random_forest_classifier
    fit_gradient_boosting_classifier
    predict_class_probabilities
    fit_multi_output_classifier
    predict_multi_output
    most_frequent_baseline
"""
from __future__ import annotations

from typing import Any, Dict, List

import numpy as np
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression


def fit_logistic_regression(
    X: np.ndarray,
    y: np.ndarray,
    C: float = 1.0,
    max_iter: int = 200,
    seed: int = 42,
) -> Dict[str, Any]:
    """Fit an L2-regularised multinomial logistic regression."""
    clf = LogisticRegression(
        C=C,
        max_iter=max_iter,
        solver="lbfgs",
        multi_class="auto",
        random_state=seed,
        n_jobs=-1,
    )
    clf.fit(X, y)
    return {
        "kind": "logreg",
        "model": clf,
        "classes_": np.asarray(clf.classes_, dtype=int),
    }


def fit_random_forest_classifier(
    X: np.ndarray,
    y: np.ndarray,
    n_estimators: int = 200,
    max_depth: int | None = None,
    min_samples_leaf: int = 1,
    seed: int = 42,
) -> Dict[str, Any]:
    """Fit a Random Forest classifier."""
    clf = RandomForestClassifier(
        n_estimators=n_estimators,
        max_depth=max_depth,
        min_samples_leaf=min_samples_leaf,
        random_state=seed,
        n_jobs=-1,
    )
    clf.fit(X, y)
    return {
        "kind": "random_forest",
        "model": clf,
        "classes_": np.asarray(clf.classes_, dtype=int),
        "feature_importances_": clf.feature_importances_.astype(float),
    }


def fit_gradient_boosting_classifier(
    X: np.ndarray,
    y: np.ndarray,
    n_estimators: int = 100,
    max_depth: int = 3,
    learning_rate: float = 0.1,
    seed: int = 42,
) -> Dict[str, Any]:
    """Fit an sklearn GradientBoostingClassifier (slower; use a small slot vocab)."""
    clf = GradientBoostingClassifier(
        n_estimators=n_estimators,
        max_depth=max_depth,
        learning_rate=learning_rate,
        random_state=seed,
    )
    clf.fit(X, y)
    return {
        "kind": "gradient_boosting",
        "model": clf,
        "classes_": np.asarray(clf.classes_, dtype=int),
    }


def predict_class_probabilities(model_dict: Dict[str, Any], X: np.ndarray) -> np.ndarray:
    """Return (n_samples, n_classes) probability matrix in class-index order."""
    proba = model_dict["model"].predict_proba(X)
    classes = np.asarray(model_dict["classes_"], dtype=int)
    n_classes_full = int(max(classes.max() + 1, classes.shape[0]))
    full = np.zeros((proba.shape[0], n_classes_full), dtype=float)
    for j, c in enumerate(classes):
        full[:, int(c)] = proba[:, j]
    return full


def fit_multi_output_classifier(
    X_train: np.ndarray,
    y_train_per_slot: Dict[str, np.ndarray],
    estimator: str = "random_forest",
    **kwargs: Any,
) -> Dict[str, Dict[str, Any]]:
    """Fit one classifier per slot using the same feature matrix.

    estimator: 'logreg' | 'random_forest' | 'gradient_boosting'
    Returns {slot: model_dict}.
    """
    if estimator == "logreg":
        fit_fn = fit_logistic_regression
    elif estimator == "random_forest":
        fit_fn = fit_random_forest_classifier
    elif estimator == "gradient_boosting":
        fit_fn = fit_gradient_boosting_classifier
    else:
        raise ValueError(f"unknown estimator {estimator!r}")
    out: Dict[str, Dict[str, Any]] = {}
    for slot, y in y_train_per_slot.items():
        out[slot] = fit_fn(X_train, y, **kwargs)
    return out


def predict_multi_output(
    models_per_slot: Dict[str, Dict[str, Any]],
    X: np.ndarray,
) -> Dict[str, np.ndarray]:
    """Apply each per-slot model to ``X``; return {slot: (n, n_classes) probabilities}."""
    return {slot: predict_class_probabilities(m, X) for slot, m in models_per_slot.items()}


def most_frequent_baseline(
    y_train: np.ndarray,
    n_classes: int,
) -> np.ndarray:
    """Class-frequency vector (length ``n_classes``) used as the constant baseline."""
    counts = np.bincount(y_train, minlength=n_classes).astype(float)
    if counts.sum() <= 0:
        return np.full(n_classes, 1.0 / n_classes)
    return counts / counts.sum()

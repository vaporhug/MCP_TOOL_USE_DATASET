"""Top-k accuracy and per-slot evaluation helpers.

Exposed functions:
    top_k_accuracy
    per_slot_top_k
    combined_top_k_exact_match
    confusion_topk_matrix
    average_improvement_over_baseline
"""
from __future__ import annotations

from typing import Any, Dict, List, Sequence

import numpy as np


def top_k_accuracy(
    y_true: np.ndarray,
    proba: np.ndarray,
    k: int = 1,
) -> float:
    """Standard top-k classification accuracy."""
    if proba.ndim != 2:
        raise ValueError("proba must be (n_samples, n_classes)")
    n, c = proba.shape
    k = min(k, c)
    topk_idx = np.argpartition(-proba, kth=k - 1, axis=1)[:, :k]
    # Sort the partition for determinism
    row_order = np.argsort(-np.take_along_axis(proba, topk_idx, axis=1), axis=1)
    topk_sorted = np.take_along_axis(topk_idx, row_order, axis=1)
    hits = (topk_sorted == y_true[:, None]).any(axis=1)
    return float(hits.mean())


def per_slot_top_k(
    y_true_per_slot: Dict[str, np.ndarray],
    proba_per_slot: Dict[str, np.ndarray],
    ks: Sequence[int] = (1, 3, 5, 10),
) -> Dict[str, Dict[int, float]]:
    """Compute top-k accuracy for each slot independently."""
    out: Dict[str, Dict[int, float]] = {}
    for slot, y in y_true_per_slot.items():
        if slot not in proba_per_slot:
            continue
        out[slot] = {int(k): top_k_accuracy(y, proba_per_slot[slot], k=k) for k in ks}
    return out


def combined_top_k_exact_match(
    y_true_per_slot: Dict[str, np.ndarray],
    proba_per_slot: Dict[str, np.ndarray],
    slot_order: Sequence[str],
    k: int = 3,
) -> float:
    """Top-k joint exact-match accuracy.

    A reaction is counted correct if the joint truth tuple matches one of
    the k highest-product candidates obtained from per-slot top-k. This is
    the metric reported in Table 3 of the ORDerly paper.
    """
    n = len(next(iter(y_true_per_slot.values())))
    # Per-slot top-k indices and probabilities
    per_slot_topk: Dict[str, np.ndarray] = {}
    per_slot_topk_proba: Dict[str, np.ndarray] = {}
    for slot in slot_order:
        proba = proba_per_slot[slot]
        kk = min(k, proba.shape[1])
        topk_idx = np.argpartition(-proba, kth=kk - 1, axis=1)[:, :kk]
        row_order = np.argsort(-np.take_along_axis(proba, topk_idx, axis=1), axis=1)
        topk_sorted = np.take_along_axis(topk_idx, row_order, axis=1)
        per_slot_topk[slot] = topk_sorted
        per_slot_topk_proba[slot] = np.take_along_axis(proba, topk_sorted, axis=1)

    hits = 0
    for i in range(n):
        # Build at most k joint candidates by greedy beam search across slots.
        beams: List[tuple[float, Dict[str, int]]] = [(1.0, {})]
        for slot in slot_order:
            new_beams = []
            for logp, partial in beams:
                idxs = per_slot_topk[slot][i]
                ps = per_slot_topk_proba[slot][i]
                for cls, p in zip(idxs, ps):
                    new = dict(partial)
                    new[slot] = int(cls)
                    new_beams.append((logp * float(p), new))
            new_beams.sort(key=lambda t: -t[0])
            beams = new_beams[:k]
        truth = {slot: int(y_true_per_slot[slot][i]) for slot in slot_order}
        if any(b == truth for _, b in beams):
            hits += 1
    return float(hits / max(n, 1))


def confusion_topk_matrix(
    y_true: np.ndarray,
    proba: np.ndarray,
    n_top_classes: int = 10,
) -> Dict[str, Any]:
    """Restrict TRUE labels to the most-frequent ``n_top_classes`` (by truth count)
    and build a confusion matrix between truth and top-1 prediction. Predictions
    falling outside the top-N classes are aggregated into a synthetic ``__OTHER__``
    column so the row-normalised heatmap reflects the full top-1 confusion
    (not the conditional distribution over top-N predicted classes only).

    Returns matrix shape (n_top_classes, n_top_classes + 1):
        rows = top-N truth classes
        cols = top-N predicted classes + 1 final __OTHER__ column
    """
    counts = np.bincount(y_true, minlength=proba.shape[1])
    top_classes = np.argsort(-counts)[:n_top_classes]
    in_top = np.isin(y_true, top_classes)
    y_t = y_true[in_top]
    y_p = proba[in_top].argmax(axis=1)
    # keep ALL predictions: in-top go to their own column, out-of-top go to __OTHER__
    cls_to_row = {int(c): i for i, c in enumerate(top_classes)}
    cls_to_col = dict(cls_to_row)
    other_col = len(top_classes)  # index for __OTHER__
    n = len(top_classes)
    M = np.zeros((n, n + 1), dtype=int)
    for t, p in zip(y_t, y_p):
        row = cls_to_row[int(t)]
        col = cls_to_col.get(int(p), other_col)
        M[row, col] += 1
    return {
        "matrix": M,
        "class_indices": top_classes.astype(int),
        "other_column_label": "__OTHER__",
    }


def absolute_improvement_over_baseline(
    model_top_k: Dict[str, Dict[int, float]],
    baseline_top_k: Dict[str, Dict[int, float]],
) -> Dict[str, Dict[int, float]]:
    """Absolute improvement in accuracy points: model - baseline (per slot, per k).

    NOTE: this is NOT the same as the ORDerly paper's AIB metric. The paper's
    AIB is an error-reduction ratio (model - baseline) / (1 - baseline); see
    `paper_aib_over_baseline` below for the paper-faithful version.
    """
    out: Dict[str, Dict[int, float]] = {}
    for slot, ks in model_top_k.items():
        out[slot] = {}
        b = baseline_top_k.get(slot, {})
        for k, v in ks.items():
            out[slot][int(k)] = float(v - b.get(int(k), 0.0))
    return out


def paper_aib_over_baseline(
    model_top_k: Dict[str, Dict[int, float]],
    baseline_top_k: Dict[str, Dict[int, float]],
    eps: float = 1e-12,
) -> Dict[str, Dict[int, float]]:
    """Paper-style AIB: (model - baseline) / (1 - baseline) per slot, per k.

    Matches the ORDerly Nature paper Table 3 reporting convention (e.g. Solvents
    baseline 36%, model 51% gives AIB = 15 / (1 - 0.36) = 23.4% ≈ 24% as reported).
    """
    out: Dict[str, Dict[int, float]] = {}
    for slot, ks in model_top_k.items():
        out[slot] = {}
        b = baseline_top_k.get(slot, {})
        for k, m_acc in ks.items():
            b_acc = float(b.get(k, 0.0))
            denom = max(1.0 - b_acc, eps)
            out[slot][int(k)] = float((float(m_acc) - b_acc) / denom)
    return out


# Backward-compat alias: keep the old name pointing at absolute improvement
# (the actual implementation history; not the paper AIB).
average_improvement_over_baseline = absolute_improvement_over_baseline

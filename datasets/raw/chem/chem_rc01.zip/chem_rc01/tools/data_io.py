"""Reaction-record and label-vocabulary loaders.

Exposed functions:
    resolve_data_path
    load_reaction_records
    load_label_vocabulary
    list_label_slots
    summarise_label_distribution
    filter_complete_reactions
    train_test_split_reactions
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Tuple

import numpy as np
import pandas as pd


LABEL_SLOTS: Tuple[str, ...] = (
    "solvent_000",
    "solvent_001",
    "agent_000",
    "agent_001",
)


def resolve_data_path(path: str | Path) -> Path:
    """Resolve a path that may be given relative to the task root."""
    p = Path(path)
    if p.exists():
        return p
    here = Path(__file__).resolve().parent.parent
    cand = here / path
    if cand.exists():
        return cand
    raise FileNotFoundError(f"could not locate {path!s}")


def load_reaction_records(
    path: str = "input_data/data/orderly_condition_sample.csv",
) -> pd.DataFrame:
    """Load the 8,000-row ORDerly-condition sample.

    Returns a DataFrame with columns:
        original_index, reactant_000, reactant_001, product_000,
        agent_000, agent_001, agent_002,
        solvent_000, solvent_001,
        temperature, yield_000, rxn_time
    Missing optional slots (second reactant, second/third agent, second solvent,
    temperature, yield, time) appear as NaN.
    """
    p = resolve_data_path(path)
    df = pd.read_csv(p)
    # Cast SMILES columns to string (NaN preserved)
    for col in ("reactant_000", "reactant_001", "product_000",
                "agent_000", "agent_001", "agent_002",
                "solvent_000", "solvent_001"):
        if col in df.columns:
            df[col] = df[col].where(df[col].notna(), other=np.nan)
    # Numeric columns
    for col in ("temperature", "yield_000", "rxn_time"):
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    return df


def load_label_vocabulary(
    slot: str,
    data_dir: str = "input_data/data",
) -> pd.DataFrame:
    """Load the per-slot label-frequency table generated from the dataset.

    Columns: rank (1-indexed), canonical_smiles, count, frequency.
    """
    if slot not in LABEL_SLOTS:
        raise ValueError(f"unknown slot {slot!r}; expected one of {LABEL_SLOTS}")
    p = resolve_data_path(Path(data_dir) / f"vocab_{slot}.csv")
    return pd.read_csv(p)


def list_label_slots() -> List[str]:
    """Return the ordered tuple of label-slot names this task models."""
    return list(LABEL_SLOTS)


def summarise_label_distribution(
    records: pd.DataFrame,
    slot: str,
    top_n: int = 10,
) -> Dict[str, Any]:
    """Per-slot summary: total non-null, unique label count, top-N coverage."""
    if slot not in records.columns:
        raise KeyError(slot)
    s = records[slot].dropna()
    vc = s.value_counts()
    coverage = float(vc.head(top_n).sum() / max(len(s), 1))
    return {
        "slot": slot,
        "n_total": int(len(records)),
        "n_non_null": int(len(s)),
        "n_unique": int(len(vc)),
        "top_n": int(top_n),
        "top_n_coverage": coverage,
        "most_common": vc.head(top_n).to_dict(),
    }


def filter_complete_reactions(
    records: pd.DataFrame,
    require_solvent: bool = True,
    require_agent: bool = False,
) -> pd.DataFrame:
    """Drop reactions missing reactants/products and (optionally) solvent/agent."""
    mask = records["reactant_000"].notna() & records["product_000"].notna()
    if require_solvent:
        mask &= records["solvent_000"].notna()
    if require_agent:
        mask &= records["agent_000"].notna()
    return records.loc[mask].reset_index(drop=True)


def train_test_split_reactions(
    records: pd.DataFrame,
    test_fraction: float = 0.2,
    seed: int = 42,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Random shuffle + split. Returns (train_df, test_df)."""
    if not 0.0 < test_fraction < 1.0:
        raise ValueError("test_fraction must be in (0,1)")
    rng = np.random.RandomState(seed)
    n = len(records)
    idx = rng.permutation(n)
    n_test = max(1, int(round(n * test_fraction)))
    test_idx = idx[:n_test]
    train_idx = idx[n_test:]
    return (
        records.iloc[train_idx].reset_index(drop=True),
        records.iloc[test_idx].reset_index(drop=True),
    )

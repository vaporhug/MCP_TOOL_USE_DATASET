# Bundled file licenses

## input_data/data/ (NMRShiftDB-derived tables)
The bundled NMRShiftDB-derived CSV tables (`nmrshiftdb_molecules.csv`,
`nmrshiftdb_13c_atoms.csv`, `nmrshiftdb_1h_atoms.csv`) and the
`nmrshiftdb_smiles_split_seed0.csv` split file are tabular conversions
of the per-molecule `mol_dict` data released by Jonas & Kuhn 2019
alongside their J. Cheminformatics paper. The underlying NMRShiftDB
records and the Jonas & Kuhn release are CC-BY 4.0 / BSD-2-Clause
respectively; the present CSV reshaping is offered under CC-BY 4.0
with attribution to the original NMRShiftDB curators and to
Jonas & Kuhn.

## input_data/reference_paper/target.pdf
Jonas E. and Kuhn S., "Rapid prediction of NMR spectral properties
with quantified uncertainty," J. Cheminformatics 2019, 11:50,
DOI 10.1186/s13321-019-0374-3. Published Open Access under
CC-BY 4.0. Redistribution permitted with attribution.

## tools/
Original code, MIT licensed.

No CC-BY-NC or other non-commercial-restricted files are bundled.

"""Evaluation primitives for per-atom NMR shift predictions.

Headline metrics:
- per-atom MAE / RMSE on a held-out test set
- per-molecule MAE / RMSE (each molecule contributes equally regardless of
  atom count)
- error stratified by an arbitrary categorical column (element, hybridisation,
  neighbouring-atom type)
- confidence-vs-error curves: when a regressor outputs an uncertainty value,
  sort predictions by uncertainty and report the running mean error for the
  top-k% most-confident predictions.

Each function returns plain-python / numpy types so that the agent can
compose downstream plots and tables.
"""

from __future__ import annotations

from typing import Sequence

import numpy as np
import pandas as pd


def per_atom_mae(y_true: Sequence[float], y_pred: Sequence[float]) -> float:
    """Mean absolute error in ppm across all rows."""
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    if y_true.size == 0:
        return float("nan")
    return float(np.mean(np.abs(y_pred - y_true)))


def per_atom_rmse(y_true: Sequence[float], y_pred: Sequence[float]) -> float:
    """Root mean squared error in ppm across all rows."""
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    if y_true.size == 0:
        return float("nan")
    return float(np.sqrt(np.mean((y_pred - y_true) ** 2)))


def per_molecule_mae(
    mol_ids: Sequence[int],
    y_true: Sequence[float],
    y_pred: Sequence[float],
) -> float:
    """Mean across molecules of (mean per-atom absolute error within that molecule).

    This matches the ``mol MAE`` reported in the reference paper, where each
    molecule contributes equally regardless of how many labelled atoms it has.
    """
    df = pd.DataFrame({
        "mol_id": np.asarray(mol_ids),
        "abs_err": np.abs(np.asarray(y_pred, dtype=float) - np.asarray(y_true, dtype=float)),
    })
    if df.empty:
        return float("nan")
    return float(df.groupby("mol_id")["abs_err"].mean().mean())


def per_molecule_rmse(
    mol_ids: Sequence[int],
    y_true: Sequence[float],
    y_pred: Sequence[float],
) -> float:
    """Mean across molecules of the per-molecule RMSE."""
    yt = np.asarray(y_true, dtype=float)
    yp = np.asarray(y_pred, dtype=float)
    df = pd.DataFrame({
        "mol_id": np.asarray(mol_ids),
        "sq_err": (yp - yt) ** 2,
    })
    if df.empty:
        return float("nan")
    per_mol_rmse = df.groupby("mol_id")["sq_err"].mean().pow(0.5)
    return float(per_mol_rmse.mean())


def error_distribution(y_true: Sequence[float], y_pred: Sequence[float]) -> dict[str, float]:
    """Return summary statistics of the absolute error distribution."""
    err = np.abs(np.asarray(y_pred, dtype=float) - np.asarray(y_true, dtype=float))
    if err.size == 0:
        return {"n": 0}
    return {
        "n": int(err.size),
        "mean": float(np.mean(err)),
        "median": float(np.median(err)),
        "p90": float(np.quantile(err, 0.90)),
        "p95": float(np.quantile(err, 0.95)),
        "p99": float(np.quantile(err, 0.99)),
        "max": float(np.max(err)),
    }


def error_by_category(
    y_true: Sequence[float],
    y_pred: Sequence[float],
    category: Sequence,
) -> pd.DataFrame:
    """Aggregate per-row absolute error grouped by a categorical column.

    Returns a DataFrame with columns ``[category, n, mae, rmse, p95]``.
    """
    yt = np.asarray(y_true, dtype=float); yp = np.asarray(y_pred, dtype=float)
    df = pd.DataFrame({
        "category": np.asarray(category),
        "abs_err": np.abs(yp - yt),
        "sq_err": (yp - yt) ** 2,
    })
    if df.empty:
        return pd.DataFrame(columns=["category", "n", "mae", "rmse", "p95"])
    g = df.groupby("category").agg(
        n=("abs_err", "size"),
        mae=("abs_err", "mean"),
        rmse=("sq_err", lambda s: float(np.sqrt(np.mean(s)))),
        p95=("abs_err", lambda s: float(np.quantile(s, 0.95))),
    ).reset_index()
    return g


def error_by_neighbour(
    df: pd.DataFrame,
    y_true: Sequence[float],
    y_pred: Sequence[float],
) -> pd.DataFrame:
    """Stratify the per-row error by the most electronegative bonded neighbour.

    For every row, choose the dominant heavy-atom neighbour using a fixed
    priority order ``[F, Cl, S, O, N, P, C]`` based on the boolean
    ``has_X_neighbor`` columns (or ``parent_has_X_neighbor`` for 1H tables).
    Returns the same shape as :func:`error_by_category`.
    """
    yt = np.asarray(y_true, dtype=float); yp = np.asarray(y_pred, dtype=float)
    is_1h = "parent_element" in df.columns
    prefix = "parent_" if is_1h else ""
    priority = ["F", "Cl", "S", "O", "N", "P"]

    def _label(row: pd.Series) -> str:
        for el in priority:
            col = f"{prefix}has_{el}_neighbor"
            if col in row and bool(row[col]):
                return el
        return "C"

    cat = df.apply(_label, axis=1)
    return error_by_category(yt, yp, cat)


def confidence_error_curve(
    y_true: Sequence[float],
    y_pred: Sequence[float],
    uncertainty: Sequence[float],
    fractions: Sequence[float] = (0.10, 0.25, 0.50, 0.80, 0.95, 1.00),
) -> pd.DataFrame:
    """Mean absolute error of the most-confident ``frac`` of predictions.

    Predictions are ranked by ``uncertainty`` ascending; for each fraction,
    the lowest-uncertainty fraction is retained and the per-atom MAE is
    computed on that subset.
    """
    yt = np.asarray(y_true, dtype=float)
    yp = np.asarray(y_pred, dtype=float)
    u = np.asarray(uncertainty, dtype=float)
    n = yt.size
    if n == 0:
        return pd.DataFrame(columns=["fraction", "n", "mae"])
    order = np.argsort(u, kind="mergesort")
    yt = yt[order]; yp = yp[order]
    rows = []
    for f in fractions:
        k = max(1, int(round(float(f) * n)))
        rows.append({"fraction": float(f), "n": int(k),
                     "mae": float(np.mean(np.abs(yp[:k] - yt[:k])))})
    return pd.DataFrame(rows)


def fraction_data_at_threshold(
    uncertainty: Sequence[float], thresholds: Sequence[float]
) -> pd.DataFrame:
    """For each threshold, return the fraction of rows below that uncertainty.

    Useful when comparing 'GNN at frac=80%' style claims from the paper.
    """
    u = np.asarray(uncertainty, dtype=float)
    n = u.size
    if n == 0:
        return pd.DataFrame(columns=["threshold", "fraction"])
    return pd.DataFrame([
        {"threshold": float(t), "fraction": float(np.mean(u <= t))}
        for t in thresholds
    ])

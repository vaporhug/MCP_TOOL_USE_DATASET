"""Tools package for the chem_nm01 SCP benchmark task.

Sub-modules:
- ``data_io``      : CSV loading and dataset summaries.
- ``mol_parsing``  : SMILES -> RDKit Mol parsing, atom-property extraction.
- ``featurization``: per-atom Morgan circular fingerprints, HOSE-style env codes,
                     scalar atom-property vectors, train/test splitting.
- ``regression``   : ridge / random-forest / k-nearest-neighbour shift regressors,
                     fit/predict primitives.
- ``evaluation``   : per-atom MAE/RMSE, per-molecule MAE, error stratified by
                     element / hybridisation / heavy-atom neighbour, confidence
                     vs error curves.
- ``plotting``     : matplotlib helpers; every function returns ``{"path": ...}``.

Each function is a low-level primitive — none of them encode the headline
result of the benchmark.  The agent is expected to compose them.
"""

from . import data_io, mol_parsing, featurization, regression, evaluation, plotting  # noqa: F401

__all__ = [
    "data_io",
    "mol_parsing",
    "featurization",
    "regression",
    "evaluation",
    "plotting",
]

"""Per-atom feature builders + train / test splitting.

The agent builds two kinds of feature representations:

1. **Atom-centred Morgan circular fingerprint** — RDKit's
   ``GetMorganFingerprintAsBitVect`` with ``fromAtoms=[atom_idx]`` returns
   a bit vector that hashes the local connectivity environment up to a
   given bond radius.  This mirrors the per-atom 2-D environment encoding
   used in graph-network featurisations.

2. **Scalar atom property vector** — the categorical atom descriptors
   (hybridisation, aromaticity, neighbour elements, ring membership) that
   complement the Morgan bits.

Splits are SMILES-based: every record sharing the same canonical SMILES
goes to the same partition, mirroring the protocol used in the reference
paper to prevent train/test leakage from molecules with multiple spectra.
"""

from __future__ import annotations

from typing import Iterable, Sequence

import numpy as np
import pandas as pd
from rdkit import Chem, RDLogger
from rdkit.Chem import AllChem

RDLogger.DisableLog("rdApp.*")


def per_atom_morgan_fingerprint(
    smiles_list: Sequence[str],
    atom_idx_list: Sequence[int],
    radius: int = 2,
    n_bits: int = 256,
) -> np.ndarray:
    """Compute one atom-centred Morgan fingerprint per (smiles, atom_idx).

    Defaults match the fixed runtime protocol declared in the task
    instruction (radius=2, n_bits=256) so that the bundled pipeline can
    be invoked with stock arguments.

    Parameters
    ----------
    smiles_list : sequence of str
        SMILES for each labelled atom.
    atom_idx_list : sequence of int
        Atom index inside the parsed molecule for each row.
    radius : int
        Bond-distance radius around the centre atom (default 2 = Morgan-r2).
    n_bits : int
        Bit-vector length (default 256).

    Returns
    -------
    np.ndarray of shape (n_rows, n_bits), dtype float32, values in {0, 1}.
    """
    out = np.zeros((len(smiles_list), int(n_bits)), dtype=np.float32)
    cache: dict[str, Chem.Mol] = {}
    for k, (smi, ai) in enumerate(zip(smiles_list, atom_idx_list)):
        mol = cache.get(smi)
        if mol is None:
            mol = Chem.MolFromSmiles(smi)
            cache[smi] = mol
        if mol is None:
            continue
        ai = int(ai)
        if ai < 0 or ai >= mol.GetNumAtoms():
            continue
        try:
            fp = AllChem.GetMorganFingerprintAsBitVect(
                mol, int(radius), nBits=int(n_bits), fromAtoms=[ai]
            )
            out[k] = np.asarray(fp, dtype=np.float32)
        except Exception:
            pass
    return out


def per_atom_property_matrix(df: pd.DataFrame) -> tuple[np.ndarray, list[str]]:
    """Build a one-hot + boolean atom-property matrix from the table columns.

    Parameters
    ----------
    df : pandas.DataFrame
        The labelled-atom table; must contain at least one of the property
        columns (``hybridization``, ``aromatic``, ``in_ring``, ``degree``,
        ``total_h``, ``formal_charge``, ``n_heavy_neighbors``,
        ``has_*_neighbor``).  Columns specific to the 1H table
        (``parent_*``) are also detected.

    Returns
    -------
    (X, feature_names)
        ``X`` is a float matrix of shape ``(len(df), n_features)``;
        ``feature_names`` lists each column produced by ``pd.get_dummies``.
    """
    candidate_cols = [
        "hybridization", "aromatic", "in_ring", "degree", "total_h",
        "formal_charge", "n_heavy_neighbors", "has_O_neighbor",
        "has_N_neighbor", "has_S_neighbor", "has_F_neighbor",
        "has_Cl_neighbor", "has_P_neighbor",
        "parent_hybridization", "parent_aromatic", "parent_in_ring",
        "parent_degree", "parent_total_h", "parent_n_heavy_neighbors",
        "parent_has_O_neighbor", "parent_has_N_neighbor",
        "parent_has_F_neighbor", "parent_has_Cl_neighbor",
    ]
    cols = [c for c in candidate_cols if c in df.columns]
    if not cols:
        return np.zeros((len(df), 0), dtype=np.float32), []
    enc = pd.get_dummies(df[cols], drop_first=False, dtype=float)
    return enc.values.astype(np.float32), list(enc.columns)


def concat_features(*matrices: np.ndarray) -> np.ndarray:
    """Concatenate any number of 2-D feature matrices along the column axis."""
    valid = [m for m in matrices if m is not None and m.size > 0]
    if not valid:
        return np.zeros((0, 0), dtype=np.float32)
    return np.concatenate(valid, axis=1).astype(np.float32)


def smiles_split_mask(
    smiles: Sequence[str],
    train_fraction: float = 0.8,
    seed: int = 0,
) -> np.ndarray:
    """Return a boolean mask of length ``len(smiles)`` marking train rows.

    All rows with the same SMILES end up in the same split (matching the
    reference paper's protocol).
    """
    smiles = list(smiles)
    unique = np.array(sorted(set(smiles)))
    rng = np.random.RandomState(int(seed))
    rng.shuffle(unique)
    n_train = int(round(float(train_fraction) * len(unique)))
    train_set = set(unique[:n_train].tolist())
    return np.array([s in train_set for s in smiles], dtype=bool)


def train_test_arrays(
    X: np.ndarray, y: np.ndarray, mask: np.ndarray
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Slice (X, y) into (X_train, y_train, X_test, y_test) using a boolean mask."""
    X = np.asarray(X); y = np.asarray(y); mask = np.asarray(mask, dtype=bool)
    return X[mask], y[mask], X[~mask], y[~mask]


def project_smiles_split_to_atoms(
    smiles_list: Sequence[str], atom_table_smiles: Sequence[str],
) -> np.ndarray:
    """Project a SMILES-level train/test split down to atom-table rows.

    Given a ``smiles_list`` of training SMILES (typically the molecules
    that fell on the train side of ``smiles_split_mask``) and the per-atom
    table's ``smiles`` column, return a boolean mask of length
    ``len(atom_table_smiles)`` marking the rows whose SMILES is in the
    training set. All atom rows of the same molecule therefore go to the
    same split, matching the SMILES-disjoint protocol.
    """
    train_set = set(smiles_list)
    return np.array([s in train_set for s in atom_table_smiles], dtype=bool)


def hose_codes_for_table(
    df: pd.DataFrame, max_sphere: int = 4, idx_col: str | None = None,
) -> list[str]:
    """Compute a HOSE-style code for every row in ``df``.

    Uses ``mol_parsing.hose_code_string`` (Bremser-subset encoding; see
    that function for the exact sphere convention and the rationale for
    omitting ring-membership / charge markers). The column holding the
    atom index defaults to ``atom_idx`` (13C table) falling back to
    ``parent_atom_idx`` (1H table).

    RDKit ``Mol`` objects are cached per unique SMILES so re-parsing
    each canonical SMILES only happens once across all of ``df``'s
    atom rows (typically 5–10× faster than the naive per-row loop on
    the full bundled tables, since a single SMILES holds many atom
    rows in the per-atom 13C/1H tables).
    """
    from .mol_parsing import hose_code_string, parse_smiles, _BOND_PREFIX
    if idx_col is None:
        idx_col = "atom_idx" if "atom_idx" in df.columns else (
            "parent_atom_idx" if "parent_atom_idx" in df.columns else None
        )
    if idx_col is None:
        return [""] * len(df)

    # Pre-parse every unique SMILES exactly once and reuse the Mol cache
    # for the per-row HOSE computation.
    mol_cache: dict[str, "Chem.Mol | None"] = {}
    for smi in df["smiles"].astype(str).unique():
        mol_cache[smi] = parse_smiles(smi)

    def _hose_cached(smi: str, ai: int) -> str:
        mol = mol_cache.get(smi)
        if mol is None or ai < 0 or ai >= mol.GetNumAtoms():
            return ""
        visited = {int(ai)}
        centre = mol.GetAtomWithIdx(int(ai))
        spheres = [centre.GetSymbol()]
        frontier = [int(ai)]
        for _ in range(int(max_sphere)):
            sphere_items = []
            for cur in frontier:
                for bond in mol.GetAtomWithIdx(cur).GetBonds():
                    nbr = bond.GetOtherAtom(mol.GetAtomWithIdx(cur))
                    ni = nbr.GetIdx()
                    if ni in visited:
                        continue
                    prefix = _BOND_PREFIX.get(bond.GetBondType(), "")
                    sphere_items.append((prefix + nbr.GetSymbol(), ni))
            if not sphere_items:
                spheres.append("")
                continue
            sphere_items.sort(key=lambda x: x[0])
            spheres.append(",".join(it[0] for it in sphere_items))
            next_frontier = []
            for _, ni in sphere_items:
                visited.add(ni)
                next_frontier.append(ni)
            frontier = next_frontier
        return "/".join(spheres)

    out: list[str] = []
    for smi, ai in zip(df["smiles"].tolist(), df[idx_col].tolist()):
        out.append(_hose_cached(str(smi), int(ai)))
    return out

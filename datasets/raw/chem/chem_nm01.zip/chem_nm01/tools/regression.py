"""Regression primitives for per-atom chemical-shift prediction.

These are thin wrappers around scikit-learn estimators plus a HOSE-code
longest-prefix-match (Bremser-subset) baseline: for every test atom the
baseline returns the mean training shift over all training atoms whose
HOSE-code shares the deepest matched sphere prefix with the test atom.
None of these wrappers encode the headline result; they simply provide
``fit`` and ``predict`` entry points.
"""

from __future__ import annotations

from typing import Sequence

import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import Ridge
from sklearn.neighbors import KNeighborsRegressor


def train_random_forest(
    X_train: np.ndarray,
    y_train: np.ndarray,
    n_estimators: int = 100,
    max_depth: int | None = 20,
    max_features: str | float | int = "sqrt",
    min_samples_leaf: int = 2,
    seed: int = 0,
    n_jobs: int = -1,
) -> RandomForestRegressor:
    """Fit a ``RandomForestRegressor`` and return the trained model.

    Defaults match the fixed runtime protocol declared in the task
    instruction (``n_estimators=100``, ``max_depth=20``); the additional
    scikit-learn hyperparameters ``max_features='sqrt'`` and
    ``min_samples_leaf=2`` are conventional regression-tree defaults left
    unchanged from earlier versions so the call site can omit them.

    Parameters
    ----------
    X_train, y_train : np.ndarray
        Training features and per-atom shift targets in ppm.
    n_estimators : int
        Number of trees (default 100, matches declared protocol).
    max_depth : int | None
        Maximum depth of each tree (default 20, matches declared protocol).
    max_features : ...
        Forwarded to scikit-learn.
    min_samples_leaf : int
        Forwarded to scikit-learn.
    seed : int
        Random seed.
    n_jobs : int
        Parallel jobs for fitting.
    """
    rf = RandomForestRegressor(
        n_estimators=int(n_estimators),
        max_depth=(None if max_depth is None else int(max_depth)),
        max_features=max_features,
        min_samples_leaf=int(min_samples_leaf),
        random_state=int(seed),
        n_jobs=int(n_jobs),
    )
    rf.fit(np.asarray(X_train), np.asarray(y_train))
    return rf


def train_ridge(X_train: np.ndarray, y_train: np.ndarray, alpha: float = 1.0) -> Ridge:
    """Fit a ridge regressor and return it."""
    rg = Ridge(alpha=float(alpha))
    rg.fit(np.asarray(X_train), np.asarray(y_train))
    return rg


def train_knn(
    X_train: np.ndarray,
    y_train: np.ndarray,
    n_neighbors: int = 5,
    metric: str = "cosine",
    n_jobs: int = -1,
) -> KNeighborsRegressor:
    """Fit a k-nearest-neighbour regressor on a fingerprint feature matrix.

    The default ``metric='cosine'`` works well on bit-vector inputs.
    """
    knn = KNeighborsRegressor(
        n_neighbors=int(n_neighbors), metric=metric, n_jobs=int(n_jobs)
    )
    knn.fit(np.asarray(X_train), np.asarray(y_train))
    return knn


def predict(model, X_test: np.ndarray) -> np.ndarray:
    """Apply ``model.predict`` to ``X_test`` and return a 1-D float array."""
    return np.asarray(model.predict(np.asarray(X_test)), dtype=float)


def hose_nearest_neighbour_predict(
    train_codes: Sequence[str],
    train_shifts: Sequence[float],
    test_codes: Sequence[str],
    n_spheres_min: int = 1,
) -> np.ndarray:
    """HOSE-code longest-prefix-match shift prediction (Bremser baseline).

    For every test code, scan it from the deepest sphere downwards (longest
    common prefix) until at least one training code is found that shares the
    same prefix; return the mean of the matching training shifts. If even a
    single sphere cannot be matched the predictor falls back to the global
    training mean. The HOSE codes are produced by
    ``mol_parsing.hose_code_string`` (Bremser-subset bond-order-aware
    encoding; ring-membership and formal-charge markers omitted — see
    that function's docstring for the rationale).

    Parameters
    ----------
    train_codes, test_codes : sequences of str
        HOSE codes from ``mol_parsing.hose_code_string``.
    train_shifts : sequence of float
        Per-atom shift values aligned with ``train_codes``.
    n_spheres_min : int
        Minimum sphere depth required for a positive match before falling
        back to the global mean.

    Returns
    -------
    np.ndarray of float, shape (len(test_codes),)
    """
    train_codes = list(train_codes)
    test_codes = list(test_codes)
    train_shifts = np.asarray(train_shifts, dtype=float)
    global_mean = float(train_shifts.mean()) if train_shifts.size else 0.0

    # Build a prefix index: dict[prefix -> list of indices into train arrays]
    prefix_index: dict[str, list[int]] = {}
    for i, code in enumerate(train_codes):
        parts = code.split("/")
        for depth in range(1, len(parts) + 1):
            key = "/".join(parts[:depth])
            prefix_index.setdefault(key, []).append(i)

    out = np.full(len(test_codes), global_mean, dtype=float)
    for j, code in enumerate(test_codes):
        parts = code.split("/")
        # Try deepest match first
        for depth in range(len(parts), max(0, int(n_spheres_min) - 1), -1):
            key = "/".join(parts[:depth])
            hits = prefix_index.get(key)
            if hits:
                out[j] = float(train_shifts[np.array(hits)].mean())
                break
    return out


def predict_with_uncertainty_rf(
    rf: RandomForestRegressor, X_test: np.ndarray
) -> dict[str, np.ndarray]:
    """Use the per-tree predictions of a random forest to estimate uncertainty.

    Returns
    -------
    dict
        ``{"mean": np.ndarray, "std": np.ndarray}`` where std is the
        per-row standard deviation across the trees in ``rf.estimators_``.
    """
    X_test = np.asarray(X_test)
    preds = np.stack([t.predict(X_test) for t in rf.estimators_], axis=0)
    return {"mean": preds.mean(axis=0), "std": preds.std(axis=0)}

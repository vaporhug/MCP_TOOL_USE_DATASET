"""SMILES / mol parsing primitives built on RDKit.

These helpers turn a SMILES string into an ``rdkit.Chem.Mol`` and expose
per-atom property accessors that the featurisation layer consumes.  The
NMRShiftDB CSV records a ``smiles`` column plus an ``atom_idx`` integer
that indexes into the parsed molecule, so the agent can recover the local
chemical environment of every labelled nucleus.
"""

from __future__ import annotations

from typing import Any, Optional

from rdkit import Chem, RDLogger

RDLogger.DisableLog("rdApp.*")


def parse_smiles(smiles: str, sanitize: bool = True) -> Optional[Chem.Mol]:
    """Parse a SMILES string into an RDKit ``Mol``.

    Parameters
    ----------
    smiles : str
        SMILES string.
    sanitize : bool
        If True (default) RDKit sanitisation is applied.

    Returns
    -------
    rdkit.Chem.Mol or None
        ``None`` is returned when parsing fails.
    """
    try:
        return Chem.MolFromSmiles(smiles, sanitize=sanitize)
    except Exception:
        return None


def n_heavy_atoms(smiles: str) -> int:
    """Return the number of heavy (non-H) atoms in a SMILES."""
    mol = parse_smiles(smiles)
    if mol is None:
        return 0
    return mol.GetNumHeavyAtoms()


def atom_neighbors(smiles: str, atom_idx: int) -> list[str]:
    """Return the element symbols of immediate (1-bond) neighbours of an atom.

    Empty list if the SMILES fails to parse or the atom index is out of range.
    """
    mol = parse_smiles(smiles)
    if mol is None or atom_idx < 0 or atom_idx >= mol.GetNumAtoms():
        return []
    atom = mol.GetAtomWithIdx(int(atom_idx))
    return [n.GetSymbol() for n in atom.GetNeighbors()]


def atom_environment_atoms(smiles: str, atom_idx: int, radius: int = 4) -> list[int]:
    """Return atom indices within a given bond-radius of ``atom_idx``.

    Uses ``Chem.FindAtomEnvironmentOfRadiusN`` and unpacks the returned bond
    indices to atom indices.  Always includes the centre atom itself.
    """
    mol = parse_smiles(smiles)
    if mol is None or atom_idx < 0 or atom_idx >= mol.GetNumAtoms():
        return []
    bonds = Chem.FindAtomEnvironmentOfRadiusN(mol, int(radius), int(atom_idx))
    out = {int(atom_idx)}
    for bidx in bonds:
        b = mol.GetBondWithIdx(bidx)
        out.add(b.GetBeginAtomIdx())
        out.add(b.GetEndAtomIdx())
    return sorted(int(a) for a in out)


_BOND_PREFIX = {
    Chem.BondType.SINGLE: "",
    Chem.BondType.DOUBLE: "=",
    Chem.BondType.TRIPLE: "#",
    Chem.BondType.AROMATIC: "*",
}


def hose_code_string(smiles: str, atom_idx: int, max_sphere: int = 4) -> str:
    """Build a HOSE-style code for ``atom_idx`` in ``smiles``.

    The encoding is a Bremser-subset HOSE code (atom symbol + bond order
    per sphere; ring-membership and formal-charge markers are intentionally
    omitted because the full Bremser encoding over-fragments the 1H
    nearest-neighbour prefix tree on this dataset and increases test MAE):

    - Sphere 0 = the centre atom's element symbol.
    - Each successive sphere lists the new atoms reached via one
      additional bond, with each atom prefixed by its bond order to the
      previous sphere (``""`` single, ``"="`` double, ``"#"`` triple,
      ``"*"`` aromatic).
    - Atoms within a sphere are sorted alphabetically.
    - Spheres are separated by ``/`` and atoms within a sphere by ``,``.

    Returns the concatenated HOSE string for use with
    ``regression.hose_nearest_neighbour_predict``.
    """
    mol = parse_smiles(smiles)
    if mol is None or atom_idx < 0 or atom_idx >= mol.GetNumAtoms():
        return ""
    visited = {int(atom_idx)}
    centre = mol.GetAtomWithIdx(int(atom_idx))
    spheres: list[str] = [centre.GetSymbol()]
    frontier = [int(atom_idx)]
    for _ in range(int(max_sphere)):
        sphere_items: list[tuple[str, int]] = []
        for ai in frontier:
            for bond in mol.GetAtomWithIdx(ai).GetBonds():
                nbr = bond.GetOtherAtom(mol.GetAtomWithIdx(ai))
                ni = nbr.GetIdx()
                if ni in visited:
                    continue
                prefix = _BOND_PREFIX.get(bond.GetBondType(), "")
                sphere_items.append((prefix + nbr.GetSymbol(), ni))
        if not sphere_items:
            spheres.append("")
            continue
        sphere_items.sort(key=lambda x: x[0])
        spheres.append(",".join(it[0] for it in sphere_items))
        next_frontier = []
        for _, ni in sphere_items:
            visited.add(ni)
            next_frontier.append(ni)
        frontier = next_frontier
    return "/".join(spheres)


def atom_property_dict(smiles: str, atom_idx: int) -> dict[str, Any]:
    """Return a dictionary of common per-atom RDKit properties for one atom.

    Keys: element, hybridization, aromatic, in_ring, degree, total_h,
    formal_charge, n_heavy_neighbors, has_O_neighbor, has_N_neighbor,
    has_S_neighbor, has_F_neighbor, has_Cl_neighbor, has_P_neighbor.
    """
    mol = parse_smiles(smiles)
    if mol is None or atom_idx < 0 or atom_idx >= mol.GetNumAtoms():
        return {}
    a = mol.GetAtomWithIdx(int(atom_idx))
    nbr = [n.GetSymbol() for n in a.GetNeighbors()]
    return {
        "element": a.GetSymbol(),
        "hybridization": str(a.GetHybridization()),
        "aromatic": bool(a.GetIsAromatic()),
        "in_ring": bool(a.IsInRing()),
        "degree": int(a.GetDegree()),
        "total_h": int(a.GetTotalNumHs(includeNeighbors=True)),
        "formal_charge": int(a.GetFormalCharge()),
        "n_heavy_neighbors": int(sum(1 for n in nbr if n != "H")),
        "has_O_neighbor": "O" in nbr,
        "has_N_neighbor": "N" in nbr,
        "has_S_neighbor": "S" in nbr,
        "has_F_neighbor": "F" in nbr,
        "has_Cl_neighbor": "Cl" in nbr,
        "has_P_neighbor": "P" in nbr,
    }

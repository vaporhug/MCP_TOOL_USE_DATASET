"""SMILES / mol parsing primitives built on RDKit.

These helpers turn a SMILES string into an ``rdkit.Chem.Mol`` and expose
per-atom property accessors that the featurisation layer consumes.  The
NMRShiftDB CSV records a ``smiles`` column plus an ``atom_idx`` integer
that indexes into the parsed molecule, so the agent can recover the local
chemical environment of every labelled nucleus.
"""

from __future__ import annotations

from typing import Any, Optional

from rdkit import Chem, RDLogger

RDLogger.DisableLog("rdApp.*")


def parse_smiles(smiles: str, sanitize: bool = True) -> Optional[Chem.Mol]:
    """Parse a SMILES string into an RDKit ``Mol``.

    Parameters
    ----------
    smiles : str
        SMILES string.
    sanitize : bool
        If True (default) RDKit sanitisation is applied.

    Returns
    -------
    rdkit.Chem.Mol or None
        ``None`` is returned when parsing fails.
    """
    try:
        return Chem.MolFromSmiles(smiles, sanitize=sanitize)
    except Exception:
        return None


def n_heavy_atoms(smiles: str) -> int:
    """Return the number of heavy (non-H) atoms in a SMILES."""
    mol = parse_smiles(smiles)
    if mol is None:
        return 0
    return mol.GetNumHeavyAtoms()


def atom_neighbors(smiles: str, atom_idx: int) -> list[str]:
    """Return the element symbols of immediate (1-bond) neighbours of an atom.

    Empty list if the SMILES fails to parse or the atom index is out of range.
    """
    mol = parse_smiles(smiles)
    if mol is None or atom_idx < 0 or atom_idx >= mol.GetNumAtoms():
        return []
    atom = mol.GetAtomWithIdx(int(atom_idx))
    return [n.GetSymbol() for n in atom.GetNeighbors()]


def atom_environment_atoms(smiles: str, atom_idx: int, radius: int = 4) -> list[int]:
    """Return atom indices within a given bond-radius of ``atom_idx``.

    Uses ``Chem.FindAtomEnvironmentOfRadiusN`` and unpacks the returned bond
    indices to atom indices.  Always includes the centre atom itself.
    """
    mol = parse_smiles(smiles)
    if mol is None or atom_idx < 0 or atom_idx >= mol.GetNumAtoms():
        return []
    bonds = Chem.FindAtomEnvironmentOfRadiusN(mol, int(radius), int(atom_idx))
    out = {int(atom_idx)}
    for bidx in bonds:
        b = mol.GetBondWithIdx(bidx)
        out.add(b.GetBeginAtomIdx())
        out.add(b.GetEndAtomIdx())
    return sorted(int(a) for a in out)


def hose_code_string(smiles: str, atom_idx: int, max_sphere: int = 4) -> str:
    """Build a HOSE-style hierarchical environment code.

    The HOSE code is a string that lists the atom symbols in successive
    spheres around the central atom, separated by ``/``; within a sphere
    atoms are concatenated in sorted order.  This is a *simplified*
    HOSE encoding (no bond-order brackets) sufficient for nearest-neighbour
    style baselines.
    """
    mol = parse_smiles(smiles)
    if mol is None or atom_idx < 0 or atom_idx >= mol.GetNumAtoms():
        return ""
    visited = {int(atom_idx)}
    centre = mol.GetAtomWithIdx(int(atom_idx))
    spheres = [[centre.GetSymbol()]]
    frontier = {int(atom_idx)}
    for _ in range(int(max_sphere)):
        next_frontier: set[int] = set()
        for ai in frontier:
            for n in mol.GetAtomWithIdx(ai).GetNeighbors():
                if n.GetIdx() in visited:
                    continue
                next_frontier.add(n.GetIdx())
        if not next_frontier:
            spheres.append([])
            continue
        sphere_syms = sorted(mol.GetAtomWithIdx(j).GetSymbol() for j in next_frontier)
        spheres.append(sphere_syms)
        visited.update(next_frontier)
        frontier = next_frontier
    return "/".join("".join(s) for s in spheres)


def atom_property_dict(smiles: str, atom_idx: int) -> dict[str, Any]:
    """Return a dictionary of common per-atom RDKit properties for one atom.

    Keys: element, hybridization, aromatic, in_ring, degree, total_h,
    formal_charge, n_heavy_neighbors, has_O_neighbor, has_N_neighbor,
    has_S_neighbor, has_F_neighbor, has_Cl_neighbor, has_P_neighbor.
    """
    mol = parse_smiles(smiles)
    if mol is None or atom_idx < 0 or atom_idx >= mol.GetNumAtoms():
        return {}
    a = mol.GetAtomWithIdx(int(atom_idx))
    nbr = [n.GetSymbol() for n in a.GetNeighbors()]
    return {
        "element": a.GetSymbol(),
        "hybridization": str(a.GetHybridization()),
        "aromatic": bool(a.GetIsAromatic()),
        "in_ring": bool(a.IsInRing()),
        "degree": int(a.GetDegree()),
        "total_h": int(a.GetTotalNumHs(includeNeighbors=True)),
        "formal_charge": int(a.GetFormalCharge()),
        "n_heavy_neighbors": int(sum(1 for n in nbr if n != "H")),
        "has_O_neighbor": "O" in nbr,
        "has_N_neighbor": "N" in nbr,
        "has_S_neighbor": "S" in nbr,
        "has_F_neighbor": "F" in nbr,
        "has_Cl_neighbor": "Cl" in nbr,
        "has_P_neighbor": "P" in nbr,
    }

"""Matplotlib helpers for visualising NMR shift prediction results.

Every function returns ``{"path": <output_path>}`` and writes a PNG to
disk so the agent can reference the artefact from the answer manifest.
"""

from __future__ import annotations

import os
from typing import Sequence

import matplotlib

matplotlib.use("Agg")  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402


def _ensure_dir(path: str) -> None:
    parent = os.path.dirname(os.path.abspath(path))
    if parent and not os.path.isdir(parent):
        os.makedirs(parent, exist_ok=True)


def plot_predicted_vs_observed(
    y_true: Sequence[float],
    y_pred: Sequence[float],
    out_path: str,
    title: str = "",
    units: str = "ppm",
) -> dict[str, str]:
    """Scatter of predicted vs observed shift, with the y=x diagonal.

    The dynamic range of the data is used for both axes; the diagonal
    helps the agent eyeball calibration.
    """
    _ensure_dir(out_path)
    yt = np.asarray(y_true, dtype=float)
    yp = np.asarray(y_pred, dtype=float)
    fig, ax = plt.subplots(figsize=(5.5, 5.5))
    ax.scatter(yt, yp, s=4, alpha=0.25, color="#2a4d8f", edgecolors="none")
    if yt.size and yp.size:
        lo = float(min(yt.min(), yp.min())) - 1.0
        hi = float(max(yt.max(), yp.max())) + 1.0
        ax.plot([lo, hi], [lo, hi], color="black", lw=1.0, ls="--")
        ax.set_xlim(lo, hi); ax.set_ylim(lo, hi)
    ax.set_xlabel(f"observed shift ({units})")
    ax.set_ylabel(f"predicted shift ({units})")
    if title:
        ax.set_title(title)
    fig.tight_layout()
    fig.savefig(out_path, dpi=130)
    plt.close(fig)
    return {"path": out_path}


def plot_residual_histogram(
    y_true: Sequence[float],
    y_pred: Sequence[float],
    out_path: str,
    title: str = "",
    bins: int = 60,
    units: str = "ppm",
) -> dict[str, str]:
    """Histogram of (predicted - observed) residuals."""
    _ensure_dir(out_path)
    yt = np.asarray(y_true, dtype=float)
    yp = np.asarray(y_pred, dtype=float)
    res = yp - yt
    fig, ax = plt.subplots(figsize=(6.0, 4.0))
    ax.hist(res, bins=int(bins), color="#cc6633", edgecolor="white", alpha=0.85)
    ax.axvline(0.0, color="black", lw=1.0)
    ax.set_xlabel(f"residual = predicted - observed ({units})")
    ax.set_ylabel("count")
    if title:
        ax.set_title(title)
    fig.tight_layout()
    fig.savefig(out_path, dpi=130)
    plt.close(fig)
    return {"path": out_path}


def plot_error_by_category(
    error_df: pd.DataFrame,
    out_path: str,
    title: str = "",
    units: str = "ppm",
    sort_by: str = "mae",
) -> dict[str, str]:
    """Bar chart of MAE per category (output of :func:`evaluation.error_by_category`).

    The DataFrame must contain ``category``, ``mae`` and ``n`` columns.
    """
    _ensure_dir(out_path)
    df = error_df.copy()
    if df.empty:
        df = pd.DataFrame({"category": ["(no data)"], "mae": [0.0], "n": [0]})
    df = df.sort_values(sort_by, ascending=False).reset_index(drop=True)
    fig, ax = plt.subplots(figsize=(6.5, 4.5))
    ax.bar(df["category"].astype(str), df["mae"], color="#2c8770", edgecolor="black")
    for i, (m, n) in enumerate(zip(df["mae"], df["n"])):
        ax.text(i, m, f"n={int(n)}", ha="center", va="bottom", fontsize=9)
    ax.set_ylabel(f"MAE ({units})")
    ax.set_xlabel("")
    if title:
        ax.set_title(title)
    plt.setp(ax.get_xticklabels(), rotation=30, ha="right")
    fig.tight_layout()
    fig.savefig(out_path, dpi=130)
    plt.close(fig)
    return {"path": out_path}


def plot_confidence_curve(
    curve_df: pd.DataFrame,
    out_path: str,
    title: str = "",
    units: str = "ppm",
) -> dict[str, str]:
    """Line plot of MAE vs fraction of most-confident predictions retained."""
    _ensure_dir(out_path)
    df = curve_df.sort_values("fraction").reset_index(drop=True)
    fig, ax = plt.subplots(figsize=(6.0, 4.0))
    ax.plot(df["fraction"], df["mae"], marker="o", color="#1f4e79", lw=1.8)
    ax.set_xlabel("fraction of retained predictions (sorted by ascending uncertainty)")
    ax.set_ylabel(f"MAE on retained subset ({units})")
    if title:
        ax.set_title(title)
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=130)
    plt.close(fig)
    return {"path": out_path}


def plot_method_comparison(
    method_results: dict[str, float],
    out_path: str,
    title: str = "",
    units: str = "ppm",
    metric_name: str = "MAE",
) -> dict[str, str]:
    """Simple bar chart comparing a single metric across methods."""
    _ensure_dir(out_path)
    keys = list(method_results.keys())
    vals = [float(method_results[k]) for k in keys]
    fig, ax = plt.subplots(figsize=(5.5, 4.0))
    bars = ax.bar(keys, vals, color=["#1f4e79", "#cc6633", "#2c8770", "#7d3a8a"][: len(keys)],
                  edgecolor="black")
    for bar, v in zip(bars, vals):
        ax.text(bar.get_x() + bar.get_width() / 2.0, v, f"{v:.2f}",
                ha="center", va="bottom", fontsize=10)
    ax.set_ylabel(f"{metric_name} ({units})")
    if title:
        ax.set_title(title)
    fig.tight_layout()
    fig.savefig(out_path, dpi=130)
    plt.close(fig)
    return {"path": out_path}


def plot_shift_distribution(
    y: Sequence[float],
    out_path: str,
    title: str = "",
    units: str = "ppm",
    bins: int = 80,
) -> dict[str, str]:
    """Histogram of observed chemical shifts (sanity-check the dataset)."""
    _ensure_dir(out_path)
    y = np.asarray(y, dtype=float)
    fig, ax = plt.subplots(figsize=(6.0, 3.5))
    ax.hist(y, bins=int(bins), color="#1f4e79", edgecolor="white", alpha=0.85)
    ax.set_xlabel(f"observed shift ({units})")
    ax.set_ylabel("count")
    if title:
        ax.set_title(title)
    fig.tight_layout()
    fig.savefig(out_path, dpi=130)
    plt.close(fig)
    return {"path": out_path}

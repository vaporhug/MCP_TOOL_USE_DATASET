"""CSV loading and basic dataset inspection for the per-atom NMR shift tables.

Three CSVs are expected in ``input_data/data/``:

- ``nmrshiftdb_molecules.csv``  : one row per molecule (mol_id, smiles,
  n_atoms_heavy, n_shifts_13c, n_shifts_1h).
- ``nmrshiftdb_13c_atoms.csv``  : one row per labelled carbon atom with
  shift_ppm and structural descriptors of that atom.
- ``nmrshiftdb_1h_atoms.csv``   : one row per labelled heavy atom carrying
  one or more attached protons; the recorded shift is the median of all
  attached-proton shifts.

These functions only read and summarise the tables.  No domain logic.
"""

from __future__ import annotations

import os
from typing import Any

import numpy as np
import pandas as pd


def load_atom_table(path: str) -> pd.DataFrame:
    """Load a per-atom NMR shift table.

    Parameters
    ----------
    path : str
        Absolute or task-relative path to the CSV file.

    Returns
    -------
    pandas.DataFrame
        The full table with ``shift_ppm`` cast to float.
    """
    if not os.path.isfile(path):
        raise FileNotFoundError(path)
    df = pd.read_csv(path)
    if "shift_ppm" in df.columns:
        df["shift_ppm"] = pd.to_numeric(df["shift_ppm"], errors="coerce")
        df = df.dropna(subset=["shift_ppm"]).reset_index(drop=True)
    return df


def load_molecule_table(path: str) -> pd.DataFrame:
    """Load the per-molecule summary CSV (mol_id, smiles, n_atoms_heavy, ...)."""
    if not os.path.isfile(path):
        raise FileNotFoundError(path)
    return pd.read_csv(path)


def list_columns(df: pd.DataFrame) -> dict[str, str]:
    """Return ``{column: dtype_string}`` for every column in the frame."""
    return {c: str(df[c].dtype) for c in df.columns}


def shift_summary(df: pd.DataFrame, column: str = "shift_ppm") -> dict[str, float]:
    """Return ``{n, mean, std, min, q05, q50, q95, max}`` for a chemical-shift column."""
    if column not in df.columns:
        raise KeyError(column)
    y = df[column].dropna().to_numpy()
    if y.size == 0:
        return {"n": 0, "mean": float("nan"), "std": float("nan"),
                "min": float("nan"), "q05": float("nan"), "q50": float("nan"),
                "q95": float("nan"), "max": float("nan")}
    return {
        "n": int(y.size),
        "mean": float(np.mean(y)),
        "std": float(np.std(y, ddof=1)) if y.size > 1 else 0.0,
        "min": float(np.min(y)),
        "q05": float(np.quantile(y, 0.05)),
        "q50": float(np.quantile(y, 0.50)),
        "q95": float(np.quantile(y, 0.95)),
        "max": float(np.max(y)),
    }


def count_unique_molecules(df: pd.DataFrame) -> int:
    """Return the number of distinct molecules in the table (by ``mol_id``)."""
    if "mol_id" not in df.columns:
        raise KeyError("mol_id column missing")
    return int(df["mol_id"].nunique())


def count_atoms_per_molecule(df: pd.DataFrame) -> pd.Series:
    """Return a Series indexed by mol_id giving the number of labelled atoms."""
    if "mol_id" not in df.columns:
        raise KeyError("mol_id column missing")
    return df.groupby("mol_id").size().rename("n_labelled_atoms")


def molecule_size_distribution(mol_df: pd.DataFrame, n_bins: int = 32) -> dict[str, list]:
    """Return histogram ``{bin_edges, counts}`` of n_atoms_heavy."""
    if "n_atoms_heavy" not in mol_df.columns:
        raise KeyError("n_atoms_heavy")
    counts, edges = np.histogram(mol_df["n_atoms_heavy"].to_numpy(), bins=int(n_bins))
    return {"bin_edges": [float(e) for e in edges],
            "counts": [int(c) for c in counts]}


def atoms_by_element(df: pd.DataFrame) -> dict[str, int]:
    """Return ``{element_symbol: count}`` aggregating over the table.

    Falls back to ``parent_element`` for 1H tables.
    """
    if "element" in df.columns:
        return {str(k): int(v) for k, v in df["element"].value_counts().items()}
    if "parent_element" in df.columns:
        return {str(k): int(v) for k, v in df["parent_element"].value_counts().items()}
    return {}


def shift_range_by_hybridization(df: pd.DataFrame) -> pd.DataFrame:
    """Aggregate shift mean / std by hybridisation column.

    Looks up ``hybridization`` (13C table) or ``parent_hybridization`` (1H table).
    """
    col = "hybridization" if "hybridization" in df.columns else (
        "parent_hybridization" if "parent_hybridization" in df.columns else None
    )
    if col is None or "shift_ppm" not in df.columns:
        return pd.DataFrame()
    g = df.groupby(col)["shift_ppm"].agg(["count", "mean", "std", "min", "max"])
    return g.reset_index()

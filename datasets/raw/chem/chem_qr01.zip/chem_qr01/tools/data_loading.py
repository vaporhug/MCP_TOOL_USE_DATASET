"""Tools for loading ChEMBL compound datasets and scaffold split indices."""

import json
import pandas as pd
from typing import Dict, List, Tuple


def load_compound_csv(csv_path: str) -> pd.DataFrame:
    """Load a ChEMBL compound CSV file containing SMILES and bioactivity data.

    Parameters
    ----------
    csv_path : str
        Path to a CSV file with columns including 'Compound_ID', 'Smiles',
        'pChEMBL Value', etc.

    Returns
    -------
    pd.DataFrame
        DataFrame with compound data.
    """
    df = pd.read_csv(csv_path)
    required = ["Compound_ID", "Smiles", "pChEMBL Value"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    return df


def load_scaffold_split(json_path: str) -> Dict[str, List[int]]:
    """Load scaffold split indices from a JSON file.

    Parameters
    ----------
    json_path : str
        Path to JSON file with keys 'train_idx', 'test_idx', and
        optionally 'val_idx'.

    Returns
    -------
    dict
        Dictionary mapping split names to lists of integer indices.
    """
    with open(json_path, "r") as f:
        data = json.load(f)
    return data


def get_smiles_and_targets(df: pd.DataFrame) -> Tuple[List[str], List[float]]:
    """Extract SMILES strings and pChEMBL target values from a DataFrame.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame with 'Smiles' and 'pChEMBL Value' columns.

    Returns
    -------
    tuple
        (list of SMILES strings, list of pChEMBL float values)
    """
    smiles = df["Smiles"].tolist()
    targets = df["pChEMBL Value"].astype(float).tolist()
    return smiles, targets


def list_datasets(data_dir: str) -> List[str]:
    """List available ChEMBL dataset IDs found in a data directory.

    Looks for files matching the pattern '<ID>_compounds.csv'.

    Parameters
    ----------
    data_dir : str
        Path to directory containing compound CSV files.

    Returns
    -------
    list of str
        Sorted list of dataset identifiers (e.g. ['CHEMBL278', 'CHEMBL2734']).
    """
    import os
    ids = []
    for fname in os.listdir(data_dir):
        if fname.endswith("_compounds.csv"):
            ids.append(fname.replace("_compounds.csv", ""))
    return sorted(ids)

"""Tools for statistical comparison of model performances across datasets."""

import numpy as np
from scipy import stats
from typing import Dict, List, Tuple


def paired_t_test(
    scores_a: List[float],
    scores_b: List[float],
) -> Dict[str, float]:
    """Perform a paired t-test comparing two models across datasets.

    Parameters
    ----------
    scores_a : list of float
        Per-dataset scores for model A.
    scores_b : list of float
        Per-dataset scores for model B.

    Returns
    -------
    dict
        Keys: 't_statistic', 'p_value', 'mean_diff', 'n_datasets'.
    """
    a = np.array(scores_a)
    b = np.array(scores_b)
    t_stat, p_val = stats.ttest_rel(a, b)
    return {
        "t_statistic": float(t_stat),
        "p_value": float(p_val),
        "mean_diff": float(np.mean(a - b)),
        "n_datasets": len(a),
    }


def wilcoxon_signed_rank_test(
    scores_a: List[float],
    scores_b: List[float],
) -> Dict[str, float]:
    """Perform Wilcoxon signed-rank test (non-parametric paired test).

    Parameters
    ----------
    scores_a : list of float
        Per-dataset scores for model A.
    scores_b : list of float
        Per-dataset scores for model B.

    Returns
    -------
    dict
        Keys: 'statistic', 'p_value', 'median_diff'.
    """
    a = np.array(scores_a)
    b = np.array(scores_b)
    stat, p_val = stats.wilcoxon(a, b)
    return {
        "statistic": float(stat),
        "p_value": float(p_val),
        "median_diff": float(np.median(a - b)),
    }


def compute_win_rate(
    scores_a: List[float],
    scores_b: List[float],
    higher_is_better: bool = True,
) -> Dict[str, object]:
    """Compute the fraction of datasets where model A beats model B.

    Parameters
    ----------
    scores_a : list of float
        Per-dataset scores for model A.
    scores_b : list of float
        Per-dataset scores for model B.
    higher_is_better : bool
        If True, A wins when score_a > score_b (e.g. Spearman).
        If False, A wins when score_a < score_b (e.g. NRMSE).

    Returns
    -------
    dict
        Keys: 'win_rate_a' (float), 'wins_a' (int), 'wins_b' (int),
        'ties' (int), 'n_datasets' (int).
    """
    a = np.array(scores_a)
    b = np.array(scores_b)
    if higher_is_better:
        wins_a = int(np.sum(a > b))
        wins_b = int(np.sum(b > a))
    else:
        wins_a = int(np.sum(a < b))
        wins_b = int(np.sum(b < a))
    ties = len(a) - wins_a - wins_b
    return {
        "win_rate_a": wins_a / len(a) if len(a) > 0 else 0.0,
        "wins_a": wins_a,
        "wins_b": wins_b,
        "ties": ties,
        "n_datasets": len(a),
    }

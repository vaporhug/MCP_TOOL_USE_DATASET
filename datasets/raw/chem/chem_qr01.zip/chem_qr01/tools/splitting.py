"""Tools for creating train/test splits: random k-fold CV and scaffold-based."""

import numpy as np
from typing import List, Tuple, Dict
from rdkit import Chem
from rdkit.Chem.Scaffolds import MurckoScaffold
from collections import defaultdict


def random_kfold_split(
    n_samples: int,
    n_folds: int = 5,
    random_seed: int = 42,
) -> List[Tuple[np.ndarray, np.ndarray]]:
    """Generate random k-fold cross-validation splits.

    Parameters
    ----------
    n_samples : int
        Total number of samples.
    n_folds : int
        Number of folds (default 5).
    random_seed : int
        Random seed for reproducibility.

    Returns
    -------
    list of (train_indices, test_indices) tuples
        Each element is a tuple of numpy arrays with integer indices.
    """
    rng = np.random.RandomState(random_seed)
    indices = np.arange(n_samples)
    rng.shuffle(indices)
    fold_sizes = np.full(n_folds, n_samples // n_folds, dtype=int)
    fold_sizes[: n_samples % n_folds] += 1
    folds = []
    current = 0
    for size in fold_sizes:
        test_idx = indices[current : current + size]
        train_idx = np.concatenate([indices[:current], indices[current + size :]])
        folds.append((train_idx, test_idx))
        current += size
    return folds


def scaffold_split(
    smiles_list: List[str],
    test_fraction: float = 0.2,
    random_seed: int = 42,
) -> Tuple[np.ndarray, np.ndarray]:
    """Split molecules by Murcko scaffold so train and test have different scaffolds.

    Parameters
    ----------
    smiles_list : list of str
        SMILES strings for all molecules.
    test_fraction : float
        Approximate fraction of data to put in test set (default 0.2).
    random_seed : int
        Random seed for shuffling scaffold groups.

    Returns
    -------
    tuple
        (train_indices, test_indices) as numpy arrays.
    """
    scaffold_map = defaultdict(list)
    for i, smi in enumerate(smiles_list):
        mol = Chem.MolFromSmiles(smi)
        if mol is not None:
            scaffold = MurckoScaffold.MurckoScaffoldSmiles(
                mol=mol, includeChirality=False
            )
            scaffold_map[scaffold].append(i)
        else:
            scaffold_map["INVALID"].append(i)

    rng = np.random.RandomState(random_seed)
    scaffold_groups = list(scaffold_map.values())
    rng.shuffle(scaffold_groups)

    test_size = int(len(smiles_list) * test_fraction)
    train_idx, test_idx = [], []
    for group in scaffold_groups:
        if len(test_idx) < test_size:
            test_idx.extend(group)
        else:
            train_idx.extend(group)

    return np.array(train_idx), np.array(test_idx)


def apply_predefined_split(
    split_dict: Dict[str, List],
    compound_ids: List[str] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    """Apply a predefined scaffold split from loaded JSON indices.

    The bundled split JSON files key the train/val/test members by
    ``Compound_ID`` strings (e.g. ``'CHEMBL389844'``), not by integer row
    numbers. Pass ``compound_ids`` (the ``Compound_ID`` column of the matching
    compounds CSV, in row order) and this function maps each ID to its
    positional row index so the returned arrays can be used to slice the
    feature/target matrices directly. If the split entries are already
    integers (or ``compound_ids`` is omitted), they are returned as-is.

    Parameters
    ----------
    split_dict : dict
        Dictionary with 'train_idx' and 'test_idx' keys (optionally
        'val_idx') mapping to lists of Compound_ID strings or integer indices.
    compound_ids : list of str, optional
        The Compound_ID values in CSV row order. Required when the split
        entries are Compound_ID strings.

    Returns
    -------
    tuple
        (train_indices, test_indices) as integer numpy arrays of row numbers.
    """
    def _to_row_indices(members):
        members = list(members)
        if len(members) == 0:
            return np.array([], dtype=int)
        # Already integer row indices -> pass through.
        if all(isinstance(m, (int, np.integer)) for m in members):
            return np.array(members, dtype=int)
        if compound_ids is None:
            raise ValueError(
                "Split entries are Compound_ID strings; pass compound_ids "
                "(the CSV Compound_ID column in row order) to map them."
            )
        id_to_row = {cid: i for i, cid in enumerate(compound_ids)}
        missing = [m for m in members if m not in id_to_row]
        if missing:
            raise KeyError(
                f"{len(missing)} split Compound_IDs not found in compound_ids "
                f"(e.g. {missing[:3]})."
            )
        return np.array([id_to_row[m] for m in members], dtype=int)

    train_idx = _to_row_indices(split_dict["train_idx"])
    test_idx = _to_row_indices(split_dict["test_idx"])
    return train_idx, test_idx

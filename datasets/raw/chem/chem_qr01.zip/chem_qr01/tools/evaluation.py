"""Tools for cross-validation evaluation loops across datasets."""

import numpy as np
from typing import Dict, List, Callable, Tuple
import pandas as pd


def cross_validate_model(
    X: np.ndarray,
    y: np.ndarray,
    folds: List[Tuple[np.ndarray, np.ndarray]],
    train_fn: Callable,
    metric_fn: Callable,
) -> List[Dict[str, float]]:
    """Run cross-validation for a model over pre-defined folds.

    Parameters
    ----------
    X : np.ndarray
        Feature matrix of shape (n_samples, n_features).
    y : np.ndarray
        Target array of shape (n_samples,).
    folds : list of (train_idx, test_idx) tuples
        Pre-computed fold indices.
    train_fn : callable
        Function(X_train, y_train) -> fitted model with .predict() method.
    metric_fn : callable
        Function(y_true, y_pred) -> dict of metric_name: value.

    Returns
    -------
    list of dict
        One metrics dictionary per fold.
    """
    results = []
    for train_idx, test_idx in folds:
        X_train, X_test = X[train_idx], X[test_idx]
        y_train, y_test = y[train_idx], y[test_idx]
        model = train_fn(X_train, y_train)
        y_pred = model.predict(X_test)
        metrics = metric_fn(y_test, y_pred)
        results.append(metrics)
    return results


def average_cv_metrics(fold_results: List[Dict[str, float]]) -> Dict[str, float]:
    """Average metrics across cross-validation folds.

    Parameters
    ----------
    fold_results : list of dict
        List of per-fold metric dictionaries (all with the same keys).

    Returns
    -------
    dict
        Mean value for each metric across folds.
    """
    keys = fold_results[0].keys()
    return {k: float(np.mean([r[k] for r in fold_results])) for k in keys}


def evaluate_on_split(
    X: np.ndarray,
    y: np.ndarray,
    train_idx: np.ndarray,
    test_idx: np.ndarray,
    train_fn: Callable,
    metric_fn: Callable,
) -> Dict[str, float]:
    """Evaluate a model on a single predefined train/test split.

    Parameters
    ----------
    X : np.ndarray
        Feature matrix.
    y : np.ndarray
        Target array.
    train_idx : np.ndarray
        Training indices.
    test_idx : np.ndarray
        Test indices.
    train_fn : callable
        Training function returning fitted model.
    metric_fn : callable
        Metric computation function.

    Returns
    -------
    dict
        Metrics on the test set.
    """
    model = train_fn(X[train_idx], y[train_idx])
    y_pred = model.predict(X[test_idx])
    return metric_fn(y[test_idx], y_pred)


def multi_dataset_evaluation(
    dataset_results: Dict[str, Dict[str, float]],
) -> pd.DataFrame:
    """Compile per-dataset results into a summary DataFrame.

    Parameters
    ----------
    dataset_results : dict
        Mapping of dataset_id -> {metric_name: value}.

    Returns
    -------
    pd.DataFrame
        DataFrame with datasets as rows and metrics as columns,
        plus a 'Mean' row.
    """
    df = pd.DataFrame(dataset_results).T
    df.index.name = "dataset"
    mean_row = df.mean()
    mean_row.name = "Mean"
    df = pd.concat([df, mean_row.to_frame().T])
    return df

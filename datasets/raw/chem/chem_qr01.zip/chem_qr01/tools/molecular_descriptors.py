"""Tools for computing molecular descriptors from SMILES strings."""

import numpy as np
from typing import List, Optional, Dict
from rdkit import Chem
from rdkit.Chem import Descriptors


# Standard RDKit 2D descriptor set
_DESCRIPTOR_FUNCS = {
    "MolWt": Descriptors.MolWt,
    "MolLogP": Descriptors.MolLogP,
    "NumHDonors": Descriptors.NumHDonors,
    "NumHAcceptors": Descriptors.NumHAcceptors,
    "NumRotatableBonds": Descriptors.NumRotatableBonds,
    "NumHeavyAtoms": Descriptors.HeavyAtomCount,
    "NumAtoms": lambda m: m.GetNumAtoms(),
    "TPSA": Descriptors.TPSA,
    "MolMR": Descriptors.MolMR,
    "NumRings": Descriptors.RingCount,
    "NumAromaticRings": Descriptors.NumAromaticRings,
    "FractionCSP3": Descriptors.FractionCSP3,
    "HallKierAlpha": Descriptors.HallKierAlpha,
    "BalabanJ": Descriptors.BalabanJ,
    "BertzCT": Descriptors.BertzCT,
    "Chi0": Descriptors.Chi0,
    "Chi1": Descriptors.Chi1,
    "Kappa1": Descriptors.Kappa1,
    "Kappa2": Descriptors.Kappa2,
    "Kappa3": Descriptors.Kappa3,
    "LabuteASA": Descriptors.LabuteASA,
    "MaxPartialCharge": Descriptors.MaxPartialCharge,
    "MinPartialCharge": Descriptors.MinPartialCharge,
}


def compute_descriptors(
    smiles_list: List[str],
    descriptor_names: Optional[List[str]] = None,
) -> np.ndarray:
    """Compute RDKit 2D molecular descriptors for a list of SMILES.

    Parameters
    ----------
    smiles_list : list of str
        SMILES strings.
    descriptor_names : list of str, optional
        Subset of descriptor names to compute. If None, all 23 standard
        descriptors are computed.

    Returns
    -------
    np.ndarray
        Array of shape (n_molecules, n_descriptors). NaN for invalid SMILES.
    """
    if descriptor_names is None:
        descriptor_names = list(_DESCRIPTOR_FUNCS.keys())

    results = []
    for smi in smiles_list:
        mol = Chem.MolFromSmiles(smi)
        if mol is None:
            results.append([np.nan] * len(descriptor_names))
        else:
            row = []
            for name in descriptor_names:
                try:
                    val = _DESCRIPTOR_FUNCS[name](mol)
                    row.append(float(val))
                except Exception:
                    row.append(np.nan)
            results.append(row)
    return np.array(results, dtype=float)


def get_descriptor_names() -> List[str]:
    """Return the list of available descriptor names.

    Returns
    -------
    list of str
        Names of all available molecular descriptors.
    """
    return list(_DESCRIPTOR_FUNCS.keys())


def filter_valid_molecules(
    smiles_list: List[str],
) -> Dict[str, object]:
    """Identify valid and invalid SMILES from a list.

    Parameters
    ----------
    smiles_list : list of str
        SMILES strings to validate.

    Returns
    -------
    dict
        Keys: 'valid_indices' (list of int), 'invalid_indices' (list of int),
        'n_valid' (int), 'n_invalid' (int).
    """
    valid = []
    invalid = []
    for i, smi in enumerate(smiles_list):
        mol = Chem.MolFromSmiles(smi)
        if mol is not None:
            valid.append(i)
        else:
            invalid.append(i)
    return {
        "valid_indices": valid,
        "invalid_indices": invalid,
        "n_valid": len(valid),
        "n_invalid": len(invalid),
    }

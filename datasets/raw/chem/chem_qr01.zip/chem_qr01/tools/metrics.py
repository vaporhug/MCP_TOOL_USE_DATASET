"""Tools for computing regression evaluation metrics."""

import numpy as np
from scipy import stats
from typing import Dict


def compute_rmse(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Compute Root Mean Square Error.

    Parameters
    ----------
    y_true : np.ndarray
        True target values.
    y_pred : np.ndarray
        Predicted values.

    Returns
    -------
    float
        RMSE value.
    """
    return float(np.sqrt(np.mean((y_true - y_pred) ** 2)))


def compute_nrmse(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Compute Normalized Root Mean Square Error.

    NRMSE = RMSE / std(y_true), as used in the paper to normalize
    across datasets with different activity ranges.

    Parameters
    ----------
    y_true : np.ndarray
        True target values.
    y_pred : np.ndarray
        Predicted values.

    Returns
    -------
    float
        NRMSE value. Lower is better.
    """
    rmse = np.sqrt(np.mean((y_true - y_pred) ** 2))
    std = np.std(y_true, ddof=0)
    if std == 0:
        return float("inf")
    return float(rmse / std)


def compute_r2(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Compute coefficient of determination (R-squared).

    Parameters
    ----------
    y_true : np.ndarray
        True target values.
    y_pred : np.ndarray
        Predicted values.

    Returns
    -------
    float
        R-squared value. 1.0 is perfect prediction.
    """
    ss_res = np.sum((y_true - y_pred) ** 2)
    ss_tot = np.sum((y_true - np.mean(y_true)) ** 2)
    if ss_tot == 0:
        return 0.0
    return float(1.0 - ss_res / ss_tot)


def compute_mae(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Compute Mean Absolute Error.

    Parameters
    ----------
    y_true : np.ndarray
        True target values.
    y_pred : np.ndarray
        Predicted values.

    Returns
    -------
    float
        MAE value.
    """
    return float(np.mean(np.abs(y_true - y_pred)))


def compute_spearman(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Compute Spearman rank correlation coefficient.

    This is the primary metric used in the paper for comparing model
    performance across ChEMBL datasets.

    Parameters
    ----------
    y_true : np.ndarray
        True target values.
    y_pred : np.ndarray
        Predicted values.

    Returns
    -------
    float
        Spearman rho. Higher is better.
    """
    rho, _ = stats.spearmanr(y_true, y_pred)
    return float(rho)


def compute_all_metrics(
    y_true: np.ndarray, y_pred: np.ndarray
) -> Dict[str, float]:
    """Compute all regression metrics at once.

    Parameters
    ----------
    y_true : np.ndarray
        True target values.
    y_pred : np.ndarray
        Predicted values.

    Returns
    -------
    dict
        Keys: 'rmse', 'nrmse', 'r2', 'mae', 'spearman'.
    """
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    return {
        "rmse": compute_rmse(y_true, y_pred),
        "nrmse": compute_nrmse(y_true, y_pred),
        "r2": compute_r2(y_true, y_pred),
        "mae": compute_mae(y_true, y_pred),
        "spearman": compute_spearman(y_true, y_pred),
    }

"""Tools for training regression models (Random Forest, XGBoost, KNN)."""

import numpy as np
from typing import Dict, Optional


def train_random_forest(
    X_train: np.ndarray,
    y_train: np.ndarray,
    n_estimators: int = 500,
    max_features: str = "sqrt",
    random_seed: int = 42,
) -> object:
    """Train a Random Forest regressor.

    Parameters
    ----------
    X_train : np.ndarray
        Training features of shape (n_train, n_features).
    y_train : np.ndarray
        Training targets of shape (n_train,).
    n_estimators : int
        Number of trees (default 500).
    max_features : str
        Feature subset strategy (default 'sqrt').
    random_seed : int
        Random state.

    Returns
    -------
    sklearn.ensemble.RandomForestRegressor
        Fitted model.
    """
    from sklearn.ensemble import RandomForestRegressor

    model = RandomForestRegressor(
        n_estimators=n_estimators,
        max_features=max_features,
        random_state=random_seed,
        n_jobs=-1,
    )
    model.fit(X_train, y_train)
    return model


def train_xgboost(
    X_train: np.ndarray,
    y_train: np.ndarray,
    n_estimators: int = 500,
    max_depth: int = 6,
    learning_rate: float = 0.1,
    random_seed: int = 42,
) -> object:
    """Train an XGBoost regressor.

    Parameters
    ----------
    X_train : np.ndarray
        Training features of shape (n_train, n_features).
    y_train : np.ndarray
        Training targets of shape (n_train,).
    n_estimators : int
        Number of boosting rounds.
    max_depth : int
        Maximum tree depth.
    learning_rate : float
        Step size shrinkage.
    random_seed : int
        Random state.

    Returns
    -------
    xgboost.XGBRegressor
        Fitted model.
    """
    from xgboost import XGBRegressor

    model = XGBRegressor(
        n_estimators=n_estimators,
        max_depth=max_depth,
        learning_rate=learning_rate,
        random_state=random_seed,
        n_jobs=-1,
        verbosity=0,
    )
    model.fit(X_train, y_train)
    return model


def train_knn_regressor(
    X_train: np.ndarray,
    y_train: np.ndarray,
    n_neighbors: int = 5,
    metric: str = "minkowski",
) -> object:
    """Train a k-Nearest Neighbors regressor.

    Parameters
    ----------
    X_train : np.ndarray
        Training features of shape (n_train, n_features).
    y_train : np.ndarray
        Training targets of shape (n_train,).
    n_neighbors : int
        Number of neighbors (default 5).
    metric : str
        Distance metric (default 'minkowski').

    Returns
    -------
    sklearn.neighbors.KNeighborsRegressor
        Fitted model.
    """
    from sklearn.neighbors import KNeighborsRegressor

    model = KNeighborsRegressor(n_neighbors=n_neighbors, metric=metric, n_jobs=-1)
    model.fit(X_train, y_train)
    return model


def predict(model: object, X_test: np.ndarray) -> np.ndarray:
    """Generate predictions from a fitted regression model.

    Parameters
    ----------
    model : fitted sklearn/xgboost model
        Model with a .predict() method.
    X_test : np.ndarray
        Test features of shape (n_test, n_features).

    Returns
    -------
    np.ndarray
        Predicted values of shape (n_test,).
    """
    return model.predict(X_test)


def get_feature_importances(
    model: object,
    feature_names: Optional[list] = None,
) -> Dict[str, float]:
    """Extract feature importances from a tree-based model.

    Parameters
    ----------
    model : fitted model
        Must have a .feature_importances_ attribute (RF or XGBoost).
    feature_names : list of str, optional
        Names for each feature. If None, uses integer indices.

    Returns
    -------
    dict
        Mapping of feature name to importance value, sorted descending.
    """
    importances = model.feature_importances_
    if feature_names is None:
        feature_names = [str(i) for i in range(len(importances))]
    imp_dict = dict(zip(feature_names, importances))
    return dict(sorted(imp_dict.items(), key=lambda x: x[1], reverse=True))

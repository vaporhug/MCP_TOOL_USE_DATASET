"""Tools for plotting dataset summary statistics."""

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from typing import Dict, List


def plot_activity_distribution(
    activities: List[float],
    dataset_name: str,
    output_path: str,
    n_bins: int = 30,
    figsize: tuple = (7, 4),
) -> Dict[str, str]:
    """Plot histogram of pChEMBL activity values for a dataset.

    Parameters
    ----------
    activities : list of float
        pChEMBL values for all compounds.
    dataset_name : str
        Dataset identifier for the title.
    output_path : str
        File path to save the figure.
    n_bins : int
        Number of histogram bins.
    figsize : tuple
        Figure size.

    Returns
    -------
    dict
        {"path": output_path}
    """
    fig, ax = plt.subplots(figsize=figsize)
    ax.hist(activities, bins=n_bins, edgecolor="black", alpha=0.7, color="steelblue")
    ax.set_xlabel("pChEMBL Value")
    ax.set_ylabel("Count")
    ax.set_title(f"Activity Distribution: {dataset_name}")
    ax.axvline(np.mean(activities), color="red", linestyle="--",
               label=f"Mean = {np.mean(activities):.2f}")
    ax.legend()
    plt.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"path": output_path}


def plot_multi_dataset_summary(
    dataset_stats: Dict[str, Dict[str, float]],
    output_path: str,
    figsize: tuple = (10, 5),
) -> Dict[str, str]:
    """Plot summary bar chart of dataset sizes and activity ranges.

    Parameters
    ----------
    dataset_stats : dict
        Mapping dataset_id -> {'n_compounds': int, 'mean_activity': float,
        'std_activity': float}.
    output_path : str
        File path to save the figure.
    figsize : tuple
        Figure size.

    Returns
    -------
    dict
        {"path": output_path}
    """
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=figsize)

    names = list(dataset_stats.keys())
    n_compounds = [dataset_stats[n]["n_compounds"] for n in names]
    means = [dataset_stats[n]["mean_activity"] for n in names]
    stds = [dataset_stats[n]["std_activity"] for n in names]

    ax1.bar(names, n_compounds, color="steelblue")
    ax1.set_ylabel("Number of Compounds")
    ax1.set_title("Dataset Sizes")
    ax1.tick_params(axis="x", rotation=45)

    ax2.bar(names, means, yerr=stds, capsize=4, color="coral")
    ax2.set_ylabel("pChEMBL Value")
    ax2.set_title("Mean Activity (with std)")
    ax2.tick_params(axis="x", rotation=45)

    plt.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"path": output_path}

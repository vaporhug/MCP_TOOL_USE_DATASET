"""Tools for computing molecular fingerprints from SMILES strings."""

import numpy as np
from typing import List
from rdkit import Chem
from rdkit.Chem import AllChem, DataStructs


def compute_ecfp4(
    smiles_list: List[str],
    n_bits: int = 1024,
    radius: int = 2,
) -> np.ndarray:
    """Compute folded ECFP4 (Morgan) fingerprints for a list of SMILES.

    Uses RDKit's Morgan algorithm with the specified radius and bit-size,
    matching the protocol in the paper (radius=2, 1024 bits by default).

    Parameters
    ----------
    smiles_list : list of str
        SMILES strings.
    n_bits : int
        Length of the folded bit-vector (default 1024).
    radius : int
        Radius for the Morgan algorithm (default 2 for ECFP4).

    Returns
    -------
    np.ndarray
        Binary array of shape (n_molecules, n_bits). Rows of zeros for
        invalid SMILES.
    """
    fp_array = np.zeros((len(smiles_list), n_bits), dtype=np.int8)
    for i, smi in enumerate(smiles_list):
        mol = Chem.MolFromSmiles(smi)
        if mol is not None:
            fp = AllChem.GetMorganFingerprintAsBitVect(mol, radius, nBits=n_bits)
            arr = np.zeros(n_bits, dtype=np.int8)
            DataStructs.ConvertToNumpyArray(fp, arr)
            fp_array[i] = arr
    return fp_array


def compute_tanimoto_distance_matrix(fp_array: np.ndarray) -> np.ndarray:
    """Compute pairwise Tanimoto distance matrix from binary fingerprints.

    Tanimoto distance = 1 - Tanimoto coefficient, as used in the paper
    for the topological regression distance input.

    Parameters
    ----------
    fp_array : np.ndarray
        Binary fingerprint array of shape (n, n_bits).

    Returns
    -------
    np.ndarray
        Symmetric distance matrix of shape (n, n).
    """
    n = fp_array.shape[0]
    dist = np.zeros((n, n), dtype=np.float64)
    for i in range(n):
        for j in range(i + 1, n):
            intersection = np.sum(fp_array[i] & fp_array[j])
            union = np.sum(fp_array[i] | fp_array[j])
            tc = intersection / union if union > 0 else 0.0
            d = 1.0 - tc
            dist[i, j] = d
            dist[j, i] = d
    return dist


def compute_maccs_keys(smiles_list: List[str]) -> np.ndarray:
    """Compute MACCS structural key fingerprints.

    Parameters
    ----------
    smiles_list : list of str
        SMILES strings.

    Returns
    -------
    np.ndarray
        Binary array of shape (n_molecules, 167).
    """
    from rdkit.Chem import MACCSkeys
    n_bits = 167
    fp_array = np.zeros((len(smiles_list), n_bits), dtype=np.int8)
    for i, smi in enumerate(smiles_list):
        mol = Chem.MolFromSmiles(smi)
        if mol is not None:
            fp = MACCSkeys.GenMACCSKeys(mol)
            arr = np.zeros(n_bits, dtype=np.int8)
            DataStructs.ConvertToNumpyArray(fp, arr)
            fp_array[i] = arr
    return fp_array

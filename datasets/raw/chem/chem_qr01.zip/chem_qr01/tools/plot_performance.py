"""Tools for plotting model performance comparisons."""

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from typing import Dict, List, Optional


def plot_model_comparison_bar(
    model_metrics: Dict[str, Dict[str, float]],
    metric_name: str,
    title: str,
    output_path: str,
    figsize: tuple = (8, 5),
) -> Dict[str, str]:
    """Create a grouped bar chart comparing models on a specific metric.

    Parameters
    ----------
    model_metrics : dict
        Mapping of model_name -> {dataset_id: metric_value}.
    metric_name : str
        Name of the metric being plotted (used in y-axis label).
    title : str
        Plot title.
    output_path : str
        File path to save the figure.
    figsize : tuple
        Figure size in inches.

    Returns
    -------
    dict
        {"path": output_path}
    """
    fig, ax = plt.subplots(figsize=figsize)
    model_names = list(model_metrics.keys())
    datasets = list(next(iter(model_metrics.values())).keys())
    n_models = len(model_names)
    n_datasets = len(datasets)
    x = np.arange(n_datasets)
    width = 0.8 / n_models

    for i, model_name in enumerate(model_names):
        values = [model_metrics[model_name][ds] for ds in datasets]
        offset = (i - n_models / 2 + 0.5) * width
        ax.bar(x + offset, values, width, label=model_name)

    ax.set_xlabel("Dataset")
    ax.set_ylabel(metric_name)
    ax.set_title(title)
    ax.set_xticks(x)
    ax.set_xticklabels(datasets, rotation=45, ha="right")
    ax.legend()
    plt.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"path": output_path}


def plot_boxplot_comparison(
    model_scores: Dict[str, List[float]],
    metric_name: str,
    title: str,
    output_path: str,
    figsize: tuple = (8, 5),
) -> Dict[str, str]:
    """Create a box plot comparing distributions of per-dataset scores.

    Replicates the style of Figure 2 in the paper, showing boxplots
    of per-dataset Spearman or NRMSE across models.

    Parameters
    ----------
    model_scores : dict
        Mapping of model_name -> list of per-dataset metric values.
    metric_name : str
        Name of the metric (for y-axis label).
    title : str
        Plot title.
    output_path : str
        File path to save the figure.
    figsize : tuple
        Figure size in inches.

    Returns
    -------
    dict
        {"path": output_path}
    """
    fig, ax = plt.subplots(figsize=figsize)
    labels = list(model_scores.keys())
    data = [model_scores[lbl] for lbl in labels]

    bp = ax.boxplot(data, labels=labels, patch_artist=True, showmeans=True)
    colors = plt.cm.Set2(np.linspace(0, 1, len(labels)))
    for patch, color in zip(bp["boxes"], colors):
        patch.set_facecolor(color)

    ax.set_ylabel(metric_name)
    ax.set_title(title)
    plt.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"path": output_path}


def plot_scatter_predicted_vs_actual(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    title: str,
    output_path: str,
    figsize: tuple = (6, 6),
) -> Dict[str, str]:
    """Scatter plot of predicted vs actual values with identity line.

    Parameters
    ----------
    y_true : np.ndarray
        True target values.
    y_pred : np.ndarray
        Predicted values.
    title : str
        Plot title.
    output_path : str
        File path to save the figure.
    figsize : tuple
        Figure size.

    Returns
    -------
    dict
        {"path": output_path}
    """
    fig, ax = plt.subplots(figsize=figsize)
    ax.scatter(y_true, y_pred, alpha=0.6, edgecolors="k", linewidth=0.3)
    lims = [
        min(np.min(y_true), np.min(y_pred)) - 0.2,
        max(np.max(y_true), np.max(y_pred)) + 0.2,
    ]
    ax.plot(lims, lims, "r--", linewidth=1, label="y = x")
    ax.set_xlabel("Actual pChEMBL Value")
    ax.set_ylabel("Predicted pChEMBL Value")
    ax.set_title(title)
    ax.legend()
    plt.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"path": output_path}

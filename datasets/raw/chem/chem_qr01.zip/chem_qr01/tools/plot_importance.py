"""Tools for plotting feature/descriptor importance."""

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from typing import Dict, Optional


def plot_feature_importance(
    importance_dict: Dict[str, float],
    top_n: int = 20,
    title: str = "Feature Importance",
    output_path: str = "feature_importance.png",
    figsize: tuple = (8, 6),
) -> Dict[str, str]:
    """Create a horizontal bar chart of top feature importances.

    Parameters
    ----------
    importance_dict : dict
        Mapping of feature_name -> importance_value (pre-sorted or not).
    top_n : int
        Number of top features to display (default 20).
    title : str
        Plot title.
    output_path : str
        File path to save the figure.
    figsize : tuple
        Figure size in inches.

    Returns
    -------
    dict
        {"path": output_path}
    """
    sorted_items = sorted(importance_dict.items(), key=lambda x: x[1], reverse=True)
    top_items = sorted_items[:top_n]
    names = [item[0] for item in reversed(top_items)]
    values = [item[1] for item in reversed(top_items)]

    fig, ax = plt.subplots(figsize=figsize)
    ax.barh(names, values, color="steelblue")
    ax.set_xlabel("Importance")
    ax.set_title(title)
    plt.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"path": output_path}


def plot_fingerprint_bit_importance(
    importance_dict: Dict[str, float],
    top_n: int = 30,
    title: str = "Top ECFP4 Bit Importances",
    output_path: str = "fp_bit_importance.png",
    figsize: tuple = (10, 6),
) -> Dict[str, str]:
    """Create a bar chart showing most important fingerprint bits.

    Parameters
    ----------
    importance_dict : dict
        Mapping of bit_index (str) -> importance.
    top_n : int
        Number of top bits to display.
    title : str
        Plot title.
    output_path : str
        File path to save the figure.
    figsize : tuple
        Figure size.

    Returns
    -------
    dict
        {"path": output_path}
    """
    sorted_items = sorted(importance_dict.items(), key=lambda x: x[1], reverse=True)
    top_items = sorted_items[:top_n]
    names = [f"Bit {item[0]}" for item in top_items]
    values = [item[1] for item in top_items]

    fig, ax = plt.subplots(figsize=figsize)
    ax.bar(range(len(names)), values, color="coral")
    ax.set_xticks(range(len(names)))
    ax.set_xticklabels(names, rotation=90, fontsize=7)
    ax.set_ylabel("Importance")
    ax.set_title(title)
    plt.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"path": output_path}

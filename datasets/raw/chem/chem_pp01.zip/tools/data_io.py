"""Data loading and preprocessing utilities for polymer informatics task.

Functions in this module read the polymer property CSV and provide basic
inspection helpers. They are deliberately low-level: they do not impose any
modelling decisions.
"""
from __future__ import annotations

import os
from typing import Iterable

import numpy as np
import pandas as pd


SCORED_PROPERTIES: tuple[str, ...] = (
    "Tg_K",
    "Tm_K",
    "Td_K",
    "density_g_cm3",
    "refidx_exp",
    "bandgap_chain_eV",
    "electron_affinity_eV",
    "ionization_energy_eV",
)
"""Canonical list of the eight target columns scored by the benchmark."""

CONTEXT_ONLY_PROPERTIES: tuple[str, ...] = (
    "refidx_dft",
    "atomization_energy_eV_per_atom",
)
"""The two CSV property columns provided for context but NOT scored."""


def load_polymer_csv(
    path: str,
    require_scored_properties: bool = True,
    expected_n_rows: int | None = None,
) -> pd.DataFrame:
    """Load the polymer properties CSV and validate its schema.

    Parameters
    ----------
    path : str
        Absolute path to ``polymer_properties.csv``.
    require_scored_properties : bool
        When True (default) raise if any of the eight SCORED_PROPERTIES are
        missing from the loaded frame.
    expected_n_rows : int or None
        When set, raise if the loaded frame does not have exactly that many
        rows (typically 5000 for the bundled snapshot).

    Returns
    -------
    pandas.DataFrame
        Frame indexed by integer position with one row per polymer.
        First column is ``smiles`` (PSMILES with two ``[*]`` end-points).
    """
    if not os.path.exists(path):
        raise FileNotFoundError(f"polymer_properties.csv not found at {path}")
    df = pd.read_csv(path)
    if "smiles" not in df.columns:
        raise ValueError("CSV is missing required 'smiles' column")
    if require_scored_properties:
        missing = [c for c in SCORED_PROPERTIES if c not in df.columns]
        if missing:
            raise ValueError(
                f"CSV is missing required scored property columns: {missing}"
            )
    if expected_n_rows is not None and len(df) != expected_n_rows:
        raise ValueError(
            f"CSV row count {len(df)} does not match expected {expected_n_rows}"
        )
    return df


def list_property_columns(df: pd.DataFrame) -> list[str]:
    """Return numeric property column names (everything except ``smiles``)."""
    return [c for c in df.columns if c != "smiles"]


def list_scored_properties(df: pd.DataFrame | None = None) -> list[str]:
    """Return the eight scored property columns, optionally filtered to those
    present in ``df`` (defaults to the canonical SCORED_PROPERTIES tuple)."""
    if df is None:
        return list(SCORED_PROPERTIES)
    return [c for c in SCORED_PROPERTIES if c in df.columns]


def summarise_columns(df: pd.DataFrame, columns: Iterable[str] | None = None) -> pd.DataFrame:
    """Per-column count, mean, std, min, max, median and IQR.

    Useful for ascertaining the dynamic range of each predicted property
    before training so that performance metrics can be put in context.
    """
    cols = list(columns) if columns else list_property_columns(df)
    out = []
    for c in cols:
        s = df[c].astype(float)
        q1, q3 = float(np.quantile(s, 0.25)), float(np.quantile(s, 0.75))
        out.append(
            {
                "property": c,
                "count": int(s.shape[0]),
                "mean": float(s.mean()),
                "std": float(s.std()),
                "min": float(s.min()),
                "median": float(s.median()),
                "max": float(s.max()),
                "iqr": q3 - q1,
            }
        )
    return pd.DataFrame(out)


def train_test_split_indices(
    n_rows: int, test_fraction: float = 0.2, seed: int = 42
) -> tuple[np.ndarray, np.ndarray]:
    """Random train/test row index split.

    Parameters
    ----------
    n_rows : int
        Total number of rows.
    test_fraction : float
        Fraction of rows to reserve for the held-out test set.
    seed : int
        Numpy RNG seed for reproducibility.
    """
    rng = np.random.default_rng(seed)
    perm = rng.permutation(n_rows)
    n_test = int(round(n_rows * test_fraction))
    return perm[n_test:], perm[:n_test]


def kfold_indices(n_rows: int, n_splits: int = 5, seed: int = 42) -> list[tuple[np.ndarray, np.ndarray]]:
    """Return a list of ``(train_idx, val_idx)`` arrays for K-fold CV."""
    rng = np.random.default_rng(seed)
    perm = rng.permutation(n_rows)
    folds = np.array_split(perm, n_splits)
    out = []
    for k in range(n_splits):
        val = folds[k]
        train = np.concatenate([folds[i] for i in range(n_splits) if i != k])
        out.append((train, val))
    return out


def select_columns(
    df: pd.DataFrame, smiles_col: str = "smiles", target: str | None = None
) -> tuple[list[str], np.ndarray]:
    """Return ``(smiles_list, target_array)`` for a given property name."""
    smiles = df[smiles_col].astype(str).tolist()
    if target is None:
        return smiles, np.empty(0, dtype=float)
    if target not in df.columns:
        raise KeyError(f"property '{target}' not in dataframe columns")
    y = df[target].to_numpy(dtype=float)
    return smiles, y

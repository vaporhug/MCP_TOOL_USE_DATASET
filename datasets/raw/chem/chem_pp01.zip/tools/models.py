"""Regression model wrappers for polymer property prediction.

Provides three baseline regressors:

* ``fit_random_forest`` — sklearn RandomForestRegressor
* ``fit_ridge`` — sklearn Ridge (L2 linear regression)
* ``fit_gradient_boosting`` — sklearn GradientBoostingRegressor

All wrappers return a dict containing the trained estimator plus a
"normalising mean/std" pair so callers can report standardised errors if
desired. No hyperparameter search is performed inside these helpers; the
caller is expected to make those modelling choices.
"""
from __future__ import annotations

from typing import Any

import numpy as np
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.linear_model import Ridge


def fit_random_forest(
    X: np.ndarray,
    y: np.ndarray,
    n_estimators: int = 300,
    max_depth: int | None = None,
    seed: int = 42,
    n_jobs: int = -1,
) -> dict[str, Any]:
    """Fit a RandomForestRegressor on (X, y)."""
    rf = RandomForestRegressor(
        n_estimators=n_estimators,
        max_depth=max_depth,
        random_state=seed,
        n_jobs=n_jobs,
    )
    rf.fit(X, y)
    return {
        "model": rf,
        "y_mean": float(np.mean(y)),
        "y_std": float(np.std(y) if np.std(y) > 0 else 1.0),
        "feature_importances": rf.feature_importances_.astype(float),
    }


def fit_ridge(
    X: np.ndarray, y: np.ndarray, alpha: float = 1.0, seed: int = 42
) -> dict[str, Any]:
    """Fit a Ridge linear regressor on (X, y)."""
    rr = Ridge(alpha=alpha, random_state=seed)
    rr.fit(X, y)
    return {
        "model": rr,
        "y_mean": float(np.mean(y)),
        "y_std": float(np.std(y) if np.std(y) > 0 else 1.0),
        "coef": rr.coef_.astype(float),
        "intercept": float(rr.intercept_),
    }


def fit_gradient_boosting(
    X: np.ndarray,
    y: np.ndarray,
    n_estimators: int = 300,
    max_depth: int = 3,
    learning_rate: float = 0.05,
    seed: int = 42,
) -> dict[str, Any]:
    """Fit a GradientBoostingRegressor on (X, y)."""
    gb = GradientBoostingRegressor(
        n_estimators=n_estimators,
        max_depth=max_depth,
        learning_rate=learning_rate,
        random_state=seed,
    )
    gb.fit(X, y)
    return {
        "model": gb,
        "y_mean": float(np.mean(y)),
        "y_std": float(np.std(y) if np.std(y) > 0 else 1.0),
        "feature_importances": gb.feature_importances_.astype(float),
    }


def predict(model_dict: dict[str, Any], X: np.ndarray) -> np.ndarray:
    """Run the trained model on a feature matrix."""
    return np.asarray(model_dict["model"].predict(X), dtype=float)


def predict_with_uncertainty(
    model_dict: dict[str, Any], X: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    """Return (mean, std) per-sample predictions for a forest ensemble.

    For non-forest models the std is approximated as zero. This is a
    convenience wrapper to support uncertainty-aware downstream use.
    """
    mdl = model_dict["model"]
    if hasattr(mdl, "estimators_") and isinstance(mdl, RandomForestRegressor):
        all_preds = np.stack([t.predict(X) for t in mdl.estimators_], axis=0)
        return all_preds.mean(axis=0), all_preds.std(axis=0)
    pred = predict(model_dict, X)
    return pred, np.zeros_like(pred)

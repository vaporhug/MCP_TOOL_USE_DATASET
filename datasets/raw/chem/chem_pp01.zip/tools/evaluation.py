"""Regression evaluation utilities — metrics and cross-validation.

Provides:

* ``regression_metrics`` — dict of R^2, RMSE, MAE, normalised RMSE
* ``cross_validate_regressor`` — generic K-fold CV given a fit/predict pair
* ``rank_features_by_importance`` — extract top-K features from a forest
"""
from __future__ import annotations

from typing import Any, Callable, Iterable

import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score


def regression_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict[str, float]:
    """Standard regression scoreboard.

    Returns
    -------
    dict
        Keys: ``R2``, ``RMSE``, ``MAE``, ``MAPE``, ``RMSE_over_std``.
    """
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    rmse = float(np.sqrt(mean_squared_error(y_true, y_pred)))
    mae = float(mean_absolute_error(y_true, y_pred))
    r2 = float(r2_score(y_true, y_pred))
    std = float(np.std(y_true) if np.std(y_true) > 0 else 1.0)
    eps = 1e-9
    mape = float(np.mean(np.abs((y_true - y_pred) / (np.abs(y_true) + eps))) * 100.0)
    return {"R2": r2, "RMSE": rmse, "MAE": mae, "MAPE": mape, "RMSE_over_std": rmse / std}


def cross_validate_regressor(
    X: np.ndarray,
    y: np.ndarray,
    fit_fn: Callable[[np.ndarray, np.ndarray], dict[str, Any]],
    predict_fn: Callable[[dict[str, Any], np.ndarray], np.ndarray],
    folds: Iterable[tuple[np.ndarray, np.ndarray]],
) -> pd.DataFrame:
    """Run K-fold cross-validation and return per-fold metrics.

    Parameters
    ----------
    X, y : feature/target matrices
    fit_fn : callable taking (X_train, y_train) and returning a model dict
    predict_fn : callable taking (model_dict, X) and returning predictions
    folds : iterable of (train_idx, val_idx) numpy arrays
    """
    rows = []
    for k, (tr, va) in enumerate(folds):
        m = fit_fn(X[tr], y[tr])
        yv = predict_fn(m, X[va])
        scores = regression_metrics(y[va], yv)
        scores["fold"] = k
        scores["n_train"] = len(tr)
        scores["n_val"] = len(va)
        rows.append(scores)
    return pd.DataFrame(rows)


def aggregate_cv(metrics_df: pd.DataFrame) -> dict[str, float]:
    """Mean +/- std summary of a per-fold metrics DataFrame."""
    out = {}
    for k in ("R2", "RMSE", "MAE", "MAPE", "RMSE_over_std"):
        if k in metrics_df.columns:
            out[f"{k}_mean"] = float(metrics_df[k].mean())
            out[f"{k}_std"] = float(metrics_df[k].std())
    return out


def rank_features_by_importance(
    model_dict: dict[str, Any], top_k: int = 25
) -> pd.DataFrame:
    """Return top-K features by importance for a forest-style model dict."""
    if "feature_importances" not in model_dict:
        raise ValueError("model_dict has no 'feature_importances' field")
    imp = np.asarray(model_dict["feature_importances"], dtype=float)
    order = np.argsort(-imp)[:top_k]
    return pd.DataFrame(
        {"feature_index": order, "importance": imp[order]}
    ).reset_index(drop=True)


def residuals(y_true: np.ndarray, y_pred: np.ndarray) -> np.ndarray:
    """Return ``y_pred - y_true`` as a 1-D array."""
    return np.asarray(y_pred, dtype=float) - np.asarray(y_true, dtype=float)


def fraction_within(
    y_true: np.ndarray, y_pred: np.ndarray, tolerance: float
) -> float:
    """Fraction of samples whose absolute error is within ``tolerance``."""
    err = np.abs(np.asarray(y_pred, dtype=float) - np.asarray(y_true, dtype=float))
    return float(np.mean(err <= tolerance))

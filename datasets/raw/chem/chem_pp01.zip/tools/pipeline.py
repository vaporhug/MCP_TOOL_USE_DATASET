"""High-level pipeline composers for the polymer property task.

These functions chain the lower-level primitives to expose simple
multi-property training/eval workflows. They never bake-in the answers,
but they make it cheap for the agent to reproduce the cross-property
benchmark workflow without re-implementing it from scratch.
"""
from __future__ import annotations

from typing import Iterable

import numpy as np
import pandas as pd

from . import data_io, evaluation, featurise, models


def featurise_and_split(
    df: pd.DataFrame,
    target: str,
    method: str = "morgan_count",
    radius: int = 2,
    n_bits: int = 1024,
    test_fraction: float = 0.2,
    seed: int = 42,
) -> dict:
    """End-to-end: SMILES -> fingerprint, then random train/test split."""
    smiles, y = data_io.select_columns(df, target=target)
    X = featurise.featurise_dataset(smiles, method=method, radius=radius, n_bits=n_bits)
    tr, te = data_io.train_test_split_indices(len(y), test_fraction=test_fraction, seed=seed)
    return {
        "X_train": X[tr],
        "X_test": X[te],
        "y_train": y[tr],
        "y_test": y[te],
        "train_idx": tr,
        "test_idx": te,
    }


def benchmark_models_on_property(
    X: np.ndarray,
    y: np.ndarray,
    folds: Iterable[tuple[np.ndarray, np.ndarray]] | None = None,
    n_splits: int = 5,
    seed: int = 42,
    rf_kwargs: dict | None = None,
    gb_kwargs: dict | None = None,
    ridge_kwargs: dict | None = None,
) -> pd.DataFrame:
    """Run RF, Ridge, and GradientBoosting on the same K-fold split.

    Pass ``rf_kwargs`` / ``gb_kwargs`` / ``ridge_kwargs`` to override the
    default hyperparameters of the underlying fit functions.

    Returns a long-format DataFrame: ``model``, ``fold``, ``R2``, ``RMSE``,
    ``MAE``, etc.
    """
    if folds is None:
        folds = data_io.kfold_indices(len(y), n_splits=n_splits, seed=seed)
    folds = list(folds)
    rf_kwargs = rf_kwargs or {}
    gb_kwargs = gb_kwargs or {}
    ridge_kwargs = ridge_kwargs or {}
    out = []

    def _rf(Xa, ya):
        return models.fit_random_forest(Xa, ya, **rf_kwargs)

    def _rr(Xa, ya):
        return models.fit_ridge(Xa, ya, **ridge_kwargs)

    def _gb(Xa, ya):
        return models.fit_gradient_boosting(Xa, ya, **gb_kwargs)

    rf_metrics = evaluation.cross_validate_regressor(X, y, _rf, models.predict, folds)
    rf_metrics["model"] = "random_forest"
    out.append(rf_metrics)

    rr_metrics = evaluation.cross_validate_regressor(X, y, _rr, models.predict, folds)
    rr_metrics["model"] = "ridge"
    out.append(rr_metrics)

    gb_metrics = evaluation.cross_validate_regressor(X, y, _gb, models.predict, folds)
    gb_metrics["model"] = "gradient_boosting"
    out.append(gb_metrics)

    return pd.concat(out, ignore_index=True)


def multi_property_benchmark(
    df: pd.DataFrame,
    properties: Iterable[str],
    method: str = "morgan_count",
    radius: int = 2,
    n_bits: int = 1024,
    n_splits: int = 5,
    seed: int = 42,
    rf_kwargs: dict | None = None,
    gb_kwargs: dict | None = None,
    ridge_kwargs: dict | None = None,
) -> pd.DataFrame:
    """Benchmark RF, Ridge, GB on every named property.

    Long-format result with columns ``property``, ``model``, ``R2_mean``,
    ``RMSE_mean``, ``MAE_mean``, plus the standard deviations.

    Pass ``rf_kwargs`` / ``gb_kwargs`` / ``ridge_kwargs`` to control the
    individual regressor hyperparameters, e.g. ``gb_kwargs={"n_estimators": 100}``.
    """
    smiles, _ = data_io.select_columns(df)
    X = featurise.featurise_dataset(smiles, method=method, radius=radius, n_bits=n_bits)

    rows = []
    for prop in properties:
        y = df[prop].to_numpy(dtype=float)
        per_fold = benchmark_models_on_property(
            X, y, n_splits=n_splits, seed=seed,
            rf_kwargs=rf_kwargs, gb_kwargs=gb_kwargs, ridge_kwargs=ridge_kwargs,
        )
        for mname, sub in per_fold.groupby("model"):
            rows.append(
                {
                    "property": prop,
                    "model": mname,
                    "R2_mean": float(sub["R2"].mean()),
                    "R2_std": float(sub["R2"].std()),
                    "RMSE_mean": float(sub["RMSE"].mean()),
                    "RMSE_std": float(sub["RMSE"].std()),
                    "MAE_mean": float(sub["MAE"].mean()),
                    "MAE_std": float(sub["MAE"].std()),
                    "n": int(len(y)),
                }
            )
    return pd.DataFrame(rows)


def run_benchmark_and_save_csv(
    df: pd.DataFrame,
    properties: Iterable[str],
    out_path: str,
    method: str = "morgan_count",
    radius: int = 2,
    n_bits: int = 1024,
    n_splits: int = 5,
    seed: int = 42,
    rf_kwargs: dict | None = None,
    gb_kwargs: dict | None = None,
    ridge_kwargs: dict | None = None,
) -> dict:
    """Run multi_property_benchmark and persist the per-(property, regressor)
    R^2 / RMSE / MAE table to ``out_path`` as the canonical
    ``benchmark_results.csv`` artifact.

    Returns dict with the output path and the DataFrame ``rows`` count.
    """
    import os as _os
    out = multi_property_benchmark(
        df, properties,
        method=method, radius=radius, n_bits=n_bits,
        n_splits=n_splits, seed=seed,
        rf_kwargs=rf_kwargs, gb_kwargs=gb_kwargs, ridge_kwargs=ridge_kwargs,
    )
    _os.makedirs(_os.path.dirname(out_path) or ".", exist_ok=True)
    out.to_csv(out_path, index=False)
    return {"output_path": out_path, "n_rows": int(len(out))}


def kfold_single_property_pipeline(
    df: pd.DataFrame,
    target: str,
    method: str = "morgan_count",
    radius: int = 2,
    n_bits: int = 1024,
    model_name: str = "random_forest",
    n_splits: int = 5,
    seed: int = 42,
    rf_kwargs: dict | None = None,
    gb_kwargs: dict | None = None,
    ridge_kwargs: dict | None = None,
) -> dict:
    """Run K-fold cross-validation for ONE regressor on ONE property and
    return out-of-fold predictions plus per-fold and aggregated metrics.

    This is the recommended path for producing parity-plot, residual-
    histogram, and feature-importance figures with full out-of-fold
    coverage (every input sample appears in exactly one held-out fold).
    The aggregated importances are averaged across the K trained models.

    Returns dict with:
      - y_true: ndarray of length N
      - y_oof: ndarray of length N (out-of-fold predictions)
      - fold_index: ndarray of length N (the held-out fold each row was in)
      - per_fold_metrics: list of dicts with keys {fold, R2, RMSE, MAE}
      - cv_metrics: dict with mean R2 / RMSE / MAE across folds
      - oof_metrics: dict with R2 / RMSE / MAE computed on (y_true, y_oof)
      - feature_importances: ndarray of length n_bits (averaged across folds)
        — only populated for tree-based models that expose
        ``feature_importances_``.
    """
    smiles, _ = data_io.select_columns(df)
    X = featurise.featurise_dataset(smiles, method=method, radius=radius, n_bits=n_bits)
    y = df[target].to_numpy(dtype=float)
    folds = list(data_io.kfold_indices(len(y), n_splits=n_splits, seed=seed))

    y_oof = np.full(len(y), np.nan, dtype=float)
    fold_idx = np.full(len(y), -1, dtype=np.int64)
    per_fold = []
    importances_sum = np.zeros(X.shape[1], dtype=float)
    importances_count = 0

    for k, (train_idx, test_idx) in enumerate(folds):
        Xa, ya = X[train_idx], y[train_idx]
        Xb, yb = X[test_idx], y[test_idx]
        if model_name == "random_forest":
            m = models.fit_random_forest(Xa, ya, seed=seed, **(rf_kwargs or {}))
        elif model_name == "ridge":
            m = models.fit_ridge(Xa, ya, **(ridge_kwargs or {}))
        elif model_name == "gradient_boosting":
            m = models.fit_gradient_boosting(Xa, ya, seed=seed, **(gb_kwargs or {}))
        else:
            raise ValueError(f"unknown model_name '{model_name}'")
        pred = models.predict(m, Xb)
        y_oof[test_idx] = pred
        fold_idx[test_idx] = k
        fold_metrics = evaluation.regression_metrics(yb, pred)
        per_fold.append({"fold": int(k), **fold_metrics})
        # Tree-based wrappers (random_forest, gradient_boosting) expose
        # feature_importances directly on the returned dict; ridge does not.
        fi = m.get("feature_importances") if isinstance(m, dict) else None
        if fi is not None:
            importances_sum += np.asarray(fi, dtype=float)
            importances_count += 1

    cv_metrics = {
        "R2_mean": float(np.mean([r["R2"] for r in per_fold])),
        "RMSE_mean": float(np.mean([r["RMSE"] for r in per_fold])),
        "MAE_mean": float(np.mean([r["MAE"] for r in per_fold])),
        "R2_std": float(np.std([r["R2"] for r in per_fold])),
        "RMSE_std": float(np.std([r["RMSE"] for r in per_fold])),
        "MAE_std": float(np.std([r["MAE"] for r in per_fold])),
    }
    oof_metrics = evaluation.regression_metrics(y, y_oof)
    feature_importances = (importances_sum / importances_count
                           if importances_count > 0 else None)
    return {
        "y_true": y,
        "y_oof": y_oof,
        "fold_index": fold_idx,
        "per_fold_metrics": per_fold,
        "cv_metrics": cv_metrics,
        "oof_metrics": oof_metrics,
        "feature_importances": feature_importances,
        "n_splits": int(n_splits),
        "method": method,
        "model_name": model_name,
    }


def single_property_pipeline(
    df: pd.DataFrame,
    target: str,
    method: str = "morgan_count",
    radius: int = 2,
    n_bits: int = 1024,
    test_fraction: float = 0.2,
    model_name: str = "random_forest",
    seed: int = 42,
) -> dict:
    """Train a single regressor on a single property and return predictions.

    Convenient one-call workflow returning everything needed to plot a
    parity diagram, residual histogram, and feature importance with a
    single random train/test split. Prefer ``kfold_single_property_pipeline``
    when the task requires 5-fold cross-validated metrics with out-of-fold
    predictions.
    """
    sp = featurise_and_split(
        df, target, method=method, radius=radius, n_bits=n_bits,
        test_fraction=test_fraction, seed=seed,
    )
    if model_name == "random_forest":
        m = models.fit_random_forest(sp["X_train"], sp["y_train"], seed=seed)
    elif model_name == "ridge":
        m = models.fit_ridge(sp["X_train"], sp["y_train"])
    elif model_name == "gradient_boosting":
        m = models.fit_gradient_boosting(sp["X_train"], sp["y_train"], seed=seed)
    else:
        raise ValueError(f"unknown model_name '{model_name}'")
    pred = models.predict(m, sp["X_test"])
    metrics = evaluation.regression_metrics(sp["y_test"], pred)
    return {
        "model_dict": m,
        "y_train": sp["y_train"],
        "y_test": sp["y_test"],
        "y_pred_test": pred,
        "X_test": sp["X_test"],
        "metrics": metrics,
        "train_idx": sp["train_idx"],
        "test_idx": sp["test_idx"],
    }

"""Matplotlib plotting helpers for the polymer property task.

Each plot writes a PNG to disk and returns a dict with the path so the
caller can compose the path into the final answer's ``image`` items.
"""
from __future__ import annotations

import os
from typing import Iterable

import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


def _ensure_parent(path: str) -> None:
    parent = os.path.dirname(path)
    if parent and not os.path.exists(parent):
        os.makedirs(parent, exist_ok=True)


def plot_parity(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    out_path: str,
    title: str = "Parity plot",
    xlabel: str = "Measured",
    ylabel: str = "Predicted",
) -> dict[str, str]:
    """Predicted-vs-target scatter with y=x reference and metric box."""
    _ensure_parent(out_path)
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    rmse = float(np.sqrt(np.mean((y_pred - y_true) ** 2)))
    mae = float(np.mean(np.abs(y_pred - y_true)))
    ss_res = np.sum((y_true - y_pred) ** 2)
    ss_tot = np.sum((y_true - np.mean(y_true)) ** 2)
    r2 = float(1.0 - ss_res / ss_tot) if ss_tot > 0 else float("nan")

    fig, ax = plt.subplots(figsize=(5.4, 5.4))
    ax.scatter(y_true, y_pred, s=8, alpha=0.45, color="#2b6cb0", edgecolor="none")
    lo = float(min(y_true.min(), y_pred.min()))
    hi = float(max(y_true.max(), y_pred.max()))
    ax.plot([lo, hi], [lo, hi], color="#1a202c", linewidth=1.2, linestyle="--")
    ax.set_xlim(lo, hi)
    ax.set_ylim(lo, hi)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.text(
        0.04,
        0.96,
        f"R$^2$ = {r2:.3f}\nRMSE = {rmse:.3f}\nMAE = {mae:.3f}\nN = {len(y_true)}",
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=10,
        bbox=dict(boxstyle="round,pad=0.3", facecolor="white", alpha=0.85),
    )
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": out_path}


def plot_error_distribution(
    y_true: np.ndarray, y_pred: np.ndarray, out_path: str, title: str = "Error distribution"
) -> dict[str, str]:
    """Histogram of residuals (predicted - target) with mean+std vertical lines."""
    _ensure_parent(out_path)
    res = np.asarray(y_pred, dtype=float) - np.asarray(y_true, dtype=float)

    fig, ax = plt.subplots(figsize=(6.4, 4.4))
    ax.hist(res, bins=40, color="#2c7a7b", edgecolor="white", alpha=0.85)
    ax.axvline(0.0, color="black", linewidth=0.9)
    ax.axvline(float(res.mean()), color="#c53030", linewidth=1.1, label=f"mean = {res.mean():+.3f}")
    ax.axvline(float(res.mean() + res.std()), color="#c53030", linewidth=0.6, linestyle="--", label=f"$\\pm 1\\sigma$ = {res.std():.3f}")
    ax.axvline(float(res.mean() - res.std()), color="#c53030", linewidth=0.6, linestyle="--")
    ax.set_xlabel("Residual (predicted - target)")
    ax.set_ylabel("Count")
    ax.set_title(title)
    ax.legend(loc="upper right", fontsize=9)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": out_path}


def plot_top_features(
    importances: np.ndarray,
    out_path: str,
    feature_names: Iterable[str] | None = None,
    top_k: int = 20,
    title: str = "Top features by importance",
) -> dict[str, str]:
    """Horizontal bar chart of top-K feature importances."""
    _ensure_parent(out_path)
    importances = np.asarray(importances, dtype=float)
    order = np.argsort(-importances)[:top_k]
    vals = importances[order]
    if feature_names is None:
        labels = [f"f{i}" for i in order]
    else:
        names = list(feature_names)
        labels = [names[i] if i < len(names) else f"f{i}" for i in order]

    fig, ax = plt.subplots(figsize=(6.4, max(3.5, 0.28 * top_k)))
    y = np.arange(len(order))[::-1]
    ax.barh(y, vals, color="#805ad5", edgecolor="white")
    ax.set_yticks(y)
    ax.set_yticklabels(labels, fontsize=8)
    ax.set_xlabel("Feature importance")
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": out_path}


def plot_property_heatmap(
    metric_table: dict[str, dict[str, float]],
    out_path: str,
    metric: str = "R2",
    title: str = "Per-property R^2 heatmap",
    vmin: float | None = None,
    vmax: float | None = None,
) -> dict[str, str]:
    """Plot a property-vs-model heatmap of one metric.

    Parameters
    ----------
    metric_table : dict
        ``{property_name: {model_name: metric_value}}``
    metric : str
        The metric key shown in the heatmap (used in cbar label only).
    vmin, vmax : float, optional
        Colour-scale limits. If left as ``None`` the limits are inferred
        from the observed values in ``metric_table`` (data-driven), so the
        figure highlights the dynamic range of the agent's results. Pass
        explicit values (e.g. 0.0 and 1.0) to force a fixed scale.
    """
    _ensure_parent(out_path)
    props = list(metric_table.keys())
    models = sorted({m for sub in metric_table.values() for m in sub.keys()})
    arr = np.full((len(props), len(models)), np.nan, dtype=float)
    for i, p in enumerate(props):
        for j, m in enumerate(models):
            v = metric_table[p].get(m, np.nan)
            arr[i, j] = float(v) if v is not None else np.nan

    if vmin is None:
        finite = arr[np.isfinite(arr)]
        vmin = float(finite.min()) if finite.size else 0.0
    if vmax is None:
        finite = arr[np.isfinite(arr)]
        vmax = float(finite.max()) if finite.size else 1.0

    fig, ax = plt.subplots(figsize=(0.9 + 0.9 * len(models), 0.4 + 0.4 * len(props)))
    im = ax.imshow(arr, aspect="auto", cmap="viridis", vmin=vmin, vmax=vmax)
    ax.set_xticks(range(len(models)))
    ax.set_xticklabels(models, rotation=30, ha="right", fontsize=9)
    ax.set_yticks(range(len(props)))
    ax.set_yticklabels(props, fontsize=9)
    for i in range(arr.shape[0]):
        for j in range(arr.shape[1]):
            v = arr[i, j]
            if not np.isnan(v):
                ax.text(j, i, f"{v:.2f}", ha="center", va="center",
                        color="white" if v < 0.5 else "black", fontsize=8)
    cb = fig.colorbar(im, ax=ax)
    cb.set_label(metric)
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": out_path}


def plot_learning_curve(
    train_sizes: np.ndarray,
    rmse_means: np.ndarray,
    rmse_stds: np.ndarray,
    out_path: str,
    title: str = "Learning curve",
    ylabel: str = "Validation RMSE",
) -> dict[str, str]:
    """Plot mean RMSE +/- 1 sigma against training-set size."""
    _ensure_parent(out_path)
    train_sizes = np.asarray(train_sizes, dtype=float)
    means = np.asarray(rmse_means, dtype=float)
    stds = np.asarray(rmse_stds, dtype=float)

    fig, ax = plt.subplots(figsize=(6.0, 4.0))
    ax.plot(train_sizes, means, marker="o", color="#dd6b20", linewidth=1.4)
    ax.fill_between(train_sizes, means - stds, means + stds, alpha=0.25, color="#dd6b20")
    ax.set_xlabel("Training set size")
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return {"path": out_path}

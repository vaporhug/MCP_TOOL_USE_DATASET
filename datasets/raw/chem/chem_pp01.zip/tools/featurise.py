"""Polymer-aware fingerprint featurisation utilities.

Polymer SMILES (PSMILES) here use ``[*]`` to denote the two repeat-unit
end-points. To compute Morgan / circular fingerprints we cap each ``[*]``
with a hydrogen, allowing standard RDKit chemistry parsing. We expose the
"capped monomer" fingerprint as a 1D bit vector (or count vector) and a
"two-end concatenation" fingerprint that doubles each end with a methyl
proxy and concatenates the two atom-environment hashes.

These functions deliberately stay below the model-fitting layer. They take
SMILES in, vectors out. No modelling decisions are baked in.
"""
from __future__ import annotations

from typing import Iterable

import numpy as np

from rdkit import Chem
from rdkit.Chem import AllChem, Descriptors, rdMolDescriptors


def _cap_psmiles(psmiles: str, replacement: str = "[H]") -> str:
    """Replace ``[*]`` end-points with a small chemical group.

    The default ``[H]`` keeps the heavy-atom skeleton untouched. Use
    ``replacement="C"`` to model "methyl-capped" monomers when stronger
    chain-end perturbations are desired.
    """
    return psmiles.replace("[*]", replacement)


def psmiles_to_mol(psmiles: str, replacement: str = "[H]") -> Chem.Mol | None:
    """Convert a PSMILES string to an RDKit Mol (or None on parse failure)."""
    smi = _cap_psmiles(psmiles, replacement)
    return Chem.MolFromSmiles(smi)


def morgan_bit_fp(psmiles: str, radius: int = 2, n_bits: int = 1024) -> np.ndarray:
    """Hashed binary Morgan fingerprint of length ``n_bits``."""
    mol = psmiles_to_mol(psmiles)
    if mol is None:
        return np.zeros(n_bits, dtype=np.uint8)
    bv = AllChem.GetMorganFingerprintAsBitVect(mol, radius=radius, nBits=n_bits)
    arr = np.zeros((n_bits,), dtype=np.uint8)
    from rdkit.DataStructs import ConvertToNumpyArray

    ConvertToNumpyArray(bv, arr)
    return arr


def morgan_count_fp(psmiles: str, radius: int = 2, n_bits: int = 1024) -> np.ndarray:
    """Hashed integer (count) Morgan fingerprint of length ``n_bits``."""
    mol = psmiles_to_mol(psmiles)
    if mol is None:
        return np.zeros(n_bits, dtype=np.int32)
    bv = rdMolDescriptors.GetHashedMorganFingerprint(mol, radius=radius, nBits=n_bits)
    arr = np.zeros((n_bits,), dtype=np.int32)
    for idx, count in bv.GetNonzeroElements().items():
        arr[idx] = count
    return arr


def two_end_concat_fp(
    psmiles: str, radius: int = 2, n_bits: int = 512
) -> np.ndarray:
    """Polymer-aware fingerprint: H-cap + Methyl-cap concatenated.

    Captures the same monomer twice but with different chain-end
    proxies. The concatenation is sensitive to chain-end environment in a
    way a single capped fingerprint is not.
    """
    fp_h = morgan_count_fp(psmiles, radius=radius, n_bits=n_bits)
    smi_c = _cap_psmiles(psmiles, "C")
    mol_c = Chem.MolFromSmiles(smi_c)
    if mol_c is None:
        fp_c = np.zeros(n_bits, dtype=np.int32)
    else:
        bv = rdMolDescriptors.GetHashedMorganFingerprint(mol_c, radius=radius, nBits=n_bits)
        fp_c = np.zeros((n_bits,), dtype=np.int32)
        for idx, count in bv.GetNonzeroElements().items():
            fp_c[idx] = count
    return np.concatenate([fp_h, fp_c])


def featurise_dataset(
    smiles_list: Iterable[str],
    method: str = "morgan_count",
    radius: int = 2,
    n_bits: int = 1024,
) -> np.ndarray:
    """Featurise a list of PSMILES with the chosen fingerprint method.

    Parameters
    ----------
    smiles_list : iterable of str
    method : one of ``{'morgan_bit', 'morgan_count', 'two_end_concat'}``
    radius, n_bits : int
        Morgan fingerprint parameters.

    Returns
    -------
    numpy.ndarray
        Float32 matrix of shape ``(n_polymers, feature_dim)``.
    """
    rows = []
    for smi in smiles_list:
        if method == "morgan_bit":
            v = morgan_bit_fp(smi, radius=radius, n_bits=n_bits)
        elif method == "morgan_count":
            v = morgan_count_fp(smi, radius=radius, n_bits=n_bits)
        elif method == "two_end_concat":
            v = two_end_concat_fp(smi, radius=radius, n_bits=n_bits)
        else:
            raise ValueError(f"unknown method '{method}'")
        rows.append(v)
    return np.asarray(rows, dtype=np.float32)


def basic_descriptors(psmiles: str) -> dict[str, float]:
    """Compute a small set of RDKit physicochemical descriptors.

    Returns a dict of MolWt, HeavyAtomCount, NumAromaticRings, NumRings,
    NumHBD, NumHBA, FractionCSP3, TPSA, LogP for the H-capped monomer.
    Useful for sanity-checking dataset chemical diversity, not modelling.
    """
    mol = psmiles_to_mol(psmiles)
    if mol is None:
        return {k: float("nan") for k in (
            "MolWt", "HeavyAtomCount", "NumAromaticRings", "NumRings",
            "NumHBD", "NumHBA", "FractionCSP3", "TPSA", "MolLogP",
        )}
    return {
        "MolWt": float(Descriptors.MolWt(mol)),
        "HeavyAtomCount": float(mol.GetNumHeavyAtoms()),
        "NumAromaticRings": float(rdMolDescriptors.CalcNumAromaticRings(mol)),
        "NumRings": float(rdMolDescriptors.CalcNumRings(mol)),
        "NumHBD": float(rdMolDescriptors.CalcNumHBD(mol)),
        "NumHBA": float(rdMolDescriptors.CalcNumHBA(mol)),
        "FractionCSP3": float(rdMolDescriptors.CalcFractionCSP3(mol)),
        "TPSA": float(rdMolDescriptors.CalcTPSA(mol)),
        "MolLogP": float(Descriptors.MolLogP(mol)),
    }


def descriptor_matrix(smiles_list: Iterable[str]) -> np.ndarray:
    """Stack ``basic_descriptors`` outputs into a matrix.

    The column order matches the dict key order in ``basic_descriptors``.
    """
    rows = [list(basic_descriptors(s).values()) for s in smiles_list]
    return np.asarray(rows, dtype=np.float32)

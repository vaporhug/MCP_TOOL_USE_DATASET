"""Polymer property prediction toolkit (chem_pp01).

Modules
-------
data_io : CSV loading, train/test/K-fold splits.
featurise : PSMILES -> Morgan-bit / Morgan-count / polymer-aware two-end-concatenated / descriptor features.
models : RandomForest, Ridge, GradientBoosting regressor wrappers.
evaluation : R^2 / RMSE / MAE metrics, K-fold cross-validation, feature ranking.
plotting : parity, residual, feature-importance, and per-property R^2 heatmap PNGs.
pipeline : composer functions chaining the above; ``kfold_single_property_pipeline``
    runs full 5-fold CV with out-of-fold predictions and aggregated feature
    importances (the recommended path for the Tg parity / residual / importance
    figures), ``multi_property_benchmark`` produces the per-property × per-regressor
    R^2 table, and ``single_property_pipeline`` does a quick single train/test split.

Example
-------
>>> from tools import data_io, pipeline, plotting
>>> df = data_io.load_polymer_csv("input_data/data/polymer_properties.csv")
>>> res = pipeline.kfold_single_property_pipeline(df, target="Tg_K")
>>> plotting.plot_parity(res["y_true"], res["y_oof"], "artifacts/Fig_Tg_parity.png")
"""

from . import data_io, evaluation, featurise, models, pipeline, plotting

__all__ = ["data_io", "evaluation", "featurise", "models", "pipeline", "plotting"]

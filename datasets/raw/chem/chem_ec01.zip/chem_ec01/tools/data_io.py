"""Loading and inspection primitives for the chem_ec01 electrochemistry task.

Every tool reads CSV files from ``input_data/data`` using only ``pandas``
and ``numpy`` so that the agent can run them in any sandbox.  The CSVs
follow these conventions:

LSV files (``ORR_Pt_C_20ugPt.csv``, ``ORR_Pt_C_5ugPt.csv``,
``Ferricyanide_Au.csv``, ``OER_Pt_disk.csv``):
    columns
        ``E_vs_ref_V`` -- potential as recorded vs the named reference
                          electrode (Hg/HgO or Ag/AgCl).
        ``i_A``        -- raw measured current (Ampere; sign convention
                          is cathodic negative, anodic positive).
        ``i_blank_A``  -- background current measured with the active
                          species removed (used for double-layer/blank
                          correction).

CV file (``CV_double_layer_Pt.csv``):
    columns
        ``scan_rate_mV_s``, ``branch`` ("forward"/"reverse"),
        ``E_vs_RHE_V``, ``i_A``.

Metadata file (``experiment_metadata.csv``):
    one row per LSV file, with cell geometry, electrolyte, temperature,
    rotation rate, reference-electrode-to-RHE offset and uncompensated
    series resistance Rs.
"""
from __future__ import annotations

import os
from typing import Dict, List

import numpy as np
import pandas as pd


def load_lsv_csv(path: str) -> pd.DataFrame:
    """Load a linear-sweep voltammogram from CSV.

    Parameters
    ----------
    path : str
        Path to a CSV file with columns ``E_vs_ref_V``, ``i_A`` and
        ``i_blank_A``.

    Returns
    -------
    pandas.DataFrame
        The full table, sorted ascending in ``E_vs_ref_V``.
    """
    if not os.path.isfile(path):
        raise FileNotFoundError(path)
    df = pd.read_csv(path)
    required = {"E_vs_ref_V", "i_A", "i_blank_A"}
    missing = required - set(df.columns)
    if missing:
        raise KeyError(f"missing columns in LSV file {path}: {sorted(missing)}")
    return df.sort_values("E_vs_ref_V").reset_index(drop=True)


def load_cv_csv(path: str) -> pd.DataFrame:
    """Load the cyclic-voltammetry double-layer dataset.

    Returns the full long-format table with columns ``scan_rate_mV_s``,
    ``branch``, ``E_vs_RHE_V``, ``i_A``.
    """
    if not os.path.isfile(path):
        raise FileNotFoundError(path)
    df = pd.read_csv(path)
    required = {"scan_rate_mV_s", "branch", "E_vs_RHE_V", "i_A"}
    missing = required - set(df.columns)
    if missing:
        raise KeyError(f"missing columns in CV file {path}: {sorted(missing)}")
    return df


def load_metadata(path: str) -> pd.DataFrame:
    """Load the experiment metadata table (one row per LSV file)."""
    if not os.path.isfile(path):
        raise FileNotFoundError(path)
    df = pd.read_csv(path)
    df = df.set_index("system_id", drop=False)
    return df


def list_systems(meta: pd.DataFrame) -> List[str]:
    """Return the list of ``system_id`` strings in the metadata table."""
    return [str(s) for s in meta["system_id"].tolist()]


def get_system_meta(meta: pd.DataFrame, system_id: str) -> Dict[str, object]:
    """Return the metadata row for one system as a dictionary."""
    if system_id not in meta.index:
        raise KeyError(system_id)
    return {k: meta.loc[system_id, k] for k in meta.columns}


def lsv_summary(df: pd.DataFrame) -> Dict[str, float]:
    """Return ``{n, E_min, E_max, i_min, i_max, i_mean, i_blank_mean}``."""
    out = {
        "n": int(len(df)),
        "E_min_V": float(df["E_vs_ref_V"].min()),
        "E_max_V": float(df["E_vs_ref_V"].max()),
        "i_min_A": float(df["i_A"].min()),
        "i_max_A": float(df["i_A"].max()),
        "i_mean_A": float(df["i_A"].mean()),
        "i_blank_mean_A": float(df["i_blank_A"].mean()),
    }
    return out


def to_current_density(df: pd.DataFrame, area_cm2: float) -> pd.DataFrame:
    """Add columns ``j_A_cm2`` and ``j_blank_A_cm2`` (current density)."""
    if area_cm2 <= 0:
        raise ValueError("area_cm2 must be > 0")
    out = df.copy()
    out["j_A_cm2"] = out["i_A"].to_numpy() / float(area_cm2)
    out["j_blank_A_cm2"] = out["i_blank_A"].to_numpy() / float(area_cm2)
    return out


def merge_lsv_with_meta(df: pd.DataFrame, meta_row: Dict[str, object]) -> pd.DataFrame:
    """Attach geometry/electrolyte/temperature columns from the metadata
    row to every sample of the LSV table.

    Returns a new DataFrame with a copy of ``df`` plus the metadata
    columns ``geometric_area_cm2``, ``temperature_C``, ``Rs_ohm``,
    ``ref_offset_to_RHE_V``.
    """
    needed = ("geometric_area_cm2", "temperature_C", "Rs_ohm", "ref_offset_to_RHE_V")
    out = df.copy()
    for k in needed:
        if k not in meta_row:
            raise KeyError(f"metadata row missing key {k}")
        out[k] = meta_row[k]
    return out

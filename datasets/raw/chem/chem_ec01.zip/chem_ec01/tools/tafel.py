"""Tafel-plot, differential-Tafel-plot and exchange-current primitives.

All routines work on the kinetic current ``ik`` (after blank and
mass-transfer corrections), the overpotential ``eta`` (signed), and the
local temperature.  The IUPAC definition of the apparent transfer
coefficient is alpha = (RT/F) * d ln|ik| / d eta, equivalently
``(1/f) * d ln|ik| / d eta`` with ``f = F/(RT)``.

The Tafel slope (in V/dec) is ``b = ln(10) / (alpha * f)``.

A "constant alpha plateau" in the differential Tafel plot is the
operational criterion of Khadke 2021 for a kinetically meaningful Tafel
range: only inside this plateau may i0 be extracted by extrapolating
``ln|ik|`` to eta = 0.
"""
from __future__ import annotations

from typing import Dict, Tuple

import numpy as np
import pandas as pd

R = 8.31446
F_C_PER_MOL = 96485.332


def _f_factor(T_K: float) -> float:
    if T_K <= 0:
        raise ValueError("T_K must be > 0")
    return F_C_PER_MOL / (R * float(T_K))


def tafel_plot(eta_V: np.ndarray, ik_A: np.ndarray) -> pd.DataFrame:
    """Return a long-format Tafel-plot table.

    Columns: ``eta_V``, ``ln_abs_ik`` (natural log) and ``log10_abs_ik``.
    Rows where ``ik`` is non-finite or zero are dropped.
    """
    eta = np.asarray(eta_V, dtype=np.float64)
    ik = np.asarray(ik_A, dtype=np.float64)
    if eta.size != ik.size:
        raise ValueError("eta and ik size mismatch")
    valid = np.isfinite(eta) & np.isfinite(ik) & (np.abs(ik) > 0)
    eta_v = eta[valid]
    ik_v = np.abs(ik[valid])
    return pd.DataFrame({
        "eta_V": eta_v,
        "ln_abs_ik": np.log(ik_v),
        "log10_abs_ik": np.log10(ik_v),
    })


def linear_fit_log_ik_vs_eta(
    eta_V: np.ndarray, ik_A: np.ndarray, eta_window_V: Tuple[float, float],
    T_K: float = 294.15,
) -> Dict[str, float]:
    """Fit ln|ik| = ln(i0) + alpha*f*eta on points inside the window.

    ``eta_window_V`` is interpreted on the *signed* eta axis.  For a
    cathodic reaction pass e.g. ``(-0.45, -0.30)``; for OER pass
    ``(0.60, 0.75)``.

    ``T_K`` is the experiment temperature in Kelvin used to convert the
    slope (V^-1) into a transfer coefficient. The bundled experiments
    range from 21 C to 60 C; pass the experiment_metadata temperature
    rather than relying on the default room-temperature value.

    Returns
    -------
    dict
        ``slope_per_V`` -- d ln|ik| / d eta = alpha * f.
        ``alpha``       -- apparent transfer coefficient at the given T.
        ``tafel_slope_V_dec`` -- ln(10)/(alpha*f).
        ``tafel_slope_mV_dec``.
        ``intercept`` and ``i0_extrap_A`` -- exp(intercept).
        ``rsq`` and ``n_points``.

    The function uses numpy.linalg.lstsq only (no scipy).
    """
    lo, hi = float(eta_window_V[0]), float(eta_window_V[1])
    if lo >= hi:
        raise ValueError("eta_window_V must satisfy lo < hi")
    tp = tafel_plot(eta_V, ik_A)
    in_win = (tp["eta_V"] >= lo) & (tp["eta_V"] <= hi)
    sub = tp[in_win]
    if len(sub) < 5:
        raise ValueError(
            f"Tafel window {eta_window_V} contains only {len(sub)} points"
        )
    x = sub["eta_V"].to_numpy(dtype=np.float64)
    y = sub["ln_abs_ik"].to_numpy(dtype=np.float64)
    A = np.vstack([x, np.ones_like(x)]).T
    coef, *_ = np.linalg.lstsq(A, y, rcond=None)
    slope, intercept = float(coef[0]), float(coef[1])
    yhat = slope * x + intercept
    ss_res = float(np.sum((y - yhat) ** 2))
    ss_tot = float(np.sum((y - y.mean()) ** 2)) if y.size > 1 else 0.0
    rsq = float(1.0 - ss_res / ss_tot) if ss_tot > 0 else float("nan")
    f = _f_factor(T_K)
    alpha = abs(slope) / f
    tafel_slope_V = np.log(10.0) / abs(slope) if slope != 0 else float("nan")
    return {
        "slope_per_V": slope,
        "alpha": alpha,
        "tafel_slope_V_dec": float(tafel_slope_V),
        "tafel_slope_mV_dec": float(tafel_slope_V * 1000.0),
        "intercept": intercept,
        "i0_extrap_A": float(np.exp(intercept)),
        "rsq": rsq,
        "n_points": int(len(sub)),
        "eta_window_V": (lo, hi),
    }


def compute_alpha_from_slope(slope_per_V: float, T_K: float) -> float:
    """Convert a fitted slope d ln|ik| / d eta (in 1/V) to alpha at the
    given absolute temperature."""
    f = _f_factor(T_K)
    return abs(float(slope_per_V)) / f


def differential_tafel_plot(
    eta_V: np.ndarray,
    ik_A: np.ndarray,
    smoothing_window: int = 21,
    T_K: float = 294.15,
) -> pd.DataFrame:
    """Compute the DTP: alpha(eta) = (1/f) * d ln|ik| / d eta.

    The derivative is taken on the natural log of |ik| using a centred
    finite-difference stencil of width ``smoothing_window`` (odd).
    Returns a table with columns ``eta_V``, ``ln_abs_ik``, ``alpha``,
    ``tafel_slope_mV_dec`` (=ln10/(alpha*f)*1000).

    The DTP is the operational test of Khadke 2021: a true Tafel range
    is the eta interval over which ``alpha`` is constant.
    """
    if smoothing_window < 3 or smoothing_window % 2 == 0:
        raise ValueError("smoothing_window must be an odd integer >= 3")
    tp = tafel_plot(eta_V, ik_A).sort_values("eta_V").reset_index(drop=True)
    eta = tp["eta_V"].to_numpy(dtype=np.float64)
    y = tp["ln_abs_ik"].to_numpy(dtype=np.float64)
    n = len(eta)
    alpha_arr = np.full(n, np.nan, dtype=np.float64)
    half = smoothing_window // 2
    f = _f_factor(T_K)
    for k in range(half, n - half):
        x_loc = eta[k - half:k + half + 1]
        y_loc = y[k - half:k + half + 1]
        A = np.vstack([x_loc, np.ones_like(x_loc)]).T
        coef, *_ = np.linalg.lstsq(A, y_loc, rcond=None)
        alpha_arr[k] = abs(float(coef[0])) / f
    out = pd.DataFrame({
        "eta_V": eta,
        "ln_abs_ik": y,
        "alpha": alpha_arr,
    })
    safe_alpha = np.where(alpha_arr > 0, alpha_arr, np.nan)
    out["tafel_slope_mV_dec"] = np.log(10.0) / (safe_alpha * f) * 1000.0
    return out


def find_tafel_plateau(
    dtp: pd.DataFrame,
    eta_search: Tuple[float, float],
    alpha_tol: float = 0.025,
    min_width_V: float = 0.05,
    T_K: float = 294.15,
) -> Dict[str, float]:
    """Find the longest contiguous eta interval inside ``eta_search`` over
    which ``alpha`` is constant within ``alpha_tol`` (absolute units).

    Pass ``T_K`` matching the experiment temperature so that the reported
    Tafel slope is correct for the system (the bundled experiments span
    21 C to 60 C).

    Returns a dictionary with the eta range, the median alpha and Tafel
    slope inside it, and the number of points; or ``{'found': False}``
    if no plateau wider than ``min_width_V`` exists.
    """
    lo, hi = float(eta_search[0]), float(eta_search[1])
    if lo >= hi:
        raise ValueError("eta_search must satisfy lo < hi")
    sub = dtp[(dtp["eta_V"] >= lo) & (dtp["eta_V"] <= hi) & dtp["alpha"].notna()]
    sub = sub.sort_values("eta_V").reset_index(drop=True)
    if len(sub) < 5:
        return {"found": False, "reason": "too few DTP points"}
    eta_arr = sub["eta_V"].to_numpy(dtype=np.float64)
    alpha_arr = sub["alpha"].to_numpy(dtype=np.float64)
    # iterate over windows in the median-around-window space
    best = {"width": 0.0, "i0": 0, "i1": 0, "median_alpha": float("nan")}
    n = len(eta_arr)
    for i0 in range(n - 1):
        med_run = []
        for i1 in range(i0 + 1, n):
            window_alpha = alpha_arr[i0:i1 + 1]
            if np.max(window_alpha) - np.min(window_alpha) > alpha_tol:
                break
            width = float(eta_arr[i1] - eta_arr[i0])
            if width > best["width"]:
                med_run = window_alpha
                best = {
                    "width": width,
                    "i0": int(i0),
                    "i1": int(i1),
                    "median_alpha": float(np.median(med_run)),
                }
    if best["width"] < min_width_V:
        return {"found": False, "reason": f"no plateau wider than {min_width_V} V"}
    eta_lo = float(eta_arr[best["i0"]])
    eta_hi = float(eta_arr[best["i1"]])
    median_alpha = float(best["median_alpha"])
    f = _f_factor(T_K)
    tafel_slope_mV = float(np.log(10.0) / (median_alpha * f) * 1000.0) if median_alpha > 0 else float("nan")
    return {
        "found": True,
        "eta_lo_V": eta_lo,
        "eta_hi_V": eta_hi,
        "width_V": best["width"],
        "median_alpha": median_alpha,
        "tafel_slope_mV_dec": tafel_slope_mV,
        "n_points": int(best["i1"] - best["i0"] + 1),
    }


def exchange_current_from_intercept(
    eta_V: np.ndarray,
    ik_A: np.ndarray,
    eta_window_V: Tuple[float, float],
    T_K: float = 294.15,
) -> Dict[str, float]:
    """Extract i0 by extrapolating the linear ln|ik|-vs-eta fit to eta=0.

    Pass ``T_K`` matching the experiment temperature so that the reported
    alpha and Tafel slope are correct for the system (the bundled
    experiments span 21 C to 60 C).

    Wraps ``linear_fit_log_ik_vs_eta`` for the agent's convenience and
    returns ``{'i0_A': ..., 'i0_uA': ..., 'tafel_slope_mV_dec': ...,
    'rsq': ...}``.
    """
    fit = linear_fit_log_ik_vs_eta(eta_V, ik_A, eta_window_V, T_K=T_K)
    return {
        "i0_A": fit["i0_extrap_A"],
        "i0_uA": fit["i0_extrap_A"] * 1e6,
        "tafel_slope_mV_dec": fit["tafel_slope_mV_dec"],
        "alpha": fit["alpha"],
        "rsq": fit["rsq"],
        "n_points": fit["n_points"],
    }


def tafel_overpotential_required(alpha: float, T_K: float = 294.15) -> float:
    """Return the |eta_TOP| above which the backward BV term contributes
    less than 1% (Eq.(12) of Khadke 2021): |eta_TOP| = ln(100) / (f *
    alpha_total).  ``alpha`` here is the *total* alpha = alpha_a +
    alpha_c (=1 for a single-step single-electron reaction).
    """
    if alpha <= 0:
        raise ValueError("alpha must be > 0")
    f = _f_factor(T_K)
    return float(np.log(100.0) / (f * float(alpha)))


def is_within_tafel_range(
    eta_V: float, alpha: float, T_K: float = 294.15
) -> bool:
    """Return True if |eta_V| > eta_TOP for the given alpha."""
    return abs(float(eta_V)) > tafel_overpotential_required(alpha, T_K)


def scan_tafel_windows(
    eta_V: "np.ndarray",
    ik_A: "np.ndarray",
    eta_min: float,
    eta_max: float,
    window_width_V: float = 0.06,
    step_V: float = 0.01,
    T_K: float = 294.15,
) -> "pd.DataFrame":
    """Sweep multiple eta-window placements and return per-window Tafel slopes.

    Useful for producing the 'comparison of slopes from alternative analysis
    windows' figure: returns a DataFrame with one row per window placement
    listing ``eta_lo_V``, ``eta_hi_V``, ``tafel_slope_mV_dec``, ``alpha``,
    ``rsq``, ``n_points``. The agent can then plot tafel_slope vs window
    centre to expose the dependence of the apparent slope on window choice.

    Args:
        eta_V, ik_A: signed eta (V) and kinetic current (A); typically the
            outputs of overpotential_from_RHE and Koutecky-Levich correction.
        eta_min, eta_max: outer bounds for the window-centre sweep on the
            signed eta axis. For OER pass positive values; for cathodic
            reactions pass negative values (lo < hi).
        window_width_V: fixed window width (default 60 mV).
        step_V: step between successive window centres (default 10 mV).
        T_K: experiment temperature in Kelvin.
    """
    import numpy as np
    import pandas as pd
    if eta_min >= eta_max:
        raise ValueError("eta_min must be < eta_max")
    centres = np.arange(eta_min + window_width_V/2.0, eta_max - window_width_V/2.0 + 1e-12, step_V)
    rows = []
    for c in centres:
        lo, hi = float(c - window_width_V/2.0), float(c + window_width_V/2.0)
        try:
            fit = linear_fit_log_ik_vs_eta(eta_V, ik_A, (lo, hi), T_K=T_K)
            rows.append({
                "eta_lo_V": lo,
                "eta_hi_V": hi,
                "eta_centre_V": float(c),
                "tafel_slope_mV_dec": fit["tafel_slope_mV_dec"],
                "alpha": fit["alpha"],
                "rsq": fit["rsq"],
                "n_points": fit["n_points"],
            })
        except ValueError:
            # window doesn't have enough points
            continue
    return pd.DataFrame(rows)

"""Tools package for the chem_ec01 SCP benchmark task.

The agent must compose these primitives to extract Tafel kinetic
parameters from raw electrochemistry experiments.

Sub-modules:
- ``data_io``      : load LSV / CV CSVs and the experiment metadata table.
- ``corrections``  : iR drop, blank subtraction, reference-electrode
                     conversion to RHE, Koutecky-Levich mass-transfer
                     correction, double-layer capacitance / ECSA from CV.
- ``tafel``        : log(ik) vs eta (TP), DTP differentiation, linear
                     Tafel slope fit, exchange-current extraction,
                     overpotential-at-fixed-current, Tafel range checks.
- ``benchmark``    : tabulate kinetic parameters across systems and
                     compute headline benchmark figures.
- ``plotting``     : matplotlib helpers; every function returns
                     ``{"path": "<file>.png"}``.

None of these primitives encodes the headline conclusion of the paper;
the agent is expected to call them in the correct order to reproduce it.
"""

from . import benchmark, corrections, data_io, plotting, tafel  # noqa: F401

__all__ = ["data_io", "corrections", "tafel", "benchmark", "plotting"]

"""Electrochemistry corrections: iR drop, reference-to-RHE conversion,
mass-transfer (Koutecky-Levich), blank/double-layer subtraction, and
double-layer capacitance / electrochemical surface area extraction from
CV scan-rate sweeps.

These primitives use only ``numpy`` and ``pandas``.  They never apply a
correction silently -- every transformation produces a new column or a
new array that the caller can audit.
"""
from __future__ import annotations

from typing import Dict, Tuple

import numpy as np
import pandas as pd


def convert_potential_to_RHE(E_vs_ref: np.ndarray, ref_offset_V: float) -> np.ndarray:
    """Return E_vs_RHE = E_vs_ref + ref_offset_V (vector)."""
    arr = np.asarray(E_vs_ref, dtype=np.float64)
    return arr + float(ref_offset_V)


def apply_iR_correction(
    E_V: np.ndarray, i_A: np.ndarray, Rs_ohm: float, fraction: float = 1.0
) -> np.ndarray:
    """Return iR-corrected potential, E - fraction * i * Rs.

    The user can pass ``fraction < 1`` to model partial compensation.
    """
    if Rs_ohm < 0:
        raise ValueError("Rs_ohm must be >= 0")
    if not (0.0 <= fraction <= 1.0):
        raise ValueError("fraction must lie in [0,1]")
    Earr = np.asarray(E_V, dtype=np.float64)
    iarr = np.asarray(i_A, dtype=np.float64)
    return Earr - fraction * iarr * float(Rs_ohm)


def overpotential_from_RHE(
    E_RHE_V: np.ndarray, reaction: str, pH: float | None = None
) -> np.ndarray:
    """Return overpotential ``eta = E_RHE - E_eq``.

    ``reaction`` selects the standard equilibrium potential vs RHE:
    HER -> 0 V, OER -> 1.229 V, ORR -> 1.229 V, ferricyanide -> 0.36 V
    (vs SHE; converted to RHE using ``pH`` if supplied, else 0 V).

    Note that the returned ``eta`` is signed: negative for cathodic
    branches (HER, ORR, ferricyanide reduction) and positive for the
    anodic OER.
    """
    Earr = np.asarray(E_RHE_V, dtype=np.float64)
    r = reaction.upper()
    if r == "HER":
        Eeq = 0.0
    elif r in ("OER", "ORR"):
        Eeq = 1.229
    elif r in ("FERRICYANIDE", "FE(CN)6"):
        # Standard E0 of Fe(CN)6 3-/4- vs SHE ~ 0.36 V; convert to RHE.
        # IMPORTANT: pH must be supplied because Fe(CN)6 reduction is run in
        # buffered solutions whose pH directly shifts E_eq vs RHE; the
        # bundled ferricyanide experiment uses pH read from
        # experiment_metadata.csv (the 0.1 M KCl + 1 mM Fe(CN)6 supporting
        # electrolyte has a near-neutral pH that the agent should source
        # from the metadata file rather than this helper defaulting it).
        if pH is None:
            raise ValueError(
                "ferricyanide overpotential requires pH; pass the experiment_metadata pH explicitly"
            )
        E_SHE = 0.36
        # Ferricyanide is pH-independent vs SHE. Convert SHE -> RHE:
        # E_vs_RHE = E_vs_SHE + 0.0591 * pH  (RHE is more negative than SHE
        # by 0.0591*pH, so a fixed SHE potential corresponds to a more
        # positive RHE potential).
        Eeq = E_SHE + 0.0591 * pH
    else:
        raise ValueError(f"unknown reaction {reaction}")
    return Earr - Eeq


def subtract_blank(i_A: np.ndarray, i_blank_A: np.ndarray) -> np.ndarray:
    """Return ``i_A - i_blank_A`` (faradaic current after blank subtraction)."""
    return np.asarray(i_A, dtype=np.float64) - np.asarray(i_blank_A, dtype=np.float64)


def estimate_limiting_current(
    i_A: np.ndarray, frac: float = 0.05, sign: str = "auto"
) -> float:
    """Estimate iL by averaging the plateau region of the polarisation curve.

    The plateau is taken as the ``frac`` fraction of points with the
    largest absolute current.  ``sign='auto'`` chooses the sign from the
    data; pass ``'cathodic'`` to force iL < 0 or ``'anodic'`` to force
    iL > 0.
    """
    arr = np.asarray(i_A, dtype=np.float64)
    if not (0.0 < frac < 1.0):
        raise ValueError("frac must be in (0,1)")
    n_take = max(3, int(np.round(frac * arr.size)))
    if sign == "auto":
        if np.mean(arr) < 0:
            sign = "cathodic"
        else:
            sign = "anodic"
    if sign == "cathodic":
        idx = np.argsort(arr)[:n_take]  # most negative
    elif sign == "anodic":
        idx = np.argsort(arr)[-n_take:]  # most positive
    else:
        raise ValueError(f"sign must be 'auto'|'cathodic'|'anodic', got {sign}")
    return float(np.mean(arr[idx]))


def koutecky_levich_correction(
    i_A: np.ndarray, iL: float, eps: float = 1e-12
) -> np.ndarray:
    """Mass-transfer correction:  ik = i * iL / (iL - i).

    This is Eq.(9) of Khadke 2021.  It returns the kinetic current ``ik``
    consistent with the assumed limiting current ``iL``.  When ``i``
    asymptotes to ``iL`` the kinetic current diverges; values where
    ``|iL - i| < eps`` are masked to NaN.
    """
    iarr = np.asarray(i_A, dtype=np.float64)
    denom = float(iL) - iarr
    out = iarr * float(iL) / np.where(np.abs(denom) < eps, np.nan, denom)
    return out


def linear_region_capacitive_current(
    cv: pd.DataFrame, E_centre_V: float, half_window_V: float = 0.005
) -> pd.DataFrame:
    """Pick the (forward, reverse) currents at a centre potential for
    each scan rate, by averaging a small window.

    Returns a long-format table with columns
    ``scan_rate_V_s, i_forward_A, i_reverse_A, i_capacitive_A``
    where ``i_capacitive = (i_forward - i_reverse) / 2`` is the
    standard double-layer current at the chosen E.
    """
    rows = []
    lo = E_centre_V - half_window_V
    hi = E_centre_V + half_window_V
    for v_mV, sub in cv.groupby("scan_rate_mV_s"):
        v_V = v_mV / 1000.0
        win = sub[(sub["E_vs_RHE_V"] >= lo) & (sub["E_vs_RHE_V"] <= hi)]
        if win.empty:
            continue
        i_fwd = float(win.loc[win["branch"] == "forward", "i_A"].mean())
        i_rev = float(win.loc[win["branch"] == "reverse", "i_A"].mean())
        rows.append({
            "scan_rate_V_s": v_V,
            "i_forward_A": i_fwd,
            "i_reverse_A": i_rev,
            "i_capacitive_A": 0.5 * (i_fwd - i_rev),
        })
    return pd.DataFrame(rows)


def double_layer_capacitance_from_cv(
    cv: pd.DataFrame,
    area_cm2: float,
    E_centre_V: float = 0.35,
    half_window_V: float = 0.005,
    Cs_uF_cm2: float = 40.0,
) -> Dict[str, float]:
    """Compute Cdl by linear regression of i_capacitive vs scan rate.

    The slope of ``i_capacitive`` (in A) vs the scan rate (in V/s) at a
    fixed centre potential is the double-layer capacitance ``Cdl`` (in
    Farads).  Dividing by ``area_cm2`` gives the geometric-area-specific
    Cdl (F/cm2).  ECSA is computed as ``ECSA = Cdl / Cs`` with the
    specific capacitance ``Cs_uF_cm2`` (default 40 uF/cm^2 for a smooth
    metal in alkaline media; pass a different value when the literature
    convention or analyst preference differs). The returned dict
    includes ``Cs_F_cm2`` so the assumption is reported alongside the
    derived ECSA.

    Returns a dictionary with keys ``Cdl_F``, ``Cdl_F_cm2``,
    ``Cdl_uF_cm2``, ``ECSA_cm2``, ``ECSA_per_geom``, ``Cs_F_cm2``,
    ``Cs_uF_cm2`` (both Cs unit forms are returned so callers can
    pick the column-name convention used by their downstream
    benchmark table; ``Cs_uF_cm2`` is the convention used by
    ``task_content/task_content.json`` and the bundled benchmark
    template), ``intercept_A`` and ``rsq``.
    """
    if area_cm2 <= 0:
        raise ValueError("area_cm2 must be > 0")
    tab = linear_region_capacitive_current(cv, E_centre_V, half_window_V)
    if len(tab) < 3:
        raise ValueError("need at least 3 scan rates for Cdl regression")
    x = tab["scan_rate_V_s"].to_numpy(dtype=np.float64)
    y = tab["i_capacitive_A"].to_numpy(dtype=np.float64)
    # ordinary least-squares via numpy
    A = np.vstack([x, np.ones_like(x)]).T
    coef, *_ = np.linalg.lstsq(A, y, rcond=None)
    slope, intercept = float(coef[0]), float(coef[1])
    yhat = slope * x + intercept
    ss_res = float(np.sum((y - yhat) ** 2))
    ss_tot = float(np.sum((y - y.mean()) ** 2)) if y.size > 1 else 0.0
    rsq = float(1.0 - ss_res / ss_tot) if ss_tot > 0 else float("nan")
    Cdl_F = slope  # i = Cdl * dE/dt, so slope of i vs nu is Cdl
    Cs_F_cm2 = Cs_uF_cm2 * 1e-6
    ECSA_cm2 = Cdl_F / Cs_F_cm2
    return {
        "Cdl_F": Cdl_F,
        "Cdl_F_cm2": Cdl_F / area_cm2,
        "Cdl_uF_cm2": Cdl_F / area_cm2 * 1e6,
        "ECSA_cm2": ECSA_cm2,
        "ECSA_per_geom": ECSA_cm2 / area_cm2,
        "Cs_F_cm2": Cs_F_cm2,
        "Cs_uF_cm2": float(Cs_uF_cm2),
        "intercept_A": intercept,
        "rsq": rsq,
    }


def cv_capacitive_table(
    cv: pd.DataFrame,
    E_centre_V: float = 0.35,
    half_window_V: float = 0.005,
) -> pd.DataFrame:
    """Convenience wrapper exposing the per-scan-rate capacitive current
    table to the agent (for plotting and inspection)."""
    return linear_region_capacitive_current(cv, E_centre_V, half_window_V)


def overpotential_at_current_density(
    j_A_cm2: np.ndarray, E_RHE_V: np.ndarray, j_target_A_cm2: float, reaction: str,
    pH: float | None = None,
) -> Tuple[float, float]:
    """Linear-interpolate the overpotential at a target current density.

    Returns ``(eta_V, E_RHE_V)``.  ``j_target_A_cm2`` should match the
    sign of the data (positive for OER, negative for HER/ORR).  The
    target is matched on absolute value, so passing 0.01 (= 10 mA/cm2)
    works for either branch.

    Handles BOTH anodic (|j| ascending with E) and cathodic (|j| ascending
    as E becomes more negative) curves by detecting the first |j| crossing
    of the target in the natural sweep direction (sorted by E ascending).

    ``pH`` is required when the reaction is ferricyanide because the
    Fe(CN)6 3-/4- equilibrium potential vs RHE is pH-dependent; the
    agent should pass the experiment-specific pH from
    ``experiment_metadata.csv``.
    """
    j = np.asarray(j_A_cm2, dtype=np.float64)
    E = np.asarray(E_RHE_V, dtype=np.float64)
    if j.size != E.size:
        raise ValueError("size mismatch")
    abs_j = np.abs(j)
    abs_t = abs(float(j_target_A_cm2))
    order = np.argsort(E)
    E_sorted = E[order]
    abs_j_sorted = abs_j[order]
    if abs_t < abs_j_sorted.min() or abs_t > abs_j_sorted.max():
        raise ValueError(
            f"target |j|={abs_t:g} outside data range [{abs_j_sorted.min():g},"
            f" {abs_j_sorted.max():g}]"
        )
    # Find ALL sign changes in (|j| - target) between adjacent E-sorted points.
    # This works for both anodic (|j| increasing with E) and cathodic (|j| decreasing with E):
    # we want the segment where |j| crosses the target threshold, irrespective of direction.
    diff = abs_j_sorted - abs_t
    sign_changes = np.where(diff[:-1] * diff[1:] <= 0)[0]
    if len(sign_changes) == 0:
        raise ValueError("no crossing of target |j| found in data range")
    # Pick the first crossing (closest to onset).  For cathodic curves this
    # corresponds to the first time |j| exits a low-|j| region (small overpotential)
    # and reaches the target; for anodic the same logic applies.
    idx = int(sign_changes[0]) + 1
    j0, j1 = abs_j_sorted[idx - 1], abs_j_sorted[idx]
    E0, E1 = E_sorted[idx - 1], E_sorted[idx]
    if j1 == j0:
        E_at = float(E0)
    else:
        E_at = float(E0 + (E1 - E0) * (abs_t - j0) / (j1 - j0))
    eta = overpotential_from_RHE(np.asarray([E_at]), reaction, pH=pH).item()
    return float(eta), float(E_at)

"""Plotting primitives for chem_ec01.

Every function returns ``{"path": "<output_png_path>"}`` and writes a PNG
to disk.  Plots use the non-interactive ``Agg`` backend so they work in
headless environments.
"""
from __future__ import annotations

import os
from typing import Dict, Mapping, Sequence

import numpy as np
import pandas as pd

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402


def _ensure_parent(path: str) -> None:
    parent = os.path.dirname(os.path.abspath(path))
    if parent:
        os.makedirs(parent, exist_ok=True)


def plot_polarization_curves(
    series: Mapping[str, pd.DataFrame],
    out_path: str,
    title: str = "Polarisation curves",
    x_col: str = "E_vs_RHE_V",
    y_col: str = "j_A_cm2",
    j_clip_mA_cm2: float | None = 30.0,
) -> Dict[str, str]:
    """Overlay LSV polarisation curves for several systems.

    ``series`` maps a label to a DataFrame with the columns ``x_col``
    (potential) and ``y_col`` (current density).  ``j_clip_mA_cm2``
    bounds the y-axis to make the 10 mA/cm2 reference visible across
    fast and slow systems; pass ``None`` to disable.
    """
    _ensure_parent(out_path)
    fig, ax = plt.subplots(figsize=(7.0, 5.0), dpi=150)
    palette = ["#2e64a8", "#e07b3a", "#3a8c44", "#9c4cad", "#c84444", "#666666"]
    for i, (label, df) in enumerate(series.items()):
        c = palette[i % len(palette)]
        ax.plot(df[x_col].to_numpy(), df[y_col].to_numpy() * 1000.0, color=c, label=label, lw=1.5)
    ax.axhline(0.0, color="grey", lw=0.8)
    ax.axhline(10.0, color="black", lw=0.6, linestyle="--", alpha=0.5)
    ax.axhline(-10.0, color="black", lw=0.6, linestyle="--", alpha=0.5)
    if j_clip_mA_cm2 is not None:
        ax.set_ylim(-j_clip_mA_cm2, j_clip_mA_cm2)
    ax.set_xlabel("E vs RHE (V)")
    ax.set_ylabel("j (mA cm$^{-2}$)")
    ax.set_title(title)
    ax.legend(fontsize=9, loc="best")
    fig.tight_layout()
    fig.savefig(out_path, bbox_inches="tight")
    plt.close(fig)
    return {"path": out_path}


def plot_tafel(
    series: Mapping[str, Mapping[str, np.ndarray]],
    out_path: str,
    title: str = "Tafel plots",
    current_unit: str = "A cm$^{-2}$",
) -> Dict[str, str]:
    """Plot ln|ik| or log10|ik| vs eta for several systems.

    ``series`` maps a label to a dict with keys ``eta_V`` and
    ``log10_abs_ik`` (or ``ln_abs_ik``).  If both are present log10 is
    preferred.  Optional fit lines may be drawn from ``fit_eta`` and
    ``fit_log10_ik`` arrays.

    ``current_unit`` controls only the y-axis label string. The bundle's
    Tafel pipeline passes current DENSITY (A/cm^2), so the default label
    is `log10|ik| (A cm^-2)`; pass ``current_unit="A"`` if the caller is
    plotting raw absolute current.
    """
    _ensure_parent(out_path)
    fig, ax = plt.subplots(figsize=(7.0, 5.0), dpi=150)
    palette = ["#2e64a8", "#e07b3a", "#3a8c44", "#9c4cad", "#c84444", "#666666"]
    for i, (label, payload) in enumerate(series.items()):
        c = palette[i % len(palette)]
        eta = np.asarray(payload["eta_V"])
        if "log10_abs_ik" in payload:
            y = np.asarray(payload["log10_abs_ik"])
            ax.plot(eta, y, "o", color=c, markersize=2.5, alpha=0.5, label=label)
        elif "ln_abs_ik" in payload:
            y = np.asarray(payload["ln_abs_ik"]) / np.log(10.0)
            ax.plot(eta, y, "o", color=c, markersize=2.5, alpha=0.5, label=label)
        if "fit_eta" in payload and "fit_log10_ik" in payload:
            ax.plot(payload["fit_eta"], payload["fit_log10_ik"], color=c, lw=2.0)
    ax.set_xlabel(r"$\eta$ (V)")
    ax.set_ylabel(rf"$\log_{{10}}|i_k|$ ({current_unit})")
    ax.set_title(title)
    ax.legend(fontsize=9, loc="best")
    fig.tight_layout()
    fig.savefig(out_path, bbox_inches="tight")
    plt.close(fig)
    return {"path": out_path}


def plot_dtp(
    series: Mapping[str, pd.DataFrame],
    out_path: str,
    title: str = "Differential Tafel plots",
    plateau: Mapping[str, Dict[str, float]] | None = None,
) -> Dict[str, str]:
    """Plot alpha(eta) for each system; optionally shade the identified
    Tafel plateau.

    ``series`` maps a label to a DataFrame with columns ``eta_V`` and
    ``alpha`` (output of ``differential_tafel_plot``).  ``plateau`` (if
    given) maps the same labels to ``find_tafel_plateau`` outputs.
    """
    _ensure_parent(out_path)
    n = len(series)
    fig, axs = plt.subplots(n, 1, figsize=(7.0, 2.5 * n), dpi=150, sharex=False)
    if n == 1:
        axs = [axs]
    palette = ["#2e64a8", "#e07b3a", "#3a8c44", "#9c4cad", "#c84444", "#666666"]
    for ax, (label, dtp), c in zip(axs, series.items(), palette):
        ax.plot(dtp["eta_V"].to_numpy(), dtp["alpha"].to_numpy(), color=c, lw=1.4, label=label)
        ax.set_ylabel(r"$\alpha$")
        ax.set_ylim(0.0, 1.0)
        ax.set_title(label, fontsize=10)
        if plateau is not None and label in plateau and plateau[label].get("found"):
            p = plateau[label]
            ax.axvspan(p["eta_lo_V"], p["eta_hi_V"], color=c, alpha=0.15)
            ax.axhline(p["median_alpha"], color=c, lw=0.8, linestyle="--")
    axs[-1].set_xlabel(r"$\eta$ (V)")
    fig.suptitle(title)
    fig.tight_layout(rect=(0, 0, 1, 0.97))
    fig.savefig(out_path, bbox_inches="tight")
    plt.close(fig)
    return {"path": out_path}


def plot_cdl_regression(
    cap_table: pd.DataFrame,
    out_path: str,
    Cdl_F: float | None = None,
    intercept_A: float | None = None,
    title: str = "Double-layer capacitance",
) -> Dict[str, str]:
    """Plot i_capacitive vs scan rate with a fitted line and report Cdl."""
    _ensure_parent(out_path)
    fig, ax = plt.subplots(figsize=(6.0, 4.5), dpi=150)
    x = cap_table["scan_rate_V_s"].to_numpy(dtype=np.float64)
    y = cap_table["i_capacitive_A"].to_numpy(dtype=np.float64) * 1e6  # uA
    ax.plot(x, y, "o", color="#2e64a8", markersize=6)
    if Cdl_F is not None:
        b = float(intercept_A) if intercept_A is not None else 0.0
        xfit = np.linspace(x.min(), x.max(), 50)
        yfit = (Cdl_F * xfit + b) * 1e6
        ax.plot(xfit, yfit, color="#c84444", lw=2.0, label=f"Cdl = {Cdl_F*1e6:.1f} uF")
        ax.legend()
    ax.set_xlabel(r"Scan rate $\nu$ (V s$^{-1}$)")
    ax.set_ylabel(r"$i_\mathrm{capacitive}$ ($\mu$A)")
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(out_path, bbox_inches="tight")
    plt.close(fig)
    return {"path": out_path}


def plot_benchmark_bar(
    table: pd.DataFrame,
    out_path: str,
    metric_col: str = "tafel_slope_mV_dec_DTP",
    title: str = "Tafel slope by system",
) -> Dict[str, str]:
    """Bar chart of the chosen kinetic metric per system."""
    _ensure_parent(out_path)
    fig, ax = plt.subplots(figsize=(7.0, 4.5), dpi=150)
    labels = table["system_id"].tolist()
    vals = table[metric_col].to_numpy(dtype=np.float64)
    palette = ["#2e64a8", "#e07b3a", "#3a8c44", "#9c4cad", "#c84444", "#666666"]
    colors = [palette[i % len(palette)] for i in range(len(labels))]
    ax.bar(range(len(labels)), vals, color=colors)
    ax.set_xticks(range(len(labels)))
    ax.set_xticklabels(labels, rotation=20, ha="right", fontsize=9)
    ax.set_ylabel(metric_col.replace("_", " "))
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(out_path, bbox_inches="tight")
    plt.close(fig)
    return {"path": out_path}


def plot_tp_vs_dtp_comparison(
    table: pd.DataFrame,
    out_path: str,
    title: str = "TP vs DTP Tafel slopes",
) -> Dict[str, str]:
    """Side-by-side bars of TP and DTP Tafel slopes per system on a
    single axis, with the SIGNED disagreement (TP - DTP, in mV/dec)
    annotated above each pair of bars (positive when the naive linear
    Tafel fit overshoots the differential-Tafel plateau slope).
    """
    _ensure_parent(out_path)
    fig, ax = plt.subplots(figsize=(8.0, 4.8), dpi=150)
    labels = table["system_id"].tolist()
    x = np.arange(len(labels), dtype=np.float64)
    w = 0.35
    bp = ax.bar(x - w / 2.0, table["tafel_slope_mV_dec_TP"].to_numpy(), w,
                color="#2e64a8", label="TP linear fit")
    bd = ax.bar(x + w / 2.0, table["tafel_slope_mV_dec_DTP"].to_numpy(), w,
                color="#e07b3a", label="DTP plateau")
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=20, ha="right", fontsize=9)
    ax.set_ylabel("Tafel slope (mV/dec)")
    ax.set_title(title)
    ax.legend(fontsize=9)
    # annotate absolute differences on top
    a = table["tafel_slope_mV_dec_TP"].to_numpy()
    b = table["tafel_slope_mV_dec_DTP"].to_numpy()
    for xi, ai, bi in zip(x, a, b):
        d = ai - bi
        y = max(ai, bi) + 5.0
        ax.text(xi, y, f"$\\Delta$ = {d:+.0f}", ha="center", fontsize=8, color="#444")
    fig.tight_layout()
    fig.savefig(out_path, bbox_inches="tight")
    plt.close(fig)
    return {"path": out_path}


def plot_benchmark_table(
    table: pd.DataFrame,
    out_path: str,
    title: str = "Per-system kinetic-parameter benchmark",
    columns: list | None = None,
) -> Dict[str, str]:
    """Render the kinetic-parameter table from benchmark.kinetic_parameter_table
    as a per-system summary figure (one row per system_id, columns are the
    headline kinetic parameters). The table is shown as a matplotlib table
    rendered onto a figure so it can be saved as Fig_benchmark.png.

    Args:
        table: DataFrame returned by tools.benchmark.kinetic_parameter_table
            (must contain a system_id column).
        out_path: artifacts path to save the PNG.
        title: figure title.
        columns: optional list of columns to display. If None, picks a sensible
            subset of headline kinetic parameters that are present in `table`.
    """
    _ensure_parent(out_path)
    if columns is None:
        # Pick the full headline kinetic parameter set the benchmark targets.
        # Covers TP/DTP Tafel slopes + per-route alphas + per-route i0
        # (TP and DTP analyses have independent i0 estimates), the
        # overpotential-at-10-mA/cm2 milestone, and the Pt-disk Cdl/ECSA
        # extraction. Columns absent from `table` are silently dropped so
        # the helper still works on partial benchmarks (e.g. before the
        # Cdl analysis is appended).
        preferred = [
            "system_id",
            "alpha_TP", "alpha_DTP",
            "tafel_slope_mV_dec_TP", "tafel_slope_mV_dec_DTP",
            "i0_A_cm2_TP", "i0_A_cm2_DTP", "i0_A_cm2",
            "eta_at_10mAcm2_V",
            "Cdl_uF_cm2", "Cs_uF_cm2", "ECSA_cm2", "ECSA_per_geom",
        ]
        columns = [c for c in preferred if c in table.columns]
    df = table[columns].copy()
    for c in df.columns:
        if c != "system_id":
            df[c] = df[c].apply(lambda x: ("--" if pd.isna(x) else f"{float(x):.3g}"))
    fig_w = max(6.0, 1.1 * len(df.columns))
    fig_h = max(2.0, 0.55 * (len(df) + 2))
    fig, ax = plt.subplots(figsize=(fig_w, fig_h), dpi=150)
    ax.axis("off")
    tbl = ax.table(
        cellText=df.values.tolist(),
        colLabels=df.columns.tolist(),
        loc="center",
        cellLoc="center",
    )
    tbl.auto_set_font_size(False)
    tbl.set_fontsize(9)
    tbl.scale(1.0, 1.4)
    ax.set_title(title, fontsize=11)
    fig.tight_layout()
    fig.savefig(out_path, bbox_inches="tight")
    plt.close(fig)
    return {"path": out_path}


def plot_window_scan(
    scan: pd.DataFrame,
    out_path: str,
    title: str = "Tafel slope vs window centre",
    system_col: str = "system_id",
    window_centre_col: str = "eta_centre_V",
    slope_col: str = "tafel_slope_mV_dec",
) -> Dict[str, str]:
    """Plot fitted Tafel slope vs window centre (signed eta) for each
    system_id, using the table returned by tools.tafel.scan_tafel_windows.

    Use to visualise how strongly the apparent naive Tafel slope depends on
    where the analyst centres the eta window — the headline diagnostic that
    motivates the differential-Tafel plateau workflow.
    """
    _ensure_parent(out_path)
    fig, ax = plt.subplots(figsize=(7.0, 4.5), dpi=150)
    palette = ["#2e64a8", "#e07b3a", "#3a8c44", "#9c4cad", "#c84444", "#666666"]
    systems = list(scan[system_col].unique())
    for i, sysid in enumerate(systems):
        sub = scan[scan[system_col] == sysid].sort_values(window_centre_col)
        c = palette[i % len(palette)]
        ax.plot(
            sub[window_centre_col].to_numpy(),
            sub[slope_col].to_numpy(),
            "o-", color=c, label=str(sysid), markersize=4, linewidth=1.2,
        )
    ax.set_xlabel(r"Window centre $\eta$ (V)")
    ax.set_ylabel("Fitted Tafel slope (mV/dec)")
    ax.set_title(title)
    ax.legend(fontsize=9)
    fig.tight_layout()
    fig.savefig(out_path, bbox_inches="tight")
    plt.close(fig)
    return {"path": out_path}


def plot_ecp(
    series: Mapping[str, pd.DataFrame],
    out_path: str,
    title: str = "Exchange current plot",
    current_unit: str = "A cm$^{-2}$",
    current_col: str = "i0_local_A",
) -> Dict[str, str]:
    """Plot i0(eta) on a log axis vs eta for each system, where i0 is
    derived locally as ik / exp(alpha*f*eta).  Only for diagnostic use;
    the *true* i0 is a single number extracted in the Tafel plateau.

    ``current_unit`` controls only the y-axis label string. The bundle's
    Tafel pipeline passes current DENSITY (A/cm^2), so the default label
    is `|i_0| (A cm^-2)`; pass ``current_unit="A"`` if the caller is
    plotting raw absolute current.
    """
    _ensure_parent(out_path)
    fig, ax = plt.subplots(figsize=(7.0, 4.5), dpi=150)
    palette = ["#2e64a8", "#e07b3a", "#3a8c44", "#9c4cad", "#c84444", "#666666"]
    for i, (label, df) in enumerate(series.items()):
        c = palette[i % len(palette)]
        ax.semilogy(df["eta_V"].to_numpy(), np.abs(df[current_col].to_numpy()),
                    color=c, label=label)
    ax.set_xlabel(r"$\eta$ (V)")
    ax.set_ylabel(rf"$|i_0|$ ({current_unit})")
    ax.set_title(title)
    ax.legend(fontsize=9)
    fig.tight_layout()
    fig.savefig(out_path, bbox_inches="tight")
    plt.close(fig)
    return {"path": out_path}

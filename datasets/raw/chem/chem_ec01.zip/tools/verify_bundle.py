#!/usr/bin/env python3
"""verify_bundle.py — confirm chem_ec01 zip contents match task_content.json.

Checks:
  - 4 LSV CSVs, 1 CV CSV and experiment_metadata.csv all exist
  - experiment_metadata.csv carries the pH column (required by
    corrections.py::overpotential_from_RHE for ferricyanide)
  - all 7 bundled artifacts exist (PNGs)
  - every input_data path declared in task_content.json is physically present
  - artifacts/ has no agent_-prefixed files
Exit 0 = all pass.
"""

from __future__ import annotations

import csv
import json
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path

EXPECTED_LSV_CSVS = [
    "input_data/data/ORR_Pt_C_20ugPt.csv",
    "input_data/data/ORR_Pt_C_5ugPt.csv",
    "input_data/data/Ferricyanide_Au.csv",
    "input_data/data/OER_Pt_disk.csv",
]
EXPECTED_CV_CSV = "input_data/data/CV_double_layer_Pt.csv"
EXPECTED_METADATA = "input_data/data/experiment_metadata.csv"
EXPECTED_ARTIFACTS = [
    "artifacts/Fig_dtp.png",
    "artifacts/Fig_tp_vs_dtp.png",
    "artifacts/Fig_polarization.png",
    "artifacts/Fig_benchmark.png",
    "artifacts/Fig_cdl.png",
    "artifacts/Fig_tafel.png",
    "artifacts/Fig_window_scan.png",
]


def main(root_or_zip: str) -> int:
    p = Path(root_or_zip)
    cleanup: Path | None = None
    if p.suffix == ".zip" and p.is_file():
        extract = Path(tempfile.mkdtemp(prefix="chem_ec01_verify_"))
        cleanup = extract
        with zipfile.ZipFile(p) as zf:
            zf.extractall(extract)
        if (extract / "chem_ec01").is_dir():
            root = extract / "chem_ec01"
        else:
            root = extract
    else:
        root = p

    errs: list[str] = []

    for rel in EXPECTED_LSV_CSVS:
        if not (root / rel).is_file():
            errs.append(f"MISSING LSV: {rel}")

    if not (root / EXPECTED_CV_CSV).is_file():
        errs.append(f"MISSING CV: {EXPECTED_CV_CSV}")

    meta_path = root / EXPECTED_METADATA
    if not meta_path.is_file():
        errs.append(f"MISSING metadata: {EXPECTED_METADATA}")
    else:
        with open(meta_path, newline="") as f:
            header = next(csv.reader(f))
            if "pH" not in header:
                errs.append("experiment_metadata.csv: 'pH' column required by "
                            "corrections.overpotential_from_RHE for ferricyanide")

    for rel in EXPECTED_ARTIFACTS:
        if not (root / rel).is_file():
            errs.append(f"MISSING artifact: {rel}")

    tc = root / "task_content" / "task_content.json"
    if tc.is_file():
        j = json.load(open(tc))
        for item in j.get("input_data", []):
            if not (root / item["path"]).is_file():
                errs.append(f"task_content declares missing input: {item['path']}")
        # Verify answer weights sum exactly to 1.0 — handle both schemas:
        # (a) answer is a list of items directly, or
        # (b) answer is an object with an answer_items list inside.
        ans_obj = j.get("answer", [])
        if isinstance(ans_obj, list):
            items = ans_obj
        elif isinstance(ans_obj, dict):
            items = ans_obj.get("answer_items", [])
            if not isinstance(items, list):
                errs.append("answer.answer_items must be a list, got "
                            f"{type(items).__name__}")
                items = []
        else:
            errs.append(f"answer must be list or object, got "
                        f"{type(ans_obj).__name__}")
            items = []
        if items:
            tot = sum(float(it.get("weight", 0)) for it in items)
            if abs(tot - 1.0) > 1e-9:
                errs.append(f"answer weights sum = {tot:.10f} != 1.0")

    art = root / "artifacts"
    if art.is_dir():
        for f in art.iterdir():
            if f.name.startswith("agent_"):
                errs.append(f"agent_-prefixed file should not be bundled: {f.name}")

    if cleanup is not None:
        shutil.rmtree(cleanup, ignore_errors=True)
    if errs:
        print("verify_bundle: FAIL")
        for e in errs:
            print(" -", e)
        return 1
    print("verify_bundle: OK — 4 LSV CSVs + 1 CV CSV + experiment_metadata.csv "
          "(with pH column), 7 bundled artifacts, all input_data declarations "
          "resolved, answer weights sum to 1.0; no agent_-prefixed leakage.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1] if len(sys.argv) > 1 else "."))

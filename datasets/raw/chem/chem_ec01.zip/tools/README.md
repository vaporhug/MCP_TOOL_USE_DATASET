# chem_ec01 — tool reference

This README lists the public functions actually exported by each module
(matching `def foo(...)` in the .py files). Refer to each function's
docstring for the full parameter list.

## data_io.py

- `load_lsv_csv(path)` — load an LSV CSV (E_vs_ref_V, i_A, i_blank_A).
- `load_cv_csv(path)` — load `CV_double_layer_Pt.csv` (scan_rate_mV_s,
  branch, E_vs_RHE_V, i_A).
- `load_metadata(path)` — load `experiment_metadata.csv` as a DataFrame
  with the standard columns including `pH`.
- `list_systems(meta)` — return the system_id list from the metadata.
- `get_system_meta(meta, system_id)` — return the metadata row as a dict.
- `lsv_summary(df)` — descriptive stats on an LSV DataFrame.
- `to_current_density(df, area_cm2)` — add `j_A_cm2` column.
- `merge_lsv_with_meta(df, meta_row)` — attach per-system metadata.

## corrections.py

- `convert_potential_to_RHE(E_vs_ref, ref_offset_V)` — shift measured
  potentials by `ref_offset_to_RHE_V`.
- `apply_iR_correction(E_array, i_array, Rs_ohm)` — subtract the
  iR drop.
- `overpotential_from_RHE(E_RHE_V, reaction, pH=None)` — convert
  RHE-referenced potential to overpotential η for a given reaction.
  Ferricyanide requires the `pH` keyword from `experiment_metadata.csv`.
- `subtract_blank(i_A, i_blank_A)` — background-subtract a blank scan.
- `estimate_limiting_current(...)` — j_L estimator.
- `koutecky_levich_correction(j, j_L)` — j_k = j · j_L / (j_L − j).
- `linear_region_capacitive_current(...)`, `double_layer_capacitance_from_cv(...)`,
  `cv_capacitive_table(...)` — Cdl extraction from the CV double-layer scans.
- `overpotential_at_current_density(...)` — interpolate η at a target j.

## tafel.py

- `tafel_plot(eta_V, ik_A)` — build a DataFrame of log10|i_k| vs η.
- `linear_fit_log_ik_vs_eta(...)` — naive linear (TP) Tafel fit.
- `compute_alpha_from_slope(slope_per_V, T_K)` — convert slope → α.
- `differential_tafel_plot(...)` — α(η) curve (DTP analysis).
- `find_tafel_plateau(...)` — plateau identification on the DTP curve.
- `exchange_current_from_intercept(...)` — i_0 from the Tafel-line
  intercept (computed for both the TP and DTP fits independently;
  callers populate `i0_A_cm2_TP` and `i0_A_cm2_DTP` from the two calls).
- `tafel_overpotential_required(alpha, T_K)` — minimum η for Tafel regime.
- `is_within_tafel_range(...)` — sanity check.
- `scan_tafel_windows(eta_V, ik_A, eta_min, eta_max, window_width_V=0.06,
  step_V=0.01, T_K=294.15)` — window-sensitivity sweep; returns one row
  per window with `eta_centre_V` and `tafel_slope_mV_dec` (consumed by
  `plotting.plot_window_scan`).

## benchmark.py

- `kinetic_parameter_table(rows)` — assemble the per-system kinetic
  parameter DataFrame. The full headline column set is documented in
  the docstring: alpha/Tafel-slope/i0 for both TP and DTP routes
  (`alpha_TP/DTP`, `tafel_slope_mV_dec_TP/DTP`, `i0_A_cm2_TP/DTP` or
  legacy `i0_A_cm2`), plus `eta_at_10mAcm2_V`, and (for the Pt-disk
  OER row) `Cdl_uF_cm2`, `Cs_uF_cm2`, `ECSA_cm2`, `ECSA_per_geom`.
  Rows that do not have a particular column should leave that cell
  as `NaN`.
- `tp_dtp_disagreement(table)` — adds `delta_b_mV_dec` (absolute
  |TP − DTP|), `signed_delta_b_mV_dec` (TP − DTP, for direction), and
  `rel_delta_b_percent` (absolute, %).
- `fraction_systems_with_disagreement(table, threshold_mV_dec=5)` —
  count of rows whose `delta_b_mV_dec > threshold`.
- `rank_by_tafel_slope(...)` — sort by Tafel slope.
- `summarize_tafel_range(table)` — descriptive stats.

## plotting.py

All helpers take pandas DataFrames or `{label: payload}` mappings and
an output `.png` path; they create the artifacts/ directory if missing.

- `plot_polarization_curves(...)` — Fig_polarization.png
- `plot_tafel(..., current_unit="A cm$^{-2}$")` — Fig_tafel.png; the
  default `current_unit` matches the bundle pipeline which passes
  current DENSITY into the Tafel fit. Pass `current_unit="A"` for raw
  absolute current.
- `plot_dtp(...)` — Fig_dtp.png (α(η) curves with plateau bands)
- `plot_cdl_regression(...)` — Fig_cdl.png
- `plot_benchmark_bar(...)` — single-column bar.
- `plot_benchmark_table(table, out_path, columns=None)` — default
  Fig_benchmark.png. When `columns=None` the function picks the full
  headline column set documented above.
- `plot_tp_vs_dtp_comparison(...)` — Fig_tp_vs_dtp.png
- `plot_window_scan(scan_df, out_path,
  window_centre_col="eta_centre_V")` — Fig_window_scan.png; default
  `window_centre_col` matches `tafel.scan_tafel_windows` output.
- `plot_ecp(..., current_unit="A cm$^{-2}$", current_col="i0_local_A")`
  — diagnostic ECP plot.

## verify_bundle.py

Run `python tools/verify_bundle.py <bundle_root_or_zip>` to confirm the
4 LSV CSVs, the CV CSV, `experiment_metadata.csv` (with `pH` column),
and the 7 bundled artifacts are all present. Exit code 0 = pass.

## Bundled processing-parameter defaults (reproducibility)

To make solver results reproducible, the bundled tools fix the per-system
TP / DTP processing parameters listed below. Pass these defaults through
all four LSV systems unless explicitly overriding them; the answer's
tolerance bands assume these values.

Per-system Tafel-analysis windows. The `|η|` ranges describe the
overpotential magnitude (paper convention). The bundled tools
(`linear_fit_log_ik_vs_eta`, `find_tafel_plateau`,
`scan_tafel_windows`) filter on the SIGNED η value, so the
cathodic-reaction tool inputs use the negated range
(η < 0 for ORR and ferricyanide). The right-most column gives the
exact signed-η interval to pass into the tools:

| system_id                | \|η\| window  | DTP plateau search | signed_eta_window_for_tools | Notes                                          |
|--------------------------|----------------|--------------------|-----------------------------|------------------------------------------------|
| ORR_Pt_C_20ugPt          | 0.05 – 0.30 V  | 0.05 – 0.40 V      | (−0.30, −0.05)              | Cathodic; Koutecky–Levich on iL                 |
| ORR_Pt_C_5ugPt           | 0.05 – 0.30 V  | 0.05 – 0.40 V      | (−0.30, −0.05)              | Bare-GC co-catalysis at high η; K-L on iL       |
| Ferricyanide_Au          | 0.05 – 0.20 V  | 0.02 – 0.25 V      | (−0.20, −0.05)              | Narrow useable Tafel range (≈ 70 mV per paper)  |
| OER_Pt_disk              | 0.30 – 0.55 V  | 0.30 – 0.55 V      | (0.30, 0.55)                | No measured iL → use iR+blank-corrected j       |

Other locked defaults (matching the actual algorithm in the .py files):

- `differential_tafel_plot(eta_V, ik_A, smoothing_window=21, T_K=294.15)`
  computes `alpha(eta)` by a centred finite-difference stencil of width
  `smoothing_window` on `ln|i_k|` (default window = 21 samples; pass the
  same value through all four systems). NOT a Savitzky-Golay filter — a
  centred finite difference on the smoothed log-current.
- `find_tafel_plateau(dtp, eta_search, alpha_tol=0.025, min_width_V=0.05)`
  picks the longest contiguous run of points whose alpha varies by less
  than `alpha_tol` around the local mean and whose η-width is at least
  `min_width_V`. Pass the per-system `eta_search` ranges from the table
  above; use the default `alpha_tol=0.025` and `min_width_V=0.05`.
- `estimate_limiting_current(i_A, frac=0.05, sign='auto')` averages the
  `frac` fraction of points with the largest absolute current. For ORR
  and ferricyanide pass `sign='cathodic'` and the default `frac=0.05`;
  OER on Pt has no measured iL and SKIPS Koutecky–Levich entirely.
- iR correction: `apply_iR_correction(E, i, Rs_ohm)` with `Rs_ohm` from
  `experiment_metadata.csv` (per system).
- Blank subtraction: always subtract `i_blank_A` before any kinetic
  current step.
- `koutecky_levich_correction`: apply ONLY to ORR_Pt_C_20ugPt,
  ORR_Pt_C_5ugPt and Ferricyanide_Au (the three systems with a
  measurable iL); SKIP for OER_Pt_disk per the paper's no-iL convention.

## Cdl / ECSA convention (Pt-disk OER only)

The bundled `double_layer_capacitance_from_cv` extracts `Cdl_uF_cm2`
from the linear `i_capacitive_A` vs `scan_rate_V_s` fit on the Pt disk's
CV double-layer sweeps. ECSA is computed as
`ECSA_cm2 = Cdl_uF_cm2 · A_geom / Cs_uF_cm2`, where the specific
double-layer capacitance is locked at `Cs_uF_cm2 = 40` µF/cm² — the
Trasatti & Petrii 1991 IUPAC-recommended value for polycrystalline Pt
in aqueous electrolyte. Use this Cs value for the Pt-disk OER row.
The other three systems lack supporting CV double-layer data and
report `NaN` in the `Cdl_uF_cm2`, `Cs_uF_cm2`, `ECSA_cm2`,
`ECSA_per_geom` columns of the benchmark table.

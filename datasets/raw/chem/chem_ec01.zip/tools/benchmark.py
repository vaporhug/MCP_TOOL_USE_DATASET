"""Benchmark-table primitives.

These functions tabulate the kinetic parameters across the four systems
defined in ``experiment_metadata.csv`` and compute headline benchmark
metrics: Tafel-slope agreement between TP and DTP analyses, the i0_A_cm2 (exchange current DENSITY, A/cm^2 — caller is expected to pass current-density inputs to the Tafel fit)
extracted from each, and (where applicable) the overpotential at 10
mA/cm2 (geometric).
"""
from __future__ import annotations

from typing import Dict, List

import numpy as np
import pandas as pd


def kinetic_parameter_table(rows: List[Dict[str, float]]) -> pd.DataFrame:
    """Concatenate per-system kinetic-parameter dicts into a benchmark table.

    Each row should have at minimum ``system_id``, ``tafel_slope_mV_dec_TP``,
    ``tafel_slope_mV_dec_DTP``, ``alpha_TP``, ``alpha_DTP``, and an
    exchange-current-density field, plus ``rsq_TP`` and ``eta_at_10mAcm2_V``
    (or NaN where not available).

    Field-name conventions for the exchange current density (A/cm^2):

    - ``i0_A_cm2_TP``  — i0 extracted from the naive linear (TP) Tafel fit
    - ``i0_A_cm2_DTP`` — i0 extracted from the differential-Tafel (DTP)
      plateau analysis
    - ``i0_A_cm2``     — legacy single-field name; treated as the DTP value
      when both new fields are absent

    For the Pt-disk OER system, append per-electrode double-layer fields:

    - ``Cdl_uF_cm2``  — double-layer capacitance from CV slope (uF/cm^2)
    - ``Cs_uF_cm2``   — specific reference capacitance used for ECSA
      (also returned as ``Cs_F_cm2`` for back-compat)
    - ``ECSA_cm2``    — electrochemically active surface area (cm^2)
    - ``ECSA_per_geom`` — ECSA / geometric area (roughness factor)

    All four Cdl/ECSA columns are NaN on systems without CV_double_layer_*
    support (only the Pt disk in this bundle).
    """
    if not rows:
        raise ValueError("no rows passed")
    df = pd.DataFrame(rows)
    return df


def tp_dtp_disagreement(table: pd.DataFrame) -> pd.DataFrame:
    """For each row of ``table`` compute the absolute difference and the
    relative difference (%) between the TP and DTP Tafel slopes.

    Returns a copy of ``table`` with two new columns: ``delta_b_mV_dec``
    and ``rel_delta_b_percent``.
    """
    out = table.copy()
    if "tafel_slope_mV_dec_TP" not in out.columns or "tafel_slope_mV_dec_DTP" not in out.columns:
        raise KeyError("table must have tafel_slope_mV_dec_TP and _DTP columns")
    a = out["tafel_slope_mV_dec_TP"].to_numpy(dtype=np.float64)
    b = out["tafel_slope_mV_dec_DTP"].to_numpy(dtype=np.float64)
    # Absolute differences (matching the "absolute difference" docstring
    # contract and the abs-thresholded `fraction_systems_with_disagreement`
    # caller below). A signed version is kept under signed_delta_b_mV_dec
    # for callers that need the direction (TP > DTP or DTP > TP).
    out["delta_b_mV_dec"] = np.abs(a - b)
    out["signed_delta_b_mV_dec"] = a - b
    with np.errstate(divide="ignore", invalid="ignore"):
        rel = np.abs(a - b) / np.where(np.abs(b) > 0, np.abs(b), np.nan) * 100.0
    out["rel_delta_b_percent"] = rel
    return out


def fraction_systems_with_disagreement(
    table: pd.DataFrame, threshold_mV_dec: float = 5.0
) -> Dict[str, float]:
    """How many systems have |b_TP - b_DTP| > threshold mV/dec?"""
    if "delta_b_mV_dec" not in table.columns:
        table = tp_dtp_disagreement(table)
    n_total = int(len(table))
    n_disagree = int(np.sum(np.abs(table["delta_b_mV_dec"].to_numpy()) > threshold_mV_dec))
    return {
        "n_total": n_total,
        "n_disagree": n_disagree,
        "fraction": float(n_disagree) / n_total if n_total > 0 else float("nan"),
        "threshold_mV_dec": threshold_mV_dec,
    }


def rank_by_tafel_slope(
    table: pd.DataFrame, slope_col: str = "tafel_slope_mV_dec_DTP"
) -> pd.DataFrame:
    """Sort the systems ascending by Tafel slope (smaller = better kinetics)."""
    if slope_col not in table.columns:
        raise KeyError(slope_col)
    out = table.sort_values(slope_col).reset_index(drop=True)
    out["rank"] = np.arange(1, len(out) + 1, dtype=int)
    return out


def summarize_tafel_range(table: pd.DataFrame) -> pd.DataFrame:
    """Compute the *experimental* Tafel range width per system from
    columns ``eta_lo_V`` and ``eta_hi_V``.  Returns a copy with a new
    column ``tafel_range_width_V``.
    """
    out = table.copy()
    if "eta_lo_V" not in out.columns or "eta_hi_V" not in out.columns:
        raise KeyError("table must have eta_lo_V and eta_hi_V columns")
    out["tafel_range_width_V"] = out["eta_hi_V"].to_numpy() - out["eta_lo_V"].to_numpy()
    return out

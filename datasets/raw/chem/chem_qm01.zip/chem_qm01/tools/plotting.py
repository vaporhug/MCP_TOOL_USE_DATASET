"""Plotting helpers for the QM9 KRR benchmark.

All functions write a PNG to ``path`` and return ``{"path": path}``.

Functions
---------
plot_parity(y_true, y_pred, label, path, units, title)
plot_learning_curve(sizes, mae_curves, labels, path, property_label, target_mae)
plot_residual_histogram(y_true, y_pred, path, units, label, n_bins)
plot_error_by_property(property_names, mae_values, path, target_values)
"""
from __future__ import annotations

import os
from typing import Dict, Iterable, Sequence

import matplotlib

matplotlib.use("Agg")  # headless backend for pipeline use
import matplotlib.pyplot as plt
import numpy as np


def _ensure_parent(path: str) -> None:
    parent = os.path.dirname(os.path.abspath(path))
    if parent and not os.path.isdir(parent):
        os.makedirs(parent, exist_ok=True)


def plot_parity(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    label: str,
    path: str,
    units: str = "",
    title: str | None = None,
) -> Dict[str, str]:
    """Scatter ``y_true`` vs ``y_pred`` with a y = x reference line."""
    _ensure_parent(path)
    yt = np.asarray(y_true, dtype=np.float64)
    yp = np.asarray(y_pred, dtype=np.float64)
    fig, ax = plt.subplots(figsize=(5.0, 5.0))
    ax.scatter(yt, yp, s=8, alpha=0.4, color="#2c7fb8", label=label)
    lo = float(min(yt.min(), yp.min()))
    hi = float(max(yt.max(), yp.max()))
    pad = 0.05 * (hi - lo)
    ax.plot([lo - pad, hi + pad], [lo - pad, hi + pad], "k--", linewidth=1.0)
    ax.set_xlim(lo - pad, hi + pad)
    ax.set_ylim(lo - pad, hi + pad)
    xlab = f"reference [{units}]" if units else "reference"
    ylab = f"prediction [{units}]" if units else "prediction"
    ax.set_xlabel(xlab)
    ax.set_ylabel(ylab)
    if title:
        ax.set_title(title)
    ax.legend(loc="upper left")
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(path, dpi=140)
    plt.close(fig)
    return {"path": path}


def plot_learning_curve(
    sizes: Sequence[int],
    mae_curves: Dict[str, Sequence[float]],
    path: str,
    property_label: str = "",
    target_mae: float | None = None,
) -> Dict[str, str]:
    """Log-log learning curve.  ``mae_curves`` maps a label to per-size MAE."""
    _ensure_parent(path)
    fig, ax = plt.subplots(figsize=(6.0, 4.5))
    colors = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd"]
    for i, (lab, vals) in enumerate(mae_curves.items()):
        ax.plot(sizes, vals, marker="o", color=colors[i % len(colors)], label=lab)
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlabel("Training set size N")
    ylab = f"MAE [{property_label}]" if property_label else "MAE"
    ax.set_ylabel(ylab)
    if target_mae is not None and target_mae > 0:
        ax.axhline(target_mae, color="black", linestyle=":", linewidth=1.0,
                   label=f"chemical accuracy ({target_mae})")
    ax.legend(loc="best")
    ax.grid(True, which="both", alpha=0.3)
    fig.tight_layout()
    fig.savefig(path, dpi=140)
    plt.close(fig)
    return {"path": path}


def plot_residual_histogram(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    path: str,
    units: str = "",
    label: str = "",
    n_bins: int = 40,
) -> Dict[str, str]:
    """Histogram of signed residuals ``y_pred - y_true``."""
    _ensure_parent(path)
    yt = np.asarray(y_true, dtype=np.float64)
    yp = np.asarray(y_pred, dtype=np.float64)
    res = yp - yt
    fig, ax = plt.subplots(figsize=(6.0, 4.0))
    ax.hist(res, bins=n_bins, color="#2c7fb8", alpha=0.8, edgecolor="white")
    ax.axvline(0.0, color="black", linestyle="--", linewidth=1.0)
    mae = float(np.mean(np.abs(res)))
    ax.set_xlabel(f"residual (pred - ref) [{units}]" if units else "residual (pred - ref)")
    ax.set_ylabel("count")
    ax.set_title(f"{label}  MAE = {mae:.4g}" + (f" {units}" if units else ""))
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(path, dpi=140)
    plt.close(fig)
    return {"path": path}


def plot_error_by_property(
    property_names: Sequence[str],
    mae_values: Dict[str, Sequence[float]],
    path: str,
    target_values: Sequence[float] | None = None,
) -> Dict[str, str]:
    """Grouped bar chart: per-property MAE for one or more (representation, regressor) labels."""
    _ensure_parent(path)
    n_props = len(property_names)
    n_models = len(mae_values)
    width = 0.8 / max(1, n_models)
    x = np.arange(n_props)
    fig, ax = plt.subplots(figsize=(max(6.0, n_props * 0.9), 4.0))
    colors = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd"]
    for i, (lab, vals) in enumerate(mae_values.items()):
        if len(vals) != n_props:
            raise ValueError(f"mae_values[{lab!r}] has {len(vals)} entries, expected {n_props}")
        ax.bar(x + i * width - 0.4 + width / 2.0, vals, width=width, color=colors[i % len(colors)], label=lab)
    if target_values is not None:
        if len(target_values) != n_props:
            raise ValueError("target_values length mismatch")
        for j, t in enumerate(target_values):
            ax.hlines(t, x[j] - 0.4, x[j] + 0.4, colors="black", linestyles="--", linewidth=1.0)
    ax.set_xticks(x)
    ax.set_xticklabels(property_names, rotation=30, ha="right")
    ax.set_ylabel("MAE (native units)")
    ax.set_yscale("log")
    ax.legend(loc="best")
    ax.grid(True, axis="y", which="both", alpha=0.3)
    fig.tight_layout()
    fig.savefig(path, dpi=140)
    plt.close(fig)
    return {"path": path}

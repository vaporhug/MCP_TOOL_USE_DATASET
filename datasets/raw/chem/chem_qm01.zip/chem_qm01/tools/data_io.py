"""Data loaders for the QM9 subset.

Functions
---------
load_properties_csv(path)
load_structures_json(path)
load_atomic_reference(path)
hartree_to_ev(value)
hartree_to_kcal_per_mol(value)
compute_atomization_energy_kcal(elements, u0_total_Ha, atomref)
train_test_split_indices(n_total, n_train, n_test, seed)
get_property_array(rows, key, dtype)
"""
from __future__ import annotations

import csv
import json
from typing import Dict, List, Sequence, Tuple

import numpy as np


HA_TO_EV = 27.211386245988
HA_TO_KCAL = 627.5094740631


def load_properties_csv(path: str) -> List[Dict[str, str]]:
    """Read the QM9 subset properties CSV into a list of dicts.

    The file has ``mol_id`` plus 19 numeric columns (rotational constants,
    dipole, polarizability, HOMO/LUMO, gap, r2, zpve, u0/u298/h298/g298,
    Cv, and atomization energies in kcal/mol).  Numeric values are kept as
    strings; use :func:`get_property_array` to cast.
    """
    with open(path) as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    if not rows:
        raise ValueError(f"empty CSV: {path}")
    return rows


def load_structures_json(path: str) -> Dict[str, Dict]:
    """Load the structures JSON keyed by ``mol_id``.

    Each value is ``{"n_atoms": int, "elements": [str, ...],
    "coords_angstrom": [[x, y, z], ...]}``.
    """
    with open(path) as f:
        records = json.load(f)
    return {r["mol_id"]: r for r in records}


def load_atomic_reference(path: str) -> Dict[str, float]:
    """Load atomic-reference energies (in Hartree) keyed by element symbol."""
    refs: Dict[str, float] = {}
    with open(path) as f:
        reader = csv.DictReader(f)
        for row in reader:
            refs[row["element"]] = float(row["u0_isolated_Ha"])
    if not refs:
        raise ValueError(f"empty atomref: {path}")
    return refs


def hartree_to_ev(value):
    """Convert energy from Hartree to electron-volt."""
    return np.asarray(value, dtype=np.float64) * HA_TO_EV


def hartree_to_kcal_per_mol(value):
    """Convert energy from Hartree to kcal/mol."""
    return np.asarray(value, dtype=np.float64) * HA_TO_KCAL


def compute_atomization_energy_kcal(
    elements: Sequence[str],
    u0_total_Ha: float,
    atomref: Dict[str, float],
) -> float:
    """Return atomization energy in kcal/mol.

    Defined as ``- (E_total - sum_i E_atom(i))`` so larger positive values
    correspond to more strongly bound molecules, in line with the
    ``u0_atom`` column of the QM9 CSV (which is already in kcal/mol with
    sign convention ``+`` for binding).
    """
    e_atoms = sum(atomref[el] for el in elements)
    e_atomization_Ha = e_atoms - float(u0_total_Ha)
    return float(e_atomization_Ha) * HA_TO_KCAL


def train_test_split_indices(
    n_total: int,
    n_train: int,
    n_test: int,
    seed: int = 0,
) -> Tuple[np.ndarray, np.ndarray]:
    """Return ``(train_idx, test_idx)`` numpy arrays of integer indices.

    The remaining indices (if any) are discarded.  Disjointness is
    guaranteed.  Raises ``ValueError`` if ``n_train + n_test > n_total``.
    """
    if n_train + n_test > n_total:
        raise ValueError(f"n_train + n_test = {n_train + n_test} > n_total = {n_total}")
    rng = np.random.default_rng(seed)
    perm = rng.permutation(n_total)
    train_idx = np.sort(perm[:n_train])
    test_idx = np.sort(perm[n_train : n_train + n_test])
    return train_idx, test_idx


def get_property_array(
    rows: Sequence[Dict[str, str]],
    key: str,
    dtype=np.float64,
) -> np.ndarray:
    """Extract column ``key`` from a list of dict rows as a typed array."""
    if not rows:
        return np.zeros(0, dtype=dtype)
    if key not in rows[0]:
        raise KeyError(f"column {key!r} not in row keys {list(rows[0].keys())}")
    return np.asarray([dtype(r[key]) for r in rows], dtype=dtype)

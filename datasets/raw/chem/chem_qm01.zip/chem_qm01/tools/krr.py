"""Kernel ridge regression with Gaussian and Laplacian kernels.

All linear algebra is via ``numpy.linalg`` (Cholesky / lstsq); no sklearn
dependency.  The agent should chain ``compute_kernel_matrix`` ->
``train_krr`` -> ``predict_krr`` to fit a model.

Functions
---------
gaussian_kernel_matrix(X, Y, sigma)
laplacian_kernel_matrix(X, Y, sigma)
compute_kernel_matrix(X, Y, kernel, sigma)
median_pairwise_distance(X, n_subsample, seed)
sigma_grid_from_distance(d_median, factors)
train_krr(K_train, y_train, lam)
predict_krr(K_test, alpha)
fit_predict_krr(X_train, y_train, X_test, sigma, lam, kernel)
cv_select_sigma_lambda(X_train, y_train, sigma_grid, lambda_grid, k_folds, kernel, seed)
"""
from __future__ import annotations

from typing import Dict, Sequence, Tuple

import numpy as np


# ---------------------------------------------------------------------------
# Kernels
# ---------------------------------------------------------------------------
def _pairwise_sq_dist(X: np.ndarray, Y: np.ndarray) -> np.ndarray:
    """Return the (Nx, Ny) matrix of squared L2 distances."""
    Xn = (X * X).sum(axis=1)
    Yn = (Y * Y).sum(axis=1)
    sq = Xn[:, None] + Yn[None, :] - 2.0 * X @ Y.T
    return np.maximum(sq, 0.0)


def _pairwise_l1_dist(X: np.ndarray, Y: np.ndarray) -> np.ndarray:
    """Return the (Nx, Ny) matrix of L1 distances (slow but exact)."""
    out = np.empty((X.shape[0], Y.shape[0]), dtype=np.float64)
    for i in range(X.shape[0]):
        out[i] = np.sum(np.abs(Y - X[i]), axis=1)
    return out


def gaussian_kernel_matrix(X: np.ndarray, Y: np.ndarray, sigma: float) -> np.ndarray:
    """Return ``K[i, j] = exp(-||x_i - y_j||_2^2 / (2 sigma^2))``."""
    if sigma <= 0:
        raise ValueError("sigma must be positive")
    sq = _pairwise_sq_dist(np.asarray(X, dtype=np.float64), np.asarray(Y, dtype=np.float64))
    return np.exp(-sq / (2.0 * sigma * sigma))


def laplacian_kernel_matrix(X: np.ndarray, Y: np.ndarray, sigma: float) -> np.ndarray:
    """Return ``K[i, j] = exp(-||x_i - y_j||_1 / sigma)``.

    The Laplacian kernel is the standard choice for Coulomb-matrix
    representations (Hansen et al. 2013, Faber et al. 2017) because the
    representation has spike-like discontinuities under permutation
    sorting that the L1 metric handles better than L2.
    """
    if sigma <= 0:
        raise ValueError("sigma must be positive")
    d = _pairwise_l1_dist(np.asarray(X, dtype=np.float64), np.asarray(Y, dtype=np.float64))
    return np.exp(-d / sigma)


def compute_kernel_matrix(
    X: np.ndarray,
    Y: np.ndarray,
    kernel: str = "gaussian",
    sigma: float = 1.0,
) -> np.ndarray:
    """Dispatch to the requested kernel; ``kernel`` in ``{"gaussian", "laplacian"}``."""
    if kernel == "gaussian":
        return gaussian_kernel_matrix(X, Y, sigma)
    if kernel == "laplacian":
        return laplacian_kernel_matrix(X, Y, sigma)
    raise ValueError(f"unknown kernel: {kernel!r}")


# ---------------------------------------------------------------------------
# Sigma selection helpers
# ---------------------------------------------------------------------------
def median_pairwise_distance(
    X: np.ndarray,
    n_subsample: int = 200,
    seed: int = 0,
    metric: str = "l2",
) -> float:
    """Median pairwise distance over a random subset.

    Used as a heuristic centre value for the Gaussian/Laplacian sigma
    grid.  ``metric`` selects ``"l2"`` (Euclidean) or ``"l1"`` (Manhattan).
    """
    n = X.shape[0]
    n_use = min(n_subsample, n)
    rng = np.random.default_rng(seed)
    idx = rng.choice(n, size=n_use, replace=False)
    sub = X[idx]
    if metric == "l2":
        d = np.sqrt(_pairwise_sq_dist(sub, sub))
    elif metric == "l1":
        d = _pairwise_l1_dist(sub, sub)
    else:
        raise ValueError(f"unknown metric {metric!r}")
    iu = np.triu_indices(n_use, k=1)
    return float(np.median(d[iu]))


def sigma_grid_from_distance(
    d_median: float,
    factors: Sequence[float] = (0.25, 0.5, 1.0, 2.0, 4.0),
) -> np.ndarray:
    """Build a sigma grid as multiples of ``d_median``."""
    return d_median * np.asarray(factors, dtype=np.float64)


# ---------------------------------------------------------------------------
# KRR fit / predict
# ---------------------------------------------------------------------------
def train_krr(K_train: np.ndarray, y_train: np.ndarray, lam: float) -> np.ndarray:
    """Solve ``(K + lam I) alpha = y`` via Cholesky and return ``alpha``.

    Falls back to ``np.linalg.lstsq`` if the regularised kernel is not
    positive definite (very rare for sensible lam > 0).
    """
    n = K_train.shape[0]
    if K_train.shape[1] != n or y_train.shape[0] != n:
        raise ValueError("shape mismatch in train_krr")
    A = K_train + lam * np.eye(n)
    try:
        L = np.linalg.cholesky(A)
        z = np.linalg.solve(L, y_train)
        alpha = np.linalg.solve(L.T, z)
    except np.linalg.LinAlgError:
        alpha, *_ = np.linalg.lstsq(A, y_train, rcond=None)
    return alpha


def fit_predict_krr(
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_test: np.ndarray,
    sigma: float,
    lam: float,
    kernel: str = "gaussian",
) -> Dict[str, np.ndarray]:
    """End-to-end convenience: fit on (X_train, y_train), predict on X_test.

    Returns ``{"alpha", "y_pred", "K_train", "K_test"}``.
    """
    K_train = compute_kernel_matrix(X_train, X_train, kernel=kernel, sigma=sigma)
    K_test = compute_kernel_matrix(X_test, X_train, kernel=kernel, sigma=sigma)
    alpha = train_krr(K_train, y_train, lam)
    y_pred = _predict_krr_inner(K_test, alpha)
    return {"alpha": alpha, "y_pred": y_pred, "K_train": K_train, "K_test": K_test}


def cv_select_sigma_lambda(
    X_train: np.ndarray,
    y_train: np.ndarray,
    sigma_grid: Sequence[float],
    lambda_grid: Sequence[float],
    k_folds: int = 5,
    kernel: str = "gaussian",
    seed: int = 0,
) -> Dict[str, float]:
    """K-fold CV over (sigma, lambda); minimises mean MAE.

    Returns ``{"sigma": float, "lambda": float, "cv_mae": float, "scores": ndarray}``.
    """
    X = np.asarray(X_train, dtype=np.float64)
    y = np.asarray(y_train, dtype=np.float64)
    n = X.shape[0]
    rng = np.random.default_rng(seed)
    perm = rng.permutation(n)
    fold_sizes = [n // k_folds + (1 if i < n % k_folds else 0) for i in range(k_folds)]
    folds: list[np.ndarray] = []
    s = 0
    for fs in fold_sizes:
        folds.append(perm[s : s + fs])
        s += fs

    sigma_grid = np.asarray(sigma_grid, dtype=np.float64)
    lambda_grid = np.asarray(lambda_grid, dtype=np.float64)
    scores = np.zeros((len(sigma_grid), len(lambda_grid)), dtype=np.float64)
    for fi in range(k_folds):
        val_idx = folds[fi]
        train_idx = np.concatenate([folds[k] for k in range(k_folds) if k != fi])
        Xtr, ytr = X[train_idx], y[train_idx]
        Xva, yva = X[val_idx], y[val_idx]
        for i_s, sigma in enumerate(sigma_grid):
            K_tr = compute_kernel_matrix(Xtr, Xtr, kernel=kernel, sigma=float(sigma))
            K_va = compute_kernel_matrix(Xva, Xtr, kernel=kernel, sigma=float(sigma))
            for j_l, lam in enumerate(lambda_grid):
                alpha = train_krr(K_tr, ytr, float(lam))
                yhat = K_va @ alpha
                scores[i_s, j_l] += float(np.mean(np.abs(yhat - yva))) / k_folds
    i_best = np.unravel_index(np.argmin(scores), scores.shape)
    return {
        "sigma": float(sigma_grid[i_best[0]]),
        "lambda": float(lambda_grid[i_best[1]]),
        "cv_mae": float(scores[i_best]),
        "scores": scores,
    }


def _predict_krr_inner(K_test: np.ndarray, alpha: np.ndarray) -> np.ndarray:
    return np.asarray(K_test) @ np.asarray(alpha)


def predict_krr(K_test: np.ndarray, alpha: np.ndarray) -> np.ndarray:
    """Compute test predictions ``K_test @ alpha``.

    Convention: ``K_test`` has shape ``(n_test, n_train)`` so the
    ``i``-th test point's prediction is ``sum_j K_test[i, j] alpha[j]``.
    """
    return np.asarray(K_test) @ np.asarray(alpha)



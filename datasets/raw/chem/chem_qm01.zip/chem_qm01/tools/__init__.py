"""Quantum-chemistry molecular machine-learning primitives for the QM9 task.

Submodules
----------
data_io          : load CSV / structure JSON / atomref tables.
representations  : Coulomb matrix (sorted L1), bag-of-bonds, descriptor utilities.
krr              : kernel ridge regression with Gaussian kernel from scratch
                   (numpy linalg only -- no sklearn).
metrics          : RMSE, MAE, R^2, learning-curve helpers.
plotting         : parity plot, learning-curve plot, residual histogram, error-by-property.

All numerics use numpy.linalg only; the agent should not need to import sklearn or
rdkit anywhere -- chain primitives instead.  Plotting functions write a PNG and
return ``{"path": "<file>"}``.
"""
from . import data_io, representations, krr, metrics, plotting  # noqa: F401

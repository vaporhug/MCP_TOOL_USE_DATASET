"""Molecular representations for KRR.

Functions
---------
nuclear_charge(element)
coulomb_matrix(elements, coords_angstrom, max_size, sort_by_row_norm)
flatten_upper_triangular(matrix)
coulomb_matrix_eigenvalues(matrix)
build_coulomb_matrix_descriptors(structures, max_size, mode)
bag_of_bonds(elements, coords_angstrom, bag_sizes)
build_bag_of_bonds_descriptors(structures, bag_sizes)
infer_bag_sizes(structures, pad_quantile)
inverse_distance_atomic(elements, coords_angstrom)
sorted_distances_descriptor(elements, coords_angstrom, max_pairs)

The descriptors are pure-numpy and avoid any dependency on rdkit / openbabel.
"""
from __future__ import annotations

from collections import Counter
from typing import Dict, Iterable, List, Sequence, Tuple

import numpy as np


# ---------------------------------------------------------------------------
# Atomic data
# ---------------------------------------------------------------------------
_NUCLEAR_CHARGE = {
    "H": 1.0,
    "C": 6.0,
    "N": 7.0,
    "O": 8.0,
    "F": 9.0,
    "P": 15.0,
    "S": 16.0,
    "Cl": 17.0,
    "Br": 35.0,
    "I": 53.0,
}


def nuclear_charge(element: str) -> float:
    """Return Z for the given element symbol (CHNOFPSClBrI supported)."""
    if element not in _NUCLEAR_CHARGE:
        raise KeyError(f"unsupported element: {element!r}")
    return _NUCLEAR_CHARGE[element]


# ---------------------------------------------------------------------------
# Coulomb matrix
# ---------------------------------------------------------------------------
def coulomb_matrix(
    elements: Sequence[str],
    coords_angstrom: Sequence[Sequence[float]],
    max_size: int,
    sort_by_row_norm: bool = True,
) -> np.ndarray:
    """Build a padded sorted Coulomb matrix of shape ``(max_size, max_size)``.

    Rupp et al. (Phys. Rev. Lett. 108, 058301, 2012):

    .. math::
        C_{ii} = 0.5 Z_i^{2.4}, \\quad
        C_{ij} = Z_i Z_j / r_{ij} \\;\\;(i \\ne j)

    where ``r_{ij}`` is in Bohr.  Coordinates passed in Angstrom are
    converted internally (1 Bohr = 0.5291772109 A).  The atom rows are
    sorted in descending order of ``||C_i||`` to remove permutation
    invariance, then padded with zeros to ``max_size``.
    """
    if max_size < 1:
        raise ValueError("max_size must be >= 1")
    n_atoms = len(elements)
    if n_atoms > max_size:
        raise ValueError(f"molecule has {n_atoms} atoms > max_size = {max_size}")
    Z = np.array([nuclear_charge(e) for e in elements], dtype=np.float64)
    coords_bohr = np.asarray(coords_angstrom, dtype=np.float64) / 0.5291772109
    # pairwise distance in Bohr
    diff = coords_bohr[:, None, :] - coords_bohr[None, :, :]
    r = np.linalg.norm(diff, axis=-1)
    np.fill_diagonal(r, 1.0)  # avoid /0; diagonal is overwritten below
    M = (Z[:, None] * Z[None, :]) / r
    # diagonal:
    np.fill_diagonal(M, 0.5 * Z ** 2.4)
    if sort_by_row_norm:
        # L1 row norm (sum of absolute values) — the standard sorted-Coulomb-matrix
        # convention used by Rupp et al. 2012 and the QM9 / FCHL papers. Using the
        # L2 (default numpy) norm here would silently change the descriptor ordering.
        norms = np.sum(np.abs(M), axis=1)
        order = np.argsort(-norms)
        M = M[order][:, order]
    out = np.zeros((max_size, max_size), dtype=np.float64)
    out[:n_atoms, :n_atoms] = M
    return out


def flatten_upper_triangular(matrix: np.ndarray) -> np.ndarray:
    """Return the upper-triangular (incl. diagonal) of a square matrix as a 1-D vector."""
    if matrix.ndim != 2 or matrix.shape[0] != matrix.shape[1]:
        raise ValueError("expect square matrix")
    iu = np.triu_indices(matrix.shape[0])
    return matrix[iu]


def coulomb_matrix_eigenvalues(matrix: np.ndarray) -> np.ndarray:
    """Return sorted-descending eigenvalues of a (symmetric) Coulomb matrix."""
    w = np.linalg.eigvalsh(matrix)
    return np.sort(w)[::-1]


def build_coulomb_matrix_descriptors(
    structures: Iterable[Dict],
    max_size: int,
    mode: str = "sorted_full",
) -> np.ndarray:
    """Build a ``(N, D)`` descriptor matrix from a list of structure dicts.

    ``mode`` selects the flattening scheme:

    - ``"sorted_full"`` -- full sorted CM padded to ``max_size``,
      flattened row-major (D = max_size**2).
    - ``"upper"``       -- upper-triangle (incl. diagonal) of the sorted
      padded CM (D = max_size*(max_size+1)//2).
    - ``"eigenvalues"`` -- sorted eigenvalues of the sorted padded CM
      (D = max_size).
    """
    feats: List[np.ndarray] = []
    for rec in structures:
        M = coulomb_matrix(rec["elements"], rec["coords_angstrom"], max_size)
        if mode == "sorted_full":
            feats.append(M.flatten())
        elif mode == "upper":
            feats.append(flatten_upper_triangular(M))
        elif mode == "eigenvalues":
            feats.append(coulomb_matrix_eigenvalues(M))
        else:
            raise ValueError(f"unknown mode {mode!r}")
    return np.vstack(feats)


# ---------------------------------------------------------------------------
# Bag of Bonds (Hansen et al. 2015)
# ---------------------------------------------------------------------------
def _pair_key(a: str, b: str) -> Tuple[str, str]:
    return (a, b) if a <= b else (b, a)


def bag_of_bonds(
    elements: Sequence[str],
    coords_angstrom: Sequence[Sequence[float]],
    bag_sizes: Dict[Tuple[str, str], int],
    diag_sizes: Dict[str, int] | None = None,
) -> np.ndarray:
    """Compute the bag-of-bonds descriptor for one molecule.

    For every pair (incl. self-pair for the diagonal terms) we collect the
    Coulomb matrix entries ``Z_i Z_j / r_ij`` (in Bohr units) and store
    them sorted descending into a fixed-length bag of size
    ``bag_sizes[(a, b)]``; missing slots are zero-padded.  The diagonal
    half-Z**2.4 entries are stored in their own per-element bags
    (``diag_sizes[el]``); if ``diag_sizes`` is ``None`` the per-element
    counts are taken from ``bag_sizes[(el, el)]``.

    The output is the concatenation of all bags in lexicographic order of
    their key ``(a, b)`` (off-diagonal) followed by self-bags ``(el,)``.
    """
    n_atoms = len(elements)
    Z = np.array([nuclear_charge(e) for e in elements], dtype=np.float64)
    coords_bohr = np.asarray(coords_angstrom, dtype=np.float64) / 0.5291772109
    # bags
    off_bags: Dict[Tuple[str, str], List[float]] = {k: [] for k in bag_sizes}
    diag_bags: Dict[str, List[float]] = {}
    for i in range(n_atoms):
        diag_bags.setdefault(elements[i], []).append(0.5 * Z[i] ** 2.4)
        for j in range(i + 1, n_atoms):
            r = float(np.linalg.norm(coords_bohr[i] - coords_bohr[j]))
            v = Z[i] * Z[j] / r if r > 0 else 0.0
            key = _pair_key(elements[i], elements[j])
            if key in off_bags:
                off_bags[key].append(v)
            # else: silently dropped if molecule contains an element pair
            # not specified in bag_sizes
    # determine diag sizes
    if diag_sizes is None:
        diag_sizes = {el: bag_sizes.get((el, el), 0) for el in diag_bags}
    # assemble: emit ALL off-diagonal bags (including same-element pairs
    # like (C,C), (H,H) which are physical Coulomb interactions between
    # different atoms of the same element, distinct from the diagonal
    # 0.5*Z^2.4 entries that get their own per-element bags below).
    out: List[float] = []
    for key in sorted(bag_sizes):
        size = bag_sizes[key]
        vals = sorted(off_bags.get(key, []), reverse=True)
        if len(vals) > size:
            vals = vals[:size]
        elif len(vals) < size:
            vals = vals + [0.0] * (size - len(vals))
        out.extend(vals)
    # diagonal bags: 0.5*Z^2.4 entries, one per atom, grouped by element
    for el in sorted(diag_sizes):
        size = diag_sizes[el]
        vals = sorted(diag_bags.get(el, []), reverse=True)
        if len(vals) > size:
            vals = vals[:size]
        elif len(vals) < size:
            vals = vals + [0.0] * (size - len(vals))
        out.extend(vals)
    return np.asarray(out, dtype=np.float64)


def infer_bag_sizes(
    structures: Iterable[Dict],
    pad_quantile: float = 1.0,
) -> Tuple[Dict[Tuple[str, str], int], Dict[str, int]]:
    """Scan structures and return ``(off_bag_sizes, diag_bag_sizes)``.

    ``pad_quantile`` selects the quantile of the per-pair counts to use as
    the bag size; ``1.0`` corresponds to the maximum.  A safety floor of
    1 is enforced for any pair that appears at least once.
    """
    pair_counts: List[Counter] = []
    diag_counts: List[Counter] = []
    for rec in structures:
        elements = rec["elements"]
        n = len(elements)
        pc: Counter = Counter()
        dc: Counter = Counter()
        for i in range(n):
            dc[elements[i]] += 1
            for j in range(i + 1, n):
                pc[_pair_key(elements[i], elements[j])] += 1
        pair_counts.append(pc)
        diag_counts.append(dc)
    all_pairs = sorted({k for c in pair_counts for k in c})
    all_elems = sorted({k for c in diag_counts for k in c})
    off_sizes: Dict[Tuple[str, str], int] = {}
    diag_sizes: Dict[str, int] = {}
    for k in all_pairs:
        vals = np.array([c.get(k, 0) for c in pair_counts])
        size = int(np.quantile(vals, pad_quantile))
        off_sizes[k] = max(1, size)
    for el in all_elems:
        vals = np.array([c.get(el, 0) for c in diag_counts])
        size = int(np.quantile(vals, pad_quantile))
        diag_sizes[el] = max(1, size)
    return off_sizes, diag_sizes


def build_bag_of_bonds_descriptors(
    structures: Iterable[Dict],
    bag_sizes: Dict[Tuple[str, str], int],
    diag_sizes: Dict[str, int] | None = None,
) -> np.ndarray:
    """Build a ``(N, D)`` descriptor matrix using bag-of-bonds."""
    feats: List[np.ndarray] = []
    for rec in structures:
        feats.append(bag_of_bonds(rec["elements"], rec["coords_angstrom"], bag_sizes, diag_sizes))
    return np.vstack(feats)


# ---------------------------------------------------------------------------
# Auxiliary descriptors (for diagnostics and cross-checks)
# ---------------------------------------------------------------------------
def inverse_distance_atomic(
    elements: Sequence[str],
    coords_angstrom: Sequence[Sequence[float]],
) -> np.ndarray:
    """Per-atom sum of ``Z_j / r_ij`` over all neighbours j != i.

    Returns a length-``n_atoms`` array; can be aggregated (mean, sum) into
    a fixed-length molecule descriptor for sanity checks.
    """
    Z = np.array([nuclear_charge(e) for e in elements], dtype=np.float64)
    coords_bohr = np.asarray(coords_angstrom, dtype=np.float64) / 0.5291772109
    out = np.zeros(len(elements), dtype=np.float64)
    for i in range(len(elements)):
        for j in range(len(elements)):
            if i == j:
                continue
            r = float(np.linalg.norm(coords_bohr[i] - coords_bohr[j]))
            if r > 0:
                out[i] += Z[j] / r
    return out


def sorted_distances_descriptor(
    elements: Sequence[str],
    coords_angstrom: Sequence[Sequence[float]],
    max_pairs: int,
) -> np.ndarray:
    """Sorted vector of all pairwise distances (Bohr), padded / truncated to ``max_pairs``."""
    coords_bohr = np.asarray(coords_angstrom, dtype=np.float64) / 0.5291772109
    n = len(elements)
    pairs: List[float] = []
    for i in range(n):
        for j in range(i + 1, n):
            pairs.append(float(np.linalg.norm(coords_bohr[i] - coords_bohr[j])))
    pairs.sort()
    out = np.zeros(max_pairs, dtype=np.float64)
    n_use = min(len(pairs), max_pairs)
    out[:n_use] = pairs[:n_use]
    return out

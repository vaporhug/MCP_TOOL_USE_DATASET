"""Metrics and learning-curve utilities.

Functions
---------
mean_absolute_error(y_true, y_pred)
root_mean_squared_error(y_true, y_pred)
r2_score(y_true, y_pred)
mean_absolute_deviation(y)
normalized_mae(mae, mad)
residuals(y_true, y_pred)
learning_curve_sizes(n_train, n_steps, log_spaced)
build_learning_curve(X_train_full, y_train_full, X_test, y_test, sigma, lam, sizes, kernel, seed)
property_summary_statistics(rows, keys)
"""
from __future__ import annotations

from typing import Dict, List, Sequence

import numpy as np

from .krr import fit_predict_krr


def mean_absolute_error(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """MAE = mean(|y_true - y_pred|)."""
    return float(np.mean(np.abs(np.asarray(y_true) - np.asarray(y_pred))))


def root_mean_squared_error(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """RMSE = sqrt(mean((y_true - y_pred)**2))."""
    e = np.asarray(y_true) - np.asarray(y_pred)
    return float(np.sqrt(np.mean(e * e)))


def r2_score(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Coefficient of determination ``1 - ss_res / ss_tot``.

    Returns ``nan`` if the variance of ``y_true`` is zero.
    """
    yt = np.asarray(y_true, dtype=np.float64)
    yp = np.asarray(y_pred, dtype=np.float64)
    ss_res = float(np.sum((yt - yp) ** 2))
    ss_tot = float(np.sum((yt - yt.mean()) ** 2))
    if ss_tot <= 0:
        return float("nan")
    return 1.0 - ss_res / ss_tot


def mean_absolute_deviation(y: np.ndarray) -> float:
    """``MAD = mean(|y - mean(y)|)``; the trivial-mean baseline MAE."""
    y = np.asarray(y, dtype=np.float64)
    return float(np.mean(np.abs(y - y.mean())))


def normalized_mae(mae: float, mad: float) -> float:
    """``NMAE = MAE / MAD`` -- model error normalized by the trivial baseline."""
    if mad <= 0:
        return float("nan")
    return float(mae) / float(mad)


def residuals(y_true: np.ndarray, y_pred: np.ndarray) -> np.ndarray:
    """Return ``y_pred - y_true`` (signed residuals)."""
    return np.asarray(y_pred) - np.asarray(y_true)


def learning_curve_sizes(
    n_train: int,
    n_steps: int = 5,
    log_spaced: bool = True,
) -> np.ndarray:
    """Generate training-set sizes for a learning-curve sweep.

    Always returns ascending integers ending at ``n_train``.  When
    ``log_spaced`` is True, the sweep is roughly geometric with the
    smallest size around ``n_train / 2**(n_steps - 1)``.
    """
    if n_train < 2 or n_steps < 1:
        raise ValueError("need n_train >= 2 and n_steps >= 1")
    if log_spaced:
        sizes = np.unique(
            np.round(np.geomspace(max(2, n_train // (2 ** (n_steps - 1))), n_train, n_steps)).astype(int)
        )
    else:
        sizes = np.unique(
            np.round(np.linspace(max(2, n_train // n_steps), n_train, n_steps)).astype(int)
        )
    return sizes


def build_learning_curve(
    X_train_full: np.ndarray,
    y_train_full: np.ndarray,
    X_test: np.ndarray,
    y_test: np.ndarray,
    sigma: float,
    lam: float,
    sizes: Sequence[int],
    kernel: str = "gaussian",
    seed: int = 0,
) -> Dict[str, np.ndarray]:
    """Fit KRR on increasing prefixes of a shuffled training set.

    Returns ``{"sizes": ndarray, "mae": ndarray, "rmse": ndarray}`` where
    each metric is reported on ``(X_test, y_test)`` for each size.  The
    same shuffle is used for every size so the smaller sets are nested
    prefixes of the larger ones.
    """
    rng = np.random.default_rng(seed)
    n = len(X_train_full)
    perm = rng.permutation(n)
    X_shuf = np.asarray(X_train_full)[perm]
    y_shuf = np.asarray(y_train_full)[perm]
    out_sizes: List[int] = []
    out_mae: List[float] = []
    out_rmse: List[float] = []
    for s in sizes:
        s = int(s)
        if s > n:
            raise ValueError(f"size {s} exceeds available training set {n}")
        Xt = X_shuf[:s]
        yt = y_shuf[:s]
        res = fit_predict_krr(Xt, yt, X_test, sigma=sigma, lam=lam, kernel=kernel)
        yhat = res["y_pred"]
        out_sizes.append(s)
        out_mae.append(mean_absolute_error(y_test, yhat))
        out_rmse.append(root_mean_squared_error(y_test, yhat))
    return {
        "sizes": np.asarray(out_sizes, dtype=np.int64),
        "mae": np.asarray(out_mae, dtype=np.float64),
        "rmse": np.asarray(out_rmse, dtype=np.float64),
    }


def property_summary_statistics(
    rows: Sequence[Dict[str, str]],
    keys: Sequence[str],
) -> Dict[str, Dict[str, float]]:
    """For each ``key``, return ``{"mean", "std", "min", "max", "mad"}``."""
    out: Dict[str, Dict[str, float]] = {}
    for k in keys:
        vals = np.asarray([float(r[k]) for r in rows], dtype=np.float64)
        out[k] = {
            "mean": float(vals.mean()),
            "std": float(vals.std(ddof=1)) if vals.size > 1 else 0.0,
            "min": float(vals.min()),
            "max": float(vals.max()),
            "mad": float(np.mean(np.abs(vals - vals.mean()))),
        }
    return out

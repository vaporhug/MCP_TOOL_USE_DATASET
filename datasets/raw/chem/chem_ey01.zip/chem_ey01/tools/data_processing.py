"""General data processing utilities for tabular data."""

import pandas as pd
import numpy as np
from typing import List, Optional, Tuple


def load_csv(file_path: str, **kwargs) -> pd.DataFrame:
    """Load a CSV file into a pandas DataFrame.

    Parameters
    ----------
    file_path : str
        Path to the CSV file.
    **kwargs
        Additional keyword arguments passed to pd.read_csv.

    Returns
    -------
    pd.DataFrame
        Loaded data.
    """
    return pd.read_csv(file_path, **kwargs)


def filter_rows(df: pd.DataFrame, column: str, min_val: Optional[float] = None,
                max_val: Optional[float] = None) -> pd.DataFrame:
    """Filter DataFrame rows by a numeric column's value range.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame.
    column : str
        Column name to filter on.
    min_val : float, optional
        Minimum allowed value (inclusive).
    max_val : float, optional
        Maximum allowed value (inclusive).

    Returns
    -------
    pd.DataFrame
        Filtered DataFrame.
    """
    mask = pd.Series(True, index=df.index)
    if min_val is not None:
        mask &= df[column] >= min_val
    if max_val is not None:
        mask &= df[column] <= max_val
    return df[mask].reset_index(drop=True)


def drop_columns_with_missing(df: pd.DataFrame, threshold: float = 0.5) -> pd.DataFrame:
    """Drop columns where the fraction of missing values exceeds a threshold.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame.
    threshold : float
        Maximum allowed fraction of missing values (0 to 1).

    Returns
    -------
    pd.DataFrame
        DataFrame with high-missing columns removed.
    """
    frac_missing = df.isnull().mean()
    keep = frac_missing[frac_missing <= threshold].index.tolist()
    return df[keep]


def select_numeric_columns(df: pd.DataFrame, exclude: Optional[List[str]] = None) -> pd.DataFrame:
    """Select only numeric columns from a DataFrame, optionally excluding some.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame.
    exclude : list of str, optional
        Column names to exclude even if numeric.

    Returns
    -------
    pd.DataFrame
        DataFrame with only numeric columns.
    """
    numeric_df = df.select_dtypes(include=[np.number])
    if exclude:
        numeric_df = numeric_df.drop(columns=[c for c in exclude if c in numeric_df.columns])
    return numeric_df


def impute_missing(df: pd.DataFrame, strategy: str = "median") -> pd.DataFrame:
    """Impute missing values in numeric columns.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame.
    strategy : str
        One of 'mean', 'median', 'zero'.

    Returns
    -------
    pd.DataFrame
        DataFrame with missing values filled.
    """
    df_out = df.copy()
    numeric_cols = df_out.select_dtypes(include=[np.number]).columns
    for col in numeric_cols:
        if df_out[col].isnull().any():
            if strategy == "mean":
                df_out[col] = df_out[col].fillna(df_out[col].mean())
            elif strategy == "median":
                df_out[col] = df_out[col].fillna(df_out[col].median())
            elif strategy == "zero":
                df_out[col] = df_out[col].fillna(0.0)
    return df_out


def scale_yield_to_fraction(yields, clip: bool = False) -> np.ndarray:
    """Convert percent yields (0-100 scale) to the fractional 0-1 scale.

    CANONICAL >100% RULE (applied consistently across the answer text, the
    reported metrics, and every figure caption): yields are divided by 100 and
    the raw value is KEPT — they are NOT clipped to 1.0. A small number of ELN
    rows carry instrument/work-up yields slightly above 100% (the ELN ``yield``
    column ranges 0-102.97%, i.e. 6 rows exceed 100%); after dividing by 100
    these become values slightly above 1.0 (max 1.0297). The paper performs no
    clipping, so the bundled pipeline keeps the raw fractional value to preserve
    the measured signal. The HTE ``yield`` column never exceeds 100% (max
    99.999%), so HTE is unaffected. Pass ``clip=True`` only if a clipped-to-1.0
    variant is explicitly desired; the scored benchmark and all figures use the
    default ``clip=False`` (keep-raw) convention.

    Parameters
    ----------
    yields : array-like
        Yields on the 0-100 percent scale.
    clip : bool
        If True, clip the resulting fractional values into [0, 1]. Default
        False (keep-raw), which is the convention used everywhere in this task.

    Returns
    -------
    np.ndarray
        Yields on the fractional scale (0-1, or slightly above 1.0 for the few
        >100% ELN rows when ``clip=False``).
    """
    frac = np.asarray(yields, dtype=float) / 100.0
    if clip:
        frac = np.clip(frac, 0.0, 1.0)
    return frac


def normalize_column(series: pd.Series, method: str = "minmax") -> pd.Series:
    """Normalize a numeric series.

    Parameters
    ----------
    series : pd.Series
        Input numeric series.
    method : str
        'minmax' for [0,1] scaling, 'zscore' for zero-mean unit-variance.

    Returns
    -------
    pd.Series
        Normalized series.
    """
    if method == "minmax":
        mn, mx = series.min(), series.max()
        if mx - mn == 0:
            return pd.Series(0.0, index=series.index)
        return (series - mn) / (mx - mn)
    elif method == "zscore":
        mu, sigma = series.mean(), series.std()
        if sigma == 0:
            return pd.Series(0.0, index=series.index)
        return (series - mu) / sigma
    else:
        raise ValueError(f"Unknown method: {method}")


def summarize_dataframe(df: pd.DataFrame) -> dict:
    """Return summary statistics for a DataFrame.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame.

    Returns
    -------
    dict
        Keys: 'n_rows', 'n_cols', 'numeric_cols', 'missing_per_col',
        'describe' (from df.describe()).
    """
    return {
        "n_rows": len(df),
        "n_cols": len(df.columns),
        "numeric_cols": df.select_dtypes(include=[np.number]).columns.tolist(),
        "missing_per_col": df.isnull().sum().to_dict(),
        "describe": df.describe().to_dict(),
    }

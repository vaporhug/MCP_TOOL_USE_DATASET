"""Visualization tools for yield prediction analysis."""

import numpy as np
from typing import Optional, List, Dict


def plot_yield_distribution(yields: np.ndarray, save_path: str,
                             title: str = "Yield Distribution",
                             n_bins: int = 30,
                             xlabel: str = "Yield (%)",
                             color: str = "#4C72B0") -> str:
    """Plot a histogram of reaction yields.

    Parameters
    ----------
    yields : np.ndarray
        Array of yield values.
    save_path : str
        File path to save the figure (e.g., 'artifacts/yield_dist.png').
    title : str
        Plot title.
    n_bins : int
        Number of histogram bins.
    xlabel : str
        X-axis label.
    color : str
        Bar color.

    Returns
    -------
    str
        Path to the saved figure.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.hist(yields, bins=n_bins, color=color, edgecolor="black", alpha=0.8)
    ax.set_xlabel(xlabel, fontsize=12)
    ax.set_ylabel("Count", fontsize=12)
    ax.set_title(title, fontsize=14)
    ax.axvline(np.mean(yields), color="red", linestyle="--",
               label=f"Mean = {np.mean(yields):.1f}")
    ax.legend(fontsize=11)
    plt.tight_layout()
    fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return save_path


def plot_parity(y_true: np.ndarray, y_pred: np.ndarray, save_path: str,
                title: str = "Predicted vs Actual Yield",
                xlabel: str = "Actual Yield (%)",
                ylabel: str = "Predicted Yield (%)",
                r2: Optional[float] = None,
                mae: Optional[float] = None) -> str:
    """Plot a parity (predicted vs actual) scatter plot.

    Parameters
    ----------
    y_true : np.ndarray
        True yield values.
    y_pred : np.ndarray
        Predicted yield values.
    save_path : str
        File path to save the figure.
    title : str
        Plot title.
    xlabel, ylabel : str
        Axis labels.
    r2 : float, optional
        R-squared value to display on the plot.
    mae : float, optional
        MAE value to display on the plot.

    Returns
    -------
    str
        Path to the saved figure.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(7, 7))
    ax.scatter(y_true, y_pred, alpha=0.5, s=20, color="#4C72B0")
    lims = [min(y_true.min(), y_pred.min()) - 2,
            max(y_true.max(), y_pred.max()) + 2]
    ax.plot(lims, lims, "k--", linewidth=1, label="y = x")
    ax.set_xlim(lims)
    ax.set_ylim(lims)
    ax.set_xlabel(xlabel, fontsize=12)
    ax.set_ylabel(ylabel, fontsize=12)
    ax.set_title(title, fontsize=14)
    ax.set_aspect("equal")

    annotation = ""
    if r2 is not None:
        annotation += f"R² = {r2:.3f}"
    if mae is not None:
        if annotation:
            annotation += "\n"
        annotation += f"MAE = {mae:.3f}"
    if annotation:
        ax.text(0.05, 0.95, annotation, transform=ax.transAxes,
                fontsize=12, verticalalignment="top",
                bbox=dict(boxstyle="round", facecolor="wheat", alpha=0.5))

    ax.legend(fontsize=11)
    plt.tight_layout()
    fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return save_path


def plot_learning_curve(train_sizes: List[int],
                         train_scores: List[float],
                         test_scores: List[float],
                         save_path: str,
                         metric_name: str = "R²",
                         title: str = "Learning Curve") -> str:
    """Plot a learning curve showing performance vs training set size.

    Parameters
    ----------
    train_sizes : list of int
        Training set sizes.
    train_scores : list of float
        Training metric values.
    test_scores : list of float
        Test metric values.
    save_path : str
        File path to save the figure.
    metric_name : str
        Name of the metric (for y-axis label).
    title : str
        Plot title.

    Returns
    -------
    str
        Path to the saved figure.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(train_sizes, train_scores, "o-", label="Train", color="#4C72B0")
    ax.plot(train_sizes, test_scores, "s-", label="Test", color="#DD8452")
    ax.set_xlabel("Training Set Size", fontsize=12)
    ax.set_ylabel(metric_name, fontsize=12)
    ax.set_title(title, fontsize=14)
    ax.legend(fontsize=11)
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return save_path


def plot_model_comparison(model_names: List[str],
                           r2_means: List[float],
                           r2_stds: List[float],
                           save_path: str,
                           title: str = "Model Comparison",
                           ylabel: str = "R²") -> str:
    """Bar chart comparing multiple models on a metric.

    Parameters
    ----------
    model_names : list of str
        Names of models.
    r2_means : list of float
        Mean metric values per model.
    r2_stds : list of float
        Std deviation of metric per model.
    save_path : str
        File path to save the figure.
    title : str
        Plot title.
    ylabel : str
        Y-axis label.

    Returns
    -------
    str
        Path to the saved figure.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(8, 5))
    x = np.arange(len(model_names))
    bars = ax.bar(x, r2_means, yerr=r2_stds, capsize=5, color="#4C72B0",
                  edgecolor="black", alpha=0.85)
    ax.set_xticks(x)
    ax.set_xticklabels(model_names, rotation=30, ha="right", fontsize=11)
    ax.set_ylabel(ylabel, fontsize=12)
    ax.set_title(title, fontsize=14)
    ax.grid(axis="y", alpha=0.3)
    plt.tight_layout()
    fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return save_path


def plot_residual_histogram(residuals: np.ndarray, save_path: str,
                             title: str = "Residual Distribution",
                             n_bins: int = 30) -> str:
    """Plot a histogram of prediction residuals.

    Parameters
    ----------
    residuals : np.ndarray
        Residual values (true - predicted).
    save_path : str
        File path to save the figure.
    title : str
        Plot title.
    n_bins : int
        Number of bins.

    Returns
    -------
    str
        Path to the saved figure.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.hist(residuals, bins=n_bins, color="#DD8452", edgecolor="black", alpha=0.8)
    ax.axvline(0, color="black", linestyle="--", linewidth=1)
    ax.set_xlabel("Residual (True − Predicted)", fontsize=12)
    ax.set_ylabel("Count", fontsize=12)
    ax.set_title(title, fontsize=14)
    ax.text(0.95, 0.95, f"Mean = {np.mean(residuals):.2f}\nStd = {np.std(residuals):.2f}",
            transform=ax.transAxes, fontsize=11, va="top", ha="right",
            bbox=dict(boxstyle="round", facecolor="wheat", alpha=0.5))
    plt.tight_layout()
    fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return save_path


def plot_feature_importance(feature_names: List[str], importances: List[float],
                             save_path: str, top_n: int = 15,
                             title: str = "Feature Importances") -> str:
    """Horizontal bar chart of top feature importances.

    Parameters
    ----------
    feature_names : list of str
        Feature names.
    importances : list of float
        Importance values.
    save_path : str
        File path to save the figure.
    top_n : int
        Number of top features to show.
    title : str
        Plot title.

    Returns
    -------
    str
        Path to the saved figure.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    # Sort and take top N
    sorted_pairs = sorted(zip(importances, feature_names), reverse=True)[:top_n]
    vals = [p[0] for p in sorted_pairs][::-1]
    names = [p[1] for p in sorted_pairs][::-1]

    fig, ax = plt.subplots(figsize=(8, max(4, top_n * 0.35)))
    ax.barh(range(len(names)), vals, color="#4C72B0", edgecolor="black", alpha=0.85)
    ax.set_yticks(range(len(names)))
    ax.set_yticklabels(names, fontsize=10)
    ax.set_xlabel("Importance", fontsize=12)
    ax.set_title(title, fontsize=14)
    plt.tight_layout()
    fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return save_path

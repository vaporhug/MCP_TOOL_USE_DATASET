# Tools — Buchwald–Hartwig yield prediction (HTE vs ELN)

Low-level primitives for featurizing the two reaction datasets and running the
RF / SVM / KNN model comparison. No tool embeds the answer or the headline
numbers; they are computed by composing these primitives.

## Pinned dependency versions (determinism)

The scored benchmark was produced and verified with:

| package      | pinned version |
|--------------|----------------|
| python       | 3.12           |
| rdkit        | 2023.09.6      |
| scikit-learn | 1.8.0          |
| numpy        | 1.26.4         |
| pandas       | 2.3.3          |

A `requirements.txt` with these pins sits next to this README.

### RDKit-version-independent HTE features (bundled CSV)

`Descriptors.descList` can change between RDKit releases, which would change the
HTE feature columns. To keep the HTE feature matrix **deterministic regardless
of the installed RDKit version**, the exact feature matrix used by the scored
benchmark is bundled as:

```
input_data/data/doyle_hte_reactions_rdkit.csv   # 3955 x 1260 features + 1 yield column
```

Load it with `reaction_chemistry.load_hte_feature_matrix()`. Using the bundled
CSV reproduces the headline HTE metrics bit-for-bit on any machine. Recomputing
from SMILES via `reaction_chemistry.build_rdkit_feature_matrix(...)` reproduces
the same matrix on RDKit 2023.09.x. The ELN RDKit descriptors are likewise
pre-bundled in `az_eln_reactions_rdkit.csv`, so neither dataset depends on a
live RDKit descriptor computation for reproducibility.

## ELN feature-selection rule (canonical, word-for-word)

`reaction_chemistry.select_eln_feature_matrix` implements the rule used in the
task instruction / input_data description / answer:

> Keep the numeric per-component descriptor columns and the numeric
> reaction-condition columns as features, and drop the row-index column
> (`Unnamed: 0`), the `id` column, the `yield` target, the raw-SMILES string
> columns (`reactant_smiles`, `solvent_smiles`, `base_smiles`,
> `product_smiles`), and any remaining non-numeric (object/string) column. The
> two numeric solvent-descriptor columns `solvent_1` (solvent dielectric
> constant) and `solvent_2` (a second numeric solvent polarity parameter) are
> KEPT as features (they are float-valued descriptors, NOT categorical name
> strings). `product_*` descriptors are descriptors of the product structure,
> not the measured yield, so they are legitimate features and are kept.

This yields **907 raw numeric ELN feature columns** (includes `solvent_1`,
`solvent_2`). HTE features come from `build_rdkit_feature_matrix` /
`load_hte_feature_matrix` (**1260 raw columns**).

### solvent_1 / solvent_2 semantics

Despite the names, these are **not** categorical solvent names. They are
float-valued numeric solvent descriptors taken from compound databases:
`solvent_1` is the solvent dielectric constant (range 2.25–37.8) and
`solvent_2` is a second numeric solvent polarity parameter (range −0.36–2.44).
Each has 14 distinct float values (the distinct solvents in the bundled
subset). They are kept as features.

## Yield >100% rule (canonical)

`data_processing.scale_yield_to_fraction` converts percent yields to the
fractional 0–1 scale by dividing by 100 with **keep-raw** handling (default
`clip=False`): the few ELN rows above 100% (the ELN `yield` column ranges
0–102.97%, 6 rows >100%) become values slightly above 1.0 (max 1.0297) and are
**not** clipped. The paper performs no clipping. The scored metrics, the answer
text, and every figure caption use this keep-raw convention. HTE yields never
exceed 100% (max 99.999%).

## Per-fold leakage-free cleaning

`ml_modeling.cross_validate_model(..., clean_per_fold=True)` drops
train-fold-constant columns and median-imputes using **training-fold statistics
only**, then (for SVM/KNN) fits `StandardScaler` on the train fold only. No
statistic ever leaks from the test fold.

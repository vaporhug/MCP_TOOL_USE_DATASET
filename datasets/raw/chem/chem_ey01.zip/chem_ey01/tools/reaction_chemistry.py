"""Reaction chemistry primitives: SMILES parsing, fingerprint generation,
molecular descriptor computation, and reaction feature construction."""

import numpy as np
from typing import List, Optional, Tuple, Dict


def parse_reaction_smiles(reaction_smiles: str, delimiter: str = ".") -> List[str]:
    """Split a concatenated reaction SMILES string into individual component SMILES.

    Parameters
    ----------
    reaction_smiles : str
        Dot-separated SMILES string (e.g., 'amine_smi.halide_smi.ligand_smi').
    delimiter : str
        Separator between components (default '.').

    Returns
    -------
    list of str
        Individual SMILES strings for each reactant component.
    """
    from rdkit import Chem
    # Split and validate each component
    parts = reaction_smiles.split(delimiter)
    valid = []
    for smi in parts:
        smi = smi.strip()
        if smi:
            mol = Chem.MolFromSmiles(smi)
            if mol is not None:
                valid.append(Chem.MolToSmiles(mol))
            else:
                valid.append(smi)
    return valid


def smiles_to_mol(smiles: str):
    """Convert a SMILES string to an RDKit Mol object.

    Parameters
    ----------
    smiles : str
        SMILES string.

    Returns
    -------
    rdkit.Chem.Mol or None
        RDKit molecule object, or None if parsing fails.
    """
    from rdkit import Chem
    return Chem.MolFromSmiles(smiles)


def compute_morgan_fingerprint(smiles: str, radius: int = 2,
                                n_bits: int = 1024) -> np.ndarray:
    """Compute a Morgan (circular) fingerprint for a molecule.

    Parameters
    ----------
    smiles : str
        SMILES string of the molecule.
    radius : int
        Fingerprint radius (default 2).
    n_bits : int
        Length of the bit vector (default 1024).

    Returns
    -------
    np.ndarray
        Binary fingerprint array of shape (n_bits,).
    """
    from rdkit import Chem
    from rdkit.Chem import AllChem
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return np.zeros(n_bits, dtype=int)
    fp = AllChem.GetMorganFingerprintAsBitVect(mol, radius, nBits=n_bits)
    arr = np.zeros(n_bits, dtype=int)
    for idx in fp.GetOnBits():
        arr[idx] = 1
    return arr


def compute_rdkit_descriptors(smiles: str) -> Dict[str, float]:
    """Compute a set of RDKit 2D molecular descriptors for a molecule.

    Parameters
    ----------
    smiles : str
        SMILES string.

    Returns
    -------
    dict
        Dictionary mapping descriptor names to float values.
        Returns empty dict if SMILES is invalid.
    """
    from rdkit import Chem
    from rdkit.Chem import Descriptors
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return {}
    desc = {}
    for name, func in Descriptors.descList:
        try:
            desc[name] = float(func(mol))
        except Exception:
            desc[name] = np.nan
    return desc


def build_reaction_fingerprint(reactant_smiles_list: List[str],
                                radius: int = 2,
                                n_bits: int = 1024,
                                mode: str = "concatenate") -> np.ndarray:
    """Build a reaction-level fingerprint from multiple reactant SMILES.

    Parameters
    ----------
    reactant_smiles_list : list of str
        SMILES strings for each reaction component.
    radius : int
        Morgan fingerprint radius.
    n_bits : int
        Fingerprint length per component.
    mode : str
        'concatenate' to stack fingerprints, 'difference' to compute
        product_fp - sum(reactant_fps) (requires last element to be product).

    Returns
    -------
    np.ndarray
        Combined fingerprint array.
    """
    fps = [compute_morgan_fingerprint(smi, radius, n_bits) for smi in reactant_smiles_list]
    if mode == "concatenate":
        return np.concatenate(fps)
    elif mode == "difference":
        if len(fps) < 2:
            return np.concatenate(fps)
        product_fp = fps[-1]
        reactant_sum = np.sum(fps[:-1], axis=0)
        return product_fp - reactant_sum
    else:
        raise ValueError(f"Unknown mode: {mode}")


def compute_onehot_encoding(values: List[str]) -> Tuple[np.ndarray, List[str]]:
    """One-hot encode a list of categorical string values.

    Parameters
    ----------
    values : list of str
        Categorical values (e.g., solvent names, base SMILES).

    Returns
    -------
    np.ndarray
        One-hot encoded matrix of shape (len(values), n_categories).
    list of str
        Category labels corresponding to columns.
    """
    unique = sorted(set(values))
    cat_to_idx = {c: i for i, c in enumerate(unique)}
    ohe = np.zeros((len(values), len(unique)), dtype=int)
    for i, v in enumerate(values):
        ohe[i, cat_to_idx[v]] = 1
    return ohe, unique


def build_rdkit_feature_matrix(df, reactant_col: str = "reactant_smiles",
                               extra_smiles_cols: Optional[List[str]] = None,
                               n_components: int = 4):
    """Build a pinned RDKit-descriptor feature matrix for a reaction table.

    This is the canonical featurization used to reproduce the "with RDKit
    features" (footnote a) rows of the paper's Table 1 for datasets that ship
    SMILES but not pre-computed RDKit descriptors (e.g. the HTE file). The
    recipe is fixed so the reported R2/MAE values reproduce:

      1. Split the concatenated ``reactant_col`` on '.' into up to
         ``n_components`` components (amine, halide, ligand, additive); each
         gets the full RDKit ``Descriptors.descList`` prefixed ``c{i}_``.
      2. Each SMILES column in ``extra_smiles_cols`` (default base + solvent)
         gets the same descriptor set, prefixed with the column name.
      3. Keep only numeric columns, drop columns that are constant across all
         rows, and median-impute remaining NaNs.

    The same descriptor set (RDKit ``Descriptors.descList``) is what the
    bundled ``az_eln_reactions_rdkit.csv`` already contains per component, so
    the HTE and ELN feature spaces are constructed consistently.

    Parameters
    ----------
    df : pd.DataFrame
        Reaction table with a concatenated reactant SMILES column.
    reactant_col : str
        Column holding the dot-separated reactant SMILES.
    extra_smiles_cols : list of str, optional
        Additional single-molecule SMILES columns (default base + solvent).
    n_components : int
        Maximum number of reactant components to featurize.

    Returns
    -------
    pd.DataFrame
        Numeric feature matrix (rows aligned to ``df``), constant columns
        dropped and NaNs median-imputed.
    """
    import pandas as pd
    if extra_smiles_cols is None:
        extra_smiles_cols = [c for c in ("base_smiles", "solvent_smiles")
                             if c in df.columns]

    records = []
    for _, row in df.iterrows():
        feats: Dict[str, float] = {}
        comps = str(row[reactant_col]).split(".")
        for i, smi in enumerate(comps[:n_components]):
            for name, val in compute_rdkit_descriptors(smi).items():
                feats[f"c{i}_{name}"] = val
        for col in extra_smiles_cols:
            for name, val in compute_rdkit_descriptors(str(row[col])).items():
                feats[f"{col}_{name}"] = val
        records.append(feats)

    X = pd.DataFrame(records, index=df.index)
    X = X.select_dtypes(include=[np.number])
    X = X.loc[:, X.nunique(dropna=True) > 1]
    X = X.fillna(X.median())
    return X


def count_unique_components(smiles_series) -> Dict[str, int]:
    """Count unique molecular components in a pandas Series of SMILES strings.

    Parameters
    ----------
    smiles_series : pd.Series
        Series of SMILES strings.

    Returns
    -------
    dict
        Mapping from unique canonical SMILES to their occurrence count.
    """
    from rdkit import Chem
    from collections import Counter
    canonical = []
    for smi in smiles_series:
        if isinstance(smi, str):
            mol = Chem.MolFromSmiles(smi)
            if mol is not None:
                canonical.append(Chem.MolToSmiles(mol))
            else:
                canonical.append(smi)
        else:
            canonical.append(str(smi))
    return dict(Counter(canonical))

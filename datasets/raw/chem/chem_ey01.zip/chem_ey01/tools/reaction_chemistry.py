"""Reaction chemistry primitives: SMILES parsing, fingerprint generation,
molecular descriptor computation, and reaction feature construction."""

import numpy as np
from typing import List, Optional, Tuple, Dict


def parse_reaction_smiles(reaction_smiles: str, delimiter: str = ".") -> List[str]:
    """Split a concatenated reaction SMILES string into individual component SMILES.

    Parameters
    ----------
    reaction_smiles : str
        Dot-separated SMILES string (e.g., 'amine_smi.halide_smi.ligand_smi').
    delimiter : str
        Separator between components (default '.').

    Returns
    -------
    list of str
        Individual SMILES strings for each reactant component.
    """
    from rdkit import Chem
    # Split and validate each component
    parts = reaction_smiles.split(delimiter)
    valid = []
    for smi in parts:
        smi = smi.strip()
        if smi:
            mol = Chem.MolFromSmiles(smi)
            if mol is not None:
                valid.append(Chem.MolToSmiles(mol))
            else:
                valid.append(smi)
    return valid


def smiles_to_mol(smiles: str):
    """Convert a SMILES string to an RDKit Mol object.

    Parameters
    ----------
    smiles : str
        SMILES string.

    Returns
    -------
    rdkit.Chem.Mol or None
        RDKit molecule object, or None if parsing fails.
    """
    from rdkit import Chem
    return Chem.MolFromSmiles(smiles)


def compute_morgan_fingerprint(smiles: str, radius: int = 2,
                                n_bits: int = 1024) -> np.ndarray:
    """Compute a Morgan (circular) fingerprint for a molecule.

    Parameters
    ----------
    smiles : str
        SMILES string of the molecule.
    radius : int
        Fingerprint radius (default 2).
    n_bits : int
        Length of the bit vector (default 1024).

    Returns
    -------
    np.ndarray
        Binary fingerprint array of shape (n_bits,).
    """
    from rdkit import Chem
    from rdkit.Chem import AllChem
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return np.zeros(n_bits, dtype=int)
    fp = AllChem.GetMorganFingerprintAsBitVect(mol, radius, nBits=n_bits)
    arr = np.zeros(n_bits, dtype=int)
    for idx in fp.GetOnBits():
        arr[idx] = 1
    return arr


def compute_rdkit_descriptors(smiles: str) -> Dict[str, float]:
    """Compute a set of RDKit 2D molecular descriptors for a molecule.

    Parameters
    ----------
    smiles : str
        SMILES string.

    Returns
    -------
    dict
        Dictionary mapping descriptor names to float values.
        Returns empty dict if SMILES is invalid.
    """
    from rdkit import Chem
    from rdkit.Chem import Descriptors
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return {}
    desc = {}
    for name, func in Descriptors.descList:
        try:
            desc[name] = float(func(mol))
        except Exception:
            desc[name] = np.nan
    return desc


def build_reaction_fingerprint(reactant_smiles_list: List[str],
                                radius: int = 2,
                                n_bits: int = 1024,
                                mode: str = "concatenate") -> np.ndarray:
    """Build a reaction-level fingerprint from multiple reactant SMILES.

    Parameters
    ----------
    reactant_smiles_list : list of str
        SMILES strings for each reaction component.
    radius : int
        Morgan fingerprint radius.
    n_bits : int
        Fingerprint length per component.
    mode : str
        'concatenate' to stack fingerprints, 'difference' to compute
        product_fp - sum(reactant_fps) (requires last element to be product).

    Returns
    -------
    np.ndarray
        Combined fingerprint array.
    """
    fps = [compute_morgan_fingerprint(smi, radius, n_bits) for smi in reactant_smiles_list]
    if mode == "concatenate":
        return np.concatenate(fps)
    elif mode == "difference":
        if len(fps) < 2:
            return np.concatenate(fps)
        product_fp = fps[-1]
        reactant_sum = np.sum(fps[:-1], axis=0)
        return product_fp - reactant_sum
    else:
        raise ValueError(f"Unknown mode: {mode}")


def compute_onehot_encoding(values: List[str]) -> Tuple[np.ndarray, List[str]]:
    """One-hot encode a list of categorical string values.

    Parameters
    ----------
    values : list of str
        Categorical values (e.g., solvent names, base SMILES).

    Returns
    -------
    np.ndarray
        One-hot encoded matrix of shape (len(values), n_categories).
    list of str
        Category labels corresponding to columns.
    """
    unique = sorted(set(values))
    cat_to_idx = {c: i for i, c in enumerate(unique)}
    ohe = np.zeros((len(values), len(unique)), dtype=int)
    for i, v in enumerate(values):
        ohe[i, cat_to_idx[v]] = 1
    return ohe, unique


def build_rdkit_feature_matrix(df, reactant_col: str = "reactant_smiles",
                               extra_smiles_cols: Optional[List[str]] = None,
                               n_components: int = 4):
    """Build a fixed RDKit-descriptor feature matrix for a reaction table.

    This is the "with RDKit features" featurization for datasets that ship
    SMILES but not pre-computed RDKit descriptors (e.g. the HTE file). The
    recipe is fixed and deterministic:

      1. Split the concatenated ``reactant_col`` on '.' into up to
         ``n_components`` components (amine, halide, ligand, additive); each
         gets the full RDKit ``Descriptors.descList`` prefixed ``c{i}_``.
      2. Each SMILES column in ``extra_smiles_cols`` (default base + solvent)
         gets the same descriptor set, prefixed with the column name.
      3. Keep only numeric columns, drop columns that are constant across all
         rows, and median-impute remaining NaNs.

    The same descriptor set (RDKit ``Descriptors.descList``) is what the
    bundled ``az_eln_reactions_rdkit.csv`` already contains per component, so
    the HTE and ELN feature spaces are constructed consistently.

    Parameters
    ----------
    df : pd.DataFrame
        Reaction table with a concatenated reactant SMILES column.
    reactant_col : str
        Column holding the dot-separated reactant SMILES.
    extra_smiles_cols : list of str, optional
        Additional single-molecule SMILES columns (default base + solvent).
    n_components : int
        Maximum number of reactant components to featurize.

    Returns
    -------
    pd.DataFrame
        Numeric feature matrix (rows aligned to ``df``), constant columns
        dropped and NaNs median-imputed.
    """
    import pandas as pd
    if extra_smiles_cols is None:
        extra_smiles_cols = [c for c in ("base_smiles", "solvent_smiles")
                             if c in df.columns]

    records = []
    for _, row in df.iterrows():
        feats: Dict[str, float] = {}
        comps = str(row[reactant_col]).split(".")
        for i, smi in enumerate(comps[:n_components]):
            for name, val in compute_rdkit_descriptors(smi).items():
                feats[f"c{i}_{name}"] = val
        for col in extra_smiles_cols:
            for name, val in compute_rdkit_descriptors(str(row[col])).items():
                feats[f"{col}_{name}"] = val
        records.append(feats)

    X = pd.DataFrame(records, index=df.index)
    X = X.select_dtypes(include=[np.number])
    # NOTE: constant-column drop and median-imputation are intentionally NOT
    # done here. They must be performed *per training fold* (see
    # ml_modeling.cross_validate_model with ``clean_per_fold=True``) to avoid
    # information leakage from the test fold. This function therefore returns
    # the raw numeric descriptor matrix (constants kept, NaNs kept).
    return X


# Identifier / index / target / raw-SMILES columns that must never be used as
# model features for the ELN table (and the HTE table where present). These are
# bookkeeping columns, raw string columns, or the prediction target itself.
#
# IMPORTANT (solvent_1 / solvent_2 semantics): despite their names, these two
# columns are NOT categorical solvent-name strings. They are float-valued
# numeric SOLVENT DESCRIPTORS taken from compound databases (per the paper's
# feature description, "dielectric constants of the solvents ... were taken
# from compound databases"): ``solvent_1`` is the solvent dielectric constant
# (values 2.25-37.8, e.g. ~2.4 for toluene, ~37.5 for DMF) and ``solvent_2`` is
# a second numeric solvent polarity parameter (values -0.36 to 2.44). Both have
# exactly 14 distinct numeric values (the distinct solvents in the bundled
# subset) and dtype float64. They are therefore legitimate numeric FEATURES and
# are KEPT, not dropped. They are intentionally absent from this drop list.
ELN_NON_FEATURE_COLUMNS = (
    "Unnamed: 0",  # pandas row index written into the CSV
    "id",           # reaction identifier
    "yield",        # the prediction target
    "reactant_smiles", "solvent_smiles", "base_smiles", "product_smiles",
)


def select_eln_feature_matrix(df,
                              include_product_descriptors: bool = True,
                              include_reaction_conditions: bool = True):
    """Select the ELN feature matrix from ``az_eln_reactions_rdkit.csv``.

    CANONICAL FEATURE-SELECTION RULE (kept word-for-word identical in
    task_content.json instruction, the ``eln_reactions_rdkit`` input_data
    description, the answer text, and this docstring):

    Keep the numeric per-component descriptor columns and the numeric
    reaction-condition columns as features, and drop the row-index column
    (``Unnamed: 0``), the ``id`` column, the ``yield`` target, the raw-SMILES
    string columns (``reactant_smiles``, ``solvent_smiles``, ``base_smiles``,
    ``product_smiles``), and any remaining non-numeric (object/string) column.
    The two numeric solvent-descriptor columns ``solvent_1`` (solvent dielectric
    constant) and ``solvent_2`` (a second numeric solvent polarity parameter)
    are KEPT as features (they are float-valued descriptors, NOT categorical
    name strings). ``product_*`` descriptors are descriptors of the product
    structure, not the measured yield, so they are legitimate features and are
    kept.

    Concretely, starting from every column:

      * DROPPED unconditionally (never features), see ``ELN_NON_FEATURE_COLUMNS``:
          - index column ``Unnamed: 0`` (pandas row index in the CSV)
          - identifier column ``id``
          - target column ``yield``
          - raw SMILES columns ``reactant_smiles``, ``solvent_smiles``,
            ``base_smiles``, ``product_smiles`` (strings, not numeric)
          - any remaining non-numeric (object/string) column

      * KEPT as features:
          - per-component RDKit 2D descriptors (prefixes ``amine_``, ``halide_``,
            ``ligand_``, ``solvent_``, ``base_``, ``product_``) — these are the
            "with RDKit" descriptors the paper's footnote-a featurization uses.
          - per-component DFT descriptors carried over from the base file
            (e.g. ``*_E_HOMO``, ``*_electronegativity``, ``*_NMR_shift``).
          - the two numeric solvent-descriptor columns ``solvent_1`` (dielectric
            constant) and ``solvent_2`` (solvent polarity parameter).
          - reaction-condition numeric columns (``temperature``,
            ``metal_amount``, ``amine_amount``, ``halide_amount``,
            ``base_amount``, ``ligand_amount``, ``reaction_volume``) when
            ``include_reaction_conditions`` is True.

      * ``product_*`` descriptors are descriptors of the *product structure*
        (molecular shape/composition), NOT the measured yield, so they are
        legitimate features and are kept when ``include_product_descriptors``
        is True. They can be excluded by passing False if a product-free
        feature set is desired.

    No constant-column drop or imputation is performed here; that is done
    per training fold downstream (``clean_per_fold=True``) to avoid leakage.

    Parameters
    ----------
    df : pd.DataFrame
        The loaded ``az_eln_reactions_rdkit.csv`` table.
    include_product_descriptors : bool
        Keep ``product_*`` descriptor columns (default True).
    include_reaction_conditions : bool
        Keep numeric reaction-condition columns (default True).

    Returns
    -------
    pd.DataFrame
        Raw numeric feature matrix (constants and NaNs preserved).
    """
    import numpy as _np
    drop = set(ELN_NON_FEATURE_COLUMNS)
    X = df.drop(columns=[c for c in drop if c in df.columns], errors="ignore")
    X = X.select_dtypes(include=[_np.number])
    if not include_product_descriptors:
        X = X.drop(columns=[c for c in X.columns if c.startswith("product_")],
                   errors="ignore")
    if not include_reaction_conditions:
        cond = ("temperature", "metal_amount", "amine_amount", "halide_amount",
                "base_amount", "ligand_amount", "reaction_volume")
        X = X.drop(columns=[c for c in cond if c in X.columns], errors="ignore")
    return X


def load_hte_feature_matrix(data_dir: str = "input_data/data"):
    """Load the DETERMINISTIC, precomputed HTE RDKit feature matrix.

    To make the HTE feature space reproducible regardless of the installed
    RDKit version, the exact RDKit ``Descriptors.descList`` feature matrix used
    by the scored benchmark is bundled as
    ``input_data/data/doyle_hte_reactions_rdkit.csv`` (3955 rows x 1260 raw
    descriptor columns, plus a leading ``yield`` column on the 0-100 scale).
    This function loads that bundled CSV and returns ``(X, y_percent)`` where
    ``X`` is the 1260-column raw feature DataFrame (constants/NaNs preserved,
    cleaned per training fold downstream) and ``y_percent`` is the yield on the
    0-100 scale. Divide ``y_percent`` by 100 (see
    ``data_processing.scale_yield_to_fraction``) for the fractional target.

    Using the bundled CSV gives bit-identical features and therefore identical
    metrics across machines/RDKit versions; calling
    ``build_rdkit_feature_matrix`` on the raw SMILES recomputes the same matrix
    on the fly (it matches for RDKit 2023.09.x, the pinned version).

    Parameters
    ----------
    data_dir : str
        Directory holding the bundled CSVs (default ``input_data/data``).

    Returns
    -------
    (pd.DataFrame, np.ndarray)
        Raw 1260-column feature matrix and the 0-100 yield array.
    """
    import os
    import pandas as pd
    path = os.path.join(data_dir, "doyle_hte_reactions_rdkit.csv")
    df = pd.read_csv(path)
    y = df["yield"].values.astype(float)
    X = df.drop(columns=["yield"])
    return X, y


def count_unique_components(smiles_series) -> Dict[str, int]:
    """Count unique molecular components in a pandas Series of SMILES strings.

    Parameters
    ----------
    smiles_series : pd.Series
        Series of SMILES strings.

    Returns
    -------
    dict
        Mapping from unique canonical SMILES to their occurrence count.
    """
    from rdkit import Chem
    from collections import Counter
    canonical = []
    for smi in smiles_series:
        if isinstance(smi, str):
            mol = Chem.MolFromSmiles(smi)
            if mol is not None:
                canonical.append(Chem.MolToSmiles(mol))
            else:
                canonical.append(smi)
        else:
            canonical.append(str(smi))
    return dict(Counter(canonical))

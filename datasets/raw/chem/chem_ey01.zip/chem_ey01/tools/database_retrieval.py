"""Local dataset retrieval helpers for the reaction yield prediction task.

This task is fully offline-reproducible: the core analysis runs entirely on
the bundled CSVs under ``input_data/data`` and requires no network access.
These helpers only locate and load the bundled reaction tables. No function
in this module opens a network connection.
"""

import os
from typing import Dict


def list_local_datasets(data_dir: str) -> Dict[str, str]:
    """List the bundled reaction CSV files available under a data directory.

    Parameters
    ----------
    data_dir : str
        Directory holding the bundled CSV files (e.g. ``input_data/data``).

    Returns
    -------
    dict
        Mapping from file stem to absolute file path for every ``*.csv`` found.
    """
    out: Dict[str, str] = {}
    for fname in sorted(os.listdir(data_dir)):
        if fname.lower().endswith(".csv"):
            stem = os.path.splitext(fname)[0]
            out[stem] = os.path.abspath(os.path.join(data_dir, fname))
    return out


def load_local_dataset(data_dir: str, name: str):
    """Load one of the bundled reaction CSV files by name.

    Parameters
    ----------
    data_dir : str
        Directory holding the bundled CSV files.
    name : str
        File stem (without ``.csv``), e.g. ``az_eln_reactions_rdkit``.

    Returns
    -------
    pd.DataFrame
        The loaded table.

    Raises
    ------
    FileNotFoundError
        If the requested file is not present in ``data_dir``.
    """
    import pandas as pd
    path = os.path.join(data_dir, f"{name}.csv")
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"{name}.csv not found in {data_dir}; available: "
            f"{sorted(list_local_datasets(data_dir).keys())}"
        )
    return pd.read_csv(path)

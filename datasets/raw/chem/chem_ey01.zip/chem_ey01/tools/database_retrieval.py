"""Database retrieval helpers for the reaction yield prediction task.

These are optional convenience utilities for fetching auxiliary data. The
core analysis runs entirely on the bundled CSVs and does not require network
access; these helpers are provided for users who wish to pull additional
reference data.
"""

import json
import os
import urllib.parse
import urllib.request


def fetch_reaction_data(url: str, save_path: str, timeout: float = 60.0) -> str:
    """Download a reaction dataset from a URL and save it locally.

    Parameters
    ----------
    url : str
        URL to the dataset file (CSV, JSON, etc.).
    save_path : str
        Local path to save the downloaded file.
    timeout : float
        Network timeout in seconds.

    Returns
    -------
    str
        Path to the saved file.

    Raises
    ------
    urllib.error.URLError
        If the download fails.
    """
    os.makedirs(os.path.dirname(os.path.abspath(save_path)), exist_ok=True)
    with urllib.request.urlopen(url, timeout=timeout) as resp:
        data = resp.read()
    with open(save_path, "wb") as fh:
        fh.write(data)
    return save_path


def query_pubchem_by_smiles(smiles: str, timeout: float = 30.0) -> dict:
    """Query PubChem for compound properties given a SMILES string.

    Uses the public PUG-REST endpoint to look up the canonical record for a
    molecule. Returns an empty dict if the compound is not found.

    Parameters
    ----------
    smiles : str
        SMILES string of the molecule.
    timeout : float
        Network timeout in seconds.

    Returns
    -------
    dict
        Dictionary with keys 'CID', 'MolecularFormula', 'MolecularWeight',
        and 'CanonicalSMILES' when available; empty dict if not found.
    """
    base = "https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/smiles"
    props = "MolecularFormula,MolecularWeight,CanonicalSMILES"
    enc = urllib.parse.quote(smiles, safe="")
    url = f"{base}/{enc}/property/{props}/JSON"
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
    except Exception:
        return {}
    table = payload.get("PropertyTable", {}).get("Properties", [])
    if not table:
        return {}
    rec = table[0]
    return {
        "CID": rec.get("CID"),
        "MolecularFormula": rec.get("MolecularFormula"),
        "MolecularWeight": rec.get("MolecularWeight"),
        "CanonicalSMILES": rec.get("CanonicalSMILES"),
    }

"""Evaluation metrics for regression tasks."""

import numpy as np
from typing import Dict


def compute_r2(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Compute the coefficient of determination (R-squared).

    Parameters
    ----------
    y_true : np.ndarray
        Ground truth values.
    y_pred : np.ndarray
        Predicted values.

    Returns
    -------
    float
        R-squared score (can be negative for poor models).
    """
    ss_res = np.sum((y_true - y_pred) ** 2)
    ss_tot = np.sum((y_true - np.mean(y_true)) ** 2)
    if ss_tot == 0:
        return 0.0
    return float(1.0 - ss_res / ss_tot)


def compute_mae(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Compute Mean Absolute Error.

    Parameters
    ----------
    y_true : np.ndarray
        Ground truth values.
    y_pred : np.ndarray
        Predicted values.

    Returns
    -------
    float
        MAE value.
    """
    return float(np.mean(np.abs(y_true - y_pred)))


def compute_rmse(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Compute Root Mean Squared Error.

    Parameters
    ----------
    y_true : np.ndarray
        Ground truth values.
    y_pred : np.ndarray
        Predicted values.

    Returns
    -------
    float
        RMSE value.
    """
    return float(np.sqrt(np.mean((y_true - y_pred) ** 2)))


def compute_all_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> Dict[str, float]:
    """Compute R-squared, MAE, and RMSE together.

    Parameters
    ----------
    y_true : np.ndarray
        Ground truth values.
    y_pred : np.ndarray
        Predicted values.

    Returns
    -------
    dict
        Keys: 'r2', 'mae', 'rmse'.
    """
    return {
        "r2": compute_r2(y_true, y_pred),
        "mae": compute_mae(y_true, y_pred),
        "rmse": compute_rmse(y_true, y_pred),
    }


def compute_residuals(y_true: np.ndarray, y_pred: np.ndarray) -> np.ndarray:
    """Compute residuals (true - predicted).

    Parameters
    ----------
    y_true : np.ndarray
        Ground truth values.
    y_pred : np.ndarray
        Predicted values.

    Returns
    -------
    np.ndarray
        Residual array.
    """
    return y_true - y_pred


def summarize_repeated_metrics(metric_lists: Dict[str, list]) -> Dict[str, Dict[str, float]]:
    """Summarize metrics from repeated splits as mean +/- std.

    Parameters
    ----------
    metric_lists : dict
        Keys are metric names, values are lists of float from repeated evaluations.

    Returns
    -------
    dict
        For each metric: {'mean': float, 'std': float}.
    """
    summary = {}
    for name, vals in metric_lists.items():
        arr = np.array(vals)
        summary[name] = {"mean": float(np.mean(arr)), "std": float(np.std(arr))}
    return summary

"""Machine learning modeling primitives: train/test splitting, regressors,
hyperparameter search, and learning curves."""

import numpy as np
from typing import Tuple, Optional, Dict, List, Any


def train_test_split_indices(n_samples: int, test_fraction: float = 0.3,
                              random_state: Optional[int] = None) -> Tuple[np.ndarray, np.ndarray]:
    """Generate random train/test split indices.

    Parameters
    ----------
    n_samples : int
        Total number of samples.
    test_fraction : float
        Fraction of samples for the test set (default 0.3).
    random_state : int, optional
        Random seed for reproducibility.

    Returns
    -------
    train_idx : np.ndarray
        Indices for training set.
    test_idx : np.ndarray
        Indices for test set.
    """
    rng = np.random.RandomState(random_state)
    indices = rng.permutation(n_samples)
    n_test = int(n_samples * test_fraction)
    return indices[n_test:], indices[:n_test]


def train_random_forest(X_train: np.ndarray, y_train: np.ndarray,
                         n_estimators: int = 100,
                         max_depth: Optional[int] = None,
                         random_state: Optional[int] = None) -> Any:
    """Train a Random Forest regressor.

    Parameters
    ----------
    X_train : np.ndarray
        Training feature matrix.
    y_train : np.ndarray
        Training target values.
    n_estimators : int
        Number of trees.
    max_depth : int, optional
        Maximum tree depth.
    random_state : int, optional
        Random seed.

    Returns
    -------
    sklearn.ensemble.RandomForestRegressor
        Trained model.
    """
    from sklearn.ensemble import RandomForestRegressor
    model = RandomForestRegressor(
        n_estimators=n_estimators,
        max_depth=max_depth,
        random_state=random_state,
        n_jobs=-1,
    )
    model.fit(X_train, y_train)
    return model


def train_gradient_boosting(X_train: np.ndarray, y_train: np.ndarray,
                             n_estimators: int = 100,
                             max_depth: int = 6,
                             learning_rate: float = 0.1,
                             random_state: Optional[int] = None) -> Any:
    """Train an XGBoost gradient boosting regressor.

    Parameters
    ----------
    X_train : np.ndarray
        Training feature matrix.
    y_train : np.ndarray
        Training target values.
    n_estimators : int
        Number of boosting rounds.
    max_depth : int
        Maximum tree depth.
    learning_rate : float
        Step-size shrinkage.
    random_state : int, optional
        Random seed.

    Returns
    -------
    xgboost.XGBRegressor
        Trained model.
    """
    from xgboost import XGBRegressor
    model = XGBRegressor(
        n_estimators=n_estimators,
        max_depth=max_depth,
        learning_rate=learning_rate,
        random_state=random_state,
        n_jobs=-1,
        verbosity=0,
    )
    model.fit(X_train, y_train)
    return model


def train_gaussian_process(X_train: np.ndarray, y_train: np.ndarray,
                            kernel: Optional[str] = None,
                            random_state: Optional[int] = None,
                            n_restarts: int = 2) -> Any:
    """Train a Gaussian Process regressor.

    Parameters
    ----------
    X_train : np.ndarray
        Training feature matrix. For GP scalability, consider using
        a subset or dimensionality reduction for large datasets.
    y_train : np.ndarray
        Training target values.
    kernel : str, optional
        Kernel specification: 'rbf', 'matern', or None (default RBF + WhiteKernel).
    random_state : int, optional
        Random seed.
    n_restarts : int
        Number of optimizer restarts for kernel hyperparameters.

    Returns
    -------
    sklearn.gaussian_process.GaussianProcessRegressor
        Trained model.
    """
    from sklearn.gaussian_process import GaussianProcessRegressor
    from sklearn.gaussian_process.kernels import RBF, WhiteKernel, Matern, ConstantKernel

    if kernel == "matern":
        k = ConstantKernel() * Matern(nu=2.5) + WhiteKernel()
    else:
        k = ConstantKernel() * RBF() + WhiteKernel()

    model = GaussianProcessRegressor(
        kernel=k,
        n_restarts_optimizer=n_restarts,
        random_state=random_state,
        normalize_y=True,
    )
    model.fit(X_train, y_train)
    return model


def train_svr(X_train: np.ndarray, y_train: np.ndarray,
              kernel: str = "rbf", C: float = 1.0,
              epsilon: float = 0.1) -> Any:
    """Train a Support Vector Regression model.

    Parameters
    ----------
    X_train : np.ndarray
        Training feature matrix.
    y_train : np.ndarray
        Training target values.
    kernel : str
        Kernel type ('rbf', 'linear', 'poly').
    C : float
        Regularization parameter.
    epsilon : float
        Epsilon in epsilon-SVR model.

    Returns
    -------
    sklearn.svm.SVR
        Trained model.
    """
    from sklearn.svm import SVR
    model = SVR(kernel=kernel, C=C, epsilon=epsilon)
    model.fit(X_train, y_train)
    return model


def train_knn_regressor(X_train: np.ndarray, y_train: np.ndarray,
                         n_neighbors: int = 5,
                         weights: str = "uniform") -> Any:
    """Train a K-Nearest Neighbors regressor.

    Parameters
    ----------
    X_train : np.ndarray
        Training feature matrix.
    y_train : np.ndarray
        Training target values.
    n_neighbors : int
        Number of neighbors.
    weights : str
        'uniform' or 'distance'.

    Returns
    -------
    sklearn.neighbors.KNeighborsRegressor
        Trained model.
    """
    from sklearn.neighbors import KNeighborsRegressor
    model = KNeighborsRegressor(n_neighbors=n_neighbors, weights=weights)
    model.fit(X_train, y_train)
    return model


def predict(model, X: np.ndarray) -> np.ndarray:
    """Generate predictions from a trained model.

    Parameters
    ----------
    model : fitted sklearn-compatible estimator
        Trained model with a .predict() method.
    X : np.ndarray
        Feature matrix.

    Returns
    -------
    np.ndarray
        Predicted values.
    """
    return model.predict(X)


def get_feature_importances(model, feature_names: Optional[List[str]] = None) -> Dict[str, float]:
    """Extract feature importances from a tree-based model.

    Parameters
    ----------
    model : fitted tree-based estimator
        Must have .feature_importances_ attribute (RF, XGBoost, etc.).
    feature_names : list of str, optional
        Feature names; if None, uses integer indices.

    Returns
    -------
    dict
        Mapping from feature name to importance score, sorted descending.
    """
    importances = model.feature_importances_
    if feature_names is None:
        feature_names = [str(i) for i in range(len(importances))]
    imp_dict = dict(zip(feature_names, importances))
    return dict(sorted(imp_dict.items(), key=lambda x: -x[1]))


def compute_learning_curve(X: np.ndarray, y: np.ndarray,
                            model_type: str = "rf",
                            train_fractions: Optional[List[float]] = None,
                            n_splits: int = 5,
                            random_state: Optional[int] = None,
                            **model_kwargs) -> Dict[str, List[float]]:
    """Compute a learning curve: performance vs training set size.

    Parameters
    ----------
    X : np.ndarray
        Full feature matrix.
    y : np.ndarray
        Full target array.
    model_type : str
        'rf' for RandomForest, 'xgb' for XGBoost, 'svr' for SVR, 'knn' for KNN.
    train_fractions : list of float, optional
        Fractions of training data to evaluate (default [0.1, 0.2, ..., 1.0]).
    n_splits : int
        Number of random train/test splits per fraction.
    random_state : int, optional
        Base random seed.
    **model_kwargs
        Additional keyword arguments for the model constructor.

    Returns
    -------
    dict
        Keys: 'train_sizes' (list of int), 'train_r2' (list of float),
        'test_r2' (list of float), 'train_mae' (list of float),
        'test_mae' (list of float). Each value list has length = len(train_fractions).
    """
    from sklearn.metrics import r2_score, mean_absolute_error

    if train_fractions is None:
        train_fractions = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]

    results = {"train_sizes": [], "train_r2": [], "test_r2": [],
               "train_mae": [], "test_mae": []}

    for frac in train_fractions:
        r2_trains, r2_tests, mae_trains, mae_tests = [], [], [], []
        for split_i in range(n_splits):
            seed = (random_state or 0) + split_i
            train_idx, test_idx = train_test_split_indices(len(X), test_fraction=0.3, random_state=seed)

            n_use = max(1, int(len(train_idx) * frac))
            X_tr, y_tr = X[train_idx[:n_use]], y[train_idx[:n_use]]
            X_te, y_te = X[test_idx], y[test_idx]

            if model_type == "rf":
                m = train_random_forest(X_tr, y_tr, random_state=seed, **model_kwargs)
            elif model_type == "xgb":
                m = train_gradient_boosting(X_tr, y_tr, random_state=seed, **model_kwargs)
            elif model_type == "knn":
                m = train_knn_regressor(X_tr, y_tr, **model_kwargs)
            elif model_type == "svr":
                m = train_svr(X_tr, y_tr, **model_kwargs)
            else:
                raise ValueError(f"Unknown model_type: {model_type}")

            pred_tr = predict(m, X_tr)
            pred_te = predict(m, X_te)

            r2_trains.append(r2_score(y_tr, pred_tr))
            r2_tests.append(r2_score(y_te, pred_te))
            mae_trains.append(mean_absolute_error(y_tr, pred_tr))
            mae_tests.append(mean_absolute_error(y_te, pred_te))

        results["train_sizes"].append(n_use)
        results["train_r2"].append(float(np.mean(r2_trains)))
        results["test_r2"].append(float(np.mean(r2_tests)))
        results["train_mae"].append(float(np.mean(mae_trains)))
        results["test_mae"].append(float(np.mean(mae_tests)))

    return results


def cross_validate_model(X: np.ndarray, y: np.ndarray,
                          model_type: str = "rf",
                          n_splits: int = 30,
                          random_state: int = 0,
                          scale: bool = False,
                          clean_per_fold: bool = True,
                          **model_kwargs) -> Dict[str, List[float]]:
    """Run repeated random 70:30 split cross-validation.

    The split for repeat ``i`` uses ``random_state + i`` as the seed, so the
    full protocol is deterministic given ``random_state`` and ``n_splits``.

    Parameters
    ----------
    X : np.ndarray
        Feature matrix. May contain constant columns and NaNs; these are
        cleaned **per training fold** when ``clean_per_fold=True`` (the default).
    y : np.ndarray
        Target array.
    model_type : str
        'rf', 'xgb', 'gp', 'svr', 'knn'.
    n_splits : int
        Number of random 70:30 splits (default 30).
    random_state : int
        Base random seed (default 0); split ``i`` uses ``random_state + i``.
    scale : bool
        If True, standardize features with a ``StandardScaler`` fit on the
        training fold only and applied to the test fold (no leakage). Distance-
        and kernel-based learners (KNN, SVR) require this; tree models (RF, XGB)
        are scale-invariant and may leave it False.
    clean_per_fold : bool
        If True (default), constant-column dropping and median imputation are
        computed **on the training fold only** and applied to the test fold,
        so no statistic ever leaks from test to train. Columns that are
        constant *within the training fold* are dropped; remaining NaNs are
        filled with the *training-fold* median. Pass an already-clean ``X``
        with ``clean_per_fold=False`` to skip this step.
    **model_kwargs
        Model constructor arguments.

    Returns
    -------
    dict
        Keys: 'r2_scores', 'mae_scores', 'rmse_scores' (each a list of float).
    """
    from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
    from sklearn.preprocessing import StandardScaler

    X = np.asarray(X, dtype=float)
    r2s, maes, rmses = [], [], []
    for i in range(n_splits):
        seed = random_state + i
        train_idx, test_idx = train_test_split_indices(len(X), test_fraction=0.3, random_state=seed)
        X_tr, y_tr = X[train_idx], y[train_idx]
        X_te, y_te = X[test_idx], y[test_idx]

        if clean_per_fold:
            # Drop columns that are constant within the TRAIN fold, then
            # median-impute using TRAIN-fold medians only (no test leakage).
            col_min = np.nanmin(X_tr, axis=0)
            col_max = np.nanmax(X_tr, axis=0)
            keep = ~np.isclose(col_min, col_max, equal_nan=False)
            keep &= ~np.isnan(col_min)  # all-NaN columns are dropped
            X_tr, X_te = X_tr[:, keep], X_te[:, keep]
            train_median = np.nanmedian(X_tr, axis=0)
            train_median = np.where(np.isnan(train_median), 0.0, train_median)
            tr_nan = np.isnan(X_tr)
            te_nan = np.isnan(X_te)
            X_tr = np.where(tr_nan, train_median, X_tr)
            X_te = np.where(te_nan, train_median, X_te)

        if scale:
            scaler = StandardScaler().fit(X_tr)
            X_tr = scaler.transform(X_tr)
            X_te = scaler.transform(X_te)

        if model_type == "rf":
            m = train_random_forest(X_tr, y_tr, random_state=seed, **model_kwargs)
        elif model_type == "xgb":
            m = train_gradient_boosting(X_tr, y_tr, random_state=seed, **model_kwargs)
        elif model_type == "gp":
            m = train_gaussian_process(X_tr, y_tr, random_state=seed, **model_kwargs)
        elif model_type == "svr":
            m = train_svr(X_tr, y_tr, **model_kwargs)
        elif model_type == "knn":
            m = train_knn_regressor(X_tr, y_tr, **model_kwargs)
        else:
            raise ValueError(f"Unknown model_type: {model_type}")

        pred = predict(m, X_te)
        r2s.append(r2_score(y_te, pred))
        maes.append(mean_absolute_error(y_te, pred))
        rmses.append(float(np.sqrt(mean_squared_error(y_te, pred))))

    return {"r2_scores": r2s, "mae_scores": maes, "rmse_scores": rmses}

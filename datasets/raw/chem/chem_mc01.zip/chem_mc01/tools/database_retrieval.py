"""
Database retrieval stubs for external antimicrobial resistance databases.
These functions provide lookup interfaces for reference data.
"""

import pandas as pd
from typing import Optional, Dict, List


def get_clsi_breakpoint(species: str, antibiotic: str,
                         breakpoints_df: pd.DataFrame) -> Dict:
    """
    Look up CLSI clinical breakpoints for a pathogen-antibiotic pair.
    breakpoints_df should have columns: Species, Antibiotic, S, R.
    Returns dict with S (susceptible cutoff) and R (resistant cutoff) in
    log2-normalized MIC units, or NaN if not found.
    """
    match = breakpoints_df[
        (breakpoints_df['Species'] == species) &
        (breakpoints_df['Antibiotic'] == antibiotic)
    ]
    if len(match) == 0:
        return {'S': float('nan'), 'R': float('nan'), 'found': False}
    row = match.iloc[0]
    return {'S': float(row['S']), 'R': float(row['R']), 'found': True}


def list_available_breakpoints(breakpoints_df: pd.DataFrame,
                                species: Optional[str] = None) -> pd.DataFrame:
    """
    List all available CLSI breakpoints, optionally filtered by species.
    Returns a DataFrame of Species, Antibiotic, S, R.
    """
    if species:
        return breakpoints_df[breakpoints_df['Species'] == species].copy()
    return breakpoints_df.copy()


def get_species_list(df: pd.DataFrame) -> List[str]:
    """Return sorted list of unique pathogen species in the dataset."""
    return sorted(df['Species'].unique().tolist())


def get_antibiotic_list(df: pd.DataFrame, species: Optional[str] = None) -> List[str]:
    """
    Return list of antibiotics tested for a given species.
    If species is None, returns all antibiotic columns.
    """
    meta_cols = ['Isolate Id', 'Study', 'Species', 'Organism Group', 'Country',
                 'Gender', 'Age Group', 'Speciality', 'Source', 'In / Out Patient', 'Year']
    abx_cols = [c for c in df.columns if c not in meta_cols and not str(c).endswith('_I')]

    if species is None:
        return abx_cols

    sp_data = df[df['Species'] == species]
    # Return only antibiotics with at least some non-null values
    return [c for c in abx_cols if sp_data[c].notna().sum() > 0]


def get_country_list(df: pd.DataFrame) -> List[str]:
    """Return sorted list of unique countries in the dataset."""
    return sorted(df['Country'].dropna().unique().tolist())


def get_year_range(df: pd.DataFrame) -> Dict:
    """Return the year range of the dataset."""
    return {'min_year': int(df['Year'].min()), 'max_year': int(df['Year'].max()),
            'n_years': int(df['Year'].nunique())}

"""
Plotting primitives for MIC surveillance data visualization.
All functions return a dict with 'path' pointing to the saved figure file.
"""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from typing import Optional, List, Dict, Tuple


def plot_resistance_heatmap(rate_matrix: np.ndarray, row_labels: List[str],
                             col_labels: List[str], output_path: str,
                             title: str = 'Resistance Rate (%)',
                             cmap: str = 'YlOrRd',
                             annotate: bool = True,
                             figsize: Tuple[float, float] = (14, 10)) -> Dict:
    """
    Plot a heatmap of resistance rates. Rows are pathogen-antibiotic pairs,
    columns are years or other grouping variable.
    rate_matrix values should be in [0, 100] (percentages).
    Returns {'path': output_path}.
    """
    fig, ax = plt.subplots(figsize=figsize)
    im = ax.imshow(rate_matrix, aspect='auto', cmap=cmap, interpolation='nearest')
    ax.set_xticks(range(len(col_labels)))
    ax.set_xticklabels(col_labels, rotation=45, ha='right', fontsize=9)
    ax.set_yticks(range(len(row_labels)))
    ax.set_yticklabels(row_labels, fontsize=8)
    ax.set_title(title, fontsize=14)
    cbar = plt.colorbar(im, ax=ax, shrink=0.8)
    cbar.set_label('% Resistant', fontsize=11)

    if annotate:
        for i in range(len(row_labels)):
            for j in range(len(col_labels)):
                val = rate_matrix[i, j]
                if not np.isnan(val):
                    color = 'white' if val > 50 else 'black'
                    ax.text(j, i, f'{val:.0f}', ha='center', va='center',
                            fontsize=6, color=color)

    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    return {'path': output_path}


def plot_temporal_trend(years: np.ndarray, values: np.ndarray,
                         output_path: str,
                         ylabel: str = 'Value',
                         title: str = 'Temporal Trend',
                         show_regression: bool = True,
                         figsize: Tuple[float, float] = (8, 5)) -> Dict:
    """
    Plot a time series with optional linear regression line.
    Returns {'path': output_path}.
    """
    from scipy import stats as sp_stats

    fig, ax = plt.subplots(figsize=figsize)
    ax.plot(years, values, 'o-', linewidth=2, markersize=6, color='steelblue')

    if show_regression and len(years) > 2:
        slope, intercept, r_val, p_val, se = sp_stats.linregress(years, values)
        x_fit = np.array([years.min(), years.max()])
        y_fit = slope * x_fit + intercept
        ax.plot(x_fit, y_fit, '--r', alpha=0.7,
                label=f'slope={slope:.3f}/yr, p={p_val:.4f}')
        ax.legend(fontsize=10)

    ax.set_xlabel('Year', fontsize=12)
    ax.set_ylabel(ylabel, fontsize=12)
    ax.set_title(title, fontsize=13)
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    return {'path': output_path}


def plot_mic_distribution(mic_values: np.ndarray, output_path: str,
                           title: str = 'MIC Distribution',
                           bins: Optional[np.ndarray] = None,
                           breakpoint_line: Optional[float] = None,
                           figsize: Tuple[float, float] = (8, 5)) -> Dict:
    """
    Plot histogram of log2-transformed MIC values.
    Optionally shows a vertical line at the clinical breakpoint.
    Returns {'path': output_path}.
    """
    log_mics = np.log2(np.where(mic_values <= 0, np.nan, mic_values))
    log_mics = log_mics[~np.isnan(log_mics)]

    if bins is None:
        bins = np.arange(-10, 12, 1)

    fig, ax = plt.subplots(figsize=figsize)
    ax.hist(log_mics, bins=bins, edgecolor='black', alpha=0.7, color='steelblue', density=True)

    if breakpoint_line is not None:
        ax.axvline(np.log2(breakpoint_line), color='red', linestyle='--', linewidth=2,
                   label=f'Breakpoint = {breakpoint_line}')
        ax.legend(fontsize=10)

    ax.set_xlabel('log₂(MIC)', fontsize=12)
    ax.set_ylabel('Density', fontsize=12)
    ax.set_title(title, fontsize=13)
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    return {'path': output_path}


def plot_multi_trend_comparison(trend_data: Dict[str, pd.DataFrame],
                                 output_path: str,
                                 value_col: str = 'resistance_rate',
                                 year_col: str = 'Year',
                                 ylabel: str = 'Resistance Rate (%)',
                                 title: str = 'Resistance Trends Comparison',
                                 figsize: Tuple[float, float] = (10, 6)) -> Dict:
    """
    Plot multiple time series on the same axes for comparison.
    trend_data is a dict mapping label -> DataFrame with year_col and value_col.
    Returns {'path': output_path}.
    """
    fig, ax = plt.subplots(figsize=figsize)
    for label, tdf in trend_data.items():
        ax.plot(tdf[year_col], tdf[value_col] * 100, 'o-', label=label,
                linewidth=2, markersize=5)

    ax.set_xlabel('Year', fontsize=12)
    ax.set_ylabel(ylabel, fontsize=12)
    ax.set_title(title, fontsize=13)
    ax.legend(fontsize=9, bbox_to_anchor=(1.05, 1), loc='upper left')
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    return {'path': output_path}


def plot_slope_histogram(slopes: np.ndarray, output_path: str,
                          title: str = 'Distribution of MIC Temporal Trends',
                          xlabel: str = 'Mean log₂ MIC Change per Year',
                          figsize: Tuple[float, float] = (8, 5)) -> Dict:
    """
    Plot histogram of regression slopes for multiple PA pairs.
    Highlights zero line and median.
    Returns {'path': output_path}.
    """
    clean = slopes[~np.isnan(slopes)]
    n_pos = int(np.sum(clean > 0))
    n_neg = int(np.sum(clean < 0))

    fig, ax = plt.subplots(figsize=figsize)
    ax.hist(clean, bins=40, edgecolor='black', alpha=0.7, color='steelblue')
    ax.axvline(0, color='red', linestyle='--', linewidth=2, label='No change')
    ax.axvline(np.median(clean), color='green', linestyle='--', linewidth=2,
               label=f'Median={np.median(clean):.4f}')
    ax.set_xlabel(xlabel, fontsize=12)
    ax.set_ylabel('Number of PA Pairs', fontsize=12)
    ax.set_title(f'{title}\n({n_neg} decreasing, {n_pos} increasing)', fontsize=13)
    ax.legend(fontsize=10)
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    return {'path': output_path}


def plot_correlogram(corr_matrix: np.ndarray, year_labels: List[str],
                      output_path: str,
                      title: str = 'Year-Year MIC Correlation',
                      figsize: Tuple[float, float] = (8, 7)) -> Dict:
    """
    Plot a year-year correlation matrix (correlogram) as a heatmap.
    Returns {'path': output_path}.
    """
    fig, ax = plt.subplots(figsize=figsize)
    im = ax.imshow(corr_matrix, cmap='RdYlGn', vmin=0, vmax=1, interpolation='nearest')
    ax.set_xticks(range(len(year_labels)))
    ax.set_xticklabels(year_labels, rotation=45, ha='right', fontsize=9)
    ax.set_yticks(range(len(year_labels)))
    ax.set_yticklabels(year_labels, fontsize=9)
    ax.set_title(title, fontsize=13)
    plt.colorbar(im, ax=ax, label='Correlation', shrink=0.8)
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    return {'path': output_path}


def plot_phase_plane(r_position: np.ndarray, dr_dt: np.ndarray,
                      labels: List[str], output_path: str,
                      title: str = 'R-MIC Phase Plane',
                      figsize: Tuple[float, float] = (10, 8)) -> Dict:
    """
    Plot (R, dR/dt) phase plane where R is the 2017 R-MIC position
    and dR/dt is the R-MIC time derivative.
    x-axis: R position as a breakpoint-normalized coordinate
            log2(MIC / 2**R_breakpoint), so 0 = the clinical breakpoint
            (this is the normalize_mic_to_breakpoint flow, distinct from the
            raw log2(MIC)-vs-log2-breakpoint classification used for SIR rates)
    y-axis: dR/dt (change per year)
    Returns {'path': output_path}.
    """
    fig, ax = plt.subplots(figsize=figsize)
    ax.axhline(0, color='gray', linestyle='-', alpha=0.5)
    ax.axvline(0, color='gray', linestyle='-', alpha=0.5)
    ax.scatter(r_position, dr_dt, s=60, alpha=0.7, edgecolors='black', linewidth=0.5)

    for i, label in enumerate(labels):
        if not np.isnan(r_position[i]) and not np.isnan(dr_dt[i]):
            ax.annotate(label, (r_position[i], dr_dt[i]), fontsize=7,
                       ha='left', va='bottom', alpha=0.8)

    ax.set_xlabel('R-MIC position (log₂, 0 = breakpoint)', fontsize=12)
    ax.set_ylabel('dR/dt (log₂ MIC change per year)', fontsize=12)
    ax.set_title(title, fontsize=13)
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    return {'path': output_path}


def plot_regional_comparison(region_rates: Dict[str, pd.DataFrame],
                              output_path: str,
                              value_col: str = 'resistance_rate',
                              year_col: str = 'Year',
                              title: str = 'Regional Resistance Comparison',
                              figsize: Tuple[float, float] = (10, 6)) -> Dict:
    """
    Plot resistance rate trends for different geographic regions.
    region_rates maps region name to DataFrame with year_col and value_col.
    Returns {'path': output_path}.
    """
    fig, ax = plt.subplots(figsize=figsize)
    markers = ['o', 's', '^', 'D', 'v', 'p']
    for idx, (region, rdf) in enumerate(region_rates.items()):
        marker = markers[idx % len(markers)]
        ax.plot(rdf[year_col], rdf[value_col] * 100, f'{marker}-', label=region,
                linewidth=2, markersize=6)

    ax.set_xlabel('Year', fontsize=12)
    ax.set_ylabel('Resistance Rate (%)', fontsize=12)
    ax.set_title(title, fontsize=13)
    ax.legend(fontsize=10)
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    return {'path': output_path}

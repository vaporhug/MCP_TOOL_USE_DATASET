"""
Low-level analysis primitives for MIC (minimum inhibitory concentration)
antimicrobial resistance surveillance data.
Functions operate on pandas DataFrames and numpy arrays.
No domain-specific logic is embedded — the caller decides thresholds and parameters.
"""

import numpy as np
import pandas as pd
from typing import Optional, Tuple, List, Dict
from scipy import stats


def load_mic_data(filepath: str, compression: Optional[str] = 'infer', **kwargs) -> pd.DataFrame:
    """Load MIC surveillance data from CSV (optionally gzipped). Returns a DataFrame."""
    return pd.read_csv(filepath, compression=compression, low_memory=False, **kwargs)


def load_breakpoints(filepath: str) -> pd.DataFrame:
    """Load clinical breakpoint definitions from CSV. Expected columns: Species, Antibiotic, S, R."""
    return pd.read_csv(filepath)


def get_metadata_columns(df: pd.DataFrame,
                         meta_cols: Optional[List[str]] = None) -> List[str]:
    """Return metadata column names in the DataFrame (non-antibiotic columns)."""
    if meta_cols is None:
        meta_cols = ['Isolate Id', 'Study', 'Species', 'Organism Group', 'Country',
                     'Gender', 'Age Group', 'Speciality', 'Source', 'In / Out Patient', 'Year']
    return [c for c in meta_cols if c in df.columns]


def get_antibiotic_columns(df: pd.DataFrame, exclude_interpretation: bool = True) -> List[str]:
    """
    Return antibiotic MIC columns from the DataFrame.
    If exclude_interpretation is True, columns ending in '_I' (SIR interpretation) are excluded.
    """
    meta = get_metadata_columns(df)
    abx_cols = [c for c in df.columns if c not in meta]
    if exclude_interpretation:
        abx_cols = [c for c in abx_cols if not str(c).endswith('_I')]
    return abx_cols


def parse_mic_value(mic_str) -> float:
    """
    Parse a single MIC string to numeric value.
    Handles formats: '0.5', '<=0.06', '>=64', '>32', '<0.25'.
    Returns np.nan for unparseable values.
    """
    s = str(mic_str).strip()
    if s in ('nan', 'NaN', '', 'None'):
        return np.nan
    s = s.replace('<=', '').replace('>=', '').replace('>', '').replace('<', '')
    try:
        return float(s)
    except (ValueError, TypeError):
        return np.nan


def parse_mic_column(series: pd.Series) -> pd.Series:
    """Parse an entire column of MIC strings to numeric values."""
    return series.apply(parse_mic_value)


def log2_transform(values: np.ndarray, floor: float = 0.001) -> np.ndarray:
    """
    Log2-transform MIC values. Values <= 0 are replaced with floor before transform.
    Returns array of log2(values).
    """
    safe = np.where(values <= 0, floor, values)
    return np.log2(safe)


def normalize_mic_to_breakpoint(mic_values: np.ndarray, breakpoint: float) -> np.ndarray:
    """
    Normalize raw (linear) MIC concentrations against a LINEAR clinical
    breakpoint by dividing and log2-transforming: result = log2(MIC / breakpoint).
    A result of 0 means MIC equals the breakpoint; positive is more resistant,
    negative is more susceptible.

    NOTE on units: the ``R``/``S`` columns in breakpoints.csv are stored as
    log2 of the raw-MIC concentration threshold (e.g. R = 2.0 means a clinical
    breakpoint of 2**2 = 4 ug/mL). To use this normalized flow with those
    values, first convert the stored log2 threshold to a linear breakpoint, i.e.
    pass ``breakpoint = 2 ** stored_log2_breakpoint``. The resulting
    log2(MIC / 2**stored) is then centred so that 0 = the clinical boundary.
    (For the simpler classification path, classify_sir compares
    log2(raw MIC) directly against the stored log2 breakpoint, which is
    equivalent and avoids this conversion.)
    """
    ratio = mic_values / breakpoint
    return np.log2(np.where(ratio <= 0, np.nan, ratio))


def classify_sir(mic_values: np.ndarray, s_breakpoint: float,
                 r_breakpoint: float, breakpoint_in_log2: bool = True) -> np.ndarray:
    """
    Classify MIC values into S (Susceptible), I (Intermediate), R (Resistant).

    The breakpoints in breakpoints.csv are expressed on a log2 scale (0 = the
    clinical boundary, negative = more susceptible, positive = more resistant),
    while the raw MIC strings in the surveillance table are linear concentrations.
    To compare like with like, the raw MIC values are log2-transformed before the
    threshold test when ``breakpoint_in_log2`` is True (the default). Set it to
    False only if both the MICs and the breakpoints are already on the same
    linear scale.

    S: log2(MIC) <= s_breakpoint
    R: log2(MIC) >= r_breakpoint
    I: s_breakpoint < log2(MIC) < r_breakpoint
    Returns array of strings 'S', 'I', 'R', or 'NA'.
    """
    mic_values = np.asarray(mic_values, dtype=float)
    if breakpoint_in_log2:
        scale = log2_transform(mic_values)
        # preserve NaNs from the original (log2_transform floors them)
        scale = np.where(np.isnan(mic_values), np.nan, scale)
    else:
        scale = mic_values

    result = np.full(len(scale), 'NA', dtype=object)
    valid = ~np.isnan(scale)
    result[valid & (scale <= s_breakpoint)] = 'S'
    result[valid & (scale >= r_breakpoint)] = 'R'
    result[valid & (scale > s_breakpoint) & (scale < r_breakpoint)] = 'I'
    return result


def compute_resistance_rate(sir_classifications: np.ndarray) -> float:
    """
    Compute the fraction of isolates classified as Resistant.
    Ignores 'NA' entries.
    """
    valid = sir_classifications[sir_classifications != 'NA']
    if len(valid) == 0:
        return np.nan
    return float(np.sum(valid == 'R')) / len(valid)


def compute_resistance_rate_by_group(df: pd.DataFrame, group_col: str,
                                      mic_col: str, r_breakpoint: float,
                                      breakpoint_in_log2: bool = True) -> pd.DataFrame:
    """
    Compute resistance rate grouped by a column (e.g., Year, Country).

    The R breakpoint from breakpoints.csv is on a log2 scale, so by default the
    raw parsed MIC values are log2-transformed before the comparison
    ``log2(MIC) >= r_breakpoint``. Set ``breakpoint_in_log2`` to False to compare
    raw MICs directly against a linear-scale breakpoint.

    Returns DataFrame with columns: [group_col, N, N_resistant, resistance_rate].
    """
    mics = parse_mic_column(df[mic_col])
    valid = df[mics.notna()].copy()
    mic_num = mics[mics.notna()].values
    if breakpoint_in_log2:
        valid['_mic_num'] = log2_transform(mic_num)
    else:
        valid['_mic_num'] = mic_num

    results = []
    for grp_val, grp in valid.groupby(group_col):
        n = len(grp)
        n_r = int((grp['_mic_num'] >= r_breakpoint).sum())
        results.append({group_col: grp_val, 'N': n, 'N_resistant': n_r,
                       'resistance_rate': n_r / n if n > 0 else np.nan})
    return pd.DataFrame(results)


def compute_mic_distribution(mic_values: np.ndarray,
                              bins: Optional[np.ndarray] = None) -> Tuple[np.ndarray, np.ndarray]:
    """
    Compute histogram of log2-transformed MIC values.
    Returns (counts, bin_edges).
    """
    log_mics = log2_transform(mic_values[~np.isnan(mic_values)])
    if bins is None:
        bins = np.arange(-10, 12, 1)
    counts, bin_edges = np.histogram(log_mics, bins=bins)
    return counts, bin_edges


def compute_annual_mean_mic(df: pd.DataFrame, mic_col: str,
                             year_col: str = 'Year',
                             log_transform: bool = True) -> pd.DataFrame:
    """
    Compute annual mean MIC (optionally log2-transformed) for a given antibiotic.
    Returns DataFrame with columns: [Year, mean_mic, n_isolates].
    """
    mics = parse_mic_column(df[mic_col])
    valid = df[mics.notna()].copy()
    valid['_mic'] = mics[mics.notna()].values
    if log_transform:
        valid['_mic'] = log2_transform(valid['_mic'].values)

    result = valid.groupby(year_col).agg(
        mean_mic=('_mic', 'mean'),
        std_mic=('_mic', 'std'),
        n_isolates=('_mic', 'count')
    ).reset_index()
    return result


def linear_regression_trend(x: np.ndarray, y: np.ndarray) -> Dict:
    """
    Fit a linear regression y = slope*x + intercept.
    Returns dict with slope, intercept, r_value, p_value, std_err, r_squared.
    """
    mask = ~(np.isnan(x) | np.isnan(y))
    x_clean = x[mask]
    y_clean = y[mask]
    if len(x_clean) < 3:
        return {'slope': np.nan, 'intercept': np.nan, 'r_value': np.nan,
                'p_value': np.nan, 'std_err': np.nan, 'r_squared': np.nan}
    slope, intercept, r_value, p_value, std_err = stats.linregress(x_clean, y_clean)
    return {'slope': float(slope), 'intercept': float(intercept),
            'r_value': float(r_value), 'p_value': float(p_value),
            'std_err': float(std_err), 'r_squared': float(r_value**2)}


def compute_temporal_mic_trend(df: pd.DataFrame, mic_col: str,
                                year_range: Optional[Tuple[int, int]] = None,
                                year_col: str = 'Year') -> Dict:
    """
    Compute the temporal trend of mean log2(MIC) using linear regression.
    Optionally restrict to a year range (start, end inclusive).
    Returns regression results dict.
    """
    annual = compute_annual_mean_mic(df, mic_col, year_col, log_transform=True)
    if year_range:
        annual = annual[(annual[year_col] >= year_range[0]) & (annual[year_col] <= year_range[1])]

    if len(annual) < 3:
        return {'slope': np.nan, 'p_value': np.nan, 'n_years': 0}

    result = linear_regression_trend(annual[year_col].values.astype(float),
                                     annual['mean_mic'].values)
    result['n_years'] = len(annual)
    return result


def skewness_test(values: np.ndarray) -> Dict:
    """
    Perform D'Agostino skewness test on an array.
    Returns dict with statistic and p_value.
    """
    clean = values[~np.isnan(values)]
    if len(clean) < 8:
        return {'statistic': np.nan, 'p_value': np.nan}
    stat, p = stats.skewtest(clean)
    return {'statistic': float(stat), 'p_value': float(p)}


def compute_year_year_correlation(df: pd.DataFrame, mic_col: str,
                                   year_col: str = 'Year',
                                   bins: Optional[np.ndarray] = None) -> np.ndarray:
    """
    Compute year-year correlation matrix (correlogram) of MIC distributions.
    For each pair of years, compute the Pearson correlation of their MIC histograms.
    Returns a symmetric correlation matrix (years x years).
    """
    mics = parse_mic_column(df[mic_col])
    valid = df[mics.notna()].copy()
    valid['_mic'] = log2_transform(mics[mics.notna()].values)

    if bins is None:
        bins = np.arange(-10, 12, 1)

    years = sorted(valid[year_col].unique())
    n_years = len(years)
    corr_matrix = np.ones((n_years, n_years))

    # Compute histogram for each year
    histograms = {}
    for yr in years:
        yr_data = valid[valid[year_col] == yr]['_mic'].values
        if len(yr_data) > 10:
            hist, _ = np.histogram(yr_data, bins=bins, density=True)
            histograms[yr] = hist

    for i, yr_i in enumerate(years):
        for j, yr_j in enumerate(years):
            if yr_i in histograms and yr_j in histograms:
                r, _ = stats.pearsonr(histograms[yr_i], histograms[yr_j])
                corr_matrix[i, j] = r
            else:
                corr_matrix[i, j] = np.nan

    return corr_matrix


def filter_by_species(df: pd.DataFrame, species: str) -> pd.DataFrame:
    """Filter DataFrame to rows matching a specific pathogen species."""
    return df[df['Species'] == species].copy()


def filter_by_year_range(df: pd.DataFrame, start_year: int, end_year: int,
                          year_col: str = 'Year') -> pd.DataFrame:
    """Filter DataFrame to rows within a year range (inclusive)."""
    return df[(df[year_col] >= start_year) & (df[year_col] <= end_year)].copy()


def filter_by_country(df: pd.DataFrame, countries: List[str]) -> pd.DataFrame:
    """Filter DataFrame to rows from specified countries."""
    return df[df['Country'].isin(countries)].copy()


def filter_by_study(df: pd.DataFrame, study: str) -> pd.DataFrame:
    """Filter DataFrame to rows from a specific study component (e.g., 'TEST' or 'Inform')."""
    return df[df['Study'] == study].copy()


def count_isolates_by_group(df: pd.DataFrame, group_cols: List[str]) -> pd.DataFrame:
    """Count number of isolates per group (e.g., by Species, Year, Country)."""
    return df.groupby(group_cols).size().reset_index(name='count')

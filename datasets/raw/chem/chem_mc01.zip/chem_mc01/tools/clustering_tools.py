"""
Clustering and Gaussian mixture model primitives for MIC distribution analysis.
Used to identify susceptible (S) and resistant (R) subpopulations in MIC data.
"""

import numpy as np
import pandas as pd
from typing import Optional, Tuple, Dict, List
from scipy import stats


def fit_gaussian_mixture(data: np.ndarray, n_components: int = 2,
                          max_iter: int = 100, tol: float = 1e-4,
                          random_state: int = 42) -> Dict:
    """
    Fit a Gaussian mixture model to 1D data using EM algorithm.
    Returns dict with means, variances, weights, labels, bic, aic.
    """
    from sklearn.mixture import GaussianMixture
    data_clean = data[~np.isnan(data)].reshape(-1, 1)
    if len(data_clean) < n_components * 5:
        return {'means': [], 'variances': [], 'weights': [], 'labels': np.array([]),
                'bic': np.nan, 'aic': np.nan}

    gm = GaussianMixture(n_components=n_components, max_iter=max_iter,
                          tol=tol, random_state=random_state)
    gm.fit(data_clean)
    labels = gm.predict(data_clean)

    return {
        'means': gm.means_.flatten().tolist(),
        'variances': gm.covariances_.flatten().tolist(),
        'weights': gm.weights_.tolist(),
        'labels': labels,
        'bic': float(gm.bic(data_clean)),
        'aic': float(gm.aic(data_clean))
    }


def select_optimal_k(data: np.ndarray, k_range: Tuple[int, int] = (1, 5),
                      criterion: str = 'bic') -> int:
    """
    Select the optimal number of Gaussian mixture components using BIC or AIC.
    Returns the optimal k.
    """
    data_clean = data[~np.isnan(data)].reshape(-1, 1)
    if len(data_clean) < 10:
        return 1

    from sklearn.mixture import GaussianMixture
    best_k = 1
    best_score = np.inf

    for k in range(k_range[0], k_range[1] + 1):
        if len(data_clean) < k * 5:
            break
        gm = GaussianMixture(n_components=k, random_state=42, max_iter=200)
        gm.fit(data_clean)
        score = gm.bic(data_clean) if criterion == 'bic' else gm.aic(data_clean)
        if score < best_score:
            best_score = score
            best_k = k

    return best_k


def identify_sr_clusters(data: np.ndarray, n_components: int = 2) -> Dict:
    """
    Identify susceptible (S) and resistant (R) clusters from MIC data.
    The R-cluster is the one with the highest mean MIC.
    The S-cluster is the complement (all non-R clusters).
    The boundary is the MIC value where both clusters are equally likely.

    Returns dict with r_mean, s_mean, r_fraction, s_fraction, boundary.
    """
    gmm_result = fit_gaussian_mixture(data, n_components=n_components)
    if not gmm_result['means']:
        return {'r_mean': np.nan, 's_mean': np.nan, 'r_fraction': np.nan,
                's_fraction': np.nan, 'boundary': np.nan}

    means = np.array(gmm_result['means'])
    weights = np.array(gmm_result['weights'])

    r_idx = np.argmax(means)
    r_mean = means[r_idx]
    r_fraction = weights[r_idx]

    s_indices = [i for i in range(len(means)) if i != r_idx]
    if s_indices:
        s_mean = np.average(means[s_indices], weights=weights[s_indices])
        s_fraction = np.sum(weights[s_indices])
    else:
        s_mean = r_mean
        s_fraction = 0.0

    # Boundary: midpoint between S and R means (simplified)
    boundary = (s_mean + r_mean) / 2.0

    return {
        'r_mean': float(r_mean),
        's_mean': float(s_mean),
        'r_fraction': float(r_fraction),
        's_fraction': float(s_fraction),
        'boundary': float(boundary),
        'n_components': n_components
    }


def compute_annual_sr_metrics(df: pd.DataFrame, mic_col: str,
                               year_col: str = 'Year',
                               n_components=2,
                               k_range: Tuple[int, int] = (1, 5),
                               criterion: str = 'bic') -> pd.DataFrame:
    """
    Compute S-MIC and R-MIC cluster means per year using a Gaussian mixture
    model.

    The number of mixture components can be chosen two ways:

    * ``n_components`` an int (default 2) -> fixed-k clustering: every year is
      fit with exactly that many Gaussian components (the standard S/R two-
      cluster decomposition).
    * ``n_components="auto"`` -> information-criterion k-selection: for each
      year the optimal number of components is chosen by ``select_optimal_k``
      over ``k_range`` using ``criterion`` ('bic' or 'aic'), so years whose MIC
      distribution is genuinely unimodal/multi-modal get a data-driven k rather
      than a forced two-cluster split. The selected k is recorded per year in
      the returned ``n_components`` column.

    Returns DataFrame with Year, s_mean, r_mean, r_fraction, s_fraction,
    boundary, n_components (the k used that year), and n_isolates.
    """
    try:
        from .mic_analysis import parse_mic_column, log2_transform
    except ImportError:
        from mic_analysis import parse_mic_column, log2_transform

    auto_k = isinstance(n_components, str) and n_components.lower() == 'auto'

    mics = parse_mic_column(df[mic_col])
    valid = df[mics.notna()].copy()
    valid['_mic_log2'] = log2_transform(mics[mics.notna()].values)

    results = []
    for yr, grp in valid.groupby(year_col):
        log_mics = grp['_mic_log2'].values
        if len(log_mics) < 50:
            continue

        if auto_k:
            k = select_optimal_k(log_mics, k_range=k_range, criterion=criterion)
        else:
            k = int(n_components)

        sr = identify_sr_clusters(log_mics, n_components=k)
        sr['Year'] = int(yr)
        sr['n_isolates'] = len(log_mics)
        results.append(sr)

    return pd.DataFrame(results)


def compute_rmics_trend(annual_sr: pd.DataFrame, year_col: str = 'Year') -> Dict:
    """
    Compute temporal trend of R-MIC using linear regression on annual R-cluster means.
    Returns regression dict with slope (dR/dt), p_value, etc.
    """
    try:
        from .mic_analysis import linear_regression_trend
    except ImportError:
        from mic_analysis import linear_regression_trend
    valid = annual_sr.dropna(subset=['r_mean'])
    if len(valid) < 3:
        return {'slope': np.nan, 'p_value': np.nan}
    return linear_regression_trend(valid[year_col].values.astype(float),
                                    valid['r_mean'].values)


def compute_smics_trend(annual_sr: pd.DataFrame, year_col: str = 'Year') -> Dict:
    """
    Compute temporal trend of S-MIC using linear regression on annual S-cluster means.
    Returns regression dict with slope (dS/dt), p_value, etc.
    """
    try:
        from .mic_analysis import linear_regression_trend
    except ImportError:
        from mic_analysis import linear_regression_trend
    valid = annual_sr.dropna(subset=['s_mean'])
    if len(valid) < 3:
        return {'slope': np.nan, 'p_value': np.nan}
    return linear_regression_trend(valid[year_col].values.astype(float),
                                    valid['s_mean'].values)

# Tools Index

## mic_analysis.py
MIC data loading, parsing, SIR classification, resistance rate computation, temporal trend analysis, year-year correlation, and data filtering primitives.

## clustering_tools.py
Gaussian mixture model fitting, optimal cluster selection (BIC/AIC), S/R cluster identification, and annual S-MIC/R-MIC trend computation. `compute_annual_sr_metrics` supports both fixed-k clustering (`n_components=int`, default 2) and information-optimal-k clustering (`n_components="auto"`, which calls `select_optimal_k` to choose k per year by BIC/AIC over `k_range`). Cross-module imports of `mic_analysis` use a package/standalone fallback (`try: from .mic_analysis ... except ImportError: from mic_analysis ...`) so the workflow loads under both `import tools.clustering_tools` and a bare `import clustering_tools`.

## plotting_tools.py
Visualization functions: resistance heatmaps, temporal trends, MIC distributions, slope histograms, correlograms, phase planes, regional comparisons. All return {"path": ...}.

## data_processing.py
General tabular data utilities: CSV/compressed loading, filtering, grouping, pivoting, melting, summary statistics, correlation matrices.

## database_retrieval.py
Lookup interfaces for CLSI breakpoints, species/antibiotic/country lists, and year range queries.

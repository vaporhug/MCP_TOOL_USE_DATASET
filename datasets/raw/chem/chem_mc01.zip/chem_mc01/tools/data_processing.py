"""
General-purpose data processing utilities for tabular data.
"""

import numpy as np
import pandas as pd
from typing import Optional, List, Dict, Tuple


def load_csv(filepath: str, **kwargs) -> pd.DataFrame:
    """Load a CSV file into a DataFrame."""
    return pd.read_csv(filepath, **kwargs)


def load_compressed_csv(filepath: str, compression: str = 'gzip', **kwargs) -> pd.DataFrame:
    """Load a compressed CSV file into a DataFrame."""
    return pd.read_csv(filepath, compression=compression, low_memory=False, **kwargs)


def filter_rows(df: pd.DataFrame, column: str, values: list) -> pd.DataFrame:
    """Filter DataFrame to rows where column value is in the given list."""
    return df[df[column].isin(values)].copy()


def group_aggregate(df: pd.DataFrame, group_cols: List[str],
                     agg_col: str, agg_func: str = 'mean') -> pd.DataFrame:
    """Group by columns and aggregate a value column."""
    return df.groupby(group_cols).agg({agg_col: agg_func}).reset_index()


def pivot_table(df: pd.DataFrame, index: str, columns: str,
                values: str, aggfunc: str = 'mean',
                fill_value: Optional[float] = None) -> pd.DataFrame:
    """Create a pivot table from long-format data."""
    return pd.pivot_table(df, index=index, columns=columns,
                          values=values, aggfunc=aggfunc, fill_value=fill_value)


def melt_wide_to_long(df: pd.DataFrame, id_vars: List[str],
                       value_vars: List[str],
                       var_name: str = 'variable',
                       value_name: str = 'value') -> pd.DataFrame:
    """Melt wide-format DataFrame to long format."""
    return pd.melt(df, id_vars=id_vars, value_vars=value_vars,
                   var_name=var_name, value_name=value_name)


def compute_summary_stats(values: np.ndarray) -> Dict:
    """Compute summary statistics for an array of values."""
    clean = values[~np.isnan(values)]
    if len(clean) == 0:
        return {'mean': np.nan, 'median': np.nan, 'std': np.nan,
                'min': np.nan, 'max': np.nan, 'count': 0}
    return {
        'mean': float(np.mean(clean)),
        'median': float(np.median(clean)),
        'std': float(np.std(clean)),
        'min': float(np.min(clean)),
        'max': float(np.max(clean)),
        'count': int(len(clean))
    }


def merge_dataframes(left: pd.DataFrame, right: pd.DataFrame,
                      on: List[str], how: str = 'inner') -> pd.DataFrame:
    """Merge two DataFrames on shared columns."""
    return pd.merge(left, right, on=on, how=how)


def rank_values(df: pd.DataFrame, column: str,
                ascending: bool = True) -> pd.DataFrame:
    """Rank rows by a column value. Adds a 'rank' column."""
    sorted_df = df.sort_values(column, ascending=ascending).reset_index(drop=True)
    sorted_df['rank'] = range(1, len(sorted_df) + 1)
    return sorted_df


def compute_correlation_matrix(df: pd.DataFrame,
                                 columns: List[str]) -> pd.DataFrame:
    """Compute pairwise Pearson correlation matrix for selected columns."""
    return df[columns].corr(method='pearson')


def describe_dataframe(df: pd.DataFrame) -> Dict:
    """Return a summary description of the DataFrame structure."""
    return {
        'n_rows': len(df),
        'n_columns': len(df.columns),
        'columns': list(df.columns),
        'dtypes': {col: str(dtype) for col, dtype in df.dtypes.items()},
        'null_counts': {col: int(df[col].isna().sum()) for col in df.columns}
    }

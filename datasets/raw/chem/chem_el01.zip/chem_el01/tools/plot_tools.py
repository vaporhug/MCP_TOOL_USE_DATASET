"""Plotting tools for electrolyte screening analysis.

All plot functions save a figure to disk and return {"path": <filepath>}.
"""
import numpy as np
from typing import Optional


def plot_optimization_trajectory(
    history_values: list[float],
    batch_labels: Optional[list[str]] = None,
    xlabel: str = "Cumulative number of evaluated solvents",
    ylabel: str = "BTZ solubility (M)",
    title: str = "Active learning optimization trajectory",
    output_path: str = "artifacts/fig_optimization_trajectory.png",
) -> dict:
    """Plot the optimization trajectory showing best-so-far value over iterations.

    Parameters
    ----------
    history_values : list[float]
        Measured target values in order of evaluation.
    batch_labels : list[str] or None
        Labels for batch boundaries (e.g., ["Initialization", "Cycle 1", ...]).
    xlabel, ylabel, title : str
        Axis labels and title.
    output_path : str
        File path to save the figure.

    Returns
    -------
    dict
        {"path": output_path}
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(8, 5))
    best_so_far = np.maximum.accumulate(history_values)
    ax.plot(range(1, len(history_values) + 1), history_values, 'o', alpha=0.4,
            label="Measured", color="steelblue", markersize=4)
    ax.plot(range(1, len(best_so_far) + 1), best_so_far, '-', color="red",
            linewidth=2, label="Best so far")
    ax.set_xlabel(xlabel, fontsize=12)
    ax.set_ylabel(ylabel, fontsize=12)
    ax.set_title(title, fontsize=14)
    ax.legend()
    plt.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"path": output_path}


def plot_bo_vs_random_comparison(
    bo_counts: list[int],
    random_counts: list[int],
    p_value: float,
    xlabel: str = "Selection method",
    ylabel: str = "Number of evaluated solvents",
    title: str = "BO vs Random selection",
    output_path: str = "artifacts/fig_bo_vs_random.png",
) -> dict:
    """Bar chart comparing BO and random selection efficiency.

    Parameters
    ----------
    bo_counts : list[int]
        Evaluations needed by BO across trials.
    random_counts : list[int]
        Evaluations needed by random across trials.
    p_value : float
        p-value from the t-test.
    xlabel, ylabel, title : str
        Axis labels and title.
    output_path : str
        File path to save the figure.

    Returns
    -------
    dict
        {"path": output_path}
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(6, 5))
    means = [np.mean(bo_counts), np.mean(random_counts)]
    stds = [np.std(bo_counts), np.std(random_counts)]
    labels = ["Bayesian\noptimization", "Random\nselection"]
    colors = ["#4DBEEE", "#D95319"]
    bars = ax.bar(labels, means, yerr=stds, capsize=8, color=colors,
                  edgecolor="black", linewidth=0.8)
    for bar, m, s in zip(bars, means, stds):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + s + 1,
                f"$\\pm${int(s)}", ha="center", fontsize=10)
    ax.set_ylabel(ylabel, fontsize=12)
    ax.set_title(f"{title}\n(p = {p_value:.2e})", fontsize=13)
    plt.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"path": output_path}


def plot_gpr_parity(
    y_true_train: np.ndarray,
    y_pred_train: np.ndarray,
    y_true_test: np.ndarray,
    y_pred_test: np.ndarray,
    sigma_train: Optional[np.ndarray] = None,
    sigma_test: Optional[np.ndarray] = None,
    metrics_train: Optional[dict] = None,
    metrics_test: Optional[dict] = None,
    xlabel: str = "Measured solubility (M)",
    ylabel: str = "Predicted solubility (M)",
    title: str = "GPR parity plot",
    output_path: str = "artifacts/fig_gpr_parity.png",
) -> dict:
    """Parity plot of GPR-predicted vs measured solubility.

    Parameters
    ----------
    y_true_train, y_pred_train : np.ndarray
        Training set true and predicted values.
    y_true_test, y_pred_test : np.ndarray
        Test set true and predicted values.
    sigma_train, sigma_test : np.ndarray or None
        Prediction standard deviations for error bars.
    metrics_train, metrics_test : dict or None
        {R2, RMSE, MAE} for legend annotation.
    output_path : str
        Save path.

    Returns
    -------
    dict
        {"path": output_path}
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(6, 6))
    train_label = "Train"
    test_label = "Test"
    if metrics_train:
        train_label += f" (R²={metrics_train['R2']:.2f}, RMSE={metrics_train['RMSE']:.2f} M)"
    if metrics_test:
        test_label += f" (R²={metrics_test['R2']:.2f}, RMSE={metrics_test['RMSE']:.2f} M)"

    if sigma_train is not None:
        ax.errorbar(y_true_train, y_pred_train, yerr=sigma_train, fmt='o',
                     color="black", markersize=4, alpha=0.6, label=train_label,
                     elinewidth=0.5, capsize=1)
    else:
        ax.scatter(y_true_train, y_pred_train, c="black", s=20, alpha=0.6,
                   label=train_label)

    if sigma_test is not None:
        ax.errorbar(y_true_test, y_pred_test, yerr=sigma_test, fmt='o',
                     color="red", markersize=4, alpha=0.6, label=test_label,
                     elinewidth=0.5, capsize=1)
    else:
        ax.scatter(y_true_test, y_pred_test, c="red", s=20, alpha=0.6,
                   label=test_label)

    lims = [min(ax.get_xlim()[0], ax.get_ylim()[0]),
            max(ax.get_xlim()[1], ax.get_ylim()[1])]
    ax.plot(lims, lims, '--', color='gray', alpha=0.5)
    ax.set_xlim(lims)
    ax.set_ylim(lims)
    ax.set_xlabel(xlabel, fontsize=12)
    ax.set_ylabel(ylabel, fontsize=12)
    ax.set_title(title, fontsize=14)
    ax.legend(fontsize=9)
    ax.set_aspect("equal")
    plt.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"path": output_path}


def plot_property_correlation(
    x_values: np.ndarray,
    y_values: np.ndarray,
    xlabel: str = "logP_solv",
    ylabel: str = "Predicted solubility (M)",
    title: str = "Feature-solubility correlation",
    output_path: str = "artifacts/fig_property_correlation.png",
) -> dict:
    """Scatter plot showing correlation between a feature and predicted solubility.

    Parameters
    ----------
    x_values : np.ndarray
        Feature values (e.g., logP_solv).
    y_values : np.ndarray
        Predicted or measured solubility.
    xlabel, ylabel, title : str
        Axis labels and title.
    output_path : str
        Save path.

    Returns
    -------
    dict
        {"path": output_path}
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(6, 5))
    ax.scatter(x_values, y_values, s=10, alpha=0.4, color="steelblue")

    # Linear fit
    coeffs = np.polyfit(x_values, y_values, 1)
    x_line = np.linspace(x_values.min(), x_values.max(), 100)
    ax.plot(x_line, np.polyval(coeffs, x_line), '--', color='black',
            linewidth=1.5, label=f"slope={coeffs[0]:.3f}")

    ax.set_xlabel(xlabel, fontsize=12)
    ax.set_ylabel(ylabel, fontsize=12)
    ax.set_title(title, fontsize=14)
    ax.legend()
    plt.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"path": output_path}


def plot_solubility_distribution(
    values: np.ndarray,
    batch_labels: Optional[np.ndarray] = None,
    xlabel: str = "BTZ solubility (M)",
    ylabel: str = "Number of evaluated solvents",
    title: str = "Solubility distribution across screening rounds",
    output_path: str = "artifacts/fig_solubility_distribution.png",
) -> dict:
    """Histogram of measured solubilities, optionally colored by batch/round.

    Parameters
    ----------
    values : np.ndarray
        All measured solubility values.
    batch_labels : np.ndarray or None
        Integer labels indicating which batch each sample belongs to.
    xlabel, ylabel, title : str
        Axis labels and title.
    output_path : str
        Save path.

    Returns
    -------
    dict
        {"path": output_path}
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(8, 5))
    if batch_labels is not None:
        unique_batches = sorted(set(batch_labels))
        colors = plt.cm.tab10(np.linspace(0, 1, len(unique_batches)))
        batch_names = {0: "Initialization", 1: "1st batch", 2: "2nd batch", 3: "3rd batch"}
        for b, c in zip(unique_batches, colors):
            mask = batch_labels == b
            label = batch_names.get(b, f"Batch {b}")
            ax.hist(values[mask], bins=20, alpha=0.6, color=c, label=label,
                    edgecolor="black", linewidth=0.5)
        ax.legend()
    else:
        ax.hist(values, bins=20, color="steelblue", edgecolor="black",
                linewidth=0.5)

    ax.set_xlabel(xlabel, fontsize=12)
    ax.set_ylabel(ylabel, fontsize=12)
    ax.set_title(title, fontsize=14)
    plt.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"path": output_path}


def plot_top_formulations_bar(
    names: list[str],
    solubilities: list[float],
    component_solubilities: Optional[list[list[float]]] = None,
    xlabel: str = "Solvent formulation",
    ylabel: str = "BTZ solubility (M)",
    title: str = "Top binary solvent formulations",
    output_path: str = "artifacts/fig_top_formulations.png",
) -> dict:
    """Bar chart of top solvent formulations with their solubilities.

    Parameters
    ----------
    names : list[str]
        Formulation names (e.g., "DOX:DMSO @ 0.8:0.2").
    solubilities : list[float]
        Measured solubility for each formulation.
    component_solubilities : list[list[float]] or None
        Per-formulation list of [solv1_pure, solv2_pure] solubilities.
    xlabel, ylabel, title : str
        Axis labels and title.
    output_path : str
        Save path.

    Returns
    -------
    dict
        {"path": output_path}
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(8, 5))
    x = np.arange(len(names))
    bars = ax.bar(x, solubilities, color="limegreen", edgecolor="black",
                  linewidth=0.8, label="Binary mixture")

    if component_solubilities:
        for i, (comps) in enumerate(component_solubilities):
            for c_val in comps:
                ax.plot([i - 0.2, i + 0.2], [c_val, c_val], '--',
                        color="blue", linewidth=1.5)

    ax.set_xticks(x)
    ax.set_xticklabels(names, rotation=30, ha="right", fontsize=9)
    ax.set_ylabel(ylabel, fontsize=12)
    ax.set_title(title, fontsize=14)
    plt.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"path": output_path}

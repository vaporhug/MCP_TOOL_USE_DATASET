"""Active learning / Bayesian optimization loop for electrolyte screening.

Provides the core closed-loop workflow: train surrogate, score candidates
with an acquisition function, select next batch, update training set.
Also includes random-selection baseline and statistical comparison.
"""
import numpy as np


def run_bo_loop(
    X_pool: np.ndarray,
    y_pool: np.ndarray,
    pool_names: list[str],
    n_initial: int = 5,
    n_iterations: int = 93,
    batch_size: int = 1,
    acquisition: str = "ei",
    epsilon: float = 1e-2,
    kernel_nu: float = 1.5,
    random_state: int = 42,
) -> dict:
    """Run a single Bayesian optimization trial on a pre-measured dataset.

    Simulates the closed-loop BO workflow: at each iteration, train GPR on
    the current training set, score remaining candidates (the as-yet
    unevaluated entries of the pool) with the chosen acquisition function,
    select top candidate(s), look up their true y-value from y_pool, and add
    them to the training set. The pool itself is the candidate space, so a
    separate candidate matrix is not required.

    Parameters
    ----------
    X_pool : np.ndarray
        (N, d) feature matrix for all candidates with known y.
    y_pool : np.ndarray
        (N,) true target values for all candidates.
    pool_names : list[str]
        Names for the pool entries.
    n_initial : int
        Number of randomly selected initial training points.
    n_iterations : int
        Number of BO iterations after initialization.
    batch_size : int
        Number of candidates selected per iteration.
    acquisition : str
        Acquisition function: 'ei', 'ucb', or 'pi'.
    epsilon : float
        Exploration parameter for EI/PI; kappa for UCB.
    kernel_nu : float
        Matern kernel smoothness.
    random_state : int
        RNG seed for initial selection.

    Returns
    -------
    dict
        {
            "n_evaluated": total number of pool entries evaluated when the
                loop terminated (n_initial + all BO selections),
            "n_evaluated_to_best": total number of evaluations (including the
                n_initial seed points) performed when the best y was first
                reached -- the natural cost metric for BO-vs-random,
            "best_name": str,
            "best_value": float,
            "history": list of (name, value) tuples in order of evaluation,
            "found_at_iteration": number of post-initialization BO iterations
                taken to first reach the best y (0 if the best was already in
                the seed set),
        }
    """
    from sklearn.gaussian_process import GaussianProcessRegressor
    from sklearn.gaussian_process.kernels import ConstantKernel, Matern, WhiteKernel
    from scipy.stats import norm

    rng = np.random.RandomState(random_state)
    N = len(y_pool)

    # Random initial selection
    init_idx = rng.choice(N, size=n_initial, replace=False).tolist()
    remaining_idx = [i for i in range(N) if i not in init_idx]
    train_idx = list(init_idx)

    best_val = np.max(y_pool[train_idx])
    best_name = pool_names[train_idx[np.argmax(y_pool[train_idx])]]
    found_at = 0
    n_eval_to_best = n_initial

    history = [(pool_names[i], float(y_pool[i])) for i in train_idx]

    for it in range(n_iterations):
        if not remaining_idx:
            break

        X_train = X_pool[train_idx]
        y_train = y_pool[train_idx]
        X_remain = X_pool[remaining_idx]

        n_feat = X_train.shape[1]
        kernel = (ConstantKernel(1.0, (1e-3, 1e3))
                  * Matern([1.0]*n_feat, [(1e-3, 1e3)]*n_feat, nu=kernel_nu)
                  + WhiteKernel(1.0, (1e-3, 1e3)))
        gp = GaussianProcessRegressor(kernel=kernel, n_restarts_optimizer=10,
                                       normalize_y=False)
        gp.fit(X_train, y_train)

        mu, sigma = gp.predict(X_remain, return_std=True)
        y_best_pred = np.max(gp.predict(X_train))

        # Compute acquisition scores
        if acquisition == "ei":
            scores = np.zeros_like(mu)
            mask = sigma > 0
            z = (mu[mask] - y_best_pred - epsilon) / sigma[mask]
            scores[mask] = ((mu[mask] - y_best_pred - epsilon) * norm.cdf(z)
                           + sigma[mask] * norm.pdf(z))
        elif acquisition == "ucb":
            scores = mu + epsilon * sigma
        elif acquisition == "pi":
            scores = np.zeros_like(mu)
            mask = sigma > 0
            z = (mu[mask] - y_best_pred - epsilon) / sigma[mask]
            scores[mask] = norm.cdf(z)
        else:
            raise ValueError(f"Unknown acquisition: {acquisition}")

        # Select top candidate(s)
        n_sel = min(batch_size, len(remaining_idx))
        top_local = np.argsort(scores)[::-1][:n_sel]

        for li in top_local:
            gi = remaining_idx[li]
            train_idx.append(gi)
            history.append((pool_names[gi], float(y_pool[gi])))
            if y_pool[gi] > best_val:
                best_val = float(y_pool[gi])
                best_name = pool_names[gi]
                found_at = len(train_idx) - n_initial
                n_eval_to_best = len(train_idx)

        # Remove selected from remaining (rebuild to avoid index shift)
        selected_global = {remaining_idx[li] for li in top_local}
        remaining_idx = [i for i in remaining_idx if i not in selected_global]

    return {
        "n_evaluated": len(train_idx),
        "n_evaluated_to_best": n_eval_to_best,
        "best_name": best_name,
        "best_value": float(best_val),
        "history": history,
        "found_at_iteration": found_at,
    }


def run_random_baseline(
    y_pool: np.ndarray,
    pool_names: list[str],
    target_value: float,
    n_trials: int = 100,
    random_state: int = 42,
) -> dict:
    """Random selection baseline: how many samples to find the target.

    Parameters
    ----------
    y_pool : np.ndarray
        All target values.
    pool_names : list[str]
        Names for pool entries.
    target_value : float
        The value to find (best in pool).
    n_trials : int
        Number of random trials to average over.
    random_state : int
        RNG seed.

    Returns
    -------
    dict
        {"mean_n": float, "std_n": float, "trials": list[int]}
    """
    rng = np.random.RandomState(random_state)
    target_idx = np.argmax(y_pool)
    N = len(y_pool)
    counts = []
    for _ in range(n_trials):
        perm = rng.permutation(N)
        found_at = int(np.where(perm == target_idx)[0][0]) + 1
        counts.append(found_at)
    return {
        "mean_n": float(np.mean(counts)),
        "std_n": float(np.std(counts)),
        "trials": counts,
    }


def compare_bo_vs_random(
    bo_counts: list[int],
    random_counts: list[int],
) -> dict:
    """Statistical comparison of BO vs random selection using t-test.

    Parameters
    ----------
    bo_counts : list[int]
        Number of evaluations to find target across BO trials.
    random_counts : list[int]
        Number of evaluations to find target across random trials.

    Returns
    -------
    dict
        {"t_statistic": float, "p_value": float, "bo_mean": float,
         "bo_std": float, "random_mean": float, "random_std": float}
    """
    from scipy.stats import ttest_ind
    t_stat, p_val = ttest_ind(bo_counts, random_counts)
    return {
        "t_statistic": float(t_stat),
        "p_value": float(p_val),
        "bo_mean": float(np.mean(bo_counts)),
        "bo_std": float(np.std(bo_counts)),
        "random_mean": float(np.mean(random_counts)),
        "random_std": float(np.std(random_counts)),
    }

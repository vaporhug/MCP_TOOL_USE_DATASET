"""Surrogate model training and prediction for Bayesian optimization.

Gaussian Process Regression (GPR) with Matern kernel, and Random Forest
as an alternative surrogate. Provides train/predict/evaluate interfaces.
"""
import numpy as np
from typing import Optional


def train_gpr(
    X_train: np.ndarray,
    y_train: np.ndarray,
    kernel_type: str = "matern",
    nu: float = 1.5,
    n_restarts: int = 40,
    normalize_y: bool = False,
) -> object:
    """Train a Gaussian Process Regression model.

    Parameters
    ----------
    X_train : np.ndarray
        (n_samples, n_features) training features.
    y_train : np.ndarray
        (n_samples,) training targets.
    kernel_type : str
        Kernel family: 'matern' or 'rbf'.
    nu : float
        Smoothness parameter for Matern kernel (0.5, 1.5, or 2.5).
    n_restarts : int
        Number of optimizer restarts for kernel hyperparameter tuning.
    normalize_y : bool
        Whether to normalize y internally.

    Returns
    -------
    GaussianProcessRegressor
        Fitted GPR model.
    """
    from sklearn.gaussian_process import GaussianProcessRegressor
    from sklearn.gaussian_process.kernels import (
        ConstantKernel, Matern, WhiteKernel, RBF
    )

    if kernel_type == "matern":
        n_feat = X_train.shape[1]
        length_scale = [1.0] * n_feat
        length_scale_bounds = [(1e-3, 1e3)] * n_feat
        kernel = (ConstantKernel(1.0, (1e-3, 1e3))
                  * Matern(length_scale, length_scale_bounds, nu=nu)
                  + WhiteKernel(1.0, (1e-3, 1e3)))
    elif kernel_type == "rbf":
        kernel = (ConstantKernel(1.0, (1e-3, 1e3))
                  * RBF(1.0, (1e-3, 1e3))
                  + WhiteKernel(1.0, (1e-3, 1e3)))
    else:
        raise ValueError(f"Unknown kernel_type: {kernel_type}")

    gp = GaussianProcessRegressor(
        kernel=kernel, n_restarts_optimizer=n_restarts,
        normalize_y=normalize_y
    )
    gp.fit(X_train, y_train)
    return gp


def predict_gpr(model, X: np.ndarray) -> tuple:
    """Predict mean and standard deviation from a fitted GPR model.

    Parameters
    ----------
    model : GaussianProcessRegressor
        Fitted GPR.
    X : np.ndarray
        (n_samples, n_features) query points.

    Returns
    -------
    tuple
        (y_pred, sigma) arrays of shape (n_samples,).
    """
    y_pred, sigma = model.predict(X, return_std=True)
    return y_pred, sigma


def evaluate_surrogate(y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    """Compute regression metrics: R², RMSE, MAE.

    Parameters
    ----------
    y_true : np.ndarray
        Ground truth values.
    y_pred : np.ndarray
        Model predictions.

    Returns
    -------
    dict
        {"R2": float, "RMSE": float, "MAE": float}
    """
    from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
    return {
        "R2": float(r2_score(y_true, y_pred)),
        "RMSE": float(np.sqrt(mean_squared_error(y_true, y_pred))),
        "MAE": float(mean_absolute_error(y_true, y_pred)),
    }


def train_random_forest(
    X_train: np.ndarray,
    y_train: np.ndarray,
    n_estimators: int = 100,
    random_state: int = 42,
) -> object:
    """Train a Random Forest regressor as an alternative surrogate.

    Parameters
    ----------
    X_train : np.ndarray
        Training features.
    y_train : np.ndarray
        Training targets.
    n_estimators : int
        Number of trees.
    random_state : int
        RNG seed.

    Returns
    -------
    RandomForestRegressor
        Fitted model.
    """
    from sklearn.ensemble import RandomForestRegressor
    rf = RandomForestRegressor(n_estimators=n_estimators,
                                random_state=random_state)
    rf.fit(X_train, y_train)
    return rf

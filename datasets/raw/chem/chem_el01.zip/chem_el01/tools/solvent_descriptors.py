"""Solvent descriptor generation and feature engineering for electrolyte screening.

Functions for computing molecular descriptors from SMILES, generating
binary-solvent mixture features via mol-fraction weighting, and
performing PCA-based dimensionality reduction on descriptor matrices.
"""
import numpy as np
from typing import Optional


def smiles_to_descriptors(smiles: str) -> dict:
    """Compute physicochemical descriptors for a single molecule from its SMILES.

    Returns a dict with keys: MW, TPSA, HeavyAtomCount, LogP.
    Uses RDKit internally.

    Parameters
    ----------
    smiles : str
        SMILES string of the molecule.

    Returns
    -------
    dict
        Molecular descriptors {MW, TPSA, HeavyAtomCount, LogP}.
    """
    from rdkit import Chem
    from rdkit.Chem import Descriptors, rdMolDescriptors
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        raise ValueError(f"Invalid SMILES: {smiles}")
    return {
        "MW": Descriptors.MolWt(mol),
        "TPSA": rdMolDescriptors.CalcTPSA(mol),
        "HeavyAtomCount": mol.GetNumHeavyAtoms(),
        "LogP": Descriptors.MolLogP(mol),
    }


def binary_solvent_features(
    features_solvent1: dict,
    features_solvent2: dict,
    vol_fraction1: float,
) -> dict:
    """Compute mol-fraction-weighted descriptors for a binary solvent mixture.

    For each descriptor key present in both input dicts, the mixture value
    is computed as:  f1 * val1 + (1 - f1) * val2.

    Parameters
    ----------
    features_solvent1 : dict
        Descriptors of solvent 1.
    features_solvent2 : dict
        Descriptors of solvent 2.
    vol_fraction1 : float
        Volume fraction of solvent 1 (between 0 and 1).

    Returns
    -------
    dict
        Weighted mixture descriptors.
    """
    f2 = 1.0 - vol_fraction1
    common_keys = set(features_solvent1) & set(features_solvent2)
    return {k: vol_fraction1 * features_solvent1[k] + f2 * features_solvent2[k]
            for k in common_keys}


def pca_transform(feature_matrix: np.ndarray, n_components: int = 5) -> tuple:
    """Standardize features then reduce dimensionality via PCA.

    Parameters
    ----------
    feature_matrix : np.ndarray
        (n_samples, n_features) raw descriptor matrix.
    n_components : int
        Number of principal components to retain.

    Returns
    -------
    tuple
        (transformed_matrix, explained_variance_ratio, scaler, pca_object)
    """
    from sklearn.preprocessing import StandardScaler
    from sklearn.decomposition import PCA

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(feature_matrix)
    pca = PCA(n_components=n_components)
    X_pca = pca.fit_transform(X_scaled)
    return X_pca, pca.explained_variance_ratio_, scaler, pca


def feature_importance_permutation(
    model,
    X: np.ndarray,
    y: np.ndarray,
    feature_names: list[str],
    n_repeats: int = 10,
    random_state: int = 42,
) -> dict:
    """Compute permutation feature importance for a fitted model.

    Parameters
    ----------
    model : fitted sklearn-compatible estimator
    X : np.ndarray
        Feature matrix.
    y : np.ndarray
        Target values.
    feature_names : list[str]
        Names corresponding to columns of X.
    n_repeats : int
        Number of permutation rounds.
    random_state : int
        RNG seed.

    Returns
    -------
    dict
        {feature_name: importance_mean} sorted descending.
    """
    from sklearn.inspection import permutation_importance
    result = permutation_importance(model, X, y, n_repeats=n_repeats,
                                    random_state=random_state)
    imp = {name: float(val) for name, val in
           zip(feature_names, result.importances_mean)}
    return dict(sorted(imp.items(), key=lambda x: x[1], reverse=True))

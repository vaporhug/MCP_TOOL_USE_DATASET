"""Acquisition functions for Bayesian optimization.

Expected Improvement (EI), Upper Confidence Bound (UCB), and
Probability of Improvement (PI). Each function scores candidate
points based on surrogate-model predictions to balance
exploration and exploitation.
"""
import numpy as np
from scipy.stats import norm


def expected_improvement(
    mu: np.ndarray,
    sigma: np.ndarray,
    y_best: float,
    epsilon: float = 1e-2,
) -> np.ndarray:
    """Compute Expected Improvement acquisition scores.

    EI(x) = (mu(x) - y_best - eps) * Phi(Z) + sigma(x) * phi(Z)
    where Z = (mu(x) - y_best - eps) / sigma(x).

    Parameters
    ----------
    mu : np.ndarray
        Predicted means from the surrogate model.
    sigma : np.ndarray
        Predicted standard deviations.
    y_best : float
        Best observed (or predicted) target value so far.
    epsilon : float
        Exploration-exploitation trade-off parameter.

    Returns
    -------
    np.ndarray
        EI scores for each candidate.
    """
    ei = np.zeros_like(mu)
    mask = sigma > 0
    z = (mu[mask] - y_best - epsilon) / sigma[mask]
    ei[mask] = (mu[mask] - y_best - epsilon) * norm.cdf(z) + sigma[mask] * norm.pdf(z)
    return ei


def upper_confidence_bound(
    mu: np.ndarray,
    sigma: np.ndarray,
    kappa: float = 2.0,
) -> np.ndarray:
    """Compute Upper Confidence Bound acquisition scores.

    UCB(x) = mu(x) + kappa * sigma(x).

    Parameters
    ----------
    mu : np.ndarray
        Predicted means.
    sigma : np.ndarray
        Predicted standard deviations.
    kappa : float
        Exploration weight. Higher = more exploration.

    Returns
    -------
    np.ndarray
        UCB scores for each candidate.
    """
    ucb = np.zeros_like(mu)
    mask = sigma > 0
    ucb[mask] = mu[mask] + kappa * sigma[mask]
    return ucb


def probability_of_improvement(
    mu: np.ndarray,
    sigma: np.ndarray,
    y_best: float,
    epsilon: float = 1e-2,
) -> np.ndarray:
    """Compute Probability of Improvement acquisition scores.

    PI(x) = Phi((mu(x) - y_best - eps) / sigma(x)).

    Parameters
    ----------
    mu : np.ndarray
        Predicted means.
    sigma : np.ndarray
        Predicted standard deviations.
    y_best : float
        Best observed value so far.
    epsilon : float
        Improvement threshold.

    Returns
    -------
    np.ndarray
        PI scores for each candidate.
    """
    pi = np.zeros_like(mu)
    mask = sigma > 0
    z = (mu[mask] - y_best - epsilon) / sigma[mask]
    pi[mask] = norm.cdf(z)
    return pi


def select_top_candidates(
    scores: np.ndarray,
    candidate_names: list[str],
    n_select: int = 40,
) -> list[tuple]:
    """Select top-scoring candidates from acquisition function output.

    Parameters
    ----------
    scores : np.ndarray
        Acquisition function scores for each candidate.
    candidate_names : list[str]
        Names/identifiers for each candidate.
    n_select : int
        Number of top candidates to return.

    Returns
    -------
    list[tuple]
        List of (name, score) tuples sorted descending by score.
    """
    sorted_idx = np.argsort(scores)[::-1][:n_select]
    return [(candidate_names[i], float(scores[i])) for i in sorted_idx]

"""Cost-aware candidate selection for electrolyte screening.

Utilities for incorporating experimental cost, time, and material
availability into the selection of next candidates during active
learning. Includes Pareto-front identification for multi-objective
optimization (e.g., maximizing solubility while minimizing cost).
"""
import numpy as np
from typing import Optional


def cost_weighted_acquisition(
    acq_scores: np.ndarray,
    costs: np.ndarray,
    cost_exponent: float = 1.0,
) -> np.ndarray:
    """Re-weight acquisition scores by per-candidate experimental cost.

    score_adj = acq_score / cost^cost_exponent

    Parameters
    ----------
    acq_scores : np.ndarray
        Raw acquisition function scores.
    costs : np.ndarray
        Per-candidate cost (e.g., experimental time in minutes).
    cost_exponent : float
        How aggressively to penalise cost (0 = ignore cost, 1 = linear).

    Returns
    -------
    np.ndarray
        Cost-adjusted acquisition scores.
    """
    adjusted = np.zeros_like(acq_scores)
    mask = costs > 0
    adjusted[mask] = acq_scores[mask] / np.power(costs[mask], cost_exponent)
    return adjusted


def pareto_front_2d(
    obj1: np.ndarray,
    obj2: np.ndarray,
    names: list[str],
    maximize_obj1: bool = True,
    maximize_obj2: bool = True,
) -> list[dict]:
    """Identify the Pareto-optimal front for two objectives.

    Parameters
    ----------
    obj1 : np.ndarray
        First objective values (e.g., solubility).
    obj2 : np.ndarray
        Second objective values (e.g., negative cost, or another property).
    names : list[str]
        Candidate names.
    maximize_obj1 : bool
        Whether to maximize objective 1.
    maximize_obj2 : bool
        Whether to maximize objective 2.

    Returns
    -------
    list[dict]
        Pareto-optimal points: [{name, obj1, obj2}, ...].
    """
    n = len(obj1)
    s1 = -1.0 if maximize_obj1 else 1.0
    s2 = -1.0 if maximize_obj2 else 1.0
    v1 = obj1 * s1
    v2 = obj2 * s2

    pareto = []
    for i in range(n):
        dominated = False
        for j in range(n):
            if i == j:
                continue
            if v1[j] <= v1[i] and v2[j] <= v2[i] and (v1[j] < v1[i] or v2[j] < v2[i]):
                dominated = True
                break
        if not dominated:
            pareto.append({"name": names[i],
                          "obj1": float(obj1[i]),
                          "obj2": float(obj2[i])})
    return sorted(pareto, key=lambda x: x["obj1"], reverse=maximize_obj1)


def batch_diversity_selection(
    X_candidates: np.ndarray,
    acq_scores: np.ndarray,
    batch_size: int = 40,
    diversity_weight: float = 0.5,
) -> list[int]:
    """Select a diverse batch from top acquisition candidates.

    Greedy selection: iteratively pick the candidate with the highest
    combined acquisition + distance-to-already-selected score.

    Parameters
    ----------
    X_candidates : np.ndarray
        (n_candidates, n_features) feature matrix.
    acq_scores : np.ndarray
        Acquisition scores for each candidate.
    batch_size : int
        Number of candidates to select.
    diversity_weight : float
        Weight of the diversity term relative to acquisition score.

    Returns
    -------
    list[int]
        Indices of selected candidates.
    """
    n = len(acq_scores)
    if batch_size >= n:
        return list(range(n))

    # Normalize scores to [0, 1]
    s_min, s_max = acq_scores.min(), acq_scores.max()
    if s_max > s_min:
        norm_scores = (acq_scores - s_min) / (s_max - s_min)
    else:
        norm_scores = np.ones(n)

    selected = [int(np.argmax(acq_scores))]

    for _ in range(batch_size - 1):
        remaining = [i for i in range(n) if i not in selected]
        if not remaining:
            break

        best_combined = -np.inf
        best_idx = remaining[0]
        X_sel = X_candidates[selected]

        for idx in remaining:
            min_dist = np.min(np.linalg.norm(X_sel - X_candidates[idx], axis=1))
            combined = norm_scores[idx] + diversity_weight * min_dist
            if combined > best_combined:
                best_combined = combined
                best_idx = idx

        selected.append(best_idx)

    return selected

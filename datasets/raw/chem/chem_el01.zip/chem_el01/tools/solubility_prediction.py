"""Solubility prediction and analysis utilities.

Functions for computing solubility from NMR data, converting between
molar concentration and log-solubility, filtering solvents by
threshold, and identifying top formulations.
"""
import numpy as np
from typing import Optional


def compute_molar_solubility_nmr(
    I_BTZ: float,
    I_INSD: float,
    N_BTZ: int = 4,
    N_INSD: int = 4,
    C_INSD_NMR: float = 8.0,
    V_NMR_sample: float = 630.0,
    V_sat_sol: float = 30.0,
) -> float:
    """Compute BTZ molar concentration from quantitative NMR data.

    Uses Eq. (1) from the paper:
      C_BTZ = (V_NMR / V_sat) * (I_BTZ / I_INSD) * (N_INSD / N_BTZ) * C_INSD

    Parameters
    ----------
    I_BTZ : float
        Integrated area of BTZ peaks (peaks b + c).
    I_INSD : float
        Integrated area of internal standard peaks (peak a).
    N_BTZ : int
        Number of BTZ protons contributing to I_BTZ.
    N_INSD : int
        Number of INSD protons contributing to I_INSD.
    C_INSD_NMR : float
        Molar concentration of INSD in the NMR solution (mg/mL).
    V_NMR_sample : float
        Total NMR sample volume (uL).
    V_sat_sol : float
        Volume of saturated solution transferred (uL).

    Returns
    -------
    float
        BTZ molar concentration (M).
    """
    return (V_NMR_sample / V_sat_sol) * (I_BTZ / I_INSD) * (N_INSD / N_BTZ) * C_INSD_NMR


def molarity_to_logS(molarity: np.ndarray) -> np.ndarray:
    """Convert molar concentrations to log10-scale solubility.

    Parameters
    ----------
    molarity : np.ndarray
        Molar concentrations (M).

    Returns
    -------
    np.ndarray
        log10(molarity) values.
    """
    return np.log10(np.asarray(molarity, dtype=float))


def logS_to_molarity(logS: np.ndarray) -> np.ndarray:
    """Convert log10-solubility back to molar concentration.

    Parameters
    ----------
    logS : np.ndarray
        log10(molarity) values.

    Returns
    -------
    np.ndarray
        Molar concentrations (M).
    """
    return np.power(10.0, np.asarray(logS, dtype=float))


def filter_above_threshold(
    names: list[str],
    values: np.ndarray,
    threshold: float = 6.20,
) -> list[tuple]:
    """Return candidates whose solubility exceeds a threshold.

    Parameters
    ----------
    names : list[str]
        Candidate identifiers.
    values : np.ndarray
        Measured solubility values (M).
    threshold : float
        Minimum solubility threshold.

    Returns
    -------
    list[tuple]
        Sorted list of (name, value) above threshold, descending.
    """
    pairs = [(n, float(v)) for n, v in zip(names, values) if v >= threshold]
    return sorted(pairs, key=lambda x: x[1], reverse=True)


def rank_top_formulations(
    names: list[str],
    values: np.ndarray,
    top_n: int = 5,
) -> list[dict]:
    """Rank and return the top-N solvent formulations by solubility.

    Parameters
    ----------
    names : list[str]
        Candidate solvent names.
    values : np.ndarray
        Measured solubility values.
    top_n : int
        Number of top candidates to return.

    Returns
    -------
    list[dict]
        [{name, solubility, rank}, ...] sorted descending.
    """
    idx = np.argsort(values)[::-1][:top_n]
    return [{"name": names[i], "solubility": float(values[i]), "rank": k + 1}
            for k, i in enumerate(idx)]

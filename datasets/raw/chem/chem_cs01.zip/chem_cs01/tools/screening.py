"""High-level catalyst-screening helpers.

These compose lower-level primitives: filter the binding-energy table
by facet, build descriptor lists, predict activity for each metal,
and produce ranked tables.
"""
from __future__ import annotations

import math
from typing import Sequence


def filter_by_facet(rows: list[dict], facet: str) -> list[dict]:
    """Return only rows where row['facet'] equals the requested facet string."""
    out: list[dict] = []
    for r in rows:
        if r.get("facet") == facet:
            out.append(r)
    return out


def build_descriptor_table(rows: list[dict], descriptor_col: str) -> dict[str, float]:
    """Map metal -> descriptor value (float). Missing values are skipped."""
    out: dict[str, float] = {}
    for r in rows:
        m = r.get("metal")
        v = r.get(descriptor_col)
        if m is None or v is None:
            continue
        try:
            out[str(m)] = float(v)
        except (TypeError, ValueError):
            continue
    return out


def metal_log_rate(descriptor_value: float, slope: float, intercept: float,
                   U_vs_RHE: float, T_K: float = 300.0, n_pe: int = 1,
                   beta: float = 0.5, coverage_saturation_eV: float = -0.5) -> float:
    """log10(TOF) for a single metal at descriptor value with TS scaling.

    Uses Butler-Volmer extrapolation (beta) and a site-blocking penalty
    on the strong-binding side, mirroring descriptor_volcano in
    microkinetics.py.
    """
    KB = 8.617333262e-5
    d = float(descriptor_value)
    G_TS = float(slope) * d + float(intercept)
    Ea = (G_TS - d) + float(n_pe) * float(beta) * float(U_vs_RHE)
    if Ea < 0.0:
        Ea = 0.0
    K = math.exp(-(d - float(U_vs_RHE)) / (KB * float(T_K)))
    theta = K / (1.0 + K)
    if theta <= 0.0:
        return -50.0
    site_blocking = max(0.0, float(coverage_saturation_eV) - d)
    Ea_eff = Ea + site_blocking
    rate = theta * 1.0e13 * math.exp(-Ea_eff / (KB * float(T_K)))
    return math.log10(rate) if rate > 0 else -50.0


def screen_metals(descriptor_table: dict[str, float], slope: float, intercept: float,
                  U_vs_RHE: float, T_K: float = 300.0) -> list[dict]:
    """Score every metal in the descriptor table; return list of dicts
    with metal/descriptor/log_rate sorted descending by log_rate.
    """
    scored: list[dict] = []
    for metal, d in descriptor_table.items():
        lr = metal_log_rate(d, slope, intercept, U_vs_RHE, T_K=T_K)
        scored.append({"metal": metal, "descriptor": float(d), "log_rate": lr})
    scored.sort(key=lambda r: r["log_rate"], reverse=True)
    return scored


def descriptor_distance_to_apex(descriptor_table: dict[str, float], apex_value: float
                                ) -> list[dict]:
    """Distance |G_descriptor - apex| for each metal, sorted ascending."""
    out: list[dict] = []
    for m, v in descriptor_table.items():
        out.append({"metal": m, "descriptor": float(v),
                    "distance_to_apex_eV": abs(float(v) - float(apex_value))})
    out.sort(key=lambda r: r["distance_to_apex_eV"])
    return out


def select_top_k(scored: list[dict], k: int) -> list[dict]:
    """Return the first k entries of an already sorted list (truncate-safe)."""
    if k < 0:
        k = 0
    return list(scored[:k])


def join_descriptors(table_a: dict[str, float], table_b: dict[str, float]
                     ) -> list[tuple[str, float, float]]:
    """Return (metal, value_a, value_b) for keys present in BOTH tables."""
    out: list[tuple[str, float, float]] = []
    for m in table_a:
        if m in table_b:
            out.append((m, float(table_a[m]), float(table_b[m])))
    return out

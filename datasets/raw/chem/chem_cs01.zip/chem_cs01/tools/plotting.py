"""Matplotlib helpers for free-energy diagrams, scaling plots, and volcanos.

Every plotting function returns {"path": <absolute path to PNG>} so that
artifacts can be tracked. The functions do not perform fitting or kinetic
modelling; they only draw what they are given.
"""
from __future__ import annotations

import os
from typing import Sequence

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


def _ensure_dir(path: str) -> str:
    abs_path = os.path.abspath(path)
    os.makedirs(os.path.dirname(abs_path), exist_ok=True)
    return abs_path


def plot_free_energy_diagram(step_labels: Sequence[str], cumulative_G: Sequence[float],
                             title: str, out_path: str,
                             second_curve: dict | None = None) -> dict:
    """Draw a stair-style free-energy diagram. Each level is held flat and a
    vertical drop connects to the next. Optionally overlays a second curve
    given as {"label": str, "cumulative_G": list, "color": str}.
    """
    abs_path = _ensure_dir(out_path)
    fig, ax = plt.subplots(figsize=(8, 4.5))
    xs = list(range(len(cumulative_G)))
    ys = [float(v) for v in cumulative_G]
    for i in range(len(ys) - 1):
        ax.plot([xs[i], xs[i] + 1], [ys[i], ys[i]], color="C0", lw=2)
        ax.plot([xs[i] + 1, xs[i] + 1], [ys[i], ys[i + 1]], color="C0", lw=2, ls="--")
    ax.plot([xs[-1], xs[-1] + 1], [ys[-1], ys[-1]], color="C0", lw=2, label="0 V vs RHE")
    if second_curve is not None:
        ys2 = [float(v) for v in second_curve["cumulative_G"]]
        col = second_curve.get("color", "C3")
        lab = second_curve.get("label", "second")
        for i in range(len(ys2) - 1):
            ax.plot([xs[i], xs[i] + 1], [ys2[i], ys2[i]], color=col, lw=2)
            ax.plot([xs[i] + 1, xs[i] + 1], [ys2[i], ys2[i + 1]], color=col, lw=2, ls="--")
        ax.plot([xs[-1], xs[-1] + 1], [ys2[-1], ys2[-1]], color=col, lw=2, label=lab)
    ax.set_xticks([x + 0.5 for x in xs])
    ax.set_xticklabels(step_labels, rotation=30, ha="right", fontsize=8)
    ax.set_ylabel("G (eV)")
    ax.set_title(title)
    ax.axhline(0, color="grey", lw=0.5)
    ax.legend(loc="best", fontsize=8)
    fig.tight_layout()
    fig.savefig(abs_path, dpi=140)
    plt.close(fig)
    return {"path": abs_path}


def plot_scaling_relation(x_vals: Sequence[float], y_vals: Sequence[float],
                          metal_labels: Sequence[str], slope: float, intercept: float,
                          x_label: str, y_label: str, title: str,
                          out_path: str) -> dict:
    """Scatter of (x, y) labelled by metal with a fitted line overlay."""
    abs_path = _ensure_dir(out_path)
    fig, ax = plt.subplots(figsize=(6.5, 5.0))
    xs = [float(v) for v in x_vals]
    ys = [float(v) for v in y_vals]
    ax.scatter(xs, ys, c="C0", s=70, edgecolors="k", zorder=3)
    for xi, yi, lab in zip(xs, ys, metal_labels):
        ax.annotate(lab, (xi, yi), xytext=(4, 4), textcoords="offset points", fontsize=8)
    if xs:
        x_lo = min(xs) - 0.2
        x_hi = max(xs) + 0.2
        line_x = [x_lo, x_hi]
        line_y = [slope * x_lo + intercept, slope * x_hi + intercept]
        ax.plot(line_x, line_y, "k--",
                label=f"y = {slope:.2f}x + {intercept:.2f}")
    ax.set_xlabel(x_label)
    ax.set_ylabel(y_label)
    ax.set_title(title)
    ax.legend(loc="best", fontsize=9)
    fig.tight_layout()
    fig.savefig(abs_path, dpi=140)
    plt.close(fig)
    return {"path": abs_path}


def plot_volcano(descriptor_grid: Sequence[float], log_rates: Sequence[float],
                 metal_descriptors: Sequence[float], metal_log_rates: Sequence[float],
                 metal_labels: Sequence[str], descriptor_label: str,
                 title: str, out_path: str,
                 apex_x: float | None = None) -> dict:
    """Plot the predicted volcano curve with metal points overlaid."""
    abs_path = _ensure_dir(out_path)
    fig, ax = plt.subplots(figsize=(7.0, 5.0))
    ax.plot(list(descriptor_grid), list(log_rates), color="C3", lw=2, label="model")
    ax.scatter(list(metal_descriptors), list(metal_log_rates),
               c="C0", s=80, edgecolors="k", zorder=3, label="metals")
    for x, y, lab in zip(metal_descriptors, metal_log_rates, metal_labels):
        ax.annotate(lab, (x, y), xytext=(4, 4), textcoords="offset points", fontsize=8)
    if apex_x is not None:
        ax.axvline(float(apex_x), color="grey", ls=":", label=f"apex = {apex_x:.2f} eV")
    ax.set_xlabel(descriptor_label)
    ax.set_ylabel("log10(TOF / s$^{-1}$)")
    ax.set_title(title)
    ax.legend(loc="best", fontsize=9)
    fig.tight_layout()
    fig.savefig(abs_path, dpi=140)
    plt.close(fig)
    return {"path": abs_path}


def plot_selectivity_map(descriptor_grid: Sequence[float], selectivity_log: Sequence[float],
                         metal_descriptors: Sequence[float], metal_selectivity: Sequence[float],
                         metal_labels: Sequence[str], descriptor_label: str,
                         title: str, out_path: str) -> dict:
    """Plot CO-reduction selectivity vs descriptor with metal annotations."""
    abs_path = _ensure_dir(out_path)
    fig, ax = plt.subplots(figsize=(7.0, 5.0))
    ax.plot(list(descriptor_grid), list(selectivity_log), color="C2", lw=2, label="model")
    ax.scatter(list(metal_descriptors), list(metal_selectivity),
               c="C0", s=80, edgecolors="k", zorder=3, label="metals")
    for x, y, lab in zip(metal_descriptors, metal_selectivity, metal_labels):
        ax.annotate(lab, (x, y), xytext=(4, 4), textcoords="offset points", fontsize=8)
    ax.set_xlabel(descriptor_label)
    ax.set_ylabel("log10( CO-reduction selectivity )")
    ax.set_title(title)
    ax.legend(loc="best", fontsize=9)
    fig.tight_layout()
    fig.savefig(abs_path, dpi=140)
    plt.close(fig)
    return {"path": abs_path}

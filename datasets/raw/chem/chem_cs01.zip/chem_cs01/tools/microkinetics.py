"""Mean-field microkinetic primitives for an electrochemical descriptor model.

These functions take *already corrected* free energies (G in eV) and a
descriptor (e.g. G_CO*) and return rates / coverages / activities. They
do not know what the descriptor means or which scaling relation to use;
the caller wires that.
"""
from __future__ import annotations

import math
from typing import Sequence


KB_EV_PER_K = 8.617333262e-5
PREFACTOR_S_INV = 1.0e13


def site_coverage_langmuir(deltaG_ads_eV: float, T_K: float = 300.0) -> float:
    """Langmuir coverage theta = K / (1+K) with K = exp(-G_ads / kT).

    deltaG_ads is the free energy of adsorption from gas phase; negative
    values bind strongly and theta -> 1.
    """
    K = math.exp(-float(deltaG_ads_eV) / (KB_EV_PER_K * float(T_K)))
    return K / (1.0 + K)


def activation_energy_from_ts(G_TS_eV: float, G_IS_eV: float) -> float:
    """Apparent activation barrier Ea = G_TS - G_IS (eV)."""
    return float(G_TS_eV) - float(G_IS_eV)


def turnover_frequency(barrier_eV: float, coverage: float, T_K: float = 300.0,
                       prefactor_s_inv: float = PREFACTOR_S_INV) -> float:
    """TOF = theta * nu * exp(-Ea / kT) per active site, s^-1."""
    if coverage <= 0.0:
        return 0.0
    return float(coverage) * float(prefactor_s_inv) * math.exp(
        -float(barrier_eV) / (KB_EV_PER_K * float(T_K))
    )


def descriptor_volcano(descriptor_values: Sequence[float], scaling_slope: float,
                       scaling_intercept: float, U_vs_RHE: float = 0.0,
                       T_K: float = 300.0, n_pe: int = 1,
                       beta: float = 0.5,
                       coverage_saturation_eV: float = -0.5) -> list[float]:
    """Compute log10(TOF) along a 1D descriptor axis using a TS scaling
    relation G_TS = slope * descriptor + intercept.

    The barrier extrapolates with a Butler-Volmer charge-transfer
    coefficient beta (default 0.5):
        Ea(U) = max(0, (G_TS - descriptor) + n_pe * beta * U)

    Strong-binding metals also pay a coverage-saturation penalty: if the
    descriptor is more negative than coverage_saturation_eV, the rate
    decreases linearly with the over-binding because adsorbed CO* blocks
    further reaction (site-blocking). This produces a true volcano shape
    rather than a monotonic curve.
    """
    out: list[float] = []
    for d in descriptor_values:
        d = float(d)
        G_TS = float(scaling_slope) * d + float(scaling_intercept)
        Ea = (G_TS - d) + float(n_pe) * float(beta) * float(U_vs_RHE)
        if Ea < 0.0:
            Ea = 0.0
        # weak-binding side: coverage drops -> rate drops
        theta = site_coverage_langmuir(d - float(U_vs_RHE), T_K=T_K)
        if theta <= 0.0:
            out.append(-50.0)
            continue
        # strong-binding side: site-blocking penalty proportional to over-binding
        site_blocking_eV = max(0.0, float(coverage_saturation_eV) - d)
        Ea_eff = Ea + site_blocking_eV
        rate = theta * PREFACTOR_S_INV * math.exp(-Ea_eff / (KB_EV_PER_K * float(T_K)))
        out.append(math.log10(rate) if rate > 0 else -50.0)
    return out


def selectivity_log_ratio(log_rate_target: float, log_rate_competitor: float) -> float:
    """log10(rate_target / (rate_target + rate_competitor)).

    Inputs are log10 rates; the ratio is computed in linear space.
    """
    rA = 10.0 ** float(log_rate_target)
    rB = 10.0 ** float(log_rate_competitor)
    s = rA + rB
    if s <= 0:
        return -50.0
    return math.log10(rA / s)


def find_volcano_apex(descriptor_values: Sequence[float],
                      log_rates: Sequence[float]) -> dict[str, float]:
    """Locate the descriptor value and rate at the volcano maximum."""
    best_i = -1
    best = -float("inf")
    for i, r in enumerate(log_rates):
        if r is None:
            continue
        if r > best:
            best = r
            best_i = i
    if best_i < 0:
        return {"x_apex": float("nan"), "log_rate_apex": float("nan"), "index": -1.0}
    return {
        "x_apex": float(descriptor_values[best_i]),
        "log_rate_apex": float(log_rates[best_i]),
        "index": float(best_i),
    }


def rank_metals(metals: Sequence[str], scores: Sequence[float],
                descending: bool = True) -> list[tuple[str, float]]:
    """Pair metals with scores and sort. NaN scores are pushed to the end."""
    pairs = []
    for m, s in zip(metals, scores):
        if s is None or (isinstance(s, float) and math.isnan(s)):
            pairs.append((m, -float("inf") if descending else float("inf")))
        else:
            pairs.append((m, float(s)))
    pairs.sort(key=lambda p: p[1], reverse=descending)
    return pairs

"""Free-energy primitives: ZPE/entropy/solvation corrections and the
computational-hydrogen-electrode (CHE) potential shift.

Each function takes scalar values and returns scalar values; they are
deliberately small primitives that the agent must compose.
"""
from __future__ import annotations

import math
from typing import Iterable


def apply_thermo_correction(E_DFT: float, ZPE: float, minus_TS: float, solvation: float = 0.0) -> float:
    """Return G = E_DFT + ZPE + (-T*S) + solvation (all in eV).

    The convention follows G = E + ZPE - T*S, where the caller supplies
    minus_TS already negated (so that adding gives the right result).
    """
    return float(E_DFT) + float(ZPE) + float(minus_TS) + float(solvation)


def free_energy_step(G_final: float, G_initial: float) -> float:
    """Reaction free energy of a single elementary step, eV."""
    return float(G_final) - float(G_initial)


def che_potential_shift(n_pe: int, U_vs_RHE: float) -> float:
    """Computational-hydrogen-electrode shift for an n-electron-proton
    transfer step. Returns -n * e * U in eV (with e=1 in eV/V units).
    """
    return -float(n_pe) * float(U_vs_RHE)


def apply_potential_to_step(deltaG_0V: float, n_pe: int, U_vs_RHE: float) -> float:
    """Shift a step's free energy by the CHE term.

    deltaG(U) = deltaG(0V) + n*(-e*U).
    """
    return float(deltaG_0V) + che_potential_shift(n_pe, U_vs_RHE)


def cumulative_free_energy(step_deltas: Iterable[float]) -> list[float]:
    """Cumulative sum of step free energies, starting at 0.

    Output length is len(step_deltas) + 1.
    """
    cum = [0.0]
    s = 0.0
    for d in step_deltas:
        s += float(d)
        cum.append(s)
    return cum


def limiting_potential(step_deltas: Iterable[float]) -> float:
    """Return U_L = -max(deltaG_step) / e for a sequence of single-PCET
    steps at U=0. By convention U_L is the most negative potential at
    which all steps become exergonic for a reduction reaction.
    """
    deltas = [float(d) for d in step_deltas]
    if not deltas:
        return 0.0
    return -max(deltas)


def boltzmann_rate(barrier_eV: float, T_K: float = 300.0, prefactor_s_inv: float = 1.0e13) -> float:
    """Arrhenius/Eyring TOF estimate: nu * exp(-Ea / kT). Returns s^-1."""
    kB = 8.617333262e-5  # eV/K
    return float(prefactor_s_inv) * math.exp(-float(barrier_eV) / (kB * float(T_K)))


def log10_rate(rate_s_inv: float) -> float:
    """Safe log10 of a rate (returns -50 for non-positive inputs)."""
    if rate_s_inv <= 0.0:
        return -50.0
    return math.log10(float(rate_s_inv))

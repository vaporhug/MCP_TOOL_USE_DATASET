"""Low-level CSV/JSON loaders and basic table operations.

These functions only do data I/O and trivial selection. No domain-specific
logic, no scaling-relation fitting, no volcano construction.
"""
from __future__ import annotations

import csv
import json
import os
from typing import Any


def load_csv_table(path: str) -> list[dict[str, str]]:
    """Read a CSV file into a list of row dictionaries with string values.

    Numeric parsing is left to downstream consumers so that this function
    is purely structural.
    """
    rows: list[dict[str, str]] = []
    with open(path, "r", newline="") as fh:
        reader = csv.DictReader(fh)
        for r in reader:
            rows.append({k: (v if v is not None else "") for k, v in r.items()})
    return rows


def load_json(path: str) -> Any:
    """Read a JSON document and return the parsed Python object."""
    with open(path, "r") as fh:
        return json.load(fh)


def coerce_float_columns(rows: list[dict[str, str]], columns: list[str]) -> list[dict[str, Any]]:
    """Cast the listed columns from string to float in-place on a copy.

    Empty strings become None so downstream code can detect missing values.
    """
    out: list[dict[str, Any]] = []
    for r in rows:
        nr: dict[str, Any] = dict(r)
        for c in columns:
            v = nr.get(c, "")
            if isinstance(v, str) and v.strip() != "":
                try:
                    nr[c] = float(v)
                except ValueError:
                    nr[c] = None
            elif isinstance(v, str):
                nr[c] = None
        out.append(nr)
    return out


def select_rows(rows: list[dict[str, Any]], key: str, value: Any) -> list[dict[str, Any]]:
    """Filter rows where row[key] == value (string comparison if value is str)."""
    out: list[dict[str, Any]] = []
    for r in rows:
        v = r.get(key)
        if v == value:
            out.append(r)
    return out


def project_columns(rows: list[dict[str, Any]], columns: list[str]) -> list[list[Any]]:
    """Return a column-major list of value lists in the requested order."""
    cols: list[list[Any]] = [[] for _ in columns]
    for r in rows:
        for i, c in enumerate(columns):
            cols[i].append(r.get(c))
    return cols


def write_json(obj: Any, path: str) -> str:
    """Persist obj as JSON. Returns the absolute path written."""
    abs_path = os.path.abspath(path)
    os.makedirs(os.path.dirname(abs_path), exist_ok=True)
    with open(abs_path, "w") as fh:
        json.dump(obj, fh, indent=2, default=str)
    return abs_path

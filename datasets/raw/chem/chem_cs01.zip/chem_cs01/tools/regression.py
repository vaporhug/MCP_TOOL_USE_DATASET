"""Pure-Python linear-regression and 1D interpolation primitives.

No external numerical libraries are used so the agent's notebook can
remain dependency-light. The fit returns slope, intercept, R^2, and MAE.
"""
from __future__ import annotations

import math
from typing import Sequence


def linear_fit(x: Sequence[float], y: Sequence[float]) -> dict[str, float]:
    """Ordinary least-squares fit y = m x + b.

    Returns {"slope": m, "intercept": b, "R2": ..., "MAE": ..., "n": ...}.
    Raises ValueError if fewer than 2 finite pairs are supplied.
    """
    pairs = [(float(xi), float(yi)) for xi, yi in zip(x, y)
             if xi is not None and yi is not None and math.isfinite(xi) and math.isfinite(yi)]
    n = len(pairs)
    if n < 2:
        raise ValueError("linear_fit requires at least 2 finite (x, y) pairs")
    sx = sum(p[0] for p in pairs)
    sy = sum(p[1] for p in pairs)
    sxx = sum(p[0] * p[0] for p in pairs)
    sxy = sum(p[0] * p[1] for p in pairs)
    mx = sx / n
    my = sy / n
    denom = sxx - n * mx * mx
    if denom == 0.0:
        raise ValueError("linear_fit: x has zero variance")
    m = (sxy - n * mx * my) / denom
    b = my - m * mx
    ss_tot = sum((p[1] - my) ** 2 for p in pairs)
    ss_res = sum((p[1] - (m * p[0] + b)) ** 2 for p in pairs)
    r2 = 1.0 - (ss_res / ss_tot) if ss_tot > 0 else float("nan")
    mae = sum(abs(p[1] - (m * p[0] + b)) for p in pairs) / n
    return {"slope": m, "intercept": b, "R2": r2, "MAE": mae, "n": float(n)}


def predict_line(slope: float, intercept: float, x_values: Sequence[float]) -> list[float]:
    """y_hat_i = slope * x_i + intercept for each x_i."""
    return [float(slope) * float(x) + float(intercept) for x in x_values]


def linspace(low: float, high: float, n: int) -> list[float]:
    """Evenly spaced n points from low to high inclusive."""
    if n <= 1:
        return [float(low)]
    step = (float(high) - float(low)) / (n - 1)
    return [float(low) + i * step for i in range(n)]


def argmax(values: Sequence[float]) -> int:
    """Index of the maximum element. Returns -1 for an empty sequence."""
    best_i = -1
    best_v = -float("inf")
    for i, v in enumerate(values):
        if v is None:
            continue
        if v > best_v:
            best_v = v
            best_i = i
    return best_i


def argmin(values: Sequence[float]) -> int:
    """Index of the minimum element. Returns -1 for empty sequences."""
    best_i = -1
    best_v = float("inf")
    for i, v in enumerate(values):
        if v is None:
            continue
        if v < best_v:
            best_v = v
            best_i = i
    return best_i

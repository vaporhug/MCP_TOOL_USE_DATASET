"""Tools for computing molecular fingerprints and descriptors from SMILES."""

import numpy as np
from typing import List, Optional
from rdkit import Chem, DataStructs
from rdkit.Chem import AllChem, MACCSkeys, Descriptors
from rdkit.ML.Descriptors import MoleculeDescriptors


def smiles_to_mols(smiles_list: List[str]) -> List[Optional[Chem.Mol]]:
    """Convert a list of SMILES strings to RDKit Mol objects.

    Parameters
    ----------
    smiles_list : list of str
        SMILES strings.

    Returns
    -------
    list of Mol or None
        RDKit Mol objects; None for invalid SMILES.
    """
    return [Chem.MolFromSmiles(s) for s in smiles_list]


def compute_ecfp(mols: List[Chem.Mol], radius: int = 2, nbits: int = 1024) -> np.ndarray:
    """Compute Extended-Connectivity Fingerprints (ECFP / Morgan fingerprints).

    Parameters
    ----------
    mols : list of Mol
        RDKit molecule objects.
    radius : int
        Radius for fragment enumeration (2 = ECFP4).
    nbits : int
        Number of bits for fingerprint folding.

    Returns
    -------
    np.ndarray
        (M, nbits) binary fingerprint array.
    """
    array = np.empty((len(mols), nbits), dtype=np.float32)
    fps = [AllChem.GetMorganFingerprintAsBitVect(m, radius, nbits) for m in mols]
    for i in range(len(array)):
        DataStructs.ConvertToNumpyArray(fps[i], array[i])
    return array


def compute_maccs(mols: List[Chem.Mol]) -> np.ndarray:
    """Compute MACCS structural key fingerprints.

    Parameters
    ----------
    mols : list of Mol
        RDKit molecule objects.

    Returns
    -------
    np.ndarray
        (M, 167) binary fingerprint array.
    """
    array = np.empty((len(mols), 167), dtype=np.float32)
    fps = [MACCSkeys.GenMACCSKeys(m) for m in mols]
    for i in range(len(array)):
        DataStructs.ConvertToNumpyArray(fps[i], array[i])
    return array


def compute_2d_descriptors(mols: List[Chem.Mol], n_desc: int = 100) -> np.ndarray:
    """Compute 2D physicochemical descriptors using RDKit.

    Parameters
    ----------
    mols : list of Mol
        RDKit molecule objects.
    n_desc : int
        Number of descriptors to calculate (from RDKit's descriptor list).

    Returns
    -------
    np.ndarray
        (M, n_desc) descriptor array with NaN/Inf cleaned.
    """
    names = [x[0] for x in Descriptors._descList][:n_desc]
    calc = MoleculeDescriptors.MolecularDescriptorCalculator(names)

    descs = np.zeros((len(mols), n_desc))
    for i, mol in enumerate(mols):
        temp = calc.CalcDescriptors(mol)
        if temp is not None:
            descs[i, :] = temp

    descs = np.nan_to_num(descs, posinf=1e10, neginf=-1e10)
    return descs


def filter_valid_molecules(smiles_list: List[str]) -> tuple:
    """Filter SMILES list to keep only valid molecules.

    Parameters
    ----------
    smiles_list : list of str
        Input SMILES strings.

    Returns
    -------
    valid_mols : list of Mol
        Valid RDKit Mol objects.
    valid_indices : list of int
        Original indices of valid molecules.
    n_invalid : int
        Count of invalid SMILES.
    """
    valid_mols = []
    valid_indices = []
    n_invalid = 0
    for i, smi in enumerate(smiles_list):
        mol = Chem.MolFromSmiles(smi)
        if mol is not None:
            valid_mols.append(mol)
            valid_indices.append(i)
        else:
            n_invalid += 1
    return valid_mols, valid_indices, n_invalid

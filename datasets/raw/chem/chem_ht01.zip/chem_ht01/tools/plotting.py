"""Tools for generating evaluation plots for HTS hit prioritization."""

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from typing import Dict, List, Optional


def plot_method_comparison_bar(
    methods: Dict[str, Dict[str, float]],
    metric_name: str,
    output_path: str,
    title: Optional[str] = None,
    ylabel: Optional[str] = None,
) -> str:
    """Create a grouped bar chart comparing methods on FP and TP detection.

    Parameters
    ----------
    methods : dict
        Keys are method names, values are dicts with 'fp' and 'tp' scores.
    metric_name : str
        Name of the metric for labeling.
    output_path : str
        Path to save the figure.
    title : str, optional
        Figure title.
    ylabel : str, optional
        Y-axis label.

    Returns
    -------
    str
        Path to the saved figure.
    """
    fig, ax = plt.subplots(figsize=(10, 5))
    names = list(methods.keys())
    x = np.arange(len(names))
    width = 0.35

    fp_vals = [methods[n]["fp"] for n in names]
    tp_vals = [methods[n]["tp"] for n in names]

    bars1 = ax.bar(x - width / 2, fp_vals, width, label="FP Detection", color="#e74c3c", alpha=0.8)
    bars2 = ax.bar(x + width / 2, tp_vals, width, label="TP Detection", color="#2ecc71", alpha=0.8)

    ax.set_xlabel("Method")
    ax.set_ylabel(ylabel or metric_name)
    ax.set_title(title or f"{metric_name} Comparison")
    ax.set_xticks(x)
    ax.set_xticklabels(names, rotation=30, ha="right")
    ax.legend()
    ax.grid(axis="y", alpha=0.3)
    plt.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return output_path


def plot_importance_distribution(
    importance_scores: np.ndarray,
    y_primary: np.ndarray,
    y_fp: np.ndarray,
    y_tp: np.ndarray,
    idx_confirmed: np.ndarray,
    output_path: str,
) -> str:
    """Plot distribution of MVS-A importance scores for confirmed FP vs TP.

    Parameters
    ----------
    importance_scores : np.ndarray
        (M,) MVS-A importance scores for all compounds.
    y_primary : np.ndarray
        (M,) primary labels.
    y_fp : np.ndarray
        (V,) false-positive labels for confirmed compounds.
    y_tp : np.ndarray
        (V,) true-positive labels for confirmed compounds.
    idx_confirmed : np.ndarray
        (V,) indices of confirmed compounds in original data.
    output_path : str
        Path to save the figure.

    Returns
    -------
    str
        Path to the saved figure.
    """
    scores_confirmed = importance_scores[idx_confirmed]
    fp_scores = scores_confirmed[y_fp == 1]
    tp_scores = scores_confirmed[y_tp == 1]

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.hist(fp_scores, bins=40, alpha=0.6, color="#e74c3c", label="False Positives", density=True)
    ax.hist(tp_scores, bins=40, alpha=0.6, color="#2ecc71", label="True Positives", density=True)
    ax.set_xlabel("MVS-A Importance Score")
    ax.set_ylabel("Density")
    ax.set_title("MVS-A Score Distribution: FP vs TP")
    ax.legend()
    ax.grid(alpha=0.3)
    plt.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return output_path


def plot_scaffold_diversity_comparison(
    methods: Dict[str, Dict[str, float]],
    output_path: str,
) -> str:
    """Plot scaffold diversity of FP and TP sets across methods.

    Parameters
    ----------
    methods : dict
        Keys are method names, values are dicts with 'fp_diversity' and 'tp_diversity'.
    output_path : str
        Path to save the figure.

    Returns
    -------
    str
        Path to the saved figure.
    """
    fig, ax = plt.subplots(figsize=(10, 5))
    names = list(methods.keys())
    x = np.arange(len(names))
    width = 0.35

    fp_div = [methods[n]["fp_diversity"] for n in names]
    tp_div = [methods[n]["tp_diversity"] for n in names]

    ax.bar(x - width / 2, fp_div, width, label="FP Scaffold Diversity", color="#e74c3c", alpha=0.8)
    ax.bar(x + width / 2, tp_div, width, label="TP Scaffold Diversity", color="#2ecc71", alpha=0.8)

    ax.set_xlabel("Method")
    ax.set_ylabel("Scaffold Diversity (%)")
    ax.set_title("Scaffold Diversity of Predicted FP/TP Sets")
    ax.set_xticks(x)
    ax.set_xticklabels(names, rotation=30, ha="right")
    ax.legend()
    ax.set_ylim(0, 100)
    ax.grid(axis="y", alpha=0.3)
    plt.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return output_path


def plot_importance_trajectory(
    trajectory: np.ndarray,
    sample_indices: List[int],
    labels: List[str],
    output_path: str,
) -> str:
    """Plot MVS-A importance trajectory across training iterations.

    Parameters
    ----------
    trajectory : np.ndarray
        (M, T) importance scores per iteration.
    sample_indices : list of int
        Indices of samples to plot.
    labels : list of str
        Labels for each sample.
    output_path : str
        Path to save the figure.

    Returns
    -------
    str
        Path to the saved figure.
    """
    fig, ax = plt.subplots(figsize=(10, 5))
    for idx, label in zip(sample_indices, labels):
        cumulative = np.cumsum(trajectory[idx, :])
        ax.plot(cumulative, label=label, alpha=0.7)

    ax.set_xlabel("Tree Iteration")
    ax.set_ylabel("Cumulative MVS-A Score")
    ax.set_title("MVS-A Importance Trajectory During Training")
    ax.legend(fontsize=8)
    ax.grid(alpha=0.3)
    plt.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return output_path


def plot_metric_summary_table(
    results: Dict[str, Dict[str, float]],
    output_path: str,
) -> str:
    """Create a table figure summarizing all metrics for all methods.

    Parameters
    ----------
    results : dict
        Nested dict: {method: {metric: value}}.
    output_path : str
        Path to save the figure.

    Returns
    -------
    str
        Path to the saved figure.
    """
    methods = list(results.keys())
    metrics = list(results[methods[0]].keys())

    cell_text = []
    for m in methods:
        row = [f"{results[m][k]:.3f}" if isinstance(results[m][k], float) else str(results[m][k]) for k in metrics]
        cell_text.append(row)

    fig, ax = plt.subplots(figsize=(max(12, len(metrics) * 1.5), 1 + len(methods) * 0.5))
    ax.axis("off")
    table = ax.table(
        cellText=cell_text,
        rowLabels=methods,
        colLabels=metrics,
        cellLoc="center",
        loc="center",
    )
    table.auto_set_font_size(False)
    table.set_fontsize(8)
    table.scale(1, 1.5)
    ax.set_title("Hit Prioritization Performance Summary", fontsize=12, pad=20)
    plt.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return output_path

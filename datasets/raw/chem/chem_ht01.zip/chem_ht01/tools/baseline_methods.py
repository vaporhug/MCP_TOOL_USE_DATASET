"""Tools for baseline hit prioritization methods (primary score ranking, isolation forest)."""

import numpy as np
from sklearn.ensemble import IsolationForest
from typing import Tuple


def score_based_ranking(
    scores: np.ndarray,
    y_primary: np.ndarray,
    percentile: int = 90,
) -> Tuple[np.ndarray, np.ndarray]:
    """Rank compounds by primary screen activity score.

    Higher-scoring primary actives are presumed to be true positives;
    lower-scoring ones are presumed to be false positives.

    .. warning::
        This baseline requires a *continuous* primary-readout / assay-response
        column. In the bundled GPCR dataset the ``Score`` column is a binary
        activity label (0 for inactive, 100 for active): every primary active
        shares the identical score of 100, so this baseline carries no
        ranking information and is **excluded from the graded comparison** for
        this task. It is retained only for datasets that do provide a genuine
        continuous readout.

    Selection uses a fixed top-k / bottom-k split rather than a raw percentile
    threshold so that a single compound can never be flagged as both FP and TP
    (the percentile thresholds coincide on the degenerate, all-equal score
    column). With ``k = ceil((100 - percentile)/100 * n_actives)``, the ``k``
    highest-scoring actives are flagged TP and the ``k`` lowest-scoring actives
    are flagged FP; ties at the boundary are broken deterministically by index
    so the TP and FP sets stay disjoint.

    Parameters
    ----------
    scores : np.ndarray
        (M,) primary screen activity scores.
    y_primary : np.ndarray
        (M,) primary screen labels.
    percentile : int
        Threshold percentile for flagging (90 -> top/bottom 10%).

    Returns
    -------
    fp_flags : np.ndarray
        (M,) binary array; 1 = predicted FP (low score).
    tp_flags : np.ndarray
        (M,) binary array; 1 = predicted TP (high score).

    Notes
    -----
    The return order is ``(fp_flags, tp_flags)``, matching
    ``isolation_forest_ranking`` and ``mvs_analysis.rank_by_importance`` so the
    three ranking functions can be used interchangeably.
    """
    idx_pos = np.where(y_primary == 1)[0]
    n_pos = len(idx_pos)

    tp_flags = np.zeros(len(y_primary))
    fp_flags = np.zeros(len(y_primary))

    if n_pos == 0:
        return fp_flags, tp_flags

    scores_pos = scores[idx_pos]

    # Fraction selected at each end (e.g. percentile=90 -> top/bottom 10%).
    frac = (100 - percentile) / 100.0
    k = int(np.ceil(frac * n_pos))
    # Cap so the top-k and bottom-k sets cannot overlap.
    k = max(0, min(k, n_pos // 2))
    if k == 0:
        return fp_flags, tp_flags

    # Stable sort of actives by score; ties broken by position so the same
    # compound is never assigned to both ends.
    order = np.argsort(scores_pos, kind="stable")
    bottom_local = order[:k]          # lowest scores -> false positives
    top_local = order[n_pos - k:]     # highest scores -> true positives

    fp_flags[idx_pos[bottom_local]] = 1
    tp_flags[idx_pos[top_local]] = 1

    return fp_flags, tp_flags


def isolation_forest_ranking(
    X: np.ndarray,
    y_primary: np.ndarray,
    percentile: int = 90,
    seed: int = 0,
) -> Tuple[np.ndarray, np.ndarray]:
    """Use Isolation Forest anomaly detection to flag likely FP/TP compounds.

    Anomalous actives (low anomaly score) are presumed false positives;
    normal actives are presumed true positives.

    Parameters
    ----------
    X : np.ndarray
        (M, K) feature matrix.
    y_primary : np.ndarray
        (M,) primary screen labels.
    percentile : int
        Threshold percentile.
    seed : int
        Random seed.

    Returns
    -------
    fp_flags : np.ndarray
        (M,) binary; 1 = predicted FP.
    tp_flags : np.ndarray
        (M,) binary; 1 = predicted TP.
    raw_scores : np.ndarray
        (M,) anomaly scores (negated so higher = more anomalous).
    """
    primary_idx = np.where(y_primary == 1)[0]

    model = IsolationForest(n_jobs=-1, random_state=seed)
    model.fit(X)

    preds = model.score_samples(X[primary_idx])
    # Negate so that higher = more anomalous = more likely FP
    preds_full = np.zeros(len(y_primary))
    preds_full[primary_idx] = -preds

    idx_pos = primary_idx
    scores_pos = preds_full[idx_pos]
    t_high = np.percentile(scores_pos, percentile)
    t_low = np.percentile(scores_pos, 100 - percentile)

    fp_flags = np.zeros(len(y_primary))
    tp_flags = np.zeros(len(y_primary))
    fp_flags[idx_pos[scores_pos >= t_high]] = 1
    tp_flags[idx_pos[scores_pos <= t_low]] = 1

    return fp_flags, tp_flags, preds_full

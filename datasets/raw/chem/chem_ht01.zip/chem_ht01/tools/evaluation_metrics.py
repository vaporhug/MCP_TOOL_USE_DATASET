"""Tools for evaluating hit prioritization performance."""

import numpy as np
from sklearn.metrics import precision_score
from rdkit.ML.Scoring.Scoring import CalcBEDROC


def compute_precision_at_percentile(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Compute precision of binary predictions from percentile-based ranking.

    Parameters
    ----------
    y_true : np.ndarray
        (V,) ground-truth labels (1=positive).
    y_pred : np.ndarray
        (V,) predicted labels (1=predicted positive).

    Returns
    -------
    float
        Precision score.
    """
    return float(precision_score(y_true, y_pred, zero_division=0))


def compute_enrichment_factor(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Compute enrichment factor from binary predictions.

    EF = (TP_at_k / selected_k) / (total_actives / total_compounds)

    A value > 1 indicates the method enriches for true actives better
    than random selection.

    Parameters
    ----------
    y_true : np.ndarray
        (V,) ground-truth binary labels.
    y_pred : np.ndarray
        (V,) predicted binary labels (selected subset).

    Returns
    -------
    float
        Enrichment factor. Returns 0 if no compounds selected.
    """
    compounds_at_k = np.sum(y_pred)
    if compounds_at_k == 0:
        return 0.0
    total_compounds = len(y_true)
    total_actives = np.sum(y_true)
    tp_at_k = len(np.where(y_true + y_pred == 2)[0])

    return (tp_at_k / compounds_at_k) / (total_actives / total_compounds)


def compute_bedroc(
    y_true: np.ndarray,
    scores: np.ndarray,
    alpha: float = 20.0,
    reverse: bool = True,
) -> float:
    """Compute BEDROC (Boltzmann-Enhanced Discrimination of ROC).

    BEDROC emphasizes early recognition; alpha controls how much weight
    is placed on top-ranked compounds.

    Parameters
    ----------
    y_true : np.ndarray
        (V,) ground-truth binary labels.
    scores : np.ndarray
        (V,) continuous scores for ranking.
    alpha : float
        BEDROC alpha parameter (default 20).
    reverse : bool
        If True, higher scores are ranked first.

    Returns
    -------
    float
        BEDROC score in [0, 1].
    """
    y_true = y_true.flatten()
    scores = scores.flatten()
    paired = list(zip(y_true, scores))
    paired = sorted(paired, key=lambda p: p[1], reverse=reverse)
    return float(CalcBEDROC(scores=paired, col=0, alpha=alpha))


def aggregate_replicate_metrics(results_list: list) -> dict:
    """Aggregate metrics across multiple replicates.

    Parameters
    ----------
    results_list : list of dict
        Each dict has keys like 'fp_precision', 'tp_precision', etc.

    Returns
    -------
    dict
        Mean and std for each metric.
    """
    if not results_list:
        return {}

    keys = results_list[0].keys()
    agg = {}
    for k in keys:
        vals = [r[k] for r in results_list]
        agg[f"{k}_mean"] = float(np.mean(vals))
        agg[f"{k}_std"] = float(np.std(vals))
    return agg

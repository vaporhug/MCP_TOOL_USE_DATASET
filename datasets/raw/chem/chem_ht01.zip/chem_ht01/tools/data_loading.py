"""Tools for loading and preprocessing HTS campaign data."""

import pandas as pd
import numpy as np
from typing import Tuple


def load_hts_data(filepath: str) -> pd.DataFrame:
    """Load HTS campaign CSV data containing SMILES, Primary labels, Score,
    and Confirmatory labels.

    Parameters
    ----------
    filepath : str
        Path to CSV file with columns: SMILES, Primary, Score, Confirmatory.

    Returns
    -------
    pd.DataFrame
        Loaded dataframe with original columns preserved.
    """
    df = pd.read_csv(filepath, index_col=0)
    required = ["SMILES", "Primary", "Score", "Confirmatory"]
    for col in required:
        if col not in df.columns:
            raise ValueError(f"Missing required column: {col}")
    return df


def extract_labels(df: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Extract primary, true-positive, and false-positive label arrays from HTS data.

    Primary labels are used for ML training (active=1, inactive=0).
    For compounds with confirmatory measurements:
      - TP label = 1 if primary active AND confirmed active
      - FP label = 1 if primary active BUT NOT confirmed active

    Parameters
    ----------
    df : pd.DataFrame
        HTS dataframe with Primary and Confirmatory columns.

    Returns
    -------
    y_primary : np.ndarray
        (N,) binary labels from primary screen.
    y_tp : np.ndarray
        (V,) true-positive labels for confirmed subset.
    y_fp : np.ndarray
        (V,) false-positive labels for confirmed subset.
    idx_confirmed : np.ndarray
        (V,) indices into original df of confirmed primary actives.
    """
    y_primary = np.array(df["Primary"])

    # Compounds with confirmatory measurement that were primary actives
    confirmed = df[~df["Confirmatory"].isnull()]
    confirmed_actives = confirmed.loc[confirmed["Primary"] == 1]

    y_tp = np.array(confirmed_actives["Confirmatory"])
    y_fp = (y_tp - 1) * -1  # invert: 0->1, 1->0

    idx_confirmed = np.array(confirmed_actives.index)

    return y_primary, y_tp, y_fp, idx_confirmed


def get_dataset_summary(df: pd.DataFrame) -> dict:
    """Compute summary statistics of an HTS dataset.

    Parameters
    ----------
    df : pd.DataFrame
        HTS dataframe.

    Returns
    -------
    dict
        Dictionary with keys: n_total, n_primary_actives, n_primary_inactives,
        hit_rate, n_confirmed, n_true_positives, n_false_positives, fp_rate.
    """
    n_total = len(df)
    n_active = int((df["Primary"] == 1).sum())
    n_inactive = n_total - n_active

    confirmed = df[~df["Confirmatory"].isnull()]
    confirmed_actives = confirmed.loc[confirmed["Primary"] == 1]
    n_confirmed = len(confirmed_actives)
    n_tp = int(confirmed_actives["Confirmatory"].sum())
    n_fp = n_confirmed - n_tp

    return {
        "n_total": n_total,
        "n_primary_actives": n_active,
        "n_primary_inactives": n_inactive,
        "hit_rate": n_active / n_total,
        "n_confirmed": n_confirmed,
        "n_true_positives": n_tp,
        "n_false_positives": n_fp,
        "fp_rate": n_fp / n_confirmed if n_confirmed > 0 else 0.0,
    }

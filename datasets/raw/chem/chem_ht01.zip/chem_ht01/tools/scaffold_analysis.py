"""Tools for scaffold diversity analysis of prioritized compound sets."""

import numpy as np
from typing import List
from rdkit import Chem
from rdkit.Chem.Scaffolds import MurckoScaffold


def compute_scaffold_diversity(mols: List[Chem.Mol]) -> float:
    """Compute Murcko scaffold diversity for a set of molecules.

    Scaffold diversity = (number of unique Murcko scaffolds) / (number of molecules) * 100.
    High diversity indicates the method does not over-select from a single
    chemical series.

    Parameters
    ----------
    mols : list of Mol
        RDKit molecule objects.

    Returns
    -------
    float
        Scaffold diversity percentage (0-100).
    """
    if len(mols) == 0:
        return 0.0

    smiles = [Chem.MolToSmiles(m) for m in mols]
    scaffolds = set()
    for smi in smiles:
        try:
            scaffolds.add(MurckoScaffold.MurckoScaffoldSmiles(smi))
        except Exception:
            continue

    return len(scaffolds) * 100.0 / len(mols)


def extract_flagged_molecules(
    mols: List[Chem.Mol], flags: np.ndarray
) -> List[Chem.Mol]:
    """Extract molecules that were flagged (flag=1) by a prioritization method.

    Parameters
    ----------
    mols : list of Mol
        All molecules in the dataset.
    flags : np.ndarray
        (M,) binary array where 1 indicates flagged.

    Returns
    -------
    list of Mol
        Subset of flagged molecules.
    """
    idx = np.where(flags == 1)[0]
    return [mols[i] for i in idx]


def get_scaffold_distribution(mols: List[Chem.Mol]) -> dict:
    """Get distribution of Murcko scaffolds in a molecule set.

    Parameters
    ----------
    mols : list of Mol
        RDKit molecule objects.

    Returns
    -------
    dict
        Keys are scaffold SMILES, values are counts.
    """
    dist = {}
    for mol in mols:
        try:
            smi = Chem.MolToSmiles(mol)
            scaff = MurckoScaffold.MurckoScaffoldSmiles(smi)
            dist[scaff] = dist.get(scaff, 0) + 1
        except Exception:
            continue
    return dist

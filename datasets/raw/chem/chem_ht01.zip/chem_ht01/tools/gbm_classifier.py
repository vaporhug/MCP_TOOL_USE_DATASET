"""Tools for training gradient boosting machine classifiers on HTS data."""

import numpy as np
import lightgbm as lgb
from typing import Optional


def train_lightgbm(
    X: np.ndarray,
    y: np.ndarray,
    params: Optional[dict] = None,
    seed: int = 0,
) -> lgb.Booster:
    """Train a LightGBM binary classifier on HTS data.

    Parameters
    ----------
    X : np.ndarray
        (M, K) feature matrix (e.g., ECFP fingerprints).
    y : np.ndarray
        (M,) binary labels (1=active, 0=inactive).
    params : dict, optional
        LightGBM hyperparameters. If None, uses defaults tuned for HTS
        data with cross-entropy loss and regularization.
    seed : int
        Random seed for reproducibility.

    Returns
    -------
    lgb.Booster
        Trained LightGBM model.
    """
    if params is None:
        params = {
            "reg_lambda": 1.0,
            "objective": "cross_entropy",
            "verbosity": -1000,
            "feature_fraction": 0.95,
            "random_seed": seed,
        }

    dataset = lgb.Dataset(X, y)
    model = lgb.train(params=params, train_set=dataset)
    return model


def get_tree_metadata(model: lgb.Booster, X: np.ndarray) -> dict:
    """Extract tree ensemble metadata from a trained LightGBM model.

    Parameters
    ----------
    model : lgb.Booster
        Trained LightGBM model.
    X : np.ndarray
        Training feature matrix (needed to determine leaf assignments).

    Returns
    -------
    dict
        Dictionary with keys:
        - n_estimators: number of trees
        - n_leaves: array of the true leaf *count* per tree

    Notes
    -----
    ``n_leaves[i]`` is the actual number of leaves in tree ``i`` as reported by
    the model structure (``dump_model``). It is NOT the maximum leaf index seen
    in the training data: that quantity is off by one (a tree with K leaves has
    indices 0..K-1, so the max index is K-1) and can further under-count when
    some leaves are never reached by the supplied X. Downstream code iterates
    ``range(n_leaves[i])`` over leaf indices, so an accurate count is required to
    include the final leaf.
    """
    n_estimators = model.num_trees()
    tree_info = model.dump_model()["tree_info"]
    n_leaves = np.array([t["num_leaves"] for t in tree_info], dtype=int)
    return {"n_estimators": n_estimators, "n_leaves": n_leaves}


def predict_proba(model: lgb.Booster, X: np.ndarray) -> np.ndarray:
    """Get probability predictions from a trained LightGBM model.

    Parameters
    ----------
    model : lgb.Booster
        Trained LightGBM model.
    X : np.ndarray
        (N, K) feature matrix.

    Returns
    -------
    np.ndarray
        (N,) predicted probabilities of class 1.
    """
    return model.predict(X)


def predict_at_iteration(
    model: lgb.Booster, X: np.ndarray, n_iter: int
) -> np.ndarray:
    """Get predictions at a specific iteration of the ensemble.

    Parameters
    ----------
    model : lgb.Booster
        Trained LightGBM model.
    X : np.ndarray
        (N, K) feature matrix.
    n_iter : int
        Number of iterations (trees) to use for prediction.

    Returns
    -------
    np.ndarray
        (N,) predicted probabilities using first n_iter trees.
    """
    return model.predict(X, start_iteration=0, num_iteration=n_iter)

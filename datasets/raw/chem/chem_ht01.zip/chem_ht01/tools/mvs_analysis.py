"""Tools for Minimum Variance Sampling Analysis (MVS-A) on HTS data.

MVS-A estimates sample influence during gradient boosting training to
distinguish true bioactive compounds from assay artifacts (false positives).
"""

import numpy as np
import lightgbm as lgb


def compute_l1_norm(model: lgb.Booster, tree_idx: int, n_leaves: int) -> float:
    """Compute L1 norm of leaf weights for a specific tree.

    The L1 norm normalizes the squared hessians when computing MVS scores,
    accounting for the magnitude of the tree's contribution.

    Parameters
    ----------
    model : lgb.Booster
        Trained LightGBM model.
    tree_idx : int
        Index of the tree in the ensemble.
    n_leaves : int
        Number of leaves in this tree.

    Returns
    -------
    float
        L1 norm of leaf weights.
    """
    n_leaves = int(n_leaves)
    if n_leaves < 1:
        raise ValueError(
            f"n_leaves must be >= 1 for tree {tree_idx}, got {n_leaves}"
        )
    l1 = 0.0
    for i in range(n_leaves):
        l1 += abs(model.get_leaf_output(tree_idx, i))
    return l1


def compute_mvs_score(
    preds: np.ndarray, y: np.ndarray, l1: float
) -> np.ndarray:
    """Compute MVS scores for one iteration of the ensemble.

    The MVS score combines the squared gradient (prediction error) with
    the L1-normalized squared hessian to measure how much each sample
    influences the learning process.

    Parameters
    ----------
    preds : np.ndarray
        (M,) predicted probabilities at current iteration.
    y : np.ndarray
        (M,) true labels.
    l1 : float
        L1 norm of leaf weights for the current tree.

    Returns
    -------
    np.ndarray
        (M,) MVS scores, clipped to [0, 1].
    """
    grad = preds - y
    grad_2 = grad * grad

    hessian = preds * (1 - preds)
    hessian_2 = hessian * hessian * l1

    score = np.sqrt(grad_2 + hessian_2)
    score[score > 1.0] = 1.0
    return score


def compute_sample_importance(
    model: lgb.Booster,
    X: np.ndarray,
    y: np.ndarray,
    n_estimators: int,
    n_leaves: np.ndarray,
    return_trajectory: bool = False,
) -> np.ndarray:
    """Compute global MVS-A importance for all training samples.

    Iterates over all trees in the ensemble, accumulating per-sample
    importance scores. High MVS-A scores indicate compounds whose active
    label contradicts the learned pattern (likely false positives), while
    low scores indicate compounds easily classified as active (likely true
    positives).

    Parameters
    ----------
    model : lgb.Booster
        Trained LightGBM model.
    X : np.ndarray
        (M, K) training feature matrix.
    y : np.ndarray
        (M,) training labels.
    n_estimators : int
        Number of trees in the ensemble.
    n_leaves : np.ndarray
        True leaf *count* per tree (length n_estimators), as returned by
        ``gbm_classifier.get_tree_metadata``.
    return_trajectory : bool
        If True, return (M, T) matrix of per-iteration scores.

    Returns
    -------
    np.ndarray
        (M,) summed importance scores, or (M, T) if return_trajectory=True.
    """
    n_estimators = int(n_estimators)
    if n_estimators < 1:
        raise ValueError(f"n_estimators must be >= 1, got {n_estimators}")
    if len(n_leaves) < n_estimators:
        raise ValueError(
            f"n_leaves has length {len(n_leaves)} but n_estimators is "
            f"{n_estimators}; one leaf count is required per tree."
        )

    vals_box = np.empty((X.shape[0], n_estimators), dtype=np.float64)

    for i in range(n_estimators):
        # Predictions using the first (i + 1) trees: at iteration i we want the
        # ensemble state *after* tree i has been added. Using num_iteration=i
        # (the previous behaviour) evaluated the model with only i trees, so the
        # first iteration used zero trees (the prior) and the final tree's
        # contribution was never scored.
        preds = model.predict(X, start_iteration=0, num_iteration=i + 1)
        l1 = compute_l1_norm(model, i, n_leaves[i])
        vals_box[:, i] = compute_mvs_score(preds, y, l1)

    if return_trajectory:
        return vals_box
    return np.sum(vals_box, axis=1)


def rank_by_importance(
    y_primary: np.ndarray,
    importance_scores: np.ndarray,
    percentile: int = 90,
) -> tuple:
    """Convert raw MVS-A importance into binary FP/TP predictions.

    Compounds with scores above the top percentile among actives are
    flagged as likely false positives; those below the bottom percentile
    are flagged as likely true positives.

    Parameters
    ----------
    y_primary : np.ndarray
        (M,) primary screen labels.
    importance_scores : np.ndarray
        (M,) MVS-A importance scores.
    percentile : int
        Percentile threshold (default 90 means top 10% = FP, bottom 10% = TP).

    Returns
    -------
    fp_flags : np.ndarray
        (M,) binary array; 1 = predicted false positive.
    tp_flags : np.ndarray
        (M,) binary array; 1 = predicted true positive.
    """
    idx_pos = np.where(y_primary == 1)[0]
    scores_pos = importance_scores[idx_pos]

    t_high = np.percentile(scores_pos, percentile)
    t_low = np.percentile(scores_pos, 100 - percentile)

    fp_flags = np.zeros(len(y_primary))
    tp_flags = np.zeros(len(y_primary))

    idx_fp = np.where(scores_pos >= t_high)[0]
    idx_tp = np.where(scores_pos <= t_low)[0]

    fp_flags[idx_pos[idx_fp]] = 1
    tp_flags[idx_pos[idx_tp]] = 1

    return fp_flags, tp_flags

"""Tools for running MVS-A analysis with multiple replicates for robustness."""

import numpy as np
import time
from typing import List, Tuple


def run_single_replicate(
    train_gbm_fn,
    get_tree_meta_fn,
    compute_importance_fn,
    rank_fn,
    X: np.ndarray,
    y_primary: np.ndarray,
    seed: int = 0,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, float]:
    """Run one replicate of MVS-A analysis.

    Parameters
    ----------
    train_gbm_fn : callable
        Function to train LightGBM model: (X, y, params, seed) -> model.
    get_tree_meta_fn : callable
        Function to get tree metadata: (model, X) -> dict.
    compute_importance_fn : callable
        Function to compute MVS-A importance: (model, X, y, n_est, n_leaves) -> scores.
    rank_fn : callable
        Function to rank compounds: (y, scores, percentile) -> (fp_flags, tp_flags).
    X : np.ndarray
        (M, K) feature matrix.
    y_primary : np.ndarray
        (M,) primary labels.
    seed : int
        Random seed for this replicate.

    Returns
    -------
    fp_flags : np.ndarray
        (M,) FP predictions.
    tp_flags : np.ndarray
        (M,) TP predictions.
    importance : np.ndarray
        (M,) raw importance scores.
    elapsed : float
        Wall-clock time in seconds.
    """
    start = time.time()
    model = train_gbm_fn(X, y_primary, params=None, seed=seed)
    meta = get_tree_meta_fn(model, X)
    importance = compute_importance_fn(
        model, X, y_primary, meta["n_estimators"], meta["n_leaves"]
    )
    fp_flags, tp_flags = rank_fn(y_primary, importance, 90)
    elapsed = time.time() - start
    return fp_flags, tp_flags, importance, elapsed


def collect_replicate_results(
    replicate_outputs: List[tuple],
    y_fp: np.ndarray,
    y_tp: np.ndarray,
    idx_confirmed: np.ndarray,
    precision_fn,
    ef_fn,
    bedroc_fn,
) -> List[dict]:
    """Evaluate all replicates and collect metrics.

    Parameters
    ----------
    replicate_outputs : list of tuple
        Each tuple: (fp_flags, tp_flags, importance, elapsed).
    y_fp : np.ndarray
        (V,) FP ground truth for confirmed compounds.
    y_tp : np.ndarray
        (V,) TP ground truth for confirmed compounds.
    idx_confirmed : np.ndarray
        (V,) indices of confirmed compounds.
    precision_fn : callable
        Precision computation function.
    ef_fn : callable
        Enrichment factor function.
    bedroc_fn : callable
        BEDROC function.

    Returns
    -------
    list of dict
        Per-replicate metrics dictionaries.
    """
    results = []
    for fp_flags, tp_flags, importance, elapsed in replicate_outputs:
        r = {
            "time": elapsed,
            "fp_precision": precision_fn(y_fp, fp_flags[idx_confirmed]),
            "tp_precision": precision_fn(y_tp, tp_flags[idx_confirmed]),
            "fp_ef": ef_fn(y_fp, fp_flags[idx_confirmed]),
            "tp_ef": ef_fn(y_tp, tp_flags[idx_confirmed]),
            "fp_bedroc": bedroc_fn(y_fp, importance[idx_confirmed], reverse=True),
            "tp_bedroc": bedroc_fn(y_tp, importance[idx_confirmed], reverse=False),
        }
        results.append(r)
    return results

"""Applicability domain helpers for the VS task.

Functions
---------
nearest_neighbour_max_similarity(query_fps, train_actives_fps) -> np.ndarray
applicability_flag(scores, threshold) -> np.ndarray (bool)
classify_compounds_by_ad(scores, low=0.3, high=0.5) -> np.ndarray (str labels)
ad_summary(flags) -> dict
"""
from __future__ import annotations

from typing import Sequence

import numpy as np

from . import similarity as _sim


def nearest_neighbour_max_similarity(
    query_fps: np.ndarray, train_actives_fps: np.ndarray
) -> np.ndarray:
    """For each row in ``query_fps``, return the max Tanimoto to any training active.

    Use as an applicability-domain (AD) score: a query with NN sim < 0.3 to all
    known actives is "out-of-domain" for similarity-based VS.
    """
    sim = _sim.tanimoto_matrix(train_actives_fps, query_fps)  # (n_train, n_query)
    return sim.max(axis=0)


def applicability_flag(scores: np.ndarray, threshold: float = 0.3) -> np.ndarray:
    """Boolean mask: True if NN-similarity score >= ``threshold`` (in domain)."""
    return np.asarray(scores) >= float(threshold)


def classify_compounds_by_ad(
    scores: np.ndarray, low: float = 0.3, high: float = 0.5
) -> np.ndarray:
    """String labels: ``"out"`` (< low), ``"borderline"`` (low <= s < high), ``"in"`` (s >= high)."""
    s = np.asarray(scores)
    out = np.empty(s.shape, dtype=object)
    out[s < low] = "out"
    out[(s >= low) & (s < high)] = "borderline"
    out[s >= high] = "in"
    return out


def ad_summary(flags: Sequence[str]) -> dict:
    """Counts per AD class as a dict (``in``, ``borderline``, ``out``, ``total``)."""
    arr = np.asarray(list(flags))
    return {
        "in": int(np.sum(arr == "in")),
        "borderline": int(np.sum(arr == "borderline")),
        "out": int(np.sum(arr == "out")),
        "total": int(arr.size),
    }

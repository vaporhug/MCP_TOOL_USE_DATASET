"""I/O helpers for the DUD-subset ligand-based virtual screening task.

Functions
---------
load_compound_table(path)        -> pandas.DataFrame  (target/mol_id/zinc_id/smiles/label)
load_target_metadata(path)       -> pandas.DataFrame  (target/target_name/uniprot/n_actives/n_decoys/ratio_a_d)
load_query_lists(path)           -> dict[target -> list[list[mol_id]]]
load_dataset_manifest(path)      -> dict
load_target_notes(path)          -> dict
list_targets(compound_table)     -> list[str]
split_actives_decoys(table, target) -> (actives_df, decoys_df)
make_screening_split(actives_df, decoys_df, query_mol_ids) -> (queries_df, db_df, db_labels)
load_smiles_to_rdkit(smiles_list) -> list[Mol or None]   # silent skips on parse fail
write_dict_json(obj, path)       -> str  (path)
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import numpy as np
import pandas as pd

try:
    from rdkit import Chem
    from rdkit import RDLogger
    RDLogger.DisableLog("rdApp.*")
except Exception:  # pragma: no cover
    Chem = None


# ---------------------------------------------------------------------------
# loaders


def load_compound_table(path: str) -> pd.DataFrame:
    """Load the (target, mol_id, zinc_id, smiles, label) screening compound table."""
    df = pd.read_csv(path, dtype={"target": str, "mol_id": str, "zinc_id": str, "smiles": str, "label": int})
    df["label"] = df["label"].astype(int)
    return df


def load_target_metadata(path: str) -> pd.DataFrame:
    """Load per-target metadata (counts, name, uniprot)."""
    return pd.read_csv(path)


def load_query_lists(path: str) -> Dict[str, List[List[str]]]:
    """Load deterministic per-target query molecule ID lists.

    Returns a mapping ``target -> [[mol_id_q1, ..., mol_id_q5], rep1, ...]``.
    """
    with open(path) as f:
        return json.load(f)


def load_dataset_manifest(path: str) -> dict:
    with open(path) as f:
        return json.load(f)


def load_target_notes(path: str) -> dict:
    with open(path) as f:
        return json.load(f)


# ---------------------------------------------------------------------------
# splits


def list_targets(compound_table: pd.DataFrame) -> List[str]:
    """Return the sorted list of unique target ids in a compound table."""
    return sorted(compound_table["target"].unique().tolist())


def split_actives_decoys(table: pd.DataFrame, target: str) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Split a compound table for one ``target`` into (actives_df, decoys_df)."""
    sub = table[table["target"] == target]
    actives = sub[sub["label"] == 1].reset_index(drop=True)
    decoys = sub[sub["label"] == 0].reset_index(drop=True)
    return actives, decoys


def make_screening_split(
    actives_df: pd.DataFrame,
    decoys_df: pd.DataFrame,
    query_mol_ids: Sequence[str],
) -> Tuple[pd.DataFrame, pd.DataFrame, np.ndarray]:
    """Hold out the listed ``query_mol_ids`` from actives, keep them as queries.

    Returns
    -------
    queries_df : DataFrame with the query active molecules (label = 1)
    db_df      : DataFrame with the remaining actives + all decoys (the database
                 the agent must rank for this repetition)
    db_labels  : (n,) int array, 1 if active, 0 if decoy, aligned with db_df
    """
    qset = set(query_mol_ids)
    queries_df = actives_df[actives_df["mol_id"].isin(qset)].reset_index(drop=True)
    held_actives = actives_df[~actives_df["mol_id"].isin(qset)].reset_index(drop=True)
    db_df = pd.concat([held_actives, decoys_df], ignore_index=True)
    db_labels = db_df["label"].to_numpy(dtype=np.int64)
    return queries_df, db_df, db_labels


# ---------------------------------------------------------------------------
# small helpers


def load_smiles_to_rdkit(smiles_list: Sequence[str]):
    """Parse a sequence of SMILES into RDKit Mol objects (None for failures)."""
    if Chem is None:
        raise ImportError("rdkit is required but not importable")
    return [Chem.MolFromSmiles(s) for s in smiles_list]


def write_dict_json(obj: dict, path: str) -> str:
    """Write a JSON-serialisable dict to ``path`` (creating parents)."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w") as f:
        json.dump(obj, f, indent=2, default=_json_default)
    return str(p)


def _json_default(o):
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, np.ndarray):
        return o.tolist()
    return str(o)

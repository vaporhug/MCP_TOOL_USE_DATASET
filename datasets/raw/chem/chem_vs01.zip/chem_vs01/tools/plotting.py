"""Plotting helpers for the virtual-screening benchmark.

Each function writes a PNG to ``output_path`` and returns ``{"path": output_path}``.

Functions
---------
plot_roc_curves(rocs_by_method, output_path)
plot_per_target_metric_bar(metric_table, metric, output_path)
plot_metric_correlation(metric_table, x, y, output_path)
plot_similarity_rank_scatter(similarity, ranks_of_actives, output_path)
plot_decoy_property_distribution(prop_actives, prop_decoys, output_path)
plot_fingerprint_average_rank(rank_table, output_path)
"""
from __future__ import annotations

import os
from typing import Dict, Iterable, Sequence

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def _fig(figsize=(6.0, 4.5)):
    fig, ax = plt.subplots(figsize=figsize)
    return fig, ax


def _ensure_parent(path: str) -> None:
    d = os.path.dirname(os.path.abspath(path))
    if d:
        os.makedirs(d, exist_ok=True)


def plot_roc_curves(rocs_by_method: Dict[str, "tuple[np.ndarray, np.ndarray, float]"], output_path: str) -> dict:
    """Plot ROC curves overlay.

    ``rocs_by_method`` maps label -> (fpr, tpr, auc).  A diagonal random line
    is drawn for reference.
    """
    _ensure_parent(output_path)
    fig, ax = _fig()
    for name, (fpr, tpr, auc) in rocs_by_method.items():
        ax.plot(fpr, tpr, label=f"{name} (AUC={auc:.3f})")
    ax.plot([0, 1], [0, 1], "k--", linewidth=1, label="random")
    ax.set_xlabel("False positive rate")
    ax.set_ylabel("True positive rate")
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1.02)
    ax.set_title("ROC curves")
    ax.legend(fontsize=8, loc="lower right")
    fig.tight_layout()
    fig.savefig(output_path, dpi=140)
    plt.close(fig)
    return {"path": output_path}


def plot_per_target_metric_bar(metric_table: pd.DataFrame, metric: str, output_path: str) -> dict:
    """Grouped bar chart: per-target metric value, one bar per fingerprint method."""
    _ensure_parent(output_path)
    pivot = metric_table.pivot_table(index="target", columns="fingerprint", values=metric)
    targets = list(pivot.index)
    methods = list(pivot.columns)
    n_t = len(targets)
    n_m = len(methods)
    width = 0.8 / max(n_m, 1)
    fig, ax = _fig(figsize=(max(6.0, 1.2 * n_t), 4.5))
    cmap = plt.colormaps["tab10"]
    x = np.arange(n_t)
    for j, m in enumerate(methods):
        ax.bar(x + (j - n_m / 2 + 0.5) * width, pivot[m].values, width=width, label=m, color=cmap(j % 10))
    ax.set_xticks(x)
    ax.set_xticklabels(targets, rotation=20)
    ax.set_ylabel(metric)
    ax.set_title(f"Per-target {metric}")
    ax.axhline(0.5 if metric.lower().startswith("auc") else 1.0, color="0.5", linestyle="--", linewidth=1)
    ax.legend(fontsize=8, ncol=2)
    fig.tight_layout()
    fig.savefig(output_path, dpi=140)
    plt.close(fig)
    return {"path": output_path}


def plot_metric_correlation(metric_table: pd.DataFrame, x: str, y: str, output_path: str) -> dict:
    """Scatter of metric ``x`` vs metric ``y`` across (fingerprint, target) rows."""
    _ensure_parent(output_path)
    fig, ax = _fig()
    grouped = metric_table.groupby("fingerprint")
    cmap = plt.colormaps["tab10"]
    for j, (fp, sub) in enumerate(grouped):
        ax.scatter(sub[x], sub[y], s=24, alpha=0.8, label=fp, color=cmap(j % 10))
    ax.set_xlabel(x)
    ax.set_ylabel(y)
    ax.set_title(f"{y} vs {x}")
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(output_path, dpi=140)
    plt.close(fig)
    return {"path": output_path}


def plot_similarity_rank_scatter(
    similarity: np.ndarray, ranks_of_actives: np.ndarray, output_path: str
) -> dict:
    """Scatter of nearest-neighbour Tanimoto vs rank position of actives."""
    _ensure_parent(output_path)
    fig, ax = _fig()
    sim = np.asarray(similarity)
    rk = np.asarray(ranks_of_actives, dtype=np.float64) + 1
    ax.scatter(sim, rk, s=18, alpha=0.7)
    ax.set_yscale("log")
    ax.set_xlabel("max Tanimoto similarity to query set")
    ax.set_ylabel("rank in screened database (1 = top)")
    ax.set_title("Active retrieval rank vs query similarity")
    fig.tight_layout()
    fig.savefig(output_path, dpi=140)
    plt.close(fig)
    return {"path": output_path}


def plot_decoy_property_distribution(
    prop_actives: np.ndarray, prop_decoys: np.ndarray, output_path: str, prop_name: str = "MW"
) -> dict:
    """Overlaid histogram of a physicochemical property for actives vs decoys."""
    _ensure_parent(output_path)
    fig, ax = _fig()
    bins = 40
    ax.hist(prop_decoys, bins=bins, alpha=0.55, density=True, label="decoys", color="0.4")
    ax.hist(prop_actives, bins=bins, alpha=0.7, density=True, label="actives", color="C3")
    ax.set_xlabel(prop_name)
    ax.set_ylabel("density")
    ax.set_title(f"{prop_name} distribution actives vs decoys")
    ax.legend(fontsize=9)
    fig.tight_layout()
    fig.savefig(output_path, dpi=140)
    plt.close(fig)
    return {"path": output_path}


def plot_fingerprint_average_rank(rank_table: pd.DataFrame, output_path: str) -> dict:
    """Plot Friedman-style average rank of fingerprints across evaluation metrics."""
    _ensure_parent(output_path)
    fig, ax = _fig(figsize=(6.0, 4.5))
    cmap = plt.colormaps["tab10"]
    methods = list(rank_table.index)
    metrics = list(rank_table.columns)
    x = np.arange(len(metrics))
    for j, m in enumerate(methods):
        ax.plot(x, rank_table.loc[m].values, "-o", color=cmap(j % 10), label=m)
    ax.invert_yaxis()
    ax.set_xticks(x)
    ax.set_xticklabels(metrics, rotation=20)
    ax.set_ylabel("Average rank (1 = best)")
    ax.set_title("Fingerprint average rank across evaluation metrics")
    ax.legend(fontsize=8, ncol=2)
    fig.tight_layout()
    fig.savefig(output_path, dpi=140)
    plt.close(fig)
    return {"path": output_path}

"""Machine-learning baselines for ligand-based virtual screening.

Functions
---------
train_random_forest(X_train, y_train, n_trees=100, max_features='sqrt', seed=0) -> RandomForestClassifier
train_logistic_regression(X_train, y_train, C=1.0, seed=0) -> LogisticRegression
predict_active_probability(model, X)            -> np.ndarray (n,)
score_with_classifier(model, db_fps)            -> np.ndarray (n,)   (P(active))
build_train_test_split_for_target(actives_fps, decoys_fps, query_indices, seed=0)
                                                -> (X_train, y_train, X_test, y_test)
"""
from __future__ import annotations

from typing import Sequence, Tuple

import numpy as np

try:
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.linear_model import LogisticRegression
except Exception as exc:  # pragma: no cover
    raise ImportError("scikit-learn is required for ml_models.py") from exc


def train_random_forest(
    X_train: np.ndarray,
    y_train: np.ndarray,
    n_trees: int = 100,
    max_features: str = "sqrt",
    seed: int = 0,
) -> "RandomForestClassifier":
    """Fit an out-of-the-box random forest classifier on fingerprint features."""
    clf = RandomForestClassifier(
        n_estimators=n_trees,
        max_features=max_features,
        n_jobs=-1,
        random_state=seed,
        class_weight="balanced",
    )
    clf.fit(np.asarray(X_train), np.asarray(y_train).astype(int))
    return clf


def train_logistic_regression(
    X_train: np.ndarray,
    y_train: np.ndarray,
    C: float = 1.0,
    seed: int = 0,
) -> "LogisticRegression":
    """Fit a regularised logistic regression baseline on fingerprint features."""
    clf = LogisticRegression(
        C=C,
        max_iter=2000,
        solver="liblinear",
        class_weight="balanced",
        random_state=seed,
    )
    clf.fit(np.asarray(X_train), np.asarray(y_train).astype(int))
    return clf


def predict_active_probability(model, X: np.ndarray) -> np.ndarray:
    """Return the predicted probability of class ``1`` (active) for each row."""
    proba = model.predict_proba(np.asarray(X))
    classes = list(getattr(model, "classes_", [0, 1]))
    if 1 in classes:
        idx = classes.index(1)
    else:
        idx = -1
    return proba[:, idx].astype(np.float64)


def score_with_classifier(model, db_fps: np.ndarray) -> np.ndarray:
    """Convenience wrapper: P(active) used as VS score for ranking."""
    return predict_active_probability(model, db_fps)


def build_train_test_split_for_target(
    actives_fps: np.ndarray,
    decoys_fps: np.ndarray,
    query_indices: Sequence[int],
    seed: int = 0,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Split actives/decoys into a training set and a screening test set.

    The ``query_indices`` actives become the training positives.  A balanced
    sample of decoys (3 x #queries) becomes the training negatives, drawn
    deterministically by ``seed``.  All remaining molecules form the test set.

    Returns ``(X_train, y_train, X_test, y_test)``.
    """
    rng = np.random.default_rng(seed)
    n_dec = decoys_fps.shape[0]
    q_idx = np.asarray(query_indices, dtype=np.int64)
    n_train_neg = min(3 * len(q_idx), n_dec)
    train_neg_idx = rng.choice(n_dec, size=n_train_neg, replace=False)
    train_neg_mask = np.zeros(n_dec, dtype=bool)
    train_neg_mask[train_neg_idx] = True
    test_neg_idx = np.where(~train_neg_mask)[0]

    train_act_mask = np.zeros(actives_fps.shape[0], dtype=bool)
    train_act_mask[q_idx] = True
    test_act_idx = np.where(~train_act_mask)[0]

    X_train = np.vstack([actives_fps[train_act_mask], decoys_fps[train_neg_mask]])
    y_train = np.concatenate([
        np.ones(int(train_act_mask.sum()), dtype=np.int64),
        np.zeros(int(train_neg_mask.sum()), dtype=np.int64),
    ])
    X_test = np.vstack([actives_fps[test_act_idx], decoys_fps[test_neg_idx]])
    y_test = np.concatenate([
        np.ones(test_act_idx.size, dtype=np.int64),
        np.zeros(test_neg_idx.size, dtype=np.int64),
    ])
    return X_train, y_train, X_test, y_test

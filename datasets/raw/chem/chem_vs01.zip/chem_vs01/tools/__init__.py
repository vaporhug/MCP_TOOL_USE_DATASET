"""Tool package for the ligand-based virtual screening fingerprint benchmark task.

Submodules
----------
data_io          : load actives/decoys CSV, query lists, target metadata
fingerprints     : Morgan / AtomPair / TopologicalTorsion / MACCS / atom-count baseline
similarity       : Tanimoto on bit vectors and counts; max-similarity / fusion scorers
ml_models        : random forest classifier from fingerprints; logistic regression baseline
                   (optional; requires scikit-learn — imported lazily)
evaluation       : AUROC, BEDROC(alpha=20), enrichment factor, RIE, scaffold-hopping EF
applicability    : nearest-neighbour applicability domain on training-active fingerprints
plotting         : matplotlib helpers; each function returns ``{"path": output_path}``
"""

# Core tools imported eagerly. ml_models is NOT imported here because it
# requires scikit-learn, which is optional for the core fingerprint-similarity
# workflow; import it explicitly (``from tools import ml_models``) when needed.
from . import data_io, fingerprints, similarity, evaluation, applicability, plotting  # noqa: F401

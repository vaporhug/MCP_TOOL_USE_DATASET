"""Molecular fingerprint primitives (RDKit) for the VS benchmark.

Functions
---------
compute_morgan_fingerprint(smiles, radius=2, n_bits=1024) -> np.uint8 (n_bits,)
compute_morgan_fingerprints(smiles_list, ...)             -> np.uint8 (n, n_bits)
compute_atompair_fingerprints(smiles_list, n_bits=1024)   -> np.uint8 (n, n_bits)
compute_topological_torsion_fingerprints(smiles_list, n_bits=1024) -> np.uint8 (n, n_bits)
compute_maccs_fingerprints(smiles_list)                   -> np.uint8 (n, 167)
compute_atomcount_baseline(smiles_list)                   -> np.float32 (n, 6)  # H,C,N,O,S,X
fingerprint_method_table()                                -> dict[str -> callable]
fingerprint_to_bitvect(arr_row)                           -> rdkit ExplicitBitVect
batch_smiles_validity(smiles_list)                        -> np.bool_  (n,)
"""
from __future__ import annotations

from typing import Callable, Dict, List, Sequence

import numpy as np

try:
    from rdkit import Chem
    from rdkit import DataStructs
    from rdkit.Chem import AllChem, MACCSkeys
    from rdkit.Chem import rdFingerprintGenerator as _rfg
    from rdkit import RDLogger

    RDLogger.DisableLog("rdApp.*")
except Exception as exc:  # pragma: no cover
    raise ImportError("rdkit is required for fingerprints.py") from exc


# ---------------------------------------------------------------------------
# Morgan / ECFP


def compute_morgan_fingerprint(smiles: str, radius: int = 2, n_bits: int = 1024) -> np.ndarray:
    """Compute a single Morgan/ECFP-like binary fingerprint as ``np.uint8`` (n_bits,)."""
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return np.zeros(n_bits, dtype=np.uint8)
    bv = AllChem.GetMorganFingerprintAsBitVect(mol, radius=radius, nBits=n_bits)
    arr = np.zeros((n_bits,), dtype=np.uint8)
    DataStructs.ConvertToNumpyArray(bv, arr)
    return arr


def compute_morgan_fingerprints(
    smiles_list: Sequence[str], radius: int = 2, n_bits: int = 1024
) -> np.ndarray:
    """Stack Morgan fingerprints for many SMILES into a (n, n_bits) ``np.uint8`` matrix."""
    out = np.zeros((len(smiles_list), n_bits), dtype=np.uint8)
    for i, s in enumerate(smiles_list):
        out[i] = compute_morgan_fingerprint(s, radius=radius, n_bits=n_bits)
    return out


# ---------------------------------------------------------------------------
# Atom pair


def compute_atompair_fingerprints(smiles_list: Sequence[str], n_bits: int = 1024) -> np.ndarray:
    """Hashed atom-pair fingerprints folded to ``n_bits`` bits."""
    gen = _rfg.GetAtomPairGenerator(fpSize=n_bits)
    out = np.zeros((len(smiles_list), n_bits), dtype=np.uint8)
    for i, s in enumerate(smiles_list):
        m = Chem.MolFromSmiles(s)
        if m is None:
            continue
        bv = gen.GetFingerprint(m)
        arr = np.zeros((n_bits,), dtype=np.uint8)
        DataStructs.ConvertToNumpyArray(bv, arr)
        out[i] = arr
    return out


# ---------------------------------------------------------------------------
# Topological torsion


def compute_topological_torsion_fingerprints(
    smiles_list: Sequence[str], n_bits: int = 1024
) -> np.ndarray:
    """Hashed topological-torsion fingerprints folded to ``n_bits`` bits."""
    gen = _rfg.GetTopologicalTorsionGenerator(fpSize=n_bits)
    out = np.zeros((len(smiles_list), n_bits), dtype=np.uint8)
    for i, s in enumerate(smiles_list):
        m = Chem.MolFromSmiles(s)
        if m is None:
            continue
        bv = gen.GetFingerprint(m)
        arr = np.zeros((n_bits,), dtype=np.uint8)
        DataStructs.ConvertToNumpyArray(bv, arr)
        out[i] = arr
    return out


# ---------------------------------------------------------------------------
# MACCS dictionary keys (167 bits)


def compute_maccs_fingerprints(smiles_list: Sequence[str]) -> np.ndarray:
    """MACCS dictionary keys (167-bit) for a list of SMILES."""
    out = np.zeros((len(smiles_list), 167), dtype=np.uint8)
    for i, s in enumerate(smiles_list):
        m = Chem.MolFromSmiles(s)
        if m is None:
            continue
        bv = MACCSkeys.GenMACCSKeys(m)
        arr = np.zeros((167,), dtype=np.uint8)
        DataStructs.ConvertToNumpyArray(bv, arr)
        out[i] = arr
    return out


# ---------------------------------------------------------------------------
# Baseline: atom counts (acts as a sanity-check fingerprint, like ECFC0 in paper)


def compute_atomcount_baseline(smiles_list: Sequence[str]) -> np.ndarray:
    """Six-element atom-count vector per molecule.

    Columns are counts of [H, C, N, O, S, X] (X = halogens F/Cl/Br/I).
    Hydrogen counts use implicit + explicit Hs from RDKit.
    """
    out = np.zeros((len(smiles_list), 6), dtype=np.float32)
    halogens = {9, 17, 35, 53}
    for i, s in enumerate(smiles_list):
        m = Chem.MolFromSmiles(s)
        if m is None:
            continue
        counts = {1: 0, 6: 0, 7: 0, 8: 0, 16: 0, 0: 0}
        for atom in m.GetAtoms():
            z = atom.GetAtomicNum()
            counts[1] += atom.GetTotalNumHs()
            if z in counts:
                counts[z] += 1
            elif z in halogens:
                counts[0] += 1
        out[i] = [counts[1], counts[6], counts[7], counts[8], counts[16], counts[0]]
    return out


# ---------------------------------------------------------------------------
# helpers


def fingerprint_method_table() -> Dict[str, Callable]:
    """Map of fingerprint name -> compute function (for many-SMILES batch)."""
    return {
        "Morgan2": lambda s: compute_morgan_fingerprints(s, radius=2, n_bits=1024),
        "Morgan3": lambda s: compute_morgan_fingerprints(s, radius=3, n_bits=1024),
        "AtomPair": compute_atompair_fingerprints,
        "TopologicalTorsion": compute_topological_torsion_fingerprints,
        "MACCS": compute_maccs_fingerprints,
        "AtomCount": compute_atomcount_baseline,
    }


def fingerprint_to_bitvect(arr_row: np.ndarray):
    """Convert a 1-D 0/1 numpy array into an RDKit ExplicitBitVect (for fast Tanimoto)."""
    arr = np.asarray(arr_row, dtype=np.uint8)
    bv = DataStructs.ExplicitBitVect(int(arr.size))
    on_bits = np.where(arr > 0)[0].tolist()
    bv.SetBitsFromList(on_bits)
    return bv


def batch_smiles_validity(smiles_list: Sequence[str]) -> np.ndarray:
    """Boolean mask: True if RDKit successfully parsed the SMILES, False otherwise."""
    return np.array([Chem.MolFromSmiles(s) is not None for s in smiles_list], dtype=bool)

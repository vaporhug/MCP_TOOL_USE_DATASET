"""Evaluation metrics for retrospective virtual screening.

All metrics take a 1-D ``np.ndarray`` of binary labels (``ranked_labels``,
1=active, 0=decoy) listed *in score-decreasing order* — i.e. position 0 is the
top hit.  Ratios such as ``chi`` are fractions of the database (0..1).

Functions
---------
auroc(scores, labels)                                    -> float
auroc_from_ranked(ranked_labels)                         -> float
roc_curve_points(scores, labels)                         -> (fpr, tpr, auc)
enrichment_factor(ranked_labels, chi=0.01)               -> float
bedroc(ranked_labels, alpha=20.0)                        -> float
rie(ranked_labels, alpha=20.0)                           -> float
average_per_target_metric(per_target, name)              -> float
summarize_repetitions(repetition_results)                -> dict
metric_table_for_fingerprints(fp_to_metrics)             -> pandas.DataFrame
average_rank_table(metric_table, metrics, ...)           -> pandas.DataFrame
"""
from __future__ import annotations

from typing import Dict, Iterable, List, Sequence

import numpy as np
import pandas as pd

try:
    from sklearn.metrics import roc_auc_score, roc_curve
except Exception:  # pragma: no cover
    roc_auc_score = None
    roc_curve = None


# ---------------------------------------------------------------------------
# AUROC


def auroc(scores: np.ndarray, labels: np.ndarray) -> float:
    """Area under the ROC curve."""
    s = np.asarray(scores, dtype=np.float64)
    y = np.asarray(labels, dtype=np.int64)
    if y.sum() == 0 or y.sum() == len(y):
        return float("nan")
    if roc_auc_score is not None:
        return float(roc_auc_score(y, s))
    # Fallback Mann-Whitney U: assign ascending ranks to ascending scores so
    # that high-score samples (positives in a good classifier) get high ranks.
    order = np.argsort(s, kind="mergesort")  # ascending
    ranks = np.empty_like(order, dtype=np.float64)
    ranks[order] = np.arange(1, len(order) + 1)
    n_pos = int(y.sum())
    n_neg = int(len(y) - n_pos)
    rank_sum_pos = ranks[y == 1].sum()
    return float((rank_sum_pos - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg))


def auroc_from_ranked(ranked_labels: np.ndarray) -> float:
    """AUROC when only the score-sorted (descending) label vector is available.

    For descending sort, position 1 is the best score: a perfect classifier
    places all actives at the top, giving AUC = 1.  We use ``score = -rank``
    so that the canonical AUC formula directly applies.
    """
    y = np.asarray(ranked_labels, dtype=np.int64)
    n = y.size
    n_pos = int(y.sum())
    if n_pos == 0 or n_pos == n:
        return float("nan")
    n_neg = n - n_pos
    # ranks-from-bottom: best score (top of list) gets the highest rank
    ranks_from_bottom = np.arange(n, 0, -1, dtype=np.float64)
    rank_sum_pos = ranks_from_bottom[y == 1].sum()
    return float((rank_sum_pos - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg))


def roc_curve_points(scores: np.ndarray, labels: np.ndarray):
    """Return ``(fpr, tpr, auc)`` for plotting an ROC curve.

    ``scores`` are per-database similarity scores (higher = more active-like)
    and ``labels`` the aligned binary labels (1=active, 0=decoy).  ``fpr`` and
    ``tpr`` are monotone arrays starting at (0, 0) and ending at (1, 1); ``auc``
    is the area under that curve.  Pairs naturally with
    :func:`tools.plotting.plot_roc_curves`, whose ``rocs_by_method`` argument
    expects ``label -> (fpr, tpr, auc)`` tuples.
    """
    s = np.asarray(scores, dtype=np.float64)
    y = np.asarray(labels, dtype=np.int64)
    n_pos = int(y.sum())
    n_neg = int(y.size - n_pos)
    if n_pos == 0 or n_neg == 0:
        return np.array([0.0, 1.0]), np.array([0.0, 1.0]), float("nan")
    if "roc_curve" in globals() and roc_curve is not None:
        fpr, tpr, _ = roc_curve(y, s)
        return np.asarray(fpr), np.asarray(tpr), float(auroc(s, y))
    # Manual ROC: sort by descending score and sweep thresholds.
    order = np.argsort(-s, kind="mergesort")
    y_sorted = y[order]
    tps = np.cumsum(y_sorted == 1)
    fps = np.cumsum(y_sorted == 0)
    tpr = np.concatenate([[0.0], tps / n_pos])
    fpr = np.concatenate([[0.0], fps / n_neg])
    return fpr, tpr, float(auroc(s, y))


def enrichment_factor(ranked_labels: np.ndarray, chi: float = 0.01) -> float:
    """Enrichment factor at the top fraction ``chi`` of the database.

    EF(chi) = (n_actives_top / n_top) / (n_actives_total / n_total).
    """
    y = np.asarray(ranked_labels, dtype=np.int64)
    n = y.size
    n_top = max(1, int(round(chi * n)))
    n_act_total = int(y.sum())
    if n_act_total == 0:
        return float("nan")
    n_act_top = int(y[:n_top].sum())
    return float((n_act_top / n_top) / (n_act_total / n))


def rie(ranked_labels: np.ndarray, alpha: float = 20.0) -> float:
    """Robust Initial Enhancement (Sheridan 2001), exponential weight ``alpha``.

    Definition (Truchon & Bayly 2007, eq. 22), as implemented below:
        RIE = mean( exp(-alpha * r_i/N) ) / [(1/N) * (1 - exp(-alpha))/(exp(alpha/N) - 1)]

    where r_i are 1-based ranks of actives in a score-decreasing list and the
    denominator is the expected numerator value for a uniformly random ranking.
    """
    y = np.asarray(ranked_labels, dtype=np.int64)
    N = y.size
    n_a = int(y.sum())
    if n_a == 0:
        return float("nan")
    ranks = np.arange(1, N + 1, dtype=np.float64)
    sum_exp = float(np.exp(-alpha * ranks[y == 1] / N).sum())
    rie_top = sum_exp / n_a
    rand = (1.0 / N) * (1.0 - np.exp(-alpha)) / (np.exp(alpha / N) - 1.0)
    return float(rie_top / rand)


def bedroc(ranked_labels: np.ndarray, alpha: float = 20.0) -> float:
    """Boltzmann-Enhanced Discrimination of ROC (Truchon & Bayly 2007 eq. 36).

    Bounded in [0, 1]; ``alpha=20`` weights roughly the top 8% of the database.
    Implementation matches ``rdkit.ML.Scoring.CalcBEDROC`` (RIE-based).
    """
    y = np.asarray(ranked_labels, dtype=np.int64)
    N = y.size
    n_a = int(y.sum())
    if n_a == 0 or n_a == N:
        return float("nan")
    Ra = n_a / N
    rie_val = rie(y, alpha=alpha)
    rie_max = (1.0 - np.exp(-alpha * Ra)) / (Ra * (1.0 - np.exp(-alpha)))
    rie_min = (1.0 - np.exp(alpha * Ra)) / (Ra * (1.0 - np.exp(alpha)))
    if rie_max == rie_min:
        return 1.0
    return float((rie_val - rie_min) / (rie_max - rie_min))


# ---------------------------------------------------------------------------
# Aggregation helpers


def average_per_target_metric(per_target: Dict[str, Iterable[float]], name: str = "") -> float:
    """Mean of the per-target metric values (ignores NaNs)."""
    vals = []
    for v in per_target.values():
        arr = np.asarray(list(v), dtype=np.float64)
        arr = arr[~np.isnan(arr)]
        if arr.size:
            vals.append(arr.mean())
    if not vals:
        return float("nan")
    return float(np.mean(vals))


def summarize_repetitions(repetition_results: Sequence[Dict[str, float]]) -> Dict[str, float]:
    """Mean +/- std of each metric over repetitions."""
    if not repetition_results:
        return {}
    keys = sorted({k for d in repetition_results for k in d})
    out: Dict[str, float] = {}
    for k in keys:
        vals = np.array(
            [d[k] for d in repetition_results if k in d and d[k] == d[k]], dtype=np.float64
        )
        if vals.size == 0:
            out[k + "_mean"] = float("nan")
            out[k + "_std"] = float("nan")
        else:
            out[k + "_mean"] = float(vals.mean())
            out[k + "_std"] = float(vals.std(ddof=1)) if vals.size > 1 else 0.0
    return out


def metric_table_for_fingerprints(
    fp_to_metrics: Dict[str, Dict[str, Dict[str, float]]],
) -> pd.DataFrame:
    """Flatten ``{fp -> {target -> {metric -> value}}}`` into a long-form table."""
    rows = []
    for fp, per_target in fp_to_metrics.items():
        for tgt, mets in per_target.items():
            row = {"fingerprint": fp, "target": tgt}
            row.update(mets)
            rows.append(row)
    return pd.DataFrame(rows)


def average_rank_table(
    metric_table: pd.DataFrame,
    metrics: Sequence[str],
    method_col: str = "fingerprint",
    group_col: str = "target",
    ascending: bool = False,
) -> pd.DataFrame:
    """Average rank of each method per evaluation metric (Friedman-style).

    For every ``metric`` the values are first aggregated by mean within each
    ``(group_col, method_col)`` cell — so any repetition rows in
    ``metric_table`` are averaged per (target, fingerprint) first — then the
    methods are ranked within each ``group_col`` value (e.g. each target), and
    finally those ranks are averaged across groups so that rank 1 is best
    (``ascending=False`` means a larger metric value is better and gets rank 1).

    Returns a DataFrame indexed by method (``method_col``) with one column per
    metric, ready to hand straight to
    :func:`tools.plotting.plot_fingerprint_average_rank`.
    """
    out = {}
    for metric in metrics:
        # mean over repetitions / rows for each (method, group)
        pivot = metric_table.pivot_table(
            index=group_col, columns=method_col, values=metric, aggfunc="mean"
        )
        # rank methods within each group; rank 1 = best
        ranks = pivot.rank(axis=1, ascending=ascending, method="average")
        out[metric] = ranks.mean(axis=0)
    rank_df = pd.DataFrame(out)
    return rank_df

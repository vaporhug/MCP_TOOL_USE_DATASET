"""Similarity scoring for ligand-based virtual screening.

Functions
---------
tanimoto_pair(a_bits, b_bits)               -> float
tanimoto_matrix(query_fps, db_fps)          -> np.ndarray (n_queries, n_db)
score_max_similarity(query_fps, db_fps)     -> np.ndarray (n_db,)   max over queries
score_mean_similarity(query_fps, db_fps)    -> np.ndarray (n_db,)
score_sum_similarity(query_fps, db_fps)     -> np.ndarray (n_db,)
score_data_fusion(query_fps, db_fps, method='max') -> np.ndarray (n_db,)
rank_by_score(scores, descending=True)      -> np.ndarray (argsort indices)
similarity_screening(query_fps, db_fps, fusion='max') -> dict {scores, rank, rank_of_actives}
"""
from __future__ import annotations

from typing import Optional, Sequence

import numpy as np


# ---------------------------------------------------------------------------
# Tanimoto on bit vectors stored as (n, n_bits) np.uint8 arrays


def tanimoto_pair(a_bits: np.ndarray, b_bits: np.ndarray) -> float:
    """Tanimoto similarity of two feature vectors.

    For binary 0/1 inputs this is the classic Jaccard.  For count / real
    vectors it is the min-max formulation: ``sum(min(a,b)) / sum(max(a,b))``.
    """
    a = np.asarray(a_bits)
    b = np.asarray(b_bits)
    if (
        np.issubdtype(a.dtype, np.integer)
        and np.issubdtype(b.dtype, np.integer)
        and a.max(initial=0) <= 1
        and b.max(initial=0) <= 1
    ):
        inter = int(np.bitwise_and(a.astype(np.uint8), b.astype(np.uint8)).sum())
        union = int(np.bitwise_or(a.astype(np.uint8), b.astype(np.uint8)).sum())
        if union == 0:
            return 0.0
        return inter / union
    af = a.astype(np.float64)
    bf = b.astype(np.float64)
    mn = float(np.minimum(af, bf).sum())
    mx = float(np.maximum(af, bf).sum())
    if mx == 0:
        return 0.0
    return mn / mx


def tanimoto_matrix(query_fps: np.ndarray, db_fps: np.ndarray) -> np.ndarray:
    """Pairwise Tanimoto between every query and every database molecule.

    For binary (0/1) inputs this is the classic Jaccard/Tanimoto on bit
    vectors.  For non-binary count or real-valued inputs the continuous
    extension (Tversky/Tanimoto on counts) is used::

        T(q, d) = sum(min(q, d)) / sum(max(q, d))

    Both inputs must be (rows, n_features) arrays with the same number of
    columns.  Computed in dense matrix form for speed.
    """
    Q = np.asarray(query_fps)
    D = np.asarray(db_fps)
    if Q.ndim == 1:
        Q = Q[None, :]
    if D.ndim == 1:
        D = D[None, :]
    if Q.shape[1] != D.shape[1]:
        raise ValueError(f"feature vector size mismatch {Q.shape[1]} vs {D.shape[1]}")
    is_binary = (
        np.issubdtype(Q.dtype, np.integer)
        and np.issubdtype(D.dtype, np.integer)
        and Q.max(initial=0) <= 1
        and D.max(initial=0) <= 1
    )
    if is_binary:
        Qf = Q.astype(np.float32)
        Df = D.astype(np.float32)
        qpop = Qf.sum(axis=1, keepdims=True)
        dpop = Df.sum(axis=1, keepdims=True)
        inter = Qf @ Df.T
        union = qpop + dpop.T - inter
    else:
        Qf = Q.astype(np.float64)
        Df = D.astype(np.float64)
        # min(q, d) sum and max(q, d) sum
        nq, nd = Qf.shape[0], Df.shape[0]
        sim = np.zeros((nq, nd), dtype=np.float64)
        for i in range(nq):
            mn = np.minimum(Qf[i][None, :], Df).sum(axis=1)
            mx = np.maximum(Qf[i][None, :], Df).sum(axis=1)
            sim[i] = np.where(mx > 0, mn / np.maximum(mx, 1e-12), 0.0)
        return sim.astype(np.float32)
    sim = np.where(union > 0, inter / np.maximum(union, 1e-12), 0.0)
    return sim.astype(np.float32)


# ---------------------------------------------------------------------------
# Score aggregation across queries (data fusion)


def score_max_similarity(query_fps: np.ndarray, db_fps: np.ndarray) -> np.ndarray:
    """Max Tanimoto over the query set: classic similarity-search score."""
    return tanimoto_matrix(query_fps, db_fps).max(axis=0)


def score_mean_similarity(query_fps: np.ndarray, db_fps: np.ndarray) -> np.ndarray:
    """Mean Tanimoto over the query set."""
    return tanimoto_matrix(query_fps, db_fps).mean(axis=0)


def score_sum_similarity(query_fps: np.ndarray, db_fps: np.ndarray) -> np.ndarray:
    """Sum Tanimoto over the query set (rank-equivalent to mean)."""
    return tanimoto_matrix(query_fps, db_fps).sum(axis=0)


def score_data_fusion(query_fps: np.ndarray, db_fps: np.ndarray, method: str = "max") -> np.ndarray:
    """Dispatch helper: ``method`` in {"max", "mean", "sum"}."""
    method = method.lower()
    if method == "max":
        return score_max_similarity(query_fps, db_fps)
    if method == "mean":
        return score_mean_similarity(query_fps, db_fps)
    if method == "sum":
        return score_sum_similarity(query_fps, db_fps)
    raise ValueError(f"unknown fusion method {method!r}")


# ---------------------------------------------------------------------------
# Ranking utilities


def rank_by_score(scores: np.ndarray, descending: bool = True) -> np.ndarray:
    """Return indices that would sort ``scores`` (descending = highest first)."""
    s = np.asarray(scores, dtype=np.float64)
    if descending:
        return np.argsort(-s, kind="mergesort")
    return np.argsort(s, kind="mergesort")


def similarity_screening(
    query_fps: np.ndarray,
    db_fps: np.ndarray,
    db_labels: Optional[Sequence[int]] = None,
    fusion: str = "max",
) -> dict:
    """Run similarity screening and return ``{scores, rank, rank_of_actives}``."""
    scores = score_data_fusion(query_fps, db_fps, method=fusion)
    rank = rank_by_score(scores, descending=True)
    out = {"scores": scores, "rank": rank}
    if db_labels is not None:
        labels = np.asarray(db_labels, dtype=np.int64)
        ranked_labels = labels[rank]
        active_positions = np.where(ranked_labels == 1)[0]  # 0-based ranks of actives
        out["rank_of_actives"] = active_positions
        out["n_actives"] = int(labels.sum())
        out["n_db"] = int(labels.size)
    return out

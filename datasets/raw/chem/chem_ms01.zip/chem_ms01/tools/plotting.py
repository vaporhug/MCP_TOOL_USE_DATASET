"""Plot helpers. Each ``plot_*`` returns ``{"path": output_path}``.

Figures use matplotlib's Agg backend so they work headless. Pass an
``output_path`` ending in ``.png``; intermediate directories are created.
"""

from __future__ import annotations

import os
from typing import Sequence

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def _ensure_dir(path: str) -> None:
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)


def plot_score_histogram(
    scores_dict: dict,
    output_path: str,
    *,
    title: str = "Similarity score distribution",
    bins: int = 30,
) -> dict:
    """Histogram of similarity scores per metric (overlaid)."""
    _ensure_dir(output_path)
    fig, ax = plt.subplots(figsize=(7, 4.5))
    colors = ["#2c7fb8", "#d95f02", "#1b9e77", "#7570b3"]
    for i, (name, s) in enumerate(scores_dict.items()):
        s_flat = np.asarray(s).ravel()
        s_flat = s_flat[s_flat > 0]
        if not s_flat.size:
            continue
        ax.hist(s_flat, bins=bins, alpha=0.55, label=name, color=colors[i % len(colors)],
                edgecolor="black", linewidth=0.4)
    ax.set_xlabel("similarity score")
    ax.set_ylabel("frequency")
    ax.set_title(title)
    ax.legend()
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path}


def plot_score_distribution_split(
    distribution: dict,
    output_path: str,
    *,
    title: str = "Same-compound vs different-compound score distribution",
    bins: int = 25,
) -> dict:
    """Two-panel histogram: same-compound vs different-compound similarity scores."""
    _ensure_dir(output_path)
    fig, axes = plt.subplots(1, 2, figsize=(10, 4))
    same = np.asarray(distribution.get("same", []))
    diff = np.asarray(distribution.get("different", []))
    if same.size:
        axes[0].hist(same, bins=bins, color="#1b9e77", edgecolor="black", linewidth=0.4)
    axes[0].set_title(f"same planar InChIKey (n={same.size})")
    axes[0].set_xlabel("score"); axes[0].set_ylabel("count")
    if diff.size:
        axes[1].hist(diff, bins=bins, color="#d95f02", edgecolor="black", linewidth=0.4)
    axes[1].set_title(f"different compound (n={diff.size})")
    axes[1].set_xlabel("score"); axes[1].set_ylabel("count")
    fig.suptitle(title)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path}


def plot_topk_accuracy(
    comparison: dict,
    output_path: str,
    *,
    title: str = "Top-k accuracy by similarity metric",
) -> dict:
    """Bar chart of accuracy@k for each metric."""
    _ensure_dir(output_path)
    fig, ax = plt.subplots(figsize=(8, 4.8))
    metrics = list(comparison.keys())
    if not metrics:
        plt.close(fig)
        return {"path": output_path}
    K = len(comparison[metrics[0]]["acc_at_k"])
    width = 0.8 / max(1, len(metrics))
    x = np.arange(K)
    colors = ["#2c7fb8", "#d95f02", "#1b9e77", "#7570b3"]
    for i, m in enumerate(metrics):
        ax.bar(x + i * width, comparison[m]["acc_at_k"], width=width, label=m,
               color=colors[i % len(colors)], edgecolor="black", linewidth=0.4)
    ax.set_xticks(x + width * (len(metrics) - 1) / 2)
    ax.set_xticklabels([f"@{k+1}" for k in range(K)])
    ax.set_ylabel("accuracy")
    ax.set_ylim(0, 1)
    ax.set_title(title)
    ax.legend()
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path}


def plot_mrr_bar(
    comparison: dict,
    output_path: str,
    *,
    title: str = "Mean reciprocal rank by metric",
) -> dict:
    """Bar chart of MRR for each metric."""
    _ensure_dir(output_path)
    fig, ax = plt.subplots(figsize=(6, 4))
    metrics = list(comparison.keys())
    mrrs = [comparison[m]["mrr"] for m in metrics]
    ax.bar(metrics, mrrs, color="#7570b3", edgecolor="black", linewidth=0.4)
    for i, v in enumerate(mrrs):
        ax.text(i, v + 0.01, f"{v:.3f}", ha="center", va="bottom", fontsize=10)
    ax.set_ylabel("MRR")
    ax.set_ylim(0, max(0.05, max(mrrs) * 1.2 if mrrs else 0.05))
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path}


def plot_score_matrix(
    score_matrix: np.ndarray,
    output_path: str,
    *,
    title: str = "Pairwise similarity matrix",
    cmap: str = "viridis",
) -> dict:
    """Heatmap of a pairwise score matrix (rows = queries, cols = library)."""
    _ensure_dir(output_path)
    fig, ax = plt.subplots(figsize=(8, 6))
    im = ax.imshow(score_matrix, aspect="auto", cmap=cmap, vmin=0, vmax=1, interpolation="nearest")
    ax.set_xlabel("library index")
    ax.set_ylabel("query index")
    ax.set_title(title)
    fig.colorbar(im, ax=ax, label="similarity")
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path}


def plot_fragment_match_panel(
    spec_q: dict,
    spec_r: dict,
    matched_pairs: list[tuple[int, int, float]],
    output_path: str,
    *,
    title: str = "Mirror plot of query vs library spectrum",
) -> dict:
    """Mirror plot: query above (positive intensity) and library below (negative).

    matched_pairs: list of (i, j, weight) returned by similarity._greedy_align.
    """
    _ensure_dir(output_path)
    import numpy as np
    fig, ax = plt.subplots(figsize=(9, 5))
    qmz = np.asarray(spec_q["mz"]); qin = np.asarray(spec_q["intensity"])
    rmz = np.asarray(spec_r["mz"]); rin = np.asarray(spec_r["intensity"])
    if qin.max() > 0:
        qin = qin / qin.max()
    if rin.max() > 0:
        rin = rin / rin.max()
    ax.vlines(qmz, 0, qin, colors="#2c7fb8", linewidth=1.2, label="query")
    ax.vlines(rmz, 0, -rin, colors="#d95f02", linewidth=1.2, label="library")
    matched_q = set(p[0] for p in matched_pairs)
    matched_r = set(p[1] for p in matched_pairs)
    if matched_q:
        ax.scatter(qmz[list(matched_q)], qin[list(matched_q)], color="black", s=18, zorder=3,
                   label="matched")
    if matched_r:
        ax.scatter(rmz[list(matched_r)], -rin[list(matched_r)], color="black", s=18, zorder=3)
    ax.axhline(0, color="grey", linewidth=0.5)
    ax.set_xlabel("m/z")
    ax.set_ylabel("relative intensity")
    ax.set_title(title)
    ax.legend(loc="lower right")
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path}


def plot_tpr_fpr_curve(
    curves: dict,
    output_path: str,
    *,
    title: str = "TPR vs FPR for library matching",
) -> dict:
    """ROC-style true vs false positive rate curves at varying similarity thresholds.

    Curves: dict mapping metric name -> {"tpr": array, "fpr": array, "thresholds": array}.
    """
    _ensure_dir(output_path)
    fig, ax = plt.subplots(figsize=(7, 5))
    colors = ["#2c7fb8", "#d95f02", "#1b9e77", "#7570b3"]
    for i, (name, curve) in enumerate(curves.items()):
        ax.plot(curve["fpr"], curve["tpr"], "o-", color=colors[i % len(colors)],
                label=name, markersize=4, linewidth=1.5)
    ax.set_xlabel("false positive rate")
    ax.set_ylabel("true positive rate")
    ax.set_xlim(0, max(0.05, max((c["fpr"].max() if len(c["fpr"]) else 0) for c in curves.values()) * 1.1))
    ax.set_ylim(0, 1)
    ax.set_title(title)
    ax.legend()
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path}


def plot_metric_summary(
    rows: Sequence[dict],
    output_path: str,
    *,
    title: str = "Library matching summary by metric",
) -> dict:
    """Grouped bar chart from a list of rows produced by ``library_matching.summary_table``."""
    _ensure_dir(output_path)
    fig, ax = plt.subplots(figsize=(8, 4.8))
    metrics = [r["metric"] for r in rows]
    cols = ["acc_at_1", "acc_at_5", "acc_at_10", "mrr"]
    x = np.arange(len(metrics))
    width = 0.18
    colors = ["#2c7fb8", "#d95f02", "#1b9e77", "#7570b3"]
    for i, c in enumerate(cols):
        vals = [r.get(c, 0.0) for r in rows]
        ax.bar(x + (i - 1.5) * width, vals, width=width, label=c,
               color=colors[i], edgecolor="black", linewidth=0.4)
    ax.set_xticks(x)
    ax.set_xticklabels(metrics)
    ax.set_ylim(0, 1)
    ax.set_ylabel("score")
    ax.set_title(title)
    ax.legend()
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path}

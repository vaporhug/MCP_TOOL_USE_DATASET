"""Loaders for MS/MS spectra in MGF format and metadata extraction utilities.

A spectrum is represented as a dict with keys:
    mz       : 1-D numpy array of fragment m/z values, ascending.
    intensity: 1-D numpy array of fragment intensities, same length as mz.
    metadata : dict with at least precursor_mz, charge, ion_mode and any of
               name, smiles, inchi, inchikey, adduct, spectrum_id, organism.

This module deliberately avoids any third-party MS library so that the agent
sees a transparent text parser and can extend it.
"""

from __future__ import annotations

import os
import re
from typing import Iterable

import numpy as np

_HEADER_RE = re.compile(r"^([A-Za-z0-9_]+)=(.*)$")
_PEAK_RE = re.compile(r"^\s*([0-9]+\.?[0-9]*(?:[eE][+\-]?[0-9]+)?)[\s,;\t]+([0-9]+\.?[0-9]*(?:[eE][+\-]?[0-9]+)?)\s*$")


def parse_mgf(path: str) -> list[dict]:
    """Parse an MGF file into a list of spectrum dicts.

    Each ``BEGIN IONS .. END IONS`` block becomes one entry. Header lines of the
    form ``KEY=value`` populate the metadata dict (keys lowercased). Numeric
    pairs become the peak list.
    """
    spectra: list[dict] = []
    cur_meta: dict = {}
    cur_mz: list[float] = []
    cur_in: list[float] = []
    in_block = False
    with open(path, "r", encoding="utf-8", errors="ignore") as fh:
        for raw in fh:
            line = raw.strip()
            if not line:
                continue
            if line.upper() == "BEGIN IONS":
                in_block = True
                cur_meta, cur_mz, cur_in = {}, [], []
                continue
            if line.upper() == "END IONS":
                if cur_mz:
                    order = np.argsort(np.asarray(cur_mz))
                    spec = {
                        "mz": np.asarray(cur_mz, dtype=float)[order],
                        "intensity": np.asarray(cur_in, dtype=float)[order],
                        "metadata": _normalize_metadata(cur_meta),
                    }
                    spectra.append(spec)
                in_block = False
                continue
            if not in_block:
                continue
            m = _HEADER_RE.match(line)
            if m:
                key, val = m.group(1).lower(), m.group(2).strip()
                cur_meta[key] = val
                continue
            m = _PEAK_RE.match(line)
            if m:
                cur_mz.append(float(m.group(1)))
                cur_in.append(float(m.group(2)))
    return spectra


def _normalize_metadata(meta: dict) -> dict:
    """Coerce frequent header fields to standard names and types."""
    out = dict(meta)
    # Precursor m/z
    pmz = meta.get("pepmass") or meta.get("precursor_mz") or meta.get("precursormz")
    if pmz is not None:
        try:
            out["precursor_mz"] = float(str(pmz).split()[0])
        except Exception:
            pass
    # Parent mass for cosine-shifted scores
    if "parent_mass" in meta:
        try:
            out["parent_mass"] = float(meta["parent_mass"])
        except Exception:
            pass
    # Charge
    ch = meta.get("charge")
    if ch is not None:
        m = re.match(r"([+-]?\d+)", str(ch))
        if m:
            out["charge"] = int(m.group(1))
    # Ion mode
    im = meta.get("ionmode") or meta.get("ion_mode")
    if im:
        out["ion_mode"] = im.lower()
    # Compound name
    nm = meta.get("name") or meta.get("compound_name")
    if nm:
        out["name"] = nm
    # If InChIKey is missing but InChI is present, derive a stable hash-based
    # 14-character key from the InChI's connectivity layer so that downstream
    # planar-key matching still works.
    if not out.get("inchikey") and out.get("inchi"):
        out["inchikey"] = compound_key_from_inchi(out["inchi"])
    return out


def compound_key_from_inchi(inchi: str) -> str:
    """Return a deterministic 14-character planar key derived from an InChI.

    Uses the connectivity layer (the part after the first ``/c`` block, up to
    the next ``/`` or end of string). This mimics the 14-character planar
    InChIKey used in the Spec2Vec paper but does not require RDKit.
    """
    import hashlib
    if not inchi:
        return ""
    # Strip any leading ``InChI=`` and ``1S/``
    s = inchi
    if s.startswith("InChI="):
        s = s[len("InChI="):]
    # Use whole formula + connectivity layer up to the H-atom layer
    # The layers are separated by '/'. Take formula (1st), connectivity (after /c).
    parts = s.split("/")
    base = ""
    for p in parts[:4]:  # formula and first 2-3 layers should suffice
        if p.startswith("h") or p.startswith("p") or p.startswith("q") or p.startswith("t"):
            break
        base += p + "/"
    h = hashlib.sha1(base.encode("utf-8")).hexdigest().upper()
    return h[:14]


def load_mgf(path: str) -> list[dict]:
    """Load an MGF file. Thin alias for :func:`parse_mgf`."""
    return parse_mgf(path)


def filter_spectra(
    spectra: Iterable[dict],
    *,
    min_peaks: int = 5,
    require_keys: tuple[str, ...] = ("precursor_mz",),
    ion_mode: str | None = None,
) -> list[dict]:
    """Keep spectra with at least ``min_peaks`` peaks and required metadata."""
    out = []
    for s in spectra:
        if len(s["mz"]) < min_peaks:
            continue
        meta = s["metadata"]
        if any(k not in meta for k in require_keys):
            continue
        if ion_mode and meta.get("ion_mode", "").lower() != ion_mode.lower():
            continue
        out.append(s)
    return out


def split_query_library(
    spectra: list[dict],
    n_query_inchikeys: int = 25,
    seed: int = 0,
) -> tuple[list[dict], list[dict]]:
    """Hold out N InChIKey planar groups (first 14 chars) for queries.

    All spectra of the chosen InChIKey go to the query set. The library still
    contains spectra of the same InChIKey (different adducts / repeats) so this
    mimics the paper's library matching evaluation.
    """
    rng = np.random.default_rng(seed)
    keys: dict[str, list[int]] = {}
    for i, s in enumerate(spectra):
        ik = s["metadata"].get("inchikey", "")
        if not ik:
            continue
        planar = ik[:14]
        keys.setdefault(planar, []).append(i)
    planar_keys = sorted([k for k, v in keys.items() if len(v) >= 2])
    if len(planar_keys) <= n_query_inchikeys:
        chosen = planar_keys
    else:
        idx = rng.choice(len(planar_keys), size=n_query_inchikeys, replace=False)
        chosen = [planar_keys[i] for i in sorted(idx)]
    query_idx: list[int] = []
    for ck in chosen:
        # take 1 spectrum from each chosen key as query
        query_idx.append(keys[ck][0])
    qset = set(query_idx)
    queries = [spectra[i] for i in sorted(qset)]
    library = [spectra[i] for i in range(len(spectra)) if i not in qset]
    return queries, library


def summarize_dataset(spectra: list[dict]) -> dict:
    """Return summary statistics: count, ion mode counts, peak count distribution."""
    n = len(spectra)
    npeaks = np.asarray([len(s["mz"]) for s in spectra])
    ions = {}
    for s in spectra:
        m = s["metadata"].get("ion_mode", "?")
        ions[m] = ions.get(m, 0) + 1
    pms = np.asarray([s["metadata"].get("precursor_mz", np.nan) for s in spectra])
    inchis = sum(1 for s in spectra if s["metadata"].get("inchi"))
    return {
        "n_spectra": int(n),
        "ion_mode_counts": ions,
        "n_peaks_mean": float(npeaks.mean()) if n else 0.0,
        "n_peaks_median": float(np.median(npeaks)) if n else 0.0,
        "n_peaks_min": int(npeaks.min()) if n else 0,
        "n_peaks_max": int(npeaks.max()) if n else 0,
        "precursor_mz_mean": float(np.nanmean(pms)) if n else 0.0,
        "precursor_mz_min": float(np.nanmin(pms)) if n else 0.0,
        "precursor_mz_max": float(np.nanmax(pms)) if n else 0.0,
        "n_with_inchi": int(inchis),
    }


def write_csv_table(rows: list[dict], path: str, columns: list[str] | None = None) -> dict:
    """Write a list of dicts as CSV. Returns ``{"path": ..., "n_rows": ...}``."""
    import csv
    if not rows:
        cols = columns or []
    else:
        cols = columns or list(rows[0].keys())
    os.makedirs(os.path.dirname(path), exist_ok=True) if os.path.dirname(path) else None
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow(r)
    return {"path": path, "n_rows": len(rows)}

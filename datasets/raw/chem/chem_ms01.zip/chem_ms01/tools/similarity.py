"""Spectral similarity scores: cosine, modified cosine, neutral-loss cosine, entropy.

Implementations are written in pure NumPy for transparency and follow the
greedy-alignment convention used by published packages: each peak in the query
is matched at most once with the closest library peak within ``tolerance``.

Returned object: ``{"score": float, "matches": int}``.
"""

from __future__ import annotations

from typing import Sequence

import numpy as np

from .preprocessing import neutral_loss_spectrum, normalize_max


def _greedy_align(
    mz_a: np.ndarray, in_a: np.ndarray,
    mz_b: np.ndarray, in_b: np.ndarray,
    tolerance: float,
    shift: float = 0.0,
) -> list[tuple[int, int, float]]:
    """Greedy peak alignment.

    Returns list of (i, j, weight) where weight = in_a[i] * in_b[j].
    ``shift`` is added to ``mz_a`` before matching (used by modified cosine).
    """
    if len(mz_a) == 0 or len(mz_b) == 0:
        return []
    a = mz_a + shift
    b = mz_b
    # Build candidate pairs sorted by descending product intensity.
    cands: list[tuple[float, int, int]] = []
    j_start = 0
    for i in range(len(a)):
        # advance j_start
        while j_start < len(b) and b[j_start] < a[i] - tolerance:
            j_start += 1
        j = j_start
        while j < len(b) and b[j] <= a[i] + tolerance:
            cands.append((float(in_a[i] * in_b[j]), i, j))
            j += 1
    cands.sort(reverse=True)
    used_a: set[int] = set()
    used_b: set[int] = set()
    matched: list[tuple[int, int, float]] = []
    for w, i, j in cands:
        if i in used_a or j in used_b:
            continue
        used_a.add(i)
        used_b.add(j)
        matched.append((i, j, w))
    return matched


def _norm(intensity: np.ndarray) -> float:
    return float(np.sqrt(np.sum(intensity * intensity)))


def cosine_similarity(spec_a: dict, spec_b: dict, *, tolerance: float = 0.005, min_match: int = 1) -> dict:
    """Cosine score between two spectra (greedy alignment, max-normalised input).

    Spec2Vec paper (Methods, p.15) uses tolerance=0.005 Da, min_match=6.
    """
    a = normalize_max(spec_a)
    b = normalize_max(spec_b)
    matched = _greedy_align(a["mz"], a["intensity"], b["mz"], b["intensity"], tolerance, 0.0)
    n_match = len(matched)
    if n_match < min_match:
        return {"score": 0.0, "matches": int(n_match)}
    num = sum(w for _, _, w in matched)
    denom = _norm(a["intensity"]) * _norm(b["intensity"]) + 1e-12
    return {"score": float(num / denom), "matches": int(n_match)}


def modified_cosine(spec_a: dict, spec_b: dict, *, tolerance: float = 0.005, min_match: int = 1) -> dict:
    """Modified cosine: combine matches at m/z and at m/z + delta_precursor.

    Each peak can be matched in either its original or shifted form, never
    both. Used for analog search where two related molecules differ by a small
    mass shift in the precursor (Watrous et al. 2012, Spec2Vec paper Methods).
    """
    a = normalize_max(spec_a)
    b = normalize_max(spec_b)
    pa = float(a["metadata"].get("precursor_mz", 0.0))
    pb = float(b["metadata"].get("precursor_mz", 0.0))
    delta = pa - pb
    direct = _greedy_align(a["mz"], a["intensity"], b["mz"], b["intensity"], tolerance, 0.0)
    shifted = _greedy_align(a["mz"], a["intensity"], b["mz"], b["intensity"], tolerance, -delta)
    used_a: set[int] = set()
    used_b: set[int] = set()
    pool = [(w, i, j, "d") for i, j, w in direct] + [(w, i, j, "s") for i, j, w in shifted]
    pool.sort(reverse=True)
    matched: list[tuple[int, int, float]] = []
    for w, i, j, _kind in pool:
        if i in used_a or j in used_b:
            continue
        used_a.add(i)
        used_b.add(j)
        matched.append((i, j, w))
    n_match = len(matched)
    if n_match < min_match:
        return {"score": 0.0, "matches": int(n_match)}
    num = sum(w for _, _, w in matched)
    denom = _norm(a["intensity"]) * _norm(b["intensity"]) + 1e-12
    return {"score": float(num / denom), "matches": int(n_match)}


def neutral_loss_cosine(spec_a: dict, spec_b: dict, *, tolerance: float = 0.005, min_match: int = 1, max_loss: float = 200.0) -> dict:
    """Cosine score on neutral-loss spectra (precursor_mz - peak_mz)."""
    nl_a = neutral_loss_spectrum(spec_a, max_loss=max_loss)
    nl_b = neutral_loss_spectrum(spec_b, max_loss=max_loss)
    return cosine_similarity(nl_a, nl_b, tolerance=tolerance, min_match=min_match)


def spectral_entropy(spec: dict) -> float:
    """Shannon entropy of an intensity distribution (sum-normalised).

    Useful as a per-spectrum complexity descriptor and as a building block of
    the Li 2021 entropy similarity (computed via :func:`entropy_similarity`).
    """
    if len(spec["intensity"]) == 0:
        return 0.0
    p = np.asarray(spec["intensity"], dtype=float)
    s = p.sum()
    if s <= 0.0:
        return 0.0
    p = p / s
    p = p[p > 0]
    return float(-np.sum(p * np.log(p)))


def _bin_to_grid(spec: dict, tolerance: float) -> tuple[np.ndarray, np.ndarray]:
    """Bin a spectrum onto a shared m/z grid for vector-style ops."""
    if len(spec["mz"]) == 0:
        return np.array([]), np.array([])
    keys = np.round(spec["mz"] / tolerance).astype(int)
    uniq, inv = np.unique(keys, return_inverse=True)
    out = np.zeros_like(uniq, dtype=float)
    for k, w in zip(inv, spec["intensity"]):
        out[k] += float(w)
    return uniq * tolerance, out


def entropy_similarity(spec_a: dict, spec_b: dict, *, tolerance: float = 0.05) -> dict:
    """Spectral entropy similarity (Li, Fiehn et al. 2021 Nat. Methods).

    Both spectra are sum-normalised, summed onto a shared binned grid, and
    the entropy increase relative to the average of the two original entropies
    yields a similarity in [0, 1] where 1 means identical.
    """
    a_mz, a_in = _bin_to_grid(spec_a, tolerance)
    b_mz, b_in = _bin_to_grid(spec_b, tolerance)
    if a_in.size == 0 or b_in.size == 0:
        return {"score": 0.0, "matches": 0}
    if a_in.sum() > 0:
        a_in = a_in / a_in.sum()
    if b_in.sum() > 0:
        b_in = b_in / b_in.sum()
    # Merge onto common grid
    keys = np.unique(np.concatenate([a_mz, b_mz]))
    pa = np.zeros_like(keys, dtype=float)
    pb = np.zeros_like(keys, dtype=float)
    for k, w in zip(a_mz, a_in):
        pa[np.searchsorted(keys, k)] = w
    for k, w in zip(b_mz, b_in):
        pb[np.searchsorted(keys, k)] = w
    pm = (pa + pb) / 2.0
    def _h(p):
        p = p[p > 0]
        return float(-np.sum(p * np.log(p)))
    h_a = _h(pa); h_b = _h(pb); h_m = _h(pm)
    inc = 2.0 * h_m - h_a - h_b   # in [0, log 2]
    sim = 1.0 - inc / np.log(2.0)
    matches = int(np.sum((pa > 0) & (pb > 0)))
    return {"score": float(max(0.0, min(1.0, sim))), "matches": matches}


def pairwise_score_matrix(
    queries: Sequence[dict],
    references: Sequence[dict],
    metric: str = "cosine",
    *,
    tolerance: float = 0.005,
    min_match: int = 1,
) -> dict:
    """Compute a Q x R score matrix between two lists of spectra.

    metric: ``"cosine"``, ``"modified_cosine"``, ``"neutral_loss"``, ``"entropy"``.
    Returns ``{"scores": ndarray, "matches": ndarray}``.
    """
    nq, nr = len(queries), len(references)
    S = np.zeros((nq, nr), dtype=float)
    M = np.zeros((nq, nr), dtype=int)
    fn = {
        "cosine": cosine_similarity,
        "modified_cosine": modified_cosine,
        "neutral_loss": neutral_loss_cosine,
        "entropy": entropy_similarity,
    }[metric]
    for i, q in enumerate(queries):
        for j, r in enumerate(references):
            if metric == "entropy":
                out = fn(q, r, tolerance=max(tolerance, 0.01))
            else:
                out = fn(q, r, tolerance=tolerance, min_match=min_match)
            S[i, j] = out["score"]
            M[i, j] = out["matches"]
    return {"scores": S, "matches": M}

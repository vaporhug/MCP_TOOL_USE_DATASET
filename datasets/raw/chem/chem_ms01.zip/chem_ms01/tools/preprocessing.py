"""Peak filtering and intensity normalisation for MS/MS spectra.

Common filters:
    * remove peaks below a minimum relative intensity (de-noising)
    * keep only peaks within an m/z window
    * cap to top-N peaks by intensity
    * neutral-loss spectrum (precursor_mz - peak m/z), discarding non-positive losses
    * intensity normalisation by max, sum, or sqrt-of-max
"""

from __future__ import annotations

from typing import Iterable

import numpy as np


def normalize_max(spec: dict) -> dict:
    """Divide intensities by their maximum so the largest peak == 1."""
    s = _copy_spec(spec)
    if len(s["intensity"]) and np.max(s["intensity"]) > 0:
        s["intensity"] = s["intensity"] / np.max(s["intensity"])
    return s


def normalize_sum(spec: dict) -> dict:
    """Divide intensities by their sum so they form a probability vector."""
    s = _copy_spec(spec)
    tot = float(np.sum(s["intensity"]))
    if tot > 0:
        s["intensity"] = s["intensity"] / tot
    return s


def filter_min_relative_intensity(spec: dict, threshold: float = 0.001) -> dict:
    """Remove peaks whose intensity is < ``threshold`` * max intensity."""
    s = _copy_spec(spec)
    if not len(s["intensity"]):
        return s
    cap = float(np.max(s["intensity"])) * threshold
    keep = s["intensity"] >= cap
    s["mz"] = s["mz"][keep]
    s["intensity"] = s["intensity"][keep]
    return s


def filter_mz_range(spec: dict, mz_min: float = 0.0, mz_max: float = 1000.0) -> dict:
    """Keep only peaks within ``[mz_min, mz_max]``."""
    s = _copy_spec(spec)
    keep = (s["mz"] >= mz_min) & (s["mz"] <= mz_max)
    s["mz"] = s["mz"][keep]
    s["intensity"] = s["intensity"][keep]
    return s


def keep_top_n_peaks(spec: dict, n: int = 50) -> dict:
    """Retain the n most intense peaks (sorted back by m/z)."""
    s = _copy_spec(spec)
    if len(s["intensity"]) <= n:
        return s
    order = np.argsort(s["intensity"])[::-1][:n]
    order = np.sort(order)
    s["mz"] = s["mz"][order]
    s["intensity"] = s["intensity"][order]
    return s


def remove_precursor_peak(spec: dict, tolerance: float = 0.5) -> dict:
    """Remove peaks within +/- tolerance of the precursor m/z."""
    s = _copy_spec(spec)
    pmz = s["metadata"].get("precursor_mz")
    if pmz is None:
        return s
    keep = np.abs(s["mz"] - float(pmz)) > tolerance
    s["mz"] = s["mz"][keep]
    s["intensity"] = s["intensity"][keep]
    return s


def neutral_loss_spectrum(spec: dict, max_loss: float = 200.0) -> dict:
    """Convert a fragment spectrum into a neutral-loss spectrum.

    Each peak m/z is replaced by precursor_mz - m/z; non-positive or
    too-large losses are discarded. Useful for analog-search tasks where
    structurally similar molecules differ by a small chemical modification.
    """
    pmz = spec["metadata"].get("precursor_mz")
    if pmz is None:
        return _copy_spec(spec)
    losses = float(pmz) - spec["mz"]
    keep = (losses > 0.0) & (losses < max_loss)
    s = {
        "mz": losses[keep],
        "intensity": spec["intensity"][keep].copy(),
        "metadata": dict(spec["metadata"]),
    }
    if len(s["mz"]):
        order = np.argsort(s["mz"])
        s["mz"] = s["mz"][order]
        s["intensity"] = s["intensity"][order]
    return s


def sqrt_intensity(spec: dict) -> dict:
    """Replace intensities by their square root (entropy-like weighting)."""
    s = _copy_spec(spec)
    s["intensity"] = np.sqrt(np.maximum(s["intensity"], 0.0))
    return s


def power_intensity(spec: dict, exponent: float = 0.5) -> dict:
    """Replace intensities by intensity^exponent."""
    s = _copy_spec(spec)
    s["intensity"] = np.power(np.maximum(s["intensity"], 0.0), exponent)
    return s


def standard_pipeline(
    spec: dict,
    *,
    mz_min: float = 0.0,
    mz_max: float = 1000.0,
    min_rel: float = 0.001,
    top_n: int | None = None,
    remove_precursor: bool = True,
    precursor_tol: float = 0.5,
    normalize: str = "max",
) -> dict:
    """Apply a typical processing pipeline used by matchms in the Spec2Vec paper."""
    s = filter_mz_range(spec, mz_min, mz_max)
    if remove_precursor:
        s = remove_precursor_peak(s, precursor_tol)
    if normalize == "max":
        s = normalize_max(s)
    s = filter_min_relative_intensity(s, min_rel)
    if top_n is not None:
        s = keep_top_n_peaks(s, top_n)
    if normalize == "sum":
        s = normalize_sum(s)
    return s


def batch_process(spectra: Iterable[dict], **kwargs) -> list[dict]:
    """Apply :func:`standard_pipeline` to a list of spectra."""
    return [standard_pipeline(s, **kwargs) for s in spectra]


def _copy_spec(spec: dict) -> dict:
    return {
        "mz": np.asarray(spec["mz"], dtype=float).copy(),
        "intensity": np.asarray(spec["intensity"], dtype=float).copy(),
        "metadata": dict(spec["metadata"]),
    }

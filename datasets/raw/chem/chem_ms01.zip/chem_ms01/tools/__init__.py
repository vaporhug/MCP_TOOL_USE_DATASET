"""Tools for MS/MS spectrum library matching benchmark.

Submodules:
    data_io: MGF/CSV loaders, spectrum metadata extraction.
    preprocessing: peak filtering, intensity normalization, parent-mass binning.
    similarity: cosine, modified cosine, neutral-loss cosine, spectral entropy.
    library_matching: top-k retrieval, accuracy / MRR / hit-at-K, false-positive rate curves.
    plotting: similarity histograms, top-k bar charts, parity heatmaps, fragment-match panels.
"""

from . import data_io
from . import preprocessing
from . import similarity
from . import library_matching
from . import plotting

__all__ = ["data_io", "preprocessing", "similarity", "library_matching", "plotting"]

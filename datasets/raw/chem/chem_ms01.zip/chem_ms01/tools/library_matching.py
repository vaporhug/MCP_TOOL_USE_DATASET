"""Top-k retrieval, accuracy/MRR scoring, false-positive curves for library matching.

Conventions:
    * A query is correctly matched if any of its top-K library hits has the
      same planar InChIKey (first 14 chars). This is the convention used in
      the Spec2Vec paper (Methods, p.13; Fig 4).
    * A query may be pre-filtered by precursor m/z tolerance against the
      library before scoring (analogous to ``tolerance = 1 ppm`` in Fig 4).
    * MRR is the mean of 1 / rank_of_first_correct, with rank = inf -> 0.
"""

from __future__ import annotations

from typing import Sequence

import numpy as np

from .similarity import pairwise_score_matrix


def planar_inchikey(spec: dict) -> str:
    """Return the first 14 characters of the spectrum's InChIKey (skeleton)."""
    ik = spec["metadata"].get("inchikey", "") or ""
    return ik[:14] if ik else ""


def precursor_filter_index(
    queries: Sequence[dict],
    library: Sequence[dict],
    ppm_tol: float = 1000.0,
) -> list[np.ndarray]:
    """For each query, return indices of library spectra within ppm_tol of precursor m/z."""
    out: list[np.ndarray] = []
    for q in queries:
        pmz = float(q["metadata"].get("precursor_mz", 0.0))
        if pmz <= 0:
            out.append(np.arange(len(library)))
            continue
        tol = pmz * ppm_tol * 1e-6
        cand = np.array([
            j for j, r in enumerate(library)
            if abs(float(r["metadata"].get("precursor_mz", 0.0)) - pmz) <= tol
        ], dtype=int)
        if cand.size == 0:
            cand = np.arange(len(library), dtype=int)
        out.append(cand)
    return out


def topk_retrieval(
    score_matrix: np.ndarray,
    queries: Sequence[dict],
    library: Sequence[dict],
    *,
    k_max: int = 10,
    candidate_idx: list[np.ndarray] | None = None,
) -> dict:
    """Compute top-K hits and accuracy@K for each query.

    Returns dict with:
        * ``ranks`` ndarray (Q,) — rank (1-based) of first correct library hit
          (np.inf if no correct hit found)
        * ``acc_at_k`` ndarray (k_max,) — accuracy@k for k=1..k_max
        * ``mrr``     float
        * ``topk_idx`` ndarray (Q, k_max) — library indices of top-K hits per query
    """
    nq, nr = score_matrix.shape
    K = min(k_max, nr)
    ranks = np.full(nq, np.inf)
    topk_idx = -np.ones((nq, K), dtype=int)
    for i in range(nq):
        if candidate_idx is not None:
            cand = candidate_idx[i]
        else:
            cand = np.arange(nr)
        if cand.size == 0:
            continue
        scores_i = score_matrix[i, cand]
        order = np.argsort(-scores_i)
        cand_sorted = cand[order]
        topk_idx[i, :min(K, cand_sorted.size)] = cand_sorted[:min(K, cand_sorted.size)]
        q_ik = planar_inchikey(queries[i])
        if not q_ik:
            continue
        for rk, j in enumerate(cand_sorted):
            r_ik = planar_inchikey(library[j])
            if r_ik == q_ik and scores_i[order[rk]] > 0:
                ranks[i] = rk + 1
                break
    acc_at_k = np.zeros(K)
    for k in range(K):
        acc_at_k[k] = float(np.mean(ranks <= (k + 1)))
    mrr = float(np.mean(np.where(np.isfinite(ranks), 1.0 / ranks, 0.0)))
    return {
        "ranks": ranks,
        "acc_at_k": acc_at_k,
        "mrr": mrr,
        "topk_idx": topk_idx,
    }


def evaluate_metric(
    metric: str,
    queries: Sequence[dict],
    library: Sequence[dict],
    *,
    tolerance: float = 0.005,
    min_match: int = 1,
    k_max: int = 10,
    ppm_tol_precursor: float | None = None,
) -> dict:
    """Run pairwise scoring + topk retrieval for one similarity metric."""
    pm = pairwise_score_matrix(queries, library, metric=metric, tolerance=tolerance, min_match=min_match)
    cand = None
    if ppm_tol_precursor is not None:
        cand = precursor_filter_index(queries, library, ppm_tol_precursor)
    res = topk_retrieval(pm["scores"], queries, library, k_max=k_max, candidate_idx=cand)
    res.update({
        "scores": pm["scores"],
        "matches": pm["matches"],
        "metric": metric,
    })
    return res


def true_positive_curve(
    score_matrix: np.ndarray,
    queries: Sequence[dict],
    library: Sequence[dict],
    *,
    thresholds: np.ndarray | None = None,
    candidate_idx: list[np.ndarray] | None = None,
) -> dict:
    """Compute (TPR, FPR) curve as a function of similarity threshold.

    Following Fig 4 of the Spec2Vec paper: for each query, take the highest
    scoring library candidate above the threshold; count TP if same planar
    InChIKey, FP otherwise; queries with no candidate above threshold do
    not contribute.
    """
    nq, nr = score_matrix.shape
    if thresholds is None:
        thresholds = np.linspace(0.05, 0.95, 19)
    tprs = []
    fprs = []
    for thr in thresholds:
        tp = 0; fp = 0; n_useful = 0
        for i in range(nq):
            cand = np.arange(nr) if candidate_idx is None else candidate_idx[i]
            if cand.size == 0:
                continue
            si = score_matrix[i, cand]
            j_best = int(np.argmax(si))
            if si[j_best] < thr:
                continue
            n_useful += 1
            if planar_inchikey(library[cand[j_best]]) == planar_inchikey(queries[i]):
                tp += 1
            else:
                fp += 1
        if n_useful == 0:
            tprs.append(0.0); fprs.append(0.0)
        else:
            tprs.append(tp / max(1, nq))
            fprs.append(fp / max(1, nq))
    return {
        "thresholds": np.asarray(thresholds, dtype=float),
        "tpr": np.asarray(tprs, dtype=float),
        "fpr": np.asarray(fprs, dtype=float),
    }


def compute_score_distribution(
    score_matrix: np.ndarray,
    queries: Sequence[dict],
    library: Sequence[dict],
) -> dict:
    """Split off-diagonal scores into 'same-compound' vs 'different-compound' arrays.

    Useful for the histogram comparison from Fig 3 of the Spec2Vec paper.
    """
    same: list[float] = []
    diff: list[float] = []
    for i, q in enumerate(queries):
        qk = planar_inchikey(q)
        for j, r in enumerate(library):
            rk = planar_inchikey(r)
            if not qk or not rk:
                continue
            if qk == rk:
                same.append(float(score_matrix[i, j]))
            else:
                diff.append(float(score_matrix[i, j]))
    return {"same": np.asarray(same), "different": np.asarray(diff)}


def compare_metrics(
    queries: Sequence[dict],
    library: Sequence[dict],
    metrics: Sequence[str] = ("cosine", "modified_cosine", "entropy"),
    *,
    tolerance: float = 0.005,
    min_match: int = 1,
    k_max: int = 10,
    ppm_tol_precursor: float | None = None,
) -> dict:
    """Run :func:`evaluate_metric` for several metrics and tabulate the results."""
    out = {}
    for m in metrics:
        out[m] = evaluate_metric(
            m, queries, library,
            tolerance=tolerance, min_match=min_match, k_max=k_max,
            ppm_tol_precursor=ppm_tol_precursor,
        )
    return out


def summary_table(comparison: dict) -> list[dict]:
    """Build a neat one-row-per-metric summary suitable for CSV export."""
    rows = []
    for m, res in comparison.items():
        a = res["acc_at_k"]
        rows.append({
            "metric": m,
            "acc_at_1": round(float(a[0]), 4) if len(a) >= 1 else 0.0,
            "acc_at_5": round(float(a[min(4, len(a) - 1)]), 4) if len(a) else 0.0,
            "acc_at_10": round(float(a[-1]), 4) if len(a) else 0.0,
            "mrr": round(float(res["mrr"]), 4),
            "n_queries": int(len(res["ranks"])),
            "n_resolved": int(np.sum(np.isfinite(res["ranks"]))),
        })
    return rows

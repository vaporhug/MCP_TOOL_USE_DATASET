"""Kinetics primitives for the neem-oil transesterification task.

Submodules
----------
data_io       : load CSV tables, compute fractional conversion X.
rate_law      : pseudo-first-order, second-order, integrated rate-law fits,
                Michaelis-Menten linear and nonlinear fits, finite-difference
                rate.
arrhenius     : Arrhenius / Eyring linearisation, kinetic isotope effect
                ratio, residual diagnostics.
plotting      : conversion-time, -ln(1-X) vs t, Arrhenius plot, residuals.

All functions return plain dicts / dataframes / arrays.  Plotting functions
return ``{"path": "<absolute-or-relative png path>"}`` and write the file.
"""
from . import data_io, rate_law, arrhenius, plotting  # noqa: F401

"""Matplotlib helpers that write PNG artifacts.

All functions return ``{"path": <png_path>}`` and write the file with
``matplotlib.pyplot.savefig``.  Parameters use sensible defaults so the
agent can call them with one line.
"""
from __future__ import annotations

import os
from typing import Dict, Iterable, Optional, Sequence, Tuple

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def _ensure_dir(path: str) -> None:
    d = os.path.dirname(os.path.abspath(path))
    if d:
        os.makedirs(d, exist_ok=True)


def plot_yield_time_course(
    df: pd.DataFrame,
    output_path: str,
    title: Optional[str] = None,
) -> Dict[str, str]:
    """Plot FAEE yield (%) vs time for every condition in ``df``.

    Expected columns: ``condition``, ``t_min``, ``yield_pct``, ``T_C``.
    Returns ``{"path": output_path}``.
    """
    _ensure_dir(output_path)
    fig, ax = plt.subplots(figsize=(6.5, 4.6))
    markers = ["o", "s", "^", "D", "v", "P"]
    for i, (c, sub) in enumerate(df.groupby("condition")):
        sub = sub.sort_values("t_min")
        ax.plot(
            sub["t_min"], sub["yield_pct"],
            marker=markers[i % len(markers)],
            label=f"Cond {int(c)} ({int(sub['T_C'].iloc[0])} °C)",
        )
    ax.set_xlabel("Reaction time (min)")
    ax.set_ylabel("FAEE yield (%)")
    ax.set_title(title or "Time-course yield profiles")
    ax.grid(alpha=0.3)
    ax.legend()
    fig.tight_layout()
    fig.savefig(output_path, dpi=160)
    plt.close(fig)
    return {"path": output_path}


def plot_pseudo_first_order(
    df: pd.DataFrame,
    fits: Iterable[Dict[str, float]],
    output_path: str,
    title: Optional[str] = None,
) -> Dict[str, str]:
    """Plot ``-ln(1 - X)`` vs t with the linear regression line for each
    fit in ``fits``.

    ``fits`` is an iterable of ``{"condition": int, "k_per_min": float,
    "intercept": float}`` dicts, one per condition.

    Returns ``{"path": output_path}``.
    """
    _ensure_dir(output_path)
    fig, ax = plt.subplots(figsize=(6.5, 4.6))
    fits_list = list(fits)
    fit_by_cond = {int(f["condition"]): f for f in fits_list}
    markers = ["o", "s", "^", "D", "v", "P"]
    for i, (c, sub) in enumerate(df.groupby("condition")):
        sub = sub.sort_values("t_min")
        t = sub["t_min"].to_numpy()
        y = -np.log(1.0 - np.clip(sub["yield_pct"].to_numpy() / 100.0, 0.0, 0.99999))
        line, = ax.plot(t, y, marker=markers[i % len(markers)], linestyle="None",
                        label=f"Cond {int(c)} ({int(sub['T_C'].iloc[0])} °C)")
        f = fit_by_cond.get(int(c))
        if f is not None:
            tt = np.linspace(0, max(t) * 1.05, 50)
            yy = float(f["k_per_min"]) * tt + float(f.get("intercept", 0.0))
            ax.plot(tt, yy, "-", color=line.get_color())
    ax.set_xlabel("Reaction time (min)")
    ax.set_ylabel(r"$-\ln(1 - X)$")
    ax.set_title(title or "Pseudo-first-order kinetic plots")
    ax.grid(alpha=0.3)
    ax.legend(loc="lower right", fontsize=9)
    fig.tight_layout()
    fig.savefig(output_path, dpi=160)
    plt.close(fig)
    return {"path": output_path}


def plot_arrhenius(
    arr_table: pd.DataFrame,
    fit: Dict[str, float],
    output_path: str,
    title: Optional[str] = None,
) -> Dict[str, str]:
    """Plot ``ln k`` vs ``1/T`` and the fitted line.

    ``arr_table`` must have ``inv_T_per_K`` and ``ln_k`` columns; ``fit``
    must contain ``slope_K`` and ``intercept_ln_A``.

    Returns ``{"path": output_path}``.
    """
    _ensure_dir(output_path)
    fig, ax = plt.subplots(figsize=(6.5, 4.6))
    x = arr_table["inv_T_per_K"].to_numpy()
    y = arr_table["ln_k"].to_numpy()
    ax.scatter(x, y, color="navy", s=55, zorder=3, label="Experimental data")
    xx = np.linspace(min(x) * 0.995, max(x) * 1.005, 50)
    yy = float(fit["slope_K"]) * xx + float(fit["intercept_ln_A"])
    ax.plot(xx, yy, "-", color="firebrick",
            label=f"Linear fit (slope = {fit['slope_K']:.0f} K)")
    ax.set_xlabel("1/T (K⁻¹)")
    ax.set_ylabel("ln k (k in min⁻¹)")
    ax.text(
        0.05, 0.10,
        f"Ea = {fit['Ea_kJ_per_mol']:.2f} kJ/mol\nR² = {fit['rsq']:.4f}",
        transform=ax.transAxes,
        bbox=dict(boxstyle="round", facecolor="white", alpha=0.85),
    )
    ax.set_title(title or "Arrhenius plot")
    ax.grid(alpha=0.3)
    ax.legend(loc="upper right", fontsize=9)
    fig.tight_layout()
    fig.savefig(output_path, dpi=160)
    plt.close(fig)
    return {"path": output_path}


def plot_residuals(
    residual_tables: Sequence[Tuple[int, pd.DataFrame]],
    output_path: str,
    title: Optional[str] = None,
) -> Dict[str, str]:
    """Plot per-condition residuals of the pseudo-first-order fit.

    ``residual_tables`` is a sequence of ``(condition, dataframe)``
    tuples whose dataframe has columns ``t_min`` and ``residual``.

    Returns ``{"path": output_path}``.
    """
    _ensure_dir(output_path)
    fig, ax = plt.subplots(figsize=(6.5, 4.6))
    markers = ["o", "s", "^", "D"]
    for i, (c, rt) in enumerate(residual_tables):
        ax.scatter(
            rt["t_min"], rt["residual"],
            marker=markers[i % len(markers)],
            label=f"Cond {int(c)}",
        )
    ax.axhline(0.0, color="black", linewidth=0.8)
    ax.set_xlabel("Reaction time (min)")
    ax.set_ylabel(r"residual of $-\ln(1 - X)$")
    ax.set_title(title or "Residual diagnostic")
    ax.grid(alpha=0.3)
    ax.legend(fontsize=9)
    fig.tight_layout()
    fig.savefig(output_path, dpi=160)
    plt.close(fig)
    return {"path": output_path}

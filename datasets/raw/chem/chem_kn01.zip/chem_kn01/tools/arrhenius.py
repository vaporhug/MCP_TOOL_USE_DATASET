"""Arrhenius / Eyring linearisation, KIE ratios, residual diagnostics.

Functions
---------
arrhenius_table(T_K_array, k_array)
fit_arrhenius_linear(T_K_array, k_array)
predict_k_arrhenius(Ea_J_per_mol, A_per_min, T_K)
fit_eyring_linear(T_K_array, k_array)
isotope_effect_ratio(k_H, k_D)
isotope_effect_arrhenius(EaH, AH, EaD, AD, T_K)
residual_table(t, X, k_per_min, intercept)
diagnose_pseudo_first_order(t, X, threshold_rsq)
compare_models(rsq_first, rsq_second)
sort_conditions_for_arrhenius(table)
"""
from __future__ import annotations

from typing import Dict, List

import numpy as np
import pandas as pd

R_GAS = 8.31446  # J / (mol K)
KB = 1.380649e-23  # J/K
H_PLANCK = 6.62607015e-34  # J s
NA = 6.02214076e23


# --------------------------------------------------------------------------
# Arrhenius
# --------------------------------------------------------------------------
def arrhenius_table(T_K_array: np.ndarray, k_array: np.ndarray) -> pd.DataFrame:
    """Build a tidy linearised-Arrhenius table.

    Columns: ``T_K``, ``inv_T_per_K``, ``k_per_min``, ``ln_k``.
    Reproduces the ``Table 4`` layout of the paper.
    """
    T = np.asarray(T_K_array, dtype=np.float64)
    k = np.asarray(k_array, dtype=np.float64)
    if T.size != k.size:
        raise ValueError("T and k must have same length")
    return pd.DataFrame({
        "T_K": T,
        "inv_T_per_K": 1.0 / T,
        "k_per_min": k,
        "ln_k": np.log(k),
    })


def fit_arrhenius_linear(T_K_array: np.ndarray, k_array: np.ndarray) -> Dict[str, float]:
    """Linear fit of ``ln k`` against ``1/T`` -> Ea (kJ/mol), A (min^-1).

    Returns
    -------
    dict
        ``slope_K``           -- d ln k / d (1/T)
        ``Ea_J_per_mol``      -- ``-slope * R`` (J/mol)
        ``Ea_kJ_per_mol``     -- ``Ea_J_per_mol / 1000``
        ``intercept_ln_A``    -- intercept of the linear fit
        ``A_per_min``         -- ``exp(intercept)``
        ``rsq``, ``n_points``.
    """
    T = np.asarray(T_K_array, dtype=np.float64)
    k = np.asarray(k_array, dtype=np.float64)
    if T.size < 2:
        raise ValueError("need >=2 temperature points")
    x = 1.0 / T
    y = np.log(k)
    A_mat = np.column_stack([x, np.ones_like(x)])
    sol, *_ = np.linalg.lstsq(A_mat, y, rcond=None)
    slope, intercept = float(sol[0]), float(sol[1])
    yhat = slope * x + intercept
    ss_res = float(((y - yhat) ** 2).sum())
    ss_tot = float(((y - y.mean()) ** 2).sum()) or 1.0
    Ea_J = -slope * R_GAS
    return {
        "slope_K": slope,
        "Ea_J_per_mol": Ea_J,
        "Ea_kJ_per_mol": Ea_J / 1000.0,
        "intercept_ln_A": intercept,
        "A_per_min": float(np.exp(intercept)),
        "rsq": 1.0 - ss_res / ss_tot,
        "n_points": int(T.size),
    }


def predict_k_arrhenius(Ea_J_per_mol: float, A_per_min: float, T_K: float) -> float:
    """Return predicted k (min^-1) at a given temperature."""
    return float(A_per_min * np.exp(-float(Ea_J_per_mol) / (R_GAS * float(T_K))))


# --------------------------------------------------------------------------
# Eyring (transition-state theory) linearisation: ln(k/T) = -dH^/RT + ln(kB/h)+dS^/R
# --------------------------------------------------------------------------
def fit_eyring_linear(T_K_array: np.ndarray, k_array: np.ndarray) -> Dict[str, float]:
    """Linear fit of ``ln(k/T)`` vs ``1/T`` -> ΔH^(J/mol), ΔS^(J/(mol K)).

    The pre-exponential of the Eyring relation is ``kB / h`` and the
    transmission coefficient is taken to be 1.  The k values must be in
    consistent units; if expressed in min^-1 they are first converted to
    s^-1 for the entropy intercept.

    Returns ``{"dH_J_per_mol", "dH_kJ_per_mol", "dS_J_per_mol_K",
    "rsq", "n_points"}``.
    """
    T = np.asarray(T_K_array, dtype=np.float64)
    k_min = np.asarray(k_array, dtype=np.float64)
    k_s = k_min / 60.0
    x = 1.0 / T
    y = np.log(k_s / T)
    A_mat = np.column_stack([x, np.ones_like(x)])
    sol, *_ = np.linalg.lstsq(A_mat, y, rcond=None)
    slope, intercept = float(sol[0]), float(sol[1])
    yhat = slope * x + intercept
    ss_res = float(((y - yhat) ** 2).sum())
    ss_tot = float(((y - y.mean()) ** 2).sum()) or 1.0
    dH = -slope * R_GAS
    dS = (intercept - np.log(KB / H_PLANCK)) * R_GAS
    return {
        "dH_J_per_mol": dH,
        "dH_kJ_per_mol": dH / 1000.0,
        "dS_J_per_mol_K": float(dS),
        "rsq": 1.0 - ss_res / ss_tot,
        "n_points": int(T.size),
    }


# --------------------------------------------------------------------------
# Kinetic isotope effect helpers (kept for tool-surface coverage)
# --------------------------------------------------------------------------
def isotope_effect_ratio(k_H: float, k_D: float) -> Dict[str, float]:
    """Return KIE = k_H / k_D and ln(KIE)."""
    r = float(k_H) / float(k_D)
    return {"kie": r, "ln_kie": float(np.log(r))}


def isotope_effect_arrhenius(
    EaH_J_per_mol: float,
    AH_per_min: float,
    EaD_J_per_mol: float,
    AD_per_min: float,
    T_K: float,
) -> Dict[str, float]:
    """Return KIE(T) given Arrhenius parameters for H and D species."""
    kH = predict_k_arrhenius(EaH_J_per_mol, AH_per_min, T_K)
    kD = predict_k_arrhenius(EaD_J_per_mol, AD_per_min, T_K)
    return {
        "T_K": float(T_K),
        "k_H": kH,
        "k_D": kD,
        **isotope_effect_ratio(kH, kD),
    }


# --------------------------------------------------------------------------
# residual diagnostics + model comparison
# --------------------------------------------------------------------------
def residual_table(
    t_min: np.ndarray,
    X: np.ndarray,
    k_per_min: float,
    intercept: float = 0.0,
) -> pd.DataFrame:
    """Per-point residuals of the pseudo-first-order linear fit.

    Columns: ``t_min``, ``y_obs``, ``y_pred``, ``residual``.  The
    transformation is ``y = -ln(1 - X)``.
    """
    t = np.asarray(t_min, dtype=np.float64)
    y_obs = -np.log(1.0 - np.clip(np.asarray(X, dtype=np.float64), 0.0, 0.99999))
    y_pred = float(k_per_min) * t + float(intercept)
    return pd.DataFrame({
        "t_min": t,
        "y_obs": y_obs,
        "y_pred": y_pred,
        "residual": y_obs - y_pred,
    })


def diagnose_pseudo_first_order(
    t_min: np.ndarray,
    X: np.ndarray,
    threshold_rsq: float = 0.90,
) -> Dict[str, object]:
    """Return ``{"rsq", "passes", "max_abs_residual", "n_points"}``.

    The default threshold (0.90) is consistent with the paper's
    discussion: conditions 1, 2, 3 satisfy it; condition 4 (R^2 ~ 0.7)
    does not, signalling that the pseudo-first-order assumption breaks
    down at low catalyst loading and low ethanol excess.
    """
    from .rate_law import fit_pseudo_first_order_OLS  # local import
    fit = fit_pseudo_first_order_OLS(t_min, X)
    rt = residual_table(t_min, X, fit["k_per_min"], fit["intercept"])
    return {
        "rsq": fit["rsq"],
        "passes": bool(fit["rsq"] >= float(threshold_rsq)),
        "max_abs_residual": float(rt["residual"].abs().max()),
        "n_points": fit["n_points"],
    }


def compare_models(rsq_first_order: float, rsq_second_order: float) -> Dict[str, object]:
    """Pick between first- and second-order fits using a 0.05 R^2 margin.

    Returns ``{"selected", "delta_rsq"}``.  ``selected`` is one of
    ``"first_order"``, ``"second_order"``, or ``"tie"``.
    """
    delta = float(rsq_second_order) - float(rsq_first_order)
    if abs(delta) < 0.05:
        return {"selected": "tie", "delta_rsq": delta}
    return {
        "selected": "second_order" if delta > 0 else "first_order",
        "delta_rsq": delta,
    }


def sort_conditions_for_arrhenius(per_condition_fits: List[Dict[str, float]]) -> pd.DataFrame:
    """Sort a list of {condition, T_K, k_per_min, rsq} dicts by T_K.

    Useful as the input to :func:`fit_arrhenius_linear`.
    """
    df = pd.DataFrame(per_condition_fits)
    return df.sort_values("T_K").reset_index(drop=True)

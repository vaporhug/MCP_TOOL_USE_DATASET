"""I/O helpers for kinetics task.

Functions
---------
load_yield_time_course(path)
load_condition_metadata(path)
load_feedstock_acid_value(path)
yield_to_conversion(yield_pct)
group_by_condition(df)
arrhenius_subset(df, conditions)
"""
from __future__ import annotations

from typing import Dict, Iterable, List

import numpy as np
import pandas as pd


def load_yield_time_course(path: str) -> pd.DataFrame:
    """Load the long-format yield-time-course table.

    Expected columns
    ----------------
    condition, T_C, T_K, KOH_wt_pct, EtOH_to_oil_molar, t_min, yield_pct.

    Returns
    -------
    pandas.DataFrame
        sorted by ``condition`` then ``t_min``.
    """
    df = pd.read_csv(path)
    needed = {"condition", "T_C", "T_K", "KOH_wt_pct",
              "EtOH_to_oil_molar", "t_min", "yield_pct"}
    missing = needed - set(df.columns)
    if missing:
        raise ValueError(f"missing columns: {sorted(missing)}")
    df = df.sort_values(["condition", "t_min"]).reset_index(drop=True)
    return df


def load_condition_metadata(path: str) -> pd.DataFrame:
    """Load the per-condition metadata (T, KOH, EtOH:oil, sampling, model).

    Columns
    -------
    condition, T_C, T_K, KOH_wt_pct, EtOH_to_oil_molar, oil_charge_g,
    stir_rpm, sampling_times_min, kinetic_model_assumed, arrhenius_set.
    """
    return pd.read_csv(path)


def load_feedstock_acid_value(path: str) -> pd.DataFrame:
    """Load the crude/pretreated acid-value and FFA% table."""
    return pd.read_csv(path)


def yield_to_conversion(yield_pct: np.ndarray) -> np.ndarray:
    """Convert percentage yield to fractional conversion ``X = yield/100``.

    Used in the pseudo-first-order ``-ln(1 - X)`` linearisation. Values are
    clipped just below 1.0 to avoid log singularities for runs that touch
    100 % yield.
    """
    arr = np.asarray(yield_pct, dtype=np.float64) / 100.0
    arr = np.clip(arr, 0.0, 0.99999)
    return arr


def group_by_condition(df: pd.DataFrame) -> Dict[int, pd.DataFrame]:
    """Split a long-format yield table into a dict keyed by ``condition``."""
    out: Dict[int, pd.DataFrame] = {}
    for c, sub in df.groupby("condition", sort=True):
        out[int(c)] = sub.sort_values("t_min").reset_index(drop=True)
    return out


def arrhenius_subset(df: pd.DataFrame, conditions: Iterable[int]) -> pd.DataFrame:
    """Filter the yield-time-course table to a selected subset of condition IDs.

    The caller chooses which conditions to include based on condition_metadata.csv
    and the per-condition kinetic fit results. Returns a copy of df restricted to
    rows whose condition_id is in `conditions`.

    Args:
        df: full yield-time-course DataFrame.
        conditions: iterable of integer condition_ids to keep.

    Returns:
        DataFrame containing only the selected condition rows.
    """
    keep = list(int(c) for c in conditions)
    return df[df["condition"].isin(keep)].copy().reset_index(drop=True)


def summarise_yield_table(df: pd.DataFrame) -> pd.DataFrame:
    """Return a per-condition summary: T, max yield, time-to-max, n points."""
    rows: List[Dict[str, float]] = []
    for c, sub in df.groupby("condition"):
        ymax_idx = sub["yield_pct"].idxmax()
        rows.append({
            "condition": int(c),
            "T_C": float(sub["T_C"].iloc[0]),
            "max_yield_pct": float(sub.loc[ymax_idx, "yield_pct"]),
            "t_at_max_min": float(sub.loc[ymax_idx, "t_min"]),
            "n_points": int(len(sub)),
        })
    return pd.DataFrame(rows).sort_values("condition").reset_index(drop=True)

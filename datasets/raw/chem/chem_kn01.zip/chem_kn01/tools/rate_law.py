"""Rate-law primitives.

All fits use ``numpy.linalg.lstsq`` only -- no external optimisation
dependency -- so the agent chains primitives rather than invoking a
black-box fitter.

Functions
---------
finite_difference_rate(t, X)
forward_difference_rate(t, X)
pseudo_first_order_transform(X)
fit_pseudo_first_order_OLS(t, X)
fit_pseudo_first_order_zero_intercept(t, X)
fit_second_order_integrated(t, X)
michaelis_menten_velocity(S, Vmax, Km)
fit_michaelis_menten_lineweaver_burk(S, v)
fit_michaelis_menten_grid_nonlinear(S, v, Vmax_grid, Km_grid)
ln_concentration_remaining(X)
half_life_first_order(k_per_min)
"""
from __future__ import annotations

from typing import Dict, Tuple

import numpy as np


# --------------------------------------------------------------------------
# rate from time series
# --------------------------------------------------------------------------
def finite_difference_rate(t_min: np.ndarray, X: np.ndarray) -> Dict[str, np.ndarray]:
    """Central finite-difference dX/dt over a time series.

    The first and last points use forward / backward differences so the
    output has the same length as the input.

    Returns ``{"t_min": <same-as-input>, "dX_dt": <per-min>}``.
    """
    t = np.asarray(t_min, dtype=np.float64)
    x = np.asarray(X, dtype=np.float64)
    if t.size != x.size or t.size < 2:
        raise ValueError("need same-length arrays of size >= 2")
    dxdt = np.empty_like(x)
    dxdt[0] = (x[1] - x[0]) / (t[1] - t[0])
    dxdt[-1] = (x[-1] - x[-2]) / (t[-1] - t[-2])
    for i in range(1, x.size - 1):
        dxdt[i] = (x[i + 1] - x[i - 1]) / (t[i + 1] - t[i - 1])
    return {"t_min": t, "dX_dt": dxdt}


def forward_difference_rate(t_min: np.ndarray, X: np.ndarray) -> Dict[str, np.ndarray]:
    """Forward finite-difference dX/dt; output length is ``len(t)-1``."""
    t = np.asarray(t_min, dtype=np.float64)
    x = np.asarray(X, dtype=np.float64)
    dxdt = (x[1:] - x[:-1]) / (t[1:] - t[:-1])
    t_mid = 0.5 * (t[1:] + t[:-1])
    return {"t_mid_min": t_mid, "dX_dt": dxdt}


# --------------------------------------------------------------------------
# pseudo-first-order
# --------------------------------------------------------------------------
def pseudo_first_order_transform(X: np.ndarray) -> np.ndarray:
    """Compute the linearising transformation ``y = -ln(1 - X)``.

    Inputs are clipped to (0, 0.99999) to avoid singularities.
    """
    x = np.clip(np.asarray(X, dtype=np.float64), 0.0, 0.99999)
    return -np.log(1.0 - x)


def _ols_with_intercept(x: np.ndarray, y: np.ndarray) -> Tuple[float, float, float]:
    A = np.column_stack([x, np.ones_like(x)])
    sol, *_ = np.linalg.lstsq(A, y, rcond=None)
    slope, intercept = float(sol[0]), float(sol[1])
    yhat = slope * x + intercept
    ss_res = float(((y - yhat) ** 2).sum())
    ss_tot = float(((y - y.mean()) ** 2).sum()) or 1.0
    return slope, intercept, 1.0 - ss_res / ss_tot


def fit_pseudo_first_order_OLS(t_min: np.ndarray, X: np.ndarray) -> Dict[str, float]:
    """Fit ``-ln(1-X) = k*t + c`` by ordinary least squares (intercept-allowed).

    The fitted slope is the apparent pseudo-first-order rate constant
    ``k`` (min^-1). The intercept can absorb an early-time burst
    characteristic of a pre-equilibrated catalytic system. Pair with
    ``fit_pseudo_first_order_zero_intercept`` if a through-origin form
    is required.

    Returns ``{"k_per_min", "intercept", "rsq", "n_points"}``.
    """
    t = np.asarray(t_min, dtype=np.float64)
    y = pseudo_first_order_transform(X)
    slope, intercept, rsq = _ols_with_intercept(t, y)
    return {
        "k_per_min": slope,
        "intercept": intercept,
        "rsq": rsq,
        "n_points": int(t.size),
    }


def fit_pseudo_first_order_zero_intercept(t_min: np.ndarray, X: np.ndarray) -> Dict[str, float]:
    """Fit ``-ln(1-X) = k*t`` constrained through the origin.

    Uses ``k = sum(t*y)/sum(t**2)``. Use when the intended convention is
    a through-origin first-order regression (no early-time intercept).
    """
    t = np.asarray(t_min, dtype=np.float64)
    y = pseudo_first_order_transform(X)
    k = float((t * y).sum() / (t * t).sum())
    yhat = k * t
    ss_res = float(((y - yhat) ** 2).sum())
    ss_tot = float(((y - y.mean()) ** 2).sum()) or 1.0
    return {
        "k_per_min": k,
        "intercept": 0.0,
        "rsq": 1.0 - ss_res / ss_tot,
        "n_points": int(t.size),
    }


def half_life_first_order(k_per_min: float) -> float:
    """Return the first-order half-life ``ln(2)/k`` in minutes."""
    return float(np.log(2.0) / float(k_per_min))


# --------------------------------------------------------------------------
# second-order integrated rate law (for diagnostics / model selection)
# --------------------------------------------------------------------------
def fit_second_order_integrated(t_min: np.ndarray, X: np.ndarray) -> Dict[str, float]:
    """Fit ``X / (1 - X) = k * C0 * t`` (second-order integrated form).

    Returns ``{"k_C0_per_min", "intercept", "rsq", "n_points"}``.  The
    model is selected if its R^2 exceeds the pseudo-first-order R^2
    by a meaningful margin (e.g. 0.05).
    """
    t = np.asarray(t_min, dtype=np.float64)
    x = np.clip(np.asarray(X, dtype=np.float64), 0.0, 0.99999)
    y = x / (1.0 - x)
    slope, intercept, rsq = _ols_with_intercept(t, y)
    return {
        "k_C0_per_min": slope,
        "intercept": intercept,
        "rsq": rsq,
        "n_points": int(t.size),
    }


def ln_concentration_remaining(X: np.ndarray) -> np.ndarray:
    """Return ``ln(1 - X)``; convenient for plotting concentration profiles."""
    x = np.clip(np.asarray(X, dtype=np.float64), 0.0, 0.99999)
    return np.log(1.0 - x)


# --------------------------------------------------------------------------
# Michaelis-Menten primitives (kept in tool surface for cross-validation
# of the kinetic-model selector).
# --------------------------------------------------------------------------
def michaelis_menten_velocity(S: np.ndarray, Vmax: float, Km: float) -> np.ndarray:
    """Return v = Vmax * S / (Km + S)."""
    s = np.asarray(S, dtype=np.float64)
    return Vmax * s / (Km + s)


def fit_michaelis_menten_lineweaver_burk(S: np.ndarray, v: np.ndarray) -> Dict[str, float]:
    """Fit Michaelis-Menten by Lineweaver-Burk linearisation 1/v vs 1/S.

    Returns ``{"Vmax", "Km", "rsq"}``.  The slope of 1/v vs 1/S is
    Km/Vmax and the intercept is 1/Vmax; both must be positive for a
    physically meaningful fit.
    """
    s = np.asarray(S, dtype=np.float64)
    vv = np.asarray(v, dtype=np.float64)
    mask = (s > 0) & (vv > 0)
    s, vv = s[mask], vv[mask]
    x = 1.0 / s
    y = 1.0 / vv
    slope, intercept, rsq = _ols_with_intercept(x, y)
    Vmax = 1.0 / intercept if intercept > 0 else float("nan")
    Km = slope * Vmax if (Vmax == Vmax) else float("nan")
    return {"Vmax": Vmax, "Km": Km, "rsq": rsq}


def fit_michaelis_menten_grid_nonlinear(
    S: np.ndarray,
    v: np.ndarray,
    Vmax_grid: Tuple[float, float, int] = (0.1, 100.0, 200),
    Km_grid: Tuple[float, float, int] = (1e-3, 100.0, 200),
) -> Dict[str, float]:
    """Two-axis grid search for (Vmax, Km) that minimises ||v - v_pred||^2.

    Implemented purely with numpy so no external optimisation
    dependency is required.  Returns ``{"Vmax", "Km", "ss_res", "rsq"}``
    at the best grid point; use the result as a starting point for a
    manual refinement if needed.
    """
    s = np.asarray(S, dtype=np.float64)
    vv = np.asarray(v, dtype=np.float64)
    Vlo, Vhi, nV = Vmax_grid
    Klo, Khi, nK = Km_grid
    Vgrid = np.geomspace(Vlo, Vhi, int(nV))
    Kgrid = np.geomspace(Klo, Khi, int(nK))
    best = {"ss_res": float("inf"), "Vmax": float("nan"), "Km": float("nan")}
    for V in Vgrid:
        v_pred = V * s[None, :] / (Kgrid[:, None] + s[None, :])
        ss = ((v_pred - vv[None, :]) ** 2).sum(axis=1)
        i = int(np.argmin(ss))
        if float(ss[i]) < best["ss_res"]:
            best = {"ss_res": float(ss[i]), "Vmax": float(V), "Km": float(Kgrid[i])}
    ss_tot = float(((vv - vv.mean()) ** 2).sum()) or 1.0
    best["rsq"] = 1.0 - best["ss_res"] / ss_tot
    return best

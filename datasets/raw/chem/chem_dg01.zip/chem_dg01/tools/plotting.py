"""Plotting helpers that produce PNG figures and return the saved path.

All functions return ``{"path": <str>}``. Output directory is created
if it does not exist. The Agg backend is forced so plots are produced
without a display.
"""

from __future__ import annotations

import os
from typing import Dict, List, Sequence

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402


def _ensure_dir(path: str) -> None:
    parent = os.path.dirname(path)
    if parent and not os.path.exists(parent):
        os.makedirs(parent, exist_ok=True)


def plot_roc_curves(
    curves: Dict[str, Dict[str, np.ndarray]],
    output_path: str,
    title: str = "ROC curves on scaffold-split test set",
) -> Dict[str, str]:
    """Plot multiple ROC curves on a single axes.

    Parameters
    ----------
    curves : dict
        Mapping ``{model_name: {"fpr": np.ndarray, "tpr": np.ndarray, "auroc": float}}``.
    output_path : str
        Destination PNG path.
    title : str

    Returns
    -------
    dict
        ``{"path": <output_path>}``.
    """
    _ensure_dir(output_path)
    fig, ax = plt.subplots(figsize=(6.5, 5.5))
    for name, c in curves.items():
        label = f"{name} (AUC={c['auroc']:.3f})"
        ax.plot(c["fpr"], c["tpr"], lw=1.8, label=label)
    ax.plot([0, 1], [0, 1], "--", color="grey", lw=1.0)
    ax.set_xlabel("False positive rate")
    ax.set_ylabel("True positive rate")
    ax.set_title(title)
    ax.legend(loc="lower right", fontsize=9)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1.02)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path}


def plot_auroc_bars(
    model_aurocs: Dict[str, float],
    output_path: str,
    title: str = "Test AUROC by model (scaffold split)",
    error_bars: Dict[str, float] | None = None,
) -> Dict[str, str]:
    """Bar chart of test AUROC values per model.

    Parameters
    ----------
    model_aurocs : dict
        Mapping ``{model_name: auroc}``.
    output_path : str
    title : str
    error_bars : dict, optional
        ``{model_name: std}`` to draw symmetric error bars.

    Returns
    -------
    dict
        ``{"path": <output_path>}``.
    """
    _ensure_dir(output_path)
    names = list(model_aurocs.keys())
    values = [model_aurocs[n] for n in names]
    errs = (
        [error_bars.get(n, 0.0) for n in names] if error_bars else None
    )
    fig, ax = plt.subplots(figsize=(7.0, 4.5))
    xs = np.arange(len(names))
    ax.bar(xs, values, yerr=errs, color="#4C78A8", capsize=4)
    ax.set_xticks(xs)
    ax.set_xticklabels(names, rotation=25, ha="right")
    ax.set_ylabel("AUROC (test set)")
    ax.set_title(title)
    ax.set_ylim(0.5, max(0.85, max(values) + 0.05))
    for x, v in zip(xs, values):
        ax.text(x, v + 0.005, f"{v:.3f}", ha="center", fontsize=8)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path}


def plot_feature_importance(
    ranked_features: List[dict],
    output_path: str,
    title: str = "Top descriptors by importance",
) -> Dict[str, str]:
    """Horizontal bar chart of the top-K features.

    Parameters
    ----------
    ranked_features : list of dict
        Output of ``rank_top_features``: each dict has ``name`` and
        ``importance``.
    output_path : str
    title : str

    Returns
    -------
    dict
        ``{"path": <output_path>}``.
    """
    _ensure_dir(output_path)
    names = [f["name"] for f in ranked_features][::-1]
    vals = [f["importance"] for f in ranked_features][::-1]
    fig, ax = plt.subplots(figsize=(7.0, max(4.0, 0.32 * len(names))))
    ax.barh(np.arange(len(names)), vals, color="#54A24B")
    ax.set_yticks(np.arange(len(names)))
    ax.set_yticklabels(names, fontsize=9)
    ax.set_xlabel("Feature importance")
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path}


def plot_applicability_distance(
    distances: np.ndarray,
    output_path: str,
    threshold: float = 0.3,
    title: str = "Applicability domain: NN Tanimoto distance",
) -> Dict[str, str]:
    """Histogram of nearest-neighbour distances with threshold marker.

    Parameters
    ----------
    distances : np.ndarray
        From ``nearest_neighbor_tanimoto_distance``.
    output_path : str
    threshold : float
        Nearest-neighbour Tanimoto *distance* cutoff to mark on the
        histogram. The default ``threshold=0.3`` is the conventional QSAR
        applicability-domain cutoff (Tanimoto similarity >= 0.7,
        equivalently distance <= 0.3), matching
        ``applicability_domain.applicability_flag_by_distance``. Pass a
        larger value (e.g. 0.5 or 0.7) only to illustrate a looser cutoff.
    title : str

    Returns
    -------
    dict
        ``{"path": <output_path>}``.
    """
    _ensure_dir(output_path)
    fig, ax = plt.subplots(figsize=(6.5, 4.5))
    ax.hist(distances, bins=40, color="#E45756", edgecolor="black", alpha=0.8)
    ax.axvline(threshold, color="black", linestyle="--", lw=1.2,
               label=f"threshold = {threshold:.2f}")
    ax.set_xlabel("Nearest-neighbour Tanimoto distance to training set")
    ax.set_ylabel("Count")
    ax.set_title(title)
    ax.legend()
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path}


def plot_split_class_balance(
    y_train: Sequence[int],
    y_valid: Sequence[int],
    y_test: Sequence[int],
    output_path: str,
    title: str = "Class balance across scaffold splits",
) -> Dict[str, str]:
    """Stacked bar showing positive/negative counts per split.

    Parameters
    ----------
    y_train, y_valid, y_test : sequence of int
        Binary labels per split.
    output_path : str
    title : str

    Returns
    -------
    dict
        ``{"path": <output_path>}``.
    """
    _ensure_dir(output_path)
    splits = ["train", "valid", "test"]
    labels = [np.asarray(y_train), np.asarray(y_valid), np.asarray(y_test)]
    pos = [int((l == 1).sum()) for l in labels]
    neg = [int((l == 0).sum()) for l in labels]
    fig, ax = plt.subplots(figsize=(6.0, 4.0))
    xs = np.arange(len(splits))
    ax.bar(xs, neg, color="#B279A2", label="BBB-")
    ax.bar(xs, pos, bottom=neg, color="#4C78A8", label="BBB+")
    ax.set_xticks(xs)
    ax.set_xticklabels(splits)
    ax.set_ylabel("Number of compounds")
    ax.set_title(title)
    ax.legend()
    for i, (n, p) in enumerate(zip(neg, pos)):
        ax.text(i, n + p + 5, f"{n+p}", ha="center", fontsize=9)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"path": output_path}

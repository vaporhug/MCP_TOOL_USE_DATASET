"""Tool package for the BBBP scaffold-split benchmark task."""

"""Classifier training primitives.

Wrap scikit-learn estimators with a uniform fit/predict_proba API so
the agent does not need to import sklearn directly. Models exposed:
random forest, logistic regression, kernel SVM (RBF), and gradient
boosting. Each function returns the trained estimator and a dictionary
of provenance metadata.
"""

from __future__ import annotations

from typing import Any, Dict, Tuple

import numpy as np
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC


def train_random_forest(
    X_train: np.ndarray,
    y_train: np.ndarray,
    n_estimators: int = 500,
    max_features: str = "sqrt",
    random_state: int = 0,
) -> Tuple[RandomForestClassifier, Dict[str, Any]]:
    """Fit a random-forest classifier.

    Parameters
    ----------
    X_train : np.ndarray
        Feature matrix ``(n_samples, n_features)``.
    y_train : np.ndarray
        Binary labels ``(n_samples,)``.
    n_estimators : int
        Number of trees.
    max_features : str
        Sklearn ``max_features`` argument.
    random_state : int
        Seed.

    Returns
    -------
    model : RandomForestClassifier
    info : dict
        Training-set size and parameters.
    """
    clf = RandomForestClassifier(
        n_estimators=n_estimators,
        max_features=max_features,
        random_state=random_state,
        n_jobs=-1,
    )
    clf.fit(X_train, y_train)
    info = {
        "model": "random_forest",
        "n_train": int(X_train.shape[0]),
        "n_features": int(X_train.shape[1]),
        "n_estimators": n_estimators,
    }
    return clf, info


def train_logistic_regression(
    X_train: np.ndarray,
    y_train: np.ndarray,
    C: float = 1.0,
    max_iter: int = 2000,
    random_state: int = 0,
) -> Tuple[LogisticRegression, Dict[str, Any]]:
    """Fit a logistic-regression classifier with L2 penalty.

    Parameters
    ----------
    X_train, y_train : np.ndarray
    C : float
        Inverse regularisation strength.
    max_iter : int
        Maximum solver iterations.
    random_state : int

    Returns
    -------
    model : LogisticRegression
    info : dict
    """
    clf = LogisticRegression(
        C=C,
        penalty="l2",
        solver="liblinear",
        max_iter=max_iter,
        random_state=random_state,
    )
    clf.fit(X_train, y_train)
    info = {
        "model": "logistic_regression",
        "n_train": int(X_train.shape[0]),
        "n_features": int(X_train.shape[1]),
        "C": C,
    }
    return clf, info


def train_kernel_svm(
    X_train: np.ndarray,
    y_train: np.ndarray,
    C: float = 1.0,
    gamma: str = "scale",
    standardize: bool = True,
    random_state: int = 0,
) -> Tuple[Any, Dict[str, Any]]:
    """Fit an RBF-kernel SVM with optional standardisation.

    Parameters
    ----------
    X_train, y_train : np.ndarray
    C : float
        Penalty parameter.
    gamma : str or float
        Kernel coefficient.
    standardize : bool
        If True, fit a StandardScaler on the training features and
        attach it to the returned estimator wrapper.
    random_state : int

    Returns
    -------
    model : object
        Object exposing ``predict`` and ``predict_proba`` that
        internally applies the optional scaler.
    info : dict
    """

    class _ScaledSVM:
        def __init__(self, scaler, svc):
            self.scaler = scaler
            self.svc = svc

        def predict(self, X):
            Xs = self.scaler.transform(X) if self.scaler is not None else X
            return self.svc.predict(Xs)

        def predict_proba(self, X):
            Xs = self.scaler.transform(X) if self.scaler is not None else X
            return self.svc.predict_proba(Xs)

    scaler = StandardScaler().fit(X_train) if standardize else None
    Xt = scaler.transform(X_train) if scaler is not None else X_train
    svc = SVC(
        C=C,
        kernel="rbf",
        gamma=gamma,
        probability=True,
        random_state=random_state,
    )
    svc.fit(Xt, y_train)
    info = {
        "model": "kernel_svm",
        "n_train": int(X_train.shape[0]),
        "n_features": int(X_train.shape[1]),
        "C": C,
        "gamma": gamma,
        "standardize": standardize,
    }
    return _ScaledSVM(scaler, svc), info


def train_gradient_boosting(
    X_train: np.ndarray,
    y_train: np.ndarray,
    n_estimators: int = 200,
    max_depth: int = 4,
    learning_rate: float = 0.1,
    random_state: int = 0,
) -> Tuple[GradientBoostingClassifier, Dict[str, Any]]:
    """Fit a gradient boosting classifier (sklearn analogue of XGBoost).

    Parameters
    ----------
    X_train, y_train : np.ndarray
    n_estimators : int
    max_depth : int
    learning_rate : float
    random_state : int

    Returns
    -------
    model : GradientBoostingClassifier
    info : dict
    """
    clf = GradientBoostingClassifier(
        n_estimators=n_estimators,
        max_depth=max_depth,
        learning_rate=learning_rate,
        random_state=random_state,
    )
    clf.fit(X_train, y_train)
    info = {
        "model": "gradient_boosting",
        "n_train": int(X_train.shape[0]),
        "n_features": int(X_train.shape[1]),
        "n_estimators": n_estimators,
        "max_depth": max_depth,
    }
    return clf, info


def predict_proba_positive(model: Any, X: np.ndarray) -> np.ndarray:
    """Return the probability of the positive class for each row.

    Parameters
    ----------
    model : object
        Estimator with a ``predict_proba`` method.
    X : np.ndarray
        Feature matrix.

    Returns
    -------
    np.ndarray
        Vector of length ``X.shape[0]``.
    """
    proba = model.predict_proba(X)
    if proba.shape[1] != 2:
        raise ValueError("Expected binary classifier with 2 columns of proba")
    return proba[:, 1]

"""Cross-validation utilities for benchmarking molecular classifiers.

Run k-fold or scaffold-stratified CV by training one of the exposed
classifier factories on each fold and aggregating AUROC/AUPRC.
"""

from __future__ import annotations

from typing import Any, Callable, Dict, List

import numpy as np
from sklearn.model_selection import StratifiedKFold

from .evaluation import compute_auprc, compute_auroc


def stratified_kfold_indices(
    y: np.ndarray, n_splits: int = 5, seed: int = 0
) -> List[Dict[str, np.ndarray]]:
    """Yield train/valid index arrays for stratified k-fold CV.

    Parameters
    ----------
    y : np.ndarray
        Binary labels.
    n_splits : int
        Number of folds.
    seed : int

    Returns
    -------
    list of dict
        Each fold dict: ``{"train": np.ndarray, "valid": np.ndarray}``.
    """
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    folds = []
    for tr, va in skf.split(np.zeros_like(y), y):
        folds.append({"train": tr, "valid": va})
    return folds


def cv_auroc(
    train_factory: Callable[[np.ndarray, np.ndarray], Any],
    X: np.ndarray,
    y: np.ndarray,
    n_splits: int = 5,
    seed: int = 0,
) -> Dict[str, Any]:
    """Run stratified k-fold CV and report AUROC per fold + summary.

    Parameters
    ----------
    train_factory : callable
        Function ``(X_train, y_train) -> trained_estimator`` that
        already has any hyperparameters bound.
    X : np.ndarray
        Full feature matrix.
    y : np.ndarray
        Full label vector.
    n_splits : int
    seed : int

    Returns
    -------
    dict
        ``aurocs`` (per-fold), ``mean``, ``std``, ``n_splits``.
    """
    folds = stratified_kfold_indices(y, n_splits=n_splits, seed=seed)
    aurocs: List[float] = []
    auprcs: List[float] = []
    for fold in folds:
        tr, va = fold["train"], fold["valid"]
        model = train_factory(X[tr], y[tr])
        proba = model.predict_proba(X[va])[:, 1]
        aurocs.append(compute_auroc(y[va], proba))
        auprcs.append(compute_auprc(y[va], proba))
    arr = np.asarray(aurocs)
    return {
        "aurocs": [float(x) for x in aurocs],
        "auprcs": [float(x) for x in auprcs],
        "mean": float(arr.mean()),
        "std": float(arr.std(ddof=0)),
        "n_splits": int(n_splits),
    }

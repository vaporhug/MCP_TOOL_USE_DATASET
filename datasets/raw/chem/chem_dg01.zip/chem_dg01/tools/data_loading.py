"""Data loading utilities for the molecular property prediction task.

Functions read the BBBP CSV (SMILES + binary labels), validate molecular
structures via RDKit, and return cleaned arrays ready for downstream
featurization. All paths are relative to the task root.
"""

from __future__ import annotations

from typing import List, Tuple

import numpy as np
import pandas as pd
from rdkit import Chem
from rdkit import RDLogger


def _silence_rdkit() -> None:
    """Suppress RDKit warning spam to keep agent output clean."""
    RDLogger.DisableLog("rdApp.*")


def load_bbbp_csv(csv_path: str) -> pd.DataFrame:
    """Load the BBBP CSV into a pandas DataFrame.

    Parameters
    ----------
    csv_path : str
        Path to the BBBP CSV. The file must contain columns
        ``num``, ``name``, ``p_np``, ``smiles``.

    Returns
    -------
    pd.DataFrame
        DataFrame indexed sequentially. ``p_np`` is the binary label
        column (1 = positive class, 0 = negative class).
    """
    df = pd.read_csv(csv_path)
    expected = {"num", "name", "p_np", "smiles"}
    missing = expected - set(df.columns)
    if missing:
        raise ValueError(f"BBBP CSV missing columns: {missing}")
    return df.reset_index(drop=True)


def validate_smiles(smiles_list: List[str]) -> Tuple[List[int], List[str], int]:
    """Filter SMILES that RDKit can parse into a valid molecule.

    Parameters
    ----------
    smiles_list : list of str
        Raw SMILES strings from the CSV.

    Returns
    -------
    valid_indices : list of int
        Original positions of SMILES that RDKit successfully parsed.
    canonical_smiles : list of str
        Canonical SMILES for the valid set (same length as
        ``valid_indices``).
    n_invalid : int
        Number of SMILES rejected by RDKit (parse failure or NaN).
    """
    _silence_rdkit()
    valid_indices: List[int] = []
    canonical: List[str] = []
    n_invalid = 0
    for i, raw in enumerate(smiles_list):
        if raw is None or (isinstance(raw, float) and np.isnan(raw)):
            n_invalid += 1
            continue
        mol = Chem.MolFromSmiles(str(raw))
        if mol is None:
            n_invalid += 1
            continue
        valid_indices.append(i)
        canonical.append(Chem.MolToSmiles(mol))
    return valid_indices, canonical, n_invalid


def get_clean_dataset(csv_path: str) -> pd.DataFrame:
    """Convenience wrapper: load CSV and drop rows with invalid SMILES.

    Parameters
    ----------
    csv_path : str
        Path to the BBBP CSV.

    Returns
    -------
    pd.DataFrame
        DataFrame restricted to chemically valid SMILES with an extra
        ``canonical_smiles`` column.
    """
    df = load_bbbp_csv(csv_path)
    idx, canon, _ = validate_smiles(df["smiles"].tolist())
    cleaned = df.iloc[idx].copy().reset_index(drop=True)
    cleaned["canonical_smiles"] = canon
    return cleaned


def label_distribution(df: pd.DataFrame, label_col: str = "p_np") -> dict:
    """Return the count of each class label.

    Parameters
    ----------
    df : pd.DataFrame
        Dataset containing the binary label column.
    label_col : str
        Column with 0/1 labels.

    Returns
    -------
    dict
        Mapping ``{class_label_int: count_int}``.
    """
    counts = df[label_col].value_counts().to_dict()
    return {int(k): int(v) for k, v in counts.items()}

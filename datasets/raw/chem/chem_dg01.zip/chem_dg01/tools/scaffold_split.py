"""Bemis-Murcko scaffold splitting utilities.

Implements the deterministic scaffold split used by molecular ML
benchmarks: compounds are grouped by their Bemis-Murcko scaffold, the
scaffold sets are sorted by descending size, and the largest scaffolds
populate the train set first so that train/test molecules share
minimal scaffold overlap.
"""

from __future__ import annotations

from collections import defaultdict
from typing import Dict, List, Tuple

import numpy as np
from rdkit import Chem
from rdkit.Chem.Scaffolds import MurckoScaffold


def compute_scaffold(smiles: str, include_chirality: bool = False) -> str:
    """Return the Bemis-Murcko scaffold SMILES for a single molecule.

    Parameters
    ----------
    smiles : str
        Input SMILES.
    include_chirality : bool
        If True, retain stereochemistry in the scaffold SMILES.

    Returns
    -------
    str
        Canonical SMILES of the scaffold; empty string if the molecule
        cannot be parsed.
    """
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return ""
    try:
        scaffold = MurckoScaffold.MurckoScaffoldSmiles(
            mol=mol, includeChirality=include_chirality
        )
    except Exception:
        return ""
    return scaffold


def group_by_scaffold(smiles_list: List[str]) -> Dict[str, List[int]]:
    """Group compound indices by shared Bemis-Murcko scaffold.

    Parameters
    ----------
    smiles_list : list of str
        SMILES for each compound.

    Returns
    -------
    dict
        Mapping ``{scaffold_smiles: [list of compound indices]}``.
        Compounds without a valid scaffold (e.g. acyclic) share the
        empty-string key.
    """
    groups: Dict[str, List[int]] = defaultdict(list)
    for i, smi in enumerate(smiles_list):
        scaffold = compute_scaffold(smi)
        groups[scaffold].append(i)
    return dict(groups)


def scaffold_split_indices(
    smiles_list: List[str],
    train_frac: float = 0.8,
    valid_frac: float = 0.1,
    test_frac: float = 0.1,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Deterministic scaffold split returning train/valid/test indices.

    Larger scaffold groups are placed in the train set first so that the
    test partition contains the rarest scaffold classes, mimicking the
    out-of-distribution split used by MoleculeNet.

    Parameters
    ----------
    smiles_list : list of str
    train_frac, valid_frac, test_frac : float
        Fractions that must sum to 1.0.

    Returns
    -------
    train_idx, valid_idx, test_idx : np.ndarray
        Sorted arrays of compound indices (positions in
        ``smiles_list``) for each split.
    """
    if not np.isclose(train_frac + valid_frac + test_frac, 1.0):
        raise ValueError("Fractions must sum to 1.0")
    n_total = len(smiles_list)
    n_train = int(np.floor(train_frac * n_total))
    n_valid = int(np.floor(valid_frac * n_total))

    groups = group_by_scaffold(smiles_list)
    sorted_groups = sorted(
        groups.values(), key=lambda x: (len(x), min(x)), reverse=True
    )

    train_idx: List[int] = []
    valid_idx: List[int] = []
    test_idx: List[int] = []
    for grp in sorted_groups:
        if len(train_idx) + len(grp) <= n_train:
            train_idx.extend(grp)
        elif len(valid_idx) + len(grp) <= n_valid:
            valid_idx.extend(grp)
        else:
            test_idx.extend(grp)
    return (
        np.array(sorted(train_idx), dtype=np.int64),
        np.array(sorted(valid_idx), dtype=np.int64),
        np.array(sorted(test_idx), dtype=np.int64),
    )


def random_split_indices(
    n_total: int,
    train_frac: float = 0.8,
    valid_frac: float = 0.1,
    test_frac: float = 0.1,
    seed: int = 0,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Reproducible random split returning train/valid/test indices.

    Parameters
    ----------
    n_total : int
        Number of compounds.
    train_frac, valid_frac, test_frac : float
    seed : int
        RNG seed.

    Returns
    -------
    train_idx, valid_idx, test_idx : np.ndarray
        Disjoint sorted index arrays.
    """
    if not np.isclose(train_frac + valid_frac + test_frac, 1.0):
        raise ValueError("Fractions must sum to 1.0")
    rng = np.random.default_rng(seed)
    perm = rng.permutation(n_total)
    n_train = int(np.floor(train_frac * n_total))
    n_valid = int(np.floor(valid_frac * n_total))
    train = perm[:n_train]
    valid = perm[n_train : n_train + n_valid]
    test = perm[n_train + n_valid :]
    return np.sort(train), np.sort(valid), np.sort(test)


def scaffold_overlap(
    train_smiles: List[str], test_smiles: List[str]
) -> Dict[str, float]:
    """Quantify scaffold overlap between two compound sets.

    Parameters
    ----------
    train_smiles, test_smiles : list of str

    Returns
    -------
    dict
        ``n_train_scaffolds``, ``n_test_scaffolds``, ``n_shared``,
        ``test_scaffold_recovery_rate`` (fraction of test scaffolds
        also present in train).
    """
    train_set = {compute_scaffold(s) for s in train_smiles}
    test_set = {compute_scaffold(s) for s in test_smiles}
    shared = train_set & test_set
    return {
        "n_train_scaffolds": len(train_set),
        "n_test_scaffolds": len(test_set),
        "n_shared": len(shared),
        "test_scaffold_recovery_rate": (
            len(shared) / len(test_set) if test_set else 0.0
        ),
    }

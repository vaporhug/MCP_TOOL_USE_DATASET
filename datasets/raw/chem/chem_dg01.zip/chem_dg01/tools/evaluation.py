"""Evaluation primitives for binary molecular classifiers.

Computes ROC, PRC, AUROC, AUPRC, classification metrics, and
calibration summaries. All functions operate on numpy arrays of true
labels and predicted probabilities, returning JSON-serialisable
dictionaries.
"""

from __future__ import annotations

from typing import Any, Dict, List, Tuple

import numpy as np
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    confusion_matrix,
    f1_score,
    precision_recall_curve,
    roc_auc_score,
    roc_curve,
)


def compute_roc(y_true: np.ndarray, y_prob: np.ndarray) -> Dict[str, np.ndarray]:
    """Compute ROC curve points.

    Parameters
    ----------
    y_true : np.ndarray
        Binary 0/1 labels.
    y_prob : np.ndarray
        Predicted probability of the positive class.

    Returns
    -------
    dict
        ``fpr``, ``tpr``, ``thresholds`` arrays.
    """
    fpr, tpr, thr = roc_curve(y_true, y_prob)
    return {"fpr": fpr, "tpr": tpr, "thresholds": thr}


def compute_auroc(y_true: np.ndarray, y_prob: np.ndarray) -> float:
    """Compute the area under the ROC curve.

    Parameters
    ----------
    y_true : np.ndarray
    y_prob : np.ndarray

    Returns
    -------
    float
        AUROC in [0, 1].
    """
    return float(roc_auc_score(y_true, y_prob))


def compute_prc(y_true: np.ndarray, y_prob: np.ndarray) -> Dict[str, np.ndarray]:
    """Compute the precision-recall curve.

    Parameters
    ----------
    y_true : np.ndarray
    y_prob : np.ndarray

    Returns
    -------
    dict
        ``precision``, ``recall``, ``thresholds`` arrays.
    """
    precision, recall, thr = precision_recall_curve(y_true, y_prob)
    return {"precision": precision, "recall": recall, "thresholds": thr}


def compute_auprc(y_true: np.ndarray, y_prob: np.ndarray) -> float:
    """Compute the area under the precision-recall curve (average precision).

    Parameters
    ----------
    y_true : np.ndarray
    y_prob : np.ndarray

    Returns
    -------
    float
        Average precision score.
    """
    return float(average_precision_score(y_true, y_prob))


def classification_metrics(
    y_true: np.ndarray, y_pred: np.ndarray
) -> Dict[str, float]:
    """Threshold-dependent classification metrics for binary labels.

    Parameters
    ----------
    y_true : np.ndarray
        Ground-truth labels.
    y_pred : np.ndarray
        Predicted hard labels.

    Returns
    -------
    dict
        ``accuracy``, ``f1``, plus ``tn``, ``fp``, ``fn``, ``tp``.
    """
    cm = confusion_matrix(y_true, y_pred, labels=[0, 1])
    tn, fp, fn, tp = cm.ravel()
    return {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "f1": float(f1_score(y_true, y_pred, zero_division=0)),
        "tn": int(tn),
        "fp": int(fp),
        "fn": int(fn),
        "tp": int(tp),
    }


def evaluate_split(
    model: Any,
    X: np.ndarray,
    y: np.ndarray,
) -> Dict[str, Any]:
    """One-call evaluator: predict probabilities and report headline metrics.

    Parameters
    ----------
    model : object
        Estimator with ``predict_proba``.
    X : np.ndarray
        Feature matrix.
    y : np.ndarray
        Ground truth labels.

    Returns
    -------
    dict
        ``auroc``, ``auprc``, ``y_true``, ``y_prob`` (numpy arrays
        for downstream plotting), ``n``.
    """
    proba = model.predict_proba(X)[:, 1]
    return {
        "auroc": float(roc_auc_score(y, proba)),
        "auprc": float(average_precision_score(y, proba)),
        "y_true": np.asarray(y),
        "y_prob": np.asarray(proba),
        "n": int(len(y)),
    }


def aggregate_replicate_aurocs(
    auroc_list: List[float],
) -> Dict[str, float]:
    """Mean/std/min/max summary of an AUROC vector across seeds.

    Parameters
    ----------
    auroc_list : list of float

    Returns
    -------
    dict
        ``mean``, ``std``, ``min``, ``max``, ``n_replicates``.
    """
    arr = np.asarray(auroc_list, dtype=float)
    return {
        "mean": float(arr.mean()),
        "std": float(arr.std(ddof=0)),
        "min": float(arr.min()),
        "max": float(arr.max()),
        "n_replicates": int(arr.size),
    }


def benchmark_table(
    results: Dict[str, Dict[str, float]],
) -> List[Tuple[str, float, float]]:
    """Sort a dict of model->metric results by AUROC for tabular display.

    Parameters
    ----------
    results : dict
        Mapping ``{model_name: {"auroc": float, "auprc": float, ...}}``.

    Returns
    -------
    list of tuples
        Sorted list ``[(model_name, auroc, auprc)]`` descending by AUROC.
    """
    rows = []
    for name, metrics in results.items():
        rows.append((name, float(metrics["auroc"]), float(metrics.get("auprc", float("nan")))))
    rows.sort(key=lambda r: r[1], reverse=True)
    return rows

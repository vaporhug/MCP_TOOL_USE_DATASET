"""Applicability domain (AD) primitives.

Define how confidently a trained classifier should be applied to new
compounds. Two complementary methods are exposed: nearest-neighbour
Tanimoto distance to the training set and leverage on the descriptor
matrix. Each returns per-compound scores plus a binary in/out flag at
a configurable threshold.
"""

from __future__ import annotations

from typing import Dict, Tuple

import numpy as np


def nearest_neighbor_tanimoto_distance(
    fp_train: np.ndarray, fp_query: np.ndarray
) -> np.ndarray:
    """Compute 1-Tanimoto similarity to nearest training neighbour.

    Parameters
    ----------
    fp_train : np.ndarray
        Binary fingerprint matrix for training compounds.
    fp_query : np.ndarray
        Binary fingerprint matrix for query compounds.

    Returns
    -------
    np.ndarray
        Vector of length ``fp_query.shape[0]`` with the minimum
        Tanimoto distance from each query to any training compound
        (0 = exact match, 1 = no overlap).
    """
    fp_train = fp_train.astype(bool).astype(np.float32)
    fp_query = fp_query.astype(bool).astype(np.float32)
    inter = fp_query @ fp_train.T
    sums_q = fp_query.sum(axis=1, keepdims=True)
    sums_t = fp_train.sum(axis=1, keepdims=True).T
    union = sums_q + sums_t - inter
    with np.errstate(divide="ignore", invalid="ignore"):
        sim = np.where(union > 0, inter / union, 0.0)
    nearest = sim.max(axis=1)
    return 1.0 - nearest


def applicability_flag_by_distance(
    distances: np.ndarray, threshold: float = 0.7
) -> np.ndarray:
    """Flag compounds inside the applicability domain.

    Parameters
    ----------
    distances : np.ndarray
        Output of ``nearest_neighbor_tanimoto_distance``.
    threshold : float
        A query is "in domain" if its nearest-neighbour distance is at
        most ``threshold``.

    Returns
    -------
    np.ndarray
        Boolean array, True = inside domain.
    """
    return distances <= threshold


def leverage_scores(
    X_train: np.ndarray, X_query: np.ndarray, ridge: float = 1e-3
) -> Tuple[np.ndarray, float]:
    """Compute the OLS leverage of each query relative to the training set.

    Implements ``h_i = x_i^T (X^T X + ridge*I)^{-1} x_i`` where
    ``X = X_train``. The "warning leverage" cutoff is the classical
    ``h* = 3 * (p+1) / n`` used in QSAR.

    Parameters
    ----------
    X_train : np.ndarray
        Training descriptor matrix (continuous).
    X_query : np.ndarray
        Query descriptor matrix.
    ridge : float
        Tikhonov regularisation added to the Gram matrix.

    Returns
    -------
    leverages : np.ndarray
        Vector of leverage values for each query.
    h_star : float
        Standard warning cutoff ``3*(p+1)/n``.
    """
    n, p = X_train.shape
    gram = X_train.T @ X_train + ridge * np.eye(p)
    inv_gram = np.linalg.pinv(gram)
    leverages = np.einsum("ij,jk,ik->i", X_query, inv_gram, X_query)
    h_star = 3.0 * (p + 1) / n
    return leverages, float(h_star)


def applicability_flag_by_leverage(
    leverages: np.ndarray, h_star: float
) -> np.ndarray:
    """Flag compounds inside the leverage-based applicability domain.

    Parameters
    ----------
    leverages : np.ndarray
        Output of ``leverage_scores``.
    h_star : float
        Warning cutoff (also returned by ``leverage_scores``).

    Returns
    -------
    np.ndarray
        Boolean array, True = leverage <= h_star (inside domain).
    """
    return leverages <= h_star


def domain_coverage_summary(
    in_domain_flags: np.ndarray, y_true: np.ndarray, y_prob: np.ndarray
) -> Dict[str, float]:
    """Compare in-domain vs out-of-domain prediction quality.

    Parameters
    ----------
    in_domain_flags : np.ndarray
        Boolean per-compound mask.
    y_true : np.ndarray
        Binary labels for the same compounds.
    y_prob : np.ndarray
        Probability of the positive class.

    Returns
    -------
    dict
        ``coverage`` (fraction in domain), ``auroc_in``,
        ``auroc_out`` (or NaN if a partition is single-class).
    """
    from sklearn.metrics import roc_auc_score

    coverage = float(in_domain_flags.mean())
    out: Dict[str, float] = {"coverage": coverage}
    for tag, mask in [("in", in_domain_flags), ("out", ~in_domain_flags)]:
        yt = y_true[mask]
        yp = y_prob[mask]
        if yt.size == 0 or len(set(yt.tolist())) < 2:
            out[f"auroc_{tag}"] = float("nan")
        else:
            out[f"auroc_{tag}"] = float(roc_auc_score(yt, yp))
    return out

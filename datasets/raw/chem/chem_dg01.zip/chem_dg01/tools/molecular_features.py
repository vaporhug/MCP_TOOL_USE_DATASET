"""Molecular featurization primitives.

Wraps RDKit fingerprint and descriptor calls so the agent does not need
to import RDKit directly. Each function takes either a list of SMILES
strings or a list of RDKit Mol objects and returns a numpy array.
"""

from __future__ import annotations

from typing import List, Optional

import numpy as np
from rdkit import Chem, DataStructs
from rdkit.Chem import AllChem, MACCSkeys, Descriptors
from rdkit.ML.Descriptors import MoleculeDescriptors


def smiles_to_mols(smiles_list: List[str]) -> List[Optional[Chem.Mol]]:
    """Convert SMILES strings to RDKit Mol objects.

    Parameters
    ----------
    smiles_list : list of str

    Returns
    -------
    list of Mol or None
        ``None`` entries indicate parse failure for the matching index.
    """
    return [Chem.MolFromSmiles(s) if s else None for s in smiles_list]


def compute_morgan_fingerprints(
    smiles_list: List[str],
    radius: int = 2,
    nbits: int = 2048,
) -> np.ndarray:
    """Compute Morgan / ECFP fingerprints for a list of SMILES.

    Parameters
    ----------
    smiles_list : list of str
        Valid SMILES strings.
    radius : int
        Morgan radius. ``radius=2`` is ECFP4.
    nbits : int
        Number of bits in the folded fingerprint.

    Returns
    -------
    np.ndarray
        Binary fingerprint matrix of shape ``(n_compounds, nbits)``.
    """
    mols = smiles_to_mols(smiles_list)
    out = np.zeros((len(mols), nbits), dtype=np.float32)
    for i, mol in enumerate(mols):
        if mol is None:
            continue
        fp = AllChem.GetMorganFingerprintAsBitVect(mol, radius, nbits)
        DataStructs.ConvertToNumpyArray(fp, out[i])
    return out


def compute_maccs_fingerprints(smiles_list: List[str]) -> np.ndarray:
    """Compute the 167-bit MACCS structural-key fingerprints.

    Parameters
    ----------
    smiles_list : list of str

    Returns
    -------
    np.ndarray
        Binary matrix of shape ``(n_compounds, 167)``.
    """
    mols = smiles_to_mols(smiles_list)
    out = np.zeros((len(mols), 167), dtype=np.float32)
    for i, mol in enumerate(mols):
        if mol is None:
            continue
        fp = MACCSkeys.GenMACCSKeys(mol)
        DataStructs.ConvertToNumpyArray(fp, out[i])
    return out


def compute_rdkit_descriptors(
    smiles_list: List[str],
    n_descriptors: int = 100,
) -> np.ndarray:
    """Compute classical 2D physicochemical descriptors via RDKit.

    Parameters
    ----------
    smiles_list : list of str
    n_descriptors : int
        Number of descriptors to take from the head of ``Descriptors._descList``.

    Returns
    -------
    np.ndarray
        Matrix ``(n_compounds, n_descriptors)`` with NaN/inf replaced by
        finite sentinels.
    """
    mols = smiles_to_mols(smiles_list)
    names = [d[0] for d in Descriptors._descList][:n_descriptors]
    calc = MoleculeDescriptors.MolecularDescriptorCalculator(names)
    out = np.zeros((len(mols), n_descriptors), dtype=np.float64)
    for i, mol in enumerate(mols):
        if mol is None:
            continue
        try:
            vals = calc.CalcDescriptors(mol)
            out[i] = vals
        except Exception:
            out[i] = 0.0
    out = np.nan_to_num(out, nan=0.0, posinf=1e10, neginf=-1e10)
    return out


def get_descriptor_names(n_descriptors: int = 100) -> List[str]:
    """Return the names of the descriptors produced by ``compute_rdkit_descriptors``.

    Parameters
    ----------
    n_descriptors : int
        Same value passed to ``compute_rdkit_descriptors``.

    Returns
    -------
    list of str
        Descriptor names in the same column order.
    """
    return [d[0] for d in Descriptors._descList][:n_descriptors]


def tanimoto_similarity_matrix(fp_matrix: np.ndarray) -> np.ndarray:
    """Compute pairwise Tanimoto similarity for a binary fingerprint matrix.

    Parameters
    ----------
    fp_matrix : np.ndarray
        Binary matrix of shape ``(n_compounds, n_bits)``.

    Returns
    -------
    np.ndarray
        Symmetric ``(n_compounds, n_compounds)`` Tanimoto similarity
        matrix; diagonal entries are 1.
    """
    fp = fp_matrix.astype(bool).astype(np.float32)
    intersect = fp @ fp.T
    sums = fp.sum(axis=1, keepdims=True)
    union = sums + sums.T - intersect
    with np.errstate(divide="ignore", invalid="ignore"):
        sim = np.where(union > 0, intersect / union, 0.0)
    np.fill_diagonal(sim, 1.0)
    return sim

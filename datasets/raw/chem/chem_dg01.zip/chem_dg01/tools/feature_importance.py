"""Feature importance utilities for tree-based classifiers.

Convert RDKit-descriptor-based or fingerprint-based feature importances
from a trained estimator into a sorted ranking suitable for plotting.
"""

from __future__ import annotations

from typing import Any, List, Optional

import numpy as np


def extract_feature_importances(model: Any) -> np.ndarray:
    """Return per-feature importance scores from a tree ensemble.

    Parameters
    ----------
    model : object
        Fitted estimator exposing ``feature_importances_``.

    Returns
    -------
    np.ndarray
        Vector of importances.
    """
    if not hasattr(model, "feature_importances_"):
        raise ValueError(
            "Model does not expose feature_importances_; pass a tree ensemble."
        )
    return np.asarray(model.feature_importances_, dtype=float)


def rank_top_features(
    importances: np.ndarray,
    feature_names: Optional[List[str]] = None,
    top_k: int = 20,
) -> List[dict]:
    """Sort features by descending importance.

    Parameters
    ----------
    importances : np.ndarray
        Per-feature importance vector.
    feature_names : list of str, optional
        Names matching ``importances``. If None, names are
        ``feature_<idx>``.
    top_k : int
        Number of top features to return.

    Returns
    -------
    list of dict
        Each dict has ``rank``, ``index``, ``name``, ``importance``.
    """
    if feature_names is None:
        feature_names = [f"feature_{i}" for i in range(len(importances))]
    if len(feature_names) != len(importances):
        raise ValueError("feature_names length mismatch")
    order = np.argsort(-importances)[:top_k]
    return [
        {
            "rank": int(rank + 1),
            "index": int(idx),
            "name": str(feature_names[idx]),
            "importance": float(importances[idx]),
        }
        for rank, idx in enumerate(order)
    ]


def permutation_importance_simple(
    model: Any,
    X: np.ndarray,
    y: np.ndarray,
    n_repeats: int = 5,
    seed: int = 0,
) -> np.ndarray:
    """Lightweight permutation importance via AUROC drop.

    Parameters
    ----------
    model : object
        Fitted estimator with ``predict_proba``.
    X : np.ndarray
    y : np.ndarray
    n_repeats : int
        Times to permute each feature.
    seed : int

    Returns
    -------
    np.ndarray
        Mean drop in AUROC per feature (positive = important).
    """
    from sklearn.metrics import roc_auc_score

    rng = np.random.default_rng(seed)
    base = roc_auc_score(y, model.predict_proba(X)[:, 1])
    n_features = X.shape[1]
    drops = np.zeros(n_features, dtype=float)
    for j in range(n_features):
        s = 0.0
        for _ in range(n_repeats):
            Xp = X.copy()
            rng.shuffle(Xp[:, j])
            s += base - roc_auc_score(y, model.predict_proba(Xp)[:, 1])
        drops[j] = s / n_repeats
    return drops

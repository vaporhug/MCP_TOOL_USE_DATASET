"""Online bandit algorithms run on the ICU sepsis logged stream.

Each algorithm consumes a stream of contexts (state indices and/or feature
vectors) and an oracle reward function, sequentially picks an action,
observes a reward, and updates internal state. They return per-step
selected-action and observed-reward sequences which are then aggregated
into cumulative reward and regret curves.

The algorithms implemented:
    - epsilon-greedy (tabular per-state)
    - UCB1 (tabular per-state)
    - Thompson Sampling with Beta posterior (tabular per-state)
    - LinUCB disjoint (contextual / linear)

All four take the same data-generating loop interface so they can be
benchmarked head-to-head.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, List, Optional

import numpy as np


@dataclass
class BanditRunResult:
    """Container for a bandit run's per-step traces."""

    selected_actions: np.ndarray
    rewards: np.ndarray
    cumulative_reward: np.ndarray
    name: str

    def total_reward(self) -> float:
        return float(self.rewards.sum())


def _ensure_rng(seed: Optional[int]) -> np.random.Generator:
    return np.random.default_rng(seed)


def _allowed_actions(admissible_mask: np.ndarray | None, state: int,
                     n_actions: int) -> np.ndarray:
    """Return allowed actions for a state; terminal/no-support rows map to [0]."""
    if admissible_mask is None:
        return np.arange(n_actions, dtype=int)
    mask = np.asarray(admissible_mask, dtype=bool)
    allowed = np.where(mask[int(state)])[0]
    return allowed.astype(int) if len(allowed) else np.asarray([0], dtype=int)


def epsilon_greedy(
    contexts: np.ndarray,
    reward_oracle: Callable[[int, int], float],
    n_actions: int,
    n_states: int,
    epsilon: float = 0.1,
    seed: int = 0,
    admissible_mask: np.ndarray | None = None,
) -> BanditRunResult:
    """Tabular per-state epsilon-greedy bandit.

    Maintains a Q-table Q[s,a] = mean reward and a count table N[s,a].
    With probability ``epsilon`` picks uniformly at random; otherwise the
    argmax of Q.

    Parameters
    ----------
    contexts : np.ndarray, shape (T,)
        Sequence of state indices observed at each round.
    reward_oracle : callable
        ``reward_oracle(state, action) -> float`` returning the (stochastic)
        reward observed for that arm.
    n_actions, n_states : int
    epsilon : float
        Exploration probability.
    seed : int

    Returns
    -------
    BanditRunResult
    """
    rng = _ensure_rng(seed)
    Q = np.zeros((n_states, n_actions))
    N = np.zeros((n_states, n_actions), dtype=int)
    T = len(contexts)
    sel = np.empty(T, dtype=int)
    rew = np.empty(T, dtype=float)
    for t in range(T):
        s = int(contexts[t])
        allowed = _allowed_actions(admissible_mask, s, n_actions)
        if rng.random() < epsilon:
            a = int(rng.choice(allowed))
        else:
            a = int(allowed[np.argmax(Q[s, allowed])])
        r = float(reward_oracle(s, a))
        N[s, a] += 1
        Q[s, a] += (r - Q[s, a]) / N[s, a]
        sel[t] = a
        rew[t] = r
    return BanditRunResult(sel, rew, np.cumsum(rew), name="epsilon_greedy")


def ucb1(
    contexts: np.ndarray,
    reward_oracle: Callable[[int, int], float],
    n_actions: int,
    n_states: int,
    c: float = 1.4,
    seed: int = 0,
    admissible_mask: np.ndarray | None = None,
) -> BanditRunResult:
    """Tabular per-state UCB1 bandit.

    Selects ``argmax_a Q[s,a] + c * sqrt(log(t_s) / N[s,a])`` where ``t_s``
    is the number of times state s has been seen.

    Parameters
    ----------
    contexts : np.ndarray, shape (T,)
    reward_oracle : callable
    n_actions, n_states : int
    c : float
        Exploration coefficient.
    seed : int

    Returns
    -------
    BanditRunResult
    """
    rng = _ensure_rng(seed)
    Q = np.zeros((n_states, n_actions))
    N = np.zeros((n_states, n_actions), dtype=int)
    Ns = np.zeros(n_states, dtype=int)
    T = len(contexts)
    sel = np.empty(T, dtype=int)
    rew = np.empty(T, dtype=float)
    for t in range(T):
        s = int(contexts[t])
        allowed = _allowed_actions(admissible_mask, s, n_actions)
        Ns[s] += 1
        # Force trying each arm at least once per state
        untried = allowed[N[s, allowed] == 0]
        if len(untried):
            a = int(rng.choice(untried))
        else:
            ucb = Q[s, allowed] + c * np.sqrt(np.log(max(Ns[s], 2)) / N[s, allowed])
            a = int(allowed[np.argmax(ucb)])
        r = float(reward_oracle(s, a))
        N[s, a] += 1
        Q[s, a] += (r - Q[s, a]) / N[s, a]
        sel[t] = a
        rew[t] = r
    return BanditRunResult(sel, rew, np.cumsum(rew), name="ucb1")


def thompson_sampling_beta(
    contexts: np.ndarray,
    reward_oracle: Callable[[int, int], float],
    n_actions: int,
    n_states: int,
    alpha_prior: float = 1.0,
    beta_prior: float = 1.0,
    seed: int = 0,
    admissible_mask: np.ndarray | None = None,
) -> BanditRunResult:
    """Tabular Thompson Sampling with Beta(alpha,beta) posterior.

    Suitable for the ICU-sepsis MDP because the terminal reward is binary
    (survival = 1, death = 0). At each step samples theta_a ~ Beta and
    picks argmax.

    Parameters
    ----------
    contexts : np.ndarray, shape (T,)
    reward_oracle : callable
    n_actions, n_states : int
    alpha_prior, beta_prior : float
        Beta prior parameters.
    seed : int

    Returns
    -------
    BanditRunResult
    """
    rng = _ensure_rng(seed)
    alpha = np.full((n_states, n_actions), alpha_prior)
    beta = np.full((n_states, n_actions), beta_prior)
    T = len(contexts)
    sel = np.empty(T, dtype=int)
    rew = np.empty(T, dtype=float)
    for t in range(T):
        s = int(contexts[t])
        allowed = _allowed_actions(admissible_mask, s, n_actions)
        samples = rng.beta(alpha[s, allowed], beta[s, allowed])
        a = int(allowed[np.argmax(samples)])
        r = float(reward_oracle(s, a))
        # Clip to [0,1] if reward is not strictly Bernoulli
        r_clipped = max(0.0, min(1.0, r))
        alpha[s, a] += r_clipped
        beta[s, a] += 1.0 - r_clipped
        sel[t] = a
        rew[t] = r
    return BanditRunResult(sel, rew, np.cumsum(rew), name="thompson_sampling")


def linucb_disjoint(
    contexts: np.ndarray,
    feature_lookup: np.ndarray,
    reward_oracle: Callable[[int, int], float],
    n_actions: int,
    alpha: float = 1.0,
    seed: int = 0,
    admissible_mask: np.ndarray | None = None,
) -> BanditRunResult:
    """Disjoint LinUCB contextual bandit (Li et al. 2010).

    Each arm a maintains its own ridge regression on features x_s with
    A_a = I + sum x x^T and b_a = sum r * x. UCB score is
    x^T theta_a + alpha * sqrt(x^T A_a^-1 x).

    Parameters
    ----------
    contexts : np.ndarray, shape (T,)
        State indices used to look up the feature vector.
    feature_lookup : np.ndarray, shape (n_states, d)
        Feature matrix indexed by state.
    reward_oracle : callable
    n_actions : int
    alpha : float
        UCB exploration parameter.
    seed : int

    Returns
    -------
    BanditRunResult
    """
    rng = _ensure_rng(seed)
    d = feature_lookup.shape[1]
    A = np.stack([np.eye(d) for _ in range(n_actions)])  # (A, d, d)
    b = np.zeros((n_actions, d))
    T_steps = len(contexts)
    sel = np.empty(T_steps, dtype=int)
    rew = np.empty(T_steps, dtype=float)
    for t in range(T_steps):
        s = int(contexts[t])
        x = feature_lookup[s]
        allowed = _allowed_actions(admissible_mask, s, n_actions)
        ucbs = np.full(n_actions, -np.inf)
        for a in allowed:
            A_inv = np.linalg.inv(A[a])
            theta = A_inv @ b[a]
            ucbs[a] = x @ theta + alpha * np.sqrt(x @ A_inv @ x)
        a = int(np.argmax(ucbs))
        # Random tie break with rng to avoid systematic bias
        if (ucbs == ucbs[a]).sum() > 1:
            a = int(rng.choice(np.where(ucbs == ucbs[a])[0]))
        r = float(reward_oracle(s, a))
        A[a] += np.outer(x, x)
        b[a] += r * x
        sel[t] = a
        rew[t] = r
    return BanditRunResult(sel, rew, np.cumsum(rew), name="linucb")


def cumulative_regret(rewards_alg: np.ndarray, rewards_optimal: np.ndarray) -> np.ndarray:
    """Per-step cumulative regret = cum(opt) - cum(alg).

    Parameters
    ----------
    rewards_alg : np.ndarray, shape (T,)
        Rewards earned by the algorithm.
    rewards_optimal : np.ndarray, shape (T,)
        Rewards the oracle-best arm would have earned at the same contexts.

    Returns
    -------
    regret : np.ndarray, shape (T,)
        Non-decreasing cumulative regret.
    """
    return np.cumsum(rewards_optimal - rewards_alg)


def expected_survival_reward_table(
    T: np.ndarray,
    reward: np.ndarray,
    continuation_value: np.ndarray | None = None,
    gamma: float = 1.0,
    terminal_states: tuple | list | None = None,
) -> np.ndarray:
    """Counterfactual expected survival reward for each state-action pair.

    This is the reward oracle that should drive online bandit regret curves:
    for a candidate action at a logged state, compute the one-step expected
    reward ``E[R(s') | s,a]`` from the empirical transition model. If a
    continuation_value vector is supplied, the oracle instead returns
    ``E[R(s') + gamma V_cont(s') | s,a]`` with terminal states' continuation
    set to zero, i.e. a Q-value under the chosen downstream continuation
    policy. It avoids the invalid shortcut of reusing the realised trajectory
    outcome as every counterfactual arm's reward.
    """
    future = np.zeros_like(reward, dtype=float) if continuation_value is None else np.asarray(continuation_value, dtype=float).copy()
    if terminal_states is not None:
        for s in terminal_states:
            if 0 <= int(s) < len(future):
                future[int(s)] = 0.0
    return T @ (np.asarray(reward, dtype=float) + gamma * future)


def best_action_per_state(reward_table: np.ndarray,
                          admissible_mask: np.ndarray | None = None) -> np.ndarray:
    """Return the argmax-reward action for each state.

    Parameters
    ----------
    reward_table : np.ndarray, shape (n_states, n_actions)
        Expected reward for each (s, a) pair.
    admissible_mask : optional bool array, shape (n_states, n_actions)
        Restrict oracle actions to the same historically observed action
        support used by policy iteration. Rows with no admissible actions
        (terminal/sink states) return action 0.

    Returns
    -------
    best_a : np.ndarray, shape (n_states,)
    """
    q = np.asarray(reward_table, dtype=float)
    if admissible_mask is None:
        return np.argmax(q, axis=1)
    mask = np.asarray(admissible_mask, dtype=bool)
    qm = np.where(mask, q, -np.inf)
    out = np.zeros(q.shape[0], dtype=int)
    for s in range(q.shape[0]):
        if np.isfinite(qm[s]).any():
            out[s] = int(np.argmax(qm[s]))
    return out


def constrained_oracle_rewards(states: np.ndarray,
                               reward_table: np.ndarray,
                               admissible_mask: np.ndarray | None = None) -> np.ndarray:
    """Expected oracle reward for each logged context under the chosen action set."""
    best = best_action_per_state(reward_table, admissible_mask=admissible_mask)
    states = np.asarray(states, dtype=int)
    return np.asarray(reward_table, dtype=float)[states, best[states]]
